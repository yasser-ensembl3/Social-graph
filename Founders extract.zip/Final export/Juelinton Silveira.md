# Juelinton Silveira

## Position actuelle

**Titre** : CEO & Founder
**Entreprise** : Hopin
**Durée dans le rôle** : 2 months in role
**Durée dans l'entreprise** : 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Blending technology and art to turn every journey into an unforgettable story.

## Résumé

I’m the Founder of Hopin, a startup born in Montréal that blends AI and storytelling to create soulful travel experiences, helping people not just see the world, but feel it.

After 20+ years leading growth and strategy across the tech, telecom, and infrastructure sectors, I decided to return to what moves me most: building things from zero, where the map isn’t drawn and the manual doesn’t exist.

Recently Hopin was accepted into the Next AI Bootcamp 2025, one of the country’s leading accelerators for AI startups, a milestone that reflects our vision of using technology to make travel more human.

Beyond Hopin, I serve as an advisor and mentor to executives and founders navigating growth, strategy, and complex sales, helping them scale with clarity, narrative, and purpose.

I’m also the author of the newsletter “Vendas Complexas São Simples,” where I share frameworks and reflections on persuasion, leadership, and the art of selling ideas in complex environments.

I believe in strategy with soul, where clarity meets creativity, and where purpose becomes execution.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABrqd4BaVvsBlPvPNErm3S3Y-BNqux_044/
**Connexions partagées** : 4


---

# Juelinton Silveira

## Position actuelle

**Entreprise** : Hopin

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Juelinton Silveira

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403614297823535104 | Document |  |  | Being a founder is not glamorous.
It’s uncomfortable, lonely, and brutally honest.

So I wrote 20 Founder Truths no one told me at the beginning, but I wish they had.

Tell me if any of these hit you or

Comment “Part 2” and I’ll create a second part. | 3 | 2 | 0 | 3h | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:22.958Z |  | 2025-12-08T02:00:01.103Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7403059393048760320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFfAPnKpqH7A/feedshare-shrink_800/B4EZrv7oPwIwAg-/0/1764961984017?e=1766620800&v=beta&t=h4V0JDk3VtwwAM-3qDp4mPZGRBwA6UcNn3BtqOEYojE | You can understand a city by the way it builds innovation. And Curitiba has been doing that for decades. 
Yesterday, I visited the Pinhão Hub and reconnected with friends from the local innovation ecosystem.

For those who don’t know: Curitiba is one of Brazil’s most forward-thinking cities, known for smart urban planning, strong tech talent, and a startup community that keeps growing in depth and maturity.

Yesterday’s visit was even better thanks to the conversations with Paulo Krauss and Marcello Deoarez and a few great unexpected encounters with Luciano Carstens, Gustavo Possetti and ROMULO KRUTA.

We talked about Hopin, the rising AI movement in Montréal, and how the innovation ecosystems of Brazil and Canada can collaborate even more closely.

Innovation happens when different worlds meet.
Hopin is being built exactly at that intersection.

If you want to follow this journey across Brazil → Canada → the world, stay connected. Great things are coming.

And for those who follow my love for hidden stories: the last photo is from an actual World War II bunker built right under the Pinhão Hub, one of Curitiba’s many unexpected historical layers. | 23 | 9 | 1 | 1d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:22.959Z |  | 2025-12-06T13:15:01.495Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402712120242520064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8xwggqKktEw/feedshare-shrink_800/B4EZrql47MJgAk-/0/1764872397023?e=1766620800&v=beta&t=qlFjvZsYXNnOyqHpjL-Yr5Z6fiTA2Lm4B3HAXuwveoY | Proud to share that I’ve officially completed the NEXT AI Montréal Bootcamp! 

These past weeks have been an incredible opportunity to learn, grow, and connect with inspiring Founders, Scientists in Residence and Venture Managers. Grateful for the insights, the community, and the push to think bigger.

Being immersed in this environment has also accelerated the development of Hopin, the AI-powered travel companion I’m building to transform how people experience the world. The mentorship and frameworks I’ve learned here are already shaping our next product iterations.

If you're building an AI-driven venture and wondering whether NEXT AI could be the right next step for you, applications for the 2026 cohort are open until December 10.

If you can’t find the application link, just drop a comment and I’ll share it with you directly (links in posts usually hurt reach).

#NEXTAI #NEXTAIMontreal #AIStartups #Bootcamp #FounderJourney | 22 | 1 | 0 | 2d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:22.959Z |  | 2025-12-05T14:15:05.206Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402285552642867200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEe76rNpFzEVA/feedshare-shrink_2048_1536/B4EZrU9GKlHcA0-/0/1764509380084?e=1766620800&v=beta&t=_Xn8NKvigg2N9iEdOPvX0O5vaK5mkn2JifTWt3fwLxo | Um aviso incômodo para todo vendedor:
Os top performers não seguem um roteiro.
 
Em tempos de IA, parece que muitos se esqueceram que vendas complexas dependem de escuta ativa.
A inovação muda ferramentas, mas não o fundamento: entender o cliente ainda é a “tecnologia” de vendas mais importante.
 
Os melhores vendedores não se parecem com um vendedor, mas como um parceiro na tomada de decisão.
Fazem perguntas pra compreender as motivações ocultas do decisor.
“Chegar logo” à oferta não é a maior preocupação.
 
Por isso, técnicas como SPIN Selling devem ser visto menos como uma “lista de perguntas prontas”, e mais como um framework mental pra conduzir conversas para:
 
⫸ Mapear situação atual
⫸ Identificar fricções, ineficiências e dores fortes
⫸ Ampliar a consciência sobre o impacto de manter o problema
⫸ Ajudar o cliente a enxergar os ganhos de se resolver o problema
 
IA pode até ajudar a coletar informações e sugerir perguntas.
Mas o que faz a diferença é o trabalho humano de organizar o excesso de informação, destacando o que realmente é mais valioso pro cliente.
 
Portanto, lembre-se: continue sempre no comando do volante, e use as novas tecnologias apenas como um “turbo”. | 14 | 0 | 0 | 3d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:22.959Z |  | 2025-12-04T10:00:03.565Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401949590804910080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQk74NVkZxvQ/feedshare-shrink_2048_1536/B4EZrAGIfaHUAw-/0/1764159426065?e=1766620800&v=beta&t=__HulSd2baBJuagcGlQsTVrSJ2aIto9Zm3aNq3-UP20 | Escuta Ativa e Perguntas que Abrem Caminos

Escutar bem é, talvez, a habilidade mais subestimada em vendas complexas.
Vendedores medianos falam muito.
Vendedores excelentes perguntam pouco (mas perguntam certo) e ouvem tudo.
⸻
Por que escutar vende mais que falar?

Escuta ativa não é ficar em silêncio.
É investigar.
É conectar pontos.
É ouvir o “não dito”.

⫸ Entender contexto antes de oferecer solução
⫸ Captar emoções, motivações e política interna
⫸ Ajudar o cliente a enxergar o que ainda não viu
⫸ Se posicionar melhor frente à concorrência

Em vendas consultivas, ouvir é o trabalho.

⸻
Como praticar escuta ativa de verdade?

⫸ Interesse genuíno (não teatral)
⫸ Evitar interromper
⫸ Parafrasear: “se eu entendi bem…”
⫸ Observar linguagem corporal
⫸ Tomar notas sem perder conexão
⫸ Perguntar com propósito — não para cumprir checklist

A chave: menos ansiedade de vender, mais curiosidade de entender.

⸻
Perguntas que vendem (sem parecer vendas)

Boas perguntas criam clareza, confiança e movimento.

⫸ Perguntas abertas — expandem o diálogo
⫸ De impacto — geram reflexão imediata
⫸ De priorização — organizam o pensamento do cliente
⫸ De visão — conectam com o futuro desejado
⫸ De alinhamento — garantem entendimento
⫸ Sobre outras soluções — posicionam você no mapa competitivo

Perguntar não é invadir.
É iluminar.

⸻
O risco de não perguntar (ou perguntar mal)

Quando o vendedor não pergunta com intenção, ele:

⫸ Assume demais — e erra
⫸ Perde informações valiosas
⫸ Cria soluções genéricas
⫸ Não constrói rapport
⫸ Soa superficial

E quanto menos o cliente fala, menos ele compra.
⸻
Para aprofundar

⫸ SPIN Selling — Neil Rackham
⫸ As Armas da Persuasão — Robert Cialdini
⫸ O Corpo Fala — Pierre Weil & Roland Tompakow | 2 | 0 | 0 | 4d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:22.960Z |  | 2025-12-03T11:45:04.021Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7401273876279771137 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEyk5k8bLOeFQ/feedshare-shrink_800/B56Zq2wXCGI4Ag-/0/1764002723706?e=1766620800&v=beta&t=O3qWEGUtJF-hPdMxRClUdXG1-pId6PvFuWhEhfz88Nc | Você não lembra de viagens.
Você lembra dos momentos que te surpreenderam.

A questão é:
por que esperamos o acaso para viver esses momentos?

Para quem ficou curioso sobre o local da foto: 
Este é o Bar Plan de l’Aiguille, a parada icônica no caminho para o Aiguille du Midi, em Chamonix. Um café/bar perdido na neve, entre o silêncio das montanhas e a rota que leva até a face do Mont Blanc.

Direto de Montreal estamos construindo um companheiro de viagens que te ajudará a selecionar os melhores lugares para visitar, a Hopin! 

#viagem #turismo #IA | 6 | 1 | 0 | 6d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.381Z |  | 2025-12-01T15:00:01.124Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7401221042871967744 | Text |  |  | Viajar nunca foi o problema.
O problema sempre foi entender o que faz cada lugar ganhar alma.

Quando você chega em um ponto turístico clássico, o que recebe?
Um monte de panfletos com informações muitas vezes genéricas, repetidas e desconectadas da sua curiosidade naquele momento.

A verdade é que ninguém viaja por informações.
As pessoas viajam por histórias, significados, detalhes que não aparecem no Google.

É por isso que criamos a Hopin.
Uma forma de usar IA para transformar cada passo em descoberta.
Cada esquina tem uma curiosidade.
Cada cidade tem algo que desperta atenção, não só fotos.

Não para substituir guias.
Mas para devolver profundidade ao ato de viajar.

E estamos construindo isso publicamente. | 8 | 1 | 0 | 6d | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.381Z |  | 2025-12-01T11:30:04.658Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7400937912193830913 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFMZbUuC3u5tA/feedshare-shrink_800/B56Zq2zrxAG4Ak-/0/1764003596086?e=1766620800&v=beta&t=x0J2g0CArJ9oS3Xmzstdcq8K1C01zPtnOeL5TLIzxS8 | A maioria das pessoas visita um ponto turístico e só vê… o ponto turístico.
Mas cada lugar carrega uma história que nunca aparece na placa.

Por exemplo:
A estátua do Bruce Lee em Hong Kong ficou anos desaparecida durante a reforma da Avenue of Stars. Turistas cruzavam a cidade inteira tentando descobrir onde o “dragão” tinha ido parar, como uma caça ao tesouro involuntária. 🥋🔥
(Ainda bem que quando eu fui tava lá)

Viajar fica muito mais interessante quando você entende o que existe por trás do que você vê.

É isso que a Hopin quer trazer de volta:
não o “onde”, mas o porquê. | 13 | 1 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.382Z |  | 2025-11-30T16:45:01.044Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400549107473506305 | Text |  |  | Being a founder in Montréal teaches you two things fast:

The world doesn’t care about your idea.
But it pays attention when your idea solves something real.

Building Hopin here, inside a city that breathes culture, diversity and Tech reminds me every day why travel still has so much unexplored depth.

And why AI is finally mature enough to unlock it. | 10 | 0 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.382Z |  | 2025-11-29T15:00:02.775Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7400133864813281280 | Text |  |  | A experiência de viagem corporativa vai mudar e rápido.

Nos últimos meses, conversando com ISPs, operadoras, agências e áreas de RH, ficou claro um padrão:
todo mundo quer oferecer algo diferente, mas quase todos esbarram no mesmo problema.

Personalização não escala.
E escala não personaliza.

O resultado?
Benefícios que ninguém usa.
SVAs que não geram receita.
Agências oferecendo exatamente o mesmo produto que os concorrentes.
RH oferecendo “experiência” que não cria memória.

Mas existe um ponto de virada:
IA + geolocalização + modelos de contexto.

Isso permite que cada colaborador receba:
↳ histórias relevantes ao lugar onde está
↳ insights culturais
↳ curiosidades reais
↳ recomendações que fazem sentido para seu perfil
↳ uma jornada que parece única, não copiada

Isso não é luxo.
É retenção, percepção de valor e diferenciação.

E as empresas que entenderem isso primeiro vão liderar o próximo ciclo do turismo corporativo, retenção de assinantes e colaboradores. | 5 | 0 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.383Z |  | 2025-11-28T11:30:01.210Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7399809427341717504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6CPpj9Mf6og/feedshare-shrink_800/B4EZrByuB2HUAg-/0/1764187903564?e=1766620800&v=beta&t=MwPmcCYGsC1j2H6RaVyda6QKhi0Az4l1HH6_fgi3eK0 | I’m opening Hopin’s closed beta for a few people to test, completely free.
No commitment, just honest feedback.

Hopin was born to solve a simple problem:
travel has become a generic experience.
Same itineraries, same tips, same recommendations, no matter who you are.

We’re building a way to use contextual AI to turn every place into a real discovery.
Not “travel content”, but meaning.

If you’d like to join the beta, comment “Beta”
or tell me the most unforgettable place you’ve ever visited.

I’ll be selecting the first group later this week.

One of the most memorable places I’ve ever been was Cappadocia, waking up with hundreds of hot-air balloons rising around me felt surreal. | 31 | 10 | 1 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.384Z |  | 2025-11-27T14:00:49.289Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7399771577019494400 | Text |  |  | As empresas ainda tratam “experiência de viagem” como algo genérico.
Mas temos uma oportunidade enorme.

Agências de viagem, ISPs e áreas de RH poderiam estar oferecendo algo muito mais valioso do que um simples acesso a descontos ou roteiros padrão.

O que falta?
Personalização real. Contextual. Em escala.

A verdade é simples:
se uma empresa consegue entregar uma experiência memorável quando o colaborador viaja, ela melhora retenção, cultura e percepção de valor e sem aumentar custos.

A tecnologia já permite isso.
Só falta quem coloque de pé. | 6 | 0 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.385Z |  | 2025-11-27T11:30:25.069Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7399416751685533696 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHiW7Cnx011vg/feedshare-shrink_800/B4EZq3e234KoAk-/0/1764014911872?e=1766620800&v=beta&t=R61JLL3n-8-Pxndu_IjjmDKVpPkO5KyMZY5xNCxNtew | Estou abrindo o beta fechado da Hopin para algumas pessoas testarem gratuitamente.
Sem compromisso, só feedback honesto.

A Hopin nasce para resolver um problema simples:
hoje, viajar virou uma experiência genérica.
Mesmos roteiros, mesmas dicas, mesmas recomendações, independente de quem você é.

Estamos construindo uma forma de usar IA contextual para transformar cada lugar em descoberta real.
Não em “conteúdos de viagem”, mas em significado.

Se quiser participar do beta, comente “Beta” ou
escreva o nome do lugar mais inesquecível onde você já esteve.

Vou selecionar os primeiros grupos ainda esta semana.

(A foto é de Aiguille du Midi, em Chamonix. Até hoje, uma das viagens mais marcantes que já fiz!) | 42 | 21 | 2 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.385Z |  | 2025-11-26T12:00:28.117Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7399084507351584768 | Text |  |  | The next AI breakthrough won’t come from apps. It will come from context.

Few industries waste more contextual data than travel.

Travel today is “flat”:
same recommendations, same routes, same content regardless of who you are or why you’re there.

But that gap is opening a new frontier.
The combination of GenAI + geolocation + contextual memory enables something travel has never had:
experiences that adapt to the traveler in real time.

Not AI-assisted travel.
AI-shaped travel.

Hopin was born exactly from this insight.
A way to turn each place into a story, a feeling, a discovery without generic guides or templated information.

It’s not about information.
It’s about intelligence with context.

And this wave is only beginning. | 4 | 0 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.386Z |  | 2025-11-25T14:00:14.895Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7398750855467827200 | Text |  |  | A próxima onda da IA não estará nos apps. Vai estar no contexto.
E poucos mercados têm mais contexto desperdiçado do que o turismo.

Hoje, viajar continua sendo uma experiência “burra”:
mesmos roteiros, mesmas recomendações, mesmas respostas, independente de quem você é, de onde está e do que realmente procura.

Só que isso está mudando.
A combinação entre IA generativa + geolocalização + memória contextual abre espaço para algo novo:
experiências que se adaptam ao viajante, não o contrário.

Para mim, o ato de viajar não vai ser “assistido por IA”.
Vai ser reescrito por IA.

E as startups que explorarem essa interseção vão capturar um mercado gigantesco que ainda opera com ferramentas do século passado.

A Hopin nasceu exatamente desse ponto cego:
como transformar cada passagem por um lugar em uma história, uma sensação, uma descoberta sem depender de guias, roteiros prontos ou conteúdo genérico.

Não é sobre mais informação.
É sobre contexto.

E estamos só no começo. | 15 | 2 | 0 | 1w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.387Z |  | 2025-11-24T15:54:26.087Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7396667451922411520 | Video (LinkedIn Source) | blob:https://www.linkedin.com/282776c6-4d81-4fa4-bcc7-3056f876d3f2 | https://media.licdn.com/dms/image/v2/D4D05AQGEUHW-7DyMqg/videocover-high/B4DZqVBykiJABU-/0/1763436868699?e=1765778400&v=beta&t=GrJMGGixsG5EayTh8vnw2TcN8Vr2kDN4DKjD1ULXkVk | Quem roubou a Mona Lisa? 🖼️🎞️ | 4 | 0 | 0 | 2w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.387Z |  | 2025-11-18T21:55:43.974Z | https://www.linkedin.com/feed/update/urn:li:activity:7396653440678035456/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7396664757082013697 | Video (LinkedIn Source) | blob:https://www.linkedin.com/13483c03-79cf-42a2-94c9-05b6e9584282 | https://media.licdn.com/dms/image/v2/D4D05AQGGpXEtWcUSOQ/videocover-high/B4DZqVD4GzGkBU-/0/1763437415659?e=1765778400&v=beta&t=RJyzT96HraiHaN6ZZEhXsMPY8Sjr2EMFu5FgxaWjplA | Se você gosta de viajar descobrindo histórias que quase ninguém conhece, segue a página da Hopin
Estamos criando algo especial lá.

A prova?
A história da Mona Lisa não começa com um sorriso…
começa com um roubo.

Em 1911, um funcionário entrou no Louvre e encontrou apenas a moldura vazia.
O quadro tinha desaparecido.
Paris entrou em pânico.
Multidões foram ao museu só para olhar para o espaço vazio.
Os jornais enlouqueceram.
Até Picasso acabou interrogado.

E aqui está o twist:
foi esse roubo que transformou a Mona Lisa numa lenda mundial.

Antes, ela era só um retrato.
Depois… virou mito.

Na Hopin, estamos reunindo histórias assim
pequenos detalhes que mudaram o mundo e tornam cada viagem mais profunda.

Se curtir esse tipo de conteúdo, ja sabe, Hopin!
Vem acompanhar o que estamos construindo.

Travel. Feel. Remember. | 5 | 1 | 1 | 2w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.388Z |  | 2025-11-18T21:45:01.474Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7396510000845725696 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbKxDwGKDvjg/feedshare-shrink_800/B4EZqWupMqHUAk-/0/1763465402467?e=1766620800&v=beta&t=5S8oYeRm6GLdnLQgUrOK-NBwmxieDYjGwDxJXtJIUTM | A Mona Lisa não nasceu famosa.
Ela virou um mito por causa do dia em que desapareceu.

Em 1911, o Musée du Louvre descobriu a moldura vazia…
e Paris parou.
Multidões foram ao museu só para olhar para o espaço vazio.
Os jornais explodiram.
Até Picasso foi interrogado.

E o mais curioso disso tudo:
foi o roubo que transformou a pintura mais discreta do Louvre na obra mais famosa do mundo.

Se você gosta de histórias que mudam a forma como viajamos, vem acompanhar a Hopin .

Travel. Feel. Remember. | 8 | 0 | 0 | 2w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.389Z |  | 2025-11-18T11:30:04.712Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7396245802718953472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErfhd21PoCMw/feedshare-shrink_800/B4EZqPRPTvIIAg-/0/1763340253430?e=1766620800&v=beta&t=KyW9_FHmeRnlzfnyMe1UfQ3u6pt4Qbo70Oj966BT-u4 | [🇧🇷]
A Muralha da China foi construída com... ARROZ? 🤯

Sim, você leu certo! Mergulhe na história fascinante da Grande Muralha da China e descubra um dos segredos mais surpreendentes da engenharia antiga. Não foi cimento moderno, mas sim uma solução engenhosa e inesperada que garantiu a sua longevidade por séculos.

Este carrossel revela:
➡️ O desafio colossal de construir $21.000$ km de muralha.
➡️ A fórmula secreta que desafiou o tempo e os elementos.
➡️ E a poderosa lição que a criatividade milenar nos ensina hoje.

A inovação pode surgir dos lugares mais improváveis e um ingrediente humilde se tornou a espinha dorsal de uma das maiores maravilhas do mundo!

👉 O que o "arroz" representa em seus desafios atuais? Qual foi a sua solução mais criativa (e talvez "inusitada") para um problema recente? Compartilhe nos comentários!

Siga a Hopin para mais insights históricos e curiosidades que expandem a mente!

#GrandeMuralhaDaChina #História #Inovação #Engenharia #Criatividade #CuriosidadesHistóricas #HopinAI

[🇨🇦🇺🇸]
The Great Wall of China was built with... RICE? 🤯

Yes, you read that right! Dive into the fascinating history of the Great Wall of China and uncover one of the most surprising secrets of ancient engineering. It wasn't modern cement, but an ingenious and unexpected solution that ensured its longevity for centuries.

This carousel reveals:
➡️ The colossal challenge of building $21,000$ km of wall.
➡️ The secret formula that defied time and the elements.
➡️ And the powerful lesson that ancient creativity teaches us today.

Swipe to learn how innovation can emerge from the most unlikely places, and how a humble ingredient became the backbone of one of the world's greatest wonders!

👉 What does "rice" represent in your current challenges? What was your most creative (and perhaps "unusual") solution to a recent problem? Share in the comments!

Follow Hopin for more historical insights and mind-expanding curiosities!

#GreatWallOfChina #History #Innovation #Engineering #Creativity #HistoricalFacts #HopinAI | 10 | 1 | 0 | 2w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.391Z |  | 2025-11-17T18:00:14.970Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7395061897009721344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8ac68598-08f7-4909-b7a2-25ad9e8dcb7b | https://media.licdn.com/dms/image/v2/D4E05AQEifxjCVYaf2Q/videocover-low/B4EZqCJH9aJ0CE-/0/1763120023713?e=1765778400&v=beta&t=085gOL0hR6VwxL7NJa5GWryxhB4KB7iEbLPsdh9LTB8 | A maior parte das pessoas vê o Coliseu como um monumento a gladiadores, imperadores e ao poder da Roma antiga.

Mas a verdade por trás dele é muito mais dramática.

Antes do Coliseu existir, toda aquela região era o lago particular de Nero, parte do seu extravagante complexo da Domus Aurea, palco de banquetes, orgias e níveis de excesso que chocavam o povo romano.

Quando Nero caiu, Roma enfrentou uma escolha.

Apagar o passado.
Ou transformá-lo.

Os novos líderes drenaram o lago, preencheram o solo e reconstruíram a identidade do Império exatamente no lugar que simbolizava tudo o que Roma queria esquecer.

O que surgiu depois não foi apenas um anfiteatro.
Foi uma mensagem.

Um monumento público erguido sobre o antigo império privado do excesso.

O Coliseu é muito mais que pedra e arcos.
É a prova de que até o terreno mais instável pode se tornar fundamento sólido quando reconstruído com propósito.

E que, às vezes, as maiores transformações começam quando confrontamos o que está logo abaixo dos nossos pés.

Se essa história te chamou a atenção, siga a Hopin , seu companheiro de viagem para lugares onde a história ainda respira emoção e verdade.

Travel. Feel. Remember. | 4 | 0 | 0 | 3w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.392Z |  | 2025-11-14T11:35:49.853Z | https://www.linkedin.com/feed/update/urn:li:activity:7395061370817445889/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7394699807707111424 | Text |  |  | A IA vai substituir vendedores? Resposta rápida: sim.
Mas só os transacionais.

Os que repetem roteiro, seguem script e empurram produto vão ser substituídos, e rápido.

Agora, os que conduzem conversas complexas, entendem o contexto político e fazem o cliente pensar estão entrando na era de ouro.
Porque a IA consegue gerar perguntas, mas só o humano entende o peso das respostas.

No novo episódio da trilha Vendas Complexas São Simples, falo sobre como o clássico SPIN Selling está sendo reinventado com o uso da Inteligência Artificial.

Falo sobre o que a IA já faz melhor (diagnóstico e preparo) e o que continua sendo 100% humano:
Significado, empatia e timing.

📖 Leia o episódio completo da Season 4
e entenda como o SPIN+IA redefine o papel do vendedor consultivo.

#VendasComplexas #SPINSelling #InteligenciaArtificial #VendasB2B #VendasConsultivas | 12 | 0 | 0 | 3w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.393Z |  | 2025-11-13T11:37:01.036Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7394331193523163136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEO3WLA4-peIg/feedshare-shrink_800/B4EZp0yFZdGoAg-/0/1762895878508?e=1766620800&v=beta&t=q2UbLyQiUkFL9Or7kw21rWdoBq0UyvcWvWearjAHOtY | A Hopin nasceu de uma pergunta simples: por que as viagens perderam a alma?

Hoje, publicamos nosso manifesto, um convite para voltarmos a ouvir as histórias do mundo!

🕊️ Leia o manifesto na página da Hopin e descubra o que estamos construindo.

Siga a página para ficar por dentro das próximas novidades! | 4 | 1 | 0 | 3w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.394Z |  | 2025-11-12T11:12:16.566Z | https://www.linkedin.com/feed/update/urn:li:activity:7394328170587508737/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7392951793447608320 | Text |  |  | Quer aprender a fechar R$10 milhões em contratos complexos B2B só usando IA, sem sair de casa e com 30 minutos por dia?

Eu também quero. 😅

Mas enquanto o milagre não vem, vamos falar do que realmente funciona em vendas de projetos complexos.

A verdade é que a IA já está vendendo milhares de SKUs, tem robô fechando pedido por WhatsApp. Vimos recentemente o Anúncio da Magalu (projeto sensacional do time do Caio (Kyle) Gomes) 

Mas quando o assunto é projeto complexo, com várias pessoas, política interna e decisão de alto impacto, ouso dizer que nem a AGI vai conseguir fazer isso por você.

Não adianta pensar que pra vender soluções de alto valor é sobre truques, scripts ou gatilhos mentais mirabolantes.

Precisa entender de gente, contexto e processo.
É sobre navegar interesses, lidar com objeções e construir consenso entre pessoas que raramente pensam igual.

Parece mais difícil? É.

Mas também é o que separa a simplicidade de uma venda transacional que será substituída por IA de uma venda mais complexa que não.

Se você quer entender um pouco do jogo real das vendas B2B, eu escrevo sobre isso toda semana na newsletter Vendas Complexas São Simples.

🧠 Assina lá e vem aprender como pensar (e vender) em um mundo onde até a IA vai tentar ganhar a sua comissão!

Link na minha Bio e no primeiro comentário. | 16 | 2 | 1 | 4w | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.395Z |  | 2025-11-08T15:51:01.960Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7392565246286041088 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHUJjilNo-nGw/feedshare-shrink_800/B4EZpdjSvxHoAg-/0/1762506124852?e=1766620800&v=beta&t=6vwUGmJUHLu39F4QVCKw1s1ann9CX4_leNTFaePcPOU | Someone asked me recently:
“Juelinton, you’ve worked in several countries, built teams, led projects… you could easily take a senior role in a big company. Why go through the chaos of a startup?”

My answer was simple:
because I actually like chaos. 😂

But here’s what I really meant.
I like being where things are still being invented.
Where the map isn’t drawn, the manual doesn’t exist, and every decision still feels like discovery.

Big companies are incredible, but the game there is different: to perfect what already works.
I wanted to go back to building something from scratch — where risk smells like possibility and purpose feels alive.

And deep down, there’s something that haunts every restless person:
the doubt of dying without ever trying something with global scale.

Today, that attempt has a name: Hopin.
A startup born between 🇧🇷 and 🇨🇦, trying to change how we travel — bringing living stories to every corner of the world, instead of just collecting selfies for the feed.

Maybe it’ll work, maybe it won’t.
But one thing’s for sure: you can’t live waiting for the perfect moment.

The future never comes ready.
We’re the ones who build it — right there, in the middle of the chaos. 🌪️🚀🔶

#Entrepreneurship #StartupLife #Hopin #AI #TravelTech #Innovation #GlobalScale #NextAI #Montreal #Brazil #Canada | 13 | 1 | 0 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.396Z |  | 2025-11-07T14:15:01.935Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7392516175294898176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEk-ZpOgaiNvQ/feedshare-shrink_800/B4EZpdj2QTKcAg-/0/1762506270256?e=1766620800&v=beta&t=RJVK0TCssVZ3kBJ62geYKm4cHUNxjdqC0JXGWTVHddY | Me perguntaram esses dias:
“Mas Juelinton, você é um executivo com anos de experiência, já trabalhou em vários países… podia buscar um cargo numa grande empresa. Por que vai fazer uma startup?”

A resposta foi bem simples:
porque eu gosto mesmo é de confusão. 😂

Brincadeiras à parte, o que eu realmente quis dizer é que gosto de estar onde as coisas ainda estão sendo inventadas.
Onde o mapa não está desenhado, o manual não existe e as decisões não vêm prontas.

Grandes empresas são incríveis, mas o jogo ali é outro: aperfeiçoar o que já funciona.
Eu queria voltar a construir algo do zero, com cheiro de risco, gosto de propósito e potencial ilimitado.

E também porque, no fundo, existe uma coisa que assombra qualquer pessoa inquieta: a dúvida de morrer sem ter tentado algo de escala global.

Hoje, essa tentativa tem nome: Hopin.
Uma startup nascida entre 🇧🇷 e 🇨🇦, que quer transformar a forma como viajamos, levando histórias vivas para cada esquina do mundo e se contrapondo às viagens vazias só para selfies no Insta.

Talvez dê certo, talvez não.
Mas a verdade é que não dá pra viver esperando o momento perfeito.

O futuro nunca vem pronto.
A gente é quem constrói, bem ali no meio da confusão. 🌪️🚀🔥🔶

#Empreendedorismo #StartupLife #Hopin #AI #TravelTech #Inovação #EscalaGlobal #NextAI #Montreal #Brazil #Canada | 122 | 34 | 0 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.397Z |  | 2025-11-07T11:00:02.499Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7391806539944054784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGS4rexHFW4tw/feedshare-shrink_800/B4EZpLPjLHHoAg-/0/1762198959486?e=1766620800&v=beta&t=9xToGMRG83FLxmCwQSEOHPBT5SBW_ESxdjZhQTrzt3E | [🇬🇧] Big news for Hopin!  🔶 🌎

We have just been accepted into the NEXT AI Bootcamp 2025 Montréal, part of NEXT Canada, and powered by HEC Montréal, forming one of the world’s leading ecosystems for artificial intelligence and innovation.

This environment brings together entrepreneurs, scientists, and investors to turn cutting-edge research into real-world impact, and we’re thrilled to be part of it.

For us, it’s a chance to learn from the best, challenge what’s possible, and bring our vision for soulful travel to life through technology, art, and AI.

If you love to travel, follow us to be the first to explore what’s coming next. 🎧✨

—

[🇧🇷] Ótima notícia para a Hopin! 🔶 🌎

A Hopin acaba de ser aceita no Next AI Bootcamp 2025 (Montréal), parte do Next Canada, com apoio da HEC Montréal, formando um dos ecossistemas mais relevantes do mundo em inteligência artificial e inovação.

Esse ambiente reúne empreendedores, cientistas e investidores para transformar pesquisa de ponta em impacto real, e é uma honra fazer parte dele.

Pra nós, é a chance de aprender com os melhores, desafiar o possível e dar vida à nossa visão de devolver a alma às viagens, com tecnologia, arte e IA.

Se você ama viajar, siga a gente para saber em primeira mão o que vem por aí. 🎧✨ | 24 | 2 | 2 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.398Z |  | 2025-11-05T12:00:12.247Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7391179843234639872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEp5CBZuCCPag/feedshare-shrink_800/B4EZpK.5YKGUAg-/0/1762194594988?e=1766620800&v=beta&t=jV7BbRYnu-K3mRio0WPfyjHqpLfnEmSSQjRjbHxAoAs | [🇺🇸] 🇧🇷
For the past month, I’ve been building something that brings together everything I believe in: technology, art, and the power of stories.

It started with a feeling: that travel has become too shallow, too filtered. 
Full of pictures, but empty of meaning.

Together with Ricardo Figueiredo, we’re creating Hopin an AI travel companion designed to reimagine how we experience the world, turning every trip into an unforgettable story.

If you love to travel, follow us to be the first to explore what’s coming next. 🌍🎧

—
🇺🇸 [🇧🇷]
No último mês, venho construindo algo que une tudo em que acredito: tecnologia, arte e o poder das histórias.

Tudo começou com uma sensação: a de que viajar se tornou raso demais. Cheio de fotos, mas vazio de significado.

Junto com Ricardo Figueiredo, estamos criando a Hopin, um IA companheiro de viagem feito para reinventar a forma como vivemos o mundo e devolver a alma das nossas viagens.

Se você ama viajar, siga a gente para saber em primeira mão o que vem por aí. 🌍🎧 | 33 | 6 | 1 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.398Z |  | 2025-11-03T18:29:56.108Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7388545046532341760 | Text |  |  | Você pode perder meses de relacionamento com uma apresentação mal feita!

Você entra na sala. O slide está bonito. A solução é sólida.
Mas em dois minutos, você já perdeu metade da mesa.
Um olha o celular. Outro está no e-mail. O decisor mal te escuta.
Você não errou na proposta. Você errou na narrativa.

Apresentar não é despejar dados. É mover decisões.
É construir uma ponte entre lógica e emoção, entre o problema que o cliente vive e a transformação que ele precisa ver.

No novo episódio da minha newsletter Vendas Complexas São Simples, eu te ajudo a fazer isso com uma estrutura simples e eficaz.

Não deixe de conferir, me enviar feedback e compartilhar! | 5 | 0 | 0 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.399Z |  | 2025-10-27T12:00:11.622Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7383944633589997568 | Text |  |  | Truth doesn’t need decoration. Complexity does.

Most strategies fail not because they lack intelligence, but because they hide behind noise, endless reports, dashboards full of vanity metrics, presentations that mistake volume for vision.

Real strategy sounds simple because it’s clear:
Compete here, not there.
Prioritize this client, not that one.
Invest in this capability, even if it costs another.

If it can’t be said clearly, it’s not ready to be executed.

Read the full piece on Strategy Ex Machina ↓

#Strategy #Leadership #DecisionMaking #Simplicity #B2B #Clarity #BI #Growth | 2 | 1 | 0 | 1mo | Post | Juelinton Silveira | https://www.linkedin.com/in/juelinton | https://linkedin.com/in/juelinton | 2025-12-08T05:24:27.400Z |  | 2025-10-14T19:19:47.705Z |  |  | 

---



---

# Juelinton Silveira
*Hopin*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Fireside Chat with Hopin Founder & CEO, Johnny Boufarhat - The Product Podcast](https://theproductpodcast.buzzsprout.com/90361/episodes/8302308-fireside-chat-with-hopin-founder-ceo-johnny-boufarhat)
*2021-04-19*
- Category: podcast

### [Fireside Chat with Hopin Founder & CEO, Johnny Boufarhat](https://open.spotify.com/episode/07BLIVqmA90s0jQJnoPPhS?go=1&sp_cid=f99b8d791d9c9a01da955ae31c259691&utm_source=embed_player_p&utm_medium=desktop&nd=1&dlsi=bc6495687c00417f)
*2021-04-19*
- Category: podcast

### [The Importance Of Speed and Quality Execution by Hopin CEO](https://productschool.com/resources/product-podcast/importance-speed-quality-execution-hopin-ceo)
*2024-04-30*
- Category: podcast

### [EP139: How Hopin is Managing Hyper-Growth as a Remote Company](https://podcasts.apple.com/ie/podcast/ep139-how-hopin-is-managing-hyper-growth-as-a-remote-company/id1413489357?i=1000487053726)
*2020-08-04*
- Category: podcast

### [CEO Secrets: Hopin founder shares his business advice](https://www.bbc.com/news/business-57553552)
*2021-06-22*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
