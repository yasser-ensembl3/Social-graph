# Ioannis Koutroubis

## Position actuelle

**Titre** : Co-Founder Cinemagi Productions / Technical Director of the Film and TV Program at Trebas Institute
**Entreprise** : Cinemagi Productions
**Durée dans le rôle** : 14 years 7 months in role
**Durée dans l'entreprise** : 14 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Résumé

Founding his own International Visual Media Company Cinemagi Productions. As well as Alioan  Creations, a creative writing company. With his hand in every aspect of the profession from producing  and directing, to writer, cinematographer, and editor he has prepared and coordinated for over 600  productions for various media outlets.
In the past 14 months Ioannis Koutroubis has had his productions enter 80+ Film Festivals and has won 
30+ Awards including Best Producer, Best Director, Best Film, Best script, Best Cinematography, Best 
Music Video, and Best Dance Video.
Innovative Producer with years of experience in all aspects of video production

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAALfK-wBaR4jEHObIbKdhftdc5E2EN7iWnw/
**Connexions partagées** : 3


---

# Ioannis Koutroubis

## Position actuelle

**Entreprise** : Koutroubis International

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Ioannis Koutroubis

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396370671364108288 | Article |  |  | Here is my latest interview.
https://lnkd.in/ep8XVxu5 | 2 | 0 | 0 | 2w | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:53.428Z |  | 2025-11-18T02:16:25.975Z | https://wildfilmmaker.com/my-plans-for-2026-exclusive-interview-with-ioannis-koutroubis/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7395242021055258624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHhuNwtKc7XVA/feedshare-shrink_800/B4EZqEtbXVKcAk-/0/1763163093408?e=1766620800&v=beta&t=cIJ56USFlivbQky9T5nePEtF5KMW87ZFjaE4WOW7KbM | I am deeply humbled and honored to share that The Indie Directors Guild of the World has selected me as one of the Top 10 Artists of the Year for the Michelangelo Film Critics Awards. Out of more than 32,000 submissions, to stand among this remarkable shortlist is a recognition that touches me deeply.

This acknowledgment is not just about the work I create—it is about the countless hours, the persistence, the sacrifices, and the belief that storytelling still matters. Every frame, every word, every lesson I teach, every project I nurture… it all comes from a place of passion and conviction.

Michelangelo once said:
“The greatest danger for most of us is not that our aim is too high and we miss it, but that it is too low and we reach it.”
Today, these words ring louder than ever.

To be recognized by an institution inspired by one of history’s greatest artists reminds me why we chase excellence—not perfection, but truth, craft, and soul.

Thank you to everyone who has supported my journey—students, collaborators, family, and the incredible creative community around me. This milestone fuels me to keep pushing forward, keep creating, and keep aiming higher.

The journey continues. | 10 | 1 | 0 | 3w | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:53.429Z |  | 2025-11-14T23:31:34.772Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7390741810874044416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIxQPGBkZPnQ/feedshare-shrink_1280/B4EZpEwg0iGoAs-/0/1762090159995?e=1766620800&v=beta&t=UkGC9icApTYNpgyxETb_QqlAoAq2pLLEl7tlFiX5Pfg | Honored beyond words to share that I’ve won BEST ORIGINAL SCREENWRITER at the Edgar Allan Poe International Screenwriter Awards.

To receive an award bearing Poe’s name is profoundly meaningful — because his work has always been more than literature to me; it’s been a compass. Poe once wrote, “I would define, in brief, the poetry of words as the rhythmical creation of beauty.” That rhythm — of truth, pain, and beauty intertwined — is what I’ve chased on every page.

Poe taught me that art isn’t meant to comfort; it’s meant to reveal. To dig where it hurts and find something worth saying. Every word, every line, every sleepless rewrite was a step toward that revelation.

This recognition isn’t just a trophy — it’s a reminder to keep creating even when no one’s watching, to keep writing through doubt, fear, and silence.

To my family and supporters, thank you for being my foundation. And to every dreamer reading this — don’t wait for validation. Write, build, create. Let your art speak when the world won’t listen.

Tonight, I raise a pen to Poe — the master of shadows — and to all who dare to write in the dark until their words become light. | 16 | 2 | 1 | 1mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:53.429Z |  | 2025-11-02T13:29:21.055Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7390349311647043584 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEMwM30nEtwSQ/feedshare-shrink_800/B4EZo_LiL.HUAg-/0/1761996580491?e=1766620800&v=beta&t=jwOkVJLWlgwZNlCuz_LDnzpuIraIbkbZ1F1bkvy3sdw | Absolutely thrilled to share that I’ve been named one of the Top 10 Leading Men in 2025 by MSN! This recognition truly humbles me and fuels my passion to keep pushing boundaries and doing meaningful work.

From day one, I’ve believed in the power of dedication, authenticity, and connecting with others in genuine ways. To be included among such remarkable professionals is beyond special. I could not have reached this milestone without the unwavering support of my incredible team, the clients and collaborators who challenge me to grow, and the friends and family whose belief in me never wavers.

Here’s to continuing on this journey—leading with heart, purpose, and vision. I’m excited about what’s ahead and committed to making 2026 even more impactful. Thank you to MSN for this honour, and thank you to everyone who has been part of this ride. Let’s keep lifting each other up. | 36 | 7 | 1 | 1mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:53.430Z |  | 2025-11-01T11:29:41.947Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7377115596926132225 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHarnJlDHiYkw/feedshare-shrink_1280/B4EZmDHio3IkAs-/0/1758841416893?e=1766620800&v=beta&t=K-m1wZAqGVFV2us6ozvQNG3oISITFg7p5d42K6emGZo | 🔥📚 BOOK SIGNING — SAVE THE DATE! 📚🔥

I’m signing two filmmaking essentials:
The Horror Filmmaker’s Handbook: Creating Terrifying Cinema &
The Art of Documentary Filmmaking: A Comprehensive Guide

📅 Saturday, October 4, 2025
📍 Indigo — 6321 Trans-Canada Hwy, bureau 141, Pointe-Claire, QC H9R 5A5
⏰ Time: TBA

Come for signatures, photos, and a rapid-fire Q&A on crafting fear that lingers and truth that hits the heart. Bring your questions, your passion, and that Wolfpack energy. 🐺🎬

👉 RSVP/Details in bio
💾 Save this post + 🔁 Share it + 👥 Tag a filmmaker friend

#BookSigning #MontrealEvents #Indigo #HorrorFilmmaking #DocumentaryFilmmaking #IndieFilm #FilmmakerLife #Cinematography #Directing #Screenwriting #QuebecCulture #PointeClaire #YUL #CinemagiProductions #Wolfpack | 4 | 0 | 1 | 2mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:53.430Z |  | 2025-09-25T23:03:38.487Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7317857814532546560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFj5iNP-TB-aw/feedshare-shrink_1280/B4EZY5A52zGYAk-/0/1744713261037?e=1766620800&v=beta&t=qX0QhTgCfeYgJfY55itOuBuLnVMuu-gCqMPEVHInOz0 | You weren’t supposed to make it this far. They counted you out, underestimated your worth, and looked the other way when your name was mentioned. But here you are — not just surviving, but thriving. From undesirable to undeniable.

This journey was never about proving them wrong. It’s always been about proving yourself right. The real battle was never you versus them — it’s always been you versus you. Your doubts. Your fears. Your comfort zone. And you’ve been winning, quietly and consistently.

You didn’t need applause. You didn’t need validation. You just needed vision, discipline, and the heart to keep going even when everything inside you said stop. And look at you now — shining in your own light, not borrowed from anyone else. Growing in your own lane, not competing with anyone else.

There’s power in your perseverance. There’s strength in your scars. And there’s beauty in the fact that you never folded when life tried to break you.

So keep shining. Keep growing. Keep getting better. Every version of you that came before was building the foundation for who you are becoming. And trust this — the best is still unfolding.

This is your reminder: You are not finished. You are not defined by who you were or what they said. You are a masterpiece in motion, and your only competition is the reflection staring back at you.

You’re not here to be liked. You’re here to be legendary.

Let them watch. Let them wonder. Let them doubt. Just don’t stop.

Undesirable to undeniable. Always you versus you. | 10 | 0 | 0 | 7mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.143Z |  | 2025-04-15T10:34:22.208Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7312080295229329408 | Article |  |  | Here is my latest interview in Variety UAE
https://lnkd.in/gBaUEG7d | 13 | 2 | 0 | 8mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.144Z |  | 2025-03-30T11:56:34.265Z | https://varietyuae.com/entertainment/the-inspiring-journey-of-ioannis-koutroubis-a-filmmaker-educator-and-innovator/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7309185284653416448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhDle8dLHOsQ/feedshare-shrink_800/B4EZW9xR78HgAk-/0/1742645568302?e=1766620800&v=beta&t=aGZWJjJjrd0TbvHbX3TRmP4nEdLkfgspjrNCapwEnLY | This journey you’re on—it’s bigger than you. The late nights, the early mornings, the silent battles no one sees… they’re not just shaping your destiny, they’re lighting the path for someone else in the dark. You’re connected to something greater. Every win, every step forward, is proof that it can be done. Your resilience echoes louder than you know.

You’re not here to seek validation. You’re here to conquer. To grow. To rise.

Let them whisper. Let them look away. Let them pretend your shine doesn’t blind their comfort. They need the spotlight to survive. You? You were built in the shadows. You grind quietly. You rise humbly. And when they wonder how you keep going, remind them—it’s purpose, not applause, that drives you.

Keep climbing, even if it’s one shaky step at a time. Progress isn’t about speed—it’s about consistency. And yes, you’re allowed to pause. Take that breath. Take that rest. Refill your cup. That isn’t weakness—it’s wisdom. You’re not quitting. You’re recharging for the next round.

This is your pace. Your struggle. Your story.

And guess what? You hold the pen.

So write it raw. Write it real. Write it with scars and triumphs, with the falls and the comebacks. One chapter at a time, until your story becomes someone else’s survival guide.

Keep grinding. Keep shining.

Because when you win, you show the world that it's possible. You prove that darkness can’t hold you down. Those demons can be defeated. That pain can birth purpose.

And in doing so—you inspire the next warrior to rise.

Let them watch. Or let them look away.

Either way, you’re still climbing.

Still shining.

Still writing your legacy. | 9 | 0 | 0 | 8mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.146Z |  | 2025-03-22T12:12:49.957Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7306862353512366081 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH6iU4N9q81Ww/feedshare-shrink_800/B4EZWcwll8HUAk-/0/1742091738541?e=1766620800&v=beta&t=mU9djIIeMNxA-TtgKs__JMJ55s6qghsJ1DjKYXFiBJ8 | ​Life's challenges often seem insurmountable, testing our resolve and determination. Yet, it's precisely during these moments of adversity that our true character is forged. Embracing hardships not only builds resilience but also propels us toward greatness.​

Consider the golf ball, a seemingly simple object that holds a profound lesson. Early designs were smooth, but golfers noticed that balls with nicks and scratches traveled farther. This observation led to the intentional addition of dimples, which enhance aerodynamics and performance. Similarly, our personal 'dimples'—the scars and experiences from our struggles—equip us to soar higher and achieve more.  Each setback, each struggle, adds to our 'dimples,' refining our character and enhancing our capabilities. Embracing this perspective transforms obstacles into opportunities for growth.​

In moments of doubt, reflect on the golf ball's design or the stories of individuals like Thomas and Lewis. Recognize that your struggles are shaping you, making you more resilient and better prepared for future endeavors. By pushing through the hard times, you not only build strength but also pave the way for unprecedented achievements.​

Remember, it's through the dimples—the trials and tribulations—that we gain the lift needed to reach new heights. Embrace your challenges, for they are the catalysts propelling you toward your fullest potential. | 14 | 1 | 1 | 8mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.147Z |  | 2025-03-16T02:22:20.015Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7306299973032181760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZGXNi-_VQMg/feedshare-shrink_800/B4EZWUxG8MGYAg-/0/1741957657014?e=1766620800&v=beta&t=LTWg02tvveif9RRyqNxdcYegieffzQw6FDFcLbFBnpk | INSECURE" WINS BEST MUSIC VIDEO! 🎬🏆

Every journey in filmmaking is filled with challenges, doubts, and moments where you wonder if the world will ever see your vision. But when you put in the work, stay committed, and pour your heart into your craft, the universe takes notice.

Our music video INSECURE has just won BEST MUSIC VIDEO at the Elegant International Film Festival, proving once again that passion, perseverance, and storytelling will always shine through.

This award isn’t just for us—it’s for every artist who’s ever questioned themselves, for every creator who’s been told "No," and for everyone grinding in the shadows waiting for their moment. Keep pushing, keep creating, and never let self-doubt win.

The journey doesn’t stop here. More to come!

#InsecureMusicVideo #BestMusicVideo #ElegantFilmFestival #KeepCreating #Filmmaking #AwardWinning #StayHungry #StayHumble | 14 | 1 | 0 | 8mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.148Z |  | 2025-03-14T13:07:38.060Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7300972656546230273 | Text |  |  | Soulaf Diab, PRC is #hiring. Know anyone who might be interested? | 1 | 0 | 0 | 9mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.149Z |  | 2025-02-27T20:18:46.833Z |  | https://www.linkedin.com/jobs/view/4169990445/ | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7298884227956158464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYpmeMqetibw/feedshare-shrink_800/B4EZUrYhmVHgAg-/0/1740189605042?e=1766620800&v=beta&t=1szVKvpHVqLx3ujKGxWinCjroT0WICKMEFmQH9_quGE | 🏆 TWO BIG WINS for URBAN EATS MTL! 🏆

We did it! Urban Eats MTL has won BEST INTERNATIONAL WEB SERIES, and I am deeply honored to receive the award for BEST DIRECTOR (Web/TV Series Category). This is not just a win for us but for everyone who has been part of this journey.

From the very beginning, Urban Eats MTL was built on passion, perseverance, and a love for storytelling through food. It wasn’t always easy—there were challenges, long nights, and moments where giving up might have seemed like an option. But we NEVER did. We pushed forward, we adapted, and we kept creating, because we believed in what we were building.

I want to express my deepest gratitude to my partner in this series and a great friend, Luigi Portaro—this journey wouldn’t have been the same without you. Your dedication, vision, and hard work have been instrumental in making Urban Eats MTL what it is today.

A huge THANK YOU to the Urban Eats MTL family—every single person who stood by us, supported us, and helped us bring this series to life. To the Wolfpack, you are more than a team—you are family. Your commitment, creativity, and relentless pursuit of excellence continue to inspire me every day.

To the amazing restaurants that opened their doors, shared their stories, and allowed us to showcase their passion—we share this award with you. This series exists because of the incredible culinary world we get to explore, and we are grateful for the trust you placed in us.

Through all the ups and downs, one thing remained constant: our belief in the power of storytelling and community.

As the great Anthony Bourdain once said:
"Skills can be taught. Character you either have or you don’t."

It’s character that got us here. It’s resilience, hard work, and an unshakable belief that what we do matters. We don’t just film a show—we document passion, culture, and the soul of the food scene.

Thank you to everyone who has supported us, watched our episodes, and believed in what we do. This is just the beginning! 🚀

#UrbanEatsMTL #AwardWinning #BestInternationalWebSeries #BestDirector #WolfpackEmpire #Passion #HardWorkPaysOff | 29 | 4 | 2 | 9mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.151Z |  | 2025-02-22T02:00:06.656Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7297781020924260352 | Article |  |  | Here is my latest interview.
Thank you to all who have supported me.
https://lnkd.in/eWagavZ3 | 24 | 2 | 0 | 9mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.151Z |  | 2025-02-19T00:56:21.603Z | https://www.filmmakerlife.com/interviews/ioannis-koutroubis-exploring-the-mind-of-an-award-winning-filmmaker-author-and-educator/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7293394305207943168 | Text |  |  | Job Title: Producer (International Markets)
 Location: Montreal, Canada
 Salary: Starting at $4,000/month (Negotiable)
About Us:
 We are Cinemagi Productions/ Koutroubis International, a dynamic film production company with a growing presence in both domestic and international markets. We pride ourselves on creating compelling stories and building strong industry relationships worldwide.
Position Overview:
 We are seeking an experienced Producer with a proven track record in international film markets, particularly the Chinese film industry. The ideal candidate will have strong connections and a keen understanding of production processes, from development through post-production. Fluency in both Cantonese and Mandarin is essential to effectively navigate our expanding network and engage with key stakeholders in the Chinese market.
Key Responsibilities:
Oversee the development and production of film projects aimed at international audiences, focusing on Chinese markets.
Collaborate with writers, directors, and other production staff to ensure projects stay on schedule and within budget.
Establish and maintain relationships with Chinese film distributors, investors, and production houses.
Negotiate deals, contracts, and partnerships with various stakeholders.
Conduct market research to identify emerging trends and opportunities in the Chinese film industry.
Manage project timelines, budgets, and deliverables, ensuring all production milestones are met.
Coordinate with marketing teams to develop and implement strategies tailored to international markets.
Qualifications:
Proven experience in film or media production, with a focus on international markets.
Fluency in Cantonese and/or Mandarin (oral and written) is a must.
Strong negotiation skills and ability to cultivate relationships with international partners.
Excellent project management and organizational skills.
Ability to adapt and thrive in a fast-paced, collaborative environment.
Knowledge of Chinese film industry regulations and best practices is highly desirable.
Salary & Benefits:
Starting at $4,000/month, with the possibility of negotiation based on experience and qualifications.
Opportunities for career growth within a global-minded organization.
Collaborative work environment with diverse projects and international reach.
How to Apply:
 Please submit your resume, cover letter, and any relevant portfolio links or showreels to ioanniskoutroubis@hotmail.com. In your cover letter, please highlight your experience in international productions and your proficiency in Cantonese and Mandarin.
We look forward to hearing from you and discussing the possibilities! | 27 | 0 | 5 | 10mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.153Z |  | 2025-02-06T22:25:07.075Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7275835498684641280 | Article |  |  | 🎥✨ BREAKING NEWS FOR FILM LOVERS! ✨🎥
📚 My highly anticipated second book, The Art of Documentary Filmmaking: A Comprehensive Guide, is NOW AVAILABLE on Amazon! 🌟
Whether you're an aspiring filmmaker, a seasoned pro, or just someone who loves storytelling, this book is your ultimate guide to crafting compelling documentaries. 🖊️ Dive into:
🎬 Step-by-step techniques for mastering the craft.
🎥 Insider tips from 17+ years in the industry.
🌍 Real-world insights on bringing stories to life.
💡 This isn’t just a book—it’s a game-changer for anyone who dreams of making impactful documentaries that resonate globally.
🎁 Perfect gift alert! Order now to get your copy in time for Christmas and give the gift of knowledge and creativity to yourself or the storyteller in your life. 🎄📦
👉 Click the link, grab your copy, and let’s create stories that matter!
🔗 https://lnkd.in/ehmhgQfv
#DocumentaryFilmmaking #FilmmakingTips #NewBookRelease #TheArtOfDocumentaryFilmmaking #PerfectGift | 8 | 2 | 0 | 11mo | Post | Ioannis Koutroubis | https://www.linkedin.com/in/ioannis-koutroubis-09017614 | https://linkedin.com/in/ioannis-koutroubis-09017614 | 2025-12-08T07:11:57.155Z |  | 2024-12-20T11:32:41.373Z | https://www.amazon.ca/dp/B0DR1SR75V?ref_=pe_93986420_774957520&fbclid=IwY2xjawHSNG1leHRuA2FlbQIxMAABHU4LTPsetxe8VjCP2gC4B22h6PHQYNLN9o4PDf_a--Tlrq9vmc9uZQ2tiA_aem_FcoV1iJOLggCr7RbV6faqw |  | 

---



---

# Ioannis Koutroubis
*Koutroubis International*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Koutroubis International Archives - SpaceDive Media](https://thespacedivemedia.com/tag/koutroubis-international/)
*2024-03-26*
- Category: article

### [David Biagini - Interview](https://florencefilmawards.com/interview6)
- Category: article

### [LISTEN TO MY INTERVIEW AS A GUEST ON THE GREAT GREEKS PODCAST — GEORGE STROUMBOULIS](https://www.stroumboulis.com/blog/listen-to-my-interview-as-a-guest-on-the-great-greeks-podcast)
*2022-10-24*
- Category: podcast

### [MY INTERVIEW ON THE "GREECE CHATS WITH TONY KARIOTIS" PODCAST  — GEORGE STROUMBOULIS](https://www.stroumboulis.com/blog/my-interview-on-the-greece-chats-with-tony-kariotis-podcast)
*2023-02-20*
- Category: podcast

### [Building Communities With Pumble: How Ioannis Gkourtzounis Started an Online IT Community](https://pumble.com/blog/ioannis-gkourtzounis-pumble-building-an-online-community)
*2025-08-08*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
