# Yann Bourdeau Cervantes

## Position actuelle

**Titre** : CEO & Founder
**Entreprise** : SYG anima
**Durée dans le rôle** : 2 years 1 month in role
**Durée dans l'entreprise** : 2 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Delivering high-end 3D modeling and architectural visualization.

  -  Created 3D models and virtual tours for Mexico's largest textile company’s new offices, in Mexico city, Mexico.

  -  Developed comprehensive 3D models of oil platforms, machinery, and port infrastructure. in Tamaulipas, Mexico. 
ENERGY SECRETARIAT OF TAMAULIPAS GOVERNMENT

  -  Designed and 3D modeled the terrace and office renovation for Coworking Business, including virtual walkthroughs and graphics representations in México City, Mexico.
ESTACION SAN MIGUEL

  -  Completed 3D plans and walkthroughs for the representation of a new park project of large scale in Sonora, Mexico.
AM

  -  In charge of digital communication, including the creation and ongoing maintenance of website, the production of 3D animations to showcase new collections, and the integration of augmented reality art to elevate their storytelling.
MAS CHINGON

  -  Realization of commercial animations from idealization, modeling, animation and post-production in order to advertise for (Washington) events. Washington (US)
DC CONNECT

  -  Conceptualize, modeling & animating of advertisement to open Night Club in Madrid "Los Amantes". Madrid, Spain.
LOS AMANTES

   -  Modeling creator and animator for presenting animations. Carlita as well as Villanova DJ. London, England.
CARLITA / VILLANOVA -DJ

  -  Idealization and creation of 3D animation in order to advertise two of its events. Mexico, Mexico city. 
FRANCAIS DU MONDE

## Résumé

I am a French-Mexican Entrepreneur, deeply influenced by both cultures, with a lifelong passion for the arts. I embarked on my artistic journey at the age of 8, self-taught in painting, sculpting, and drawing. My formative years were spent primarily at Liceo Franco Mexicano in Mexico City, with brief educational stints in Canada and France.At 4 I began to play chess and I´ve won some tournament. Chess brought me an open mind about the world and culture in general.At the age of 14, I began to do some portraits created with oil paints on canvas and pencil sketches. My interest in anatomy led to sculptural work, allowing me to collaborate with Dr. Alejandro Espinosa Gutierrez on a scientific article concerning wrist surgery. I reconstructed a 3D surgical animation, which has already been presented at medical congresses.Subsequently, I immersed myself almost entirely in 3D animation, honing my skills independently. I collaborated with the "George Town Events Committee" in Washington, D.C., creating promotional animations for DC CONNECT events. I also worked with "Francais du Monde" ADFE, producing promotional animations for their events.As my 3D abilities improved, I joined a company where I've been engaged in the creation of detailed park plans, lighting, texturing, and animation. This venture continues to be a significant part of my career.Relocating to Canada, I pursued a Bachelor's degree in Landscape Architecture at the University of Montreal (UdeM). I collaborate with the UdeM Landscape Architecture Association on event promotion. Additionally, I´ve done an audiovisual for the Mexican Independence Day celebration hosted by the Mexican Consulate in Montreal.This experience led to collaborations with the Consulate of Mexico in Montreal and the office of Architect Javier Senosiain, involving the creation of animations to be showcased at the Montreal Arts Council for five days during the tribute to Jose Alfredo Jimenez exhibition in late October.Despite my diverse body of work, I remain dedicated to continuous learning and development. I embrace the ever-evolving nature of my professional and personal journey, always open to new directions and opportunities.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAEZBPlMBL7jRJTxmrsGqCkKy1qcElrowhLU/


---

# Yann Bourdeau Cervantes

## Position actuelle

**Entreprise** : Consulado De Mexico

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Yann Bourdeau Cervantes
*Consulado De Mexico*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [YB Digital](https://ybierling.com/en/podcast-yonumerique-yaniss-comment-apprehender-un-parcours-de-fondation-dentreprise)
*2026-09-10*
- Category: podcast

### [Ep. 74: Yalo raises $20M to build ‘c-commerce’](https://sceniusmexico.substack.com/p/ep-74-yalo-raises-20m-to-build-c)
*2023-12-21*
- Category: blog

### [Ep. 61: Mexican Startups are changing the game – exciting developments in e-commerce and mental health](https://sceniusmexico.substack.com/p/ep-61-mexican-startups-are-changing)
*2023-08-30*
- Category: blog

### [Yalo](https://founderslaunchpad.axented.com/p/yalo)
*2024-03-28*
- Category: article

### [Yann Barbarroux, CEO of Otonomi — InsurTech.ME](https://www.insurtech.me/insurtechtalks/episode-118)
*2024-04-26*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
