# Jason Elate

## Position actuelle

**Titre** : Founder
**Entreprise** : INSECTFLUX
**Durée dans le rôle** : 2 years 2 months in role
**Durée dans l'entreprise** : 2 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Intelligence Platforms

## Description du rôle

Digitalization of insect industry & agri-food hub.
Online platform connecting the insect farming industry - organic products/waste industry. 
Connecting all players to the equation to effectively solve food waste - food security problems.

## Résumé

The best way to predict the future is to create it. @insectflux

Building a category defining company addressing the food waste crisis -  A $1.1T global problem. 

https://insectflux.com/

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAD7wC-sBU0XXhpt0q8qm-fq3mkbqUZTGzzY/
**Connexions partagées** : 91


---

# Jason Elate

## Position actuelle

**Entreprise** : INSECTFLUX

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jason Elate

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397362037095292931 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQGLNfj7q1motQ/mp4-720p-30fp-crf28/B4EZqi1hH2KkCI-/0/1763668537188?e=1765774800&v=beta&t=D3h8JTwOTPTqreE5hbt2XiFTAHdkY2d4AUkPRCd6qow | https://media.licdn.com/dms/image/v2/D4E05AQGLNfj7q1motQ/videocover-low/B4EZqi1hH2KkBQ-/0/1763668531845?e=1765774800&v=beta&t=bLXBAagU-Xoyl2lZlq3iMrT1Ddd-VaIhgPgkxNxAQe4 | Food For Thought #45
Leveraging insect farms as decentralized waste management solution

One of my core beliefs: if you want to solve a systemic problem like the food waste crisis, you need a systemic solution.

In my recent conversation with Kenneth Alston on the Circularity Catalyst podcast, we explored exactly that: how insect farms especially modular farms can become decentralized waste management hubs anywhere in the world.
Every year, over 1.3 billion tons of organic surpluses, by-products and food waste are lost. That’s a $1.1 trillion problem. Most of it is still treated as a liability instead of a resource.

What if we flipped the script?
Imagine a world where cities, enterprises, organisations, individuals,  food processors, hotels, restaurants even refugee camps and rural communities host-own modular insect farms that:
 → Take in local organic surplus & waste
 → Transform it into protein, oils, fertilizers, chitin & more insect-based products
 → Feed local value chains instead of landfills

In other words:
 ▪️ Waste management becomes a profit center
 ▪️ Local economies are strengthened (new jobs, new SMEs, new skills)
 ▪️ Circularity is built from the bottom up, not just designed from the top down

This is the paradigm we’re building at Insectflux with our partners FLYBOX, Africa Circular & Quebec Agrifood Development Center:
A global B2B2C infrastructure & ecosystem that lets anyone, anywhere, plug into the insect economy.

In the podcast, we also talk about:
Why the insect industry is still mainly offline and fragmented
How modular farms can be deployed like “waste-to-value nodes” worldwide
Why I see Insectflux as infrastructure for local self-determination, not just a marketplace

Podcast with Kenneth Alston - Circularity Catalyst Podcast
 “How Bugs Are Changing Farming and Sustainability Forever!”
Link Podcast : https://lnkd.in/e8C7eeAd

Feel free to send me your feedback. 
Special thank you to Ken for the opportunity!

#CircularEconomy #FoodWasteSolutions #InsectFarming #WasteToValue
#SustainabilityInnovation #ClimateTech #Bioeconomy #RegenerativeAgriculture #InsectProtein #Insectflux #Flybox INSECTFLUX | 44 | 4 | 0 | 2w | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:45.021Z |  | 2025-11-20T19:55:45.984Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391557352325279744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFwkAHmjpnoiQ/image_304_612/B56ZpQb29GKEAc-/0/1762286071942?e=1766620800&v=beta&t=yr-VBl8w8lO58Fy5eNGNhhTdWW_BHSzS3DX8dyg4L6I | Food for Thought #44 
What’s the Correlation Between the AI Boom & Insect Farms?

It turns out that the global AI boom and the digitalization of the world are driving an unprecedented expansion of data centres, the backbone of our modern infrastructure.

One of the biggest challenges both industries face is energy dependency, particularly in managing heat. Insect farms, especially in Western regions, require climate-controlled environments, making energy a major cost factor.

I’m currently exploring opportunities to co-locate modular insect farms (container-sized units) near data centres, strategically positioned close to insect feed sources.
The goal is to leverage excess heat from data centres to reduce insect-farming energy costs that can reach up to 30% of operating costs (depending on the region), while democratizing access to this emerging industry - a model that could be replicated across multiple cities globally.

At the same time, we’re also witnessing a green movement in the data center sector turning heat from a costly byproduct into a sustainable resource, making data centers environmental solutions rather than ecological liabilities.
This new symbiosis would allow data centers to fuel a regenerative industry, creating positive environmental and economic externalities.

Equinix opened on the roof of its PA10 data center in Paris a greenhouse warmed by waste-heat from its servers. This trend is gaining traction and I believe the insect-farming industry could play a key role.
https://lnkd.in/emae2CPc

As AI adoption & digitalization accelerate, the number of data centres is growing exponentially representing a unique opportunity to pilot, adapt, and scale this decentralized model worldwide.

At Insectflux, our mission is built around this systemic vision:
→ Buy a modular insect farm (with our hardtech partner)
→ Access insect feed (organic surplus + waste)
→ Buy & sell insect-based products
→ Connect with industry experts
→ Access financing, insurance, logistics and more. 

If you're working in the data center field (across the world), please write to me - I'd love to learn and collaborate.

#Insectflux #AI #DataCenter #Sustainability #GreenTech #InsectFarming #CircularEconomy #Innovation #FutureOfFood #AgTech #ClimateTech #TechForGood #Entrepreneurship #DeepTech #Insectflux #Biodiversity | 58 | 3 | 2 | 1mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:45.024Z |  | 2025-11-04T19:30:01.289Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7381395402635497473 | Text |  |  | 🍺 Food for Thought #43
 Do you like beer?

Last year, the world consumed an estimated 188 billion liters of beer generating hundreds of billions of dollars in revenue. In other words, a lot of people love beer;)

Here’s the hidden story: to brew all that beer, massive amounts of grains are used and once the brewing process is over, these grains become “spent grains.” Today, most of them are discarded or underutilized. That means we’re losing out on a huge amount of untapped value (Billions of $$$).

Here’s the exciting part: spent grains are one of the most prized inputs for insect farming.
Imagine enabling breweries, an industry that employs millions globally, to sell (or at least donate) their spent grains to insect farms. These farms could transform waste & byproducts into sustainable proteins, frass fertilizers, oils, chitin and more insect-based products.

In practice, this means:
- Unlocking a new revenue stream for breweries.
- Directly reinjecting capital into local economies.
- Fueling the growth of the insect industry, one of the world’s most promising circular economy sectors.

It’s not just about beer. It’s about rethinking value chains and creating new business models that turn waste into abundance. In a context where beer consumption often fuels the travelling-tourist economy worldwide, this becomes a big deal. Connecting these 2 industries becomes more relevant. 

That’s exactly what we’re building with Insectflux: a global one-stop shop where industries like brewing can connect with insect farming to co-create a sustainable future.

“Rien ne se perd, rien ne se crée, tout se transforme.” – Lavoisier

#Insectflux #CircularEconomy #FoodTech #Sustainability #Beer #InsectFarming | 20 | 2 | 0 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.613Z |  | 2025-10-07T18:30:03.683Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7378805968286949376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEGtHhDtiRVsA/feedshare-shrink_800/B4EZma8Kf_IIAk-/0/1759241088333?e=1766620800&v=beta&t=StmVJWcX37VBKc9YESCZPGmr8aoAeWkqUs1zXyVR9Bg | 🚀 New Partnership + Speaking opportunity🚀 

I’m happy to announce a strategic partnership between Insectflux and Africa Circular (formerly ACEN Foundation).

🌍 Africa Circular has been at the forefront of shaping circular economy strategies across the continent active in over 44 countries & supporting 15+ African governments in designing national roadmaps, policies, and bankable projects. By joining forces, we’re creating the bridge between policy, implementation, and technology.

Through this partnership:
African governments, farmers, and enterprises will gain direct access to Insectflux, the world’s first global B2B2C platform-marketplace for insect farming and agri-food.
Together, we’ll revalorize agri-food surpluses, organic waste and byproducts like spent grains, coffee husks, maize stalks, fisheries waste and more into sustainable proteins, frass fertilizers, oils, chitin and more insect-based products.

We’ll co-develop flagship pilots across Africa proving that circular solutions can unlock economic value, food security, and climate resilience at scale.
A special thank you to Piotr Barczak, Théo Venturelli, Ifeoluwa O. & Oluwasemilore Adeoti their team for collaborating & embracing this mission. This is more than a partnership, it’s about building the infrastructure of the future.

✨ On another exciting note, I’m deeply honoured to also be speaking at Rep Matters’ upcoming event (tomorrow).

Grateful to Phil G. Joseph for the opportunity and proud to share the stage at 
McGill Dobson Centre for Entrepreneurship with fellow panelists committed to rethinking equity, sustainability, and innovation in business. 
Félix ZOGNING, Hawa Mariam, Dexter Peart

🚀 From New York Climate Week to Cornell University, to Africa Circular, to Rep Matters, the puzzle pieces are coming together. We’re building not just a company, but an ecosystem.

“Rien ne se perd, rien ne se crée, tout se transforme.” – Lavoisier

🔗 Explore Africa Circular: https://lnkd.in/eStXf_CY
🔗 Reserve your spot at Rep Matters community - speaking event :
https://lnkd.in/ekbjrXS3

#Insectflux #AfricaCircular #CircularEconomy #ClimateTech #FoodTech #RepMatters #ImpactInvesting #Sustainability INSECTFLUX | 81 | 6 | 2 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.615Z |  | 2025-09-30T15:00:34.425Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7378598387102924800 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHAxB-UtYd2Kg/feedshare-shrink_800/B56ZmHK9JSHAAg-/0/1758909421011?e=1766620800&v=beta&t=9EDAgsPHSOzJrgCsPgGSSEpxvKgfnOEJrRYP9CVXU30 | Such an honour. Moments like these remind me that the future of food systems but also problem solving at scale will be shaped by collaboration, curiosity and bold ideas. A huge thank you to the Cornell Institute for Food Systems for the warm welcome, and special recognition to the leadership! | 33 | 0 | 0 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.615Z |  | 2025-09-30T01:15:43.214Z | https://www.linkedin.com/feed/update/urn:li:activity:7377400827264765952/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7376320889883373569 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c93428d5-f3bc-4cae-bbe9-8248113389e8 | https://media.licdn.com/dms/image/v2/D4E05AQGQAgXMrA-0gw/videocover-high/B4EZl30LgUKoB8-/0/1758651929579?e=1765774800&v=beta&t=ct-LrlKvfE1gVU7u5s-iSVKltfsA9u6zn7ottnjtwAc | 🍀 Touchdown in NYC!

Fall has officially started and I’m loving it.

This week, I’m here for Climate Week both as an attendee and a speaker. 
I feel energized by the city - Let’s get to work.

I’ll also have the privilege of giving an expert-guest lecture at Cornell University hosted by the Cornell Food Science Club, Alt Protein Project, Snodwiggs (Entomology Club), and Product Development Club.

During my session, I’ll dive into:

- How insect farming & the agri-food industries can be connected through a new global business model to solve the $1.1 trillion food waste crisis.

- How bridging these two worlds unlocks sustainable proteins, fertilizers, other insect-based products and circular-economy opportunities worldwide.

- The mental frameworks I use as a founder to reverse-engineer challenges and focus on a human nature first approach. 

📍 If you’re in New York for Climate Week, I’d love to connect.
And if you’re near Cornell this Thursday afternoon, join my session - it’ll challenge how you think about food systems and climate solutions and the role you could play in the equation:

👉 Event Link – RSVP Free : https://lnkd.in/e98p4z9f

At Insectflux, we’re building a global one-stop connecting the Insect-Farming & Agri-Food industries for the very first time. This is only the beginning.

“Rien ne se perd, rien ne se crée, tout se transforme.” – Lavoisier

#ClimateWeekNYC #Insectflux #CircularEconomy #FoodTech #Sustainability #AgriFood #FoodWaste #Innovation | 24 | 0 | 0 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.617Z |  | 2025-09-23T18:25:45.563Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7374121306449027074 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFRhk0M3FWg5w/feedshare-shrink_800/B4EZlYkP1eIUAg-/0/1758127521694?e=1766620800&v=beta&t=VJP6jYl7f8jl1OrL4r6VmyAvQbivsFnTFlq8IsMHwCU | New York Climate Week🍀🍀

Next week, I’ll be in New York for Climate Week as both a speaker and an attendee. I’d be happy to meet and exchange with anyone who will be there. 

I’ll also have the chance to give an expert-guest lecture at Cornell University, hosted by the Cornell Food Science Club, Food Science Product Development Club and Grub Ventures next Thursday. A special thank you to Rajni Aneja & Matthew Livingston for making this possible!

One of my core beliefs: 
The world is a made of a puzzle of answers. The key is learning how to ask better questions in order to find better answers and ultimately to enable better execution. Everything already exists in front of us; surprisingly you just have to pay attention so the key is about cutting through the noise. With a first-principle approach, the pieces reveal themselves gradually.

The big question I asked myself 2 years ago:
 What should exist by 2030 that will be even more relevant and valuable by 2050?

My answer: Insectflux – The Insect-Farming & Agri-Food Hub.
A global one-stop shop empowering agri-food owners and operators to reduce food waste ($1100B in losses), monetize their surplus and actively contribute to the circular economy by fuelling the insect industry. At the same time, empowering the insect industry itself through a B2B2C marketplace-platform where anyone globally can:
Buy an insect farm,
Access insect feed (organic surplus),
Buy and sell insect-based products,
Connect with industry experts,
Access financing, insurance, and more.

I pursued a double major in Politics & Economics to understand the world we live in but also to figure out my role in it. I believe I’ve found it and I’m doubling down every single day.

We’re bringing to life, in real time, a quote we all know:
 “Rien ne se perd, rien ne se crée, tout se transforme.” – Lavoisier

Sign up to Insectflux here : https://lnkd.in/eZZHm6nM

If you’re in New York next week, I’d love to connect.
 Feel free to join my session @Cornell if you’re nearby, you won’t regret it;)
Event Link : https://lnkd.in/eBJDc-74 | 40 | 1 | 0 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.618Z |  | 2025-09-17T16:45:24.006Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7371720482204717056 | Video (LinkedIn Source) | blob:https://www.linkedin.com/46ef429a-567b-4a17-897b-6c72692b61e6 | https://media.licdn.com/dms/image/v2/D4E05AQGdASXvbrKrLQ/videocover-low/B4EZk1tMwBIoCE-/0/1757542675786?e=1765774800&v=beta&t=keATuWmlseDDFIavcKzJYoTljVOvhArnE5uoN__uun8 | 🚀 We’re live  - Insectflux V1 (on desktop): The Insect-Farming & Agri-Food Hub
https://lnkd.in/e5sH-V4i 

Today we're launching Insectflux V1 (actual V1), the world’s first global B2B2C platform built to connect the agri-food sector with the fast-rising insect farming industry to turn organic byproducts, surplus & waste into high-value, climate-smart solutions at scale.

Business model we’re introducing
As a global one-stop shop connecting both industries, Insectflux is introducing a model where the public, entrepreneurs, farmers, companies and organizations. can:
- Buy-invest in insect farms
- Access insect feed & equipment
- Sell insect-based products
- Connect with global experts

What goes live today (V1)
Global & regional visibility: Everyone can browse available insect-based products in their region or worldwide. If a seller chooses Europe-only, only European buyers can see and purchase those listings
Marketplace categories (live at launch):
 - Organic Fertilizers (Frass)
- Insect-based Biocontrol & Biopesticides
- Insect-based Oils
- Insect-based Animal & Pet Feed
- Insect-based Snacks
- Insect Farming IoT & Equipment
- Live Insects
- Culinary Staples
- Protein Powders
- Insects (Bulk Supply)
- Insect-Farming Software & Management systems
- Insect Pheromone traps and lures
- Educational based insect kits
- Other insect-based products

*Direct Messaging: We’ve added a built-in buyer–seller chat to increase trust, transparency, and synergies across the industry while reducing friction.
* Logistics (for now): Sellers handle their own distribution & shipping.
* Availability: Desktop version is live; mobile is coming soon.
*New revenues for agri-food): Any agri-food player wishing to sell or donate surplus/byproducts/organic waste to insect farms can submit the Get Involved form (see picture below). Turn disposal costs into new revenue streams or into verified circularity flows.

New Partnerships :
- CDBQ (Centre de développement bioalimentaire du Québec) via its Insect Processing Innovation Platform (PITI). This unlocks hands-on expertise in ingredient development and secondary processing. 

- Flybox: Building modular, distributed insect farm systems that make local production faster, repeatable and economical. 

Who it’s for (today):
- Agri-food producers (farms, processors, restaurants, grocery chains, hotels): monetize or donate surplus/byproducts/organic waste directly to insect farms via (Get Involved section).
- Insect farms-operators: List real products, set regional availability, and connect to feed inputs, buyers and equipment.
- Insect based products buyers (pet food, aquaculture, regenerative ag, biotech, cosmetics, consumer): discover proteins, oils, fertilizers, live insects, equipment and others by region or globally.

Demo for Vendor Onboarding : 
https://lnkd.in/efPngzUi

yessssirrr

INSECTFLUX #Insectflux #CDBQ #Flybox #CircularEconomy #InsectProtein #FoodTech #ClimateTech #PetFood #RegenerativeAg #FutureOfFood | 97 | 26 | 8 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.620Z |  | 2025-09-11T01:45:22.901Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7371268334253727744 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFws-rOjAVJQA/feedshare-shrink_800/B4DZkwBfNxGsAk-/0/1757447321455?e=1766620800&v=beta&t=q2_WlkpuALqKHUOejvwFbel4wLcGpncd4IKeuoGRAXA | 🌍New Partnership : INSECTFLUX x Quebec Agrifood Development Center 
Building the Infrastructure of the Insect Economy

At Insectflux, our mission is to create the global one-stop shop where the agri-food sector and the insect industry finally meet. We're enabling an ecosystem where entrepreneurs, farmers, companies, org and institutions can:
 → Buy or invest in insect farms
 → Access feed and equipment
 → Sell insect-based products
 → Tap into world-class expertise

That’s why our partnership with the CDBQ (Centre de développement bioalimentaire du Québec) is transformative. Through their Insect Processing Innovation Platform (PITI), we are unlocking for the industry:
 ✅ Direct access to facilities, equipment, and expert teams available both locally on-site and internationally via online collaboration - shipping samples.
 ✅ A pathway for producers worldwide to ship samples, recipes, and prototypes for validation, diversification, and scale-up.
 ✅ Expertise at the cutting edge of entotechnologies, from proteins and oils to advanced food applications.

This is how our approach & business model come alive: reducing costs, democratizing expertise and enabling companies & new players everywhere to accelerate.

We believe in turning fragmentation into connection and scarcity into abundance. With CDBQ, we’re doubling on our perspective “Rien ne se perd, rien ne se crée, tout se transforme.”

Special thank you to Yves Fournier & his team, pleasure to move forward.
 
#Insectflux #CDBQ #CircularEconomy #ClimateTech #FoodTech #tech #Innovation INSECTFLUX | 130 | 11 | 1 | 2mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.622Z |  | 2025-09-09T19:48:42.429Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7365805180388274176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE98M8l0v1jdw/feedshare-shrink_800/B4EZjZR11rGoAg-/0/1755991990983?e=1766620800&v=beta&t=B-ylFCpx3b0PDn5cKOPiV8HMmcWuevjF70lAzBOvKfI | Food For Thought #42
How Much Would the Dinosaur Industry Be Worth Today?

If dinosaurs still roamed the Earth, imagine the industries that would have sprung from their unique traits : new medicines derived from their biology, cutting-edge materials engineered from their bones or scales, even innovations in mobility, defense or agriculture and more. We would have turned their very existence into a trillion-dollar ecosystem of discovery.

Dinosaurs existed for about 230 million years and then vanished. 

Insects, however, have been here for over 430 million years, not only surviving the same extinction event that wiped out the dinosaurs but thriving ever since. They are, in many ways, the most resilient and resourceful life forms we share this planet with.

And yet, despite their ancient endurance and unparalleled diversity, we are only just beginning to recognize the wealth of solutions they offer. Take bee venom, for example: recent studies have demonstrated its ability to rapidly destroy breast cancer cells while leaving healthy cells largely unharmed (Ali & Kunugi, 2024; Choi et al., 2022; Moradipoor et al., 2023).

This breakthrough underscores a powerful truth: insect-derived compounds hold untapped potential to transform medicine, biotechnology, and sustainability. What we’re seeing with bee venom is likely just the tip of the iceberg. 

With everything considered, the insect industry’s current valuation of around $2B feels like a massive underestimation of its true potential, a pretty juicy discount for those willing to act early. As applications multiply across food, feed, health and biotech, this opportunity could redefine how we think about value creation in the 21st century.

That’s where Insectflux comes in. 
By unlocking streams of organic surplus, byproducts, and waste from the global agri-food sector, we fuel more insect farming. More insect farming means more insects (protein, oils, chitin, fertilizers & insect-based products) but also more opportunities for R&D, testing, product creation, and breakthrough applications. Every ton of organic matter we divert from landfills into insect ecosystems becomes a seed for innovation.

The lesson is clear: while dinosaurs are a fascinating “what if”...... 
Insects are a living, thriving “what now.” 

They’ve survived longer, adapted better and hold the keys to breakthroughs that can drive food security, circular economies and even new frontiers in health, biotech and biomimicry.

At Insectflux, we aren’t just building a marketplace. 
We’re catalyzing an entire value chain that turns today’s waste into tomorrow’s wealth.

InsectIndustry #FutureOfFood #BioEconomy #SustainableInnovation #CircularEconomy #ClimateTech #FoodTech #AgriTech #InsectProtein #AlternativeProteins #ZeroWaste #NatureInspired #Biotech #InsectBiotechnology #FoodWasteSolutions #DeepTech #DisruptiveInnovation #GlobalSustainability #LifeSciences #ImpactInvesting #FutureOfBiotech #FoodSecurity #BlackSoldierFly #InsectFlux | 22 | 1 | 1 | 3mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.623Z |  | 2025-08-25T18:00:05.047Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7363249532815458306 | Text |  |  | 🚀 PSA - Update Insectflux!

1️⃣ We’re currently in discussions with a North American industrial player interested in developing pet treats made from cricket flour & black soldier fly (BSF) protein.

If you are a producer of cricket flour or BSF products, and would like to collaborate, please send me your spec sheets to be considered as a potential product provider from now on.  Please write to me : jason@insectflux.com

2️⃣ At the same time, we are building a dedicated global logistics & distribution portal within Insectflux to connect the agri-food and insect industries in real time. 

If you are a distribution/logistics company already working in agri-food or insect industry or if you’re seeking to integrate these industries, we want to hear from you. Please write to me : jason@insectflux.com

🌍 No matter where you are in the world, reach out. Our mission is not only to digitalize these industries through our online marketplace, but also to ensure products can move efficiently in the real world, bridging gaps in this fast-emerging sector.

Exciting times ahead....;)

#Insectflux #CircularEconomy #FoodTech #PetFood #InsectProtein #Logistics #AgriFood #Sustainability #Tech | 33 | 0 | 0 | 3mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.624Z |  | 2025-08-18T16:44:51.184Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7361803828200890368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGiMsAsLgTjKQ/feedshare-shrink_800/B4EZilhQ_jGwAo-/0/1755123619093?e=1766620800&v=beta&t=hvIibtqMuScrnzBZ6cnydKTOn7EypEGY2ZdAjm57HNc | Food for Thought #41 
Food Diversion, Nutrient Reintroduction, Landfill Bans

Across the world, momentum is building around diverting food from landfills with some regions going as far as banning organic waste from landfill disposal entirely. In the agri-food sector, companies are facing growing social, moral, and financial penalties not only for generating food waste, but also for the associated losses in resources, energy, and value (over $1100B+ annually).

This mounting pressure is catalyzing the search for better ways to reintroduce nutrients into value chains with solutions that don’t just prevent waste, but actively preserve and regenerate resources.
As an innovator, I’ve learned that you don’t always need to create the waves yourself. Instead, you need to position yourself to ride the waves that are already gathering speed. If you can align your solution with a macro trend that is accelerating, the narrative will naturally converge toward you. When executed well, your solution’s growth will mirror the exponential rise of a problem so relevant and urgent that adoption becomes almost inevitable.

In today’s landscape, most food waste solutions focus on producing and consuming less. But with the global population projected to reach 9.5 billion by 2050 (about 1.5 billion more people than today) we will, in reality, need to produce and consume more.

This presents an enormous opportunity: reintegrating organic surplus, by-products, and waste back into the value chain. What better vehicle than the insect industry to absorb these organics as feed and directly fuel the industry, transforming them into protein, fertilizer, oil, and other high-value insect-based products?

By framing the insect farming as a decentralized business model for tackling food waste, we can turn a global crisis into a distributed, revenue-generating, and climate-smart solution. 

Insectflux's role as Global One Stop Shop connecting the agri-food & insect industries is to provide a B2B2C platform-marketplace offering modular insect farms (with our partners), insect feed (agri-food products), insect-based products, access to expertise, financing + insurance (partners), distribution & logistics (partners) and a digital hub for all the players involved globally. 

Stay tuned for the next announcements - partnerships, you won't be disappointed. 

#INSECTFLUX #Foodwaste #Startup #MTL #Impact #Entrepreneurship
#Insect #InsectIndustry #Agrifood #CircularEconomy #Landfill #Tech #Climate #Protein #Marketplace #Decentralization #Innovation INSECTFLUX | 44 | 8 | 0 | 3mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.625Z |  | 2025-08-14T17:00:08.344Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7353159778887442433 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFtzlA5RUTNig/feedshare-shrink_800/B4EZgur2W9HoAk-/0/1753129904594?e=1766620800&v=beta&t=RIYmykFaPwbzxR5uxDU3PtX_9Tb4Cxha5ZDzGMRw8Yo | Food For Thought #40
I believe there's enough abundance for everyone, we've simply been conditioned to think otherwise. The mission of my startup is to prove it.

Thank you so much for the recent feedback and support for Insectflux V1!
 Business is always about people and deeply understanding the human nature behind the problems I'm solving has been crucial. That’s why I’ve conducted over 740 interviews over the past 20 months.

Fun fact: I thought I had to give up my dream job of becoming a diplomat to become a founder, turns out I have to be both and I love it.
 Diplomacy teaches you that to get what you want, you must genuinely care about what the other party wants and build the right context for it. It’s about stepping into their shoes and applying emotional intelligence with purpose.

The global excitement from the insect industry around what we’re building reflects a community that has long been overlooked and is now finally being seen and heard. Insectflux exists to make empower them and address their constraints so we can push the industry forward and close systemic gaps at a global scale.

The launch of Insectflux V1 comes at a perfect time, as traditional farmers and the agri-food sector face mounting financial losses from food waste (1.3 billion tons = $1.1 trillion lost annually).
Instead of discarding organic surplus, byproducts and waste, agri-food players from farms and processors to restaurants and grocery chains can now sell or donate these materials to insect farms through our marketplace, unlocking new revenue streams or contributing meaningfully to sustainability.

By building these industries together in a decentralized way, we’re creating a new paradigm where environmental sustainability and economic prosperity can coexist harmoniously. Every feature we release and every partnership we enable will always aim to democratize access and lower systemic costs while seamlessly connecting these 2 industries.

We’re bringing to life a quote that everyone knows well:
 “Nothing is lost, nothing is created, everything is transformed.”

Want to get involved?

- To donate or sell agri-food surplus, byproducts, waste to insect farms
https://lnkd.in/eYQV-9dv 

- To sell insect-based products, equipment (starting in North America) 
https://lnkd.in/eSYwid9X

- To offer expert-consulting services on Insectflux Expert Services marketplace (will be featured in Insectflux V2) 
https://lnkd.in/eyBrr7fi

- To buy insect farms - Establish Partnership : Dm me or reach out : jason@insectflux.com | 29 | 0 | 0 | 4mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:47.626Z |  | 2025-07-21T20:31:46.389Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7351300099232210944 | Article |  |  | Insectflux - Insect Industry Merchants Onboarding Begins

We’re LIVE.
Today marks a major milestone: We’ve officially opened vendor registration for Insectflux. 

We’re kicking things off with 10 core categories:
- Organic Fertilizers (Frass)
- Insect-based Biocontrol & Biopesticides
- Insect-based Oils
- Insect-based Animal & Pet Feed
- Insect-based Snacks
- Insect Farming IoT & Equipment
- Live Insects
- Culinary Staples
- Protein Powders
- Insects (Bulk Supply)

Want us to add another product category?
 Feel free to message me on Linkedin or jason@insectflux.com, we’re actively listening to the ecosystem as we build.

Insectflux V2 will include expert services on the marketplace as well but for now, we’re focusing solely on products & equipment related to insect farming.

👉 Here’s the link to register as a vendor (Canada & USA):
 🔗 https://lnkd.in/eSYwid9X

🌍 Want to sell outside North America?
 Yes, that’s possible!
 We’re mapping out and onboarding global sellers offline and will gradually digitize the industry as we roll out. If you'd like to be part of that, email me: jason@insectflux.com

***Product purchasing for buyers will go live next week***
If you’re an insect industry player or know someone in the insect space, please share this. The future of food, feed, soil health, bioeconomy is in our hands. 

We're starting in North America for a reason, I’ll explain soon. 
Stay tuned. 
 
#Insectflux #MarketplaceLaunch #InsectProtein #CircularEconomy #AgriTech #FoodTech #SustainableFarming INSECTFLUX | 32 | 4 | 4 | 4mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:49.813Z |  | 2025-07-16T17:22:04.208Z | https://vendor.insectflux.com/register |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7350967255720980480 | Video (LinkedIn Source) | blob:https://www.linkedin.com/01bd36fd-26ac-443f-9607-0650e25cc485 | https://media.licdn.com/dms/image/v2/D4D05AQGXC75GZ9WJAQ/videocover-high/B4DZgPcAuoHkCM-/0/1752605668549?e=1765774800&v=beta&t=yx2f70Bk6Vd3u0IE_rGrDMFRBdxKpRnsglMv0wlUGro | 🚀 Insectflux - A Small Step for Bugs, A Giant Leap for Sustainability 🌍

I’m thrilled to officially unveil Insectflux V1 : The world’s first global B2B2C marketplace connecting agri-food surplus/waste producers with insect farms and buyers of insect-based products.

For too long, food waste has been a trillion-dollar problem and the insect farming industry, valued at $2.5B+, has remained offline, fragmented and under-leveraged. We’re changing that.

Here’s how it works:
→ Food producers (farms, processors, grocery chains, restaurants, hotels, etc.) list their organic byproducts, surplus, and waste.
→ Insect farms access those inputs as feedstock to raise black soldier flies, crickets, mealworms and more.
→ The resulting insect-based products (protein, fertilizer, oil, chitin, etc.) are sold back through the same platform to industries like aquaculture, regenerative farming, pet food, biotech, cosmetics, and public consumers - closing the loop within a zero-waste, circular economy supply chain.

Industry experts-consultants all over the world can also fill in the form (get involved section) to offer services globally on the Expert Services Marketplace that we'll launch in Insectflux V2.

Even better: We’re now onboarding merchants! 
***Unlocking product purchasing next week***
If you’re producing insect-based products or agri-food surplus & waste, your marketplace is finally here. We're starting with all insect-based products & equipment available or sold in North America then we'll gradually unlock all markets. Join us and be part of the first wave of changemakers shaping this regenerative economy.

First Scoop:
Proud to announce our strategic partnership with Flybox® a polyvalent company building scalable, modular insect farms for commercial and humanitarian applications worldwide. Everywhere we'll launch, we'll be able to tap into this $1.1T food waste opportunity while fuelling the insect-farming at the same time! We're focusing on developing the industry with a decentralized hybrid approach to raise the industry floor. Together, we’re bridging food systems and circular economy innovation on a global scale.

This is just the beginning.
More partnerships, regions and opportunities coming soon.

Interested in joining our merchant community or exploring collaborations?
Drop me a note (jason@insectflux.com) or sign up at www.insectflux.com

Let’s build a regenerative, profitable and waste-free future - one insect at a time!!🐛🚀


Links to preliminary demo videos : 

- General Introduction https://lnkd.in/dnThNqqQ
- Vendors Onboarding Step 1 https://lnkd.in/deGUx3nq
- Vendors Onboarding Step 2 https://lnkd.in/d6_MzpZN
- Podcast with Ken Tencer ICD.D https://lnkd.in/e-c8KPwe 


#Insectflux #CircularEconomy #FoodWaste #SustainableInnovation #InsectFarming #AltProtein #ClimateTech #AgriTech #TechForGood #ImpactDrivenInnovation INSECTFLUX | 70 | 20 | 6 | 4mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:49.815Z |  | 2025-07-15T19:19:28.131Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7346198550738853890 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGM5K26PF-NeA/feedshare-shrink_800/B4EZfGaXHTHgAk-/0/1751380490971?e=1766620800&v=beta&t=1YfLOA1E5dhYv1Q7R3SVKsTaj5TeQCf779-dZB0SQBY | Insectflux - Trailblazer

July’s lining up to be a milestone month.

Last week, I had the privilege of joining the ReFED Food Waste Solutions Summit in Seattle, sponsored by Amazon and Chick-fil-A Restaurants. 
What struck me most wasn’t just the scale of the problem, it was the caliber of solutions being built. From policy innovators to climate-tech founders, it was a powerful reminder that the real breakthroughs happen when unlikely sectors work together. Special thank you to Dana Gunders and her team!

Proud that INSECTFLUX is now part of this global conversation redefining how we turn waste into value and pushing circularity from concept to commercial reality.

Next week, I’ll be pitching at Startupfest (July 9-11) Canada’s largest startup & venture capital gathering. Can’t wait to connect with bold founders, sharp investors and partners ready to rethink the global economy. Also, don’t be afraid to ask questions/test me, I don’t bite🤝

And here’s the headline:
We’re officially launching INSECTFLUX V1 this month.
 Our first product is a B2B2C online marketplace that lets sellers of insect-based products, byproducts, insect farms & insect farming equipment list and sell directly to buyers. It’s Phase 1 of our broader Global One-Stop Shop for the insect and agri-food industries.

This is just the beginning and I believe Insectflux V2 & V3 have much better surprises in store!

Everyone on our waitlist will get early access to every feature along with the chance to help shape the future of this industry. Drop me a message, if you’d like to be added.

Grateful to every person who’s opened a door, shared a word of encouragement or challenged us to think bigger.

Let’s build what's missing.

#FoodTech #CircularEconomy #Insectflux #ClimateSolutions #Startupfest2025 #RefedSummit #ImpactLeadership #AgriFoodInnovation #refed | 51 | 4 | 1 | 5mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:49.817Z |  | 2025-07-02T15:30:20.265Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7342672748915154944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE00LG7n7GXMw/feedshare-shrink_800/B4EZeZb18cHsAg-/0/1750625908471?e=1766620800&v=beta&t=Ui3HzY66ntF0rcWBDFWWH71hAl5GPemfxynra8ADFDY | Touchdown in Seattle!

Grateful, fired up and ready to dive in as the 2025 ReFED Food Waste Solutions Summit kicks off.

Honored that Insectflux was selected as one of few sponsorship recipients for this year’s summit. It represents a testament to how circular models, insect agriculture and regenerative systems are quickly becoming core to the global sustainability agenda.

Huge thanks to ReFED, Amazon and Chick-fil-A Restaurants for sponsoring us and believing in bold ideas that challenge the status quo!

Being here in Seattle feels like a full-circle moment. 
From hundreds of hours spent listening to farmers, food execs, policy makers, waste managers and more all across the globe to now standing alongside some of the world’s most progressive thinkers on food system transformation. 
It’s clear we’re no longer talking about if circular food systems will take hold, but how fast we can build them.

If you’re around this week - let’s connect. 
Would love to meet fellow founders, innovators and investors working at the edges of food, climate, and tech.

The future isn’t linear, it’s circular and the best part.... we’re just getting started!

#Insectflux #ReFED #FoodWasteSolutions #CircularEconomy #AgriFoodInnovation #ClimateTech #RegenerativeSystems #ImpactDrivenInnovation #InsectIndustry #FoodTech #TechForGood #SystemChange #Seattle2025 #Montreal #Startupfest | 47 | 3 | 0 | 5mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:49.818Z |  | 2025-06-22T22:00:03.604Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7275178000931852288 | Text |  |  | Food for Thought #32
Insect Industry - African Refugees Empowerment

This morning, I had the privilege of meeting with a few members of the United Nations team based in Eastern Africa, specifically with the Food and Agriculture Organization (FAO). It was inspiring to connect with a fantastic team of dynamic women committed to providing sustainable solutions for the world. It turns out that the insect industry is—and will continue to be—at the heart of these efforts!

The FAO Eastern Africa serves 19 countries and is actively working to develop the insect industry directly on the ground, with a focus on small and medium players. During the meeting, I learned that the insect industry is being leveraged as an accessible and dynamic solution for refugees and households in the region. The goal is to empower these communities by providing them with wages, introducing bioconversion solutions, and offering alternative proteins to enhance their independence and create opportunities.

As an African man myself, this mission resonates deeply with me. The chance to contribute to a positive narrative for the continent while playing a role in the growth of such a promising industry is a privilege I hold close to my heart.

The insect industry has immense potential, and I firmly believe the world will be delighted to witness its growth and impact. | 18 | 4 | 1 | 11mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:54.478Z |  | 2024-12-18T16:00:01.693Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7273400487373123585 | Text |  |  | 🚀 Exciting News! 🚀

Nous sommes ravis d’annoncer qu’Insectflux a été sélectionné pour le parcours Rémi-Marcoux de La base entrepreneuriale HEC Montréal, axé sur les stratégies de commercialisation!

Hier, nous avons eu l’honneur de rejoindre le lancement officiel des cohortes 2025. Dans notre quête à Silicon Valley, nous tenons à garder un pied au Canada, plus particulièrement à Montréal puisque notre équipe est montréalaise. 

Je tiens à remercier l'équipe de la La base entrepreneuriale HEC Montréal et plus particulièrement Théo Corboliou, Delphie Poulin, Charles Couture-Lebrun, Msc, Robert Dutton.

Au grand plaisir de joindre d'autres organisations & institutions montréalaises pour mettre de l'avant le potentiel du Québec! | 53 | 21 | 1 | 11mo | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:54.479Z |  | 2024-12-13T18:16:49.436Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7270149868663308288 | Text |  |  | Food for Thought #31
Ego vs Vision

One of my life philosophies is simple: I know that I don’t know everything. So the real question becomes: What should I know?

Being self-aware is crucial for making progress in life. It starts with understanding where you are and where you want to go.
Whatever someone undertakes—or plans to undertake—they need to figure out what they truly want while contrasting it with different perspectives.

I believe everything exists on a spectrum. That’s why it’s important to surround yourself with knowledgeable people, but also, paradoxically, with those who hold opposing views. This allows you to better understand the spectrum and, ultimately, to grow.

Ego often becomes an obstacle in this process. In other words, it’s you vs. you. The goal isn’t to get rid of your ego but to build a healthy relationship with it—stay grounded, rational, and open to progress.

The ultimate aim: become your own best friend. 
Challenge yourself without self-sabotaging, stay curious, and let your ego drive your vision forward, not hold it back.

Ego vs Vision: The choice is yours. Progress is the reward. | 5 | 0 | 0 | 1yr | Post | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/jason-elate-34b760255 | 2025-12-08T04:51:54.480Z |  | 2024-12-04T19:00:01.542Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7336847824333991936 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHYzj7Dbidm-Q/feedshare-shrink_800/B4DZdGwmIqHAAo-/0/1749238834496?e=1766620800&v=beta&t=EHxBM5HYevY2N_XS3kyIUqx7eeeIjSP0f0i90Kgxbyw | Retour sur une aventure inspirante à Vancouver pour le Web Summit 2025 

Il y a des événements qui marquent, qui challengent et qui recentrent. Ce sommet en a été un.

J’y ai rencontré des esprits brillants, des entrepreneurs audacieux et des bâtisseurs d’impact qui, comme moi, croient qu’un futur durable se construit en sortant des sentiers battus.

Ce que je retiens le plus ?
 La force du collectif. Échanger, apprendre, challenger et célébrer avec d’autres entrepreneurs de La base entrepreneuriale HEC Montréal a été une expérience humaine et professionnelle précieuse. Ce genre de connexion qu’on ne peut vivre qu’en immersion, loin des écrans, à bâtir des ponts et à imaginer ensemble le monde de demain.

Merci du fond du cœur à La base entrepreneuriale HEC Montréal, à toute l’équipe, aux donateurs, à Québec Tech et aux mentors présents pour votre confiance et votre soutien. 
Robert Dutton, Luis Cisneros Martinez, Nathalie Marcoux, Julien Vasseur, Delphie Poulin, Joseph EL-Khoury, Kévin Combe, Théo Corboliou, Rebecca Schneider

Merci également aux entrepreneurs incroyables qui m’ont inspiré tout au long de ce voyage, ce fut un privilège d’apprendre à vos côtés.
Christophe Roy, Enric Soldevila, Manon Vaisse, Hippolyte Lapierre, Félix Prud'homme, Maxence Lhuisset, Alexandre Bramoullé, M.Sc., Antoine Levesque, Pierre-Luc Pépin-Pagé, Pierre-Briac METAYER--MARIOTTI, Elias Nouari. 

Ce genre d’initiatives confirme encore plus mon ambition : bâtir des solutions à fort impact systémique, en connectant industries, institutions et communautés. 

Je poursuis cette aventure en étant rechargé et inspiré!

#WebSummit #Vancouver #BusinessIsPeople #Entrepreneuriat 
#Innovation #HECMontreal #Insectflux | 57 | 8 | 1 | 6mo | Hippolyte Lapierre reposted this | Jason Elate | https://www.linkedin.com/in/jason-elate-34b760255 | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:17.928Z |  | 2025-06-06T20:13:53.362Z |  |  | 

---



---

# Jason Elate
*INSECTFLUX*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [Jason Elate - GLOBExCHANGE](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*2025-02-04*
- Category: article

### [Insectflux marketplace connects agrifood with insect protein](https://www.petfoodindustry.com/insect-based-cat-and-dog-food/news/15754667/insectflux-marketplace-connects-agrifood-with-insect-protein)
*2025-09-05*
- Category: article

### [Insectflux Information Session - Food Science Club](https://cornell.campusgroups.com/FoodScience/rsvp?event_uid=c175e55fb7286fc3534a97440be6e988)
*2025-09-25*
- Category: article

### [Founder Stories: Flux | Skalata](https://www.skalata.vc/founder-stories/flux)
*2024-04-12*
- Category: article

### [The Plantbased Business Hour: Investing in Food System Transformation with Jason Ingle](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle)
*2024-11-21*
- Category: article

---

## 📖 Full Content (Scraped)

*8 articles scraped, 27,830 words total*

### Jason Elate - GLOBExCHANGE
*888 words* | Source: **EXA** | [Link](https://www.globeseries.com/globexchange/speaker/jason-elate/)

Jason Elate - GLOBExCHANGE

===============

![Image 1: Revisit consent button](https://www.globeseries.com/globexchange/wp-content/plugins/cookie-law-info/lite/frontend/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://www.globeseries.com/globexchange/wp-content/plugins/cookie-law-info/lite/frontend/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

No cookies to display.

Functional

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

No cookies to display.

Analytics

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

No cookies to display.

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

No cookies to display.

 Reject All  Save My Preferences  Accept All 

[![Image 3: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

[![Image 4: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

[![Image 5: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)
*   [](https://www.globeseries.com/globexchange/speaker/jason-elate/)

*   [Home](https://www.globeseries.com/globexchange/ "Home")
*   [Why Attend](https://www.globeseries.com/globexchange/why-attend/ "Why Attend")
*   [Program _Toggle Submenu_](https://www.globeseries.com/globexchange/speaker/jason-elate/# "Program")
    *   [Program](https://www.globeseries.com/globexchange/program/?menu_parent=4729 "Program")
    *   [Partner Program](https://www.globeseries.com/globexchange/partner-program/?menu_parent=4729 "Partner Program")

*   [Speakers](https://www.globeseries.com/globexchange/speakers/ "Speakers")
*   [Partners](https://www.globeseries.com/globexchange/partners/ "Partners")

*   [Essential Info _Toggle Submenu_](https://www.globeseries.com/globexchange/speaker/jason-elate/# "Essential Info")
    *   [Venue, Accommodations & Accessibility](https://www.globeseries.com/globexchange/venue-accommodations-accessibility/?menu_parent=4351 "Venue, Accommodations & Accessibility")
    *   [FAQs](https://www.globeseries.com/globexchange/faqs/?menu_parent=4351 "FAQs")
    *   [Media](https://www.globeseries.com/globexchange/media/?menu_parent=4351 "Media")

*   [NEW – Roadmap for Action](https://www.globeseries.com/globexchange/roadmap-for-action-2024/ "NEW - Roadmap for Action")
*   [Register](https://cvent.me/0OEevR "Register")

Speaker Profile
===============

Jason Elate
-----------

**Founder, Insectflux: Global One Stop Shop connecting Agri-Food & $2.5B Insect Farming industries**

![Image 6](https://www.globeseries.com/globexchange/wp-content/uploads/s

*[... truncated, 7,197 more characters]*

---

### Insectflux marketplace connects agrifood with insect protein
*1,687 words* | Source: **EXA** | [Link](https://www.petfoodindustry.com/insect-based-cat-and-dog-food/news/15754667/insectflux-marketplace-connects-agrifood-with-insect-protein)

Insectflux marketplace connects agrifood with insect protein | PetfoodIndustry

===============

[![Image 1: PetfoodIndustry](https://img.petfoodindustry.com/files/base/wattglobalmedia/all/image/static/petfoodindustry/2020PETFOOD_INDUSTRY_logo_R.svg?h=45&auto=format,compress)](https://www.petfoodindustry.com/)

*   [News & Newsletters](https://www.petfoodindustry.com/page/news-newsletters)
*   [Expert Insights](javascript:document.querySelector(".site-navbar__toggler").click())
*   [Petfood Forum](https://www.petfoodforumevents.com/)
*   [Career Center](https://careers.petfoodindustry.com/)
*   [Magazine](https://www.petfoodindustry.com/magazine)
*   [More](javascript:document.querySelector(".site-navbar__toggler").click())

*   [Sign In](https://www.petfoodindustry.com/user/login)

[](https://www.petfoodindustry.com/search)

*   [Market Trends & Reports](https://www.petfoodindustry.com/pet-food-market/market-trends-and-reports)
*   [Nutrition](https://www.petfoodindustry.com/nutrition)
*   [Safety & Quality](https://www.petfoodindustry.com/safety-quality)
*   [Production](https://www.petfoodindustry.com/production)
*   [Packaging](https://www.petfoodindustry.com/packaging)
*   [Sustainability](https://www.petfoodindustry.com/sustainable-dog-and-cat-food)
*   [Protein 360](https://www.petfoodindustry.com/protein-360)
*   [Regions](https://www.petfoodindustry.com/regions)

Pet Food Market

*   [Market Trends & Reports](https://www.petfoodindustry.com/pet-food-market/market-trends-and-reports)
*   [Top Pet Food Companies](https://www.petfoodindustry.com/top-pet-food-companies)
*   [Top Companies Data Reports](https://www.wattglobalproducts.com/collections/petfood-industry-products)
*   [Pet Food Company Profiles](https://www.petfoodindustry.com/pet-food-market/pet-food-company-profiles)
*   [Pet Food Product Database](https://www.petfoodindustry.com/pet-food-product-database)

Topics

*   [Nutrition](https://www.petfoodindustry.com/nutrition)
*   [Safety & Quality](https://www.petfoodindustry.com/safety-quality)
*   [Production](https://www.petfoodindustry.com/production)
*   [Packaging](https://www.petfoodindustry.com/packaging)
*   [Sustainability](https://www.petfoodindustry.com/sustainable-dog-and-cat-food)
*   [Protein 360](https://www.petfoodindustry.com/protein-360)
*   [Regions](https://www.petfoodindustry.com/regions)
*   [Marketing/Branding](https://www.petfoodindustry.com/pet-food-marketing-and-branding)
*   [Lawsuits](https://www.petfoodindustry.com/pet-food-lawsuits-litigation)
*   [Avian Influenza](https://www.petfoodindustry.com/avian-influenza)
*   [Pet Obesity](https://www.petfoodindustry.com/pet-obesity)
*   [Global Commerce](https://www.petfoodindustry.com/global-commerce)

Expert Insights

*   [Blogs & Columns](https://www.petfoodindustry.com/blogs-columns)
*   [Trending: Pet Food Podcast](https://www.petfoodindustry.com/trending-pet-food-podcast)
*   [Magazine](https://www.petfoodindustry.com/magazine)
*   [Webinars](https://www.petfoodindustry.com/webinars)
*   [Brand Insights](https://www.petfoodindustry.com/brand-insights)
*   [White Papers](https://www.petfoodindustry.com/resources/white-papers)
*   [Custom Publications](https://www.petfoodindustry.com/resources/custom-pet-food-publication)

Resources

*   [Sign In](https://www.petfoodindustry.com/user/login)

*   [Industry Calendar](https://www.petfoodindustry.com/resources/industry-calendar)
*   [Directory of Suppliers](https://www.petfoodindustry.com/industry-solutions)
*   [Petfood Industry Product Portfolio](https://www.petfoodindustry.com/page/petfood-industry-product-portfolio)
*   [Career Center](https://careers.petfoodindustry.com/)
*   [Subscribe](https://watt.dragonforms.com/loading.do?omedasite=PET_land&pk=petsiteh)
*   [Advertise](https://www.wattmediakit.com/petfood)
*   [About Us](https://www.wattglobalmedia.com/about-us/)
*   [Contact Us](https://www.wattglobalmedia.com/about-us/contact/)

Follow PetfoodIndustry

[](https://www.facebook.com/PetfoodIndustryCommunity "Visit us on Facebook")[](https://www.linkedin.com/groups/5099353/ "Visit us on Linkedin")[](https://www.youtube.com/user/PetFoodIndustryTV "Visit us on Youtube")

*   [Sign In](https://www.petfoodindustry.com/user/login)

Follow PetfoodIndustry

[](https://www.facebook.com/PetfoodIndustryCommunity "Visit us on Facebook")[](https://www.linkedin.com/groups/5099353/ "Visit us on Linkedin")[](https://www.youtube.com/user/PetFoodIndustryTV "Visit us on Youtube")

*   [Market Trends & Reports](https://www.petfoodindustry.com/pet-food-market/market-trends-and-reports)
*   [Nutrition](https://www.petfoodindustry.com/nutrition)
*   [Safety & Quality](https://www.petfoodindustry.com/safety-quality)
*   [Production](https://www.petfoodindustry.com/production)
*   [Packaging](https://www.petfoodindustry.com/packaging)
*   [Sustainability](https://www.petfoodindustry.com/sustainable-dog-and-cat-food)
*   [Protein 360](https://www.petfoodindustry.com/protein-360)
*   [Re

*[... truncated, 24,132 more characters]*

---

### Insectflux Information Session - Food Science Club
*309 words* | Source: **EXA** | [Link](https://cornell.campusgroups.com/FoodScience/rsvp?event_uid=c175e55fb7286fc3534a97440be6e988)

Insectflux Information Session - Food Science Club

===============

[Skip to Main Content](javascript:void('skip-to-main-content');)[Skip to Navigation](javascript:void('skip-to-navigation');)

![Image 2: Loading](https://cornell.campusgroups.com/images/loader-big.gif)

 Loading...

![Image 3: Loading](https://cornell.campusgroups.com/images/loader-big.gif)

 Loading...

[![Image 4: Cornell University Website Logo](https://cornell.campusgroups.com/upload/cornell/2025/image_upload_3881935_Cornell_CG_Logo_9816748.png)![Image 5: Cornell University Logo Image.](https://cornell.campusgroups.com/upload/cornell/2019/image_upload_34747_20190506_155101_56155344.png)](https://cornell.campusgroups.com/groups)

*   [Home](https://cornell.campusgroups.com/home_login)
*   [Groups](https://cornell.campusgroups.com/home/groups/)

*   [Events](https://cornell.campusgroups.com/home/events/)

*   [Support](https://cornell.campusgroups.com/home/support-(copy)/)

*   [Data and Privacy](https://cornell.campusgroups.com/home/data-privacy/)

*       *   [Home](https://cornell.campusgroups.com/home_login)
    *   [Groups](https://cornell.campusgroups.com/home/groups/)
    *   [Events](https://cornell.campusgroups.com/home/events/)
    *   [Support](https://cornell.campusgroups.com/home/support-(copy)/)
    *   [Data and Privacy](https://cornell.campusgroups.com/home/data-privacy/)

*   [Sign In](https://cornell.campusgroups.com/login_only)

Top of Main Content

![Image 6: Banner for Insectflux Information Session](https://cornell.campusgroups.com/upload/cornell/2025/r3_image_upload_5159007_Screenshot_20250916_at_72423PM_91619260.png)

Sep

25

FREE

Insectflux Information Session
==============================

by [Food Science Club](javascript:;)

[Information Session](https://cornell.campusgroups.com/events?event_type=82905)

Thu, Sep 25, 2025

5 PM – 6 PM EDT (GMT-4)

[Add to Calendar](javascript:;)

Private Location (sign in to display)

[View Map](javascript:;)

23

Registered

Registration
------------

Registration is now closed (this event already took place).

Details
-------

 Jason Elate, Founder & CEO of Insectflux, will present on how the $2.5B insect farming and the agri-food industries can be connected through a marketplace enabling a groundbreaking global business model to help solve the $1.1 trillion food waste crisis. Beyond the science and innovation, Jason will also share the mental frameworks he uses to reverse engineer challenges and strategies to become a high achiever. Offering students-experts both a practical look at the future of food systems and personal tools for success. 

[Copy Link](javascript:;)

Hosted By
---------

**Food Science Club** | [Website](https://cornell.campusgroups.com/FoodScience/) | [View More Events](https://cornell.campusgroups.com/events?group_ids=27033)

Co-hosted with: **Food Science Club (OWNER)**, Food Science Product Development Club, Snodgrass and Wigglesworth - Cornell Undergraduate Entomology Club, Grub Ventures, The Alt. Protein Project at Cornell 

[Contact the organizers](javascript:; "Contacting the host")

![Image 7: Cornell University Website Logo](https://cornell.campusgroups.com/upload/cornell/2025/image_upload_3881935_Cornell_CG_Logo_9816748.png)

Contact
-------

Cornell University

Ithaca, New York 14853

United States

[activities@cornell.edu](mailto:activities@cornell.edu)

Links
-----

[Groups](https://cornell.campusgroups.com/home/groups/)

[Events](https://cornell.campusgroups.com/home/events/)

[Support](https://cornell.campusgroups.com/home/support-(copy)/)

[Data and Privacy](https://cornell.campusgroups.com/home/data-privacy/)

[Support Center](https://readyedu.atlassian.net/wiki/spaces/CGSD/overview?homepageId=302186786)

If you have a disability and are having trouble accessing information on this website or need materials in an alternate format, contact [web-accessibility@cornell.edu](mailto:web-accessibility@cornell.edu) for assistance. 

[Equal Education & Employment](https://hr.cornell.edu/about/workplace-rights/equal-education-and-employment)

[©2025 CampusGroups](http://www.novalsys.com/)

---

### Founder Stories: Flux | Skalata
*1,650 words* | Source: **EXA** | [Link](https://www.skalata.vc/founder-stories/flux)

Founder Stories: Flux | Skalata

===============

[News! Down with downtime: why we invested in Factory AI](https://www.skalata.vc/investment-notes/factory-ai)

[News! Skalata Expands West with $5M Government Backing](https://www.skalata.vc/news/skalata-expands-west-with-5m-government-backing)

[![Image 1: Skalata Logo](https://cdn.prod.website-files.com/649cad4c9021ca8165c59d07/64ab30157a03f6aabf808746_skalata_logo.svg)](https://www.skalata.vc/)

Founders

[Founder Support](https://www.skalata.vc/founders/support)[Get Investment](https://www.skalata.vc/founders/get-investment)[Founder Stories](https://www.skalata.vc/founder-stories)

Investors

[Invest with Skalata](https://www.skalata.vc/investors)[Briefing Room](https://www.skalata.vc/content/investor)[Contact](https://www.skalata.vc/contact)

Portfolio

[Our Portfolio](https://www.skalata.vc/portfolio)[Open Roles](https://www.skalata.vc/jobs)

About

[Why Skalata](https://www.skalata.vc/about)[Team & Board](https://www.skalata.vc/team)

Reading

Featured

[![Image 2](https://cdn.prod.website-files.com/649cad4c9021ca8165c59cda/67bd312692f42422978f0498_factory-ai.jpg)](https://www.skalata.vc/investment-notes/factory-ai)[Investment Note Down with downtime: why we invested in Factory AI](https://www.skalata.vc/investment-notes/factory-ai)

[![Image 3](https://cdn.prod.website-files.com/649cad4c9021ca8165c59d07/659f725015ddbf4cb4f527f2_1147683.jpg)![Image 4](https://cdn.prod.website-files.com/649cad4c9021ca8165c59cda/66221177f065b7aeeb0f82fe_joel-tom-claire.webp)](https://www.skalata.vc/founder-stories/foremind)[Founder Story Minding your business with Foremind](https://www.skalata.vc/founder-stories/foremind)

[![Image 5](https://cdn.prod.website-files.com/649cad4c9021ca8165c59cda/667a5167b0db27c4fdba91b4_labyrinth.jpg)](https://www.skalata.vc/blog/founders-and-false-prophets)[Blog Founders and false prophets: a pitch to the founders who’ve stopped listening](https://www.skalata.vc/blog/founders-and-false-prophets)

[Playbooks ##### Australia's biggest guide to raising a (pre) seed sound (2024)](https://www.skalata.vc/playbooks/fundraising)

Featured

[Investment Notes](https://www.skalata.vc/investment-notes)[Founder Stories](https://www.skalata.vc/founder-stories)[Briefing Room](https://www.skalata.vc/content/investor)[News](https://www.skalata.vc/news)

[Founder FAQs](https://www.skalata.vc/founders/get-investment#faqs)

[Contact](https://www.skalata.vc/contact)

[Pitch](https://www.skalata.vc/contact)

[](https://www.skalata.vc/founder-stories/flux#)

[![Image 6](https://cdn.prod.website-files.com/649cad4c9021ca8165c59d07/64ab30157a03f6aabf808746_skalata_logo.svg)](https://www.skalata.vc/founder-stories/flux#)

Founders

[Founder Support](https://www.skalata.vc/founders/support)[Get Investment](https://www.skalata.vc/founders/get-investment)[Founder Stories](https://www.skalata.vc/founder-stories/flux#)

Investors

[Invest with Skalata](https://www.skalata.vc/investors)[Briefing Room](https://www.skalata.vc/content/investor)[Contact](https://www.skalata.vc/contact)

[Portfolio](https://www.skalata.vc/portfolio)

About

[Why Skalata](https://www.skalata.vc/about)[Team &Board](https://www.skalata.vc/team)

Reading

[Investment Notes](https://www.skalata.vc/investment-notes)[Founder Stories](https://www.skalata.vc/founder-stories)[News](https://www.skalata.vc/news)

[Pitch](https://www.skalata.vc/contact)[Contact](https://www.skalata.vc/contact)

Founder Story

Roadmapping a better financial future for young Australians with Flux
---------------------------------------------------------------------

Using gamification, podcasting, and community building, Flux founders Justin, Brett and Gus are humanising personal finance for a Gen Z and Millennial audience

[![Image 7: Sam Henderson](https://cdn.prod.website-files.com/649cad4c9021ca8165c59d07/65f7820121e5ea2f018fd0d7_sam-henderson.webp)](https://www.skalata.vc/team/sam-henderson)[![Image 8](https://www.skalata.vc/founder-stories/flux)](https://www.skalata.vc/founder-stories/flux#)

Written by

[Sam Henderson](https://www.skalata.vc/team/sam-henderson)

&

[](https://www.skalata.vc/founder-stories/flux#)

Operating Partner

![Image 9](https://cdn.prod.website-files.com/649cad4c9021ca8165c59cda/64af9c029dd11af6f84769a7_flux.jpeg)![Image 10](https://www.skalata.vc/founder-stories/flux)![Image 11](https://www.skalata.vc/founder-stories/flux)

Company

Flux

Home

Melbourne

,

VIC

Industry

Finance

Founders

[Gus Hoirisch](https://www.skalata.vc/founder-stories/flux#)

[Brett Joffe](https://www.skalata.vc/founder-stories/flux#)

[Justin Joffe](https://www.skalata.vc/founder-stories/flux#)

[Website](https://www.flux.finance/)

Contents

[Early days](https://www.skalata.vc/founder-stories/flux#early-days)

[Growing the community](https://www.skalata.vc/founder-stories/flux#growing-the-community)

[Monetisation and revenue growth](https://www.skalata.vc/founder-stories/flux#monetisation-and-revenue-growth)

[T

*[... truncated, 15,029 more characters]*

---

### The Plantbased Business Hour: Investing in Food System Transformation with Jason Ingle
*585 words* | Source: **EXA** | [Link](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle)

The Plantbased Business Hour: Investing in Food System Transformation with Jason Ingle

===============

Toggle navigation[](https://plantbasedbusinesshour.libsyn.com/ "Home Page")

*    
*   [About](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle)
*   [Episodes](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle#)
    *   [All Episodes](https://plantbasedbusinesshour.libsyn.com/)
    *   [Categories](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle#)
        *   [agriculture](https://plantbasedbusinesshour.libsyn.com/category/agriculture)
        *   [alternative proteins](https://plantbasedbusinesshour.libsyn.com/category/alternative+proteins)
        *   [animal rights](https://plantbasedbusinesshour.libsyn.com/category/animal+rights)
        *   [biotech](https://plantbasedbusinesshour.libsyn.com/category/biotech)
        *   [business](https://plantbasedbusinesshour.libsyn.com/category/business)
        *   [cheese](https://plantbasedbusinesshour.libsyn.com/category/cheese)
        *   [climate change](https://plantbasedbusinesshour.libsyn.com/category/climate+change)
        *   [energy](https://plantbasedbusinesshour.libsyn.com/category/energy)
        *   [entertainment](https://plantbasedbusinesshour.libsyn.com/category/entertainment)
        *   [environment](https://plantbasedbusinesshour.libsyn.com/category/environment)
        *   [ethics](https://plantbasedbusinesshour.libsyn.com/category/ethics)
        *   [farming](https://plantbasedbusinesshour.libsyn.com/category/farming)
        *   [fashion](https://plantbasedbusinesshour.libsyn.com/category/fashion)
        *   [fast food](https://plantbasedbusinesshour.libsyn.com/category/fast+food)
        *   [finance](https://plantbasedbusinesshour.libsyn.com/category/finance)
        *   [food](https://plantbasedbusinesshour.libsyn.com/category/food)
        *   [food business](https://plantbasedbusinesshour.libsyn.com/category/food+business)
        *   [food systems transformation](https://plantbasedbusinesshour.libsyn.com/category/food+systems+transformation)
        *   [food tech](https://plantbasedbusinesshour.libsyn.com/category/food+tech)
        *   [food trends](https://plantbasedbusinesshour.libsyn.com/category/food+trends)
        *   [general](https://plantbasedbusinesshour.libsyn.com/category/general)
        *   [health](https://plantbasedbusinesshour.libsyn.com/category/health)
        *   [investing](https://plantbasedbusinesshour.libsyn.com/category/investing)
        *   [legal](https://plantbasedbusinesshour.libsyn.com/category/legal)
        *   [market predictions](https://plantbasedbusinesshour.libsyn.com/category/market+predictions)
        *   [news](https://plantbasedbusinesshour.libsyn.com/category/news)
        *   [pizza](https://plantbasedbusinesshour.libsyn.com/category/pizza)
        *   [plant-based](https://plantbasedbusinesshour.libsyn.com/category/plant-based)
        *   [plantbased](https://plantbasedbusinesshour.libsyn.com/category/plantbased)
        *   [politics](https://plantbasedbusinesshour.libsyn.com/category/politics)
        *   [precision fermentation](https://plantbasedbusinesshour.libsyn.com/category/precision+fermentation)
        *   [restaurants](https://plantbasedbusinesshour.libsyn.com/category/restaurants)
        *   [science](https://plantbasedbusinesshour.libsyn.com/category/science)
        *   [seafood](https://plantbasedbusinesshour.libsyn.com/category/seafood)
        *   [socially conscious business](https://plantbasedbusinesshour.libsyn.com/category/socially+conscious+business)
        *   [sustainability](https://plantbasedbusinesshour.libsyn.com/category/sustainability)
        *   [tech business](https://plantbasedbusinesshour.libsyn.com/category/tech+business)
        *   [travel](https://plantbasedbusinesshour.libsyn.com/category/travel)
        *   [vegan](https://plantbasedbusinesshour.libsyn.com/category/vegan)

    *   [Archives](https://plantbasedbusinesshour.libsyn.com/investing-in-food-system-transformation-with-jason-ingle#)
        *   [2025](https://plantbasedbusinesshour.libsyn.com/2025)
            *   [May](https://plantbasedbusinesshour.libsyn.com/2025/05)
            *   [April](https://plantbasedbusinesshour.libsyn.com/2025/04)
            *   [March](https://plantbasedbusinesshour.libsyn.com/2025/03)
            *   [February](https://plantbasedbusinesshour.libsyn.com/2025/02)
            *   [January](https://plantbasedbusinesshour.libsyn.com/2025/01)

        *   [2024](https://plantbasedbusinesshour.libsyn.com/2024)
            *   [December](https://plantbasedbusinesshour.libsyn.com/2024/12)
            *   [November](https://plantbasedbusinesshour.libsyn.com/2024/11)
            *   [October](https://plantbasedbusinesshour.libsyn.com/2024/10)
            *   [September](https://plantbasedbusinesshour.libsyn.co

*[... truncated, 7,536 more characters]*

---

### Speakers - GLOBExCHANGE
*2,147 words* | Source: **GOOGLE** | [Link](https://www.globeseries.com/globexchange/speakers/)

Speakers - GLOBExCHANGE

===============

![Image 1: Revisit consent button](https://www.globeseries.com/globexchange/wp-content/plugins/cookie-law-info/lite/frontend/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://www.globeseries.com/globexchange/wp-content/plugins/cookie-law-info/lite/frontend/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

No cookies to display.

Functional

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

No cookies to display.

Analytics

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

No cookies to display.

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

No cookies to display.

 Reject All  Save My Preferences  Accept All 

[![Image 3: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

[![Image 4: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

[![Image 5: GLOBExCHANGE](https://www.globeseries.com/globexchange/wp-content/themes/globe-2025/img/GX25_Wordmark_K.svg)](https://www.globeseries.com/globexchange)

*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)
*   [](https://www.globeseries.com/globexchange/speakers/)

*   [Home](https://www.globeseries.com/globexchange/ "Home")
*   [Why Attend](https://www.globeseries.com/globexchange/why-attend/ "Why Attend")
*   [Program _Toggle Submenu_](https://www.globeseries.com/globexchange/speakers/# "Program")
    *   [Program](https://www.globeseries.com/globexchange/program/?menu_parent=4729 "Program")
    *   [Partner Program](https://www.globeseries.com/globexchange/partner-program/?menu_parent=4729 "Partner Program")

*   [Speakers](https://www.globeseries.com/globexchange/speakers/ "Speakers")
*   [Partners](https://www.globeseries.com/globexchange/partners/ "Partners")

*   [Essential Info _Toggle Submenu_](https://www.globeseries.com/globexchange/speakers/# "Essential Info")
    *   [Venue, Accommodations & Accessibility](https://www.globeseries.com/globexchange/venue-accommodations-accessibility/?menu_parent=4351 "Venue, Accommodations & Accessibility")
    *   [FAQs](https://www.globeseries.com/globexchange/faqs/?menu_parent=4351 "FAQs")
    *   [Media](https://www.globeseries.com/globexchange/media/?menu_parent=4351 "Media")

*   [NEW – Roadmap for Action](https://www.globeseries.com/globexchange/roadmap-for-action-2024/ "NEW - Roadmap for Action")
*   [Register](https://cvent.me/0OEevR "Register")

Speakers
========

[![Image 6](https://www.globeseries.com/globexchange/wp-content/uploads/sites/4/2025/01/PHO_ChrisABRAHAM-scaled-e1736525769877-1024x1024.jpg) Chris Abraham Director, The Assembly – Energy in Canada⟶](https://www.globeseries.com/globexchange/speaker/chris-abraham/)

[![Image 7](https://www.globeseries.com/globexchange/wp-content/uploads/sites/4/2025/02/Kai-Alderson.jpg) Kai Alder

*[... truncated, 40,409 more characters]*

---

### C2MTL | The Emerging Entrepreneurs Contest
*1,057 words* | Source: **GOOGLE** | [Link](https://c2montreal.com/contest/)

Emerging

Entrepreneurs
------------------------

![Image 1:  Emerging entrepreneurs at work at C2 Montréal  ](https://images.ctfassets.net/ht21ojggmic0/4CKu1ypS5Hq3Xdkic3KSNo/b0f20384044f561d82b9965d489962d1/2024-05-22_1034004800_Photo_by_Jimmy_Hamelin.jpg?w=2880&h=1920&fm=webp)

Discover the best of the next generation of entrepreneurs.

Each year, the Emerging Entrepreneurs Contest helps propel 25 of Quebec’s most promising new companies. Launched in 2011, made possible by the support of Claudine and Stephen Bronfman, the contest’s mission is to help local startups shine by giving them access to networking, visibility and the tools they need to take their business to new heights. Since its inception, more than 325 companies have benefitted from the contest, and 85% of them are still operating. Among them are flagships of our economy such as Dialogue, Les Fermes Lufa, BonLook, Frank and Oak, Alvéole, Breather, Oatbox and Busbud.

The Emerging Entrepreneurs Contest celebrated its 14th edition this year and rewarded 25 promising young companies.

![Image 2: C2MTL](https://images.ctfassets.net/ht21ojggmic0/18angbs3itjgfwY6fSeCTh/f1eb8951b78f61d655917044ad708a6c/Design_sans_titre.jpeg?w=1901&h=1924&fm=webp)

Perks

*   A pass to C2MTL 2025 for your company.

*   Exclusive workshops tailored to your needs.

*   A meet & greet with a speaker

*   Special networking opportunities within the C2 ecosystem and more

*   A chance to win access to Startupfest 2025 with exclusive mentorship

*   And much more!

![Image 3: C2MTL](https://images.ctfassets.net/ht21ojggmic0/7mEJgStwaXWL9eBoH36T0z/4e9efa7f69e15c82440962494b4efbc5/20230526_104902_Photo_by_Arianne_Bergeron-2__1_.jpeg?w=1901&h=1924&fm=webp)

Requirements

*   Be a creative startup company that has been in existence for less than three years.

*   Be incorporated in Quebec.

*   Be actively in business.

Meet the next wave of Quebec business change-makers. Here are the winners of the 2025 edition :

*   Samuel Babity: mTatt, Co-founder et director

mTatt develops medical microtattoos for real-time monitoring of biological markers, such as blood sugar levels. This non-invasive technology enables continuous health monitoring, with data accessible via a smartwatch-style reader for home monitoring.

*   Nima Jalalvandi: Ready Plan Go, Founder and director

Ready Plan Go helps accounting firms triple their capacity by automating low-margin T1 returns with an invisible, white-label AI platform.

*   Jason Elate: InsectFlux, Founder and director

One small step for insects, one giant leap for sustainability. The best way to predict the future is to create it.

*   Romane L'Hemeury : Ova Entreprise, Founder and president

Ova entreprise, A new way of looking at death. A company specializing in the design of biodegradable caskets and high-end funeral services.

*   Marine Queffeulou : Kalego Solutions, Founder and director

KALEGO SOLUTIONS INC innovates tomorrow's materials by offering companies simple, permanent and eco-responsible surface treatments. The advanced technology startup uses plasma, an artificial lightning bolt, to modify the extreme surface of materials. Its flagship application is a robust anti-fog treatment applied directly to the optics of medical endoscopes.

*   Ariane Brien Legault : Eden Creative Studio, Co-founder and General Director

Eden Creative Studio designs immersive worlds where digital innovation meets human connection - transforming public spaces into living works of art.

*   Nicolas Jourdan-Gassin: Encore Biomatériaux, Co-founder

Encore! Biomatériaux gives a second life to Quebec’s agri-food waste by turning it into 100% bio-sourced materials — creating a future where nothing is lost, but everything is transformed again and again!

*   Tonya Dickenson: Asymmetric by Design, Founder and Creative Director

Zero waste. Fewer mines — just imagination. We design bold, circular jewelry from vintage, repurposed, and recycled materials for change-driven women who want to express their values and make a positive impact on the planet and society.

*   Jacob Giroux Lamont: Enda Technologies, Co-founder and President

ENDA is a smart medical assistant using AI to automate clinical note-taking, streamline documentation, and reduce healthcare professionals’ administrative burden, saving them up to 2 hours per day.

*   Kostas Eleftheriou: School is Loud, Founder

School is Loud turns classrooms into newsrooms, where students learn storytelling, fact-checking, and critical thinking through live radio and podcasting — without adding to teachers’ workloads.

*   Maxime LeBleu, Geneviève Langlois, Kacim Azouz: Anagram Lab, Co-founders

AnagramLab is an innovative startup specializing in textile recycling, with a unique process that turns fabric waste into a sustainable, versatile, and recyclable material — a green alternative to traditional fabrics.

*   Jean-Simon Boucher: Cortech Sports, Founder and President

Cortech Sports enhances brain recovery

*[... truncated, 2,977 more characters]*

---

### Global: Virtual breakfasts at all hours of the day.
*19,507 words* | Source: **GOOGLE** | [Link](https://impactforbreakfast.com/chapter/global-virtual-breakfasts-at-all-hours-of-the-day)

NAME ORGANIZATION
Abha Thorat-Shah British Asian Trust
Adam Robbins Triodos Investment Management
Adam Greene Klaatch
Admir Trnjanin BlueOrchard
Admir Imami CDC Group
Adrian Floor Cofra Holding
Aerie Changala Nuru International
Agathe Bourgon Montpelier Foundation
Ahish Kaushik The Carlyle Group / Family Office
Akanksha Anand Said Business School, University Of Oxford
Akbar Khan Fortune Law
Akshay Singh London Business School
Alan Boyce Impact +
Alan Bernstein Social Venture Circle
Alberto Caballero LSE
Alejandra Baigun London Business School
Alessandro Mele Ethicalfin
Alex Jarman Investing for Good
Alex Goodenough British International Investment
Alexander Barkawi Council on Economic Policies
Alexander Hayward Vestra Private Office
Alexandra Korijn Enclude
Alexandre Ayad GiveXpert
Alexia Ponce Quadia
Alexis Ettinger Aspen Institute
Alice Piterova ustwo
Alice Chapple Impact Value
Alice Motte-Munoz Non Executive Director
Alicia Robb Next Wave Ventures
Alina Truhina SPRING
Alison Benson Freelance journalist
Amanda Powell-Smith Forster Communications
Amanda Mosle Friedman Mosle Associates
Amanda Feldman Heliotropy
Aminarta Kumari Morgan Stanley
Amy Birchall Volans
Amy Clarke Tribe Impact Capital
Anand Chandani responsAbility Investments AG
Ketaki Gokhale ResponsAbility Investments AG
Andre Lottersberger Impact Investing & Legal Advisory
Andre Wegner Authentise
Andy Fuller Skagen
Andy Lower ADAP Capital LLC
Ani Haykuni ANI HAYKUNI Cancer Treatment Support Foundation & Vordan
Anita Kover UBS Optimus Foundation
Anja Koenig Social Impact Markets
Anna Mroczkowska Topan AG
Anna Brosnan Small Foundation
Anne Ackermann Credit Suisse
Anne Salter Anne Salter
Anne-Madeleine Kropf Independent
Annie Roberts Open Capital
Anoop Maini Excite Ventures
Anton Simanowitz Social performance solutions
Antonio Gomez Lopez UBS
Antonio Potenza Proodos Impact Capital
Anu Bajaj BayTree Ventures Pvt Ltd
Anuradha Bhatnagar Ashoka UK
Anuradha Shetty Soros Economic Development Fund, Open Society Foundations
Anuradha Shetty Independent
Archana Shah Wilson Center of Social Entrepreneurship, Pace University
Ari Bjornsson Privilege Management
Arjun Gupta UGE
Arko Chatterjee NaturaYuva AG
Arlene Esdaile HUBSolutions Ltd
Arnaud Longet AIT Geneva SA
Arnaud Gandon Heptagon Capital
Arthur R Wood
arti Bareja ClearlySo
ASHNI SHAH SOCIAL FINANCE
Atalanti Moqette GivingWomen
Aude Thibaut Chair, Medical Aid Films
Audrey Selian Artha Impact (Rianta Capital Zurich)
Aunnie Patton Power Intelligent Impact
Aurelien Leblay Small Foundation
Balz Hug CleverBridge AG
Barbara Scola CGAP
Basil Tschümperlin Student
basile gaillard Medair
Belinda Bell Cambridge Social Ventures
Ben Dixon SYSTEMIQ
Ben Metz www.benmetz.org
Benjamin Stein AB Bernstein
Bertrand Beghin Avondale Private Capital
Beth Gertz Seven Hills Advisors
Bethany Larsen University of Oxford
Betsy Lippman UNHCR
Bijoya BANERJEA International Commission for Jurists
Bonnie Chiu The Social Investment Consultancy
Bora Polat All Impact – Venture Philanthropy
Brad Merchant Palladium
Brian Iselin slavefreetrade
Brian Walsh Brian Walsh
Brigitte Small Self employed
Brindusa Burrows The Ground_Up Project
Bruno De Kegel Arvella Investments
Candice Hampson Big Society Capital
Carl Pratt Future Planet
Carolina de Azevedo responsAbility Investments
carolina staehle none
Caroline Ashley Director, System Transformation Programmes, Forum for the Future
Carrie Baptist Save the Children UK
Casper Fluitman AgUnity
Catalina Jossen
Catherine McDonald ICRC
Catherine Thompson Fairtrade Foundation
Catherine Grigioni Artha Collections
Catia Cesari TAU investment
Celine Chi Hae Wong UBS AG
Chaarvi Badani AmFam Institute
Charlie Curtis Mr
Charlie Graham-Brown Seedstars World SA
Charlotte Davis CDC Group
Chiara Rinaldi Senior sustainability advisor
Chris Cozzone Bain Capital Impact
Chris Greenwood EspeRare Foundation
Christian Regnicoli Enabling Qapital AG
Christin ter Braak-Forstinger Chi Impact Capital
Christina Ulardic Swiss Re
Christopher Toy Tribe Impact Capital
Ciara Shannon EdenWorks
Claire Lexa HSBC
Claire Smith Beyond Fund Advisors
Claire Michelet CDC Group
Claudius Gutemann Rianta Capital Zurich AG
Clint Bartlett Transformational Business Network
cole ramse none
Colleen Ebbitt J.P. Morgan
Conny Czymoch Moderation and Media Coaching
Cornelius Pietzner Alterra Impact Finance
Cory Donovan ImpactPHL
Curt SCHULTZ Anchor Group
Cyrille Antignac UBERIS
Dana Elman Federation of Small Businesses
Daniel Nowack Yunus Social Business
Daniel Rostrup Applied Social Innovations, Inc.
Daniel Duman Total Impact Capital
Daniel Gächter SIIN Network
Daniela Herrmann Topan
Danielle Brassel Zurich Insurance
Danyal Sattar Big Issue Invest
Darshita Gillies Blu Dot
David Cordobés International Trade Centre
David Oehm DFS Lab
David Irwin Irwin Grayson Associates
David Laou NVCGeneva.ch / État de Genève
David Fitzherbert Progression Capital
David Carrington David Carrington
David Pollock Consilium Capital
David Wright Turquoise
David Gowenlock IESE
De

*[... truncated, 138,882 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Insectflux marketplace connects agrifood with insect protein ...](https://www.petfoodindustry.com/insect-based-cat-and-dog-food/news/15754667/insectflux-marketplace-connects-agrifood-with-insect-protein)**
  - Source: petfoodindustry.com
  - *Sep 5, 2025 ... Insectflux marketplace connects agrifood with insect protein. Climate ... Founder and CEO Jason Elate is scheduled to present during N...*

- **[Ep 163: Transforming The Insect Industry | Ingenious Thinkers | Say ...](https://www.youtube.com/watch?v=LqewqrS8Ynw)**
  - Source: youtube.com
  - *May 7, 2025 ... Joining us on Ingenious Thinkers hosted by Ken Tencer today is Jason Elate, Founder of InsectFlux ... podcast, part blog series, part ...*

- **[Jason Elate - GLOBExCHANGE](https://www.globeseries.com/globexchange/speaker/jason-elate/)**
  - Source: globeseries.com
  - *Feb 12, 2025 ... Since October 2023, Jason has conducted over 390 industry interviews ... Jason Elate Founder, Insectflux: Global One Stop Shop connec...*

- **[Speakers - GLOBExCHANGE](https://www.globeseries.com/globexchange/speakers/)**
  - Source: globeseries.com
  - *Jason Elate Founder, Insectflux: Global One Stop Shop connecting Agri-Food & $2.5B Insect Farming industries ⟶ · Shaun Fantauzzo VP of Policy, First N...*

- **[The Emerging Entrepreneurs Contest - C2MTL](https://c2montreal.com/contest/)**
  - Source: c2montreal.com
  - *Jason Elate: InsectFlux, Founder and director. One small step for insects, one giant leap for sustainability. The best way to predict the future is to...*

- **[Global: Virtual breakfasts at all hours of the day.](https://impactforbreakfast.com/chapter/global-virtual-breakfasts-at-all-hours-of-the-day)**
  - Source: impactforbreakfast.com
  - *Worldwide Music Conference. Carolin Zeitler, The Impact Collective. Anna ... Jason Elate, INSECTFLUX. Alexander Landau, n/a. Alexander Landau, n/a. Le...*

---

*Generated by Founder Scraper*
