# Samy Debbah

## Position actuelle

**Titre** : Founder
**Entreprise** : Swelio
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

💰 Basically, a software for realtors that enables them to attract, manage, and grow their clients through a simplified process via SMS, email, and ads.

💸 I've tried so many software tools to help realtors grow, and all of them were either too expensive, too difficult to learn, or filled with numerous unnecessary functionalities.

That's where Swelio comes in—a CRM designed for individual realtors with functionalities that they actually need and use on a daily basis. It's easy to use and... not expensive at all 🚀

## Résumé

👋 Hey, I’m Samy. I help realtors simplify growth. And I’m the founder of Swelio

I’ve spent the last 8 years working in IT and automation.

Along the way, I helped my aunt, a solo realtor, generate more leads online.

I made it easier for her to find clients, follow up consistently, and manage her deals without stress.

She started closing more deals with less effort.

That experience inspired me to create Swelio, a simple and affordable CRM built for realtors like her.

No complicated features. No overwhelm. Just the essentials solo agents actually need.

I also help realtors cut through the noise around AI so they can focus on the tools that truly save them time, without the overwhelm of constant AI headlines.

Today my focus is helping realtors:

→ Attract more clients without working 24/7
→ Save hours every week with AI and automation
→ Stay visible on social media without overthinking it
→ Simplify the tech side of their business

If you’re a realtor looking to grow your brand and free up your time, you’re in the right place.

I share tips, tools, and lessons I’ve learned from building Swelio and working with realtors every week.

Glad you’re here.

Samy

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAE0yRioBquq6CbQ_ENSX-8Dr8uULiRiJoEY/


---

# Samy Debbah

## Position actuelle

**Entreprise** : Swelio

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Samy Debbah
*Swelio*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Swelio: Pricing, Free Demo & Features](https://softwarefinder.com/crm/swelio)
*2025-01-01*
- Category: article

### [Swelio 1.18.31](https://www.nuget.org/packages/Swelio)
*2024-11-20*
- Category: article

### [Swelio 1.6 released](https://delphi32.blogspot.com/search/label/C%23)
*2024-06-07*
- Category: blog

### [Swelio 1.5 - Freeware Belgian eID card SDK](https://delphi32.blogspot.com/2014/06)
*2018-04-01*
- Category: blog

### [Web3 Founder Journey: From 0 to 1](https://samyilmaz.substack.com/p/web3-founder-journey-from-0-to-1)
*2023-08-10*
- Category: blog

---

## 📖 Full Content (Scraped)

*5 articles scraped, 3,997 words total*

### Swelio: Pricing, Free Demo & Features
*1,324 words* | Source: **EXA** | [Link](https://softwarefinder.com/crm/swelio)

Swelio: Pricing, Free Demo & Features | Software Finder

===============

[![Image 2: Softwarefinder](https://softwarefinder.com/_next/image?url=%2Fimages%2Fsf-logo-new.svg&w=640&q=75)](https://softwarefinder.com/)

[go](https://softwarefinder.com/search-result?search=)

No category found for""

*   [Software Categories](https://softwarefinder.com/categories)
*   [For Vendors](https://softwarefinder.com/for-vendors)
*   [Resource Center](https://softwarefinder.com/resources)
*   [Write a Review](https://softwarefinder.com/review)
*   [Join Free or Log In](https://my.softwarefinder.com/login)

![Image 3: icon-search](https://softwarefinder.com/_next/image?url=%2Fimages%2Ficon-search.svg&w=48&q=75)

[![Image 4: Softwarefinder](https://softwarefinder.com/_next/image?url=%2Fimages%2Fsf-logo-new.svg&w=640&q=75)](https://softwarefinder.com/)

*   [Software Categories](https://softwarefinder.com/categories)
*   [For Vendors](https://softwarefinder.com/for-vendors)
*   [Resource Center](https://softwarefinder.com/resources)
*   [Write a Review](https://softwarefinder.com/review)

[![Image 5: user-plus](https://softwarefinder.com/_next/image?url=%2Fimages%2FuserPluss.svg&w=32&q=75)Join Free or Log In](https://my.softwarefinder.com/login)

*   [Home](https://softwarefinder.com/)
*   [CRM Software](https://softwarefinder.com/crm)
*   [Swelio](https://softwarefinder.com/crm/swelio)

![Image 6: Swelio](https://softwarefinder.com/_next/image?url=https%3A%2F%2Fsoftware-finder-prod.blr1.digitaloceanspaces.com%2FSwelio_796f562cc3.png&w=3840&q=75)

Swelio
======

0

[Write a review](https://softwarefinder.com/review/crm/swelio)

Watch Demo Get Pricing

[* Overview](https://softwarefinder.com/crm/swelio#overview)[* Features](https://softwarefinder.com/crm/swelio#features)[* Pros and Cons](https://softwarefinder.com/crm/swelio#pros-cons)[* FAQs](https://softwarefinder.com/crm/swelio#faqs)[* Alternatives](https://softwarefinder.com/crm/swelio/alternatives)

Last Updated Sep 2, 2025

Overview
--------

Swelio delivers tailored software for real estate professionals, streamlining client interactions and simplifying marketing workflows. It efficiently manages leads and deals, boosting agent productivity. While feature-rich, the platform may lack advanced customization options for precise workflows. Swelio equips users with powerful tools to support scalable growth.

See The Software In Action 

 Watch Free Demo!Get A Firsthand Look At Software 

 Watch Free Demo
-------------------------------------------------------------------------------------------------

- [x] I agree to the[Terms of Service](https://softwarefinder.com/terms-of-service)and[Privacy Policy](https://softwarefinder.com/privacy-policy). 

Watch Demo

Be the first one to leave a review!

No review found

Write a Review

![Image 7: vendorReviewSummaryStar icon](https://softwarefinder.com/_next/image?url=%2Fimages%2FvendorReviewSummaryStar.svg&w=64&q=75)

###### Starting Price

###### Custom

Get Pricing

Swelio Specifications
---------------------

Contact Management

Lead Management

Opportunity Management

Deal Pipeline Management

View All Specifications

**What Is Swelio?**
-------------------

Swelio software is a comprehensive solution that helps meet the diverse demands of real estate professionals. The platform offers tools to manage client relationships, streamline marketing campaigns, and optimize daily operations. It centralizes communications, simplifies deal pipelines, and automates various tasks, empowering small to medium-sized real estate businesses to achieve desired efficiency and success in their client interactions and sales processes.

### **Swelio Pricing**

The platform features a subscription-based pricing model with three available plans:

*   **Essential Plan:**$35/month
*   **Pro Plan:**$50/month
*   **Business Plan:**$70/month

A 14-day free trial is offered, allowing users to evaluate features before committing to a Swelio price plan. Request a personalized **[Swelio pricing quote](https://softwarefinder.com/crm/swelio)** tailored to specific requirements.

_Disclaimer: The pricing is subject to change._

### **Swelio Integrations**

Swelio seamlessly integrates with various applications, including:

*   Gmail
*   Outlook Calendar
*   Meta
*   WhatsApp
*   Messenger
*   Facebook
*   [PayPal software](https://softwarefinder.com/retail/paypal-software)
*   Google

Watch a free **[Swelio demo](https://softwarefinder.com/crm/swelio)** to learn more about its integration arrangements.

**Who Is Swelio For?**
----------------------

Swelio is designed for real estate professionals seeking a streamlined and intuitive CRM solution. Ideal for realtors, the platform centralizes client and property information, streamlines task management, and enhances productivity through a user-friendly interface that leverages ease of use and efficiency.

**Is Swelio Right For You?**
----------------------------

Swelio is an ideal choice for realtors seeking a 

*[... truncated, 11,566 more characters]*

---

### Swelio 1.18.31
*390 words* | Source: **EXA** | [Link](https://www.nuget.org/packages/Swelio)

*   [README](https://www.nuget.org/packages/Swelio#readme-body-tab)
*   [Frameworks](https://www.nuget.org/packages/Swelio#supportedframeworks-body-tab)
*   [Dependencies](https://www.nuget.org/packages/Swelio#dependencies-body-tab)
*   [Used By](https://www.nuget.org/packages/Swelio#usedby-body-tab)
*   [Versions](https://www.nuget.org/packages/Swelio#versions-body-tab)

<img src="https://github.com/perevoznyk/swelio-sdk/raw/master/Swelio_icon.png" width="120">

swelio-sdk
----------

Belgian eID card SDK

### Features

*   No external dependencies
*   x32 and x64 versions. There are 2 apart nuget package for x32 and x64 version. You need to select the right one for your configuration.
*   All functions have Unicode and Ansi version
*   Simple to use, easy to embed in any programming language
*   For Microsoft .NET Framework and C++
*   Works in Windows XP - Windows 11
*   Provides more than 200 different functions
*   QR codes generation
*   Export card data to XML
*   Multiple readers support
*   Exports photo in different graphical formats
*   Hash functions and encryption supported
*   Check of the pin code
*   Can create and verify digital signatures
*   Many other useful things...

| **Product** | Compatible and additional computed target framework versions. |
| --- | --- |
| .NET | net8.0 is compatible.net8.0-android was computed.net8.0-browser was computed.net8.0-ios was computed.net8.0-maccatalyst was computed.net8.0-macos was computed.net8.0-tvos was computed.net8.0-windows was computed.net9.0 was computed.net9.0-android was computed.net9.0-browser was computed.net9.0-ios was computed.net9.0-maccatalyst was computed.net9.0-macos was computed.net9.0-tvos was computed.net9.0-windows was computed.net10.0 was computed.net10.0-android was computed.net10.0-browser was computed.net10.0-ios was computed.net10.0-maccatalyst was computed.net10.0-macos was computed.net10.0-tvos was computed.net10.0-windows was computed. |
| .NET Framework | net462 is compatible.net463 was computed.net47 was computed.net471 was computed.net472 is compatible.net48 is compatible.net481 was computed. |

*   #### .NETFramework 4.6.2

    *   [System.Drawing.Common](https://www.nuget.org/packages/System.Drawing.Common/)(>= 9.0.0)

*   #### .NETFramework 4.7.2

    *   [System.Drawing.Common](https://www.nuget.org/packages/System.Drawing.Common/)(>= 9.0.0)

*   #### .NETFramework 4.8

    *   [System.Drawing.Common](https://www.nuget.org/packages/System.Drawing.Common/)(>= 9.0.0)

*   #### net8.0

    *   [System.Drawing.Common](https://www.nuget.org/packages/System.Drawing.Common/)(>= 9.0.0)

### **NuGet packages**

This package is not used by any NuGet packages.

### **GitHub repositories**

This package is not used by any popular GitHub repositories.

| Version | Downloads | Last Updated |
| --- | --- | --- |
| [1.18.31](https://www.nuget.org/packages/Swelio/1.18.31 "1.18.31") | 268 | 11/20/2024 |
| [1.18.30](https://www.nuget.org/packages/Swelio/1.18.30 "1.18.30") | 187 | 11/14/2024 |
| [1.18.29](https://www.nuget.org/packages/Swelio/1.18.29 "1.18.29") | 465 | 8/29/2023 |
| [1.18.27](https://www.nuget.org/packages/Swelio/1.18.27 "1.18.27") | 364 | 4/13/2023 |
| [1.18.26](https://www.nuget.org/packages/Swelio/1.18.26 "1.18.26") | 586 | 12/14/2022 |
| [1.18.22](https://www.nuget.org/packages/Swelio/1.18.22 "1.18.22") | 474 | 11/28/2022 |
| [1.18.19](https://www.nuget.org/packages/Swelio/1.18.19 "1.18.19") | 672 | 7/14/2022 |
| [1.18.11](https://www.nuget.org/packages/Swelio/1.18.11 "1.18.11") | 767 | 11/16/2021 |
| [1.18.8](https://www.nuget.org/packages/Swelio/1.18.8 "1.18.8") | 1,946 | 10/4/2021 |
| [1.18.6](https://www.nuget.org/packages/Swelio/1.18.6 "1.18.6") | 493 | 9/29/2021 |
| [1.18.0](https://www.nuget.org/packages/Swelio/1.18.0 "1.18.0") | 1,675 | 3/5/2021 |
| [1.14.0](https://www.nuget.org/packages/Swelio/1.14.0 "1.14.0") | 1,637 | 8/31/2018 |

---

### Modern software design
*369 words* | Source: **EXA** | [Link](https://delphi32.blogspot.com/search/label/C%23)

Modern software design

===============
[Skip to main content](https://delphi32.blogspot.com/search/label/C#main)

### Search This Blog

[Modern software design](https://delphi32.blogspot.com/)
========================================================

Serhiy Perevoznyk new blog on https://perevoznyk.wordpress.com

Posts
-----

 Showing posts with the label C

[Show all](https://delphi32.blogspot.com/)

 No results found 

[Powered by Blogger](https://www.blogger.com/)

 Theme images by [Michael Elkan](http://www.offset.com/photos/394244)

[](https://www.blogger.com/profile/05054587701401425172)

[Serhiy Perevoznyk](https://www.blogger.com/profile/05054587701401425172)[Visit profile](https://www.blogger.com/profile/05054587701401425172)

### Archive

*   [October 2015 1](https://delphi32.blogspot.com/2015/10/)
*   [October 2014 1](https://delphi32.blogspot.com/2014/10/)
*   [June 2014 2](https://delphi32.blogspot.com/2014/06/)
*   [February 2014 2](https://delphi32.blogspot.com/2014/02/)
*   [December 2013 2](https://delphi32.blogspot.com/2013/12/)
*   [November 2013 3](https://delphi32.blogspot.com/2013/11/)
*   [September 2013 1](https://delphi32.blogspot.com/2013/09/)
*   [June 2013 1](https://delphi32.blogspot.com/2013/06/)
*   [December 2012 1](https://delphi32.blogspot.com/2012/12/)
*   [November 2012 1](https://delphi32.blogspot.com/2012/11/)

*   [October 2012 1](https://delphi32.blogspot.com/2012/10/)
*   [September 2012 1](https://delphi32.blogspot.com/2012/09/)
*   [August 2012 2](https://delphi32.blogspot.com/2012/08/)
*   [July 2012 2](https://delphi32.blogspot.com/2012/07/)
*   [June 2012 1](https://delphi32.blogspot.com/2012/06/)
*   [May 2012 1](https://delphi32.blogspot.com/2012/05/)
*   [April 2012 1](https://delphi32.blogspot.com/2012/04/)
*   [March 2012 2](https://delphi32.blogspot.com/2012/03/)
*   [February 2012 3](https://delphi32.blogspot.com/2012/02/)
*   [January 2012 3](https://delphi32.blogspot.com/2012/01/)
*   [December 2011 2](https://delphi32.blogspot.com/2011/12/)
*   [November 2011 3](https://delphi32.blogspot.com/2011/11/)
*   [October 2011 1](https://delphi32.blogspot.com/2011/10/)
*   [September 2011 2](https://delphi32.blogspot.com/2011/09/)
*   [August 2011 2](https://delphi32.blogspot.com/2011/08/)
*   [July 2011 2](https://delphi32.blogspot.com/2011/07/)
*   [June 2011 2](https://delphi32.blogspot.com/2011/06/)
*   [May 2011 2](https://delphi32.blogspot.com/2011/05/)
*   [April 2011 3](https://delphi32.blogspot.com/2011/04/)
*   [March 2011 3](https://delphi32.blogspot.com/2011/03/)
*   [February 2011 6](https://delphi32.blogspot.com/2011/02/)
*   [January 2011 4](https://delphi32.blogspot.com/2011/01/)
*   [December 2010 7](https://delphi32.blogspot.com/2010/12/)
*   [November 2010 3](https://delphi32.blogspot.com/2010/11/)
*   [October 2010 1](https://delphi32.blogspot.com/2010/10/)
*   [September 2010 2](https://delphi32.blogspot.com/2010/09/)
*   [August 2010 2](https://delphi32.blogspot.com/2010/08/)
*   [July 2010 2](https://delphi32.blogspot.com/2010/07/)
*   [June 2010 1](https://delphi32.blogspot.com/2010/06/)
*   [May 2010 17](https://delphi32.blogspot.com/2010/05/)
*   [April 2010 3](https://delphi32.blogspot.com/2010/04/)
*   [March 2010 11](https://delphi32.blogspot.com/2010/03/)
*   [February 2010 7](https://delphi32.blogspot.com/2010/02/)
*   [January 2010 11](https://delphi32.blogspot.com/2010/01/)
*   [December 2009 26](https://delphi32.blogspot.com/2009/12/)
*   [November 2009 16](https://delphi32.blogspot.com/2009/11/)
*   [October 2009 11](https://delphi32.blogspot.com/2009/10/)
*   [September 2009 2](https://delphi32.blogspot.com/2009/09/)
*   [June 2009 3](https://delphi32.blogspot.com/2009/06/)
*   [May 2009 2](https://delphi32.blogspot.com/2009/05/)
*   [February 2009 3](https://delphi32.blogspot.com/2009/02/)
*   [October 2008 2](https://delphi32.blogspot.com/2008/10/)
*   [September 2008 1](https://delphi32.blogspot.com/2008/09/)
*   [July 2008 2](https://delphi32.blogspot.com/2008/07/)
*   [December 2006 2](https://delphi32.blogspot.com/2006/12/)
*   [November 2006 1](https://delphi32.blogspot.com/2006/11/)
*   [August 2006 1](https://delphi32.blogspot.com/2006/08/)
*   [March 2006 4](https://delphi32.blogspot.com/2006/03/)
*   [February 2006 1](https://delphi32.blogspot.com/2006/02/)
*   [January 2006 2](https://delphi32.blogspot.com/2006/01/)
*   [March 2005 1](https://delphi32.blogspot.com/2005/03/)

Show more Show less

### Labels

*   [.NET](https://delphi32.blogspot.com/search/label/.NET)
*   [Android](https://delphi32.blogspot.com/search/label/Android)
*   [C#](https://delphi32.blogspot.com/search/label/C%23)
*   [C++](https://delphi32.blogspot.com/search/label/C%2B%2B)
*   [Delphi](https://delphi32.blogspot.com/search/label/Delphi)
*   [Desktop](https://delphi32.blogspot.com/search/label/Desktop)
*   [Development](https://delphi32.blogspot.com/search/label/Development)
*   [Diary](https://delphi32.blogspot.com/search/label/Diary)
* 

*[... truncated, 1,405 more characters]*

---

### Swelio 1.5 - Freeware Belgian eID card SDK
*898 words* | Source: **EXA** | [Link](https://delphi32.blogspot.com/2014/06)

Modern software design

===============
[Skip to main content](https://delphi32.blogspot.com/2014/06#main)

### Search This Blog

[Modern software design](https://delphi32.blogspot.com/)
========================================================

Serhiy Perevoznyk new blog on https://perevoznyk.wordpress.com

Posts
-----

 Showing posts from June, 2014 

[Show all](https://delphi32.blogspot.com/)

[](https://delphi32.blogspot.com/2014/06)
### [Swelio 1.5 - Freeware Belgian eID card SDK](https://delphi32.blogspot.com/2014/06/swelio-15-freeware-belgian-eid-card-sdk.html)

*   Get link
*   Facebook
*   X
*   Pinterest
*   Email
*   Other Apps

![Image 2: Image](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjXAOUiG8d0Y4-jOVSnn4kzvWiB5GigRrU1-NREfz_1NnNCa1DROT0FgSF_efAaSpFJDYbqxK1z_YJWwxgTu6EUvI0FnvppuI1L_CB41ElvRuV6E-KLzSIP2_vLSMu6bc6qn2rn/s1600/Swelio_icon.png)

 The new release of Swelio - freeware Belgian eID card SDK is available for download . Whats new in this release: * Fixed some bugs in C++ code * Updated C++ documentation * Added Delphi documentation * Added Microsoft .NET binding The C# source code of the .NET binding included. The library supports AnyCPU, x86 and x64 projects. It is compatible with .NET Framework 2.0 - 4.5 and tested with all Windows versions starting from Windows XP. The provided assembly was compiled for .NET Framework 2.0 using Microsoft Visual Studio 2008, but the project can be easily upgraded to the more recent versions of the .NET Framework and Visual Studio. It was done to cover more possible configuration, because the downgrade of the Visual Studio project is not possible. The sample project is also provided. Please leave your comments or write a review to help me improve the quality and functionality of the Swelio SDK. If you found a bug - please report it to me using the contact form . The... 

[](https://delphi32.blogspot.com/2014/06/swelio-15-freeware-belgian-eid-card-sdk.html)

[June 23, 2014](https://delphi32.blogspot.com/2014/06/swelio-15-freeware-belgian-eid-card-sdk.html "permanent link")[Post a Comment](https://delphi32.blogspot.com/2014/06/swelio-15-freeware-belgian-eid-card-sdk.html#comments)[](https://www.blogger.com/email-post/11216446/4279513370722324748 "Email Post")

[Read more](https://delphi32.blogspot.com/2014/06/swelio-15-freeware-belgian-eid-card-sdk.html "Swelio 1.5 - Freeware Belgian eID card SDK")

[](https://delphi32.blogspot.com/2014/06)
### [EIDNative library update](https://delphi32.blogspot.com/2014/06/eidnative-library-update.html)

*   Get link
*   Facebook
*   X
*   Pinterest
*   Email
*   Other Apps

 There is a small update for EIDNative library 3.0 available: http://users.telenet.be/serhiy.perevoznyk/download/EIDLibrarySetup.zip This update solves some problems related to the new Eid card with chip v1.7 

[](https://delphi32.blogspot.com/2014/06/eidnative-library-update.html)

[June 19, 2014](https://delphi32.blogspot.com/2014/06/eidnative-library-update.html "permanent link")[Post a Comment](https://delphi32.blogspot.com/2014/06/eidnative-library-update.html#comments)[](https://www.blogger.com/email-post/11216446/3900972780810268615 "Email Post")

[Read more](https://delphi32.blogspot.com/2014/06/eidnative-library-update.html "EIDNative library update")

[More posts](https://delphi32.blogspot.com/search?updated-max=2014-06-19T10:36:00%2B02:00 "More posts")

[Powered by Blogger](https://www.blogger.com/)

 Theme images by [Michael Elkan](http://www.offset.com/photos/394244)

[](https://www.blogger.com/profile/05054587701401425172)

[Serhiy Perevoznyk](https://www.blogger.com/profile/05054587701401425172)[Visit profile](https://www.blogger.com/profile/05054587701401425172)

### Archive

*   [October 2015 1](https://delphi32.blogspot.com/2015/10/)
*   [October 2014 1](https://delphi32.blogspot.com/2014/10/)
*   [June 2014 2](https://delphi32.blogspot.com/2014/06/)
*   [February 2014 2](https://delphi32.blogspot.com/2014/02/)
*   [December 2013 2](https://delphi32.blogspot.com/2013/12/)
*   [November 2013 3](https://delphi32.blogspot.com/2013/11/)
*   [September 2013 1](https://delphi32.blogspot.com/2013/09/)
*   [June 2013 1](https://delphi32.blogspot.com/2013/06/)
*   [December 2012 1](https://delphi32.blogspot.com/2012/12/)
*   [November 2012 1](https://delphi32.blogspot.com/2012/11/)

*   [October 2012 1](https://delphi32.blogspot.com/2012/10/)
*   [September 2012 1](https://delphi32.blogspot.com/2012/09/)
*   [August 2012 2](https://delphi32.blogspot.com/2012/08/)
*   [July 2012 2](https://delphi32.blogspot.com/2012/07/)
*   [June 2012 1](https://delphi32.blogspot.com/2012/06/)
*   [May 2012 1](https://delphi32.blogspot.com/2012/05/)
*   [April 2012 1](https://delphi32.blogspot.com/2012/04/)
*   [March 2012 2](https://delphi32.blogspot.com/2012/03/)
*   [February 2012 3](https://delphi32.blogspot.com/2012/02/)
*   [January 2012 3](https://delphi32.blogspot.com/2012/01/)
*   [December 2011 2](https://delphi32.blogspot.com/2011

*[... truncated, 7,217 more characters]*

---

### Web3 Founder Journey: From 0 to 1
*1,016 words* | Source: **EXA** | [Link](https://samyilmaz.substack.com/p/web3-founder-journey-from-0-to-1)

Over the last 3.5 years, we have spoken with 600+ Web3 founders. As they were hard at work building their companies through winter and summer cycles, we observed that they faced a unique set of challenges. These challenges were distinct and different from those of their Web1 and Web2 predecessors. Yet, there has been very little information or guidance out there on how to overcome them.

With that in mind, in the spirit of cross-learning, last week during Messari Mainnet, I interviewed five exceptional Web3 leaders at a soirée event @ the Harvard Club of NYC. The goal of the gathering was to share the “scar tissue” and to discuss what everyone has learned in their Web3 journey.

These five Web3 leaders represent both companies and DAOs across three layers of the Web3 stack — L1s ([John Wu](https://twitter.com/John1wu), President of AvaLabs), Web3 service layer (Richard Ma, CEO of [QuantStamp](https://twitter.com/Quantstamp)), and applications ([Sid Powell](https://twitter.com/syrupsid), CEO of [Maple Finance](https://twitter.com/maplefinance), [Lucas Vogelsan](https://twitter.com/lucasvo)g CEO of [Centrifuge](https://twitter.com/centrifuge), and Michael Carter, CEO of Play.co &[Storyverse](https://twitter.com/storyverse_xyz).

The panelists brought diversity of founding experience — Richard and Sid are first time founders; John, Lucas, and Michael have founded Web2 firms in the past. Some have launched chains, some have launched on chain, some have plans to launch tokens while others have already retired a token.

We received an overwhelming amount of interest with 300+ Web3 founders applying to join the soirée. So, we ran a survey to which more than 50 Web3 builders have responded.

We asked a simple question: _what is the #1 existential problem you are facing today?_

Here’s what they said:

1.   Legal & Regulatory Challenges — 92%

2.   Finding a Product-Market Fit — 74%

3.   Team Building & Recruiting — 65%

The below are the key takeaways from the discussion organized across these three pain points. For the recording of the panel, you may see my youtube channel [here](https://youtu.be/wsSXwWvlOv0).

→ You have to know who you are first, before you go ask for an opinion. Are you a company who wants to ask for permission or to ask for forgiveness?

→ By definition, when it comes to legal opinions, answers are likely more flexible. Before changing your product based on the feedback of one firm, try to get a second or third opinion. The type of your law firm you want is the one who can help you architect a solution for the problem you want.

→ Compliance cannot be put on “autopilot” or outsourced. It is the obligation for the early team to have an owner of the compliance strategy.

→ In the deliberation of what to do, in crypto, there are always competitors who try to move very quickly. You might lose, if you take too much time.

→ Ask your lawyer how to mitigate the risk of achieving the outcome you want, rather than asking them for permission.

→ Embrace the “fail fast” MVP mentality and iterate with your audience feedback. Unlike Web2, the process of finding product-market-fit in Web3 is much more iterative.

→ Not only do you have to listen to your customers and your developers, but also to your community — leverage the latter as a source of social signaling to help guide their decisions.

→ Find your niche and build an exceptional product in it.

→ Unlike shipping a Web2 product, in Web3 there is very low tolerance for failure, especially in DeFi. For that reason, you are better off breaking things up in chunks and releasing them sequentially (e.g. V1, V2, etc), after auditing your code.

→ Do as much learning “off chain” as possible, because learning “on chain” could be very costly. Try to validate your idea without writing any smart contract code on chain.

→ In the B2B context, try to sell your product first — for say $250K — before building the product. That is how you can elicit whether the problem you are trying to solve is actually very painful.

→ Optimize for 1. Community 2. Speed, scale, and cost advantages 3. EVM compatibility 4. Execution environment, access points, and tools to make development easier 5. Grants are nice to have, but don’t optimize for that first.

→ Many layer ones are converging to a single architecture — akin to how Sequel did many years ago. For that reason, optimizing for community and users might be the right strategy for you.

→ It is really hard to tell who to bet on. If you make the wrong bet, you will lose just because you chose the wrong chain. Consider going multi-chain.

→ If you do go multi-chain, consider aqui-hiring a team to be able to bring in talent native to that chain. That’s what Maple Finance did.

→ Team building always starts with a hiring process. The low-hanging fruit is to leverage university networks in search for talent.

→ Look for a “T” structure personality. Look for people who can go deep, but can also be flexible. In other words, can the

*[... truncated, 1,065 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
