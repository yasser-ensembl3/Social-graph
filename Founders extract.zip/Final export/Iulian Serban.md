# Iulian Serban

## Position actuelle

**Titre** : Founder, CEO
**Entreprise** : Korbit AI
**Durée dans le rôle** : 6 years 11 months in role
**Durée dans l'entreprise** : 6 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Korbit was a Khosla Ventures-backed GenAI startup on a mission to empower and level up millions of software engineers. Korbit built two distinct products and helped impact over 25,000 students and engineers. I started bootstrapping this during my years as a PhD student.

Our first product was an edtech learning platform (an AI Teacher) delivering personalized learning on software and data science skills to 20,000+ students around the world. This was a GenAI product built pre-ChatGPT. The AI Teacher assessed each learner, constructed personalized learning paths and guided them through every lesson with instructional videos, exercises and coding projects coupled with personalized feedback. The system was powered by 20+ ML components, including Socratic tutoring, generative models for synthesizing educational content and reinforcement learning (RL) for adapting each student's learning path.

We published a dozen research papers on the technology. The AI Teacher achieved huge improvements on standardized learning assessments - 2.5X higher normalized scores compared to MOOCs using videos and static exercises. Unfortunately, due to the business model and unit economics, we decided to pivot to software companies with greater purchasing power.

Our second product was a code reviewer product able to detect over 10,000 types of issues from critical bugs and security vulnerabilities to code architecture and performance issues, and train the software engineering team to resolve them. The Korbit Code Reviewer beta was launched in early 2024 and reviewed over 100,000 pull requests and helped over 180 paying customers to fix 30,000 issues in their codebase before shipping to production. The product reached ~$500,000 in ARR with a 110% NRR.

Unfortunately, due to the extreme competitive landscape and our limited resources, we decided to shut down the company in September, 2025, and move on to greener pastures.

## Résumé

I'm a GenAI Researcher Turned Entrepreneur & Product Builder.

I have led different R&D and ML teams to build GenAI products from scratch (designing, building, iterating and evaluating) and bringing them to market until they become revenue-positive.

I was the Founder and CEO of Korbit, a Khosla Ventures-backed GenAI startup on a mission to empower and level up millions of software engineers through upskilling, mentorship and code reviews. We took experimental technology to market, building & launching new products when people said it couldn’t be done:
- We published a dozen research papers and won multiple awards.
- We raised over $15 million and created 50 new jobs.
- We funded and supervised half a dozen Masters and PhDs working with the Quebec Artificial Intelligence Institute, McGill University and other institutions.
- Our AI Teacher helped to teach and level up over 20,000 students and professionals across 50+ countries - including thousands who would otherwise not have had a chance!
- Our Code Reviewer helped to identify over 100,000 security vulnerabilities, functionality bugs, and many more across thousands of software projects.

Before founding Korbit, I was a mathematician, a software engineer, and then a GenAI researcher. I completed my PhD in AI at Mila (Quebec's Artificial Intelligence Institute) investigating natural language processing, reinforcement learning and interactive conversational systems under the supervision of Yoshua Bengio and Aaron Courville. While working with Amazon at Mila, I led a team of 15 engineers and researchers to build and deploy the Milabot conversational system to 10,000 homes across Canada and US. I have published 40+ research papers, co-authored two books and won 5 awards for research contributions and entrepreneurship.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAI7TcMBb94F7VtkL8DFPZJHaPKfZ5IhfFs/
**Connexions partagées** : 61


---

# Iulian Serban

## Position actuelle

**Entreprise** : Korbit AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Iulian Serban
*Korbit AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [How to Build Software With LLMs (Part 3) · Korbit Blog](https://www.korbit.ai/post/how-to-build-software-with-llms-part-3)
*2025-05-02*
- Category: article

### [How to Build Software With LLMs (Part 1) · Korbit Blog](https://www.korbit.ai/post/how-to-build-software-with-llms-part-1)
*2025-05-02*
- Category: article

### [How to Build Software With LLMs (Part 2) · Korbit Blog](https://www.korbit.ai/post/how-to-build-software-with-llms-part-2)
*2025-05-02*
- Category: article

### [Turing Award Winner Yoshua Bengio and Korbit cofounder Iulian Serban talk about AI in Education. — Eye On AI](https://www.eye-on.ai/podcast-064)
*2019-01-01*
- Category: podcast

### [Iulian Serban - Korbit AI | LinkedIn](https://ca.linkedin.com/in/iulian-serban-28365710)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[#10 - Iulian Serban: PhD to $13M Raised and Korbit AI, The Future ...](https://www.youtube.com/watch?v=lPl-AgLXRhI)**
  - Source: youtube.com
  - *May 14, 2025 ... Meet Iulian Serban. From coding at 12 to raising ... Korbit AI: https://www.korbit.ai/ Podcast Links: Substack: https://thinkingthoma...*

- **[11 Canadian tech companies to watch in 2020 | BetaKit](https://betakit.com/11-canadian-tech-companies-to-watch-in-2020/)**
  - Source: betakit.com
  - *Jan 21, 2020 ... Korbit AI. Website, korbit.ai. Headquarters, Montreal, QC. Year founded, 2017. Key People. Iulian Serban, co-founder, CEO & CTO; Anso...*

- **[Infinite coder (claude sonnet 3.5) GPTs - There's An AI For That®](https://theresanaiforthat.com/gpts/s/infinite+coder+%28claude+sonnet+3.5%29/most-saved/)**
  - Source: theresanaiforthat.com
  - *Sep 8, 2025 ... Korbit AI website. Iulian Serban profile picture. Iulian Serban. 204 karma · Apr 10, 2024. We've internally been using Korbit since it...*

- **[DEliBots : Deliberation Enhancing Bots](https://www.repository.cam.ac.uk/bitstreams/ab6fce34-944e-45ed-a684-b18478af5e54/download)**
  - Source: repository.cam.ac.uk
  - *1For example, https://www.korbit.ai/. 2https://www.webex ... Ryan Thomas Lowe, Nissan Pow, Iulian Serban, Laurent Charlin, Chia-Wei Liu, and Joelle. P...*

- **[AI APIs for Napari - TAAFT®](https://theresanaiforthat.com/apis/s/napari/sota/?sort=default)**
  - Source: theresanaiforthat.com
  - *Sep 18, 2025 ... Didn't find the AI you were looking for? Post a request Create a tool. Korbit AI ... Iulian Serban profile picture. Iulian Serban. 20...*

- **[MBZUAI Faculty Brochure | PDF | Artificial Intelligence | Intelligence ...](https://www.scribd.com/document/823719509/MBZUAI-Faculty-Brochure)**
  - Source: scribd.com
  - *Technologies (NAACL-HLT 2021) chief scientific officer of Korbit AI, ... Iulian Serban, François St-Hilaire, and Jackie capable of providing learners...*

- **[Question Generation for Creating Exercises and Personalized ...](https://escholarship.mcgill.ca/downloads/8c97kw63h)**
  - Source: escholarship.mcgill.ca
  - *... Iulian Serban (CEO, Korbit ... Muhammad Shayan Korbit Technologies Montreal, shayan@korbit.ai. Robert Belfer Korbit Technologies Montreal, robert@...*

- **[Korbit Technologies - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/korbit-ai)**
  - Source: crunchbase.com
  - *Products & Services. Korbit AI Code Reviews. An AI-powered tool that ... Photo of Iulian Serban. Iulian Serban Co-founder, CEO and CTO. View All. News...*

- **[Impact Report 2022-23 | Mila](https://mila.quebec/en/about/impact-reports/impact-report-2022-23)**
  - Source: mila.quebec
  - *Cofounded by Iulian Serban in 2018, the company helps software engineering teams create optimized code in record time. With the Korbit AI Mentor, user...*

- **[Natural Language Generation for Intelligent Tutoring Systems](https://espace.etsmtl.ca/id/eprint/3024/1/VU_Do_Dung.pdf)**
  - Source: espace.etsmtl.ca
  - *However, I met Iulian Serban who was the CEO/CTO of Korbit Inc. The mission ... Upload link: https://www.korbit.ai/fpt-mooc-week-one-practice-quiz....*

---

*Generated by Founder Scraper*
