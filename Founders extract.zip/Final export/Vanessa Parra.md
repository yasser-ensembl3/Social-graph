# Vanessa Parra

## Position actuelle

**Titre** : Co-Founder, Spiritual Storyteller & Trainer
**Entreprise** : Autónomo
**Durée dans le rôle** : 1 month in role
**Durée dans l'entreprise** : 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Co-founder of an initiative focused on creating a safe haven for the integral healing of the Latino migrant community in Montreal.

In this new professional chapter, my work is focused on:

Spiritual Storytelling & Writing: Author of the book "The Expansion of the Fireflies," an exploration of collective trauma, rest, and purpose through the lens of the gospel.

Training & Spiritual Formation: Designer and facilitator of bilingual (Spanish/English) workshops focused on healing from trauma, migratory grief, resilience, mind renewal, and purpose-driven stewardship.

My approach combines narrative and faith with practical, trauma-informed care tools. My training includes the Trauma Care MasterClass (CareImpact, 2024) and the Trauma Competent Care course (Trauma Free World, 2025), and I am in the process of certification as a Trauma Trainer Associate.

## Résumé

Spiritual Storyteller & Trainer in Healing and Resilience | Writing & Spiritual Formation for the Migrant Community

My mission is to create "safe havens" where the Latino migrant community can heal, grow, and find purpose in Christ. My work lies at the intersection of faith, trauma healing, and the migrant experience.

After more than 10 years in audiovisual production, a profound calling led me to redirect my path. Today, I use my experience in narrative to inform my work as a Spiritual Storyteller. My work is supported by extensive training, including the Trauma Care MasterClass (CareImpact, 2024) and the Trauma Competent Care course (Trauma Free World, 2025). I am also currently in the process of certification as a Trauma Trainer Associate with both organizations.

Through my book, "The Expansion of the Fireflies," and the workshops I facilitate, I walk alongside others in their Spiritual Formation, addressing topics such as:

Community Healing: Processing collective trauma and migratory grief.

Mind Renewal: Dismantling deep-rooted lies with the truth of the Word.

Integral Well-being: Practicing biblical rest and financial stewardship.

Resilience in Faith: Building strength for the invisible battles of migration.

My approach is warm, practical, and deeply biblical, using symbolic and artistic dynamics to make healing an integral experience.

True transformation happens in community; a space where every healed story becomes a light that illuminates the path for others. Let's keep expanding the light, together. ✨

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA5FZ8EB1oojycbYPfL0gOli4sS9Iau_gaM/


---

# Vanessa Parra

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Vanessa Parra

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394517095654322176 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQEtC7uX1N-0zQ/mp4-720p-30fp-crf28/B4EZp6aFvKHcBw-/0/1762990257176?e=1765785600&v=beta&t=AbDWtJf2Xqj-XVChG9mHlqUgyy6aBKAqehYf5RJtJWA | https://media.licdn.com/dms/image/v2/D4E05AQEtC7uX1N-0zQ/videocover-high/B4EZp6aFvKHcCI-/0/1762990256394?e=1765785600&v=beta&t=fdl3b7MfbhQysbZDNkckMTbjqPdYmgZtmgAWYpbRUf8 | ¡De los libros a la experiencia! ✨
Tras el lanzamiento de nuestros libros, Susúrrate Bonito y La expansión de las luciérnagas, te invitamos a nuestro primer taller vivencial: "Metamorfosis: Mariposas y Luciérnagas".

Creamos este espacio íntimo para redescubrir la voz de Dios en nuestro interior y encender juntos la esperanza en comunidad. 

Es un taller presencial de 2 horas en Montreal, donde exploraremos cómo la voz que nos habla por dentro puede convertirse en una luz que alumbra hacia afuera.

— TALLER PRESENCIAL (MONTREAL) —

Cuándo: Sábado 29 de Noviembre
Hora: 3:30 p.m. - 5:30 p.m.
Inscripciones: ¡Cupos limitados! Escríbenos para reservar tu lugar: proyectomariposasyluciernagas@gmail.com

¿No estás en Montreal pero te gustaría participar? ¡Escríbenos al mismo correo y te contaremos de la versión virtual que estamos preparando!

Recuerda: La metamorfosis está en el silencio.
¡Te esperamos!
#Metamorfosis #TallerVivencial #Sanidad #ComunidadMigrante #Fe #Resiliencia #CrecimientoEspiritual #Montreal #Luciérnagas | 3 | 0 | 0 | 3w | Post | Vanessa Parra | https://www.linkedin.com/in/vanessaparra-paez | https://linkedin.com/in/vanessaparra-paez | 2025-12-08T07:11:44.291Z |  | 2025-11-12T23:30:59.088Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394476039831408642 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFHt_rktg5WwQ/feedshare-shrink_800/B4EZp50xYaIUAg-/0/1762980469289?e=1766620800&v=beta&t=5N09WGfSAZ_82TWTPAE7HMoXtsU1DhmpzYxHnjv8aRY | Permanent roots, new beginnings 🌱 ✨ 

With deep gratitude and excitement, I share that I’ve received my Canadian Permanent Resident card! 🍁 
 
For those who have migrated, you know this is much more than a milestone — it’s a story.

Every migration story begins long before the journey itself. Canada has allowed me to experience migration —not only as a human reality, but as something reflected throughout creation— in a way I never had before.

It’s a land of extraordinary diversity —beautiful, complex, and alive— where different roots intertwine to form a shared ecosystem.

To every migrant in this community, my admiration for the courage it takes to navigate the invisible battles along the way.

And to those who call this place home, my heartfelt gratitude for welcoming growth with warmth — through a coffee, a helping hand, or a simple act of kindness.

Personally, what moved me most was the warmth of strangers who chose to welcome us with generosity — just to name a few: our Airbnb host who sat with us for coffee and helped us find our way around town, a neighbor who gifted us a couch when we had just arrived without even knowing our names, and the pastors who invited us into their home for Thanksgiving and Christmas, gave us our first tree, and adopted us as family.

Finding that kind of warmth upon arrival —from people who gain nothing in return, yet offer everything humanly possible— is what makes new soil feel fertile, warm, and alive. 

Here’s to the journeys that transform us — and to the roots we keep growing wherever we are. 🌿 | 31 | 10 | 0 | 3w | Post | Vanessa Parra | https://www.linkedin.com/in/vanessaparra-paez | https://linkedin.com/in/vanessaparra-paez | 2025-12-08T07:11:44.291Z |  | 2025-11-12T20:47:50.617Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391188377674625024 | Text |  |  | Muy emocionada de compartir mi blog "Cuando la cima se convierte en semilla".

Es una historia muy personal sobre mi transición del mundo audiovisual a un nuevo llamado: crear "refugios seguros" para la sanidad y la comunidad. Es el "por qué" detrás de mi nueva misión y de mi libro, "La expansión de las luciérnagas" ✨ 🌱 .

Me encantaría que pudieran leerlo y compartir sus reflexiones en los comentarios. ¡Gracias por acompañarme en este nuevo comienzo!

#StorytellingEspiritual #Sanidad #Resiliencia #ComunidadMigrante #Fe #NuevosComienzos | 15 | 3 | 1 | 1mo | Post | Vanessa Parra | https://www.linkedin.com/in/vanessaparra-paez | https://linkedin.com/in/vanessaparra-paez | 2025-12-08T07:11:44.292Z |  | 2025-11-03T19:03:50.877Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387189726123806721 | Text |  |  | Today marks the close of a truly meaningful chapter.

After 3.5 years with ReDefine, I’m deeply grateful for the experiences, the learning, and the many incredible people I’ve had the chance to work alongside. Each season brought new challenges and growth — both professionally and personally.

I’m especially thankful to my colleagues and leaders for their support and collaboration throughout this journey. Working with such a dedicated and compassionate team has been a privilege.

As I step into a new season — one focused on writing, training, and building community — I carry forward the lessons and relationships that have shaped me. I’m genuinely excited for what’s ahead and hopeful that our paths will cross again in meaningful ways.

Grateful for every step of the journey 🙌 | 39 | 12 | 0 | 1mo | Post | Vanessa Parra | https://www.linkedin.com/in/vanessaparra-paez | https://linkedin.com/in/vanessaparra-paez | 2025-12-08T07:11:44.292Z |  | 2025-10-23T18:14:38.056Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7286066513176850432 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE-d8OS4SXFjw/feedshare-shrink_800/B56ZRRD.M5GoAg-/0/1736526790189?e=1766620800&v=beta&t=IT3i85AunIPUqUHoRpdApkqj988xmEsXbTwzvm4E35M | 📣 Exciting News 📣 
✨ Talking Tom is finally HERE! ✨ 
I had the amazing opportunity to be part of this project and learn from such creative and talented people. | 37 | 4 | 2 | 10mo | Post | Vanessa Parra | https://www.linkedin.com/in/vanessaparra-paez | https://linkedin.com/in/vanessaparra-paez | 2025-12-08T07:11:44.293Z |  | 2025-01-17T17:07:05.311Z | https://www.linkedin.com/feed/update/urn:li:activity:7283521268123869184/ |  | 

---



---

# Vanessa Parra


*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 17 |

---

## 📚 Articles & Blog Posts

### [Vanessa Parra, Author at DigitalNEST](https://digitalnest.org/author/vanessa-p/)
*2024-11-20*
- Category: article

### [Vanessa J Villa Parra Digital Marketing | Pros Marketplace](https://prosmarketplace.com/remoteworker/profile/vanessajcz0ne58)
*2025-09-10*
- Category: article

### [Vanessa Paredes Virtual Assistant | Pros Marketplace](https://prosmarketplace.com/remoteworker/profile/paredesvanessa)
*2025-09-09*
- Category: article

### [Vanessa - Parasec](https://www.parasec.com/staff/vanessa/)
*2024-09-11*
- Category: article

### [Vanessa Virguez Social Media Manager | Pros Marketplace](https://prosmarketplace.com/remoteworker/profile/mvanessav)
*2025-09-11*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Vanessa Parra Ferreira | Senior Manager](https://www.deloitte.com/uk/en/about/people/profiles.vanessaferreira+4789da49.html)**
  - Source: deloitte.com
  - *Click on the image to visit the Green Room podcasts page. The Green Room Podcasts ... Vanessa Parra Ferreira. Senior Manager | Strategy and ......*

- **[The Can Do Man – Caught in the Act](https://blog.strazcenter.org/2018/09/25/the-can-do-man/)**
  - Source: blog.strazcenter.org
  - *Sep 25, 2018 ... ... podcast. Our interview with Eric goes live on Thursday, 9/27/18 ... Vanessa Parra, zeros. Caught in the Act. Back to top. Exit mo...*

- **[International Lawyers Assisting Workers (ILAW) Network ...](https://www.influencewatch.org/organization/international-lawyers-assisting-workers-ilaw-network/)**
  - Source: influencewatch.org
  - *Listen to the weekly IW Podcast · Subscribe to Our Newsletter · Educational ... Campaign and media communications director Vanessa Parra worked for Am...*

- **[Work With Me - Marketing with Cultura](https://marketingwithcultura.com/work-with-me/)**
  - Source: marketingwithcultura.com
  - *... Vanessa Parra! Founder of Marketing With Cultura Media & Host of the Marketing With Cultura Podcast. As a proud first-generation Mexican American ...*

- **[The Americans Season 1 recap: Episode guide and review for ...](https://slate.com/culture/2013/04/episode-11-the-americans-season-1-recap-episode-guide-and-review-for-episode-11.html)**
  - Source: slate.com
  - *Apr 17, 2013 ... This week she chats with Vanessa Parra, TV fanatic and daughter of Cold War-aficionado Cuban exiles. ... Podcast FAQs · Newsletters ·...*

- **[Three people arrested in connection with Emmanuel Torres homicide](https://www.azcentral.com/story/news/local/phoenix-breaking/2020/10/22/three-people-arrested-connection-phoenix-homicide-june/3732189001/)**
  - Source: azcentral.com
  - *Oct 22, 2020 ... In addition, Vanessa Parra contacted investigators and provided them ... In an interview with police, Leonard Parra would not admit t...*

- **[Ways to Partner & Support Digital NEST Interns - DigitalNEST](https://digitalnest.org/ways-to-partner-support-digital-nest-interns/)**
  - Source: digitalnest.org
  - *Ways to Partner & Support Digital NEST Interns. Written by Vanessa Parra. Published On: November 20th, 2024Categories: bizzNEST, Education Equity, ......*

- **[Vanessa Parra - Women's Cross Country - East Central University ...](https://ecutigers.com/sports/womens-cross-country/roster/vanessa-parra/1072)**
  - Source: ecutigers.com
  - *Vanessa Parra - Before ECU: A four-year member of the Eastwood High School ... Great American Conference (GAC), opens in new tab. NCAA Division 2 ......*

- **[Curtis Wesley](https://www.letu.edu/academics/arts-and-sciences/fac-bio-wesley.html)**
  - Source: letu.edu
  - *... Vanessa Parra, and Joy Wee), Proceedings of the RESNA Annual Conference 2013. Presentations. April 2014, American Mathematical Society Sectional M...*

- **[Beyond the Noise: Crisis Communications in Foreign Aid | by ...](https://medium.com/@interactionorg/beyond-the-noise-crisis-communications-in-foreign-aid-91364cc1c616)**
  - Source: medium.com
  - *Apr 15, 2025 ... By Mitch McQuate and Emma Nardone. “It is easy to demonize an organization that has a logo and no face.” — Vanessa Parra....*

---

*Generated by Founder Scraper*
