# Ben Rodier

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : FrontlineIQ
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Software Development

## Description du rôle

FrontlineIQ is an AI sales coach for customer-facing sales teams in stores, dealerships, and branches.

## Résumé

Entrepreneur with 20 years of experience building companies and developing technology that drives innovation in commerce and retail. As Co-Founder of Salesfloor, I helped redefine the role of sales associates in driving performance and customer engagement. Now, as CEO of FrontlineIQ, I’m focused on unlocking the power of AI sales coaching for distributed sales teams.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABeL8YBBGj857ihn_pT0c9VaBKNVyONe5I/
**Connexions partagées** : 173


---

# Ben Rodier

## Position actuelle

**Entreprise** : FrontlineIQ

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Ben Rodier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397493768611971072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFkt7BPuv9q3Q/feedshare-shrink_800/B4EZqktXV.IwAg-/0/1763699949938?e=1766620800&v=beta&t=uj08hBnaSNhdMUq0brAkkE2gjiUTeB6nzaj5kM8v7ww | What a week! We held our first FrontlineIQ board meeting since closing our seed round — amazing to work side-by-side with AQC Capital and UP.Labs in Montreal. 

A whirlwind of deep work sessions focused on our biggest opportunities ahead in 2026, plus time to celebrate together in some of the city’s best spots 🍻 

This is what partnership looks like!

Mike Linton , Steven Dahan, Kalthoum Bouacida, ICD.D, Louis Matthews, D. Patrick Pettay, Adam Lane (missing Shammeera Alles) | 182 | 10 | 0 | 2w | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:34.315Z |  | 2025-11-21T04:39:13.225Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396258629185818624 | Article |  |  | We are humbled at FrontlineIQ, to be sharing the stage with so many great nominees for the Vendors in Partnership awards at #NRF2026

Cast your vote for FrontlineIQ here: https://lnkd.in/eGWVJX-H

Voting closes this Friday, November 21 🗳️ | 19 | 0 | 0 | 2w | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:34.316Z |  | 2025-11-17T18:51:13.038Z | https://usvendorawards.awardsplatform.com/entry/vote/QyJeboJB?keywords=frontlineIQ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395998451685027840 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a43de236-6bbe-4940-8387-6a0986d3c24f | https://media.licdn.com/dms/image/v2/D4E05AQG3q1FQ-ZSEMg/videocover-low/B4EZqPdXp8IQCE-/0/1763343434715?e=1765774800&v=beta&t=Jn-BKPpDvDPEx64GTu94U28xYwZwdQzZqjQoKKxmSs0 | I really believe showing up to practice is one of the most underrated things top performers do. 

Think about an extraordinary athlete like Michael Jordan; it wasn’t just game-day talent that made him great, it was the relentless reps in practice when no one was watching.

We’re embracing that same approach as we build FrontlineIQ. Growth is uncomfortable, progress isn’t always obvious, and the breakthroughs come from consistent reps and real coaching. And that's the same mindset we’re helping frontline sales teams develop every week through our platform. | 129 | 1 | 1 | 3w | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:34.316Z |  | 2025-11-17T01:37:21.888Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394172430023434241 | Text |  |  | Shammeera Alles is hiring. We're looking for our next Product Manager, but to be clear, we’re not looking for a typical PM.

At FrontlineIQ, the problem we're solving is big, and the product we’re building is ambitious. This is an opportunity to shape how AI transforms coaching and training for frontline sales teams. 

If you’re ready to build something game-changing, read below 👇 | 34 | 0 | 0 | 3w | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:34.317Z |  | 2025-11-12T00:41:24.398Z | https://www.linkedin.com/feed/update/urn:li:activity:7394057696028663809/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7392753435126956032 | Video (LinkedIn Source) | blob:https://www.linkedin.com/638bdc1d-aa74-4d15-add7-b33ffc96cac6 | https://media.licdn.com/dms/image/v2/D4E05AQH1UY9t93ywcA/videocover-low/B4EZphWCroKcCI-/0/1762569763133?e=1765774800&v=beta&t=5MM53KBAMzRHkHLuctjY2Bn3OOWheE6RZWvMz5fm0BY | Last week’s announcement wasn’t the finish line, it was the green light. 

The energy at FrontlineIQ this week has shifted — faster decisions, sharper focus, bigger goals.

This short clip captures the moment we announced our oversubscribed seed round, and the mindset that’s driving what we're building 🚀 

#FrontlineIQ #AI #SalesCoaching #Startups | 308 | 39 | 2 | 1mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:34.317Z |  | 2025-11-08T02:42:49.651Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7380777668608438272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4621b673-fb38-4de9-b0d8-cb96a5fc951b | https://media.licdn.com/dms/image/v2/D4E05AQEzPjcTD0XniQ/videocover-low/B4EZm3JuggHcB4-/0/1759714486155?e=1765774800&v=beta&t=eJ05928RUTMJmasCLP9Rjkd4oE9UJtdjLA5pbFuOrCI | Last week at Italian Tech Week , Jeff Bezos delivered a masterclass — an eye-opening talk about the extraordinary moment we’re living through. 

Like the internet and the unlock that fibre optics gave the the world 25+ years ago, AI will impact every single company, in every sector. We’re witnessing an industrial revolution in real time! 

We are fortunate to be living through multiple golden ages at the same time— from space travel, to AI, to robotics. 

Most importantly— there has never been a better time to be excited about the future. Especially for entreupreneurs 💪 | 31 | 1 | 0 | 2mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.599Z |  | 2025-10-06T01:35:24.414Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7376619330890833922 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQH_lutMzRaQ/feedshare-shrink_800/B4EZl8BMxnHIAk-/0/1758722314494?e=1766620800&v=beta&t=VdjjbKlBK_XhEYoulZWYlQvIvrpSh9sKT8wDphN4M4c | Shammeera Alles is looking for an AI Product Intern to help us work through our backlog of new customers to onboard. 

At FrontlineIQ, we're building the world's first AI sales coach for in-person sales teams and our team is growing 🚀 

Details below 

McGill Faculty of Engineering, Gina Cody School of Engineering and Computer Science, Polytechnique Montréal | 23 | 1 | 1 | 2mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.600Z |  | 2025-09-24T14:11:39.444Z | https://www.linkedin.com/feed/update/urn:li:activity:7376616041650548736/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7373197255735926784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEKx-GhhvyWQ/feedshare-shrink_800/B4EZlLbx0VGUAg-/0/1757907211780?e=1766620800&v=beta&t=jLIz5qWWum07y-TkW6X1OrAKj0C6lFFdimL2a5D4V2A | Super excited to be at the RetailClub’s AI Deepdive Retreat here in Orange County. 

World-class venue, with Surf City beach as the backdrop for conversations with an amazing community on how AI is transforming retail and sales 🌴 | 129 | 3 | 0 | 2mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.600Z |  | 2025-09-15T03:33:33.148Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7371965390010183681 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEvqu5L7p1ALQ/feedshare-shrink_800/B56Zk57dVnI0Ag-/0/1757613512611?e=1766620800&v=beta&t=llWlFTV54zHRhbQYwd-KonJTXAzdJeVPO32aU4Lrnrw | Next week, I'm attending RetailClub's AI Deepdive Retreat! 

Looking forward to sharing insights on how AI is transforming sales operations for retailers. 

#retailclub #AI # | 42 | 0 | 1 | 2mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.601Z |  | 2025-09-11T17:58:33.472Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7366636778763595777 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEwoQzLjeG-ZQ/feedshare-shrink_1280/B4EZjuHyLjGUAs-/0/1756341675056?e=1766620800&v=beta&t=dsWoHD4uevICPMZGdeK7UKPaZKX_QSGYZ-XzmlGj5os | It's been a very busy summer at FrontlineIQ! One of the major highlights was onboarding the amazing sales teams at Sleep Country Canada. 

I'm humbled by the hard work and determination from everyone involved in launching our latest customer. Adoption and engagement numbers after just a few weeks post-launch are incredible, and we're just getting started! 

Welcome to our new users and a big thank you to our partners 🙏 | 109 | 11 | 1 | 3mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.602Z |  | 2025-08-28T01:04:33.550Z | https://www.linkedin.com/feed/update/urn:li:activity:7366630919496966145/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7348776195217408000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEz0Hmasc37lw/feedshare-shrink_800/B4EZfwUH1nHEAk-/0/1752083496871?e=1766620800&v=beta&t=a2xjoGUo-570wQruDTJN2AbdvcM2C132QlM6u6akt4Q | Excited to have Adam Lane on board as Head of Engineering at FrontlineIQ. It’s already clear he’s going to make a huge impact— big step forward as we keep building and growing. LETS GO! | 57 | 2 | 0 | 4mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.602Z |  | 2025-07-09T18:12:58.599Z | https://www.linkedin.com/feed/update/urn:li:activity:7348770822813106177/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7311124351821500416 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHf_VknX28UIQ/feedshare-shrink_1280/B4DZXTjFN9GkAo-/0/1743010944450?e=1766620800&v=beta&t=-caX4bKkiF8ZCoe260JvoER2kLkTAJ1i5Knmoasgxac | Early adopters make a huge difference in growing companies

Just a few short months after rolling out FrontlineIQ, one of our first partners saw a big drop in their employee turnover rate- saving over $600,000 in re-training costs (more details below)

This is what happens when an innovative, agile partner works with an engaged, forward-thinking client — impact and ROI comes fast. 

We’re just getting started. The opportunity to transform sales enablement for frontline sales teams is massive, and this is only the beginning! 

#salesenablement #frontline #ROI | 41 | 1 | 0 | 8mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.603Z |  | 2025-03-27T20:37:59.596Z | https://www.linkedin.com/feed/update/urn:li:activity:7310717780117401601/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7305337311175532545 | Document |  |  | This is most interesting thing I've read this year - it's the 2025 Moving World Report from my partners at UP.Labs and it gives a unique perspective on just how much of a 'moment' we are having with technology. A few things that really stood out: 

- Data (not money) is the most valuable resource of the future. AI needs to be trained to be useful, and whoever owns the best training data will shape what comes next.

- Humanoids at $1 per hour—what happens to our productivity when labor costs drop to near-zero? 

- A one-person company generating $1 billion? It’s not some far-off idea, it’s actually within reach and an entrepreneur will make it happen soon. 

- The human brain is still 8000x more energy-efficient than Nvidia’s H100 GPU. This isn’t about robots replacing us—it’s about building stuff that works with us, to improves life in ways we’re only beginning to understand.

Conclusion: The biggest opportunities belong to those who see what’s coming and build for it 🚀🚀 | 21 | 0 | 0 | 8mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.604Z |  | 2025-03-11T21:22:21.588Z | https://www.linkedin.com/feed/update/urn:li:activity:7304852656697602049/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7283236406460571648 | Article |  |  | Today, I’m announcing that I’ve transitioned out of my day-to-day role at Salesfloor, the company I co-founded and had the privilege to lead for over a decade. Building Salesfloor from the ground up into the company it is today has been one of the most fulfilling journeys of my career. I remain deeply invested in Salesfloor’s success and am proud to continue contributing as a member of the board.

I’m thrilled to embark on a brand-new journey as the CEO of FrontlineIQ. Our mission is to unlock the power of coaching for frontline sales teams using AI, and I couldn’t be more energized to build something from the ground up once again. There’s something truly special about creating a vision, building a team, and driving innovation that makes a meaningful impact—and I’m excited to do it all over again with FrontlineIQ.

Thank you to everyone who has supported me throughout this journey. I’m forever grateful to the incredible team, customers, and my partner Oscar Sachs who made Salesfloor such a rewarding experience—and I’m eager to channel that energy and experience into building FrontlineIQ into something extraordinary.

I’ll be at NRF in New York next week and look forward to reconnecting with customers and partners, both new and old. If you’d like to connect, feel free to DM me. You can also learn more about FrontlineIQ at https://lnkd.in/eU-dWMBy 

🚀🚀🚀 | 466 | 142 | 5 | 10mo | Post | Ben Rodier | https://www.linkedin.com/in/benrodier | https://linkedin.com/in/benrodier | 2025-12-08T04:59:39.605Z |  | 2025-01-09T21:41:15.289Z | https://www.frontlineiq.ai/ |  | 

---



---

# Ben Rodier
*FrontlineIQ*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [How Ashley Furniture transformed coaching with FrontlineIQ](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq)
- Category: blog

### [Retail Podcast 413: Ben Rodier on Relationship Building with Clienteling](https://www.retaildoc.com/podcast/413-ben-rodier-on-relationship-building-with-clienteling)
*2025-01-01*
- Category: podcast

### [Saving retail with Ben Rodier, COO & Co-Founder @ Salesfloor  Ben Rodier | Business growth consultant and strategic management firm | PNR](https://thepnr.com/what-we%E2%80%99re-learning/saving-retail-ben-rodier-coo-co-founder-salesfloor-ben-rodier/)
*2018-01-05*
- Category: article

### [Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores](https://www.youtube.com/watch?v=YyW0W_RYEak)
*2020-01-27*
- Category: video

### [FrontlineIQ announces $3.3 million funding round](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools)
*2025-10-28*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 14,277 words total*

### How Ashley Furniture transformed coaching with FrontlineIQ
*902 words* | Source: **EXA** | [Link](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq)

How Ashley Furniture transformed coaching with FrontlineIQ

===============

[![Image 1](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77f30e00aafff769da29a_Original%20Logo%20-%20DarkGreen.png)](https://www.frontlineiq.ai/)
*   Product  [Overview ![Image 2](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/product-overview)[AI skill development ![Image 3](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/ai-coaching)[Structured coaching ![Image 4](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/coaching-platform)[Performance intelligence ![Image 5](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/performance-intelligence) 
*   Industries  [Auto ![Image 6](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/automotive)[Finance ![Image 7](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/finance)[Home ![Image 8](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/home-services)[Retail ![Image 9](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/retail)[Telecom ![Image 10](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/telecom)  
*   [FAQ](https://www.frontlineiq.ai/faq)  
*   About  [Company ![Image 11](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/about)[Stories ![Image 12](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/stories)[Contact us ![Image 13](https://cdn.prod.website-files.com/68a77972d60d5d82b7310a3b/68a77973d60d5d82b7310a9b_Frame%20(9).svg)](https://www.frontlineiq.ai/book-a-demo) 
*   [Book a demo](https://www.frontlineiq.ai/book-a-demo)   

[Book a demo](https://www.frontlineiq.ai/book-a-demo)

How Ashley Furniture transformed coaching with FrontlineIQ
----------------------------------------------------------

See how managers drove higher close rates across showrooms

![Image 14](https://cdn.prod.website-files.com/68a77973d60d5d82b7310ada/68d8975943851f40e1103134_Ben.jpg)

Ben Rodier, CEO

2 min read

![Image 15](https://cdn.prod.website-files.com/68a77973d60d5d82b7310ada/68cb0edc92f3c5db8d1e0b56_Ashley-Main%20image.jpg)

IN THIS ARTICLE

[Executive summary](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-1)[Client background](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-2)[The challenge](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-3)[The solution](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-4)[Implementation](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-5)[Results](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-6)[Conclusion](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq#Part-7)

### Executive summary

Ashley Furniture needed a way to scale consistent sales coaching across hundreds of associates and managers. By adopting FrontlineIQ, they replaced guesswork with AI-powered coaching that delivered measurable results. Within months, Ashley saw **double-digit sales growth and higher employee retention**.

For a video overview, visit [https://www.youtube.com/watch?v=3EvaVBIe5Ic](https://www.youtube.com/watch?v=3EvaVBIe5Ic).

### Client background

Ashley Furniture is one of the largest home furnishings retailers in North America, with a mission to deliver quality products and exceptional customer experiences. Their stores rely on large, distributed sales teams where performance depends on consistent coaching and engagement.

‍

As Kevin Hook, President of The Dufresne Group’s Ashley Stores, explained:

> We’re building on a strong culture of coaching that keeps our teams engaged and consistently improving.

### The challenge

Ashley’s leadership recognized that traditional sales training and coaching methods were falling short. Managers were stretched thin, and coaching often lacked structure or consistency. This created gaps in performance and limited the ability to scale best practices across locations.

*   **Inconsistent 

*[... truncated, 9,801 more characters]*

---

### Retail Podcast 413: Ben Rodier on Relationship Building with Clienteling
*3,611 words* | Source: **EXA** | [Link](https://www.retaildoc.com/podcast/413-ben-rodier-on-relationship-building-with-clienteling)

**Bob:**How are you doing, Ben?

**Ben:**I’m good Bob, how are you?

**Bob:**Excellent. Well, you know, we are recording this in May and thank god it's a different month than when I was recording these in March two months ago, I think it was like,“The whole world is crashing and Tom Hanks and his wife have Covid. Oh my god.”

And you know, we're starting to see some retailers are closing down and reorganizing by Chapter 11. I think we're going to come out of it stronger. And the reason, listeners, that I was drawn to want to talk to Ben is because I met Ben on the floor of [NRF](https://nrf.com/) through the Retail Store Tours this last January.

And you had a pretty significant achievement that was announced there, Ben. Can you tell us about that?

**Ben:**Yeah, for sure. That was a really fun event and I'm really glad we got to do that. And it led to this, so happy to be here. The NRF show that happened in January kicked off with a big bang for [Salesfloor](https://salesfloor.net/), because we were actually awarded best omnichannel customer experience solution in 2020, at the award ceremony that kicked off the NRF.

It was called the Vendors in Partnership, the VIP awards, so it was really thrilling, you know, to obviously be in New York for NRF, but also to kick the whole experience off at Gotham Hall, just a beautiful venue, jumping on stage with, you know, a big company like Intel presenting the award.

So, it really put the spotlight on the company. And, definitely, you know, paid homage to a lot of the effort and hard work that our entire team has been doing for the past few years with our retailers.

**Bob:**Yeah, it's great. So, most people don't know necessarily what Salesfloor is, and it's easy to say the wrong name of your company, which I am afraid of doing.

So I have to make sure, and look at my notes. It's Salesfloor, like you're out on the sales floor, but tell us what does it do? And, briefly, not a big sales pitch, but like you tell somebody over Starbucks or something and how does it work?

**Ben:**No problem. You know, it's funny you mentioned the name confusion because I joke with people often that we do have a jar in the office and every time you mistake Salesfloor for sales force, you’ve got to put five bucks in the jar for our Friday beer fund.

But Salesfloor is an SAS solution sold to retailers with the main focus of empowering store associates to essentially elevate the level of their role and their impact on the business by giving them digital tools to serve and sell to customers. So, a lot of people call what we do clienteling or assisted selling.

But the way I describe it is that Salesfloor is really a platform, a platform of many features and many functionalities that are all brought together in one convenient app so that the store associate can communicate by email, text message, live chat. They can look up inventory levels. They can sell to customers who choose to shop online.

They can sell to customers who choose to shop in store, and it's all being done by one solution provider. One piece of training that an associate needs to learn, which is very different than a lot of, you know what we've come to get used to these days, which is I have one app for clienteling, one app for POS, I have one app for inventory lookup.

And I remember reading an article recently about a store associate who worked at, I think Old Navy or the Gap. And she had to learn like nine different technology apps to do her job. Which you know, from a Salesfloor perspective seems crazy because what we've been focused on for the last six years is building a solution that has a platform, has it all in one convenient place for store associates to use.

**Bob:**Yeah, that's the key, I think. And ultimately, you know, we kind of call it virtual selling, but there's so many different ways now to engage a customer at different points and to keep them.

And certainly, in a time like Covid-19 when so many apparel retailers have boatloads of merchandise they're going to need to get rid of, it would seem like the more that your associates could know their customers better, the more they could end up selling it and bundling it and saying, you know, Why don't you get a bunch of these items? It certainly pays for itself, I would think. Can you give an example of how somebody might do this? How might it work in one of your stores?

**Ben:**So, when you log into the application in the morning, it will tell you who you should reach out to. That's one of the baseline features of clienteling.

We automate tasks on a daily basis so that if you're, let's say, Bob who works at Saks Fifth Avenue, you know who to reach out to, and when you reach out to those customers, you're able to know what they purchased in the past and what you should recommend for future consideration. When the customer receives the email, they can click the item that you've selected, that you've recommended to them, and a nice branded message that look

*[... truncated, 14,549 more characters]*

---

### Saving retail with Ben Rodier, COO & Co-Founder @ Salesfloor  Ben Rodier | Business growth consultant and strategic management firm | PNR
*364 words* | Source: **EXA** | [Link](https://thepnr.com/what-we%E2%80%99re-learning/saving-retail-ben-rodier-coo-co-founder-salesfloor-ben-rodier/)

![Image 1: ben-Pic](https://thepnr.com/wp-content/uploads/2021/11/ben-Pic.jpg)

Saving retail with Ben Rodier, COO & Co-Founder @ Salesfloor Ben Rodier
-----------------------------------------------------------------------

January 5, 2018

On this week’s show, we spoke with [Ben Rodier](mailto:https://www.linkedin.com/in/benrodier/), COO @ [Salesfloor](http://salesfloor.net/). Ben is the Co-Founder of Salesfloor, a retail technology company. Thousands of store associates from some of the biggest names in retail use Salesfloor to create their own version of their retailer’s e-commerce site, offering customers a new and personalized way to shop online.

Before launching Salesfloor, Ben was Vice President of Shopper Marketing and Digital Media at Mediative (formerly Ad Splash Media, acquired by Yellow Media in 2010). He was responsible for the growth of the company’s North American portfolio of retail media partnerships, with brands including Best Buy, Toys”R”Us and Walmart. Prior to Mediative, Ben was responsible for business development and digital media at Canwest Media and Global Television Network.

Ben’s accomplishments in marketing and advertising include a Shopper Innovation Award from Strategy Magazine and he was featured in Marketing Magazines Top 30 Marketing Professionals. Ben holds an MBA from Queen’s University, and a Bachelor of Commerce degree in Marketing from Concordia’s John Molson School of Business.

We had a wide-ranging conversation on several topics:

*   His successful exit from AdSplash Media and how that led him to co-found Salesfloor
*   The challenges of the retail industry and how Salesfloor is helping retailers solve a crucial problem
*   How the team at Salesfloor manages to keep the product vision intact
*   The team’s six month planning cycle
*   Ben’s focus on the innovating around the store experience
*   The key technology trends he’s keeping his eye on

I’ve known Ben for a few years during his time at AdSplash Media and he is a very talented individual. I always learn a ton when I talk to him. I hope that you enjoy the conversation!

Let us know what you think. What types of guests would like to see on the show? What topics interest you the most? Send me your thoughts at [nectar@thepnr.com](mailto:nectar@thepnr.com)

Subscribe to iTunes [here](https://itunes.apple.com/ca/podcast/point-of-no-return-podcast/id1160536476?mt=2) | Subscribe to Google Play[here](https://play.google.com/music/listen?u=0#/ps/Iefjqhwcdz5o6v6flvj7bu7o5o4)

### Subscribe to our newsletter!

A weekly round up of our favorite articles, research and insights about corporate strategy.

---

### Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores
*1,493 words* | Source: **EXA** | [Link](https://www.youtube.com/watch?v=YyW0W_RYEak)

Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores - YouTube

===============

 Back [![Image 1](https://www.youtube.com/watch?v=YyW0W_RYEak)](https://www.youtube.com/ "YouTube Home")

Skip navigation

 Search 

 Search with your voice 

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

[Sign in](https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253DYyW0W_RYEak&hl=en&ec=65620)

[![Image 2](https://www.youtube.com/watch?v=YyW0W_RYEak)](https://www.youtube.com/ "YouTube Home")

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

[Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores](https://www.youtube.com/watch?v=YyW0W_RYEak)

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

Tap to unmute

2x

[![Image 3](https://www.youtube.com/watch?v=YyW0W_RYEak)](https://www.youtube.com/watch?v=YyW0W_RYEak)

Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores
---------------------------------------------------------------------------------------

The Retail Doctor 478 views 5 years ago

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

Search

Copy link

Info

Shopping

![Image 4](https://www.youtube.com/watch?v=YyW0W_RYEak)

[![Image 5](https://www.youtube.com/watch?v=YyW0W_RYEak)](https://www.youtube.com/watch?v=YyW0W_RYEak)

If playback doesn't begin shortly, try restarting your device.

•

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

Cancel Confirm

Video unavailable

[](https://www.youtube.com/watch?v=YyW0W_RYEak)

Share

[](https://www.youtube.com/watch?v=YyW0W_RYEak "Share link")- [x] Include playlist 

An error occurred while retrieving sharing information. Please try again later.

![Image 6](https://www.youtube.com/watch?v=YyW0W_RYEak)

0:00

[](https://www.youtube.com/watch?v=YyW0W_RYEak)[](https://www.youtube.com/watch?v=fOwzKtGosSU "Next (SHIFT+n)")

0:00 / 7:32

Live

•Watch full video

•

•

[7:48 I Married An Irish Guy and Chinese Is Too Hard For Him To Learn | Dawn Wong Dawn Wong 9.5M views • 4 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=_MJERTr8gfU)[18:28 10 Things You SHOULD Be Buying at Costco in December 2025 The Deal Guy 597K views • 12 hours ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=yyjKADNZAJE)[6:30 This Young Boy Sings One of The HARDEST Songs of All Time.. What A COVER! 😮Top Talent 6.7M views • 2 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=JDjgvIA0ZEg)[24:12 Visual Merchandising 101: Where to Start (Even If You’re Not a Visual Person)Rooted in Retail Podcast 2.1K views • 5 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=fOwzKtGosSU)[5:08 Haircut - SNL Saturday Night Live 2.9M views • 3 weeks ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=uFrNdPHL52c)[16:08 5 Tiny Habits That Make You Instantly Magnetic Kim Foster, M.D.748K views • 3 weeks ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=XvBl4ikQQiM)[34:08 What Every Body Fat % Actually Looks Like (50% to 5%)Jeff Nippard 8.2M views • 4 weeks ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=5K9QhkPww44)[16:04 Mr Bean does 'Blind Date' | Comic Relief Comic Relief 22M views • 16 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=qLNhVC296YI)[7:57 She’s 12. She Sings Aretha Franklin… Until Simon TELLS Her to Do It Acapella! 😳Top Talent 3.2M views • 1 month ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=HLxDp5rZmIs)[14:24 The Foot Traffic Formula For Retailers WhizBang! Retail Training 12K views • 2 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=RYQo-oHdD-Y)[8:07 How to Greet Customers in Retail - Never Say This!RETAILMavens 318K views • 4 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=U8vwLb9Z_LA)[4:46 Prince Auditions - SNL Saturday Night Live 7.8M views • 4 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=ZsMuKSpQfIY)

Ben Rodier with Salesfloor Co-founder shows how they help retailers sell more in stores
=======================================================================================

[![Image 7](https://yt3.ggpht.com/nosXT5qePKwEpnTwwDuMMrzEOt5iL6PGwVJ73LZIBmC7_uGMHx-dTjYK621bHi0YEx6BSqQ2hcY=s48-c-k-c0x00ffffff-no-rj)](https://www.youtube.com/@TheRetailDoctor)

[The Retail Doctor](https://www.youtube.com/@TheRetailDoctor)

 The Retail Doctor 

7.89K subscribers

Subscribe

Subscribed

2

Share

Download

 Download 

478 views 5 years ago[#retailer](

*[... truncated, 16,755 more characters]*

---

### FrontlineIQ announces $3.3 million funding round
*967 words* | Source: **EXA** | [Link](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools)

IN THIS ARTICLE

[FrontlineIQ emerges from stealth with $3.3M in funding to lead a new era of AI coaching for in-person sales](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-1)[A new category: AI coaching for the frontline](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-2)[Proven results with global brands](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-3)[Fueling growth with new capital](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-4)[About FrontlineIQ Inc.](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-5)[](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-6)[](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools#Part-7)

### FrontlineIQ emerges from stealth with $3.3M in funding to lead a new era of AI coaching for in-person sales

_The company is bringing AI sales coaching to millions of salespeople who sell face-to-face in stores, branches, showrooms, counters and dealerships across North America._

‍

**Montreal, Canada – October 28, 2025** — [FrontlineIQ](http://www.frontlineiq.ai/), an AI sales coaching platform, today announced its public launch alongside an oversubscribed $3.3 million seed round. AQC Capital led the round, which also included participation from strategic investors across retail, automotive, and financial services.

**‍**

In less than a year, FrontlineIQ has proven that its AI sales coaching delivers rapid ROI for leading brands including Ashley HomeStore, Sleep Country, Dufresne Furniture & Appliances, Hyundai, and Porsche. In 2024, Ashley piloted FrontlineIQ and, after strong adoption and engagement, expanded the rollout nationally—driving double-digit sales growth and higher employee retention. Building on that success, additional brands have signed on for 2025 rollouts, and demand has grown to the point that FrontlineIQ now maintains a customer waitlist extending into 2026.

FrontlineIQ is led by CEO [Ben Rodier](http://www.linkedin.com/in/benrodier), a repeat entrepreneur with more than 15 years of experience building sales technology and software companies. As the previous Co-Founder of Salesfloor, Rodier helped redefine omnichannel selling and enabled global brands to empower their sales teams. He spent his career at the intersection of sales enablement and enterprise technology, and has assembled an experienced team of experts with track records of taking companies from zero to exit. Together, they’re transforming frontline sales with AI.

‍

> “AI has already revolutionized digital sales, but millions of people selling in-person or on showroom floors have been left behind,” said Rodier.

‍

> “We’re building the first AI coach for in-person sales teams; designed to scale coaching across millions of sellers and give every manager the support they need to succeed. This funding allows us to accelerate delivery and bring our solution to more industries where human-to-human sales still matter most.”

### A new category: AI coaching for the frontline

While most AI sales tools were built for office-based Business-to-Business (B2B) environments reliant on call transcripts or email, FrontlineIQ was purpose-built for Business-to-Consumer (B2C) and field sales teams. The platform’s proprietary AI Sales Coach, “Theo” unifies a mobile app for sellers and intuitive performance dashboards for managers, into a comprehensive operating system for sales coaching. Theo delivers personalized goal recommendations and instant feedback to sales teams, while providing managers with real-time AI insights that drive measurable revenue growth.

‍

This approach directly tackles what Rodier calls the “coaching crisis”—too many salespeople per manager, inconsistent coaching practices, and an overreliance on outdated training methods leaving employees underdeveloped, resulting in underperformance that drives unwanted employee turnover and lost sales.

‍

FrontlineIQ makes every sales manager a super-coach. This approach ensures every seller on the team – not just the top performers – receive consistent, data-driven feedback tied directly to earnings and performance outcomes.

### Proven results with global brands

FrontlineIQ partners with leading enterprise customers with some of the largest sales teams in the world. After launching to hundreds of sales consultants and managers, the company’s early customers achieved up to 86% weekly active usage and 11% increase in sales per customer. On average, sales consultants that hit their goals in FrontlineIQ, improved performance metrics by 250% vs their peer-control group.

‍

_“FrontineIQ is now part of our coaching DNA,” said Kevin Hook, President

*[... truncated, 2,434 more characters]*

---

### FrontlineIQ raises $3.3-million seed to “gamify” sales jobs with AI coaching | BetaKit
*1,384 words* | Source: **GOOGLE** | [Link](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/)

FrontlineIQ raises $3.3-million seed to “gamify” sales jobs with AI coaching | BetaKit

===============

Read [BetaKit Most Ambitious](https://bit.ly/4k6pCHn): Telling the story of what’s possible.

✕

[![Image 1: BetaKit - Canadian Startup News & Tech Innovation](https://betakit.com/wp-content/uploads/2024/01/BetaKit_Logo_White_250px.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [About](https://betakit.com/about-us/)
*   [Advertise](https://betakit.com/advertise/)
*   [Members](https://betakit.com/innovation-leaders/)
*   [Contact](https://betakit.com/about-us/#contact)

*   [](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/#)
    *   [](https://www.linkedin.com/company/BetaKit)
    *   [](https://twitter.com/BetaKit)
    *   [](https://www.youtube.com/user/Betakit)
    *   [](https://www.facebook.com/BetaKit)

[![Image 2: BetaKit - Canadian Tech & Startup News](https://betakitdev.trypl.com/wp-content/uploads/2025/04/betakit-logo-OG.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [News](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/#)

    *   [Latest News](https://betakit.com/#Latest)
    *   [By Topics](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/#)

        *   [Funding](https://betakit.com/tag/funding)
        *   [Acquisitions](https://betakit.com/tag/acquisitions)
        *   [Layoffs](https://betakit.com/tag/layoffs/)
        *   [VC](https://betakit.com/tag/vc/)
        *   [Events](https://betakit.com/tag/events)
        *   [Markets](https://betakit.com/tag/markets/)
        *   [Reports](https://betakit.com/tag/reports)
        *   [Impact](https://betakit.com/tag/impact)

    *   [By Verticals](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/#)

        *   [AI](https://betakit.com/tag/ai)
        *   [FinTech](https://betakit.com/tag/fintech)
        *   [SaaS](https://betakit.com/tag/saas)
        *   [Retail](https://betakit.com/tag/retail)
        *   [Healthtech](https://betakit.com/tag/healthtech)
        *   [Cleantech](https://betakit.com/tag/cleantech)
        *   [Deep Tech](https://betakit.com/tag/deep-tech/)
        *   [Defence Tech](https://betakit.com/tag/defence-tech/)

    *   [By Regions](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/#)

        *   [Toronto](https://betakit.com/tag/toronto)
        *   [Montréal](https://betakit.com/tag/montreal)
        *   [Vancouver](https://betakit.com/tag/vancouver)
        *   [Waterloo Region](https://betakit.com/tag/kitchener-waterloo)
        *   [Ottawa](https://betakit.com/tag/ottawa)
        *   [Calgary](https://betakit.com/tag/calgary)
        *   [Prairies](https://betakit.com/tag/prairies)
        *   [Atlantic Canada](https://betakit.com/tag/atlantic-canada/)

*   [Podcast](https://betakit.com/category/podcasts)
*   [Newsletter](https://betakit.com/category/newsletters)
*   [Quiz](https://betakit.com/category/quiz/)
*   [Jobs](https://betakit.com/tag/jobs/)

FrontlineIQ raises $3.3-million seed to “gamify” sales jobs with AI coaching
============================================================================

 By [Madison McLauchlan](https://betakit.com/author/madison-mclauchlan/ "Posts by Madison McLauchlan")November 7, 2025

[Email](mailto:?subject=FrontlineIQ%20raises%20$3.3-million%20seed%20to%20%E2%80%9Cgamify%E2%80%9D%20sales%20jobs%20with%20AI%20coaching&body=https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/)[Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/&title=FrontlineIQ+raises+%243.3-million+seed+to+%E2%80%9Cgamify%E2%80%9D+sales+jobs+with+AI+coaching&source=BetaKit)[Share on X](https://twitter.com/intent/tweet?original_referer=https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/&text=FrontlineIQ+raises+%243.3-million+seed+to+%E2%80%9Cgamify%E2%80%9D+sales+jobs+with+AI+coaching&tw_p=tweetbutton&url=https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/&via=BetaKit)[Share on Reddit](http://www.reddit.com/submit?url=https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/&title=FrontlineIQ+raises+%243.3-million+seed+to+%E2%80%9Cgamify%E2%80%9D+sales+jobs+with+AI+coaching)[Share on BlueSky](https://bsky.app/intent/compose?text=FrontlineIQ+raises+%243.3-million+seed+to+%E2%80%9Cgamify%E2%80%9D+sales+jobs+with+AI+coaching%20https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/)

![Image 3: Sales laptop | BetaKit](https://cdn.betakit.com/wp-content/uploads/2025/11/headway-5QgIuuBxKwM-unsplash-770x513.jpg)

Platform aims to take “ickiness

*[... truncated, 17,134 more characters]*

---

### FrontlineIQ Emerges from Stealth with $3.3M in Funding to Lead a New Era of AI Coaching for In-Person Sales
*4,434 words* | Source: **GOOGLE** | [Link](https://finance.yahoo.com/news/frontlineiq-emerges-stealth-3-3m-110000104.html)

FrontlineIQ Emerges from Stealth with $3.3M in Funding to Lead a New Era of AI Coaching for In-Person Sales

===============

Oops, something went wrong

[Skip to navigation](https://finance.yahoo.com/news/frontlineiq-emerges-stealth-3-3m-110000104.html#ybar-navigation)[Skip to main content](https://finance.yahoo.com/news/frontlineiq-emerges-stealth-3-3m-110000104.html#nimbus-app)[Skip to right column](https://finance.yahoo.com/news/frontlineiq-emerges-stealth-3-3m-110000104.html#right-rail)

### [News](https://www.yahoo.com/)

*   [Today's news](https://www.yahoo.com/news/)
*   [US](https://www.yahoo.com/news/us/)
*   [Politics](https://www.yahoo.com/news/politics/)
*   [2025 Election](https://www.yahoo.com/events/elections/)
*   [World](https://www.yahoo.com/news/world/)
*   [Weather](https://www.yahoo.com/news/weather/)
*   [Climate change](https://www.yahoo.com/issues/climate-change/)
*   [Health](https://health.yahoo.com/)

    *   [Wellness](https://health.yahoo.com/wellness/)

        *   [Mental health](https://health.yahoo.com/wellness/mental-health/)
        *   [Sexual health](https://health.yahoo.com/wellness/sexual-health/)
        *   [Dermatology](https://health.yahoo.com/wellness/dermatology/)
        *   [Oral health](https://health.yahoo.com/wellness/oral-health/)
        *   [Hair loss](https://health.yahoo.com/wellness/hair-loss/)
        *   [Foot health](https://health.yahoo.com/wellness/foot-health/)

    *   [Nutrition](https://health.yahoo.com/nutrition/)

        *   [Healthy eating](https://health.yahoo.com/nutrition/healthy-eating/)
        *   [Meal delivery](https://health.yahoo.com/nutrition/meal-delivery/)
        *   [Weight loss](https://health.yahoo.com/nutrition/weight-loss/)
        *   [Vitamins and supplements](https://health.yahoo.com/nutrition/vitamins-supplements/)

    *   [Fitness](https://health.yahoo.com/fitness/)

        *   [Equipment](https://health.yahoo.com/fitness/equipment/)
        *   [Exercise](https://health.yahoo.com/fitness/exercise/)

    *   [Women's health](https://health.yahoo.com/womens-health/)
    *   [Sleep](https://health.yahoo.com/sleep/)
    *   [Healthy aging](https://health.yahoo.com/healthy-aging/)

        *   [Hearing](https://health.yahoo.com/healthy-aging/hearing/)
        *   [Mobility](https://health.yahoo.com/healthy-aging/mobility/)

*   [Science](https://www.yahoo.com/news/science/)
*   [Originals](https://www.yahoo.com/guides/originals/)

    *   [The 360](https://www.yahoo.com/events/elections/)

*   [Newsletters](https://news.yahoo.com/newsletters/)
*   [Games](https://www.yahoo.com/games)

### [Life](https://www.yahoo.com/lifestyle/)

*   [Health](https://health.yahoo.com/)

    *   [Wellness](https://health.yahoo.com/wellness/)

        *   [Nutrition](https://health.yahoo.com/wellness/nutrition/)
        *   [Fitness](https://health.yahoo.com/wellness/fitness/)
        *   [Healthy aging](https://health.yahoo.com/wellness/healthy-aging/)
        *   [Mental health](https://health.yahoo.com/wellness/mental-health/)
        *   [Sleep](https://health.yahoo.com/wellness/sleep/)

    *   [Your body](https://health.yahoo.com/your-body/)

        *   [Dermatology](https://health.yahoo.com/your-body/dermatology/)
        *   [Children's health](https://health.yahoo.com/your-body/childrens-health/)
        *   [Foot health](https://health.yahoo.com/your-body/foot-health/)
        *   [Hair loss](https://health.yahoo.com/your-body/hair-loss/)
        *   [Hearing](https://health.yahoo.com/your-body/hearing/)
        *   [Oral health](https://health.yahoo.com/your-body/oral-health/)
        *   [Sexual health](https://health.yahoo.com/your-body/sexual-health/)
        *   [Women's health](https://health.yahoo.com/your-body/womens-health/)

    *   [Conditions](https://health.yahoo.com/conditions/)

        *   [Cardiovascular health](https://health.yahoo.com/conditions/cardiovascular-health/)
        *   [Digestive health](https://health.yahoo.com/conditions/digestive-health/)
        *   [Endocrine system](https://health.yahoo.com/conditions/endocrine-system/)

*   [Parenting](https://www.yahoo.com/lifestyle/family-relationships/)

    *   [Family health](https://www.yahoo.com/lifestyle/family-relationships/)
    *   [So mini ways](https://www.yahoo.com/guides/so-mini-ways/)

*   [Style and beauty](https://www.yahoo.com/lifestyle/style-beauty/)

    *   [It Figures](https://www.yahoo.com/guides/it-figures/)
    *   [Unapologetically](https://www.yahoo.com/guides/unapologetically/)

*   [Horoscopes](https://www.yahoo.com/lifestyle/horoscope/)
*   [Shopping](https://shopping.yahoo.com/)

    *   [Style](https://shopping.yahoo.com/style/)

        *   [Accessories](https://shopping.yahoo.com/style/accessories/)
        *   [Clothing](https://shopping.yahoo.com/style/clothing/)
        *   [Luggage](https://shopping.yahoo.com/style/luggage/)
        *   [Shoes](https://shopping.yahoo.com/style/shoes/)

    *   [Beauty](https://shopp

*[... truncated, 77,053 more characters]*

---

### Stoneybrook Elevators - Stock Quotes
*276 words* | Source: **GOOGLE** | [Link](https://www.stoneybrookelevators.ca/markets/stocks.php?article=gnwcq-2025-8-21-meet-the-builders-uplabs-appoints-elite-founders-to-lead-its-next-wave-of-enterprise-ai-startups)

Stoneybrook Elevators - Stock Quotes

===============

[Cash Bids](https://www.stoneybrookelevators.ca/cashbids "Cash Bids")

[Cash Bids Table](https://www.stoneybrookelevators.ca/cashbids "Cash Bids Table")[ABOUT US](https://www.stoneybrookelevators.ca/aboutus "ABOUT US")

[Location](https://www.stoneybrookelevators.ca/locations "Location")

[Contact Us](https://www.stoneybrookelevators.ca/pages/contact.php "Contact Us")

[About Us](https://www.stoneybrookelevators.ca/aboutus "About Us")[Market Data](https://www.stoneybrookelevators.ca/markets/stocks.php?article=gnwcq-2025-8-21-meet-the-builders-uplabs-appoints-elite-founders-to-lead-its-next-wave-of-enterprise-ai-startups# "Market Data")

[Market Overview](https://www.stoneybrookelevators.ca/markets/fixed.php?page=overview "Market Overview")

[Futures](https://www.stoneybrookelevators.ca/pages/custom.php?id=58681 "Futures")

[Options](https://www.stoneybrookelevators.ca/pages/custom.php?id=58690 "Options")

[Charts](https://www.stoneybrookelevators.ca/markets/chart.php "Charts")

[Tech. Charts](https://www.stoneybrookelevators.ca/markets/custchart.php "Tech. Charts")

[Spread Charts](https://www.stoneybrookelevators.ca/markets/spreadchart.php "Spread Charts")

[Market Heat Map](https://www.stoneybrookelevators.ca/markets/heatmap.php "Market Heat Map")

[Stocks](https://www.stoneybrookelevators.ca/markets/stocks.php "Stocks")[Newswire](https://www.stoneybrookelevators.ca/markets/news.php "Newswire")

[Newswire](https://www.stoneybrookelevators.ca/markets/news.php "Newswire")

[AgWeb](https://www.stoneybrookelevators.ca/markets/news.php?feed=AGWEB "AgWeb")

[Barchart.com](https://www.stoneybrookelevators.ca/markets/news.php?feed=BC "Barchart.com")

[USDA Reports](https://www.stoneybrookelevators.ca/usda/usdarpts.php "USDA Reports")[Commentary](https://www.stoneybrookelevators.ca/markets/commentary.php "Commentary")

[Ag Market Commentary](https://www.stoneybrookelevators.ca/markets/news.php?feed=BRUG "Ag Market Commentary")

[InsideFutures](https://www.stoneybrookelevators.ca/markets/news.php?feed=IF "InsideFutures")[Weather](https://www.stoneybrookelevators.ca/pages/custom.php?id=58694 "Weather")

[Weather Center](https://www.stoneybrookelevators.ca/pages/weather-new.php "Weather Center")[Resources](https://www.stoneybrookelevators.ca/markets/stocks.php?article=gnwcq-2025-8-21-meet-the-builders-uplabs-appoints-elite-founders-to-lead-its-next-wave-of-enterprise-ai-startups# "Resources")

[Trade Calendar](https://www.stoneybrookelevators.ca/markets/calendar.php "Trade Calendar")

[Futures 101](https://www.stoneybrookelevators.ca/pages/custom.php?id=58680 "Futures 101")

[Commodity Symbols](https://www.stoneybrookelevators.ca/pages/custom.php?id=58679 "Commodity Symbols")

[Home](https://www.stoneybrookelevators.ca/)

[Contact Us](https://www.stoneybrookelevators.ca/pages/contact.php)

[Cash Bids](https://www.stoneybrookelevators.ca/cashbids)

[Pioneer Yield Data](https://www.pioneer.com/yield/)

[Profit Calculator](http://s3.amazonaws.com/media.agricharts.com/sites/2434/Calculators/profitcalculator-1.xls)

[Target Contract Request](https://www.stoneybrookelevators.ca/targetcontractrequest)

 Drying Charts 

>Wheat Drying Chart 

[>Corn Drying Chart](https://s3.amazonaws.com/media.agricharts.com/sites/2434/Moisture%20Chart%202025.pdf)

>Soybean Drying Chart 

[Profit Talk Nov/Dec 2025](https://www.mywhitecommercial.com/fc/2025/pt_novdec25.pdf)Stock Quotes
============

Get quotes for stocks: 

To display multiple quotes,enter symbols with a comma separating each symbol (e.g. F,MSFT,GOOG)

[Home](https://www.stoneybrookelevators.ca/) | [Contact Us](https://www.stoneybrookelevators.ca/pages/contact.php)

© 2025 Barchart.com, Inc. All [market data](https://www.barchart.com/solutions "Market data provider site") is hosted and powered by [Barchart](https://www.barchart.com/cmdty "Hosting provider").

Information presented is provided 'as-is' and solely for informational purposes, not for trading purposes or advice, and is delayed. No representations are made by Barchart as to its informational accuracy or completeness.

*   [Terms of Use](https://www.barchart.com/terms "Terms of Use")
*   [Privacy Policy](https://www.barchart.com/terms#privacy-policy "Privacy Policy")
*   [Do Not Sell My Personal Information](https://www.barchart.com/terms#do-not-sell "Do not sell my personal information")
*   [Exchange Delays](https://www.barchart.com/terms#user-agreement "Exchange Delays")

By using this site, you agree to the storage of cookies on your devices for enhanced navigation, site analysis, and Barchart's marketing. Data sharing with social media platforms might occur based on the privacy choices you make on those platforms. For specifics, see our our [Privacy Policy](https://www.barchart.com/terms#privacy-policy).

Accept

---

### FrontlineIQ Emerges from Stealth with $3.3M in Funding to Lead a New Era of AI Coaching for In-Person Sales
*820 words* | Source: **GOOGLE** | [Link](https://www.theglobeandmail.com/investing/markets/markets-news/GlobeNewswire/35723545/frontlineiq-emerges-from-stealth-with-3-3m-in-funding-to-lead-a-new-era-of-ai-coaching-for-in-person-sales/)

[Skip to main content](https://www.theglobeandmail.com/investing/markets/markets-news/GlobeNewswire/35723545/frontlineiq-emerges-from-stealth-with-3-3m-in-funding-to-lead-a-new-era-of-ai-coaching-for-in-person-sales/#)

Montreal, Canada, Oct. 28, 2025 (GLOBE NEWSWIRE) -- FrontlineIQ, an AI sales coaching platform, today announced its public launch alongside an oversubscribed $3.3 million seed round. AQC Capital led the round, which also included participation from strategic investors across retail, automotive, and financial services.

In less than a year, FrontlineIQ has proven that its AI sales coaching delivers rapid ROI for leading brands including Ashley HomeStore, Sleep Country, Dufresne Furniture & Appliances, Hyundai, and Porsche. In 2024, Ashley piloted FrontlineIQ and, after strong adoption and engagement, expanded the rollout nationally—driving double-digit sales growth and higher employee retention. Building on that success, additional brands have signed on for 2025 rollouts, and demand has grown to the point that FrontlineIQ now maintains a customer waitlist extending into 2026.

FrontlineIQ is led by CEO Ben Rodier, a repeat entrepreneur with more than 15 years of experience building sales technology and software companies. As the previous Co-Founder of Salesfloor, Rodier helped redefine omnichannel selling and enabled global brands to empower their sales teams. He spent his career at the intersection of sales enablement and enterprise technology, and has assembled an experienced team of experts with track records of taking companies from zero to exit. Together, they’re transforming frontline sales with AI.

_“AI has already revolutionized digital sales, but millions of people selling in-person or on showroom floors have been left behind,” said Rodier. “We’re building the first AI coach for in-person sales teams—designed to scale coaching across millions of sellers and give every manager the support they need to succeed. This funding allows us to accelerate delivery and bring our solution to more industries where human-to-human sales still matter most.”_

**A New Category: AI Coaching for the Frontline**

While most AI sales tools were built for office-based Business-to-Business (B2B) environments reliant on call transcripts or email, FrontlineIQ was purpose-built for Business-to-Consumer (B2C) and field sales teams. The platform’s proprietary AI Sales Coach, “Theo” unifies a mobile app for sellers and intuitive performance dashboards for managers, into a comprehensive operating system for sales coaching. Theo delivers personalized goal recommendations and instant feedback to sales teams, while providing managers with real-time AI insights that drive measurable revenue growth.

This approach directly tackles what Rodier calls the “coaching crisis”—too many salespeople per manager, inconsistent coaching practices, and an overreliance on outdated training methods leaving employees underdeveloped, resulting in underperformance that drives avoidable employee turnover and lost sales.

FrontlineIQ makes every sales manager a super-coach. This approach ensures every seller on the team – not just the top performers – receive consistent, data-driven feedback tied directly to earnings and performance outcomes.

**Proven Results with Global Brands**

FrontlineIQ partners with leading enterprise customers with some of the largest sales teams in the world. After launching to hundreds of sales consultants and managers, the company’s early customers achieved up to 86% weekly active usage and 11% increase in sales per customer. On average, sales consultants that hit their goals in FrontlineIQ, improved performance metrics by 250% vs their peer-control group.

_“FrontineIQ is now part of our coaching DNA,” said Kevin Hook, President of The Dufresne Group’s Ashley Stores. “With FrontlineIQ’s real-time insights and coaching tools, our leaders can change the story while it’s still being written. We're not just hitting performance goals—we’re building on a strong culture of coaching that keeps our teams engaged and consistently improving.”_

Further, the platform helps leaders refine an organization’s sales culture by empowering sales associates to actively participate in their professional development journey. Associates can instantly see their goals and understand the specific behaviors that will drive desired results and increase their earning power.

**Fueling Growth with New Capital**

With $3.3 million in seed funding, FrontlineIQ will accelerate its engineering velocity, ship key features designed from customer feedback that further strengthens product-market fit, and build out sales and marketing capacity to scale adoption across North America. The company is hiring across sales, marketing, engineering, and customer success roles in both Canada and the U.S., with an eye on rapid but disciplined expansion.

###

**About FrontlineIQ Inc.**

FrontlineIQ is redefining modern sales by tackling one of its toughes

*[... truncated, 1,226 more characters]*

---

### Just a moment...
*26 words* | Source: **GOOGLE** | [Link](https://rocketreach.co/steven-dahan-email_1305769)

![Image 1: Icon for rocketreach.co](https://rocketreach.co/favicon.ico)rocketreach.co
-------------------------------------------------------------------------------------

Verify you are human by completing the action below.

rocketreach.co needs to review the security of your connection before proceeding.

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[FrontlineIQ announces $3.3 million funding round](https://www.frontlineiq.ai/blog-posts/frontlineiq-featured-in-techcrunch-list-of-ai-driven-sales-tools)**
  - Source: frontlineiq.ai
  - *Oct 28, 2025 ... FrontlineIQ is led by CEO Ben Rodier, a repeat entrepreneur with ... PODCAST: Ben Rodier on Minding Your Business with Katherine Kora...*

- **[FrontlineIQ raises $3.3-million seed to “gamify” sales jobs with AI ...](https://betakit.com/frontlineiq-raises-3-3-million-seed-to-gamify-sales-jobs-with-ai-coaching/)**
  - Source: betakit.com
  - *Nov 7, 2025 ... Podcast · Newsletter · Quiz · Jobs. FrontlineIQ raises $3.3-million seed ... “Tech can solve not having a good manager.” Ben Rodier, F...*

- **[How Ashley Furniture transformed coaching with FrontlineIQ](https://www.frontlineiq.ai/blog-posts/how-ashley-furniture-transformed-coaching-with-frontlineiq)**
  - Source: frontlineiq.ai
  - *By adopting FrontlineIQ, they replaced guesswork with AI-powered ... PODCAST: Ben Rodier on Minding Your Business with Katherine Korakakis and Dan Lax...*

- **[FrontlineIQ Emerges from Stealth with $3.3M in Funding to Lead a ...](https://finance.yahoo.com/news/frontlineiq-emerges-stealth-3-3m-110000104.html)**
  - Source: finance.yahoo.com
  - *Oct 28, 2025 ... Video podcasts · Stocks in Translation · Trader Talk · Warrior Money · Living ... CONTACT: Ben Rodier FrontlineIQ 514-945-2505 ben@fr...*

- **[Raw unedited with Ben Rodier, CEO of FrontlineIQ - Failure- AI ...](https://www.youtube.com/watch?v=Iy4mNLGrtno)**
  - Source: youtube.com
  - *Sep 19, 2025 ... Raw unedited with Ben Rodier, CEO of FrontlineIQ - Failure- AI - Hero - Strange business learning. 66 views · 2 months ago ...more. A...*

- **[FrontlineIQ Ben Rodier - YouTube](https://www.youtube.com/watch?v=y2T_VfqjfE0)**
  - Source: youtube.com
  - *Oct 22, 2025 ... FrontlineIQ Ben Rodier. 71 views · 1 month ago. MONTREAL, QC H3W ... Jon Gray - President of Blackstone | Podcast | In Good Company |...*

- **[Meet the Builders: UP.Labs Appoints Elite Founders to Lead its Next ...](https://www.stoneybrookelevators.ca/markets/stocks.php?article=gnwcq-2025-8-21-meet-the-builders-uplabs-appoints-elite-founders-to-lead-its-next-wave-of-enterprise-ai-startups)**
  - Source: stoneybrookelevators.ca
  - *Aug 21, 2025 ... Profit Talk Sept/Oct 2025. Stock Quotes. Get quotes for stocks: To ... Ben Rodier — CEO, FrontlineIQ. Ben has spent more than 20 year...*

- **[FrontlineIQ Emerges from Stealth with $3.3M in Funding to Lead a ...](https://www.theglobeandmail.com/investing/markets/markets-news/GlobeNewswire/35723545/frontlineiq-emerges-from-stealth-with-3-3m-in-funding-to-lead-a-new-era-of-ai-coaching-for-in-person-sales/)**
  - Source: theglobeandmail.com
  - *Oct 28, 2025 ... Ben Rodier FrontlineIQ 514-945-2505 ben@frontlineIQ.ai. This article contains syndicated content. We have not reviewed, approved, or ...*

- **[Steven Dahan Email & Phone Number | FrontlineIQ Vice President ...](https://rocketreach.co/steven-dahan-email_1305769)**
  - Source: rocketreach.co
  - *FrontlineIQ Employee Ben Rodier's profile photo · Ben Rodier. Co-Founder and ... Blog · Contact Us. © 2025 RocketReach.co....*

- **[Zoonop: Internet's largest repository](https://zoonop.com/)**
  - Source: zoonop.com
  - *Article Search. Search articles. Willie Colón's Enduring Harmony: A Look ... Ben Rodier (FrontlineIQ): 10 Key Things You Must Know · Balnord Fund I · ...*

---

*Generated by Founder Scraper*
