# Rich Destiny

## Position actuelle

**Titre** : President | Co-fondateur
**Entreprise** : DOD BASKETBALL
**Durée dans le rôle** : 22 years 11 months in role
**Durée dans l'entreprise** : 22 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Management

## Résumé

Richard Destiné or Rich Destiny is an architect of virtual and real-world experiences that push the boundaries of audience engagement.  Rich is currently the CTO of GeniusXR, a full-service XR creative and development agency.  As an entrepreneur, Richard not only has extensive expertise in immersive digital production & Software creation, but he has also earned valuable experience in bringing real-world functions to the virtual realm.
 
Rich is also the President and co-founder of DOD basketball, a highly active sports club in the Montreal neighborhood of St-Leonard.
 
Rich is passionate about efficient use of cutting-edge technology for a better tomorrow, WEB3 & Building the Metaverse, and also facilitating access to sports & activities that keep communities Connected, Active & healthy.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAeBI98BFT-t_Oe5bdWVAckxVxQdozLa-GE/
**Connexions partagées** : 20


---

# Rich Destiny

## Position actuelle

**Entreprise** : GeniusXR

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Rich Destiny

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401654387380727808 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQGVbgjCdHWAcw/mp4-720p-30fp-crf28/B4EZrfzzCPKgCI-/0/1764691496611?e=1765778400&v=beta&t=BaOn6mcbOqUgRefMQXWz2vrgEtMkS_yfRmQ-_sXtIos | https://media.licdn.com/dms/image/v2/D4E05AQGVbgjCdHWAcw/videocover-high/B4EZrfzzCPKgBU-/0/1764691490554?e=1765778400&v=beta&t=K5VscT7DsmzNvmz5gzroxBQqNodIuEiGVDGkzx-at7Q | Quick 4DGS test — high-speed skateboard capture.

Captured & processed by UVRSE x GeniusXR 

Pushing another fast-movement test with 4D Gaussian Splatting. This time: a skateboard run + a fully AI-generated scene built in #WorldLabs.

Still rough — but more time and more splats get us closer to clean, real-time 4D motion for sports, stunts, and beyond.

More coming 🚀

#4DGS #GaussianSplatting #UVRSE #GeniusXR
Azad Abbasi | 16 | 3 | 2 | 5d | Azad Abbasi reposted this | Rich Destiny | https://www.linkedin.com/in/richdestiny | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:35.942Z |  | 2025-12-02T16:12:02.040Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399886848329936896 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9ef15660-c4b5-441e-981e-b96bfc95b357 | https://media.licdn.com/dms/image/v2/D4E05AQHi3zrV4R0kXQ/videocover-low/B4EZrGs93eGYBQ-/0/1764270269565?e=1765778400&v=beta&t=ZJFlkwH3EKwo27qriEu--QfwUMBQXO4g6IhJPqiJYl8 | 4DGS Guitar Capture — This was captured inside the volumetric studio at COlab Innovation sociale et culture numérique in Alma — a studio we built in collaboration with Sony inside their facility.

It’s an older test, but it still demonstrates the potential of the pipeline:

Raw 4D Gaussian Splatting capture

Clean performer isolation

AI-generated backgrounds created with #worldslab

Not a final output — just a glimpse of what happens when real volumetric capture meets AI-driven environments.

The next step is full AI enhancement, which will push the quality and cohesion even further.

AI enhancement coming soon.

#4dgs #GaussianSplat #uvrse #geniusxr
UVRSE 
GeniusXR 
Azad Abbasi | 38 | 0 | 4 | 1w | Azad Abbasi reposted this | Rich Destiny | https://www.linkedin.com/in/richdestiny | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:35.944Z |  | 2025-11-27T19:08:27.891Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386054817921728512 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQHuw-DUQnzjFw/videocover-high/B4EZoCFlJsHEBQ-/0/1760971610064?e=1765778400&v=beta&t=I2vAmeQwC9Mmrlna1Sk6eGBEiEGsfeSPBN4VhI2ub5I | Quick 4D Demo. Captured fast. Rendered fast.

This short 4D test shows how far spatial video can go — built entirely in Gaussian Splatting within an AI-generated 3D environment.

GeniusXR | UVRSE | World Labs 

Huge potential ahead for previsualization, gaming, and cinematic storytelling✨️

#GeniusXR #UVRSE #WorldLabs #4D #GaussianSplatting #SpatialComputing #VolumetricVideo #ImmersiveTech
Azad Abbasi | 27 | 3 | 3 | 1mo | Azad Abbasi reposted this | Rich Destiny | https://www.linkedin.com/in/richdestiny | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.580Z |  | 2025-10-20T15:04:54.855Z |  |  | 

---



---

# Rich Destiny
*GeniusXR*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [The World's #1 Entrepreneur Success Platform](https://app.geniusu.com/articles?a_aid=RichPhil&page=547)
*2025-01-01*
- Category: article

### [GeniusXR - VR - AR - MR - AI - Augmented & Virtual Reality - GXR LAB  Montreal](https://www.geniusxr.ai/)
*2024-05-22*
- Category: article

### [Volumetric Capture Studio in South Florida — GeniusXR - VR - AR - MR - AI - Augmented & Virtual Reality - GXR LAB  Montreal](https://www.geniusxr.ai/work/florida-volumetric-capture-studio)
*2024-01-01*
- Category: article

### [Sony Electronics, GeniusXR, Levan Center of Innovation Collaborate for Volumetric Capture Studio](https://www.ravepubs.com/sony-electronics-genius-xr-levan-center-of-innovation/)
*2024-01-03*
- Category: article

### [Levan Center of Innovation Unveils State-of-the-Art Volumetric Capture Studio In Collaboration With Sony Electronics And GeniusXR](https://tvnewscheck.com/tech/article/levan-center-of-innovation-unveils-state-of-the-art-volumetric-capture-studio-in-collaboration-with-sony-electronics-and-geniusxr/)
*2024-01-03*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
