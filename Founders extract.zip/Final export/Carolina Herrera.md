# Carolina Herrera

## Position actuelle

**Titre** : Founder at Bhakti Media
**Entreprise** : Bhakti Media
**Durée dans le rôle** : 13 years 2 months in role
**Durée dans l'entreprise** : 13 years 2 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Online Audio and Video Media

## Description du rôle

As Founder and Executive Producer at Bhakti Media, I led an independent film production company, overseeing the entire creative and operational lifecycle for four feature films. This entrepreneurial venture resulted in productions featured at over 30 international film festivals and reaching 100,000+ theatrical viewers. This experience was pivotal in developing profound expertise in strategic vision, end-to-end project management, and creative leadership within a competitive industry.

## Résumé

As a passionate executive with over two decades of experience, I specialize in driving impact across diverse sectors. My career journey blends audiovisual production with strategic project and program management, all while leading high-performing cross-functional teams in both public and private spheres.

I thrive on transforming visions into reality through compelling storytelling, data-driven content optimization, and innovative experience creation. With a global and entrepreneurial mindset, and fluency in both English and Spanish, I'm dedicated to leveraging my expertise to "Make Shift Happen" – propelling organizations and individuals forward to achieve their fullest potential.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAU3B0YBt2D_D7scf1uscMcrCcM_Ha5s2wo/
**Connexions partagées** : 2


---

# Carolina Herrera

## Position actuelle

**Entreprise** : Autodesk

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Carolina Herrera

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7390296836055547904 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8f1aa17f-7e7f-41b1-9583-d4ea97692661 | https://media.licdn.com/dms/image/v2/D5605AQH7VSI7gYDLpw/videocover-low/B56Zou37caKACE-/0/1761723013176?e=1765785600&v=beta&t=V8aMOJoqoxp5PWEURO0XLngdfDUMjgWvG0dHmWM2Jq0 | #LetThereBeAnything #Autodesk 🎉🔥 | 1 | 0 | 0 | 1mo | Post | Carolina Herrera | https://www.linkedin.com/in/carolina-herrera-23237425 | https://linkedin.com/in/carolina-herrera-23237425 | 2025-12-08T07:15:33.337Z |  | 2025-11-01T08:01:10.791Z | https://www.linkedin.com/feed/update/urn:li:activity:7389339098118897664/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7374851914817089536 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bb4e5e64-de92-4230-8f79-0652e7854e80 | https://media.licdn.com/dms/image/v2/D5605AQHYVFHSvKnHuA/feedshare-thumbnail_720_1280/B56ZkvRjSLJoA0-/0/1757434755496?e=1765785600&v=beta&t=-SnQcrY9dv9B0_CqcmJOsbrlw1yHuudygetyj5aeek0 | #MakeAnything | 0 | 0 | 0 | 2mo | Post | Carolina Herrera | https://www.linkedin.com/in/carolina-herrera-23237425 | https://linkedin.com/in/carolina-herrera-23237425 | 2025-12-08T07:15:33.338Z |  | 2025-09-19T17:08:34.615Z | https://www.linkedin.com/feed/update/urn:li:activity:7371215946356682752/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7374220357685153792 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3b8d5668-b70e-4efa-b276-21f75478eaca | https://media.licdn.com/dms/image/v2/D5610AQEGbkBZvpdK3w/ads-video-thumbnail_720_1280/B56ZlUEBJwG0Ag-/0/1758051969288?e=1765785600&v=beta&t=84q49cF-JTTir547G_ItjRs8o5d2xgUvtYWnQ-610x4 | #makeanything | 0 | 0 | 0 | 2mo | Post | Carolina Herrera | https://www.linkedin.com/in/carolina-herrera-23237425 | https://linkedin.com/in/carolina-herrera-23237425 | 2025-12-08T07:15:33.339Z |  | 2025-09-17T23:18:59.661Z | https://www.linkedin.com/feed/update/urn:li:activity:7373804538484629504/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7276234997101989888 | Article |  |  | Gracias, Cali 🎬 | 6 | 0 | 0 | 11mo | Post | Carolina Herrera | https://www.linkedin.com/in/carolina-herrera-23237425 | https://linkedin.com/in/carolina-herrera-23237425 | 2025-12-08T07:15:36.965Z |  | 2024-12-21T14:00:09.218Z | https://www.elpais.com.co/entretenimiento/la-piel-mas-temida-la-segunda-pelicula-de-la-trilogia-filmica-sobre-la-memoria-del-director-joel-calero-tendra-su-premier-en-cali-1854.html# |  | 

---



---

# Carolina Herrera
*Autodesk*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [A Conversation with Carolina Herrera](https://www.ellevatenetwork.com/articles/5572-a-conversation-with-carolina-herrera)
*2016-07-27*
- Category: article

### [Carolina Herrera launches Walk Tall career podcast and coaching platform](https://www.diarydirectory.com/newsarticle/carolina-herrera-launches-walk-tall-career-podcast-and-coaching-platform/46196)
*2022-09-01*
- Category: podcast

### [Carolina A. Herrera on her Beauty Mantra and her Familial Brand’s Gold Fantasy](https://smagazineofficial.com/beauty/carolina-a-herrera-on-her-beauty-mantra-and-her-familial-brands-gold-fantasy-121937180)
*2022-12-19*
- Category: article

### [Interview with Carolina Herrera: The legendary American designer reflects on her 35 in fas](https://www.lofficielsingapore.com/fashion/interview-with-carolina-herrera-new-book-35-years-in-fashion)
*2021-09-08*
- Category: article

### [EXCLUSIVE: The colorful stories behind Carolina Herrera's embroideries told from Hidalgo, Mexico | Politics + Fashion | Political Fashion Blog](https://www.political.fashion/posts/exclusive-the-colorful-stories-behind-carolina-herreras-embroideries-told-from-hidalgo-mexico)
*2025-01-17*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[How To Sell on Roblox: Steps for Entrepreneurs (2025) - Shopify ...](https://www.shopify.com/sg/blog/how-to-sell-on-roblox)**
  - Source: shopify.com
  - *... Autodesk Maya. These tools let users create 3D models by generating shapes ... Similarly, fashion designer Carolina Herrera partnered with model K...*

- **[Louis Vuitton Metaverse - RUNWAY MAGAZINE ® Official](https://runwaymagazines.com/louis-vuitton-metaverse/)**
  - Source: runwaymagazines.com
  - *In this Web3 experience we used integrations of Unity, WebGL, Maya – Autodesk, Blender, Ready Player Me, Spatial technologies. ... Runway Magazine 202...*

- **[Karlie Kloss Acquires i-D Magazine From Vice Media](https://www.yahoo.com/lifestyle/karlie-kloss-acquires-id-magazine-173000984.html)**
  - Source: yahoo.com
  - *Nov 14, 2023 ... She has partnered with brands including Adidas and Roblox and Carolina Herrera on tech ventures. She has invested in multiple digital...*

- **[Runway Magazine First Metaverse Magazine - RUNWAY ...](https://runwaymagazines.com/runway-magazine-first-metaverse-magazine/)**
  - Source: runwaymagazines.com
  - *In this Web3 experience we used integrations of Unity, WebGL, Maya – Autodesk, Blender, Ready Player Me, Spatial technologies. ... Runway Magazine 202...*

- **[SCAD 2020-2021 Academic Catalog](https://www.scad.edu/sites/default/files/PDF/catalog-20-21-accessible.pdf)**
  - Source: scad.edu
  - *Carolina Herrera. Calvin Klein. David Benioff. Beanie Feldstein. Jeremy Irons ... Autodesk® Building Performance Analysis (BPA) Certifcation. AVID Cer...*

- **[Speakers - Blueprint Vegas](https://blueprintvegas.com/speakers/)**
  - Source: blueprintvegas.com
  - *Prior to founding Promise Robotics, Ramtin was a Distinguished Research Scientist and Head of Autodesk Technology Centre in Canada. ×. Eric ......*

- **[Vitesse AuDessus launces one-piece carbon fiber wheel design ...](https://www.carbodydesign.com/2015/07/vitesse-audessus-launces-one-piece-carbon-fiber-wheel-design/)**
  - Source: carbodydesign.com
  - *Jul 31, 2015 ... Autodesk Alias Tutorials · Maya Tutorials · Rhino 3D Tutorials · MODO ... Carolina Herrera Dress. You wouldn't pair either with a gen...*

- **[Contxt 2023 by Ringling College - Issuu](https://issuu.com/ringlingcollegecontinuingstudies/docs/_contxt_2023_issuu)**
  - Source: issuu.com
  - *May 11, 2023 ... ... Carolina Herrera, Marciano, and Estee Lauder, Lucia is set to ... They were interviewed by Autodesk's feature “Meet the Student D...*

- **[food is hope. food is love. food is medicine.](https://www.glwd.org/wp-content/uploads/2018/09/2016.pdf)**
  - Source: glwd.org
  - *Autodesk, inc. robert & ellen Bach foundation mr. paris r. Baldacci and mr ... carolina herrera and mr. reinaldo herrera ms. loretta hickman ms. mary ...*

- **[— ISAAC Procedural 3D Factory — Real Time 3D Assets by beffio ...](https://www.beffio.com/nvidia-isaac-procedural-3d-factory)**
  - Source: beffio.com
  - *... Autodesk Maya, Unity3D (HDRP, DXR), Subtance Painter. Services 3D Art ... Carolina Herrera — Mercedes Car App - AR — Mercedes EQC WEBGL — ISAAC .....*

---

*Generated by Founder Scraper*
