# Ishkhan Ishkhanian

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : CanianteK
**Durée dans le rôle** : 5 months in role
**Durée dans l'entreprise** : 5 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Security and Investigations

## Résumé

Empowering and passionate leader with over 15 years of experience in software engineering (Product 
management, technical sales and development) and over 4 years in managing international remote and 
dispersed Engineering teams. Leading teams with empathy and trust to deliver above and beyond 
performances to customers and organizations. Multi-lingual and customer oriented with significant 
experience working on international enterprise projects. Thrive in hyper growth environment with 
innovative and outside the box thinking

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABVXD8B0xKtF8zXuj2CF2maqEvH9EOycnM/
**Connexions partagées** : 10


---

# Ishkhan Ishkhanian

## Position actuelle

**Entreprise** : CanianteK

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Ishkhan Ishkhanian

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397465351623479296 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFRDip85Iz5aw/feedshare-shrink_800/B4EZqkTiCkKcAk-/0/1763693176507?e=1766620800&v=beta&t=3MQ_bwWMOduQ0TgJVDG90KgHnGUIe3YaWuB05iOzgW4 | Mission accomplie ! 🎯
Fierté d'avoir présenté CanianteK hier au Demo Day du Centech Mtl. Une étape marquante dans notre parcours d'accélération.
Un grand merci à toute l'équipe du Centech Mtl pour ces mois de mentorat exceptionnel, d'organisation impeccable et de soutien inestimable. Votre travail fait une réelle différence pour les startups.
Félicitations à tous les entrepreneurs de la cohorte pour leurs pitchs impressionnants. Le meilleur est à venir !
À très bientôt pour la suite de l'aventure CanianteK !
#Centech #DemoDay #StartupLife #CanianteK | 94 | 3 | 1 | 2w | Post | Ishkhan Ishkhanian | https://www.linkedin.com/in/ish-ishkhanian | https://linkedin.com/in/ish-ishkhanian | 2025-12-08T06:11:49.648Z |  | 2025-11-21T02:46:18.087Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394544497596182528 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFqin92fpHQcQ/feedshare-shrink_800/B4EZpv4Cd3IoAg-/0/1762813573304?e=1766620800&v=beta&t=vm8cWQAkmH15Dcs1qfXvATXXD3_E5pXCDmo_JI6ejQU | Un immense merci à notre incroyable Entrepreneure en résidence, Doryne Bourque, ICD.D , pour ce magnifique témoignage et surtout pour son accompagnement inestimable au sein de la cohorte Accélération du Centech.
Chaque jour est une opportunité d'apprendre, de pivoter et de se dépasser, et c'est grâce à des mentors comme elle que CanianteK peut tracer sa voie avec confiance.
Nous sommes déterminés à concrétiser notre vision et à faire la différence.
#CanianteK #Centech #Accélération #Startups #Innovation #Entrepreneurship #DeepTech #Montreal | 12 | 1 | 0 | 3w | Post | Ishkhan Ishkhanian | https://www.linkedin.com/in/ish-ishkhanian | https://linkedin.com/in/ish-ishkhanian | 2025-12-08T06:11:49.649Z |  | 2025-11-13T01:19:52.220Z | https://www.linkedin.com/feed/update/urn:li:activity:7393776070543708161/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7368651927682707456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGHyAYhaVi6vg/feedshare-shrink_800/B4EZkK14JUGUAo-/0/1756823521714?e=1766620800&v=beta&t=4US_4fO5y49nMw5xfDk0jEPzYtBiuO7Fc1OO9Ucn-NM | I’m happy and proud to announce that CanianteK joined Centech incubator. I look forward to this exciting journey
#centech #CanianteK #startup | 105 | 16 | 0 | 3mo | Post | Ishkhan Ishkhanian | https://www.linkedin.com/in/ish-ishkhanian | https://linkedin.com/in/ish-ishkhanian | 2025-12-08T06:11:49.650Z |  | 2025-09-02T14:32:02.492Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7368382842176692224 | Text |  |  | Some big news to share. After a period of important reflection with my family following a major career transition, I've decided to embark on the most challenging and meaningful journey of my professional life: founding my own company, Caniantek.

This isn't just a career move; it's a deeply personal one. A few years ago, a promise I made to my late sister crystallized what truly matters to me: building something with purpose and leaving a legacy of real impact.

This venture is driven by a core belief that has shaped my career: an industry responsible for our safety must lead innovation, not just follow it. Too often, we've seen trends from the consumer market adapted for our industry, without first solving our own fundamental, operational challenges. Caniantek was created to change that—to build solutions based on the real-world needs of security and defense professionals.

Our focus is on eliminating one of the longest-standing compromises in the surveillance industry: the impossible choice between wide-area situational awareness and critical, high-resolution detail. Caniantek’s technology is designed to solve this by augmenting existing cameras, expanding their field of view by over 300% to deliver the whole picture and every detail, all at once. By making a single surveillance asset drastically more effective, this capability is a key to unlocking the true potential of modern platforms, particularly in aerial surveillance.

The road ahead is long. My focus for the next few months is on finalizing our Proof of Concept and bringing together a world-class team of advisors and engineers to build our MVP.

If you're a passionate engineer (Mechatronics, AI/ML, Software) who wants to solve fundamental challenges in security and defense, or if you're simply interested in the future of visual intelligence, I'd love to connect.

If you are a professional in the security or defense industry facing the challenges of wide-area surveillance, I would be honored to connect. We are looking for a select group of visionary end-users to join our pilot program and help shape the future of this technology.

And finally, to the camera manufacturers, platform providers, and specialized resellers who want to offer a truly differentiated solution: I am building a powerful partner ecosystem from day one. Let's connect.

Please follow the new Caniantek company page to join me on this journey.

https://www.caniantek.com

#Caniantek #Founder #DeepTech #Innovation #SecurityTech #DefenseTech #AI #Montreal | 151 | 73 | 1 | 3mo | Post | Ishkhan Ishkhanian | https://www.linkedin.com/in/ish-ishkhanian | https://linkedin.com/in/ish-ishkhanian | 2025-12-08T06:11:49.651Z |  | 2025-09-01T20:42:47.508Z |  |  | 

---



---

# Ishkhan Ishkhanian
*CanianteK*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Ishkhan Margaryan - 120K Project | LinkedIn](https://am.linkedin.com/in/ishkhan-margaryan)
*2025-05-08*
- Category: article

### [How a Gen AI Startup solved its product gaps with the Canva Apps SDK - Canva Developers Blog](https://www.canva.dev/blog/developers/gen-ai-startup-solved-product-gaps-with-apps-sdk/)
*2024-03-01*
- Category: blog

### [Bringing Artists and Art Lovers Together With Kanvas AI. The Interview](https://medium.com/startup-adventures-international/bringing-artists-and-art-lovers-together-with-kanvas-ai-the-interview-83822c1fa2e5?source=post_internal_links---------2----------------------------)
*2022-02-22*
- Category: blog

### [Interview with Ishan Anand, Creator of Spreadsheets-are-all-you-need.ai](https://www.js-craft.io/blog/interview-with-ishan-anand-creator-of-spreadsheets-are-all-you-need-ai/)
*2024-09-13*
- Category: blog

### [Founder Stories — Granatus Ventures](https://www.granatusventures.com/founder-stories)
*2023-03-13*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
