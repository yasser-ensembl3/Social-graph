# John Sclapari

## Position actuelle

**Titre** : Founder, CEO & President
**Entreprise** : Fuel Digital Media
**Durée dans le rôle** : 15 years 3 months in role
**Durée dans l'entreprise** : 15 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

Founded in 2010, Fuel Digital Media is Quebec's largest independent media representation firm.

Fuel Digital Media has exclusive relationships with an impressive portfolio of influential digital publishers, including Les Coops de l’information (Lesoleil.com; Lenouvelliste.ca; Lequotidien.com; Latribune.ca; Lavoixdelest.ca and Ledroit.com), Auto123.com, Otogo.ca, BIZZ Média websites (Cinoche.com et ShowBizz.net), Educatout.com, major Real Estate publishers (Remax-Quebec.com, SuttonQuebec.com, ViaCapitalevendu.com, RoyalLepage.ca), Culture Cible websites (Sors-tu.ca, Atuvu.ca, Lecanalauditif.ca, labibleurbaine.com, etc.), the 500+ sports organization websites associated with the Spordle.com network, Passeportsante.net, Groupe Le Monde websites (LeMonde.fr, CourrierInternational.com, Nouvelobs.com, etc.) as well as Groupe Webedia websites (AlloCine.fr, JeuxVideo.com, 750g.com, etc.).

Fondée en 2010, Fuel Digital Media est la plus importante firme de représentation média indépendante au Québec. 

Fuel Digital Média représente – en exclusivité – un impressionnant portfolio d’éditeurs numériques influents dont les sites des Coops de l’information (Lesoleil.com; Lenouvelliste.ca; Lequotidien.com; Latribune.ca; Lavoixdelest.ca and Ledroit.com), Auto123.com, Otogo.ca, les sites du groupe BIZZ Média (Cinoche.com et ShowBizz.net), Educatout.com, les principaux sites immobiliers (Remax-Quebec.com, SuttonQuebec.com, ViaCapitalevendu.com, RoyalLepage.ca), les sites du collectif Culture Cible (Sors-tu.ca, Atuvu.ca, Lecanalauditif.ca, labibleurbaine.com), les 500+ sites des organisations sportives membres du réseau Spordle.com, Passeportsante.net, les sites du groupe Le Monde (LeMonde.fr, CourrierInternational.com, Nouvelobs.com, etc.) ainsi que les sites du groupe Webedia (AlloCine.fr, JeuxVideo.com, 750g.com, etc.).

## Résumé

Specialties: Online Advertising, Email Marketing, Mobile Media, SEM, Media Planning + Buying, Advertising, Partner Relations, Sales Management, Content Marketing.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACzd7oBDA1T2-zljl2XD4OZjTHy60vacYo/
**Connexions partagées** : 115


---

# John Sclapari

## Position actuelle

**Entreprise** : Fuel Digital Media

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# John Sclapari

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400554268258373632 | Article |  |  | Our team is proud to welcome Jobillico.com as our newest exclusive premium partner.

A leader in the job search market, Jobillico.com connects employers and job seekers across Quebec and Canada, with more than 736,000 monthly unique visitors, over 100,000 job postings, and nearly 7 million monthly page views.

We’re excited about this collaboration and the new opportunities it creates for brands looking to engage workers and job seekers at key moments of influence.
____

Notre équipe est fière d’accueillir Jobillico.com comme notre nouveau partenaire exclusif.

Leader du marché de la recherche d’emploi, Jobillico connecte employeurs et chercheurs d’emploi à travers le Québec et le Canada, avec plus de 736 000 visiteurs uniques par mois, plus de 100 000 offres d’emploi et près de 7 millions de pages vues mensuellement.

Plusieurs belles opportunités sont disponibles pour les annonceurs souhaitant rejoindre travailleurs et chercheurs d’emploi à des moments clés de leur parcours professionnel ! | 20 | 0 | 1 | 1w | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:45.258Z |  | 2025-11-29T15:20:33.202Z | https://www.grenier.qc.ca/actualites/52402/jobiillico-recrute-fuel-digital-media-pour-commercialiser-son-inventaire-publicitaire |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387094862048960512 | Text |  |  | Alerte emploi pour l’un de nos partenaires - avis aux intéressés ! | 2 | 0 | 0 | 1mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:45.259Z |  | 2025-10-23T11:57:40.698Z | https://www.linkedin.com/feed/update/urn:li:activity:7386782476284731392/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7380908707171438592 | Article |  |  | Nous recrutons!

Fuel Digital Media est à la recherche d’un(e) Directeur(trice) de comptes passionné(e) par la vente et le développement des affaires numériques. Si tu as une solide expérience en vente de médias numériques et que tu souhaites rejoindre une équipe dynamique, ce poste est pour toi! Tu seras responsable de stimuler la croissance auprès des clients directs et des agences, avec un objectif de vente de plus de 3 millions de dollars en valeur contractuelle.

//
We're hiring!

Fuel Digital Media is looking for a passionate Account Director with a strong background in digital media sales. If you're eager to join a dynamic team and drive business growth, this role is for you! You'll be responsible for expanding our client base and increasing revenue, with a contract value target exceeding $3 million.

https://lnkd.in/eRhnEu7T | 25 | 0 | 4 | 2mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:45.259Z |  | 2025-10-06T10:16:06.442Z | https://www.grenier.qc.ca/emplois/87593/directeurtrice-de-comptes |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7348869506372423680 | Article |  |  | Notre équipe représente les propriétés de Les Coops de l’information, dont Lesoleil.com, Ledroit.com, Lenouvelliste.ca, Lequotidien.com, Latribune.ca et Lavoixdelest.ca, à l’échelle canadienne depuis octobre 2023.

Depuis le 1er juillet 2025, Les Coops de l’information nous ont confié l’ensemble de leur représentation publicitaire à l’échelle nationale, incluant désormais le marché québécois.
 
C’est une annonce qui nous tient particulièrement à cœur. Elle marque une étape importante pour notre entreprise, mais surtout, elle survient à un moment crucial pour les médias d’ici.
 
À l’heure où les géants du numérique comme Facebook et Google accaparent une part écrasante des revenus publicitaires, acheter local devient un geste essentiel pour assurer la pérennité du journalisme local.
 
Les Coops de l’information, c’est une voix indépendante, engagée et profondément enracinée dans nos communautés, au service des Québécois depuis plus de 100 ans. Nous sommes fiers et sincèrement reconnaissants de contribuer à leur rayonnement partout au pays.
 
Merci à notre partenaire pour sa confiance. | 20 | 6 | 0 | 4mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:45.260Z |  | 2025-07-10T00:23:45.712Z | http://lesoleil.com/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7341592312860299266 | Article |  |  | C’est avec une immense fierté que notre équipe annonce aujourd’hui l’arrivée d’un partenaire automobile d’envergure, dans une catégorie que nous avons travaillé sans relâche à développer depuis un peu plus de deux ans. Ces efforts soutenus nous ont permis d’établir une position dominante dans le secteur automobile au Québec.

J’ai donc le plaisir de vous annoncer que, dès le 26 juin prochain, RPMweb.ca rejoindra notre portefeuille de partenaires médias premium au Québec.

Grâce à cette addition stratégique, notre offre automobile permet désormais à nos clients-partenaires de rejoindre chaque mois plus de 1,6 million d’acheteurs automobiles actifs sur le marché, grâce à des placements numériques à la fois innovants et performants, conçus pour générer des résultats tangibles tout en captant l’attention.

Un grand merci à l’équipe de # TORQ Le Groupe pour sa confiance! | 30 | 0 | 0 | 5mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:45.261Z |  | 2025-06-19T22:26:47.575Z | https://www.grenier.qc.ca/actualites/49685/rpm-web-confie-la-commercialisation-de-son-inventaire-publicitaire-a-fuel-digital-media |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7295587931132489728 | Article |  |  | Quelle fierté de travailler avec BIZZ Media et son équipe de stars depuis plus de 8 ans, en représentant les plus grands sites de divertissement québécois du pays. Un merci spécial à Joé Bussière pour sa confiance, sa loyauté, sa collaboration et son amitié qui perdurent depuis bien avant notre partenariat.

Fuel Digital Media se positionne plus que jamais comme LA plus grande maison de représentation dans la francophonie au Canada, et nous sommes plus que fiers de collaborer avec les plus grands éditeurs québécois et canadiens dans leurs catégories respectives. Au plaisir de collaborer avec nos partenaires agences et annonceurs, et un grand merci à tous pour votre soutien continu. | 15 | 0 | 0 | 9mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:49.097Z |  | 2025-02-12T23:41:48.251Z | https://www.grenier.qc.ca/actualites/46985/fuel-digital-media-renouvelle-son-partenariat-avec-bizz-media |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7293062762337820672 | Text |  |  | Notre partenaire de longue date est à la recherche d’un(e) stagiaire en marketing numérique. Si vous connaissez quelqu’un dans votre entourage, n’hésitez pas à passer le mot ! | 6 | 0 | 1 | 10mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:49.098Z |  | 2025-02-06T00:27:41.095Z | https://www.linkedin.com/feed/update/urn:li:activity:7293008736627884032/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7277671459093712896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGl-1gg6lVmTQ/feedshare-shrink_800/B4EZPmG9cKHEAg-/0/1734732405082?e=1766620800&v=beta&t=7japJM5K9yvIb0ffVxCwzMiSgN_yK1lgicSb1sJSEZk | Wishing all our client and publisher partners and friends a very happy holiday season and a peaceful and prosperous 2025! Thank you all for your support throughout the year ! | 19 | 0 | 0 | 11mo | Post | John Sclapari | https://www.linkedin.com/in/johnsclapari | https://linkedin.com/in/johnsclapari | 2025-12-08T05:20:49.098Z |  | 2024-12-25T13:08:08.445Z | https://www.linkedin.com/feed/update/urn:li:activity:7275995072200945665/ |  | 

---



---

# John Sclapari
*Fuel Digital Media*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Charlotte Sclapari, Founder of Sequoia Films, on Making a Meaningful Cultural Impact — The Luna Collective](https://www.thelunacollective.co/journal/spotlight-sequoia-films)
*2024-07-20*
- Category: article

### [Sequoia Films Founder Charlotte Sclapari is Building a Bi-Coastal Creative Agency on a Global Mission](https://www.about.us/blog/sequoia-films-founder-charlotte-sclapari-is-building-a-bi-coastal-creative-agency-on-a-global-mission)
*2025-01-01*
- Category: blog

### [Business Archives](https://livethefuel.com/business-episodes)
*2025-08-20*
- Category: article

### [Jean-Paul Sclapari joins Pelmorex Media Inc as Head of Sales, Quebec](https://pelmorex.com/en/media-hub/jean-paul-sclapari-joins-pelmorex-media-inc-as-head-of-sales-quebec)
*2017-04-03*
- Category: article

### [Sequoia Films Enters New York Digital Commercial Production Scene With Refreshing Fashion Film | shots Magazine](https://magazine.shots.net/news/view/sequoia-films-enters-new-york-digital-commercial-production-scene-with-refreshing-fashion-film)
*2017-02-24*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[RPM Web confie la commercialisation de son inventaire publicitaire ...](https://isarta.com/infos/rpm-web-confie-la-commercialisation-de-son-inventaire-publicitaire-a-fuel-digital-media/)**
  - Source: isarta.com
  - *Jun 17, 2025 ... ... John Sclapari, président-fondateur de Fuel Digital Média. Avec nos ... podcasts, les infolettres, les courriels dédiés, les ......*

- **[Les Coops de l'information choisissent Fuel Digital Media | Isarta Infos](https://isarta.com/infos/les-coops-de-linformation-choisissent-fuel-digital-media/)**
  - Source: isarta.com
  - *Jan 8, 2024 ... Podcasts · EMPLOIS · FORMATIONS · logo image Emplois / Formations ... John Sclapari, président fondateur de Fuel Digital Media. « Parc...*

- **[Fuel Digital Média devient le représentant publicitaire exclusif de ...](https://www.automedia.ca/fuel-digital-media-rpmweb/)**
  - Source: automedia.ca
  - *Jun 17, 2025 ... ... John Sclapari, président-fondateur de Fuel Digital Média. Une offre ... podcasts, infolettres, courriels dédiés, intégrations sur...*

- **[Fuel Digital Media - Profiles & Contacts](https://www.crunchbase.com/organization/fuel-digital-media/people)**
  - Source: crunchbase.com
  - *Fuel Digital Media has 1 current employee profile, Founder John Sclapari . ... Talk With Sales. What We Do. Crunchbase Pro · Crunchbase Business · Mar...*

- **[John Sclapari Email & Phone Number | Fuel Digital Media Founder ...](https://rocketreach.co/john-sclapari-email_3570184)**
  - Source: rocketreach.co
  - *John Sclapari, based in Montreal, QC, CA, is currently a Founder, CEO and President at Fuel Digital Media. John Sclapari brings experience from previo...*

- **[Industry News: Jolt expands DOOH-enabled EV charging network to ...](https://mediaincanada.com/2025/09/11/jolt-calgary-fuel-digital-carpages/)**
  - Source: mediaincanada.com
  - *Sep 11, 2025 ... ... John Sclapari, founder and president of Fuel Digital Media. “Carpages.ca allows us to offer advertisers a direct line to highly e...*

- **[Adnews](https://www.adnews.com/44261)**
  - Source: adnews.com
  - *Aug 22, 2025 ... ... John Sclapari, president of Fuel Digital Media. “CarPages.ca allows us to offer advertisers a direct line to highly engaged car b...*

- **[Otogo.ca se joint à Fuel Digital Media | Grenier aux nouvelles](https://www.grenier.qc.ca/actualites/40950/otogoca-se-joint-a-fuel-digital-media)**
  - Source: grenier.qc.ca
  - *Apr 3, 2024 ... ... John Sclapari, président fondateur de Fuel Digital Media. Avec l ... « De la publication d'un article à la création d'un dossier ....*

- **[Publicité: annoncez dans InfoBref](https://infobref.com/pub/)**
  - Source: infobref.com
  - *attirer du trafic vers un contenu sur votre site (article, conseil ... John Sclapari, de Fuel Digital Media à john@fueldigitalmedia.com. Il pourra ......*

- **[Jobboom et Réseau Contact confient leurs ventes publicitaires ...](https://www.grenier.qc.ca/actualites/9413/jobboom-et-reseau-contact-confient-leurs-ventes-publicitaires-nationales-a-fuel-digital-media)**
  - Source: grenier.qc.ca
  - *Dec 10, 2015 ... ... John Sclapari, président chez Fuel Digital Media. Mots clés associés : Partenariat, Fuel Digital Média, Reseau Contact, Jobboom. ...*

---

*Generated by Founder Scraper*
