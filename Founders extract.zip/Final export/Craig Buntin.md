# Craig Buntin

## Position actuelle

**Titre** : Founder, CEO
**Entreprise** : Rise Robotics and Materials
**Durée dans le rôle** : 9 months in role
**Durée dans l'entreprise** : 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAASO4qUBYGx3eLyNd4o7HPEnmBNgu92zCEA/
**Connexions partagées** : 133


---

# Craig Buntin

## Position actuelle

**Entreprise** : Rise: Intelligent Automation

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Craig Buntin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392146939460616192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdZIQ2AhSzgA/feedshare-shrink_800/B4EZpUUKlRGYAg-/0/1762351169697?e=1766620800&v=beta&t=iGr-NHk-357jdfaOsE9NWCUq7Oc8XzmE6n82tMUmqpU | There’s something incredible brewing in Montreal | 36 | 0 | 0 | 1mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:24.990Z |  | 2025-11-06T10:32:49.816Z | https://www.linkedin.com/feed/update/urn:li:activity:7391836573501120513/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389286364485427201 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGxAPEZxYn-Mw/feedshare-shrink_1280/B4EZoMPiJ1IMAs-/0/1761141990389?e=1766620800&v=beta&t=wbaw4mBZql0sAU_Y-qYFMgVOhJe7ac7ZFPcFnU4HUZA | Robots are about to have their ChatGPT moment.

Awesome being on this panel.

Thank you Nectarios Economakis and Mila - Quebec Artificial Intelligence Institute for making this event happen.

Also, thank you David Charbonneau at Boreal Ventures, Brad Moon at Astrus and Colin Gallacher at. Haply Robotics for the insightful discussion. | 15 | 1 | 0 | 1mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:24.991Z |  | 2025-10-29T13:05:55.595Z | https://www.linkedin.com/feed/update/urn:li:activity:7386764899638542336/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7388610128440131585 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFyXKHFBn8Hjw/feedshare-shrink_800/B4EZolxCR9GcAg-/0/1761570214675?e=1766620800&v=beta&t=wgVpGdyO2hvhTxKA-fzvIH7RUqMWkI4qk6EYzhXMQHY | This conversation was 🔥

Thank you Antoine Riachi for bringing together such an incredible group of people. | 14 | 2 | 0 | 1mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:24.993Z |  | 2025-10-27T16:18:48.358Z | https://www.linkedin.com/feed/update/urn:li:activity:7388561032660586497/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387542978522750976 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHuF8yZ3fhNwQ/feedshare-shrink_800/B4EZoXTMDGGoAg-/0/1761327498436?e=1766620800&v=beta&t=BBxzAmdOWGD_zduS1RJBe37RhqsgCnFUg19P4vHO2Y8 | Really enjoyed discussing the benefits of venture studios, particularly regarding my experience at TandemLaunch Ventures and Cycle Momentum.

Thank you Geoffroy Renaud, and Remi Richard for the great discussion today! Patricio Gutierrez Mella, it was a really a pleasure. Thank you for having me on.

Thank you to elantech and Cycle Momentum for your work with https://lnkd.in/ehKQmmgs | 47 | 1 | 1 | 1mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:24.993Z |  | 2025-10-24T17:38:19.991Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7386883025265008641 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF05ZLuz0NiYA/feedshare-shrink_2048_1536/B4EZoHc4HpIMAw-/0/1761061602223?e=1766620800&v=beta&t=LDMZJnFZsxqy4o_lzl6mpVScnYqmcz_QIr2mJRXLNPE | Really enjoyed the conversation with Alexandre Préfontaine, Michel Dubois and Scott Pelton. Thank you to everyone for bringing the event together.

Great people build great things, and if today’s panel was any indication, I’m excited to see what projects Innovobot, BDC and RiSC Capital are backing! | 17 | 1 | 0 | 1mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:24.994Z |  | 2025-10-22T21:55:54.873Z | https://www.linkedin.com/feed/update/urn:li:activity:7386427728192757761/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7338972984658804737 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEoJdoN1F8c-Q/feedshare-shrink_800/B4EZdVi1rNHsAg-/0/1749486885891?e=1766620800&v=beta&t=UWeo510pJ_3EyN41iy06dfh4pn3dBPOTZzBJua0cDkM | I'm so excited to present Rise at the Climate Solutions Prize next week! What an honour to have qualified for the final round. If you plan on attending and would like to connect, send me a msg and let's make it happen.

#ClimateTech #CSPFestival #ClimateAction #Sustainability | 55 | 5 | 1 | 5mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.103Z |  | 2025-06-12T16:58:31.067Z | https://www.linkedin.com/feed/update/urn:li:activity:7337879849157468160/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7328298499572199425 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9k17nSYzCrg/feedshare-shrink_2048_1536/B4EZbLMhLAHoAo-/0/1747165779855?e=1766620800&v=beta&t=Dah7ciCsjKqQesuqujIdtENwCVKA0p1dP5Mypoe3Ylk | Agreed | 9 | 0 | 0 | 6mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.104Z |  | 2025-05-14T06:01:55.500Z | https://www.linkedin.com/feed/update/urn:li:activity:7328144423496658944/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7326337418939277313 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEunRd_Peih3Q/feedshare-shrink_800/B56ZaqgtzkGUAg-/0/1746617425966?e=1766620800&v=beta&t=F196Q1kXQ9CHwq4phxvkLsrpYKbyHF4w5hx4FZZDJC4 | Absolutely loving my work as an Entrepreneur in Residence with 2 Degrés and Cycle Momentum! Thank you Patrick Gagné and Alexandre Guindon for the opportunity! | 72 | 8 | 0 | 6mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.105Z |  | 2025-05-08T20:09:17.442Z | https://www.linkedin.com/feed/update/urn:li:activity:7325851932525244416/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7321505753603715073 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE-uAgtigW_Ww/feedshare-shrink_800/B4EZZroihDHcAk-/0/1745562516978?e=1766620800&v=beta&t=3xBWkWF4NaPDD88WJIPBt6gzpi75PTKhHPHG8X19Elk | I use this reference often. Your goals define your actions and your outcomes, so you might as well set big goals. | 23 | 1 | 0 | 7mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.106Z |  | 2025-04-25T12:09:58.658Z | https://www.linkedin.com/feed/update/urn:li:activity:7321419853880254465/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7318031325825818624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGQqInQbzigdg/feedshare-shrink_800/B4EZY7F.GmHkAg-/0/1744748143709?e=1766620800&v=beta&t=Rul-WR3tOLPMHfRQW10OA-dS4m-nLqCrV3O6X16tBvk | Honoured to have been a part of this. Congrats to everyone at Israel on Campus on a great event!! | 15 | 2 | 0 | 7mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.107Z |  | 2025-04-15T22:03:50.524Z | https://www.linkedin.com/feed/update/urn:li:activity:7318004121930784770/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7312906783814012929 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgv-aAH6SFWA/feedshare-shrink_800/B4EZXyp9SVH0Ak-/0/1743532843581?e=1766620800&v=beta&t=-7W0RzSALKETuyql-WEzy991Nhynp8NVsotiNFt8tyA | Incredibly honoured to have won the People's Choice Award at Tech Shuk last night. It was the first time out in public with Rise, and I can't express how invigorating it was to see the reaction.

Thank you to Karen Aflalo, Adam Levy, Yaelle Ifergan, and Galit Suissa for making this happen, and to our Lions Andrée-Lise Méthot, Jeffrey Baikowitz, Remi Fournier, Stephan Ouaknine, and Steven Oyer for the great feedback. Thank you as well to the Jewish National Fund of Canada. Tech Shuk was an unbelievable event! | 194 | 27 | 1 | 8mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.108Z |  | 2025-04-01T18:40:44.499Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7308284547668869120 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGW3FU-6pAwVQ/feedshare-shrink_800/B4DZWv_2jIHABo-/0/1742414506970?e=1766620800&v=beta&t=RIjXuIXGepq_DI8OlnODXukoADRRW4JgJTPQoOBg8hc | Excited to share that I will be on stage with Rise at Tech Shuk on March 31. Our mission is to solve the CO2 problem in our lifetime. | 43 | 7 | 1 | 8mo | Post | Craig Buntin | https://www.linkedin.com/in/craigbuntin | https://linkedin.com/in/craigbuntin | 2025-12-08T05:17:27.109Z |  | 2025-03-20T00:33:37.525Z | https://www.linkedin.com/feed/update/urn:li:activity:7308216144069353473/ |  | 

---



---

# Craig Buntin
*Rise: Intelligent Automation*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [From Olympian to AI Entrepreneur: Craig Buntin's Bold Reinvention - After Peter Pan: Growing Up to Purpose](https://afterpeterpan.buzzsprout.com/2329592/episodes/16528596-from-olympian-to-ai-entrepreneur-craig-buntin-s-bold-reinvention)
*2025-01-30*
- Category: article

### [Craig Buntin, Co-founder & CEO, Sportlogiq - How to selectively consume information in the tech era? | Breakfast Bar Podcast Series](https://www.deviqa.com/podcasts/craig-buntin/)
*2025-05-06*
- Category: podcast

### [Craig Buntin, co-Founder and CEO of Sportlogiq - The CEO Series with McGill's Karl Moore](https://omny.fm/shows/the-ceo-series-with-mcgills-karl-moore/craig-buntin-co-founder-and-ceo-of-sportlogiq)
*2024-03-11*
- Category: article

### [Craig Buntin - Rise Carbon Solutions | LinkedIn](https://ca.linkedin.com/in/craigbuntin)
*2025-04-25*
- Category: article

### [Washington University Law Review](https://journals.library.wustl.edu/lawreview/article/3851/galley/20684/view/)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
