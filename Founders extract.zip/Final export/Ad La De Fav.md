# Adélaïde Favé

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400205586497417216 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFu3k_00QL_sw/feedshare-shrink_800/B4EZrLPugxKoAg-/0/1764346496970?e=1766620800&v=beta&t=8V1kQo9HSetHRZbFmFXv_ciVFP2gHR_xHV_I9sp4YOE | 🇨🇦🇨🇦🇨🇦
After almost 10 years in this country, studying here, meeting incredible people, travelling, building my company, and most of all, feeling at home, this moment feels special to me✨

More than gaining the right to vote (an amazing power in itself) what moves me the most is feeling even more legitimate in contributing to Canada’s future. Well, to my country’s future (because I can finally say “my country” now, ahah).

To creating impact.
To helping build the foundations of tomorrow’s economy.
To giving back to the country that welcomed me with open arms,  the country I’ve grown to love so deeply, whose values I fell in love with from the very beginning.

I chose this journey. I chose this country. A place where anything still feels possible.

I can’t wait to see it continue to grow, and to keep growing with it.

Canada, you have my heart ❤️

Tabarnouche, je suis Canadienne 🥹 | 240 | 36 | 0 | 1w | Post | Adélaïde Favé | https://www.linkedin.com/in/adelaide-fave | https://linkedin.com/in/adelaide-fave | 2025-12-08T06:22:35.381Z |  | 2025-11-28T16:15:00.992Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396267581613133824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPl6vXKu1RtQ/feedshare-shrink_800/B4EZqTSKiVHgAk-/0/1763407605188?e=1766620800&v=beta&t=OuxQWN9TIWYPpNz3EX4EJNDjtv8kq_Z9O7BebXnMq2U | 🎃 CarInspect Baking contest - the Halloween edition! 

Two weeks ago, we celebrated Halloween at the office with our second baking contest of the year! (Spoiler: the Christmas one is coming soon… brace yourselves 👀 )

A few facts from this round:
 
🍰 2nd cake EVER for Ed Schaeffer. And he’s getting pretty good at it! (even if it was… challenging to cut 😅)
 
🙅‍♂️ Jad doesn’t like sweets… (yes, you read that correctly), we still made him taste some.

💪 First time baking for Anass in a CarInspect contest, and he delivered some delicious autumn-vibe muffins! Definitely a competitor to watch out for!

👻 Meryl, fully on theme with her adorable ghost treats! She came in ready to win, and honestly, with that competitive spirit, next time the title is yours. 

And the winner: Christelle, with brain-shaped cakes! 🧠 🥳 

👋 And while I’m here, I also want to highlight and congratulate our two newest team members, Anass and Christelle!

A few months ago, you jumped into startup life without hesitation. You’ve already demonstrated a strong commitment, and the progress you’ve made speaks for itself.
Seeing you fully aligned with CarInspect’s core values is also a great confirmation that we made the right choice. 

Here’s to all the adventures (and challenges 😅 ) we’ll navigate together. Excited for everything ahead 🚀 | 41 | 6 | 2 | 2w | Post | Adélaïde Favé | https://www.linkedin.com/in/adelaide-fave | https://linkedin.com/in/adelaide-fave | 2025-12-08T06:22:35.382Z |  | 2025-11-17T19:26:47.463Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7346885246954471427 | Text |  |  | CarInspect is hiring a Customer Success Manager to join a wonderful startup adventure!

If you're someone who thrives in a fast-paced environment, enjoys wearing multiple hats, loves helping customers, and wants to be part of a small team where your ideas matter and you truly have ownership,  then this might just be the opportunity you’ve been waiting for.

Know someone who would thrive in this role? Tag them or share this post, we’d love to meet them! | 55 | 4 | 3 | 5mo | Post | Adélaïde Favé | https://www.linkedin.com/in/adelaide-fave | https://linkedin.com/in/adelaide-fave | 2025-12-08T06:22:35.384Z |  | 2025-07-04T12:59:01.401Z |  | https://www.linkedin.com/jobs/view/4256039551/ | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7274455807369396226 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFcKngw_Jo3TA/feedshare-shrink_800/B4EZPQO9DcHwAg-/0/1734365416265?e=1766620800&v=beta&t=pp4njHefnQDAUSm8jF-aBVk97tBBXGPLUdh2zoX6XjY | “I love your French accent”

I wish I could have a perfect American accent, but Mother Nature had other plans, ahah.

Ending 2024 with the Forbes 30 Under 30 celebration in New York City.

See you in 2025 for exciting new projects at CarInspect LinkedIn people!

Take care ❄️☃️ | 486 | 29 | 0 | 11mo | Post | Adélaïde Favé | https://www.linkedin.com/in/adelaide-fave | https://linkedin.com/in/adelaide-fave | 2025-12-08T06:22:40.483Z |  | 2024-12-16T16:10:17.330Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7269778397306699779 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGmjk2f_hsryA/feedshare-shrink_800/feedshare-shrink_800/0/1733250234326?e=1766620800&v=beta&t=EPYSBo5NAGkaCEr9rUD4EZ2HxDB_TKjcz1KQcDojJNM | What a surprise this morning!!
I was beyond thrilled to discover that Edouard and I have been named to Forbes 30 Under 30 in the Mobility & Transportation category for North America  🚗🌍

This recognition is an incredible honor, and reflects the years of hard work, countless challenges, and bold decisions that brought us here. 

When I met Edouard five years ago at HEC Montréal it was clear we shared a deep passion for entrepreneurship, a commitment to creating meaningful change, and a vision for transforming how people make better-informed decisions when it comes to vehicles.
That moment was life-changing—I knew we had to build something together. And so, CarInspect was born with a single, bold ambition: to transform the vehicle inspection industry for better-informed decisions 💡 

This journey has taught me that youth isn’t a barrier to success; it’s a mindset of curiosity, resilience, and fearlessness that fuels it. Forbes’ recognition is a reminder for me—and all young leaders—to dream even bigger and embrace the responsibility to change this world for the better.

To our team, inspectors, clients, investors, mentors, partners and everyone who believed in this vision: this milestone is as much yours as it is ours. Thank you for being part of this incredible journey 🚀

Here’s to dreaming big, working hard, and driving forward! 🏆

https://lnkd.in/erFDQZqg

 #ForbesUnder30 #MobilityAndTransportation #CarInspect #Entrepreneurship #Grateful | 788 | 103 | 2 | 1yr | Post | Adélaïde Favé | https://www.linkedin.com/in/adelaide-fave | https://linkedin.com/in/adelaide-fave | 2025-12-08T06:22:40.485Z |  | 2024-12-03T18:23:55.869Z |  |  | 

---

