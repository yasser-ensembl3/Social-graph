# Kathy Marquis

## Position actuelle

**Titre** : Fondatrice et  productrice
**Entreprise** : urbnstudios
**Durée dans le rôle** : 2 years 8 months in role
**Durée dans l'entreprise** : 2 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Broadcast Media Production and Distribution

## Description du rôle

TON ONE - STOP - SHOP DANS L’UNIVERS DU BALADO ET DE LA PRODUCTION WEB.

## Résumé

Entrepreneure et animatrice, j’évolue dans l’univers des médias depuis plus de 15 ans. Productrice du podcast Génération Sidechick et fondatrice d’URBN, une boîte spécialisée en balados et contenu web, je maîtrise l’écosystème médiatique dans sa globalité. Avec mon expertise en vente, planification et créativité média, j’aide les marques à créer des contenus qui résonnent et qui performent.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA7eZJUBxaCoCEsQZgLdJX0wfGc7H31YHCg/
**Connexions partagées** : 27


---

# Kathy Marquis

## Position actuelle

**Entreprise** : urbnstudios

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Kathy Marquis

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401297397739331584 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG07hWIt9_yTg/feedshare-shrink_1280/B4EZraww1iJgAs-/0/1764606807820?e=1766620800&v=beta&t=CgwZttRXoF2Qa5iozpi2LSeuDWu7n-Gh_QOFb9xILV0 | Plusieurs l'ont demandé. Je l’ai fait!!

Après 16 ans à travailler dans les médias et 5 ans à mon compte comme pigiste, productrice, animatrice… alouette! Je me suis entourée des meilleurs pour offrir un véritable one-stop-shop dans l’univers des balados, urbnstudios

👉 URBN, c’est un studio de production niché chez notre partenaire Grandé Studio qui offre le meilleur côté technique et production. 

👉 C’est une division média qui accompagne les créateurs vers la monétisation de leur contenu et qui collabore avec les agents d’artistes, les agences, les diffuseurs et toute autre partie prenante.

👉 C’est aussi de l’accompagnement personnalisé en développement de marque originales et de la formation pour maîtriser l’art du podcast.

URBN, c’est exactement le type de hub collaboratif dont le marché avait besoin pour amener le médium du balado là où il doit être. Et il a été mis sur pied par des gens d’expérience dans le milieu… qui savent vraiment de quoi ils parlent !

Pour avoir un aperçu global de nos services, rendez-vous sur: www.urbnstudios.ca | 58 | 9 | 0 | 6d | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:06.972Z |  | 2025-12-01T16:33:29.077Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7393724290996527104 | Text |  |  | Quand j’ai commencé ma carrière dans les médias, il y a plus de quinze ans, j’avais la soif de réussir. J’enviais celles et ceux qui semblaient déjà être dans leur prime : un réseau solide, une carrière stable, des mandats stimulants… et de la « grosse argent ».
Je pensais que l’apogée d'une carrière, c’était ça. 
Aujourd’hui, je réalise que le “prime” dans notre industrie n’a plus la même signification et surtout, qu’il est loin d’être synonyme de sécurité.

Savais-tu que 60 % des demandes d’aide reçues par le Le bec proviennent de personnes âgées entre 30 et 49 ans?
Et que, parmi ces demandes, 60 % viennent de femmes?
Encore plus frappant : 80 % des services offerts aux Canadiens sont utilisés par des Québécois… alors que nous ne contribuons qu’à moins de 20 % de la levée de fonds annuelle du Le bec ? 

On parle ici de nous.
De nos amies, nos collègues, nos mentors. De femmes brillantes, compétentes, expérimentées, mais prises dans les réalités bien concrètes de :
 • licenciements massifs
 • coupures budgétaires
 • congé de maternité
 • rôle de proche aidante
 • transitions de carrière forcées

Est-ce vraiment surprenant que ce soient encore nous, les femmes, qui soyons pénalisées, même dans cette ère qu’on dit moderne?
Ce n’est pas un constat amer.
C’est un rappel que notre industrie est forte, mais notre solidarité doit l’être encore plus.
💛 On peut normaliser l’entraide.
 💛 On peut parler vrai.
 💛 Et on peut choisir de se soutenir, concrètement !

Si vous êtes en planif ou achat média, ou si vous influencez la stratégie de communication de votre entreprise : écrivez-moi.
Vous avez réellement le pouvoir de faire une différence! 

L’inventaire média multiplateforme du BEC est maintenant disponible pour 2026. 
En l'intégrant à vos plans, vous obtenez des placements de qualité tout en finançant directement :
• des ateliers professionnels
 • de l’accompagnement en développement de carrière
 • du soutien psychologique
 • de l’aide financière d’urgence
pour des gens de notre industrie.

Ce n’est pas de la charité. 
C’est prendre soin du milieu dans lequel on évolue, ensemble. ❤️

Contactez-moi pour recevoir la liste de l’inventaire disponible : kathy@bec-nabs.org | 24 | 1 | 1 | 3w | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:06.974Z |  | 2025-11-10T19:00:39.728Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7328473952849129474 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEikCQOlq5ChQ/feedshare-shrink_800/B4EZbP4OYKGQAg-/0/1747244345508?e=1766620800&v=beta&t=2BL2VSdUKBPi5x6qpzZo3QSOMl98Ofu1C9IfXmp14Zw | La semaine prochaine, je prendrai la parole à C2 Montréal!
Préparez-vous à des idées transformatrices, des connexions fortes et une bonne dose d’inspiration.
J'aurai non seulement le plaisir de m'entretenir avec des gens inspirants, mais je serai également sur place, pendant les trois jours, pour vous rencontrer.

Que ce soit pour un café, prendre une bouchée ou simplement venir me saluer, prendre rendez-vous avec moi via l’application C2 Montréal.  :) 

On s’y retrouve? 
#C2MTL25 #MakeYourMove | 46 | 1 | 0 | 6mo | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:10.198Z |  | 2025-05-14T17:39:06.821Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7321918815120863232 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGQgkhuejE14w/feedshare-shrink_800/B4EZZueta3GYAg-/0/1745610268024?e=1766620800&v=beta&t=wJMfuwsyQI3ZO_O6TBU8YOtZdt81P0Fwubew_mwOUbY | Bravo team LG2 pour ces nombreuses nominations. On peut y voir ma binette dans le cadre de la campagne National Bank of Canada | 10 | 0 | 0 | 7mo | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:10.198Z |  | 2025-04-26T15:31:20.198Z | https://www.linkedin.com/feed/update/urn:li:activity:7321620135536979968/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7302369562660909057 | Article |  |  | Très heureuse de joindre l’utile à l’agréable grâce à cette nomination. Merci à l’équipe du BEC pour sa confiance.

À toutes les agences et annonceurs, je vous invite à me contacter pour planifier votre prochaine campagne média. Nous disposons d’un inventaire premium à vous offrir, gracieusement offert par nos généreux donateurs.

kathy@bec-nabc.org

https://lnkd.in/ezdSmTnr | 4 | 1 | 0 | 9mo | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:10.199Z |  | 2025-03-03T16:49:35.204Z | https://www.grenier.qc.ca/actualites/47405/jennifer-hawtin-et-kathy-marquis-nommees-a-la-direction-de-la-vente-de-medias-nabs-bec |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7292182689032404992 | Text |  |  | Je suis très heureuse d’annoncer que je me suis jointe à l’équipe du Le bec en tant que directrice média.

Je suis fière de pouvoir contribuer au bien-être de mes collègues de l’industrie.

Étant dans le domaine depuis 15 ans, j’ai côtoyé de nombreux professionnels ayant souffert d’épuisement professionnel, de perte d’emploi, d’instabilité financière, et bien plus.

Pouvoir apporter ma contribution en offrant du soutien financier et psychologique, des ateliers, voire même des bourses pour le perfectionnement ou la réorientation de carrière me comble de joie.

Les demandes de soutien psychologique et financier ont considérablement augmenté ces dernières années. Plus que jamais, nous avons besoin de votre appui.

N’hésitez pas à me contacter pour la planification de votre prochaine campagne média. Grâce à nos généreux donateurs, nous pouvons vous offrir des placements privilégiés, multiplateformes, et les fonds recueillis sont directement remis à l’organisme. 

Merci de contribuer à la pérennité de notre industrie et, surtout, d’offrir un coup de pouce à vos collègues, amis et peut-être même à vous-même. 

kathy@bec-nabs.org 

______

I am very pleased to announce that I have joined the Le bec team as Media Director.

I am proud to contribute to the well-being of my colleagues in the industry. 

With 15 years of experience in the field, I have worked alongside many professionals who have faced burnout, job loss, financial instability, and more.

Being able to make a difference by offering financial and psychological support, workshops, and even scholarships for professional development or career transitions brings me great joy.

Requests for psychological and financial support have increased significantly in recent years. Now more than ever, we need your support.

Feel free to contact me to plan your next media campaign. Thanks to our generous donors, we can offer premium, multiplatform placements, and all funds go directly to the organization.

Thank you for contributing to the sustainability of our industry and, above all, for lending a helping hand to your colleagues, friends, and perhaps even yourself.

kathy@bec-nabs.org | 80 | 7 | 0 | 10mo | Post | Kathy Marquis | https://www.linkedin.com/in/kathy-marquis-b856606b | https://linkedin.com/in/kathy-marquis-b856606b | 2025-12-08T07:19:10.201Z |  | 2025-02-03T14:10:35.268Z |  |  | 

---



---

# Kathy Marquis
*urbnstudios*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [About Us — Urbsworks](https://www.urbsworks.com/about)
*2025-01-01*
- Category: article

### [Why I Left Architecture for Urban Design — Urbsworks](https://www.urbsworks.com/perspectives/blog-post-title-two-6n7mn)
*2023-11-27*
- Category: blog

### [Practice Notes: On Commercial Corridors](https://urbandesignforum.org/local-center-practice-notes-on-connected-corridors/)
*2024-05-03*
- Category: article

### [March 2023 | Urban Design Forum](https://urbandesignforum.org.nz/2023/03)
*2023-03-27*
- Category: article

### [In Conversation with UECo: Mark Maresca & Kathryn Faull | The Urban Electric Co.](https://blog.urbanelectric.com/mark-maresca-and-kathryn-faull)
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
