# Susan Williams

## Position actuelle

**Titre** : Founder
**Entreprise** : Booming Encore
**Durée dans le rôle** : 12 years 6 months in role
**Durée dans l'entreprise** : 12 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Online Media

## Résumé

Are you interested in living a long, healthy, and purposeful life?

Welcome to Booming Encore - a digital hub dedicated to redefining what it means to age and thrive in today’s longevity era.

I founded Booming Encore in 2013 because I saw a remarkable opportunity: as we live longer than any generation before us, we have the chance to completely reimagine what our later years can be. Our motto, “Every day matters,” reflects that belief.

Through articles, videos, and stories of interesting and extraordinary individuals, Booming Encore shares practical insights on health, wellness, purpose, and reinvention. Our goal is to help people design lives that are vibrant, meaningful, and filled with possibility - no matter their age.

What began as a passion project has grown, purely through organic reach, into a globally recognized authority on longevity, aging, and retirement. Along the way, I co-authored Retirement Heaven or Hell: Which Will You Choose? and continue contributing to Longevity Lifestyle by Design, helping people navigate this exciting new life stage.

Here’s what continues to surprise me: older adults now control roughly 70% of disposable income and hold over $46 trillion in wealth - yet only 5–10% of businesses actively engage with them. That’s a massive opportunity for change.

If you share my interest in longevity, purposeful living, or connecting with this influential demographic, let’s connect and collaborate.

#aging #retirement #longevity #purpose

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAU4FA4BYBTXiEmRSbmGkmWvrjoqh_DDlfw/
**Connexions partagées** : 10


---

# Susan Williams

## Position actuelle

**Entreprise** : Booming Encore

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Susan Williams
*Booming Encore*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 28 |

---

## 📚 Articles & Blog Posts

### [Susan Williams - Founder of Booming Encore](https://impakter.com/author/susan-williams/)
*2019-03-13*
- Category: article

### ["ReFire" Instead Of 'Just' Retire: Planning With Purpose](https://www.kitces.com/blog/refirement-reimagining-retirement-with-purpose-passion-planning-change-beginning-financial-advisor/)
*2025-05-28*
- Category: blog

### [The Wealthy Barber's big idea on the Sunday Reads.](https://cutthecrapinvesting.com/2025/11/16/the-wealthy-barbers-big-idea-on-the-sunday-reads/)
*2025-11-16*
- Category: article

### [Episode 16: Living Life Purposefully with Susan Williams — The Latest Version Podcast](https://www.thelatestversionpodcast.com/episodes/episode16-susan-williams-y3pax-ctd99-n4a7h-tyc4p-ah9fy-lb9sm-56f3k-43hzz-35c5x-jhf7f-xe275-sc2ft-fskjb)
*2022-02-10*
- Category: podcast

### [Embracing the Renaissance of Retirement](https://boomingencore.com/retirement-rebels/embracing-the-renaissance-of-retirement-a737fc4d-9121-4e74-aa69-5213e9acb8fd)
*2024-04-08*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Why is the Silver Tsunami a Constantly Overflowing Bucket?](https://www.retirementwisdom.com/why-the-silver-tsunami-is-more-like-a-constantly-overflowing-bucket/)**
  - Source: retirementwisdom.com
  - *Jun 5, 2017 ... CLICK HERE to hear our podcast! X. Retirement Wisdom. Retire Smarter ... Susan Williams is the Founder of Booming Encore – a website a...*

- **[5 Tips for Semi-Retirement | Retirement Wisdom](https://www.retirementwisdom.com/blogs/career-and-work/page/3/)**
  - Source: retirementwisdom.com
  - *May 3, 2019 ... ... podcast. Is the Real Issue Age or Competence? Retirement Wisdom ... Susan Williams is the Founder of Booming Encore – a website an...*

- **[Why We Need to Get Comfortable Talking About Death | Booming ...](https://boomingencore.com/why-we-need-to-get-comfortable-talking-about-death-00a4c6b2-7a87-4f94-9732-1ae43720c536)**
  - Source: boomingencore.com
  - *BOOMING ENCORE NEWS · Life Health Relationships Finances Technology Purpose Inspiration Retirement Rebels Opinions. ABOUT BOOMING ENCORE. About ......*

- **[IKIGAI - Book Review - Retirement Wisdom](https://www.retirementwisdom.com/books/ikigai/)**
  - Source: retirementwisdom.com
  - *Feb 26, 2018 ... CLICK HERE to hear our podcast! X. Retirement Wisdom. Retire ... I first learned the word Ikigai from Susan Williams of @Booming Enco...*

- **[Living Your Best Encore: Jayne Galanka | Booming Encore](https://boomingencore.com/living-your-best-encore-jayne-galanka-f2480460-456b-4c29-8f22-9812f3a89c3e)**
  - Source: boomingencore.com
  - *In this week's Booming Bites we're exploring why you may want to consider starting a business later in life, what life lessons Susan Williams has lear...*

- **[You Can't Do It Alone - WISE](https://wisentrepreneur.com/you-cant-do-it-alone/)**
  - Source: wisentrepreneur.com
  - *Susan Williams is the Founder of Booming Encore – a digital media hub dedicated to providing information and inspiration to help baby boomers create a...*

- **[Marketing to Older Consumers - Booming Encore](https://boomingencore.com/block-one-home-page/marketing-to-older-consumers-examples-of-companies-that-get-it-58f7b3e8-2e06-45f7-b8c7-c27d97371b32)**
  - Source: boomingencore.com
  - *... that marketers continue to ignore or insult them. But some companies are getting it right. Profile picture. Susan Williams. Founder, Booming Encor...*

- **[Arrowsmith Program - In the Media - Empowering Lives](https://www.empoweringlives.com.au/mediapress.html)**
  - Source: empoweringlives.com.au
  - *Elevate Podcast with Ramita Amand Canada, (22 June 2021). Picture ... Booming Encore Susan Williams (2020). Picture. NZ Herald Auckland, NZ (28 Feb .....*

- **[How Some Small Dietary Changes Can Positively Affect Both Our ...](https://boomingencore.com/block-one-home-page/how-some-small-dietary-changes-can-positively-affect-both-our-longevity-and-carbon-footprint-49143480-2e7c-4a07-88f3-5ee950a79c82)**
  - Source: boomingencore.com
  - *In this Booming Encore Learning Bites segment, Susan Williams speaks with ... podcast called "Standing By". Finances. Creating a Financial Legacy for ...*

- **[List of 60 Before 60 Project Experiences | Booming Encore](https://boomingencore.com/list-of-60-before-60-project-experiences-ebb4568b-293d-410b-8287-d4e15153757d)**
  - Source: boomingencore.com
  - *In November 2022, Booming Encore's Founder - Susan Williams turned 59. As ... #24 - Do a Radio Interview. #25 - Go on a Guided Walking Tour. #26 - Try...*

---

*Generated by Founder Scraper*
