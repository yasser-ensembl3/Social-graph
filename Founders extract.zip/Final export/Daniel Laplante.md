# Daniel Laplante

## Position actuelle

**Titre** : CEO / co-founder
**Entreprise** : booxi
**Durée dans le rôle** : 12 years 4 months in role
**Durée dans l'entreprise** : 12 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

We provide small service businesses and professionals a smart online appointment booking solution with a virtual business assistant.

Our mission is to help small businesses and professional focus on their expertise and accomplish more in less time.  Using artificial intelligence applied to business logic, we can unleash the power of a virtual assistant working for the professionals and businesses, as well as assisting administrative resources.

## Résumé

SaaS & Technology Entrepreneur.  Skills in Software Development, Product Management, International Business Development and Sales & Marketing.

First start-up in 1989 with a menu software for 8088 intel PC, followed by POS software (incl.rental and video store w/ central system), than video games until 1998 where I co-founded MITSTIC Software w/ Nick Bélanger. Created a RAD Studio and multi platforms technology used to develop video games (over 200 titles in 28 languages / 16,000 SKUs) and applications in the In-Flight Entertainment industry. 

As a start-up entrepreneur I learned about HR, IT, Financing, Legal, Sales, Marketing and Product Management among various aspects, and on the technical side, Software Development, Architecture, Integration, Design, QA, etc. MISTIC became DTI Software in 2001 where I was co-founder / CTO and gained experience in building partnership (w/ Panasonic Avionics, Thales, Rockwell Collins, and others), and conducted international business with 103 airlines, travelling around the world. DTI Software reached 95% market share before we sold in 2008 and exit 2012. 

The business culture I embrace is about respect, communication, collaboration and responsibilities; and a feeling that we each bring something IN and get something OUT. DTI Software was a great school for many to develop their expertise and themselves. It was hard work, preaching by example - we were a team, working for a common goal, and loving it.

I am now involved in a few start-up projects, putting skills and experience at profit in web SaaS platforms and mobile technologies.

Experience in: 
Start-up
Business Development
Partnership Management
Product Management
Marketing Strategy & Business Model
Project Management
Technical Marketing
Software Architecture & Development
Web & Mobile Technologies

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADP2vIBVqaKSyUrSJMw0bgi0zcjzedEXGQ/
**Connexions partagées** : 93


---

# Daniel Laplante

## Position actuelle

**Entreprise** : Booxi

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Daniel Laplante
*Booxi*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Daniel Laplante - CEO / Co-Founder at Booxi | The Org](https://theorg.com/org/booxi/org-chart/daniel-laplante)
*2024-11-12*
- Category: article

### [Daniel Laplante - Contact Information](https://leadsforge.ai/contact/daniel-laplante-7ee453ff)
*2025-01-01*
- Category: article

### [Daniel Laplante | booxi | Email, CEO](https://www4.lead411.com/Daniel_Laplante_55206581.html)
*2025-01-01*
- Category: article

### [Daniel Laplante Email & Phone Number | booxi - CEO / co-founder - ContactOut](https://contactout.com/Daniel-Laplante-32855343)
*2023-12-01*
- Category: article

### [Booxi CEO, Founder, Key Executive Team, Board of Directors & Employees](https://www.cbinsights.com/company/booxi/people)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Previously bootstrapped, appointment booking solution Booxi raises ...](https://betakit.com/previously-bootstrapped-appointment-booking-solution-booxi-raises-1-5-million/)**
  - Source: betakit.com
  - *Nov 25, 2021 ... – Daniel Laplante. The $1.5 million represents Booxi's first institutional financing to date as the startup claims to have been boots...*

- **[SaaSpasse chez Booxi](https://www.saaspasse.com/startups/booxi)**
  - Source: saaspasse.com
  - *Daniel Laplante. CEO, co-fondateur. Marc-André B. CTO, co-fondateur. Suivre. Booxi. Offres d'emploi chez Booxi. Aucun emploi. Restez à l'affut. Tech s...*

- **[S|W: The SaaS Weekly - Hootsuite IPO plans now a 2022 resolution ...](https://betakit.com/sw-the-saas-weekly-hootsuite-ipo-plans-now-a-2022-resolution/)**
  - Source: betakit.com
  - *Nov 30, 2021 ... Previously bootstrapped, appointment booking solution Booxi raises $1.5 million (BETAKIT). The company was founded in 2013 by Daniel ...*

- **[80 Top Wellness Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/wellness/canada/co)**
  - Source: f6s.com
  - *7 days ago ... Daniel Laplante | F6S - Images Elie P | F6S - Images. Meet Daniel and Elie that work here. ​​Booxi ... podcasts, infographics, texts, e...*

- **[100 Top Fashion Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/fashion/canada/co)**
  - Source: f6s.com
  - *7 days ago ... booxi · See full page People, funding & more. Make Commerce More Human ... Engage differently with smart appointment booking. Daniel La...*

- **[About Booxi — Appointment Scheduling Software](https://www.booxi.com/about)**
  - Source: booxi.com
  - *Daniel Laplante CEO / co-founder Booxi. Daniel Laplante. Co-founder & CPO ... your customer experience? Talk To an Expert. Join our newsletter. Sign u...*

- **[Daniel Laplante - CEO / co-founder @ Booxi - Crunchbase Person ...](https://www.crunchbase.com/person/daniel-laplante)**
  - Source: crunchbase.com
  - *Daniel Laplante - CEO / co-founder @ Booxi. ... Talk With Sales. What We Do. Crunchbase Pro · Crunchbase Business · Marketplace · Data Licensing · Cus...*

- **[Appointment Shopping: A Guide for Retailers | Lightspeed](https://www.lightspeedhq.com/uk/blog/retail-appointment-shopping/)**
  - Source: lightspeedhq.com
  - *Feb 5, 2021 ... We spoke to Lace and Day, a lingerie store in Buffalo, NY; Daniel Laplante, co-founder and CEO at booxi ... While in-person small talk...*

- **[100 Top Retail Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/retail/canada/co)**
  - Source: f6s.com
  - *7 days ago ... Daniel Laplante | F6S - Images Elie P | F6S - Images. Meet Daniel and Elie that work here. ​​Booxi ... conference venues. We help our c...*

- **[Booxi Raises $1.5M Backed by Investissement Québec](https://www.booxi.com/blog/booxi-raises-1-5m-with-support-from-investissement-quebec-and-bdc)**
  - Source: booxi.com
  - *'' says Daniel Laplante, Co-Founder and CEO at Booxi. ''We've established ... BlogGuides & ToolsSuccess storiesSystem statusSupport. © 2025 Booxi ......*

---

*Generated by Founder Scraper*
