# Mohamed Sabri

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Rocket Science Development
**Durée dans le rôle** : 4 years 9 months in role
**Durée dans l'entreprise** : 4 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT System Custom Software Development

## Résumé

I solve complex machine learning problems. 

Founder of Rocket Science & the MLOps Institute, I am developing the new generation of MLOps Engineers. 

A Data Science Mentor at MIT, I wrote the book on Data Science essentials called “Data Science Pocket Guide” available on Amazon. 

If your dream is to work for FAAMG, join the MLOps Institute → https://join.slack.com/t/mlopsinstitute/shared_invite/zt-14cc9zrhc-hqdgm8Ht3DOpV40AmHMuIA

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAzTtKYBIjzeUAKwkKiPFLpKMNAFFluHOSs/
**Connexions partagées** : 90


---

# Mohamed Sabri

## Position actuelle

**Entreprise** : Rocket Science Development

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mohamed Sabri

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401666467961704448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEfP3VveqKvlA/feedshare-shrink_800/B4EZraPkgaKMAg-/0/1764598107072?e=1766620800&v=beta&t=EuNCrXBbiO9njzjdV5bcj1MlckTXpmlXAGct5DsLALI | La semaine dernière, j’ai eu le plaisir d’offrir une formation complète d'une demi-journée sur l’utilisation stratégique de ChatGPT aux équipes de la MRC de Montmagny. Cette session en ligne a permis d’explorer les capacités réelles de l’IA générative, de comprendre comment l’intégrer concrètement dans les opérations quotidiennes et d’identifier des gains rapides pour améliorer l’efficacité et la qualité du service.

J’ai été impressionné par la curiosité, l’ouverture et l’engagement des participants. Leur volonté d’adopter l’intelligence artificielle de manière responsable et efficace démontre une vision moderne et tournée vers l’avenir. C’est exactement ce type de collaboration qui permet de transformer la technologie en levier concret d’innovation.

Merci à la MRC de Montmagny pour son accueil et son intérêt marqué pour l’IA. Merci également à Rocket Science Development pour le soutien continu dans la mission de démocratiser l’intelligence artificielle et d’accompagner les organisations québécoises dans leur transition numérique.

Heureux de contribuer à renforcer les compétences en IA partout au Québec, un atelier à la fois. | 10 | 0 | 3 | 5d | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:03.420Z |  | 2025-12-02T17:00:02.275Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399129796473122816 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGCYcb0sJvvPA/feedshare-shrink_800/B56ZqnUGctJQAk-/0/1763743663280?e=1766620800&v=beta&t=RuNXwFRX0rAPyLbtKC42xT0zlJYaPZOpHdiEyL-kpuM | Un grand plaisir d’avoir été exposant à la conférence sur l’intelligence artificielle Les Affaires. Une journée riche en discussions stratégiques, en rencontres de qualité et en perspectives concrètes sur l’impact de l’IA dans nos organisations.

Merci aux participants, aux organisateurs et à tous ceux qui sont venus échanger avec nous. L’enthousiasme autour de l’IA continue de grandir, et c’est un privilège de contribuer à cette transformation.

Au plaisir de poursuivre les conversations et de bâtir ensemble les prochaines étapes de l’innovation. 🚀 Rocket Science Development | 53 | 1 | 0 | 1w | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:03.421Z |  | 2025-11-25T17:00:12.663Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396593035343568897 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEioTCiMiz3SA/feedshare-shrink_800/B4EZqM.rb8IoAg-/0/1763301833105?e=1766620800&v=beta&t=dddgtKE8xXVCHa35Qm79vML09NNoj3h3emeltbz4KMU | Un immense merci à toutes celles et ceux qui ont participé à notre conférence « Plongée dans l’IA Agentique » du 13 novembre. En partenariat avec Databricks Hewlett Packard Enterprise TELUS Business. Votre présence, votre curiosité et la profondeur des échanges ont réellement donné vie à cette journée.
Merci également à nos conférenciers et experts qui ont partagé leurs visions et leurs expériences avec une grande générosité. Vous avez permis de montrer, de manière concrète, à quel point l’IA agentique transforme déjà les organisations et ouvre des perspectives audacieuses pour l’avenir.
Chez Rocket Science Development, nous croyons que ce n’est que le début. L’IA agentique redéfinit la manière dont les entreprises innovent, collaborent et créent de la valeur. Et voir autant de leaders, de décideurs et de passionnés réunis autour de ce sujet confirme que le Québec et le Canada sont prêts à passer à la prochaine étape.
Merci encore pour votre énergie, vos questions et vos discussions inspirantes. Nous avons déjà hâte de vous revoir… et surtout de continuer à bâtir ensemble les solutions qui feront la différence.

Alexandre Guilbault Philippe Habra Steve  Emmanuel Tchokoani Siebatcheu Noubissie Fatih Nayebi Dong Qiao Yang Chad Lortie Patrick Chenel JS Patenaude Florent Tastet | 54 | 1 | 2 | 2w | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:03.422Z |  | 2025-11-18T17:00:01.679Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394056387971932160 | Article |  |  | Le budget fédéral 2025 révèle un paradoxe fascinant : Ottawa mise tout sur l'innovation pour relancer une productivité en berne, mais arrive-t-il 5 ans trop tard?
Avec 925M$ pour une infrastructure IA "souveraine" et un RS&DE bonifié à 4,5M$, le gouvernement tente visiblement de rattraper son retard face aux géants américains qui ont déjà investi des dizaines de milliards dans l'IA générative.
3 signaux forts à décoder:
Le timing n'est pas anodin. Ce budget arrive alors que les États-Unis menacent d'imposer des tarifs douaniers supplémentaires et que notre productivité stagne depuis une décennie. Le "Fonds de réponse stratégique" de 5G$ n'est pas qu'un programme d'aide - c'est un aveu que notre dépendance commerciale est devenue une vulnérabilité existentielle.
L'infrastructure IA souveraine soulève une question critique: peut-on vraiment rivaliser avec les hyperscalers américains? La réalité est que nos entreprises continueront d'utiliser AWS et Azure. Ce "nuage canadien" servira surtout aux données gouvernementales sensibles et à quelques secteurs réglementés. C'est nécessaire, mais insuffisant pour créer un avantage compétitif.
La vraie innovation de ce budget? La reconnaissance implicite que le modèle canadien de R&D académique déconnectée du marché a échoué. Les nouvelles mesures forcent la commercialisation: superdéduction pour l'équipement productif (pas juste la recherche), focus sur la PI exploitable, et surtout, l'intégration de la défense (30G$) comme moteur d'innovation appliquée.
L'angle mort qui devrait nous inquiéter:
Pendant qu'on bonifie des crédits d'impôt, la Chine et les États-Unis se battent pour dominer l'IA générative, le quantique et les semi-conducteurs. Notre stratégie reste défensive - protéger ce qu'on a plutôt que conquérir de nouveaux territoires technologiques.
Le Québec, avec Mila et son écosystème IA, est paradoxalement mieux positionné que le reste du Canada. Mais attention: avoir inventé le deep learning ne garantit pas qu'on en capturera la valeur économique. Yoshua Bengio nous l'a assez répété.
La vraie question: Ces milliards créeront-ils des champions technologiques canadiens ou subventionneront-ils simplement des filiales qui développent de la PI pour leurs maisons-mères étrangères?
Le budget pose les bonnes fondations. Mais sans une ambition d'échelle mondiale et une tolérance au risque radicalement différente, on restera des fournisseurs de talents pour la Silicon Valley.
Qu'en pensez-vous?

Pour plus de lecture sur l'analyse du conseil de l'innovation du Québec: https://lnkd.in/ekRXx3zT

#StratégieTech #InnovationCanada #CompétitivitéÉconomique #SouverainetéNumérique | 11 | 0 | 0 | 3w | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:03.423Z |  | 2025-11-11T17:00:17.817Z | https://conseilinnovation.quebec/budget-federal-2025-linnovation-comme-moteur-de-croissance-ce-quil-faut-retenir/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7391519644651634688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF1AL7kwY1-kA/feedshare-shrink_800/B4EZoO7wVsIQAk-/0/1761187137447?e=1766620800&v=beta&t=2kN_GcNFau6oHHbAMgb0LbLOhxQSaFiIaezCYNFNKWg | 🎓✨ L’éducation francophone à l’ère de l’intelligence artificielle
Je suis honoré de coprésenter une table ronde au 3e Forum Franco-Ontarien organisé par eCampusOntario sur le thème :
 « Regards croisés sur les compétences du futur : (re)penser l’éducation francophone à l’ère de l’intelligence artificielle »
Dans un monde où l’IA transforme nos façons d’apprendre, de travailler et de créer, il devient essentiel de repenser la formation et les compétences nécessaires pour les générations futures.
Je partagerai ma vision en tant que fondateur de Rocket Science, expert en intelligence artificielle, leaders passionnés d’innovation et d’éducation.
📅 3e Forum Franco-Ontarien – Innover l’éducation pour demain

Rejoignez-nous pour imaginer ensemble l’avenir de l’éducation francophone à l’ère de l’IA. 🚀
#Éducation #IA #Innovation #Francophonie #ForumFrancoOntarien #RocketScience #MIT #Apprentissage #CompétencesDuFutur | 10 | 0 | 1 | 1mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:03.423Z |  | 2025-11-04T17:00:11.079Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7386431207636623360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhNqro8Frsog/feedshare-shrink_800/B4EZnz52dOIUAg-/0/1760733657984?e=1766620800&v=beta&t=fTd6T6cto1ZSn_-OsPZu5Z2tEOqA3aJasoZ76c-RUxU | 🚀 La semaine dernière, on a fait notre 5@7 trimestriel chez Rocket Science Development !
Près de 60 personnes, une ambiance de feu, de quoi boire, de quoi manger… et surtout des belles personnes ❤️

Pour une fois, j’ai laissé Momo l’astronaute au placard 👨‍🚀😅
Merci à tous ceux qui sont venus — c’est toujours un plaisir de se retrouver entre passionnés d’IA, de projets fous et de bonne vibe.

À la prochaine mission 🌌
#RocketScience #AICommunity #TeamVibes #Innovation | 41 | 0 | 0 | 1mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.953Z |  | 2025-10-21T16:00:33.156Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7383894365804339200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErcZs4ePRMTg/feedshare-shrink_800/B4EZnT8kJLGcAg-/0/1760197493878?e=1766620800&v=beta&t=QtZfNqjhpxpAGOMVCy4Rkpo_ln5OFHw7ygLf9dHi080 | ChatGPT sur des cas d’usage simples ou en sandbox, cela peut sembler abordable, mais croyez-moi, dans des cas réels, la facture grimpe très vite.

Le plus ironique, c’est qu’après avoir dépensé des millions de dollars, on vous envoie un trophée…

Croyez-le : une fois que vous atteignez le trillion de tokens, il vaut bien mieux investir dans des experts en LLM et construire votre propre modèle fine-tuned. Le retour sur investissement est là.

C’est du pur non-sens autrement. | 15 | 0 | 0 | 1mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.954Z |  | 2025-10-14T16:00:02.931Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7381357659897360384 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKELsQGbHMYw/feedshare-shrink_800/B4EZm2YLnEGoAg-/0/1759701423954?e=1766620800&v=beta&t=E4qdyJgFoR5hN9IU_rWh9pUm_yzaFM3nWquCjUq6u4A | 🚀 Quel privilège d’avoir participé comme juge au NASA International Space Apps Challenge 2025 !

En tant que juré, j’ai eu l’occasion de découvrir des projets brillants, portés par des équipes passionnées, ingénieuses et audacieuses. Que ce soit dans les domaines de l’analyse de données spatiales, de la durabilité, de l’exploration ou de la technologie, j’ai été impressionné par la créativité et la rigueur de chacune des propositions.

Un grand bravo à tous les participant·es pour leurs efforts, leur esprit collaboratif et leur vision. Vous êtes la preuve que l’innovation et la passion peuvent s’allier pour repousser les frontières du possible.

Merci également aux organisateurs pour cette plateforme inspirante, et pour le soin porté à l’accompagnement des équipes.

Un clin d’œil Collège LaSalle, Montréal à Rocket Science Development — hâte de retrouver vos talents lors des prochaines éditions !

#NASASpaceApps #Innovation #Technologie #Espace #Jugement #Collaboration #FutureMakers | 45 | 2 | 2 | 2mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.955Z |  | 2025-10-07T16:00:05.113Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7376284308442882050 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFHdyJwqnbQgA/feedshare-shrink_2048_1536/B4EZlJbFz4IIAw-/0/1757873463790?e=1766620800&v=beta&t=qimwrYkMKGzGYn6ASKTSnlMFkkuLmNBNFqWPJA_VZsg | C’est toujours une fierté de voir le Canada reconnu comme l’un des pays les plus aimés au monde. L’ère Trudiste porte ses fruits, comme on peut le constater. Mais dans une longue réflexion personnelle, je me demande : est-ce que nous, Canadiens, nous nous aimons vraiment ? Est-ce que nous aimons suffisamment notre pays en ce moment ?
Le minimum serait de continuer à cultiver cet amour de soi collectif, à être fiers de ce que nous sommes et à le montrer dans nos gestes du quotidien. Aimer le Canada, ce n’est pas seulement se réjouir de sa réputation à l’étranger, c’est aussi prendre soin de notre diversité, protéger nos valeurs de liberté et d’égalité, et contribuer chacun à sa manière à renforcer le tissu social qui nous unit.
Peut-être que la vraie question n’est pas seulement de savoir si le monde nous aime, mais si nous, Canadiens, sommes capables d’entretenir cette flamme de respect, d’engagement et de confiance envers notre propre pays. Car c’est dans ce miroir-là que se joue l’avenir du Canada. | 9 | 0 | 1 | 2mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.956Z |  | 2025-09-23T16:00:23.868Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7373747588623405057 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGrCv0Y6FltYg/feedshare-shrink_800/B4DZk0O2ZMGgAo-/0/1757517932742?e=1766620800&v=beta&t=C5oWvJw4U-8xOW6MeDyNsDPWI3JfmOHXrHLDtpDL3Zo | 🚀 Rocket Science Development présente une soirée exclusive dédiée à l’intelligence artificielle !
📅 Le 16 octobre 2025
 📍 Espace Rodier, Montréal
 🕖 17h30 à 21h00
Joignez-vous à nous pour une soirée de réseautage unique qui réunira chercheurs, entrepreneurs, décideurs et passionnés d’IA. Une occasion privilégiée de connecter les écosystèmes du Québec, d’échanger sur les tendances actuelles et de bâtir ensemble les projets de demain.
✨ Au programme :
 – Discussions ouvertes sur les enjeux et opportunités de l’IA
 – Témoignages et partages d’expériences par des acteurs clés
 – Cocktail réseautage pour multiplier les connexions
Cet événement est rendu possible grâce à nos partenaires : Hewlett Packard Enterprise et Databricks
🎟️ Réservez votre place dès maintenant :
 👉 https://lnkd.in/dT8JJb5e | 32 | 0 | 2 | 2mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.957Z |  | 2025-09-16T16:00:22.733Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7371210830060892160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGJAaFanPbZVQ/feedshare-shrink_800/B4EZkqVBDqHEAo-/0/1757351777896?e=1766620800&v=beta&t=DCZP2zYVICMCuKOJ2osxLATVsskOckJSrZ_wyPBKN6w | 🚀 Rocket Science sera présent à ALL IN les 24 et 25 septembre prochains à Montréal !
Venez nous rencontrer pour discuter d’intelligence artificielle, de gouvernance et d’innovation au service des entreprises.
 C’est l’occasion idéale d’échanger sur vos enjeux, découvrir nos projets, et explorer ensemble l’avenir de l’IA.
🌌 Le 24 septembre au soir, nous organisons également un 5@7 exclusif pour prolonger les discussions dans un cadre convivial.
🍌 Et parce qu’on aime surprendre, nous avons préparé notre fameux effet banane, cette fois-ci sur le thème de l’espace… un clin d’œil à l’ADN créatif de Rocket Science Development.
📅 On se voit à ALL IN ?
#ALLIN2025 #IA #Innovation #RocketScience | 14 | 1 | 3 | 2mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.958Z |  | 2025-09-09T16:00:12.361Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7368674130176557056 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHw-HJ7ObnzVg/feedshare-shrink_800/B4EZkFk3YCGwAg-/0/1756735178480?e=1766620800&v=beta&t=zP2uFNEeFz-NStVZMbQSoh3-Qu_XH9rT_7jlo02Mx8w | Au cours de la dernière année, nous avons eu le privilège d’accompagner pardeux e-learning │ gamification, une entreprise d’ici spécialisée en e-learning et gamification, menée par une entrepreneure d’exception : Nathalie Lessard.
✨ Ensemble, nous avons intégré l’IA pour optimiser les processus internes et enrichir les expériences d’apprentissage. Résultat : des formations plus personnalisées, engageantes et créatives, qui permettent à pardeux de se démarquer encore davantage.
🤝 Au-delà de la technologie, c’est une vision commune qui nous unit : faire rayonner le savoir-faire local en conjuguant créativité et intelligence artificielle.
L’avenir de pardeux e-learning │ gamification s’annonce prometteur, et nous sommes fiers de soutenir une équipe audacieuse qui repousse sans cesse les limites de l’apprentissage numérique. 💫 | 15 | 0 | 0 | 3mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.959Z |  | 2025-09-02T16:00:15.979Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7366137368543768576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFaDGEsmlUz1w/feedshare-shrink_800/B4EZjhbVVgHoAk-/0/1756128697294?e=1766620800&v=beta&t=DIWYzX-eX19nfgVeNkQ3GqRoBMvRkJeQ5wqNK2NKUZ4 | Le fantasme ultime de tout entrepreneur ou dirigeant : un revenu par employé de 102 millions $ US par an.
 Il faut dire que ce chiffre fait rêver. Avec une telle rentabilité par employé, on imagine aisément le salaire et les avantages de ceux qui travaillent dans ces entreprises.
Bien sûr, il existe les champions de l’efficacité et de la rentabilité, comme Nvidia ou Apple, mais aussi des anomalies statistiques comme Tether ou Hyperliquid.
Toutes industries confondues (médiane) :
Le revenu généré par employé se situe autour de 310 000 $.
Il est valorisé à 564 706 $ pour les entreprises les plus performantes, et à 176 471 $ dans le quartile inférieur.
Les startups SaaS (privées) tournent plutôt autour de 130 000 $.
Je n’ai pas trouvé de chiffres spécifiques pour le Canada, mais la règle empirique veut qu’au-delà de 200 000 $ CAD par employé et par an, on considère cela comme une bonne performance, et qu’en dessous de ce seuil, on parle d’une entreprise « en devenir ».
La métrique du revenu par employé est un excellent indicateur de performance. C’est une donnée que j’utilise souvent. | 18 | 1 | 1 | 3mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.960Z |  | 2025-08-26T16:00:04.875Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7363600657343246336 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHEWeKhVPIP6g/feedshare-shrink_800/B4DZi9rfDoGsAg-/0/1755528951173?e=1766620800&v=beta&t=hO9I8uvBIB0ULAfn5OOOW9BmTqlm1Vz2tGiQ_aKHPMo | 🚀 Fiers d’accompagner LEMNY !
 
Chez Rocket Science Development, nous avons le plaisir de soutenir LEMNY dans le déploiement de solutions GenAI et IA agentique (AgenticIA) pour accélérer et fiabiliser la gestion de projets en construction.
🎯 Objectif clair : transformer LEMNY en entreprise 4.0.
 
🏗️ À propos de LEMNY
Experte en gestion de projet, surintendance de chantier et droit de la construction, l’équipe LEMNY est reconnue pour livrer des projets à prix compétitif avec un haut standard de qualité. Avec 25+ années d’expérience collective dans l’industrie et 4 000+ unités livrées, LEMNY possède le savoir-faire pour mener à bien les projets les plus exigeants.
 
#GenAI #IAAgentique #Construction #GestionDeProjet #Entreprise40 #ConTech #Productivité #Innovation | 12 | 0 | 0 | 3mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.961Z |  | 2025-08-19T16:00:05.795Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7355990540401688576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFBs8E55AQcsg/feedshare-shrink_800/B4EZhCVVItGYAg-/0/1753459545113?e=1766620800&v=beta&t=rIPQzjsRYa9i-0QdbFjlx7twuXa2D5KUCYnoeWE1cWM | Dans le cadre de discussions corsées dans mes affaires récemment, j’ai découvert que j’avais été enregistré à mon insu grâce à un appareil Plaud. J’ai constaté que la technologie d’enregistrement et de transcription vocale est revenue à la mode, un peu comme à l’époque des dictaphones.
 
Mais revenons à mes affaires : j’étais furieux, car la personne en question était de mauvaise foi. Elle ne m’a pas enregistré pour prendre des notes de réunion, mais pour tenter de prouver un point dans le cadre d’une affaire en cours. Pire encore, elle m’a menti en prétendant qu’elle enregistrait « toutes ses réunions ». 

Il y a un véritable enjeu de sécurité et de gouvernance ici.
 
D’abord, on ne peut pas enregistrer la voix des gens sans leur consentement. Plaud ne fait pas que « prendre des notes » — cela enregistre intégralement la voix. L’un de mes avocats l’a bien compris : il a toujours le réflexe de scruter le col et la chemise de ses clients, à la recherche de ces parasites technologiques. Et il a entièrement raison.
 
Ensuite, après mes recherches, j’ai découvert que Plaud est une entreprise américaine (Nicebuild LLC). J’ai même lu sur certains forums qu’il existerait un doute quant à une origine chinoise de l’entreprise, mais je n’ai trouvé aucune source fiable à ce sujet. Et bien que les données soient stockées localement, la version Cloud transfère tout vers des serveurs AWS situés aux États-Unis. Par les temps qui courent, soyons clairs : on n’est jamais trop prudent, ni trop paranoïaque.
 
Je considère que dans des environnements corporatifs, Plaud peut avoir sa place pour des sessions de brainstorming ou des réunions agiles, mais certainement pas dans des rencontres exécutives ou sensibles. C’est là que l’enjeu devient critique.
 
Car, selon les règles corporatives, les enregistrements audio et les transcriptions de réunions sont considérés comme des données d’entreprise. Si vous les transférez vers des serveurs AWS aux États-Unis, vous êtes en infraction avec les politiques internes de sécurité des données. Point.
 
Alors si vous vous sentez visé par ce message en tant qu’utilisateur de Plaud, faites-moi une faveur :
allez vous dénoncer immédiatement aux TI, donnez-leur accès à votre compte Plaud si cela vous est demandé, et présentez vos excuses.
Soyez rassuré : la technologie est encore récente, et probablement pas encore couverte explicitement par les politiques internes. Au pire, vous recevrez une tape sur les doigts. Mais mieux vaut prévenir que guérir.
 
Et pour être serein : trouvez une alternative canadienne.
Achetez local, bon sang ! Achetez local ! | 28 | 20 | 0 | 4mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.961Z |  | 2025-07-29T16:00:12.527Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7353453836558082049 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2af1526a-7294-42bb-82ae-bf826e073e4c | https://media.licdn.com/dms/image/v2/D4E05AQE8IkxUQqZWDw/videocover-low/B4EZguaDkmGoCI-/0/1753125241932?e=1765774800&v=beta&t=InQJCUlLDyvtmgu4n66PFuqJ6aZB6-_b8ssBo77BjRw | Gestion de projet en IA : êtes-vous un 747 ou un 737 ?

Dans cette vidéo, un Boeing 747-400 décolle avec une puissance brute impressionnante. À ses côtés, un 737-800 s’élance plus discrètement, mais avec une redoutable efficacité.
👉 Le 747, c’est le projet IA ambitieux, lourd, à forte visibilité. Il nécessite des mois de préparation, une équipe complète, une infrastructure robuste… et un budget en conséquence.
👉 Le 737, c’est le projet agile, ciblé, rapide à mettre en œuvre. Moins spectaculaire, mais parfaitement adapté à son objectif et souvent plus rentable à court terme.
✈️ Dans vos projets IA, l’important n’est pas de faire du bruit, mais de bien décoller.
 #AviationMeetsAI #GestionDeProjet #IntelligenceArtificielle #Agilité #StratégieIA | 28 | 6 | 2 | 4mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:05.962Z |  | 2025-07-22T16:00:15.201Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7350917085608198146 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEV1qlTcg5v8A/feedshare-shrink_2048_1536/B4EZf6ClVdGwAs-/0/1752246671151?e=1766620800&v=beta&t=sl65NDjsb7yXnS28BtjLw4WCRXxpzaD2WEiF-5D47A0 | Le fait même qu’on dise aujourd’hui qu’il n’y a plus assez de données pour entraîner les IA marque un point de rupture fondamental dans l’évolution de l’algorithmie. Le modèle traditionnel consistant à entraîner une intelligence artificielle sur de grandes quantités de données a atteint ses limites. Je suis convaincu que le moment est venu pour une innovation majeure, une transformation radicale qui remplacera définitivement cette approche dite de « training ».
 
Et pour cela, il suffit d’observer ce que la nature a déjà parfaitement conçu : le cerveau humain.
Voici quelques pistes inspirantes :
 
Raisonnement abductif : la capacité à formuler des hypothèses plausibles à partir d’observations incomplètes.
 
Pensée générative : l’aptitude à créer des idées nouvelles ou des représentations mentales sans les avoir apprises.
 
Apprentissage constructiviste (déjà partiellement exploré via le incremental/continuous learning) : comme chez l’enfant, qui construit ses modèles mentaux par interaction directe avec le monde, sans base de connaissances préexistante.
 
Théorie de l’esprit : cette faculté d’imaginer ce que pense ou ressent autrui, sans jamais l’avoir expérimenté soi-même.
 
Modélisation bayésienne intuitive : le cerveau émet des hypothèses probabilistes et les ajuste en temps réel, même sans jeu de données complet.
 
L’intelligence artificielle évolue à une vitesse vertigineuse, et tous les deux ou trois ans, nous assistons à une nouvelle révolution. La prochaine approche de rupture est proche. Et elle sera, à mon avis, plus humaine que jamais. | 21 | 2 | 2 | 4mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:08.059Z |  | 2025-07-15T16:00:06.644Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7348380380334317568 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQERD29t_XrMuw/feedshare-shrink_800/B4EZeyEyIlHYAk-/0/1751039289530?e=1766620800&v=beta&t=Q66B_DtRfn-Mv7Q7EnVnvRN57clob6BVbmDkr-Oixu8 | 💡 DeepSeek est-il conforme aux standards canadiens ?
C’est la question à laquelle nous avons tenté de répondre lors de notre dernier webinaire technique dédié à l’audit de l’outil DeepSeek.
 Un moment riche en échanges et en découvertes, où nous avons analysé en profondeur :
✅ Le fonctionnement interne de DeepSeek-R1
 ✅ Les limites réglementaires canadiennes (gouvernance, confidentialité, biais, données)
 ✅ Ce qu’un audit rigoureux implique pour un LLM dans un contexte d’entreprise publique ou réglementée
 ✅ Comment adapter DeepSeek à un cadre de conformité local
📽️ Vous avez manqué le webinaire ? Bonne nouvelle : il est maintenant accessible en rediffusion ici :
 👉 https://lnkd.in/eh6zW5CD | 4 | 1 | 0 | 4mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:08.060Z |  | 2025-07-08T16:00:08.977Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7346909525897101314 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fc68a635-b487-4fcc-a4a0-fff8ba7318c5 | https://media.licdn.com/dms/image/v2/D4E05AQHk2hee7dH33g/videocover-high/B4EZfV3QYyG4CI-/0/1751639723734?e=1765778400&v=beta&t=HMhnkxU8ISzwx9SKVVW1rzYeQYKYBHZ79DE2M17hxKg | Une petite coupe de cheveux façon Rocket Science Development?
Découvrez notre tout nouveau concept : le Rocket Barber, pour hommes et femmes !

Venez nombreux vous faire coiffer par notre robot coiffeur futuriste.
Une expérience unique à ne pas manquer !

Bon weekend ! | 12 | 7 | 2 | 5mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:08.061Z |  | 2025-07-04T14:35:29.952Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7345843685651079169 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVdVDI5yeFAA/feedshare-shrink_800/B4EZeeENnVGwAg-/0/1750703594698?e=1766620800&v=beta&t=yKyRIR3AKdCaHTKPUL1VtDf_6PQi435CjkS708y8xSk | J’aime cette photo, car elle illustre bien ce que pourrait être l’avenir du monde du travail grâce à l’intelligence artificielle.

En tant que chevaux, nous serons enfin occupés à profiter de la vie plutôt qu’à tirer des charrues. Vivement la société post-laborale.

Crédit de la photo Philippe Beaudoin | 10 | 0 | 0 | 5mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:08.062Z |  | 2025-07-01T16:00:13.835Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7343306998307848193 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEaobz2J1cfeQ/feedshare-shrink_800/B4EZcyTECUG4Ag-/0/1748895549532?e=1766620800&v=beta&t=4MwkgJKWzJ95AfloiikKnmOgA-qNFJDDfyEsS9jepVQ | Je pense sincèrement que la culture québécoise est en train de se perdre.

Il y a quelque temps, lors d’un appel, on discutait de la disparition des cultures autochtones, que certaines langues autochtones étaient en voie de disparition. Et j’ai eu envie de dire : ce n’est pas juste la culture autochtone qui se dilue, c’est toute la culture québécoise qui est en train de s’effacer.

Posez la question autour de vous : « C’est quoi, la culture québécoise ? »
Les réponses qu’on entend, pour ceux qui s’y essaient encore, tournent autour de la poutine, des cabanes à sucre, ou des Cowboys Fringants. Et encore, ça, c’est pour les plus informés. Le reste ? Silence radio. On gratte la surface, mais on n’a plus de racines.

Mais attention : le problème n’est pas l’immigration, ni les Arabes, ni les Noirs, ni les Juifs, ni qui que ce soit.
Prenons un raisonnement par l’absurde : imaginons que demain, M. Legault proclame l’islam religion d’État au Québec. Combien de Québécois changeraient de foi et adopteraient cette culture ? À peine 10 %, peut-être 20 % dans le meilleur des cas. Ce simple exemple montre une vérité : une culture forte n’est pas remplacée, elle se renforce. Les minorités culturelles au Québec sont riches, vibrantes, parfois même très visibles — mais jamais envahissantes.

Le vrai danger, c’est l’américanisation.
On mange comme les Américains. On s’habille comme eux. On regarde leurs séries, on utilise leurs mots au travail. On s’excuse en anglais avant même de se défendre en français. Et pendant ce temps-là, notre culture se dilue lentement dans l’oubli collectif.

Investir dans la culture québécoise, c’est un acte de souveraineté.
C’est une souveraineté identitaire, culturelle, symbolique. Oui, des efforts sont faits pour protéger la langue, soutenir les artistes, promouvoir notre histoire. Mais soyons honnêtes : c’est loin d’être suffisant. Il faut rallier les masses, redonner aux gens le goût d’être Québécois au-delà du folklore. Il faut cesser de faire de notre culture un musée et en refaire un feu vivant.

Et surtout, il faut faire rayonner le Québec à l’international.
Pas juste comme une province du Canada, mais comme une culture unique, distincte, vivante. Tant que notre culture n’aura pas d’écho ailleurs, elle restera fragile ici.

Alors oui, la culture québécoise est en péril. Mais elle peut encore être sauvée, à condition qu’on décide collectivement qu’elle en vaut la peine.

Bonne Saint-Jean à tous ! | 12 | 0 | 0 | 5mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:08.062Z |  | 2025-06-24T16:00:20.443Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7336421563103150080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0lF-U_yAIEg/feedshare-shrink_800/B4EZcwyyneG4Ak-/0/1748870312606?e=1766620800&v=beta&t=8DH2VhwMiu6XawcV20S5B3fMxAThDB_t3-Q0fBX-l98 | Un réel plaisir d’avoir pu échanger sur la divergence des modèles LLM lors de l’événement Databricks chez BDC par Rocket Science Development!

Une audience de qualité, une ambiance stimulante, et des échanges riches autour d’un sujet crucial pour l’avenir de l’IA en entreprise.

Comprendre la divergence des modèles (drift, biais, évolution du comportement) est essentiel pour garantir la fiabilité, la sécurité et la conformité des systèmes d’IA générative à long terme.

Merci à tous les participants et organisateurs pour cette belle opportunité ! | 19 | 0 | 1 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.538Z |  | 2025-06-05T16:00:04.765Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7335696817893875712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzE_5EacIq7g/feedshare-shrink_800/B4EZcyekfdG4Ak-/0/1748898565083?e=1766620800&v=beta&t=i1wS_N_vza07yuWLoA_rRrlT15pQ2492YKf-c_irG2A | 🚀 Rocket Science Development est fière d’annoncer qu’elle a remporté le prix de la Startup de l’année 2025 – Rive-Sud lors du 41e Gala Excellence de la CCIRS - Chambre de commerce et d'industrie de la Rive-Sud ! 🏆✨
C’est une immense reconnaissance pour notre équipe, notre vision et notre engagement envers l’innovation responsable en intelligence artificielle. Depuis notre quartier général, nous avons prouvé qu’il est possible de rayonner localement tout en ayant un impact global 🌍.
Merci à la Chambre de commerce et d’industrie de la Rive-Sud pour cet honneur, à nos partenaires qui nous font confiance et à toute notre équipe pour son travail exceptionnel. Merci à DEL - Développement économique de l'agglomération de Longueuil !
Ce prix, on le dédie à tous ceux qui rêvent grand, bâtissent avec rigueur, et croient que la technologie peut être mise au service du bien commun.

#StartupDeLAnnée #GalaExcellence2025 #RiveSud #InnovationResponsable #IntelligenceArtificielle #RocketScience #FiertéLocale #ImpactGlobal | 101 | 20 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.540Z |  | 2025-06-03T16:00:12.042Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7334301929860198401 | Text |  |  | 🚀 Rejoins Rocket Science Development à Montréal ! 🇨🇦

Nous ouvrons 7 nouveaux postes pour renforcer notre équipe en intelligence artificielle. Si tu veux évoluer dans un environnement entrepreneurial, proche de l’innovation, entouré·e de passionné·e·s, lis bien ce qui suit 👇

📌 Postes ouverts (Montréal uniquement – statut au Canada requis) :
🔹 1 Ingénieur·e ML junior (Excellent·e en Python + bonnes bases en ML)
🔹 3 Stagiaires Data (niveau maîtrise)
🔹 2 Data Scientists intermédiaires (à l’aise en MLOps, certifiés Databricks un gros plus)
🔹 1 Data Scientist senior (expérimenté·e avec Dataiku)

Chez Rocket Science, on travaille sur des projets concrets, on contribue à faire avancer la gouvernance de l’IA, et on bâtit des solutions qui comptent. 🌍

📬 Intéressé·e ou tu connais quelqu’un qui le serait ?
Écris-moi directement ou envoie ton CV à nkhelil@rocketscience.one ou Nawel Khelil 

#DataScience #MachineLearning #MLOps #StageData #Recrutement #Montréal #IA #RocketScience #Carrière | 47 | 4 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.543Z |  | 2025-05-30T19:37:24.819Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7333160111160344577 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFQAQM_aRupUA/feedshare-shrink_800/B4DZb6LFf3GYAg-/0/1747953937802?e=1766620800&v=beta&t=zcJ6TFuwBAoHUju1wYt68EkTyVutMSRE9J_P9EJcYaY | 🚀 Très fier d'annoncer que Rocket Science Development a reçu deux prix de DEL - Développement économique de l'agglomération de Longueuil pour avoir été sélectionné afin de bénéficier de fonds de soutien aux entrepreneurs de la Rive-Sud ! 

Ces récompenses viennent renforcer notre engagement à innover et à contribuer activement à l’écosystème entrepreneurial de la Rive-Sud. Merci à DEL pour leur confiance et leur soutien précieux dans notre parcours de croissance.

Continuons ensemble à viser toujours plus haut ! 🌟 Un grand merci à Julie Ethier et toute son équipe !

#Innovation #Entrepreneuriat #Longueuil #RiveSud #RocketScience #SoutienAuxEntrepreneurs #DéveloppementÉconomique | 62 | 5 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.545Z |  | 2025-05-27T16:00:14.027Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7331348137023856642 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFWqOazgBnhVQ/feedshare-shrink_2048_1536/B56Zbv2wCpHgAs-/0/1747780830341?e=1766620800&v=beta&t=SDgApQtayIEh174MIgER4SnlEJPTbZ9y2F5ofQj16nY | Pour être honnête, je ne porte pas les réseaux sociaux dans mon cœur, en particulier Instagram et TikTok, et leur système de "feed" continu. Ces plateformes sont aujourd’hui l’une des plus grandes sources de désinformation, de racisme et de haine. Lorsqu’on tombe sur des absurdités comme celle de cette vidéo, cela démontre à quel point les réseaux sociaux peuvent être nocifs.
On y voit un jeune homme noir manger ce qui ressemble à un singe, accompagné d’un texte qui se veut humoristique. Ce type de contenu alimente les pires stéréotypes, notamment celui de l’Africain sauvage, et ne fait que renforcer les préjugés. Imaginez l’effet que cela peut avoir sur une jeune fille québécoise de 14 ans : ce genre de vidéos ne fait que nourrir la peur, le rejet, voire le racisme.
Je voudrais soulever deux points essentiels à propos de ce contenu :
 1. La vidéo montre visiblement un individu dans un environnement rural, probablement en Afrique. À la lumière de la végétation visible en arrière-plan, et selon mon propre raisonnement, il pourrait s’agir d’une région d’Afrique de l’Est — peut-être l’Éthiopie ou le Sud-Soudan. Il est important de rappeler qu’en Afrique de l’Est, la consommation de viande de singe est très rare, voire inexistante. Le singe est davantage présent dans les zones forestières denses comme l’Afrique centrale ou l’Afrique de l’Ouest. De plus, depuis les épidémies d’Ebola, de nombreux pays africains ont interdit cette pratique pour des raisons sanitaires. D’un point de vue culturel, dans plusieurs tribus de l'Afrique de l'Est, manger du singe est perçu comme un tabou ou une violation des coutumes. Un autre détail pertinent : le jeune homme dans la vidéo ne porte aucun signe tribal distinctif comme des scarifications, des ornements ou des vêtements traditionnels, ce qui me laisse penser, toujours selon mon interprétation, qu’il pourrait s’agir d’un citadin ou d’un habitant d’un village non traditionnel.
 2. Il est important de comprendre que lorsque vous "likez" ou envoyez de l’argent via TikTok ou Instagram à ceux qui publient ce genre de vidéos, vous contribuez à une forme moderne d’exploitation humaine. Dans certains cas, cela s’apparente même à une traite d’êtres humains. Les personnes qui apparaissent dans les vidéos reçoivent parfois une infime partie des revenus générés, voire rien du tout. Elles doivent produire des vidéos virales toute la journée, souvent dans des conditions dégradantes, pour très peu d’argent. C’est inacceptable que des géants comme Meta ou TikTok ferment les yeux sur ce genre d’abus.
 
Si vous voulez vraiment comprendre l’Afrique et les Africains, ce n’est certainement pas sur les réseaux sociaux que vous le ferez. Offrez-vous un billet d’avion pour Addis-Abeba, ou vers une autre capitale africaine. Allez à la rencontre des gens, apprenez leur langue, mangez leur nourriture, vivez avec eux. C’est seulement là que vous comprendrez la dignité, la complexité, et la richesse du continent africain. | 3 | 0 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.546Z |  | 2025-05-22T16:00:05.728Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7330623395543273472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZYj0rOcYs0w/feedshare-shrink_800/B4EZa_sglWHMAg-/0/1746972838664?e=1766620800&v=beta&t=wNfk7tGer4mYZUabU9e0gU3hMr0oyRGhxhu_DuC-3xo | Je vous présente Mohamed en tenue de combat ! Je ne sais pas trop si je dois crier « Vive le Québec libre ! » ou « Allah Ou Akbar ! »
 
Dans tous les cas, je suis fier de mon identité québécoise !
 
D'expérience, je peux vous dire que ce n'est pas une identité facile à porter, surtout pour quelqu'un issu de la diversité. Il y a quelques temps, j'étais à un événement corporatif, portant fièrement cette tenue avec mon petit drapeau du Québec, lorsque je me fais accoster par trois malabars qui semblaient bien canadiens. L'un d'eux me demande : « C'est quoi cette tenue, jeune homme ? Vous êtes perdu ? »
 
La vérité, c'est que je ne suis ni perdu ni sous mauvaise influence. Je suis simplement fier d'être Québécois.
 
Au fil des années, l'identité québécoise s'est faite marginaliser à cause d'un malentendu profond sur ce qu'elle représente vraiment. Être Québécois, ce n'est pas une question de couleur de peau, de religion ou d'origine ethnique, c'est avant tout un sentiment d'appartenance, une adhésion à des valeurs communes et un amour sincère pour cette terre que nous partageons tous.
 
Pourtant, trop souvent, certains confondent diversité et division. Ils voient l'expression d'une identité complexe comme une menace, alors qu'elle est justement ce qui fait la richesse et la force du Québec moderne. Être Québécois aujourd'hui signifie embrasser pleinement cette diversité, construire des ponts entre nos cultures et traditions, tout en respectant nos racines communes.
 
Je continuerai à porter fièrement mes couleurs, à célébrer mon héritage et mon amour pour le Québec, peu importe les regards ou les remarques. Parce qu'au fond, être Québécois, c'est choisir l'ouverture plutôt que la fermeture, l'inclusion plutôt que l'exclusion, et c'est surtout choisir de vivre ensemble, en harmonie et en solidarité.
 
#FiertéQuébécoise #IdentitéQuébécoise #VivreEnsemble #QuébecInclusif #MonQuébec #FierDetreQuebecois | 56 | 3 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.547Z |  | 2025-05-20T16:00:13.894Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7328431390914404352 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHqfRt_42QGMQ/feedshare-shrink_800/B4DZbPRg9IH8Ao-/0/1747234197785?e=1766620800&v=beta&t=VINOsGfepfL_qH9FfY--vQemYHvy5VZbgZKRY5Bj7ZU | J’étais très emballé en apprenant la nomination d'Evan Solomon comme nouveau ministre canadien de l’Intelligence artificielle.

Actuellement, seuls deux pays dans le monde disposent d’un ministère entièrement dédié à l’IA : les Émirats arabes unis et le Canada.

Je sais que certaines mauvaises langues ont déjà commencé à critiquer le choix d'un journaliste sans expérience directe en IA pour occuper ce poste. Personnellement, cela ne m’inquiète absolument pas. L’essentiel, c’est que le ministre soit animé d'une véritable volonté de faire avancer l’intelligence artificielle au Canada et qu'il soit prêt à porter l’écosystème IA sur ses épaules afin de positionner notre pays comme leader mondial incontesté.

Pour l’expertise technique, il suffira simplement au ministre de nommer des sous-ministres et des conseillers dotés des compétences nécessaires en IA.

Dossier chaud du moment ! Bien hâte de voir tout cela démarrer ! | 8 | 0 | 0 | 6mo | Post | Mohamed Sabri | https://www.linkedin.com/in/mohamed-sabri | https://linkedin.com/in/mohamed-sabri | 2025-12-08T05:00:10.548Z |  | 2025-05-14T14:49:59.265Z |  |  | 

---



---

# Mohamed Sabri
*Rocket Science Development*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [RocketDevs’ Commitment to Providing Opportunities to Talented Developers in Opportunity-Scarce Countries](https://thelastsultan.medium.com/rocketdevs-commitment-to-providing-opportunities-to-talented-developers-in-opportunity-scarce-4372c5df7eca)
*2023-08-23*
- Category: blog

### [Rocket Academy Reviews | SwitchUp](https://www.switchup.org/bootcamps/rocket-academy?page=15)
*2023-10-17*
- Category: article

### [ROCKETECH & QuizWithIt | Startup Founder Testimonials](https://www.youtube.com/watch?v=T7O2cvkdfnc)
*2024-03-22*
- Category: video

### [Blog - Page | rocketmvp.io](https://www.rocketmvp.io/blog)
*2024-12-16*
- Category: blog

### [Reimagining Mens Health: One founders journey from personal recovery to mass market - Rocketship.fm Podcast: Business Explored](https://rocketship.fm/episodes/reimagining_mens_health_one_founders_journey_from_personal_recovery_to_mass_market)
*2021-08-12*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 15,033 words total*

### RocketDevs’ Commitment to Providing Opportunities to Talented Developers in Opportunity-Scarce…
*1,463 words* | Source: **EXA** | [Link](https://thelastsultan.medium.com/rocketdevs-commitment-to-providing-opportunities-to-talented-developers-in-opportunity-scarce-4372c5df7eca)

[![Image 1: Mohamed Ali Elzeiny](https://miro.medium.com/v2/resize:fill:64:64/1*5loeGLe4vPidWIXr-ekMaA.jpeg)](https://thelastsultan.medium.com/?source=post_page---byline--4372c5df7eca---------------------------------------)

7 min read

Aug 22, 2023

![Image 2](https://miro.medium.com/v2/resize:fit:626/1*alqhVvxVmq-o4HsvXDrmQw.jpeg)

In an era defined by technological advancement and global progress, [RocketDevs](https://rocketdevs.com/) emerges as a transformative force, dedicated to nurturing exceptional software developers from underserved regions. We explore [RocketDevs](https://rocketdevs.com/)’ mission to bridge the talent gap, empowering developers from emerging nations and propelling them onto the global stage.

[RocketDevs](https://rocketdevs.com/) recognizes that talent knows no boundaries, sparking its commitment to opportunity-scarce countries. By doing so, it dismantles barriers and creates avenues for aspiring developers to flourish. The tech industry’s rapid evolution demands a diverse workforce, drawing strength from varied backgrounds and experiences.

Beyond individual successes, [RocketDevs](https://rocketdevs.com/) addresses the industry-wide talent gap. As technology reshapes the world, demand for skilled developers soars. Yet, many emerging nations struggle to provide necessary resources. This mission is pivotal in transforming the landscape, enabling aspiring developers to thrive. This journey uncovers [RocketDevs](https://rocketdevs.com/)’ multifaceted approach, catalyzing growth, innovation, and economic progress in marginalized tech ecosystems. The path traverses educational programs, mentorship, and network-building, amplifying voices often overlooked.

In this pursuit, [RocketDevs](https://rocketdevs.com/) holds the power to reshape the future, driving diversity, innovation, and empowerment in the tech industry. This article delves into the heart of [RocketDevs](https://rocketdevs.com/)’ mission, unveiling its impact — one developer at a time.

Elevating Emerging Developers
-----------------------------

> In an interview with 1,600 software developers, Google discovered that 38% of African developers work for at least one company based outside of the continent — [African developers: creating opportunities and building for the future](https://blog.google/around-the-globe/google-africa/african-developers-creating-opportunities-and-building-future/)

Google’s findings highlight the global impact of African software developers, as they contribute to companies beyond their region. [RocketDevs](https://rocketdevs.com/)’ commitment to nurturing talent in opportunity-scarce countries aligns with this trend, aiming to increase developers from these regions working on international projects.

Central to [RocketDevs](https://rocketdevs.com/)’ mission is elevating developers from these regions onto a global stage. By offering opportunities, mentorship, and a supportive environment, they reshape the paths of emerging talents. This section explores its vital role and the challenges these developers face, emphasizing the need for a platform to bridge potential and success.

Emerging nations are rich in untapped talent, yet obstacles hinder success. Limited access to education, technology, and opportunities creates disparity, inhibiting a vibrant tech ecosystem.

Enter [RocketDevs](https://rocketdevs.com/) — an empowering force recognizing this untapped potential. Curated programs, workshops, and mentorship initiatives empower developers, fostering skills and confidence for the tech industry.

By closing the gap between aspiration and opportunity, [RocketDevs](https://rocketdevs.com/) empowers marginalized developers. It reminds us that talent transcends borders and awaits nurturing.

A Launchpad for Excellence
--------------------------

Press enter or click to view image in full size

![Image 3](https://miro.medium.com/v2/resize:fit:626/1*RM-Hbj9hTbK_dPmlkimfTQ.jpeg)

[RocketDevs](https://rocketdevs.com/)’ philosophy centers on holistic developer empowerment, encompassing mentorship, skill-building, and hands-on experience. This unique approach distinguishes [RocketDevs](https://rocketdevs.com/) as a beacon of opportunity for those aspiring beyond their circumstances.

Mentorship is pivotal to [RocketDevs](https://rocketdevs.com/)’ mission, offering developers industry insights and personalized guidance. Seasoned mentors bridge theory and practice, enabling developers to confidently navigate challenges. Skill enhancement is equally crucial, equipping developers with future-focused tools and fostering continuous learning. [RocketDevs](https://rocketdevs.com/) ensures agility in the ever-evolving tech landscape.

A hallmark of [RocketDevs](https://rocketdevs.com/) is real-world project experience, cultivating technical skills, ownership, and collaboration. This prepares developers for success in the modern tech ecosystem. From potential to expertise, [RocketDevs](https://rocketdevs.com/)’ journ

*[... truncated, 7,915 more characters]*

---

### Rocket Academy Reviews | SwitchUp
*2,133 words* | Source: **EXA** | [Link](https://www.switchup.org/bootcamps/rocket-academy?page=15)

Rocket Academy Reviews | SwitchUp

===============

[![Image 1: SwitchUp logo](https://d92mrp7hetgfk.cloudfront.net/images/sites/misc/SU-logo-polished-d/original.png?1628697059)](https://www.switchup.org/)

[Best Bootcamps](https://www.switchup.org/rankings/best-coding-bootcamps)

*   [Coding](https://www.switchup.org/rankings/best-coding-bootcamps)
*   [Cybersecurity](https://www.switchup.org/rankings/best-cyber-security-bootcamps)
*   [Online](https://www.switchup.org/rankings/best-online-bootcamps)
*   [Digital Marketing](https://www.switchup.org/rankings/best-digital-marketing-bootcamps)
*   [Data Science](https://www.switchup.org/rankings/best-data-science-bootcamps)
*   [Data Analytics](https://www.switchup.org/rankings/best-data-analytics-bootcamps)
*   [Web Design](https://www.switchup.org/rankings/best-web-design-bootcamps)
*   [By Location](https://www.switchup.org/locations)
*   [Product Management](https://www.switchup.org/rankings/best-product-management-bootcamps)

[Search Bootcamps](https://www.switchup.org/coding-bootcamps-reviews)

[Student Reviews](https://www.switchup.org/coding-bootcamps-reviews)

*   [Write a Review](https://www.switchup.org/write-review)

[Resources](https://www.switchup.org/blog)

*   [Blog](https://www.switchup.org/blog)
*   [Bootcamps by Subject](https://www.switchup.org/subjects)

[About](https://www.switchup.org/about)

*   [Best Bootcamps](https://www.switchup.org/rankings/best-coding-bootcamps) 

    *   [Coding](https://www.switchup.org/rankings/best-coding-bootcamps)
    *   [Online](https://www.switchup.org/rankings/best-online-bootcamps)
    *   [Data Science](https://www.switchup.org/rankings/best-data-science-bootcamps)
    *   [Web Design](https://www.switchup.org/rankings/best-web-design-bootcamps)
    *   [Product Management](https://www.switchup.org/rankings/best-product-management-bootcamps)
    *   [Cybersecurity](https://www.switchup.org/rankings/best-cyber-security-bootcamps)
    *   [Digital Marketing](https://www.switchup.org/rankings/best-digital-marketing-bootcamps)
    *   [Data Analytics](https://www.switchup.org/rankings/best-data-analytics-bootcamps)
    *   [By Location](https://www.switchup.org/locations)

*   [Search Bootcamps](https://www.switchup.org/coding-bootcamps-reviews)
*   [Student Reviews](https://www.switchup.org/coding-bootcamps-reviews) 

    *   [Write a Review](https://www.switchup.org/write-review)

*   [Resources](https://www.switchup.org/blog) 

    *   [Blog](https://www.switchup.org/blog)
    *   [Bootcamps by Subject](https://www.switchup.org/subjects)

*   [About](https://www.switchup.org/about)

Not Sure Where to Apply?

 Get Matched  ADVERTISEMENT

[![Image 2: Rocket Academy logo](https://d92mrp7hetgfk.cloudfront.net/images/sites/misc/Rocket_Academy_11192020/original.png?1605803468)](https://rocketacademy.co/)

Rocket Academy
==============

Online,Singapore,Kowloon Bay,Sydney

[**Write a Review**](https://www.switchup.org/write-review)

[**4.93/5**](https://www.switchup.org/bootcamps/rocket-academy?page=15#reviews)

[**149 reviews**](https://www.switchup.org/bootcamps/rocket-academy?page=15#reviews)

About Rocket Academy
--------------------

Location:Online,Singapore,Kowloon Bay,Sydney

 Available Online 

 Flexible Classes 

Rocket Academy is a 6-month live and online coding bootcamp that trains software engineers for job placements in Singapore. With instructor experience from Facebook to Alibaba, Stanford to General Assembly, you will be placed in Singapore's highest-calibre... [Read More](https://www.switchup.org/bootcamps/rocket-academy?page=15) coding community. Small classes ensure students get attention and build bonds. Graduates join RA’s powerful alumni network, enabling lifelong friendships and career opportunities. Graduates unable to get a software development or related job within 6 months of graduation will receive a full refund.

[Read Less](https://www.switchup.org/bootcamps/rocket-academy?page=15)

Do you represent this school? [Suggest edits.](https://www.switchup.org/contact)

[](https://www.switchup.org/bootcamps/rocket-academy?page=15)

### Courses

#### Coding Basics

**Cost:** 199 

**Duration:** 6 weeks

**Locations:**Online,  Singapore, Kowloon Bay, Sydney 

In-person Available Online

**Course Description:**
Coding Basics is a 6-week part-time course to help students learn basic coding and decide whether to pursue a software engineering career. Coding Basics is a prerequisite for Rocket Academy’s career-preparatory Software Engineering Bootcamp.

Through simple examples and games, students will learn core concepts of all programming languages, from variable manipulation to functions, conditionals, loops, and data structures. More importantly, students will learn how to think programmatically and translate ideas to code. By the end of the course, students will have built a small card game and have the foundations to build larger software projects.

Rocket Academy’s methodology emphasise

*[... truncated, 16,444 more characters]*

---

### ROCKETECH & QuizWithIt | Startup Founder Testimonials
*1,188 words* | Source: **EXA** | [Link](https://www.youtube.com/watch?v=T7O2cvkdfnc)

ROCKETECH & QuizWithIt | Startup Founder Testimonials - YouTube

===============

 Back [![Image 1](https://www.youtube.com/watch?v=T7O2cvkdfnc)](https://www.youtube.com/ "YouTube Home")

Skip navigation

 Search 

 Search with your voice 

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[Sign in](https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3Dhttps%253A%252F%252Fwww.youtube.com%252Fwatch%253Fv%253DT7O2cvkdfnc&hl=en&ec=65620)

[![Image 2](https://www.youtube.com/watch?v=T7O2cvkdfnc)](https://www.youtube.com/ "YouTube Home")

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[ROCKETECH & QuizWithIt | Startup Founder Testimonials](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

Tap to unmute

2x

[![Image 3](https://www.youtube.com/watch?v=T7O2cvkdfnc)](https://www.youtube.com/watch?v=T7O2cvkdfnc)

ROCKETECH & QuizWithIt | Startup Founder Testimonials
-----------------------------------------------------

ROCKETECH Company 64 views 1 year ago

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

Search

Copy link

Info

Shopping

![Image 4](https://www.youtube.com/watch?v=T7O2cvkdfnc)

[![Image 5](https://www.youtube.com/watch?v=T7O2cvkdfnc)](https://www.youtube.com/watch?v=T7O2cvkdfnc)

If playback doesn't begin shortly, try restarting your device.

•

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

Cancel Confirm

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)

Share

[](https://www.youtube.com/watch?v=T7O2cvkdfnc "Share link")- [x] Include playlist 

An error occurred while retrieving sharing information. Please try again later.

![Image 6](https://www.youtube.com/watch?v=T7O2cvkdfnc)

0:00

[](https://www.youtube.com/watch?v=T7O2cvkdfnc)[](https://www.youtube.com/watch?v=mno5XYouonY "Next (SHIFT+n)")

0:00 / 0:00

Live

•Watch full video

•

•

[5:25 New Barista Training - SNL Saturday Night Live 6.8M views • 10 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=Tn7g2cn7iBo)[13:39 How to Spot Autism in High-Masking Adults Auticate with Chris & Debby 1.3M views • 10 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=jJDKjH6rHhw)[5:10 The FUNNIEST Talking Baby and Dog Moment Caught on Camera Happy Chocolate Family 6.1M views • 11 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=y-BOY7obSOU)[22:32 Do NOT Move to These 7 Countries in 2025. Here's Why Evan Eh! 🇨🇦690K views • 3 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=zle5_D-f1oU)[14:58 ChatGPT in a real robot does what experts warned.InsideAI 769K views • 7 days ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=byQmJ9x0RWA)[4:24 Kristen Wiig Breaking People on SNL for 4 Minutes Straight PopMojo 1.9M views • 9 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=eE2BQ7rE7OU)[5:31 Black Moms At Parent Teacher Conference Jay Nedaj 2.1M views • 1 year ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=A56SvKe1a1w)[34:08 What Every Body Fat % Actually Looks Like (50% to 5%)Jeff Nippard 8.2M views • 4 weeks ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=5K9QhkPww44)[20:10 Inside America's Robbery Capital (Oakland)RocaNews 1.3M views • 4 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=mh2cU-Z1Sik)[12:27 AI vs Oscar Winning Actor (Same Scene)Tristan Spohn 754K views • 3 months ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=Y3Lc67fxR0U)[1:00:02 Bright Flying Blue Fire Sparks Background video | Footage | Screensaver MG1010 87K views • 4 years ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=mno5XYouonY)[5:08 Haircut - SNL Saturday Night Live 2.9M views • 3 weeks ago Live Playlist ()Mix (50+)](https://www.youtube.com/watch?v=uFrNdPHL52c)

Sign in to confirm you’re not a bot This helps protect our community. [Learn more](https://support.google.com/youtube/answer/3037019#zippy=%2Ccheck-that-youre-signed-into-youtube)

[Sign in](https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252Fwatch%253Fv%253DT7O2cvkdfnc&hl=en)

ROCKETECH & QuizWithIt | Startup Founder Testimonials
=====================================================

[![Image 7](https://yt3.ggpht.com/z2nwN2ePrvimIDJPnWl5SGXANoeAnbHwJNgeorugj86clb5WTK8hdOsYy_ScU5kDtfGEorwg=s48-c-k-c0x00ffffff-no-rj)](https://www.youtube.com/@ROCKETECH-IT)

[ROCKETECH Company](https://www.youtube.com/@ROCKETECH-IT)

 ROCKETECH Company 

6 subscribers


*[... truncated, 12,302 more characters]*

---

### Blog - Page | rocketmvp.io
*285 words* | Source: **EXA** | [Link](https://www.rocketmvp.io/blog)

Insights on MVP Development & SaaS
----------------------------------

Expert insights on MVP development, SaaS solutions, and startup technology. Learn proven strategies for rapid product development, scaling your SaaS, and building successful digital products from concept to launch.

[![Image 1: The Complete SaaS Founder Roadmap: From Zero to Revenue-Ready Business](https://www.rocketmvp.io/_next/image?url=%2Fimages%2Fsaas-founder-roadmap-cover.webp&w=3840&q=75) SaaS Strategy The Complete SaaS Founder Roadmap: From Zero to Revenue-Ready Business ---------------------------------------------------------------------- Skip the painful mistakes most founders make. This battle-tested roadmap takes you from validated idea to thriving SaaS business with detailed SOPs, templates, and real lessons learned. November 27, 2025](https://www.rocketmvp.io/blog/the-complete-saas-founder-roadmap-from-zero-to-revenue)[![Image 2: Why SaaS MVPs Fail: 6 Common Mistakes That Kill Your Startup](https://www.rocketmvp.io/_next/image?url=%2Fimages%2Fwhy-mvps-fail-cover.webp&w=3840&q=75) MVP Development Why SaaS MVPs Fail: 6 Common Mistakes That Kill Your Startup ------------------------------------------------------------ 42% of startups fail because they build products nobody wants. Learn why SaaS MVPs fail and the 6 critical mistakes that kill momentum before launch. November 26, 2025](https://www.rocketmvp.io/blog/why-saas-mvps-fail-6-common-mistakes-to-avoid)[![Image 3: Next.js vs React for SaaS: Which Framework to Choose for Your MVP](https://www.rocketmvp.io/_next/image?url=https%3A%2F%2Fimages.unsplash.com%2Fphoto-1633356122544-f134324a6cee%3Fw%3D1200%26h%3D630%26fit%3Dcrop&w=3840&q=75) Product Development Next.js vs React for SaaS: Which Framework to Choose for Your MVP ----------------------------------------------------------------- Compare Next.js vs React for building your SaaS MVP. Learn which framework offers better performance, SEO, and development speed for your startup in 2025. January 26, 2025](https://www.rocketmvp.io/blog/nextjs-vs-react-for-saas-which-framework-to-choose-for-your-mvp)[![Image 4: MVP Development Timeline: What to Expect](https://www.rocketmvp.io/_next/image?url=https%3A%2F%2Fassets.seobotai.com%2Frocketmvp.io%2F676059a24aaf8cd2e0d704b7-1734368686145.jpg&w=3840&q=75) Product Development MVP Development Timeline: What to Expect ---------------------------------------- Learn the essential steps, timelines, and strategies for building a successful Minimum Viable Product (MVP) in this comprehensive guide. December 16, 2024](https://www.rocketmvp.io/blog/mvp-development-timeline-what-to-expect)[![Image 5: 7 Critical Features Every SaaS MVP Must Include in 2025](https://www.rocketmvp.io/_next/image?url=https%3A%2F%2Fassets.seobotai.com%2Frocketmvp.io%2F675ff9c5250f5fea60171adb-1734344755128.jpg&w=3840&q=75) Product Development 7 Critical Features Every SaaS MVP Must Include in 2025 ------------------------------------------------------- Learn the essential features every SaaS MVP needs in 2025 to ensure security, scalability, and user satisfaction for long-term success. December 16, 2024](https://www.rocketmvp.io/blog/7-critical-features-every-saas-mvp-must-include-in-2025)

---

### Origin DNS error | rocketship.fm
*82 words* | Source: **EXA** | [Link](https://rocketship.fm/episodes/reimagining_mens_health_one_founders_journey_from_personal_recovery_to_mass_market)

Please enable cookies.

Error 1016
----------

Ray ID: 9aaa84334aa7d9bb •2025-12-08 07:23:16 UTC

What can I do?
--------------

**If you are a visitor of this website:**

Please try again in a few minutes.

**If you are the owner of this website:**

Check your DNS settings. If you are using a CNAME origin record, make sure it is valid and resolvable. [Additional troubleshooting information here.](https://support.cloudflare.com/hc/en-us/articles/234979888-Error-1016-Origin-DNS-error)

Was this page helpful?

Thank you for your feedback!

Cloudflare Ray ID: **9aaa84334aa7d9bb**• Your IP: 222.155.143.64•Performance & security by[Cloudflare](https://www.cloudflare.com/5xx-error-landing)

---

### L'Oréal Canada launches new Business Data Lab to make ‘beauty more understandable’ - Global Cosmetics News
*1,823 words* | Source: **GOOGLE** | [Link](https://www.globalcosmeticsnews.com/loreal-canada-launches-new-business-data-lab-to-make-beauty-more-understandable/)

L'Oréal Canada launches new Business Data Lab to make ‘beauty more understandable’ - Global Cosmetics News

===============

TRENDING:

[Cosmo Pharmaceuticals Shares Surge After Male Hair Loss Treatment Delivers Breakthrough Phase III Results](https://www.globalcosmeticsnews.com/cosmo-pharmaceuticals-shares-surge-after-male-hair-loss-treatment-delivers-breakthrough-phase-iii-results/)
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Yuv Secures US$12m Series A as Smart Hair Colour Tech Attracts Further Investor Backing](https://www.globalcosmeticsnews.com/yuv-secures-us12m-series-a-as-smart-hair-colour-tech-attracts-further-investor-backing/)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Revlon Appoints Ariadne Oliveira as VP of Marketing Innovation for Global Professional Hair](https://www.globalcosmeticsnews.com/revlon-appoints-ariadne-oliveira-as-vp-of-marketing-innovation-for-global-professional-hair/)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[India’s Ceuticoz Enters Babycare Market with Dermatology-Led ‘Ceuticoz Baby’ Range](https://www.globalcosmeticsnews.com/indias-ceuticoz-enters-babycare-market-with-dermatology-led-ceuticoz-baby-range/)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[CTPA Publishes Guidance to Help Parents Navigate Children’s Growing Skincare Habits](https://www.globalcosmeticsnews.com/ctpa-publishes-guidance-to-help-parents-navigate-childrens-growing-skincare-habits/)
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Street Talk: Make-Up –Episode Nine Skin Type: Sensitive](https://www.globalcosmeticsnews.com/street-talk-make-up-episode-nine-skin-type-sensitive/)
----------------------------------------------------------------------------------------------------------------------------------------------------

[P&G Flags Sharp U.S. Category Declines as Consumer Weakness Weighs on Q2 Outlook](https://www.globalcosmeticsnews.com/pg-flags-sharp-u-s-category-declines-as-consumer-weakness-weighs-on-q2-outlook/)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Shiseido Announces Major Structural Reorganization and Senior Leadership Moves Ahead of 2026](https://www.globalcosmeticsnews.com/shiseido-announces-major-structural-reorganization-and-senior-leadership-moves-ahead-of-2026/)
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Unrivaled Miami Rebrands to Sephora Arena Under Expanded Deal](https://www.globalcosmeticsnews.com/unrivaled-miami-rebrands-to-sephora-arena-under-expanded-deal/)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------

[Ulta Beauty Reports Q3 FY2025 Results; Raises Full-Year Outlook](https://www.globalcosmeticsnews.com/ulta-beauty-reports-q3-fy2025-results-raises-full-year-outlook/)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------

*   [Follow](https://www.facebook.com/globalcosmeticsnews/ "Follow on Facebook")
*   [Follow](https://twitter.com/globalcosmetics "Follow on X")
*   [Follow](https://www.instagram.com/globalcosmeticsnews/ "Follow on Instagram")
*   [Follow](https://www.linkedin.com/company/9552229/admin/updates/ "Follow on LinkedIn")
*   [Follow](https://www.youtube.com/channel/UCkrUsUbhEM4quI9o-0m4IeA?view_as=subscriber "Follow on Youtube")

[![Image 1: Global Cosmetics News](https://www.globalcosmeticsnews.com/wp-content/uploads/2025/01/gcn-10-years-logo.jpg)](https://www.globalcosmeticsnews.com/)

*   [HOME](https://www.globalcosmeticsnews.com/)
*   [ALL REGIONS](https://www.globalcosmeticsnews.com/regions/)
*   [VIDEO](https://www.globalcosmeticsnews.com/loreal-canada-launches-new-business-data-lab-to-make-beauty-more-understandable/#)
    *

*[... truncated, 31,528 more characters]*

---

### L'Oréal Canada launches a Business Data Lab
*2,860 words* | Source: **GOOGLE** | [Link](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html)

L'Oréal Canada launches a Business Data Lab

===============

[Close menu](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-0)

*   [News](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-news)
*   [Products](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-products)
*   [Contact](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-contact)

[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-default)
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-news)
*   _3_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-1)News in Focus
*   _5_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-2)Business
*   _5_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-3)Science & Tech
*   _5_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-4)Lifestyle & Health
*   _1_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-5)Policy & Public Interest
*   _1_[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-6)People & Culture
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-products)
*   [Explore Our Platform](https://www.newswire.ca/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.newswire.ca/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.newswire.ca/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.newswire.ca/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.newswire.ca/multichannel-amplification/ "Amplify Content ")
*   [IR](https://www.newswire.ca/products/investor-relations/ "IR")
*   [All Products](https://www.newswire.ca/products/all-products/ "All Products")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html#mm-panel-contact)
*   [Sign Up](https://www.newswire.ca/contact-us "Sign Up")
*   [Request a Demo](https://www.newswire.ca/request-a-demo/ "Request a Demo")
*   [Editorial Bureaus](https://www.newswire.ca/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https://www.newswire.ca/contact-us/partnerships "Partnerships")
*   [General Enquiries](https://www.newswire.ca/contact-us/general-enquiries/ "General Enquiries")
*   [Media Enquiries](https://www.newswire.ca/contact-us/media-enquiries "Media Enquiries")
*   [Worldwide Offices](https://www.newswire.ca/contact-us/worldwide-offices "Worldwide Offices")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Web

*[... truncated, 66,778 more characters]*

---

### Checking your browser
*64 words* | Source: **GOOGLE** | [Link](https://www.f6s.com/companies/fashion/canada/co)

Checking your browser

===============

![Image 1](https://www.f6s.com/content-resource/static/f6s-logo-square.svg?v=FVXHfEQcGR)

We think you might be a bot 

 To regain access, please make sure that cookies and JavaScript are enabled before reloading the page.

 Please email [support@f6s.com](mailto:support@f6s.com) with the info below if you think this is an error: 

IP: 34.34.225.138

 Request ID: fo4dH-PNOyxS9GAtpI1hWLmZYItR1vpRRK1ObX8eqO79Ut8XxoCGgg==

[Terms](https://www.f6s.com/terms)[Privacy](https://www.f6s.com/privacy-policy)[Data Security](https://www.f6s.com/data-security)[Cookie Policy](https://www.f6s.com/cookie-policy)[Cookie Table](https://www.f6s.com/cookie-table)© 2025 F6S Network Limited. All rights reserved. F6S is a registered trademark.

---

### Best AI Consulting Companies in Doha, Qatar
*2,985 words* | Source: **GOOGLE** | [Link](https://aisuperior.com/ai-consulting-companies-in-doha/)

In the thriving technological hub of Doha, Qatar, businesses are increasingly turning to artificial intelligence (AI) to gain a competitive edge. The integration of AI into business operations can drive innovation, optimize processes, and enhance decision-making. This article highlights some of the best AI consulting companies in Doha, known for their expertise, innovative solutions, and commitment to helping businesses harness the power of AI. These firms offer a range of services, from AI strategy development to custom AI solutions, ensuring that companies can effectively leverage AI to achieve their objectives.

![Image 1](https://aisuperior.com/wp-content/uploads/2024/12/AI-Superior-300x55-1-300x81.png)

1. AI Superior
--------------

At AI Superior, we provide comprehensive artificial intelligence consulting services, assisting businesses in integrating AI solutions to enhance operations and foster growth. Established in 2019 by Dr. Ivan Tankoyeu and Dr. Sergey Sukhanov, our firm is grounded in deep AI expertise and a commitment to pushing the boundaries of what AI can achieve. Our approach to AI consulting focuses on transforming AI concepts into scalable, practical solutions. This is bolstered by our robust project life cycle management, which mitigates risks by aligning AI implementations with business objectives, ensuring transparency, and effectively communicating risks and opportunities.

The strength of our team lies in its diversity and specialization. Our PhD-level data scientists and engineers possess broad expertise across various technologies and domains. This multidisciplinary knowledge enables us to tackle complex business challenges with pragmatic, data-driven solutions. Understanding the pivotal role of project management in AI deployment, we structure our teams to optimize project outcomes from the onset. Our project teams, including data scientists, ML engineers, and developers, work in concert to ensure the success of each AI initiative, guided by a customer-centric philosophy.

Our work extends beyond project completion; we empower clients with the knowledge and tools necessary to sustain and expand AI functionalities within their operations. This commitment to client empowerment and long-term value creation underscores every project we undertake.

### Key Highlights:

*   Founded in 2019 by experts Dr. Ivan Tankoyeu and Dr. Sergey Sukhanov.
*   Specializes in transforming AI concepts into scalable solutions.
*   High success rate in Proof of Concept (PoC) projects.
*   Effective risk management in AI project life cycles.
*   Team comprised of PhD-level data scientists and engineers.

### Services:

*   AI and Data Strategy Development.
*   Process Optimization with AI.
*   AI Use Case Discovery & Identification.
*   AI Training and Workshops.
*   Generative AI Development.

### Contact and Social Media Information:

*   Website: [aisuperior.com](https://aisuperior.com/)
*   Contact Email: [info@aisuperior.com](mailto:info@aisuperior.com)
*   Phone Number: +49 6151 3943489
*   Location: Robert-Bosch-Str.7, 64293 Darmstadt, Germany
*   LinkedIn: [www.linkedin.com/company/ai-superior](http://www.linkedin.com/company/ai-superior)
*   Twitter: [twitter.com/aisuperior](http://twitter.com/aisuperior)
*   Facebook:[www.facebook.com/aisuperior](http://www.facebook.com/aisuperior)
*   Instagram: [www.instagram.com/ai_superior](http://www.instagram.com/ai_superior)
*   Youtube: [www.youtube.com/channel/UCNq7KZXztu6jODLpgVWpfFg](http://www.youtube.com/channel/UCNq7KZXztu6jODLpgVWpfFg)

![Image 2](https://aisuperior.com/wp-content/uploads/2024/07/aiqatar-1.png)

2. AI Qatar
-----------

AIQatar is a consulting firm specializing in artificial intelligence and data analytics solutions. The company provides a comprehensive range of services including AI strategy development, custom AI solutions, and integration of AI technologies into business processes. They cater to a diverse set of industries such as healthcare, finance, and public sector institutions, aiming to enhance operational efficiency and decision-making through advanced AI applications. Their offerings include machine learning model development, AI-powered process optimization, and predictive analytics.

In addition to their consulting services, AIQatar is actively involved in research and development. They collaborate with academic institutions and industry leaders to stay at the forefront of AI innovations. AIQatar’s mission is to drive digital transformation and foster innovation within organizations, contributing to the broader advancement of AI in the region.

### Key Highlights:

*   Leading AI consulting firm in Qatar.
*   Focuses on innovative AI solutions and strategies.
*   Experienced team of AI professionals.

### Services:

*   AI Strategy and Consulting.
*   Custom AI Development.
*   AI Training and Workshops.
*   Data Analytics and Insights.

### Contact and Social Media Information:

*   Address: West Walk, 1st Floor, 

*[... truncated, 18,401 more characters]*

---

### L’Oréal for the Future
*2,150 words* | Source: **GOOGLE** | [Link](https://www.loreal.com/en/canada/news/brands/loreal-canada-launches-a-business-data-lab/)

L'Oréal Canada launches a Business Data Lab

===============

===============

*   [](https://www.loreal.com/en/canada/news/brands/loreal-canada-launches-a-business-data-lab/#)
*   [Go to Content](https://www.loreal.com/en/canada/news/brands/loreal-canada-launches-a-business-data-lab/#main-content)
*   [Go To Footer](https://www.loreal.com/en/canada/news/brands/loreal-canada-launches-a-business-data-lab/#page-footer)

Main Navigation Menu

[](https://www.loreal.com/en/)

*   [Group](https://www.loreal.com/en/group/)

back
Group

    *   [Who We Are](https://www.loreal.com/en/group/)
    *   [Our purpose](https://www.loreal.com/en/group/about-loreal/our-purpose/)Our purpose

back
Our purpose

        *   [Our purpose](https://www.loreal.com/en/group/about-loreal/our-purpose/)
        *   [Essentiality of Beauty](https://essentiality-of-beauty.loreal.com/)
        *   [Strategy & Model](https://www.loreal.com/en/group/about-loreal/strategy-and-model/)
        *   [Quality & Safety Standards](https://www.loreal.com/en/group/about-loreal/standard-quality-and-safety/)
        *   [Our Performance](https://www.loreal-finance.com/eng)

    *   [Governance & Ethics](https://www.loreal.com/en/group/governance-and-ethics/)Governance & Ethics

back
Governance & Ethics

        *   [More About Governance & Ethics](https://www.loreal.com/en/group/governance-and-ethics/)
        *   [Board of Directors](https://www.loreal.com/en/group/governance-and-ethics/board-of-directors/)
        *   [Executive Committee](https://www.loreal.com/en/group/governance-and-ethics/comex-members/)
        *   [Our Ethical Principles](https://www.loreal.com/en/group/governance-and-ethics/our-ethical-principles/)

    *   [Culture & Heritage](https://www.loreal.com/en/group/culture-and-heritage/)Culture & Heritage

back
Culture & Heritage

        *   [More About Culture & Heritage](https://www.loreal.com/en/group/culture-and-heritage/)
        *   [Life at L'Oréal](https://www.loreal.com/en/group/culture-and-heritage/life-at-loreal/)
        *   [Values & Mindset](https://www.loreal.com/en/group/culture-and-heritage/our-values-and-mindset/)
        *   [L'Oréal History](https://www.loreal.com/en/group/culture-and-heritage/l-oreal-history/)

    *   [Newsroom](https://www.loreal.com/en/mediaroom/)Newsroom

back
Newsroom

        *   [All News & Documentation](https://www.loreal.com/en/mediaroom/)
        *   [Press releases](https://www.loreal.com/en/press-release/)
        *   [Latest News](https://www.loreal.com/en/news/)

*   [Commitments](https://www.loreal.com/en/commitments-and-responsibilities/)

back
Commitments

    *   [Our Commitments & Responsibilities](https://www.loreal.com/en/commitments-and-responsibilities/)
    *   [For The Planet](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/)For The Planet

back
For The Planet

        *   [For The Planet](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/)
        *   [L'Oréal for the Future](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/)
        *   [Steward the Climate Transition](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/steward-the-climate-transition/)
        *   [Safeguard Nature](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/safeguard-nature/)
        *   [Drive Circularity](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/driving-circularity/)
        *   [Accelerator Program](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/accelerator/)

    *   [For The People](https://www.loreal.com/en/commitments-and-responsibilities/for-the-people/)For The People

back
For The People

        *   [More About The People](https://www.loreal.com/en/commitments-and-responsibilities/for-the-people/)
        *   [Caring for our Employees](https://www.loreal.com/en/group/about-loreal/our-purpose/social-innovation/)
        *   [Support Communities](https://www.loreal.com/en/commitments-and-responsibilities/for-the-planet/preserving-natural-resources/)
        *   [Promoting Diversity, Equity and Inclusion](https://www.loreal.com/en/commitments-and-responsibilities/for-the-people/promoting-diversity-and-inclusion/)
        *   [Respecting Human Rights](https://www.loreal.com/en/commitments-and-responsibilities/for-the-people/respecting-human-rights/)
        *   [Fondation L'Oréal](https://www.fondationloreal.com/)
        *   [L’Oréal for Youth](https://www.loreal.com/en/commitments-and-responsibilities/for-the-people/for-the-youth/)

    *   [For Our Products](https://www.loreal.com/en/commitments-and-responsibilities/for-our-products/)For Our Products

back
For Our Products

        *   [More About Our Products](https://www.loreal.com/en/commitments-and-responsibilities/for-our-products/)
        *   [Inside our Products](https://inside-our-products.loreal.com/)
        *   [Our Product Quality and Safety](

*[... truncated, 26,164 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[L'Oréal Canada launches new Business Data Lab to make 'beauty ...](https://www.globalcosmeticsnews.com/loreal-canada-launches-new-business-data-lab-to-make-beauty-more-understandable/)**
  - Source: globalcosmeticsnews.com
  - *Jun 23, 2022 ... ... Rocket Science Development and its CEO Mohamed Sabri, as well as McGill University. ... Podcast · Opinion · Fashion · Professiona...*

- **[L'Oréal Canada launches a Business Data Lab](https://www.newswire.ca/news-releases/l-oreal-canada-launches-a-business-data-lab-852673273.html)**
  - Source: newswire.ca
  - *Jun 17, 2022 ... ... Rocket Science Development and its CEO Mohamed Sabri, as well as McGill University. "Our Beauty Tech ambition is to exponentially...*

- **[100 Top Fashion Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/fashion/canada/co)**
  - Source: f6s.com
  - *7 days ago ... Rocket Science Development ... W... more. Montreal, Canada. Founded 2021. Raised from Mohamed Sabri, MLOps | F6S - Images Mohamed Sabri...*

- **[Best AI Consulting Companies in Doha, Qatar](https://aisuperior.com/ai-consulting-companies-in-doha/)**
  - Source: aisuperior.com
  - *Jul 2, 2024 ... Founded by Mohamed Sabri, Rocket Science has built a reputation for ... LinkedIn: linkedin.com/company/rocket-science-development. 7 ....*

- **[L'Oréal Canada launches a Business Data Lab](https://www.loreal.com/en/canada/news/brands/loreal-canada-launches-a-business-data-lab/)**
  - Source: loreal.com
  - *Jun 17, 2022 ... ... Rocket Science Development and its CEO Mohamed Sabri, as well as McGill University. ... conference and exhibition, Viva Technolog...*

- **[Passes give access to any session. Build your own program, your way.](https://www.torontomachinelearning.com/wp-content/uploads/2022/11/TMLS-AGENDA-As-of-Nov-28th.pdf)**
  - Source: torontomachinelearning.com
  - *Nov 28, 2022 ... Eric Hammel, MLOps Engineer l Mohamed Sabri, Chief MLOps Officer, Rocket Science Development ... Which talk track does this best fit ...*

- **[9 Top ChatGPT Companies in Canada · November 2025 | F6S](https://www.f6s.com/companies/chatgpt/canada/co)**
  - Source: f6s.com
  - *Rocket Science Development · See full page ... W... more. Montreal, Canada. Founded 2021. Raised from Mohamed Sabri, MLOps | F6S - Images Mohamed Sabr...*

- **[Hands on: A Beginner Friendly Crash Course to Kubernetes ...](https://www.youtube.com/watch?v=8GB0qmnaBUA)**
  - Source: youtube.com
  - *May 28, 2023 ... Mohamed Sabri, Senior Consultant in MLOps, Rocket Science Development Mohamed Sabri is a results-driven Machine learning Engineer and...*

- **[10 Top Chatbot Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/chatbot/canada/co)**
  - Source: f6s.com
  - *Rocket Science Development · See full page ... W... more. Montreal, Canada. Founded 2021. Raised from Mohamed Sabri, MLOps | F6S - Images Mohamed Sabr...*

- **[Mohamed Sabri Email & Phone Number | Kymeta Corporation VP of ...](https://rocketreach.co/mohamed-sabri-email_1829829)**
  - Source: rocketreach.co
  - *te.eg. Rocket Science Development Employee Mlops Mohamed Sabri's profile photo ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
