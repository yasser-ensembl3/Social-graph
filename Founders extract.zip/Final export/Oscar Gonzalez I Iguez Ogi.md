# Oscar Gonzalez Iñiguez - OGI

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402684909275807744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-95y6eP42iA/feedshare-shrink_800/B4EZruep5iGYAg-/0/1764937615206?e=1766620800&v=beta&t=vXxZOd8sIDEYyRjTugWvNZuYYDb8HRqcZPZv7hLktsU | A meaningful evening at the Startup Community Awards 2025 in Montréal. I left inspired and grateful to be part of such an exceptional ecosystem.

Witnessing my amigo Claude G. Théoret receive the award for “Impactful Legacy of the Year” was truly special. Let me share something personal: as an immigrant founder in Quebec, the journey is often complex—new language, culture, norms, networks. When someone suggested I reach out to Claude, he didn’t schedule weeks later or delegate to someone else. He picked up the phone immediately, and we spoke for two hours. No agenda, just genuine support. His generosity has continued ever since. That kind of leadership is rare, and seeing him recognized for the positive impact he brings to founders and the community was a moment worth celebrating.

It was also a pleasure to share the evening with some of the most influential people shaping Montréal’s startup scene, including one of the finest leadership certified coaches, Sophie Legendre, and seeing Géraldine J. getting recognized for her entrepreneurship. Great to see Mahya Khaki, mijo Pascal Leblanc, Isaac Souweine and meeting Jonas Brandon and Simon Leroux! 🚀

Nights like this remind me that beyond technology, capital, accelerators, and innovation — people, character, and community are what make the difference.

Congratulations to all the winners and nominees. You make the startup world a more human and hopeful place. 

#StartupCommunityAwards #MontrealTech #StartupEcosystem #Leadership #Entrepreneurship #QuebecTech #Impact #CommunityBuilders #Accéder #TITAN #Gratitude #PositiveLeadership | 26 | 5 | 0 | 2d | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:24.949Z |  | 2025-12-05T12:26:57.606Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7400213416260567040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0KeKLlLhUxQ/feedshare-shrink_800/B4EZrLWv1VJgAg-/0/1764348338351?e=1766620800&v=beta&t=KaIg8MyoMP6gLlQFO8n1xq0aF_JDwMsRjaCe9FUxtyM | A truly wonderful experience exchanging ideas with the leadership, business and operations teams at LAURA, one of Medellín’s standout fashion manufacturers, on the realities of AI adoption — including the common mistakes that lead to failure — and how to successfully evolve toward Agentic AI with measurable business impact.

My sincere thanks to Eliana Restrepo and Camilo Castrillon for the kind invitation and for fostering such an open and thoughtful discussion. It’s inspiring to see a company so committed to innovation, resiliency, and strategic evolution.

I am confident that AI — implemented with discipline, governance, and purpose — will become a true strategic ally for LAURA’s continued growth and competitive advantage. Exciting times ahead!

Special shout out to our wonderful local partner Bruno Reyna from Dacotek LATAM. 

#AgenticAI #EnterpriseAI #AIinManufacturing #IndustrialAI #FashionManufacturing #DigitalTransformation #DataStrategy #AILeadership #AIInnovation #ColombiaTech #Medellín #SmartIndustry #FutureOfWork #AccederAI #TITAN #titanagenticai | 5 | 3 | 0 | 1w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:24.950Z |  | 2025-11-28T16:46:07.753Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399506136531611649 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHDH8AzLtxTPw/feedshare-shrink_800/B56Zq17E01I0Ag-/0/1763988761806?e=1766620800&v=beta&t=0jWb6XRI7O2ya8hrjYdg3WA46lvnhuX8wQoFV1C56KA | Great visual from Rakesh Gohel — especially as a reality check for those who think Agentic AI is just “throw an LLM at it and call it a day.”

Let’s be honest: Agentic AI isn’t magic fairy dust you sprinkle on your data. It’s real software engineering — architecture, integrations, pipelines, governance — the unsexy stuff no one brags about on LinkedIn.

This is why so many internal teams hit a wall:
You can’t build enterprise-grade Agentic AI with just a data scientist and a credit card connected to an API.

Data science alone won’t save you — you need software engineering, ML engineering, and systematic thinking.

Otherwise you’ll end up with something that looks like AI…
…until the moment someone actually tries to use it. 😅

#titanagenticai #agenticai #bestpractices #ai #TITAN | 2 | 0 | 0 | 1w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:24.951Z |  | 2025-11-26T17:55:39.125Z | https://www.linkedin.com/feed/update/urn:li:activity:7398705124178579456/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399122107143671809 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEpCZng5x3AiA/feedshare-shrink_800/B4EZq72UIRIQAg-/0/1764088176929?e=1766620800&v=beta&t=V-dl_77rqUzitUHjE9Xs1hoMaKC0xJWb7lSGOhQmLlk | This morning I had the privilege of presenting at the prestigious Club Unión Medellín 🇨🇴, sharing insights with industry leaders about the current and future impact of Agentic AI — and just as importantly — what NOT to do.

We explored:

🚫 Common failure cases companies face when adopting AI: Tesla, Duolingo, Taco Bell and Telstra.

⚠️ What causes wasted investment and disappointing results.

🔑 Best practices for implementation Agentic AI

✔️ How to use Agentic AI to actually drive KPIs and ROI

✔️ A real business example and lessons learned from deployments

✔️ Why governance and architecture matter just as much as strategy

It was great sharing Accéder ‘s experince with such a curious, engaged, technically informed, and forward-thinking audience. Their questions, concerns, and vision for the future made the session truly meaningful.

A very special thanks to María Nelly Porras A for sharing the stage with me and to our local partner Bruno Reyna for making this event possible and for believing in our mission of bringing true enterprise-grade Agentic AI to Latin America.

Medellín surprised me — the talent, mindset, and industrial potential here are enormous. I’m excited for what comes next, and for the deep collaboration opportunities that were born in this room.

#AgenticAI #EnterpriseAI #TITAN #titanagenticai #Medellín #ColombiaTech #IndustrialAI #AIinLatinAmerica #Innovation #IntelligentAgents #FutureOfWork #DigitalTransformation #AILeadership #Manufacturing #Finance #SupplyChain | 28 | 1 | 0 | 1w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:24.952Z |  | 2025-11-25T16:29:39.384Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398719817735888897 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG0n2qtR76lvw/feedshare-shrink_1280/B4DZq1UVTVJEAs-/0/1763978600790?e=1766620800&v=beta&t=301oAwOnJS30-MLBzSdXhTcyHvpUnjM_M9YXk6RTchQ | This graphic does a good job illustrating the basic components of an Agentic AI system. But let’s be honest — explaining it is easy… executing it is extremely hard.

To build a true enterprise-grade agentic system you need:

🔹multi-model orchestration
🔹data pipelines
🔹system integrations
🔹secure data governance
🔹task planning
🔹ML models
🔹domain-adapted reasoning layers…and much more.

This isn’t something you assemble over a weekend with a “make-your-agent” tool.

For context — everything shown (and beyond) already exists inside TITAN, our platform that has taken more than two years of focused engineering and hundreds of thousands of dollars in development to build, test, deploy and refine in real enterprise environments.

So here’s the question for decision-makers:
Do you really want to build your own engine, reinvent everything, and spend 12–24 months learning the hard lessons…
or would you rather adopt a proven, customizable, enterprise-grade platform that is already delivering results today?

Your call — build from scratch or accelerate with something real.

#AgenticAI #EnterpriseAI #TITAN #AccéderAI #DeepTech #AIEngineering #AIinManufacturing #AIinFinance #AIEdge #DataGovernance #IntelligentAgents #FutureOfWork #IndustrialAI #LatinAmericaTech #MontrealTech #AILeadership | 2 | 0 | 0 | 1w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:24.953Z |  | 2025-11-24T13:51:06.115Z | https://www.linkedin.com/feed/update/urn:li:activity:7398662516194746368/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394748637806764033 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEnIjtjOoevTQ/feedshare-shrink_800/B4EZp9ss43KoAg-/0/1763045462031?e=1766620800&v=beta&t=DdNFj_3obYB0eigC543YPXd5R8rpULC5cRMkMB0n8H0 | 🍁 Canada’s AI Ecosystem Is Accelerating — Cohere Shows the Scale, and Vertical Enterprise Intelligence Platforms Like Accéder Are Next! 🚀 

Canada continues to strengthen its position as a global leader in AI. Cohere’s recent USD 500M+ mega-round, their new Montreal office, and their strategic partnership with Mila - Quebec Artificial Intelligence Institute demonstrate the depth, credibility, and momentum of our national AI ecosystem. 

These investments confirm what the global market already sees: Canadian AI is entering a hyper-growth cycle — and the world is betting big. 🇨🇦 

The timing couldn’t be clearer.

According to MarketDataForecast, the enterprise AI market was worth USD 35.4B in 2024, will reach USD 47.8B in 2025, and is projected to expand to USD 520.7B by 2033 — a stunning 35% CAGR. 💰 

This growth explains why horizontal foundation-model companies like Cohere attract such massive capital. Enterprises need strong AI infrastructure, and investors understand the scale required to compete globally.

But infrastructure is only half the story.

The Next Wave of AI Value: Vertical Enterprise Intelligence

While large horizontal platforms power broad capabilities, the next generation of enterprise value will emerge from vertical, domain-specific intelligence layers — where AI connects to real business systems, operational decisions, and financial outcomes.

That is precisely where Accéder and our TITAN platform operate. Enterprises don’t run on generic LLMs. They run on: ERP, SCADA, CRM, BI systems, Manufacturing workflows, Financial processes, Supply chain, risk, and customer operations. Vertical AI is where foundation models become ROI.

TITAN’s specialized intelligent agents deliver instant intelligence and decision support directly inside these mission-critical environments, across:

 • Manufacturing
 • Supply chain & logistics
 • Finance & FP&A
 • Energy & industrial operations
 • Customer care & digital sales
 • Defence simulation

This is a space where generic copilots cannot deliver enterprise-grade outcomes.

The Enterprise AI Stack Is Expanding in Layers

🔹 Layer 1 (LLMs) is validated by Cohere’s USD 500M+ raise.
🔹 Layer 2 (Enterprise Intelligence) is where Accéder’s TITAN delivers real value — directly inside the systems that run operations, supply chain, finance, sales and customer care.

Cohere’s momentum strengthens Canada’s AI ecosystem and opens the door for the next wave: vertical, ROI-driven enterprise AI.

Accéder is that opportunity — a capital-efficient deep-tech company raising USD 20M, not the USD 300M–700M required by foundation models, with real deployments across Mexico and LATAM and a scalable partner-driven GTM.

In a USD 520B+ enterprise AI market still dominated by generic tools, Accéder leads the high-ROI vertical intelligence layer — offering investors a rare, defensible, and perfectly timed opportunity.

#titanagenticai #investmentopportunity #raisingfunds #agentiai #neuromorphiccomputing #snn | 8 | 1 | 0 | 3w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.872Z |  | 2025-11-13T14:51:03.039Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394411215072157697 | Document |  |  | 💡 AI Should Empower Humans — Not Replace Them
A recent Stanford University SALT Lab study — “Future of Work with AI Agents: Auditing Automation and Augmentation Potential across the U.S. Workforce” (Shao et al., 2025) — confirms something I’ve believed for years:

The most successful AI systems keep humans in the loop — not out of it.

At Accéder, our platform #TITAN is built on this exact philosophy: AI should augment people, not automate them out of a job.

🔍 Key Insights from Stanford’s Research

📊 The team analyzed over 1,500 workers, 104 occupations, and 844 tasks — comparing what humans want AI to do vs. what AI can actually do.

🧭 They introduced a Human Agency Scale (HAS) to measure how much human control workers prefer.

They mapped four “zones” of AI potential:

🟩 Green Light → workers want help and AI is capable.
🟥 Red Light → AI could do it, but workers don’t want it.
🔹 R&D Opportunity → humans want help, but AI isn’t ready yet.
⬇️ Low Priority → neither feasible nor desirable.

The prominent finding: People overwhelmingly prefer collaboration, not full automation.

🧠 Why This Matters for Business Leaders

This aligns perfectly with our TITAN Agentic AI philosophy:

🔹 Keep Humans Accountable — Humans must lead; AI should advise and execute within guardrails.

🔹 Augment, Don’t Replace — Automate repetitive data tasks, not human judgment.

🔹 Audit Use Cases — Choose “Green Light” opportunities where both people and AI are aligned.

🔹 Design for Collaboration — Define clear human–AI hand-offs and transparent oversight.

🔹 Upskill Continuously — Invest in decision-making, scenario-building, and coordination skills.

🔹 Measure Trust and Adoption — A technically perfect AI means nothing if users reject it.

⚙️ How We Apply This at Accéder

In TITAN, we embed:

✅ Human-in-the-loop checkpoints.
✅ Transparent reasoning and audit logs.
✅ Domain-specific agents for supply chain, finance, sales, and customer care.
✅  Our AI supports judgment, strategy, and collaboration — not black-box decision-making.

Because the best AI amplifies human intelligence, it doesn’t attempt to replace it.

👉 Check out the full article in the comments! Michael Christian R. COLLEMICHE, Alexander E., Andrés E., Gildardo Salas Campbell, Manuel Llorens, Mauricio Leal, Gilbert W., Gabriela Vargas Gómez, Sophie Legendre, Luc Giguère, Natalie Riviere, Manuel Valdivia, CDO LATAM, Eugenia Moreno, Bruno Reyna

#agenticai #titanagenticai #humanintheloop #ai #aiforbusiness #artificialintelligence #aireasearch | 9 | 3 | 0 | 3w | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.874Z |  | 2025-11-12T16:30:15.190Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7392206829231034368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEuVtW2ieECew/feedshare-shrink_800/B4EZpZk73FHUAg-/0/1762439447210?e=1766620800&v=beta&t=M2K8eNohRryQsvtV6pA11V-LciFka-pjalYTwehvmvQ | 💡 The Next Leap in Enterprise AI: From Thinking Machines to Brain-Inspired Intelligence

LLMs changed how companies reason with data. 🤖 

Now, Spiking Neural Networks (SNNs) are changing how they react to the world. ⚡ 

🧠  At Accéder, we’re building TITAN — the first brain-inspired enterprise AI platform — merging the reflexes of SNNs with the reasoning power of Agentic LLMs. 

This hybrid intelligence doesn’t just analyze what happened. It senses, decides, and acts in real time — across manufacturing, finance, and defence operations.

🏭 In factories, TITAN’s neuromorphic reflexes catch anomalies in milliseconds, reducing downtime and waste.

💰 In finance, it detects regime shifts and liquidity risks before they hit balance sheets.

🛡️ In defence, it enables adaptive logistics and mission-critical situational awareness.

And it does all of this 10–100× more efficiently than GPU-based AI. 🚀 

The future of enterprise intelligence will belong to those who combine speed, sustainability, and sovereignty in their AI systems.

🔗 Read more about how we’re fusing SNNs + Agentic AI to redefine enterprise performance, resilience, and ROI.

 👉 [link in the comments]

Check it out: Michael Christian R. COLLEMICHE, Alexander E., Andres Vazquez del Mercado B, Andrés E., Aldo Zaimi, CDL-Montreal, Justin Dunnion, Radical Ventures, FEMSA Ventures, NEXT AI, Mila - Quebec Artificial Intelligence Institute, Claude G. Théoret, Louis Brun, Luc Giguère, Marc Pare, Neil Ginsburg | 11 | 2 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.875Z |  | 2025-11-06T14:30:48.650Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391826929873559552 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEImX4j-qBynA/feedshare-shrink_2048_1536/B4DZpTdSbqGQAw-/0/1762336779510?e=1766620800&v=beta&t=i04GBxv256QqVRqfzU_nj39CspjpZ8rRpGuOdHT-Qyc | This graphic nails it 👏 — a great reminder that artificial intelligence goes way beyond a GPT tool or a $20/month “agent”.

If you want to build real enterprise-grade AI, you need to understand all the circles of AI — from machine learning and neural networks to software engineering, MLOps, and system design.

💡 Be mindful of the difference — it’s the key to avoiding months of wasted time, rework, and “AI experiments” gone wrong.

Don’t hire someone to build you a camping tent when what you really need is a skyscraper.

Look for true enterprise AI and real agentic platforms that deliver measurable impact and tangible ROI — not just flashy chatbots with marketing buzzwords.

#AI #AgenticAI #EnterpriseAI #DeepTech #MLOps #ArtificialIntelligence #Innovation #BusinessTransformation #TITAN #titanagenticai | 11 | 0 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.876Z |  | 2025-11-05T13:21:13.585Z | https://www.linkedin.com/feed/update/urn:li:activity:7391776208893411328/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391197662580166656 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEI-EP570Nhfg/feedshare-shrink_800/B56ZpJrU6uIsAg-/0/1762172686870?e=1766620800&v=beta&t=IeB2lhAhVOba_rHwMkf8-ZZ3B_F0nU-XKMwAxwZKvV8 | I love this one! I can proudly say Accéder with TITAN can be in line with the guy in the business suit at the first door! 💪🏼😎🚀 

#titanagenticai #agenticai #realagentic #titan #acceder | 11 | 0 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.876Z |  | 2025-11-03T19:40:44.571Z | https://www.linkedin.com/feed/update/urn:li:activity:7391087952828948481/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7389983884123463758 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEV6Xry_PwjRQ/feedshare-shrink_800/B4EZo5_LcSHUAg-/0/1761909455443?e=1766620800&v=beta&t=ORZIb6kxQRI_AOrqNkK8SdemQxAoDdIBSf73oKAk8gQ | 🎓 Last night, I had the privilege to collaborate with Movimiento STEM+ giving a masterclass for elementary and secondary school teachers from Mexico 🇲🇽 on how to integrate tools like ChatGPT responsibly and creatively into the classroom.

In just one hour, we covered:

🔹What artificial intelligence really is and how models like GPT work.

🔹Best practices for educators: when to use it, when not to, and how to always keep pedagogy at the center.

🔹Real-world use cases tailored to different grade levels — from rhyming stories to simulated historical interviews.

🔹How to train students to write better prompts, validate information, and think critically.

🔹Strategies to detect AI-generated content and avoid passive use of these tools.

💡 The takeaway: AI will not replace teachers, but educators who learn to use it strategically will lead the way in this new era of education.

📘 We are providing a practical PDF guide, an educational prompt template, and a classroom-ready mini activity kit to start using right away.

🌍 AI literacy starts with our teachers.
And I’m convinced that when we give them the right tools, they’ll become the leaders of the change our students need.

Muchas gracias to the wondertful team from MOV STEM and the opportunity to do something for our maestros: Graciela Rojas, Valentina, and Montse. 

#Education #ArtificialIntelligence #GPTinClassroom #EdTech #DigitalTransformation #AIforTeachers #ChatGPT #OGI #AgenticAI #STEM #EducacionSTEM #MovimientoSTEM | 13 | 1 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.878Z |  | 2025-10-31T11:17:37.236Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7389412869827772416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErwHKOqeInsg/feedshare-shrink_800/B4EZox31DuIQAg-/0/1761773313549?e=1766620800&v=beta&t=wA2oJFISxSnjYOJMHRkBHYa1pp8oErd9wtXoWiOrZhc | 💡 Forum Tech 360 — Turning Innovation Into Real Impact

This afternoon, I attended the BCF Forum Tech 360, and it was a very revealing event confirming what many of us in Quebec’s tech ecosystem already sense — Canada is slowly losing its tech edge.

Some numbers hit hard:

🇨🇦 Canada’s R&D investment is just 1.8% of GDP, barely growing 0.8% since 2016, while the U.S. stands at 3.4%, up 2.8% in the same period.

⚙️ Quebec leads the country at 2.3%, but that’s actually down 0.1% since 2013, while Ontario grew to 2.2%.

💰 And the most shocking stat: Canadian companies making over $1B invest only 6% of their revenue in risk capital — U.S. firms invest 40%.

That’s the gap — not talent, but capital. Canada is full of brilliant entrepreneurs and world-class engineers, but without serious risk capital, great ideas stay small. Until we fix that, many of us will keep looking abroad to scale truly global companies.

Maybe it’s time for our mini-VCs to start writing bigger checks together — and bet on the homegrown innovation we already have.

Big thanks to the BCF team for an excellent event and to all the speakers — Aviseo Conseil , Annick Charbonneau, Dr. Yves Jacquier, Amy Lorincz, and especially Eric Rondeau for your rare honesty and straight talk.

#CanadaRD #Startups #VC #Funding #TITAN #Acceder | 17 | 1 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.879Z |  | 2025-10-29T21:28:36.819Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7388929643937943552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEcSecQy-KGUw/feedshare-shrink_800/B4EZorAWoQIQAg-/0/1761658104988?e=1766620800&v=beta&t=6jFv31XSSJST6E2FH0tAyfrTL-i7qOVlirBGaE3UCR8 | 🧠 The Agentic AI Paradox: Why 84% of Workers Are Excited — and 56% Are Afraid. 

The latest EY Agentic AI in the Workplace Study reveals something every executive should pay attention to:

Most employees are ready for #AgenticAI — but most companies aren’t ready for their employees to use it.

Here’s the paradox:

🔹 84% of workers are eager to use Agentic AI.
🔹 86% already see productivity gains.
🔹 But 56% fear losing their jobs — and 51% think #AI could make them obsolete.

That’s not resistance. That’s misalignment.

It’s not about AI taking control — it’s about leaders losing it.

EY found that 85% of employees are self-teaching AI outside of work. 

Meanwhile, only 52% of leaders have a real training or upskilling plan.

The result?

Confusion at the bottom. Uncertainty at the top. And a massive opportunity in between.

As I’ve been saying, true #EnterpriseAI must be under human control, guided by strategy, communication, and responsible design.

That’s exactly why we built #TITAN, our enterprise-grade Agentic AI platform at Accéder.

TITAN helps organizations:

 ✅ Integrate Agentic AI securely with ERP, CRM, and data systems
 ✅ Train teams interactively, not theoretically
 ✅ Empower human decision-makers through explainable reasoning
 ✅ Deliver measurable ROI, with total data privacy

The EY findings confirm what we’ve been witnessing in real time: The future of work isn’t about humans versus AI — it’s about humans leading AI.

And the winners will be those who don’t just deploy AI tools…but build Agentic AI strategies that combine trust, performance, and human intelligence.

💡 Read my full article in the comments:
 “Agentic AI: The Excitement, the Anxiety, and the Leadership Gap”

I hope you find this article interesting: Michael Christian R. COLLEMICHE, Alexander E., Gabriela Vargas Gómez, CDO LATAM, Sophie Legendre, Manuel Valdivia, Rod Chavez, Enio Moraes, Maximilian Leger, Julio Luna, Bruno Reyna, Mauricio Reyes, Mauricio Leal, Samir Sharma, Iván Herrero Bartolomé

#titanagenticai #aiworkplace #aitransformation #aiandhumans #artificialintelligence #agenticaiplatform | 11 | 4 | 3 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.880Z |  | 2025-10-28T13:28:26.789Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7387436235906109440 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEj09VIHMP30g/feedshare-shrink_800/B4EZoVyGRJHMAg-/0/1761302048805?e=1766620800&v=beta&t=7tMbINwbGb3ZETTTaehBbm_jvMqUN1D-jVSmSsFt72E | Great evening surrounded by brilliant AI minds and industry innovators at Innovobot — a hybrid VC + Lab based in Montreal driving the next wave of Canadian tech innovation. 🇨🇦💡

From non-carbon construction materials to underwater drones, their portfolio is nothing short of fascinating. It was a pleasure to meet inspiring new people and reconnect with familiar faces pushing boundaries in their fields.

A huge thanks to Natalie Riviere for the invitation — always happy to be your plus one at events like this! 🙌

And Claude G. Théoret, congratulations on the fantastic work you’re doing at Innovobot. Your impact is clear — and yes, I’m holding you to that next AI Salon Montreal pitch! 😉

It was great to meet you: Nicolas Veilleux, Thomas Friedlaender, Michel Dubois, Pedro Gregorio, Margarita S, Qinghe Sun, Lionel T., Ph.D 

#AI #Innovation #VentureCapital #DeepTech #Montreal #Networking #CanadianTech | 37 | 3 | 4 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.881Z |  | 2025-10-24T10:34:10.568Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7387066564451213313 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG_1X9b6UhApA/feedshare-shrink_800/B4DZoQCvoPGQAg-/0/1761205746702?e=1766620800&v=beta&t=f4wwh1uG-Jp9d2IzTbGZO593GzjPC1nzWganZzi9gaQ | Everyone’s an “AI expert” these days… until you ask them about anything outside the Generative AI circle ☺️

Building real enterprise AI isn’t about asking a GPT to “make me an app.” You need to know all the circles — AI, ML, Neural Networks, Deep Learning — plus some good old-fashioned software engineering and MLOps wizardry.

So if you’re diving into this fascinating world of enterprise AI — grab your coffee, roll up your sleeves, and do the homework. The magic doesn’t happen in prompts; it happens in code.

Shout out: Yulen Gallastegui Michelena, Ricardo Praelli, Karin Rodriguez, Marcos Durbano, Omar Costilla-Reyes, PhD, Manuel Valdivia, Brian Alarcon Flores, Carlos Pua, David Scharbach 

#AIrealexperts #RealenterpriseAI #AIpractice #Datascience #AIexpertise | 12 | 0 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.882Z |  | 2025-10-23T10:05:14.025Z | https://www.linkedin.com/feed/update/urn:li:activity:7387032313261494273/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7386769861303173120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGeTi4gtBlzag/feedshare-shrink_800/B4EZoMUCeTIoAg-/0/1761143173011?e=1766620800&v=beta&t=UZUWB_gDZHEEgyxeluseAttgkCX4sCMFlRyorOVOrK0 | 🚀 We are proud to announce a key strategic partnership! 🤝

Accéder and CII.IA - Centro de Innovación Industrial en Inteligencia Artificial are joining forces to combine the best of our capabilities:

✅ CII.IA will provide TITAN, our agentic AI platform, to its network of clients in the manufacturing and financial sectors in Mexico.

✅ They will help us strengthen our relationship with SAP users in this market, further positioning TITAN as a complementary AI layer for SAP products.

 ✅ CII.IA’s data scientists will develop custom machine learning models for Accéder’s clients, expanding the value we can deliver.

This collaboration allows us to offer companies:

🔹 A complete approach to Agentic AI-powered ERP, CRM, BI and systems modernization.

🔹 Faster deployments.

🔹 Tailored predictive and analytical models.

At Accéder, we believe the future belongs to those who innovate, collaborate, and create real value for their clients. This partnership is a true example of that commitment. 💡🌎

A huge thank you to CII.IA team led by Mauricio Leal and Manuel Llorens for trusting us!

The best is yet to come. 🚀

#AI #Innovation #StrategicPartnerships #TITAN #ERP #SAP #SAPS4 #SAPB1 #DataScience #AccederAI #titanagenticai #CII.IA | 16 | 0 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.884Z |  | 2025-10-22T14:26:14.482Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7386373958712967168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHi830h7usCrg/feedshare-shrink_800/B4EZoGr.CcGUAk-/0/1761048782328?e=1766620800&v=beta&t=qcitvobr5TSjev_WW8xzXzJYkwyJHmdv8QVMi8n7rAM | 🚀 AI is NOT here to REPLACE US but to AMPLIFY US!
Many companies are realizing this the hard way. Tesla, Microsoft, Amazon, and others rushed to automate entire operations — only to find that machines alone can’t replace human judgment, adaptability, and creativity.

More than 55% of companies that replaced employees with AI now regret it.

Why? Because AI without a strategy is fragile.

At Accéder, we believe artificial intelligence only becomes powerful when guided by real experts and integrated with purpose. When HUMANS and AI work together, businesses see measurable gains — higher productivity, more substantial margins, and more intelligent decisions.

In my latest article, I explain why replacing humans with AI is a strategic mistake — and how the most successful companies are adopting human-AI symbiosis instead.

👉 Read the full article below to discover why “True intelligence comes from humans and machines working together.”

Check this article out: Michael Christian R. COLLEMICHE, Alexander E., Manuel Llorens, Mauricio Leal, Bruno Reyna, Francisco Teran, Manuel Valdivia, Iván Herrero Bartolomé, Linda Collazos, CDO LATAM, Natalie Riviere, Gabriela Vargas Gómez, Sophie Legendre, Luc Giguère, Neil Ginsburg, Thomas Rideg, Enio Moraes

#AI #BusinessStrategy #DigitalTransformation #Acceder #AgenticAI #Leadership #Innovation #titanagenticai | 17 | 2 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.885Z |  | 2025-10-21T12:13:03.949Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7384571354022477824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGul5d6eurtjA/feedshare-shrink_800/B4EZntEgK.IwAg-/0/1760619007765?e=1766620800&v=beta&t=L2SUTkZ7RRQQflOpxMPzON13DCR_6vx_dHRCfhsu2Hk | 🌟 A Dream in Motion: Bringing AI to the Classroom for Thousands of Teachers

Since the beginning of my journey in AI (10+ years), I’ve dreamed of building technology that truly helps people — not just companies or machines, but HUMANS. Today, that dream is becoming reality. 💫

I’m proud to announce a new collaboration between Accéder and Movimiento STEM+, the most important NGO for STEM education in Mexico and Latin America. Together, we’ll empower thousands of elementary and secondary school teachers to embrace AI tools and make learning more dynamic, creative, and impactful. 🇲🇽🤖📚

Our mission: help teachers introduce AI responsibly and practically — so they can inspire the next generation to use it ethically and intelligently.

🎓 Our first Masterclass: “Cómo Usar y Aprovechar al Máximo las Herramientas GPT en el Aula” - is going to start at 5:00 PM CDMX this coming October 30th.
 
In just one hour, teachers will learn how to:

 ✨ Use ChatGPT and similar tools to create dynamic activities and simplify complex concepts.
 
✨ Teach students to use AI critically and ethically.
 
✨ Detect when AI has generated work and guide students to think for themselves.
 
✨ Use AI as a creative companion — not a replacement.

Because the future of education isn’t about replacing teachers — it’s about empowering them.

Thank you to Movimiento STEM+ for joining forces in this transformative mission. Together, we’re planting the seeds of a new generation that will grow up understanding and shaping the future of AI. 🌎💡

Special thanks to my friend and STEM global leader, Graciela Rojas, Founder & CEO of Movimiento STEM+ and her fantastic team! Montserrat Sánchez, María Rosa Araiza Flores, Angélica Sandoval, Laura Segura Guzmán, Valentina Morales.

#AI #Education #STEM #TeacherTraining #AgenticAI #Accéder #MOVIEMITOSTEM #DeepTech #Innovation #Learning #FutureOfEducation #EdTech #OGI #tiatanagenticai | 15 | 3 | 1 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.886Z |  | 2025-10-16T12:50:09.500Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7384318316028428288 | Document |  |  | 🇨🇴✨ ¡Es un honor anunciar mi participación como panelista en el Congreso CDO LATAM 2025, el evento más importante sobre Inteligencia Artificial y Gobierno de Datos en Latinoamérica, que se celebrará los días 20 y 21 de noviembre en la Universidad de los Andes, Bogotá!

Tendré el privilegio de participar en la sesión:
 
🎙️ Mini Keynote + Panel: “Tendencias y Gobierno de Agentes de IA”
 🕚 20 de noviembre | 11:30 a.m. – 12:20 p.m. (hora Bogotá)

Acompañado por grandes referentes de la región como Eugenia Moreno, Miguel Angel Diaz Rodriguez y Leon Palafox, compartiremos cómo la nueva generación de Agentes de IA y plataformas agenticas está transformando las operaciones industriales y financieras en Latinoamérica.

Desde Accéder y nuestra plataforma TITAN, seguimos construyendo la próxima capa de inteligencia empresarial —una IA segura, precisa y de alto impacto para las empresas que están liderando esta nueva Revolución Industrial.

💡 Si eres ejecutivo, innovador o inversionista, no te pierdas este encuentro clave sobre “Inteligencia Artificial para el futuro de Latinoamérica”.

 👉 Regístrate en los links que están en los comentarios:
 
Nos vemos en Bogotá, donde el futuro de la IA empresarial está tomando forma. 🚀🤖

Gracias especiales a los cracks del CDO LATAM: Claudia Chirinos Calderon, Michael Christian R. COLLEMICHE, Iván Herrero Bartolomé, Daniel Monteagudo Benavides

#CDOLatam2025 #AI #AgenticAI #TITAN #Accéder #DeepTech #EnterpriseAI #ArtificialIntelligence #Innovation #DataGovernance #IndustrialAI #Bogotá #LatAmTech | 26 | 3 | 2 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.887Z |  | 2025-10-15T20:04:40.541Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7384220889766334464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGFbSCmapf-bQ/feedshare-shrink_480/B4EZnoFxPWHMAY-/0/1760535451097?e=1766620800&v=beta&t=76lCCKSoZz02PSe8cyK1V60fdhQDxm3KtgMWlm1Rdck | 🧠 Beyond Artificial Intelligence: When Machines Learn to Think Like the Brain 🤖 

🏭  Industrial leaders are racing to harness AI—but most of today’s systems still run on computing architectures built for spreadsheets, not for the fast, chaotic rhythm of factories, logistics, or supply chains.

What if AI could react like the human brain—processing billions of signals, consuming a fraction of the energy, and responding to change in milliseconds?

That’s the promise of neuromorphic computing — the next frontier where AI meets neuroscience. By mimicking how neurons communicate through spikes of activity, Spiking Neural Networks (SNNs) unlock real-time intelligence at the edge: smarter machines, faster decisions, and greener operations.

At Accéder, we’re building this future into TITAN—our enterprise-grade Agentic AI platform—by combining LLMs’ cognitive reasoning with SNNs’ sensory reflexes to create the next generation of enterprise intelligence for manufacturing, supply chain, and finance. Learn more about the transformative technology we are adopting (link in the comments).

Welcome to the dawn of brain-inspired AI for industry. 🧠⚡

Check this out: Michael Christian R. COLLEMICHE, Alexander E., Aldo Zaimi, CDL-Montreal, Justin Dunnion, Ismael Alaoui, Allen Shashaty, Karine Syrine NAHI, M.Sc, MBA, Anne Robinson, Radical Ventures

#titanagenticai #titansnn #titanllm #titanneuromorphic #agenticai #specializedllms #snn #spikingneuralnterworks #neuromorphicai | 5 | 2 | 1 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.889Z |  | 2025-10-15T13:37:32.310Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7382524138219003904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIAURC_lkLWQ/feedshare-shrink_800/B4EZnPBVMGGUAk-/0/1760114857759?e=1766620800&v=beta&t=1gVMvmOtLV47Y20Bw7PsGalAsbCuo_WlHDPcalz7TSA | 🎉 Bravo Creative Destruction Lab! 👏🏼

You continue to demonstrate why you are one of the world’s leading deep-tech accelerators — and now, with a Nobel laureateJohn Martinis among your mentors, you’ve set a new global benchmark for excellence.

It’s an incredible honor to be part of this visionary community and to represent CDL-Montreal as a graduated company that continues to grow thanks to the mentorship, rigor, and inspiration this program instills.

Proud to see Canada leading the way in shaping the next generation of deep-tech innovators - and Accéder be part of the Agentic AI Industrial Revolution. 🇨🇦🚀

Felicidades: Karine Syrine NAHI, M.Sc, MBA, Valentina Tacchi, Vittorina S., Anne Robinson, Samantha Betancourt, Isaac Souweine, Guillaume de Tilly-Dion 

#CDL #DeepTech #Innovation #Entrepreneurship #AI #Canada #Leadership #TitanAgenticAI | 10 | 1 | 0 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.890Z |  | 2025-10-10T21:15:15.217Z | https://www.linkedin.com/feed/update/urn:li:activity:7382456794935091200/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7381648750907170816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEoUu0u-wxWnQ/feedshare-shrink_800/B4EZnDia84HEAg-/0/1759922205304?e=1766620800&v=beta&t=WCR4vQZwiWOdyIi1Q1MowBFQqLICCIt0Up_dWJ2Pidk | 🔥 Beyond LLMs: Building Brain-Inspired AI for the Next Era of Enterprise Intelligence 🔥

LLMs have transformed how companies use AI — powering reporting, KPIs, and decision support across ERP, CRM, supply chain, and finance. The global enterprise LLM market is already $4.6 B (2024) and growing at ~28% CAGR.

But here’s the truth executives and investors must hear:

 👉 LLMs are great at reasoning over data but struggle in real-time, event-driven industrial operations.

 👉 They can’t sense and react instantly to anomalies on the factory floor, demand shocks, or micro-second transaction flows.

 👉 They’re compute-hungry, expensive to run continuously, and not optimized for the edge.

That’s why Accéder is building the next layer of enterprise intelligence with TITAN — fusing:

 ⚡ Spiking Neural Networks (SNNs) for reflex-like sensing at the edge (10-100× more energy-efficient).

 🧠 Domain-adapted LLMs for strategic reasoning, forecasting, reporting, and explainability.

Together, this hybrid approach enables enterprises to sense, decide, and act in milliseconds — transforming manufacturing, supply-chain, and finance!

🌎 Our vision: to lead the Industrial AI Revolution with a brain-inspired enterprise layer — a game-changer for companies seeking speed, resilience, and profitability.

📢 Business leaders: Are your current AI pilots delivering ROI, or still stuck at the “chatbot” stage?

💰 Investors: This is a $1B+ opportunity to back deep-tech that goes beyond LLM hype.

👉 Read the full piece: “Beyond LLMs: Building Brain-Inspired AI for the Next Era of Enterprise Intelligence” by Oscar Gonzalez:   <full article in the comments>

This might be interesting to you: Michael Christian R. COLLEMICHE, Alexander E., Marc Pare, Craig Tavares, Ian Rae, Neil Ginsburg, Francisco Teran, Carlos Calderón, Iván Herrero Bartolomé, Omar Costilla-Reyes, PhD, Marc Lijour, Luc Giguère, Maxime Julien 


#IndustrialAI #AgenticAI #LLM #SNN #DeepTech #TITAN #Accéder #NeuromorphicAI #EnterpriseAI #InvestInAI #SupplyChain #Manufacturing | 12 | 1 | 3 | 1mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.892Z |  | 2025-10-08T11:16:46.618Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7379494775923564544 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkg5hQGGXrdQ/feedshare-shrink_800/B4EZmk7Y45KoAk-/0/1759408657082?e=1766620800&v=beta&t=AIfQfxvX-tyrH7AEPz6Y1W9Sme4AcCQ4dhJ_bK8Y09g | 🚀 Accéder Launches $20M Seed Round to Build the Enterprise Intelligence Layer of the Future! 

Today, we’re officially opening our $20M seed round (with 7M + 7M + 6M trenches given upon milestones) to accelerate our flagship TITAN — our enterprise-grade and Deep Tech Agentic AI platform, soon enhanced with proprietary domain-specific LLMs and SpikingBrain Neural Networks (SNNs).

Our mission:

➡️ Create a new global category — the Enterprise Intelligence Layer — a $20B market by 2030.

➡️ Empower manufacturing companies in the Americas & Europe to maximize their existing ERP, CRM, BI, business systems and individual documents — no rip-and-replace, no long, costly implementations.

➡️ Deliver secure, private, cloud, hybrid, on-premise, real-time decision intelligence that boosts business KPIs and improves workforce productivity & quality of life.

➡️ Cement Canadian AI technology sovereignty in a market dominated by US hyperscalers and create the foundation for future Deep-Tech products.

Now, we have:

✅ A talented core team of engineers, product leaders, and data scientists.

✅ A group of extraordinary professionals is already committed to joining as soon as we expand our budget.

✅ A product ready to scale — with a clear roadmap for IP-driven growth, profitability, and global reach.

✅ Key collaborations with the National Research Council Canada / Conseil national de recherches Canada, and Mila - Quebec Artificial Intelligence Institute.

For me, this isn’t just about building a company; it’s about leaving a legacy — a Canadian-born Deep-Tech leader that future generations can build upon. 

Let's talk!

Shout out and thanks for your support to: Yulen Gallastegui Michelena, Ricardo Praelli, Neil Ginsburg, Sandra Villalba, Mark Woolen, Michael Christian R. COLLEMICHE, Alexander E., Andrés E., Gildardo Salas Campbell, Manuel Valdivia, Berthony Cereceda Quintanilla, Pascal Leblanc, Louis Brun, Luc Giguère, Olivier Caron-Lizotte, Marc Pare, Ian Rae, Mike Bouchard, Maximilian Leger, Hugo Sereys, Laurence Bertoux, Graciela Rojas, Bruno Reyna, Karine Syrine NAHI, M.Sc, MBA, Isaac Souweine, Guillaume de Tilly-Dion, Ismael Alaoui, Geneviève Wiedmann-Harland, Justin Dunnion, Akhilesh Prabhu, Nathalie Provost, Nathalie Dubé, Jean-Dominique Ieraci, Cameron MacKay, Stewart Wheeler, Uffe Galsgaard, Mélanie Guertin, Samir Mounir, Ph.D., MBA.

#DeepTech #AgenticAI #EnterpriseIntelligenceLayer #LLM #SNN #CanadianTech #Industry40 #Accéder #TITAN #SeedRound | 45 | 17 | 10 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.894Z |  | 2025-10-02T12:37:38.963Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7377531070701015040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFHqOoajcHUw/feedshare-shrink_800/B4EZmJBZY_HIAg-/0/1758940472832?e=1766620800&v=beta&t=gbbl7Pd9f1FTnLPSNrEmqvmQwysoDQSMLubb8hM7GvY | 🚀 After a wonderful #ALLIN2025, we’re back in action with Mila - Quebec Artificial Intelligence Institute in our game-changing collaboration with this world-leading AI research institution—a transcendent milestone for Accéder 💫.

It is an incredible experience working alongside Aldo Zaimi, gaining valuable insights as we build our specialized LLMs to power #TITAN, our Agentic AI platform—designed to deliver highly accurate and secure results for our current clients and the future users of our specialized LLMs.

We’re excited to expand this partnership and boldly step into the future as a Canadian Deep-Tech 🇨🇦🤖 innovator, leading the way in the new wave of the Industrial AI Revolution. We believe AI can be a force for good—driving efficiency, innovation, and positive impact on people, industries, and the world.

A special thanks to our AI R&D and Product Captain, Ricardo Praelli, for his exceptional leadership in pushing the frontiers of enterprise Agentic AI and helping us turn this vision into reality 👏🏼🙏🏼.

Our goal remains clear: to deliver the most advanced Enterprise Intelligence Layer for industrial and financial companies—transforming how they operate with secure, high-precision, enterprise-grade AI.

Thanks also for your expert support: Alexander E., Michael Christian R. COLLEMICHE, Roberto Amor Arroyo, Anne Robinson, Jorge Antonio López García, Mauricio Reyes

#DeepTech #AgenticAI #TITAN #EnterpriseAI #IndustrialAI #AIInnovation #LLM #MadeInCanada #ALLIN2025 #Mila #titanagenticai #aifinance #aisupplychain | 20 | 1 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.895Z |  | 2025-09-27T02:34:35.154Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7377100390447722497 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHxQuHJOjkxXA/feedshare-shrink_800/B4EZmC5sEoIMAg-/0/1758837788018?e=1766620800&v=beta&t=jhbHeYVf7MqkAPmKpYXvPxR3Yb2pXVxt3s4ntNMiyus | Great #ALLIN2025! It was amazing to reconnect with leaders across the Canadian tech industry. Exciting synergies and future collaborations are already on the horizon.

One of the main themes was Agentic AI and its ability to automate workflows. Workflows are nice — but the real value of intelligent agents lies in going further: executing complex tasks, optimizing outputs, and generating end-to-end business operations.

Think about something like KPI generation — a task that usually requires juggling multiple Excel sheets and data sources. With Agentic AI, this can be done instantly, accurately, and at scale.

That’s the future we’re building with TITAN. 🚀

It was great to see you again and meet you: Marc Pare, Craig Tavares, Hugo Sereys, Robin Hughes, Uffe Galsgaard, Allen Shashaty, Maxime Julien, Marc-Alexandre F., Justin Dunnion 

#EnterpriseAI #AgenticAI #AI #DigitalTransformation #TITAN #Accéder #titanagenticai | 27 | 0 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.896Z |  | 2025-09-25T22:03:12.980Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7376720468336357376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFOIbtAX-FBdQ/feedshare-shrink_800/B4EZl9gJvwGoAg-/0/1758747210728?e=1766620800&v=beta&t=58YuUg8m-da2kadVIRmC9OSotlQqMUqU9JufIByS2J0 | What a great event #ALLIN2025!!! I had the chance to catch up with Quebec’s top entrepreneurs and startup stars 💫  - always getting great advice and looking for synergies and collaborations adding to our success with our #AgenticAI platform TITAN. 

Great news coming soon!!!🚀💪🏼👏🏻

It was awesome to see you Géraldine J., Louis Brun, Luc Giguère, Francois R.-Moisan, Olivier Caron-Lizotte, Félix Bélisle Dockrill, and Felipe Cordero. | 35 | 1 | 1 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.897Z |  | 2025-09-24T20:53:32.490Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7376378602457677824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9dCFAXH8FCQ/feedshare-shrink_800/B4EZl4pOXBHgAg-/0/1758665699969?e=1766620800&v=beta&t=Lhoaj2ZVtX1vharEHJxd26qstvZivrpDwvz3HT58O48 | Behind the scenes at the #ALLIN Montreal 2025!!! 👀 See you soon!!! Scale AI, Mila - Quebec Artificial Intelligence Institute, SAP, Cohere 🚀

#TITAN #TitanAgenticAI #Accéder #AIEvents #AIMontreal | 33 | 1 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.897Z |  | 2025-09-23T22:15:05.313Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7376364600268582912 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFKFH9pUEpF4A/feedshare-shrink_800/B4DZl3RjkWJMAg-/0/1758642717703?e=1766620800&v=beta&t=SpqwDL5nps8rACfnPW7rwuEmb1hUCuKi27hGvY3E7JI | Me da mucho gusto compartir que Accéder estará como sponsor en el #CongresoCDOLatam2025 del prestigioso CDO LATAM el 20 y 21 de Noviembre en Bogotá! 🇨🇴

Estaremos compartiendo experiencias y aprendizajes que hemos logrado a través de todos estos años en el negocio de desarrollar tecnología empresarial con #IA. 

También podremos platicar de mejores prácticas, los errores frecuentes y cómo la #IAagéntica está y seguira cambiando la manera en que trabajamos y cómo aprovechamos los datos de nuestras empersas!

Amigos en Colombia, ahí nos vemos! Valérie Noel, Sandra Villalba, Bruno Reyna, Cristhian C., Freddy Mejia Rocha, Fredy Enrique Mena Andrade, Benjamin Solins, Danny Bravo

#Accéder #TITAN #AgenticAI #AILatam #AICDOLatam #CDOLatam2025 | 24 | 6 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.898Z |  | 2025-09-23T21:19:26.931Z | https://www.linkedin.com/feed/update/urn:li:activity:7376282190445187072/ |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7375966264130961408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEt3Jof5VMCPQ/feedshare-shrink_800/B4EZlyyOqwHoAg-/0/1758567394603?e=1766620800&v=beta&t=bUh23Fxf6iiMjb_P8tab3SMnP0WQII1VuHFmvF92HZE | 🚀 At ALL IN 2025 in Montreal, sharing how TITAN is redefining enterprise AI.

ALL IN is one of the most important gatherings for AI leaders, innovators, and decision-makers in Canada and beyond. I’m thrilled to be part of this year’s event, sharing Accéder’s vision for enterprise-grade AI.

At Accéder, we’re building the future with #TITAN, our #AgenticAI platform that will be powered soon by our domain-specialized LLMs.

✨ For businesses: TITAN connects directly to your ERP, CRM, SCM, finance and any other system, enabling specialized intelligent agents that get what you need in seconds and execute real business actions, reduce complexity, and deliver measurable ROI.

💡 For investors: TITAN represents a $1B+ opportunity as we launch our next $20M investment round. With proven traction and our new deep-tech strategy, we’re redefining how enterprises adopt AI at scale.

I’d love to connect at ALL IN — whether you’re a business leader looking to transform your operations with AI or an investor searching for the next deep tech opportunity. Let’s talk about how TITAN can shape the future together.

📅 Join us: ALL IN 2025 – Montreal, Sept 24–25

See you there: Justin Dunnion, Ismael Alaoui, Pascal Leblanc, Isaac Souweine, Allen Shashaty, Yassine Lazraq, Aldo Zaimi, Luc Giguère, Karine Syrine NAHI, M.Sc, MBA

#ALLIN2025 #EnterpriseAI #AgenticAI #DeepTech #LLM #TITAN #Accéder #MontrealAI | 16 | 5 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.900Z |  | 2025-09-22T18:56:36.195Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7374425558295928832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG9Kj0shxa6ow/feedshare-shrink_800/B4EZlc495HHEAg-/0/1758200062287?e=1766620800&v=beta&t=yvGjTLSrOhntmaDKMasxSR5Izfx9EYPmE7l_3bJFCYA | ChatGPT’s Consumer Surge ≠ Enterprise Readiness

A new usage study of ChatGPT (700M users; ~18B weekly messages by July 2025) shows rapid consumer adoption—but also why generic chatbots struggle in business settings.

Key findings (consumer usage):

🔹 Non-work messages grew from 53% → 70% of all usage; work use skews to writing assistance and “practical guidance.”

🔹 Top topics: Writing, Seeking Information, Practical Guidance (~80% of conversations).

🔹 Work usage is higher among educated, professional cohorts; “doing” (production outputs) is a minority vs. “asking” (advice/decision support).

🔹 Overall: meaningful consumer value, especially as a research assistant, less as an end-to-end work executor.

Why this matters for business:

▶️ Generalist bias: ChatGPT is optimized for broad, conversational help—not system-of-record integrity, auditability, or transactional execution.

▶️ Data control gaps: Consumer/chat-first tools complicate data residency, lineage, PII handling, and compliance (SOX, GDPR, HIPAA, etc.).

▶️ Operational friction: Hallucinations, shifting model behaviour, and limited enterprise context make it hard to meet SLAs and pass internal controls.

__________________________

What #TITAN Delivers for #Enterprises (built for systems, not just chats)

Context-aware accuracy

👉 Unlike generic tools, TITAN connects directly to ERP, CRM, Finance, and Supply Chain systems. It doesn’t “guess” — it works with your company’s real data, in real time, ensuring accuracy in every response.

Specialized intelligent agents

👉 Instead of one general chatbot, TITAN deploys domain-specific agents — for forecasting, inventory, compliance, financial reporting, or customer care. Each agent is tuned to solve business-critical problems end-to-end.

Data integrity

👉 Direct, governed connections to ERP/CRM/Finance/SCM with read/write controls, validations, and full audit trails.

👉 Deterministic workflows and multi-agent orchestrations reducing hallucination risk.

Security

👉 Private cloud / hybrid deployments; SSO, RBAC/ABAC, key management; network isolation with signed actions, immutable logs, and policy enforcement aligned to internal controls.

Privacy & compliance

👉 Data minimization and field-level protection, redaction, and configurable data residency with built-in policy guardrails.

💡 Bottom line: ChatGPT is excellent for broad guidance; TITAN is engineered for trusted execution inside your core systems—with data integrity, security, and privacy by design.

Look at the entire report in the comments.

Shout out to: Manuel Valdivia, Berthony Cereceda Quintanilla, Gildardo Salas Campbell, Michael Christian R. COLLEMICHE, Natalie Riviere, Maximilian Leger, Bruno Reyna, Isaac Souweine, Justin Dunnion, Pedro Herrera, MBA

#Accéder #TITAN #TITANAgenticAI #CanadaTech #QuebecTech #AI #GenAI #EnterpriseAI #AgenticAI #DataIntegrity #Security #Privacy #AIGovernance #Compliance #ERP #CRM #SupplyChain #MLOps #DigitalTransformation | 6 | 2 | 0 | 2mo | Post | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/ogi-acceder | 2025-12-08T04:58:30.903Z |  | 2025-09-18T12:54:23.299Z |  |  | 

---

## Post 31

https://www.linkedin.com/feed/update/urn:li:activity:7389034367429394432 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEj09VIHMP30g/feedshare-shrink_800/B4EZoVyGRJHMAg-/0/1761302048805?e=1766620800&v=beta&t=7tMbINwbGb3ZETTTaehBbm_jvMqUN1D-jVSmSsFt72E | Great evening surrounded by brilliant AI minds and industry innovators at Innovobot — a hybrid VC + Lab based in Montreal driving the next wave of Canadian tech innovation. 🇨🇦💡

From non-carbon construction materials to underwater drones, their portfolio is nothing short of fascinating. It was a pleasure to meet inspiring new people and reconnect with familiar faces pushing boundaries in their fields.

A huge thanks to Natalie Riviere for the invitation — always happy to be your plus one at events like this! 🙌

And Claude G. Théoret, congratulations on the fantastic work you’re doing at Innovobot. Your impact is clear — and yes, I’m holding you to that next AI Salon Montreal pitch! 😉

It was great to meet you: Nicolas Veilleux, Thomas Friedlaender, Michel Dubois, Pedro Gregorio, Margarita S, Qinghe Sun, Lionel T., Ph.D 

#AI #Innovation #VentureCapital #DeepTech #Montreal #Networking #CanadianTech | 37 | 3 | 4 | 1mo | Natalie Riviere reposted this | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.968Z |  | 2025-10-28T20:24:34.815Z |  |  | 

---

## Post 32

https://www.linkedin.com/feed/update/urn:li:activity:7355985729178456079 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWFF-PZnCYDw/feedshare-shrink_800/B4EZhSJ0EoHgAg-/0/1753724964084?e=1766620800&v=beta&t=U9HVXaaYn8ba1IT1BidbpBUFDMwGPLQ35aJydK-QKqs | This weekend, I had the privilege of shaping the next big step for Accéder alongside two of the smartest women I know — Natalie Riviere and Sophie Legendre.

Like nature, true growth emerges from the fusion of past experience and present clarity — creating something entirely new, grounded, and resilient.

There’s nothing more energizing than being in the company of brilliant minds, surrounded by nature, and taking time for calm reflection.

🌱 Ideas take deeper root when nurtured by purpose, perspective, and peace.

#SocialEntrepreneurship #Leadership #Philosophy #Reflection #AIforGood #WomenInBusiness #NatureAndInnovation #AccéderJourney | 46 | 1 | 1 | 4mo | Natalie Riviere reposted this | Oscar Gonzalez Iñiguez - OGI | https://www.linkedin.com/in/ogi-acceder | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.978Z |  | 2025-07-29T15:41:05.442Z |  |  | 

---

