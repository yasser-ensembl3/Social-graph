# Cynthia Lepage

## Position actuelle

**Titre** : Multimedia Graphic Designer
**Entreprise** : Freelance
**Durée dans le rôle** : 14 years 11 months in role
**Durée dans l'entreprise** : 14 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

- Print
- Graphic design
- Social Medias 
- Website
- Advertising

## Résumé

- I'm a creative entrepreneur / FILMMAKER/VIDEOGRAPHER • VIDEO EDITOR • GRAPHIC DESIGNER -

I guide creative entrepreneurs, CEOs, and artists in a content creation process that allows them to forge an authentic connection with their target audience. 
Together, we weave communications filled with emotions, revealing the very essence of their story, to gain trust and captivate those they seek to touch.

Every word, every image is an invitation to an experience where their message comes to life, leaving a lasting impression in the minds of those who watch or listen.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB8ebGYBas27i_6dY1Un8pSAz0A2TsnkB1o/
**Connexions partagées** : 3


---

# Cynthia Lepage

## Position actuelle

**Entreprise** : Keylight Studio

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Cynthia Lepage

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389254709024563201 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHOcPFKohb-mg/feedshare-shrink_1280/B4EZotFSwtHMAw-/0/1761692954157?e=1766620800&v=beta&t=oVMSXWlLdsZbT06stwXFRJGQ6kzAH9kU5-S1v8lsBAw | La vidéo, c'est du luxe. 
L'internet déborde d'informations, ton entreprise va se perdre dans les fins fonds du web et tu ne sera jamais viral avec tes vidéos. THE END.

À chaque jour, je vois des entrepreneurs passionnés freinés par ces fausses croyances, débordés par leur business, en se disant que le prochain client viendra par la volonté du Saint-Esprit. (💔 C'est là que ça fait mal!)

Et c'est pour eux que j'ai choisi la vidéo, parce que je sais que c'est un levier à la fois humain, stratégique et, oui, accessible.

Accessible?!
Oui, parce que la vérité c'est que la vidéo n'est pas un luxe, c'est un investissement sur l'avenir de ton entreprise.

✴️ NEWS FLASH = T'as pas besoin d'être viral. 🤯 
T'as juste besoin d'être vu par la bonne personne. 
Et quand tu parles sincèrement à cette personne dans ta vidéo, tu deviens visible, compris et, surtout, mémorable.

Fun Facts :
👁️‍🗨️ Le cerveau humain est branché sur le visuel. 
 90 % de l’information que ton cerveau perçoit est visuelle, donc la vidéo est le langage qu'il comprend le mieux.
👁️‍🗨️ L'authenticité c'est tout ce que t'as besoin.
 Une vidéo où t'es simplement toi peut tripler ton taux d’engagement.
👁️‍🗨️ La vidéo c'est un accélérateur de croissance.
 Les marques qui utilisent la vidéo dans leur stratégie grandissent jusqu'à 2 fois plus vite.

C'est le pont entre ta passion et la confiance de ton futur client.

La vidéo, c'est pas du luxe, c'est un investissement.

T'en pense quoi ... Considères-tu ta création vidéo comme encore un luxe ... 
ou si elle fait partie de ta stratégie? | 13 | 6 | 1 | 1mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:15.729Z |  | 2025-10-29T11:00:08.345Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7380998083674820608 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQEVi9j9jeNYCw/feedshare-thumbnail_720_1280/B56Zm6Sep1KEA0-/0/1759767031529?e=1765789200&v=beta&t=nQ-wRUxxdwtcSiUSKrqA_qmkGQlnUYT61VO_2EZdfOI | On oublie souvent que la vidéo, c’est plus qu’un outil de promo.

C’est une façon de créer un vrai lien, une émotion, une réflexion.

Mon but, c’est que ta vidéo parle à ton public comme s’il s’entendait lui-même.

🎯 Si tu veux qu’on explore ensemble comment donner plus de sens et d’impact à tes vidéos, écris-moi, pour qu'on s'en parle.

Parce qu’au fond, les vidéos qui marquent ne sont pas les plus “parfaites”.
Ce sont celles qu’on retient parce qu’elles nous font dire : 
“C’est exactement ça !”


#ContenuVideo #CreationDeContenu #VideoBusiness #VideoEntrepreneur | 7 | 0 | 1 | 2mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:15.730Z |  | 2025-10-06T16:11:15.461Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7376298024823578624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEQhg5k5vmUgg/feedshare-shrink_800/B4EZl3f89dIwAk-/0/1758646492788?e=1766620800&v=beta&t=WekRX-Cr3GKdQ_Ss5kbw6Yb42BVZlM_mPoPanpnAYWU | « Mon espace n’est pas assez beau pour la vidéo. »

C’est l’une des principales raisons pour lesquelles les entrepreneur·es hésitent à créer du contenu vidéo.
Ils regardent leur bureau, leur boutique, leur espace de travail… et ne voient que ce qui manque.

La vérité ?
Avec le bon œil, le bon cadrage et le bon éclairage presque n’importe quel environnement peut devenir un décor professionnel.

👁️‍🗨️ Parce que ce que tu vois VS ce que ma caméra voit sont deux réalités très différentes.

Curieux·se de voir ce qui est possible dans ton espace?
Réserve une discussion gratuite via mon lien pour voir comment ton environnement peut jouer en ta faveur. 👇 
https://lnkd.in/eNcFj9Jc

#contenuvideo #videobusiness #entrepreneurs | 6 | 2 | 0 | 2mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:15.730Z |  | 2025-09-23T16:54:54.108Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7370861649253023744 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQHW7wNSXk-qAA/feedshare-thumbnail_720_1280/B4EZkqPdZkIsA0-/0/1757350320657?e=1765789200&v=beta&t=_L5tqCkNGW9RQefOacWUnNwGjnXzFHuQEOLntlB0rjA | Tu publies du contenu… mais personne ne s'en rend compte? 🫤 
Tu n’es pas seul.e. 

Beaucoup d’entreprises s’étonnent de leur manque de visibilité sans réaliser qu’elles passent à côté de ce que les algorithmes adorent vraiment.

En réalité, les plateformes mettent surtout de l’avant le contenu qui retient l’attention plus longtemps.

Regarde la vidéo et découvre ce qui attire vraiment les algorithmes. 👇 | 9 | 1 | 1 | 2mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:15.731Z |  | 2025-09-08T16:52:41.169Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7365776680260444161 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETtGxZ07bgDA/feedshare-shrink_800/B4EZjh.22NHEAg-/0/1756138008695?e=1766620800&v=beta&t=hT1xzWij0rSwaf9O2GGexP2P__W1WSSz8-zhRLPdmBQ | La semaine dernière, une entrepreneure m’a dit :

« Je veux faire une vidéo pour mes réseaux sociaux, mais je ne veux pas dépenser trop… »
Moi : « Ok, combien as‑tu prévu? »
 Lui : « Genre… 250$? »
 Moi : 😅 

Le truc, c’est que la vidéo n’a pas besoin d’être incroyablement coûteuse pour être efficace. 

Mais il y a un seuil minimal à respecter pour que ton contenu soit professionnel et reflète vraiment les valeurs et le branding de ton entreprise.

Si tu descends en dessous de ce minimum, le résultat risque de sembler amateur : le son est mauvais, l’image floue, ou le message peu clair. Et là, c’est ta crédibilité qui prend un coup.

Une vidéo professionnelle, c’est un investissement intelligent : elle attire l’attention, crédibilise ta marque et fait passer ton message clairement à ton audience.

💡 Moralité : ce n’est pas une dépense, c’est un moyen de montrer à tes clients que tu es sérieux, cohérent et que tu prends soin de ton image.

Si tu as un projet vidéo en tête, on peut en discuter tranquillement pour voir ce qui serait possible et adapté à ton entreprise.
https://lnkd.in/eNcFj9Jc | 25 | 2 | 0 | 3mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:15.732Z |  | 2025-08-25T16:06:50.087Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7360648795354763265 | Video (LinkedIn Source) | blob:https://www.linkedin.com/428285ff-c7ab-4bc9-8fc4-9f3895a95bec | https://media.licdn.com/dms/image/v2/D4E05AQEKcE6yVzGa-g/feedshare-thumbnail_720_1280/B4EZhxvwwsGwCQ-/0/1754255003807?e=1765789200&v=beta&t=UJXJFmB3paWQsd6FYI2kxNWxi9NXNgYjx7bl1lyVv_s | Et si tu arrêtais de parler de toi dans tes vidéos ?
 … pour enfin parler à ton client ?

Les marques qui se démarquent aujourd’hui ne sont pas celles qui crient le plus fort.
 Ce sont celles qui savent raconter une histoire.
 Une histoire dans laquelle leur client est le héros,
 et où leur valeur ajoutée devient une évidence.

Si tu veux que ta vidéo connecte, inspire et convertisse, je de donne les 3 ingrédients essentiels :
 1️⃣ Parle à ton client, pas de toi.
 2️⃣ Raconte une transformation, pas un pitch.
 3️⃣ Sois vrai. L’authenticité crée la connexion.

Dans la vidéo, je t’explique comment structurer ton message pour que ta vidéo devienne un véritable outil de storytelling.

Prêt à montrer pourquoi c’est toi la bonne option ?
C’est par ici → https://lnkd.in/eNcFj9Jc

Parce qu’une histoire bien racontée vaut plus qu’un pitch parfait. | 16 | 1 | 0 | 3mo | Post | Cynthia Lepage | https://www.linkedin.com/in/cynthia-lepage | https://linkedin.com/in/cynthia-lepage | 2025-12-08T08:01:19.811Z |  | 2025-08-11T12:30:27.054Z |  |  | 

---



---

# Cynthia Lepage
*Keylight Studio*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [KeyP it Light](https://podcasts.apple.com/ca/podcast/keyp-it-light/id1745427072)
*2025-08-25*
- Category: podcast

### [Talks & Interviews | WIL Entertainment](https://womeninlighting.com/entertainment/talks-interviews)
*2025-05-15*
- Category: article

### [MEET THE 15 LIGHTWORKERS WHO STOLE THE SHOW IN 2023](https://www.keyssoulcare.com/connection/meet-the-15-lightworkers-who-stole-the-show-in-2023.html?srsltid=AfmBOoojLKhf7A8uyYP2RH2pR4ei7q2n7W0aKfvc9gNQWKMyaH4M8N7I)
*2025-05-01*
- Category: article

### [Women in Entertainment Lighting – Collected Light Volume Three | Celebration of light](https://lightcollective.net/light/ing/women-in-entertainment-lighting)
*2025-02-04*
- Category: article

### [Everyday Wellness with Cynthia Thurlow ™ - TopPodcast.com](https://toppodcast.com/podcast_feeds/everyday-wellness-with-cynthia-thurlow/)
*2025-05-14*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
