# Pierre Chamberland

## Position actuelle

**Titre** : AmBoSsador
**Entreprise** : Business of Software Conference
**Durée dans le rôle** : 9 years 3 months in role
**Durée dans l'entreprise** : 9 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

"To improve is to change; to be perfect is to change often." Winston Churchill.

I have 30 years of experience driving product innovation for technology businesses around the world, spanning semiconductors, consumer electronics, and cybersecurity. For 20+ years, I was the Founder and CEO of NetGovern (Netmail), an information governance software company that we sold to IPRO in a strategic M&A transaction. 

I am now an M&A Advisor, investor, coach, and mentor for software company founders, sharing the experience I gained during my career as a serial entrepreneur, executive leader, and technologist. I am a strong believer in the transformative power of open-book management and employee-ownership.

Specialties: Growth/Exit Advisory, Positioning & Marketing, Strategic Partnerships, Leadership, Building authentic & meaningful company cultures.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAB6lOMBAaCf8kJTJHQOFUkYxQC3B864704/
**Connexions partagées** : 4


---

# Pierre Chamberland

## Position actuelle

**Entreprise** : Concordia University

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pierre Chamberland

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400904841025200128 | Article |  |  | My buddy Pierre Herubel has put out a crazy deal for Black Friday, it ends tonight so I wanted my network to know about it. I am a paid client and truly enjoy working with his method. 

Thanks Pierre for offering a compelling rebate to growth minded entrepreneurs.

Grab the offer here: https://lnkd.in/eUpTfZ53 | 1 | 1 | 0 | 1w | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:35.646Z |  | 2025-11-30T14:33:36.263Z | https://www.skool.com/principles-9384/about |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7376634178550857728 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5054eeff-2d84-4409-97c4-c2186c88f12e | https://media.licdn.com/dms/image/v2/D4D05AQEhlmcqOuGlJQ/videocover-low/B4DZl7T0RIJEB4-/0/1758710485282?e=1765785600&v=beta&t=xEMdvAw22_CkkNrEvSK1gxfWP-PYV5KAvO4lI1ASkKk | 3 min awesome recap of what BoS is all about... hope to see you there... and not just because I'm finally doing a talk 😜 | 15 | 2 | 1 | 2mo | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:35.647Z |  | 2025-09-24T15:10:39.402Z | https://www.linkedin.com/feed/update/urn:li:activity:7376593784911839232/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7375587620027858944 | Text |  |  | I'm attending BoS USA 2025. Join me on October 6.

If there ever was a great time to invest in yourself and in your team, NOW is it. If you have any questions about the BoS event, feel free to DM me on LinkedIn. I'd love to connect with you there and chat more about employee ownership & financial literacy. | 3 | 2 | 0 | 2mo | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:35.647Z |  | 2025-09-21T17:52:00.406Z | https://www.linkedin.com/feed/update/urn:li:activity:7318290408269041664/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7373353158959611904 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e600b263-c140-4f4f-8549-8578533372b2 | https://media.licdn.com/dms/image/v2/D4D05AQHmQR1XmRY1gw/feedshare-thumbnail_720_1280/B4DZlNguqfH0A0-/0/1757942051242?e=1765785600&v=beta&t=YDR_XyNhrbSLjlQlC-gi8LhTazLe1gKBIU1tp10EvyE | Finally getting the story out... 20 years in the making (wow). This is going to be fun/interesting/contrarian/exciting.  I am REALLY looking forward to it. Hope to see you there! | 90 | 9 | 0 | 2mo | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:35.648Z |  | 2025-09-15T13:53:03.373Z | https://www.linkedin.com/feed/update/urn:li:activity:7373343611758817280/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7307703197563846659 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e05e84d2-efc9-43b1-8a7d-2f973ecf1f55 | https://media.licdn.com/dms/image/v2/D4E05AQFOwedre6jVpw/feedshare-thumbnail_720_1280/B4EZVbgbpxHMA8-/0/1740996984531?e=1765785600&v=beta&t=s3XmjMsIvKALP4IJmIiwGs5rZakjI9qEMbb14vYLaLk | Building a more fair workplace is by definition helping to build a more fair society.

Pls help foster awareness on the issue of Gender Equality. As one participant notes:  “… this is a responsibility we all have” yes indeed! 

Help flip the script - share (and watch) this video with your network, your co-workers, your family, your kids. Powerful stuff! | 9 | 0 | 0 | 8mo | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:39.548Z |  | 2025-03-18T10:03:32.859Z | https://www.linkedin.com/feed/update/urn:li:activity:7302270759521955840/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7293903282186407936 | Article |  |  | This is not the end of programming. It is the beginning of its latest reinvention….

Happy to share this “must read” opinion piece by Tim O’Reilly, brilliant Technologist (and Futurist) who has had a front row seat, and also been an active participant, in the evolution of computing over the past 30+ years. 

Read it, then read it again… let it sink in. If you work in tech/software, share it with your colleagues. Welcome the (hopefully) opinionated conversations it will create. | 14 | 1 | 1 | 9mo | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:39.549Z |  | 2025-02-08T08:07:36.643Z | https://www.oreilly.com/radar/the-end-of-programming-as-we-know-it/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7270570204689051648 | Article |  |  | Yeeeehaaaa! Wire.com acquires Pydio… an amazing add-on to an already amazing collaboration stack! 

Kudos to the team at Wire for recognizing the potential of Pydio’s tech and bringing it into their fold. 

From the email newsletter I just got: “This marks a monumental step in our journey to redefine secure collaboration. Together, we’re working to create the world’s first unified, secure workspace solution… By integrating Wire’s end-to-end encrypted communications platform with Pydio Cells’ secure document management, sharing, and collaboration capabilities, we’re building a single, seamless platform for text, voice, video + document sharing and collaboration - Benjamin Schilz, CEO, Wire”

I cannot wait to see how the new bigger & better dev team at Wire will amaze us with this smart integration. The bar is high as these 2 very talented dev teams have taught us to expect great things. I’m sure they’ll deliver, and then some. 

Exciting times ahead for Wire as regulated industries move even faster towards privacy-first & data sovereign collaboration in support of their international growth. 

#wire.com
#pydio.com | 5 | 2 | 0 | 1yr | Post | Pierre Chamberland | https://www.linkedin.com/in/pchamberland | https://linkedin.com/in/pchamberland | 2025-12-08T07:18:39.550Z |  | 2024-12-05T22:50:17.460Z | http://wire.com/ |  | 

---



---

# Pierre Chamberland
*Concordia University*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [Pierre Chamberland Email & Phone Number | 85 Advisors Founder in Residence Contact Information](https://rocketreach.co/pierre-chamberland-email_2776929)
*2025-01-01*
- Category: article

### [In conversation with Graham Carr](https://qcna.qc.ca/in-conversation-with-graham-carr/)
*2025-02-27*
- Category: article

### [Concordia launches a commemorative public history project to mark 50 years - Concordia University](https://www.concordia.ca/news/stories/2024/12/03/concordia-launches-a-commemorative-public-history-project-to-mark-50-years.html)
*2024-12-03*
- Category: article

### [RSM Richter Chamberland gift announcement, 2009-24](https://www.flickr.com/photos/concordiaalumnipics/15199118962/)
*2025-02-12*
- Category: article

### [INGREDIENTS FOR REVOLUTION](https://spectrum.library.concordia.ca/id/eprint/993126/1/Ketchum_Ingredients-lr.pdf)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Fun at Homecoming 2021! | News - Concordia University](https://www.concordia.ca/cunews/offices/advancement/2021/10/06/fun-at-homecoming-2021.html)**
  - Source: concordia.ca
  - *Oct 6, 2021 ... The Concordia University Alumni Association (CUAA) hosted its Annual ... Bhuiyan led the discussion with panellists Pierre Chamberland...*

- **[Thank You](https://walrus-assets.s3.amazonaws.com/PDFS/The_Walrus_Donor_Listing_2021.pdf)**
  - Source: walrus-assets.s3.amazonaws.com
  - *Concordia University. Labatt Breweries of Canada. Meta. Ontario Arts Council ... Pierre Chamberland. Shakir Chambers. Jennifer Chapman. Alison Chapman...*

- **[DIGITAL HEALTH](https://www.concordia.ca/content/dam/concordia/aar/docs/magazine/2021-Fall-Concordia_University_Magazine.pdf)**
  - Source: concordia.ca
  - *concordia university magazine fall 2021 | 17. “THE NEWLY EXPANDED AWARDS WILL ... Pierre Chamberland of. IPRO, Charlotte Savage, undergraduate student...*

- **[Thank You](https://walrus-assets.s3.amazonaws.com/img/AD_DonorSpread_MAY24_05.pdf)**
  - Source: walrus-assets.s3.amazonaws.com
  - *Pierre Chamberland. Jennifer Chapman. David Cheatley. Diana Chown. Bent ... Concordia University. Deloitte, Office of the. Chair, Canada, Chile. Enbri...*

- **[Annual Report](https://fgmtl.org/wp-content/uploads/2023/06/FGM_RA-2022_EN_Final_web.pdf)**
  - Source: fgmtl.org
  - *the project: the Concordia University Foundation, the Skagit Environmental Endowment Commission, ... Fonds Fondation Pierre Chamberland. 1. Fonds Fond...*

- **[Full text of "Queen's Alumni Review 2000"](https://archive.org/stream/queensreview74/queensreview74_djvu.txt)**
  - Source: archive.org
  - *Daughter Catherine is a student at Concordia University, and son Chris is ... Pierre Chamberland Allison Charters Alan Chen Meds '75 Bruce Chernoff Sc...*

- **[Full text of "Queen's Alumni Review 2001"](https://archive.org/stream/queensreview75/queensreview75_djvu.txt)**
  - Source: archive.org
  - *... Pierre Chamberland Conrad Chan A/S '92 Allison Charters Alan Chen Meds '75 ... (Concordia) University in 1949, then graduated from Queen's in 1951...*

- **[THE FAMILY ADVANTAGE](https://marchesdescapitaux.bnc.ca/assets/media/FinancialMarkets/PDF/family_advantages/en/TheFamilyAdvantage_2023_E_Digital_V6.pdf)**
  - Source: marchesdescapitaux.bnc.ca
  - *Me Jean-Pierre Chamberland. Partner, Fasken Martineau DuMoulin LLP ... A graduate of Concordia University with a B.A. in. Political Science, Lino A .....*

- **[THE HEART OF GREATER MONTRÉAL](https://fgmtl.org/wp-content/uploads/2020/12/FGM-Annual-Report-2016.pdf)**
  - Source: fgmtl.org
  - *FONDS FONDATION PIERRE CHAMBERLAND. 8 240. David Suzuki Foundation. 1 000 ... Concordia University (Art Hives). 15 000. Conseil Communautaire Notre-Da...*

- **[Ottawa South Community Association Review (OSCAR) October, 2023](https://oldottawasouth.ca/wp-content/uploads/2023/10/2023-10-October.pdf)**
  - Source: oldottawasouth.ca
  - *Oct 1, 2023 ... ZONE F2: Pierre Guevremont (Coordinator), Paulette Theriault, Alaster. Ayson, Judy & Pierre Chamberland, Luc & Sydney Grenier, Mary Jo...*

---

*Generated by Founder Scraper*
