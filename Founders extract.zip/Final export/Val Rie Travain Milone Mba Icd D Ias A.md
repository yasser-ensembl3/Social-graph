# Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397640470312427521 | Article |  |  | Canada just went all-in with its investment for space future with Europe 🇨🇦🚀🇪🇺

With an historic decision to boost Canada’s investment in ESA programmes by C$528.5M – a tenfold increase over previous levels, Ottawa is sending a clear signal: space is strategic, for our economy, our security and our climate. 

Beyond the headlines, this is a game-changer for the Canadian space ecosystem. Thanks to the unique CSA–ESA cooperation agreement, Canadian companies and researchers gain broader access to European missions, contracts and new business opportunities – turning public investment into jobs, innovation and export capacity back home. 

I am thrilled as this reinforces the opportunity to deepen EU–Canada collaboration on major programs that deliver critical solutions for a sustainable future, especially around:
 •	🌍 Earth observation data for climate resilience, Arctic monitoring and disaster risk reduction
 •	📡 Next-generation telecommunications to connect remote locations and communities
 •	🛰️ Navigation and positioning services for smarter, greener mobility
 •	🛡️ Space safety & situational awareness to protect the space environment we all depend on

If we get this right, Canada and Europe can together turn these investments into real impact on the ground – from climate action to secure connectivity and resilient infrastructure.

This is the moment to build bold, transatlantic space partnerships. Exciting time ahead ! 

#Space #CanadaSpace #CSA #ESA #EarthObservation #Telecommunications #SustainableDevelopment #EUCanada #NewSpace | 33 | 0 | 0 | 2w | Post | Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A | https://www.linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | https://linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | 2025-12-08T04:40:37.763Z |  | 2025-11-21T14:22:09.636Z | https://www.asc-csa.gc.ca/eng/funding-programs/canada-esa/about-cooperation-agreement.asp |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7336718289286430720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGVezFQ2l6bzw/feedshare-shrink_800/B4EZc8h4JgGcAo-/0/1749067204610?e=1766620800&v=beta&t=PMVh7OFARUTlu0jHZ22ZlT30KoXX_HalG0cobRrFP8o | Busy and exciting times at Calian Advanced Technologies right now …SatelliteAsia, SpaceOps, CanSec, Horizons2025…just to name a few of the conferences where our team expertise was highlighted. This week we were pleased to welcome Josef Aschbacher, Eric Morel de Westgaver and the whole ESA delegation in Canada alongside Lisa Campbell and the CSA team. Keeping strong ties between Canada and Europe is key for the Space industry. Calian is proud of being amongst ESA key Canadian partners. | 24 | 0 | 0 | 6mo | Post | Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A | https://www.linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | https://linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | 2025-12-08T04:40:37.764Z |  | 2025-06-06T11:39:09.800Z | https://www.linkedin.com/feed/update/urn:li:activity:7336119576784433152/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7308634957076156416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHa4gSu9m-7KQ/feedshare-shrink_2048_1536/B4EZW0eREcHcAw-/0/1742489588617?e=1766620800&v=beta&t=J1njLdYFwOW8npn40BhyGcR1jLqPP7mfF0PpJK34bvc | Very proud of this achievement from our team which demonstrates once again the quality of our technology in high-precision large antennas. This is a great illustration of our long term relationship with NASA, being their trusted partner for essential scientific programs. | 29 | 2 | 0 | 8mo | Post | Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A | https://www.linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | https://linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | 2025-12-08T04:40:37.765Z |  | 2025-03-20T23:46:01.638Z | https://www.linkedin.com/feed/update/urn:li:activity:7308536556313608192/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7300332747313565697 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHYGelfOK-ZFg/feedshare-shrink_1280/B4DZTc6n0UHIAk-/0/1738873143339?e=1766620800&v=beta&t=Y3cLRryV9Y5vTq_HXrAKJDWEIS-WAEW6wVyIQNvLT80 | Exceptional recognition for our SatCom product team. Amazed by your leadership and recognition internationally ! Great team work :) | 15 | 0 | 0 | 9mo | Post | Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A | https://www.linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | https://linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | 2025-12-08T04:40:37.765Z |  | 2025-02-26T01:56:00.583Z | https://www.linkedin.com/feed/update/urn:li:activity:7293362586698366977/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7300331911405600768 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHE7klsrklfLQ/feedshare-shrink_800/B4DZTxo3yUGkAg-/0/1739220811830?e=1766620800&v=beta&t=s3Ks8JItjhmgVNsZHCRC38KInSG6L7i-Ln7RAgLciUM | Great achievement team ! So proud of having you part of the Calian family ! | 24 | 0 | 0 | 9mo | Post | Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A | https://www.linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | https://linkedin.com/in/val%C3%A9rie-travain-milone-mba-icd-d-ias-a-57229 | 2025-12-08T04:40:37.766Z |  | 2025-02-26T01:52:41.287Z | https://www.linkedin.com/feed/update/urn:li:activity:7294820814271528960/ |  | 

---

