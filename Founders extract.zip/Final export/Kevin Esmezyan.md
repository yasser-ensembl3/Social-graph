# Kevin Esmezyan

## Position actuelle

**Titre** : Chief Product Officer
**Entreprise** : Matador
**Durée dans le rôle** : 1 year 7 months in role
**Durée dans l'entreprise** : 4 years 2 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Software Development

## Description du rôle

All things Product, Marketing & Growth.

## Résumé

| Product & Marketing at Matador AI, leading AI innovation in the automotive industry. 
| Developed a pioneering ad bidding algorithm used by most dealerships across North America. 
| Founder of Spectrums AI, dedicated to using AI to support neurodivergent individuals.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABtJS6ABa18Vze9z7BGM6rgDgt7AqIiK3jE/
**Connexions partagées** : 16


---

# Kevin Esmezyan

## Position actuelle

**Entreprise** : Matador

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Kevin Esmezyan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398846844199510016 | Article |  |  | As of today, Matador AI is officially a Preferred Partner of Nissan USA in their brand-new AI Lead Nurturing category.

We continue to shape, every single day, how AI elevates the modern dealership.

Learn more: https://lnkd.in/emCNeagX | 13 | 1 | 1 | 1w | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:18:58.137Z |  | 2025-11-24T22:15:51.584Z | https://www.nissandigitalprogram.com/AILeadNurturing/MatadorAI |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397179119274455041 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFDkb1MRszU6g/image-shrink_800/B4EZqdR23GHgAc-/0/1763575295923?e=1765782000&v=beta&t=uk89JJLjomRaQrDobeWYlIjyuSFSOGesdz8udcLNGN8 | 238th fastest growing tech company in North America 📈 
For some it's success, for us, it's 238 reasons we need to lock in for 2026. | 9 | 3 | 0 | 2w | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:18:58.138Z |  | 2025-11-20T07:48:54.977Z | https://www.linkedin.com/feed/update/urn:li:activity:7396970941898969089/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7392243479185367040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGB48I6qf6pqQ/feedshare-shrink_800/B4EZpZ.L2iKcAg-/0/1762446065788?e=1766620800&v=beta&t=rZ3N5igI8Sz7tLiqbgiJ_Kavz62qHjVRq9Fs2wlt1jg | Talking all day: ✅
Listening to myself talk: 😖

Jokes aside, big thanks to Jen Suzuki for having me on Dealer Talk! Excited to share how AI is transforming the way dealerships run. | 12 | 0 | 0 | 1mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:18:58.138Z |  | 2025-11-06T16:56:26.680Z | https://www.linkedin.com/feed/update/urn:li:activity:7392234590649872384/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7363325946721935360 | Text |  |  | We’re growing fast at Matador AI and we’re hiring a Senior Software Engineer to take on some truly complex, high-impact work. 

You’ll be building and optimizing real-time Kafka pipelines, working with a modern stack: Node.js, TypeScript, ksqlDB, PostgreSQL, Clickhouse and Docker, to move massive volumes of data that power automotive applications like telematics and automations.

If you’re excited by tough problems and real world scale, we’d love to talk! | 26 | 1 | 4 | 3mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:18:58.139Z |  | 2025-08-18T21:48:29.679Z |  | https://www.linkedin.com/jobs/view/4288312761/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7279996606618238976 | Article |  |  | DIY o1 Personal Reasoning Model: https://buff.ly/4gPtFGQ 

China just open sourced reasoning 👀 | 2 | 1 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.236Z |  | 2024-12-31T23:07:26.814Z | https://buff.ly/4gPtFGQ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7279471902643871745 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEGAgOEH_9HgA/image-shrink_800/image-shrink_800/0/1735561322437?e=1765782000&v=beta&t=X4GdyCnbKoGnkVnHawVYNH1317VxPJhD7OQTOFN2PVw | Is it happening right now? | 3 | 0 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.236Z |  | 2024-12-30T12:22:27.638Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7278518372063969280 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHEYf5f5nKrdg/image-shrink_800/image-shrink_800/0/1735333983102?e=1765782000&v=beta&t=ENFyCg-Bkd_zgTf6DduDI3MHs08UYqQAD68B8w8zQig | I’ve rediscovered my childhood favorite, NFL Street 2, originally played on my GameCube, now on my Steam Deck. Talk about nostalgia and the ultimate way to make time fly (literally)! 🕹️

This little travel hack has been a game-changer for long flights. Nothing beats diving into your favorite games while cruising at 30,000 feet.

What’s your go-to setup for long flights? | 12 | 2 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.236Z |  | 2024-12-27T21:13:28.232Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7278111688191619072 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEGyAwwK8rGcg/image-shrink_800/image-shrink_800/0/1735237022292?e=1765782000&v=beta&t=rNWR0x3vfPbfIf7KQ83s8gBt77Ko63mYNuAtnG9BFcw | "'We need a new email sequence."
At this point, ChatGPT rewriting stuff is the standard creative process.

Oh, and yeah, that’s my grandma holding a watermelon she grew in her garden. Because while I’m over here struggling with AI, she’s out there crushing it at life. No big deal. | 4 | 1 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.237Z |  | 2024-12-26T18:17:27.241Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7277002377885278208 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEfVZVFfWr62g/image-shrink_800/image-shrink_800/0/1734972541831?e=1765782000&v=beta&t=vrICh9pTgbPtqLISMs0PA8yk8FuVMixfYz68MQJedzg | Advanced reasoning models like o3 are here. Some call it AGI...

The only question that matters:
Will YOU use it? Or will it be used against you? 

What are you building? 👇 | 5 | 0 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.237Z |  | 2024-12-23T16:49:27.054Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7275866896577560579 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHP2rXpUOhyMA/image-shrink_800/image-shrink_800/0/1734701822207?e=1765782000&v=beta&t=ZOwXU_sDXpX4vahQfIhyBG50dC2Ddc3881jDBOjQa7E | Working from paradise isn’t all sunsets and palm trees. 🌴

Working remote gave me better weather, less stress, and a life upgrade. But staying on EST? Brutal.

Here’s me wrapping up at 6 AM as the sun rises—heading to bed while the world here wakes up.

Is it worth it? 100%. Every dream has its price. 🌅 | 34 | 0 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.237Z |  | 2024-12-20T13:37:27.214Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7275146444863418369 | Video (LinkedIn Source) | blob:https://www.linkedin.com/43d3e857-be41-42ff-b8b6-7e5cbb443418 | https://media.licdn.com/dms/image/v2/D4E10AQGnA7VdrOF1pA/videocover-high/videocover-high/0/1734530050171?e=1765782000&v=beta&t=Z1GRPAV0coPKYq8bXuMVH1VpYMTvS54toe9fV8aiMq4 | I used OpenAI’s new multimodal AI agent 🤖 to pick wines 🍷 for my sister’s birthday. 

No employees around, roasted lamb on the menu 🐑, and I needed a perfect pairing fast.

The result? Meh. Even the most advanced agents have to choose between hallucination stability and latency. 🤔

That being said, we're months away from these agents being more convenient than a human. 

When they get there? Game over. 

What do you think? Would you trust an AI Sommelier? 🍷 | 7 | 0 | 0 | 11mo | Post | Kevin Esmezyan | https://www.linkedin.com/in/kevin-esmezyan-96838b109 | https://linkedin.com/in/kevin-esmezyan-96838b109 | 2025-12-08T06:19:00.238Z |  | 2024-12-18T13:54:38.140Z |  |  | 

---



---

# Kevin Esmezyan
*Matador*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Matador AI Named Nissan USA Preferred Partner in first AI ...](https://financialpost.com/pmn/business-wire-news-releases-pmn/matador-ai-named-nissan-usa-preferred-partner-in-first-ai-category)
*2025-11-24*
- Category: article

### [Matador AI Named Nissan USA Preferred Partner in first AI Category](https://www.businesswire.com/news/home/20251124477697/en/Matador-AI-Named-Nissan-USA-Preferred-Partner-in-first-AI-Category)
*2025-11-24*
- Category: article

### [Matador Says A.I.-Powered Travel Has Found Its Stride With GuideGeek](https://www.forbes.com/sites/joesills/2023/09/18/matador-ceo-says-ai-powered-travel-tool-guidegeek-can-forge-human-connections/)
*2023-09-18*
- Category: article

### [Matador.AI Company Profile | Management and Employees List](https://www.datanyze.com/companies/matadorai/480259663)
*2025-01-01*
- Category: article

### [Kevin Espiritu: Building a Business and 3.5+ Million Follower Audience in the Gardening Niche  by The HeyCreator Show](https://creators.spotify.com/pod/profile/heycreator/episodes/Kevin-Espiritu-Building-a-Business-and-3-5-Million-Follower-Audience-in-the-Gardening-Niche-e2d9r2b)
*2025-05-12*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Dealer Talk With Jen Suzuki - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/dealer-talk-with-jen-suzuki/id1543989710)**
  - Source: podcasts.apple.com
  - *... podcast on Apple Podcasts ... P1 AI Mini Series: How to Collab with AI in Your Dealership with Kevin Esmezyan, Matador AI....*

- **[Dealer Talk With Jen Suzuki | Podcast on Spotify](https://open.spotify.com/show/5iOPXtChr3aAUt4pM3kNHx)**
  - Source: open.spotify.com
  - *In this first episode of our new mini-series with Matador AI, Jen sits down with Kevin Esmezyan, Head of Product at Matador AI, to explore how dealers...*

- **[Matador AI Named Nissan USA Preferred Partner in first AI Category ...](https://financialpost.com/pmn/business-wire-news-releases-pmn/matador-ai-named-nissan-usa-preferred-partner-in-first-ai-category)**
  - Source: financialpost.com
  - *Nov 24, 2025 ... ... Podcasts · Small Business · Lives Told · Shopping · Travel Deals · Obituaries ... Kevin Esmezyan, Chief Product Officer at Matado...*

- **[Tractor Supply Company shows the power of AI in retail - AI in Action ...](https://open.spotify.com/episode/2MrGus1ECSNVE8jIshTv13)**
  - Source: open.spotify.com
  - *Sep 9, 2025 ... ... podcast are solely those of the participants and do not ... Kevin Esmezyan, Matador AI · The Future of Digital Workers. Company....*

- **[P1 AI Mini Series: How to Collab with AI in Your Dealership with ...](https://www.youtube.com/watch?v=bp5pXpJsRjw)**
  - Source: youtube.com
  - *Nov 6, 2025 ... https://matador.ai/ | Kevin Esmezyan, 514-793-1488 | Kevin@matador.ai Dealer Talk with Jen Suzuki Podcast | https://apple.co/38lmHM1 ....*

- **[Unlocking the power of AI - Canadian Auto Dealer](https://canadianautodealer.ca/2025/06/unlocking-the-power-of-ai/)**
  - Source: canadianautodealer.ca
  - *Jun 15, 2025 ... In an interview with Canadian auto dealer, Kevin Esmezyan, Head of Product at Matador.ai, said the company uses AI to generate ......*

- **[Matador AI Named Nissan USA Preferred Partner in first AI Category](https://www.businesswire.com/news/home/20251124477697/en/Matador-AI-Named-Nissan-USA-Preferred-Partner-in-first-AI-Category)**
  - Source: businesswire.com
  - *Nov 24, 2025 ... ... Kevin Esmezyan, Chief Product Officer at Matador AI. “It helps ... Contacts. For information or interviews: Daniel Torchia, APR T...*

- **[2022 NADA Show well received by industry - Canadian Auto Dealer](https://canadianautodealer.ca/2022/04/2022-nada-show-well-received-by-industry/)**
  - Source: canadianautodealer.ca
  - *Apr 29, 2022 ... ... talk about the digital retail platform company called Roadster ... ” —Kevin Esmezyan, Head of Growth and Marketing, Matador.ai. “...*

- **[Don't Start Using ChatGPT For Sales Tomorrow…Do It Now](https://snov.io/blog/chatgpt-for-sales/)**
  - Source: snov.io
  - *With an average deal size of $15,000+, the ROI we've achieved by adding ChatGPT is incredible. Kevin Esmezyan. Head of Marketing at Matador.ai. Use ca...*

- **[Matador AI Named Nissan USA Preferred Partner in first AI Category](https://finance.yahoo.com/news/matador-ai-named-nissan-usa-193100360.html)**
  - Source: finance.yahoo.com
  - *Nov 24, 2025 ... Trader Talk · Warrior Money · Living Not So Fabulously · The Big Idea ... Kevin Esmezyan, Chief Product Officer at Matador AI. "It he...*

---

*Generated by Founder Scraper*
