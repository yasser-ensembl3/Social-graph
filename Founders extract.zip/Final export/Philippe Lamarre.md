# Philippe Lamarre

## Position actuelle

**Titre** : President, producer, creative director
**Entreprise** : URBANIA
**Durée dans le rôle** : 25 years 3 months in role
**Durée dans l'entreprise** : 25 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Online Media

## Résumé

Philippe Lamarre est le fondateur et président d'URBANIA, un groupe média indépendant basé à Montréal et à Paris. Fondé en 2003, le magazine URBANIA a toujours été à l’avant-garde des évolutions numériques, devenant un incontournable pour les jeunes adultes québécois en décryptant les phénomènes de société émergents et en mettant en valeur la culture québécoise. L’entreprise a su s’adapter et se diversifier dans la production de contenu multiplateforme et produit aujourd’hui des projets audiovisuels et interactifs primés pour des diffuseurs tels que Télé-Québec, Radio-Canada/CBC, TV5, ARTE France, Bell Média et Québecor. URBANIA compte aujourd’hui une centaine d’employés, a ouvert des bureaux en France en 2020 et célébré ses vingt ans en 2023.
—

Philippe Lamarre is the founder and president of URBANIA, an independent media group based in Montreal and Paris. Founded in 2003, URBANIA magazine has always been at the forefront of digital evolution, becoming a staple for young Quebec adults by deciphering emerging social phenomena and highlighting Québec culture. The company has successfully adapted and diversified into multiplatform content production and now produces award-winning audiovisual and interactive projects for broadcasters such as Télé-Québec, Radio-Canada/CBC, TV5, ARTE France, Bell Media, and Québecor. Today, URBANIA employs around one hundred people, opened offices in France in 2020, and celebrated its twentieth anniversary in 2023.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAKpkYwBUZsgeycChk53hUmm0ILqM_dCtGY/
**Connexions partagées** : 154


---

# Philippe Lamarre

## Position actuelle

**Entreprise** : Valides

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Philippe Lamarre

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401435841056894976 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzzXxhhb4_Vg/feedshare-shrink_800/B4EZrbi959KMAg-/0/1764619968514?e=1766620800&v=beta&t=zk2FDgM-IAVyGSiIz2l3o1Wg9ft8BgPVz_OTf0zKyOU | Avis aux créateurs de contenus et aux agences de représentation : ce programme est pour vous. | 43 | 3 | 3 | 6d | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:07.112Z |  | 2025-12-02T01:43:36.536Z | https://www.linkedin.com/feed/update/urn:li:activity:7401352598928248833/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399010629996638208 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0a6c18ba-c4fe-46a9-be61-47de2ffe9742 | https://media.licdn.com/dms/image/v2/D4E05AQG1GByAmRSwag/videocover-high/B4EZqmr3sMJgBY-/0/1763733112181?e=1765778400&v=beta&t=Nfk7ZDH2OqNJNfyN4D3gaK5ViWtwQ7uE3s0TQwu_72U | Fragments, la série documentaire que nous produisons depuis plus de 5 ans pour ARTE, est un véritable baume pour l’âme. À travers chaque épisode, quelqu’un partage une part de sa vie, ses joies, ses blessures, sa vérité propre. Dans un monde complexe et polarisé, cette série joue un rôle précieux : elle rappelle ce que nous avons en commun et nous rapproche un peu les uns des autres.

Lama Serhan Xavier Havitov Aurélie Sfez | 69 | 3 | 2 | 1w | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:07.115Z |  | 2025-11-25T09:06:41.161Z | https://www.linkedin.com/feed/update/urn:li:activity:7398661664012652544/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7383849578900500480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFeMPd-dCL2Vw/feedshare-shrink_800/B4EZneSX0hJgAg-/0/1760370983841?e=1766620800&v=beta&t=S50E2wj0ooRH0XUm3MA65CbdBGfemYPiZp7k2PM8E64 | J'ai eu le plaisir d'aller partager la petite et grande histoire d'URBANIA Media à HEC Montréal dans le cours de Stéphane Goyette. Toujours un plaisir de rappeler aux futures générations l'importance de la culture québécoise et d'avoir un écosystème média en santé. | 166 | 7 | 0 | 1mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.515Z |  | 2025-10-14T13:02:04.901Z | https://www.linkedin.com/feed/update/urn:li:activity:7383841554324705280/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7375160661728796672 | Article |  |  | On publie aujourd’hui notre édition micromag de la rentrée culturelle avec des artistes de la nouvelle génération qui partagent leurs coups de cœur culturels québécois. Rafraîchissante formule qui nous sort des sentiers battus.

https://lnkd.in/etw66wVh | 60 | 0 | 6 | 2mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.515Z |  | 2025-09-20T13:35:25.615Z | https://urbania.ca/micromag/guide-culture-quebecoise-automne-micromag-127 |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7374065658034143232 | Article |  |  | monique simard et moi avons publié hier une lettre ouverte afin de subtilement rappeler aux pouvoirs en place que nous sommes ravis de l'accueil qu'a reçu le rapport du Groupe de travail sur l'avenir de l'audiovisuel au Québec, mais que pour nous, ce n'est que la moitié de l'objectif qui est atteint...

https://lnkd.in/eX_PgDix | 160 | 14 | 1 | 2mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.516Z |  | 2025-09-17T13:04:16.390Z | https://www.lapresse.ca/dialogue/opinions/2025-09-15/industrie-audiovisuelle/un-avenir-qui-repose-sur-la-volonte-politique.php |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7372986175449612288 | Article |  |  | Excellente analyse de François Cardinal à propos du rapport du Groupe de travail sur l’avenir de l’audiovisuel au Québec que monique simard et moi avons présenté la semaine passée en compagnie du ministre Mathieu Lacombe. | 73 | 3 | 4 | 2mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.516Z |  | 2025-09-14T13:34:47.686Z | https://lp.ca/xC7ucF?sharing=true |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7370918873933697024 | Article |  |  | Vendredi dernier, on a rendu public notre rapport sur l’avenir de l’audiovisuel au Québec. Si j’ai accepté de consacrer une année à ce mandat, c’est parce que l’avenir de notre audiovisuel et de notre culture me préoccupe et me tient à coeur profondément, tant à titre d’entrepreneur, de citoyen que de père.

Je suis heureux de constater que le rapport a été bien reçu et semble rallier. C’était notre objectif : offrir une vision ambitieuse et rassembleuse pour l’avenir de l’audiovisuel québécois, mais en demeurant réalistes et pragmatiques.

Merci au ministre Mathieu Lacombe de m’avoir confié ce mandat, à ma co-présidente monique simard avec qui ce fut un honneur de collaborer étroitement, et à mes collègues du groupe de travail : Sophie Dufort, Jean-Christophe J. Lamontagne, Christine Maestracci et Stéphanie Morrissette.

Enfin, un merci tout spécial à mes équipes chez URBANIA Media, qui ont tenu le fort et veillé au grain pendant cette année, particulièrement mon associée Raphaëlle Huysmans, qui doit malheureusement désormais me rendre mon trône et mon sceptre.
—
Pour consulter le rapport «Souffler les braises» : https://lnkd.in/esuM6NBb | 372 | 22 | 4 | 2mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.517Z |  | 2025-09-08T20:40:04.596Z | https://cdn-contenu.quebec.ca/cdn-contenu/adm/min/culture-communications/documents/GTAAQ/Rapport_Groupe_travail_audiovisuel_Quebec.pdf |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7357108372539592704 | Article |  |  | Mon collègue Jean s'est fendu d'un magnifique hommage à Pierre Foglia. Dans son texte, il fait référence à une chronique publié le jour de mon anniversaire en 2010. Je me rappelle encore la surprise d'ouvrir Cyberpresse et de découvrir que Foglia—après nous avoir revirés de bord après qu'on lui eu proposé une collaboration dans notre édition sur le vieux—parlait d'URBANIA. Le plus beau cadeau d'anniversaire qu'on ne m'a pas offert. Je joins une capture d'écran de ladite chronique en commentaire.

https://lnkd.in/eUQdFfjR | 99 | 2 | 0 | 4mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.518Z |  | 2025-08-01T18:02:04.477Z | https://urbania.ca/article/deces-pierre-foglia-hommage |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7342417349171396609 | Article |  |  | À l’occasion de la fête nationale du Québec, on a demandé à notre ami Mounir Kaddouri aka Maire de Laval d’enquêter sur la résurgence du souverainisme chez les jeunes. 

Très fier de cette collaboration et du résultat (et surtout de ce jeunes qui portent en eux le souhait très légitime de voir naître un pays à coups de rap et de memes. :)

https://lnkd.in/eMSh2QNz | 46 | 3 | 4 | 5mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:09.521Z |  | 2025-06-22T05:05:11.560Z | https://micromag.ca/micromag/nouveaux-souverainistes-quebec-independance-micromag-124 |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7337177957385359360 | Article |  |  | URBANIA est allé à la rencontre de jeunes urbexeurs qui frôlent la mort pour vivre des sensations fortes (et peut-être un peu pour mettre ça sur Youtube ensuite). 

Attention si vous avez le vertige, ça fait peur. 

https://lnkd.in/e64fvMmr | 10 | 0 | 0 | 6mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:11.641Z |  | 2025-06-07T18:05:43.215Z | https://urbania.ca/micromag/urbex-extreme-froler-la-mort-pour-le-plaisir-micromag-122 |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7328205190652731393 | Document |  |  | Vous connaissez la bonne personne pour développer le marché corporatif pour nous chez Valides, notre agence de représentation de créateurs de contenu. | 11 | 0 | 2 | 6mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:14.984Z |  | 2025-05-13T23:51:08.920Z | https://www.linkedin.com/feed/update/urn:li:activity:7328154190696914945/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7318667096521887744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEc9jBlwGil2w/feedshare-shrink_800/B4EZZD6c9CHcAk-/0/1744896119466?e=1766620800&v=beta&t=K9T5-4MIpAWmjmNg1hQ0f-PN-A8DMWKk_9kiYM4QsYs | Deux talents hors du commun se joignent à Valides :) | 27 | 1 | 1 | 7mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:14.984Z |  | 2025-04-17T16:10:10.070Z | https://www.linkedin.com/feed/update/urn:li:activity:7318624780079824897/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7315804734357987328 | Document |  |  | Super article de Médianes à propos du format Micromag conçu et développé à Montréal, maintenant déployé en France. | 14 | 0 | 0 | 7mo | Post | Philippe Lamarre | https://www.linkedin.com/in/philippelamarre | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:14.988Z |  | 2025-04-09T18:36:09.750Z | https://www.linkedin.com/feed/update/urn:li:activity:7315760775015387137/ |  | 

---



---

# Philippe Lamarre
*Valides*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 11 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [Philippe Lamarre 🇨🇦 - H. Grégoire Mitsubishi Laval | LinkedIn](https://ca.linkedin.com/in/philippelamarre1)
*2025-07-05*
- Category: article

### [Dialogues with/avec Laure Marin de la Vallée | All Episodes](https://dialoguespodcast.com/episodes)
*2025-02-25*
- Category: podcast

### [Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI applications and models in healthcare](https://medium.com/pear-healthcare-playbook/lessons-from-vivek-natarajan-google-health-and-viswesh-krishna-valar-labs-building-ai-57e787e7f0a2)
*2023-09-25*
- Category: blog

### [‎Pear Healthcare Playbook: Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI applications and models in healthcare on Apple Podcasts](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?i=1000624588506&amp;uo=4&quot;,&quot;releaseDate&quot;:&quot;2023-08-16T00:35:18Z&quot)
*2023-08-16*
- Category: podcast

### [Top 20 LinkedIn Influencers in Quebec in 2025 - Favikon](https://www.favikon.com/blog/top-linkedin-influencers-quebec)
*2025-01-19*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 340,162 words total*

### Philippe Lamarre 🇨🇦 - H. Grégoire Mitsubishi Laval | LinkedIn
*5,678 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/philippelamarre1)

Philippe Lamarre 🇨🇦 - H. Grégoire Mitsubishi Laval | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/philippelamarre1#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-newport-tn?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fphilippelamarre1&fromSignIn=true&trk=public_profile_nav-header-signin)[Register now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=philippelamarre1&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fphilippelamarre1&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fphilippelamarre1&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/C4D16AQFKjP84xtD3sw/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1532487554688?e=2147483647&v=beta&t=GC6GN8J6qhwf3OXRHDQxIVJo8bz7WblVULb7Ej1pEkQ)

![Image 3: Philippe Lamarre 🇨🇦](https://media.licdn.com/dms/image/v2/D4E03AQGfsxw2DDd0TQ/profile-displayphoto-shrink_200_200/B4EZdbImQQH0Ac-/0/1749580672788?e=2147483647&v=beta&t=HFBCj_4NuHF5gBOKa66He8Bzby7pL8X5Vokvz8UWFyU)

![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQGfsxw2DDd0TQ/profile-displayphoto-shrink_200_200/B4EZdbImQQH0Ac-/0/1749580672788?e=2147483647&v=beta&t=HFBCj_4NuHF5gBOKa66He8Bzby7pL8X5Vokvz8UWFyU)
Sign in to view Philippe’s full profile
---------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=philippelamarre1&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=philippelamarre1&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Philippe Lamarre 🇨🇦
=====================

![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQGfsxw2DDd0TQ/profile-displayphoto-shrink_200_200/B4EZdbImQQH0Ac-/0/1749580672788?e=2147483647&v=beta&t=HFBCj_4NuHF5gBOKa66He8Bzby7pL8X5Vokvz8UWFyU)
Sign in to view Philippe’s full profile
---------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=philippelamarre1&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_join-link)

or

New t

*[... truncated, 63,325 more characters]*

---

### Dialogues with/avec Laure Marin de la Vallée | All Episodes
*2,703 words* | Source: **EXA** | [Link](https://dialoguespodcast.com/episodes)

Dialogues with/avec Laure Marin de la Vallée | All Episodes

===============

[Dialogues with/avec Laure Marin de la Vallée](https://dialoguespodcast.com/)

[Home](https://dialoguespodcast.com/ "Home")[Episodes](https://dialoguespodcast.com/episodes "Episodes")[Laure.Love](https://www.laure.love/ "Laure.Love")

[](mailto:%63%6f%6e%74%61%63%74@%6c%61%75%72%65.%6c%6f%76%65 "Email Us")

[Subscribe](https://dialoguespodcast.com/subscribe)

Open main menu Close menu

[Home](https://dialoguespodcast.com/ "Home")[Episodes](https://dialoguespodcast.com/episodes "Episodes")[Laure.Love](https://www.laure.love/ "Laure.Love")[Subscribe](https://dialoguespodcast.com/subscribe "Subscribe")

[](mailto:%63%6f%6e%74%61%63%74@%6c%61%75%72%65.%6c%6f%76%65 "Email Us")

All Episodes
============

Displaying **1-10** of **10** in total

[![Image 1: À Corps Consentants: le sens du toucher et du consentement](https://substackcdn.com/feed/podcast/4959602/post/163127720/bf4854aca3d02642d551cb5828b065ab.jpg)](https://dialoguespodcast.com/episodes/a-corps-consentants-le-sens-du-toucher-et-du-consentement)

 55 mins  Feb 25, 25 

[### À Corps Consentants: le sens du toucher et du consentement À propos des invité-es:Marie Cachou Trudel-Langevin et Caro Dupeyras, co-fondatrices du projet À Corps Consentants (depuis 2021), facilitent des ateliers pratiques sur le consentement et le développement de formes d’intimité plus conscientes depuis 2019. Leur approche est expérientielle, somatique, féministe-Queer et sensible aux traumas. Danseuses dans la communauté d’impro contact de Montréal, iels co-animent des classes et des jams en mixité choisie pour femmes et personnes Queer. Au travers de leurs pratiques, iels explorent les liens entre émancipation sensuelle, artistique et politique.Caro développe depuis plusieurs années sa pratique comme travailleuse sociale en santé mentale et en éducation sexuelle. Marie C, artiste et massothérapeute, poursuit actuellement des études en éducation sexuelle somatique. Iels sont en formation continue auprès de The School of Consent, école co-fondée par Betty Martin, créatrice de la Roue du Consentement © Site web de À Corps ConsentantsÀ Corps Consentants sur FacebookThe School of ConsentCarmen Leilani De Jesus (référence autout de 38 minutes) This is a public episode. If you would like to discuss this with other subscribers or get access to bonus episodes, visit lauremarin.substack.com](https://dialoguespodcast.com/episodes/a-corps-consentants-le-sens-du-toucher-et-du-consentement)

[![Image 2: Jonas Mago: Presence and Consciousness in Theory and Practice](https://substackcdn.com/feed/podcast/4959602/post/163127721/d9f7d11a555d16a98636902e59ce225d.jpg)](https://dialoguespodcast.com/episodes/jonas-mago-presence-and-consciousness-in-theory-and-practice)

 63 mins  Jan 29, 25 

[### Jonas Mago: Presence and Consciousness in Theory and Practice About today's guest: Jonas Mago is am a certified Unified Mindfulness meditation coach with a deep fascination for the science and mathematics of consciousness and wellbeing. His work bridges the gap between scientific inquiry, practices of the body and mind, and the wisdom of ancient traditions. Rooted in lineages such as Buddhism and Christian prayer, Jonas find inspiration in exploring how contemplative practices across traditions offer pathways to profound states of consciousness and flourishing. In his academic work, Jonas is pursuing a PhD in Neuroscience at McGill University, where he studies how contemplative practices enable the brain, body, and mind to access new states of consciousness. His research focuses on how these states support holistic wellbeing and transformation, weaving together insights from neurobiology, cognitive science, and phenomenology. Jonas' personal contemplative practice is deeply influenced by the teachings of Culadasa (John Yates), Rob Burbea, and Michael Taft, as well as his training under Shinzen Young, who certified him as a meditation coach. He currentlyoffers one-on-one coaching sessions, guiding individuals in exploring the many dimensions of consciousness and cultivating a life of clarity and purpose.Learn more about Jonas' work at his website: https://www.jonasmago.com/---About the host: Laure Marin de la Vallée is a somatic educator, bodyworker, naturopath in training, and cultural worker passionate about the art of nourishing life. Living with over 20 years of chronic autoimmunity, Laure’s work is rooted in fostering deep connections between self, community, and the living world. Through their research, writing, and practice, they create spaces for dialogue and embodied exploration beyond the porous boundaries of the skin. Learn more at https//laure.love.Podcast website: https://dialoguespodcast.com This is a public episode. If you would like to discuss this with other subscribers or get access to bonus episodes, visit lauremarin.substack.com](https://dialoguespodcast.com/episodes/jonas-mago-presence-and-consciousness-in-the

*[... truncated, 16,742 more characters]*

---

### Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI…
*4,196 words* | Source: **EXA** | [Link](https://medium.com/pear-healthcare-playbook/lessons-from-vivek-natarajan-google-health-and-viswesh-krishna-valar-labs-building-ai-57e787e7f0a2)

Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI applications and models in healthcare
-----------------------------------------------------------------------------------------------------------------------------

[![Image 1: Vivien Ho](https://miro.medium.com/v2/resize:fill:64:64/2*rl0vZYOZTo7FfVp0IQZNPw.jpeg)](https://medium.com/@vivienlho?source=post_page---byline--57e787e7f0a2---------------------------------------)

17 min read

Sep 25, 2023

**_Subscribe to our_**[**_Substack_**](https://pearhealthcareplaybook.substack.com/)**_for weekly updates and listen on_**[**_Apple Podcasts_**](https://podcasts.apple.com/us/podcast/pear-healthcare-playbook/id1606987445)**_or_**[**_Spotify_**](https://open.spotify.com/show/2kKsYzKLmdEBejkqn8ruIl)**_._**

Welcome back to the **Pear Healthcare Playbook**! Every week, we’ll be getting to know trailblazing healthcare leaders and dive into building a digital health business from 0 to 1.

Today, we’re excited to get to know [Vivek](https://www.linkedin.com/in/vivek-natarajan-a3670118/), AI researcher at Google and one of the lead researchers for Med-PaLM2, and [Viswesh](https://www.linkedin.com/in/visweshk/), CTO and Founder of [Valar Labs](https://www.valarlabs.com/)!
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

![Image 2](https://miro.medium.com/v2/resize:fit:400/0*ho4ExkeKSgFCWJLX.jpg)

**Vivek is a Research Scientist at Google Health AI advancing biomedical AI to help scale world class healthcare to everyone.** Vivek is particularly interested in building large language models and multimodal foundation models for biomedical applications and leads the Google Brain moonshot behind Med-PaLM, Google’s flagship medical large language model. Med-PaLM has been featured in publications such as The Scientific American and Forbes. Vivek graduated with his masters from UT Austin in Computer Science and Bachelors at National Institute of Technology in India.

Press enter or click to view image in full size

![Image 3](https://miro.medium.com/v2/resize:fit:700/0*O3m3PjTGNXj8prpt.png)

**Viswesh is the CTO and Co-Founder of Valar Labs, building clinical grade deep learning to analyze each patient’s characteristics and provide clarity to oncologists during decision making.** Their AI is built with oncologists at the center and provides interpretable and actionable insights. Prior to founding Valar Labs, Viswesh was a Research Assistant in Stanford’s Artificial Intelligence Laboratory (SAIL) leveraging cutting edge artificial intelligence to solve healthcare problems. He was also the founder of Kanna, a patented and clinically-validated method to detect Amblyopia in children in India. Viswesh graduated with a bachelors in Computer Science at Stanford.

In this episode, Vivek and Viswesh shares how they got into Healthcare AI research and how they fell into different career paths, one leading Research at Google Health AI and the other as the CTO and Co-Founder of Valar Labs. We talk about the future of LLMs in healthcare, and also how to build defensibility in AI healthcare startups.

**If you prefer to listen, here is the recording!**

**_What did you want to be growing up?_**

Vivek: “Cricket commentator.”

Viswesh: “Healthcare.”

**_What brought you to this intersection of Healthcare and Machine Learning? What were the different pivotal moments in your life?_**

Vivek:

*   Growing up, healthcare had a huge impact on Vivek. He grew up in parts of India where for most people, going to the doctor meant walking 30 miles in extreme weather and giving up a day’s wages. Most people would go their entire lifetimes without seeing a doctor.
*   Vivek studied electronics engineering during his undergrad in India. His final thesis was an app called Ask the Doctor Anytime, Anywhere. He had very little idea of AI or machine learning, but he shares that he was a product of the MOOC (Massive Open Online Courses) revolution.
*   He stumbled onto a course one day when he was browsing the Internet with whatever little bandwidth he had access to. It was an ML course from Professor Yasser Abu Mustafa at CalTech called Learning from Data, and that got him hooked on to AI and machine learning. When he came to grad school, he took as many courses in machine learning and AI as possible and landed his first industry role in Facebook AI Research back in 2014.
*   Vivek spent four years at Facebook working on a bunch of different problem areas: conversational AI, natural language processing, computer vision, speech recognition. He loved that they were deploying models into real products for hundreds of millions of users at scale, and that it was lifting key metrics like engagement or revenue likes never seen before.
*   When it c

*[... truncated, 22,039 more characters]*

---

### Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI applications and models in healthcare
*1,538 words* | Source: **EXA** | [Link](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?i=1000624588506&amp;uo=4&quot;,&quot;releaseDate&quot;:&quot;2023-08-16T00:35:18Z&quot)

Lessons from Vivek Natarajan, … - Pear Healthcare Playbook - Apple Podcasts

===============

[](https://podcasts.apple.com/us/new)

*   [Home](https://podcasts.apple.com/us/home)
*   [New](https://podcasts.apple.com/us/new)
*   [Top Charts](https://podcasts.apple.com/us/charts)
*   [Search](https://podcasts.apple.com/us/search)

Open in Podcasts

PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

![Image 1: Pear Healthcare Playbook](https://podcasts.apple.com/assets/artwork/1x1.gif)

*   08/16/2023
*   34 MIN

Lessons from Vivek Natarajan, Google Health and Viswesh Krishna, Valar Labs building AI applications and models in healthcare
=============================================================================================================================

[Pear Healthcare Playbook](https://podcasts.apple.com/us/podcast/pear-healthcare-playbook/id1606987445)

 Play 

Today, we’re excited to get to know Vivek, AI researcher at Google and one of the lead researchers for Med-PaLM2, and Viswesh, CTO and Founder of Valar Labs!

Vivek is a Research Scientist at Google Health AI advancing biomedical AI to help scale world class healthcare to everyone. Vivek is particularly interested in building large language models and multimodal foundation models for biomedical applications and leads the Google Brain moonshot behind Med-PaLM, Google's flagship medical large language model. Med-PaLM has been featured in publications such as The Scientific American and Forbes. Vivek graduated with his masters from UT Austin in Computer Science and Bachelors at National Institute of Technology in India.

Viswesh is the CTO and Co-Founder of Valar Labs. Valar Labs is building clinical grade deep learning to analyze each patient's characteristics and provide clarity to oncologists during decision making. Their AI is built with oncologists at the center and provides interpretable and actionable insights.Prior to founding Valar Labs, Viswesh was a Research Assistant in Stanford's Artificial Intelligence Laboratory (SAIL) leveraging cutting edge artificial intelligence to solve healthcare problems. He was also the founder of Kanna, a patented and clinically-validated method to detect Amblyopia in children in India. Viswesh graduated with a bachelors in Computer Science at Stanford.

In this episode, Vivek and Viswesh shares how they got into Healthcare AI research and how they fell into different career paths, one leading Research at Google Health AI and the other as the CTO and Co-Founder of Valar Labs. We talk about the future of LLMs in healthcare, and also how to build defensibility in AI healthcare startups.

[Episode Webpage](https://podcasters.spotify.com/pod/show/pearhealthcareplaybook/episodes/Lessons-from-Vivek-Natarajan--Google-Health-and-Viswesh-Krishna--Valar-Labs-building-AI-applications-and-models-in-healthcare-e285fu2)

Information
-----------

*   Show [Pear Healthcare Playbook](https://podcasts.apple.com/us/podcast/pear-healthcare-playbook/id1606987445) 
*   Frequency Updated Weekly 
*   Published August 16, 2023 at 12:35 AM UTC 
*   Length 34 min 
*   Rating Clean 

United States
*   [Español (México)](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=es-MX)
*   [العربية](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=ar)
*   [Русский](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=ru)
*   [简体中文](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=zh-Hans-CN)
*   [Français (France)](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=fr-FR)
*   [한국어](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=ko)
*   [Português (Brazil)](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=pt-BR)
*   [Tiếng Việt](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=vi)
*   [繁體中文 (台灣)](https://podcasts.apple.com/us/podcast/lessons-from-vivek-natarajan-google-health-and/id1606987445?l=zh-Hant-TW)

Select a country or region

Africa, Middle East, and India
------------------------------

See All 

*   [Algeria](https://podcasts.apple.com/dz/new)
*   [Angola](https://podcasts.apple.com/ao/new)
*   [Armenia](https://podcasts.apple.com/am/new)
*   [Azerbaijan](https://podcasts.apple.com/az/new)
*   [Bahrain](https://podcasts.apple.com/bh/new)
*   [Benin](https://podcasts.apple.com/bj/new)
*   [Botswana](https://podcasts.apple.com/bw/new)
*   [Brunei Darussalam](https://podcasts.apple.com/bn/new)
*   [Bur

*[... truncated, 20,847 more characters]*

---

### Top 20 LinkedIn Influencers in Quebec in 2025 - Favikon
*2,308 words* | Source: **EXA** | [Link](https://www.favikon.com/blog/top-linkedin-influencers-quebec)

**Here’s the list of the Top 20 LinkedIn Influencers in Quebec in 2025:**
-------------------------------------------------------------------------

![Image 1](https://cdn.prod.website-files.com/5fdb2fcbe8cb905cd95d758f/678cd2618c166eb43e85ac29_678cd2492104921eaa97079c_20.png)

### **20. Dominique Gagnon**

Dominique Gagnon is a successful entrepreneur and CEO with a diverse background in technology and business. He is the co-founder and CEO of Connect&Go, a leading company specializing in RFID solutions for events and attractions. Dominic has also co-founded and led several other companies, including Piranha & Mozzo Technologies, Propulse, and Karelab. He is a partner and CEO at IX-Points, an e-learning company, and serves as the Chairman of the Board and investor in Rose Buddha, an eco-friendly and ethical product platform. Dominic is recognized for his achievements and has received numerous awards and distinctions throughout his career. He is also a blogger for Les Affaires and a columnist for QUB Radio. With his extensive experience and expertise, Dominic is a respected figure in the business and technology sectors.

‍_LinkedIn Score :_**_80.3/100_**

_Favikon Authority Score :_**_6 705 pts_**

**‍**

[View their AI-Powered Profile](https://app.favikon.com/profile/650417e3ca94bfc77b12079b/content/)

![Image 2](https://cdn.prod.website-files.com/5fdb2fcbe8cb905cd95d758f/678cd2628c166eb43e85acf5_678cd242bb8aaaca2aa19bc3_19.png)

### **19. David Cantin**

David Cantin is a barrel broker for Mannaz Whisky and a French-speaking whisky simplifier for C pas un dram. With a passion for social selling, he teaches clients how to engage in conversations, be kind and open-minded, and add value to others. He helps them build a social selling strategy that fits their values and needs, resulting in unlimited clients and more deals. David shares his experiences as a victim of bullying and advocates for a world without intimidation. He is also a courtier en tonneaux, exploring the global spirits market and developing partnerships. With a background in marketing and sales, David understands the importance of collaboration and the power of choice in business.

‍_LinkedIn Score :_**_80.7/100_**

_Favikon Authority Score :_**_5 087 pts_**

‍

[View their AI-Powered Profile](https://app.favikon.com/profile/6526c777879b4be79fc1ff80/content/)

‍

> **Recommended tools**‍[Find LinkedIn influencers](https://www.favikon.com/find-influencers/linkedin)‍[Analyze your own LinkedIn profile](https://www.favikon.com/features/linkedin-analytics)‍[Analyze competitors' LinkedIn profiles](https://www.favikon.com/features/linkedin-competitor-analytics)

‍

![Image 3](https://cdn.prod.website-files.com/5fdb2fcbe8cb905cd95d758f/678cd2618c166eb43e85ac3b_678cd23b61f9da169a826633_18.png)

### **18. Olfa Khemiri**

Olfa Khemiri is an Agile Coach and Career Mentor who helps companies implement agile and QA strategies. She is dedicated to empowering individuals to overcome career challenges with confidence. With a focus on quality assurance and agile methodologies, Olfa equips teams with the knowledge and tools to deliver high-quality software and drive innovation. She also provides guidance on personal branding, networking, and career transitions to help individuals thrive in the competitive job market.

‍_LinkedIn Score :_**_80.9/100_**

_Favikon Authority Score :_**_5 239 pts_**

‍

[View their AI-Powered Profile](https://app.favikon.com/profile/65eed61aaddb77e0d764e5f0/content/)

![Image 4](https://cdn.prod.website-files.com/5fdb2fcbe8cb905cd95d758f/678cd2618c166eb43e85ac38_678cd23598be9d8d2e9d33f9_17.png)

### **17. Dorothy Rhau**

Dorothy Rhau is the President and founder of Audace Au Féminin, a non-profit organization celebrating black women's influence and promoting self-esteem and leadership development. She is also the creator of the Salon International De La Femme Noire (SIFN), aiming to empower black women through events, workshops, and products tailored to their needs. Dorothy's work focuses on highlighting the achievements of black women and advocating for their visibility and integration in Quebec and Canada.

‍_LinkedIn Score :_**_81.1/100_**

_Favikon Authority Score :_**_6 572 pts_**

‍

[View their AI-Powered Profile](https://app.favikon.com/profile/663768a7ca1379f200c456e1/content/)

![Image 5](https://cdn.prod.website-files.com/5fdb2fcbe8cb905cd95d758f/678cd2618c166eb43e85ac32_678cd230bb8aaaca2aa18213_16.png)

### **16. François Bernier**

François Bernier is a B2B strategy expert and inclusion advocate, known for his work in personal branding and business relationship building. Despite living with spinal muscular atrophy, he has achieved significant milestones, including founding Horizon B2B and Axel, and earning a Master's degree in Strategy. He is a prominent speaker and LinkedIn strategist, guiding entrepreneurs in North America. His content focuses on inclusion, resilience, and breaking barriers, often sharing personal stor

*[... truncated, 15,273 more characters]*

---

### Urbania (media group)
*4,886 words* | Source: **GOOGLE** | [Link](https://en.wikipedia.org/wiki/Urbania_(media_group))

From Wikipedia, the free encyclopedia

Urbania| Industry | Media, telecommunication |
| --- |
| Founded | 2000 |
| Founder | Philippe Lamarre, Vianney Tremblay |
| Headquarters | Montreal, Quebec , Canada |
| Number of locations | 2 offices |
| Owner | Philippe Lamarre, Raphaëlle Huysmans |
| [Divisions](https://en.wikipedia.org/wiki/Division_(business) "Division (business)") | Dehors, Guide des Universités Urbania, Magazineurbania.com, Mollo, Quatre95, Urbania France |
| Website | [https://urbania.ca/](https://urbania.ca/)[https://urbania.fr/](https://urbania.fr/) |

**Urbania** is a Montreal-based media group that was created in 2000. The company operates diverse digital media, a brand agency, a technological laboratory, and an audiovisual production house.

The media group distinguishes itself with its unconventional tone, its close attention to graphic design and visual presentation and its focus on discussing controversial news.

Urbania also operates in France since 2020.

Urbania Media originated as a magazine launched in 2003 with a thematic quarterly format. The founders, Philippe Lamarre and Vianney Tremblay, initially worked at the Toxa Design Agency, which had been established in 2000. Initially, the main goal of project was to explore new avenues and have fun. The founders did not imagine it would last for more than a decade.[[1]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:0-1)[[2]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:3-2)[[3]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:1-3)[[4]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:4-4)

In 2015, The Toxa Design Agency and Urbania's operations were combined under the same name.[[3]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:1-3)[[5]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:5-5)

In an interview for the French Canadian Newspaper [Le Devoir](https://en.wikipedia.org/wiki/Le_Devoir "Le Devoir"), Philippe Lamarre explains that Urbania's initial mission to highlight ordinary people doing extraordinary things did not change. Still, its approach to achieving this mission has evolved.[[6]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:2-6)

For its 15th anniversary, Urbania referenced a famous [Esquire](https://en.wikipedia.org/wiki/Esquire_(magazine) "Esquire (magazine)") magazine cover featuring [Muhammad Ali](https://en.wikipedia.org/wiki/Muhammad_Ali "Muhammad Ali"), by portraying Richard Martineau as a martyr which created controversy. Among Urbania's previous magazine covers are [Justin Trudeau](https://en.wikipedia.org/wiki/Justin_Trudeau "Justin Trudeau") and [Gérald Tremblay](https://en.wikipedia.org/wiki/G%C3%A9rald_Tremblay "Gérald Tremblay") crucified on [Mont Royal](https://en.wikipedia.org/wiki/Mount_Royal "Mount Royal"), [Jean Charest](https://en.wikipedia.org/wiki/Jean_Charest "Jean Charest") shaped in a block of cheddar cheese and [Antoine Bertrand](https://en.wikipedia.org/wiki/Antoine_Bertrand "Antoine Bertrand") and Michèle Richard wearing a bikini.[[1]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:0-1)[[3]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:1-3)[[6]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:2-6)[[7]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-7)[[8]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:6-8)

In September 2020, Urbania Media was established in France under the supervision of Florent Peiffer. Urbania's interest in France was previously shown had already shown an interest for the French market by dedicating an issue to Paris in 2012 as well as during an interview for [Le Devoir](https://en.wikipedia.org/wiki/Le_Devoir "Le Devoir") in 2018.[[1]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:0-1)[[6]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:2-6)[[9]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:25-9)[[10]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:7-10)[[11]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:8-11)[[12]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:9-12)

For Urbania's 20th anniversary in 2023, Cardinal Editions published a book tracing the media group's history.[[13]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-13)[[14]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:10-14)

Urbania first started as a physical magazine but is now mainly a digital magazine.

Each issue of Urbania is dedicated to a particular theme, such as odours, vice, food, scammers, sex, lesbians, and the Quebecois male. The first issue was dedicated to locomotion. The magazine puts lots of attention on graphic design, visual presentation, and layout.[[1]](https://en.wikipedia.org/wiki/Urbania_(media_group)#cite_note-:0-1)[[2]](https://en.wikipedia.org/wiki/Urba

*[... truncated, 63,584 more characters]*

---

### Urbania (groupe média)
*5,085 words* | Source: **GOOGLE** | [Link](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia))

Un article de Wikipédia, l'encyclopédie libre.

URBANIA
[![Image 1: Logo de Urbania](https://upload.wikimedia.org/wikipedia/fr/thumb/e/e8/Logo_URBANIA.png/330px-Logo_URBANIA.png)](https://fr.wikipedia.org/wiki/Fichier:Logo_URBANIA.png)
* * *
[Adresse](https://fr.wikipedia.org/wiki/Uniform_Resource_Locator "Uniform Resource Locator")[urbania.media/fr](https://urbania.media/fr)

Canada: [urbania.ca](https://urbania.ca/)

France: [urbania.fr](https://urbania.fr/)
[Slogan](https://fr.wikipedia.org/wiki/Slogan "Slogan")Rendre l'ordinaire extraordinaire.
[Commercial](https://fr.wikipedia.org/wiki/Commerce_en_ligne "Commerce en ligne")![Image 2](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/OOjs_UI_icon_check-constructive.svg/20px-OOjs_UI_icon_check-constructive.svg.png)Oui
[Publicité](https://fr.wikipedia.org/wiki/Publicit%C3%A9_en_ligne "Publicité en ligne")![Image 3](https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/OOjs_UI_icon_check-constructive.svg/20px-OOjs_UI_icon_check-constructive.svg.png)Oui
Type de site[Presse en ligne](https://fr.wikipedia.org/wiki/Presse_en_ligne "Presse en ligne")
Langue[Français](https://fr.wikipedia.org/wiki/Fran%C3%A7ais "Français")
[Siège social](https://fr.wikipedia.org/wiki/Si%C3%A8ge_social "Siège social")Rue Notre-Dame Ouest, [Montréal](https://fr.wikipedia.org/wiki/Montr%C3%A9al "Montréal")

[![Image 4: Drapeau du Canada](https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Flag_of_Canada_%28Pantone%29.svg/20px-Flag_of_Canada_%28Pantone%29.svg.png)](https://commons.wikimedia.org/wiki/File:Flag_of_Canada_(Pantone).svg?uselang=fr "Drapeau du Canada")[Canada](https://fr.wikipedia.org/wiki/Canada "Canada")
Propriétaire Philippe Lamarre et Raphaëlle Huysmans
Lancement 2000
État actuel actif
[modifier](https://fr.wikipedia.org/w/index.php?title=Urbania_(groupe_m%C3%A9dia)&action=edit&section=0)[![Image 5](https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Info_Simple.svg/20px-Info_Simple.svg.png)](https://fr.wikipedia.org/wiki/Mod%C3%A8le:Infobox_Site_web "Consultez la documentation du modèle")

_**Urbania**_ (stylisé _**URBANIA**_) est un groupe de [médias](https://fr.wikipedia.org/wiki/M%C3%A9dia "Média") basé à [Montréal](https://fr.wikipedia.org/wiki/Montr%C3%A9al "Montréal") ([Québec](https://fr.wikipedia.org/wiki/Qu%C3%A9bec "Québec")) fondé en 2000. Le groupe est composé de médias numériques, d'une agence de contenu pour les marques, d'un laboratoire technologique et d'une maison de [production audiovisuelle](https://fr.wikipedia.org/wiki/Production_audiovisuelle "Production audiovisuelle").

Le groupe de médias se distingue par un ton [anticonformiste](https://fr.wikipedia.org/wiki/Anticonformisme "Anticonformisme"), une attention particulière portée au [graphisme](https://fr.wikipedia.org/wiki/Graphisme "Graphisme") et des [unes controversées](https://fr.wikipedia.org/wiki/Une_(journalisme) "Une (journalisme)").

Depuis 2020, _Urbania_ est présent en [France](https://fr.wikipedia.org/wiki/France "France").

Le magazine est lancé sous forme magazine trimestriel thématique en 2003 par deux associés de l'agence de design _[Toxa](https://fr.wikipedia.org/wiki/Toxa "Toxa")_ fondée en 2000[[1]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:10-1),[[2]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:11-2), Philippe Lamarre et Vianney Tremblay[[3]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-1juin2013_www.ledevoir.com-3),[[4]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:6-4).

L'agence Toxa ainsi que toutes les activités d'_Urbania_ s'unissent sous un même nom à partir de 2015[[1]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:10-1),[[5]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:15-5).

Dans le quotidien québécois _[Le Devoir](https://fr.wikipedia.org/wiki/Le\_Devoir "Le Devoir"),_ Philippe Lamarre fait savoir que «[leur] mission, de célébrer des gens ordinaires qui font des choses extraordinaires, n’a pas tant changé, mais toutes les façons d’arriver à [leurs] fins ont évolué au fil du temps»[[6]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:9-6). À l'occasion de l'édition de son 15 e anniversaire, _URBANIA_ met en scène [Richard Martineau](https://fr.wikipedia.org/wiki/Richard_Martineau "Richard Martineau") en [martyr](https://fr.wikipedia.org/wiki/Martyr "Martyr")[[6]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:9-6). Ce clin d'œil à une célèbre couverture d'_[Esquire](https://fr.wikipedia.org/wiki/Esquire\_(magazine) "Esquire (magazine)")_ avec [Mohamed Ali](https://fr.wikipedia.org/wiki/Mohamed_Ali "Mohamed Ali") déclencha une polémique[[6]](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia)#cite_note-:9-6). Des précédentes couvertures ont mis en scène [Justin Trudeau](https://fr.wikipedia.org/wiki/Justin_Trudeau "Justin Trudeau")[[1]](https://fr

*[... truncated, 92,001 more characters]*

---

### La presse, Dernière édition | BAnQ numérique
*231,544 words* | Source: **GOOGLE** | [Link](https://numerique.banq.qc.ca/patrimoine/details/52327/2756778)

Montréal, mercredi, 8 novembre 1961 - / saint Dieudonné, pape 

.«W/W %:if ***m 

statistiques hier après-midi à ce sujet. 

A date, l'organisme a reçu de demandes. Nous préférons 30.000 demandes concernant les avoir fixé la date au 1er sus pensions de vieillesse de 65 à tembre et être en retard de 70 ans; il en a reçu 70,000 pour trois ou quatre mois dans les les allocations supplémentaires paiements que de l’avoir fixé de vieillesse au-dessus de 70 au 1er janvier 1962 et n'êlrc ans; 3,000 pour les allocations pas débordés, a expliqué le supplémentaires aux aveugles; premier ministre. 20.000 pour les allocations sup- „ „ , ,plémentaircs aux invalides et Par a.lleurs, le chef liberal a95.000 concernant les allocations aborde un grand nombre de scolaires aux étudiants de 16 sujets. Après avoir passé en rc-ct 17 ans. vue les principales mesures Toutes ecs allocations de- passées lors de la dernière vaient commencer à être ver- session, il a déclaré que l'édu-sées le 1er septembre. Cepen- cation continuerait à être la dant les fonctionnaires ont été préoccupation principale de son débordés devant la multitude gouvernement, ,.i 

QUELQUES-UNES DES 250 DEMEURES PRiNCtERES détruites par la pire conflagration à se produire dans la région 

Angeles. L'incendie a ravagé les plus beaux quartiers. Quelques vedettes de cinéma ont été jetées sur le pavé. 

e Los 

# L Équateur au seuil 

# de la guerre civile Beverly Hills valeur, socialiste et commu niste. tLes chefs de l’armée, qui prétendent que la succession d’Arosemena est invalide, ont déclaré qu'il avait remis la situation entre les mains de Gallegos à cause de la “situa tion cahotique" qui prévaut dans le pays et parce que le conflit entre Ibarra et Arose-mena empêchait l'application des mesures constitutionnelles ’

Voir EQUATEUR en page 2

QUITO, Equateur. <PA. UPI, AFP) — La guerre civile me nace d’éclater en Equateur. Deux gouvernements se dispu tent en effet la direction du pays, à la suite de la démis sion du président Jose Velasco Ibarra. Déjà les émeutes qui ont provoqué le coup d’ Etat ont fait 29 morts et plusieurs centaines de blessés. L’armée a renversé d’un mê me coup le president et son successeur constitutionnel, Car los H. Arosemena, qui avait d'abord été emprisonné par Ibarra, et a nommé à la tête du pays le juge en chef de la Cour suprême, également pré sident du Conseil d’Etat, Cami-lo Gallegos. Ibarra s ’est réfugié à l'am bassade du Mexique et Arose mena, après avoir été désigné par le Congres, a annoncé que son droit à la présidence était soutenu par les forces armées stationnées a Guayaquil, Cuen ca et Ambàto. Il est également appuyé par les partis, conser-

# ONU: les Etats-Unis sont violemment pris à parti 

# iks anticommunistes chahutent de ( URSS devant l'ambassade ta : "L ’armée russe n’est pas encore ici ”. Quelques minutes plus tard après un échange de propos virulents trois agents de police intervenaient. A ce moment, les manifes tants se sont dirigés vers l’ex térieur des terrains de l’am bassade. Pendant ce temps, les invités continuaient d’arriver àpied ou en automobile. La plu-

Voir MANIFESTATION en p. 2

communiste canadien, s ’était avancé à l’entrée de l’ambas sade pour distribuer des tracts invitant les invités à boycotter la réception. Un membre du personnel so viétique a alors interpellé M. Walsh de la façon suivante :"S ’il-vous-plait, retirez-vous, àl’extérieur de la clôture ”.“Non ”, cria M. Walsh, les bras chargés de tracts. 11 ajou-OTTAWA. (PC,AFP) - Un bref incident s ’est produit hier soir face à l’ambassade sovié tique à Ottawa, alors que les communistes s’ apprêtaient à cé lébrer le 44e anniversaire de la révolution bolchéviquc. Au moment où les invités, principalement des membres du corps diplomatique, commen çaient à arriver, M. Pat Walsh, secrétaire du Mouvement anci-

* w v

Les deux avocats ont affirmé que M. Sura avait le droit de prétendre qu ’il n’était obligé de payer l’impôt que sur la moi tié de son revenu, de 1947 à1954. inclusivement. Ce droit est fondé, selon Mes Vincberg et Myer, sur le Code civil de la province de Québec, qui sou met au régime de la commu nauté iégale de biens les con joints que se sont mariés sans contrat. 

L'origine de l'affairo 

L’affaire remonte à 1954. M. W. S. Fisher, membre de la Commission d’appel dé l’impôt, avait alors donné raison à M. Sura. Des fonctionnaires fédé raux du service de l’impôt 

Voir QUEBECOIS en page 2

AJACCIO, Corse. (UPI, Reu ters) — Les autorités corses craignent de plus en plus pour la vie du général de Gaulle à la suite de la découverte, ce ma tin, d’ une bombe au plastic qui avait été déposée à quelque 300 verges de l’hôtel de ville d’Ajac cio, où le président français de vait prendre la parole plus tard. Cet incident porte à croire que les terroristes de l’Organisation de l’armée secrète < O AS) tra quent le général et qu ’ils feront l’impossible pour attenter à sa vie. 

ANTICOMMUNISTES A L'OEUVRE — Dirigé par PAT WALSH, virulent secrétaire 

*[... truncated, 1,401,347 more characters]*

---

### Privacy-preserving distributed queries compatible with opportunistic networks
*37,832 words* | Source: **GOOGLE** | [Link](https://theses.hal.science/tel-04217442/file/121763_JAVET_2023_archivage.pdf)

# HAL Id: tel-04217442 https://theses.hal.science/tel-04217442v1 

Submitted on 25 Sep 2023 

HAL is a multi-disciplinary open access archive for the deposit and dissemination of sci-entific research documents, whether they are pub-lished or not. The documents may come from teaching and research institutions in France or abroad, or from public or private research centers. L’archive ouverte pluridisciplinaire HAL , est destinée au dépôt et à la diffusion de documents scientifiques de niveau recherche, publiés ou non, émanant des établissements d’enseignement et de recherche français ou étrangers, des laboratoires publics ou privés. 

# Privacy-preserving distributed queries compatible with opportunistic networks 

# Ludovic Javet 

# To cite this version: 

Ludovic Javet. Privacy-preserving distributed queries compatible with opportunistic networks. Dis-tributed, Parallel, and Cluster Computing [cs.DC]. Université Paris-Saclay, 2023. English. ￿NNT : 2023UPASG038￿. ￿tel-04217442￿ Privacy -preserving distributed queries 

# compatible with opportunistic networks 

## Requêtes distribuées respectueuses de la vie privée compatibles avec des 

## réseaux opportuniste s

Thèse de doctorat de l' université Paris -Saclay 

École doctorale n° 580 : Sci ences et Technologies de l’Information et de la 

Communication (STIC) 

Spécialité de doctorat : Informatique 

Graduate School : Informatique et Sciences du Numérique 

Référent : Université de Versailles -Saint -Quentin -en -Yvelines 

Thèse préparée dans l’ unité de recherche Données et Algorithmes pour une ville 

intelligente et durable (Université Paris -Saclay, UVSQ , I nria ), sous la direction de 

Luc BOUGANIM , Directeur de recherche , le co -encadrement de Nicolas ANCIAUX ,

Directeur de recherche, et le co -encadrement de Philippe PUCHERAL , Professeur. 

Thèse soutenue à Versailles , le 19 juillet 2023 , par 

# Ludovic JAVET 

# Composition du Jury 

Membres du jury avec voix délibérative 

Nathalie MITTON 

Directrice de recherche, Inria  Présidente 

Philippe LAMARRE 

Professe ur , INSA Lyon  Rapporteur & Examinateur 

Pierre SENS 

Professeur , Sorbonne Université  Rapporteur & Examinateur 

Zoubida KEDAD 

Professeure, UVSQ, Université Paris -Saclay  Examinatrice 

Claudia RONCANCIO 

Professeure , Grenoble INP Ensimag  Examinatrice 

> NNT  : 2023UPASG038
> THESE DE DOCTORAT

Titre : Requêtes distribuées respectueuses de la vie privée compatibles avec des réseaux opportunistes 

Mots clés : Gestion de données décentralisée, Calculs par la foule , Protection de la vie privée, Réseaux opportunistes 

Résumé : Dans la société actuelle, où l'IoT et les 

plateformes numériques transforment notre vie 

quotidienne , les données personnelles sont générées 

à profusion et leur utilisation échappe souvent à 

notre contrôle. Des législations récentes comme le 

RGPD en Europe proposent des solutions c oncrètes 

pour réguler ces nouvelles pratiques et protéger 

notre vie privée. Parallèlement, sur le plan technique, 

de nouvelles architectures émergent pour répondre 

à ce besoin urgent de se réapproprier nos propres 

données personnelles. C'est le cas des sys tèmes de 

gestion des données personnelles (PDMS) qui offrent 

un moyen décentralisé de stocker et de gérer les 

données personnelles, permettant aux individus 

d’avoir un meilleur contrôle sur leur vie numérique. 

Cette thèse explore l'utilisation distribuée d e ces 

PDMS dans un contexte de réseau opportuniste, où 

les messages sont transférés d'un appareil à l'autre 

sans nécessiter d'infrastructure. L'objectif est de 

permettre la mise en œuvre de traitements 

complexes croisant les données de milliers 

d'individus , tout en garantissant la sécurité et la 

tolérance aux pannes des exécutions. 

L'approche proposé e utilise les environnements 

d'exécution de confiance pour définir un nouveau 

paradigme informatique, intitulé Edgelet 

computing, qui satisfait à la fois les pr opriétés de 

validité, de résilience et de confidentialité. Les 

contributions comprennent (1) des mécanismes de 

sécurité pour protéger les exécutions contre les 

attaques malveillantes visant à piller les données 

personnelles, (2) des stratégies de résilienc e pour 

tolérer les défaillances et les pertes de messages 

induit es par l'environnement décentralisé, (3) des 

validations approfondies et des démonstrations 

pratiques des méthodes proposées. 

Title: Privacy -preserving distributed queries compatible with opportunistic networks 

Keywords: Decentralized data management , Crowd computing, Privacy protection, Opportunistic networks 

Abstract : In today's society, where IoT and digital 

platforms are transforming our daily lives, personal 

data is generated in profus ion and its usage is often 

beyond our control. Recent legislations like the GDPR 

in Europe propose concrete solutions to regulate 

these new practices and protect our privacy. 

Meanwhile, on the technical side, new arc

*[... truncated, 247,461 more characters]*

---

### DM2L - Data Mining and Machine Learning Team
*44,392 words* | Source: **GOOGLE** | [Link](https://projet.liris.cnrs.fr/dm2l/)

DM2L - Data Mining and Machine Learning Team - LIRIS, Lyon

===============

![Image 2: drawing](https://projet.liris.cnrs.fr/dm2l/pics/logo_DM2L.png)[![Image 3](https://projet.liris.cnrs.fr/dm2l/pics/logo_LIRIS.png)](https://liris.cnrs.fr/)[![Image 4](https://projet.liris.cnrs.fr/dm2l/pics/logo_LYON1.png)](https://www.univ-lyon1.fr/)[![Image 5](https://projet.liris.cnrs.fr/dm2l/pics/logo_INSA.png)](https://www.insa-lyon.fr/)[![Image 6](https://projet.liris.cnrs.fr/dm2l/pics/logo_CNRS.png)](https://projet.liris.cnrs.fr/dm2l/cnrs.fr)

*   [**Overview**](https://projet.liris.cnrs.fr/dm2l/#HOME)
*   [People](https://projet.liris.cnrs.fr/dm2l/#MEMBERS)
*   [Publications](https://projet.liris.cnrs.fr/dm2l/#PUBLICATIONS)
*   [Projects](https://projet.liris.cnrs.fr/dm2l/#PROJECTS)
*   [Softwares](https://projet.liris.cnrs.fr/dm2l/#SOFTWARES)
*   [Seminars](https://projet.liris.cnrs.fr/dm2l/#SEMINARS)
*   [Partners](https://projet.liris.cnrs.fr/dm2l/#PARTNERS)
*   [Contact](https://projet.liris.cnrs.fr/dm2l/#CONTACT)

![Image 7: drawing](https://projet.liris.cnrs.fr/dm2l/pics/logo_DM2L.png)

Introducing the team
====================

DM2L (Data Mining & Machine Learning) is a scientific team created in 2012 whose research activity is devoted to Knowledge Discovery from Data based on automatic or semi-automatic techniques. This includes data mining, machine learning, pattern recognition, data analysis, natural language processing, etc.

Fields of interest
==================

DM2L team leverages about 7 permanent researchers whose computer skills and research interests are complementary. More specifically, the team is working on the following problems:

 • Fundamentals of constraint-based mining

 • N-ary relations or Boolean tensors mining

 • Spatio-temporal data mining

 • Graph Learning & Mining : Dynamic, Attributed, Temporal, Text-rich, …

 • Ensemble learning

 • Learning probabilistic graphical models

 • Natural language processing and geographic information retrieval

 • Semi-supervised learning

 • Representation learning

 • Multi-label learning

 • Multi-view learning

 • Dimensionality learning

 • Deep Learning

 • XAI

Our results are theoretical, methodological, algorithmic and practical. Our guiding principle is to try to help data owners throughout the interactive process of knowledge discovery from data. As these processes require the combination of a wide range of paradigms of description or induction (pattern extraction, classification, regression, clustering, outlier detection, data reduction, domain adaptation, etc.)

Applications
============

Our research is developed in close relation to real world applications: the quantitative and qualitative empirical study on real data is essential. While DM2L research team develops mainly methods and algorithms rather than applications, it works with owners of data from several environments. Our application domains contain, but not only:

*   Health,
*   Predictive maintenance,
*   Biology,
*   Finance and Cryptocurrencies,
*   Competitive intelligence,
*   Urban monitoring, 
*   Digital humanity
*   Neuroscience,
*   Cognitive services, 
*   CRM,
*   Transport and mobility 

Contributions
=============

In addition to many major annual conferences that are common to DM and ML, machine learning-specific conferences are mainly ICML, Neurips, ECML/PKDD. Similarly, in addition to the major journals on KDD, there are few well established journals that are dedicated to learning methods (IEEE TNNLS, Journal of Machine Learning Research, Pattern Recognition, Machine Learning, Neurocomputing,). Significant contributions in data mining and machine learning can occur in conferences (and journals) of Artificial Intelligence (eg, IJCAI, AAAI, ECAI, Artificial Intelligence), data management (eg, VLDB, ACM CIKM, Information Systems, IEEE TKDE, KAIS), Network Science (e.g., CN & Applications, Journal of Complex Networks), and Geographic Information Science (eg, IJGIS, ACM SIGSPATIAL).

#### Active projects, up to 2025

**Main projects**, public and mixed fundings. Click on a project name to see details. 

**![Image 8](https://projet.liris.cnrs.fr/dm2l/pics/logo_UCBL.png)** | BIT-STABLENET: Extraction of stable relations between entities in crypto-currencies
2023

2025

The objective of this project is to develop methods for the extraction of stable relations between entities in crypto-currencies.

**![Image 9](https://projet.liris.cnrs.fr/dm2l/pics/logo-ANR.png)** | PORTRAIT, Improving psychiatric screening with artificial intelligence
2022

2025

It is a project funded by the ANR, French National Research Agency, as a 42 months PRCE program (projet de recherche collaborative Entreprise).

**Partners**: Humans Matter

**![Image 10](https://projet.liris.cnrs.fr/dm2l/pics/logoPEPR.png)** | WAIT4, Welfare: Artificial Intelligence and new Technologies for Tracking key indicator Traits in animals facing challenges of the agro-ecological Transition
2022

2027

PEPR A GROEC

*[... truncated, 558,557 more characters]*

---

---

## 🎬 YouTube Videos

- **[Réinventer la consommation des médias d’actualité | Entrevue avec Philippe Lamarre d&#39;URBANIA](https://www.youtube.com/watch?v=tsrMDPbKccM)**
  - Channel: Capital-Image
  - Date: 2023-12-08

- **[#8 : Philippe Lamarre, Fondateur et président d&#39;Urbania - Défendre la culture québécoise en allan...](https://www.youtube.com/watch?v=ZyBanu9kZJU)**
  - Channel: Montréal Boulevard
  - Date: 2021-03-03

- **[Philippe Lamarre de Urbania | Comment survivre en Média](https://www.youtube.com/watch?v=-WJJxwSDELA)**
  - Channel: Les Dérangeants
  - Date: 2023-12-05

- **[Philippe Lamarre - Souffler les braises - Episode 01](https://www.youtube.com/watch?v=0znyzTudOFM)**
  - Channel: Les engagés publics
  - Date: 2025-09-18

- **[Browse | Masterclass - Philippe Lamarre, fondateur d&#39;Urbania](https://www.youtube.com/watch?v=nYrV40MlpXw)**
  - Channel: Le Tank
  - Date: 2017-12-19

- **[Le Storytelling de Marque | Philippe Lamarre - Urbania](https://www.youtube.com/watch?v=RWTPMzI5ST4)**
  - Channel: La Grande Idée
  - Date: 2025-01-23

- **[Les 20 ans d’Urbania avec Philippe Lamarre](https://www.youtube.com/watch?v=GdqMA4QQPDY)**
  - Channel: 37e AVENUE
  - Date: 2023-06-15

- **[Guillaume Lespérance | Épisode 1 | Entre la fin pis le début](https://www.youtube.com/watch?v=UZjc3BED33g)**
  - Channel: URBANIA
  - Date: 2022-04-27

- **[De l&#39;intelligence collective aux entreprises libérées sans hiérarchie](https://www.youtube.com/watch?v=YuKKa36rLw0)**
  - Channel: Philippe WEBER
  - Date: 2015-10-19

- **[Forum Blanc 2015 / Fort McMoney](https://www.youtube.com/watch?v=FhpLE8oh1OQ)**
  - Channel: The Rabbit Hole Blog/Studio
  - Date: 2015-02-03

---

## 🔎 Press & Mentions

- **[Urbania (media group) - Wikipedia](https://en.wikipedia.org/wiki/Urbania_(media_group))**
  - Source: en.wikipedia.org
  - *Philippe Lamarre, Raphaëlle Huysmans. Divisions, Dehors, Guide des Universités ... In 2023, Urbania launched a talent agency named Valides to represen...*

- **[Urbania (groupe média) — Wikipédia](https://fr.wikipedia.org/wiki/Urbania_(groupe_m%C3%A9dia))**
  - Source: fr.wikipedia.org
  - *Urbania (groupe média). un groupe de médias basé à Montréal (Québec) fondé en 2000 par Philippe Lamarre et Vianney Tremblay du studio de création Toxa...*

- **[La presse, Dernière édition | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/2756778)**
  - Source: numerique.banq.qc.ca
  - *... valides seulement Prix Mon mart U CSL novembre T- \u2022 - ¦ - - \u2022 ... Philippe Lamarre, de la Cour supérieure, en rejetant les poursuites .....*

- **[Privacy-preserving distributed queries compatible with opportunistic ...](https://theses.hal.science/tel-04217442/file/121763_JAVET_2023_archivage.pdf)**
  - Source: theses.hal.science
  - *Sep 25, 2023 ... Philippe LAMARRE ... La présentation et l'analyse de trois stratégies de résilience différentes produisant des résultats valides et t...*

- **[DM2L - Data Mining and Machine Learning Team - LIRIS, Lyon](https://projet.liris.cnrs.fr/dm2l/)**
  - Source: projet.liris.cnrs.fr
  - *... Philippe Lamarre (2019). « DEvIANT : Discovering significant exceptional ... Ces garanties sont valides même si l'algorithme d'apprentissage obser...*

- **[Atelier - Mesures de similarité sémantique](https://www-sop.inria.fr/axis/egc08/atelier_5.pdf)**
  - Source: www-sop.inria.fr
  - *Jan 29, 2008 ... Antony Ventresque, Sylvie Cazalens, Philippe Lamarre et Patrick ... sur les chemins valides sont issus des travaux d'Aleksovski et al...*

- **[Contributions aux approches logiques de l'argumentation en ...](https://theses.fr/api/v1/document/2013ARTO0412)**
  - Source: theses.fr
  - *Nov 21, 2013 ... prise en compte afin d'empêcher des formules valides d'être dans une situation de contrariété : ... [Lamarre 1992] Philippe Lamarre. ...*

- **[Conférence Nationale d'Intelligence Artificielle Année 2018](https://hal.science/hal-02189744v1/file/OUN013%20-%20CNIA%202018%20V2.pdf)**
  - Source: hal.science
  - *Jul 19, 2019 ... ... Philippe Lamarre. LIRIS. •. Jérôme Lang. LAMSADE, CNRS – Université ... valides pour une très longue période, plus longue que cel...*

- **[(PDF) Conférence Nationale d'Intelligence Artificielle, Toulouse, 01 ...](https://www.academia.edu/83059677/Conf%C3%A9rence_Nationale_dIntelligence_Artificielle_Toulouse_01_07_2019_05_07_2019)**
  - Source: academia.edu
  - *... Philippe Lamarre LIRIS • Jérôme Lang LAMSADE, CNRS – Université Paris ... valides pour une très longue période, plus face de la terre à partir d'u...*

- **[URBANIA et Hainault lancent l'agence Valides | Grenier aux nouvelles](https://www.grenier.qc.ca/actualites/37459/urbania-et-hainault-lancent-lagence-valides)**
  - Source: grenier.qc.ca
  - *Oct 10, 2023 ... Valides, la nouvelle agence de représentation qui propulse des ... Philippe Lamarre, président et fondateur, URBANIA. «Accompagner de...*

---

*Generated by Founder Scraper*
