# George Fortin

## Position actuelle

**Titre** : Executive Advisor
**Entreprise** : Procero
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Advisor to the CEO and the Executive Committee for anything related to strategy, financing, and any business needs. 

Procero is pioneering a new class of AI runtime infrastructure, purpose-built for edge computing.
The company is developing Runtime Intelligence for the EDGE — enabling models to adapt in real time, optimizing for latency, power efficiency, and performance across embedded, mobile, and distributed systems.

Procero is redefining what’s possible when AI runs locally, autonomously, and intelligently, without reliance on the cloud. The future of edge AI inference isn’t smaller. It’s smarter.

## Résumé

With a deep experience in private assets management and in driving innovation in real assets, I am putting this experience to the benefit of the art and collectibles space. Leveraging our expertise in proptech has allowed us to steer Title towards solving real problems with proven and tested tools. The team at Title is committed to the highest standards of the financial industry, while fostering innovation to continuously push the boundaries of technology for collection markets.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAANHRhsBqq-U4xCIynPTpVh0_xdRoF05YNg/
**Connexions partagées** : 43


---

# George Fortin

## Position actuelle

**Entreprise** : Title

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# George Fortin
*Title*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 23 |

---

## 📚 Articles & Blog Posts

### [](https://fnti.com/category/news/first-lets-talk-title-podcast/)
- Category: podcast

### [Podcasts Archives – Fort](https://fort-companies.com/category/podcasts/)
*2025-04-09*
- Category: podcast

### [About](https://www.thefortpod.com/about/)
*2025-01-01*
- Category: article

### [1000+ 5-Star Reviews and One Non-Traditional Vision: How Google Reviews Redefined George Duffield and National Integrity Title Agency's Destiny](https://www.closesimple.com/resources/1000-5-star-reviews-and-one-non-traditional-vision-how-google-reviews-redefined-george-duffield-and-national-integrity-title-agencys-destiny)
*2025-04-01*
- Category: article

### [[Podcast] Take Your Talents In-House with a Dream Job (Michel Fortin, Part 1)](https://www.leadpages.com/blog/michel-fortin-part-1-lead-generation-podcast?srsltid=AfmBOooVRzr-D9_qD_IUmbIsrfKTY-l1e6GY07WZnH6AIn8QWVkBp9y5)
*2023-10-06*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[The Death of the Hired Man (Short) - IMDb](https://www.imdb.com/title/tt33995118/)**
  - Source: imdb.com
  - *The Death of the Hired Man: Directed by Donald Tongue. With Michael Cobb, Trish Aponte, Ray Dudley, George Fortin ... Podcasts. Awards & events. Oscar...*

- **[NH Girls Soccer Previews: Returning state champion Astros hoping ...](https://www.eagletribune.com/sports/nh-girls-soccer-previews-returning-state-champion-astros-hoping-for-an-encore/article_63072acd-e134-4c4e-b7ee-80e7a3bc0f54.html)**
  - Source: eagletribune.com
  - *Aug 28, 2025 ... Pinkerton Academy, the defending New Hampshire Division I girls soccer state champions, will look to defend its title this season sta...*

- **[The Core Orthopedics at Exeter Hospital Division I Girls Soccer ...](https://www.nhsportspage.com/news_article/show/1345128)**
  - Source: nhsportspage.com
  - *Sep 2, 2025 ... Windham is another one of the Division 1 teams with a new head coach, and theirs is George Fortin. While he is new to Windham girls va...*

- **[Holderness School Today | Summer 2024 by Holderness School ...](https://issuu.com/holdernessschool/docs/hst_summer-2024)**
  - Source: issuu.com
  - *George Fortin '24 competes in the New Hampshire Poetry Out Loud Semi-Final ... so winning the club downhill title—and beating the second-place finishe...*

- **[Full text of "Catalog of Copyright Entries, Third Series. Parts 12-13 ...](https://archive.org/stream/catalogofcopyri351213libr/catalogofcopyri351213libr_djvu.txt)**
  - Source: archive.org
  - *... Title 17 of the United States Code. CATALOG OF COPYRIGHT ENTRIES Third ... Ex-GI [George Fortin] keeps invasion vow [to marry Italian girl]. Film ...*

- **[Audit - Consulting - Audensiel Canada](https://audensiel.ca/en/audit-conseil/)**
  - Source: audensiel.ca
  - *Oct 25, 2024 ... – GEORGE FOrtin, Managing Director De Title Collections, a company specializing in title management and real estate legal documents. ...*

- **[Calipso research team: Fight against Inequities in Cancer ...](https://sesstim.univ-amu.fr/en/equipe-calipso/publications)**
  - Source: sesstim.univ-amu.fr
  - *Word(s) present in the title, abstract etc. Author(s). BARRE Tangui, BOUHNIK ... George, Fortin Davide, Mourad Abbas, Carrieri Patrizia, Marino Patriz...*

- **[Mary E. Carlson](https://brickyardcreekcommunity.com/wp-content/uploads/2019/01/The-Sawmill-at-Roys-Point.pdf)**
  - Source: brickyardcreekcommunity.com
  - *It will come as no surprise that the area known as Roy's Point was named after the first man to acquire title ... George Fortin. George Fortin was bor...*

- **[The Chicago blue book of selected names of Chicago and suburban ...](http://livinghistoryofillinois.com/pdf_files/1897%20Chicago%20Blue%20Book.pdf)**
  - Source: livinghistoryofillinois.com
  - *... title portrait of Mrs. Katherine Fisk, the eminent American Contralto, and ... George Fortin. 408 Mr. & Mrs. S. P. Wilson. 420 Mr. & Mrs. Nelson....*

- **[Bristol, Connecticut, in the olden time "New Cambridge" which ...](https://archive.org/download/bristolconnectic00hart/bristolconnectic00hart.pdf)**
  - Source: archive.org
  - *... title of the farm by inheritance, and lived there the greater part of his ... George Fortin. R; (3) No. 189, North, Arthur T. Woodford R; (4) No. ...*

---

*Generated by Founder Scraper*
