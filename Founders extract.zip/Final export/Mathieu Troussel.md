# Mathieu Troussel

## Position actuelle

**Titre** : Chargé de projet culturel & Responsable des subventions
**Entreprise** : Art Urbain Montréal
**Durée dans le rôle** : 1 year 1 month in role
**Durée dans l'entreprise** : 1 year 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Entertainment Providers

## Description du rôle

🌱 Responsabilités principales :
Gestion et coordination du projet culturel et artistiques Mémoire de l'Avenir 2025.
Rédaction et dépôt de demandes de subventions auprès d’institutions publiques et privées pour financer les initiatives d’AUM.
Développement de stratégies pour assurer la pérennité financière des projets culturels.
Collaboration avec les artistes, les partenaires et les organismes culturels pour structurer les propositions et renforcer l’impact des actions menées.
Suivi administratif et gestion des relations avec les bailleurs de fonds.
Gestion de coordination dans l'équipe d'AUM.
Gestion et stratégie de communication avec la direction de AUM.

## Résumé

QUI JE SUIS : 
Pour commencer, je suis un passionné. 
En effet, les deux passions qui m’animent sont : 
🔸 La préservation du patrimoine culturel
🔸 L'innovation technologique
Ces deux passions ont guidé mon parcours professionnel qui a été marqué par des expériences mémorables.
Je pense notamment à la célébration du 375ᵉ anniversaire de Montréal. Lors de ce projet, j’avais la responsabilité, en collaboration avec le designer principal, de concevoir la scénographie et l’exposition de Moshe Safdie, l’architecte de Habitat 67. Ce projet représentait une opportunité exceptionnelle de mettre en lumière une pièce emblématique du patrimoine architectural de Montréal.

J’ai compris avec cette expérience que je pouvais utiliser les technologies modernes pour préserver et partager notre histoire collective. 
Enfin, en tant que fervent amateur de rugby, passionné de musique électronique et explorateur de la nature, je trouve mon équilibre dans ces activités qui enrichissent ma perspective professionnelle.

MON PARCOURS : 
En tant que directeur général d’Archiv VR, ma mission est d’exploiter au mieux la réalité virtuelle (VR) et augmentée (AR) pour révolutionner la conservation et la valorisation du patrimoine culturel. 
Nous créons des expériences immersives qui permettent aux gens de visiter des expositions et des sites historiques comme s’ils y étaient réellement. 
Nos services incluent la création d’expériences XR, un système PaaS pour la gestion des productions numériques, l'archivage sécurisé des données et la diffusion de ces expériences au public. 

Notre mission : protéger et partager notre histoire grâce à des technologies innovantes.

MA VISION : 
Je suis convaincu que la technologie peut transformer la conservation et l'accessibilité du patrimoine culturel. 
Mon objectif est de développer un modèle d'affaires viable qui soutient un écosystème collaboratif, permettant aux trésors culturels d'être préservés et accessibles à tous. 
Je souhaite également contribuer à la valorisation des artistes et à la protection de leur patrimoine. 
Ma vision est de voir le patrimoine culturel revivre grâce aux technologies modernes, permettant aux générations actuelles et futures d'interagir avec leur histoire de manière immersive et enrichissante.

Voilà pour ma présentation.

Je serai ravi d’en apprendre plus sur vous et votre parcours.
De parler de toutes potentielles collaborations ou juste de faire connaissance.

N’hésitez donc pas à m’ajouter et à m'écrire en messages privés.
Je me ferai un plaisir de vous répondre et de prévoir un appel avec vous.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACWJGJ0BC6W0P-nJKj4eWHvvtJBTgLM8pSU/
**Connexions partagées** : 40


---

# Mathieu Troussel

## Position actuelle

**Entreprise** : Art Urbain Montréal

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mathieu Troussel

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399877594311049216 | Text |  |  | Petite question pour mon réseau. 

Est-ce que quelqu’un pourrait me recommander un·e comptable fiscaliste qui travaille autant avec les particuliers que les petites entreprises?

Je suis en train de revoir ma situation personnelle et professionnelle pour 2026, et j’aimerais trouver quelqu’un de fiable.

Si vous avez une personne de confiance à me suggérer, je suis preneur. 
Merci d’avance pour votre aide 🙏 | 3 | 11 | 0 | 1w | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:43.442Z |  | 2025-11-27T18:31:41.561Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384249911648608257 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnJLQKfVUhBQ/feedshare-shrink_800/B4EZnoKKYuJgAg-/0/1760536605541?e=1766620800&v=beta&t=6jlHVVMVjwA4MPMRKcTANCsWY15c-NQ-dn8KKiIi5Xk | Fin de parcours… pour espérer mieux.
C’est avec beaucoup d’émotion que nous annonçons la fermeture temporaire des activités d’Art Urbain Montréal et de son projet phare Mémoire de l’avenir.

Malgré l’énergie, la passion, les artistes engagé·es, les partenaires fidèles et les citoyen·nes touché·es par nos expositions dans les rues de Montréal, la pression grandissante sur le milieu culturel et le désengagement financier progressif ne nous permettent plus aujourd’hui de poursuivre cette aventure dans des conditions viables pour l'équipe.

Nous arrivons à la fin d’un chapitre, riche de rencontres, de luttes artistiques, et de poésie urbaine. Avant notre pause, et pour nous aider à imaginer un avenir, nous lançons une campagne de dons.
Chaque contribution aidera à poser les bases d’un possible retour du projet.

Pour chaque don, vous aurez une ou plusieurs affiches d'exposition urbaine originales de l’édition 2025, telles que vues dans les rues de Montréal. À venir chercher à notre atelier.

Chaque affiche est un fragment de mémoire à conserver. | 20 | 0 | 0 | 1mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:43.443Z |  | 2025-10-15T15:32:51.666Z | https://www.linkedin.com/feed/update/urn:li:activity:7384225734648700928/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7369844000989536256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGaP9jr7W9XNA/feedshare-shrink_800/B4EZj2bPkJHoAk-/0/1756480995831?e=1766620800&v=beta&t=ezoAkcsRwMEeHDZcl2g7F2VRDlTdFzQrisZPKlrwK78 | Appel à un·e jeune commissaire.
Art Urbain Montréal cherche son ou sa commissaire invité·e pour Mémoire de l’avenir 2026.

→ Opportunité rémunérée
→ Pour une personne issue de la diversité culturelle
→ Dans le cadre du programme démART-Mtl

Création, sélection d’artistes, rédaction, médiation, représentation… une expérience complète et encadrée.

📆 Date limite : 14 septembre 2025
📩 Formulaire → https://is.gd/FYDk8y
info@aumtl.com | 6 | 1 | 1 | 3mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:43.443Z |  | 2025-09-05T21:28:54.916Z | https://www.linkedin.com/feed/update/urn:li:activity:7367215271985442816/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7355996257976217601 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEk_i_X5n3yqw/feedshare-shrink_800/B4EZhWmYjcGwAk-/0/1753799574311?e=1766620800&v=beta&t=FbeyW2PPDHLJOhXe8Qk7smsR3q1mURFF0edCvB1akXc | Mémoire de l'avenir 2025. 

Merci à toutes celles et ceux qui rendent le projet possible.
L’édition « Habiter l’incertain » est une traversée urbaine, une prise de parole artistique dans l’espace public, une invitation à réfléchir collectivement à ce que l’on partage.

Je tiens à remercier sincèrement toutes les personnes qui ont rendu ce projet vivant :
→ Les artistes, pour leur confiance et leur vision;
→ Les partenaires culturels et communautaires, pour leur accueil généreux et leur enracinement dans les quartiers;
→ Les membres de l’équipe d’Art Urbain Montréal, pour leur implication indéfectible ;
→ Les organismes publics et bailleurs de fonds qui soutiennent la diffusion artistique dans l’espace urbain;
→ Et bien sûr, les citoyen·nes qui prennent le temps de s’arrêter, d’observer, de ressentir.

On entre dans la 5e édition de ce projet avec toujours autant d’humilité et de conviction. L’art dans la rue, c’est une manière de rendre visible les silences, de créer du lien, de réactiver la mémoire.

Merci de faire partie de cette aventure : 
Publicité Sauvage, Conseil des arts de Montréal, artch, Baudoin Wart, Danielle Lamontagne, Ariane Levasseur, Noah L'abbée, Tais da Costa, Léuli Eshrāghi, Andrew Jackson, Florencia Sosa Rey, Lorna Bauer, Marwan Sekkat, Sophia Borowska. 


—
#memoiredelavenir #arturbain #artpublicmtl #culturemontréal #expositionurbaine #merci | 13 | 0 | 1 | 4mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:43.444Z |  | 2025-07-29T16:22:55.703Z | https://www.linkedin.com/feed/update/urn:li:activity:7355968584247873536/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7348457409717194752 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2vvwLbb9ehw/feedshare-shrink_800/B4EZdhRpIrHsAg-/0/1749683704727?e=1766620800&v=beta&t=3Km3g3vvkn_BUKfXKlsy5il6ykAxfZwjHmM4w-BKANQ | Demain c'est le vernissage! 

Très hâte. | 3 | 0 | 0 | 4mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:43.444Z |  | 2025-07-08T21:06:14.213Z | https://www.linkedin.com/feed/update/urn:li:activity:7344024160467075072/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7335704371399180289 | Video (LinkedIn Source) | blob:https://www.linkedin.com/74b32f6c-1c64-447b-aff3-3eafdcd23949 | https://media.licdn.com/dms/image/v2/D4E05AQFqs8rnI9V1Ow/videocover-low/B4EZcx.byDHIBk-/0/1748890171709?e=1765785600&v=beta&t=4UmCdU1ahYWPP0lruXgrIa0Wk9aSjIbSSd1Pl0E8JEg | L’édition 2025 de Mémoire de l’avenir arrive à grands pas!
Lancement le 1er juillet → art, affiches et mémoire dans les rues de Montréal tout l’été. | 5 | 0 | 0 | 6mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.619Z |  | 2025-06-03T16:30:12.938Z | https://www.linkedin.com/feed/update/urn:li:activity:7335666617114128384/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7328399951145701380 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHajNZgHvgBGg/feedshare-shrink_800/B4EZamuGw_HMAg-/0/1746553828344?e=1766620800&v=beta&t=PyhlcPsXp3wTr_g837Ud6hrsiiHZWU3majMfNIjYMOc | Je suis heureux de partager la fin d'une étape importante de mon parcours :
je suis officiellement devenu citoyen canadien. 🇨🇦

C’est un moment chargé d’émotions, après onze ans au Québec, à bâtir, apprendre, m’impliquer et créer ici. Le Québec et le Canada m’ont offert un espace d’expression, de rencontres et d’engagement que je chéris profondément. Merci à toutes celles et ceux avec qui j’ai collaboré, travaillé, rêvé, parfois douté, mais toujours avancé. Poursuivons ensemble pour les prochaines années.

C’est aussi grâce à vous que ce pays est devenu un chez-moi.
Hâte de continuer à faire vivre des projets qui nous rassemblent. | 135 | 29 | 0 | 6mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.619Z |  | 2025-05-14T12:45:03.440Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7326286023779364885 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6beg3C3rxWQ/feedshare-shrink_800/B4EZal01I7HMAk-/0/1746538812406?e=1766620800&v=beta&t=MsrItmLyy43FUI_U7V5QDfs-SKECKqbFxUgAyl1JzLQ | Fier de voir le travail d’Art Urbain Montréal mis en lumière.
Les affiches sont bien plus que des images : ce sont des voix, des mémoires, des présences qui habitent l’espace public et traversent les époques.

Depuis plusieurs années, AUM inscrit une trace vivante et sensible dans le paysage culturel montréalais. Et encore cette année, nous travaillons pour vous proposer une belle édition 2025 de Mémoire de l'avenir.

L'affiche, c'est un geste simple, mais puissant, qui continue de faire résonner les luttes, les récits, les identités.

#arturbainmontreal #affichageculturel #mémoire #espacepublic #culturemontréalaise #expositionurbaine | 10 | 0 | 0 | 6mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.620Z |  | 2025-05-08T16:45:03.881Z | https://www.linkedin.com/feed/update/urn:li:activity:7325514742305886208/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7325542370257625088 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFWSoVMBnq8Ow/feedshare-shrink_800/B4EZajLLasHMAg-/0/1746494339466?e=1766620800&v=beta&t=q7nLBGuyEyM63cuhUyroI6pF44URFTPJftZnO7n5msw | De retour de l’Atelier Grand Nord XR, les idées encore en mouvement.
Presque difficile de revenir à la réalité.. 

Une semaine immersive pour confronter notre vision à celle des autres, écouter, ajuster, rêver plus grand. Un privilège.

L’architecture du bonheur, notre documentaire immersif interactif, entre maintenant dans une nouvelle phase de réflexion et de développement. Merci à François Dubé (Frangin) pour son impulsion, à Eulalie Lecoq (Agence Spatiale) pour la richesse de sa vision, et à toute la cohorte internationale pour les échanges denses et bienveillants.

Merci aussi à la SODEC - Société de développement des entreprises culturelles et son équipe pour l'AGN XR, Véronique Le Sayec et Chloé Lafrenière pour cette initiative précieuse, qui donne l’élan et l’encadrement dont les projets XR ont tant besoin.

Hâte de partager la suite. | 60 | 0 | 2 | 7mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.621Z |  | 2025-05-06T15:30:03.065Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7317962117708476417 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5f7756d5-f82b-40af-bb4c-caaa58365d5e | https://media.licdn.com/dms/image/v2/D4E05AQGyZFkCjluBow/videocover-high/B4EZYbDLLYGYBs-/0/1744210594415?e=1765785600&v=beta&t=cuV4fGT2rn80ymIVEzT5hknuNHLJbYjPEG4k25EHCVc | Soutenir les artistes d’ici, c’est aussi les inviter chez soi.
Art Urbain Montréal propose une sélection d’affiches issues de ses expositions urbaines. Une belle manière d’encourager la création locale, tout en embellissant vos murs.

Chaque achat soutient directement le travail des artistes qui ont contribué à faire vivre l’espace public autrement.

💻 Découvrez la boutique 👉 https://boutique.aumtl.com

Merci de faire rayonner l’art d’ici jusque chez vous 💛


#arturbainmontreal #afficheartistique #soutienauxartistes #boutiqueenligne #aumtl #affiche | 7 | 1 | 0 | 7mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.622Z |  | 2025-04-15T17:28:50.023Z | https://www.linkedin.com/feed/update/urn:li:activity:7317939828883357697/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7315345924984115201 | Article |  |  | ✨ Annonce officielle ✨
Je suis très heureux de partager que notre projet L’Architecture du Bonheur a été sélectionné pour la 9e édition de l’Atelier Grand Nord XR de la SODEC - Société de développement des entreprises culturelles

C’est un honneur de porter cette œuvre immersive aux côtés de François Dubé (Frangin), Étienne Bernier et Eulalie Lecoq (Agence Spatiale), ainsi que mon précieux partenaire Charles Richard (Archiv VR).

Bravo à tous les projets sélectionnés pour cette cohorte 2025 ! Vos univers singuliers nous inspirent déjà, hâte de vous rencontrer à Montebello prochainement. | 40 | 5 | 0 | 7mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.625Z |  | 2025-04-08T12:13:01.071Z | https://sodec.gouv.qc.ca/la-sodec-annonce-la-cohorte-de-la-9e-edition-datelier-grand-nord-xr/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7313560982725808130 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7eb4122e-7119-4eb6-9c80-3a074442b144 | https://media.licdn.com/dms/image/v2/D4E05AQET1k3kXrI12A/videocover-low/B4EZXZvxB6GwCQ-/0/1743114937740?e=1765785600&v=beta&t=moyLkBktDigBNkvRrGE9_SsmP4BlSDXAIM42a6kLk0E | C’est officiel : la BETA TEST est lancée !
Il ne vous reste que quelques jours pour rejoindre l’équipe des testeurs d’Apophenia XR. C'est un grand moment pour nous. 

👇 Toujours aussi simple, c'est dans le Discord 👇 
https://lnkd.in/ewErTU5H | 12 | 0 | 1 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.626Z |  | 2025-04-03T14:00:17.674Z | https://www.linkedin.com/feed/update/urn:li:activity:7311397916403720194/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7311430410251501568 | Video (LinkedIn Source) | blob:https://www.linkedin.com/21012598-b8b9-4b2b-b78d-9e6f01675304 | https://media.licdn.com/dms/image/v2/D4E05AQET1k3kXrI12A/videocover-low/B4EZXZvxB6GwCQ-/0/1743114937740?e=1765785600&v=beta&t=moyLkBktDigBNkvRrGE9_SsmP4BlSDXAIM42a6kLk0E | Depuis une semaine, j'essaye d'expliquer par les mots. Donc on a fait une petite vidéo, et elle montre pas mal tout ce qu’il faut savoir.

Apophenia XR, c’est notre système de production XR développé depuis 2021 chez Archiv VR. Et on entre enfin en BETA test. C’est une grosse étape pour nous.

Vous travaillez en XR sur Unity ?
➡ Rejoignez-nous sur Discord : https://lnkd.in/ewErTU5H | 7 | 1 | 0 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.626Z |  | 2025-03-28T16:54:09.612Z | https://www.linkedin.com/feed/update/urn:li:activity:7311397916403720194/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7310288101522788353 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHWfZf2aTOBtA/feedshare-shrink_800/B4EZWxx4IeG0Ag-/0/1742444397690?e=1766620800&v=beta&t=3_nzHi0eD4AR344tXL0WxVO-5UVb5Vd46bPAd9qLVP4 | Apophenia XR est bientôt disponible! 💪 

Bientôt 5 ans déjà que l'aventure a commencé avec Archiv VR, et aujourd’hui, avec Charles, on franchit une nouvelle étape importante, notre grande annonce : la mise en marché de notre propre outil numérique, Apophenia XR.

Un système que nous avons commencé à développer en 2021, lors de notre toute première production avec le The UQAM Design center de Montréal, puis que nous avons fait évoluer, testé, affiné avec les projets comme celui de l’OSTR-Orchestre symphonique de Trois-Rivières ou de Vivid Memory Studios.

Aujourd’hui, Apophenia XR est en BETA TEST. Quel fierté, émotion importante pour Charles et moi. C’est beaucoup de travail, de doutes aussi. Des hauts et des bas que seul Charles et moi pouvons vraiment comprendre… Et pourtant, on continue de s’entraider, d’avancer, après presque 5 années de collaboration. C’est ça aussi, l’aventure entrepreneuriale : tenir, créer, apprendre, et rêver encore.

Alors je me permets ce petit message personnel pour dire : merci à celles et ceux qui nous soutiennent depuis si longtemps. Vous vous reconnaitrez assurément. 

Si vous êtes curieux, impliqué dans le milieu XR ou simplement intéressé à tester ou référer un professionnel de votre réseau, écrivez-nous ou rejoignez-nous ici :
👉 https://lnkd.in/eWMBccKs
👉 apophenia@archivvr.com

Merci 💛

#apopheniaxr #archivvr #betatest #xrcommunity #entrepreneuriat #unityxr | 47 | 10 | 3 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.628Z |  | 2025-03-25T13:15:01.988Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7309963460858028032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVemVqC1bBYA/feedshare-shrink_800/B4EZWxmSkOGYAk-/0/1742441360076?e=1766620800&v=beta&t=0EMLCcWhmahuhkfIxGCH59ogIDMHfW-iU5YhJfcJLHE | Good Monday everyone ☕ 
Archiv VR is now on Discord! 

And our Apophenia XR BETA is live.
A space for XR professionals & creators to connect, share & grow.

💬 XR workflows – No-code tools – Digital archiving – Creative collaboration.

Join us now → https://lnkd.in/ewErTU5H
Let’s build this together.

#xrcommunity #archivvr #apopheniaxr #unitydevelopers #betatesterswanted | 6 | 0 | 0 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.629Z |  | 2025-03-24T15:45:01.622Z | https://www.linkedin.com/feed/update/urn:li:activity:7309914387362820096/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7308993316027547649 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTznf2_UKSOA/feedshare-shrink_800/B4EZW6.N2aH0Ag-/0/1742598627483?e=1766620800&v=beta&t=1fRCUGfMdNjg8ZtQNXLPjUymXiWtvuzmnyh5A5zC4Rw | 🚀 Apophenia XR is now in BETA!

Are you creating XR experiences on Unity?
We’re looking for BETA testers / creators, devs, studios.

What is it?
A no-code production tool for Unity, built to simplify XR workflows.
Manage scenes visually, export to multiple platforms, collaborate more easily.

➡ Join our Discord: https://is.gd/ctUgkA
📩 Questions? apophenia@archivvr.com

Not for you? Maybe someone in your network, feel free to share!

#XR #Unity #BetaTest #ApopheniaXR #ArchivVR #NoCodeTools #ImmersiveCreation | 12 | 0 | 1 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.630Z |  | 2025-03-21T23:30:01.070Z | https://www.linkedin.com/feed/update/urn:li:activity:7308988400630484992/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7308509075686785026 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQERH2MSdu8RvA/feedshare-shrink_800/B4EZWwceRbH0Ak-/0/1742422009653?e=1766620800&v=beta&t=7Ycbqzsv--Px9D6pMmSxU_wZAeQnnIZc4iiOpEpmZDY | Un moment important pour nous chez Archiv VR : on lance enfin la BETA d’Apophenia XR.

Un outil qu’on développe depuis des années pour simplifier la production XR sur Unity.

On est super fiers… et on a besoin de vous 🙏 😇 

➡ On cherche des BETA TESTEURS XR : créateurs, studios, devs, venez tester, donner vos retours sur notre système.

👇 Toutes les informations ici 👇 
https://lnkd.in/ewErTU5H

#archivvr #unity #betatesting #apopheniaxr | 17 | 0 | 2 | 8mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.631Z |  | 2025-03-20T15:25:49.176Z | https://www.linkedin.com/feed/update/urn:li:activity:7308461084762394628/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7288237637687996417 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHV_60o3cbCiQ/feedshare-shrink_800/B4EZSO3dLxG0Ak-/0/1737563690514?e=1766620800&v=beta&t=AxJuWRA7t5T0XYowJCqt7f5_cNagbbu4_STjxHOebck | 👇 Annonce pour mon réseau professionnel 👇

Art Urbain Montréal (AUM) cherche des partenaires engagés et passionnés pour faire rayonner l'art et les artistes par l’affichage urbain. L’édition 2025 de Mémoire de l’Avenir se prépare à transformer l’espace public en une véritable galerie à ciel ouvert.

📣 Pourquoi s’impliquer ?

En soutenant AUM, vous ne financez pas seulement un événement d’envergure, vous contribuez activement à la vitalité culturelle de Montréal sur le long terme. Nous cherchons des partenaires qui ont à cœur notre mission et souhaitent s’engager pour bâtir un avenir où l’art et la communauté se rencontrent dans l’espace public.

💡 Devenir partenaire, c’est aussi :
✅ Associer votre marque à un projet culturel unique et engagé
✅ Participer à la mise en valeur de la créativité locale
✅ Offrir aux artistes des opportunités d’expression inédites par l'affiche
✅ Soutenir une vision culturelle durable et évolutive

Nous avons besoin de vous pour que cette édition et les suivantes continuent de faire vibrer les rues de la Ville de Montréal au rythme de l’art. Envie de contribuer ? 

Parlons-en ! 👉 info@aumtl.com

📩 Pour toute information supplémentaire, vous pouvez me contacter directement sur mon Linkedin, ou échanger avec Baudoin Wart ou Danielle Lamontagne.

#partenariatculturel #arturbainmontreal #artMTL #MTLmoments #culturemontreal #artpublicmontreal #quebeccreatif | 14 | 0 | 2 | 10mo | Mathieu Troussel reposted this | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.633Z |  | 2025-01-23T16:54:21.732Z | https://www.linkedin.com/feed/update/urn:li:activity:7287870343560482818/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7288235311283789826 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHV_60o3cbCiQ/feedshare-shrink_800/B4EZSO3dLxG0Ak-/0/1737563690514?e=1766620800&v=beta&t=AxJuWRA7t5T0XYowJCqt7f5_cNagbbu4_STjxHOebck | 👇 Annonce pour mon réseau professionnel 👇

Art Urbain Montréal (AUM) cherche des partenaires engagés et passionnés pour faire rayonner l'art et les artistes par l’affichage urbain. L’édition 2025 de Mémoire de l’Avenir se prépare à transformer l’espace public en une véritable galerie à ciel ouvert.

📣 Pourquoi s’impliquer ?

En soutenant AUM, vous ne financez pas seulement un événement d’envergure, vous contribuez activement à la vitalité culturelle de Montréal sur le long terme. Nous cherchons des partenaires qui ont à cœur notre mission et souhaitent s’engager pour bâtir un avenir où l’art et la communauté se rencontrent dans l’espace public.

💡 Devenir partenaire, c’est aussi :
✅ Associer votre marque à un projet culturel unique et engagé
✅ Participer à la mise en valeur de la créativité locale
✅ Offrir aux artistes des opportunités d’expression inédites par l'affiche
✅ Soutenir une vision culturelle durable et évolutive

Nous avons besoin de vous pour que cette édition et les suivantes continuent de faire vibrer les rues de la Ville de Montréal au rythme de l’art. Envie de contribuer ? 

Parlons-en ! 👉 info@aumtl.com

📩 Pour toute information supplémentaire, vous pouvez me contacter directement sur mon Linkedin, ou échanger avec Baudoin Wart ou Danielle Lamontagne.

#partenariatculturel #arturbainmontreal #artMTL #MTLmoments #culturemontreal #artpublicmontreal #quebeccreatif | 14 | 0 | 2 | 10mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.634Z |  | 2025-01-23T16:45:07.074Z | https://www.linkedin.com/feed/update/urn:li:activity:7287870343560482818/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7285287117318942720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEk_4sj77uHbw/feedshare-shrink_800/B4EZRjEM0WHMAg-/0/1736828836057?e=1766620800&v=beta&t=hc5zjnD1xRSRVnzW1SQlycMvVv-L0-mpA_CHwK7desc | Ai-je des artistes dans mon réseau professionnel? 🎨

Il reste encore quelques jours pour rejoindre l’aventure Mémoire de l’Avenir 2025! C’est l’opportunité parfaite de participer à un projet culturel ambitieux qui transformera l’espace public montréalais en 2025.

📅 Date limite : 1er février 2025
👉 Soumettez votre candidature ici : https://lnkd.in/eF6ZaweW

Partagez cette opportunité dans vos réseaux💡

#aum #mda #artistes #artpublic #culturemontreal #explorepage #quebec #montreal #poster #affiche #illustration | 11 | 5 | 1 | 10mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.636Z |  | 2025-01-15T13:30:02.858Z | https://www.linkedin.com/feed/update/urn:li:activity:7284928498513641472/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7282459729384148993 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGMa421CuOgBw/feedshare-shrink_1280/B4EZRBQyuYHEAs-/0/1736261709131?e=1766620800&v=beta&t=X5NeOF8eLPaq4muxr9aO1Ikd14aJXqEkZmx7QY0rYHE | Nouvelle année, nouveaux défis! 
Merci à l'équipe d'Art Urbain Montréal pour cet accueil chaleureux! 🌟

Je suis ravi de rejoindre AUM et de contribuer au projet Mémoire de l’Avenir 2025, qui met en lumière l’art et les artistes à travers des affiches dans l’espace public, tout en intégrant depuis 2023 un volet numérique innovant en réalité augmentée.

Cette mission s’aligne parfaitement avec mon engagement à travers Archiv VR, qui continue d’être un moteur pour la préservation et la valorisation du patrimoine culturel grâce aux outils numériques. Je suis enthousiaste à l’idée de voir ces deux engagements enrichir mutuellement leurs perspectives.

#memoiredelavenir2025 #arturbainmontreal #archivvr #realiteaugmentee #nouveauxdefis | 63 | 23 | 0 | 11mo | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.637Z |  | 2025-01-07T18:15:01.044Z | https://www.linkedin.com/feed/update/urn:li:activity:7282409436290187269/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7270899872810078209 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHSo0JuCPPt2w/feedshare-shrink_800/feedshare-shrink_800/0/1733287565951?e=1766620800&v=beta&t=Hq-mgis50H3kPWgwynDmkuZzZp8XutnyReJck45DvL0 | Retour sur une belle journée au DigiHub Shawinigan !

Ce fut un réel plaisir de présenter nos projets VR/AR lors de l’événement organisé par Tourisme Mauricie. La Mauricie m’a encore prouvé qu’elle est un terreau fertile pour des initiatives ambitieuses et créatives. Les rencontres et échanges ont été stimulants, et j'ai hâte 2025 pour découvrir les futurs projets se mettre en place et contribuer à ce dynamisme régional.

Merci à Tourisme Mauricie, au DigiHub Shawinigan, et à tous les partenaires pour cette belle journée de collaboration et d’innovation. 🚀

#VR #AR #tourisme #innovation #culture #archivvr | 6 | 0 | 0 | 1yr | Post | Mathieu Troussel | https://www.linkedin.com/in/mathieutroussel | https://linkedin.com/in/mathieutroussel | 2025-12-08T07:19:48.638Z |  | 2024-12-06T20:40:16.465Z | https://www.linkedin.com/feed/update/urn:li:activity:7270117151544410112/ |  | 

---



---

# Mathieu Troussel
*Art Urbain Montréal*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Untitled - bureau d'étude de pratiques indisciplinées](https://www.be-pi.ca/s/INVENTAIRE-Livret-WEB.pdf)
- Category: article

### [Social Media](https://digitalmediaknowledge.com/socialmedia/)
- Category: article

### [MSP and Urbania – Montréal Signs Project](https://www.montrealsignsproject.ca/msp-and-urbania)
*2025-01-01*
- Category: article

### [The Art Souterrain festival marks 15 years  with a festive theme!](https://www.quartierdesspectacles.com/en/blog/the-art-souterrain-festival-marks-15-years-with-a-festive-theme)
*2025-01-17*
- Category: blog

### [Narratives - IN SITU](https://www.in-situ.info/narratives?countries=61)
*2024-12-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Équipe — Art Urbain Montréal](https://www.aumtl.com/equipe)**
  - Source: aumtl.com
  - *Pendant notre pause, Art Urbain Montréal maintient un fonctionnement minimal grâce à son équipe actuelle. ... MATHIEU TROUSSEL. (il) CHARGÉ DE PROJET ...*

---

*Generated by Founder Scraper*
