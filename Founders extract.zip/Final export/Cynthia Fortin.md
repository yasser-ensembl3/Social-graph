# Cynthia Fortin

## Position actuelle

**Titre** : Founder & Consultant
**Entreprise** : CFortissimo
**Durée dans le rôle** : 14 years 11 months in role
**Durée dans l'entreprise** : 14 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

As a senior digital marketing consultant, I use my expertise, passion and 20 years of experience to understand my clients' needs through insights gathered through UX and marketing research and analytics and develop solutions with my clients using digital tools. 

Developed and grown Affiliate Marketing program at Bell Media, making it a sustainable source of revenues (CTV News Shopping Trends & Noovo Moi)

Test and introduced and managed Affiliate Marketing program as a new revenue stream at Quebecor 
Media (Journal de Montréal, Canadian Living , Elle Canada& Québec, Coup de Pouce)

Developed social media campaigns & digital plans for clients in the Fragrance, Health and Advisory (engineering & coaching) in Switzerland, Belgium & Canada 

Developed social media campaigns & digital plans for clients in the Fragrance, Health and Advisory (engineering & coaching) in Switzerland, Belgium & Canada 

Conceptualized and executed SEO & SEM mandates for SMEs in Quebec & Switzerland Developed websites and and implemented digital & PR campaigns for clients, including the Fragrance Industry with the developement of the web presence and launch campaign for Valeur Absolue Parfums, (valeurabsolue.com)

## Résumé

As a digital marketing expert, I have been working independently for nearly five years, both solo as an affiliate marketing expert and as part of a team with my loyal colleagues, who are as passionate as I am and have expertise that complements my own (Hugues Chandonnet, Déraison, Camille Blais, graphic designer, Caroline Tétreault, digital content manager, Daniel Fournier, DFSA) with whom we help companies and organizations launch brands, rethink their marketing plans, change habits, and boost sales.

My eight years of experience in affiliate marketing on the publisher side (content editor) make me one of the most qualified experts in the country in affiliate marketing.  I was also invited to speak at Affiliate Summit West in January 2025 on the Canadian affiliate marketing market.  
Through this discipline, which is still underutilized in Canada, I help Canadian media outlets monetize their sites through partnerships with international and Canadian brands, working closely with major affiliate networks such as Amazon, Rakuten, CJ & Impact. 



SKILLS
• 20 years of experience in marketing & digital
• Affiliate Marketing
• Monetization
• Development and management of large-scale websites & eCommerce sites
• Development of partnerships
• UX Research and Marketing
• Content strategy 
• Data, performance measurement, and optimization
• SEO, SEM
• Team management & coaching
• Proof of Concept
• Market development
• Digital Media Strategy

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABcVTcBhWjjEHORttdiO6dx7BzsZqv1KRg/
**Connexions partagées** : 24


---

# Cynthia Fortin

## Position actuelle

**Entreprise** : CFortissimo

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Cynthia Fortin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394042551785181184 | Article |  |  | Mon chum interviewé par Urbania sur les pièges à éviter quand on commence à investir. 

Si vous jouez à l'autruche avec vos finances, que vous n'avez pas de plan pour votre futur ou que votre conseiller est moyen, je vous incite à le contacter.  En plus, il est ben l'fun, ça passe mieux quand vient le temps de parler d'argent. 
⚡Daniel Coté⚡
https://lnkd.in/eVcEERau | 18 | 0 | 0 | 3w | Post | Cynthia Fortin | https://www.linkedin.com/in/cynthia-fortin-9870392 | https://linkedin.com/in/cynthia-fortin-9870392 | 2025-12-08T06:21:24.169Z |  | 2025-11-11T16:05:19.013Z | https://urbania.ca/article/9-pieges-a-eviter-quand-on-commence-a-investir |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7317643960879837184 | Article |  |  | Bien fière de cette belle participation à la populaire téléréalité Coeur de Trucker pour mon client le Centre du Camion Gamache.  Vous y verrez Richard Gamache présenter ses camions à PA Méthot l'animateur et la participante Josiane, prendre la route avec un camion de chez Gamache.  . 

Pour visionner le premier épisode, c'est ici! https://lnkd.in/gTM_tChY

Et voici le spot imaginé par Hughes Chandonnet@Déraison) et réalisé par Motus, beau parallèle entre la recherche de l'âme soeur et celle d'un camion! https://lnkd.in/gBeKxJvb

Merci à Carole Simpson du Centre du Camion Gamache pour sa confiance et à l'équipe d'Attraction et de TV5/Unis pour leur professionnalisme. | 15 | 1 | 0 | 7mo | Post | Cynthia Fortin | https://www.linkedin.com/in/cynthia-fortin-9870392 | https://linkedin.com/in/cynthia-fortin-9870392 | 2025-12-08T06:21:24.170Z |  | 2025-04-14T20:24:35.524Z | https://www.tv5unis.ca/videos/coeur-de-trucker/saisons/3/episodes/1 |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7295575655054753793 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGFbr-N-xDD8w/feedshare-shrink_2048_1536/B4EZT8XY6.GYAo-/0/1739400777801?e=1766620800&v=beta&t=0xoQ-AOSpKt7WuZe6e3-VatwKV93BkPgzq8UtfOfZ7I | Great times at ASW25 as a speaker at the Publisher Demo and off course, connecting with great people! | 45 | 5 | 0 | 9mo | Post | Cynthia Fortin | https://www.linkedin.com/in/cynthia-fortin-9870392 | https://linkedin.com/in/cynthia-fortin-9870392 | 2025-12-08T06:21:24.170Z |  | 2025-02-12T22:53:01.406Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7292685514514546688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhRmbLNMKiNA/feedshare-shrink_800/B4EZTTSyyhHMAk-/0/1738711713645?e=1766620800&v=beta&t=YDQ5uB6yYika2e7LBkjQgg46ALoUrsZqNDHxy354t1k | Bien heureuse de pouvoir apprendre et m’inspirer de mes pairs (NBC, Forbes, CNet, WSJ) et faire des rencontres profitables à Affiliate Summit West #ASW2025 | 41 | 1 | 0 | 10mo | Post | Cynthia Fortin | https://www.linkedin.com/in/cynthia-fortin-9870392 | https://linkedin.com/in/cynthia-fortin-9870392 | 2025-12-08T06:21:24.171Z |  | 2025-02-04T23:28:38.205Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7275896977052114945 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEYBhW5CBSUCw/feedshare-shrink_800/B56ZPktvrMGsAk-/0/1734709017791?e=1766620800&v=beta&t=_ZVNfXUX5j_K8brqE_12QaTwNJ_z3vXiBEyAJTigY1g | I'm speaking at #ASW25! Join me and over 7,000 advertisers, affiliates, ecom sellers, tech providers, and networks at the biggest affiliate marketing event in the WORLD on February 3–5 in Las Vegas. Plus, use my speaker code SPEAKER20 to get 20% off your ticket!
https://lnkd.in/gEcyXrAg | 61 | 7 | 0 | 11mo | Post | Cynthia Fortin | https://www.linkedin.com/in/cynthia-fortin-9870392 | https://linkedin.com/in/cynthia-fortin-9870392 | 2025-12-08T06:21:24.171Z |  | 2024-12-20T15:36:58.958Z |  |  | 

---



---

# Cynthia Fortin
*CFortissimo*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [About — cFortissimo](https://www.cfortissimo.com/about)
*2019-01-01*
- Category: article

### [Cynthia Fortlage - INvolve Outstanding](https://outstanding.involverolemodels.org/person/cynthia-fortlage-4/)
*2021-01-19*
- Category: article

### [‎Startup Parent: Designing For Resilience (with co-host Cary Fortin) on Apple Podcasts](https://podcasts.apple.com/us/podcast/designing-for-resilience-with-co-host-cary-fortin/id1289880441?i=1000516766548)
*2021-04-12*
- Category: podcast

### [‎The Fort - An Entrepreneurship Podcast on Apple Podcasts](https://podcasts.apple.com/be/podcast/the-fort-an-entrepreneurship-podcast/id1410549811)
*2024-06-11*
- Category: podcast

### [Podcasts Archives – Fort](https://fort-companies.com/category/podcasts/)
*2025-04-09*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Affiliate Summit West - 2025 - Conference Connect](https://conferenceconnect.com/events/affiliate-summit-west-2025)**
  - Source: conferenceconnect.com
  - *Cynthia Fortin. Founder & Consultant CFortissimo. Penny Lee. VP of Marketing Medigap Life. Tickets. Register. Where To Stay. Hotel and ......*

- **[La MRC de Roussillon lance sa nouvelle signature régionale ...](https://www.grenier.qc.ca/actualites/43003/la-mrc-de-roussillon-lance-sa-nouvelle-signature-regionale)**
  - Source: grenier.qc.ca
  - *Jul 2, 2024 ... roussilon Simon Tremblay, Templar Branding; Cynthia Fortin, CFortissimo ... TOU.TV s'invite dans vos pauses Lire l'article ......*

---

*Generated by Founder Scraper*
