# Felix Simard

## Position actuelle

**Titre** : Founder, CEO
**Entreprise** : Dimedove
**Durée dans le rôle** : 1 year 9 months in role
**Durée dans l'entreprise** : 1 year 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Building Dimedove: AI agents for intelligent lead qualification — transforming how businesses connect, sell, and grow in the agentic era.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABk9mrwBl--23rmAn0nU97yGb_d4AF7lg7Q/
**Connexions partagées** : 35


---

# Felix Simard

## Position actuelle

**Entreprise** : Dimedove

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Felix Simard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402728227489914880 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG2eV0IOSU65w/feedshare-shrink_800/B56ZrvGF5eLAAg-/0/1764947943727?e=1766620800&v=beta&t=YMXW6V2mzPjhFp0c2QotVCpHqPa4MmLSWOSExj2KkW0 | Semaine dernière, j’ai eu la chance de jaser “agents” avec Francois Lanthier Nadeau, une occasion de lui partager comment des entreprises d’ici bâtissent et déploient des agents de qualification de leads à grande échelle grâce à Dimedove.

On parle entre autres du passage des anciens chatbots aux agents modernes, de notre approche humaine de “onboarding” pour créer un agent, et de l’importance du contrôle et des limites tout en offrant une expérience client rapide et intelligente.

Merci à SaaSpasse de jouer un rôle crucial dans la visibilité et la croissance de l’écosystème tech du Québec. Si vous n’êtes pas encore abonnés à leur infolettre : https://lnkd.in/gwziqJeT | 66 | 5 | 1 | 2d | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.201Z |  | 2025-12-05T15:19:05.473Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389403432677433344 | Text |  |  | We’ve been fortunate to work side by side with our first customers as they launch their agents. Watching them see real outcomes so early is both motivating and validating.

To share more of that journey, I just sent out the first edition of Founder Insider, a behind-the-scenes look at building Dimedove, covering product updates, milestones, challenges, and company progress as we grow more and more (hopefully).

If you’d like to follow along and get updates directly from me on a loosely defined cadence, visit dimedove.com and subscribe at the bottom. | 86 | 8 | 1 | 1mo | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.201Z |  | 2025-10-29T20:51:06.827Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7362098678863433728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGp8eyn0am7tQ/feedshare-shrink_800/B4EZittvDHHEAg-/0/1755261105582?e=1766620800&v=beta&t=oK8xYt2Jfyob42nEEeKZACq2XkmTLs6jCuvQCwJb7DY | Been a bit quiet the last couple weeks… here’s the latest on Dimedove.

Twelve months ago, Dimedove embarked on a mission to make financial expertise more accessible, personalized, digital, affordable, powered by AI, and backed by humans.

As I spoke with more and more businesses and professionals aiming to kickstart or grow their careers, I kept hearing the same thing. They wanted to get to know both visitors and prospects more deeply and quickly, to understand their context, engage them in their brand and offerings more efficiently, meet their needs, and personalize the experience from the very first interaction. I realized the platform I’d built for finance could already do this, but by focusing on those specific pain points, we could make it even more impactful.

Today, that’s exactly what Dimedove does. Businesses can deploy our technology directly on their own website, aligned with their unique goals, to elevate their lead qualification process into something faster, smarter, more connected, and more efficient. We’re building intelligent, task-driven AI agents for lead qualification, purpose-built to deliver consistent, personalized, instant interactions at scale. Our mission is to equip any business with truly useful agents they can integrate into existing workflows to transform how businesses will connect, sell, and grow in the agentic era of the web.

We’ve already onboarded early customers, and the results have been very promising.

If you want to see what this looks like in action and how it could supercharge your business’s lead qualification process, check out the new site and book a call/demo with me.

🔗 https://dimedove.com
📅 https://lnkd.in/e_3Ei79v | 104 | 11 | 1 | 3mo | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.202Z |  | 2025-08-15T12:31:46.220Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7354169778455949312 | Video (LinkedIn Source) | blob:https://www.linkedin.com/266e3448-cec3-40c6-b5db-21618df6e56c | https://media.licdn.com/dms/image/v2/D4E05AQEd5xJbYcQGKw/feedshare-thumbnail_720_1280/B4EZg8seqAGYA0-/0/1753364952604?e=1765782000&v=beta&t=eJ37yWQqkuLivyj6AS7cWQGEDLksBRx5Ci3cVYyXPHc | "Phil, je sors le MVP la semaine prochaine, trust me." 
- Me, for way too many weeks, being a stubborn engineer

Dimedove — both as a product and a vision — has evolved a lot over the past months, taking a bold new direction with a clearer trajectory that’s already showing traction with customers. We’re really excited to share more about this next chapter in the coming weeks.

Merci l'ACET! | 71 | 13 | 1 | 4mo | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.203Z |  | 2025-07-24T15:25:09.051Z | https://www.linkedin.com/feed/update/urn:li:activity:7354146358745788417/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7296173178161168384 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE3ouxJ3uiAJw/feedshare-shrink_800/B4EZUE20FBH0Ao-/0/1739543240184?e=1766620800&v=beta&t=UuGaww9C1qbZBLjZIVwZOGVCZZ6m2HSkYF1R8rsjFSk | Announcing awards for the "Entrepreneurial Finances" case at the 2025 McGill-hosted Financial Open was definitely not something I had in my short-term plans after graduating as a software engineer... but then again, none of what I'm doing now was ever part of "the plan".

Alongside my partner, Vladimir Buslayev, Pl. Fin., it was an honour for Dimedove to sponsor the 2025 FO, Canada’s largest inter-university finance and accounting competition, bringing together the next generation of finance professionals.

Thank you to every school delegation that worked on our case, to everyone who engaged in insightful conversations with us, and to the Financial Open team for this incredible opportunity.

Dimedove will be available for exclusive access in the coming month. If you're interested, join our waitlist: https://lnkd.in/eiu9whn2 | 158 | 14 | 4 | 9mo | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.204Z |  | 2025-02-14T14:27:22.016Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7285636014549659648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJ7S5MaIMfWw/feedshare-shrink_800/B4EZRslo4tGgAg-/0/1736988594656?e=1766620800&v=beta&t=S2ZIL24lrf7kQ-iAGPrjlF2hauTzy-Ct083mayHnVww | Dimedove is excited to partner with the Financial Open, Canada’s largest inter-university finance and accounting competition. 

Thank you to the Financial Open team—can’t wait! | 70 | 14 | 0 | 10mo | Post | Felix Simard | https://www.linkedin.com/in/felixsimard | https://linkedin.com/in/felixsimard | 2025-12-08T06:10:22.204Z |  | 2025-01-16T12:36:26.440Z | https://www.linkedin.com/feed/update/urn:li:activity:7285458214484082690/ |  | 

---



---

# Felix Simard
*Dimedove*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Simard podcasts | Ivy.fm](https://ivy.fm/tag/simard)
*2025-04-15*
- Category: article

### [How to maximise your agency's exit value — Board Advisor, M&A and Exit Strategist, and Strategic Growth Consultant | Felix Velarde](https://felixvelarde.com/articles/how-to-maximise-your-agencys-exit-value)
*2025-11-14*
- Category: article

### [Have You Heard of Polywork?](https://nicksimard.substack.com/p/04)
*2022-09-18*
- Category: blog

### [Introduction - Dimedove](https://dimedove.mintlify.app/)
- Category: article

### [How to Scale at Speed with Felix Velarde (MDE552)](https://www.minterdial.com/2024/02/felix-velarde/)
*2024-02-18*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Privacy policy - Dimedove](https://docs.dimedove.com/legal/privacy-policy)**
  - Source: docs.dimedove.com
  - *Aug 27, 2025 ... Dimedove Technologies Inc., operating as “Dimedove” (“we,” “us ... Felix Simard, CEO Email: security@dimedove.com Support: support .....*

- **[felixsimard (Felix Simard) · GitHub](https://github.com/felixsimard)**
  - Source: github.com
  - *Blog. Integrations. GitHub Marketplace · MCP Registry · View all features. Solutions ... Felix Simard felixsimard. Follow. Building Dimedove. 11 follo...*

- **[Stratégie IA : l'écosystème mobilisé pour la feuille de route ...](https://vitrine.ia.quebec/strategie-ia-lecosysteme-mobilise-pour-la-feuille-de-route-quebecoise-c82102b8-a12d-47ef-812d-359df6c80eae)**
  - Source: vitrine.ia.quebec
  - *Nov 10, 2025 ... Felix Simard (Dimedove). Francis Baillet (Ubisoft). Francis Latulippe ... Une entreprise en IA Une étude de cas Un article. Informati...*

---

*Generated by Founder Scraper*
