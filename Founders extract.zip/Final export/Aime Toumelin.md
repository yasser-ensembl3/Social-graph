# Aime Toumelin

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Hadaly
**Durée dans le rôle** : 3 years 8 months in role
**Durée dans l'entreprise** : 3 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Data Infrastructure and Analytics

## Description du rôle

Hadaly is an AI-powered platform that streamlines business transfers and enhances data governance for M&A transactions.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACPtUEEBBFH1MF4EuJcthpFRXuomFrrs2q8/
**Connexions partagées** : 54


---

# Aime Toumelin

## Position actuelle

**Entreprise** : Hadaly

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Aime Toumelin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401655156037099522 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQGoVAGYTyOUzA/mp4-720p-30fp-crf28/B4EZq33pB3KcCE-/0/1764021411237?e=1765782000&v=beta&t=vGLTuMKHRoWam0ZRcnHTUA-WJT1i3CQBBGSzuTC-KtU | https://media.licdn.com/dms/image/v2/D4E05AQGoVAGYTyOUzA/feedshare-thumbnail_720_1280/B4EZq33pB3KcA0-/0/1764021408268?e=1765782000&v=beta&t=GCx7T6Z1OOJcspbyXAqgNj8EQm0xvpgFYmillgOQDnk | We’re Opening Up Our Numbers at Hadaly !

Building a company is hard.
What makes it even harder is not knowing whether your numbers are “good” or not.

Over the last few years, being surrounded by founders through programs like NEXT AI taught us something important. Everyone faces similar challenges, but nobody talks openly about their real numbers.

Reda Mjahed Christopher Dip Nabil Tayeb, MBA Nylan Raufaste Alexandre Carey ;)

Not because they don’t want to,  but because transparency requires trust.

So how do we, as entrepreneurs, know if we’re actually on the right track?

What if we could benchmark ourselves, Safely?
What if companies could compare their performance anonymously, using real fundamentals pulled from their data room, without revealing any sensitive information?

We’re launching a pilot inside Hadaly that allows businesses to benchmark themselves across 35 financial and operational metrics, anonymously, against their industry and anonymised data from 500+ canadian companies.

To lead by example, we’ve added Hadaly’s own numbers into the benchmark group.

Transparency starts with us. :)


If your company runs on QuickBooks and you want to:
- Understand how you truly compare to similar businesses
- Evaluate Your Business Real Value
- Identify where your margins, SG&A, payroll ratios, or growth stand
- See your performance through the lens of investors and acquirers
- Get insights that normally require expensive consulting work

…then this pilot will give you clarity you’ve never had before.

We’re opening access to a limited group of QuickBooks-integrated companies.

To join this group message me directly :) or take a meeting with me 

https://lnkd.in/gGHR-J8f | 44 | 3 | 2 | 5d | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:07.821Z |  | 2025-12-02T16:15:05.302Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399103342658084865 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQU-qZmyaaSw/feedshare-shrink_800/B4EZpgayPlHgAg-/0/1762554225992?e=1766620800&v=beta&t=fsCxmucC3o50oqzx6ei0wc2cqtB72yepHpq3065L3Fw | Do you Know your Business Valuation ?

Business owners on Hadaly can now generate a business valuation report in one click ! 

We now support a native QuickBooks integration to help you understand your company’s value and performance

What should we integrate next ?

Acomba , Sage, Xero, Qonto name it we will integrate it.

book a meeting with me if you want to test it :)

https://lnkd.in/gGHR-J8f | 55 | 12 | 4 | 1w | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:07.826Z |  | 2025-11-25T15:15:05.582Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393686402107904000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG_MS1fZdjydA/feedshare-shrink_800/B4EZpgO0q6GYAg-/0/1762551090739?e=1766620800&v=beta&t=-F3TGPdvdToWj5j2UGlsZQ82ukFGUH_M9CMjc632hSc | Quels sont les multiples de valorisation au Québec ? (Liste partageable)

C’est une question que j’entends chaque jour auprès des courtiers, directeurs de compte, comptables et avocats.

Chez Hadaly, nous avons compilé une liste anonymisée de 100 transactions d’entreprises québécoises conclues ces dernières années pour donner un repère concret sur les multiples au Québec.

On parle beaucoup de repreneuriat et d’un afflux de vendeurs à venir. Sur le terrain, on le voit : mieux vaut être bien appuyé, les volumes peuvent grimper vite et la qualité d’exécution fait la différence.

Il vous suffit d'écrire “Transaction100” et je vous enverrai la liste anonymisée (multiples, secteurs/NAICS, métriques clés).

 Données anonymisées, à usage indicatif  (pas un avis de valeur).

#Québec #PME #Repreneuriat #Courtier #Mergers #Évaluation #Multiples | 66 | 323 | 6 | 3w | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:07.827Z |  | 2025-11-10T16:30:06.313Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7351699467999318017 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9cdde42e-b292-4e5c-ad83-4a5e6e7b45ba | https://media.licdn.com/dms/image/v2/D4E05AQEBJA--lDX-3g/videocover-high/B4EZgZ7tAyGcCI-/0/1752781739103?e=1765782000&v=beta&t=KXiKDjkqX34l2tqCvUTMZb6eH4SAvDvxGtbe70DThKY | Major Update on Hadaly

Since the beginning of 2025, our clients have been using our data room software for multiple purposes:

- Secure document exchange
- Maintaining momentum and control during business sales and acquisitions
- Generating valuation reports directly from the platform (over 160 reports generated since January)

As we continue to expand our features, you can now also:

- Generate a CIM (Confidential Information Memorandum)
- Create a Teaser
- Add your own branding to the documents and data room

We know how important it is for business professionals and entrepreneurs to reflect their brand identity throughout the transaction process. That’s why branding is now fully supported within Hadaly.

The new features are now live on Hadaly. And because nothing beats a real conversation, our team is available to answer any questions you may have. | 69 | 4 | 6 | 4mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.644Z |  | 2025-07-17T19:49:01.142Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7343671479236030464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ea055dbc-9ceb-4d81-9af6-781b5e5e548c | https://media.licdn.com/dms/image/v2/D5605AQGnIMJqL5ApyQ/videocover-low/B56Zen2E6aG0CA-/0/1750867712155?e=1765782000&v=beta&t=6UbNp1SDp09SorRu0krRrnqZe6VBnDda-aCgzalU6K4 | I had to give it a try.

We had some interesting discussions with Camden last week, with Philippe Degoul and Félix Major about Veo 3, its accessibility, and how it’s revolutionizing the creative and marketing industries.

So I tried it myself, and I have to say: it’s wild how far generative models have come over the past two years. Even with 10 of us at Hadaly keeping an eye on the space, it’s hard to keep up, but incredibly exciting.

Go easy on me,  this was just a quick test I put together in under an hour, with no real video editing skills. Still, pretty cool!

I do wonder who first came up with the idea of generating full videos, even films from prompts.

It definitely inspired me, especially around a subject we’ve been diving into for the past three years: business valuation, company document protection & interpretation, and financial advising for small businesses.

Wouldn’t it be amazing if we had a tool like this to help us?

As entrepreneurs, grow and navigate our financial and administrative journeys or even benchmark ourselves against similar businesses?

Just some thoughts, no need to answer now. But yes, we’re working on it 🤫

#GenerativeAI
#Veo3
#BusinessValuation
#Fintech
#Entrepreneurship
#DataRoom | 46 | 4 | 2 | 5mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.646Z |  | 2025-06-25T16:08:39.468Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7341487460780044288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFA05KeFHVk_Q/feedshare-shrink_800/B4EZaDaoX0HYAg-/0/1745961520545?e=1766620800&v=beta&t=i2Fsdwc_8BSl4gaLH39Qu8XgqqxgC3eLmBvYA8YGR74 | This is a story about how we got a hint that Hadaly was onto something important.

Last November we rolled out a module that lets users generate a 17-page business-valuation report for free.

We were surprised by the requests that came in way faster than we could handle.

We had to hit pause, thinking it was pulling us off our main focus.

Then we realized users were ready to pay for it. That changed everything.
After validating the report’s quality with accounting firms and CBV valuation experts, we streamlined the process. The feature is now fully live on our platform.

if you would like to value your business and get an efficient report for about one-tenth of the usual cost plus our next-gen Data Room. It is possible.

Thinking about selling you company ? Our sell-side partner Martin DuTou⌚️ and his team can help.

Looking for a serious acquisition target? Classe Affaires Canada France can run your entire acquisition process.

You are a Broker wanting a 360° client experience, Hadaly can help enrich your services. | 50 | 0 | 0 | 5mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.648Z |  | 2025-06-19T15:30:08.891Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7318290832380289024 | Article |  |  | We had a good surprise last week, Hadaly has secured $1M in non-dilutive funding alongside My Forage System to develop a cool technology for our Data Room, targeting the structuring and performance needs of Quebec SMEs during business transfers.

The project, “Amélioration des systèmes experts pour la génération de recommandations stratégiques,” will enhance our engine and deliver a practical, next-generation solution to SMEs.

Curious about what we’re building ?
Or looking for a new generation Data Room software?

I'd love to talk about it: https://lnkd.in/gGHR-J8f

Source: https://lnkd.in/grByQHsy | 128 | 18 | 3 | 7mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.650Z |  | 2025-04-16T15:15:01.708Z | https://calendly.com/hadaly |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7316482672753590272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGcxmhh2f21Vw/feedshare-shrink_800/B4EZYcTyigGgAk-/0/1744231672738?e=1766620800&v=beta&t=KbAHgmYFl3FcyNGbz0tuR15IJLYvD0LSFTfTKyEc-I4 | We just hosted our first-ever public event, and it was quite the roller coaster !

Back in 2022, when we decided to launch Hadaly, we choose to bootstrapped it. Bootstrapping a first venture is incredibly rewarding, but it also pushes you to find truly innovative solutions which will become good story at the end of the day. ( Inspired by Matthieu Laulan )

For this event, we wanted to offer our current and future customers with the best experience. Meaning selected industry guests, artisanal gifts, and high-quality food and beverages.

So we came with our own solution !

For the guests, we personally invited each attendee. Over the course of a few months, I had 120 one-on-one meetings, building real relationships is very important for us.

To offer artisanal Gifts, we had the idea of giving out custom-engraved Hadaly glasses, so our team literally engraved 200 Glasses by hand (proof in photo ;) ).

Food & Drinks: We were extremely lucky to have premium sponsors like Columbus Café & Co Canada, Molson Coors Beverage Company, and Jeff de Bruges Canada, showcasing the incredible culinary excellence we have here in Montreal.

I had a great time organizing this successful event with the best Hadaly Team. We might organize new one, with this time more external helps and more gifts ;) | 102 | 2 | 1 | 7mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.651Z |  | 2025-04-11T15:30:02.859Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7306328326745260032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGy3_hZNll7yg/feedshare-shrink_800/B4EZWQipI4HMAg-/0/1741886755611?e=1766620800&v=beta&t=HjZHXp0Frkg9Dcd11hlzq_6zDFthUTtc8vHBOb1WXD8 | Are we destroying our entrepreneurial spirits with Business Plans and Data Rooms?

When we started Hadaly, terms like "Business Plan" and "Data Room" felt meaningless. We didn’t see the value ! at all...

Was it because, like many entrepreneurs, we were too arrogant to listen?

We had to learn the hard way:
🔹 3 pivots in 1 year
🔹 85 versions of our pitch deck
🔹 $80K spent just to realize we should have listened to experienced founders

Today, I see why startups need to build a Data Room:
✅ To structure their vision
✅ To communicate it clearly and reliably
✅ To measure the company’s health year over year

At Hadaly, we analyze 10+ new business #Datarooms every week as companies onboard. It’s been a fascinating learning experience. Showing us different strategies and structures.

And here’s the crazy part:

The number of documents in a data room correlates with a company’s value. More structure = more credibility = higher valuation. 

(graph is only for illustration purpose)

So, are business plans and data rooms limiting entrepreneurs ? | 48 | 1 | 0 | 8mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.652Z |  | 2025-03-14T15:00:18.112Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7298731951341854720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0Tjbn-6z6cw/feedshare-shrink_800/B4EZTNLQUiHcAg-/0/1738609068161?e=1766620800&v=beta&t=K6tEvylDZb8bzJNCfDt7XF_C8CYs9WXWn4mJ0Q8OXoI | #Startup life is wild ! it’s been my greatest teacher since I drop my #PhD at Polytechnique Montréal.

As a French founder in Canada, my biggest challenge is learning how to sell myself. Back home, “classes préparatoires” and engineering school taught me humility and technical rigor.

But not how to sell myself.

I really admire how founders here amplify every win, attracting success like a super magnet.

I have to admit, it has put enormous #pressure on me over the last three years, as it can sometimes feel like everyone else is building the next #unicorn. While you are still figuring out how to generate a small salary for each member of your team.

At the end of the day, I'm super grateful for this incredible journey with this amazing team.

Guirec Forges Joshua ATTIA Clément Boutier Patrick Iversenc Thomas Puibusque Lennin Sabogal Tinhinane Boudiab Gabriel Landry | 143 | 6 | 0 | 9mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.653Z |  | 2025-02-21T15:55:01.082Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7295870395616747520 | Article |  |  | I'm not great at communication. But people with the same name sure are 😁 

Last month Aimée Look, a journalist from The Logic, asked me about the impact of tariffs on #MnA deals in Canada. We look at our #data and here is what we’ve observed with Hadaly.

- In the short term, more #deals are on hold
Many entrepreneurs are waiting to see how Canada responds before making a move. Uncertainty is slowing deals down.

- Canada could lose investors
International buyers have long used Canada as a launchpad into the U.S. market. Now, some may bypass Canada entirely and head straight to the U.S.

- Canadian valuations may drop
If the Trump administration plan is to build a business-friendly ecosystem for U.S.-based SMEs, #valuation multiples for small Canadian businesses will take a hit.

You can read the full article here: https://lnkd.in/eA8CGa52

Thanks Classe Affaires Canada France for giving me more insights on this interview. | 38 | 2 | 3 | 9mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.655Z |  | 2025-02-13T18:24:13.032Z | https://thelogic.co/news/canada-mergers-acquisition-trump-threats/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7295109422371012610 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG3nY1F0w28FA/feedshare-shrink_800/B4EZTNFZ9uGwAg-/0/1738607534923?e=1766620800&v=beta&t=NuO0wxA9XtE21uZPihQ5BqNb7pCOp8GZh11LnUJv-JM | Welcome to the jungle! 🌎

A part of our team left Canada for #Brazil for two months… and we won’t do it again! 

Brazil is the largest #franchise market in the world, and since we help #entrepreneurs buy and sell companies (including franchises), it made perfect sense to explore the opportunity.

But there were two major challenges:
-  It’s a closed market for international companies
- Most of the population speaks only Portuguese

So, what did we do?
🔹 Did we speak Portuguese? No.
🔹 Had we ever been to South America? No.
🔹 Did we go anyway? Yes!

Sometimes, we might be a bit crazy ! maybe even delusional. But we did it.

Half our team spent two months in #Florianópolis, breaking into the market, learning #Portuguese, making incredible connections, and boosting our sales.

The experience was game-changing, and it has undoubtedly taken Hadaly to the next level.

🙏 Huge thanks to everyone who helped us prepare for this adventure and shared their contacts. Jean-Hamilton Philippe Ambre Dupuis Bruno Agard and Camélia Dadouchi, Ing., PhD. Loïc PARRENIN Giancarlo Marchesini Flávio Barbosa Gustavo Salvati and Maxime Leduc

And for those we couldn’t meet this time, we’ll be back in June for the ABF Franchising Expo, the world’s biggest franchise event! See you there! | 86 | 1 | 2 | 9mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.656Z |  | 2025-02-11T16:00:22.872Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7292655937738162177 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEEkBniL-wRqA/feedshare-shrink_800/B56ZTSiydZGQAg-/0/1738699123692?e=1766620800&v=beta&t=A94iD8MGSo51kgCA0wM0aZP-5QWlycrujJbUr048z_4 | Our boat just got an upgrade!

At Hadaly, we often talk about our project as a boat we’re building to travel the world. 

Let me explain: we started as four people, each swimming in a different direction, until we decided to pull some planks together, strap on a scrappy engine, and set sail. 

Day by day, our boat got stronger, faster, and more beautiful…

Today, we’re adding a fresh coat of paint by being selected for IVADO’s #DémultiplIA 2025 program! We’ll be working with top researchers, entrepreneurs-in-residence, and a network of #AI experts to push our #vision even further. | 49 | 1 | 1 | 10mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.658Z |  | 2025-02-04T21:31:06.552Z | https://www.linkedin.com/feed/update/urn:li:activity:7292636031655329793/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7284654652199952386 | Article |  |  | On parle d'Hadaly dans la presse !

Je suis très fier de grandir avec une équipe aussi motivée pour aider à moderniser le transfert d'entreprises. Let's go Hadaly Team !

C'est très gratifiant de voir que toutes ces heures de travail portent leurs fruits.

https://lnkd.in/eC-YrUus

Si vous souhaitez en savoir plus sur Hadaly, n'hésitez pas à nous contacter !

Tinhinane Boudiab Lennin Sabogal Gabriel Landry Clément Boutier Patrick Iversenc Joshua ATTIA Thomas Puibusque Guirec Forges | 81 | 1 | 4 | 10mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.659Z |  | 2025-01-13T19:36:51.423Z | https://lexpress-franchise.com/fr-ca/articles/le-repreneuriat-sous-la-loupe-de-lia/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7272988601573871616 | Article |  |  | Quelle surprise en me levant ce matin :)

Un immense merci à Jean-Sébastien Côté M. Sc. CRHA, PROSCI® de Transfert 360 et à Martin DuTou⌚️ pour nous avoir mentionnés dans leur podcast dédié à l'évaluation d'entreprise. 

C'est pour des petites surprises comme celle-ci que je me suis lancé dans l'entrepeneuriat avec Hadaly !




🎙️ https://lnkd.in/gquk5zXz | 45 | 5 | 0 | 11mo | Post | Aime Toumelin | https://www.linkedin.com/in/aime-toumelin-769a40149 | https://linkedin.com/in/aime-toumelin-769a40149 | 2025-12-08T06:05:12.660Z |  | 2024-12-12T15:00:08.209Z | https://transfert360.com/evaluation-entreprise/ |  | 

---



---

# Aime Toumelin
*Hadaly*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [](https://hadaly.ca/about-us/)
- Category: article

### [Hadaly | The Org](https://theorg.com/org/hadaly)
*2025-01-01*
- Category: article

### [Hadaly | LinkedIn](https://ca.linkedin.com/company/hadaly)
*2025-05-12*
- Category: article

### [hadaly | F6S](https://www.f6s.com/company/hadaly)
*2023-06-08*
- Category: article

### [Entrepreneuriat social - ONG AIME](https://aime-ong.org/en/theme/entrepreneuriat-social-en/)
*2025-03-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Ventures - Next Canada](https://www.nextcanada.com/directory/ventures/)**
  - Source: nextcanada.com
  - *https://hadaly.ca/. Cohort: Next AI - Montreal, 2023. Founders: Joshua Attia. Aime Toumelin. CoverQuick. Coverquick is your AI job search buddy, creat...*

- **[Stratégie IA : l'écosystème mobilisé pour la feuille de route ...](https://vitrine.ia.quebec/strategie-ia-lecosysteme-mobilise-pour-la-feuille-de-route-quebecoise-c82102b8-a12d-47ef-812d-359df6c80eae)**
  - Source: vitrine.ia.quebec
  - *Nov 10, 2025 ... Aime Toumelin (Hadaly). Alain Beauséjour (Groupe MISA). Alain Lavoie ... Une entreprise en IA Une étude de cas Un article. Informatio...*

---

*Generated by Founder Scraper*
