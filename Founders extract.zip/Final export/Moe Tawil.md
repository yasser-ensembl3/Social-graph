# Moe Tawil

## Position actuelle

**Titre** : Founder
**Entreprise** : MOEtreal
**Durée dans le rôle** : 12 years 5 months in role
**Durée dans l'entreprise** : 12 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

Moetreal Is a company located in Montreal, we specialize in event management, digital marketing, media and production. We are the leader in covering high-end social and corporate events. Our team is highly present at the most vibrant and coveted events in Ontario & Quebec. Additionally, our social networks have more than 90,000 followers, and we have more than 750,000 unique visits per year to our website.
Our team will produce media that will attract prospects, help supercharge your presentations with award winning, targeted and entertaining brand messaging. Some of our clients include: Ogilvy Holt Renfrew, the Ritz Carlton Montreal, HydraFacial, Cisco Canada, Harry Rosen and the Fairmont Queen Elizabeth. In addition we have also serviced the Formula1 Grand Prix of Canada, Bijouterie Italienne, Stone Tile International, National Bank of Canada, Cominar, Salon de L’auto de Montreal, Sotheby’s Canada, Mercedes-Benz Rive-Sud, charity balls, galas and many more high-end events.

Our Services 
Productions
- Corporate videos
- Photography
- Professional tributes
- Events media coverage: lifestyle & corporate
- Content creation for social media platforms and websites
- Private events: weddings, anniversaries, bridal showers & more

Real Estate
We are the leader in covering and launching new condominium and town house developments. We work side by side with developers and real estate agencies to create event themes, host promotional events to promote the projects and reach our main goals: awareness & sales.

Event Management
- Theme Creation
- Sound & Lights
- DJ & Entertainment - VIP Guests
- Hosting & Modeling

## Résumé

MOEtreal: Your Ultimate Event, Marketing, and Media Partner

Based in Montreal, MOEtreal is a premier destination for event management, digital marketing, and media production. We specialize in high-end social and corporate events, delivering unforgettable experiences for clients in Ontario and Quebec. 

With over 100,000 social media followers and over 2000000 annual unique website visits, we offer a strong online presence. Our media production aims to elevate your brand image through engaging content, while our events are known for their unique settings and seamless execution. 

Our Services Include:
- Video & Photo production
- Corporate videos production 
- Professional photography
- Events Media coverage
- Content creation for social media and websites design
- Events management and planning

We specialize in coordinating charity balls, galas, corporate functions, weddings, and anniversaries, with a focus on real estate groups especially when it comes to condominium launches. 

Real Estate Launches:
For real estate developers, we offer comprehensive strategies for launching condominium and townhouse projects. From thematic events to promotional activities, our goal is to drive awareness and sales. We also provide corporate photo shoots tailored for brokers.

Partner with MOEtreal for an exceptional experience that leaves a lasting impression.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAkIcWYBrWfdS6_Lc0b-5cazo3rWiqQb_OU/
**Connexions partagées** : 179


---

# Moe Tawil

## Position actuelle

**Entreprise** : MOEtreal

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Moe Tawil

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402386011357421568 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVvpnkf2JlaQ/feedshare-shrink_800/B4EZrqO2J6KkAg-/0/1764866352083?e=1766620800&v=beta&t=tr6_xIr5FNYRmYODujZWmvZ-LTBYo09_y4RRW4dZwMA | An inspiring evening at the Cedars Gala @cedarscancer , celebrating 60 years of milestones in cancer care and the incredible people who make it possible. 💙✨ Full photos album available now on moetreal.com MOEtreal #moetreal #cedarscancer

Fondation du cancer des Cèdres / Cedars Cancer Foundation Andrew Lutfy Zahi Abou Chacra Nadim Rizk Sahar Abi-Ziki Joanne Pizzino Mario Rigante, MBA, C.P.A. Senator Tony Loffreda Amy Assaad Majd Jabali | 82 | 2 | 1 | 3d | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:46.640Z |  | 2025-12-04T16:39:14.789Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396227370443128832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH6J_nfoPolBw/feedshare-shrink_800/B4EZqStmKhKgAk-/0/1763398018491?e=1766620800&v=beta&t=cc9bxY5QASTZTjvwcQUJPgOkxOxW1wPjSDZ5SGJmoBs | Sweet Vibes at the Sugar Ball 2025!  The 13th edition at St-James Theatre brought elegance, music, and gourmet delights together in the heart of Old Montreal. Truly unforgettable! Stay tuned for the event pictures and official video coming soon on moetreal.com @moetreal.ca #moetreal @bal_sucre @museemccordstewart

McCord Stewart Museum Anthony A. Nader Genatec Alex Shteinberg Genesis Saint-Laurent Karim HALABY Imad Nabwani | 42 | 0 | 3 | 2w | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:46.640Z |  | 2025-11-17T16:47:00.373Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393635725285478403 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnghkjgqLZWA/feedshare-shrink_800/B4EZpt4fW7KoAg-/0/1762780121670?e=1766620800&v=beta&t=_gCY1XTF8jStt3FCcF2EQSygHkX3mmLMtPt0vyBhwYE | Grateful to share inspiring moments with incredible people at Pink in the City The Magic of Hope 2025 @pinkinthecitycanada #moetreal MOEtreal MUHC Foundation 

Full photos album available now available https://lnkd.in/eKexmZ7F

Genesis Genesis Saint-Laurent | 20 | 0 | 1 | 3w | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:46.641Z |  | 2025-11-10T13:08:44.017Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7388582999115706368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEbJo6_Qc08Vg/feedshare-shrink_800/B4EZomE9Y.KYAg-/0/1761575459495?e=1766620800&v=beta&t=dOeQi-G1iaYFKMHYotZN0jGyOeO6TMOeV5Ks77Xg5ac | An evening painted in pink 💗 with the incredible @pinkinthecitycanada , celebrating strength, courage & hope. Together, we stand with survivors, honor the angels, and support the inspiring work of the @muhcfoundation 💕 Full Photos album and video in collaboration with @patisseriemahrouse will be available soon on moetreal.com @moetreal.ca #moetreal

Fondation CUSM - MUHC Foundation

Denise Vourtzoumis | 53 | 5 | 1 | 1mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:46.641Z |  | 2025-10-27T14:31:00.223Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7386882388506869761 | Article |  |  | On Friday, October 17th, we were in Ottawa to celebrate the official groundbreaking of Eden, an inspiring new multi-residential project by SINA and Remcorp, located on March Road in the vibrant Kanata neighbourhood.

This milestone event marked the beginning of a remarkable development: two six-storey buildings comprising 196 units that beautifully blend modern living with the tranquility of nature. From its thoughtfully designed apartments to its impressive range of amenities—including an indoor pool, state-of-the-art fitness centre, coworking and conference spaces, and an elegant resident lounge—Eden is designed to offer a truly elevated residential experience.


SINA Remcorp Inc.Mohamed El-Koury Mahmoud El-Koury Charles Lemire, Ingénieur Tony Fionda, CPA, CA, MBA Tony Fionda, CPA, CA, MBA | 9 | 0 | 0 | 1mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:46.642Z |  | 2025-10-22T21:53:23.058Z | https://www.moetreal.com/photos-breaking-ground-on-eden-a-new-standard-in-modern-living-in-kanata/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379101098625748994 | Article |  |  | Le jeudi 18 septembre dernier, nous avons eu le plaisir de célébrer l’inauguration officielle du Jacob Laval, le nouveau projet résidentiel locatif situé sur le boulevard Saint-Elzéar Ouest, à Laval. Cité Urbaine | 3 | 0 | 0 | 2mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.482Z |  | 2025-10-01T10:33:18.981Z | https://www.moetreal.com/video-linauguration-officielle-du-jacob-laval/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7376030641185845248 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3x4fv-M2g3w/feedshare-shrink_800/B4EZlzsyCNIMAg-/0/1758582743795?e=1766620800&v=beta&t=dmYVbnFaXVsKLxe8JqFCk-0CPaMnIFJVaAQgU6grxCc | Last Thursday, we celebrated the grand opening of Jacob Laval ✨ A 17-storey residential project where comfort meets elegance, presented by Cité Urbaine. 🏙️ #JacobLaval #CitéUrbaine

Cité Urbaine | 19 | 1 | 0 | 2mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.483Z |  | 2025-09-22T23:12:24.881Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7369400992045486081 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZE1wcon-QBQ/feedshare-shrink_800/B4EZkVfGbnIwAg-/0/1757002105692?e=1766620800&v=beta&t=DedS0BQ3vWxYPFkRwXiOAvJHNzcn9uVYAR19_iry6nE | Le Jeudi 28 août dernier, nous avons vibré au rythme de l’innovation, de l’excellence et de la vision architecturale lors de la 7ᵉ édition de la Soirée des Grands Bâtisseurs, un événement d’exception présenté par INNO Magazine. À l’imposant Espace Paddock du Parc Jean-Drapeau, ce lieu aussi grandiose que les talents qu’il a mis à l’honneur, nous a plongés dans un voyage captivant au cœur des projets qui façonneront notre avenir urbain.

Album photos complet disponible MOEtreal https://lnkd.in/eAEZdsXd

Les Grands Bâtisseurs France Goyet Franciska Brien-Tourigny Luc Quenneville Jean-Paul Mouradian Claude Marcotte Tania Ravary Simon Drouin John Marcovecchio Magil Construction Ray Junior Courtemanche Genesis Roger III Desautels Genesis Saint-Laurent | 62 | 0 | 2 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.483Z |  | 2025-09-04T16:08:33.353Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7368749853071396864 | Article |  |  | Le Jeudi 28 août dernier, nous avons vibré au rythme de l’innovation, de l’excellence et de la vision architecturale lors de la 7ᵉ édition de la Soirée des Grands Bâtisseurs, un événement d’exception présenté par INNO Magazine. À l’imposant Espace Paddock du Parc Jean-Drapeau, ce lieu aussi grandiose que les talents qu’il a mis à l’honneur, nous a plongés dans un voyage captivant au cœur des projets qui façonneront notre avenir urbain.

Lien photos complet : https://lnkd.in/eAEZdsXd

Les Grands Bâtisseurs France Goyet Jean-Paul Mouradian Claude Marcotte Luc Quenneville | 8 | 0 | 0 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.484Z |  | 2025-09-02T21:01:09.724Z | https://www.moetreal.com/photos-les-grands-batisseurs-2025-une-7%E1%B5%89-edition-memorable/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7368616502398328832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGj883ZZaaLoA/feedshare-shrink_800/B4EZkKVpneGcAo-/0/1756815073840?e=1766620800&v=beta&t=pb85lbLy1L9f9mOb2_b96I6INL-N6ZglSJkf_eocM3w | Video complet 💥 clickez sur ce lien https://lnkd.in/eGvejpfc

Le mercredi 20 août 2025, l’Auberge du Lac des Sables à Sainte-Agathe-des-Monts a accueilli l’Apéro FINSTAR, une soirée conviviale et exclusive inspirée par les couleurs du soleil.

Groupe Finstar Simon Drouin Tania Ravary Genesis Genesis Saint-Laurent Roger III Desautels | 15 | 0 | 2 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.484Z |  | 2025-09-02T12:11:16.446Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7365703397095686144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETpVFK8gIVmA/feedshare-shrink_800/B4EZjg8M4gGcAk-/0/1756120535351?e=1766620800&v=beta&t=n5M3x3dMWJnC4kROBD6iwg-pvnAKu3WEBtongsjdPjg | It was a true pleasure for myself & the passionate team at MOEtreal to be part of the Apéro FINSTAR  at the charming @aubergedulacdessables 

Album photos complet https://lnkd.in/eEK2_yFG

Congratulations to Tania & Simon for such a wonderful event and for redefining Saint-Agathe through the vision and success of FINSTAR! #groupefinstar #moetreal

Tania Ravary Simon Drouin | 4 | 0 | 0 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.485Z |  | 2025-08-25T11:15:38.019Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7364774333275086849 | Article |  |  | Le mercredi 20 août 2025, l’Auberge du Lac des Sables à Sainte-Agathe-des-Monts a accueilli l’Apéro FINSTAR, une soirée conviviale et exclusive inspirée par les couleurs du soleil.

Album photos complet https://lnkd.in/eEK2_yFG

Simon Drouin Tania Ravary Auberge du Lac des Sables Groupe Finstar | 10 | 0 | 3 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.485Z |  | 2025-08-22T21:43:51.943Z | https://www.moetreal.com/photos-lapero-finstar-eclat-dore/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7363010594993500160 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b9e4750f-2580-420a-a504-a53a5ca31a00 | https://media.licdn.com/dms/image/v2/D4E05AQEfXwObXiWKEA/videocover-high/B4EZi6rGZJGoCI-/0/1755478519061?e=1765782000&v=beta&t=ThUawbdmWMTu63vtEuK8oBZNEJIsLr0rYaDN_LsGwDo | We at MOEtreal have been part of this journey since the very first Aera Condos Locatifs launch in Saint-Constant, followed by Saint-Hilaire, Chambly, and now Trois-Rivières in Québec Canada. It’s incredible to see the remarkable growth of this project,  and the excitement continues. Can you guess the next location? #aeracondoslocatifs #moetreal | 18 | 0 | 0 | 3mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.486Z |  | 2025-08-18T00:55:23.968Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7352317616423596032 | Article |  |  | Le 10 juillet dernier, nous avons eu le privilège de nous réunir au prestigieux Club de golf Le Mirage à l’occasion de la 37e édition du tournoi annuel de golf Alepín & Amis, marquant également les 47 ans du cabinet. Alepin Gauthier Avocats 

Sous la thématique « Juste pour le fun », cette journée fut un événement incontournable, alliant affaires, sport et plaisir dans une ambiance conviviale et chaleureuse.

Album photos complet https://lnkd.in/ezyBPwww

Chanel Alepin Maxime Alepin Brigitte Gauthier | 12 | 0 | 0 | 4mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.486Z |  | 2025-07-19T12:45:19.211Z | https://www.moetreal.com/photos-la-37e-edition-du-tournoi-annuel-de-golf-alepin-amis/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7350167323053367296 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFP_YZ6vEJYTA/feedshare-shrink_800/B4EZgEKOzIHoAg-/0/1752416448283?e=1766620800&v=beta&t=HDZGsDNRdZ5pxocm3ekWT_tWRH-cNtSvCdyx6vsYeD8 | Rest the body, clear the mind, feel the moment. Sunday vibes. | 21 | 2 | 0 | 4mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.487Z |  | 2025-07-13T14:20:49.321Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7347362931640086529 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFy8fb6lTuavw/feedshare-shrink_1280/B4EZfcTpm5HYAk-/0/1751747828725?e=1766620800&v=beta&t=rSUs7zEogumi__k5J5k_oLZ9kh4VX0-9UyIVXJWOOYk | Official opening of Boss at Royalmount 

HUGO BOSS | 21 | 1 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.487Z |  | 2025-07-05T20:37:10.305Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7345425378699620352 | Article |  |  | Le 30 mai 2025, sous les lustres éclatants de La Nesra, lieu emblématique de Montréal, s’est tenu le très attendu Le Bal Rouge 2025, un gala d’exception au bénéfice de la Fondation du Centre universitaire de santé McGill (CUSM). Cette soirée prestigieuse, empreinte de générosité et d’émotion, a permis d’amasser la somme remarquable de 2 106 445 $, un nouveau jalon dans l’histoirephilanthropique de l’événement.

MUHC Foundation Desjardins Guy Cormier Stephanie Vaillancourt Anie Rouleau Marie-Helene Laramee, Eng. Lucie Opatrny Maria Della Posta Liane S Feldman Mary Arvanitis | 15 | 1 | 1 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.488Z |  | 2025-06-30T12:18:01.686Z | https://www.moetreal.com/video-le-bal-rouge-de-la-fondation-du-cusm/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7341856543023284224 | Article |  |  | Le mardi 6 mai 2025, dans le cadre prestigieux de l’hôtel Sheraton Laval, près de 400 invités se sont réunis pour célébrer une cause noble lors du Gala annuel de la Fondation Ronald-Denis. Ce rendez-vous incontournable du calendrier philanthropique québécois a rassemblé des figures majeures du milieu médical, des partenaires engagés et des philanthropes dévoués autour d’un objectif commun : faire avancer l’accès aux soins chirurgicaux spécialisés au Québec.

La Fondation Ronald Denis Carmine D'Argenio Sheraton Laval et Centre de congrès | 12 | 1 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.488Z |  | 2025-06-20T15:56:44.955Z | https://www.moetreal.com/video-une-soiree-dengagement-et-dexcellence-le-gala-annuel-de-la-fondation-ronald-denis/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7341483949937852416 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEyaBDxrnOvPg/feedshare-shrink_800/B4DZeIwv7.HAAg-/0/1750346170707?e=1766620800&v=beta&t=jwF0EEaG399M9l0lDiPjF-Io9XJ8TWfd1NRwKg4PUz4 | I’ve always believed that being in the heart of the crowd is where the real magic happens. Working in media and events wth MOEtreal isn’t just my job, it’s my passion. I love creating moments, uplifting people, and making sure others shine. When you truly care, when you pour your heart into helping others grow, something beautiful happens: you grow too. Love what you do, do it with purpose, and the rest will follow 🫶🏼 #moetreal | 37 | 2 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.488Z |  | 2025-06-19T15:16:11.841Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7340345961296064513 | Article |  |  | Video: La troisième édition de La Soirée des Grands, au profit de la Fondation des jeunes de la DPJ

Fondation des jeunes de la DPJ | 6 | 1 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.489Z |  | 2025-06-16T11:54:14.206Z | https://www.moetreal.com/video-la-troisieme-edition-de-la-soiree-des-grands-au-profit-de-la-fondation-des-jeunes-de-la-dpj/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7340345588330225664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG7tNDV8k2h9A/feedshare-shrink_800/B4EZd4lalWHIAg-/0/1750074764457?e=1766620800&v=beta&t=nTEqPpHGSM3g8y2HSRVIfWQ1KUahDYQsNYqK0vyQhTA | Ritz Royale F1 Grand Prix Party #ritzgpmtl Ritz-Carlton Montreal | 24 | 1 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.489Z |  | 2025-06-16T11:52:45.284Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7338903446839803904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHW--f6b9IJ_w/feedshare-shrink_800/B4EZdkFyyKG4Ak-/0/1749730930678?e=1766620800&v=beta&t=69OxvYFnn7gXlroixFLwCI4WzjhsiDxNNUguJKMvxqQ | MONtREAL IS ALIVE 🤩

Grand Prix weekend is more than just racing🏎️, it’s a showcase of our city’s spirit, style, and hospitality.

To all the restaurants, hotels, creatives, hosts, and hustlers: This is your moment. Let’s make Montreal proud 💪🏼

Wishing everyone a weekend full of great energy, unforgettable connections, and that signature Montreal magic 🇨🇦✨

Let’s show the world how we do it. #moetreal

#montreal #f1 #f1weekend #canadiangrandprix | 36 | 0 | 0 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.490Z |  | 2025-06-12T12:22:11.959Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7338529837503901696 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGERl4MMEEmXQ/feedshare-shrink_800/B4EZdex.9pHcAo-/0/1749641853023?e=1766620800&v=beta&t=2_KZRk4-ai-dWbLAeQHLBeBWNgIaZBfK3FAVMFhwcLY | On June 7, we had the great pleasure of gathering for the 9th edition of the Santa Cabrini Foundation’s Annual Gala, held in the prestigious setting of the Sheraton Laval.

Presided over by Mr. Giuseppe Racanelli, a respected businessman and dedicated philanthropist, the gala brought together community leaders in support of a noble cause: advancing the mission of Santa Cabrini Hospital.

Full photos album available : https://lnkd.in/ekcAW8g9 | 62 | 1 | 1 | 5mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.491Z |  | 2025-06-11T11:37:36.552Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7336405145166995459 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHDUHHohR9apw/feedshare-shrink_800/B4EZdAlmK7HsAk-/0/1749135288292?e=1766620800&v=beta&t=GzpKgyw8J0Ox8q7J8KCoADgWY_gebqtcNlQOsBCHJ7I | On May 30, 2025, under the dazzling chandeliers of La Nesra—the highly anticipated Bal Rouge 2025 brought together elegance, heart, and purpose. This unforgettable gala, in support of the McGill University Health Centre (MUHC) Foundation, raised an outstanding $2,106,445, marking a new milestone in the event’s philanthropic legacy.

Swipe through for some highlights—and visit moetreal.com @moetreal.ca to view the full photo album from this spectacular evening.
Link : https://lnkd.in/epqmmWy8

#BalRouge2025 #moetreal #MontrealEvents #Philanthropy #MUHC #GalaSeason

MUHC Foundation The Friends of the MUHC Guy Cormier Kheng Ly Monsef DERRAJI, MBA, Ph.D , ASC – C.Dir. The Unscented Company Anie Rouleau Genesis Canada Genesis Saint-Laurent Mario Totaro | 31 | 2 | 0 | 6mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.492Z |  | 2025-06-05T14:54:50.424Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7335285417505689601 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWsU0HVpgA9Q/feedshare-shrink_800/B4EZcwrLMwHQAo-/0/1748868323724?e=1766620800&v=beta&t=Z5keVjNEZ_ypuqmMG314aRwLRmXbuRb5mLy1jVT8EBk | Photos album : https://lnkd.in/eJ8d6_MC

On May 22, the elegant Hiatus @hiatusmontreal restaurant in the heart of Montreal set the stage for AURA @aura_evenement , a graceful and generous event in support of the CHUM Foundation @fondationduchum . Imagined by Dr. Sami Obaid @sami.obaid10 and supported by Bastium Construction @bastium_construction , the night brought together fine dining, social impact, and contemporary elegance in perfect harmony.

It was a pleasure to host and cover this inspiring evening with the passionate team at @moetreal.ca #moetreal 

The full photo album is now live on moetreal.com — and stay tuned for the video featuring exclusive interviews.

Bastium Construction Franciska Brien-Tourigny Fondation du Centre hospitalier de l'Université de Montréal (CHUM) | 43 | 4 | 0 | 6mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.492Z |  | 2025-06-02T12:45:26.546Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7325603952329203713 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGmhqa1QWBPxw/feedshare-shrink_800/B4EZanF.BzHIAo-/0/1746560083391?e=1766620800&v=beta&t=THwJGfyMOzE-X3uK3hUIKLVuW3R0If1dxTvha9r8d-s | On Thursday, May 1st, 2025, elegance, culture, and generosity came together at Théâtre Cartier for an unforgettable evening. The McCord Stewart Museum Grand Ball, themed Allegory, offered a one-of-a-kind sensory journey blending art, history, and imagination.

Photos album available on https://lnkd.in/exHQ24SA

McCord Stewart Museum Aref Salem Mario Rigante, MBA, C.P.A. Genesis Canada Genesis Saint-Laurent Mario Totaro Roger III Desautels | 20 | 2 | 1 | 7mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.493Z |  | 2025-05-06T19:34:45.375Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7323684531251671040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHjk2RCWUReHQ/feedshare-shrink_800/B4EZaL0NdYGQAg-/0/1746102457628?e=1766620800&v=beta&t=fKRSlLrQQ6hHQMYdmTdi_miP-y9nyI-qmBAo7iDtfXk | EQCO 2025 – A Foundational Gathering for Québec’s Construction Industry

On Thursday, April 24th, the prestigious Plaza Rive-Sud in La Prairie hosted the very first edition of EQCO — a landmark event bringing together key figures from Québec’s construction industry. Presented by Groupe Boda, this innovative initiative is fully aligned with the mission of Évolution du Québec en Construction (EQCO): to unite industry leaders each year and drive progress within the sector.

EQCO Guido Caso Jean-Paul Mouradian Kheng Ly Doreen Assaad 

Full photos album available on MOEtreal .com

https://lnkd.in/eZg4NxUB | 21 | 0 | 0 | 7mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.494Z |  | 2025-05-01T12:27:39.729Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7323428764988682240 | Article |  |  | EQCO 2025 – Une rencontre fondatrice pour l’industrie de la construction québécoise

Album photos ➡️ https://lnkd.in/eZg4NxUB

Le jeudi 24 avril dernier, le prestigieux Plaza Rive-Sud de La Prairie accueillait la toute première édition d’EQCO — un événement phare rassemblant les figures clés du secteur de la construction au Québec. Présentée par le Groupe Boda, cette initiative innovante s’inscrit pleinement dans la mission de l’Évolution du Québec en Construction (EQCO) : réunir chaque année les leaders de l’industrie afin de stimuler l’avancement du secteur.

EQCO 2025 – A Foundational Gathering for Québec’s Construction Industry

On Thursday, April 24th, the prestigious Plaza Rive-Sud in La Prairie hosted the very first edition of EQCO — a landmark event bringing together key figures from Québec’s construction industry. Presented by Groupe Boda, this innovative initiative is fully aligned with the mission of Évolution du Québec en Construction (EQCO): to unite industry leaders each year and drive progress within the sector.

France Goyet Jean-Paul Mouradian Tania Mouradian Kheng Ly Guido Caso Hugo Girard Kim Bruneau Adam Reid Hellen Christodoulou, ing, BCL., LLB, MBA Sylvain-Pierre Crête Laurent Messier, CPA, CA, CBV Claude Marcotte Majd Jabali Lamborghini Montréal Lognet Enviro-Experts Mobilia SOPREMA Canada JACKIE BOULAY Module Doreen Assaad | 8 | 1 | 0 | 7mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.495Z |  | 2025-04-30T19:31:20.300Z | https://www.moetreal.com/photos-eqco-2025-a-groundbreaking-gathering-for-quebecs-construction-industry/ |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7319043494239526912 | Article |  |  | Jeudi le 10 avril dernier, au cœur du New City Gas, s’est tenue la 4e édition du Cocktail de la Fondation Lise Watier, un événement phare dédié à l’indépendance financière des femmes d’ici.

Lise Watier Foundation | 14 | 1 | 0 | 7mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.495Z |  | 2025-04-18T17:05:50.279Z | https://www.moetreal.com/video-la-4e-edition-du-cocktail-de-la-fondation-lise-watier/ |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7317918090141327361 | Article |  |  | Vendredi 28 mars, nous nous sommes réunis au Studio Événementiel La Nesra pour célébrer le Grand Bal de Sainte-Justine, un événement qui symbolise l’espoir et la détermination de transformer la médecine pédiatrique pour les générations futures.
Le CHU Sainte-Justine, pionnier en alliant science, technologie et humanité, offre des soins adaptés à chaque enfant. La campagne Voir Grand de la Fondation, visant 500 M$, ambitionne de révolutionner les traitements, prévenir les maladies et bâtir un avenir où l’impossible disparaît.
Sous la présidence d’honneur de Laurent Ferreira (Banque Nationale du Canada), donateurs, partenaires et alliés se sont rassemblés pour offrir aux enfants le droit à un futur en santé grâce à des innovations thérapeutiques.

Rejoignez-nous pour revivre cette soirée magique, véritable célébration de la vie et des connexions inspirantes, et contribuez à un avenir porteur d’espoir pour toutes les familles du Québec.

On Friday, March 28, we gathered at Studio Événementiel La Nesra to celebrate the Grand Bal de Sainte-Justine—an event that symbolizes hope and the determination to transform pediatric medicine for future generations.
CHU Sainte-Justine, a pioneer in blending science, technology, and compassion, provides tailored care for each child. The Fondation’s Voir Grand campaign, with a historic $500M goal, aims to revolutionize treatments, prevent illnesses, and build a future where nothing is impossible.
Under the honorary presidency of Laurent Ferreira (Banque Nationale du Canada), donors, partners, and allies united to give children the right to a healthy future through innovative therapies.

Join us to relive this magical night—a unique celebration of life, inspiring connections, and a hopeful future for all Quebec families.


Laurent Ferreira National Bank of Canada CHU Sainte-Justine Delphine Brodeur, MBA, ASC Eric Bujold Sandra Ferreira | 8 | 0 | 1 | 7mo | Post | Moe Tawil | https://www.linkedin.com/in/moe-tawil-65a90542 | https://linkedin.com/in/moe-tawil-65a90542 | 2025-12-08T06:16:52.496Z |  | 2025-04-15T14:33:53.033Z | https://www.moetreal.com/video-le-grand-bal-de-sainte-justine/ |  | 

---



---

# Moe Tawil
*MOEtreal*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [The Mo Show Podcast](https://www.themopodcast.com/)
*2025-03-14*
- Category: podcast

### [Dr Moe CEO Masterclass 7-25-24](https://vimeo.com/990766294)
*2025-04-03*
- Category: article

### [About The Mo Show — The Mo Show Podcast](https://www.themopodcast.com/about-the-mo-show)
*2022-01-01*
- Category: podcast

### [The Mo Show](https://podcasts.apple.com/sn/podcast/the-mo-show/id1529888455)
*2025-11-06*
- Category: podcast

### [Transformational Retreats / Psychedelics what works and what doesn't With Moe Srour | Ep 1 by Let’s Be Real with Motty Kenigsberg](https://creators.spotify.com/pod/profile/letsbereal-podcast/episodes/Transformational-Retreats--Psychedelics-what-works-and-what-doesnt-With-Moe-Srour--Ep-1-e1s7qkp)
*2025-04-26*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Photos: HARRY ROSEN MONTREAL - Moetreal.com](https://www.moetreal.com/photos-harry-rosen-montreal-the-brand-new-redesigned-flagship-store/)**
  - Source: moetreal.com
  - *May 19, 2016 ... tgallant@harryrosen.com. ###. For more information, images or to arrange an interview ... Moe Tawil. ABOUT US. Moetreal is an events ...*

- **[Social Notes: Season closes with bubbles for Accueil Bonneau ...](https://montrealgazette.com/life/social-notes-season-closes-with-bubbles-for-accueil-bonneau)**
  - Source: montrealgazette.com
  - *Dec 14, 2017 ... Thomahawk CEO Thomas H., Veuve Clicquot PR pro Marie Gonneville, Les Querelles' Jessika Dufour, MOEtreal's Moe Tawil and Smile Events...*

- **[Video: Revitalize 2018 Montreal's Women's Wellness Event ...](https://www.moetreal.com/video-revitalize-2018-montreals-womens-wellness-event/)**
  - Source: moetreal.com
  - *Jan 31, 2018 ... Revitalize 2018 is a trade show and conference ... Nadia's fabulous fiftieth! Moe Tawil. ABOUT US. Moetreal is an events company dedi...*

- **[Rajashree Choudhury - Moetreal.com](https://www.moetreal.com/rajashree-choudhury-senior-yoga-teacher-first-time-montreal/)**
  - Source: moetreal.com
  - *Oct 24, 2014 ... Moe Tawil. RELATED ARTICLES. Workshop by Brian Miller. February 9, 2015. ABOUT US. Moetreal is an events company dedicated to promoti...*

- **[Photos: The Ritz-Carlton Montreal Grand Prix Party 2017 » Moetreal ...](https://www.moetreal.com/photos-ritz-carlton-montreal-grand-prix-party-2017/)**
  - Source: moetreal.com
  - *Jun 13, 2017 ... Next articlePhotos: GRAND PRIX PARTY AT LE RICHMOND ! Moe Tawil ... Moetreal is an events company dedicated to promoting Montreal's v...*

- **[Relais & Chateaux | Luxury hotel Canada - StoneHaven Le Manoir](https://www.stonehavenlemanoir.com/en/)**
  - Source: stonehavenlemanoir.com
  - *When elegance, nobility & history come together in a place that fairly breathes mystery, only excellence can result. Moe Tawil, MOEtreal. If I could ....*

- **[Photos: The Official Launch of Nour Private Wealth's Quebec Head ...](https://www.moetreal.com/photos-the-official-opening-of-nour-private-wealths-quebec-head-office-in-montreal/)**
  - Source: moetreal.com
  - *Oct 16, 2019 ... Moe Tawil. RELATED ARTICLES. Photos: Ritz Holiday High Tea: A Celebration for More Than a ... © Moetreal Inc 2018 | All Rights Reserv...*

- **[StoneHaven Le Manoir | Relais & Châteaux dans les Laurentides](https://stonehavenlemanoir.com/)**
  - Source: stonehavenlemanoir.com
  - *Lorsque l'élégance, la noblesse et l'histoire se rencontrent dans un lieu qui respire le mystère, seul l'excellence peut en résulter. Moe Tawil, MOEtr...*

- **[Video: Vegas Baby! ....Nadia's fabulous fiftieth! » Moetreal.com](http://www.moetreal.com/video-vegas-baby-nadias-fabulous-fiftieth/)**
  - Source: moetreal.com
  - *Mar 29, 2018 ... Moe Tawil. RELATED ARTICLES. Video: Nadia Saputo's Birthday Bonanza ... Moetreal is an events company dedicated to promoting Montreal...*

---

*Generated by Founder Scraper*
