# BGospel Magazine

## Position actuelle

**Titre** : Founder and Manager
**Entreprise** : Jubau GROUP
**Durée dans le rôle** : 16 years 7 months in role
**Durée dans l'entreprise** : 16 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Résumé

BGospel Magazine:   Nous sommes un magazine évangélique en ligne. Nous faisons la promotion de l’évangile par la Musique - Actualités - Promotion - Spiritualité. [MAPS]

+ publication de musiques
+ Top 10 hebdomadaire 
+ BGMag 2023 Top des Tops
+ Évaluation musicale
+ biographie 
+ entrevue 
+ Spiritualité 
+ Sondages / Enquêtes
+ Quiz biblique et personnalité 
+ Promotion sur les réseaux sociaux
+ actualités

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAVGdmoBbqfzY95GEYGZZ2GvxQ4FxVJNIvg/


---

# BGospel Magazine

## Position actuelle

**Entreprise** : Jubau GROUP

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# BGospel Magazine
*Jubau GROUP*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 31 |

---

## 📚 Articles & Blog Posts

### [Bgospel Magazine : Gospel News, music, video, lyrics, download, biography - BGospel Magazine EN](https://en.bgospel.com/)
*2024-02-26*
- Category: article

### [Twenty Something · Claire Leslie](https://en.bgospel.com/twenty-something/)
*2025-03-20*
- Category: article

### [A year like no other at Jubilee+? | New Ground Churches](https://newgroundchurches.org/blog/inc-modal.php?item_id=483)
*2025-07-24*
- Category: blog

### [Kofi Owusu Peprah – BIG GOD AFRO](https://en.bgospel.com/kofi-owusu-peprah-big-god-afro/)
*2025-02-28*
- Category: article

### [Jelly Roll – The Cross Was Enough | Powerful Gospel Song (Christian Worship)](https://en.bgospel.com/jelly-roll-the-cross-was-enough-powerful-gospel-song-christian-worship/)
*2025-08-14*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Découvrez les 10 musiques populaires sur bgospel.com pour la ...](https://www.bgospel.com/decouvrez-les-10-musiques-populaires-sur-bgospel-com-pour-la-semaine-44/)**
  - Source: bgospel.com
  - *Nov 14, 2023 ... BGospel Podcast avek Pasteur Davidson Beauvil sou BGospel Magazine ... Notre mission : promouvoir l'évangile de Jésus-Christ par la m...*

- **[Mwen pap dekouraje - Josué Elismé (Analyz teks, part 2)](https://www.bgospel.com/mwen-pap-dekouraje-josue-elisme-analyz-teks-part-2/)**
  - Source: bgospel.com
  - *Nov 11, 2024 ... Auteur, compositeur et rédacteur pour BGospel.com, il a fondé Jubau GROUP en 2009, œuvrant pour la promotion de la musique évangéliqu...*

- **[12 aout 2023 | Soirée de prière et de collecte de fonds pour Villaire ...](https://www.bgospel.com/soiree-de-priere-et-de-fundraising/)**
  - Source: bgospel.com
  - *Jul 21, 2023 ... Fondateur de Jubau GROUP, promoteur de la musique évangélique depuis 2009. ... © Copyright - BGospel Magazine 2025. Pour faire un DON...*

- **[Mwen pap dekouraje - Josué Elismé (Analyz teks, part 1)](https://www.bgospel.com/mwen-pap-dekouraje-josue-elisme-analyz-teks-part-1/)**
  - Source: bgospel.com
  - *Nov 12, 2024 ... Fondateur de Jubau GROUP, promoteur de la musique évangélique depuis 2009. ... © Copyright - BGospel Magazine 2025. Pour faire un DON...*

- **[Solette J Hyppolite, ft. Jean Elie Brutus , Mwen Beni (video et paroles)](https://www.bgospel.com/solette-j-hyppolite-ft-jean-elie-brutus-mwen-beni-video-et-paroles/)**
  - Source: bgospel.com
  - *Apr 8, 2023 ... Auteur, compositeur et rédacteur pour BGospel.com, il a fondé Jubau GROUP en 2009, œuvrant pour la promotion de la musique évangélique...*

- **[Sy Garte - la science moderne révèle-t-elle un dessein créateur ?](https://www.bgospel.com/sy-garte-la-science-moderne-revele-t-elle-un-dessein-createur/)**
  - Source: bgospel.com
  - *Sep 23, 2025 ... Fondateur de Jubau GROUP, promoteur de la musique évangélique depuis 2009. ... © Copyright - BGospel Magazine 2025. Pour faire un DON...*

- **[Fondasyon'm (Cover) , Jonas Winter Blanc Feat. Liliane Oscar ...](https://www.bgospel.com/fondasyonm-cover-jonas-winter-blanc-feat-liliane-oscar-audio-lyrics/)**
  - Source: bgospel.com
  - *Jul 23, 2023 ... Fondateur de Jubau GROUP, promoteur de la musique évangélique depuis 2009. ... © Copyright - BGospel Magazine 2025. Pour faire un DON...*

- **[Anatèm De Stephanie Saint-surin](https://www.bgospel.com/anatem-de-stephanie-saint-surin/)**
  - Source: bgospel.com
  - *Apr 4, 2025 ... Fondateur de Jubau GROUP, promoteur de la musique évangélique depuis 2009. ... © Copyright - BGospel Magazine 2025. Pour faire un DON...*

- **[Interview avec Frè Debras - Emission Vendredi Recap](https://www.bgospel.com/fre-debras-ap-explike-poukisa-li-rele-album-lan-red-li-ye/)**
  - Source: bgospel.com
  - *Jan 21, 2024 ... top.bgospel.com/reservation/. Jameson Debras, BGospel Magazine, Jubau, artiste gospel haitien, interview live, ... Fondateur de Jubau...*

- **[Jonathan Laurince , Biography](https://www.bgospel.com/jonathan-laurince-biography/)**
  - Source: bgospel.com
  - *Apr 26, 2014 ... Auteur, compositeur et rédacteur pour BGospel.com, il a fondé Jubau GROUP en 2009, œuvrant pour la promotion de la musique évangéliqu...*

---

*Generated by Founder Scraper*
