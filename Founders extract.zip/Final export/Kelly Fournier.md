# Kelly Fournier

## Position actuelle

**Titre** : CEO - Founder / PDG - Fondateur
**Entreprise** : KETECH Global Consulting Services / KETECH International Services Conseils
**Durée dans le rôle** : 2 years 8 months in role
**Durée dans l'entreprise** : 2 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Providing business management consultancy services, with a special interest in technology driven markets. With proven experience in business management, including strategic vision, change management, business development, go-to-market strategies, sales leadership and enablement, process improvement, business analysis, marketing, P&L, strategic human resource management, Contracts management, procurement, expansion and growth and more. KETECH is also specialized in execution of strategies and business plans at all levels of an organization. Notable experience in telecommunications (e.g. FTTx), GIS, software and overall business management. 


La Société offre des services de consultations d'affaires notamment dans les secteurs de hautes technologies. Avec une expertise notoire en gestion d'entreprise, incluant l'élaboration de visions stratégiques, gestions de changements, développment de marchés, gestion de la force de ventes, marketing, stratégies de mise en marchés, gestion financière (P&L), gestions de contrats, ressources humaines, analyse d'affaires, amélioration de processus, stratégies et gestion d'expension et autres. De plus, l’entreprise est spécialisé dans l’exécution des plans stratégiques mise en place. Une expertise particulière envers la technology SIG (Systèmes Informations Géographique), télécomuunications, logiciels ainsi que la gestion générale d'entreprise.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAVvwo0BbEt_oFCspRFeJUxfiNBRMW6-SsM/


---

# Kelly Fournier

## Position actuelle

**Entreprise** : 3-GIS

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Kelly Fournier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391068741121363968 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEQWTdwQHJIRg/feedshare-shrink_800/B4EZpJZ2isHUAg-/0/1762168106160?e=1766620800&v=beta&t=8Zc2A3JBFzirzVC_h9p0xpF_jcIuRGuO-8IB2tTbUq8 | Esri Canada conference here I come. It’s been a while since I’ve made my way to Toronto. Can’t wait to see old friends, colleagues and chat telco.

#3GIS #GIS #telecom | 18 | 1 | 0 | 1mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:47.922Z |  | 2025-11-03T11:08:27.300Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7350506715303272448 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQEgxrssPw9JZA/image-shrink_800/B56Zf6BcDrHQAk-/0/1752246371892?e=1765782000&v=beta&t=cJiHhzB-aiRs2GNCgX7BjWAFqOhJNqL-8HU3FZzBfCo | Let's Go!!! | 9 | 0 | 0 | 4mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:47.922Z |  | 2025-07-14T12:49:26.739Z | https://www.linkedin.com/feed/update/urn:li:activity:7349454054504177664/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7348060479950348288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGDUzkuJy-Szg/feedshare-shrink_800/B4EZfmOEdhHcAk-/0/1751914137998?e=1766620800&v=beta&t=6bW813Z2Evv2cxlc4EEI3YBvPz1LVxgAc7yRBV599kE | Just one week until the Esri User Conference in San Diego! It's shaping up to be another fantastic event, as always.

Let's connect and chat while we're there! Booth no. 919

Everything 3-GIS at the UC: https://lnkd.in/eRKggK4d

#EsriUC #GIS #3GIS #Telecom #FiberOptics #FTTH | 21 | 0 | 0 | 5mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:47.923Z |  | 2025-07-07T18:48:58.782Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7338688866280787968 | Image |  | https://media.licdn.com/dms/image/v2/D4D10AQFopda8RY2mDg/image-shrink_800/B4DZdf6zJuH4Ag-/0/1749660939203?e=1765782000&v=beta&t=oN424hJxUYvemiFYuh-vjD4nWOoOme2TYE4hPQHpYU8 | Service assurance is a key part of operating your network. Reducing downtime not only cuts down on OPEX, but more importantly, gives your customers piece of mind knowing they have a trusted network provider that has the latest and greatest solutions to help manage their network. 

Join this webinar and find out more! | 9 | 1 | 0 | 5mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:47.923Z |  | 2025-06-11T22:09:31.967Z | https://www.linkedin.com/feed/update/urn:li:activity:7338609900777787392/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7335699998820483072 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQFaHOSiDPQkmQ/image-shrink_800/B56Zc2aUbyHoAc-/0/1748964559206?e=1765782000&v=beta&t=lF93l7So1RSd0NRWsXzmHO0G_QmtcZyAJ7g0ZN56Q50 | Day 1 is already behind us. But what a day it was! Felt great to reconnect with friends and colleagues of the industry. 

Day 2 is shaping up to be just as exciting. Go see my buddy Drew Peele in this session. Don't miss it!

#Fiberconnect #3GIS #FTTH | 18 | 1 | 0 | 6mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:47.924Z |  | 2025-06-03T16:12:50.434Z | https://www.linkedin.com/feed/update/urn:li:activity:7335689070079053824/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7311150363884072962 | Article |  |  | The FCC’s new NG911 mandates require telecom providers to standardize and validate 911 location data—with deadlines as short as six months. 

Our 1Locate solution automates compliance, ensuring real-time address validation, seamless interoperability, and accurate call routing to keep communities safe.

Don’t wait—let’s talk about how 1Locate can fast-track your NG911 readiness

Learn more by reading this article | 8 | 1 | 0 | 8mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:51.876Z |  | 2025-03-27T22:21:21.355Z | https://1spatial.com/us/news-events/2025/1spatial-s-1locate-empowers-telecom-providers/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7308170534431670273 | Article |  |  | A game changer in public safety. | 1 | 1 | 0 | 8mo | Post | Kelly Fournier | https://www.linkedin.com/in/kellyfournier | https://linkedin.com/in/kellyfournier | 2025-12-08T06:22:51.876Z |  | 2025-03-19T17:00:34.651Z | https://www.einpresswire.com/article/795042951/1spatial-set-to-unveil-interop-address-to-revolutionize-ng911-at-iwce-2025 |  | 

---



---

# Kelly Fournier
*3-GIS*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Podcast: GIS for Fiber Network Design](https://info.3-gis.com/gis-for-fiber-network-design)
*2025-10-03*
- Category: article

### [Podcast: The value of GIS in the Telecom Enterprise](https://info.3-gis.com/value-of-gis-in-telecom-enterprise)
*2025-10-03*
- Category: article

### [FTTH Design Software Podcast Library | 3-GIS](https://www.3-gis.com/fiberside-chat-podcast-library)
*2025-10-03*
- Category: podcast

### [Women in GIS interview!](https://ucanr.edu/blog/igis/article/women-gis-interview)
*2025-07-10*
- Category: blog

### [Women in GIS – March 2024](https://gisandyou.org/2024/03/29/women-in-gis-march-2024/)
*2024-03-29*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[3-GIS - Overview, News & Similar companies | ZoomInfo.com](https://www.zoominfo.com/c/3-gis-llc/308723783)**
  - Source: zoominfo.com
  - *Kelly Fournier. Director, Strategic Accounts Telecom. Joined May 1, 2025. Phone Email. Compare Similar Companies to 3-GIS. Compare insights from compa...*

---

*Generated by Founder Scraper*
