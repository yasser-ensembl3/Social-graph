# Majid Morabit

## Position actuelle

**Titre** : Founder
**Entreprise** : Alpha Treats
**Durée dans le rôle** : 2 years 7 months in role
**Durée dans l'entreprise** : 2 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Marketing Services

## Description du rôle

We shoot and create impactful videos to enhance your social networks and boost your marketing campaigns.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAXwEGYB-4q5DyTyk-guJZdWHpEmpV-2o1g/
**Connexions partagées** : 59


---

# Majid Morabit

## Position actuelle

**Entreprise** : The Wolves of LinkedIn

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Majid Morabit

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402622581037604865 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQFHtOzIHiO1Rg/mp4-720p-30fp-crf28/B4EZrtl9e1HcCI-/0/1764922755231?e=1765782000&v=beta&t=nrzmlfdtm3TkPV6jgDj2_TQ6BT9ZA2wB9Kj6Ae2sp0M | https://media.licdn.com/dms/image/v2/D4E05AQFHtOzIHiO1Rg/videocover-low/B4EZrtl9e1HcBQ-/0/1764922746047?e=1765782000&v=beta&t=ZqnkVTTA8zUNU0vE7venIlYCFr3qIcoMv3tspSkr4s0 | Great moment last week at MMC - Mice Meeting Casablanca in the beautiful cathedral.

 Speed-dating B2B meetings are still one of the best ways to meet incredible people fast.

 Are we shooting your next videos?

Thx Aya and Zeineb for your support at the event!

 #MICE #Casablanca #AlphaTreats #VideoProduction #EventVideo | 36 | 1 | 5 | 2d | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:01.066Z |  | 2025-12-05T08:19:17.396Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402360380968161280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/879ecd50-8a76-4ce8-bf02-f523df18ba2a | https://media.licdn.com/dms/image/v2/D4E05AQGoMooVciULRA/videocover-low/B4EZrp3etpHgBQ-/0/1764860230840?e=1765782000&v=beta&t=daAqAc422kwAF0r5iTsqH9sey5WGBA89Vzwq4GJMlmI | Paris is always a good idea.

 Last week we were at Tech4Retail creating video content for our Brazilian client.

 If you don’t know them yet, follow NetConv Shop.

Thx Lucas Piccinin for the trust!

 #Tech4Retail #Paris #AlphaTreats #VideoProduction #B2BContent #Netconv | 26 | 2 | 4 | 3d | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:01.067Z |  | 2025-12-04T14:57:24.028Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401885483510947840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHBqIbTi5bkkw/feedshare-shrink_2048_1536/B4EZrgXxGSIwAk-/0/1764700918430?e=1766620800&v=beta&t=RNZPeNDlX4EMx9ZvVejO3DS7Ya-KZNjV3i6qF94VS0Q | At Alpha Treats, we keep it simple:

 Quality work. On-time delivery.

Let’s talk about your next video project.

#CorporateVideo 
#VideoProduction 
#ContentCreation 
#AlphaTreats 
#B2BMarketing | 21 | 0 | 2 | 4d | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:01.067Z |  | 2025-12-03T07:30:19.651Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399720521506123776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEjZEw3XONLBw/feedshare-shrink_800/B4EZrEWmnwIQAg-/0/1764230851773?e=1766620800&v=beta&t=hNPyp5NUI6STOiuhk4zMfHHTFnPoTJVDRFy2QilsUUk | When the lead skips email and says:

“Can we talk on WhatsApp?”

That’s when you know your outreach hits right.

Learn how with The Wolves of LinkedIn.

#LeadGen 
#LinkedInResults 
#B2BGrowth 
#SocialSelling | 23 | 0 | 2 | 1w | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:01.068Z |  | 2025-11-27T08:07:32.486Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398990085993545728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH_c-nj-59tvA/feedshare-shrink_2048_1536/B4EZq3hs3XJgCA-/0/1764015657026?e=1766620800&v=beta&t=vaWiMnCAgeaM2_KZhCPHb2XrzH5Y1v8nAJPKVUE6TfY | Never take no for an answer.

Got a polite “this is not interesting for us, but thank you” 🙃

Sent one clear email explaining the value.

Now? The lead is alive. Discussions are ongoing for their next project.

One email. No pressure. Just clarity.

It’s never really a no, just not yet. | 19 | 0 | 4 | 1w | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:01.068Z |  | 2025-11-25T07:45:03.089Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394320112381689856 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8a62ccbd-6c0c-4e98-8ae1-cad443ffdeeb | https://media.licdn.com/dms/image/v2/D4E05AQGSPATOrpBIYw/videocover-high/B4EZp3m7pLGcBU-/0/1762943287727?e=1765782000&v=beta&t=4lNUKmEvVK136VKyY3e9oYR5xI6BmldTeNI0vjprKxE | I’m landing in Barcelona next week with Alpha Treats, ready to make some noise at IBTM World.

We’ve been creating video content across the globe all year, and now it’s time to bring that same energy to one of the biggest MICE events in the world.

 If you’re exhibiting or attending and want to talk about how we can elevate your video content, let’s meet.

 #IBTMWorld #Barcelona #AlphaTreats #VideoProduction #EventContent #B2BMarketing #TradeShowVideo | 26 | 0 | 2 | 3w | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.851Z |  | 2025-11-12T10:28:14.616Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7393558102807248896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGJ2-3sAxkZMQ/feedshare-shrink_800/B4EZppxeQGHoAk-/0/1762711169167?e=1766620800&v=beta&t=XkJb8jIsLCcBTziWl5sUif5lrwGG6G5wDR6ZhSD40js | Love waking up to pictures from our team all around the world.

 China will definitely be one of our main markets alongside the US in the coming months.

 Happy to be back in Shanghai with one of our long-term clients.

#Shanghai 
#China 
#AlphaTreats 
#VideoProduction 
#GlobalTeam 
#B2BMarketing 
#CorporateVideo | 21 | 0 | 3 | 3w | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.862Z |  | 2025-11-10T08:00:17.376Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391931749523468291 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGfgV6PDVYmug/feedshare-shrink_800/B4EZpVqwQiKcAk-/0/1762373863629?e=1766620800&v=beta&t=NhXx-jaLy7VB2wfZEVUPDm5VI5VnWlpS6b4hWBHDiWM | Hey LinkedIn 👋

Part of the Alpha Treats team is still in Dubai tomorrow for Gulfood Manufacturing. Looking to create some fresh video content?

 DM me if you’re around and want to shoot something cool. 🎥

#GulfoodManufacturing #Dubai #AlphaTreats #VideoProduction #EventContent #B2BMarketing #TradeShowVideo #gulfood2025 | 32 | 3 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.863Z |  | 2025-11-05T20:17:44.537Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391738550909685761 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFHSkAYaFOytw/feedshare-shrink_800/B4EZpQ468YIQAg-/0/1762293691462?e=1766620800&v=beta&t=U1CWTCC5yv1FIkxWqk9TcQYxk27pqr4Kxea6oY6pIi4 | While the world spins, we shoot.

 From New Delhi to Paris, our teams are creating video content 24/7 for clients around the world.

 #VideoProduction #AlphaTreats #GlobalContent #B2BMarketing #CorporateVideo | 26 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.863Z |  | 2025-11-05T07:30:02.398Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391025894569562112 | Poll |  |  | How many inbound leads did you get in October from LinkedIn?

 If the answer is “none”… your profile might be the problem.

Let's talk.

#LinkedInMarketing #LeadGeneration #B2BLeads #SocialSelling #LinkedInStrategy #PersonalBranding #InboundLeads #GrowthStrategy #SalesPipeline #MarketingTips | 22 | 1 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.864Z |  | 2025-11-03T08:18:11.886Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7390435607212314624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE5_Kg-B2a0sA/feedshare-shrink_800/B4EZpAaAv2HUAg-/0/1762017154952?e=1766620800&v=beta&t=qYYgG2VtzmLdEsebz_mAJLwnJlbix7oSFvxJLPjg6ms | Morning after Halloween, team in São Paulo sending proof we don’t sleep at Alpha Treats.

 Where are we today? 🚀

#SaoPaulo #VideoProduction #AlphaTreats #B2BContent #GlobalTeam | 27 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.865Z |  | 2025-11-01T17:12:36.413Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7389926615318933504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGsSH2hW6YtPw/feedshare-shrink_800/B4EZo3HjWaHEAk-/0/1761861319934?e=1766620800&v=beta&t=5uY6dwWl9ykGJZV3NXgCoXDKuSZ8dvD_Pm0_SQLOdaA | You’ll almost never see me on the ground covering an event with Alpha Treats.

Why? Probably because we handle too many events every day around the world, and honestly, whenever I try to help, I end up doing the opposite by putting pressure on a team that already has everything under control.

But sometimes you just have to wear the nice Alpha Treats polo.

What an experience it was to cover the 10th Annual TALA – The Aerospace Logistics Alliance Conference in Marrakech.

Four videographers on site, one of them editing same-day video content, another project manager handling everything in the back office, and me watching it all unfold exactly the way it always does, with or without me.

More than 80 attendees from around the world, four full days of activities, changing groups, sceneries, day and night, they did it all.

Congratulations Ahmed for an exceptional conference, and thank you for trusting Alpha Treats to capture it. A special thanks to Younes from Peschaud Travel & Events for the flawless organization. | 44 | 2 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.865Z |  | 2025-10-31T07:30:03.289Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7389681642761527297 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGZLlKwa4qRPw/feedshare-shrink_800/B4EZo1sSv.IQAg-/0/1761837396158?e=1766620800&v=beta&t=K5lj05ERD3xn3QWSPeiwvbApwNjebNfopzi9ZGKExlQ | Such a pleasure to work once again with Daplast, a company with over 50 years of experience that has equipped some of the world’s most iconic stadiums including the Bernabéu.

Gracias Inmaculada for your trust once again. Hope FSB-Cologne went great, already looking forward to the next project! | 26 | 1 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.866Z |  | 2025-10-30T15:16:37.280Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7389317483083726849 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHpUgLQPCnOiA/feedshare-shrink_800/B56ZowhFJYJsAg-/0/1761750573371?e=1766620800&v=beta&t=HGqlNw-srLbP7fqRzYcE9RDlHt29LCvLLYrWh6vSuno | New city, same rhythm.

Cologne, Germany. 🇩🇪

Filmed this morning, edits dropping soon.

#FSB2025 #Cologne #VideoProduction #ContentCreation #AlphaTreats #B2BMarketing | 25 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.868Z |  | 2025-10-29T15:09:34.847Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7388875662020792320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH-ERnhYQnyTw/feedshare-shrink_800/B4EZoqPQSVHgAg-/0/1761645235245?e=1766620800&v=beta&t=vgxzzOAwYNgt3vGdfRcLI07Ptksc-D1BZtvH7nz2qO4 | That’s exactly why worldwide companies trust The Wolves of LinkedIn with their outreach: we keep asking nicely until “ignore” magically turns into “invoice.”

+1 video booked for the Alpha Treats team | 25 | 1 | 2 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.869Z |  | 2025-10-28T09:53:56.497Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7387399490883821568 | Video (LinkedIn Source) | blob:https://www.linkedin.com/baed4eb7-86dc-4ed5-9d5f-31cf00a22a64 | https://media.licdn.com/dms/image/v2/D4E05AQHwpVnuKMhT2w/videocover-high/B4EZoVQrshIUBI-/0/1761293287106?e=1765782000&v=beta&t=nEIfOzCpX4BleYgrxCgPxGK2UL5pseTR0hlncdQI9PU | Another pin on the map.

Team in Singapore today for a full-day conference.

Lot of video content coming up. | 23 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.870Z |  | 2025-10-24T08:08:09.872Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7386757051101634560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-ynnhHR_VAA/feedshare-shrink_800/B4EZoMIZLsHcAk-/0/1761140118956?e=1766620800&v=beta&t=CinuH-MEu8Fusg9M2CMIFuGtX3mwd8-Cxij_RfWpR-c | Scan. Shoot. Style.

 Video project? Polo? Get in touch Alpha Treats | 26 | 0 | 4 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.870Z |  | 2025-10-22T13:35:20.292Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7386304149048709120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXeRKM33ZWdw/feedshare-shrink_1280/B4EZoFse0XGcAs-/0/1761032139064?e=1766620800&v=beta&t=PVcEmPWL6HF6hLkLTszyPgHNijk01NwWVOeeH3iuJtk | At Alpha Treats, we keep it simple:

 Quality work. On-time delivery.

Let’s talk about your next video project.

#CorporateVideo #VideoProduction #ContentCreation #AlphaTreats #B2BMarketing | 21 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.871Z |  | 2025-10-21T07:35:40.028Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7384921215565459456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEn8eOQDCWcg/feedshare-shrink_800/B4EZnyCtSkGYAk-/0/1760702421691?e=1766620800&v=beta&t=yGpe2_RYUcPbGJ35xPcT_iPI2O465hibsjzADrclY78 | Mamma mia! Some of the Alpha Treats crew are about to eat dangerously good pasta.

HostMilano, we’re here shooting video content for a few clients… and maybe a few carb shots too.

#HostMilano #Milan #VideoProduction #TradeShowContent #B2Bmarketing #EventVideo #Alphatrix #AlphaTreats #OnTheRoad | 26 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.872Z |  | 2025-10-17T12:00:22.992Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7384853222844387328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/da42166e-20e4-428f-9e00-97cbc6cb32ba | https://media.licdn.com/dms/image/v2/D4E05AQFc0hFA6jyqsA/videocover-high/B4EZnu9k.OKcB8-/0/1760650754644?e=1765782000&v=beta&t=CCd1adhdsMr3CE_mXgehOeKSZ4BRW-ejmximotTuPZ4 | Someone forgot about Berlin here but that’s fine.

Marrakech, Berlin, Lagos, Dubai!

Four GITEX GLOBAL Largest Tech & Startup Show in the World events this year, one unstoppable team Alpha Treats

Epic week, weekend is looking as crazy. 

Thanks to all our clients for keeping us inspired. | 25 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.872Z |  | 2025-10-17T07:30:12.264Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7384616562110001152 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3e5bca22-586e-4a7f-b80e-60bda0e40f41 | https://media.licdn.com/dms/image/v2/D4D05AQEGJv4yKhtg9g/videocover-low/B4DZntG0C5IkB8-/0/1760619660032?e=1765782000&v=beta&t=MIZvlwj8Yd_hleoDSEL7yXSg0CDd_SOIt7remD3lR9M | Long life to Docloop!

Happy to see some of Alpha Treats work on french television! 

More to come! | 20 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.873Z |  | 2025-10-16T15:49:47.948Z | https://www.linkedin.com/feed/update/urn:li:activity:7384574197685100544/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7384352516538552320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFphadIFygsOg/feedshare-shrink_800/B4EZnp9elAKkAk-/0/1760566832376?e=1766620800&v=beta&t=vdd01-JT9xzglufRpDhDwM6jdrgN4kJFrMCfhTXy-l4 | Monterey, California. 

A lot of sofa talks coming up!

Alpha Treats | 36 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.874Z |  | 2025-10-15T22:20:34.578Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7384128444433076224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGcbacXoXKj1A/feedshare-shrink_800/B4EZnmbqcrKcAg-/0/1760507636262?e=1766620800&v=beta&t=Bb41qbxBcMh_AEtO5nwqd52nsXaa2nP6zj32oSc1efg | When the lead skips email and says:

“Can we talk on WhatsApp?”

That’s when you know your outreach hits right.

Learn how with The Wolves of LinkedIn.

#LeadGen 
#LinkedInResults 
#B2BGrowth 
#SocialSelling | 19 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.875Z |  | 2025-10-15T07:30:11.625Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7383766078579023874 | Video (LinkedIn Source) | blob:https://www.linkedin.com/646ef72b-b17f-4fab-8d2d-b22f25a115cd | https://media.licdn.com/dms/image/v2/D4E05AQG2W21ORP98XQ/videocover-high/B4EZnhXSilJgB8-/0/1760422620526?e=1765782000&v=beta&t=eTUZwY4L8_tMHlWJYzV142FmJ0NoARnFUgveMinFQvU | Our Alpha Treats team spent the day filming corporate video content on a yacht in Dubai, just a few days before the GITEX GLOBAL Largest Tech & Startup Show in the World madness begins.

We’re on site this week if you’d like to discuss your next project.

#Dubai #GITEX #VideoProduction #CorporateVideo #ContentCreation #AlphaTreats #GITEX2025 #gitexglobal | 31 | 1 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.876Z |  | 2025-10-14T07:30:16.873Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7382432624587464705 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9b154f6e-204f-4ac0-8bcb-63b5aabf0044 | https://media.licdn.com/dms/image/v2/D4E05AQFQHwiieV1ISA/videocover-low/B4EZnOrT0iGcB4-/0/1760109087074?e=1765782000&v=beta&t=Y6DiHy4cBT97bsROq85lZUZ9OqxVcP6YyzXIc1ezOSs | Always a pleasure working with Zalar Farms.

 Back to back from Fruit Attraction in Madrid to Anuga in Cologne.

 More video content coming soon. | 28 | 0 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.877Z |  | 2025-10-10T15:11:36.667Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7381990733307621376 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bd767f66-f45a-4310-b051-0b49041c8a9c | https://media.licdn.com/dms/image/v2/D4D05AQHPnkf3EZjAcA/videocover-low/B4DZnIZUILIcB8-/0/1760003730401?e=1765782000&v=beta&t=tOdiWIXj_JMZHgy2pes-xQO0SLdZMDPubUMVwcIP3ag | Alpha Treats x Docloop

60 seconds video to understand how they’re transforming logistics paperwork.

Not one second more.

Thx Aymeric Le Page for your trust since day one. | 34 | 2 | 6 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.878Z |  | 2025-10-09T09:55:41.576Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7381616413553348608 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b295e37e-7c19-4d63-8b9a-32622b1b2a80 | https://media.licdn.com/dms/image/v2/D4E05AQHs8xOs0nONlw/videocover-low/B4EZnDE8KRHgB4-/0/1759914486782?e=1765782000&v=beta&t=21PFZEvGEdRJK7exeDDIX6Tn3aMzPnltpO-D4R031cw | Proud to share our latest project for The Venue Downtown, an incredible business space in one of Casablanca’s iconic towers.

Conference rooms, meeting areas, and an inspiring atmosphere designed to elevate collaboration.

This video was created to let clients and prospects feel the space before even stepping in.

 Big thanks to Mohcine El Hraichi for the trust. Don't hesitate to get in touch with him for your next event. | 34 | 2 | 3 | 1mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.878Z |  | 2025-10-08T09:08:16.792Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7381373478559522816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFGR6sNRJZgGQ/feedshare-shrink_800/B4EZm_oBpgIwAg-/0/1759856574999?e=1766620800&v=beta&t=Mo3bTmDpQypvm-fAEijcYQLnFD9IwdBk-G_TxfCNoXQ | If you don’t know… now you know.

Full-time video content creator team in Dubai, all day, every day.

Forex Expo, yachts, GITEX GLOBAL Largest Tech & Startup Show in the World.

Same hustle, new content. | 28 | 0 | 3 | 2mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.879Z |  | 2025-10-07T17:02:56.576Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7381265780283244545 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHGnNL5PCI8WQ/feedshare-shrink_800/B4EZm.GHGRIUAg-/0/1759830897804?e=1766620800&v=beta&t=bQDrThRqUxPAOUWaevpU3fvo30uUg9FyLOehq0fVJ5Y | While you're hesitating, your competitor is turning profile views into leads.

And you? 

Still rocking that default banner and job title.

Send me a DM | 21 | 0 | 3 | 2mo | Post | Majid Morabit | https://www.linkedin.com/in/majid-morabit-a0644129 | https://linkedin.com/in/majid-morabit-a0644129 | 2025-12-08T06:08:05.879Z |  | 2025-10-07T09:54:59.306Z |  |  | 

---



---

# Majid Morabit
*The Wolves of LinkedIn*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [the Executives: A Dialogue with Majid](https://podcasts.apple.com/de/podcast/the-executives-a-dialogue-with-majid/id1717776872)
*2025-04-03*
- Category: podcast

### [Inspiring and connecting entrepreneurs | Wamda.com](https://www.wamda.com/country/morocco)
*2025-04-17*
- Category: article

### [Morocco’s 40 Under 40: A New Generation of Leaders Driving the Country’s Transformation](https://www.moroccoworldnews.com/2024/11/12345/moroccos-40-under-40-a-new-generation-of-leaders-driving-the-countrys-transformation/)
*2024-11-16*
- Category: article

### [Be the Change You Wish to See: Reflecting on Generation Share: Changemakers of Morocco — High Atlas Foundation](https://highatlasfoundation.org/ar/%D8%A7%D9%84%D8%A8%D8%B5%D8%A7%D8%A6%D8%B1/be-the-change-you-wish-to-see-reflecting-on-generation-share-changemakers-of-morocco)
*2025-05-14*
- Category: article

### [Publications | Policy Center](https://www.policycenter.ma/publications/opinion?page=70)
*2025-11-18*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Mr Majid Morabit - Founder of "The Wolves of LinkedIn ...](https://www.youtube.com/watch?v=_DxcGERCQyY)**
  - Source: youtube.com
  - *Mar 17, 2023 ... Mr Majid Morabit - Founder of "The Wolves of LinkedIn" & "Meslentilles.ma". 154 views · 2 years ago The Outliers' Podcast ...more. Lp...*

- **[ImmotalK by Mubawab : Interview Majid Morabit - YouTube](https://www.youtube.com/watch?v=DJDrpd8dhb0)**
  - Source: youtube.com
  - *Jan 15, 2025 ... ... Majid Morabit, Founder de The Wolves of LinkedIn, qui nous dévoile ses stratégies gagnantes dans une interview exclusive Restez c...*

- **[Réseaux sociaux : une mine d'or pour la génération de Leads ...](https://www.youtube.com/watch?v=bqscJ1ATWuY)**
  - Source: youtube.com
  - *Oct 19, 2023 ... A travers cet épisode enregistré durant le salon ImmoTech organisé par MUBAWAB et RENT, Majid Morabit (CEO The Wolves of Linkedin) et...*

---

*Generated by Founder Scraper*
