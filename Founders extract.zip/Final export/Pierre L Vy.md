# Pierre Lévy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401014909876199424 | Article |  |  | Excerpt of my last blog post : «Ethical issues cannot be limited to models: they must extend to the creation of the data that drives them, i.e. to all of our online behavior. [...] We generally focus on the direct reception of our messages, but we must bear in mind that we contribute indirectly – through the models we train – to answering our contemporaries' questions, writing their texts, teaching students, guiding policies, etc.»
https://lnkd.in/eeRrdFZw | 6 | 0 | 1 | 1w | Eric Le Ray Ph.D. reposted this | Pierre Lévy | https://www.linkedin.com/in/pierrelevy | https://linkedin.com/in/epaperworldepc | 2025-12-08T06:18:18.308Z |  | 2025-11-30T21:50:58.722Z | https://intlekt.io/2025/11/30/ai-is-at-the-heart-of-the-new-communication-ecosystem/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401014654816264192 | Article |  |  | Extrait de ma dernière entrée de blog : «Les problèmes éthiques ne peuvent se limiter aux modèles : ils doivent s'étendre à la création des données qui les entraînent, c'est-à-dire à l'ensemble de notre comportement en ligne. [...] Nous nous concentrons généralement sur la réception directe de nos messages, mais il nous faut garder à l'esprit que nous contribuons indirectement – par l'intermédiaire des modèles que nous entraînons – à répondre aux questions de nos contemporains, à rédiger leurs textes, à instruire des élèves, à orienter des politiques, etc.»
https://lnkd.in/eKc5Pvyq | 6 | 0 | 2 | 1w | Eric Le Ray Ph.D. reposted this | Pierre Lévy | https://www.linkedin.com/in/pierrelevy | https://linkedin.com/in/epaperworldepc | 2025-12-08T06:18:21.279Z |  | 2025-11-30T21:49:57.911Z | https://pierrelevyblog.com/2025/11/30/lia-au-coeur-du-nouvel-ecosysteme-de-communication/ |  | 

---

