# Maxime Julien

## Position actuelle

**Titre** : CEO, Founder
**Entreprise** : Solid State of Mind
**Durée dans le rôle** : 5 years 11 months in role
**Durée dans l'entreprise** : 5 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Solid State of Mind builds an Artificial Intelligence finally able to thrive in real-world environments. We deliver few-shot learning and meaningful generalization at low power.

## Résumé

Serial entrepreneur and accomplished executive with a strong academic background and extensive experience in high-tech industries. Proven leadership as CEO, COO, VP of Engineering, and Operations or Program Management, specializing in the design, development, construction, and operation of complex products.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAALnaABLfL62vl6Guyj3fCJKz9C3doBYhs/
**Connexions partagées** : 87


---

# Maxime Julien

## Position actuelle

**Entreprise** : Solid State of Mind

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Maxime Julien

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398714349101531136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEp_fMQPGMx9w/feedshare-shrink_800/B4EZq2Dfi4IQAk-/0/1763990960914?e=1766620800&v=beta&t=mkARRugB48SGlOv-_LrlmorNyWAL0282CZ8Hj0sX7qI | Currently, we are witnessing the largest tech bubble since the dot-com era. 

Only this time, it’s powered by AI and fueled by hype, scale, and unsustainable growth.
But it doesn’t have to end in a crash. 

In my latest piece, I lay out how we can soft-land the AI bubble and steer the field back toward real, sustainable intelligence. 

https://lnkd.in/eEidJdSw | 12 | 0 | 1 | 1w | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:08.850Z |  | 2025-11-24T13:29:22.291Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394682610574131200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFv58a08De6fQ/feedshare-shrink_1280/B4EZp8wpcMGYAs-/0/1763029719421?e=1766620800&v=beta&t=vF2a-qEfrTdpRa9GGVENJwtEHMwrACwDdVLpkvhAyUM | Fascinating evening with SingularityNET and true pioneers in AI at the Lisbon Web Summit.

Last night’s exclusive reception brought together some of the brightest minds shaping the future of decentralized intelligence with Dr. Ben Goertzel , the father of AGI, Janet Adams, COO of SingularityNET, and Brittany Kaiser, CEO of AlphaTON.

Their fireside chat explored the rapidly evolving landscape of decentralized compute and data privacy in the age of intelligence, topics that sit at the intersection of technology, ethics, and societal transformation.

Hearing firsthand from those who’ve been pushing the boundaries of AI for decades was both inspiring and grounding.

Thanks to the SingularityNET team for hosting such a thought-provoking event and for continuing to lead conversations that truly matter for the future of AI.

#AI #AGI #SingularityNET #LisbonWebSummit | 10 | 0 | 1 | 3w | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:08.852Z |  | 2025-11-13T10:28:40.920Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7388952830730141696 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE1mB0PenQ8YQ/feedshare-shrink_800/B4EZorVcg1J0Ag-/0/1761663634168?e=1766620800&v=beta&t=A_KD1wtipHxwFEvL3yF3M_CR1Vk4kWmagU6s6hG0hmY | Everyone is talking about AI. Few are asking what “intelligence” actually means. 

I’m heading to #WebSummit Lisbon to demonstrate what true intelligence in AI looks like. 

At Solid State of Mind, we built an AI that goes beyond pattern-matching and achieves an actual understanding of the world around it. 

I’ll be in Lisbon starting Monday, November 10, connecting with founders, researchers, and investors who share that vision. 

If you’re in town, come see what real intelligence looks like. | 14 | 1 | 0 | 1mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:08.853Z |  | 2025-10-28T15:00:34.951Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7381668503176548352 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0KZ5ZCxzNrQ/feedshare-shrink_800/B4EZnD0Yj8IIAg-/0/1759926914368?e=1766620800&v=beta&t=q9YUsEd6nIyNLJW1XuvJniSxpl0-QySZRfh580qRFII | Day two of #SFTechWeek brought another great reminder: fundraising isn’t just about capital, it’s about alignment.

The best partnerships happen when a founder’s vision and an investor’s thesis truly resonate. When both sides are solving for the same “why,” progress moves faster, decisions get sharper, and the mission gains momentum.

Huge thanks to Nathan Beckord (Foundersuite.com) for curating and hosting such an outstanding panel of investors — SC Moatti (Mighty Capital), Robert Windesheim (Founders Fund) and Gabriel Jarrosson (Lobster Capital), each bringing a distinct, well-defined thesis and perspective. The diversity of viewpoints made the discussion both rich and real.

As founders, our job is not to convince every investor. it’s to find the ones whose conviction matches ours.

I would love to continue these conversations; let’s meet up in the city and share thoughts. 

#Entrepreneurship #VentureCapital #AI #DeepTech #Startups #SFTechWeek | 21 | 1 | 2 | 1mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.770Z |  | 2025-10-08T12:35:15.926Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7381098696085770240 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHS_n4ZM2zZBw/feedshare-shrink_800/B4EZm7uJpLIIAg-/0/1759791062020?e=1766620800&v=beta&t=rNftDD4SgzvVECk7xPXePU8qFMc0o8fCp7rG8QJFqgo | Day one of #SFTechWeek is all about momentum.

Kudos to Garrison G. for hosting How to Raise a Round, a sharp discussion on today’s funding landscape with Sophie Durey (Tamar VC), Lindsey Mignano (SSM), Anish Srivastava (Swisscom Ventures), Zamir Shukho, MBA (Vibranium.VC) and Adam Dunnett.

As #SFTechWeek unfolds, I’m looking to connect with founders and investors pushing the boundaries of Deep Tech and AI.

Let’s meet in San Francisco and talk about where innovation is really heading. | 27 | 0 | 2 | 2mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.771Z |  | 2025-10-06T22:51:03.329Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7380945937621491712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0ketaoygqmw/feedshare-shrink_800/B4EZmmObjRIUAg-/0/1759430425400?e=1766620800&v=beta&t=puOi6jeePv6FZo1oKx-pLZmjHWyjFhK5fJA3jPZ-qjM | Tech Week in San Francisco brings in the biggest ideas in AI. 

Most of them are chasing scale: large models with even larger power bills. 

At Solid State of Mind, we are charting a different path. AI that wins on adaptability, speed, and efficiency.

If you’ll be at Tech Week, let’s talk. | 31 | 1 | 5 | 2mo | Maxime Julien reposted this | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.772Z |  | 2025-10-06T12:44:02.873Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7380939322054823937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFxBNNFChAHQA/feedshare-shrink_800/B4EZm5dMJDIwAg-/0/1759753064166?e=1766620800&v=beta&t=oAKw60zOdAC28343pJqTXj_Zl7mmXp_rGairqwcLG2g | We used to do wonders with very little..

I was reminded of that while repairing my old Apple II and IBM PC during the pandemic. These machines were built under strict constraints, when engineers couldn’t throw massive hardware or borrowed code at problems. That spirit has been lost.

Today’s AI chases scale: bigger models, more GPUs, more energy. The returns are marginal, and the costs are unsustainable.

If our brains run on 25 watts, why does AI demand Gigawatts?

Frugality is not nostalgia. It is the only path forward. Read more of my thoughts on this subject: 

https://lnkd.in/exMm3ZSb | 48 | 8 | 7 | 2mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.773Z |  | 2025-10-06T12:17:45.599Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7379586074269937664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0ketaoygqmw/feedshare-shrink_800/B4EZmmObjRIUAg-/0/1759430425400?e=1766620800&v=beta&t=puOi6jeePv6FZo1oKx-pLZmjHWyjFhK5fJA3jPZ-qjM | Tech Week in San Francisco brings in the biggest ideas in AI. 

Most of them are chasing scale: large models with even larger power bills. 

At Solid State of Mind, we are charting a different path. AI that wins on adaptability, speed, and efficiency.

If you’ll be at Tech Week, let’s talk. | 31 | 1 | 5 | 2mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.774Z |  | 2025-10-02T18:40:26.185Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7375855694857523200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTyaDs1k38Iw/feedshare-shrink_800/B4EZljHT.7IoAg-/0/1758304485811?e=1766620800&v=beta&t=u1LZ5sHQ8SCZg4FuPx2S8IpWXc_TnNsVL6D9iPOqjDc | We’ll be at ALL IN on September 24-25, ready to talk about the future of AI: fast, frugal and adaptable.

After all, there’s no “I” in today’s AI. That’s what we’re here to change.

If you’re heading to the event, let’s connect. 

We believe the best opportunities come from unexpected conversations.

See you in Montréal.

#ALLIN2025 | 39 | 4 | 5 | 2mo | Maxime Julien reposted this | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.775Z |  | 2025-09-22T11:37:14.426Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7374863542061273088 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTyaDs1k38Iw/feedshare-shrink_800/B4EZljHT.7IoAg-/0/1758304485811?e=1766620800&v=beta&t=u1LZ5sHQ8SCZg4FuPx2S8IpWXc_TnNsVL6D9iPOqjDc | We’ll be at ALL IN on September 24-25, ready to talk about the future of AI: fast, frugal and adaptable.

After all, there’s no “I” in today’s AI. That’s what we’re here to change.

If you’re heading to the event, let’s connect. 

We believe the best opportunities come from unexpected conversations.

See you in Montréal.

#ALLIN2025 | 39 | 4 | 5 | 2mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.777Z |  | 2025-09-19T17:54:46.766Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7359551077509124096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2oc1bSG4q6Q/feedshare-shrink_800/B4EZiJgtCwHgAk-/0/1754653709011?e=1766620800&v=beta&t=gOtJZR3LKpwxvQu5Bk7QAl3bqxMxe8-3535JZXIUiG0 | Everyone’s scaling models. We’re building minds.

At Solid State of Mind, we believe AGI won’t come from brute force. It demands new mental models, inspired by how intelligence actually works in the real world.

That’s why we created Deep Meaning™, a foundational approach that moves beyond prediction into comprehension. It enables autonomous agents to generalize across environments using multiple orders of magnitude less data and less energy than today’s leading models. 

Our goal is to deliver by 2030 an artificial workforce that blends seamlessly into everyday human life.

As Ai4 kicks off, let’s talk about how new cognitive architectures are reshaping the future of AI. | 53 | 2 | 3 | 3mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.782Z |  | 2025-08-08T11:48:30.725Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7338248380327845888 | Text |  |  | We are #hiring! Know anyone who might be interested to make a dent in the universe?

We are looking for a highly skilled 5G ORAN Machine Learning Engineer to drive the development and the implementation of ML based xApps and rApps, capable of adapting in real time to fast changing 5G network environments. | 18 | 0 | 7 | 5mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.785Z |  | 2025-06-10T16:59:11.932Z |  | https://www.linkedin.com/jobs/view/4248225298/ | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7330970719956135936 | Text |  |  | We are #hiring! 
Know anyone who might be interested to make a dent in the universe?

We are seeking a talented and innovative Artificial Animal Brain Developer to participate in the design and implementation of autonomous agents capable of adapting in real time to changing environments, while running on batteries.

The ideal candidate will have a deep understanding of biology, neuroscience, cognition, computer science, and artificial intelligence, with a keen interest in developing sustainable artificial intelligence systems.


Solid State of Mind #embauche!

Nous recherchons un "Développeur de Cerveau Animal Artificiel" talentueux et innovant pour participer à la conception et à la mise en œuvre d'agents autonomes capables de s'adapter en temps réel à des environnements changeants, tout en fonctionnant sur batteries.

Le candidat idéal aura une compréhension approfondie de la biologie, des neurosciences, de la cognition, de l'informatique et de l'intelligence artificielle, avec un vif intérêt pour le développement de systèmes d'intelligence artificielle durable. | 39 | 2 | 6 | 6mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.786Z |  | 2025-05-21T15:00:22.487Z |  | https://www.linkedin.com/jobs/view/4234418293/ | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7272332697048363008 | Text |  |  | We are #hiring! Know anyone who might be interested to make a dent in the universe?

We are seeking a talented and innovative Artificial Animal Brain Developer to participate in the design and implementation of autonomous agents capable of adapting in real time to changing environments, while running on batteries.

The ideal candidate will have a deep understanding of biology, neuroscience, cognition, computer science, and artificial intelligence, with a keen interest in developing sustainable artificial intelligence systems.


Solid State of Mind #embauche!

Nous recherchons un "Développeur de Cerveau Animal Artificiel" talentueux et innovant pour participer à la conception et à la mise en œuvre d'agents autonomes capables de s'adapter en temps réel à des environnements changeants, tout en fonctionnant sur batteries.

Le candidat idéal aura une compréhension approfondie de la biologie, des neurosciences, de la cognition, de l'informatique et de l'intelligence artificielle, avec un vif intérêt pour le développement de systèmes d'intelligence artificielle durable. | 37 | 2 | 3 | 11mo | Post | Maxime Julien | https://www.linkedin.com/in/maximejulien | https://linkedin.com/in/maximejulien | 2025-12-08T04:45:13.789Z |  | 2024-12-10T19:33:48.384Z |  | https://www.linkedin.com/jobs/view/4096590520/ | 

---



---

# Maxime Julien
*Solid State of Mind*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Maxime Julien on LinkedIn: Solid State of Mind introduces Deep Meaning](https://ca.linkedin.com/posts/maximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl)
*2023-05-04*
- Category: article

### [Solid State of Mind | LinkedIn](https://ca.linkedin.com/company/solid-state-of-mind)
*2021-08-01*
- Category: article

### [Solid State of Mind | Building Artificial Brains for the Real World, AI Startup at appengine.ai](https://www.appengine.ai/company/solid-state-of-mind)
*2025-01-01*
- Category: article

### [Microsoft Word - Press Release - Feb 13 23.docx](https://solidstateofmind.com/wp/wp-content/uploads/2023/05/PressRelease-SSoM-202302.pdf)
*2023-05-02*
- Category: article

### [The Real Maxime Podcast](https://rss.com/podcasts/therealmaxime/)
*2022-11-22*
- Category: podcast

---

## 📖 Full Content (Scraped)

*9 articles scraped, 45,626 words total*

### Solid State of Mind introduces Deep Meaning | Maxime Julien
*511 words* | Source: **EXA** | [Link](https://ca.linkedin.com/posts/maximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl)

Solid State of Mind introduces Deep Meaning | Maxime Julien

===============

Agree & Join LinkedIn

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

[Skip to main content](https://ca.linkedin.com/posts/maximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_post_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_post_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=public_post_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=public_post_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=public_post_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_post_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fposts%2Fmaximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl&fromSignIn=true&trk=public_post_nav-header-signin)[Join for free](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fposts%2Fmaximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl&trk=public_post_nav-header-join)

Maxime Julien’s Post
====================

[![Image 1: View profile for Maxime Julien](https://media.licdn.com/dms/image/v2/D5603AQEeLkcKcKdF3w/profile-displayphoto-shrink_400_400/profile-displayphoto-shrink_400_400/0/1682377555717?e=2147483647&v=beta&t=UyIFPRzaD3lX2TOvsWiecBAyT8zqokYr6VksPHHkayU)](https://ca.linkedin.com/in/maximejulien?trk=public_post_feed-actor-image)

[Maxime Julien](https://ca.linkedin.com/in/maximejulien?trk=public_post_feed-actor-name)

 2y 

*   [Report this post](https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fposts%2Fmaximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl&trk=public_post_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[![Image 2: View organization page for Solid State of Mind](https://media.licdn.com/dms/image/v2/D4E0BAQFkhYvThlIcvA/company-logo_100_100/B4EZYBCCbMGgAQ-/0/1743774034430/solid_state_of_mind_logo?e=2147483647&v=beta&t=f6H8np6fmti7Un5VNAQ1qX_iEjLN0GHiPX8iYj2A100)](https://ca.linkedin.com/company/solid-state-of-mind?trk=public_post_reshare_feed-actor-image)

[Solid State of Mind](https://ca.linkedin.com/company/solid-state-of-mind?trk=public_post_reshare_feed-actor-name)

1,313 followers

 2y  Edited 

Introducing Deep Meaning™. Solid State of Mind is at the forefront of the next big revolution in AI: [https://lnkd.in/eAUfMTbf](https://lnkd.in/eAUfMTbf?trk=public_post_reshare-text) Our vision: Creating new opportunities for industries that can benefit from a truly autonomous Artificial Intelligence. Read our most recent press release: [https://lnkd.in/erM-SYQj](https://lnkd.in/erM-SYQj?trk=public_post_reshare-text)[#AI](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fai&trk=public_post_reshare-text)[#AGI](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fagi&trk=public_post_reshare-text)[#robotics](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Frobotics&trk=public_post_reshare-text)[#artificialintelligence](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fartificialintelligence&trk=public_post_reshare-text)[#artificialintelligencetechnology](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fartificialintelligencetechnology&trk=public_post_reshare-text)[#ainews](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Ffeed%2Fhashtag%2Fainews&trk=public_post_reshare-text)

[### Solid State of Mind introduces Deep Meaning](https://www.linkedin.com/redir/redirect?url=https%3A%2F%2Fwww%2Eyoutube%2Ecom%2Fwatch%3Fv%3DgpynR7aqYSA&urlhash=P0Wq&trk=public_post_reshare_ingested-content-summary-external-video-content)
#### https://www.youtube.com/

[![Image 3](https://static.licdn.com/aero-v1/sc/h/bn39hirwzjqj18ej1fkz55671)![Image 4](https://static.licdn.com/aero-v1/sc/h/2tzoeodxy0zug4455msr0oq0v) 32](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fposts%2Fmaximejulien_solid-state-of-mind-introduces-deep-meaning-activity-7059899993867857920-Ndkl&trk=pu

*[... truncated, 11,430 more characters]*

---

### Solid State of Mind | LinkedIn
*2,121 words* | Source: **EXA** | [Link](https://ca.linkedin.com/company/solid-state-of-mind)

Solid State of Mind | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/company/solid-state-of-mind#main-content)[LinkedIn](https://ca.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fsolid-state-of-mind&fromSignIn=true&trk=organization_guest_nav-header-signin)[Register now](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fsolid-state-of-mind&trk=organization_guest_nav-header-join)

![Image 1: Solid State of Mind’s cover photo](https://static.licdn.com/aero-v1/sc/h/5q92mjc5c51bjlwaj3rs9aa82)

![Image 2: Solid State of Mind](https://media.licdn.com/dms/image/v2/D4E0BAQFkhYvThlIcvA/company-logo_200_200/B4EZYBCCbMGgAI-/0/1743774034430/solid_state_of_mind_logo?e=2147483647&v=beta&t=rHxA1gPjPImtbJt-ptwhipeG5R6I3COnECx4GpZ-a0Y)

Solid State of Mind
===================

Software Development
--------------------

### Montreal, Quebec  1,313 followers

#### Artificial brains for the real world!

[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fsolid-state-of-mind&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://media.licdn.com/dms/image/v2/D5603AQEeLkcKcKdF3w/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1682377555717?e=2147483647&v=beta&t=fMYDd3AA0amtMBnbsdrsgWs0QbA0oKHZIJMJ5jG3q5c)![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQHCMzhOcPwVYQ/profile-displayphoto-shrink_100_100/B4EZamL4L6HMAU-/0/1746544854113?e=2147483647&v=beta&t=eIYLISiFhO0VLDH0fX-QaqeP0kFbwZnYdJWTU_2zSIw) View all 4 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B42090709%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Fsolid-state-of-mind&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

Solid State of Mind builds an Artificial Intelligence finally able to thrive in real-world environments.

 Industry  Software Development 

 Company size  2-10 employees 

 Headquarters  Montreal, Quebec 

 Type  Privately Held 

 Founded  2020 

Locations
---------

*    Primary Montreal, Quebec, CA [Get directions](https://www.bing.com/maps?where=Montreal+Quebec+CA&trk=org-locations_url)

Employees at Solid State of Mind
--------------------------------

*   [![Image 5: Click here to view Maxime Julien’s profile](https://ca.linkedin.com/company/solid-state-of-mind)### Maxime Julien](https://ca.linkedin.com/in/maximejulien?trk=org-employees)
*   [![Image 6: Click here to view Pascal Fortier-Poisson’s profile](https://ca.linkedin.com/company/solid-state-of-mind)### Pascal Fortier-Poisson](https://ca.linkedin.com/in/publicpascalfortierpoisson?trk=org-employees)

[See all employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B42090709%255D&trk=public_biz_employees-join)

Updates
-------

*   
[](https://www.linkedin.com/posts/activity-7398714349101531136-Y7W0)
[Solid State of Mind](https://ca.linkedin.com/company/solid-state-of-mind?trk=organization_guest_main-feed-card_feed-reaction-header) reposted this

[![Image 7: View profile for Maxime Julien](https://ca.linkedin.com/company/solid-state-of-mind)](https://ca.linkedin.com/in/maximejulien?trk=organization_guest_main-feed-card_feed-actor-image)[Maxime Julien](https://ca.linkedin.com/in/maximejulien?trk=organization_guest_main-feed-card_feed-actor-name)  1w    

    *   [Report this post](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Fsolid-state-of-mind&trk=organization_guest_main-feed-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

Currently, we are witnessing the largest tech bubble since the dot-com era. Only this time, it’s powered by AI and fueled by hype, scale, and unsustainable growth. But it doesn’t have to end in a crash. In my latest piece, I lay out how we can soft-land the AI bubble and steer the field back toward real, sustainable intelligence. [https://lnkd.i

*[... truncated, 39,561 more characters]*

---

### Microsoft Word - Press Release - Feb 13 23.docx
*647 words* | Source: **EXA** | [Link](https://solidstateofmind.com/wp/wp-content/uploads/2023/05/PressRelease-SSoM-202302.pdf)

FOR IMMEDIATE RELEASE 

# CANADIAN STARTUP MAKES MAJOR BREAKTHROUGH IN THEIR 

# MISSION TO CREATE THE NEXT GENERATION OF AI 

Solid State of Mind’s new approach to Artificial General Intelligence is expected to 

create new product and market opportunities for industries that can benefit from a 

truly autonomous AI. 

MONTRÉAL, QUEBEC – February 14 th , 2023 — Solid State of Mind (SSoM), a new 

Canadian startup based in Montréal, made a major breakthrough towards their 

objective to create Artificial General Intelligence (AGI) after a successful proof of 

concept that was completed earlier this year. Their new AGI is expected to 

revolutionize all industries that can benefit from a highly autonomous artificial 

workforce. 

“Imagine having autonomous mobile robots doing surveillance rounds, inspecting 

infrastructures, or helping on risky search and rescue missions,” shares Maxime 

Julien, SSoM CEO and Founder. “With the growing labor shortage, this additional 

help is not only desirable but soon to be essential.” 

Moving away from narrow applications and towards AGI 

To date, the tech industry has spent billions of dollars and numerous years of 

research on deep learning AI, a type of machine learning that achieves great results 

in very narrow applications but lacks adaptability and autonomy. 

Solid State of Mind introduces Deep Meaning TM , a new AI approach generating 

foundational knowledge that generalizes across any environment. 

“The easiest way to explain how game-changing this is: with deep learning AI, if a 

robot has been taught to grab apples but needs instead to grab cans, you would 

need to retrain it almost from scratch. It is very expensive and very time-consuming,” 

explains Etienne Dumesnil, SSoM CSO and Co-Founder. “In stark contrast, our Deep 

Meaning TM AI technology adapts very quickly to such superficial changes, more like a 

human would.” 

In its latest proof of concept, a reinforcement learning scenario where a rover is 

searching for targets in a first-person 3D environment, Solid State of Mind’s new AI 

demonstrated ground-breaking autonomy in the face of changing environments, outperforming state-of-the-art AI by a landslide. Overall, Solid State of Mind’s AI 

adapted to new environments using 10,000x less trials and 100,000x less energy than 

state-of-the-art AI. These results were vetted by government agencies that partly 

funded the development effort. 

What does this mean for the future of AI? 

The team at Solid State of Mind, comprised of experts in engineering, robotics, 

computer science, neuroscience and cognitive psychology, believe this can help 

industries of all aspects of life, in addition to the tech industry. 

For example, video game difficulty levels can evolve based on the players’ skills and 

performance; they can help teachers assess and understand the knowledge gap of 

their students, and the Medtech industry can benefit from autonomous wearable 

devices which can target, understand, flag and help fix deviations from healthy 

patterns. These are just a few possible scenarios. 

What’s next for the company? 

Solid State of Mind is in the process of completing the project with funding from 

Sustainable Development Technology Canada, an independent federal foundation 

that funds Canadian small and medium-sized enterprises (SMEs) advancing 

innovative technologies that have the potential to demonstrate significant 

environmental and economic benefits to Canada. 

The company currently has five patents at different stages and is currently seeking a 

SEED investment to accelerate research, development and productization, to 

engage customers for initial deployments of its technology, and to secure more IP. 

ABOUT SOLID STATE OF MIND 

Founded in 2020, Solid State of Mind is at the forefront of the next big revolution in 

AI. Its interdisciplinary team, composed of experts in cognitive psychology, 

neuroscience, engineering, physics, and robotics, delivers an artificial general 

intelligence technology that allows systems to adapt in real time to changing 

environments. Its AI solutions work at low power and independently of the cloud. For 

further information: https://solidstateofmind.com/ 

-30-

For more information or interviews, please contact: 

Maxime Julien Founder & CEO pr@solidstateofmind.com Cell: +1 514 295-4075

---

### The Real Maxime Podcast | Podcast on RSS.com
*1,388 words* | Source: **EXA** | [Link](https://rss.com/podcasts/therealmaxime/)

*   ### Season 3

*   [![Image 1](https://img.rss.com/therealmaxime/252/ep_cover_20240603_070622_d0144310543c608253e719896b6a639a.png) In this episode, we are joined by Kareem Saleh, Founder and CEO of FairPlay, the world's first Fairness-as-a-Service company. Financial institutions use FairPlay’s APIs to embed fairness considerations into their marketing, underwriting, pricing, and collections algorithms as well as to automate their fair lending compliance. In this insightful conversation, we discuss the challenges and triumphs of building a technology-driven solution to one of today's most pressing issues in financial services. Kareem's story is a compelling blend of personal experience and professional achievement. Tune in as we cover Kareem’s journey from growing up in the vibrant and diverse city of Chicago, to helping negotiate the Paris Climate Agreement serving in the Obama Administration, and before diving into AI and machine learning.](https://rss.com/podcasts/therealmaxime/1508967/)
*   ### Season 2

*   [![Image 2](https://img.rss.com/therealmaxime/252/ep_cover_20240504_120511_ea66c5ba3e1d337dd91544007a282ae4.jpg) In this episode, we are joined by Anna Garcia, Founding Managing Partner of Altari Ventures, an exciting emerging venture capital manager specializing in enterprise Fintech at the earliest stages. Altari Ventures seeks to invest in B2B startups focused on data-driven enterprise intelligence, capital markets and asset management technology, CFO tech stack, embedded finance, and decentralized or centralized financial infrastructure convergence. In this insightful conversation, we learn about Anna’s unique international upbringing and education, discuss how her successful Wall Street career prepared and still educates her unique underwriting approach, and hear what meaningful enterprise trends in financial services have the potential to create substantial economic value for technology investors. Tune in as we cover Anna’s journey from working her way up on the trading floor at Merrill Lynch, to a successful foray into angel investing that encouraged her to pursue her entrepreneurial calling.](https://rss.com/podcasts/therealmaxime/1464738/)
*   [![Image 3](https://img.rss.com/therealmaxime/252/ep_cover_20240312_040355_8589731fe242a8ca3b443400862f8821.png) In this episode, we are joined by Michael Broughton, Thiel Fellow and Founder of Altro, a Y Combinator Class of 2020 startup backed by Pendulum, Marcy Ventures, Citi Ventures, Black Capital Fund, Concrete Rose Fund that uses recurring monthly expenses, including rent and subscriptions like Netflix or Spotify, to build one’s credit. While attending USC, Michael was denied a $10k loan needed to cover the remainder of his tuition due to family finances and a lack of credit history. This frustrating catch-22 inspired Michael to create Altro, a business focused on financial inclusion. In this insightful conversation, we discuss the potential of innovation to address financial inclusion, the importance of personal storytelling in pitching investors, the power of mentors and human capital scaling, and how to separate hype from execution in a new era of scarce capital. Tune in as we cover Michael’s journey from his upbringing in Korea and Japan growing up in a military household, his admission to USC and Altro’s initial breakthrough with Marcy Ventures that encouraged him to drop out to pursue his entrepreneurial calling.](https://rss.com/podcasts/therealmaxime/1386199/)
*   [![Image 4](https://img.rss.com/therealmaxime/252/ep_cover_20240211_040222_16f344affa99ea6e65e6c9addf286ce8.png) In this episode, we are joined by Caleb Avery, Founder and CEO of Tilled, a PayFac-as-a-Service platform that allows B2B SaaS companies to monetize payments that pass through their platforms. Caleb is one of the most articulate thought leaders when it comes to deconstructing the mechanics of the payment industry. He founded Tilled in 2019, drawing on nearly a decade of experience advising merchants and software businesses on optimizing their payment processing. He believes in enabling Independent Software Vendors (ISVs) to retain the majority of revenue from payments, a principle that has shaped Tilled's development as a comprehensive payment solution that does not compromise on technology, user experience, or financial benefits. Tune in as we cover Caleb’s journey from an early entrepreneur with a passion for golf to a leader in the Fintech space. We'll discuss the influence of sports on leadership and team dynamics, the Fintech industry's response to changing customer demands and behaviors, and the future of payment methods, including cryptocurrencies.](https://rss.com/podcasts/therealmaxime/1340989/)
*   [![Image 5](https://img.rss.com/therealmaxime/252/ep_cover_20240127_030105_76047daaccf4e397e61f216dea41f9b1.jpg) In this episode, we are joined by Tanvi Lal, a member of the investment team at Intuit Ventures, the financial software leader’s Venture Capital gro

*[... truncated, 5,610 more characters]*

---

### Prosperity For Every Generation
*14,116 words* | Source: **GOOGLE** | [Link](https://www.prosperityforeverygeneration.ca/)

Ramy Nassar, CEO, 1000 Days Out, Kitchener

Jean Michèle, Director, 101105491 Ontario Inc, Montréal

Alan Brailsford, Owner/Operator Rental Housing, 1037652 Ontario Inc, Sioux Lookout

Harry Gandhi, Founder turned Investor, 1517 Fund, Toronto

Adam Parsons, President, 1999609 Ontario Inc., Toronto

Roustem Karimov, Founder, 1Password, Toronto

Sophie Boulanger, CEO, 1VALET, Montréal

Jim Maddocks, CEO, 2312929 Alberta Inc., Calgary

David Jefferies, Owner, 2460771 Inc., Oro Medonte

Darby Sieben, Investor and Advisor, 25237469 Alberta Inc., Calgary

Georges Aneziris, Entrepreneur, 3 Amigos, Brossard

Jamie Catania, CEO, 30 Forensic Engineering, Toronto

Dan Kirchner, Owner, 360hometours.ca Inc, Port Moody

Brayden Kehler, CEO, 3Common, Winnipeg

Paul Bendevis, Data Scientist, 4414131 Nova Scotia Ltd, Halifax

Bryan Wiens, Director, 4532649 Nova Scotia Limited, Halifax

T.J. Donnelly, CEO, 55 Rush & TruckIQ, Toronto

Rob Barlow, CEO, 6Harmonics, Ottawa

Daniel Barankin, CEO, 6ix, Toronto

Maxim Kouxenko, Senior Account Manager, 6ix Inc., Richmond Hill

Jordan Boesch, CEO, 7shifts, Saskatoon

Dave Ganton, VP Partnerships, 7shifts, Ottawa

Gregory Vitale, Owner, 879869 Ontario ltd, Alton

Fab Dolan, CEO, 99 Ravens AI Ltd, Toronto

Louis Lachapelle, CEO, A+, Montréal

Natalie Dakers, Co-Founder and CEO, A2O Advanced Materials Inc., Vancouver

Adam Morand, President, A4 Cyber-Physical Manufacturing Inc., Calgary

Ricky Pedro, CEO, A5+, Montréal

Mitch Johnstone, Founder, Abacus AI Solutions, Calgary

Jerome Konecsni, CEO, ABAzyne Bioscience, Saskatoon

Carl Hansen, CEO & President, AbCellera, Vancouver

Andrew Booth, CFO, AbCellera, Vancouver

Nik Misljencevic, Director, Business Development & Transactions, AbCellera, Vancouver

Graham Craig, Director, Corporate Development, AbCellera, Vancouver

John Fontana, Vice President, ABM Precast Inc, Markham

Graham O'Gallagher, Enterprise Account Executive, Abnormal Security, Toronto

Kate Jakobiec, Fdo, AC, Collingwood

Martin Lebeau, Former CFO, Accedian, Montréal

Patrick Ostiguy, Founder & Ex. Chairman, Accedian, Montréal

Peter Horst, Chief Technology Officer, Accelerant, Ottawa

Ruth Casselman, CEO (Interim), Accelerator Centre, Waterloo

Michael Hershfield, CEO/Founder, Accrue Savings, New York

Peter Seccareccia, Executive Vice President, Co-Founder, ACP Chemicals Inc., Montréal

Antonin G. Bérubé, CEO, Acquisition Podform 3d inc., MONTRÉAL

James Cordero-Barnett, VP Corporate Development, Activate Games, Kitchener

Evan Adcock, Founder, Adcock & Associates Inc, Burlington

Jonathan Ages, Entrepreneur and Investor, Adralis, East York

Denis Astahov, CEO, ADV-IT, Langley

Susy Martins, CEO, Advise2Rise, Kitchener

Dominique Simoneau-Ritchie, Chief Technology Officer, Affinity, Toronto

Steve Robb, President & CEO, AFTI WatchDog, Calgary

Joe Kindness, CEO, AgencyAnalytics, Toronto

Blake Acheson, CTO, AgencyAnalytics, Toronto

Mathieu Allaire, CEO, Agendrix, Sherbrooke

Samuel Roy, Co-Founder and CMO, Agendrix, Sherbrooke

Lyne Landry, Co-Founding Partner, AgeTech Capital, Montréal

Aly Janmohamed, President, Agile Developments, Calgary

Brandon Crossley, CEO, Agilitek Solutions Ltd, Richmond

Adam Morand, CEO, AgriPlay Ventures Inc., Brandon

Vineeta Ahooja, Cardiologist, Ahooja health care, Oakville

Saeed Golzar, Founder & CEO, Airble Aviation Inc., Richmomd

Kevin Brophy, President, Airborne Mechanical Systems Inc., Toronto

P G Schoch, Chairman, AirBoss of America, Newmarket

George Babu, Founder & CEO, Aire Labs, Toronto

Bruce Allen, Principal, Al Andaluse SA, St. Catharines

Courtney Cooper, Partner, Alate, Toronto

Adrian Schauer, CEO, AlayaCare, Montréal

George Psiharis, COO, AlayaCare, North Vancouver

Braydon Myers, Principal, Alcorn Partners, Toronto

Cody Hines, CFO, Alert Labs, Kitchener

Frederic Durocher, Associate, Private Equity, Alfar Capital, Westmount

Fares Kabbani, President, Alfar Capital, Westmount

Allan Benchetrit, CEO, Algolux, Montréal

Alexander Peterson, Enterprise Customer Success Manager, Alida, North Vancouver

Jeff Wasyliw, CFO, Alida Inc., Vancouver

Scott Campbell, Founder, Align Wealth, Edmonton

Alvin Kersting, CAO & Partner, Alliance Group Acquisitions, Mississauga

Melissa Rogers, Sr HRBP Manager, Alludo, Oshawa

Peter Hickey, Founder, Allumiqs Corp, Halifax

Tehmina Shah, Founder, AlphaCQ, Toronto

Steve Palmer, CEO, AlphaNorth Asset Management, Toronto

Dave Berkowitz, Founder, Alta Lake Partners, Vancouver

Nicole Janssen, Co-Founder & Co-CEO, AltaML, Edmonton

Cory Janssen, Co-CEO, AltaML Inc., Edmonton

Digby Leigh, Co-Founder + COO, AltFee, North Vancouver

Scott Leigh, CEO & Co-Founder, AltFee Solutions Inc., North Vancouver

Chris LaBossiere, CEO, Altitude Investments / We Know Training, Edmonton

Alisha Gamble, Manager, program management, Amazon, Toronto

Ferdinand Hingerl, CTO, Ambyint, Calgary

Dominic Becotte, Managing Partner, Amiral Ventures, Montréal

Frederic Bastien, Managing Partner, Amiral Ventures, 

*[... truncated, 105,935 more characters]*

---

### Growth expo: Tomorrow’s big players
*554 words* | Source: **GOOGLE** | [Link](https://websummit.com/summaries/lis25/growth-expo-tomorrows-big-players/)

Web Summit Lisbon 2025: Growth Expo Unveils Future-Shaping Innovations

_(This article was generated with AI and it’s based on a AI-generated transcription of a real talk on stage. While we strive for accuracy, we encourage readers to verify important information.)_

The Web Summit Startup Showcase, hosted by Ms. Rita Picarra, a former Microsoft CFO, presented “tomorrow’s big players” from the Growth Expo. Innovators across AI, fintech, health tech, hospitality, and clean tech delivered concise pitches, showcasing their market-disrupting solutions at Web Summit Lisbon 2025.

Several AI-focused startups demonstrated transformative technologies. Mr. Marco, CEO of Sensay, introduced an AI tool capturing experienced employees’ knowledge into a chatbot for new Gen Z hires, ensuring instant access to company information. Mr. Saad Sohail, Marketing Lead at Grona.ai, presented an AI layer that transforms static websites into dynamic, personalized experiences, aiming for a 20-30% conversion rate increase.

Mr. Maxime Julien, CEO of Solid State of Mind Inc., unveiled “deep meaning” AI, which grounds knowledge in understanding, outperforming current AI with significantly less energy and data. Mr. Kirill Solodskikh, CEO and Co-founder of TheStage AI, showcased ANA, an inference acceleration stack that compresses neural networks, making them 2-3 times cheaper to deploy with “lossless compression.”

In specialized AI applications, Ms. Nour Al Taher, Co-founder/CEO of Intella, tackled Arabic’s underrepresentation, developing the most accurate speech-to-text engine for dialectal Arabic (95.7% accuracy) for call center solutions. Mr. Sanchenba, CEO and founder of CGINSIDE, presented an AI agent simplifying complex government regulations, assisting hospitals with insurance rules.

Fintech and operational efficiency were also key themes. Mr. Roland Schüpfer, CEO of Avendo, detailed an AI platform revolutionizing real estate by connecting buyers and agents, analyzing intent, and identifying potential sellers. Mr. Josh Borg, founder of Investre, addressed the investment fund industry’s outdated systems, providing a regulated DLT-empowered capital market infrastructure for fund token safekeeping and 24/7 trading.

Mr. Murad Mordukhay, Founder of Qencode, offered solutions for video platforms. Their “per title encoding” AI optimizes file sizes by 60% without quality loss, ensuring faster loading and reduced costs. Mr. Vladislav, founder of Tivio Studio, highlighted their award-winning interactive TV technology, integrating multi-camera views, in-stream conversions, payments, and real-time interactive elements for enhanced user engagement.

Workforce and design innovation were also featured. Mr. Lukas Foglar, Co-Founder & CPO of LutherOne, presented an ecosystem predicting organizational futures, with modules generating data for accurate predictions of attrition, burnout, or performance issues up to 14 months ahead. Mr. Adam, founder of UXPilot, presented an AI design tool that transforms ideas into production-ready designs in minutes, using clients’ design systems, boasting 300,000 users and $4.2 million ARR.

Logistics and e-commerce solutions rounded out the showcase. Mr. Christoph Busch, CEO of Maple Aviation, introduced drone logistics for urban traffic. With Europe’s first BVLOS certification, Maple Aviation will transport critical hospital goods in Munich, revolutionizing medical logistics. Ms. Krystel Abi Assi, Founder and CEO of Amazon Sellers Society – Middle East, supports sellers on Amazon in the Middle East, offering accreditation and tools to understand KPIs and profitability.

Finally, Mr. Dongmin Lee, CEO of GoLe Robotics, introduced autonomous mobile robots for night-time construction material transport. These modular robots aim to reduce human labor and shorten construction periods, addressing workforce shortages. Mr. Ivan Marchuk, CEO & Founder of GEMCY, introduced a global digital cooperative fostering collective capital growth through trust and collaboration.

---

### Dealbook IQ 2024
*22,121 words* | Source: **GOOGLE** | [Link](https://cdnc.heyzine.com/files/uploaded/e36a054f6b45e6df090cade36d1edfcc0f986270.pdf)

Dealbook 

## Fall • Winter 2024 Québec, 

# a booming startup 

# ecosystem 

100+ coworking 

spaces 

Wide-ranging 

specializations:  AI, 

quantum computing, life 

sciences, FinTech, etc. 

100+ incubators and 

accelerators across 

Québec 

Population 

8.5 million residents 

(23% of Canada’s population) 

14% of population is foreign-born 

Economy 

$442 billion of the GDP in 2020 

$3.7 billion in foreign direct 

investment 

Strategic location 

17 economic regions and 6 

metropolitan areas 

Sharing a 813-km border with the 

United States 

Commercial gateway between 

America and Europe CHARLINE KEMPTER 

Trade and Innovation Attaché 

(Silicon Valley, CA) 

CARMEN ZANFIRESCU 

Transportation and VC Attaché 

(Silicon Valley, CA) 

SUSAN PAK 

Technology Trade Attaché 

(New York City, NY) 

NOAH OUELLETTE 

Life Sciences, Technology 

and Innovation Attaché 

(Boston, MA) 

# Contact our 

# U.S. Innovation 

# Team Table of 

# Contents 

AEROSPACE & SPACE 

H55 

SHEARWATER AEROSPACE 

VOLTA SPACE TECHNOLOGIES 

AEROPORT AI 

OPERAI 

SOLID STATE OF MIND 

ZENEXT IA 

CALOGY SOLUTIONS 

LETENDA 

NIOSENSE 

AVIATION 

ARTIFICIAL INTELLIGENCE 

AUTOTECH 

7

8

9

10 

11 

12 

13 

14 

15 

16 

CHILLSKYN 

FEX ENERGY 

NOVOPOWER INTERNATINONAL 

SAF+ INTERNATIONAL GROUP 

WATTBYWATT 

DIAMENTIS 

DITCH LABS 

FEMTHERAPEUTICS 

LIVINGSAFE 

MOMENTUM HEALTH 

OHMIC TECHNOLOGIES 

FRËTT ENERGY 

DIGITAL HEALTH 

KENTO HEALTH 

23 

24 

27 

28 

29 

30 

31 

32 

34 

36 

37 

25 

33 

BIOTECH 

APLANTEX 

BIOMIMIR 

17 

PAPERPLANE THERAPEUTICS 

QUEVA 

TOTUM TECH 

38 

39 

40 

IMMUGENIA 

TATUM BIOSCIENCES 

18 

21  VITALTRACER  41 

CLEANTECH & SUSTAINABILITY 

CHALUMEAU  22 

FTEX  26 

NEUROSERVO 

19 

20 

LUNABILL  35 EDTECH 

FABLI 

VLVT 

ENTERPRISE / SAAS 

HIVELIGHTER 

KIND INNOVATIONS (WORKIND) 

MODA MATCH 

OVA 

STRATEGIC THINKING SYSTEMS 

STREAMFORGE 

BERKINDALE ANALYTICS 

HAPPLY AI 

OXIA INITIATIVE 

EEVA 

NURAU 

FINTECH 

43 

44 

46 

47 

48 

50 

51 

52 

53 

54 

55 

45 

49 

GIS & GEOINT 

AYE3D 

LATENCE TECH 

MARKETPLACE 

GO MATERIALS INC 

HINT 

MEDTECH 

ENCEPHALX 

MICROELECTRONICS / SEMICONDUCTORS 

AWL ELECTRICITY 

DIGITHO TECHNOLOGIES 

IOT / CONNECTED DEVICES 

MEDIA 

POLYTONE LASER 

59 

60 

63 

65 

66 

64 

FEMTUM  67 

FOOD & BEVERAGE TECH 

BELLO 

OPALIA 

56 

57 

RELOCALIZE  58 

HAILA TECHNOLOGIES 

SOUNDSKRIT 

68 

69 

61 

62 

ROBOTICS 

ACRYLIC ROBOTICS 

HAPLY ROBOTICS 

SAMI AGTECH 

70 

71 

72 

WATCH OUT  73 

SUPPLY CHAIN 

GOMOVE 

INLAN 

74 

75 

ZILIA  42 AEROSPACE & SPACE 

# H55 

Developing certified electric propulsion systems 

for the aviation industry which are clear, quiet, 

safe and affordable 

WHAT WE DO  SEEKING 

ENABLING THE AVIATION 

INDUSTRY TO REACH NET ZERO 

We are looking at growing our footprint in North-

America with the help of US-based investors. 

Goal : 30+ MUSD 

CLEANTECH & SUSTAINABILITY 

h55.ch 

First to offer a certified powertrain under the 

CS-23 category (General Aviation) 

Target certification date from EASA 2025 

High-revenue growth 

100M revenues by 2029 and EBITDA positive 

by 2028 

TOP TAKEAWAYS  STAGE 

Series C 

REPRESENTATIVES 

Martin Larose, CEO 

martin.larose@h55.ch 

LinkedIn 

Stephane Fallot, CFO 

stephane.fallot@h55.ch 

LinkedIn 

Series C Watch our promo video 

Check our pitch 

AEROSPACE & SPACE 

# Shearwater 

# Aerospace 

Smart Flight™ is an AI-powered, weather-

optimized UAV autonomy platform that’s 

redefining UAV operations by offering fully 

automated mission planning and guidance, with 

real-time adaptability. Designed to maximize 

efficiency and minimize operational costs, Smart 

Flight™ seamlessly navigates complex weather 

patterns and optimizes flight paths to harness 

wind power, allowing UAVs to fly longer and 

faster. With the ability to control multiple UAVs 

simultaneously, Smart Flight enables one pilot to 

manage entire fleets, increasing operational 

scalability and delivering substantial cost savings. 

Whether for routine missions or advanced UAV 

operations, Smart Flight™ ensures your fleet 

operates at peak performance, revolutionizing 

how you deploy UAVs in the field. 

WHAT WE DO  SEEKING 

HELPING DRONES FLY FASTER, 

FURTHER, AND MORE OFTEN. 

We are seeking strategic investors and partners in 

the U.S. as we raise a bridge round of $500K (less 

SR&ED credit financing) through a SAFE. 

This funding will help extend our runway from 

February to August 2025, enabling us to finalize 

agreements with initial customers and launch our 

commercial-facing SaaS product. By partnering with 

like-minded investors, we aim to leverage our 

combined expertise and resources to establish 

Smart Flight as a leader in the drone autonomy 

market and capture significant opportunities in the 

rapidly evolving UAV industry. 

shearwater.ai 

Commercial agreements with leading 

companies such as

*[... truncated, 156,016 more characters]*

---

### C2 MONTRÉAL ANNOUNCES THE 25 WINNERS OF THE EMERGING ENTREPRENEURS CONTEST
*3,533 words* | Source: **GOOGLE** | [Link](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html)

C2 MONTRÉAL ANNOUNCES THE 25 WINNERS OF THE EMERGING ENTREPRENEURS CONTEST

===============

[Close menu](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-0)

*   [News](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-news)
*   [Products](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-products)
*   [Contact](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-contact)

[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-default)
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-news)
*   _3_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-1)News in Focus
*   _5_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-2)Business
*   _5_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-3)Science & Tech
*   _5_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-4)Lifestyle & Health
*   _1_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-5)Policy & Public Interest
*   _1_[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-6)People & Culture
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-products)
*   [Explore Our Platform](https://www.newswire.ca/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.newswire.ca/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.newswire.ca/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.newswire.ca/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.newswire.ca/multichannel-amplification/ "Amplify Content ")
*   [IR](https://www.newswire.ca/products/investor-relations/ "IR")
*   [All Products](https://www.newswire.ca/products/all-products/ "All Products")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html#mm-panel-contact)
*   [Sign Up](https://www.newswire.ca/contact-us "Sign Up")
*   [Request a Demo](https://www.newswire.ca/request-a-demo/ "Request a Demo")
*   [Editorial Bureaus](https://www.newswire.ca/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https://www.newswire.ca/contact-us/partnerships "Partnerships")
*   [General Enquiries](https://www.newswire.ca/contact-us/general-enquiries/ "General Enquiries")
*   [Media Enquiries](htt

*[... truncated, 76,042 more characters]*

---

### Canadian Startup Makes Major Breakthrough in Its Mission to Create the Next Generation of AI
*635 words* | Source: **GOOGLE** | [Link](https://markets.financialcontent.com/stocks/article/newswire-2023-2-14-canadian-startup-makes-major-breakthrough-in-its-mission-to-create-the-next-generation-of-ai?CSSURL=36.htm)

**Solid State of Mind's new approach to Artificial General Intelligence is expected to create new product and market opportunities for industries that can benefit from a truly autonomous AI.**

[![Image 1](https://cdn.newswire.com/files/x/55/a6/4a024f8b3fcb27bdd0c29b7432f9.jpg)](https://cdn.newswire.com/files/x/c1/e1/87edf725a68a12ed7bf97869f8d2.jpg)

Logo

**MONTREAL, February 14, 2023 (Newswire.com) -**Solid State of Mind (SSoM), a new Canadian startup based in Montréal, made a major breakthrough towards its objective to create Artificial General Intelligence (AGI) after a successful proof of concept that was completed earlier this year. Its new AGI is expected to revolutionize all industries that can benefit from a highly autonomous artificial workforce.

"Imagine having autonomous mobile robots doing surveillance rounds, inspecting infrastructures, or helping on risky search and rescue missions," shares Maxime Julien, SSoM CEO and Founder. "With the growing labor shortage, this additional help is not only desirable but soon to be essential."

**Moving away from narrow applications and towards AGI**

To date, the tech industry has spent billions of dollars and numerous years of research on deep learning AI, a type of machine learning that achieves great results in very narrow applications but lacks adaptability and autonomy.

Solid State of Mind introduces Deep Meaning TM, a new AI approach generating foundational knowledge that generalizes across any environment.

"The easiest way to explain how game-changing this is: with deep learning AI, if a robot has been taught to grab apples but needs instead to grab cans, you would need to retrain it almost from scratch. It is very expensive and very time-consuming," explains Etienne Dumesnil, SSoM CSO and Co-Founder. "In stark contrast, our Deep Meaning TM AI technology adapts very quickly to such superficial changes, more like a human would."

In its latest proof of concept, a reinforcement learning scenario where a rover is searching for targets in a first-person 3D environment, Solid State of Mind's new AI demonstrated ground-breaking autonomy in the face of changing environments, outperforming state-of-the-art AI by a landslide. Overall, Solid State of Mind's AI adapted to new environments using 10,000x less trials and 100,000x less energy than state-of-the-art AI. These results were vetted by government agencies that partly funded the development effort.

**What does this mean for the future of AI?**

The team at Solid State of Mind, comprised of experts in engineering, robotics, computer science, neuroscience and cognitive psychology, believes this can help industries of all aspects of life, in addition to the tech industry.

For example, video game difficulty levels can evolve based on the players' skills and performance; they can help teachers assess and understand the knowledge gap of their students, and the Medtech industry can benefit from autonomous wearable devices which can target, understand, flag and help fix deviations from healthy patterns. These are just a few possible scenarios.

**What's next for the company?**

Solid State of Mind is in the process of completing the project with funding from Sustainable Development Technology Canada, an independent federal foundation that funds Canadian small and medium-sized enterprises (SMEs) advancing innovative technologies that have the potential to demonstrate significant environmental and economic benefits to Canada.

The company currently has five patents at different stages and is currently seeking a SEED investment to accelerate research, development and productization, to engage customers for initial deployments of its technology, and to secure more IP.

**ABOUT SOLID STATE OF MIND**

Founded in 2020, Solid State of Mind is at the forefront of the next big revolution in AI. Its interdisciplinary team, composed of experts in cognitive psychology, neuroscience, engineering, physics, and robotics, delivers an artificial general intelligence technology that allows systems to adapt in real time to changing environments. Its AI solutions work at low power and independently of the cloud. For further information:[https://solidstateofmind.com/](https://stats.newswire.com/x/html?final=aHR0cHM6Ly9zb2xpZHN0YXRlb2ZtaW5kLmNvbS8&hit%2Csum=WyIzdDc4dGYiLCIzdDc4dGciLCIzdDc4dGgiXQ)

**Contact Information:**

 Maxime Julien 

 Founder & CEO 

[pr@solidstateofmind.com](mailto:pr@solidstateofmind.com)

 (514) 295 4075 
Original Source: [Canadian Startup Makes Major Breakthrough in Its Mission to Create the Next Generation of AI](https://www.newswire.com/news/canadian-startup-makes-major-breakthrough-in-its-mission-to-create-21955850)![Image 2](https://stats.newswire.com/x/im?ref=WyIzdDc4dDQiXQ&hit%2Csum=WyIzdDV5MGIiLCIzdDV5MGUiLCIzdDc4dDQiLCIzdDc4dDUiXQ)

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Prosperity For Every Generation](https://www.prosperityforeverygeneration.ca/)**
  - Source: prosperityforeverygeneration.ca
  - *Francois Fournier, Podcast creator, Les Productions Ian et Frank inc., Lévis ... Maxime Julien, CEO, Solid State of Mind Inc., Mont-Royal. Michael Mat...*

- **[CANADIAN STARTUP MAKES MAJOR BREAKTHROUGH IN THEIR ...](https://solidstateofmind.com/wp/wp-content/uploads/2023/05/PressRelease-SSoM-202302.pdf)**
  - Source: solidstateofmind.com
  - *Solid State of Mind is in the process of completing the project with funding from ... Maxime Julien. Founder & CEO pr@solidstateofmind.com. Cell: +1 5...*

- **[Growth expo: Tomorrow's big players | Web Summit](https://websummit.com/summaries/lis25/growth-expo-tomorrows-big-players/)**
  - Source: websummit.com
  - *Nov 27, 2025 ... Maxime Julien, CEO of Solid State of Mind Inc., unveiled “deep meaning” AI, which grounds knowledge in understanding, outperforming c...*

- **[Dealbook IQ 2024](https://cdnc.heyzine.com/files/uploaded/e36a054f6b45e6df090cade36d1edfcc0f986270.pdf)**
  - Source: cdnc.heyzine.com
  - *Solid State of Mind is seeking to raise $5 million in our current SEED ... Maxime Julien, CEO & Founder. (514) 295-4075. LinkedIn. Etienne Dumesnil, C...*

- **[C2 MONTRÉAL ANNOUNCES THE 25 WINNERS OF THE ...](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html)**
  - Source: newswire.ca
  - *Sep 15, 2022 ... Share this article. Share toX. Share this article. Share toX. MONTREAL, ... Maxime Julien, Founder and CEO, Solid State of Mind Solid...*

- **[Canadian Startup Makes Major Breakthrough in Its Mission to ...](https://markets.financialcontent.com/stocks/article/newswire-2023-2-14-canadian-startup-makes-major-breakthrough-in-its-mission-to-create-the-next-generation-of-ai?CSSURL=36.htm)**
  - Source: markets.financialcontent.com
  - *Feb 14, 2023 ... Solid State of Mind's new approach to Artificial General ... Maxime Julien, SSoM CEO and Founder. "With the growing labor shortage .....*

- **[Des entrepreneurs québécois en quête d'opportunités dans le plus ...](https://www.journaldequebec.com/2024/01/11/des-entrepreneurs-quebecois-en-quete-dopportunites-dans-le-plus-gros-salon-techno-au-monde)**
  - Source: journaldequebec.com
  - *Jan 11, 2024 ... «L'intelligence artificielle est partout au salon, souligne Maxime Julien, président et fondateur de Solid State of Mind, une entrepr...*

---

*Generated by Founder Scraper*
