# Lana Cuthbertson

## Position actuelle

**Titre** : CEO & Founder
**Entreprise** : Areto Labs
**Durée dans le rôle** : 5 years 4 months in role
**Durée dans l'entreprise** : 5 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Areto automatically moderates social media spam, abuse and illegal streams. Areto works with global sports teams and leagues, influencers and the public sector to increase fan engagement, boost revenue, and save marketing team members' time.

## Résumé

Lana is the CEO and Founder of Areto Labs. Areto is an A.I. powered content moderation and fan engagement software platform that automatically removes online abuse, scams, fraud and illegal streaming on social media across the sports, media and public service markets, in order to foster safe audience growth, provide actionable insights, optimize sponsorships, enhance fan engagement and maximize content effectiveness.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAALd7p0BeSJ617uZO5pvmsYeQadI9l8iKKE/
**Connexions partagées** : 44


---

# Lana Cuthbertson

## Position actuelle

**Entreprise** : Areto Labs

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Lana Cuthbertson
*Areto Labs*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Lana Cuthbertson](https://lanacuthbertson.wordpress.com/)
*2024-01-15*
- Category: article

### [About Areto Labs – Medium](https://medium.com/areto-labs/about)
*2025-05-14*
- Category: blog

### [Founder Friday with Kasey Machin of Areto Labs — The51](https://the51.com/51blog/fund-i-areto-labs)
*2024-11-29*
- Category: blog

### [Areto Labs Story | Accelerate Fund](https://acceleratefund.ca/stories/areto-labs/)
*2024-09-11*
- Category: article

### [Areto Labs | LinkedIn](https://ca.linkedin.com/company/aretolabs)
*2023-04-08*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Areto Labs secures $1 million to address online abuse with machine ...](https://betakit.com/areto-labs-secures-1-million-to-address-online-abuse-with-machine-learning/)**
  - Source: betakit.com
  - *Jun 20, 2022 ... Podcast · Newsletter · Quiz · Jobs. Areto Labs secures $1 million ... Areto Labs co-founder and CEO Lana Cuthbertson told BetaKit in ...*

- **[Chancellor's Conversations Podcast | Chancellor and Senate](https://www.ualberta.ca/en/chancellor-and-senate/chancellor/chancellor-conversation-podcast.html)**
  - Source: ualberta.ca
  - *This conversation with Lana Cuthbertson, co-founder of Areto Labs , a company that is finding ways to identify and mitigate online abuse and hate. Are...*

- **[Five Things I've Learned About Using AI for Social Good | New Trail](https://www.ualberta.ca/en/newtrail/people/five-things-ive-learned-about-using-ai-for-social-good.html)**
  - Source: ualberta.ca
  - *May 13, 2022 ... Lana Cuthbertson, '10 BA, didn't set out to create a tech startup ... Areto Labs, where they were later joined by a third co-founder ...*

- **[HerStory Participant Announcement — The51](https://the51.com/news/herstory-participant-announcement)**
  - Source: the51.com
  - *Oct 29, 2021 ... Lana Cuthbertson, Co-founder and CEO Areto Labs. Areto Labs is a B2B SaaS tech startup building apps to help organizations attract an...*

- **[+ SOURCE](https://generalfusion.com/wp-content/uploads/2023/04/Greg-cover-feature-PIVOT-magazine.pdf)**
  - Source: generalfusion.com
  - *Lana Cuthbertson (from left) of Areto Labs, Bobbie Racette of Virtual Gurus and Shelley Kuipers of The51. Page 53. 53. MAY/JUNE 2023 PIVOT. P. H. O. T...*

- **[Lana Cuthbertson: Pioneering Human-Focused Cybersecurity ...](https://www.nasdaq.com/articles/lana-cuthbertson%3A-pioneering-human-focused-cybersecurity)**
  - Source: nasdaq.com
  - *Feb 23, 2023 ... Lana Cuthbertson, the CEO of Areto Labs. ... Our current series features interviews by our interplanetary journalist Spiffy with insp...*

- **[EDMONTON UNLIMITED MEDIA BACKGROUNDER](https://ml.globenewswire.com/Resource/Download/7c3aecc9-0f21-4ba1-bc99-96776aae09d3)**
  - Source: ml.globenewswire.com
  - *Sep 19, 2022 ... Lana Cuthbertson, Co-Founder & CEO of Areto Labs. Through her work ... Interview Requests. Contact: Executive Assistant to the CEO .....*

- **[Areto Labs Story | Accelerate Fund](https://acceleratefund.ca/stories/areto-labs/)**
  - Source: acceleratefund.ca
  - *Lana Cuthbertson, CEO and Co-founder of Areto Labs. From politics to business ... I presented a paper at an AI conference on behalf of ATB's machine ....*

- **[2021 JACAC Student Forum | Prince Takamado Japan Centre for ...](https://www.ualberta.ca/en/prince-takamado-japan-centre/news-events/2021/march/jacac-announcement.html)**
  - Source: ualberta.ca
  - *Mar 16, 2021 ... Title: “Bush Talk: Connection, Body, and Ethics in Digital Learning” ... Lecture 4: Lana Cuthbertson, the CEO and Founder of Areto La...*

- **[Testimonials – CINTONA CONFERENCES AND SUMMITS](https://cintona.com/en/testimonials/)**
  - Source: cintona.com
  - *Aug 18, 2023 ... Thank you for a great conference! Lana Cuthbertson, CEO & Founder, Areto Labs. Thank you one more time for a great event! Magdalena M...*

---

*Generated by Founder Scraper*
