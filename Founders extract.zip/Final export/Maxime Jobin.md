# Maxime Jobin

## Position actuelle

**Titre** : Expert WordPress - Cofondateur et Associé / Cofounder & Partner
**Entreprise** : SatelliteWP
**Durée dans le rôle** : 8 years 11 months in role
**Durée dans l'entreprise** : 8 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

SatelliteWP effectue l'entretien, les mises à jour et vérifie la sécurité et la performance de votre site web utilisant WordPress. Nous possédons une expertise approfondie en ce qui concerne les meilleures pratiques et nous agissons de manière proactive afin de s'assurer de la disponibilité des sites web de nos clients.

--

SatelliteWP specializes in managing Updates, Security and Performance aspects of corporate WordPress websites. We have and in-depth expertise when it comes to best practices as it relates to pro-active management in order to ensure high availability.

## Résumé

Je suis un entrepreneur qui utilise la technologie pour aider les entreprises à accroître leur productivité tout en réduisant leurs risques. Je suis motivé par des scénarios complexes dans le but de réduire les coûts d'exploitation.

Considéré comme un résolveur de problèmes, j'aime analyser la situation actuelle, détecter les problèmes et fournir des solutions technologiques pour les différents besoins des entreprises. Je travaille avec les solopreneurs, les petites entreprises, les banques, les compagnies d'assurances et bien plus encore.

Je suis un programmeur, un analyste, un conférencier, un stratège de la technologie, un entrepreneur et un passionné.

Bref, je suis quelqu'un que vous souhaitez rencontrer. Contactez-moi: m@ximejobin.com

///

I am a entrepreneur that uses technology to help businesses increase their productivity while reducing risk.  I am motivated by complex scenarios and lowering operating costs.

Often seen as a problem solver, I analyze the current situation, detect problems and provide technology solutions for various business needs. I have worked with solo entrepreneurs, small businesses, banks, insurances companies and much more.

I am a programmer, an analyst, a speaker, a technology strategist, an entrepreneur and an enthusiast.

Well, I am someone you want to meet! Just contact me: m@ximejobin.com

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACFBVQBjk84RaZ1mUl69CBqt1cfUe7k1bQ/
**Connexions partagées** : 31


---

# Maxime Jobin

## Position actuelle

**Entreprise** : SatelliteWP

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Maxime Jobin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397379746940211200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH73tx7nurmYA/feedshare-shrink_800/B4EZqjFrVJIIAk-/0/1763672766768?e=1766620800&v=beta&t=GWres42Svk2OBzVOBC9mgscStqiGvruo7fdLi1O8td0 | Elle s'appelle Kyle et elle a changé la vie d'une famille le 12 novembre dernier...

Quatre minutes avant que je prenne la photo, Kyle sautait dans la piscine pour sauver une fillette de 3 ans de la noyade sur le resort Animal Kingdom de The Walt Disney Company.

La mère de la fillette attendait que sa fille glisse pour la récupérer. Pas besoin de veste de flottaison, la mère est devant la glissade.

Puis, un autre enfant de la famille attire l'attention de la mère. Le regard est détourné, la mère s'éloigne de quelques mètres...

... et la petite fille de 3 ans qui glissait tombe dans l'eau au même moment! Il n'y a que 3 pieds d'eau dans la piscine.

Le plaisir est partout dans la piscine : les enfants crient, sautent et s'arrosent. Pendant ce temps, une petite fille ne sachant pas nager se bat pour sa vie, à quelques mètres de sa mère qui ne voit rien de la scène.

Kyle, qui surveille ce coin de la piscine, fait abstraction des cris et des parents qui semblent surveiller leurs enfants.

Honnêtement, je n'ai même pas eu le temps de constater le drame à venir tellement tout est arrivé rapidement.

En moins de 2 secondes, Kyle a appuyé sur le bouton d'alarme et a sauté dans la piscine pour sauver la fillette.

En moins de 30 secondes, plusieurs sauveteurs sont arrivés de « je ne sais où » pour assurer la relève pour surveiller la glissade. La fillette a été remise à sa mère, Kyle a pris la serviette tendue par un autre sauveteur pour s'éponger.

Les nouveaux sauveteurs ont assuré la surveillance et validé ce qui s'était passé. La fillette était saine et sauve, Kyle semblait d'attaque pour la suite.

Aucune sirène, aucun hurlement... aucune tragédie.

Quelques minutes plus tard, Kyle était de retour à son poste, prête à surveiller la piscine en faisant des hochements de tête à répétition pour signifier qu'elle est en mode « alerte ».

Pourquoi je mentionne tout cela?

On sait tous ce qu'est et fait un sauveteur. Dans mon monde d'entretien web, on sait tous ce qu'est un backup et à quoi ça sert. Par contre, il n'y a rien comme un exemple concret pour réaliser son importance.

Ce jour-là, j'ai constaté de mes yeux l'importance des sauveteurs. Je connaissais la théorie, mais là j'ai vécu la pratique!

Entrepreneurs, avez-vous mis en place les mécanismes requis pour éviter une noyade technologique?

====
En tant que cofondateur de SatelliteWP, j’ai à cœur d’offrir des services d’entretien, d’évolution, de performance et de cybersécurité pour les sites #WordPress.

N’hésitez pas à entrer en contact avec moi pour discuter de votre site web. Ensemble, nous pourrons optimiser votre situation et réduire vos risques. | 8 | 0 | 0 | 2w | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:35.814Z |  | 2025-11-20T21:06:08.340Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7361408311461650432 | Text |  |  | La coordination de projets web t'intéresse? L'opportunité est là!
Nous cherchons une personne pour se joindre à notre équipe!

Ici, ça bouge vite : il faut être vif et efficace. Je préfère le mentionner plus tôt que tard! ⚡ 💡 

Par contre, ça vient avec des collègues compétents, dévoués et toujours prêts à aider.

Tu travailleras à la coordination autant pour SatelliteWP que Tonus Marketing.

Nos demandes sont souvent techniques, alors l'expérience dans un poste similaire est primordiale! La personne idéale sera organisée, structurée et capable de communiquer clairement. 🤓 (lunettes facultatives!!)

Ici, pas de vache sacrée. L'innovation et l'évolution sont toujours encouragées. Notre modèle d'affaires est en évolution et il faut être bien dans l'adaptation et le changement! 📈 

Le sens de l'humour est o-bli-ga-toi-re. Ici, pas une journée ne passe sans qu'un collègue joue un tour à un autre! 🤡 

« Est-ce que c'est ouvert à 100 % télétravail ? ». La réponse est... NON. Nous fonctionnons en mode hybride à 2 jours en télétravail. Oui, il est possible d'être 100% au bureau. Plusieurs le font! On discutera du scénario idéal ensemble! 😎 

Si tu t'es rendu jusqu'ici et que ça t'allume, je crois qu'on doit absolument se jaser! 🔥 

On évalue le fit d'un côté comme de l'autre et on débute! Rien de compliqué!

À très bientôt, j'espère! | 4 | 0 | 1 | 3mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:35.815Z |  | 2025-08-13T14:48:29.805Z |  | https://www.linkedin.com/jobs/view/4284432485/ | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7354152812450070529 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGzmrqwIN_Iiw/feedshare-shrink_800/B4EZg8zAqDHgAk-/0/1753366662493?e=1766620800&v=beta&t=HSqINBcTLnvKkyEkmmSMQZLGOQILGBrUFsleVrkAWOY | J'ai entendu parler de Marraine étoilée l'été passé, à la radio. La cause : les jeunes défavorisés.

Depuis plusieurs années, Francine Laplante tient à bout de bras cet organisme qui fait « ce qu'il faut » pour aider les jeunes. Que ce soit les fournitures scolaires, des manteaux et bottes d'hiver ou même une demande qui sort de nulle part... avec Francine, il y a toujours moyen de trouver une solution.

Après quelques dons, j'ai décidé de m'impliquer davantage de manière directe et notre entreprise soutient également cette superbe cause qui fait tout pour assurer un avenir aux jeunes qui ne l'ont pas facile.

Aujourd'hui, la cause est à la une du Journal de Montréal.

La rentrée arrive et l'objectif ambitieux qui avait été fixé n'est pas assez grand pour suffire à la demande.

Honnêtement, je souhaite ne plus jamais lire un truc comme : « On voit des jeunes qui arrivent à l’école avec un sac de plastique au lieu d’un sac à dos ».

La première fois que j'ai rencontré Francine, elle m'a partagé l'histoire d'un jeune qui allait à l'école une journée sur deux. La raison : les 2 enfants de cette famille se partageaient LE manteau d'hiver qui était à leur disposition.

Des histoires du genre, il en existe déjà trop...

Francine est une fonceuse qui ne refuse aucun défi. D'année en année, elle en fait toujours plus. Elle est sur le terrain au quotidien.

Le soutien financier permet de la garder sur le terrain et être constamment dans l'action, dans le concret.

Chaque dollar compte.

Si vous pouvez vous permettre un don, je vous le demande... au nom de ceux qui sont dans le besoin.

https://lnkd.in/eGrkfiAf

Comme entrepreneur et comme résidant du Québec, je me trouve extrêmement choyé. J'ai un toit et je mange 3x par jour. Je me rappelle cette chance chaque fois que je le peux.

Ce n'est pas mon genre de « solliciter mon réseau ». Ceci dit, je le fais aujourd'hui avec humilité parce que d'autres n'ont pas ma chance.

Si tu ne peux faire un don ou donner de ton temps, sache qu'un like, un commentaire ou un partage peut faire bouger les choses positivement. Il n'y a pas de trop petit montant ou de trop petit geste. Même un clic peut changer la donne...

Merci d'avance! | 8 | 0 | 0 | 4mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:35.816Z |  | 2025-07-24T14:17:44.040Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7353126459076407296 | Video (LinkedIn Source) | blob:https://www.linkedin.com/19ad8ec8-1169-4f3e-a449-37be5addc32e | https://media.licdn.com/dms/image/v2/D4E10AQEGOrOwa7mj4Q/ads-video-thumbnail_720_1280/B4EZYRy88XGgAY-/0/1744055331925?e=1765785600&v=beta&t=vQlzzBzTgv_C2Ep0GlT7Dvm8aeN9ErlGuyZjmu784L8 | Un site web, c’est comme une voiture... (oui, j'adore les analogies et les comparaisons!!)

➤ Pas d’entretien = risques de panne, d’accident… et de facture salée. 💸

Sauf qu’il n’y a pas d’alerte « check engine » sur un site WordPress. Pas de voyant rouge qui vous dit « Attention, votre site est à risque! »

Depuis 8 ans, chez SatelliteWP, on s’assure que l'aspect technique de votre site soit géré :
✅ Sauvegardes
✅ Mises à jour
✅ Sécurité proactive
✅ Monitoring 24/7
... et plus!

Résultat : des sites stables, rapides et surtout… rentables.

Vous ne laissez pas votre voiture sans entretien. Pourquoi ce serait différent pour votre site web? 😉

#WordPress #EntretienWeb #Performance #SécuritéNumérique #SatelliteWP

====
En tant que cofondateur de SatelliteWP, j’ai à cœur d’offrir des services d’entretien, d’évolution, de performance et de cybersécurité pour les sites #WordPress.

N’hésitez pas à entrer en contact avec moi pour discuter de votre site web. Ensemble, nous pourrons optimiser votre situation et réduire vos risques. | 0 | 0 | 0 | 4mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:35.816Z |  | 2025-07-21T18:19:22.327Z | https://www.linkedin.com/feed/update/urn:li:activity:7315098271880806400/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7348810375523377152 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ab0d93a2-659b-4cb6-8029-f6bfdd5ebc28 | https://media.licdn.com/dms/image/v2/D4E10AQG-jFK_rf6IyA/ads-video-thumbnail_720_1280/B4EZaR9ZInGQAU-/0/1746205536264?e=1765785600&v=beta&t=PQICMCfufSX31bSLtR4eQcP8PQ-VGhVHInk7QZ9S7jM | Peut-on se débarasser de ce mal nécessaire qu'est l'entretien web, svp? 🙏 

L'entretien de site web, c'est comme l'achat d'une assurance : c'est pas sexy. C'est pas une dépense aussi agréable que l'achat d'une nouvelle voiture ou une sortie au resto. 🚕 

Par contre, comme pour une assurance habitation, c'est vraiment pratique quand le feu prend dans la barraque! 🏠 🔥 🚒 

Je n'ai jamais hésité à assurer ma maison... c'est sûr car la banque n'aurait jamais accepté de nous prêter l'argent pour l'acheter! 🤑 

Ça fera bientôt 8 ans que nous avons lancé SatelliteWP. Après chaque lancement sur le marché d'un produit/service facilitant l'entretien, nous nous sommes demandés si nous étions appelés à disparaître.

La réponse : Non!

Si la technologie devient de plus en plus facile à utiliser, elle crée aussi une nouvelle problématique : n'importe qui peut créer n'importe quoi.

D'un côté, c'est beau! De l'autre, ça vient avec une demande de réparer, de faire évoluer, de configurer et d'adapter les sites WordPress de nos clients à ces réalités qui évoluent constamment. 📈 

Le fait d'arrêter l'entretien ne fait pas stagner un site web, ça le fait reculer! 📉 

Et ça, ça finit toujours par coûter plus cher...

---
Je suis le cofondateur de SatelliteWP, un service d'entretien, d'évolution, de performance et cybersécurité pour sites hashtag
#WordPress.

Je vous invite à connecter avec moi et venir discuter de votre site web. Nous pouvons certainement maximiser votre situation et minimiser votre risque. | 1 | 0 | 0 | 4mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:35.817Z |  | 2025-07-09T20:28:47.819Z | https://www.linkedin.com/feed/update/urn:li:activity:7324116925599408129/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7339297233911111680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFAYLi8V1zdwQ/feedshare-shrink_2048_1536/B4EZdpr8XnHIAo-/0/1749824817310?e=1766620800&v=beta&t=iZGXWMMfXRFiiagbRgutnhDkQdoIsCbaYuEDFSTOCaw | On reconnait la qualité d'une équipe quand ça va mal...

Hier, de nombreux services informatiques sont tombés suite à une panne chez Google Cloud. 👎 

En l'espace de quelques minutes, nous avons été notifiés que des dizaines de sites que nous gérons étaient tombés au combat.

À ce moment, je faisais une marche de 15 secondes entre mon bureau et la cuisine pour aller me chercher un verre d'eau.

Notre responsable de l'entretien m'a arrêté pour m'en informer et me demander comment on pouvait informer nos clients étant donné qu'il n'existait pas de façon simple d'obtenir une liste précise des clients à contacter.

En parallèle, son collègue travaillait à identifier la problématique via les pages de statuts de divers fournisseurs de services.

Au moment où j'allais suggérer de préparer un message « réactif » pour aviser les clients qui nous contacteraient, j'ai appris que notre équipe marketing était déjà à l'oeuvre pour rédiger une communication pour nos clients. ✍ 

Moins d'une minute plus tard, un premier client nous contactait pour nous informer que son site web ne fonctionnait plus. Nous le savions déjà... mais il n'avait aucune façon de savoir que nous étions en train de gérer le problème!

Moins de 15 minutes plus tard, tout était en oeuvre afin que nos clients soient tenus informés que nous étions au courant, que nous suivions la situation et qu'aucune action n'était nécessaire de leur côté.

On reconnait la force des partenaires quand ça va mal! 💪 

C'était vraiment une fierté de voir à quel point l'équipe était en mode solution pour soutenir nos clients.

Suite aux apprentissages faits hier, nous travaillons, dès ce matin, à documenter et améliorer nos processus afin d'être plus efficaces la prochaine fois! 

Le principal constat : nous n'étions pas équipés pour réagir assez efficacement quand le fournisseur d'un fournisseur flanche. Il nous faut donc une manière d'être plus flexible afin de communiquer plus efficacement.

Bref, nous avons pu rassurer nos clients rapidement, mais les efforts internes pour y arriver peuvent être réduits si on améliore certains trucs.

Nous ne souhaitons jamais de panne, mais la prochaine n'a qu'à bien se tenir!!

---
Je suis le cofondateur de SatelliteWP, un service d'entretien, d'évolution, de performance et cybersécurité pour sites WordPress.

Je vous invite à connecter avec moi et venir discuter de votre site web. Nous pouvons certainement maximiser votre situation et minimiser votre risque. | 15 | 5 | 0 | 5mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.442Z |  | 2025-06-13T14:26:58.113Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7338223048489070593 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkfLn_-4xtdA/feedshare-shrink_800/B4EZdaa.XkHIAk-/0/1749568711128?e=1766620800&v=beta&t=8HgijvZm5mPUAEhqxAyFQw7SsssBNplSfrRHap5CZVg | Bienvenue dans le passé avec votre nouveau site web!

Notre client devait faire une refonte depuis des années et il le savait. Au moment de donner le contrat, nous ne faisions aucune création alors le client a trouvé une autre agence. « Vous allez égalment perdre l'entretien... la nouvelle agence inclut tout. »

Bon... c'était le « hit » à prendre pour être niché. Chaque choix a ses impacts.

Le site web « presque final » a été livré récemment. Comme nous faisions l'entretien de l'ancien site, nous avons été en mesure de constater le travail du nouveau site.

Ouf... bienvenue en 2025... euh... en 2015!! Que dis-je...

Le projet a duré 18 mois. Les intervenants se sont relayés. Les échéanciers n'ont pas été respectés. Le projet n'est pas achevé.

Mais si c'était le pire...

Le thème choisi est mort depuis 5 ans. Avant ça, il était en mode maintenance (on corriges les bogues... mais aucune réelle évolution).

Oui, le nouveau site « presque final » est bâti sur une technologie morte depuis 5 ans.

Ouch!

J'aurais aimé dire  « ça vous apprendra à payer 2000$ pour un site web bilingue », mais le client a payé plus de 10 fois ce montant.

En analysant la situation, je ne sais pas ce que le client aurait pu faire. Le contrat est discutable, mais je ne vois pas comment le client aurait pu repérer les subtilités que nous avons identifiées.

Par contre, il sera impossible disponibles de rendre toutes les nouvelles fonctionnalités de WordPress puisque le thème ne supporte pas Gutenberg et les évolutions des dernières années.

Ce ne sera pas la première fois qu'on voit ça : le client doit faire une refonte technique.

En gros, le visuel risque de demeurer identique. On refera les choix techniques afin de rebâtir le tout de manière à ce que le client puisse manipuler ses contenus lui-même.

De mon côté, ça m'a pris 5 minutes pour constater cette débâcle. Jusqu'à ce qu'on exprime le tout au client, ce dernier croyait que tout était fait correctement et que la suite serait belle...

Avant le début du projet, cela aurait été bien difficile pour le client de savoir ce qui l'attendait. Par contre, un accompagnement externe pour suivre l'évolution du projet et les choix techniques lui aurait coûté quelques milliers de dollars.

À plus de 25 000 $ pour le projet, le client se retrouve dans une position plus que désagréable. 

C'est plate de payer des milliers de dollars qu'une firme externe valide si le projet en fait dans les règles de l'art. Par contre, c'est encore plus plate d'avoir investi/gaspillé des dizaines de milliers de dollars pour se faire livrer un site web qui est 10 ans en retard avec une technologie qui ne peut évoluer.

Ce qui excite les clients : les maquettes et les visuels.

Par contre, rien de cela n'est important quand ce qui se trouve sous le capot ne tient pas la route... | 9 | 17 | 1 | 5mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.444Z |  | 2025-06-10T15:18:32.351Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7335295948639649792 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a8c191a3-5cc0-47cb-bfc6-b389b192c41e | https://media.licdn.com/dms/image/v2/D4E10AQFLk-IH1463aA/ads-video-thumbnail_720_1280/B4EZcwmCgXHsAg-/0/1748866976687?e=1765785600&v=beta&t=r0hDQcdt_LGgE8wmYrho_9Untjy6MNo3zpxbSVl0CHQ | Collègues entrepreneurs, cette publication est très parlante du quotidien, non?

Quand tu penses que ça va bien, c'est que t'es sur le point d'être frappé tout d'un coup! Les petits détails s'accumulent sans que tu ne le vois... et boom! Tout explose en même temps!!

Je suis les aventure de Poches & Fils de plus près depuis mon passage à leur podcast avec Amélie Morency, Pascal Leblanc et Yannick Letendre.

La publication est un beau rappel que l'entrepreneuriat est tout sauf un long fleuve tranquille! C'est quand tu penses que tu contrôles la situation que la vie te ramène à la réalité.

Les deux points qui m'ont le plus marqués en lien avec la vidéo:

1) Le manque de documentation. Jamais payant quand on la crée... qu'on se dit. Mais chez SatelliteWP, on insiste là-dessus depuis nos débuts et ça nous a sauvé tellement de fois. Et si vous avez besoin d'aide, il y a des entreprises qui accompagnent... allo Charles de CHUCK & CO. Transformation numérique!

2) Le facteur vacances. Chaque fois qu'une personne part en vacances, ça expose les trous dans la documentation, le transfert de connaissance et les tâches récurrentes mal expliquées.

Et évidemment, quand ces problèmes surviennent, c'est au même moment où on bat des records de ventes et qu'il faut être encore plus attentif à l'exécution et la productivité.

Bravo à leur équipe d'avoir « steppé up »! On gagne en équipe et on perd en équipe.

Ce sont des défis comme ceux que vous vivez actuellement qui vous forceront, membres de l'équipe, à grandir parce que vous n'aurez pas le choix! La vidéo en fait mention avec ceux qui sont venus en renfort.

Lâchez pas... après la tempête, le soleil apparaîtra et vous serez mieux préparés pour la prochaine!

Bon succès!

---
Je suis le cofondateur de SatelliteWP, un service d'entretien, d'évolution, de performance et cybersécurité pour sites WordPress.

Je vous invite à connecter avec moi et venir discuter de votre site web. Nous pouvons certainement maximiser votre situation et minimiser votre risque. | 16 | 3 | 0 | 6mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.446Z |  | 2025-06-02T13:27:17.364Z | https://www.linkedin.com/feed/update/urn:li:activity:7335279888356016128/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7331345271315910657 | Text |  |  | 2025 ne se passe pas comme prévu...

Certains avancent, certains reculent et les autres stagnent.

Certains font plus de ventes, d'autres meurent à petit feu.

Certains innovent alors que d'autres consolident leurs acquis.

Certains investissent à fond alors que d'autres ont coupé les dépenses au maximum.

En apparence, tout le monde utilise l'intelligence artificielle pour automatiser 100% de leur entreprise sans travailler. En réalité, l'intelligence artificielle n'est qu'un amplificateur : tu faisais bien les choses, tu en accomplis plus de travail de qualité. Tu faisais mal les choses, tu crées des problèmes plus rapidement et en plus grande quantité.

Je sens et je vois de l'urgence.

Mais l'urgence de quoi? Et à quel prix?

J'ai l'impression d'avoir reculé de 20 ans quand je vois les solutions miracles proposées pour tout et pour rien. J'ai fait partie de ceux qui ont cru au "get rich quick" au début des années 2000.

J'ai perdu un temps fou à sauter d'opportunité en opportunité, sans jamais rien finaliser ou accomplir. Je chassais la facilité... sans rien trouver parce que je ne m'investissais concrètement dans rien.

2025 ressemble présentement à un retour à l'époque du "get rich quick" (dans son sens large) où l'adaptation est difficile.

J'ai la chance d'être dans un domaine en constante évolution. Ce que je faisais l'an passé est déjà démodé et on doit se renouveler. La situation actuelle m'est donc familière.

Ce qui est moins familier, c'est la quantité phénoménale de gens/entreprises qui se questionnent sur le "what's next?" et qui sautent partout comme je le faisais en 2000.

Pour moi, c'est un rappel de continuer dans la vision qu'on avait... sans observer le marché au quotidien.

La dernière chose que je me souhaite : retomber dans une spirale équivalente au "get rich quick" que je chassais en 2000...

Rappel à moi-même : La vie n’est pas un sprint. Être premier à la mi-course ne vaut rien si tu ne franchis pas la ligne d’arrivée. | 26 | 8 | 0 | 6mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.447Z |  | 2025-05-22T15:48:42.490Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7310373283059695617 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEJEUAdsPeRJA/feedshare-shrink_1280/B4EZXLBrAGHUAk-/0/1742867968404?e=1766620800&v=beta&t=vkb4rH2Mg4Y9R-VXcwWeEmDMyc2vv9i-yDeDy0l-Vcc | Cette publication de Chrystian Guy me rappelle un moment d'université...

Long story short, j'ai un DEC en informatique et aussi un bac.

Quand j'étais au DEC, notre prof de programmation SQL insistait de manière démesurée (c'était mon opinion à l'époque) sur la structure du code. J'ai fini par prendre le moule et produire du code indenté, lisible et structuré avec une précision dont je suis fier aujourd'hui!

Puis, quelques années plus tard, j'ai fait un bac. J'avais un cours de SQL où je devais produire des requêtes de code. J'ai donc appliqué toute la rigueur apprise dans mon travail. Et, au passage, j'ai relaté des erreurs dans l'énoncé du travail que j'ai communiquées au chargé de cours. Il envoya, chaque fois, les corrections soumises aux autres étudiants. Mon but : remettre un travail parfait.

Puis, lors de la remise de mon travail « parfait », tout était bon (donc 100%), mais j'ai reçu une pénalité de 25% pour avoir « probablement » utilisé un générateur de requêtes, ce qui expliquait la clarté et la structure de mon code. 

Nous étions aux débuts des années 2000, où les logiciels efficaces et gratuits n'existaient pas. Il fallait payer pour tout. J'étais à l'université, pas un sou... et je n'avais jamais vu un générateur de requêtes. Je ne savais même pas que ça existait.

Insulté, j'ai confronté le chargé de cours.

Il m'a avoué qu'il n'avait pas de preuve, que j'avais un travail structuré comme il n'en avait pas vu et que... je devais donc avoir utilisé un outil.

Je me suis battu... et j'ai finalement gagné, faute de preuve.

Mais au final, j'avais quand même été faussement blâmé pour quelque chose que je n'avais pas fait. Il n'avait rien validé et avait tiré sa conclusion.

La technologie est un outil... pas une vérité absolue. Et dans le « 93% des chances que ce soit écrit par ChatGPT » de la publication de Chrystian, il restait quand même un réel 7%!

Ça aurait mérité une validation, non? | 1 | 3 | 0 | 8mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.449Z |  | 2025-03-25T18:53:30.849Z | https://www.linkedin.com/feed/update/urn:li:activity:7310118094704631809/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7305577256976875521 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEJ8axTUEy7Yg/feedshare-shrink_800/B4EZWKeGhbHUAg-/0/1741784902383?e=1766620800&v=beta&t=KdYsE5Uycg1-AVFHDU68jakrKyUuUDJwdzIYUd-o3v8 | Nos amis chez Bras Gauche recrutent!! Superbe opportunité de travailler avec une équipe humaine « qui fait les choses pour les bonnes raisons ».

Je côtoie Najomie depuis des années et la passion mise dans chaque projet m'émerveille chaque fois.

Dépêche-toi avant que le poste ne soit comblé!!! | 5 | 2 | 0 | 8mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.449Z |  | 2025-03-12T13:15:49.125Z | https://www.linkedin.com/feed/update/urn:li:activity:7305575393112014849/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7303830511473311745 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9c426627-d169-4649-b41f-45b01eb0b9b9 | https://media.licdn.com/dms/image/v2/D4E05AQHeA5QLDR5j0Q/videocover-high/B4EZVxrFSPHcBs-/0/1741368884478?e=1765785600&v=beta&t=SwZUPK-TiNht5UgHP2t5c00KLvI1RHud6rxN6Lih8uM | Dans nos têtes, on veut de l'achat local. Mais qu'en est-il réellement quand c'est le temps de sortir notre portefeuille?

Lors de mon passage au podcast « On r'dress ça » de Poches & Fils, j'ai soulevé le point à Anthony et Derek que j'avais remarqué qu'il y avait souvent une différence entre les paroles et les gestes.

Il s'agit d'un extrait coupé, mais je fais référence aux enfants qui sont exploités dans certains endroits. Tout le monde trouve ça scandaleux... mais les gens ne font pas toujours le lien entre le prix alléchant d'un produit et les conditions imposées aux travailleurs.

Poches & Fils a fait le choix de produire localement ses t-shirts. C'est une excellente initiative! Cela vient par contre automatiquement avec un prix plus élevé par t-shirt étant donné les conditions de travail au Québec si on compare avec des entreprises qui achètent leur t-shirts dans d'autres pays.

Pour le consommateur, il a le choix entre 2 produits similaires à des prix pouvant varier de plus de 25%.

Comme les ventes ont ralenti de leur côté dans les dernières années, est-ce que ce choix moralement et éthiquement louable n'est pas en partie responsable de leur ralentissement? Est-ce que les gens sont vraiment prêts à payer plus cher pour leur t-shirt fait au Québec?

La question se pose.

Vous pouvez écouter l'ensemble de la discussion est les autres points débattus avec les excellents Pascal Leblanc, Amélie Morency et Yannick Letendre :

 📽️ Youtube : https://lnkd.in/eXPcmX5J
 🎤 Spotify : https://lnkd.in/emkPjv5T

---
Je suis le cofondateur de SatelliteWP, un service d'entretien, d'évolution, de performance et cybersécurité pour sites WordPress.

Je vous invite à connecter avec moi et venir discuter de votre site web. Nous pouvons certainement maximiser votre situation et minimiser votre risque. | 18 | 3 | 0 | 9mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.451Z |  | 2025-03-07T17:34:52.544Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7274468374443659270 | Text |  |  | Dernière semaine avant de s'effondrer durant les vacances?

On se questionne tous avant d'afficher notre vulnérabilité. Je me lance...

Je suis le style « à fond la caisse », « je n'ai que 2 vitesses : rapide et très rapide », « y'a pas de problème », « si j'ai le temp? je n'ai que ça du temps ». 🏎️ 

Mon corps le sait et me connait. Je le sais, je me connais.

Ça vient avec du bon... comme accomplir beaucoup et avoir le sentiment d'être au « top ». Mais ça vient aussi avec une pression et une culpabilité énorme quand on ne fait rien.

Vendredi sera ma dernière journée avant les vacances. Deux semaines.

Et, comme chaque fois avant des vacances, je me sens invincible, comme si je n'en avais pas besoin. Mais je sais que jeudi et vendredi seront pénibles... 🥱 

Oui, mon corps aura compris que le relâchement s'en vient, me donnera tout ce qu'il a jusqu'à jeudi... et ensuite, je vais me rendre à vendredi « de peine et de me misère ». 🪫 

Honnêtement, ce ne sera pas siiiii pire... mais c'est comme quand on revient d'un voyage dans le sud où on passe de 30°C à -20°C à l'arrivée à Montréal. Les 2 températures ne sont pas extrêmes... mais l'écart de 50° qu'on absorbe en quelques heures est... plus que surprenant! ☀️ ❄️ 

Le repos me fera le plus grand bien, mais je sais que ce sera un challenge de ne pas tenter d'être productif. 

Mon travail est ma passion... la ligne est mince. Une passion qui donne autant qu'elle prend. Nous avons vu plusieurs entrepreneurs « invincibles » prendre des pauses cette année. Peu importe notre situation, nous sommes tous à risque et à surveiller.

Je sais que si je réussis à décrocher convenablement, mon retour sera magique en termes de productivité! C'est ce qui rend la chose encore plus intéressante! 

C'est le concept du « delayed gratitude ». Accepte que ce soit difficile mentalement de décrocher... mais fais-le. Ça te sera rendu x5 en productivité avec un esprit 100% rechargé! 🔋 💪 

J'imagine ne pas être le seul... mais je le souhaite. Ce feeling est loin d'être agréable lorsqu'on fait partie du « j'y vais à fond ».

Au lieu de work hard, play hard. Ce sera worked hard, rest hard. 😴 

Joyeuses fêtes à tous et bon repos à tous ceux qui en ont besoin! 🎄 | 7 | 3 | 0 | 11mo | Post | Maxime Jobin | https://www.linkedin.com/in/maximejobin | https://linkedin.com/in/maximejobin | 2025-12-08T07:13:39.452Z |  | 2024-12-16T17:00:13.554Z |  |  | 

---



---

# Maxime Jobin
*SatelliteWP*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 25 |

---

## 📚 Articles & Blog Posts

### [Maxime Jobin Email & Phone Number | SatelliteWP Expert WordPress - Cofondateur et Associé and Cofounder and Partner Contact Information](https://rocketreach.co/maxime-jobin-email_11550151)
*2025-01-01*
- Category: article

### [maximejobin - Overview](https://github.com/maximejobin)
*2025-01-01*
- Category: article

### [Best Plugins from SatelliteWP with Ranking, Performance - WP Hive](https://wphive.com/authors/maximejobin)
*2022-11-16*
- Category: article

### [A faster WordPress site with Rocket-Nginx 3.0](https://www.satellitewp.com/en/a-faster-wordpress-site-with-rocket-nginx-3-0/)
*2025-02-19*
- Category: article

### [SatelliteWP](https://github.com/satellitewp)
*2025-02-26*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[WAQ 2019 - Revue du jour 2](https://www.satellitewp.com/waq-2019-revue-du-jour-2/)**
  - Source: satellitewp.com
  - *Apr 11, 2019 ... 47% des canadiens ont déjà écouté un podcast et 28% en écoutent régulièrement chaque mois. ... Maxime Jobin est le co-fondateur de Sa...*

- **[WordPress Archives](https://www.maximejobin.com/wordpress/)**
  - Source: maximejobin.com
  - *... SatelliteWP samedi le 11 août à 10h20. Lire la suite · SatelliteWP: L'histoire derrière le lancement. Par Maxime Jobin. Dans WordPress. 3 minutes ...*

- **[Les animateurs - Aucun Hasard](https://www.aucunhasard.com/les-animateurs/)**
  - Source: aucunhasard.com
  - *Maxime Jobin. Abonne-toi. Reste informé quand un épisode sort et accède à du contenu exclusif ! Prénom. Courriel ... Maintenance WordPress SatelliteWP...*

- **[Invité à Pause café avec Naj](https://www.maximejobin.com/entreprenariat/invite-a-pause-cafe-avec-naj/)**
  - Source: maximejobin.com
  - *Sep 8, 2019 ... Suite à cela, Najomie lançait son podcast « Pause ... Maxime Jobin est le cofondateur de SatelliteWP, un service d'entretien pour Word...*

- **[What is the biggest mess you have ever had to clean up? - Quora](https://www.quora.com/What-is-the-biggest-mess-you-have-ever-had-to-clean-up)**
  - Source: quora.com
  - *Mar 14, 2013 ... Maxime Jobin. Co-founder at SatelliteWP (2017–present). · 7y. Related ... I guess my fave cleaning tip is to immerse myself with a po...*

- **[Si j'avais su...](https://www.maximejobin.com/entreprenariat/si-javais-su/)**
  - Source: maximejobin.com
  - *Jul 26, 2023 ... Pendant notre discussion, ça m'a fait réaliser que SatelliteWP ... Google podcasts : Maxime Jobin : pivoter pour mieux avancer. À pro...*

- **[Ils sont ENFIN SUR LA MAP ! - Kim Auclair](https://kimauclair.ca/clients/)**
  - Source: kimauclair.ca
  - *... podcast en plus. Son dévouement à atteindre des résultats concrets est ... Maxime Jobin. Cofondateur et Stratège technologique chez SatelliteWP · ...*

- **[Le Pivot - Changer ou Crever | On R'Dress Ça (Ép. 01) - YouTube](https://www.youtube.com/watch?v=Zl9kGlLVjy4)**
  - Source: youtube.com
  - *Feb 27, 2025 ... ... Maxime Jobin, président de ⁠Satellite WP⁠ 🗣️ Pascal Leblanc ... SatelliteWP 00:50:50 Invité #4 – Pascal LeBlanc : blockchain, hyp...*

- **[Why We Use Kinsta — It Saves Hours of Work ‍ - YouTube](https://www.youtube.com/shorts/cmaH8y2KS9s)**
  - Source: youtube.com
  - *Jun 12, 2025 ... For Maxime Jobin of SatelliteWP, good hosting isn't about raw power ... interview to hear more of Maxime's story. #WordPress ......*

- **[Hébergement WordPress en France - Kinsta®](https://kinsta.com/fr/hebergement-wordpress-en-france/)**
  - Source: kinsta.com
  - *Interviews de Kingpin avec des professionnels francophones de la communauté WordPress ... Entretien avec Maxime Jobin, l'un des cofondateurs de Satell...*

---

*Generated by Founder Scraper*
