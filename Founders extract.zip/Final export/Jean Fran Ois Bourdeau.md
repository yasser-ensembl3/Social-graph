# Jean-François Bourdeau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402474746191552512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e51b7bc0-9914-44db-9edf-f571343fdc2c | https://media.licdn.com/dms/image/v2/D5605AQG21grjR8_cPw/videocover-high/B56ZrFYcGJJQBY-/0/1764248110365?e=1765774800&v=beta&t=l4HCohJ5dckPnKHIsLfOcRLHO7L8URETfJKs6_GmmEE | Are you handing your domain’s identity to hackers — for free?
Check your DMARC configuration today | 1 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.273Z |  | 2025-12-04T22:31:50.822Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402474734791278594 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5614598a-fbe7-4ce1-b541-8af1245c9345 | https://media.licdn.com/dms/image/v2/D5605AQFE3APoj6a5LA/videocover-high/B56ZrFOaDsHYBU-/0/1764245480779?e=1765774800&v=beta&t=pt-UfgtLC_6s16dEW3lrCAB5WeVuzDDyvyNeG-AvDYc | Could your current DMARC policy (or lack of strict enforcement) allow attackers to impersonate your domain in email spoofing attacks? | 0 | 0 | 7 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.274Z |  | 2025-12-04T22:31:48.104Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402308046292451328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/558bd74a-b83a-48ef-850d-0fbec071ee80 | https://media.licdn.com/dms/image/v2/D5605AQFE3APoj6a5LA/videocover-high/B56ZrFOaDsHYBU-/0/1764245480779?e=1765774800&v=beta&t=pt-UfgtLC_6s16dEW3lrCAB5WeVuzDDyvyNeG-AvDYc | Could your current DMARC policy (or lack of strict enforcement) allow attackers to impersonate your domain in email spoofing attacks? | 0 | 0 | 7 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.276Z |  | 2025-12-04T11:29:26.469Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402308023592902656 | Video (LinkedIn Source) | blob:https://www.linkedin.com/183b7bdd-d6be-4edf-91a1-cc76e243c453 | https://media.licdn.com/dms/image/v2/D5605AQG21grjR8_cPw/videocover-high/B56ZrFYcGJJQBY-/0/1764248110365?e=1765774800&v=beta&t=l4HCohJ5dckPnKHIsLfOcRLHO7L8URETfJKs6_GmmEE | Are you handing your domain’s identity to hackers — for free?
Check your DMARC configuration today | 1 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.277Z |  | 2025-12-04T11:29:21.057Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7402308009898795009 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0711d2c3-dae6-4fbd-9436-6605869208c4 | https://media.licdn.com/dms/image/v2/D5605AQHsO0xoA8cXUQ/videocover-high/B56ZrFbZ8FJoBU-/0/1764248887924?e=1765774800&v=beta&t=MZSuAW3fRr59y_oOuWpU390AQQY_G5wiU_A7f4EnLqs | To IT admins: are your users accessing a bunch of websites for personal use, emailing all their friends and family with their corporate eMail address? It's important to limit attack vectors and teach your people to never use their corporate email address for personal use. | 0 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.277Z |  | 2025-12-04T11:29:17.792Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7402307842390573056 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFHDN79TeCq0g/feedshare-shrink_800/B4EZpdmAD0GcAg-/0/1762506834821?e=1766620800&v=beta&t=d_1g7vpnZoAntj79-0i3UDvGbksleiYcyODl6s1VmBA | Well said.... Right on ! | 4 | 1 | 7 | 1mo | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.278Z |  | 2025-12-04T11:28:37.855Z | https://www.linkedin.com/feed/update/urn:li:activity:7392489471960854528/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7402307738304708608 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHVTF4_kijTrg/feedshare-shrink_800/B56ZpZuDIJJsAk-/0/1762441835664?e=1766620800&v=beta&t=8q7hWQ4dEH32outGUNDrwe5ni1EiRUKP7CM3biaG1Pg | Can hackers easily spoof your eMails/domain ? Yes yes,  pretending to be you.. 
Check here 👉 https://dmarcguy.com/ 👈 | 2 | 3 | 7 | 1mo | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.279Z |  | 2025-12-04T11:28:13.039Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7402307687515906048 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fb3daf37-1d97-45be-b240-4ac0264b5194 | https://media.licdn.com/dms/image/v2/D5605AQGWv-Ik27b_Rw/videocover-high/B56ZrDAGK.HYBU-/0/1764208174678?e=1765774800&v=beta&t=4eviW0QhltsBpk5eFk6QgymrOVL_uSLhscUWu2xwNak |  | 1 | 0 | 9 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.279Z |  | 2025-12-04T11:28:00.930Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7402094334181093378 | Text |  |  | TITRE : Une graine rebelle !
Important de travailler dans un environnement "propre" , voir un anecdote amusant !

Depuis que j’ai changé de système d’exploitation, je travaille beaucoup plus avec le clavier et moins la souris.

Ce matin, il m'est soudainement impossible de m'authentifier,  certaines touches ne fonctionnaient plus du tout comme il faut ! Mauvais caractère, etc

J’ai cru que j’avais cassé la configuration du clavier en jouant un peu trop avec des "shorcuts / Bindings, etc ".

Je vais sur un forum pour demander de l’aide et là… je découvre la vérité  tout en discutant avec des Nerds !

Une petite graine (de nourriture !) s’était coincée juste devant la touche Alt Gr droite (celle à droite de la barre d’espacement).

Si la graine avait été sur une lettre normale (A, E, etc.), cette lettre se serait répétée sans arrêt → facile à repérer.

Mais une graine coincée devan Alt Gr, ça bloque la touche sans rien afficher : c’est « invisible » !

Du coup, plein de caractères spéciaux  lorsque je tappais des lettres comme E, Y etc  Ca sorait bizarres  !
Testez vous-même : appuyez sur Alt Gr + e → vous devriez obtenir €

Avec la graine, plus rien ne marchait ! 😅

Moralité : avant de paniquer, regardez autour de vos touches… il y a parfois une graine rebelle ! | 0 | 0 | 0 | 4d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.281Z |  | 2025-12-03T21:20:13.531Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7402075948780810240 | Video (LinkedIn Source) | blob:https://www.linkedin.com/23ac820d-9f58-498c-8065-a37855e62132 | https://media.licdn.com/dms/image/v2/D5605AQGRa0o8jqt76w/videocover-high/B56Zrl0zx_LYBY-/0/1764792419269?e=1765774800&v=beta&t=pn5CZP0Ogu4MNyfbJCW5HfTz6evvp_MIMeL0EWWu9VM | 2 minutes Video for people needing to verify their eMail compliance (SPF/DKIM/DMARC)
Note : Better video quality in the comments. | 0 | 1 | 1 | 4d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.282Z |  | 2025-12-03T20:07:10.110Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7402073185904730112 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQHbYO_IxM2WCA/videocover-high/B56ZrlyS8oLwBU-/0/1764791760909?e=1765774800&v=beta&t=YW7yg4oAbwHSvVhquG-ExqlSos6RaNGRfT-oLhYGTqU | Vidéo de 2 minutes.
Aux gens techniques devant analyser la conformité des courriels (SPF/DKIM/DMARC)
Note : en commentaire, vidéo de meilleure qualité | 0 | 1 | 0 | 4d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.283Z |  | 2025-12-03T19:56:11.389Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7401933721849020416 | Article |  |  | https://lnkd.in/gXvEyxwH | 0 | 0 | 0 | 4d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.283Z |  | 2025-12-03T10:42:00.567Z | https://itsfoss.com/news/privatim-declares-international-cloud-unsuitable/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7401725194937286656 | Article |  |  | While implementing SPF, DKIM, and DMARC provides a robust foundation for email authentication and protection against external spoofing, these mechanisms alone may not address vulnerabilities in internal email routing. A critical oversight in many Microsoft 365 environments is the configuration of Direct Send, a feature that can inadvertently enable unauthorized access and phishing attempts.
https://lnkd.in/gTygSeue | 0 | 0 | 0 | 5d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.284Z |  | 2025-12-02T20:53:23.877Z | https://dmarcguy.com/blog/microsoft-direct-send-dangers |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7401706001286258688 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEQYcOuDese2w/feedshare-shrink_800/B4DZpuWB0dJUAg-/0/1762787860304?e=1766620800&v=beta&t=cJokqCYuYXs7E1pi8nw1A3QN5XhuQQOahD1-l7Sh3hM | Nos médias, universités, fleurons québécois, organisations connues.

Si vous permettez que vos @domaines  soient utilisés pour des campagnes d’hameçonnage, cela par une mauvaise configuration ou par laxisme de votre part, si je vous contacte et que le problème ne se règle pas, prenez pour acquis que je cognerai à la porte un peu plus haut dans la hiérarchie.

Mauvaise approche pour se faire des amis ou clients, bonne approche pour stopper le fléau de l’hameçonnage facilité par un laxisme au niveau de vos configurations DNS/DMARC. | 0 | 0 | 1 | 2w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.285Z |  | 2025-12-02T19:37:07.754Z | https://www.linkedin.com/feed/update/urn:li:activity:7393668177722769408/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7401680824812924928 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQHsO0xoA8cXUQ/videocover-high/B56ZrFbZ8FJoBU-/0/1764248887924?e=1765774800&v=beta&t=MZSuAW3fRr59y_oOuWpU390AQQY_G5wiU_A7f4EnLqs | To IT admins: are your users accessing a bunch of websites for personal use, emailing all their friends and family with their corporate eMail address? It's important to limit attack vectors and teach your people to never use their corporate email address for personal use. | 0 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.286Z |  | 2025-12-02T17:57:05.215Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7401680796534951939 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQG21grjR8_cPw/videocover-high/B56ZrFYcGJJQBY-/0/1764248110365?e=1765774800&v=beta&t=l4HCohJ5dckPnKHIsLfOcRLHO7L8URETfJKs6_GmmEE | Are you handing your domain’s identity to hackers — for free?
Check your DMARC configuration today | 1 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:17.287Z |  | 2025-12-02T17:56:58.473Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7401678824352243712 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQGWv-Ik27b_Rw/videocover-high/B56ZrDAGK.HYBU-/0/1764208174678?e=1765774800&v=beta&t=4eviW0QhltsBpk5eFk6QgymrOVL_uSLhscUWu2xwNak | Can we spoof your email address ?
https://lnkd.in/gWcMyYyv | 0 | 0 | 0 | 5d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.758Z |  | 2025-12-02T17:49:08.268Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7401678468108976129 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQGWv-Ik27b_Rw/videocover-high/B56ZrDAGK.HYBU-/0/1764208174678?e=1765774800&v=beta&t=4eviW0QhltsBpk5eFk6QgymrOVL_uSLhscUWu2xwNak | On peut usurper votre identité / votre adresse courriel ?
https://lnkd.in/gSg6-tNU | 0 | 0 | 0 | 5d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.758Z |  | 2025-12-02T17:47:43.333Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7401640346943733778 | Article |  |  | Cloud storage alternative. In comments you'll see a full comparison with mainstream providers (Google Drive, Dropbox, OneDrive, iCloud)
https://mega.nz/ | 0 | 7 | 0 | 5d | Post | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.759Z |  | 2025-12-02T15:16:14.539Z | https://mega.nz/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7401263869094113280 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQFE3APoj6a5LA/videocover-high/B56ZrFOaDsHYBU-/0/1764245480779?e=1765774800&v=beta&t=pt-UfgtLC_6s16dEW3lrCAB5WeVuzDDyvyNeG-AvDYc | Could your current DMARC policy (or lack of strict enforcement) allow attackers to impersonate your domain in email spoofing attacks? | 0 | 0 | 7 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.759Z |  | 2025-12-01T14:20:15.225Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7401263847245799424 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQHsO0xoA8cXUQ/videocover-high/B56ZrFbZ8FJoBU-/0/1764248887924?e=1765774800&v=beta&t=MZSuAW3fRr59y_oOuWpU390AQQY_G5wiU_A7f4EnLqs | To IT admins: are your users accessing a bunch of websites for personal use, emailing all their friends and family with their corporate eMail address? It's important to limit attack vectors and teach your people to never use their corporate email address for personal use. | 0 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.760Z |  | 2025-12-01T14:20:10.016Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7401263833224400896 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQG21grjR8_cPw/videocover-high/B56ZrFYcGJJQBY-/0/1764248110365?e=1765774800&v=beta&t=l4HCohJ5dckPnKHIsLfOcRLHO7L8URETfJKs6_GmmEE | Are you handing your domain’s identity to hackers — for free?
Check your DMARC configuration today | 1 | 0 | 6 | 1w | Jean-François Bourdeau reposted this | Jean-François Bourdeau | https://www.linkedin.com/in/jfbourdeau1 | https://linkedin.com/in/jfbourdeau1 | 2025-12-08T04:54:20.760Z |  | 2025-12-01T14:20:06.673Z |  |  | 

---

