# Olivier Rousseau

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Activity Messenger
**Durée dans le rôle** : 5 years 2 months in role
**Durée dans l'entreprise** : 5 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

​Activity Messenger is the product that I wish existed when I was starting Sportball back in 2011. ​A simple mobile-first communication tool for Sports & Leisure organizations.
Email/SMS, Online Waivers, Zoom class integration, Automated messages and much more.
AM, as we like to call it, was created — by and for — Sports and Leisure organizations.

## Résumé

About Olivier: I'm the co-founder of Activity Messenger. I also own a multi-franchise business that introduces sports to children from 2-12 years old. Over the last 10 years, my team and I have been able to grow the business to annual revenues exceeding a million dollars with 100+ part-time staff.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAWHczUBmKdhUJqivEhPTtWtl0xsHR47Xxc/
**Connexions partagées** : 12


---

# Olivier Rousseau

## Position actuelle

**Entreprise** : Activity Messenger

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Olivier Rousseau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402034323106979840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGYOEKPXhJiqQ/feedshare-shrink_2048_1536/B4EZrau7sUKgA8-/0/1764606328137?e=1766620800&v=beta&t=ky2scL-B1oqdAgF9dr87t-rLxXMZZfDEtHErPEKedNI | Un autre superbe offsite avec une superbe équipe qui grandit très vite! | 5 | 0 | 0 | 4d | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:20.382Z |  | 2025-12-03T17:21:45.776Z | https://www.linkedin.com/feed/update/urn:li:activity:7401983705776562177/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388615100548419584 | Document |  |  | Superbe opportunité dans une entreprise avec une mission incroyable et une fondatrice en or. Un très beau défi pour quelqu'un qui aime la croissance et les défis qui viennent avec. | 4 | 0 | 0 | 1mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:20.382Z |  | 2025-10-27T16:38:33.801Z | https://www.linkedin.com/feed/update/urn:li:activity:7388588217123627008/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7381357068890423296 | Article |  |  | Nous recrutons un(e) représentant(e) du service client pour nous aider avec la croissance chez Activity Messenger.
N'hésitez pas à partager si vous connaissez quelqu'un!
https://lnkd.in/e-Mthtft

We are hiring a Customer Support representative to continue the growth at Activity Messenger
Feel free to share if you know anyone! | 8 | 0 | 0 | 2mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:20.383Z |  | 2025-10-07T15:57:44.206Z | https://activitymessenger.com/p/BpKBt3B |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7380907523928727552 | Text |  |  | We are hiring a Dev to continue the growth at Activity Messenger
Feel free to share if you know anyone! | 11 | 0 | 1 | 2mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:20.383Z |  | 2025-10-06T10:11:24.335Z |  | https://www.linkedin.com/jobs/view/4310865190/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7303837965485568000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEKuAJnGpdCzQ/feedshare-shrink_800/B4EZVxx7PlGYAg-/0/1741370669014?e=1766620800&v=beta&t=0T5eYjVb4PnlZgW_Ii-2jTsyew4FhVk9jc7-txNVTQY | Avec la guerre tarifaire actuelle, beaucoup de PME et OBNL au Canada cherchent à privilégier des solutions locales. 

Chez Activity Messenger, on permet de remplacer plusieurs outils américains (Mailchimp, Jotform, SurveyMonkey, Eventbrite, Smartwaiver) par une plateforme québécoise tout-en-un.

Au cours des 18 derniers mois, nous sommes passés de 3 fondateurs à une équipe de 15 personnes basée au Canada, principalement au Québec. 

Si vous connaissez une PME ou OBNL qui aimerait migrer vers un outil québécois, n'hésitez pas à partager. 

#PME #AchatLocal #Québec #OBNL | 21 | 1 | 5 | 9mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:23.943Z |  | 2025-03-07T18:04:29.719Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7292581409120993280 | Text |  |  | Activity Messenger est à la recherche de 2 personnes au support client!
On recherche des candidats bilingues, avec de l'expérience dans le sport et les loisirs et qui aiment aider et communiquer directement avec les clients!

N'hésitez pas à partager si vous connaissez quelqu'un! | 20 | 0 | 2 | 10mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:23.944Z |  | 2025-02-04T16:34:57.545Z |  | https://www.linkedin.com/jobs/view/4143645395/ | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7273381625139191808 | Text |  |  | Nous recrutons un développeur chez Activity Messenger! Si vous êtes à la recherche d'un nouveau défi au sein d'une startup québécoise en pleine expansion, faites-nous signe.

We're recruiting a developer at Activity Messenger! If you're looking for a new challenge with a fast-growing Quebec startup, we'd love to hear from you. | 15 | 0 | 3 | 11mo | Post | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/olivier-rousseau-30509627 | 2025-12-08T06:01:23.945Z |  | 2024-12-13T17:01:52.329Z |  | https://www.linkedin.com/jobs/view/4099933542/ | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7381439670573756418 | Text |  |  | We are hiring a Dev to continue the growth at Activity Messenger
Feel free to share if you know anyone! | 11 | 0 | 1 | 2mo | Michael Shpigelman reposted this | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:02.437Z |  | 2025-10-07T21:25:57.982Z |  | https://www.linkedin.com/jobs/view/4310865190/ | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7304045631696764928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEKuAJnGpdCzQ/feedshare-shrink_800/B4EZVxx7PlGYAg-/0/1741370669014?e=1766620800&v=beta&t=0T5eYjVb4PnlZgW_Ii-2jTsyew4FhVk9jc7-txNVTQY | Avec la guerre tarifaire actuelle, beaucoup de PME et OBNL au Canada cherchent à privilégier des solutions locales. 

Chez Activity Messenger, on permet de remplacer plusieurs outils américains (Mailchimp, Jotform, SurveyMonkey, Eventbrite, Smartwaiver) par une plateforme québécoise tout-en-un.

Au cours des 18 derniers mois, nous sommes passés de 3 fondateurs à une équipe de 15 personnes basée au Canada, principalement au Québec. 

Si vous connaissez une PME ou OBNL qui aimerait migrer vers un outil québécois, n'hésitez pas à partager. 

#PME #AchatLocal #Québec #OBNL | 21 | 1 | 5 | 9mo | Michael Shpigelman reposted this | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:08.079Z |  | 2025-03-08T07:49:41.202Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7292582556674240512 | Text |  |  | Activity Messenger est à la recherche de 2 personnes au support client!
On recherche des candidats bilingues, avec de l'expérience dans le sport et les loisirs et qui aiment aider et communiquer directement avec les clients!

N'hésitez pas à partager si vous connaissez quelqu'un! | 20 | 0 | 2 | 10mo | Michael Shpigelman reposted this | Olivier Rousseau | https://www.linkedin.com/in/olivier-rousseau-30509627 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:08.082Z |  | 2025-02-04T16:39:31.143Z |  | https://www.linkedin.com/jobs/view/4143645395/ | 

---



---

# Olivier Rousseau
*Activity Messenger*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 32 |

---

## 📚 Articles & Blog Posts

### [Founder-Led SEO: How to build SEO as a Founder](https://activitymessenger.com/blog/founder-led-seo-how-to-get-started/)
*2025-01-02*
- Category: blog

### [Meet the man building deep tech ventures and spin-offs for IMEC: An interview with Olivier Rousseaux, its Director of Venture Development](https://eicscalingclub.eu/news/meet-the-man-building-deep-tech-ventures-and-spin-offs-for-imec-an-interview-with-olivier-rousseaux-its-director-of-venture-development)
*2024-05-24*
- Category: article

### [Gymnastics Marketing Ideas for your Gym](https://activitymessenger.com/blog/gymnastics-marketing-ideas-for-your-gym/)
*2024-03-02*
- Category: blog

### [8 Best Gymnastics Club Software (In-Depth Comparison)](https://activitymessenger.com/blog/8-best-gymnastics-club-software-in-depth-comparison/)
*2025-05-31*
- Category: blog

### [How to Start a Dance Studio](https://activitymessenger.com/blog/how-to-start-a-dance-studio/)
*2024-07-01*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[4 Best Podcasts for Dance Studio Owners](https://activitymessenger.com/blog/4-best-podcasts-for-dance-studio-owners/)**
  - Source: activitymessenger.com
  - *Apr 20, 2024 ... Written by Olivier Rousseau Olivier is a kids' sports ... Activity Messenger is an all-in-one platform for online registration manage...*

- **[SaaSpasse chez Activity Messenger](https://www.saaspasse.com/startups/activity-messenger)**
  - Source: saaspasse.com
  - *Activity Messenger apparait dans l'épisode 84 du pod, .Olivier Rousseau : 1M ARR, avantage injuste & co-fondateur ≠ CEO. Aperçu. Offres d'emploi. Tech...*

- **[Founder-Led SEO: How to build SEO as a Founder](https://activitymessenger.com/blog/founder-led-seo-how-to-get-started/)**
  - Source: activitymessenger.com
  - *Jan 2, 2025 ... Martin, Michael and I all knew SEO made sense for a product like Activity Messenger. ... Written by Olivier Rousseau Olivier is a kids...*

- **[Nos SaaSpals | SaaSpasse](https://saaspasse.beehiiv.com/c/saaspals)**
  - Source: saaspasse.beehiiv.com
  - *SaaSpals Événements 🎟️Podcast 🎙️. Se connecter. S'inscrire. Meet nos ... Olivier Rousseau, Co-Founder @Activity Messenger · Phil Langlois, Customer .....*

- **[How to send SMS/text messages for Dance Studios](https://activitymessenger.com/blog/sms-text-messages-for-dance-studios/)**
  - Source: activitymessenger.com
  - *Jan 13, 2024 ... Activity Messenger is also a modern Dance studio Software and an ... Written by Olivier Rousseau Olivier is a kids' sports programs ....*

- **[Maxime Courchesne : VC patient chez Investissement Québec ...](https://www.saaspasse.com/episode/maxime-courchesne-vc-patient-chez-investissement-quebec)**
  - Source: saaspasse.com
  - *Olivier Rousseau, co-fondateur chez Activity Messenger ( sur le pod). —Crédits musique. Intro/outro : Miro Chino — pas pire; Merci à ⁠Fair Enough Publ...*

- **[How to Start a Dance Studio](https://activitymessenger.com/blog/how-to-start-a-dance-studio/)**
  - Source: activitymessenger.com
  - *Jul 1, 2024 ... Activity Messenger automates and personalizes communications with integrated email marketing tools. ... Written by Olivier Rousseau Ol...*

- **[Gymnastics Marketing Ideas for your Gym](https://activitymessenger.com/blog/gymnastics-marketing-ideas-for-your-gym/)**
  - Source: activitymessenger.com
  - *Mar 2, 2024 ... At Activity Messenger, we've seen countless businesses use email ... Written by Olivier Rousseau Olivier is a kids' sports programs .....*

- **[Ep.72 - Ludovic Armand : Pussycat origin story & futur de Grip ...](https://www.youtube.com/watch?v=zEAZ5gWBJ5M)**
  - Source: youtube.com
  - *Feb 8, 2024 ... Olivier Rousseau : / olivier-rousseau-30509627 , co-fondateur chez Activity Messenger; Mark Zalzal : / markzalzal , senior data analys...*

- **[How to use AI to market your Dance Studio (with examples)](https://activitymessenger.com/blog/use-ai-to-market-your-dance-studio/)**
  - Source: activitymessenger.com
  - *Mar 19, 2024 ... I use AI tools every day to help market both Activity Messenger and my kids program business. ... Written by Olivier Rousseau Olivier...*

---

*Generated by Founder Scraper*
