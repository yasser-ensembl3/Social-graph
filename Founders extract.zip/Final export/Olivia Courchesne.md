# Olivia Courchesne

## Position actuelle

**Titre** : Co-founder
**Entreprise** : Ritual Films
**Durée dans le rôle** : 1 year 9 months in role
**Durée dans l'entreprise** : 1 year 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Entertainment Providers

## Description du rôle

Content Acquisition:
• Identify and negotiate distribution and licensing agreements with independent filmmakers, studios, distributors and international sales agents.
• Evaluate potential films based on their artistic quality, relevance to our target audience, and overall potential.
Marketing Strategy:
• Develop and implement innovative marketing strategies to promote our films to the Canadian audience.
• Manage partnerships with media outlets and oversee advertising campaigns to maximize the visibility of our productions.


Ritual distributes feature and documentary films intended for theatrical release, video on demand, and streaming platforms. Focused on emerging genres, Ritual provides Canadians with the boldest contents from here and abroad, acclaimed for their originality and vision at the world’s most prestigious festivals.

## Résumé

Mes études de premier cycle en Film Studies (Concordia) m’ont permis non seulement d’assouvir ma cinéphilie, mais aussi de développer mon esprit critique, en abordant le cinéma selon une pluralité d’approches théorique. Depuis, j’ai entamé des études en gestion, dans un programme de deuxième cycle en management (HEC Montréal) dans le but d’acquérir des habiletés en gestion, et pouvoir les mettre à l’œuvre dans le domaine du cinéma et de la culture.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB_RjIkBU18OzLYv_aouknCEzW09PdB92M0/
**Connexions partagées** : 2


---

# Olivia Courchesne

## Position actuelle

**Entreprise** : Ritual Films

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Olivia Courchesne

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393704652300734464 | Text |  |  | Bonjour :) Ritual Films recrute connaissez-vous quelqu’un qui pourrait être intéressé ? | 22 | 1 | 6 | 3w | Post | Olivia Courchesne | https://www.linkedin.com/in/olcourchesne | https://linkedin.com/in/olcourchesne | 2025-12-08T07:19:27.876Z |  | 2025-11-10T17:42:37.498Z |  | https://www.linkedin.com/jobs/view/4335144948/ | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7356768088299577345 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ed172e85-cd33-47e1-925c-0560115e343c | https://media.licdn.com/dms/image/v2/D4E05AQHZk69jYIB5wg/videocover-low/B4EZhh8aaRGcCI-/0/1753989937527?e=1765785600&v=beta&t=Jk9U6jI6CU_rM5MR_gT3GXm8e_pmuEI2jCMs3EdwMPE | Kyuka: Before Summer's End, par Kostis Charamountanis
Le plus beau film du monde (à mon avis) 
En salle avant la fin de l'été... 
🌅 | 6 | 0 | 1 | 4mo | Post | Olivia Courchesne | https://www.linkedin.com/in/olcourchesne | https://linkedin.com/in/olcourchesne | 2025-12-08T07:19:27.877Z |  | 2025-07-31T19:29:54.392Z | https://www.linkedin.com/feed/update/urn:li:activity:7356767091007311873/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7348376253705469952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/af618a4d-0c83-47ea-b481-9660a40627b7 | https://media.licdn.com/dms/image/v2/D4E05AQErSNg7_2grsg/feedshare-thumbnail_720_1280/B4EZfqtLRXG4A0-/0/1751989402075?e=1765785600&v=beta&t=VYjTOQ9sEJInmmccO0gB-tb3aWpxLohvAm1DkrZmYQs | Très fière d’amener ceci au public canadien :)

DOGTOOTH de Yorgos Lanthimos reste aussi troublant, singulier et hypnotique qu’à sa sortie. Un récit à la fois absurde et cruel sur l’isolement, le langage et le contrôle — et le film qui a révélé Lanthimos sur la scène internationale, marquant le début d’un parcours aussi radical qu’influent. L’œuvre de Lanthimos, et l’univers qu’il déploie, occupent depuis des années, une place toute particulière dans ma cinéphilie.

Présentement en salle dans plusieurs cinémas indépendants à travers le Canada, distribué par Ritual Films

#cannesfilmfestival #ritualrelease #cinemaindependant #filmdistribution #cinema | 25 | 1 | 0 | 4mo | Post | Olivia Courchesne | https://www.linkedin.com/in/olcourchesne | https://linkedin.com/in/olcourchesne | 2025-12-08T07:19:27.877Z |  | 2025-07-08T15:43:45.112Z |  |  | 

---



---

# Olivia Courchesne
*Ritual Films*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Leitrim’s young filmmaker remarkable achievement at Fresh Films Ireland 2024](https://www.leitrimobserver.ie/news/home/1490156/leitrims-young-filmmaker-remarkable-achievement-at-fresh-films-ireland-2024.html)
*2024-05-01*
- Category: article

### [Within by Olivia Santelli — Made with Movement](https://movement.so/customers/within)
*2025-06-20*
- Category: article

### [How to Turn Your Daily “Routines” into Intentional Rituals That Can Change Your Life](https://podcasts.apple.com/ie/podcast/how-to-turn-your-daily-routines-into-intentional-rituals/id1493579571?i=1000697301509)
*2025-03-03*
- Category: podcast

### [Olivia Charmaine Is On A Mission To Revolutionise The World With Black Monarch Entertainment - The C Word Mag](https://www.thecwordmag.co.uk/women-in-film/olivia-charmaine-is-on-a-mission-to-revolutionise-the-world-with-black-monarch-entertainment)
*2022-01-21*
- Category: article

### [Olivia C. Davies: Indigenous Contemporary - True Calling](https://truecallingmedia.com/stories/olivia-c-davies-indigenous-contemporary-choreographer-exploring-indigenous-identity-through-dance)
*2023-02-09*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[2024 Nova Scotia Content Market - Attending Delegates - 09 19 24](https://screennovascotia.com/wp-content/uploads//2024/09/2024-Nova-Scotia-Content-Market-Attending-Delegates-09-19-24-1.pdf)**
  - Source: screennovascotia.com
  - *Sep 19, 2024 ... ○ Ritual Films: William Gagnon, Head of Sales; and Olivia ... Company profile: Founded by Olivia Courchesne and William Gagnon, Ritua...*

- **[Profile — Ritual Films - Moving Works that Inspire](https://ritualfilms.ca/profile)**
  - Source: ritualfilms.ca
  - *Olivia Courchesne Co-president, Creative Director Email. Lineup Rebuilding ... © Ritual Films 2025....*

- **[Les distributeurs de films, des rencontres fortuites aux succès de ...](https://www.ledevoir.com/culture/cinema/816543/distributeurs-films-rencontres-fortuites-succes-box-office)**
  - Source: ledevoir.com
  - *Jul 16, 2024 ... Article. Pourquoi faire confiance au Devoir ? Ils passent ... William Gagnon et Olivia Courchesne viennent de démarrer Ritual Films ....*

---

*Generated by Founder Scraper*
