# Artmiz Golkaramnay

## Position actuelle

**Titre** : Founder & VP of Product & Business Development
**Entreprise** : LATYS
**Durée dans le rôle** : 4 years 11 months in role
**Durée dans l'entreprise** : 4 years 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Wireless Services

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABu65bsBX0sO6Dw_N8a6OGx8uiZWSfeOe-w/
**Connexions partagées** : 26


---

# Artmiz Golkaramnay

## Position actuelle

**Entreprise** : LATYS

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Artmiz Golkaramnay

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402766489608417280 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7sZlit7kH2A/feedshare-shrink_800/B4EZrvkM7cKoAg-/0/1764955841120?e=1766620800&v=beta&t=R9du46cXiKNK-LJ4RF9Urxr4rG9tNDOxe22DKmxfgzI | Thrilled to share that LATYS won Rising Community Startup of the Year at the 2025 #Startup Community Awards, last night! 🚀
Huge thank you to Simran, ilias, and the elantech team for an amazing event, and to the community for voting for us.
Most of all: thank you to my incredible LATYS team. You make building a #hardware startup not just possible, but joyful! 💛
Ad astra per aspera | 60 | 13 | 1 | 2d | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:06.761Z |  | 2025-12-05T17:51:07.873Z | https://www.linkedin.com/feed/update/urn:li:activity:7402761516342538241/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402711869670653952 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQERi38Gj0vWhQ/image-shrink_800/B56ZrkaA4CLMAc-/0/1764768617008?e=1765778400&v=beta&t=DjjSmK4HlPynCMHoZC0t-jrZU3AS_vx9iBGPeapYnJw | #opportunityknocks | 2 | 0 | 0 | 2d | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:06.761Z |  | 2025-12-05T14:14:05.465Z | https://www.linkedin.com/feed/update/urn:li:activity:7401976075515523072/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399173160350425089 | Text |  |  | #opportunityknocks to join one of the best teams in town! | 7 | 4 | 0 | 1w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.567Z |  | 2025-11-25T19:52:31.417Z |  | https://www.linkedin.com/jobs/view/4338815622/ | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398822775383228421 | Text |  |  | #opportunityknocks for multiple positions to join an amazing team! | 0 | 0 | 0 | 1w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.567Z |  | 2025-11-24T20:40:13.131Z | https://www.linkedin.com/feed/update/urn:li:activity:7398820471741521920/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396660854869508096 | Text |  |  | #opportunityknocks | 1 | 0 | 0 | 2w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.570Z |  | 2025-11-18T21:29:31.114Z | https://www.linkedin.com/feed/update/urn:li:activity:7396635152925417472/ | https://www.linkedin.com/jobs/view/4266372840/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396618736570474496 | Article |  |  | #opportunityknocks | 0 | 0 | 0 | 2w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.570Z |  | 2025-11-18T18:42:09.329Z | https://locusrobotics.com/company/careers/job-openings/job/4960461007 |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394554834890424320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFE5EN4y_GviQ/feedshare-shrink_800/B4EZp5szf8HoAo-/0/1762978381433?e=1766620800&v=beta&t=cTm70B_Ny9Fl6KR064BHqIFJMXsl1KjpPBiNOLSoS5k | 🚨 We’ve been annonymusly nominated!! 
Super stoked & proud to be among the finalists for #startupoftheyear ! If you’d like to show your support for us, *please take the time to vote*. 🗳️ 
Thank you to elantech for their continued dedication to growing and bringing together the #montreal #startup community. | 43 | 4 | 1 | 3w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.575Z |  | 2025-11-13T02:00:56.823Z | https://www.linkedin.com/feed/update/urn:li:activity:7394467284578160641/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7393778736011112449 | Text |  |  | #opportunityknocks to make #impact | 4 | 0 | 0 | 3w | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.576Z |  | 2025-11-10T22:37:00.431Z | https://www.linkedin.com/feed/update/urn:li:activity:7393719489290412032/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391802872385966080 | Text |  |  | #opportunityknocks | 1 | 0 | 0 | 1mo | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.579Z |  | 2025-11-05T11:45:37.833Z | https://www.linkedin.com/feed/update/urn:li:activity:7391588530893922304/ | https://www.linkedin.com/jobs/view/4320770728/ | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391571412819427328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f0b739f5-0efa-4942-b060-2290188e0227 | https://media.licdn.com/dms/image/v2/D4E05AQEUw1hW_90a1g/videocover-low/B4EZpQarEzKkCE-/0/1762285767892?e=1765778400&v=beta&t=aHSaSEETIK9BkY0xCr2fDhr-KwWNousDyFL1OSzN7VM | We've saved our customers a lot of time and money over the years, but the #MDU (read apartment buildings) market is a new one: reach out if you're managing an apartment complex and would like to get your tenants reliable Wi-Fi that won't break your bank 🐖 🚀

#DAS #activeDAS #apartments #wifi #wirelessnetwork #condos | 22 | 0 | 0 | 1mo | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.580Z |  | 2025-11-04T20:25:53.572Z | https://www.linkedin.com/feed/update/urn:li:activity:7391562257236721664/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7387454544898859008 | Text |  |  | #opportunityknocks | 4 | 0 | 0 | 1mo | Post | Artmiz Golkaramnay | https://www.linkedin.com/in/artmizgolkaramnay | https://linkedin.com/in/artmizgolkaramnay | 2025-12-08T05:21:11.581Z |  | 2025-10-24T11:46:55.772Z | https://www.linkedin.com/feed/update/urn:li:activity:7377378821475459072/ | https://www.linkedin.com/jobs/view/4305738794/ | 

---



---

# Artmiz Golkaramnay
*LATYS*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [Startupfest | Artmiz Golkaramnay](https://www.startupfest.com/speaker/2190/artmiz-golkaramnay)
*2024-07-10*
- Category: article

### [Latitud Blog](https://www.latitud.com/blog?2e59bebf_page=16&5139f6c3_page=1)
*2025-06-03*
- Category: blog

### [ArtMiz Media](https://www.youtube.com/@ArtMizMedia)
*2025-05-14*
- Category: video

### [LATYS | LinkedIn](https://ca.linkedin.com/company/latys)
*2023-11-10*
- Category: article

### [LATYS Secures $3 Million in Seed Round Led by Rhapsody Venture Partners — LATYS Intelligence](https://www.latys.ca/blog/latys-secures-seed-funding)
*2023-03-01*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[THE LAUNCH - Discover How LATYS is Bringing Intelligence to ...](https://www.youtube.com/watch?v=4dIwdl6poEk)**
  - Source: youtube.com
  - *Nov 17, 2021 ... This week's episode is the first of the season to feature a TandemLaunch venture! LATYS co-founders, Artmiz Golkaramnay and Gursimira...*

- **[Packet Pushers Pods](https://feeds.packetpushers.net/)**
  - Source: feeds.packetpushers.net
  - *... Artmiz Golkaramnay, Founder of LATYS. Artmiz explains the device's functionality, which includes a directional antenna for focused signal amplific...*

- **[Startup LATYS uses innovative smart RF lenses & mirrors to solve ...](https://wifinowglobal.com/news-and-blog/new-technology-startup-latys-uses-innovative-smart-rf-lenses-mirrors-to-solve-for-wi-fi-dead-zones/)**
  - Source: wifinowglobal.com
  - *Feb 15, 2024 ... ... Artmiz Golkaramnay, Founder & VP of Product & Business Development at LATYS. ... Interview with Airties: Delivering QoE for Deuts...*

- **[Surprisingly versatile LATYS FOCUS 'transmissive RF metasurface ...](https://wifinowglobal.com/news-and-blog/surprisingly-versatile-latys-focus-transmissive-rf-metasurface-boosts-wi-fi-performance-lowers-costs/)**
  - Source: wifinowglobal.com
  - *Dec 30, 2024 ... ... Artmiz Golkaramnay, founder and VP of Product & Business Development at LATYS. ... Interview with Airties: Delivering QoE for Deu...*

- **[Artmiz's Entrepreneurship Story - YouTube](https://www.youtube.com/watch?v=ZrkHsDFHHzM)**
  - Source: youtube.com
  - *Jun 10, 2021 ... 9 out of 10 startups fail. But what if you could flip that script? Meet Artmiz Golkaramnay, the fierce female co-founder of LATYS - a...*

- **[Keynotes - CIoT 2024](https://ciot.dnac.org/2024/keynotes/)**
  - Source: ciot.dnac.org
  - *Bio: Artmiz Golkaramnay is the founder of LATYS Intelligence Inc, a Montreal-based wireless networking company. She earned her BS in Electrical and Co...*

- **[About Us | LATYS](https://www.latysfocus.com/about-us)**
  - Source: latysfocus.com
  - *LATYS is a pioneering start-up founded in 2020 and based in Montréal ... Team. Paul Tornatta CEO. Artmiz Golkaramnay Founder, VP of Product & Business...*

- **[7th Conference on Cloud and Internet of Things](https://nephele-project.eu/sites/nephele/files/public/content-files/2024-10/ciot2024_program_v3.pdf)**
  - Source: nephele-project.eu
  - *Oct 30, 2024 ... 09:00 - 10:00 Keynote #3: IoT Device Performance in a. Non-Reciprocal Wireless Network. Speaker : Artmiz Golkaramnay (LATYS, Canada)....*

- **[Wi-Fi World Congress USA 2024 - Wi-Fi NOW Global](https://wifinowglobal.com/sarasota-2024/)**
  - Source: wifinowglobal.com
  - *Artmiz GolkaramnayFounder, VP of Product & Business Development, LATYS Jenni ... Keynote presentation by Cisco: Wi-Fi for large public venues - with ....*

- **[Technical Paper Program | IEEE 10th World Forum on Internet of ...](https://wfiot2024.iot.ieee.org/program/technical-paper-program)**
  - Source: wfiot2024.iot.ieee.org
  - *... Artmiz Golkaramnay (LATYS, Canada). ConvLSTMTransNet: A Hybrid Deep Learning ... Keynote & Plenary Session · Technical Paper Program · Industry Fo...*

---

*Generated by Founder Scraper*
