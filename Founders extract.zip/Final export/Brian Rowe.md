# Brian Rowe

## Position actuelle

**Titre** : Adjunct Professor
**Entreprise** : Yeshiva University
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Higher Education

## Description du rôle

I teach a graduate capstone in the Data and AI master's program. Students work on research related to the Climate Adaptation Data Platform to apply weather and climate data to solve problems in food security and public health.

## Résumé

We used to treat climate risk as a problem to solve. Today it’s a problem to live with—and to prepare for. Floods, extreme heat and wildfires are arriving faster and in unexpected places, and coarse, regional warnings aren’t giving people the context they need to act.

In Newfoundland in May 2025, the provincial dashboard reported low fire risk even after more than half the year’s average fires had already occurred. That kind of mismatch erodes trust and leaves communities exposed.

At Constellia we took a different approach: hyperlocal sensing + real‑time forecasting. Combining my quantitative‑finance background with an electrical‑engineering foundation, I built an end‑to‑end platform of rugged, low‑power sensors and real‑time analytics that turn local conditions into actionable alerts. Communities deploy networks of devices to monitor infrastructure, air, water and vegetation—so citizens and managers get timely, contextual warnings about floods, wildfires, extreme heat and poor air quality.

If your community needs smarter early warning, let’s connect and discuss a tailored deployment.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADdH-4BLPsRF3PdXd6YO_47q8gIIL4CMSo/
**Connexions partagées** : 10


---

# Brian Rowe

## Position actuelle

**Entreprise** : Constellia

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Brian Rowe

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397358818256535554 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGxQI_O8PktoQ/feedshare-shrink_800/B4EZqiyobWGYAg-/0/1763667776589?e=1766620800&v=beta&t=N0fEQCAx8L2sz1tPsiXAUEc8x-GK728UB5Zu5bw-zlg | My refrigerator died over the weekend. The replacement has a two-sided energy efficiency summary that illustrates how selection bias works. The yellow side is the US version, where this fridge is better than average in terms of energy efficiency. Yet the white side shows it is the least efficient fridge -- in Canada. Same fridge, two very different assessments.

--

Mon frigo est mort ce week-end passé. Le remplacement a un résumé d'efficacité d'energie de deux côtés. Il montre comment le biais de sélection fonctionne. Le côté jaune est americain et le frigo est parmi les meilleurs en concernant l'efficacité d'energie. Pourtant le côté blanc montre qu'il est parmi les pires -- au Canada. Le même frigo, deux jugements différents.

#datascience #statistics #energy #efficiency #ghg #ysk | 9 | 4 | 0 | 2w | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:27.493Z |  | 2025-11-20T19:42:58.553Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396315695459880960 | Text |  |  | Google has been making waves with their weather forecasting algorithms. I often get asked how I'm going to compete with them. It's simple: build hardware that provides hyperlocal data and integrates local knowledge into observation streams and model training.

Just like everyone else, Google's WeatherNext forecasting model relies on satellite data. They have a grid resolution of 0.25°, same as the ECMWF. That means each "pixel" in their model is 784 km^2, which is about the size of NYC or two Montreals. Remember that in urban areas, 1 km^2 can have 20+ microclimates, all of which are averaged out into a single data point.

If you're wowed by Google's marketing, notice how hard it is to find any concrete performance numbers. You have to dig into the actual paper to find that the average improvement over the ECMWF model is 5.8%.

In contrast, our (unoptimized) model that fine tunes the ECMWF model gives an average improvement of 65%. This is why hyperlocal data is so critical to climate adaptation and resilience. Without local monitoring and forecasting, decisions are being made on grossly inaccurate data.

#weatherforecasting #datascience #iot #ai #i #climatechange | 13 | 2 | 1 | 2w | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:27.494Z |  | 2025-11-17T22:37:58.698Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396210827881598976 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFzRIY6vUSAXA/feedshare-shrink_800/B4DZqSejXyJcAg-/0/1763394074933?e=1766620800&v=beta&t=IRI4HRN-ly9b9IKNFUgk0z8jGrgBnF41jslj_LNgw28 | Well folks, we made it to Baffin Island, Nunavut! Changes in the arctic are happening much faster than in other parts of the world. Ice instability and permafrost thaw are two major challenges that are more hazardous due to climate change. These changes impact wildlife, infrastructure, travel, and livelihoods. 

Monitoring infrastructure is essential for every aspect of addressing climate change, from mitigation to adaptation to resilience. Continuous environmental monitoring not only tells us what's changing, but also helps communities prepare for immediate climate hazards and act when they occur.

A key part our thesis is that these activities must be driven by local actors. The phrase "think globally, act locally" is just as relevant today as when I first heard it in probably the 90s. We partner with local organizations to define solutions that are consistent with their culture and practices. We then work with (and train) local entrepreneurs to customize, install, and maintain our devices. This approach builds local capacity and ensures the solution is sustainable over the long term.

#climatechange #arctic #iot #datascience #ai #earlywarningsforall #ew4all | 38 | 4 | 1 | 2w | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:27.494Z |  | 2025-11-17T15:41:16.319Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394127589860188162 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPbDSQIEbzVA/feedshare-shrink_1280/B4EZp0327xKcAs-/0/1762897392160?e=1766620800&v=beta&t=moXltQq0rqy1CD2CCeaixp6O_WfiapPisW0-EMagXv8 | Continuous environmental monitoring in winter conditions is challenging. Cold weather reduces battery capacity by 30% and LiPo batteries do not charge well below freezing. Then you have snow and ice accumulation, not to mention salty ice in coastal areas like the Acadian peninsula.

One of our research projects is to winterize these devices to withstand harsh Canadian winters. This concept uses vacuum insulation to keep the device warm and dry. It holds the complete board plus a large 10,000 mAh battery to run continuously until the sun is high enough in the sky to provide solar charging. Stay tuned as we begin collecting data to compare temperatures inside and demonstrate the viability of this approach!

#iot #winter #canada #newbrunswick #earlywarningsystems #climatechange | 26 | 3 | 2 | 3w | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:27.495Z |  | 2025-11-11T21:43:13.670Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7388978336456404992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFiRK3I9V0ZpA/feedshare-shrink_800/B4EZorslrQKoAg-/0/1761669712222?e=1766620800&v=beta&t=714m5L6PgEsXdmGoKhGm7DgtNtZ2pC4i8u2-zByNJUM | Et voilà ! Un appareil qui mesure et prevoit cinq risques climatiques quelque part vous êtes : des chaleurs extrêmes, des inondations, des sêches, des feu de forêts, et la pollution de l'air. 

--

Current forecasts cannot provide accurate predictions for microclimates, leaving people at risk of climate hazards. Our new design separates the controller from the sensor to improve wireless communication and solar capture while allowing for easy installation of the sensor unit. One device to monitor and forecast five climate risks wherever you are: extreme heat, floods, droughts, wildfire, and air pollution. 

-->

Climate change and climate mitigation often feels overwhelming and bigger than any one of us. It's hard to take action when it feels so abstract and that we have so little control over it. 

Hence, climate action must start with adaptation and resilience. A core part of our vision is to make climate change tangible. We make forecasts hyperlocal and accessible to all. Communities regain their agency and are empowered to take action to protect their family, friends, and neighbors. 

#climatechange #earlywarningsystems #ews4all #iot #datascience #agency #i | 27 | 2 | 2 | 1mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:27.495Z |  | 2025-10-28T16:41:55.990Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7384625500419149824 | Text |  |  | Ravi de partager que on a obtenu une subvention grace au Garage&co. Elle nous aidera à developper la commercialization de notre plateforme et aussi ameliorer nos appareils qui mesurent l'environnement et power nos modeles de risque.

--
Excited to share that we received a grant thanks to Garage&co. The grant will help us commercialize the technology and also improve the hardware portion of our system that measure the environment and power our risk models.


#climateadaptation #ews #ews4all #iot #empowerment | 30 | 8 | 1 | 1mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.074Z |  | 2025-10-16T16:25:19.007Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7383866535578116096 | Document |  |  | Excited to share that Constellia was included in the Montréal International list of exciting startups with ambitious ideas in Montréal!

#montreal #startup #climate #climatetech #cleantech #hardtec #iot #datascience #ai | 25 | 4 | 1 | 1mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.074Z |  | 2025-10-14T14:09:27.688Z | https://www.linkedin.com/feed/update/urn:li:activity:7379502160587235328/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7361130675996921857 | Article |  |  | The time for climate adaptation is now. This year has shown us how hotter temperatures can result in longer drought-like periods coupled with periodic extreme weather. In 2050, Seville, Spain expects to see high temperatures that exceed 50C (122F) AND 20% less rain.

Seville is adapting 3000 year old qanat technology from Persia to help cool outdoor public places. This approach conserves electricity and is equitable, since all people have access to these cool spaces. It is one of many adaptation projects they are pursuing to prepare for this eventual reality. Great to see a forward-looking city using science to improve the lives of all.
--
Le temps pour l'adaptation au climat est maintenant. Cette année a montŕe comment les températures plus élevées peuvent produire des sécheresses plus longues avec courtes rafales de tempêtes extrèmes. En 2050, Seville, Espagne verra des températures hauts qui dépassent 50C et 20% moins de pluie.

Seville adapte une technologie persien il y a 3000 ans à réduir les températures dans les éspaces publics. Cette approche conserve l'éléctricité et est equitable grace à tout le monde ont accès à les éspaces. C'est un parmi tant d'autre projets d'adaptation qu'ils poursuivent à preparer pour cette réalité éventuelle. C'est génial à voir projets comme ça qui utilisent la science à ameliorer les vies de tout le monde.

https://lnkd.in/ep2RHiMW

#climatechange #climateadaptation #heatwave #canicule | 8 | 1 | 1 | 3mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.075Z |  | 2025-08-12T20:25:16.352Z | https://www.cbc.ca/news/science/seville-spain-climate-change-extreme-heat-1.7602428 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7360743643864834049 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH5JOCKfK81Lw/feedshare-shrink_800/B4EZiadVkgGwAk-/0/1754938039465?e=1766620800&v=beta&t=neGAfo39kaEDNAy1sPvg-lE0li424BFC95oKHs3BUrY | When I was younger, Apple represented freedom, independence, and creativity. Their iconic 1984 Superbowl ad underscored this idea that Apple stood for freedom against Big Brother. 40 years later, Apple stands with Big Brother.
--
Quand j'étais plus jeune, Apple signifiait la liberté, l'indépendance, et la créativité. Leur publicité iconique du Superbowl de 1984 a mis en valeur que Apple soutenait la liberté contre Big Brother. Après 40 ans, Apple soutient Big Brother.

https://lnkd.in/eEtaKqMh

#apple #appeasement #1984 | 20 | 0 | 0 | 3mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.076Z |  | 2025-08-11T18:47:20.701Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7351268926091149313 | Article |  |  | Long time environmentalist David Suzuki has declared that "it's too late" to mitigate climate change and the focus needs to shift to climate adaptation. This sobering take has a backdrop of numerous once-in-a-thousand year floods in the USA, more massive wildfires in Canada, and a persistent heat dome in Europe. This year underscores the need to not just have adaptation plans, but to implement those plans, and measure their effectiveness. 

Paper solutions won't help anybody. Every adaptation project needs measurement and analytics to properly quantify its value to ensure promises are being delivered.

https://lnkd.in/djjWU_c9

#climatechange #climateadaptation #iot #sensornetwork | 12 | 0 | 0 | 4mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.076Z |  | 2025-07-16T15:18:11.952Z | https://www.ipolitics.ca/2025/07/02/its-too-late-david-suzuki-says-the-fight-against-climate-change-is-lost/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7308895746408235008 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF6CyQ1TmEzSg/feedshare-shrink_800/B4EZW5p84qGgAk-/0/1742576537669?e=1766620800&v=beta&t=Ya9YUuDL6GKA4xnoXXH7ra7A2IsnAFWx9IX4xWP3O8I | Continuing my previous post, Cypress is currently experiencing a 5.8 sigma event. That should happen once every million years. Recent high temperatures are 65% hotter than the average high temperature for this week, or 12.2 C. Remember when climate models talk about 1.5 C or 2 C warmer, that is a global average. Specific locations experience wildly different effects, which is why site-specific monitoring is so important.

#climatechange #climateadaptation #heatrisk #monitoring #data | 10 | 0 | 0 | 8mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.079Z |  | 2025-03-21T17:02:18.660Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7308893348533026816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHCfocQUdDiEg/feedshare-shrink_800/B4EZW5nxa9HUAk-/0/1742575966381?e=1766620800&v=beta&t=Y23g1s5OeePY9lX9CzJT_MQ-8Y9fFtAzfZZxBQPsr6o | I built Hotter Times almost two years ago to monitor temperature trends around the globe. Never have I seen a whole region (this is Eastern Turkiye, Georgia, etc) show temperature deviations like this. These deviations are compared against the 1980-2009 climate normal. A 4.5 sigma event happens once every 400 years approximately, and a 5 sigma event happens once every 4800 years. Yet these events are happening more and more often and for longer periods of time.

#climatechange #climateadaptation #heatrisk #data
https://lnkd.in/ev6Ypze4 | 11 | 0 | 0 | 8mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.079Z |  | 2025-03-21T16:52:46.962Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7305969965726121987 | Article |  |  | In 2023 I was inspired to build the Climate Adaptation Data Platform after reading about the extreme loss of life in Libya due to a powerful storm. Climate change contributed to the severity of the storm, but the lack of a functioning weather agency is what caused 12,000 unnecessary deaths.

I decided to use my experience forecasting time series data to make weather forecasts and early warnings accessible to all.

Two years later the Trump/Musk Administration is dismantling NOAA and the National Weather Service of the United States of America. That will be almost 20% of staff cut with the latest rounds of layoffs. Nations without functional weather agencies are mostly FAILED STATES.

NOAA costs every American about $1.80 per month. That's less than a Netflix subscription. It takes 500 months of NOAA to cost as much as your iPhone. NOAA isn't government waste; it is a great investment that continues to pay dividends.

https://lnkd.in/gB6GS5vg

#climatechange #weatherforecast #doge | 6 | 0 | 1 | 8mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.080Z |  | 2025-03-13T15:16:18.187Z | https://www.independent.co.uk/news/science/noaa-layoffs-doge-trump-federal-cuts-b2713188.html |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7305584958499155970 | Article |  |  | N'oubliez pas ! Ce soir je parlerai comment on fait science-based outcomes accessible pour tous à le Grand Événement de Propolys - Polytechnique Montréal.

The key to accelerating nature-based solutions is making science-based outcomes easy to calculate. These projects need a lot of devices and a lot of data analytics that are easy to set up and don't cost a fortune. That's what we're doing at Constellia. Come tonight to learn more!

📅 Mercredi 12 mars 2025 | 📍 Polytechnique Montréal
🎟️ Entrée gratuite – Places limitées : https://lnkd.in/eywz6ezG

#climatechange #climateadaptation #startups #iot | 1 | 0 | 0 | 8mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.081Z |  | 2025-03-12T13:46:25.311Z | https://www.eventbrite.ca/e/grand-evenement-annuel-de-propolys-polytechnique-montreal-tickets-1226442966929 |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7303789110303870977 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFyKOpjISXJXA/feedshare-shrink_800/B4EZVxFfWRGYAg-/0/1741359020673?e=1766620800&v=beta&t=35pKNgoPvJOIntd0X5sm3Tk6ybH2Wd_0sUm-ceJpb7Q | If you want to learn more about the risks of heat, here is a great paper that reviews heat stress indicators used worldwide. It highlights some of the challenges communicating extreme heat, particularly the difference in messaging between meteorologists and health officials. 

https://lnkd.in/ePG5AuRC

Most nations near the equator only use temperature instead of incorporating other key factors like humidity or sun exposure, which underestimates heat risk.

Changing the metrics used to report heat risk is a big task that involves multiple government agencies and a lot of data and analysis to show the impacts of a change. We're simplifying this process with our automated insights platform designed specifically for environmental monitoring. 

Every device on our platform acts as an early warning system with analytics that provide weather forecasts and risk models. Even better, multiple risk models can be run simultaneously, making it super easy to compare different heat risk metrics and how they would behave before and during a heat wave.

Making climate change illegal will only cause suffering. Let's work together and use science to save lives (not just human!) and reduce the suffering around us.

#climatechange #climateadaptation #heatwave #heatrisk #ew4all | 5 | 0 | 0 | 9mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.081Z |  | 2025-03-07T14:50:21.736Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7303512600913272832 | Article |  |  | Most people don’t know that in July 2021 my wife and I lost our house due to an extreme climate event. It was a beautiful Federal period brick home built in 1830. We planned to retire and most likely die there.

A freak microburst came through our town and felled a dozen trees on our property alone. One of those fell on our slate roof, opening our house up to the heavens. A week later the remnants of hurricane Elsa came through and delivered even more water into our house. The water became mold, and we were evacuated out of our home. That was the beginning of a three year saga.

During that time we became intimately familiar with the disaster recovery industry. It’s a world where almost everybody is trying to profit off your misfortune. From the airbnbs that housed us to the cleaners, inspectors, contractors, and even the public adjusters that negotiate on our behalf. Even worse, it’s a world where everyone involved has an incentive to create delays and mistakes, because the more problems they create, the more they profit.

Despite pouring our heart and soul into rebuilding our beloved house we gave up on our plan and sold a partially restored home. We decided to move to Montreal for an extended vacation to recharge.

Out of sheer luck, last year I was introduced to the incubator Propolys - Polytechnique Montréal. Without knowing any French, they warmly welcomed me into their program. Over the past year, they enthusiastically provided me with encouragement, guidance, and resources to help me develop a simple idea into a viable business model. I can honestly say the people at Propolys restored my faith in humanity and showed me what true community looks like.

One year later that idea has blossomed into Constellia, a startup registered in Québec, to help Canada and the world adapt to climate change. Join me next week at the Propolys Grand Événement, where I will introduce our environmental monitoring and analytics platform complete with our own custom hardware. Constellia is sharing the stage with nine other Propolys startups, each with their own inspiring story.

Come for the pitches and stay for the community!

📅 Mercredi 12 mars 2025 | 📍 Polytechnique Montréal
🎟️ Entrée gratuite – Places limitées : https://lnkd.in/eywz6ezG

#startup #pitch #inspiration #climatechange | 30 | 7 | 0 | 9mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.082Z |  | 2025-03-06T20:31:36.760Z | https://www.eventbrite.ca/e/grand-evenement-annuel-de-propolys-polytechnique-montreal-tickets-1226442966929 |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7297837695597248512 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQyyRWMBzOUQ/feedshare-shrink_800/B4EZUcgtYTH0Ag-/0/1739940092558?e=1766620800&v=beta&t=FmMFjTqwyfqr03L-GyV5XM_iD00PBa_Jc4ozbAQV7Yg | This put a smile on my face all day. Never underestimate the power of kindness and generosity. 

Even in our darkest days, random acts of kindness have the power to reverberate across the world and remind of us of the joy that we can spread. I'll take that over greed and hate any day. | 18 | 0 | 0 | 9mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.082Z |  | 2025-02-19T04:41:33.898Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7297292642378240000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH1GFjVIS-cZQ/feedshare-shrink_800/B4EZUUw_FYHMAg-/0/1739810141853?e=1766620800&v=beta&t=aHx08684Qlm2usUi53w1ZhWXkKgEZUJ_PAMYcBn4guU | What a treat to discuss with the Minister of the Environment and Mayor Yu of Prince George about climate adaptation and innovative financial mechanisms to fund nature-based solutions. There are so many ways for IOT sensor devices to advance the goals of green infrastructure!
--
C'était très inspirant à discuter avec le Ministière de l'Environnement et Mayor Yu of Prince George sur l'adaptation de climat et des outils financiers innovantes pour financer des solutions fondées sur la nature. Il y a plusieurs moyens à utiliser les apareils IOT de faire progresser les objectifs l'infrastructure verte !

#climatechange #climateadaptation #greeninfrastructure #SCC2025 | 30 | 1 | 0 | 9mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.083Z |  | 2025-02-17T16:35:43.084Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7290094398745321472 | Text |  |  | I have spent the past few days drying soil in my oven to begin some experiments with soil moisture sensors. Two surprising observations:

1. the soil I bought was more than 2/3 water!
2. my apartment smells like a dry sauna

I'm pretty chuffed about one of these.

#science #iot #sensors | 8 | 0 | 0 | 10mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.083Z |  | 2025-01-28T19:52:28.065Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7289668127246725120 | Text |  |  | As numerous public services are being actively dismantled in the USA, the need for viable non-governmental alternatives grows daily. This does not mean a private monopoly, where profit and dominance are the only goals. Rather, there are ways to leverage citizen science to build community-based services that benefit everyone.

The first step for me is archiving public data relevant to early warning systems and nature-based solutions that will help us all adapt to climate change. The next step is using science to usher in accessible and transparent technologies that anyone can use to contribute to the greater good.

For example, this semester the graduate students in my capstone are helping me conduct a study to estimate precipitation using low cost soil moisture sensors. This has the potential to reduce the cost of measuring precipitation significantly and also enabling hyperlocal measurements that can effectively capture microclimates.

#datascience #citizenscience #climatechange #publicgood | 3 | 0 | 0 | 10mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.084Z |  | 2025-01-27T15:38:37.020Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7289074025887092736 | Article |  |  | This research paper shows how off-the-shelf #LLM can already figure out how to replicate itself by writing and debugging code.

Reading through the included log transcript shows the endless persistence and goal-seeking behavior. What are seen as admirable traits in humans is uncanny to see in a LLM.

But just as with humans, pure goal-seeking behavior without any self-reflection or appreciation of the broader world will only accelerate our ruin.

https://lnkd.in/esFWAn5b

#AI #weekend #reading | 3 | 3 | 0 | 10mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.085Z |  | 2025-01-26T00:17:52.218Z | https://arxiv.org/abs/2412.12140 |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7288221779272093696 | Text |  |  | I have noticed that NOAA NCEI servers have been sluggish since late December. I started downloading an initial dataset from NCEI, and I am seeing a ridiculous amount of 503 Service Unavailable errors. To me that indicates a certain urgency on at least archiving datasets to ensure they don't just "disappear".

Over the past six months I've been migrating my weather forecasting models to ECMWF gridded data as a hedge against this scenario. My current focus is on archiving data that augments/complements those datasets:
- long timescale historical datasets 
- hourly observation data
- precipitation data and forecasts

If you think I should archive some other NCEI datasets, let me know!

#data #datascience #weatherforecast #climate #climatechange #ews #publicgood | 4 | 0 | 0 | 10mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.085Z |  | 2025-01-23T15:51:20.791Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7287844224169857024 | Text |  |  | I am considering building an independent mirror of NOAA data. Given that US agencies are already being defunded and public resources being removed, it seems this is a necessary action to ensure that critical public data is accessible to all.

Do you think this is useful or a waste of time?

#data #datascience #publicgood | 23 | 4 | 1 | 10mo | Post | Brian Rowe | https://www.linkedin.com/in/profrowe | https://linkedin.com/in/profrowe | 2025-12-08T07:02:31.086Z |  | 2025-01-22T14:51:04.640Z |  |  | 

---



---

# Brian Rowe
*Constellia*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [1182: It Is so Hard But so Simple: Not Overcomplicating it with Brian Rowe Founder and Owner of Perceivant LLC](https://theentrepreneurway.com/podcast/1182-it-is-so-hard-but-so-simple-not-overcomplicating-it-with-brian-rowe-founder-and-owner-of-perceivant-llc/)
*2019-04-28*
- Category: podcast

### [Exploring the Human Element in Technology Solutions with Brian Rowe](https://www.youtube.com/watch?v=A_lCB429OA4)
*2024-07-07*
- Category: video

### [The New Procurement Regime - Constellia](https://www.constellia.com/news-insights/news-and-blog/the_new_procurement_regime/)
*2025-08-20*
- Category: blog

### [Constellia Becomes Employee-Owned - Constellia](https://www.constellia.com/news-insights/news-and-blog/constellia-becomes-employee-owned/)
*2025-11-12*
- Category: blog

### [News & Blog - Constellia](https://www.constellia.com/news-insights/news-and-blog/)
*2025-04-08*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Brian Rowe Email & Phone Number | Honeywell Vice President of ...](https://rocketreach.co/brian-rowe-email_399138069)**
  - Source: rocketreach.co
  - *Constellia Employee Brian Rowe's profile photo. Brian Rowe. Founder at ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
