# Guillaume Jacquet

## Position actuelle

**Titre** : Executive Member
**Entreprise** : Pavilion
**Durée dans le rôle** : 1 year 9 months in role
**Durée dans l'entreprise** : 1 year 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Think Tanks

## Description du rôle

I'm an Executive member of Pavilion, a global community of Sales, Marketing, RevOps, and Customer Success leaders from the fastest-growing companies worldwide. With a dedicated group of peers, we challenge each other to learn and expand our knowledge, aiming to accelerate growth and efficiency for our companies and our clients.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAASusXMBXadyUL2KxvXHyt2rxF6E21WqwZc/
**Connexions partagées** : 240


---

# Guillaume Jacquet

## Position actuelle

**Entreprise** : Vasco

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Guillaume Jacquet

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389783396417449984 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHjCZ1_EXlqyA/feedshare-shrink_800/B4EZo3I1AdGoAk-/0/1761861654787?e=1766620800&v=beta&t=o-jiskHfnx1xklR_9T7MChealrK49DnwtJgSlkUIIEY | Still riding the high from yesterday 🤩 

RevStar started as an idea that JD Saint-Martin and I kept coming back to:
 ✨ Could we bring the GTM conversation to the forefront in Canada?
 ✨ Could we create a space where GTM operators, founders, and investors talk openly about what it really takes to scale great companies?

Yesterday in Montréal, that idea came to life and honestly, it exceeded anything we imagined.

This city showed up. The energy was electric. The conversations were real. And the ambition in the room? You could feel it.

Huge thanks to the incredible speakers who brought the heat ❤️‍🔥 
Sarah Chmielewski, Jordan CrawfordDoug Bell, Dr. Dan Patterson, Jim Texier, Karamdeep Nijjar, Emily Walsh

And of course, our Headline Speaker Mark Roberge, who stole the show ... 🎤 turning product–market fit and go-to-market fit into clean, actionable math, and reminding us that knowing (and constantly refining) your ICP is everything.

Massive love for Sophie Geoffrion, MBA, PMP, Mélissa Proust, Samuel Jobin-Morissette and our MC Francois Lanthier Nadeau; as well as the Vasco + Boreal Ventures crews who brought this event to life.

We hosted RevStar because we believe Canada is ready to bridge the commercialization gap and we’re proud Vasco could help spark that conversation.

Let’s keep building. Let’s make GTM execution our unfair advantage 🇨🇦 | 215 | 28 | 2 | 1mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:19.138Z |  | 2025-10-30T22:00:57.242Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389261836249878528 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEY-x32X0BZzQ/feedshare-shrink_800/B4EZovua.PGYAk-/0/1761737305401?e=1766620800&v=beta&t=SHdYZr58lKB6AV7XgCiRsaGMetiReDuzz9NVTn3pO2I | Let’s GO 🔥🎸🚀 | 168 | 12 | 2 | 1mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:19.138Z |  | 2025-10-29T11:28:27.608Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7379933745270689792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQElb4dUB58NyQ/feedshare-shrink_800/B4EZmqQe6jKUAg-/0/1759498072133?e=1766620800&v=beta&t=K4_yXkhzWhFrEgaXSEnJcmjbM4Ml4dCTdWHgas4ces8 | Every October it’s the same story:
 📊 Board sets an ARR target.
 😅 RevOps drowns in spreadsheets.
 🤯 Nobody feels confident in the plan.

Anthony Enrico (CEO of LeanScale) and I are done with that loop. Next Thursday we’ll show a simpler way: start with the board goal, work backwards, and build a plan the team can actually deliver (without CFO panic).

If that cycle sounds familiar, come hang out: https://lnkd.in/eYuJSjPQ | 25 | 2 | 0 | 2mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:19.139Z |  | 2025-10-03T17:41:57.411Z | https://www.linkedin.com/feed/update/urn:li:activity:7379869805358768128/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7373717371750092800 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHCwj6yj7E20g/feedshare-shrink_800/B56ZkwVB9bKAAg-/0/1757452444400?e=1766620800&v=beta&t=epnAX_ehKeaiAKCHGNjGFm_QWYEEMHmZOOVSGfEk4no | ⚡️Unmissable! Watch the 2 Legends of GTM Engineering LIVE in action — October 29th! | 9 | 0 | 0 | 2mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:19.139Z |  | 2025-09-16T14:00:18.469Z | https://www.linkedin.com/feed/update/urn:li:activity:7373705976782389248/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7369105657825742851 | Video (LinkedIn Source) | blob:https://www.linkedin.com/450c73b3-2fa7-4b2d-83aa-04f6d54e22a5 | https://media.licdn.com/dms/image/v2/D4E05AQFZvQ9hE5YbqA/videocover-low/B4EZj3mcj5GwCE-/0/1756500709419?e=1765778400&v=beta&t=NfigAJodoc2DDtUabe3IrV3If08uK9r2YYBda186VaQ | When I started my career 15 years ago at Teralys Capital, the Canadian tech ecosystem was still recovering from the 2008 crash. The big issue back then was clear: 𝘄𝗲 𝘄𝗲𝗿𝗲 𝗴𝗿𝗲𝗮𝘁 𝗮𝘁 𝗯𝘂𝗶𝗹𝗱𝗶𝗻𝗴 𝗽𝗿𝗼𝗱𝘂𝗰𝘁𝘀, 𝗯𝘂𝘁 𝘀𝘁𝗿𝘂𝗴𝗴𝗹𝗶𝗻𝗴 𝘁𝗼 𝗰𝗼𝗺𝗺𝗲𝗿𝗰𝗶𝗮𝗹𝗶𝘇𝗲 𝘁𝗵𝗲𝗺.

15 years later, the ecosystem is stronger than ever, but commercialization and GTM scaling are still the biggest blockers in every report I read. 𝗧𝗵𝗲 𝗹𝗲𝗮𝗽 𝗳𝗿𝗼𝗺 𝘀𝘁𝗮𝗿𝘁𝘂𝗽 𝘁𝗼 𝘀𝗰𝗮𝗹𝗲-𝘂𝗽, 𝘁𝗵𝗲𝗻 𝘁𝗼 𝗯𝗶𝗹𝗹𝗶𝗼𝗻-𝗱𝗼𝗹𝗹𝗮𝗿 𝗰𝗼𝗺𝗽𝗮𝗻𝘆, 𝗶𝘀 𝘀𝘁𝗶𝗹𝗹 𝗮 𝗵𝗮𝗿𝗱 𝗼𝗻𝗲.

That’s why I started Vasco: to 𝗵𝗲𝗹𝗽 𝗺𝗮𝗸𝗲 𝗴𝗿𝗼𝘄𝘁𝗵 𝗽𝗿𝗲𝗱𝗶𝗰𝘁𝗮𝗯𝗹𝗲 𝗮𝗻𝗱 𝗯𝗿𝗶𝗱𝗴𝗲 𝘁𝗵𝗮𝘁 𝗴𝗮𝗽.

It’s also why we’re launching 𝗥𝗲𝘃𝗦𝘁𝗮𝗿 ⭐. We’re bringing 𝗔-𝗹𝗶𝘀𝘁, 𝗶𝗻𝘁𝗲𝗿𝗻𝗮𝘁𝗶𝗼𝗻𝗮𝗹 𝘀𝗽𝗲𝗮𝗸𝗲𝗿𝘀 𝘁𝗼 𝗠𝗼𝗻𝘁𝗿𝗲𝗮𝗹. People who’ve scaled globally and are shaping 𝘁𝗵𝗲 𝗻𝗲𝘅𝘁 𝗚𝗧𝗠 𝗽𝗹𝗮𝘆𝗯𝗼𝗼𝗸 𝗶𝗻 𝘁𝗵𝗲 𝗮𝗴𝗲 𝗼𝗳 𝗔𝗜.

If you’re a founder, RevOps or Revenue leader in Canada, this is for you ❤️ | 68 | 6 | 1 | 3mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:19.140Z |  | 2025-09-03T20:35:00.188Z | https://www.linkedin.com/feed/update/urn:li:activity:7368976104927158272/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7358980552047095809 | Article |  |  | Been bingeing Cannonball GTM lately... and wow.

If you think "outbound is dead", you’re probably just not seeing what great messaging looks like today with AI.

Shoutout to Jordan Crawford and Doug Bell for giving away their secrets for the world to see. Vasco friends, this is the kind of thinking we need more of.

👉 https://lnkd.in/e8SH66Pg | 33 | 3 | 0 | 4mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.141Z |  | 2025-08-06T22:01:26.855Z | https://cannonballgtm.substack.com/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7345823232035352576 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0f28935c-27ca-4b9f-8228-3476cdbc4181 | https://media.licdn.com/dms/image/v2/D4D05AQH9ATixSZlnVw/videocover-low/B4DZetBBpzGYCM-/0/1750954447022?e=1765778400&v=beta&t=lTT5uWAF7IYAX23wWYinAhhvzxoNy-RTeF8i32-aoCM | Most of what it takes to get from $1M to $10M ARR follows established patterns. Yet, too many startups try to reinvent the wheel.

This is what I discussed with Pascal Unger on the Focal podcast.

Including a step by step guide of how to remove yourself from the sales process as a founder on the journey to $10M ARR. | 52 | 2 | 1 | 5mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.142Z |  | 2025-07-01T14:38:57.313Z | https://www.linkedin.com/feed/update/urn:li:activity:7345783273328971776/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7343608966406438912 | Article |  |  | NEW FEATURE DROP: Activities SLA is now live in Vasco 🔔

We built it to solve a painful reality in SaaS:
📉 Most sales teams give up after just 1.7 follow-ups
📉 Average response time to a new lead? 40+ hours
📈 But you’re 21x more likely to convert if you respond in under 5 minutes

👉 That’s a massive execution gap.

Activities SLA closes it. Here's how:
✅ Define outreach rules: number of touches, time windows, and channels
🤖 Get recommendations from Gama, our AI agent, based on what works
🧠 Auto-track all activity: no more guessing or manual logging
📊 See SLA scores by rep, team, or account
🔔 Get alerts in Slack + daily Digest = total visibility

It’s a real handshake between marketing and sales.
No black boxes. No excuses. Just accountability.

👇 Already live in your Vasco workspace. Set it up today and let us know what you think.

#ProductUpdate #NewFeature #GTMExecution #SalesOps #Vasco #RevOps

https://lnkd.in/ec8auipr | 54 | 5 | 2 | 5mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.143Z |  | 2025-06-25T12:00:15.248Z | https://youtu.be/05ymrovCYXw |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7339301351832600578 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH8GbMcQW13UA/feedshare-shrink_800/B4EZdpvr8kHYAg-/0/1749825798374?e=1766620800&v=beta&t=K-8rQa8d6iethyitjL3EDZ_8scUGa0ETYWXYNc7zo9k | 𝗥𝗲𝘃𝗢𝗽𝘀 𝗳𝗿𝗶𝗲𝗻𝗱𝘀, 𝗰𝗮𝗻 𝗜 𝘀𝘁𝗲𝗮𝗹 𝟰𝟱 𝗺𝗶𝗻𝘂𝘁𝗲𝘀 𝗼𝗳 𝘆𝗼𝘂𝗿 𝘁𝗶𝗺𝗲 𝗻𝗲𝘅𝘁 𝘄𝗲𝗲𝗸?

Because if you're tired of:

- Dumping dashboards that no one acts on
- Decisions made by anecdotes or gut feels
- Feeling like the “reporting person” instead of a strategic partner...

This session is for you!

I’m teaming up with Justin Hudon to share:
✅ A dead-simple way to map your revenue engine (Bowtie-style)
✅ How to run QBRs/WBRs that create tension AND accountability
✅ Ways to lead from RevOps, without needing a big title

👉 It’s not just theory. It’s what we’re doing at Vasco.

📅 Wednesday, June 18 | 🕛 2pm EST
🔗 https://vasco.app/webinar

If you join, drop me a DM or comment. I would love to say hey live! | 40 | 2 | 5 | 5mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.144Z |  | 2025-06-13T14:43:19.902Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7328834511151001602 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHv6Tew2CC1ag/feedshare-shrink_800/B4EZbRA7_nGkAk-/0/1747263412786?e=1766620800&v=beta&t=zYDpPnMW_fWU07wueNv42jrxvouK2Slb0sjhhxferDc | My favorite quote of the day from Winning by Design Impact Summit: "If your Ideal Customer Profile doesn't expand by design, then it's not an ICP".

My biggest takeaway: "user-generated pipeline is the best pool of growth and probably the easiest to automate with AI" 

👤 We are talking Users (humans). Champions. People who talk.
❌ Not customers. Not accounts.

People refer products, not vendors
Humans build trust, not logos
Word of mouth is a GTM channel

With AI, the viral growth engine that fueled B2C is now making its way into B2B. Major playbooks that were once out of reach are now fully within grasp.

🚀 It's a wildly exciting time to build in GTM. | 28 | 1 | 0 | 6mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.145Z |  | 2025-05-15T17:31:50.619Z | https://www.linkedin.com/feed/update/urn:li:activity:7328553927732334592/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7325597253186826241 | Video (LinkedIn Source) | blob:https://www.linkedin.com/31fc43c4-45b5-46ee-be1a-67519874cd1c | https://media.licdn.com/dms/image/v2/D4E05AQGLydnjW8nIyQ/videocover-high/B4EZam_2UtHIBc-/0/1746558482809?e=1765778400&v=beta&t=9WCjggl7xCg6klSbSSUlGapnqj2qE5pzgZ2aCrrza2w | Heading into RevOpsAF tomorrow!
I’ll be speaking on Thursday at 11:00 AM (CDT) about a challenge every RevOps leader has faced aka How to diagnose your revenue engine and get the exec team to care.

Come find me in the Grand Couteau room, or just say hi during the event. Excited to meet many of you in New Orleans!

It's not too late to register: https://lnkd.in/eANMA32s | 88 | 2 | 2 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.146Z |  | 2025-05-06T19:08:08.175Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7321606274884804611 | Article |  |  | "The nature of 𝘀𝗼𝗳𝘁𝘄𝗮𝗿𝗲 is changing from a 𝘀𝘆𝘀𝘁𝗲𝗺 𝗼𝗳 𝗿𝗲𝗰𝗼𝗿𝗱 to a 𝘀𝘆𝘀𝘁𝗲𝗺 𝗼𝗳 𝗮𝗰𝘁𝗶𝗼𝗻𝘀. In the AI era, defensibility is likely to emerge from specialization and orchestration of AI agents, lending itself to verticalized solutions."

From SaaSpasse newsletter this morning, based on the NEA Article: https://lnkd.in/ek28Q9jm

Feels 100% right from what we're seeing in the trenches every day. | 38 | 2 | 0 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.146Z |  | 2025-04-25T18:49:24.799Z | https://www.nea.com/blog/tomorrows-titans-vertical-ai |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7320837834758643712 | Text |  |  | We’re looking for a freelance designer to help us bring Vasco’s next chapter to life.

Over the next few months, the Vasco website is going to be a major focus. 

We’re planning a full redesign in Framer, and we’re producing more high-performing content than ever. We need a talented partner to help us turn it all into a clean, cohesive, on-brand experience.

You’d collaborate with our Brand & Content lead (Sophie Geoffrion, MBA, PMP) and Marketing Specialist (Samantha Tavernier) on:
- Web design and implementation in Figma & Framer
- Visual assets for content (ebooks, product explainers, posts, etc.), mostly built in Canva
- If you’re a freelancer with an eye for conversion, clarity and rhythm — or if someone great comes to mind — let us know!

DM me or reach out to sophie.geoffrion@vasco.app | 60 | 21 | 9 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.147Z |  | 2025-04-23T15:55:54.396Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7320453797095366656 | Document |  |  | Forget the flashy titles. This is how high-performing teams are actually built.

JD St-Martin lays out the principles behind hiring leaders who actually move the needle.

7 principles from someone who's scaled B2B teams at every stage: from founder to President at a public company.

📌 Worth a read: https://lnkd.in/e8xh9MbN

(Fun fact: JD and I go way back—co-founders once, still learning from each other today.) | 51 | 1 | 0 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.147Z |  | 2025-04-22T14:29:52.682Z | https://www.linkedin.com/feed/update/urn:li:activity:7320446283675025409/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7318334915144474626 | Document |  |  | Most board meetings are… a mess.
Too much fluff. Not enough clarity. Zero alignment.

If you're scaling a SaaS company, you can’t afford to waste that time.
 Your board meeting should be a growth lever—not a box to check.

🛠️ That’s why we 've teamed up with Inovia Capital to built this tactical blueprint to help founders and Revenue leaders run high-impact GTM board decks.

Inside:
 • 💡 The anatomy of a great GTM review
 • 🔄 Templates to keep investors aligned (and not overwhelmed)
 • 🧠 Lessons from GTM pros and VCs who’ve seen everything

If you’re going from startup to scale-up → this is your cheat code.
 👉 Link in the comments | 47 | 1 | 1 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.148Z |  | 2025-04-16T18:10:11.858Z | https://www.linkedin.com/feed/update/urn:li:activity:7318332397471600640/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7316082331323170816 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4712408e-4e3e-40e1-b675-19cf5fd790be | https://media.licdn.com/dms/image/v2/D4E05AQFvnNHI3o9btQ/videocover-high/B4EZYfd.QJHYBw-/0/1744284683727?e=1765778400&v=beta&t=6cF3HZRQQl2uI69Txqd924-y1TfubL5hTmHgnAlcGJY | J’ai eu la chance d’être invité sur le podcast SaaSpasse. Une conversation sans filtre sur le parcours de Vasco, de Chronogolf, en passant par Lightspeed Commerce et l’émergence d’un nouveau mindset dans le SaaS québécois.

Un grand merci à Francois Lanthier Nadeau pour l’invitation et la qualité de l’échange 🙏 C’était authentique. C’était deep. C’était un super moment. | 72 | 12 | 1 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.149Z |  | 2025-04-10T12:59:14.024Z | https://www.linkedin.com/feed/update/urn:li:activity:7316071218757947392/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7315395952486346752 | Document |  |  | One of the most underrated tools in GTM diagnostics: the cross-conversion rate matrix. It reveals the why behind leakage -> and points you to the right set of actions. | 9 | 0 | 0 | 7mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.150Z |  | 2025-04-08T15:31:48.557Z | https://www.linkedin.com/feed/update/urn:li:activity:7315341413582319616/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7313673725168545792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGUQmgPvy30uQ/feedshare-shrink_800/B4EZX9jeonHYAw-/0/1743715696092?e=1766620800&v=beta&t=GZYj9zmJN1jgY2YdquOtfj8puEQSbAF1kJ8espWdyqc | The next decade of SaaS won't be defined by features
It'll be defined by collaboration --> between humans and AI

Sequoia’s “Act o1” article came out a few months ago
And it feels more true every week

It frames a shift we’re all starting to feel
From Software as a Service
→ to Service as a Software

Let that sink in
Software that doesn’t just help you do the job
It does the job for you

As Satya Nadella put it
“We are in the midst of a platform shift that will fundamentally transform software”

Some signals already visible:
🤖 GTM workflows moving out of CRMs and into live conversations
💡 Knowledge workers asking instead of searching
📦 Value shifting from usage to outcomes

And for RevOps?
It means becoming the translator between what humans want and what AI delivers. Less about tracking, more about orchestrating.

Curious what others are seeing here?
(Link to Sequoia's article in comments) | 35 | 4 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.151Z |  | 2025-04-03T21:28:17.567Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7311450968104030209 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEG888pgLBl2A/feedshare-shrink_800/B4EZXc95w.H0As-/0/1743168971266?e=1766620800&v=beta&t=DpFMq6xzgCki4D7lNR6Cj0a9FuQfcpZiBFfNFdCeWCU | If you're in Montreal and anywhere near GTM, Pavilion is the place to be.
And Frederic Aouad? The man could drop a LinkedIn post about Excel shortcuts and I’d still be like: “🔥🔥🔥 let’s goooo.” | 24 | 1 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.152Z |  | 2025-03-28T18:15:50.986Z | https://www.linkedin.com/feed/update/urn:li:activity:7311380597736689664/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7310635398592901120 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFdmr0nWa891g/feedshare-shrink_800/B56ZXPpZ1JGoAg-/0/1742945494598?e=1766620800&v=beta&t=gh1naRwpQzwMzOoPoV_pJ4S83baRGK8n_itnGwKcnKg | 𝗬𝗼𝘂𝗿 𝗯𝗿𝗮𝗶𝗻 𝗶𝘀 𝗽𝗹𝗮𝘆𝗶𝗻𝗴 𝘁𝗿𝗶𝗰𝗸𝘀 𝗼𝗻 𝘆𝗼𝘂𝗿 𝗚𝗧𝗠 𝘀𝘁𝗿𝗮𝘁𝗲𝗴𝘆.

I’m reading The Diary of a CEO by Steven Bartlett (highly recommend!).

There’s a chapter on the 𝗛𝗮𝗯𝗶𝘁𝘂𝗮𝘁𝗶𝗼𝗻 𝗙𝗮𝗰𝘁𝗼𝗿 … and it hit me like a truck. 

The brain tunes out what it’s seen too many times before.

Steve Jobs said “It’s a revolution.”
At first, it landed. Then everyone copied it.
Now? If you say that, people roll their eyes. 🙄 It's wallpaper.

Same thing is happening with outbound right now 👇

📩 𝗘𝘃𝗲𝗻 𝘀𝘂𝗽𝗲𝗿𝗯 𝗽𝗲𝗿𝘀𝗼𝗻𝗮𝗹𝗶𝘇𝗮𝘁𝗶𝗼𝗻 𝗴𝗲𝘁𝘀 𝗳𝗶𝗹𝘁𝗲𝗿𝗲𝗱 𝗮𝘀 𝘀𝗽𝗮𝗺
 It’s not bad… it’s just overused.

❌ 𝗪𝗵𝗮𝘁 𝘄𝗮𝘀 𝗼𝗻𝗰𝗲 “𝗰𝗹𝗲𝘃𝗲𝗿” 𝗶𝘀 𝗻𝗼𝘄 𝗽𝗿𝗲𝗱𝗶𝗰𝘁𝗮𝗯𝗹𝗲
The brain has labeled it: ignore this.

But… some old tactics are coming back and new ones emerge:

💬 𝗥𝗲𝗳𝗲𝗿𝗿𝗮𝗹𝘀: trust cuts through noise
🏢 𝗢𝗻𝘀𝗶𝘁𝗲 𝗽𝗿𝗲𝘀𝗲𝗻𝗰𝗲: field events, trade shows, customer visits are back
🤳 𝗕𝟮𝗕 𝗜𝗻𝗳𝗹𝘂𝗲𝗻𝗰𝗲𝗿𝘀: have you noticed LinkedIn is becoming more like Instagram?

Finally…

𝗠𝘂𝗹𝘁𝗶-𝘁𝗼𝘂𝗰𝗵 𝗶𝘀 𝗸𝗶𝗻𝗴

If you haven’t seen Clay’s latest webinar… they’re doing some wild things. Using automation to surround their prospect, book in-person hyper-local events, and generate indirect referrals at scale. That’s GTM Engineering in action.

Want to stand out?
You can’t blend in. You need your own voice. Harder? Sure. But it’s the only way to actually get noticed.

Curious to hear your thoughts on this 👇 | 34 | 7 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.153Z |  | 2025-03-26T12:15:04.062Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7308896074855862272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEK2hfqvMn2mA/feedshare-shrink_800/B4EZWl.cKGH0Ak-/0/1742246364208?e=1766620800&v=beta&t=6XJ4jIdMEaAjVH6xepjHm3mbvUahcJhJ4pF1Hft_HEo | Some easy Friday reading for our RevOps Engineer friends 😎
Inbound vs. Outbound: the age-old debate.

Inbound leads feel like a gift. Outbound feels like a grind.

But here’s the truth: Both can be gold—or garbage—without the right qualification process.

That’s where SPICED comes in.
 It’s not just a framework—it’s a unifier.

This article breaks down: 
 • 🤯 Why inbound ≠ ready
 • 🧠 How SPICED brings consistency across GTM
 • ⚖️ What RevOps can do to make attribution actually fair

Skim it over a coffee.
Let me know what resonates 👇 | 17 | 0 | 1 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.154Z |  | 2025-03-21T17:03:36.968Z | https://www.linkedin.com/feed/update/urn:li:activity:7308513929691824128/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7307430792622686208 | Text |  |  | Stop forcing leads into your process. Look from their perspective instead (Grab our latest eBook) 👇

Too often, companies define lead stages based on internal actions:
• SQL = Demo Booked
• SAL = Demo Attended

But what if the buyer isn’t ready for a call yet? What if they prefer async communication (WhatsApp, Slack, SMS, Email)?

A prospect who asks for info but hasn’t booked a meeting is still a qualified lead.

They’re actively looking for a solution. Ignoring them just because they haven’t clicked "Schedule a Demo" is a mistake.

A better approach? Use a 𝗾𝘂𝗮𝗹𝗶𝗳𝗶𝗰𝗮𝘁𝗶𝗼𝗻 𝗳𝗿𝗮𝗺𝗲𝘄𝗼𝗿𝗸 like 𝗦𝗣𝗜𝗖𝗘𝗗:
• MQL = Fit + Pain
• SQL = Fit + Pain + Impact
• SAL = Fit + Pain + Impact + Critical Event

This method aligns Sales, Marketing, and Partnerships with a 𝗰𝗼𝗺𝗺𝗼𝗻 𝗹𝗮𝗻𝗴𝘂𝗮𝗴𝗲 𝗮𝗰𝗿𝗼𝘀𝘀 𝗮𝗹𝗹 𝗚𝗧𝗠 𝗠𝗼𝘁𝗶𝗼𝗻𝘀. 

And with AI-powered call recorders (Gong, Attention, Fathom), you can automate lead qualification without relying on reps to fill in fields manually.

Bonus: Pipeline reviews become 10x more insightful. Instead of debating why something is an SQL, you focus on real buyer signals:
- What’s their 𝗣𝗮𝗶𝗻?
- Do they have 𝗕𝘂𝗱𝗴𝗲𝘁?
- Is there a 𝗖𝗿𝗶𝘁𝗶𝗰𝗮𝗹 𝗘𝘃𝗲𝗻𝘁 driving urgency?

If these aren’t clear, why is it even an opportunity?

Curious how to implement this? 𝗚𝗿𝗮𝗯 𝗼𝘂𝗿 𝗹𝗮𝘁𝗲𝘀𝘁 𝗴𝘂𝗶𝗱𝗲 and share your feedbacks in the comments! | 30 | 1 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.155Z |  | 2025-03-17T16:01:06.460Z | https://www.linkedin.com/feed/update/urn:li:activity:7307416922583613440/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7306301375758413824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQENRKdMCWz1Ww/feedshare-shrink_800/B4EZWUpCzuH0Ao-/0/1741955542861?e=1766620800&v=beta&t=iGisI5pSh3yl-OaVVzgwJ75a6qxqKqE4X5Y8NEZKvTQ | Sharing for visibility > great summary of where to start and how to think about it. | 12 | 0 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.156Z |  | 2025-03-14T13:13:12.496Z | https://www.linkedin.com/feed/update/urn:li:activity:7306291104541298689/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7305615572388507648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFQopeJSVFnmw/feedshare-shrink_2048_1536/B4EZWKqBXKHgAs-/0/1741788027420?e=1766620800&v=beta&t=q8cTqM9FPGc4o56pG2kiUW49TpsJD6qqrQ3gsT7viZU | Sharing for visibility. A great company, mission and culture. Awesome time for a VP Revenue to join: Clear ICP and PMF -> Mission = Architecting growth from startup to scaleup. | 17 | 1 | 0 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.156Z |  | 2025-03-12T15:48:04.231Z | https://www.linkedin.com/feed/update/urn:li:activity:7305588496134533120/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7305558236831645696 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-RJChcRydsQ/feedshare-shrink_800/B4EZWIU0TIGwAg-/0/1741748913892?e=1766620800&v=beta&t=2l6KgZJopGZqrkkUFkjEcUhxDCh_BNlZ5yccZn4pNL4 | We're seeing tons of companies' revenue engines on Vasco, and it's crazy how many are leaving easy revenue on the table.

Two 𝗵𝗶𝗴𝗵-𝗶𝗺𝗽𝗮𝗰𝘁, 𝗹𝗼𝘄-𝗰𝗼𝗺𝗽𝗹𝗲𝘅𝗶𝘁𝘆 tactics stand out:

⏳ 𝗡𝗼𝘁 𝗿𝗲𝗮𝗰𝗵𝗶𝗻𝗴 𝗼𝘂𝘁 𝘁𝗼 𝗻𝗲𝘄 𝗕𝗢𝗙𝗨 𝗶𝗻𝗯𝗼𝘂𝗻𝗱 𝗹𝗲𝗮𝗱𝘀 𝘄𝗶𝘁𝗵𝗶𝗻 𝟱 𝗺𝗶𝗻𝘂𝘁𝗲𝘀
The science is clear:

• Leads contacted within 5 minutes are 21x more likely to convert than those reached after 30 minutes.
• Yet, most teams still take hours or even days to follow up.

🔄 𝗡𝗼𝘁 𝗮𝘂𝘁𝗼-𝗲𝗻𝗿𝗼𝗹𝗹𝗶𝗻𝗴 𝗹𝗼𝘀𝘁 𝗱𝗲𝗮𝗹𝘀 𝗶𝗻𝘁𝗼 𝗻𝘂𝗿𝘁𝘂𝗿𝗲 𝘀𝗲𝗾𝘂𝗲𝗻𝗰𝗲𝘀

• A "closed-lost" deal isn’t lost forever—60% of lost deals buy within 2 years, often from a competitor.
• A simple nurture sequence keeps you top of mind and brings them back when the timing is right.

Both of these are SO quick to implement and can drive serious revenue.

Any other simple but overlooked GTM moves you see too often? 👇 | 56 | 14 | 3 | 8mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.157Z |  | 2025-03-12T12:00:14.369Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7303761360520183809 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXEke4pPdk9w/feedshare-shrink_800/B4EZVtCi42HgAg-/0/1741291140758?e=1766620800&v=beta&t=0NCJGqE2L_IA2FINcwPqa9NreKVqwEFWl3S6fZl0emk | 🔥 Finally, a way to track the full account journey from HubSpot, without the data chaos.

Anyone who’s tried to pull this from CRM knows the pain:
- Cross-object connections make it a mess
- Skipped stages & duplicates lead to inaccurate data
- Multiple contacts ≠ multiple opportunities

With Vasco, we just launched a feature that allows you to visualize the entire Lifecycle Progression (Bowtie) for each accounts ... from Lead to Expansion:

✅ Smart rules auto-deduplicate contacts
✅ Enrichment of missing lifecycle stages (e.g., if Lead → SQL is missing, we create an MQL event)
✅ Reactivations detection rules to track accounts cycling back into the pipeline
✅ Identification of "stalled" accounts to re-engage

💡 The result?

- Real cohort analysis
- Consolidated activity tracking between stages by Account
- Pipeline reviews = way easier

Curious to hear: what other use cases do you see for this? 👇 | 81 | 10 | 2 | 9mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.158Z |  | 2025-03-07T13:00:05.672Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7302327850714476545 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGVY-Uu83Xm9w/feedshare-shrink_800/B4EZVcUe7FHUAk-/0/1741010628731?e=1766620800&v=beta&t=4g2BpT1uc0SCtjUqcftQdmEIjjB62poiapriXw2Pcn4 | 🚀 Andreessen Horowitz just shared a wild stat: 5️⃣ : 1️⃣ 𝗚𝗧𝗠 𝘁𝗼 𝗥𝗲𝘃𝗢𝗽𝘀 𝗿𝗮𝘁𝗶𝗼 𝗳𝗼𝗿 𝘀𝘁𝗮𝗿𝘁𝘂𝗽𝘀 & 𝘀𝗰𝗮𝗹𝗲-𝘂𝗽.

That’s 𝗱𝗼𝘂𝗯𝗹𝗲 what Saastr’s 2023 benchmarks showed. The role is gaining serious traction.

But here’s what the article doesn’t say:
💡 The quality of your RevOps hires matters just as much as the investment.
💡 And the paradox? Early-stage startups need senior RevOps talent the most to put the foundations in place — yet that's when they can rarely afford it.

That’s why going #Fractional early makes sense.

Get the right expertise first, then scale in-house.

🔗 Worth reading the full article—link in comments.
How are you thinking about these stats? Drop your thoughts below 👇 | 45 | 3 | 2 | 9mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.159Z |  | 2025-03-03T14:03:50.301Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7286041476118020097 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9xpMsaUhahw/feedshare-shrink_800/B4EZR0otqLGgAg-/0/1737123617888?e=1766620800&v=beta&t=0Ne-ZifF3gDnqGTbMFFpo7192GENQPk8fJS1Zk7W9Vo | 🎙️ Thrilled to join Nectarios Economakis on his podcast to share the Vasco journey. We unpacked quite a few big topics:

🚀 Why we raised $8M to emerge from stealth mode and transform RevOps
💡 How unifying data, processes, and technology drives scalable growth
💰 Blueprints for startups and scale-ups to build revenue engines that achieve GTM fit and fuel high-velocity growth

Product-market fit is essential, but go-to-market fit can make or break a B2B company. Vasco was built with a single focus: to shift those odds!

Listen to the full conversation—link in comments 👇 | 72 | 5 | 1 | 10mo | Post | Guillaume Jacquet | https://www.linkedin.com/in/jacquet-guillaume | https://linkedin.com/in/jacquet-guillaume | 2025-12-08T05:18:24.159Z |  | 2025-01-17T15:27:36.011Z | https://www.linkedin.com/feed/update/urn:li:activity:7286024542957780992/ |  | 

---



---

# Guillaume Jacquet
*Vasco*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 23 |

---

## 📚 Articles & Blog Posts

### [FV 17: Materializing the BowTie from @WinningByDesign with Vasco | Guillaume Jacquet – FounderVideo Podcast – Podcast](https://podtail.com/podcast/foundervideo-podcast/fv-17-materializing-the-bowtie-from-winningbydesig/)
*2024-08-14*
- Category: podcast

### [Vasco Raises US$8M Seed Round to Transform Revenue Operations  with AI-Powered Revenue Architecture](https://vasco.app/announcement)
*2025-02-04*
- Category: article

### [Vasco Secures $11.5 Million CAD to Enhance AI-Powered Revenue Management for Startups - Startup Ecosystem Canada](https://www.startupecosystem.ca/news/vasco-secures-11-5-million-cad-to-enhance-ai-powered-revenue-management-for-startups/)
*2025-01-16*
- Category: article

### [Vasco Secures $8M Seed Round to Revolutionize Revenue Ops with AI-Driven Tech](https://marketingtechginsights.com/vasco-secures-8m-seed-round-to-revolutionize-revenue-ops-with-ai-driven-tech/)
*2025-01-15*
- Category: article

### [CIBC Innovation Banking invests in Vasco](https://privatecapitaljournal.com/cibc-innovation-banking-invests-in-vasco/)
*2025-09-09*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Surf and Sales - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/surf-and-sales/id1490003203)**
  - Source: podcasts.apple.com
  - *SEP 15. S6E32 - Guillaume Jacquet - The Formula for Predictable Growth. Scott, Richard, and Guillaume "G" Jacquet, the co-founder and CEO of Vasco, di...*

- **[Vasco raises $11.5 million CAD to help startups manage revenue ...](https://betakit.com/vasco-raises-11-5-million-cad-to-help-startups-manage-revenue-trajectory-with-ai/)**
  - Source: betakit.com
  - *Jan 15, 2025 ... “One of the top reasons why great innovation doesn't make it to the world is because [it] fails in commercialization.” Guillaume Jacq...*

- **[Surf and Sales | Podcast on Spotify](https://open.spotify.com/show/5oJ9GkVkCiZEQEqCCRpVV4)**
  - Source: open.spotify.com
  - *S6E32 - Guillaume Jacquet - The Formula for Predictable Growth. Scott, Richard, and Guillaume "G" Jacquet, the co-founder and CEO of Vasco, dive into ...*

- **[The Harris Consulting Group Blog & Events](https://theharrisconsultinggroup.com/blog-events/)**
  - Source: theharrisconsultinggroup.com
  - *... podcast. We ... S6E32 – Guillaume Jacquet – The Formula for Predictable Growth. Scott, Richard, and Guillaume “G” Jacquet, the co-founder and CEO ...*

- **[Vasco rejoint notre portefeuille](https://www.framework.vc/fr/articles/vasco-rejoint-notre-portefeuille/)**
  - Source: framework.vc
  - *Jan 15, 2025 ... Vasco est une plateforme RevOps permettant aux ... Établie à Montréal, et fondée par deux entrepreneurs chevronnés, Guillaume Jacquet...*

- **[Vasco - Partenaires SaaSpasse](https://www.saaspasse.com/partenaires/vasco)**
  - Source: saaspasse.com
  - *Vasco apparait dans l'épisode 131 du pod, Guillaume Jacquet : D'investisseur ... Updates sur le podcast, la cie, les events IRL. Contenu premium pour ...*

- **[Telegraph - Du capital et de la conviction](https://www.telegraph-vc.com/)**
  - Source: telegraph-vc.com
  - *Guillaume JacqueT. CEO Chronogolf & Vasco. Telegraph leads HR tech startup Leya's $1M pre-seed round. Read more. Telegraph leads HR tech startup Leya'...*

- **[How to scale your B2B SaaS from $1M to $10M ARR - Vasco ...](https://vasco.app/blog/from-founder-led-sales-to-a-scalable-revenue-engine)**
  - Source: vasco.app
  - *Apr 14, 2025 ... Learn how B2B SaaS founders can scale from $1M to $10M ARR by moving. Watch the interview ... Now live in Vasco! Guillaume Jacquet, C...*

- **[Blog - Vasco](https://vasco.app/blog)**
  - Source: vasco.app
  - *Guillaume Jacquet, CEO @ Vasco. Guillaume Jacquet, CEO. Data destinations ... Interview with Set2Close's CEO · Guide. The board meeting playbook for s...*

- **[Bridging strategy and execution in a shifting GTM landscape - Vasco ...](https://vasco.app/blog/bridging-strategy-and-execution-in-a-shifting-gtm-landscape)**
  - Source: vasco.app
  - *May 20, 2025 ... ... Vasco: From insight to execution. Interview with Set2Close's CEO. Our CEO, Guillaume Jacquet, recently sat down with Jordon Rowse...*

---

*Generated by Founder Scraper*
