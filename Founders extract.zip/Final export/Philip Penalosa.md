# Philip Penalosa

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Sinta AI
**Durée dans le rôle** : 2 years 6 months in role
**Durée dans l'entreprise** : 2 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

- Building AI tools for consumer healthcare companies to accelerate insights and streamline compliance.
- Leading the development of RegCheck, an AI platform that pre-evaluates marketing content for regulatory alignment, reducing MLR bottlenecks.
- Partnering with Fortune 500 brands to turn data into decisions faster and with less friction.
- Driving product strategy, business development, and investor relations across North America and Europe.

## Résumé

I like to build.

Sometimes that means AI tools that help global healthcare brands move faster and stay compliant. Other times, it’s producing videos that tell a company’s story, or opening a café where community happens over coffee.

My career moves across tech, storytelling, and hospitality — but the through-line is creating things that make people’s lives easier or more enjoyable. I’ve co-founded AI startups, scaled video and motion design services, and run hospitality spaces that have become neighborhood staples.

I get energy from bringing an idea to life, scaling it with the right systems, and obsessing over the details that make the end result feel effortless.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA0SxPoBRm_LxDacWCRR4_yFn8W7CZuFb-c/
**Connexions partagées** : 8


---

# Philip Penalosa

## Position actuelle

**Entreprise** : Sinta AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Philip Penalosa

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402714963871629314 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgqJDXkbHrng/feedshare-shrink_800/B4EZru6B5KIoAg-/0/1764944781601?e=1766620800&v=beta&t=n2DBRqIGuJQQH9n9wzdx8abacoipTkTP73S7md4yq6o | Taking the Café Kuya management team out as we gear up to open our second location. 

It’s been almost five years since stepping into hospitality as a complete newcomer, and the journey has been wild, but the growth we’ve experienced in just the last year has been something special. Proud of this team and what we’re building together.

Hospitality and tech could not be more different, but both have taught me the same thing: it always comes down to people. | 42 | 7 | 0 | 2d | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:44.007Z |  | 2025-12-05T14:26:23.180Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401646611409559552 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHV5KOg5sswSA/feedshare-shrink_800/B56ZrfkDweLwAk-/0/1764687364324?e=1766620800&v=beta&t=mvrdgu0-nF6N-VEKwOPx3MXT10S9QF6Vgo_Qg_NuMvQ | This is why we’re confident in our build. From day one we focused on a secure, closed AI platform designed to enhance the work rather than replace it. We’re here to make teams faster, more accurate, and more confident in what they deliver. | 5 | 0 | 0 | 5d | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:44.007Z |  | 2025-12-02T15:41:08.104Z | https://www.linkedin.com/feed/update/urn:li:activity:7401635275921362945/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397674322053455872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHUOEso0WDs3A/feedshare-shrink_800/B4EZqnFhmLIUAg-/0/1763739836815?e=1766620800&v=beta&t=7EKt4Y2bJRMF-1fBOlwHFEN61wkfd3_MRfzBiCwoe6A | Yesterday we had the opportunity to lead a webinar for the CHPA All-Staff meeting. Erika Khanna delivered a great session on practical AI tools in the workplace, and the engagement from the group was awesome.
Always grateful to share how AI can help teams work smarter and unlock stronger insights. Thanks to the CHPA team for having us. | 18 | 2 | 0 | 2w | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:44.008Z |  | 2025-11-21T16:36:40.520Z | https://www.linkedin.com/feed/update/urn:li:activity:7397661059156971520/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397315930428682240 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFojfhF_97eLw/feedshare-shrink_800/B4EZqiKHD6KsAg-/0/1763657151189?e=1766620800&v=beta&t=F4ZyHmlh9qIxNISYUv5rQKRfMTJpEHvSEphj-dYBvI8 | This feels like a full circle moment for me! Happy to announce that we are partnering with Let There Be to supercharge their Science Story™ process. Excited to create stronger brand strategies and claim development for consumer health and beyond! | 11 | 0 | 0 | 2w | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:44.008Z |  | 2025-11-20T16:52:33.298Z | https://www.linkedin.com/feed/update/urn:li:activity:7397314249443725312/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7389042883531612160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF9UCrAJuHwNw/feedshare-shrink_800/B4EZosnR30HcAk-/0/1761685103310?e=1766620800&v=beta&t=qNp3u19q6Z6xnofhn_3YT9Y8JaQlcBu1VOVqNw8pVwc | What a day!
Day 1 at #CPHIFrankfurt has been incredible for Sinta — Erika Khanna and I met so many talented professionals across the European pharma & OTC world.
The event space is massive, the energy is palpable and the opportunities are real.
We’re looking forward to Day 2, making new connections and building meaningful partnerships. If you’re around, let’s connect! | 18 | 2 | 0 | 1mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.670Z |  | 2025-10-28T20:58:25.212Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7381315457892458496 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGHk8mSY59jlw/image-shrink_800/B4EZm.zS_BGoAc-/0/1759842743140?e=1765785600&v=beta&t=hNK0FvOcbDN_N1LuF7qpn-CuWfixFlI44xJSRpNnfRs | Thrilled to be heading to CPHI Frankfurt for the first time! It’s the perfect opportunity to meet new people, exchange ideas, and explore how we can accelerate innovation across pharma and healthcare. If you’re attending, Erika Khanna and I would love to connect.
#CPHIFrankfurt #PharmaInnovation #GlobalPharma #MeetMeAtCPHIFRANKFURT2025 | 15 | 0 | 1 | 2mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.671Z |  | 2025-10-07T13:12:23.371Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7372357649973157888 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG0bjpNGM0btQ/feedshare-shrink_800/B56Zk5JX9vI0Ag-/0/1757600386280?e=1766620800&v=beta&t=3GE6OQnORRiqKQt_VSCtrQe-5vw85LDUc1GD9CmcJJk | What a great experience at CHPA RSQ! We built meaningful connections and can’t wait to see what comes next. | 10 | 0 | 0 | 2mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.671Z |  | 2025-09-12T19:57:15.535Z | https://www.linkedin.com/feed/update/urn:li:activity:7371910339036299264/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7371518933415149568 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFyFSq7gahOvQ/feedshare-shrink_800/B56ZkwkHSoH8Ag-/0/1757456405108?e=1766620800&v=beta&t=YpbxvF32Vf3hO2TOpLdRRBcO1jLWY9Kl-wd581xX75U | Day 1 of CHPA RSQ!
Our first time attending, and definitely not the last. It’s been energizing connecting with industry leaders, hearing their questions, and discussing how AI tools can help address evolving needs in the consumer healthcare space.

Grateful for the chance to be part of conversations that are shaping the future of responsible self-care and access. | 13 | 0 | 0 | 2mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.672Z |  | 2025-09-10T12:24:29.925Z | https://www.linkedin.com/feed/update/urn:li:activity:7371306435349233664/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7371117087332810752 | Text |  |  | Touch down in Washington DC! If you’re at CHPA RSQ, we would love to meet you! Check out our first newsletter below, to see what we’ve been up to at Sinta. | 7 | 0 | 0 | 2mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.672Z |  | 2025-09-09T09:47:42.353Z | https://www.linkedin.com/feed/update/urn:li:activity:7370854311083487232/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7361494109343096832 | Text |  |  | Excited to share this news.

We’ve been working hard at Sinta AI and have just closed a round of investment to bring our platform to market. This is a huge milestone for us and I’m incredibly proud of the team.

We’re just getting started and I’m looking forward to what’s ahead. | 33 | 7 | 0 | 3mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.673Z |  | 2025-08-13T20:29:25.614Z | https://www.linkedin.com/feed/update/urn:li:activity:7361100637322797057/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7360778376732635136 | Text |  |  | We’re beyond excited to welcome Erika Khanna as our new COO at Sinta AI!
I’ve always known Erika was an amazing human being, but now that we’re working together, I get to see it every single day. Her expertise, energy, and enthusiasm have been felt since day one, and we can’t wait to see what we’ll accomplish together.
Welcome to the team, Erika! | 16 | 1 | 0 | 3mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.673Z |  | 2025-08-11T21:05:21.662Z | https://www.linkedin.com/feed/update/urn:li:activity:7360748848157241345/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7317584246250876928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEXomAZca96Qg/feedshare-shrink_800/B4EZYx4ODPHUAg-/0/1744593543731?e=1766620800&v=beta&t=vymF09n6_vGrk98esdlT9PwTu__Baj1WF1WmXupqIUw | Almost 4 years ago, I took a big risk. Last year we were rated in the top 5 coffee shops in Montreal. Thanks for hanging out Behind Each Dish! | 53 | 4 | 0 | 7mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.675Z |  | 2025-04-14T16:27:18.447Z | https://www.linkedin.com/feed/update/urn:li:activity:7317535873502228480/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7316250110357622784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGzq2N8VG_C1A/feedshare-shrink_800/B4EZYiKrHjHMAw-/0/1744329951502?e=1766620800&v=beta&t=zxSg0YedmqIOtSoMH6nj6QTARwlvXQE_UjgDFkITBl4 | Fun fact: When I’m not busy building AI products, I get to be partner in an amazing Donut shop.

And last week, we made it to the Top 7 Donut Shops in all of Quebec, according to Journal de Montréal!

Huge thanks to our incredible team for making it all happen (and for making it delicious). | 55 | 7 | 0 | 7mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.676Z |  | 2025-04-11T00:05:55.663Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7305791102400233472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEygPeELf3_aA/feedshare-shrink_800/B4EZWNiSk5G0Ag-/0/1741836332342?e=1766620800&v=beta&t=Cs4TjyEG_u4VqpzLvcSkWLvt1A6vqUw6bCLabtMaKLI | Excited to be speaking at the 2025 CHPA Self-Care Leadership Summit in San Antonio!

On March 18, I’ll be joining Jissan Cherian to discuss how AI is transforming consumer healthcare—helping brands unlock insights and drive differentiation.

If you’re attending, let’s connect! Message me to meet up and talk more about Sinta AI and the future of AI in healthcare. | 24 | 1 | 0 | 8mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.676Z |  | 2025-03-13T03:25:33.847Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7293606225148063747 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHA_0EiEMqa3A/feedshare-shrink_800/B4EZTXIOUSGgAg-/0/1738776045469?e=1766620800&v=beta&t=N3Mxj1exU2cUl77ttpO8eWqXpLz8Bp6iIUkMYrKP8q8 | Excited to be speaking with Jissan Cherian at the 2025 CHPA Self-Care Leadership Summit (SLS) from March 17-19!

Looking forward to connecting with industry leaders and sharing how Sinta AI is unlocking new opportunities for Consumer Healthcare brands. If you’re attending and want to chat, let’s connect! | 6 | 0 | 0 | 10mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.677Z |  | 2025-02-07T12:27:12.726Z | https://www.linkedin.com/feed/update/urn:li:activity:7292955329141633025/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7289771140615450624 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE5JkK78yYVtg/feedshare-shrink_800/B4DZST6FcQHIAs-/0/1737648265930?e=1766620800&v=beta&t=Bi89jmNKbnrbc5wdqwU-xy4gO71-XNWgmhl7MtOHkJ0 | Excited to welcome Jissan Cherian to the Sinta team as our Executive Advisor! His experience in healthcare marketing will be invaluable as we work to empower brands with smarter tools and bold insights. | 2 | 0 | 0 | 10mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.677Z |  | 2025-01-27T22:27:57.321Z | https://www.linkedin.com/feed/update/urn:li:activity:7288225076003426304/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7288216758715314176 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF5MNclTQNxOQ/feedshare-shrink_800/B4DZSTxDq5HkAg-/0/1737645899956?e=1766620800&v=beta&t=YpApVMO1f3WNXJy0DFhNUpj6IAYArJ4nc_KqEv3blmM | Over the past year, I’ve been working hard to bridge some of my biggest passions. Today, I’m thrilled to officially introduce Sinta!
Sinta is a powerful new Ai tool designed for marketers and R&D teams in the consumer healthcare space. With the help of incredible experts, we’ve built Sinta to unlock insights, foster innovation, and help brands turn untapped data into actionable strategies.
This is just the beginning, and I’m excited to share more about how Sinta is set to transform the way we approach healthcare innovation.
Thank you to everyone who has supported this journey so far—let’s build something amazing together!
#SintaAI #HealthcareInnovation #ConsumerHealthcare #AI | 40 | 5 | 0 | 10mo | Post | Philip Penalosa | https://www.linkedin.com/in/philip-penalosa | https://linkedin.com/in/philip-penalosa | 2025-12-08T07:07:47.678Z |  | 2025-01-23T15:31:23.797Z | https://www.linkedin.com/feed/update/urn:li:activity:7288215151219019777/ |  | 

---



---

# Philip Penalosa
*Sinta AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Phil Penalosa | Consumer Healthcare Products Association](https://www.chpa.org/about-chpa/event-speakers/phil-penalosa)
*2025-01-01*
- Category: article

### [Sinta AI | LinkedIn](https://ca.linkedin.com/company/sinta-ai?trk=public_post_feed-actor-image)
*2025-01-24*
- Category: article

### [Sinta](https://www.sinta.ai/)
*2026-06-01*
- Category: article

### [- YouTube](https://www.youtube.com/watch?v=Uj0nnxQP3Y0)
*2025-04-25*
- Category: video

### [Interview with Open Streets Creator Gil Penalosa](https://www.aarp.org/livable-communities/livable-in-action/info-2015/5-questions-for-gil-penalosa.html)
*2024-07-03*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Sinta AI](https://www.sinta.ai/)**
  - Source: sinta.ai
  - *With over a decade in healthcare marketing, Philip Penalosa has helped brands bridge the gap between science and consumer engagement. ... Sinta.ai doe...*

---

*Generated by Founder Scraper*
