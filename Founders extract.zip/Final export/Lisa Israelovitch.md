# Lisa Israelovitch

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : AssistIQ
**Durée dans le rôle** : 4 years 3 months in role
**Durée dans l'entreprise** : 4 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Software Development

## Résumé

I’m passionate about turning bold ideas into meaningful businesses. From concept to scale, I specialize in building software companies that improve lives, create lasting value, and generate measurable impact.

I co-founded Umapped, a SaaS platform for the travel industry (acquired in 2018), and am now building AssistIQ with cutting-edge computer vision, artificial intelligence (AI) and machine learning that transforms the way supplies and implants are managed in the operating room and procedural areas.

My passions in building startups:
- Building from zero to scale
- Building world-class teams and company cultures
- Leading strategic partnerships and business development
- Creating value at the intersection of tech, operations, and user experience

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAXJchABKO7pI4OzHResGnNh3dqrZPsXsdY/
**Connexions partagées** : 100


---

# Lisa Israelovitch

## Position actuelle

**Entreprise** : AssistIQ

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Lisa Israelovitch

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401983684540637184 | Text |  |  | Proud of our team at AssistIQ and grateful for your drive and commitment to add meaningful value everyday. I love building and learning everyday from all of you. 

Thank you Moishe Liberman for caring deeply to solve this problem and Mundeep Minhas and Thierry Wong for always wanting to build something better. 

Our gratitude to Fabrice Brunet, Kathy Malas, Julien GIRAUD and Nicolas Robert, our very first Canadian partners for your trust and vision. We dedicate this recognition to honour Paul Harmat, who mentored us and challenged us to make a real impact, starting here in Canada and Quebec. We miss you, Paul. | 48 | 9 | 0 | 4d | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:52.636Z |  | 2025-12-03T14:00:32.601Z | https://www.linkedin.com/feed/update/urn:li:activity:7401644069078069249/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397365428114841600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6q0RbhjR6cg/feedshare-shrink_800/B4EZqi4pwzGUAg-/0/1763669352821?e=1766620800&v=beta&t=270t127pOv7QdN9COzUmJyuTl0V6K-UuhHokrw44atk | Thank you to Hays Waldrop for the warm welcome in Nashville at the Council of Supply Chain Executives.

We had the chance to connect with a thoughtful group of supply chain leaders and hear directly about their priorities and pressure points. I left energized and grateful for the conversations. A few themes stood out:

✨ Partnership is the expectation. Providers and vendors are working side by side. Teams are showing up with a spirit of “we” instead of “us and them.”
✨ Data quality is the foundation of every decision. The feedback on how AIQ Capture can continue to drive accuracy and trusted visibility was incredibly valuable.
✨ AI is gaining real traction and the “why” matters. Leaders are excited about the potential, and they are taking a thoughtful approach to make sure solutions focus on the problems that matter most.
✨ Collaboration among vendors is increasing. When we work together, we create stronger and more complete solutions for health system supply chain teams.

Thank you again for the conversations, the candor and the hospitality + a special thank you to the supply chain leaders who joined our panel with open and direct feedback on priorities and opportunities for true transformation. 

AssistIQ, Council of Supply Chain Executives, Maria Hames Thierry Wong, Lou Fierens | 32 | 1 | 5 | 2w | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:52.637Z |  | 2025-11-20T20:09:14.466Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7384330208394506240 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9d79742d-9ef7-4e9c-924e-0a7fab98283a | https://media.licdn.com/dms/image/v2/D5605AQGh8yWhnxWhGA/videocover-high/B56ZnoJaYNI4B8-/0/1760536408578?e=1765774800&v=beta&t=WYfY5sISk8yYA2Q6fgVe45FdMtE0LiecL-Y7hZ7zllY | Excited to join this upcoming panel alongside investors and partners who’ve supported AssistIQ from day one — including StandUp Ventures, Deloitte, and N49P / TechTO (both founded by the amazing Alex Norman).

Looking forward to the conversation, Marie Chevrier Schwartz! | 23 | 2 | 0 | 1mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.687Z |  | 2025-10-15T20:51:55.902Z | https://www.linkedin.com/feed/update/urn:li:activity:7384224936963284992/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7378800899600646144 | Document |  |  | Allina Health is leading the way in healthcare innovation—rolling out a workflow that scales across procedural and operating rooms, seamless for clinicians and trusted by the supply chain. Fully connected with Epic + Workday. In just 60 days, they saw cleaner data, less admin, and more revenue across the system.

We are proud to support such an innovative team setting the standard for how clinical, supply chain, and revenue cycle can work together. 

Thank you to Tom Lubotsky, Chris Schultz, Joshua Grulke, and the Allina teams for your leadership and partnership.

#RevenueIntegrity #AIForHealthcare #HealthTechAI #AIInHealthcare #CareSimplified #PerioperativeCare #HealthcareSupplyChain | 43 | 4 | 4 | 2mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.688Z |  | 2025-09-30T14:40:25.956Z | https://www.linkedin.com/feed/update/urn:li:activity:7378790247909728257/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7363233664018636800 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHHb8XMnGrGBg/feedshare-shrink_800/B4EZi9jYxaHgAg-/0/1755526828189?e=1766620800&v=beta&t=kp2XwxS2GlJCExoz_-5MwPvIFNDo_-2zCuWeIOa4Y8M | Owensboro Health boosted monthly billable revenue by 12%—without adding more cases—by integrating AssistIQ with Epic. Accurate capture of supplies and implants in the OR means faster revenue recognition with less admin work and faster billing. 

Thank you Beth Steele and to the Owensboro Health & Optum teams for showing how AI is making a real difference in the OR. Onwards to our next stop in the Cath Lab! | 44 | 6 | 6 | 3mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.692Z |  | 2025-08-18T15:41:47.768Z | https://www.linkedin.com/feed/update/urn:li:activity:7363213201338994688/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7333623019187142657 | Text |  |  | We’re proud to share a major milestone: AssistIQ is now live at our first location at Northwell Health, one of the largest and most forward-thinking health systems in the U.S.

We’ve worked side by side with many teams across Northwell — from perioperative to finance, supply chain and IT — tackling a challenge that touches nearly every hospital: how to capture what’s actually used in the OR and procedural areas in a way that works for clinical teams and supply chain teams to deliver trusted, actionable data.

What stood out immediately wasn’t just the scale of the opportunity, it was the thoughtfulness, collaboration, and creativity that Northwell brought to the table. Together, we’ve gone from shared vision to shared execution, and we’re continuing to design and build capabilities that respond to needs across the health system and broader market.

This is the kind of partnership we built AssistIQ for. 

My thanks to Ryan Ott, Adam Becker, Kelly Treacy, Ryon Andersen, Will Corrigan, Vikas Balani & Phyllis McCready for your trust and leadership and to the AssistIQ team that made this possible. 

🔗 This milestone was featured today in Becker’s Hospital Review: bit.ly/3HtE66x

We’re also excited to share that AssistIQ has raised $11.5M in Series A funding, led by Battery Ventures with continued support from Tamarind Hill. This is more than funding, it’s a strong signal that health systems are ready for change, and that our mission resonates.

We’re thrilled to welcome Brandon Gleklen, Olivia Henkoff, and the entire Battery team as we expand across North America and continue building for and with health systems focused on raising the quality of health care. 

🔗  Battery Ventures wrote about the investment on their Blog: bit.ly/3SnvTDt | 205 | 29 | 7 | 6mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.695Z |  | 2025-05-28T22:39:39.901Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7325924093940101121 | Video (LinkedIn Source) | blob:https://www.linkedin.com/709d7438-67f5-4405-a084-b72049733126 | https://media.licdn.com/dms/image/v2/D4E05AQFDjBhpP0QUcw/videocover-high/B4EZarjLdAHoBs-/0/1746634895694?e=1765774800&v=beta&t=uMXVx4lPmUMBsf60mupW7-eCow5WtkIpFpLelGq0R7g | I'm excited to share highlights from AssistIQ's journey with Owensboro Health.
The fast impact on charge capture, inventory levels and staff efficiency was made possible by a strong collaboration between three teams—Owensboro Health, Optum, and AssistIQ—working together as one.

I’m  proud of our team and grateful to everyone who made this possible. Too many to name but a special thank you to Beth Steele Russ R., Mark Dailey, MBA, Wendy Wilson and Amy Brown for your leadership! | 47 | 8 | 3 | 7mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.697Z |  | 2025-05-07T16:46:53.083Z | https://www.linkedin.com/feed/update/urn:li:activity:7325917765712732160/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7324067985927675904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIKNNqbBuiQA/feedshare-shrink_800/B4EZaM0IFnHoAk-/0/1746119197616?e=1766620800&v=beta&t=DCTUtPDO-5_V2LvOMHSpxwXtvYQyNicFNSBxmJBWNvE | Excited to join this panel virtually on May 22 to dig into one of healthcare’s biggest opportunities: how designing for clinical teams and the bottom line can also be a win for the environment.

Join us! 👉 https://lnkd.in/eRUCNscd | 9 | 0 | 0 | 7mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.698Z |  | 2025-05-02T13:51:22.448Z | https://www.linkedin.com/feed/update/urn:li:activity:7323754740490674176/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7322242110471000064 | Text |  |  | AssistIQ is seeking an EA/ Operations Coordinator to support our leadership team. This role, based in Montreal, offers both in-office and hybrid work options (min 3 days/week in office). Fluency in both English and French is essential, along with strong organizational skills. We'll be posting the role soon and grateful for network introductions. If anyone comes to mind please DM me.

cc Jerry R. Ishmael Lynn Charabaty Leila Taktak Luis Da Costa Wafa B. Josh Buehler | 37 | 0 | 8 | 7mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.699Z |  | 2025-04-27T12:55:59.816Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7318311047600222208 | Article |  |  | Excited to be hosting this session alongside our brilliant clinical advisor, Shawn Sefton.

Every week, I speak with health systems facing the same challenge: incomplete implant and supply capture is clouding data, leading to missed billing opportunities, and burdening staff with manual workflows. 

The good news? We’re already seeing real change. Join us on April 24 for a 30-minute webinar on three problems AI is solving in the OR already.
Hope to see you there! | 15 | 0 | 0 | 7mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.699Z |  | 2025-04-16T16:35:21.392Z | https://page.assistiq.ai/webinar-registration?hs_preview=SNwjmAgM-186648935030 |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7301290039215345665 | Article |  |  | AssistIQ is growing! 🚀 We're hiring for a Customer Success role to join our team, led by Amy Brown. This role is all about customer relationships, driving impact in healthcare, and working with innovative technology. If that sounds like you, we'd love to hear from you! | 25 | 1 | 1 | 9mo | Post | Lisa Israelovitch | https://www.linkedin.com/in/lisaisraelovitch | https://linkedin.com/in/lisaisraelovitch | 2025-12-08T04:42:57.700Z |  | 2025-02-28T17:19:56.758Z | https://apply.workable.com/assistiq/?not_found=true#jobs |  | 

---



---

# Lisa Israelovitch
*AssistIQ*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 6 |
| Press & Mentions (Google) | 16 |

---

## 📚 Articles & Blog Posts

### [Lisa Israelovitch](https://www.hospitalitynet.org/author/148002769/lisa-israelovitch.html)
*2025-05-15*
- Category: article

### [AssistIQ raises $11.5M to scale AI-enabled supply tracking tech](https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech)
*2025-05-28*
- Category: article

### [Lisa Israelovitch — BLLA Events](https://www.bllaevents.com/conference-facilitators/lisa-israelovitch)
*2020-09-19*
- Category: article

### [AssistIQ | The Org](https://theorg.com/org/assistiq)
*2025-01-01*
- Category: article

### [Using AI to Make Healthcare More Efficient: Our Investment in AssistIQ](https://battery.com/blog/using-ai-to-make-healthcare-more-efficient-our-investment-in-assistiq)
*2025-05-28*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 9,210 words total*

### Lisa Israelovitch
*286 words* | Source: **EXA** | [Link](https://www.hospitalitynet.org/author/148002769/lisa-israelovitch.html)

Lisa Israelovitch

===============

[![Image 3: Hospitality Net](https://www.hospitalitynet.org/HN-icon.svg)![Image 4: Hospitality Net](https://www.hospitalitynet.org/HN-text.svg)](https://www.hospitalitynet.org/)

Search on Hospitality Net 

 Light  Dark  Auto 

Sign In

*   [Home](https://www.hospitalitynet.org/)
*   [Me](https://www.hospitalitynet.org/me)
*   [Latest News](https://www.hospitalitynet.org/list/1-10/all-latest-news.html)
*   [Opinion](https://www.hospitalitynet.org/list/1-10/opinion-articles.html)
*   [World Panel](https://www.hospitalitynet.org/list/1-10/viewpoints.html)
*   [Explainers](https://www.hospitalitynet.org/list/1-10/explainer-series.html)
*   [Thematics](https://www.hospitalitynet.org/thematics/)
*   [Calendar](https://www.hospitalitynet.org/list/events.html)
*   [Development](https://www.hospitalitynet.org/list/1-10/announcements.html)
*   [Appointments](https://www.hospitalitynet.org/list/1-10/appointments.html)
*   [Hot Topics](https://www.hospitalitynet.org/hottopic/)
*   [HNtv](https://www.hospitalitynet.org/video/hntv/)
*   [Hotelschools](https://www.hospitalitynet.org/list/hotelschools.html)
*   [Brands](https://www.hospitalitynet.org/list/hotel-brands.html)
*   [Associations](https://www.hospitalitynet.org/list/industry-associations.html)
*   [Consultants](https://www.hospitalitynet.org/list/consultants.html)
*   [Architects](https://www.hospitalitynet.org/list/architects-designers.html)
*   [Suppliers](https://www.hospitalitynet.org/list/suppliers.html)
*   [Products](https://www.hospitalitynet.org/marketplace/)
*   [Demand Index](https://www.hospitalitynet.org/demand/)
*   [Newsletter](https://www.hospitalitynet.org/360/)
*   [Advertising](https://www.hospitalitynet.org/mediakit/)
*   [Contact](https://www.hospitalitynet.org/contact.html)
*    More ‹
    *   [Home](https://www.hospitalitynet.org/)
    *   [Me](https://www.hospitalitynet.org/me)
    *   [Latest News](https://www.hospitalitynet.org/list/1-10/all-latest-news.html)
    *   [Opinion](https://www.hospitalitynet.org/list/1-10/opinion-articles.html)
    *   [World Panel](https://www.hospitalitynet.org/list/1-10/viewpoints.html)
    *   [Explainers](https://www.hospitalitynet.org/list/1-10/explainer-series.html)
    *   [Thematics](https://www.hospitalitynet.org/thematics/)
    *   [Calendar](https://www.hospitalitynet.org/list/events.html)
    *   [Development](https://www.hospitalitynet.org/list/1-10/announcements.html)
    *   [Appointments](https://www.hospitalitynet.org/list/1-10/appointments.html)
    *   [Hot Topics](https://www.hospitalitynet.org/hottopic/)
    *   [HNtv](https://www.hospitalitynet.org/video/hntv/)
    *   [Hotelschools](https://www.hospitalitynet.org/list/hotelschools.html)
    *   [Brands](https://www.hospitalitynet.org/list/hotel-brands.html)
    *   [Associations](https://www.hospitalitynet.org/list/industry-associations.html)
    *   [Consultants](https://www.hospitalitynet.org/list/consultants.html)
    *   [Architects](https://www.hospitalitynet.org/list/architects-designers.html)
    *   [Suppliers](https://www.hospitalitynet.org/list/suppliers.html)
    *   [Products](https://www.hospitalitynet.org/marketplace/)
    *   [Demand Index](https://www.hospitalitynet.org/demand/)
    *   [Newsletter](https://www.hospitalitynet.org/360/)
    *   [Advertising](https://www.hospitalitynet.org/mediakit/)
    *   [Contact](https://www.hospitalitynet.org/contact.html)

[![Image 5: Cendyn™](https://www.hospitalitynet.org/picture/153188938.jpg?t=20250925154912)](https://www.hospitalitynet.org/redirect/16000882.html?1765173564418)![Image 6](https://www.hospitalitynet.org/impression/16000882.gif)

[Author](https://www.hospitalitynet.org/list/authors.html)[Umapped](https://www.hospitalitynet.org/organization/17018246/umapped.html)

Lisa Israelovitch
=================

### CEO and co-Founder of Umapped

![Image 7: Israelovitch ](https://www.hospitalitynet.org/picture/153062090/israelovitch.jpg?t=1477399847)
Lisa Israelovitch is a visionary entrepreneur with a love for travel and growing businesses that solve big problems. As the CEO and co-Founder of Umapped. Lisa brings over a decade of experience in the hospitality and real estate industry, ranging from large public companies to building start-ups from a promising idea into a million-dollar success story.

 Follow [Umapped](https://www.hospitalitynet.org/organization/17018246/umapped.html)[Lisa Israelovitch](http://www.umapped.com/)[](https://ca.linkedin.com/in/lisaisraelovitch)[](https://twitter.com/umapped)[](https://www.facebook.com/pages/UMapped/215388181930597)

[Umapped](https://umapped.com/)

1 Westmount Square #1390

Montreal, QC H3Z 2P9

Canada

Phone: 1-800-975-6713

[https://umapped.com](https://umapped.com/)

Latest from Lisa Israelovitch
=============================

 Filter 

Tweets by Lisa Israelovitch
===========================

[https://twitter.com/umapped](https://twitter.com/umapped?ref_src=twsrc%5Etfw)

![Image 8: Hospita

*[... truncated, 1,166 more characters]*

---

### AssistIQ raises $11.5M to scale AI-enabled supply tracking tech
*687 words* | Source: **EXA** | [Link](https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech)

AssistIQ raises $11.5M to scale AI-enabled supply tracking tech | MobiHealthNews

===============
[Skip to main content](https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech#main-content)

[![Image 2: Healthcare IT News logo](https://www.mobihealthnews.com/themes/custom/mhn/logo.png)](https://www.mobihealthnews.com/)

*   TOPICS
    *   [Videos](https://www.mobihealthnews.com/video)
    *   [Podcasts](https://www.mobihealthnews.com/podcast)
    *   [Provider](https://www.mobihealthnews.com/categories/provider)
    *   [Payer](https://www.mobihealthnews.com/categories/payer)
    *   [Pharma](https://www.mobihealthnews.com/categories/pharma)
    *   [Consumer](https://www.mobihealthnews.com/categories/consumer)
    *   [Investor](https://www.mobihealthnews.com/categories/investors)

*   RESOURCES
    *   [Events](https://www.himss.org/events)
    *   [Jobs](http://jobmine.himss.org/)
    *   [Learning Center](https://www.himss.org/resources/learning-center)
    *   [Webinars](https://www.mobihealthnews.com/webinars)
    *   [White Papers](https://www.mobihealthnews.com/white-papers)

*   REGIONS
    *   [ANZ](https://www.mobihealthnews.com/anz)
    *   [ASIA](https://www.mobihealthnews.com/asia)
    *   [EMEA](https://www.mobihealthnews.com/emea)
    *   [Global Edition](https://www.mobihealthnews.com/)

*   MORE
    *   [About](https://www.mobihealthnews.com/about)
    *   [Advertise](https://www.himss.org/media-brands/#mobi)
    *   [Contact](https://www.mobihealthnews.com/contact-0)
    *   [Privacy Policy](https://www.himss.org/himss-legal/)

*   [ANZ](https://www.mobihealthnews.com/anz)
*   [ASIA](https://www.mobihealthnews.com/asia)
*   [EMEA](https://www.mobihealthnews.com/emea)
*   [Global Edition](https://www.mobihealthnews.com/)

AssistIQ raises $11.5M to scale AI-enabled supply tracking tech
===============================================================

The company's computer vision technology tracks supply and implant usage in hospital operating and procedural rooms.

[Global](https://www.mobihealthnews.com/enterprise-taxonomy-region/global)

[Investing](https://www.mobihealthnews.com/enterprise-taxonomy-topic/investing)

By [Jessica Hagen](https://www.mobihealthnews.com/author/jessica-hagen),_Executive Editor_| May 28, 2025 | 2:49 PM

[](https://www.facebook.com/sharer/sharer.php?u=https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech&title=AssistIQ%20raises%20$11.5M%20to%20scale%20AI-enabled%20supply%20tracking%20tech "Share to Facebook")[](https://twitter.com/intent/tweet?text=AssistIQ%20raises%20$11.5M%20to%20scale%20AI-enabled%20supply%20tracking%20tech+https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech "Share to X")[](https://www.linkedin.com/sharing/share-offsite/?url=https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech "Share to Linkedin")

![Image 3: Surgeons in an operating room performing a procedure](https://www.mobihealthnews.com/sites/mhn/files/styles/wide/public/web_16x9_lg-1071385548_3.JPG.webp?itok=3LNDnwq1)

Photo: Morsa Images/Getty Images

AssistIQ, which offers hospitals computer vision technology for supply chain management, has secured $11.5 million in Series A funding.

The round was led by Battery Ventures, with participation from existing investor Tamarind Hill.

Brandon Gleklen, principal at Battery Ventures, will join the company's board of directors.

**WHAT IT DOES**

The Montreal-based company offers hospitals AIQ Capture, its flagship product, which allows for supply tracking in OR and procedural rooms. It tracks real-time supply and implant usage, which the company says allows for less waste.

"Our mission is to build trust in data and empower health systems with AI-driven insights that improve margins, drive sustainability and ultimately enhance patient care," AssistIQ CEO Lisa Israelovitch said in a statement.

"We're thrilled by the market's response to our product and deeply grateful to our health system partners, whose collaboration helps us innovate and deliver solutions that create value across clinical and operational workflows. We're also excited to welcome Brandon and the Battery team to the AssistIQ journey as we accelerate our growth and expand our impact in the market."

**MARKET SNAPSHOT**

In 2023, AssistIQ raised $2.5 million CAD ($1.81 million) in early-stage funding.

AssistIQ's platform has been integrated into Epic at Owensboro Health Regional Hospital in Kentucky, and the company says it has several more Epic integrations planned in the coming months.

New York state's Northwell Health, which is also the company's design partner, also utilizes AssistIQ's technology.

Tags:

[supply management](https://www.mobihealthnews.com/tag/supply-management), 

[AssistIQ](https://www.mobihealthnews.com/tag/assistiq), 

[artificial intelligence](https://www.mobihealthnews.com/tag/artificia

*[... truncated, 6,117 more characters]*

---

### Lisa Israelovitch — BLLA Events
*339 words* | Source: **EXA** | [Link](https://www.bllaevents.com/conference-facilitators/lisa-israelovitch)

Lisa Israelovitch — BLLA Events

===============
[![Image 1: Angle Up](blob:http://localhost/06ffebd4d7aaff5d58046ffa3c2bcbd8)](https://www.bllaevents.com/conference-facilitators/lisa-israelovitch#scroll-here)

[0](https://www.bllaevents.com/cart)

[Skip to Content](https://www.bllaevents.com/conference-facilitators/lisa-israelovitch#page)

[![Image 2: BLLA Events](https://images.squarespace-cdn.com/content/v1/5e70019a9324d46ebc650fb6/7c00f712-2957-41ba-a6b2-af55b5219989/BLLA+Events+Logo+1.png?format=1500w)](https://www.bllaevents.com/)

 About 

[Who We Are](https://www.bllaevents.com/who)

[What is Our Why](https://www.bllaevents.com/why)

[What We Do](https://www.bllaevents.com/what)

[Blog](https://www.bllaevents.com/blla-events-blog)

 Events 

[Past Events](https://www.bllaevents.com/past-events)

[2026 Events](https://www.bllaevents.com/2026-events)

[Testimonials](https://www.bllaevents.com/testimonials)

[The Gallery](https://www.bllaevents.com/gallery)

[Contact](https://www.bllaevents.com/contact)

[BLLA Homepage](https://www.blla.org/)

Open Menu Close Menu

[![Image 3: BLLA Events](https://images.squarespace-cdn.com/content/v1/5e70019a9324d46ebc650fb6/7c00f712-2957-41ba-a6b2-af55b5219989/BLLA+Events+Logo+1.png?format=1500w)](https://www.bllaevents.com/)

 About 

[Who We Are](https://www.bllaevents.com/who)

[What is Our Why](https://www.bllaevents.com/why)

[What We Do](https://www.bllaevents.com/what)

[Blog](https://www.bllaevents.com/blla-events-blog)

 Events 

[Past Events](https://www.bllaevents.com/past-events)

[2026 Events](https://www.bllaevents.com/2026-events)

[Testimonials](https://www.bllaevents.com/testimonials)

[The Gallery](https://www.bllaevents.com/gallery)

[Contact](https://www.bllaevents.com/contact)

[BLLA Homepage](https://www.blla.org/)

Open Menu Close Menu

[Folder:About](https://www.bllaevents.com/about)

[Folder:Events](https://www.bllaevents.com/events)

[Testimonials](https://www.bllaevents.com/testimonials)

[The Gallery](https://www.bllaevents.com/gallery)

[Contact](https://www.bllaevents.com/contact)

[BLLA Homepage](https://www.blla.org/)

[Back](https://www.bllaevents.com/)

[Who We Are](https://www.bllaevents.com/who)

[What is Our Why](https://www.bllaevents.com/why)

[What We Do](https://www.bllaevents.com/what)

[Blog](https://www.bllaevents.com/blla-events-blog)

[Back](https://www.bllaevents.com/)

[Past Events](https://www.bllaevents.com/past-events)

[2026 Events](https://www.bllaevents.com/2026-events)

Lisa Israelovitch
=================

[Leadership Track](https://www.bllaevents.com/conference-facilitators/category/Leadership+Track)

Sep 11

Written By [Ariela Kiradjian](https://www.bllaevents.com/conference-facilitators?author=59518f00893fc02592c79939)

### Strategic Advisor, [Umapped](https://umapped.com/)&[Flight Centre Travel Group](https://www.fctgl.com/)

![Image 4: Lisa.jpg](https://images.squarespace-cdn.com/content/v1/5e70019a9324d46ebc650fb6/1599856584635-TLN5MFMTANCF09U8MG1Z/Lisa.jpg)

#### A little bit about Lisa…

Lisa is a visionary entrepreneur with a love for travel and growing businesses that deliver exceptional customer experiences. Her experience in hospitality and technology ranges from large corporate companies to building and scaling start-ups with exits to both private and public companies.

Most recently, Lisa co-founded Umapped, the award-winning SAAS travel itinerary platform used by leading travel providers to engage with their customers throughout their travel journey. In 2018, Umapped was acquired by Flight Centre Travel Group and Lisa led the team to scale the technology globally to millions of consumers.

Currently, Lisa is working as a strategic advisor and exploring new opportunities.

#### How to connect with Lisa and Umapped…

Umapped’s [Website](https://umapped.com/)

Umapped’s [Facebook](https://www.facebook.com/Umapped/), [Twitter](https://twitter.com/umapped), [LinkedIn](https://www.linkedin.com/company/umapped) Pages

Lisa’s [LinkedIn](https://www.linkedin.com/in/lisaisraelovitch/) Page

[Interviewer/Bootcamp](https://www.bllaevents.com/conference-facilitators/tag/Interviewer%2FBootcamp)

[Ariela Kiradjian](https://www.bllaevents.com/conference-facilitators?author=59518f00893fc02592c79939)[https://www.stayboutiquemedia.com](https://www.stayboutiquemedia.com/)

[Previous Previous Virginia Messina ----------------](https://www.bllaevents.com/conference-facilitators/virginia-messina)[Next Next David Williams --------------](https://www.bllaevents.com/conference-facilitators/david-williams)

Subscribe.
----------

Sign up with your email address to receive BLLA Events news and updates.

First Name 

Last Name 

Email Address 

Sign Up

We respect your privacy.

Thank you!

[](https://www.facebook.com/BLLAEvents/)[](https://www.instagram.com/bllaevents/)

#### BLLA Events

_A part of the_[_BLLA Family_](https://www.blla.org/)

[Investment](https://www.bllaevents.com/2024-bhic)

[TIEWN](https://www.bllaevents.c

*[... truncated, 515 more characters]*

---

### AssistIQ | The Org
*346 words* | Source: **EXA** | [Link](https://theorg.com/org/assistiq)

AssistIQ | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

This is an unverified company page

![Image 1: AssistIQ logo](https://cdn.theorg.com/bc820c16-01b6-4cb1-ada5-e606cb6eb747_thumb.jpg)

AssistIQ
========

[11 people](https://theorg.com/people/search)·[6 jobs](https://theorg.com/jobs)

Follow

We're on a mission to make healthcare more affordable and sustainable for everyone. AssistIQ delivers supply intelligence to health systems, reducing waste and carbon footprint without impacting patient quality with no added work. The company's platform delivers real-time visibility of supply usage... Read more

Industries

[Health Care](https://theorg.com/explore/industries/health-care)

Headquarters

[Montreal , Canada](https://theorg.com/explore/countries/canada)

Employees

[1-10](https://theorg.com/explore/employee-ranges/1-10)

Links

[](https://linkedin.com/company/assistiq "View on linkedIn")[](https://www.assistiq.ai/ "View the website")

Org chart

Teams

Offices

* * *

Org chart
---------

Full screen

[LI](https://theorg.com/org/assistiq/org-chart/lisa-israelovitch "View Lisa Israelovitch on The Org")

Hiring!

[Lisa Israelovitch](https://theorg.com/org/assistiq/org-chart/lisa-israelovitch "View Lisa Israelovitch on The Org")

Co-Founder & CEO

2

LI

Lisa Israelovitch

Collapse

[Hiring](https://theorg.com/org/assistiq/jobs/senior-implementation-man-29bd0fde "View this job on The Org")

[Senior Implementation Manager](https://theorg.com/org/assistiq/jobs/senior-implementation-man-29bd0fde "View this job on The Org")

Vacant position

0

[![Image 2: Mundeep Minhas' profile picture](https://cdn.theorg.com/b2a45ad4-9cca-4766-98d8-f171bbc2181d_thumb.jpg)](https://theorg.com/org/assistiq/org-chart/mundeep-minhas "View Mundeep Minhas on The Org")

[Mundeep Minhas](https://theorg.com/org/assistiq/org-chart/mundeep-minhas "View Mundeep Minhas on The Org")

Co-founder & Chief Product Officer

1

* * *

Teams
-----

View all (0)

This company has no teams yet

* * *

Offices
-------

View all (1)

*   [HQ 0 people · 0 jobs Use ⌘ + scroll to zoom the map Use two fingers to move the map HQ](https://theorg.com/org/assistiq/offices/hq)

Similar companies
-----------------

[Apollo Global Management 54 followers](https://theorg.com/org/apollo)[GHGSat 3 followers](https://theorg.com/org/ghgsat)[Digitas Health 5 followers](https://theorg.com/org/digitas-health-lifebrands)[Merck 303 followers](https://theorg.com/org/merck)[Elevance Health 194 followers](https://theorg.com/org/elevance-health)[Teladoc Health 100 followers](https://theorg.com/org/teladoc-health)[Ottawa Hospital Research Institute 1 follower](https://theorg.com/org/ottawa-hospital-research-institute)[HealthMark Group 3 followers](https://theorg.com/org/healthmark-group)[Sagility 11 followers](https://theorg.com/org/sagility)[ChristianaCare 7 followers](https://theorg.com/org/christianacare)[Verathon 7 followers](https://theorg.com/org/verathon)[Explore companies](https://theorg.com/explore)

Transparency starts here

Join the world's biggest network of public org charts

[Sign up](https://theorg.com/signup)[Log in](https://theorg.com/login)

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

![Image 3: Cookiebot session tracker icon loaded](https://imgsct.cookiebot.com/1.gif?dgi=46b327ce-c3bf-4c3a-94d7-32411fa4e7b8)

---

### Using AI to Make Healthcare More Efficient: Our Investment in AssistIQ
*2,488 words* | Source: **EXA** | [Link](https://battery.com/blog/using-ai-to-make-healthcare-more-efficient-our-investment-in-assistiq)

Using AI to Make Healthcare More Efficient: Our Investment in AssistIQ - Battery Ventures

===============
Using AI to Make Healthcare More Efficient: Our Investment in AssistIQ - Battery Ventures

===============

![Image 1: Revisit consent button](https://www.battery.com/wp-content/plugins/webtoffee-cookie-consent/lite/frontend/images/revisit.svg) Consent Preferences 

We use cookies on our website to give you the most relevant experience by remembering your preferences and repeat visits. By clicking “Accept,” you consent to the [use of cookies](https://www.battery.com/cookie-notice/).

Manage Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://www.battery.com/wp-content/plugins/webtoffee-cookie-consent/lite/frontend/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie __cf_bm 
*   Duration 1 hour 
*   Description This cookie, set by Cloudflare, is used to support Cloudflare Bot Management.  

*   Cookie wt_consent 
*   Duration 1 year 
*   Description Used for remembering users’ consent preferences to be respected on subsequent site visits. It does not collect or store personal information about visitors to the site. 

*   Cookie _cfuvid 
*   Duration session 
*   Description Calendly sets this cookie to track users across sessions to optimize user experience by maintaining session consistency and providing personalized services 

*   Cookie wpEmojiSettingsSupports 
*   Duration session 
*   Description WordPress sets this cookie when a user interacts with emojis on a WordPress site. It helps determine if the user's browser can display emojis properly. 

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie yt-remote-connected-devices 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie ytidb::LAST_RESULT_ENTRY_KEY 
*   Duration never 
*   Description The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future. 

*   Cookie yt-remote-device-id 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie yt-remote-session-name 
*   Duration session 
*   Description The yt-remote-session-name cookie is used by YouTube to store the user's video player preferences using embedded YouTube video. 

*   Cookie yt-remote-fast-check-period 
*   Duration session 
*   Description The yt-remote-fast-check-period cookie is used by YouTube to store the user's video player preferences for embedded YouTube videos. 

*   Cookie yt-remote-session-app 
*   Duration session 
*   Description The yt-remote-session-app cookie is used by YouTube to store user preferences and information about the interface of the embedded YouTube video player. 

*   Cookie yt-remote-cast-available 
*   Duration session 
*   Description The yt-remote-cast-available cookie is used to store the user's preferences regarding whether casting is available on their YouTube video player. 

*   Cookie yt-remote-cast-installed 
*   Duration session 
*   Description The yt-remote-cast-installed cookie is used to store the user's video player preferences using embedded YouTube video. 

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

- [x] 

Advertisement cookies are used to pro

*[... truncated, 24,519 more characters]*

---

### AssistIQ raises $2.5 million CAD to cut down on medical waste in hospitals | BetaKit
*1,216 words* | Source: **GOOGLE** | [Link](https://betakit.com/assistiq-raises-2-5-million-cad-to-cut-down-on-medical-waste-in-hospitals/)

AI platform tracks use of disposable medical devices, supplies for surgeries and common procedures.

A medtech startup that has developed a new artificial intelligence (AI) supply intelligence platform to reduce medical waste has raised $2.5 million CAD in “early-stage” funding.

Even as it prepares to use the fresh funds for product development and expansion to new hospitals, [AssistIQ](https://assistiq.ai/) also announced a partnership with the Centre Hospitalier de l’Université de Montréal (CHUM) Research Centre in Montréal.

> “By actually having data on what is actually used time and time again…we can have better insights into how to actually prep that surgery.”
> 
>  -Lisa Israelovitch, AssistIQ

The CHUM is one of the largest hospitals in Canada and was recognized as Canada’s most innovative hospital in a ranking by Newsweek of the world’s top 250 Best Smart Hospitals for 2021.

Lisa Israelovitch, AssistIQ’s CEO and one of its founders, called medical waste in hospitals a huge issue. “Medical disposable devices and supplies is the largest variable cost a hospital has to deal with after wages,” she noted. AssistIQ notes the market for medical devices and disposable supplies in North America is a more than $188 billion USD market opportunity that is expected to rise to $330 billion USD by 2029.

“It’s a huge line item for hospitals,” Israelovitch said. In hospitals, AssistIQ is focused on the operating room and common procedures, so areas such as endoscopy and catheterization labs. AssistIQ’s software works in the operating rooms, for example, to help doctors and nurses understand what is being used in order to reduce waste at different levels.

“In some cases, it’s clinicians making more efficient decisions, and in some cases it could be procurement that’s actually altering their quantities,” according to Israelovitch.

The startup’s AI platform claims that it tracks the usage of disposable medical devices and supplies across surgeries and common procedures while saving time for nurses. This new data set provides visibility and insights for many hospital stakeholders that result in savings, according to AssistIQ.

One example is in operating rooms where disposable supplies and devices will often be opened without being used. Without knowing and having enough history of what is actually used, there is not enough data for nurses to determine what should actually be opened prior to the surgeon asking for items.

“By actually having data on what is actually used time and time again for various procedures by the physician, we can have better insights into how to actually prep that surgery,” Israelovitch noted.

Reordering and procurement present another challenge for hospitals. Israelovitch pointed out that it’s not exactly like ordering for a grocery store: “It’s kind of serious if you run out of something. But if we actually knew what was being used by surgery, we could have a lot more predictive insights into how to adjust ordering volumes because today products are expiring on the shelf.”

**RELATED: [Procurement could be Canada’s biggest barrier to commercializing healthtech innovation](https://betakit.com/procurement-could-be-canadas-biggest-barrier-to-commercializing-healthtech-innovation/ "Procurement could be Canada’s biggest barrier to commercializing healthtech innovation")**

AssistIQ closed the raise, its first, in November. StandUp Ventures led the round with participation from N49P, The Kale Fund, along with several individual investors, including Kerry Liu, founder of Rubikloud and an investor at Horizon Ventures. When asked about the classification of its round, AssistIQ told BetaKit the company views it as between a pre-seed and seed stage, referring to it only as “early-stage.”

“The founding team has worked together for over a decade building, operating and scaling both enterprise and SaaS platforms,” noted Michelle McBane, managing partner at StandUp Ventures. “They developed a compelling product in a short amount of time with exciting market traction. The problem they are solving is especially important at a time when hospitals everywhere are looking for ways to improve efficiency.”

> “We’re still looking at tens of millions of dollars per hospital in terms of savings.”

Israelovitch said all the investors recognized that AssistIQ brings a well balanced team both on the technical and business side. The vision for the company originated with a prototype and study led by Dr. Moishe Liberman, a Harvard-trained thoracic surgeon and the director of the Technology Innovation and Development Lab at the CHUM.

Liberman and his team wanted to evaluate whether a real-time surgical cost awareness program would reduce disposable supply costs. The study, published in the Journal of the American College of Surgeons, resulted in average supply savings of 23 percent, demonstrating the value of real-time cost awareness of supplies to medical teams without any impact to patient quality.

According to 

*[... truncated, 2,855 more characters]*

---

### AssistIQ Raises $11.5M to Scale AI-Enabled Supply Tracking Technology
*453 words* | Source: **GOOGLE** | [Link](https://community.hlth.com/insights/news/assistiq-raises-11-5m-to-scale-ai-enabled-supply-tracking-technology-2025-05-29)

AssistIQ, a Montreal-based healthcare technology company specializing in computer vision solutions for hospital supply chain management, has announced the successful completion of an $11.5 million Series A funding round. The investment was led by Battery Ventures, with participation from existing investor Tamarind Hill, marking a significant milestone in the company's growth trajectory.

The funding will accelerate the expansion of AssistIQ's flagship product, AIQ Capture, which leverages advanced computer vision technology to track supply and implant usage in operating rooms and procedural areas. This real-time tracking capability addresses a critical challenge in healthcare operations by reducing waste and improving inventory management accuracy.

Brandon Gleklen, principal at Battery Ventures, will join AssistIQ's board of directors as part of the investment, bringing valuable expertise to guide the company's strategic direction. The appointment signals strong confidence from the investment community in AssistIQ's potential to transform hospital supply chain operations.

"Our mission is to build trust in data and empower health systems with AI-driven insights that improve margins, drive sustainability and ultimately enhance patient care," said Lisa Israelovitch, CEO of AssistIQ. "We're thrilled by the market's response to our product and deeply grateful to our health system partners, whose collaboration helps us innovate and deliver solutions that create value across clinical and operational workflows. We're also excited to welcome Brandon and the Battery team to the AssistIQ journey as we accelerate our growth and expand our impact in the market."

The company has already achieved notable market traction with its technology platform. AssistIQ's solution has been successfully integrated into Epic at Owensboro Health Regional Hospital in Kentucky, demonstrating the platform's compatibility with major healthcare IT systems. The company has outlined plans for several additional Epic integrations in the coming months, indicating strong demand for its supply tracking capabilities.

Northwell Health, one of New York state's largest health systems, serves as both a customer and design partner for AssistIQ. This collaboration exemplifies the company's approach to developing solutions in close partnership with healthcare providers, ensuring that the technology addresses real-world operational challenges faced by hospitals.

The Series A funding follows AssistIQ's 2023 early-stage funding round of $2.5 million CAD ($1.81 million), reflecting the company's rapid progress in developing and commercializing its technology. The substantial increase in funding size demonstrates investor confidence in the company's ability to scale its operations and capture a larger share of the hospital supply chain management market.

As healthcare systems continue to face pressure to improve operational efficiency while maintaining high-quality patient care, AssistIQ's AI-powered supply tracking technology addresses a critical need in the industry. The new funding will enable the company to expand its reach and help more hospitals optimize their supply chain operations through intelligent automation.

Click [here](https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech) for the original news story.

---

### AssistIQ
*563 words* | Source: **GOOGLE** | [Link](https://himalayas.app/companies/assistiq)

![Image 1: AssistIQ logo](https://cdn-images.himalayas.app/1ua0nipmd3zwylmnccaaomoq1xfk)AS

AssistIQ is an AI-driven healthcare platform that optimizes supply management to reduce waste and costs while improving patient care.

About AssistIQ
--------------

AssistIQ is your trusted line of sight into actual supply and implant usage in the operating room and procedural areas. With our innovative platform, we turn bottlenecks into value drivers by eliminating complexity, reducing waste, and maintaining a sufficient level of supplies and implants. Powered by advanced computer vision and machine learning, our AIQ Capture technology accurately tracks the usage of these supplies in real-time, significantly simplifying the process. Notably, it does this without the need for barcodes or special hardware, thus allowing for greater operational efficiency.

Our mission extends beyond just improving supply management; we strive to make healthcare affordable and sustainable. AssistIQ's platform is adaptable and easily integrates with existing EHR and ERP systems. This integration facilitates the extraction of actionable insights from the data we collect, enabling healthcare providers to proactively unlock missed revenue opportunities and implement sustainable practices. Feedback from healthcare professionals highlights how our solution enhances their workflow, allowing them to focus more on patient care rather than administrative burdens. In an era where healthcare is under immense pressure to be cost-effective, AssistIQ stands out as a leader in leveraging technology to make a measurable impact.

FAQs
----

When was AssistIQ founded?AssistIQ was founded in 2021.

Who is the CEO of AssistIQ?Lisa Israelovitch is the CEO.

What industries or markets does AssistIQ operate in?AssistIQ operates in the following markets: Healthcare Technology, Artificial Intelligence, Machine Learning, Supply Chain Management, Healthcare Operations, Computer Vision, SaaS, Hospital Management, Data Analytics, and Sustainability in Healthcare.

How many employees does AssistIQ have?AssistIQ has 11-50 employees.

Where does AssistIQ have employees?AssistIQ has employees in Canada.

Is AssistIQ hiring?Yes, AssistIQ has[1 open remote job](https://himalayas.app/companies/assistiq/jobs).

Does AssistIQ support remote work or working from home?Yes, AssistIQ is a remote-friendly company.

Does AssistIQ offer a four-day work week?No, AssistIQ does not offer a four-day work week.

What is AssistIQ's website?AssistIQ's website is[assistiq.ai](https://assistiq.ai/?utm_source=himalayas.app&utm_medium=himalayas.app&utm_campaign=himalayas.app&ref=himalayas.app&source=himalayas.app).

Where can I find AssistIQ on social media?You can find AssistIQ on[LinkedIn](https://www.linkedin.com/company/assistiq/) and [Twitter](https://twitter.com/lisrapp).

1.   [Himalayas](https://himalayas.app/)
2.   [Remote companies](https://himalayas.app/companies)
3.   AssistIQ

1 remote job at AssistIQ
------------------------

Explore the variety of open remote roles at AssistIQ, offering flexible work options across multiple disciplines and skill levels.

[View all jobs at AssistIQ](https://himalayas.app/companies/assistiq/jobs)

Remote companies like AssistIQ
------------------------------

Find your next opportunity by exploring profiles of companies that are similar to AssistIQ. Compare culture, benefits, and job openings on Himalayas.

[View all companies](https://himalayas.app/companies)

Inspectorio is an AI-powered supply chain platform that optimizes performance, builds resilience, and provides intelligence across production chains for global brands, retailers, and their multi-tier suppliers. The company's platform digitizes and connects supply chain management processes to enhance decision-making and provide real-time visibility and control.

[SaaS](https://himalayas.app/companies/markets/saas)[Logistics Technology](https://himalayas.app/companies/markets/logistics-technology)

Kit Check, rebranded as Bluesight, is a leader in hospital pharmacy medication tracking and kit restocking automation, providing cloud-hosted software and IoT technology to improve efficiency and accuracy. Their solutions aim to bring visibility, simplicity, and predictability to medication supply management.

[Healthcare Technology](https://himalayas.app/companies/markets/healthcare-technology)[Medication Management](https://himalayas.app/companies/markets/medication-management)

Apella is a healthcare technology company that uses artificial intelligence, computer vision, and modern communications to improve surgical outcomes and operating room efficiency.

[Hospital Operations](https://himalayas.app/companies/markets/hospital-operations)[Healthcare Technology](https://himalayas.app/companies/markets/healthcare-technology)

Caresyntax provides an AI-powered surgical data platform that enhances the safety and efficiency of surgical procedures worldwide, allowing healthcare professionals to util

*[... truncated, 212 more characters]*

---

### Speakers - OR Manager Conference - 2025
*1,904 words* | Source: **GOOGLE** | [Link](https://www.ormanagerconference.com/speakers/)

Speakers - OR Manager Conference - 2025

===============
![Image 2](https://ipv4.d.adroll.com/px4/GRF2WTX3ENFVZOARHY6IYZ/X6YBME3QZJHKNCP5TZ7UCU?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&cookie=&adroll_s_ref=&keyw=&p0=6698)

![Image 3](https://d.adroll.com/cm/b/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 4](https://d.adroll.com/cm/bombora/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 5](https://d.adroll.com/cm/experian/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 6](https://d.adroll.com/cm/eyeota/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 7](https://d.adroll.com/cm/g/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 8](https://d.adroll.com/cm/index/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 9](https://d.adroll.com/cm/l/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 10](https://d.adroll.com/cm/n/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 11](https://d.adroll.com/cm/o/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 12](https://d.adroll.com/cm/outbrain/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 13](https://d.adroll.com/cm/pubmatic/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 14](https://d.adroll.com/cm/taboola/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 15](https://d.adroll.com/cm/triplelift/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 16](https://d.adroll.com/cm/x/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)

![Image 17](https://polo.feathr.co/v1/analytics/crumb?cb=ddffa9f514692&a_id=574f393d7c1fea3ecd8eebc1&ses_id=6936699279e34a8924ae515d&flvr=page_view&loc_url=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&s_w=800&s_h=600&b_w=1024&b_h=1024)![Image 18](https://ipv4.d.adroll.com/px4/GRF2WTX3ENFVZOARHY6IYZ/X6YBME3QZJHKNCP5TZ7UCU?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&cookie=GRF2WTX3ENFVZOARHY6IYZ%3A1%7CX6YBME3QZJHKNCP5TZ7UCU%3A1%7CFAJJCCVD5VGPRDUN2PILAL%3A1&adroll_s_ref=&keyw=&name=or_manager_conference_adroll&p0=6698)

![Image 19](https://d.adroll.com/cm/b/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 20](https://d.adroll.com/cm/bombora/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 21](https://d.adroll.com/cm/experian/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)![Image 22](https://d.adroll.com/cm/eyeota/out?adroll_fpc=ee216557e5c6e4ad6a0c2e023b145aa1-1765173648070&pv=30535272043.950256&arrfrr=https%3A%2F%2Fwww.ormanagerconference.com%2Fspeakers%2F&advertisable=GRF2WTX3ENFVZOARHY6IYZ)

*[... truncated, 37,816 more characters]*

---

### Going global
*928 words* | Source: **GOOGLE** | [Link](https://blog.techto.org/p/going-global)

**You are receiving the Community Edition of today’s newsletter —****[upgrade to a Member](https://link.mail.beehiiv.com/ss/c/u001.dnddMH0umBm-NwrAIVQnghdKcJ5bN0_uiBMTwm_GjvltUOR7qPBiSlNEa3ievQXDmg_1k-zHgdXG0IKLOGQJqou2UBbnJrD-pMaUQdkUeh3nHc9cN0Wl75KLP8VyBxGO826MphmmWVD2M_VmO8MJGEogKnu52wPB7IvQFFlAx0ClUNRI8Kl5TzPONyJKqeBO0eCc6NYnHeel9fl7ynY6EZfejaJHoyp7qh3wVJGFl2Q/4dz/gBlxglMFRdGOiDazIc6Ing/h7/h001.wVJvunFxT6UxBi3ber7Y9MNglr-hOIS2eAhKX_pYE54?utm_source=blog.techto.org&utm_medium=newsletter&utm_campaign=fool-me-once&_bhlid=85d552649eedf720bf1bc94fb302c6b9021361f3)****to receive additional perks and experiences**

**WHAT’S NEXT AT TECHTO?**👀
----------------------------

Our next TechTO event goes live tomorrow in Montreal!

Join us on April 16 and celebrate the best in tech, and those building big things in the Montreal ecosystem.

![Image 1](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/0c255cc9-ddb4-4e89-a106-be3af0ceab65/Copy_of_TechTO_Square_Posts_for_Events__Speakers__Sponsor_Thank_You.gif?t=1744241909)

Get ready for **Together Montreal TOMORROW April 16**, from 6:00 PM to 10:00 PM at HEC Montréal. Our past Montreal meet ups have brought together hundreds of keen tech professionals who are looking to get started, launch an idea or just meet someone new.

Here’s what else you can expect:

*   **Dive into discussions** with visionaries like **[Saam Mashhad](https://www.linkedin.com/in/saam-mashhad-47598639/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (EvenUp), **[Anna Chif](https://www.linkedin.com/in/annachif/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)**(Coral), and **[Richard Chénier](https://www.linkedin.com/in/rchenier/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (Québec Tech).

*   **Explore the cutting edge** with **[Guillaume Roy](https://www.linkedin.com/in/royguillaum/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (Workleap) and **[Lisa Israelovitch](https://www.linkedin.com/in/lisaisraelovitch/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (AssistIQ).

*   **Connect with industry titans** such as **[Patrick Ostiguy](https://www.linkedin.com/in/patrick-ostiguy-95a0521/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (Accedian & Liifer), **[Houssem Achouri](https://www.linkedin.com/in/houssemachouri/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)**(3dverse), **[Marie Chevrier Schwartz](https://www.linkedin.com/in/mariechevrier/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (TechTO), and **[Alex Norman](https://www.linkedin.com/in/alexanderlnorman/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** (N49P & TechTO).

Tickets include food and drinks! Don't miss out on this opportunity to connect, learn, and be inspired.

**PROFILE**🔍
-------------

Featuring the companies to watch, founders that should be on your radar, and more insights from the ecosystem you need to know about.

Today we meet **[3dverse](https://3dverse.com/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=going-global)** and Founder Houssem Achouri (who will be joining us in real life tomorrow in Montreal). If you’re not able to join us at tomorrow’s event in Montreal, here’s a little more insight on how they are revolutionizing 3D content creation and deployment.

#### **Give us more insights on the company?**

3dverse's mission is to simplify the deployment and the use of real-time 3D (RT3D) technology for digital twins. With its cloud-native real-time 3D operating system, 3dverse aims to break down the barriers that have hindered the widespread adoption of RT3D.​ ​

#### **What inspired this idea?**

Co-founded by myself and Sylvain Ordureau and Pierre-Adrien Forestier, the company emerged from my deep-seated frustration with the inefficiencies and fragmented workflows prevalent in traditional 3D development.

My experiences in the video game industry highlighted the critical need for a more unified and interconnected 3D ecosystem. This realization sparked the vision for 3dverse: a web-based platform intended to serve as the foundational layer for a collaborative "metaverse," enabling seamless integration and real-time interaction across various devices and systems.

#### **How do you build something like this?**

The first and most important step was building 3dverse from scratch. Assembling a team of expert developers was the most critical step. The platform was developed piece by piece, with a methodical approach. Each component was carefully designed, compared against existing solutions, and validated through experience. It was an intensive, deliberate process, but one that ensured a solid, scalable foundation.

#### **What advice do you have for today’s builders?**

First and foremost

*[... truncated, 5,216 more characters]*

---

---

## 🎬 YouTube Videos

- **[Lisa Israelovitch, Founder &amp; CEO, Umapped - Phocuswright Conference - 10 seconds](https://www.youtube.com/watch?v=zLwAk5Czg-U)**
  - Channel: TravelMedia.ie
  - Date: 2015-12-03

- **[Lisa Israelovitch, Founder &amp; CEO, Umapped - Phocuswright Conference 2015](https://www.youtube.com/watch?v=J-93r7IrEF4)**
  - Channel: TravelMedia.ie
  - Date: 2015-12-03

- **[Together With Women: Fireside with Lisa Israelovitch, Assist IQ](https://www.youtube.com/watch?v=CO0fVphhRMM)**
  - Channel: TechTO
  - Date: 2025-10-24

- **[HU&#39;s Rich Siegel Interviews CEO of Umapped.com at ITB Berlin](https://www.youtube.com/watch?v=jdamXGabLFg)**
  - Channel: HUTube Video Channel
  - Date: 2014-03-05

- **[Lisa Isrealovich, Umapped](https://www.youtube.com/watch?v=NVw-Si02Aws)**
  - Channel: Team B
  - Date: 2018-12-19

- **[Collaborative Itinerary powered by Umapped](https://www.youtube.com/watch?v=SHIyEUkX8S4)**
  - Channel: Lisa Israelovitch
  - Date: 2015-11-26

---

## 🔎 Press & Mentions

- **[AssistIQ raises $2.5 million CAD to cut down on medical waste in ...](https://betakit.com/assistiq-raises-2-5-million-cad-to-cut-down-on-medical-waste-in-hospitals/)**
  - Source: betakit.com
  - *Feb 28, 2023 ... Podcast · Newsletter · Quiz · Jobs. AssistIQ raises $2.5 million CAD to ... Lisa Israelovitch, AssistIQ's CEO and one of its founders...*

- **[AssistIQ raises $11.5M to scale AI-enabled supply tracking tech ...](https://www.mobihealthnews.com/news/assistiq-raises-115m-scale-ai-enabled-supply-tracking-tech)**
  - Source: mobihealthnews.com
  - *May 28, 2025 ... Podcasts · Provider · Payer · Pharma · Consumer · Investor. RESOURCES ... AssistIQ CEO Lisa Israelovitch said in a statement. "We're ...*

- **[AssistIQ Raises $11.5M to Scale AI-Enabled Supply Tracking ...](https://community.hlth.com/insights/news/assistiq-raises-11-5m-to-scale-ai-enabled-supply-tracking-technology-2025-05-29)**
  - Source: community.hlth.com
  - *May 29, 2025 ... Podcasts · Past Event Recordings · HLTH USA 2025 HLTH Europe 2025 ... Lisa Israelovitch, CEO of AssistIQ. "We're thrilled by the mark...*

- **[AssistIQ | Himalayas](https://himalayas.app/companies/assistiq)**
  - Source: himalayas.app
  - *FAQs. When was AssistIQ founded? AssistIQ was founded in 2021. Who is the CEO of AssistIQ? Lisa Israelovitch ......*

- **[Speakers - OR Manager Conference - 2025](https://www.ormanagerconference.com/speakers/)**
  - Source: ormanagerconference.com
  - *Lisa Israelovitch. CEOAssistIQ. Liz Fare, RN, BSN, CNOR. Customer Success ... Board & Management AdvisorAssistIQ. Simone Nicholson, DNP, MSN, RN, CNOR...*

- **[Going global](https://blog.techto.org/p/going-global)**
  - Source: blog.techto.org
  - *Apr 15, 2025 ... Explore the cutting edge with Guillaume Roy (Workleap) and Lisa Israelovitch (AssistIQ). ... The TiEQuest Summit (Thursday, June 26):...*

- **[TechTO x StandUp Ventures: Together With Women @ TechTO HQ ...](https://luma.com/StandUp-MTL)**
  - Source: luma.com
  - *Oct 24, 2025 ... Join Marie Chevrier Schwartz (TechTO) and Lisa Israelovitch (AssistIQ) for a raw, real conversation beyond the glossy headlines ......*

- **[AGENDA - SDTS and SAGES NBT Summit - February 2-4, 2023 ...](https://www.sages.org/wp-content/uploads/2023/02/2023-SDTS-AGENDA.pdf)**
  - Source: sages.org
  - *Feb 3, 2023 ... ... conference. M&M is an open forum were a surgeon discusses a ... • AssistIQ Technologies Inc - Lisa Israelovitch. • Exero Medical ....*

- **[Program Outline](https://www.sages2024.org/program-outline/)**
  - Source: sages2024.org
  - *... Lisa Israelovitch Emerging Technology, Sustainability. This session will ... AssistIQ was the 2023 winner of Shark Tank. This year's finalists wil...*

- **[AssistIQ](https://www.assistiq.ai/blog-post/our-story)**
  - Source: assistiq.ai
  - *Feb 23, 2023 ... Our Story · Compelling Data. The initial idea for AssistIQ started with Dr. · Our Founding Team. Lisa Israelovitch – Chief Executive ...*

---

*Generated by Founder Scraper*
