# Pauline Boisbouvier

## Position actuelle

**Titre** : Conferences, Workshops, Panels, etc.
**Entreprise** : Youth Medias Alliance, RVCQ, XnQuebec, Universités, etc.
**Durée dans le rôle** : 11 years 2 months in role
**Durée dans l'entreprise** : 11 years 2 months in company

## Localisation & Industrie

**Localisation** : Canada

## Description du rôle

• The rise of podcasting: why create audio content in a universe that runs on screens?
• Discoverability of online cultural products
• Create engagement for online content
Etc.

## Résumé

I'm a freelance creative producer who brings original stories and experiences to all types of audiences, and on all platforms. Passionate about media and content creation I've developed and produced projects from initial concept to launching campaign, including financing, the creation of multidisciplinary teams and production.

With over 15 years of experience in the industry, I've collaborated on projects in Canada and internationally, including Like-Moi!, ; LOOV, an interactive project tackling sex education for young people; the series Téodore pas de H (seen at CANNESeries), the youth multi-platform project L'effet secondary at ZONE3, web documentary Fort McMoney (URBANIA/NFB/ARTE) and transmedia project Apocalypse World War I (Ideacom International/CC&C).

I'm now working with multidisciplinary teams and specialized in innovative productions, mixing arts, medias and technology.

I'm currently working on several immersive or multi-platform projects.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACi23ABDooLt_YmWAeR5-2WeiIX-qOcZ0U/
**Connexions partagées** : 51


---

# Pauline Boisbouvier

## Position actuelle

**Entreprise** : HINT

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pauline Boisbouvier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394741697957556224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF30s8xiz-WNg/feedshare-shrink_800/B4EZp0e4wcKoAk-/0/1762890868020?e=1766620800&v=beta&t=mYUeZ8T6PkMJnVqmnMonzNBgT9TtcXW26WsGFws-MhY | Le futur des industries créatives c'est aujourd'hui que nous le bâtissons, avec les acteurs d'innovation de NOTRE industrie. Et il y en a!.
N'attendons pas que le train nous passe dessus, soyons les acteurs de cette transition avec des solutions technologiques qui nous ressemblent.

✨ Souveraineté numérique et culturelle.
"La technologie et la créativité ne font de sens ensemble que si la technologie nous ressemble" Dimitri Gourdin, Adm.A., PRP

Chez HINT, nos solutions sont pensées pour augmenter les compétences de vos experts en création de contenu. 
La technologie est un moyen de gagner en vélocité, en collaboration, et d'exploiter des données à grande échelle, dans le respect de la diversité des voix et des approches, essentielles à une offre de contenus diversifiée.

✨ Expérimenter, expérimenter, expérimenter!
"Il faut trouver des terrains d'expérimentation dans des paramètres qui nous permettent de comprendre comment les nouvelles technologies peuvent faire évoluer nos façons de créer du contenu."
Mélissa Hébert, Directrice plateformes et croissance numérique, Télé-Québec

Chez HINT, nous vous accompagnons dans ces étapes de transformation numérique.
Oui, ça implique d'avancer sur des pistes qui peuvent être inconfortables au début. Et oui vos processus vont et doivent évoluer. 
Ce sont autant des enjeux humains que technologiques, et nos solutions s'adaptent aux contextes spécifiques de chacun de nos clients et partenaires. 

Cela fait plus de 2 ans que nous travaillons sur ces approches. 
Aujourd'hui, nous sommes prêts à vous accompagner dans cette transition.

Merci à vous Zú, d'avoir été visionnaires et d'avoir été les premiers à croire en nous! 
D'ailleurs, les candidatures pour le Programme d’incubation sont en cours 
→ https://lnkd.in/eFdW9nRw

#innovation #souveraineténumérique #diversité #culture | 12 | 0 | 0 | 3w | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:15.269Z |  | 2025-11-13T14:23:28.450Z | https://www.linkedin.com/feed/update/urn:li:activity:7394100238292037632/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388960409514426369 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnksLJnKAw7A/feedshare-shrink_800/B4EZorcUqmIoAg-/0/1761665437338?e=1766620800&v=beta&t=dJKI7zXQSb6P5z_dj6wM4etOP-TOPU1cGtYY9Jv7zNs | Thank you TechTO for an energizing week of events in Montreal!

TechTO x StandUp Ventures: Together with Women:
A No Filter Conversation About What's Right Now an Investment Thesis. 
Yes, the market is shifting. AI is not the moat anymore—was it ever?—but being AI-enabled is a must. 
In the end, Sophie Forest and Katheleen Eva summed it up well: VCs still choose founders with a strong proposition. Be bold!

Le Collectif des Fondatrices, presented by BDC Fonds Excelles/Thrive Venture Fund.
It was a fun community gathering with open-hearted conversations where wins, challenges, and advice were shared. 
Thanks for giving us this space, I loved it!

Cheers to a week packed with learning and community gatherings!

Always nice to grow the female founders squad in my network :
👋 Carla Mbol Vicky Boudreau Elisabeth Gosselin MBA Morgane NETO Mathilde Léger

PS : Marie Chevrier Schwartz, you were right—TechTo's mug is my new favorite. ;) Thank you and the team for organizing these incredible events!
PS 2 : Thanks Danica Virginia Meredith for the photo. 
PS 3: The answer to my icebreaker question is that I wanted to be an archaeologist. I haven't discovered an unknown pyramid yet, but I'm helping companies find hidden nuggets in their data with HINT. I'd say I was already onto something!

#TechTO #LeCollectifDesFondatrices #FoundersCollective #WomenInTech #MontrealTech #BDCCapital #ThriveVentureFund #FemaleFounders #TechCommunity #Innovation #StartupCanada #CanadianTech | 35 | 3 | 2 | 1mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:15.271Z |  | 2025-10-28T15:30:41.874Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7387592018413264896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGfODVUMziqpw/feedshare-shrink_800/B4EZoX_yQsIoAg-/0/1761339188867?e=1766620800&v=beta&t=wgcgZXKd2455lEdTDxrEcCffplnleLSmzxITZ32PH3I | Quelle belle édition HUB Montréal:
Cette année encore l’événement a prouvé que la créativité numérique est bien vivante et que les talents d’ici n’ont pas peur de redéfinir le terrain de jeu de la création avec ambition!

Merci Rachel Parent, Lynda Gagnon (attachée économique et innovation à la Délégation générale du Québec à Paris (DGQP)), Dimitri Gourdin, Adm.A., PRP, Jeanne Dorelli et Gwenaël Bégasseël chez Zú, pour l’incroyable opportunité de pourvoir présenter HINT à Olivier Le Garlantezec, Global VP Tech Partnerships & Accelerator Programs chez LVMH, chef de file mondial du luxe.

✨ Coups de coeur programmation pour:
« Créer autrement : humains, arts et technologies » et « Au-delà du récit »
Les limites entre les médiums et les formats n’existent plus. Le mix est au contraire vecteur de sens et d’émotions, et ouvre une une multitude de voies pour réimaginer l’expérience des arts vivants, in situ, muséale et l’interaction avec le public. Sky is the limit..!
Sweet spot in my heart for Futures Rites (Sandra Rodriguez, Alexander Whitley, Marion Guth, Sébastien Grenier-Cartier) who made me miss my producer’s days! 🫶 

C’était bien le fun de reconnecter avec l’écosystème. Allo Vali Fugulin, Guillaume Therien, Marie Côté, Isabelle Roy est tous celles et ceux croisés pendant ces quelques jours.

#HUB2025 #HUBMTL #DigitalCreativity #Innovation #QuebecCreativity | 41 | 3 | 1 | 1mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:15.271Z |  | 2025-10-24T20:53:12.012Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7351295197453975554 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6igSV1l49Sw/feedshare-shrink_800/B4EZgUMASfHEAk-/0/1752685352735?e=1766620800&v=beta&t=DjIV5qPrDSLxHhCKUKQ7p8uca-8Rhk61uxCA5t0gsFg | Last week was crazy!
As usual, it's the community that makes Montreal's vibe shine the best!

📢 On Tuesday, I pitched in front of Canadian and international investors at the consortium Demo Day at Ax-C. 
Thanks Zú for the opportunity and to the consortium for organising the event Centech Mtl, ACET and Health Technology Catalyst | CTS. 
Thanks also to Caroline Pelletier for helping us refine our presentation. 
And a huge shout-out to the courageous people who also pitched: Vicky Boudreau, Carla Mbol, Marysol Moran, Tony Aubé, Jean-Francois Malouin and Tina Pranjic!

Then I jumped into the craziness of Startupfest, which was packed with learning opportunities, connections and inspiration! 
⭐ The BDC bootcamp for Women in Tech was a highlight as usual. 
⭐ The pitch competition gave me the opportunity to present HINT to many amazing judges, mentors, and peers. The vibe was electric, and the feedback from from the Women in Tech judges The Firehood was a blast and so insightful.
⭐ The Mentors Office Hours were honestly my favourite part, even though the conferences were excellent. It's an incredible opportunity to address issues in your business and receive valuable insights, advice, perspectives, peer feedback and connections to help you grow. 
You can literally ASK ANYTHING!

And, of course, there were the off-events where the community made magic happen: news from fellow founders, insights from ecosystem supporters and new connections to build our next chapter!
🫶  We feel grateful to be part of the AI Passeport initiative launched by NEXT AI AI Mila - Quebec Artificial Intelligence Institute and CDL-Montreal.
🙌 The Google for Startups Montreal 5@7 event is always a hit!
✌ Ben Su Investors & Founders Brunch was the perfect casual way to spend time with great minds.

So many connections, fellow founders, ecosystem supporters met, I can’t name them all, but I felt surrounded, supported and it gave me a boost to keep pushing.

I went back to the office this week with lots of ideas and thoughts to unpack and follow up on, but, more than anything, with a boost of energy to get s*** done.

See you next year!
Keep grinding and have an amazing summer! | 89 | 7 | 1 | 4mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.613Z |  | 2025-07-16T17:02:35.533Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7347988089534865408 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFnktxCTzRgng/feedshare-shrink_800/B4DZeOJX2ZGUAk-/0/1750436515292?e=1766620800&v=beta&t=GkYjEBNMh0KmeX8S1JTrZQCGgKkYtvRpza-Giglotc8 | Les choses s'accélèrent pour HINT!
Je présente demain nos derniers avancements et ce qui s'en vient dans les prochains mois au Demo Day Invest-Tech, un beau préambule au Startupfest.
On s'y voit?

Merci au consortium pour cette opportunité!
ACET Centech Mtl Health Technology Catalyst | CTS et Zú qui nous supporte depuis nos débuts. | 43 | 1 | 0 | 5mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.614Z |  | 2025-07-07T14:01:19.562Z | https://www.linkedin.com/feed/update/urn:li:activity:7341862888048857088/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7344785831116636160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9T3BGVqs3CQ/feedshare-shrink_800/B4EZe3ryOhGcAk-/0/1751133398676?e=1766620800&v=beta&t=TgSpt-yIigs5msWZzgQYYbKfMQ7KFbpbKqTD_ndvl_8 | The XX Summit was thrilling, I can’t believe it’s already over!

It was an honour to present HINT alongside this incredible group of female founders.
And I'm back home energized, and with a lot of thoughts to unpack to keep building!

Thank you Mama Bears, Arielle Land and Emily McBride, for holding us accountable, and to the entire Movement51 team for helping us prepare and get ready to take to the stage.
George Damian and Mert Yucesoy, thank you for the coaching and pep talk. Looking forward to cross your paths again!
Haley Daniels, OLY, thank you for helping us to breathe and manage our stress during this epic day. It was truly special to have an Olympian supporting us!

Last but not least, congratulations to you Shelley Kuipers and The51 team on the new fund. I'm very grateful to see you continuing to build and raise funds for a future where being female will make a difference.
And WE're here to make it happen!

Sajna Massey, MBA, P. Eng, Elaine Van, Nikky Starrett, Venessa Stonehouse, Latchmi Raghunanan, Ph.D., Jennifer Johnston, MD, Nicole Rosin, Carina Kom and Tina Merry, Patti Mara, Irene Rose Saliendra, Mansi B., Felicia Smart, Taylor Kawaguchi, Tevi Legge, Vanessa Tynes Jass, Sukhi Dhillon Alberga, B.A. (Hons), J.D., Melissa MacMaster.
You all CRUSHED it. 

#The51 #XXSummit #ElevateWomen | 43 | 5 | 2 | 5mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.615Z |  | 2025-06-28T17:56:41.660Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7343397687251156992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEetYr9q_WXzA/feedshare-shrink_800/B4EZej9SACHIAo-/0/1750802440965?e=1766620800&v=beta&t=_10RMbeoGOaPHSPs-T76-BH42qDRkED6wbm47mPWalE | After weeks of preparation, learning, and growing through the Movement51 Lab Founder, I am proud to be wrapping up the program by pitching HINT tomorrow at the The51 Movement51 XX Summit! 

This is more than just a pitch, it's the opportunity to share our vision with a room full of over 250 women, founders, investors and visionaries who are all shaping the future of our economy.
This is where bold ideas meet real actions.

See you there!

🗓️ XX Summit | June 25, 2025
📍 Platform Calgary | 35 | 2 | 1 | 5mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.615Z |  | 2025-06-24T22:00:42.372Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7338261401393672192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEVtnBlxiNmZg/feedshare-shrink_800/B4EZda92mTG4Ak-/0/1749577855374?e=1766620800&v=beta&t=0Sn3pnOzfua2w4hjlNin9b-fKRRMLi92Sq_lnrv-e2g | Conciliation startup / Famille.

On me demande régulièrement comment je fais pour avoir une startup en étant maman.
Je n’ai aucun conseil magique à donner sur le sujet. Je n'vous mentirais pas, c’est challengeant. Et y’a bien des journées où j’ai l’impression de ne pas avoir été la meilleure ou aussi présente que je l’aurai aimé dans ces deux sphères de ma vie.

On est une solide équipe avec mon conjoint, mais nos horaires professionnels un peu fous peuvent être un beau défi de planification familiale.
Avec pour conséquence de parfois devoir traîner mon fils à des événements professionnels. 
C’est pas idéal, et c’est toujours notre dernier recours.
C’est pas vraiment le fun pour lui et c’est aussi un beau défi de conciliation pour moi de tenter de mon mieux de m’occuper de lui tout en étant un minimum présente professionnellement!

C'était le cas il y a quelques semaines, lors du gala régional du Défi OSEntreprendre. 
Nous y avons eu l’honneur d’être lauréat régional avec HINT. 
Et j'ai réalisé à quel point c’est important d’expliquer ma réalité un peu plus à mon fils!

Une belle reconnaissance pour HINT, mais surtout un beau moment de fierté partagé avec mon garçon, pour qui soudainement le travail de sa maman a pris plus de sens.
Depuis je me sens moins coupable...et lui a eu 1000 idées de business : des pochettes de lavande pour vos garde-robes au stand de limonade devant la maison…! 

Demain, c'est le Gala national Desjardins du Défi OSEntreprendre.
Nous sommes bien fiers d'y être finaliste dans la catégorie Innovation technologique.
Mais c'est surtout une belle occasion de mettre un visage humain sur l'entreprenariat au Québec : il y a un super volet scolaire avec plusieurs initiatives qui y seront récompensées. Et c'est diffusé sur le web !(lien en commentaire)

#startup #entrepreneuriatquebecois #moijosentreprendre #galaDefiOSEntreprendre

Manon Théberge Louis-Félix Binette DEL - Développement économique de l'agglomération de Longueuil Zú NEXT AI Ville de Longueuil Montérégie Économique | 66 | 3 | 1 | 5mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.617Z |  | 2025-06-10T17:50:56.396Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7326684234440392706 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHFjYA1JK5AWA/feedshare-shrink_800/B4EZa2ceY1HcAk-/0/1746817642089?e=1766620800&v=beta&t=z4Cy3C6d-DGx6GWpN9i4aKGHHUtVXcxVfYEPoR5hjQI | Women empowering women.
When Movement51 tells you that, it's not just words, it's wisdom in action. Period.

Back from Calgary, after 3 days packed with learning and meaningful connections.

Honestly, I have rarely attended workshops with so much engagement, peer-to-peer contribution, and such a high level of content.
A big thank you to Shelley Kuipers, Leilani Mustillo, Kristyn Carriere, Paul Natland and Jason Thompson for sharing their knowledge and experience with such passion.

A special shout out to :
⭐ Amara Wynn, who's simplifies deal sourcing and access to capital with EasyVC
⭐ Tina Merry democratizing video games for diverse audiences with Simply Sweet Games
⭐ Rina Carlini, Ph.D. from our NEXT AI cohort, who continues to fight for women's access to science backed healthcare with Healthyher.Life™
⭐ Arielle Land & Emily McBride: you welcomed us with warmth and grace. I feel privileged to be part of this cohort.

And all the amazing women who work so hard and juggle everything to change the world as we know it: Sajna Massey, MBA, P. Eng, Elaine Van, Nikky Starrett, Venessa Stonehouse, Latchmi Raghunanan, Ph.D., Jennifer Johnston, MD, Leyla Kara, Nicole Rosin, Carina Kom, Patti Mara, Irene Rose Saliendra, Mansi B., Felicia B, Taylor Kawaguchi, Tevi Legge, Vanessa Tynes Jass, Sukhi Dhillon Alberga, B.A. (Hons), J.D., Melissa MacMaster.

The bar is high, but I feel empowered to be surrounded by all these incredible powerhouses.

I'm looking forward to the next 6 weeks.
See you at the XX Summit to showcase our kick ass 22 companies. | 57 | 8 | 4 | 6mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.618Z |  | 2025-05-09T19:07:24.701Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7323088427887845376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpulBYnG522g/feedshare-shrink_800/B4EZaDWG5JHIAs-/0/1745960335919?e=1766620800&v=beta&t=mqzdsBL44GtZaTcVZQwCFywFsVEeVXk1utOHeUrUr-o | Hier, je me suis sentie Québécoise et Canadienne plutôt deux fois qu'une.

🗳️ Première fois que j'étais appelée aux urnes pour voter. Première fois à contribuer à la vie politique de mon pays d'accueil en tant que nouvelle citoyenne,

🏅 Et une belle reconnaissance pour HINT qui reçoit la bourse en Entreprenariat féminin de la Fondation Guy Laliberté lors du Sommet Influence de Zú.

J'étais tellement surprise que je n'ai même pas pensé à prendre une photo...ça c'est moi dans mon char encore un peu sous le choc de l'émotion! Don't judge me... 

Je reprends ici quelques mots et remerciements dit sous le coup d'un peu trop d'émotion hier :

Je ne m’étais pas imaginé devenir entrepreneure quand je suis arrivée ici il y a 14 ans.  Mais une chose n’a pas changé : ma volonté de contribuer à la vie culturelle et économique de mon pays d’accueil.
Je remercie Patrick Fauquembergue qui avait déjà vu tout ca en moi avant même qu’on lance HINT. 

Cette bourse là, elle est spéciale parce que Zu, vous avez été les premiers à voir du potentiel dans ce qui était juste une idée. 
Merci à toute l’équipe, pour votre support sans faille, vous avez largement contribué à nous permettre de nous rendre là où nous sommes aujourd’hui. Dimitri Gourdin, Adm.A., PRP Pierre-Olivier Bontems Jeanne Dorelli Gwenaël Bégasse Pierre Steiner et toute l'équipe. 🙏 

Merci a la Fondation Guy Laliberté de contribuer à la poursuite de notre aventure entrepreneuriale. Cette bourse là, même si l’avenir est incertain, je vous promet qu’on va faire en sorte qu’elle ait le grand impact possible! 

Un chaleureux merci à tous nos collaborateurs, clients, partenaires et mentors qui nous ont supporté jusqu'ici et qui continuent de nous faire confiance, parce qu’on est plus déterminés que jamais et on a de grandes ambitions pour cette année encore! | 182 | 58 | 1 | 7mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.619Z |  | 2025-04-29T20:58:57.612Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7316218221026529281 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEdzDMVh1v2Tw/feedshare-shrink_800/B4EZYhtst4HkAg-/0/1744322351246?e=1766620800&v=beta&t=G9vmlW-Y8FW-cCb1Hw1kPa5MM6g77DBtLCQq5mB6FO8 | Québec, c’était express mais c’était riche!

De retour de Rendez-vous numérique où HINT était startup exposante aux côtés de Jaqln.ai (team NEXT AI2024!), Panorama, Dok2u et EnJoy Social, menés par les brillant.e.s Roxanne Lessard, Justine Dupuis Soulière, Extra Junior Laguerre, Frederic Leblanc et Xavier Ménard-Beaudoin. 

Un beau programme pour cette première édition organisée par Capitale Numérique et une journée intense en rencontres!
Je reviens la tête remplie d’idées et de conversations à poursuivre…
👋 Catherine Mathys, Stéphane Carpentier, Nicole Meneteu,Marie-Andrée Gingras, Adam Pawliwec, MBA, Jeff Carrier, Séverine LeBlanc, Geoffrey Blanc, PMP, Michael James Bedford, Mathieu Moquin, Carl Frédéric De Celles, Cassie L. Rhéaume et Franck Clerget!

#IA #RDVnum #RDVnum2025 #StartupQuébécoise | 56 | 14 | 1 | 7mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.621Z |  | 2025-04-10T21:59:12.654Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7308997698295115776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErGY6yPkvZyQ/feedshare-shrink_800/B4EZW7GqwhH0Ag-/0/1742600844313?e=1766620800&v=beta&t=XRx-vutxx7coK6UhsTJEmSfyvNO7A5GExyraDea0gVQ | [Retour sur La Tournée des Maillages PME-Startups]
Mardi, j’y partageais notre expérience de collaboration entre startup et PME / grande entreprise.

Chez HINT, c’est un processus d’apprentissage continu :
🎯 Pour nos clients : vous êtes importants et notre priorité, TOUS LES JOURS. 
Pour une startup, vous êtes un partenaire stratégique dans le développement de notre entreprise. 
Pour nous, en tant que startup, c’est : 
🚀 la possibilité de travailler sur des projets d’envergure ou avec un potentiel de réplicabilité;
💲 l’opportunité de faire de faire de ces cas d’usage des leviers de R&D, de financement ou de ventes

Je souligne également les interventions très pertinentes de :
- Julie Ethier, Leader en chef DEL - Développement économique de l'agglomération de Longueuil et Présidente de Montérégie Économique, qui a fait un état très bien documenté de la situation économique avec nos voisins américains. Oui le bilan est alarmant, mais il faut réfléchir à long terme et des soutiens existent pour les entreprises locales. 
- Richard Chénier, Directeur général de Québec Tech, qui nous a rappelé le retard du Canada sur l’échelle de la productivité mondiale et qu’une crise économique c’est une occasion de transformer la situation en opportunité! À nous de les créer et de les saisir!

Merci à Marcos Pereira pour l’organisation du Panel sur la collaboration PME-Startups, à Ghislain Nadeau de Prompt pour son animation efficace, et à Remi Dion et Isabelle Bastien Barrette pour leurs partages lors du panel. | 39 | 10 | 0 | 8mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:17.622Z |  | 2025-03-21T23:47:25.884Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7305000730896052225 | Article |  |  | [Keep learning, one step closer to your goals.]

Last fall, I was honoured to participate in Flip The Script, a groundbreaking program from the Canadian Women's Chamber of Commerce (CanWCC) that taught me to advocate for myself and my business in a new way. 

CanWCC is the first (and only) chamber of commerce representing the more than 1.2 million diverse women-identified and non-binary entrepreneurs, self-employed professionals and business owners in Canada. Flip the Script is their response to the striking gender gap in access to capital.

The program provides actionable insights, but I've especially enjoyed the 'safe space' and heartfelt discussions we've created with our group. And I've met incredible entrepreneurs along the way! Marion Knaus, Morley, Kara Wardinger and Marie-Louise KALONJI, I'm glad we got to share a bit of our journey together!

#FlipTheScript #WomenInBusiness #CanadianEntrepreneur | 21 | 5 | 3 | 8mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:19.709Z |  | 2025-03-10T23:04:54.596Z | https://credsverse.com/credentials/83cb5ace-7b99-4409-a3be-bffe3e989932 |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7301271021238505472 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG26pDe7ohYKg/feedshare-shrink_800/B56ZVDIqjoGoAg-/0/1740588100526?e=1766620800&v=beta&t=VDboscWn4paZhxrYzZ9fev9KydyLK7NLbfLrLSKID3U | I'm more than excited to join the Movement51 2025 cohort!

We have big ambitions for HINT this year. I can't wait to dive in and meet all the amazing other founders! 🔥 | 12 | 4 | 0 | 9mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:19.709Z |  | 2025-02-28T16:04:22.519Z | https://www.linkedin.com/feed/update/urn:li:activity:7300555652911833091/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7300178118584016897 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEJe-X9c6fv8A/feedshare-shrink_800/B56ZU9xT43GQAo-/0/1740498092665?e=1766620800&v=beta&t=itjeLi6_XY0YOU8tZauB6qalINrgJqCm4CCC7QgYwmI | Demain débute E-AI, le grand rassemblement des industries créatives et de l’IA.
Ce qui m’a le plus interpellé dans l’événement c’est son positionnement : mettre l’humain au coeur de la créativité. 
Et c’est exactement notre approche chez HINT !

J’y serai demain pour présenter ce que nous bâtissons et comment nous supportons les créateurs pour leur permettre d’utiliser l’IA pour continuer à amener des réflexions pertinentes. 
On s'y voit?

📅  Mercredi 26 février, à 16:00
📍 Scène Communauté, Palais des Congrès de Montréal 

Il reste encore des places :
🎟️ billetterie https://lnkd.in/g4uUFsJ7
Code rabais : SPEAKER30

#EAI2025 #ONAHUMANSCALE #AECHELLEHUMAINE #CULTUREQC #CULTUREQCMONDE
Zú DEL - Développement économique de l'agglomération de Longueuil NEXT AI | 39 | 6 | 1 | 9mo | Post | Pauline Boisbouvier | https://www.linkedin.com/in/paulineboisbouvier | https://linkedin.com/in/paulineboisbouvier | 2025-12-08T04:56:19.710Z |  | 2025-02-25T15:41:34.221Z |  |  | 

---



---

# Pauline Boisbouvier
*HINT*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [hint-me.ca](https://hintme.ca/)
*2025-01-01*
- Category: article

### [Pauline Laigneau, inspiring generations of entrepreneurs with Gemmyo](https://medium.com/design-bootcamp/pauline-laigneau-inspiring-generations-of-entrepreneurs-with-gemmyo-28b1eeccaa64)
*2023-10-26*
- Category: blog

### [](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau)
- Category: article

### [Q&A Flore des Robert and Pauline Laurent : Co-founder of La Bonne Brosse](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse)
*2022-12-29*
- Category: blog

### [Adding a HINT of Success to Your Business, Kara Goldin](https://www.potentialtopowerhouse.com/blog/33-adding-a-hint-of-success-to-your-business-with-kara-goldin-of-ceo-of-hint-inc)
*2021-09-15*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 56,561 words total*

### hint-me.ca
*1,915 words* | Source: **EXA** | [Link](https://hintme.ca/)

Découvrez notre plateforme
--------------------------

#### Un outil de recherche unifié

#### Un outil de recherche unifié

#### Un outil de recherche unifié

![Image 1](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:451)

HINT rassemble des **informations contextualisées** par sujet — issues de vos contenus internes, de sources web et de modèles d’IA — dans une interface unique et intelligente, pour **retrouver rapidement l’essentiel, où qu’il se trouve.**

#### Un compagnon d'écriture

#### Un outil de recherche unifié

#### Un outil de recherche unifié

![Image 2](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:451)

HINT est votre allié créatif : l'outil vous **suggère des questions à adresser** pour enrichir et structurer le contenu, propose des **pistes à explorer** pour ouvrir de nouvelles perspectives, et signale les **points essentiels à valider** (conformité aux normes, alignement avec les objectifs stratégiques).

Nos dernières nouvelles
-----------------------

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

![Image 3](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**24 septembre 2025**

 Chez HINT, nous mettons l’humain et l’expertise des créateurs au centre de nos solutions. Notre équipe sera à ALL IN 2025 pour échanger sur vos besoins et réfléchir ensemble au rôle que peut jouer l’IA dans la création de contenu.

#### HINT participe au Demo Day du Consortium à Invest-Tech 2025 à Ax-C

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

![Image 4](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**9 juillet 2025**

HINT présent au Démo Day de l’Accélérateur DEL, aux côtés d’une dizaine d’entreprises innovantes de la Rive-Sud.

 Nous avons eu l’occasion de pitcher sur scène, de rencontrer plusieurs visiteurs et de présenter nos derniers avancements.

#### HINT participe au Demo Day du XX Summit à Calgary

#### HINT participe à ALL IN pour discuter de la création de contenu avec l’IA

#### HINT participe au Demo Day du XX Summit à Calgary

![Image 5](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**25 juin 2025**

HINT a participé au Demo Day du XX Summit à Calgary, concluant sa participation au Founder Lab de Movement51. L’événement a permis de découvrir des ventures en phase initiale, prêtes à recevoir capital, conseils et soutien stratégique.

#### HINT pitch sur scène au Demo Day de l’Accélérateur DEL

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

![Image 6](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**17 juin 2025**

HINT présent au Démo Day de l’Accélérateur DEL, aux côtés d’une dizaine d’entreprises innovantes de la Rive-Sud.

 Nous avons eu l’occasion de pitcher sur scène, de rencontrer plusieurs visiteurs et de présenter nos derniers avancements.

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

![Image 7](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**20 mai 2025**

HINT est heureux d'être annoncé parmi les finalistes nationaux de la catégorie Innovations Technologique et Technique du volet Création d'Entreprise dans la 27e édition du Défi OSEntreprendre.

#### Lancement de la cohorte 2025 du Lab des Fondatrices de Movement51

#### HINT parmi les finalistes nationaux dans la 27e édition du Défi OSEntreprendre

#### HINT gagnant de la bourse Entrepreneuriat au Féminin de la Fondation Guy Laliberté

![Image 8](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**15 mai 2025**

Founder Lab est conçu pour aider les femmes fondatrices à aquérir les connaissances, les outils et le réseau nécessaire afin d'aborder la levée de fonds avec confiance. Pauline Boisbouvier, la CEO et co-fondatrice de HINT est fière de faire partie de ce programme avec Movement51.

#### HINT gagnant de la bourse Entrepreneuriat au Féminin de la Fondation Guy Laliberté

#### HINT gagnant de la bourse Entrepreneuriat au Féminin de la Fondation Guy Laliberté

#### HINT gagnant de la bourse Entrepreneuriat au Féminin de la Fondation Guy Laliberté

![Image 9](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**28 avril 2025**

HINT a l'honneur et la surprise de gagner la bourse Entrepreneuriat au Féminin de la Fondati

*[... truncated, 9,317 more characters]*

---

### 410 Deleted by author — Medium
*32 words* | Source: **EXA** | [Link](https://medium.com/design-bootcamp/pauline-laigneau-inspiring-generations-of-entrepreneurs-with-gemmyo-28b1eeccaa64)

410 Deleted by author — Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F28b1eeccaa64&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderCollection&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2Fdesign-bootcamp%2Fpauline-laigneau-inspiring-generations-of-entrepreneurs-with-gemmyo-28b1eeccaa64&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2Fdesign-bootcamp%2Fpauline-laigneau-inspiring-generations-of-entrepreneurs-with-gemmyo-28b1eeccaa64&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 1](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

Error

410

The author deleted this Medium story.

---

### Meet Pauline Laigneau's Selected Artworks | Art for Sale | Artsper (8931)
*4,659 words* | Source: **EXA** | [Link](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau)

Meet Pauline Laigneau's Selected Artworks | Art for Sale | Artsper (8931)

===============

![Image 6: logo](blob:http://localhost/36973e8e4e539d4f310fa20e5799c098)

[](https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/)

*   [Consent](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)
*   [Details](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)
*   [[#IABV2SETTINGS#]](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)
*   [About](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services. 

Consent Selection

**Necessary** 

- [x] 

**Preferences** 

- [x] 

**Statistics** 

- [x] 

**Marketing** 

- [x] 

[Show details](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)

Details

*   
Necessary  19- [x]   Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies. 

    *   [Cookiebot 1](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 7](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.cookiebot.com/goto/privacy-policy/ "Cookiebot's privacy policy")**CookieConsent**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 1 year**Type**: HTTP Cookie   
    *   [Google 1](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 8](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://business.safety.google/privacy/ "Google's privacy policy")Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.

**test_cookie**Pending**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie   
    *   [LinkedIn 2](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 9](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.linkedin.com/legal/privacy-policy "LinkedIn's privacy policy")**bcookie**Used in order to detect spam and improve the website's security. **Maximum Storage Duration**: 1 year**Type**: HTTP Cookie  **li_gc**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [PayPal 1](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 10](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.paypal.com/us/webapps/mpp/ua/privacy-full "PayPal's privacy policy")**__paypal_storage__**Used in context with the PayPal payment-function on the website. The cookie is necessary for making a safe transaction through PayPal. **Maximum Storage Duration**: Persistent**Type**: HTML Local Storage   
    *   [Pinterest 2](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 11](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://policy.pinterest.com/en/privacy-policy "Pinterest's privacy policy")**ar_debug**Checks whether a technical debugger-cookie is present. **Maximum Storage Duration**: 1 year**Type**: HTTP Cookie  **is_eu**Determines whether the user is located within the EU and therefore is subject to EU's data privacy regulations. **Maximum Storage Duration**: Session**Type**: HTML Local Storage   
    *   [Stripe 3](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this provider![Image 12](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://stripe.com/privacy "Stripe's privacy policy")**m**Determines the device used to access the website. This allows the website to be formatted accordingly. **Maximum Storage Duration**: 400 days**Type**: HTTP Cookie  **__stripe_mid**This cookie is necessary for making credit card transactions on the website. The service is provided by Stripe.com which allows online transactions without storing any credit card information.**Maximum Storage Duration**: 1 year**Type**: HTTP Cookie  **__stripe_sid**This cookie is necessary for making credit card transactions on the website. The service is provided by Stripe.com which allows online transactions without storing any credit card information.**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie   
    *   [m.stripe.com 3](https://www.artsper.com/ca/experts-selections/8931/meet-pauline-laigneau#)[Learn more about this prov

*[... truncated, 51,417 more characters]*

---

### Q&A Flore des Robert and Pauline Laurent : Co-founder of La Bonne Brosse
*3,990 words* | Source: **EXA** | [Link](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse)

Interview Flore & Pauline | La Bonne Brosse aka The Good Brush 

===============
[Skip to content](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#MainContent)

[No Tariff, Duties or Additional Costs on US orders. Free shipping on all orders over $230](https://www.labonnebrosse.com/en-us/collections/nos-brosses-a-cheveux)

*   
 Shop 

 Shop 
    *   [Black Edition](https://www.labonnebrosse.com/en-us/collections/collection-black-edition)
    *   [Large brushes](https://www.labonnebrosse.com/en-us/collections/nos-brosses-a-cheveux)
    *   [Small brushes](https://www.labonnebrosse.com/en-us/collections/nos-petites-brosses)
    *   [Textured hair](https://www.labonnebrosse.com/en-us/collections/cheveux-textures)
    *   [Baby brushes](https://www.labonnebrosse.com/en-us/collections/ma-premiere-brosse)
    *   [Blow-dry brushes](https://www.labonnebrosse.com/en-us/collections/nos-brosses-rondes)
    *   [Pouches](https://www.labonnebrosse.com/en-us/collections/nos-pochettes)
    *   [Accessories](https://www.labonnebrosse.com/en-us/collections/nos-accessoires)
    *   [Detangling combs](https://www.labonnebrosse.com/en-us/collections/peignes)
    *   [Cair Ritual](https://www.labonnebrosse.com/en-us/collections/nos-produits-cair)
    *   [All products](https://www.labonnebrosse.com/en-us/collections/tous-nos-produits)

*   [Holiday Offers](https://www.labonnebrosse.com/en-us/collections/la-selection-cadeau)
*   [Hair quiz](https://www.labonnebrosse.com/en-us/pages/formulaire-diagnostic)
*   [Cair Ritual](https://www.labonnebrosse.com/en-us/pages/soins-cair)
*   
 About 

 About 
    *   
 Our commitments 

 Our commitments 
        *   [Our philosophy](https://www.labonnebrosse.com/en-us/pages/notre-philosophie)
        *   [Made in France](https://www.labonnebrosse.com/en-us/pages/notre-engagement-made-in-france)
        *   [Materials](https://www.labonnebrosse.com/en-us/pages/nos-materiaux-responsables)
        *   [Design](https://www.labonnebrosse.com/en-us/pages/un-tres-bel-objet-du-quotidien-doux-et-confortable-efficace-et-durable)
        *   [Partners](https://www.labonnebrosse.com/en-us/pages/nos-partenaires)

    *   
 Your needs 

 Your needs 
        *   [Volume](https://www.labonnebrosse.com/en-us/pages/comment-donner-du-volume-a-ses-cheveux)
        *   [Shine](https://www.labonnebrosse.com/en-us/pages/comment-avoir-des-cheveux-brillants)
        *   [Density & Regrowth](https://www.labonnebrosse.com/en-us/pages/comment-stimuler-la-pousse-des-cheveux)
        *   [Hydration & Nutrition](https://www.labonnebrosse.com/en-us/pages/comment-hydrater-et-nourrir-ses-cheveux)
        *   [Space out washes](https://www.labonnebrosse.com/en-us/pages/comment-espacer-les-shampoings)
        *   [Treat the scalp](https://www.labonnebrosse.com/en-us/pages/comment-traiter-le-cuir-chevelu)
        *   [Curly hair](https://www.labonnebrosse.com/en-us/pages/brosser-ses-cheveux-boucles-dossier-special-la-bonne-brosse)
        *   [Baby hairbrush](https://www.labonnebrosse.com/en-us/pages/la-brosse-bebe-ma-premiere-brosse)

    *   
 tips 

 tips 
        *   [Rituals](https://www.labonnebrosse.com/en-us/pages/nos-rituels-de-brossage)
        *   [Benefits](https://www.labonnebrosse.com/en-us/pages/les-bienfaits-du-brossage-pour-vos-cheveux)
        *   [Holistic approach](https://www.labonnebrosse.com/en-us/pages/lapproche-holistique)
        *   [Care tips](https://www.labonnebrosse.com/en-us/pages/nettoyer-et-entretenir-sa-brosse-en-poils-de-sanglier)

*   
 Help 

 Help 
    *   [Q&A](https://www.labonnebrosse.com/en-us/pages/questions-frequentes-1)
    *   [Contact us](https://www.labonnebrosse.com/en-us/pages/contact)

[Log in](https://www.labonnebrosse.com/a/account/login)

Country/region
--------------

United States | $

Search 

*   [Belgium EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [France EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [Switzerland EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [United States USD $](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)

*   [Afghanistan EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [Åland Islands EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [Albania EUR €](https://www.labonnebrosse.com/en-us/blogs/soins-cheveux/q-a-flore-des-robert-et-pauline-laurent-co-fondatrice-la-bonne-brosse#)
*   [Algeria EUR €](https://www.labonnebrosse.com/en-us/blogs/so

*[... truncated, 119,187 more characters]*

---

### Adding a HINT of Success to Your Business, Kara Goldin
*722 words* | Source: **EXA** | [Link](https://www.potentialtopowerhouse.com/blog/33-adding-a-hint-of-success-to-your-business-with-kara-goldin-of-ceo-of-hint-inc)

When Kara Goldin realized diet soda was contributing to feeling sluggish, and not losing weight, she started cutting back drinking the 6 to 10 cans of diet soda she drank daily. Two and a half weeks after she stopped her daily diet coke habit, her skin cleared up, her energy levels increased, and she lost 24 pounds. Her alternative drink at that time? Homemade, fruit flavored water. She found herself curious as to why, and how, a HINT of fruit water could be made available to consumers everywhere. From that experiment, she birthed her billion dollar idea, she pursued the idea of what is famously known today as HINT water, the leading unsweetened flavored water. The Huffington Post listed her as one of six disruptors in business, alongside Steve Jobs and Mark Zuckerberg. Tune into today’s episode to hear more about her business journey and how she turned all the obstacles into good lessons and new chances.

**In This Episode:**

[03:02] What makes HINT water different than other flavored bottled water on the market that has sugar and carbohydrates.

[06:38] Even when you do your best to prepare for every situation, challenges happen, and that’s where you build resilience.

[12:00] How pandemics influenced the production of Kara’s HINT water?

[19:20] The moment Kara realized she wanted to take a break and spend more time with her kids.

[20:54] When Kara started paying attention to the ingredients of the food she ate, she realized she wanted to do the same thing with the beverages she drank. The results were shocking.

[27:01] Why Kara’s conversation with a senior executive from Coca-Cola didn’t really go well.

[37:15] How Kara managed to self-fund her business?

[42:05] In what ways does having a formal board in the company change things?

[48:40] How to reach out to founders from the investment companies and propose an investment?

**Key Takeaways:**

Always do your best to prepare. Do your best to do what you can, even when something bad happens along the way.

When you aren't able to get workers, having an automated way of doing business is saving you.

Sometimes unavoidable conversations allow you to confirm more about what you need to do.

Having competition is not a bad thing because you actually validate the category.

**Quotes:**

“Always do your best to prepare.” - Kara Goldin

“Always thinking about how you can do better is really the key.” - Kara Goldin

**CONNECTIONS:**

For more about Kara Goldin, follow her on[Instagram](https://www.instagram.com/karagoldin/) and [Twitter](https://twitter.com/karagoldin). Also, be sure to check out [DrinkHINT.com](https://www.drinkhint.com/).

Check out our website,[Potential to Powerhouse](https://www.potential2powerhouse.com/), for more details and to learn about past, present, and future guests. Be sure to follow us on[Instagram](https://www.instagram.com/potentialtopowerhouse/) and[Twitter](https://www.twitter.com/potential2power), and join our[Facebook Community](https://www.facebook.com/groups/potentialtopowerhouse) for a deeper connection with the P2P tribe.

Grab your free copy of our guide,[4 Daily Habits Essential to Becoming a POWERHOUSE Entrepreneur](https://www.potential2powerhouse.com/habits), and don’t forget to subscribe to our show and leave a rating and review. Do you know any other female powerhouses that could benefit from listening? If so, please let them know to follow us on Apple Podcasts, Spotify, or wherever they like to listen to valuable audio content.

Until next time… High Five!

**Bio:**

Kara Goldin is the Founder and CEO of HINT, Inc., best known for its award-winning HINT water, the leading unsweetened flavored water.

She has received numerous accolades, including being named EY Entrepreneur of the Year 2017 Northern California, one of InStyle’s 2019 Badass 50, Fast Company’s

Most Creative People in Business, WWD Beauty Inc.’s Feel Good Force and Fortune’s Most Powerful Women Entrepreneurs.

The Huffington Post listed her as one of six disruptors in business, alongside

Steve Jobs and Mark Zuckerberg. Previously, Kara was VP of Shopping and Ecommerce at America Online where she helped lead the growth of its shopping and e-commerce business to over a $1 billion in revenue.

She is an active speaker and writer and, in 2017, she launched The Kara Goldin Show, a podcast where she interviews founders, entrepreneurs and disruptors across various industries. Kara’s first book, Undaunted: Overcoming Doubts and Doubters, published by Harper Leadership, was released October 2020 and is now a WSJ and Amazon Best Seller. Kara lives in the Bay Area with her family.

Join the Powerhouse Movement!
-----------------------------

Connect with other female entrepreneurs in our Potential to Powerhouse Community on Facebook.

[JOIN FOR FREE](https://www.facebook.com/groups/potential2powerhouse)

---

### PODCAST & interview audio – Qui fait Quoi / Lien MULTIMÉDIA
*1,577 words* | Source: **GOOGLE** | [Link](https://lienmultimedia.com/spip.php?mot6953)

[![Image 1](https://lienmultimedia.com/local/cache-gd2/bb/1a7c6e9a7411002ee69a27c5f63125.jpg?1737704081)](https://lienmultimedia.com/spip.php?article104546)

[![Image 2](https://lienmultimedia.com/local/cache-gd2/fb/71521bd4e564c7b7f16221cf5601e5.jpg?1737429724)](https://lienmultimedia.com/spip.php?article104479)

[![Image 3](https://lienmultimedia.com/local/cache-gd2/5d/b94d1aa42f3a81435a92aaeb88ca22.jpg?1733376623)](https://lienmultimedia.com/spip.php?article103358)

[PODCAST: Entrevue avec la musicienne Bana Haffar](https://lienmultimedia.com/spip.php?article103358)
-----------------------------------------------------------------------------------------------------

Marie-Hélène Brousseau a rencontré la musicienne Bana Haffar à l’été 2024, à l’occasion de sa première performance au festival MUTEK. Montréalaise d’adoption, cette passionnée des synthétiseurs s’est installée dans la métropole pour compléter des études universitaires à Concordia, au(…)

[Suite](https://lienmultimedia.com/spip.php?article103358)

[![Image 4](https://lienmultimedia.com/local/cache-gd2/56/0601a6958cc9ffef778d6d387a4f94.jpg?1732771839)](https://lienmultimedia.com/spip.php?article103341)

[![Image 5](https://lienmultimedia.com/local/cache-gd2/ee/3900e713ce10e873d662f6da9ba09b.jpg?1739892568)](https://lienmultimedia.com/spip.php?article105035)

[![Image 6](https://lienmultimedia.com/local/cache-gd2/84/58206c8a440f8650b41edfbb2b7d35.jpg?1739338261)](https://lienmultimedia.com/spip.php?article104913)

[![Image 7](https://lienmultimedia.com/local/cache-gd2/d2/d0eae49108f644b3116ce516e03448.jpg?1739026207)](https://lienmultimedia.com/spip.php?article104865)

[![Image 8](https://lienmultimedia.com/local/cache-gd2/bb/1a7c6e9a7411002ee69a27c5f63125.jpg?1737704081)](https://lienmultimedia.com/spip.php?article104546)

[![Image 9](https://lienmultimedia.com/local/cache-gd2/fb/71521bd4e564c7b7f16221cf5601e5.jpg?1737429724)](https://lienmultimedia.com/spip.php?article104479)

[![Image 10](https://lienmultimedia.com/local/cache-gd2/5d/b94d1aa42f3a81435a92aaeb88ca22.jpg?1733376623)](https://lienmultimedia.com/spip.php?article103358)

[PODCAST: Entrevue avec la musicienne Bana Haffar](https://lienmultimedia.com/spip.php?article103358)
-----------------------------------------------------------------------------------------------------

Marie-Hélène Brousseau a rencontré la musicienne Bana Haffar à l’été 2024, à l’occasion de sa première performance au festival MUTEK. Montréalaise d’adoption, cette passionnée des synthétiseurs s’est installée dans la métropole pour compléter des études universitaires à Concordia, au(…)

[Suite](https://lienmultimedia.com/spip.php?article103358)

[![Image 11](https://lienmultimedia.com/local/cache-gd2/56/0601a6958cc9ffef778d6d387a4f94.jpg?1732771839)](https://lienmultimedia.com/spip.php?article103341)

[![Image 12](https://lienmultimedia.com/local/cache-gd2/ee/3900e713ce10e873d662f6da9ba09b.jpg?1739892568)](https://lienmultimedia.com/spip.php?article105035)

[![Image 13](https://lienmultimedia.com/local/cache-gd2/84/58206c8a440f8650b41edfbb2b7d35.jpg?1739338261)](https://lienmultimedia.com/spip.php?article104913)

[![Image 14](https://lienmultimedia.com/local/cache-gd2/d2/d0eae49108f644b3116ce516e03448.jpg?1739026207)](https://lienmultimedia.com/spip.php?article104865)

[![Image 15](https://lienmultimedia.com/local/cache-gd2/bb/1a7c6e9a7411002ee69a27c5f63125.jpg?1737704081)](https://lienmultimedia.com/spip.php?article104546)

[](https://lienmultimedia.com/spip.php?mot6953)

[![Image 16: Éric Bruneau et Alec Castonguay dévoilent les coulisses de la pandémie dans « Le printemps le plus long »](https://lienmultimedia.com/local/cache-gd2/5e/9e9e84d970b0d39424a8d7f718b82a.jpg?1739893401)](https://lienmultimedia.com/spip.php?article105035)

### [Éric Bruneau et Alec Castonguay dévoilent les coulisses de la pandémie dans «Le printemps le plus long»![Image 17](https://lienmultimedia.com/squelettes/images/icn_key_green.png)](https://lienmultimedia.com/spip.php?article105035)

Bientôt cinq ans après l’arrivée du virus de la COVID-19 dans nos vies, Éric Bruneau donne la parole aux individus qui, du jour au lendemain, ont dû s’assurer que le Québec passe à travers la pire crise qu’il n’ait jamais vécue. Leurs révélations sur les coulisses de la pandémie feront voir les événements d’une toute nouvelle manière.

18 février 2025, 00h30

[![Image 18: Télé-Québec termine « Pilotes de brousse », Anik Jean prolonge le voyage en balado](https://lienmultimedia.com/local/cache-gd2/67/9f058648521247b4fd4500c28b0bea.jpg?1739339172)](https://lienmultimedia.com/spip.php?article104913)

### [Télé-Québec termine «Pilotes de brousse», Anik Jean prolonge le voyage en balado![Image 19](https://lienmultimedia.com/squelettes/images/icn_key_green.png)](https://lienmultimedia.com/spip.php?article104913)

Le jeudi 13 février 2025, Télé-Québec diffuse le dernier épisode de la série documentaire «Pilotes de brousse». Or, l’aventure n’est pas pour aut

*[... truncated, 11,987 more characters]*

---

### Next Canada - Ventures
*19,452 words* | Source: **GOOGLE** | [Link](https://www.nextcanada.com/directory/ventures/)

Tenomix Inc.
------------

Tenomix is medical-technology startup that is revolutionizing the way cancer tissues are processed in pathology laboratories using robotics, ultrasound imaging and AI. With our current patent-pending platform technology, we are currently automating a tedious, unreliable, and expensive process in the colon cancer staging pathway: the manual lymph node search process.

Local Energy Solutions
----------------------

Local Energy Solutions se consacre à l'efficacité énergétique en exploitant l'énergie résiduelle des processus industriels. Notre Laboratoire Virtuel aide les fournisseurs d'infrastructures dans la planification et le développement de projets d'infrastructures énergétiques. Complétant le Laboratoire Virtuel, notre plateforme marketplace permet des transactions énergétiques en temps réel entre les usines industrielles voisines. La plateforme permet non seulement le commerce de pair à pair, mais transforme également les infrastructures industrielles en marchés énergétiques locaux (LEMs), réduisant ainsi la consommation d'énergie totale consommée.

Cranberry Payments
------------------

Cranberry Payments effortlessly protects a merchant's payments with three lean solutions across a single unified platform. Cranberry Payments uses artificial intelligence to detect fraud at the point of sale, automates chargeback disputes, and quantifies a cardholder's risk for a potential chargeback claim.

Analyst3
--------

Deal sourcing and diligence platform for strategic acquirers that helps close transactions in weeks, instead of months.

reFern
------

reFern is the only AI-powered SaaS tool tailored for interior emissions, intended for use by designers and sustainability professionals. It enables tracking of circularity, exploration of sustainable materials, and reaching decarbonization objectives for building interiors. reFern supports the global aim of achieving net-zero emissions by 2050, crucial as buildings currently account for 40% of worldwide emissions.

Cove
----

Cove uses data to add value to rental relationships for both sides of the lease. Helping owners protect their assets and renters make their largest monthly payment mean more.

LUCA Theory
-----------

LUCA Theory is a revolutionary Crowd AI that is poised to transform capital decision-making. Designed to power decentralized operations while creating prediction market alpha

Elev8 and Perform
-----------------

Founded by an athlete, scientist (Team Canada, UofT) and a human rights award recipient, Elev8 is a technology designed to reduce fatigue and improve human health performance. The hardware consists of a small, lightweight breathing device used during training that releases a special supplement to enhance oxygen intake in the lungs and heart, significantly improving their natural capacity. This enables users to achieve faster progress, turning an hour of work into 30 minutes. Our software app tracks real-time biological metrics and provides personalized medical recommendations using advanced algorithms to optimize performance. Our mission is to enhance physical activity and health through innovative technology.

ZebraKet.Ltd (Acquired by Alinged IT LLC.)
------------------------------------------

We aim to help companies to have a more resilient and sustainable supply chain by using AI and quantum technologies.

Mutuo Health Solutions
----------------------

- Problem: Doctor burnout and major clinical inefficiencies due to onerous administrative tasks such as medical charting (note taking). - Solution: Our product AutoScribe uses AI to analyze patient-doctor conversations in real-time to automatically generate high-quality medical notes, saving up to 20% of a doctor's current work-time. - Differentiators: Our tool outperforms the competition at a lower cost.We prioritize transparency regarding scientific credibility and appropriate use of medical data which builds trusting and sticky relationships with our clients.

Nova Food
---------

Nova Food is a grocery companion app that aims to help users save money, eat healthier, and reduce their environmental impact. The app provides a curated dashboard that shows personalized recommendations for food items based on the user's dietary preferences and budget. Nova Food also offers discounts and cashback offers on select grocery items to help users save money while making healthier and sustainable choices.

vopemed
-------

Vope Medical has developed an AI-driven software to address a significant unmet need for clear vision in minimally invasive surgery. The lack of automation in current cleaning processes brings frustration, increased errors, and poorer patient outcomes. We optimize the cleaning process by reducing the number of cleaning events through image enhancement and minimize disruptions by fully automating the cleaning process, allowing the surgeon to stay completely focused on the procedures they are performing.

EduBeyond
---------

EduBeyond is improving

*[... truncated, 132,579 more characters]*

---

### hint-me.ca
*1,851 words* | Source: **GOOGLE** | [Link](https://hintme.ca/en)

Discover our platform
---------------------

#### A unified search tool

#### A unified search tool

#### A unified search tool

![Image 1](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:451)

HINT gathers c**ontextualized information** by topic — from your past content, web sources, and AI models — in a single, intelligent interface, so you can **quickly find what you need, wherever it is.**

#### A writing companion

#### A unified search tool

#### A unified search tool

![Image 2](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:451)

HINT is your creative ally: the tool **suggests questions to address** in order to enrich and structure content, **proposes avenues to explore** to open up new perspectives, and **highlights key points to validate** (compliance with standards, alignment with strategic objectives).

Latest news about us
--------------------

#### HINT participating in ALL IN to discuss content creation with AI

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

![Image 3](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**September 24th 2025**

 At HINT, we place humans and creators’ expertise at the heart of our solutions. We will be at ALL IN 2025 to discuss the role AI can play in your content creation needs.

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

![Image 4](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**July 9th 2025**

HINT was present at the DEL Accelerator Demo Day, alongside a dozen other innovative companies from the South Shore.

 We had the opportunity to pitch on stage, meet numerous visitors, and showcase our latest developments.

#### HINT participates in the XX Summit Demo Day in Calgary

#### HINT participates in the Consortium’s Demo Day at Invest-Tech 2025 in Ax-C

#### HINT participates in the XX Summit Demo Day in Calgary

![Image 5](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**June 25th 2025**

HINT participated in the XX Summit Demo Day in Calgary, a grand conclusion to the Movement51’s Founder Lab. The event provided an opportunity to discover early-stage ventures ready to receive capital, guidance, and strategic support.

#### HINT pitches on stage at the DEL Accelerator Demo Day

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

#### HINT participates in the XX Summit Demo Day in Calgary

![Image 6](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**June 17th 2025**

HINT was present at the DEL Accelerator Demo Day, alongside a dozen innovative companies from the South Shore.

 We had the opportunity to pitch on stage, meet numerous visitors, and showcase our latest developments.

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

![Image 7](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**May 20th 2025**

HINT is proud to be announced as one of the national finalists in the Technological and Technical Innovations category of the Business Creation division for the 27th edition of the OSEntreprendre Challenge.

#### Official Launch of the 2025 Spring Cohort of the Founder Lab by Movement51

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

#### HINT among the national finalists in the 27th edition of the OSEntreprendre Challenge

![Image 8](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**May 12th 2025**

Founder Lab is designed to help women founders gain the knowledge, tools, and network they need to approach fundraising with confidence. Pauline Boisbouvier, CEO and co-founder of HINT, is proud to officially be part of this program with Movement51.

#### HINT wins the Women in Entrepreneurship Grant from the Guy Laliberté Foundation

#### HINT wins the Women in Entrepreneurship Grant from the Guy Laliberté Foundation

#### HINT wins the Women in Entrepreneurship Grant from the Guy Laliberté Foundation

![Image 9](https://img1.wsimg.com/isteam/ip/static/transparent_placeholder.png/:/rs=w:388)

**April 28th 2025**

HINT is honored to be announced winner of the Women in Entrepreneurship Grant from the Guy Laliberté Foundation during the 3rd Émergence Summit by Zù. With big ambitions for the year ahead, we are deeply grateful to the Foundation for their support.

#### HINT takes part in the first edit

*[... truncated, 8,782 more characters]*

---

### Dealbook IQ 2024
*22,121 words* | Source: **GOOGLE** | [Link](https://cdnc.heyzine.com/files/uploaded/e36a054f6b45e6df090cade36d1edfcc0f986270.pdf)

Dealbook 

## Fall • Winter 2024 Québec, 

# a booming startup 

# ecosystem 

100+ coworking 

spaces 

Wide-ranging 

specializations:  AI, 

quantum computing, life 

sciences, FinTech, etc. 

100+ incubators and 

accelerators across 

Québec 

Population 

8.5 million residents 

(23% of Canada’s population) 

14% of population is foreign-born 

Economy 

$442 billion of the GDP in 2020 

$3.7 billion in foreign direct 

investment 

Strategic location 

17 economic regions and 6 

metropolitan areas 

Sharing a 813-km border with the 

United States 

Commercial gateway between 

America and Europe CHARLINE KEMPTER 

Trade and Innovation Attaché 

(Silicon Valley, CA) 

CARMEN ZANFIRESCU 

Transportation and VC Attaché 

(Silicon Valley, CA) 

SUSAN PAK 

Technology Trade Attaché 

(New York City, NY) 

NOAH OUELLETTE 

Life Sciences, Technology 

and Innovation Attaché 

(Boston, MA) 

# Contact our 

# U.S. Innovation 

# Team Table of 

# Contents 

AEROSPACE & SPACE 

H55 

SHEARWATER AEROSPACE 

VOLTA SPACE TECHNOLOGIES 

AEROPORT AI 

OPERAI 

SOLID STATE OF MIND 

ZENEXT IA 

CALOGY SOLUTIONS 

LETENDA 

NIOSENSE 

AVIATION 

ARTIFICIAL INTELLIGENCE 

AUTOTECH 

7

8

9

10 

11 

12 

13 

14 

15 

16 

CHILLSKYN 

FEX ENERGY 

NOVOPOWER INTERNATINONAL 

SAF+ INTERNATIONAL GROUP 

WATTBYWATT 

DIAMENTIS 

DITCH LABS 

FEMTHERAPEUTICS 

LIVINGSAFE 

MOMENTUM HEALTH 

OHMIC TECHNOLOGIES 

FRËTT ENERGY 

DIGITAL HEALTH 

KENTO HEALTH 

23 

24 

27 

28 

29 

30 

31 

32 

34 

36 

37 

25 

33 

BIOTECH 

APLANTEX 

BIOMIMIR 

17 

PAPERPLANE THERAPEUTICS 

QUEVA 

TOTUM TECH 

38 

39 

40 

IMMUGENIA 

TATUM BIOSCIENCES 

18 

21  VITALTRACER  41 

CLEANTECH & SUSTAINABILITY 

CHALUMEAU  22 

FTEX  26 

NEUROSERVO 

19 

20 

LUNABILL  35 EDTECH 

FABLI 

VLVT 

ENTERPRISE / SAAS 

HIVELIGHTER 

KIND INNOVATIONS (WORKIND) 

MODA MATCH 

OVA 

STRATEGIC THINKING SYSTEMS 

STREAMFORGE 

BERKINDALE ANALYTICS 

HAPPLY AI 

OXIA INITIATIVE 

EEVA 

NURAU 

FINTECH 

43 

44 

46 

47 

48 

50 

51 

52 

53 

54 

55 

45 

49 

GIS & GEOINT 

AYE3D 

LATENCE TECH 

MARKETPLACE 

GO MATERIALS INC 

HINT 

MEDTECH 

ENCEPHALX 

MICROELECTRONICS / SEMICONDUCTORS 

AWL ELECTRICITY 

DIGITHO TECHNOLOGIES 

IOT / CONNECTED DEVICES 

MEDIA 

POLYTONE LASER 

59 

60 

63 

65 

66 

64 

FEMTUM  67 

FOOD & BEVERAGE TECH 

BELLO 

OPALIA 

56 

57 

RELOCALIZE  58 

HAILA TECHNOLOGIES 

SOUNDSKRIT 

68 

69 

61 

62 

ROBOTICS 

ACRYLIC ROBOTICS 

HAPLY ROBOTICS 

SAMI AGTECH 

70 

71 

72 

WATCH OUT  73 

SUPPLY CHAIN 

GOMOVE 

INLAN 

74 

75 

ZILIA  42 AEROSPACE & SPACE 

# H55 

Developing certified electric propulsion systems 

for the aviation industry which are clear, quiet, 

safe and affordable 

WHAT WE DO  SEEKING 

ENABLING THE AVIATION 

INDUSTRY TO REACH NET ZERO 

We are looking at growing our footprint in North-

America with the help of US-based investors. 

Goal : 30+ MUSD 

CLEANTECH & SUSTAINABILITY 

h55.ch 

First to offer a certified powertrain under the 

CS-23 category (General Aviation) 

Target certification date from EASA 2025 

High-revenue growth 

100M revenues by 2029 and EBITDA positive 

by 2028 

TOP TAKEAWAYS  STAGE 

Series C 

REPRESENTATIVES 

Martin Larose, CEO 

martin.larose@h55.ch 

LinkedIn 

Stephane Fallot, CFO 

stephane.fallot@h55.ch 

LinkedIn 

Series C Watch our promo video 

Check our pitch 

AEROSPACE & SPACE 

# Shearwater 

# Aerospace 

Smart Flight™ is an AI-powered, weather-

optimized UAV autonomy platform that’s 

redefining UAV operations by offering fully 

automated mission planning and guidance, with 

real-time adaptability. Designed to maximize 

efficiency and minimize operational costs, Smart 

Flight™ seamlessly navigates complex weather 

patterns and optimizes flight paths to harness 

wind power, allowing UAVs to fly longer and 

faster. With the ability to control multiple UAVs 

simultaneously, Smart Flight enables one pilot to 

manage entire fleets, increasing operational 

scalability and delivering substantial cost savings. 

Whether for routine missions or advanced UAV 

operations, Smart Flight™ ensures your fleet 

operates at peak performance, revolutionizing 

how you deploy UAVs in the field. 

WHAT WE DO  SEEKING 

HELPING DRONES FLY FASTER, 

FURTHER, AND MORE OFTEN. 

We are seeking strategic investors and partners in 

the U.S. as we raise a bridge round of $500K (less 

SR&ED credit financing) through a SAFE. 

This funding will help extend our runway from 

February to August 2025, enabling us to finalize 

agreements with initial customers and launch our 

commercial-facing SaaS product. By partnering with 

like-minded investors, we aim to leverage our 

combined expertise and resources to establish 

Smart Flight as a leader in the drone autonomy 

market and capture significant opportunities in the 

rapidly evolving UAV industry. 

shearwater.ai 

Commercial agreements with leading 

companies such as

*[... truncated, 156,016 more characters]*

---

### Kampus Média et HINT reçoivent les bourses de la Fondation Guy Laliberté - Zú
*242 words* | Source: **GOOGLE** | [Link](https://zumtl.com/fr/article/kampus-media-et-hint-recoivent-les-bourses-de-la-fondation-guy-lalibert/)

[![Image 1: Zú](https://zumtl.com/wp-content/themes/fusion-child/dist/Components/subcomponents_basic/NavigationMain/Assets/logo-bf73c43aa3.png)](https://zumtl.com/fr/)

Félicitations à **Kampus Média**et**HINT**, lauréat·e·s des bourses de la Fondation Guy Laliberté remises lors de la 3ᵉ édition du Sommet Influence : technologie et créativité responsables.

Des solutions audacieuses pour transformer les industries créatives
-------------------------------------------------------------------

**BOURSE IMPACT**

![Image 2](https://zumtl.com/wp-content/uploads/2025/04/kampusmedia-240x300.png)**Kampus Media Inc**
Révolutionne la création et la diffusion de livres audio grâce à l’intelligence artificielle, tout en assurant une rémunération équitable aux artistes grâce à un modèle de redevances. Avec un engagement éthique fort, ils simplifient l’accès à des contenus audio de qualité et se positionnent comme un acteur clé dans l’avenir responsable de la culture.

**BOURSE ENTREPRENEURIAT AU FÉMININ**

![Image 3](https://zumtl.com/wp-content/uploads/2025/03/HINT-Logo-fonce_vert-300x167.png)**HINT**
Un assistant de rédaction personnalisée qui aide les professionnel·le·s des médias et les créateur·rice·s de contenu à concevoir des textes de qualité, sur mesure, selon les références et le ton de l’auteur·rice.

Une reconnaissance méritée
--------------------------

Ce lundi, **Marie-Hélène D. Longpré** (Kampus Media) et **Pauline Boisbouvier** (HINT) ont été récompensées pour leur vision, leur audace et leur contribution à une innovation porteuse de sens.

Les bourses ont été remises par **Dimitri Gourdin**, président-directeur général de Zú, en clôture d’une matinée riche en échanges et en inspiration.

Une édition marquante du Sommet Influence
-----------------------------------------

Un immense merci à toutes les personnes qui ont contribué à faire rayonner cette 3ᵉ édition du Sommet Influence.

Par leurs idées, leur présence et leur engagement, elles ont activement nourri les réflexions sur l’avenir de la technologie, de l’innovation et de la créativité responsables.

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[PODCAST & interview audio - Qui fait Quoi / Lien MULTIMÉDIA](https://lienmultimedia.com/spip.php?mot6953)**
  - Source: lienmultimedia.com
  - *PODCAST : Pauline Boisbouvier discute de HINT, son entreprise d'aide à la production de contenu ... Après avoir passé plusieurs années à travailler en...*

- **[Ventures - Next Canada](https://www.nextcanada.com/directory/ventures/)**
  - Source: nextcanada.com
  - *HINT. HINT est un outil pour les professionnels des médias pour créer du ... Pauline Boisbouvier Patrick Fauquembergue. Lila Solution. Lila solution e...*

- **[HINT](https://hintme.ca/)**
  - Source: hintme.ca
  - *Pauline Boisbouvier de HINT parmi les 20 fondateurs choisi par Movement 51 ... Présenté à la Conférence Collision à Toronto, HINT a également particip...*

- **[EN](https://hintme.ca/en)**
  - Source: hintme.ca
  - *Pauline Boisbouvier of HINT among the 20 founders selected by Movement 51 to ... Presented at the Collision Conference in Toronto, HINT also took part...*

- **[Dealbook IQ 2024](https://cdnc.heyzine.com/files/uploaded/e36a054f6b45e6df090cade36d1edfcc0f986270.pdf)**
  - Source: cdnc.heyzine.com
  - *Aiming to start raising a seed round in spring. 2025. REPRESENTATIVES. Pauline Boisbouvier, CEO pauline@hintme.ca. LinkedIn. Patrick Fauquembergue, CO...*

- **[Kampus Média et HINT reçoivent les bourses de la Fondation Guy ...](https://zumtl.com/fr/article/kampus-media-et-hint-recoivent-les-bourses-de-la-fondation-guy-lalibert/)**
  - Source: zumtl.com
  - *Apr 30, 2025 ... Longpré (Kampus Media) et Pauline Boisbouvier (HINT) ont été ... Article Publié le 07/10/2025. Rencontre des mentor·e·s : 4 nouvelles...*

---

*Generated by Founder Scraper*
