# Barbara Lima

## Position actuelle

**Titre** : Cross-Cultural Language Coach & Learning Facilitator - Corporate English and French
**Entreprise** : Freelance
**Durée dans le rôle** : 4 years 2 months in role
**Durée dans l'entreprise** : 4 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

- Facilitate language learning and cross-cultural communication training for professionals in business settings.
- Deliver tailored learning materials and strategies to enhance confidence and internal communications effectiveness.
- Support clients in refining messaging for specific audiences, bridging linguistic and cultural differences in both personal and workplace contexts.

## Résumé

I am a writer, editor, creative director, learning facilitator, and multidisciplinary artist with a background in linguistics, international education, entrepreneurship, visual arts, and regenerative culture design. 

A childhood dream of exploring the world and learning languages and an alchemical intimacy with spirituality have taken me on a deeply regenerative journey around the globe.

I am aware that true cultural transformation emerges at the scale of the individual, rippling out to impact the community and the planet, and I combine my skills and talents in service of this potential.

In 2022, I launched The Weave, a multimedia publication storytelling the Regenaissance.

I am guided by a heart-centred purpose: to embody conscious living as the core of regenerative creation.

I dream of a world where, as conscious creators, we create fertile soil for the thriving of all life. Where, together, we weave regenerative stories as seeds for expansion of consciousness and the rise of the true self.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAZnX5UB2ssLWdjomRcjWt_7KRunav02Jo0/
**Connexions partagées** : 4


---

# Barbara Lima

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Barbara Lima

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389708063869603842 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG-pC5pT4M59g/feedshare-shrink_800/B56Zo2EUTdKwAk-/0/1761843694861?e=1766620800&v=beta&t=88UwRFGeuapeU6UnB84PHBcIeAeTPJrwEpljtlXINSw | The 𝟭𝟮𝘁𝗵 𝗜𝗻𝘁𝗲𝗿𝗻𝗮𝘁𝗶𝗼𝗻𝗮𝗹 𝗗𝗶𝗴𝗶𝘁𝗮𝗹 𝗦𝘁𝗼𝗿𝘆𝘁𝗲𝗹𝗹𝗶𝗻𝗴 𝗖𝗼𝗻𝗳𝗲𝗿𝗲𝗻𝗰𝗲, hosted by the StoryCenter and the Museum of the Person, starts tomorrow. 

This conference marks a pivotal moment in the global storytelling community and offers two distinct yet interconnected experiences: a virtual gathering from 𝗢𝗰𝘁𝗼𝗯𝗲𝗿 𝟯𝟭 𝘁𝗼 𝗡𝗼𝘃𝗲𝗺𝗯𝗲𝗿 𝟭, and an in-person event—held for the first time in the Global South—from 𝗡𝗼𝘃𝗲𝗺𝗯𝗲𝗿 𝟲 𝘁𝗼 𝟴.

For more than three decades, the 𝗦𝘁𝗼𝗿𝘆𝗖𝗲𝗻𝘁𝗲𝗿 and the 𝗠𝘂𝘀𝗲𝘂𝗺 𝗼𝗳 𝘁𝗵𝗲 𝗣𝗲𝗿𝘀𝗼𝗻 have developed broad networks in support of participatory media networks. This year, they bring their shared tradition to São Paulo, Brazil, for the 𝟭𝘀𝘁 𝗜𝗻𝘁𝗲𝗿𝗻𝗮𝘁𝗶𝗼𝗻𝗮𝗹 𝗖𝗼𝗻𝗳𝗲𝗿𝗲𝗻𝗰𝗲 𝗼𝗻 𝗦𝗼𝗰𝗶𝗮𝗹 𝗧𝗲𝗰𝗵𝗻𝗼𝗹𝗼𝗴𝗶𝗲𝘀 𝗼𝗳 𝗠𝗲𝗺𝗼𝗿𝘆, as part of the program of the 12th International Digital Storytelling Conference. 

The 𝗖𝘂𝗹𝘁𝘂𝗿𝗮𝗹, 𝗠𝗲𝗺𝗼𝗿𝘆 𝗮𝗻𝗱 𝗛𝗲𝗿𝗶𝘁𝗮𝗴𝗲 𝗛𝘂𝗯 is one of the central themes of the Conference—an unprecedented meeting that brings together voices from different parts of the world and Brazil: from guardians of indigenous memory to cultural agents, from cultural centers to organizations that work with heritage and living memory.

The event marks the culmination of a cycle of work that has mobilized cultural organizations across the country and consolidated a broad network dedicated to the preservation, appreciation, and dissemination of Brazilian cultural heritage and memories. 

𝗛𝗼𝘄 𝗰𝗮𝗻 𝗦𝗼𝗰𝗶𝗮𝗹 𝗧𝗲𝗰𝗵𝗻𝗼𝗹𝗼𝗴𝗶𝗲𝘀 𝗼𝗳 𝗠𝗲𝗺𝗼𝗿𝘆 𝗶𝗻𝘀𝗽𝗶𝗿𝗲 𝗮𝗰𝘁𝗶𝗼𝗻 𝗶𝗻 𝗮 𝘄𝗼𝗿𝗹𝗱 𝗶𝗻 𝗰𝗿𝗶𝘀𝗶𝘀? 

This central question of the 𝟭𝘀𝘁 𝗜𝗻𝘁𝗲𝗿𝗻𝗮𝘁𝗶𝗼𝗻𝗮𝗹 𝗖𝗼𝗻𝗳𝗲𝗿𝗲𝗻𝗰𝗲 𝗼𝗻 𝗦𝗼𝗰𝗶𝗮𝗹 𝗧𝗲𝗰𝗵𝗻𝗼𝗹𝗼𝗴𝗶𝗲𝘀 𝗼𝗳 𝗠𝗲𝗺𝗼𝗿𝘆 invites all who understand the power of stories and ancestral wisdom as a force for transformation in the face of global challenges. 

I am truly honoured to offer a 90-minute workshop on the opening day of the virtual component of this symbolic event taking place in my homeland. 

The workshop, titled 𝘞𝘦𝘢𝘷𝘪𝘯𝘨 𝘙𝘦𝘨𝘦𝘯𝘦𝘳𝘢𝘵𝘪𝘷𝘦 𝘚𝘵𝘰𝘳𝘪𝘦𝘴 𝘧𝘳𝘰𝘮 𝘚𝘰𝘶𝘭 𝘵𝘰 𝘚𝘰𝘪𝘭, is based on a regenerative storytelling framework I started developing a year ago and will be presenting for the first time. 

You can learn more about the conference here: https://dst2025.org/ 

Interested in registering? https://lnkd.in/gzmKMcER 

Thank you, Kathleen Martsch, Joe Lambert, Luana Marques Soares, and the conference's organizing committee, for your continued support of my participation in this transformative event. | 23 | 3 | 2 | 1mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:24.685Z |  | 2025-10-30T17:01:36.563Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7355256102789271552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGf5RPmlb8INg/feedshare-shrink_2048_1536/B4EZhK.tNZGUAw-/0/1753604609518?e=1766620800&v=beta&t=nJWqg05pxWyNN_XKKLHldpH0Ld6tMKCTcWuwDrAiNY0 | So grateful for the vision and the work that you, Penny L. Heiple and the community in Barichara have so diligently cultivated, Joe. 

A learning ecosystem grounded in regeneration, holistic learning and human flourishing is what we need to seed regenerative stories within our younger generations. 

Congratulations to the whole community and to all the families who will be able to benefit from this vision! | 7 | 1 | 0 | 4mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.700Z |  | 2025-07-27T15:21:48.955Z | https://www.linkedin.com/feed/update/urn:li:activity:7355150830712287232/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7354163684333531136 | Article |  |  | Happy to see the first Eternal Forest Sanctuary coming to life, Evgenia Emets! | 3 | 1 | 1 | 4mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.701Z |  | 2025-07-24T15:00:56.099Z | https://www.youtube.com/watch?v=70QJaxGr4mw&feature=youtu.be |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7348013733664739328 | Article |  |  | Congratulations, Alexander Keehnen, Julia Becker, Giannandrea Giammanco, and all contributors for this long-awaited launch! | 14 | 4 | 1 | 5mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.703Z |  | 2025-07-07T15:43:13.599Z | https://www.youtube.com/@VillaGaiaHub |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7343357041215774723 | Article |  |  | “When I start something new, I have no shame and have no embarrassment. 

The version of me that started is a step ahead of the version who said they would, but didn’t. 

This version of me doesn’t match up to my vision of me, but the version of me that can do it can exist and will exist because of this version of me now that’s struggling.

This version of myself already has so much to be proud of.” 

Appreciating the wise and inspiring words of David Larbi on Substack. | 15 | 0 | 1 | 5mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.703Z |  | 2025-06-24T19:19:11.602Z | https://substack.com/@deeplywoven/note/c-129006986?r=wphcc |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7336451934473637888 | Article |  |  | Underneath our planetary collapse is a narrative of disconnection from our true self and our separation from nature. 

We have forgotten who we *truly* are. 

We have been told stories about human and natural resources that have paved our way into our individual and collective degeneration—and underlined our distancing from the elemental sacredness of the natural cycles as regeneration themselves.

The debut print edition of The Weave, The Medicine of Story, is being designed as a collection of narrative-based essays, poems, regenerative storytelling practices, photographs, and artwork that together explore the medicinal and reality-shaping essence of stories.

🌀 How can stories transform our individual and collective narratives to birth a regenerative culture? 

🌀 What stories help us remain deeply rooted in ourselves, one another, and the Earth as we live through the degradation of both our physical and metaphorical soils? 

🌀 How can they include more-than-human voices and multidimensional perspectives?

Discover the next evolution of The Weave, our regenerative approach to storytelling, and first call for stories 👉 https://lnkd.in/gnVH4K6D | 49 | 5 | 3 | 6mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.704Z |  | 2025-06-05T18:00:45.864Z | https://deeplywoven.substack.com/p/reintroducing-the-weave-call-for |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7320915853317672961 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH7F21sRJGF2Q/feedshare-shrink_800/B56ZZkXwsXGcAk-/0/1745440674588?e=1766620800&v=beta&t=iukl53ygI3I2H18YspB7Q2DBfxwKTENow7nBBXxDg9w | Have you read the first three editions of The Weave?

Together, they've had over 3.5 million impressions and more than 16 thousand reads in 167 countries (organic reach).

Our first three editions were an experiment that taught me valuable lessons way beyond my expectations. 

Yet, there's much more to learn. 

The Weave is coming back this year with a new website, new projects, and a new edition we could not be more excited about. 

It's in preparation for our relaunch that we are inviting our community to join us in reflecting on our journey so far. 

Want to contribute your perspective?

It only takes a few minutes. Your feedback would be super appreciated and help shape our decisions moving forward: https://tally.so/r/nWQNzj 

Haven't read The Weave yet?
Subscribe to our newsletter and get free access to our first three editions: https://shorturl.at/mednm | 40 | 7 | 1 | 7mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.706Z |  | 2025-04-23T21:05:55.470Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7318618736532303872 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE7WfbMeWLzyQ/feedshare-shrink_800/B56ZZD09DmGcAg-/0/1744894679287?e=1766620800&v=beta&t=v9vBiQbDKB8T9YvLLooA0URQVJDRy4qcDx7d3lVWaw8 | Eleven project submissions so far to The Weave Fund for Storytellers of the Regenaissance! 

Three have already been approved for curation. Eight are in review. 

Approved projects:

📽️  The Soil Within | Docuseries by Brandon Wood: https://shorturl.at/rTTXU

📽️  Another World is Possible | Planetary Regenerative Film Series by Zachary Marlow: https://shorturl.at/vrdJq

📽️  ISEDA | Feature Length Film by David Ikani: https://shorturl.at/mT4BL


Got a project idea? 
Submissions and voting close in 22 days. Curation and continued fundraising follow. 

Want to support the growth of our fund?
Artizen will be matching all contributions, big or small (starting at $10), up to $9,000. 

Link to our fund: https://shorturl.at/Ra02x

This is just the beginning of a promising journey supporting storytellers from all over the world who are weaving regenerative culture into the fabric of our collective future. 

Our gratitude to Kathleen Martsch for making the first contribution (which Artizen has already matched) and voting for her favourite project! 

Let's thrive together. We, The Weave. | 56 | 8 | 5 | 7mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.707Z |  | 2025-04-17T12:58:00.150Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7316827907606134784 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFYTOxHLN2_gw/feedshare-shrink_2048_1536/B56ZYqYNI9GsAo-/0/1744467711837?e=1766620800&v=beta&t=XNulSnts2uTYd-H0r5hcihylL96zEOTzrNbm14lDn2g | The rawest piece I've ever written is also the one that helped me heal the most and reawaken my voice as a writer. 

It was an experiment with lyrical prose that evoked many memories and emotions in me. Just like when I started working on my memoir, I found myself having to stop at the end of certain paragraphs to cry.

Writing it was a rite of passage. 

Publishing it is another one. 

The more I read and write real, vulnerable stories of transformation, the more I feel that the journey of regeneration is paved with stories as medicine. 

Medicine for the storyteller, medicine for the story guest. 

Link to 'A Microdose of Memoir' in the comments. | 31 | 8 | 1 | 7mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.707Z |  | 2025-04-12T14:21:53.262Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7315440664656113664 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEobv7C573jNg/feedshare-shrink_800/B56ZYWqd65HEAk-/0/1744136967091?e=1766620800&v=beta&t=zkYvvxB_vk9mauQAwIMxFBkI7mxVm3qkQ2aIHuoJvWo | A couple of weeks ago, I was accepted into the Artizen Accelerator program and received $10,000 to launch a community fund on their platform. 

You would've caught me stomping my feet and making high-pitched noises had I recorded a video of my reaction when I got the news!

The fund was created last Sunday and is now live: https://shorturl.at/OTcRP

'The Weave Fund for Storytellers of the Regenaissance' will support creators weaving regenerative culture into the fabric of our collective future through embodied storytelling.

❓ Are you a writer, artist, filmmaker, or multimedia visionary crafting stories that seed human and cultural transformation and breathe life into regeneration for a thriving planet? 

This opportunity is for you.

❓ Are you an individual, organization or corporation who would like to support projects that have the potential to transform lives, revitalize communities, or regenerate ecosystems?

This opportunity is for you, too.

'The Weave Fund for Storytellers of the Regenaissance' is an evergreen match fund designed to grow and attract funding from both individual supporters and corporate sponsors, ensuring the best projects receive the resources they need.

How it works:

🌀 The fund works in cycles called seasons. This season's theme is 'Stories as Medicine' (visit our fund's page for eligibility criteria).

💰 Artizen has kicked off the current funding season by injecting $1,000 into our fund and will match $1 for every $1 dollar raised in sponsorship (up to the awarded total of $10,000 – the other $9,000 being in their reserve). 

♾️ The fund grows limitlessly. 

✒️ Creators submit their project. 

✔️ If the eligibility criteria is met, we approve the project.

🏆 Projects that garner the most votes by the end of the review period are curated by the Artizen community for each season's Official Selection and go on to compete for match-funding and the Artizen Prize.

What I love about this funding model is that all the money received goes directly to creators, and it is the community who decides what projects are funded. Plus, creators can submit their project to different funds at the same time to increase their funding opportunities. 

If aligned with The Weave's editorial framework, tone and language, their project could also be published by us!

❓ How can you support this initiative?

🌱 Share this post and invite your connections to participate as sponsors or creators (or both!).

📜 Include this opportunity in your next newsletter.

🕸️ Help us grow our community of sponsors and creators. Who do I need to speak with? Tag them in the comments.

🙋‍♀️ Become a sponsor and vote for the projects you want to support. 

The Weave is coming back – stronger. 

All my gratitude to the people who have supported me, especially to my partner, Brandon Wood, and those who remained present as I navigated 2023 and 2024, some of the most challenging and transformative years of my life. 

Let's thrive together. We, The Weave. | 193 | 69 | 22 | 7mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.709Z |  | 2025-04-08T18:29:28.769Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7314782053701431297 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG30R7Mg92BCg/feedshare-shrink_800/B56ZYNTgzSGsAk-/0/1743979942541?e=1766620800&v=beta&t=Hm9aY26EzRtEFaGJwGm74yVTTqxMb46uLzb238cbdEE | Who is telling AI-free stories (including writing, film, photography, immersive media, and interdisciplinary formats) that: 

🫚 Are rooted in embodiment, cultural depth, and planetary care;

👁️ Resonate across species and systems, inviting us into new ways of seeing, being, and belonging;

🌱 Highlight themes of regeneration, cultural transformation, systemic change, or personal awakening and healing;

🌎 Reflect a multispecies or planetary perspective, embracing interdependence across living systems;

❤️ Embody originality, emotional resonance, and cultural relevance;

🌀 Recognize humans as spiritual beings interconnected in the web of life;

🪱 Invite in a culture of self-knowledge, an animistic language and regenerative myth-making;

🦉 Preferably emerge from direct experience, community practice, or ancestral wisdom?

Please add your website or reference link in the comments! | 61 | 35 | 5 | 8mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.710Z |  | 2025-04-06T22:52:23.681Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7310797592458575872 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFBrernG5FFfg/feedshare-shrink_800/B56ZXUroSSGsAo-/0/1743029973276?e=1766620800&v=beta&t=GecvpOhmU3i15by9-Jhs9uhySx6ZZzv40cHeCk1D1e4 | We are creating a new website for The Weave and looking for an aligned design and development team to assist us with it.

The website is to be custom-coded or built on Webflow.

Who is pushing the boundaries of web design and dev and wants to re-imagine media with us from a life-affirming perspective? | 38 | 33 | 4 | 8mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.711Z |  | 2025-03-26T22:59:34.093Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7308628914656948225 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEyw8c4IOl09A/feedshare-shrink_800/B56ZW13QI0HQAg-/0/1742512915892?e=1766620800&v=beta&t=KUDiwACSfsMkahHp2vRHfYu3clDk19nPy3gWL98EZFU | I could still see patches of ice slowly melting on the grass outside my window when I wrote this first Substack piece. 

Now it's the rain that falls heavily on the ground at the end of a bright first day of Spring. 

The state of the element has changed, but its transformational essence remains.

It was in reverence to this elemental essence and how it has been expressed through me that today I planted seeds of gratitude. 

Gratitude for what I have received and become. 

Gratitude for what I will receive and become. 

Gratitude for a more beautiful world.

A Spring equinox ritual to honour the end of a cycle and welcome a new one: a time of deeper return to self. 

Welcome to Deeply Woven (link in comments).

Thank you for reading, subscribing, and sharing. | 23 | 3 | 2 | 8mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.713Z |  | 2025-03-20T23:22:01.013Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7307870626608726017 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFchFvrvoC8IQ/feedshare-shrink_800/B56ZWrFjG7GQAg-/0/1742332127923?e=1766620800&v=beta&t=EdDx6heuWJsVqYBNEoVWXcwXXqeRICO1P_NZCOcKNkM | There's a peach tree on the land my partner and I have been stewarding. 

When I first saw her, she was full of peaches, hundreds of them. But instead of ripening, the fruits started rotting on her branches and showing what looked like fungal growth. 

A Japanese honeysuckle vine had been twining around her trunk. As beautiful and fragrant as the vine was, she was smothering the tree. 

We pulled meters of the vine from the ground, pried her off large sections of the trunk, and cleared the immediate area around the tree. 

Since then, I've been speaking with the peach tree, learning how to communicate with her, while my partner has been giving her a daily dose of nitrogen (aka peeing on it).

I went to see her today and spotted new growth amongst the remains of honeysuckle hanging from her higher branches. There were tiny new leaves and flower buds, some already displaying delicate pink blooms. 

She's coming back.

The new growth can only be seen in some parts of the tree though. Other parts seem to be completely dead. 

It's the first time I'm taking care of a sick peach tree. It seems clear to me that she needs pruning, and it's highly possible that she's sick beyond my initial understanding – brown rot, perhaps?

To my fellow Earth caretakers:

- I've been learning about pruning techniques, vegetative buds, flower buds... According to my research, the "leave one, stub one" is the recommended pruning method for peach trees. Any suggestions on pruning in this scenario? 

- How do I know if she is sick and what the disease is? 

Much gratitude! | 23 | 4 | 0 | 8mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.714Z |  | 2025-03-18T21:08:51.054Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7300703903405289474 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQH9hpdRFPdTFQ/feedshare-shrink_800/B4DZU9O9GzGkAg-/0/1740489093116?e=1766620800&v=beta&t=-3Sdks45tRd7OSPLGy-V0dVFs39bnubQgyJQe71Q86M | Well done, Green School Bali. 

Moving away from the SDGs is not about sustainability versus regeneration. 

Sustainability without regeneration wouldn’t allow us to reclaim and restore our individual, collective and planetary wholeness. 

Regeneration without sustainability wouldn’t allow us to maintain the wholeness of our systems—nor honour our very role as living beings in co-creating the conditions conducive to life.

This shift is about more than de-centering our human perspective to move towards a multispecies perspective. 

It is about moving away from a framework that has served us well as a scaffold in our evolutionary journey but is fundamentally scarcity-based. 

It is about exploring more deeply the power of language in shaping reality, in giving it limiting or boundless contours. 

It is about taking our place as a planetary community and trusted guardians of other species in deinstitutionalizing the understanding and embodiment of what it means to thrive together—as nature. | 16 | 4 | 2 | 9mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.716Z |  | 2025-02-27T02:30:51.091Z | https://www.linkedin.com/feed/update/urn:li:activity:7300140372427468801/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7290113545969483777 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHmTIYveWGs7g/feedshare-shrink_800/B56ZSuvn05GsAk-/0/1738098511842?e=1766620800&v=beta&t=yta503KITxEjGV1eKY1SsRstBMdJcBeHEyrCyqCGAlI | Last week I spent 12 hours with Reid Tracy, CEO of Hay House, Inc., Kelly Notaras, Founder and CEO of KN Literary Arts, and an inspiring group of published book authors in an intensive book writer's bootcamp. 

As a writer/author, my goal was to gain deeper insights into book publishing. As a startup publisher, I wanted to learn from the experience of an established publishing house.

Here's what I harvested from the bootcamp:

• The "know your genre, know your niche and identify your reader" triad is a deep, time-demanding process in book publishing. 

• A high-concept, narrowly-tailored book pitch (or hook) does as much for the reader as it does for the author. 

• Neglecting to create a strong, detailed outline before writing a book and writing a full manuscript when what they need is a book proposal are common mistakes aspiring authors make as they prepare for the journey ahead.

• Whether you choose the self-publishing or the traditional publishing route, writing a strong book proposal will give you the clarity and the focus you need to write, publish, and sell your book. 

• The self-publishing industry is expanding and getting a lot of attention. If you are aiming for traditional publishing, self-publishing your book will help you get there – but it may also come with challenges as it is harder to protect your copyrights on your own (than through an established publisher) in case you have to deal with piracy – unless you are considering open infrastructures of sharing.

• The audiobook market is growing 20-30% every year (mostly in fiction) and serve, in many cases, as a platform for paperback books (instead of replacing them). 

• Traditional book publishers generally won't accept AI-assisted* work and have their own AI detectors (though still not 100% accurate). Yet, some of them have their own internal AI systems and most of them are already using AI in audiobook production. They recognise that the future of publishing is (sadly, in my opinion) intertwined with the use of AI and are ready for it. 

• Most importantly, from my perspective: The book(s) – and I would add magazines – you want to create are alive. Work with them as living beings, ask them questions about the message they’ve chosen you to share, and remember: You are in service to their spirit (thank you, Colette Baron-Reid, for reflecting back my experience when creating The Weave). 

I did not know it, but Louise Hay founded Hay House after self-publishing her first two books. The first version of her first book, Metaphysical Causations, was a pamphlet she printed and sold herself. Louise was 60 when she started Hay House, and 90 when she wrote her last book. 

Thank you, Hay House, Inc., KN Literary Arts and inspiring guests, for sharing your experience and wisdom. 



*Accepted AI assistance is limited to research, brainstorming ideas and similar tasks. | 58 | 12 | 0 | 10mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.717Z |  | 2025-01-28T21:08:33.119Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7287166846795948034 | Article |  |  | Have you read The Serviceberry yet? 

What a *stunning* piece of writing––and how fitting that JP Parker is hosting a discussion of this deeply heart-touching essay by Robin Wall Kimmerer on the regenerative art of reciprocity. 

The session is tonight at 7pm Eastern. DM JP if you'd like to join.

You can read and listen to this story (narrated by Robin herself) on Emergence Magazine:

https://lnkd.in/gkhdzxAz | 7 | 1 | 0 | 10mo | Post | Barbara Lima | https://www.linkedin.com/in/barbara-lima | https://linkedin.com/in/barbara-lima | 2025-12-08T06:19:29.718Z |  | 2025-01-20T17:59:25.289Z | https://emergencemagazine.org/essay/the-serviceberry/ |  | 

---



---

# Barbara Lima


*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Notes from Me and The Weave - by Barbara Lima - Deeply Woven](https://deeplywoven.substack.com/p/notes-from-me-and-the-weave)
- Category: blog

### [“Successfully Insecure” to Win! Get Shark-Size Confidence with Shark Tank’s Barbara Corcoran (Pt 2) - Jamie Kern Lima](https://jamiekernlima.com/show/successfully-insecure-to-win-get-shark-size-confidence-with-shark-tanks-barbara-corcoran-pt-2/)
*2024-12-10*
- Category: article

### [Press](https://www.anandalima.com/press/)
*2025-01-01*
- Category: article

### [Barbara – Navigating new waters](https://sebratec.com/2024/05/30/barbara-navigating-new-waters/)
*2024-05-30*
- Category: article

### [Updates-A Story of Realistic Hope](https://www.nonviolenceinternational.net/updates?page=16)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Apple Podcast：《Morando Fora》〈Ep. 9: Ela Fala: Barbara Lima〉](https://podcasts.apple.com/us/podcast/ep-9-ela-fala-barbara-lima/id1441663724?i=1000435364902&l=zh-Hant-TW)**
  - Source: podcasts.apple.com
  - *Apr 18, 2019 ... Hoje conversei com a Barbara Lima, uma coreógrafa, dançarina e recém mudada para os Estados Unidos. Ela fala sobre o novo projeto del...*

- **[Podcast - Women Abroad Coaching](https://women-abroad-coaching.com/en/podcast/)**
  - Source: women-abroad-coaching.com
  - *Suivez les podcast Women Abroad, des interviews, des rencontres pour partager ... Barbara Lima is a visionary Brazilian artist and entrepreneur who is...*

- **[May DanceWatch: Springing into action • Oregon ArtsWatch](https://www.orartswatch.org/may-dancewatch-springing-into-action/)**
  - Source: orartswatch.org
  - *May 1, 2025 ... ... podcast here. New Expressive Works, always a space for ... Barbara Lima, Claire Olberding, and tiny vessels (Emily Haygeman and .....*

- **['He's a hero': Woman remembers father 75 years after his death as ...](https://www.bostonglobe.com/2022/05/28/metro/hes-hero-woman-remembers-father-75-years-after-his-death-boston-firefighter/)**
  - Source: bostonglobe.com
  - *May 28, 2022 ... Barbara Lima has few memories of her father, Charles A. Buchanan, a ... podcast · New Hampshire · Business · Politics · Education · C...*

- **[About — Gaianet](https://www.gaianet.earth/about)**
  - Source: gaianet.earth
  - *Founder Alexander Keehnen on the USA Global TV podcast. Barbara Lima's article on Medium: how Gaianet was born through synchronistic events....*

- **[Barbara Lima Vieira - IDP](https://www.idp.edu.br/corpo-docente/barbara-lima-vieira/)**
  - Source: idp.edu.br
  - *Podcasts do IDP · Comissão Própria de Avaliação · Comissão Permanente de ... Barbara Lima Vieira. Graduada e Mestra em Comunicação. Currículo Lattes ....*

- **[BARBARA LIMA](https://www.barbaralima.art/)**
  - Source: barbaralima.art
  - *BARBARA LIMA · About · Work With Me · Portfolio · ELa FaLa Collective. Open Menu ... Guest Panels & Interviews. ACDA Northwest Conference(2022 Guest P...*

- **[Author Spotlight: Angela Correll - Suzanne Woods Fisher](https://suzannewoodsfisher.com/author-spotlight/author-spotlight-angela-correll/)**
  - Source: suzannewoodsfisher.com
  - *Oct 14, 2013 ... ... interview! Reply. Connie Hendryx on October 14 ... Barbara Lima on October 14, 2013 at 1:10 pm. Second chances. That's ......*

- **[From Soul to Soil | Barbara Lima | Substack](https://deeplywoven.substack.com/)**
  - Source: deeplywoven.substack.com
  - *... Barbara Lima, a Substack publication with hundreds of subscribers ... The 12th International Digital Storytelling Conference Starts Tomorrow · And...*

- **[Barbara Lima Machado | OMICS International](https://www.omicsonline.org/author-profile/barbara-lima-machado-282581/)**
  - Source: omicsonline.org
  - *Barbara Lima Machado is a versatile writer and researcher that published ... Abstract Peer-reviewed Full Article Peer-reviewed Article PDF Mobile Full...*

---

*Generated by Founder Scraper*
