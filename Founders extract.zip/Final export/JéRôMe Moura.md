# Jérôme Moura

## Position actuelle

**Titre** : Cofondateur / PDG
**Entreprise** : Letsmoviz
**Durée dans le rôle** : 7 years in role
**Durée dans l'entreprise** : 7 years in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

En tant que co fondateur et CEO de Letsmoviz, je dirige une startup innovante qui réinventera et simplifiera le processus du placement de produits dans les films indépendants grâce à une plateforme en ligne de type WaaS (avec abonnement).

Letsmoviz offrira un espace unique où les producteurs, les réalisateurs et les entreprises pourront collaborer efficacement. 

Bien que nous soyons encore en phase de développement, nous sommes sur le point de pré lancer une solution qui, je l'espère, transformera l'industrie du cinéma et du marketing.

Mon rôle inclut :

Développement stratégique : Co définir la vision globale de Letsmoviz, visant à simplifier et moderniser le processus de placement de produits.

Supervision du produit : S'assurer que la plateforme réponde aux besoins des utilisateurs, avec des fonctionnalités adaptées aux professionnels du cinéma et aux entreprises.

Leadership d’équipe : Diriger une équipe passionnée par l'innovation, en favorisant une approche collaborative et agile pour surmonter les défis.

Partenariats stratégiques : Initier des collaborations clés avec des acteurs de l’industrie cinématographique et des marques.

Recherche de financement : Négocier avec des investisseurs, collaborer à la recherche de potentielles subventions et commandites. Gérer les ressources pour garantir une croissance solide dès le lancement. (Prochainement)

Sous ma direction, Letsmoviz est en bonne voie pour devenir une référence en matière de placement de produits dans les films, tout en restant axée sur l'innovation et la création de valeur.
-
Les nouvelles de Letsmoviz : 01 Novembre 2025

Prochaine étape : (Automne)
▪️Création des premières pages de la maquette (Wireframe)
. Elles seront conçues dans l'esprit MVP (Minimum Viable Product).
. Présentées sous la forme de fichiers; non cliquables.
🏁Objectifs : 
. Conception d'une interface utilisateur.

D' autres étapes seront mentionnées ultérieurement.

 « Merci de nous suivre dans cette aventure ».

## Résumé

Bonjour !  

👋 Bienvenue sur mon profil LinkedIn !

Après avoir cheminé à travers diverses organisations internationales, le cinéma a croisé ma route. En tant que cinéphile, je suis captivé par les défis uniques que présente la production cinématographique indépendante. Mon rêve avec Letsmoviz est de voir notre plateforme devenir une référence mondiale dans le domaine du placement de produits en ligne, tout en soutenant financièrement les cinéastes dans leurs projets et en mettant en valeur les marques de manière créative et inspirante.
▪️
Les nouvelles de Letsmoviz : 01 Décembre 2025

Info : 
⏲️ 
▪️Prochaine étape : 
1. La création des premières pages de la maquette est ficelée ! 
. Conçues dans l’esprit MVP (Minimum Viable Product)
. Présentées sous forme de fichiers non cliquables.

🏁 Objectifs
Concevoir une première interface utilisateur

✅ Tableau de bord : publié 

2. Révision du premier jet de notre future application 'Letsmo'. (ph.3-stable). Une étape de plus ! 

3. Nous avons l’intention de soumettre notre candidature au programme Disney Accelerator.

👉 D'autres étapes seront mentionnées ultérieurement.

Le plaisir d'échanger sur nos projets respectifs ✨
▪️
📣 Vous trouverez également les dernières nouvelles de Letsmoviz sur mon profil dans « Ma sélection ». 

Merci pour votre soutien continu ! 
___

👋 Welcome to my LinkedIn profile!

After traversing various international organizations, cinema crossed my path. As a cinephile, I am captivated by the unique challenges that independent filmmaking presents. My dream with Letsmoviz is to see our platform become a global reference in the field of online product placement, while financially supporting filmmakers in their projects and creatively and inspiringly showcasing brands.
▪️
Letsmoviz News: December 1st, 2025

Info:
⏲️ 
▪️ Next Step: 
1. The first pages of the wireframe are all wrapped up! 
. Designed with an MVP (Minimum Viable Product) approach
. Presented as non-clickable files

🏁 Objectives
Design an initial user interface

✅ Dashboard: Published

2. Review of the first draft of our upcoming application, 'Letsmo' Ph.3–Stable Release”. One more step forward!

3. We intend to apply to the Disney Accelerator Program.

👉 Additional steps will be outlined at a later stage.

The pleasure of discussing our respective projects ✨
▪️
📣 You will also find the latest news from Letsmoviz on my profile under "My Selection".

Thank you for your support.
🔹
« Décembre est un mois pour apprécier ce que l'on a et répandre la joie. »
🔸
Jérôme MOURA 
📧 info@letsmoviz.com
Montréal, Québec, Canada 🍁❄️

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABtOR10B9yc59VUHc2yL0XfbAGNkXA19_mg/
**Connexions partagées** : 57


---

# Jérôme Moura

## Position actuelle

**Entreprise** : Letsmoviz

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jérôme Moura
*Letsmoviz*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Letsmoviz](https://letsmoviz.com/en)
*2024-03-28*
- Category: article

### [The Mobile-First Company raises €3.5M to pioneer a new approach in Business Tooling](https://lsvp.com/stories/the-mobile-first-company-raises-e3-5m-to-pioneer-a-new-approach-in-business-tooling/)
*2024-03-28*
- Category: article

### [#32 - Vivere Stays (Spain, Travel Tech) | Founder journey - Mauricio Lezama, Co-Founder & Co-CEO](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?i=1000668446818&l=pt-BR)
*2024-09-05*
- Category: podcast

### [Swisspreneur Podcast - Insights for Entrepreneurs and Startups](https://www.swisspreneur.org/podcast?7179bc6c_page=7)
*2025-04-24*
- Category: podcast

### [Excerpts from the Question and Answer Segment with Cartesi CEO, Erick De Moura](https://medium.com/@naitsirhcchristian/excerpts-from-the-question-and-answer-segment-with-cartesi-ceo-erick-de-moura-63958f2c415c)
*2020-05-31*
- Category: blog

---

## 📖 Full Content (Scraped)

*6 articles scraped, 26,247 words total*

### Letsmoviz
*223 words* | Source: **EXA** | [Link](https://letsmoviz.com/en)

![Image 1: Sam](https://www.letsmoviz.com/images/sam_en.png)

Place your products in independent films
----------------------------------------

I am

a

brand

Features

For directors and producers
---------------------------

*   Create your free profile in the pro space as provider
*    Upload your promo trailer or other media
*   Make a list of your needs in your marketplace: accessories, jewelry, perfumes or filming locations, food, drinks, vehicles, etc.
*    Lighten the production budget of your film with funding
*    Minimize costs associated with marketing activities (travel, festival attendance, forum, etc.)
*   Increase your visibility

Subscribe

 to mailing list

Features

For brands
----------

*   Browse and validate the profiles of directors and producers
*   Consult the list of their needs on their marketplace
*   Identify the most promising projects adapted to your image
*   Proceed to the placement of your product to maximize its visibility in a positive and rewarding context
*   To associate it with characters by integrating it naturally to the history so that it enters the daily newspaper of the spectator
*   Significantly and immediately increase your visibility, your prestige and boost your sales

Subscribe

 to mailing list

Help us with our project

If you like what we do and want to support us in the research and development of our test version (MVP) you can do it by clicking on the button "Donate".

Thanks for your support,

Letsmoviz team

---

### The Mobile-First Company raises €3.5M to pioneer a new approach in Business Tooling
*2,240 words* | Source: **EXA** | [Link](https://lsvp.com/stories/the-mobile-first-company-raises-e3-5m-to-pioneer-a-new-approach-in-business-tooling/)

The Mobile-First Company raises €3.5M to pioneer a new approach in Business Tooling - Lightspeed Venture Partners

===============

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 1](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie __cfruid 
*   Duration session 
*   Description Cloudflare sets this cookie to identify trusted web traffic. 

*   Cookie cookieyes-consent 
*   Duration 1 year 
*   Description CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors. 

*   Cookie _hp2_id.* 
*   Duration 1 year 1 month 
*   Description Heap Analytics sets this cookie to collect information on how visitors use the site.  

*   Cookie JSESSIONID 
*   Duration session 
*   Description New Relic uses this cookie to store a session identifier so that New Relic can monitor session counts for an application. 

Functional

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

No cookies to display.

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie __cf_bm 
*   Duration 30 minutes 
*   Description Cloudflare set the cookie to support Cloudflare Bot Management. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

*   Cookie _gid 
*   Duration 1 day 
*   Description Google Analytics sets this cookie to store information on how visitors use a website while also creating an analytics report of the website's performance. Some of the collected data includes the number of visitors, their source, and the pages they visit anonymously. 

*   Cookie CONSENT 
*   Duration 2 years 
*   Description YouTube sets this cookie via embedded YouTube videos and registers anonymous statistical data. 

*   Cookie vuid 
*   Duration 1 year 1 month 4 days 
*   Description Vimeo installs this cookie to collect tracking information by setting a unique ID to embed videos on the website. 

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie cb_group_id 
*   Duration 1 year 
*   Description Clearbit sets this cookie to track page views and traits for Clearbit. 

*   Cookie cb_anonymous_id 
*   Duration 1 year 
*   Description Clearbit sets this cookie to track page views and traits for Clearbit. 

*   Cookie _hp2_ses_props.* 
*   Duration 30 minutes 
*   Description Heap sets this cookie to store the timestamp and cookie domain or path. 

*   Cookie cebs 
*   Duration session 
*   Description Crazyegg sets this cookie to trace the current user session internally. 

*   Cookie attribution_user_id 
*   Duration 1 year 
*   Description This cookie is set by Typeform for usage statistics and is used in context with the website's pop-up questionnaires and messengering. 

Performance

- [x] 

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

*   Cookie _gat 
*   Duration 1 minute 
*   Description Google Universal Analytics sets this cookie to restrain request rate and thus limit data collection on high-traffic sites. 

Advertisement

- [x] 

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

*   Cookie YSC 
*   Duration session 
*   Description Youtube sets this cookie to track the views of embedded videos on Youtube pages. 

*   Cookie VISITOR_INFO1_LIVE 
*   Duration 5 months 27 days 
*   Description YouTube sets this co

*[... truncated, 13,303 more characters]*

---

### #32 - Vivere Stays (Spain, Travel Tech) | Founder journey - Mauricio Lezama, Co-Founder & Co-CEO
*1,511 words* | Source: **EXA** | [Link](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?i=1000668446818&l=pt-BR)

#32 - Vivere Stays (Spain, Tra… — MEXpreneurs Podcast — Apple Podcasts

===============

[](https://podcasts.apple.com/us/new?l=pt)

*   [Início](https://podcasts.apple.com/us/home?l=pt)
*   [Novidades](https://podcasts.apple.com/us/new?l=pt)
*   [Top charts](https://podcasts.apple.com/us/charts?l=pt)
*   [Buscar](https://podcasts.apple.com/us/search?l=pt)

Abrir no podcasts

Iniciar sessão

1×

*   0,8×  
*   1×  
*   1,3×  
*   1,5×  
*   1,8×  
*   2×  

Mais rápida

Mais lenta

Iniciar sessão

1×

*   0,8×  
*   1×  
*   1,3×  
*   1,5×  
*   1,8×  
*   2×  

Mais rápida

Mais lenta

![Image 1: MEXpreneurs Podcast](https://podcasts.apple.com/assets/artwork/1x1.gif)

*   05/09/2024
*   T1, E32
*   27MIN

#32 - Vivere Stays (Spain, Travel Tech) | Founder journey - Mauricio Lezama, Co-Founder & Co-CEO
================================================================================================

[MEXpreneurs Podcast](https://podcasts.apple.com/us/podcast/mexpreneurs-podcast/id1728020988?l=pt-BR)

 Reproduzir 

Mauricio Lezama is Co-Founder and Co-CEO of Vivere Stays, a Travel Tech startup based in Madrid, Spain.

Vivere Stays is dedicated to empowering small and independent hotels with advanced technology solutions, allowing them to compete on a level-playing field with larger chains. Its platform provides these hotels with tools for efficient revenue management, dynamic pricing, and improved guest experiences. Since its launch, Vivere Stays has expanded its portfolio to over 1,500 properties across Spain and Europe and has established partnerships with leading Property Management Software vendors like Misterplan, Avirato, and Apaleo.

Mauricio is originally from Mexico City. He has a diverse background with experience in the telecommunications, automotive, and hospitality industries and across corporates and startups. He moved to Spain in 2006 during his bachelor studies, seeking new opportunities and a fresh start in a dynamic environment. What began as a six-month plan turned into nearly 20 years as he built his career and family in Spain, eventually leading him to co-found Vivere Stays.

Content:

03:00 Mauricio’s passion for sales and how he developed his sales skills

05:50 His first steps into entrepreneurship thanks to his parents

07:30 Why Mauricio moved to Spain and his career since then across corporates and startups

13:30 Mauricio’s sales leadership roles at different startups

17:20 Why Mauricio decided to start Vivere Stays

22:10 Mauricio’s connection to Mexico

23:30 His best advise for aspiring founders

Learn more:

Mauricio in LinkedIn: https://www.linkedin.com/in/mauricio-lezama-luna/

Vivere Stays in LinkedIn: https://www.linkedin.com/company/viverestays/

Vivere Stays website: https://viverestays.com/

Episode page: https://www.mexpreneurs.com/podcast-viverestays

Our supporters for this episode:

https://skyflare.com/mexpreneurs

https://partnershipleaders.com/

[Página do episódio](https://podcasters.spotify.com/pod/show/mexpreneurs/episodes/32---Vivere-Stays-Spain--Travel-Tech--Founder-journey---Mauricio-Lezama--Co-Founder--Co-CEO-e2nvbp8)

Informações
-----------

*   Podcast [MEXpreneurs Podcast](https://podcasts.apple.com/us/podcast/mexpreneurs-podcast/id1728020988?l=pt-BR) 
*   Publicado 5 de setembro de 2024 às 08:00 UTC 
*   Duração 27min 
*   Temporada 1 
*   Episódio 32 
*   Classificação Livre 

Estados Unidos (Português Brasil)
*   [Español (México)](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=es-MX)
*   [العربية](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=ar)
*   [Русский](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=ru)
*   [简体中文](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=zh-Hans-CN)
*   [Français (France)](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=fr-FR)
*   [한국어](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=ko)
*   [Tiếng Việt](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=vi)
*   [繁體中文 (台灣)](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=zh-Hant-TW)
*   [English (US)](https://podcasts.apple.com/us/podcast/32-vivere-stays-spain-travel-tech-founder-journey-mauricio/id1728020988?l=en-US)

Selecionar um país ou região

África, Oriente Médio e Índia
-----------------------------

Ver tudo 

*   [Algeria](https://podcasts.apple.com/dz/new)
*   [Angola](https://podcasts.apple.com/ao/new)
*   [Armenia](https://podcasts.apple.com/am/new)
*   [Azerbaijan](https://podcasts.apple.com/az/new)
*   [Bahrain](https://podcasts.apple.com/bh/new)
*  

*[... truncated, 21,091 more characters]*

---

### Swisspreneur Podcast - Insights for Entrepreneurs and Startups
*17,092 words* | Source: **EXA** | [Link](https://www.swisspreneur.org/podcast?7179bc6c_page=7)

Latest 

episode

[![Image 1: Levent Künzi, Co-Founder & CEO of properti, Swisspreneur Podcast](https://cdn.prod.website-files.com/66efccf0a803cdb85497b2a7/6930c6ee63318aa81066f55b_Levent%20Kunzil.png)](https://www.swisspreneur.org/podcast/levent-kunzi-ep534)

No items found.

### About Sophie Lamparter:

As founder and managing partner at [DART labs](https://www.dartlabs.io/), [Sophie](https://www.linkedin.com/in/sophielamparter/) is a Silicon Valley VC with Swiss roots. She and her team focus on finding the best European technology startups and turning them into global players. Prior to becoming a venture capitalist, she worked in media relations. In a livestream with Swisspreneur host Silvan, she answered some of the most common fundraising questions, like:

‍

**Is your company VC-backable?**

- First things first: if you can scale your startup by bootstrapping it, don’t take investors in. How scalable is your company? And how scalable would you like it to be? VC money only goes to the most scalable companies. The goal of every VC is to have an investment be an entire fund returner — that’s how they look at startups.

‍

**Should you choose a VC fund or a business angel?**

- Both can work: it really depends on your case. Look for the person with the most insider knowledge/network in your industry. If that person happens to be a business angel, great. If it’s a VC fund, that’s great too.

‍

**How many investors should you talk to?**

- As many as you can handle. Your goal as a fundraising startup is to create FOMO (fear of missing out) in investors. If you’re only talking to one, he or she will feel perfectly at ease to drag things out, but if you’re talking to several investors simultaneously, each of them will be afraid that you’ll close a deal with someone else. Doing this in a condensed timeframe will allow you to really build up momentum.

‍

**What’s an inflection point?**

- An inflection point is anything that validates your business in the eyes of an investor.

- Examples: Entering a new market, launching the next version of your product, acquiring a big customer, reaching time milestones, sheer growth, etc.

### Memorable Quotes:

"The goal of every VC is to have an investment be an entire fund returner. That’s how they look at startups."

"Getting into Y Combinator can mean the difference between being valued at 6 million or 15 million."

‍

[![Image 2: Sophie Lamparter, managing partner DART Labs, Swisspreneur Podcast](https://cdn.prod.website-files.com/66efccf0a803cdb85497b2a7/6744abccb6ebb33d65648a6f_63d3d50e0f683c480801bb51_Sophie%2520Lamparter.avif) April 7, 2022 EP #231 - Sophie Lamparter: Picking The Brain Of A VC ----------------------------------------------------- Sophie Lamparter English Fundraising Fundraising](https://www.swisspreneur.org/podcast/sophie-lamparter-ep231)

Most listened

### Bio:

[Zeki Bulgurcu](https://www.linkedin.com/in/zeki-bulgurcu-6a9424193/) ist der Gründer von [Swissmeme](https://www.instagram.com/swissmeme/) und [Zekisworld](https://www.instagram.com/zekisworld/?hl=de). Aufgewachsen in Basel, startet Zeki seine berufliche Laufbahn mit einer Berufslehre als Detailhandelsfachmann. Seine ersten Memes veröffentlicht er 2013 - schnell entwickelt sich sein Instagram Kanal "Swissmeme" zu einer festen Grösse in der Schweizer Social Media Szene. Neben Instagram ist der Meme-König persönlich, aber auch mit weiteren Comedy Profilen auf [Facebook](https://www.facebook.com/zekisworld/), [Youtube](https://www.youtube.com/c/Zekisworld) und [TikTok](https://www.tiktok.com/@zekisworld) unterwegs. Nicht selten zählen diese Accounts mehrere 100'000 Follower und so ist der Baselbieter einer, wenn nicht der erfolgreichste "Social Media Typ" der Schweiz. Dank des starken Personal Brands, welchen er sich in den letzten Jahren aufgebaut hat, ist er immer wieder als Werbegesicht in Online aber auch Offline Medien zu sehen.

Neben über zehn erfolgreichen Social Media Accounts hat Zeki Bulgurcu eine eigene [Sucuk Wurst](https://www.migros.ch/de/genossenschaften/migros-basel/aktuelles-der-migros-basel/zekis-sucuk.html), welche in vielen Migros Filialen zu finden ist. Zudem plant er aktuell einen eignen Kino-Film.

### Memorable Quotes:

"Hör auf dein Bauchgefühl. Wenn du eine Leidenschaft hast, welcher du in deiner Freizeit gerne nachgehst - bleib dran! Vielleicht explodiert es und du kannst ein Business daraus aufbauen."

"Als ich kündete und auf Social Media setzte, sagten alle 'Du spinnst doch'. Doch das machen einige heute immer noch."

[![Image 3: Zeki Bulgurcu, Swissmeme, Swisspreneur Podcast](https://cdn.prod.website-files.com/66efccf0a803cdb85497b2a7/6744abdcbaeb84cc8a9f740d_63d3d4f703047868d7998e10_Zeki%2520Bulgurcu.avif) April 4, 2022 EP #230 - Zeki Bulgurcu: Meme-König, Influencer, Unternehmer ------------------------------------------------------------ Zeki Bulgurcu German Business Model Growth & Scaling Business Model Growth & Scaling](https://www.swisspreneur.org/podc

*[... truncated, 123,400 more characters]*

---

### Excerpts from the Question and Answer Segment with Cartesi CEO, Erick De Moura
*3,086 words* | Source: **EXA** | [Link](https://medium.com/@naitsirhcchristian/excerpts-from-the-question-and-answer-segment-with-cartesi-ceo-erick-de-moura-63958f2c415c)

[![Image 1: Naitsirhc Christian](https://miro.medium.com/v2/resize:fill:64:64/1*i9dOOzu45sRgWYp1hKArZA.jpeg)](https://medium.com/@naitsirhcchristian?source=post_page---byline--63958f2c415c---------------------------------------)

13 min read

May 31, 2020

Press enter or click to view image in full size

![Image 2](https://miro.medium.com/v2/resize:fit:700/1*FKVq8P36z6EgfNH0eu2CdQ.jpeg)

Here are the excerpts of the second Q&A segment with Cartesi CEO, Erick De Moura, released last March 27, 2020.

**Q: I will participate in future PoS mining. How many CTSI tokens will I need to start mining?**

**A:** You do not need any minimum CTSI to participate in Cartesi’s proof-of-stake system. Of course, since there is a POS system, the more tokens you reserve on stake accounts, the higher your chances of rewarding. In the coming weeks, we will post an article explaining the differences and details of our stake system. This will be an interesting experience for all of us because Cartesi is designing this betting system where players do not have to make an assumption about opportunity costs. So, stay tuned!

Press enter or click to view image in full size

![Image 3](https://miro.medium.com/v2/resize:fit:700/1*KsooEsbcAkz9wMOP1p7b2g.jpeg)

**Q: Can you talk about the effect of SDK Documentation version? How important will this be to acquire new developers? What does this version mean for the Cartesi ecosystem?**

**A:** Thank you for asking this question. SDK documents are very important to us. Because we will only be able to engage mainstream developers with this, which will facilitate DF development to the point where they can offer good documentation, a good tutorial and so on. Therefore, the first version of our SDK documentation will be entirely Cartesi Core, which is basically our main point in our technical article. The first version of our SDK will be called Dean SDK and this SDK documentation and development portal will be covered throughout the version. Realizing this version is a huge turning point for us, since from now on we are opening the doors of developers to use Cartesi nodes and to develop creative things that we cannot even imagine. So, I’m very excited for this turning point, and this is not the end, this is really just the beginning. This documentation is something that will constantly evolve as a deck of the ship and like a living organism, and of course the feedback we receive from Cartesi communities will be very important even for our development, so we really welcome all opinions by recommending to join everyone. Courtesy of this process is really easy to use and practice people. We invite everyone to participate in this process to make Cartesi really easy for people to use, and we want to improve our practices accordingly. it will be very important even for our development only, so we really welcome all opinions by recommending to everyone. Courtesy of this process is really easy to use and practice people. We invite everyone to participate in this process to make Cartesi really easy for people to use, and we want to improve our practices accordingly. it will be very important even for our development only, so we really welcome all opinions by recommending to everyone. Courtesy of this process is really easy to use and practice people. We invite everyone to participate in this process to make Cartesi really easy for people to use, and we want to improve our practices accordingly.

**Q: What are the biggest threats or problems you face when Cartesi is applied in the real world? What is your plan to overcome these problems?**

**A:** Cartesi is not just a start-up and only a crypto start-up. So, like other investors, Cartesi’s journey is full of risks. It is very new and unbalanced in many areas, especially in the field of crypto it was opened. However, I would like to tell you a little bit about our story: We established Cartesi in Singapore around 2018 in January, and this was the time when the crypto winter really made us hard. We had to struggle to survive for almost a year and a half. We had a very visionary idea, we had a great team of researchers and engineers, and although we were only a few founders, we really weren’t afraid to pay a little more than our pocket to work with this little team and achieve our goals, we knew we would wait a long time even to earn revenue from the company. And for days I woke up feeling that the company could fail at any moment. During this journey, I felt many times desperate because it was really difficult to raise money from sources owned by traditional investors, especially outside the blockchain area. And technology was our signature, we had a good vision of what we wanted to get, but we really had our resources missing and a lot to do. This was a great resistance test for us. And finally, there are many threats ahead, but we have entered a new stage in our company, we have new technologies, we are expanding our team even more. We know better what w

*[... truncated, 13,671 more characters]*

---

### Marché du placement de produits en ligne
*2,095 words* | Source: **GOOGLE** | [Link](https://www.letsmoviz.com/letsmoviz_doc-promo.pdf)

Marché du placement 

# de produits en ligne 

Letsmoviz est une entreprise proposant une solution 

novatrice en ligne de type WaaS. Cette plateforme facilite 

la mise en relation entre les entreprises intéressées 

par le placement de produits ET les producteurs/réalisateurs 

de courts, moyens et longs métrages. LE PLACEMENT DE PRODUITS 

Les producteurs de films ont diverses sources de financement comprenant  :

Public 

(bourses, prêts, 

crédits d’impôt) 

Privé 

(plusieurs 

formes) 

Personnel 

(crédit, 

love money) 

Placement 

de produits 

Le placement de produits est une stratégie de communication commerciale 

consistant à intégrer un produit, un service, une marque, ou à en faire référence 

au sein d’une production visuelle. 

Cette technique de financement est fréquemment employée sur le grand écran. 

Nous sommes habitués à voir le logo de la pomme sur les produits Apple 

utilisés par les personnages, tout comme à observer James Bond consulter 

rituellement sa montre Omega. 

Les grandes productions ont des départements dédiés à la gestion du 

placement de produits, mais cette source de financement est moins 

accessible pour les productions indépendantes. Ces dernières ne disposent 

souvent ni des connaissances ni des ressources nécessaires pour mener 

un démarchage efficace. L’aspect légal représente un obstacle majeur pour 

les petites productions qui ne possèdent pas de département juridiques. 

Les opportunités de placement de produits pour les entreprises locales, 

régionales  et internationales sont également limitées, car elles n’ont pas 

les moyens financiers nécessaires de participer à de grandes productions. 

Un placement de produits efficace au sein d’une production locale permet 

un ciblage plus précis qu’une publicité diffusée dans les médias de masse. 

Letsmoviz est une plateforme web innovatrice en digitalisant le placement 

de produits dans les films, agissant comme intermédiaire entre les 

réalisateurs, les producteurs et les marques qui désirent publiciser leurs 

produits et services. 

Letsmoviz a été pensée afin de faire le pont entre les sociétés 

de production et les entreprises. SERVICES OFFERTS 

Letsmoviz est une plateforme web sécurisée et transactionnelle. 

Fonctionnant comme un service en ligne (WaaS - website as a service), 

la plateforme en ligne Letsmoviz crée un lien entre les productions 

cinématographiques et les entreprises offrant des opportunités de placement, 

le tout grâce à un modèle d’abonnement. 

Deux volets : 

Entreprise 

La page d’entreprise comprend 

une ou plusieurs fiches 

d’opportunités de placement 

— Fiche de produits à placer. 

Caractéristiques du produit, 

la sélection des conditions 

(tarifs, attributs contractuels, 

etc.)  

> EXEMPLE :

Une entreprise technologique qui 

souhaite placer son nouveau 

téléphone intelligent dans 

des films d’aventure mettant en 

scène un personnage féminin sur 

le marché francophone européen. 

Page projet / production 

Il peut s’agir d’une fiche pour un 

seul projet, ou que le projet soit 

lié à une société de production 

— Contient une description 

de la production visuelle, 

le type de production (court, 

moyen, long métrage et 

vidéo), le type de placement 

souhaité, etc.  

> EXEMPLE :

Production indépendante 

qui souhaite financer un film 

d’aventure avec un personnage 

féminin en Belgique. SERVICES OFFERTS  / SUITE 

Les interactions sont générées de trois manières distinctes  :

1)  Recommandations automatisées du système à l’aide d’algorithmes 

qui détectent la compatibilité entre les opportunités de placement 

et les projets de productions visuelles 

2)  Recherche avec filtres parmi les opportunités de placement de produits 

et les projets de productions visuelles 

3)  Recommandations d’un tiers membre de la plateforme 

## OUTILS DE RÉSEAUTAGE 

Un outil de réseautage facilite les échanges entre les entreprises 

qui placent des produits et les producteurs de créations visuelles. 

Le système peut guider les négociations à travers des échanges 

prédéterminés, ou les intervenants peuvent négocier librement. 

Le site enverra des communications transactionnelles personnalisées 

(SMS, courriels) selon la configuration des utilisateurs. 

## OPTIONS  :

Contrat  :

Un module permet de créer un 

contrat entre les intervenants. 

Un contrat type sert de base, 

duquel on peut paramétrer 

certaines variables (coût, produit, 

durée, visibilité, rayonnement, 

droits de distribution, etc.). 

Il s’agit d’un service payant. 

Transactionnel  :

Un autre module permet de 

sécuriser l’aspect transactionnel. 

Diverses modalités peuvent être 

appliquées, comme le paiement 

par étape à date prédéterminée. 

Il s’agit d’un service payant. PLATEFORME 

La plateforme en ligne fonctionne en tant que WaaS (Website as a Service). 

L’abonnement est payant, et l’inscription à la plateforme est nécessaire 

pour participer. 

Une partie publique du site

*[... truncated, 9,658 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Marché du placement de produits en ligne](https://www.letsmoviz.com/letsmoviz_doc-promo.pdf)**
  - Source: letsmoviz.com
  - *Letsmoviz a été pensée afin de faire le pont entre les sociétés de ... Jérôme Moura a travaillé auprès de divers organismes internationaux avant de s ...*

---

*Generated by Founder Scraper*
