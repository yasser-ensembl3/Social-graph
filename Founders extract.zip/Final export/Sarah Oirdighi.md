# Sarah Oirdighi

## Position actuelle

**Titre** : Fondatrice
**Entreprise** : COLORS
**Durée dans le rôle** : 2 years 3 months in role
**Durée dans l'entreprise** : 2 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Marketing Services

## Description du rôle

La première agence de social selling, de personal branding et d'influence B2B sur Linkedin au Québec.

Nos services : 

- Ghostwriting de posts 
- Gestion complète des réseaux sociaux 
- Rédaction d'articles et de newsletter
- Campagne d’influence pour entreprises 
- Génération de leads

## Résumé

Everyone wants to grow their personal brand on Linkedin.
But no one is telling you how to do it... 

With over 3.5 million impressions, 20,000 subscribers on social networks,
I managed to build a business from 0 and in 2 years, thanks to Linkedin. 😌

After signing +60 customers and generating +100k$ thanks to my content creation,
Today, I want to teach others how to do the same.

Without spending months trying to find the right method...
Or spending hours on Linkedin replying to comments or creating the perfect carousel. 😮‍💨

By the way, I'm Sarah! 💙
I help entrepreneurs develop and monetize an audience, thanks to their personal brand.


↳ In 2023: I was working in a multinational company in Montreal and earning a good living. But I lacked freedom. I was fed up with meetings all day long. Tired of not being able to spend more time traveling and visiting my family in Morocco. 

↳ In 2024: I became the number 3 creator on LinkedIn in Quebec, building my personal brand and personal branding agency.

↳ In 2025: I'm creating the best Social Selling program to teach you exactly how to succeed on your own. Without sacrificing your authenticity, and your peace of mind.

---- 


Here's how I can help you today:

📸 Subscribe to my YouTube channel 

💌 Join over 1000 amazing people and subscribe to my newsletter.

💙 Join the +60 social selling members.


And if you're not ready for all that, just stick around on Linkedin! 
I talk about content marketing, personal branding and share all the behind the scenes of my business.


Collabs and influence: sarah@agence-colors.com

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB82Bo8BBroY_j_qXcZMBVU0klQaAoYFIPg/
**Connexions partagées** : 35


---

# Sarah Oirdighi

## Position actuelle

**Entreprise** : COLORS

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Sarah Oirdighi
*COLORS*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [The McGill Daily: Volume 114, Issue 9](https://issuu.com/mcgilldaily/docs/tmd_20241111)
*2024-11-11*
- Category: article

### [The Sound of Colour](https://www.buzzsprout.com/2374912/contributors/101554)
*2025-01-01*
- Category: article

### [](https://podcasts.apple.com/us/podcast/the-sound-of-colour/id1752938765)
- Category: podcast

### [Raw Color - From Beetroot Juice to IKEA: A Colourful Journey - The Sound of Colour](https://thesoundofcolour.buzzsprout.com/2374912/episodes/15798778-raw-color-from-beetroot-juice-to-ikea-a-colourful-journey)
- Category: article

### [Celebrating Color Congress’s Work Supporting the Ecosystem of Filmmakers of Color – Common Counsel Foundation](https://www.commoncounsel.org/cultural-and-narrative-power-building-celebrating-color-congresss-work-supporting-the-ecosystem-of-filmmakers-of-color/)
*2024-08-15*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[COLORS - Agence de personal branding à Montréal](https://agence-colors.com/)**
  - Source: agence-colors.com
  - *Huitème vidéo Podcast de Sarah Oirdighi pour l'agence de personal branding COLORS. Deuxième Podcast de Sarah Oirdighi pour l'agence de personal brandi...*

- **[CONTENFEST | JUNE 3, 2025](https://contenfest.com/)**
  - Source: contenfest.com
  - *Jun 3, 2025 ... Sarah Oirdighi. Sarah-oirdighi-reseaux-sociaux. Sarah Oirdighi. Bio ... She later established COLORS, a personal branding agency that ...*

- **[À Propos - COLORS](https://agence-colors.com/apropos)**
  - Source: agence-colors.com
  - *Photo de Sarah Oirdighi, Founder de l'agence de personal branding COLORS dans une ... Podcast Side Hustle. Lancement et création d'un nouveau podcast ...*

- **[Sommet médias sociaux 2024 - Formations Infopresse](https://www.infopresse.com/formation/sommet-medias-sociaux-2024/)**
  - Source: infopresse.com
  - *Vanessa Pilon. Animatrice et créatrice du podcast "L'école de la vie" ... Sarah Oirdighi, Fondatrice, Agence COLORS. 11h20 - Conférence d'expertise. T...*

- **[Conférenciers SI – Inspirez-vous des experts de l'entrepreneuriat](https://sisaguenay.ca/conferenciers/)**
  - Source: sisaguenay.ca
  - *Personal branding agence COLORS. sarah@agence-colors.com - Créatrice de contenu et conférencière passionnée. Sarah Oirdighi est fondatrice de l'agence...*

- **[Sommet Leadership de demain - Conférence Les Affaires](https://evenements.lesaffaires.com/products/2024-12-04-sommet-leadership-de-demain)**
  - Source: evenements.lesaffaires.com
  - *Dec 4, 2024 ... Cette première conférence, organisée en collaboration avec ... Rejoignez Sarah Oirdighi, la fondatrice de l'agence COLORS, pour ......*

---

*Generated by Founder Scraper*
