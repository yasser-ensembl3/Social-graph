# Camille Mc Innis

## Position actuelle

**Titre** : Co-Founder & Associate
**Entreprise** : Cygnus Stratégies
**Durée dans le rôle** : 2 years 4 months in role
**Durée dans l'entreprise** : 2 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Consulting and Services

## Description du rôle

I help organizations anticipate threats, plan effectively, respond decisively, and safeguard their most critical assets. Let’s work together to ensure your operations remain agile, resilient, and ready for tomorrow’s challenges.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB6CYqIBu00Dv7incK-YnvQ9AR5DguB_Fn8/
**Connexions partagées** : 7


---

# Camille Mc Innis

## Position actuelle

**Entreprise** : Cygnus Strategies

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Camille Mc Innis

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399061877349203968 | Article |  |  | On part tous de la prémisse qu’il est extrêmement bénéfique de faire des retours après incident : ce qui a bien été, ce qui a moins bien été et les leçons apprises.

Dans le monde de la sécurité et de la gestion des risques, après chaque exercice ou événement, il est de notre devoir d’analyser comment il a été géré, pour mettre en lumière les failles et, surtout, pour nous réajuster et faire mieux la prochaine fois.

Je me suis questionnée sur les moyens de faire rayonner ces débriefings et c’est de là qu’est née l’idée du podcast Cold Wash. En effet, nous n’avons pas tous besoin de commettre les mêmes erreurs. En les partageant, nous pouvons apprendre les uns des autres et, collectivement, être meilleurs.

Plusieurs d’entre vous ont généreusement accepté de me donner du temps pour venir raconter vos récits (parfois difficiles) et en faire bénéficier la communauté de la gestion des risques ainsi que le grand public.

Par ailleurs, cela me réjouit de mettre en lumière des experts qui, en raison de leur choix de carrière et de leur grande humilité, sont souvent bien loin des projecteurs.

À l’ère où l’IA est partout : sur LinkedIn, dans les vidéos et même dans la suite Office (bonjour Copilote!), c’est vraiment précieux pour moi d’entretenir des conversations authentiques avec des êtres humains, parce qu’on aura beau être rendus aux meilleures itérations de GPT, Perplexity, Gemini (en anglais avec un accent québécois, ça rime), rien ne remplacera les histoires poignantes des experts qui les ont vécues.

Comme me le répétait souvent ma mentore à l’Office national du film, Luisa Frate,  CPA,CA : « Camille, it’s all about the story. » Et c’est ça, Cold Wash.

Dans ce troisième épisode, vous entendrez l’analyse fascinante d’Eric Sauvé, CD, vétéran et ancien officier de renseignement, qui raconte son déploiement à Kandahar et les enjeux rencontrés.

Bon visionnement!

PS : si vous avez apprécié la discussion, je vous serais très reconnaissante de la partager. Les algorithmes ne facilitent pas la découvrabilité. 
https://lnkd.in/ejBbfyGf | 23 | 5 | 4 | 1w | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:44.560Z |  | 2025-11-25T12:30:19.482Z | https://www.youtube.com/watch?v=erpafuK5ejw |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7386371970562543616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7d55b52e-1268-44e8-a6bf-7ecd3e6bb7df | https://media.licdn.com/dms/image/v2/D4E05AQEAp6idYViK5Q/videocover-low/B4EZmCzAM4IIB8-/0/1758836929311?e=1765785600&v=beta&t=n9PRLwUFSga9HeUSfM3ajEsPbqulyYqRSJrEnFtf6NI | Hâte d'avoir votre rétroaction sur l'épisode 1. 🧊 | 7 | 2 | 2 | 2mo | Camille Mc Innis reposted this | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.686Z |  | 2025-10-21T12:05:09.937Z | https://www.linkedin.com/feed/update/urn:li:activity:7377097029883273216/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7377109052704649216 | Video (LinkedIn Source) | blob:https://www.linkedin.com/66ceead0-e3e9-4fb3-97eb-0b5cb63dad5b | https://media.licdn.com/dms/image/v2/D4E05AQEAp6idYViK5Q/videocover-low/B4EZmCzAM4IIB8-/0/1758836929311?e=1765785600&v=beta&t=n9PRLwUFSga9HeUSfM3ajEsPbqulyYqRSJrEnFtf6NI | Hâte d'avoir votre rétroaction sur l'épisode 1. 🧊 | 7 | 2 | 2 | 2mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.687Z |  | 2025-09-25T22:37:38.223Z | https://www.linkedin.com/feed/update/urn:li:activity:7377097029883273216/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7376676602333634560 | Text |  |  | J’ai eu le privilège d’assister à un atelier vraiment intéressant sur le concept de Présilience, hier à Ottawa.

J’ai grandement apprécié la qualité du contenu présenté et la pertinence des interventions : des messages forts, des exemples concrets, je le recommande vivement. Merci à tous ceux qui ont pris la parole. ✨ 

C’était également un plaisir de connecter et reconnecter avec plusieurs acteurs du milieu de la sécurité. 

Qui sait, peut-être que si plusieurs personnes écrivent à Rob Currie B.Sc. F.ISRM RPP, lui et son équipe viendront présenter l’atelier en français à Montréal. 👀 | 1 | 1 | 0 | 2mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.689Z |  | 2025-09-24T17:59:14.020Z | https://www.linkedin.com/feed/update/urn:li:activity:7360651792394665985/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7374189417193840640 | Video (LinkedIn Source) | blob:https://www.linkedin.com/602e7df2-734e-45bb-a547-9d266187b85e | https://media.licdn.com/dms/image/v2/D4E05AQEIu7pKsM7SZg/videocover-low/B4EZlZhl9lHoB4-/0/1758143747728?e=1765785600&v=beta&t=0fYA63Jb-EH1mS0c9W7lQ1oK9ORonZMdDIibbXUKkZE | Cold Wash - Épisode 1 🥶 

Un immense honneur d’accueillir Rob Currie B.Sc. F.ISRM qui dirigeait l’équipe tactique nationale de la GRC ayant répondu à l’attentat au Parlement en 2014.

🎙️ Pour voir l'épisode complet, il est en ligne, ici : https://lnkd.in/euK2rCqq 

PS : Remerciements à l'incroyable équipe du @studiosf. 💫 | 34 | 4 | 7 | 2mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.690Z |  | 2025-09-17T21:16:02.873Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7373820087490846720 | Text |  |  | On espère vous voir parmi nous ! ✨ | 2 | 0 | 0 | 2mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.690Z |  | 2025-09-16T20:48:27.810Z | https://www.linkedin.com/feed/update/urn:li:activity:7373746477292122112/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7370531748494905344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGtM09pXUoHkA/feedshare-shrink_800/B4EZklh_WMIIAk-/0/1757271292349?e=1766620800&v=beta&t=fu17VoSWekjbh998JzTJBztNFexEIrgnBqMkrk3wvtk | On a travaillé tout l’été. 🎙️ ColdWash arrive bientôt.
We’ve been heads-down all summer. 🎙️ ColdWash drops soon. | 11 | 2 | 2 | 3mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.691Z |  | 2025-09-07T19:01:46.699Z | https://www.linkedin.com/feed/update/urn:li:activity:7370530014376800256/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7370530014376800256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGtM09pXUoHkA/feedshare-shrink_800/B4EZklh_WMIIAk-/0/1757271292349?e=1766620800&v=beta&t=fu17VoSWekjbh998JzTJBztNFexEIrgnBqMkrk3wvtk | 🎙️ C’est avec fébrilité qu’on annonce le lancement prochain de ColdWash : leçon d’expert.

Des retours après-action sans filtre sur des crises bien réelles, racontés par celles et ceux qui les ont vécues.

Au programme à chaque épisode :

🔹 Un cas marquant vécu
🔹 Un·e expert·e directement impliqué·e pour le décortiquer
🔹 Ce qui a bien fonctionné, ce qui a moins bien fonctionné, et ce qui a été fait, ou aurait dû l’être. 

On lève le voile sur des professions souvent méconnues, trop souvent dans l’ombre. 

Pour le premier épisode, tout ce que je peux dire, c’est qu’on parle d’une intervention policière marquante, de sécurité nationale, de terrorisme et de JTF-2. 👀 

📣 L’invité de l’épisode 1 sera annoncé très bientôt. Le balado sera disponible sur toutes les plateformes. 

#ColdWash #GestionDeCrise #Sécurité #ContinuitéDesAactivités #Résilience #Québec #Canada #EmergencyManagement | 24 | 12 | 3 | 3mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.692Z |  | 2025-09-07T18:54:53.253Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7365435722939510784 | Text |  |  | The April 2025 webinar on navigating the economic impacts of trade tensions with Risk 2 Solution Group and @RCAS was excellent.
✨ I’m now excited to attend the upcoming Executive Workshop on the Presilience Framework, taking place in Ottawa on September 23. Looking forward to connecting and learning alongside fellow colleagues. 🤓 📚 
Who else will be there? | 4 | 0 | 0 | 3mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.692Z |  | 2025-08-24T17:31:59.527Z | https://www.linkedin.com/feed/update/urn:li:activity:7360651792394665985/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7357121928970543105 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9422102a-673f-417b-a441-4a1e8ac5ac63 | https://media.licdn.com/dms/image/v2/D5605AQHWPvHMnviP9Q/feedshare-thumbnail_720_1280/B56ZhmtKgeH0A0-/0/1754069774585?e=1765785600&v=beta&t=UOZ9KChh6tx9-12Ge2ZrY9CTRNgnoZ4IJN8eorH41ow | Thank you to Musaab F. from the ISRM Canadian Chapter for the warm welcome and the thoughtful exchange 🙏 I feel privileged to be part of such a valuable network. 🌐

Merci à Musaab F. du chapitre canadien de l’ISRM pour ce bel accueil et cet échange 🙏 Je me sens privilégiée de faire partie d’un réseau de grande valeur. 🌐
#ISRM #RiskManagement #Gratitude #Leadership #Network | 6 | 4 | 0 | 4mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.694Z |  | 2025-08-01T18:55:56.582Z | https://www.linkedin.com/feed/update/urn:li:activity:7357102702763397120/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7341489962204180483 | Text |  |  | 🔥 Températures extrêmes + événements extérieurs = risques bien réels.

☀️ Face à des vagues de chaleur de plus en plus fréquentes, comment prendre les bonnes décisions au bon moment pour protéger les équipes, les artistes et le public?

🎤 Rejoignez Martin Deslauriers. CPP, PSP, PCI., une communauté engagée, et moi-même pour la prochaine table ronde « En sécurité et en confiance » organisée par Event Safety Alliance Canada - chapitre Québec. 

Une discussion essentielle entre professionnels de la sécurité, de la production et de la SST, autour des meilleures pratiques à adopter en contexte de chaleur extrême.

Au programme :
✔️ Prévention des coups de chaleur et surveillance des signes précurseurs
✔️ Clarification des rôles et responsabilités : Qui décide? Quand? Comment?
✔️ Mesures concrètes à déployer avant qu’un incident ne survienne
✔️ Déclenchement d’un protocole d’interruption sécuritaire : quels critères, quelle communication?

📅 26 juin à 13 h (HE)

📍 Événement virtuel et gratuit — inscription requise 👇 

🔗https://lnkd.in/dPy68feQ 

👉 Un rendez-vous incontournable pour toutes celles et ceux qui ont à cœur la sécurité événementielle, surtout lorsqu’il faut composer avec des conditions météorologiques extrêmes.

#EventSafety #SST #GestionDesRisques #SécuritéÉvénementielle #Canicule #Prévention #ESAC #EnSécuritéEtEnConfiance #SantéSécurité | 7 | 0 | 4 | 5mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.695Z |  | 2025-06-19T15:40:05.277Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7331703392995643393 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFHJWNWYX9GIA/feedshare-shrink_480/B4DZb9xYsqGgAo-/0/1748014304599?e=1766620800&v=beta&t=bP9W4A7wVNhuOvJbucyRIUPtBVWwlubt_j4T9ct-jjE | 🔊 Lancement officiel des discussions « En sécurité et en confiance », une nouvelle initiative d’Event Safety Alliance Canada (ESAC)

 📅 Mardi 27 mai | ⏰ 13 h (HE) | 📍 Sur Zoom

🎙️ Aux côtés de mes estimés collègues Martin Deslauriers. CPP, PSP, PCI. et Janet Sellery, CRSP, CHSC, j’ai le grand plaisir de vous inviter à cette première rencontre en français, spécialement conçue pour les professionnel·les œuvrant dans les domaines du spectacle, des festivals, du sport, de la production et de la sécurité au Québec.

Nous reviendrons sur une tragédie récente qui a profondément marqué le pays :
 👉 L’incident de sécurité majeur impliquant un véhicule-bélier à Vancouver.
Cet événement marquant nous rappelle la complexité de la gestion des risques dans la planification des événements publics.

 Ce forum se veut un espace d’échange pour les professionnel·les de l’industrie afin de discuter ensemble des enjeux, des défis et des bonnes pratiques en matière de sécurisation des rassemblements.

🎫 Gratuit – inscription requise

 🔗 https://lnkd.in/dSf2k4cg

***Les thèmes des prochaines discussions seront annoncés sous peu.

#SécuritéÉvénementielle #EventSafety #SécuritéEnConfiance #ESACanada #CultureDeLaSécurité #GestionDesRisques #VigilanceCollective | 11 | 0 | 4 | 6mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.695Z |  | 2025-05-23T15:31:45.352Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7308627795688017920 | Text |  |  | Le 31 mars prochain, après près de dix ans au sein du gouvernement fédéral, je tournerai la page sur ce chapitre de ma carrière.

À tous mes collègues, amis et mentors du Gouvernement du Canada, d’un océan à l’autre : MERCI! La liste est trop longue pour souligner l’impact de chacune et chacun sur mon parcours, mais vous savez qui vous êtes — et vous êtes tous si précieux. 🇨🇦🫶🏼

(J’ai une pensée particulière pour les collègues qui œuvrent dans l’ombre et qui, par la nature même de leur métier en sécurité, demeurent très discrets. Merci. La sécurité de notre pays repose sur vos sacrifices quotidiens, et ce fut un honneur de pouvoir collaborer avec certains d’entre vous.)

Pour la prochaine étape de ma carrière, j’ai choisi de relever le défi entrepreneurial, et je ne pourrais être plus enthousiaste à l’idée de ce changement de cap. Dès le 1er avril, j’offrirai mes services de consultation aux entreprises pour les accompagner dans leurs programmes de sécurité et de continuité des activités, via ma propre entreprise, Cygnus Stratégies. 

Nos services seront bientôt hautement différenciés grâce à l’intégration de l’IA et de l’intelligence d’affaires — nous finalisons actuellement le prototype de SEVA, notre première application dédiée à l’automatisation de la gestion des urgences. ✨

Si vous souhaitez en discuter ou prendre un café virtuel avec moi, n’hésitez pas à planifier une rencontre! ☕️

À très bientôt! 😄
Camille | 74 | 27 | 1 | 8mo | Post | Camille Mc Innis | https://www.linkedin.com/in/camille-mc-innis-116508123 | https://linkedin.com/in/camille-mc-innis-116508123 | 2025-12-08T07:09:46.696Z |  | 2025-03-20T23:17:34.230Z |  |  | 

---



---

# Camille Mc Innis
*Cygnus Strategies*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [](https://ca.linkedin.com/in/camillemcinnis)
- Category: article

### [Our team - Cygnus Stratégies](https://cygnusstrategies.com/en/our-team/)
*2025-04-13*
- Category: article

### [Resources | CYGNVS](https://www.cygnvs.com/resources)
*2025-01-01*
- Category: article

### [Podcast: Unlocking the Secrets of Sales Compensation](https://cygnalgroup.com/podcast-early-stage-saas-2/)
*2025-04-23*
- Category: podcast

### [Life & Work with Camille Nugent](https://voyageutah.com/interview/life-work-with-camille-nugent/)
*2024-06-26*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Notre équipe - Cygnus Stratégies](https://cygnusstrategies.com/notre-equipe/)**
  - Source: cygnusstrategies.com
  - *Podcasts · Équipe · Blogue · FAQ · Nous joindre · En. L'équipe. Home Notre équipe. L'équipe de Cygnus Stratégies. Camille Mc Innis. Position : Associé...*

- **[Podcasts - Cygnus Strategies](https://cygnusstrategies.com/podcasts/)**
  - Source: cygnusstrategies.com
  - *... Camille Mc Innis nous parle d'elle, de ses antécédents et expériences vécues ... © Copyright Cygnus Stratégies inc. 2025....*

- **[Our team - Cygnus Stratégies](https://cygnusstrategies.com/en/our-team/)**
  - Source: cygnusstrategies.com
  - *Meet the management team at Cygnus Strategies, your trusted partner for security, business continuity and emergency management ... Camille Mc Innis, B...*

---

*Generated by Founder Scraper*
