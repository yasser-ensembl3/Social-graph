# Pierre Delage

## Position actuelle

**Titre** : Project Management Teacher - Part Time
**Entreprise** : Rubika Montreal
**Durée dans le rôle** : 4 years 3 months in role
**Durée dans l'entreprise** : 4 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Higher Education

## Résumé

Profile:
- Producer since 2012, 7 games shipped on mobile, PC and consoles.
​- Thrive to create the best possible work conditions for the team.
- Can articulate ideas, information and know-how with ease and clarity.
- Able to make hard decisions, remaining goal-directed and driven.
- Hate reckless risks and always try to elaborate creative solutions to deadlocks.
- Prepared to receive constructive criticism, and respond to it with humility.


Skills:
- Productions of casual and core games for web, mobile and consoles
- Risk management
- Scheduling, tasking and budgeting
- Long term management and team building
- Practicing scrum master
- KPI analysis
- Great understanding of game design

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAZxXZ8BkkrJ2ttyi9EZhuSFjsYWGr7j0H0/
**Connexions partagées** : 6


---

# Pierre Delage

## Position actuelle

**Entreprise** : Porcelaine Digital Games

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pierre Delage

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389649353797234688 | Text |  |  | Pour rejoindre une super équipe sur un projet vraiment passionnant. | 8 | 0 | 0 | 1mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:32.900Z |  | 2025-10-30T13:08:18.991Z | https://www.linkedin.com/feed/update/urn:li:activity:7389127947267502080/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7327750012975607808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZQODg9qz8HQ/feedshare-shrink_800/B4EZbE_MIZGQAk-/0/1747061621770?e=1766620800&v=beta&t=fNw7mO-QSl3LiVwlckWuP17ZVHuvkEP_EALSXpPVE_0 | Vous connaissez des gens en finances / fiscalité qui veulent travailler dans un environnement vraiment cool et relever de nouveaux défis? On cherche ca a l'Indie Asylum 👀 
--» plus de détails ici : https://lnkd.in/eb5yJCyv | 6 | 1 | 0 | 6mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:32.904Z |  | 2025-05-12T17:42:26.105Z | https://www.linkedin.com/feed/update/urn:li:activity:7327707551574245377/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7305287266732523522 | Text |  |  | Benoit is an awesome human and an equally great programmer, I loved working with him and I guarantee he would be a great addition to your team. | 4 | 0 | 0 | 8mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:32.904Z |  | 2025-03-11T18:03:30.063Z | https://www.linkedin.com/feed/update/urn:li:activity:7305228147925438465/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7300724114481135617 | Text |  |  | Liam est un excellent tech artist avec en bonus le skill de faire du concept art. Un super profil pour une equipe qui veut des gens multidisciplinaires. | 11 | 1 | 1 | 9mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:32.905Z |  | 2025-02-27T03:51:09.787Z | https://www.linkedin.com/feed/update/urn:li:activity:7294816277800370179/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7300261060945559552 | Text |  |  | Minhye is an incredible artist: motivated, talented and fast. She has helped us a lot on our projects at Porcelaine over the past two years. | 1 | 0 | 0 | 9mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:36.587Z |  | 2025-02-25T21:11:09.221Z | https://www.linkedin.com/feed/update/urn:li:activity:7300257908032745473/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7285410988059754497 | Text |  |  | Une opportunité en or pour participer a des missions commerciales pour promouvoir vos jeux! | 3 | 1 | 0 | 10mo | Post | Pierre Delage | https://www.linkedin.com/in/delagepierre | https://linkedin.com/in/delagepierre | 2025-12-08T07:16:36.588Z |  | 2025-01-15T21:42:15.944Z | https://www.linkedin.com/feed/update/urn:li:activity:7285408614045908993/ |  | 

---



---

# Pierre Delage
*Porcelaine Digital Games*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Porcelaine Digital Games | LinkedIn](https://ca.linkedin.com/company/porcelaine-jeux-num%C3%A9riques-digital-games)
*2025-01-01*
- Category: article

### [PID Games: The "punk" indie publisher giving small studios their first chance](https://gamesindustry.biz/pid-games-the-punk-indie-publisher-giving-small-studios-their-first-chance)
*2022-11-22*
- Category: article

### [Getting Tactical With Pierre Leclerc, Creator of Fell Seal: Arbiter’s Mark](https://medium.com/super-jump/getting-tactical-with-pierre-leclerc-creator-of-fell-seal-arbiters-mark-57a6178a2aa8)
*2020-07-25*
- Category: blog

### [Culturalization of Video Game Soundtracks | Interview with Pierre Langer, Managing Director & Founder of](https://altagram.com/culturalization-of-video-game-soundtracks-an-interview-with-pierre-langer-managing-director-founder-of-dynamedion/)
*2023-08-17*
- Category: article

### [Pierô: Art in Board Games #7 — More Games Please](https://www.moregamesplease.com/art-in-boardgames/2017/7/11/pier-art-in-board-games-7)
*2017-07-11*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Pierre Delage Email & Phone Number | Dugas Commercial director ...](https://rocketreach.co/pierre-delage-email_65734364)**
  - Source: rocketreach.co
  - *Porcelaine Digital Games Employee Pierre Delage's profile photo · Pierre ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
