# Marie Lamarre

## Position actuelle

**Titre** : Cofondatrice et directrice
**Entreprise** : Pavillons
**Durée dans le rôle** : 3 years 10 months in role
**Durée dans l'entreprise** : 3 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Artists and Writers

## Description du rôle

Pavillons est une plateforme qui permet aux créateur.rice.s de se dédier à des projets d'écriture en feuilletons et aux lecteur.rice.s de s'abonner à ces projets pour en découvrir le contenu de manière exclusive.

## Résumé

J'accompagne les auteur.rices depuis plus de 10 ans, tant pour les ouvrages de fiction, essais, livres pratiques et rapports scientifiques.

Je réalise également les mandats en rédaction, notamment dans le domaine des arts et de la philanthropie.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADQW9YgBkYFeMHpsPjhzRf1j2CoBxNpBkZ0/
**Connexions partagées** : 5


---

# Marie Lamarre

## Position actuelle

**Entreprise** : Pavillons

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Marie Lamarre
*Pavillons*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 17 |

---

## 📚 Articles & Blog Posts

### [lamarre photos on Flickr](https://www.flickr.com/photos/tags/lamarre/)
*2025-05-14*
- Category: article

### [Annual report 2023](https://cdn.fondationjeunesentete.org/wp-content/uploads/2024/05/15133814/FJET_Rapport-annuel_2023_EN.pdf)
*2024-05-15*
- Category: article

### [Falling in love with a vision of how you want the world to be: From day 1 to Series A | Mariel Reed, CEO of Pavilion](https://www.forumvc.com/blog-posts/falling-in-love-with-a-vision-of-how-you-want-the-world-to-be-from-day-1-to-series-a-mariel-reed-ceo-of-pavilion)
*2023-03-01*
- Category: blog

### [Jodoin Pratte Lamarre | Architectuul](https://architectuul.com/architect/jodoin-pratte-lamarre)
*2019-10-11*
- Category: article

### [Screens and Illusionism - Oxford Academic - Oxford University Press](https://academic.oup.com/edinburgh-scholarship-online/book/61189/book-pdf/64297461/upso-9781399536530.pdf)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Marie Lamarre explore la place du numérique dans l'édition avec ...](https://lienmultimedia.com/spip.php?article91570)**
  - Source: lienmultimedia.com
  - *Dec 2, 2022 ... Marie Lamarre explore la place du numérique dans l'édition avec Pavillons ... PODCAST : Les fondateurs de Phoenix Impact parlent de le...*

- **[La plateforme numérique Pavillons s'unit à Mères au front | Le Devoir](https://www.ledevoir.com/lire/812660/collectif-plateforme-numerique-pavillons-unit-meres-front)**
  - Source: ledevoir.com
  - *May 11, 2024 ... ... Marie Lamarre. L'idée a d'abord germé dans une salle de classe, lorsque Marie Lamarre, qui, en plus d'être fondatrice et éditrice...*

- **[«L'entrevue éclair avec...» Olivier Bertrand, directeur général et ...](https://labibleurbaine.com/sorties/lentrevue-eclair-avec-olivier-bertrand-directeur-general-et-artistique-de-la-chapelle-scenes-contemporaines/)**
  - Source: labibleurbaine.com
  - *Sep 7, 2022 ... Plateforme-numerique-Pavillons-cofondatrices-Bible-urbaine ... Général · «Dans la peau de…» Annabelle Moreau, Marie Lamarre et Myriam ...*

- **[Les libraires - Numéro 132 by leslibraires - Issuu](https://issuu.com/leslibraires/docs/les-libraires-132)**
  - Source: issuu.com
  - *Aug 26, 2022 ... ... Pavillons, Myriam Comtois, Marie Lamarre et Annabelle Moreau. 1 POUR ... interview filmée, alors qu'il est au seuil de la mort. C...*

- **[SLO des PROS - Salon du livre de l'Outaouais](https://slo.qc.ca/le-salon-du-livre/slo-des-pros/)**
  - Source: slo.qc.ca
  - *Marie Lamarre de Pavillons, Julien Morissette de Transistor et Sean Michaels ... Conférence d'Angèle Delaunois. On les appelle aussi les « livres coup...*

- **[Le Salon annonce la programmation du SLM PRO! - Salon du livre ...](https://www.salondulivredemontreal.com/actualites/le-salon-annonce-la-programmation-du-slm-pro)**
  - Source: salondulivredemontreal.com
  - *Nov 6, 2024 ... Avec Hélène Hotton (directrice générale de la SODEP), Marie Lamarre (éditrice indépendante et fondatrice de Pavillons), Margot Mellet ...*

- **[Bertrand Gervais - Qui fait Quoi / Lien MULTIMÉDIA](https://lienmultimedia.com/?mot8793&debut_block_mots=2625)**
  - Source: lienmultimedia.com
  - *... Marie Lamarre (Pavillons) rencontrés à la Piscine lors d'une conférence sur le livre numérique, Corinne Lalonde (SAQ), Jean Bélanger (Premier Tech...*

- **[Opuscules](https://opuscules.uqam.ca/mediatheque?themes=cinema%2Cdanse%2Cconte%2Cedition-et-secteur-du-livre%2Carchitecture-et-urbanisme%2Cperformance)**
  - Source: opuscules.uqam.ca
  - *Midi-conférence LQM – Pavillons: l'éclatement du modèle permet-il de monétiser la littérature de façon inspirante? Annabelle Moreau, Marie Lamarre · V...*

- **[gouvernement du Québec comptes publics détail des dépenses](https://www.statefunding.ca/wp-content/uploads/Archive/Quebec/1979_Quebec_PA.pdf)**
  - Source: statefunding.ca
  - *... Pavillons Jeunesse (Joliette) Inc. Maison de la providence. Pension St-Joseph ... Marie Lamarre, 24 277; Caza Lamothe & associés, 20 543; Lanîhier...*

- **[Progrès-dimanche, dimanche 6 novembre 1966 | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/4399160)**
  - Source: numerique.banq.qc.ca
  - *... pavillons A DOMICILE AE err anh dont la constiuction extérieure est terminée ... Marie Lamarre 154 Province de Quebec.Chicoutimi.Ths, District de ...*

---

*Generated by Founder Scraper*
