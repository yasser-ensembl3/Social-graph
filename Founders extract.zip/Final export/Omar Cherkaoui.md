# Omar Cherkaoui

## Position actuelle

**Titre** : Founder
**Entreprise** : NoviFlow Inc.
**Durée dans le rôle** : 13 years 9 months in role
**Durée dans l'entreprise** : 13 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Networking

## Résumé

Networking professional and infrastructure technology leader with more than 35 years of experience in the networking industry, serving in various roles in more than 20 organizations. I have more than a hundred mandates in the network field to my credit, both in terms of network design and design, network management, development and design of equipment and cloud architectures and tools. cloud management. I have been a member of more than a dozen network engineering groups whose objectives were to ensure the continuous evolution of services, design and delivery of network solutions and virtualization services in the cloud.

Creation of several startups in this field such as Virtuor, Noviflow (www.noviflow.com).
Realization of multiple conJe Je sulting mandates in project management and technological evolution with various clients: Netronome, Broadcom, EZchip, Mellanox, Cisco, Ericsson, Bell Labs, Bell Canada, Canarie, Telus, Nortel Networks, Hydro-Québec, etc.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADidz0BkCSEZ6ReIEJ6gmkozF2B4UkBsJ0/
**Connexions partagées** : 10


---

# Omar Cherkaoui

## Position actuelle

**Entreprise** : UQAM | Université du Québec à Montréal

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Omar Cherkaoui

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397288908092485632 | Article |  |  |  | 1 | 0 | 0 | 2w | Post | Omar Cherkaoui | https://www.linkedin.com/in/cherkaou | https://linkedin.com/in/cherkaou | 2025-12-08T07:09:20.889Z |  | 2025-11-20T15:05:10.671Z | https://www.ludwigcancerresearch.org/ |  | 

---



---

# Omar Cherkaoui
*UQAM | Université du Québec à Montréal*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Books by Omar Cherkaoui (Author of Pratique de la gestion de réseau)](https://www.goodreads.com/author/list/3071390.Omar_Cherkaoui)
*2025-01-01*
- Category: article

### [Global Health, Public Health, and Making a Difference in the World with Dr. Omar Cherkaoui - AMBOSS: Beyond the Textbook](https://www.buzzsprout.com/1958671/episodes/12232261-global-health-public-health-and-making-a-difference-in-the-world-with-dr-omar-cherkaoui)
*2023-02-20*
- Category: article

### [Numérique or Digital in Morocco: Change – Continuity](https://chroniquecherkaoui.wordpress.com/2024/11/06/numerique-digital-morocco/)
*2024-11-06*
- Category: article

### [Omar Cherkaoui, Universite du Quebec a Montreal Rate Professors](https://www.professors.directory/rate/omar-cherkaoui_universite-du-quebec-a-montreal)
*2018-01-21*
- Category: article

### [dblp: Soumaya Cherkaoui](https://dblp.org/pid/57/689.html)
*2025-05-13*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[La rhétorique de l'image de guerre dans le magazine Life de 1936 à ...](https://archipel.uqam.ca/4357/1/D2226.pdf)**
  - Source: archipel.uqam.ca
  - *l'Université du Québec à Montréal une licence non exclusive d'utilisation et de ... Omar Cherkaoui du Laboratoire de recherche en téléinformatique de ...*

- **[ANNEXE B - Liste des activités de veille, de liaison et de transfert](https://cirano.qc.ca/files/rapports/2002-2003_annexe_b.pdf)**
  - Source: cirano.qc.ca
  - *May 2, 2003 ... ... Omar Cherkaoui,. Université du Québec à Montréal. • A Criteria Catalog ... Interview, CBC Newsworld, septembre 2002. Christofferse...*

- **[Evolution des réseaux télécoms – LTE Magazine](https://ptt.ma/evolution-des-reseaux-telecoms/)**
  - Source: ptt.ma
  - *... Université du Québec à Montréal (UQAM), Omar Cherkaoui, l'un des grands ... Interview with Mr. Vincent Rijmen, co-author of the Advanced Encryptio...*

- **[‪Omar Cherkaoui‬ - ‪Google Scholar‬](https://scholar.google.com/citations?user=Hk5bx_YAAAAJ&hl=en)**
  - Source: scholar.google.com
  - *Robert GodinUniversité du Québec à MontréalVerified email at uqam.ca ... Omar Cherkaoui. University of Quebec in Montreal ( Université du ......*

- **[A Declarative Approach to Network Device Configuration ...](https://dl.acm.org/doi/abs/10.1007/s10922-016-9387-7)**
  - Source: dl.acm.org
  - *Laboratoire de téléinformatique et réseaux, Université du Québec à Montréal, Montreal, Canada. View Profile. ,. Omar Cherkaoui profile image Omar Cher...*

- **[Specifying and Validating Data-Aware Temporal Web Service ...](https://dl.acm.org/doi/abs/10.1109/TSE.2009.29)**
  - Source: dl.acm.org
  - *Sep 1, 2009 ... Roger Villemaire. Université du Québec à Montréal, Montréal. Université du Québec à Montréal, Montréal. View Profile. ,. Omar Cherkaou...*

- **[Enhancing Federated Learning for Financial Sector via Graph ...](https://theses.hal.science/tel-05106721/file/TH2024DAMOUNFAROUK.pdf)**
  - Source: theses.hal.science
  - *Jun 11, 2025 ... Omar Cherkaoui Professeur. Rapporteur. Professeur. Université du Luxembourg. Université du Québec à Montréal ... Conference on Web In...*

- **[SECURE ARCHITECTURES FOR MOBILE FINANCIAL ...](https://orbilu.uni.lu/bitstream/10993/60605/1/Thesis_FKCO_final.pdf)**
  - Source: orbilu.uni.lu
  - *Dr Omar CHERKAOUI. Professor, Université du Québec à Montréal. Dr Raphael ... in chapter 5, in press from a conference, indicating potential attacker ...*

- **[IMPROVING SCALABILITY AND OPTIMIZING MESSAGE ...](https://orbilu.uni.lu/bitstream/10993/62193/1/Scheidt_de_Cristo_Thesis_Messae_Dissemination_XRPL.pdf)**
  - Source: orbilu.uni.lu
  - *Feb 12, 2024 ... Omar Cherkaoui. Associate Professor, Université du Québec à Montréal ... Conference), ser. LIPIcs, vol. 184,. Schloss Dagstuhl - Leib...*

- **[Untitled](https://ndl.ethernet.edu.et/bitstream/123456789/21334/1/253.pdf)**
  - Source: ndl.ethernet.edu.et
  - *Omar Cherkaoui University of Quebec at Montreal, Canada. Alexander Clemm ... Rudy Deca Université du Québec à Montréal, Canada. Kieran Delaney Cork .....*

---

*Generated by Founder Scraper*
