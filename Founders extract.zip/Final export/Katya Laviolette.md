# Katya Laviolette

## Position actuelle

**Titre** : Advisory Board Member
**Entreprise** : Airvet
**Durée dans le rôle** : 2 years 5 months in role
**Durée dans l'entreprise** : 2 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Veterinary Services

## Description du rôle

Airvet is the top-rated pet telehealth platform in the United States. A B2C and B2B offering connecting pet owners with licensed veterinarians.

## Résumé

Katya Laviolette is a fully bilingual (English & French) business-oriented people leader with over 25+ years’ experience in talent, culture change, global rewards, organizational effectiveness, real estate operations, health and safety, and M&A. 

Katya currently holds the position of Chief People Officer with 1Password, the leader in human-centric security and privacy. Prior to that, she held executive and senior level positions at SSENSE, TC Transcontinental, CBC|Radio-Canada, Rio Tinto, Bombardier and CN. Katya is also a Board Director. 

Katya is recognized for her ability to both operate and drive change within various governance structures. She has the innate ability to work within complex structures, with multiple stakeholders, including investors, founders, families and entrepreneurs.

Katya has received a number of awards, including the E.S. Sunley Scholarship in Industrial Relations, the Queen's Graduate Fellowship, the Cameron-Wood Prize in Industrial Relations, and the Queen's University Press Prize. She co-chaired the Governor General's Canadian Leadership Conference, as one of the youngest co-chairs. 

Katya is a member of the Ordre des conseillers en ressources humaines agréés (ORHRI) and a certified coach with Integral Coaching Canada. 

Katya is actively involved in her community. She currently serves on the Human Resources Committee for the McGill Board of Governors and served many years on the Board of Pour 3 Points, as well as continuing to mentor women leaders for Gouvernance au Féminin and Monday Girl.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAV1IgwBrPKGVtIRK5me6tiTKpBO1l_K7Cg/
**Connexions partagées** : 40


---

# Katya Laviolette

## Position actuelle

**Entreprise** : 1Password

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Katya Laviolette

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401675778490261504 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQEXolzhGyBitg/image-shrink_800/B56ZrfwcevK4Ao-/0/1764690611180?e=1765774800&v=beta&t=S7VGgpFWzWgfW1a3AcuBgj3sHuJkZRAZrTDiQPEuMyg | 1Password has been named one of Fast Company's 2025 Brands That Matter. 

At its core, this recognition is about people - how a brand shows up, how it makes them feel, and how it earns their trust. I’m proud of the way our teams design security around the realities of modern life, empowering people to do their best without complexity or compromise.

Congratulations to our entire 1Password team. K. 👏 | 35 | 1 | 0 | 5d | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:22.603Z |  | 2025-12-02T17:37:02.078Z | https://www.linkedin.com/feed/update/urn:li:activity:7401648896382566401/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396306955717410816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHsBHjG23WTTg/feedshare-shrink_800/B4EZqT1.EtHgAg-/0/1763416993512?e=1766620800&v=beta&t=RxOJmB6L2mX3SPVz96tT2mYunOGYHT2WAm3ok3fwYPw | Very excited to be returning to Transform 2026 - my third year joining this incredible community of leaders who are reimagining how we work, lead, and grow together. This year's theme is "The Human + AI Equation: Forging the Next Era of Work."

Every year, Transform brings together people who care deeply about shaping the future of work and inspiring real conversations that drive lasting impact through people. 

If you’re passionate about the evolving world of work and how we can make it better for everyone, I hope to see you there.

🎟️ Save $200 with this link: https://lnkd.in/ezuR9t_s 

#Transform2026 #FutureOfWork #HRLeadership #AILeadership | 179 | 2 | 0 | 2w | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:22.604Z |  | 2025-11-17T22:03:14.981Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394421085816922112 | Article |  |  | What does a cybersecurity strategy have to do with building high-performance cultures? More than you might think.

At 1Password, I’ve seen firsthand how the principles behind Zero Trust security also apply to how we build and lead resilient teams. Zero Trust isn’t just about safeguarding systems; it’s about creating the conditions for trust, accountability, and agility to succeed.

I expand on this in my latest article for Forbes, sharing four lessons from Zero Trust that I believe every people leader can apply:

1️⃣ Never assume — always listen and align
2️⃣ Make feedback continuous
3️⃣ Lead with transparency
4️⃣ Treat adaptation as the default setting

As our workplaces continue to evolve faster than ever, the connection between security and culture has never been clearer. After all, both rely on the same essential ingredient: people.

https://lnkd.in/eiKcbRhB 

#Leadership #HighPerformance #ScalingCulture #ZeroTrust #HRLeadership | 37 | 4 | 0 | 3w | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:22.605Z |  | 2025-11-12T17:09:28.559Z | https://www.forbes.com/councils/forbeshumanresourcescouncil/2025/11/12/the-parallels-between-zero-trust-security-and-high-performance-culture/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7392225733244243968 | Document |  |  | Behind every milestone is an extraordinary team. I’m proud of the people 1Password who bring their talent, creativity, and heart to everything we do. Our growth reflects more than numbers. It’s a reflection of our culture and our shared commitment to building the trust layer for human and AI identities. Also a big welcome to our new colleagues John Torrey and Michael Hughes. Looking forward to working with you both. K. 🚀 | 45 | 3 | 2 | 1mo | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:22.606Z |  | 2025-11-06T15:45:55.718Z | https://www.linkedin.com/feed/update/urn:li:activity:7392206951708811266/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7389751679757340674 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGu4QAA_tM_yQ/feedshare-shrink_800/B56Zo2b.A8JoAg-/0/1761849893863?e=1766620800&v=beta&t=fHGAWVeKT9dfOLU8mxJCqx4k2Qh6imMRqsd17ShL7f0 | For the third year in a row, I’m proud to share that 1Password has been named to the #Cyber60 list. AI agents, endless SaaS tools, and growing workplace complexity are reshaping how work gets done. To keep teams productive, security needs to feel effortless. It takes incredible people to build solutions that meet this moment. I’m proud of how our team continues to push the boundaries of what the future of identity security can be. 🚀 K. | 48 | 3 | 0 | 1mo | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:22.607Z |  | 2025-10-30T19:54:55.401Z | https://www.linkedin.com/feed/update/urn:li:activity:7389737876537696256/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379152793728733184 | Video (LinkedIn Source) | blob:https://www.linkedin.com/726d7284-eecf-44d7-8e0d-2b04ab3fdc58 | https://media.licdn.com/dms/image/v2/D4E05AQGKXVhtFKoZ8A/videocover-high/B4EZmgEGAuKoCA-/0/1759327115055?e=1765774800&v=beta&t=smfBrkZiucpm_XEC-BcWoEoGZ3p6vnl-BBAOoxOJEMM | High-performance cultures aren’t for everyone, and that’s the point. At 1Password, we’ve learned that scaling from B2C to enterprise B2B demands more than just adding new roles. It requires evolving the very core competencies of the team, and being brutally honest about what it really takes to succeed here.

On the Talk Talent to Me podcast with Rob Stevenson, I shared what this really looks like in practice:

 🔹 Why moving upmarket changes the core competencies we look for, not just the roles we hire.
 🔹 How being direct at every stage of the employee lifecycle—from job descriptions to interviews to regular 1:1s—helps us attract the right candidates and drive stronger retention.
 🔹 How to design interview loops that test candidates for ambiguity tolerance, curiosity, and specificity.
 🔹 Why I liken scaling a company to a long train ride: some people come along on the entire journey and others join for a chapter and disembark at a later station, but both are vital in a high-growth environment.

🔗 Find the episode linked in the comments section.

I’d love to hear your take: What do you think it really takes to thrive in a high-performance culture?

#TalkTalentToMe #FutureOfWork #HighPerformance #ScalingCulture | 96 | 3 | 4 | 2mo | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:24.646Z |  | 2025-10-01T13:58:44.054Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7353087475428315138 | Article |  |  | Mentorship has long been a cornerstone of professional growth. But in today’s multigenerational, fast-moving workplaces, we need a new approach: mutual mentorship—a model that breaks down hierarchy and creates space for growth on both sides.

When I joined 1Password in 2022, I found myself in a position whereby I was one of the oldest people at my level. I immediately sought out someone who’d held my role before—15 years my junior and deeply immersed in the company’s culture and pace. They were just as eager to sharpen their leadership skills as I was to learn how things worked in a scaling tech environment. That relationship has become one of my most trusted sources of insight.

In my latest article for Forbes, I share three ways to make mutual mentorship work:

1️⃣ Start with trust: Growth only happens when both people feel safe enough to be vulnerable and honest.

2️⃣ Establish expectations: Be clear about goals, cadence, communication styles, and how you’ll measure success.

3️⃣ Bring actionable challenges to the table: The more concrete your focus, the more meaningful the impact.

Mutual mentorship isn't just a nice-to-have; it's a powerful tool for navigating complexity, building inclusive teams, and accelerating professional development at every level.

Enjoy! K.  🩵 

https://lnkd.in/gSANuwBM | 72 | 5 | 1 | 4mo | Post | Katya Laviolette | https://www.linkedin.com/in/katya-laviolette-6907b726 | https://linkedin.com/in/katya-laviolette-6907b726 | 2025-12-08T04:45:24.647Z |  | 2025-07-21T15:44:27.901Z | https://www.forbes.com/councils/forbeshumanresourcescouncil/2025/07/17/mutual-mentorship-is-the-future-of-professional-development/ |  | 

---



---

# Katya Laviolette
*1Password*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Q&A with 1Password’s Katya Laviolette](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/)
*2025-05-02*
- Category: article

### [Meet the Team | Katya | 1Password](https://1password.com/company/meet-the-team/katya-laviolette)
*2024-01-01*
- Category: article

### [Leadership perspectives: 1Password’s chief people officer on navigating a startup environment | Insights | Heidrick & Struggles](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment)
*2025-01-01*
- Category: article

### [Katya Laviolette - Forbes Human Resources Council](https://www.forbes.com/councils/katyalaviolette/)
*2024-12-16*
- Category: article

### [Listen to foHRsight podcast](https://www.deezer.com/en/show/5508797)
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 13,316 words total*

### Q&A with 1Password’s Katya Laviolette
*1,921 words* | Source: **EXA** | [Link](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/)

Q&A with 1Password's Katya Laviolette | Benefits Canada.com

===============

*   [AVANTAGES](https://www.avantages.ca/)
*   [Canadian Investment Review](https://www.benefitscanada.com/canadian-investment-review/)
*   [CIIN](http://www.ciin.ca/)
*   [EVENTS](https://www.benefitscanada.com/microsite/conferences/)
*   [Webinars](https://www.benefitscanada.com/microsite/webinars/)
*   [AWARDS](https://www.benefitscanada.com/microsite/benefits-canada/awards/)

Toggle navigation

[![Image 2: Benefits Canada.com](https://www.benefitscanada.com/wp-content/uploads/sites/7/2023/07/Benefits_logo-1.png)](https://www.benefitscanada.com/)

Search

*   [Newsletter](https://tc.benefitscanada.com/T/WF/5912/Rp6Ird/Optin/en-US/Form.ofsys "Newsletter")
*   [Magazine](https://benefitscanada.secure.darwin.cx/Z5YBEN2B "Magazine")
*   [My account](https://www.benefitscanada.com/my-account/ "My account")

Q&A with 1Password’s Katya Laviolette

 Share [Facebook](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/)[LinkedIn](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/)[Twitter](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/)[Mail to a fried](mailto:?subject=I%20found%20this%20interesting%20for%20you!&body=Hello,%0A%20%0A%20I%20invite%20you%20to%20consult:%20%0A%0AQ&A%20with%201Password%E2%80%99s%20Katya%20Laviolette%0A%20https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/%20%0A%0A%20on%20the%20site%20Benefits%20Canada.com.%20%0A%0AHave%20a%20good%20day! "Share by Email")[Print](javascript:window.print())

*   [News](https://www.benefitscanada.com/news/ "News")
*   [Benefits](https://www.benefitscanada.com/benefits/ "Benefits")[](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/#)
    *   [Absence management](https://www.benefitscanada.com/benefits/absence-management/ "Absence management")
    *   [Communication](https://www.benefitscanada.com/benefits/benefits-communication/ "Communication")
    *   [Disability management](https://www.benefitscanada.com/benefits/disability-management/ "Disability management")
    *   [Health benefits](https://www.benefitscanada.com/benefits/health-benefits/ "Health benefits")
    *   [Health/wellness](https://www.benefitscanada.com/benefits/health-wellness/ "Health/wellness")
    *   [Legal issues](https://www.benefitscanada.com/benefits/benefits-law/ "Legal issues")
    *   [Other](https://www.benefitscanada.com/benefits/benefits-other/ "Other")

*   [Pensions](https://www.benefitscanada.com/pensions/ "Pensions")[](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/#)
    *   [Capital accumulation plans](https://www.benefitscanada.com/pensions/cap/ "Capital accumulation plans")
    *   [Governance/legislation](https://www.benefitscanada.com/pensions/governance-law/ "Governance/legislation")
    *   [Retirement](https://www.benefitscanada.com/pensions/retirement/ "Retirement")
    *   [Communication](https://www.benefitscanada.com/pensions/pension-communication/ "Communication")
    *   [Other](https://www.benefitscanada.com/pensions/pension-other/ "Other")

*   [Investments](https://www.benefitscanada.com/canadian-investment-review/ "Investments")[](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/#)
    *   [News](https://www.benefitscanada.com/canadian-investment-review/cir-news/ "News")
    *   [Partner Content](https://www.benefitscanada.com/canadian-investment-review/canadian-investment-review-partner-content/ "Partner Content")
    *   [Expert Panel](https://www.benefitscanada.com/canadian-investment-review/canadian-investment-review-expert/ "Expert Panel")
    *   [DB](https://www.benefitscanada.com/canadian-investment-review/db-investments/ "DB")
    *   [DC](https://www.benefitscanada.com/canadian-investment-review/dc-investments/ "DC")
    *   [Public Equities](https://www.benefitscanada.com/canadian-investment-review/public-equities/ "Public Equities")
    *   [Fixed income](https://www.benefitscanada.com/canadian-investment-review/fixed-income/ "Fixed income")
    *   [Alternative investments](https://www.benefitscanada.com/canadian-investment-review/alts/ "Alternative investments")
    *   [Investment Strategies](https://www.benefitscanada.com/canadian-investment-review/strategies/ "Investment Strategies")
    *   [Research & Markets](https://www.benefitscanada.com/canadian-investment-review/research-markets/ "Research & Markets")
    *   [Other](https://www.benefitscanada.com/canadian-investment-review/investments-other/ "Other")

*   [HR](https://www.benefitscanada.com/human-resources/ "HR")[](https://www.benefitscanada.com/archives_/benefits-canada-archive/qa-with-1passwords-katya-laviolette/#)
    *   [Communication](http

*[... truncated, 30,230 more characters]*

---

### Katya Laviolette - Meet the Team | 1Password
*514 words* | Source: **EXA** | [Link](https://1password.com/company/meet-the-team/katya-laviolette)

Katya Laviolette - Meet the Team | 1Password

===============
[Skip to Main Content](https://1password.com/company/meet-the-team/katya-laviolette#main)

[![Image 2: 1Password](https://1password.com/logo-images/1password-logo-dark@2x.png)](https://1password.com/)

![Image 3: Katya Laviolette](https://images.ctfassets.net/2h488pz7kgfv/47Y7da0TfpNKJbp1i0iAeA/12af7f7f8a5209cb2917353829b308c0/company-katya-laviolette-photo-706x706.webp)
Katya Laviolette
================

Chief People Officer
--------------------

Katya Laviolette is the Chief People Officer at 1Password, where she’s grown the fully remote workforce to over 1,400 employees across five countries and hit a record 93% offer-to-acceptance rate.

Katya believes that HR programs must be strategically aligned with business priorities and does so with a global mindset. She’s passionate about creating a positive work culture and has been recognized for her ability to influence and drive business innovation through both talent and organizational development.

Before joining 1Password, Katya held executive positions at SSENSE, TC Transcontinental, CBC/Radio-Canada, Rio Tinto, Bombardier Aerospace, and Canadian National Railway. She’s also a Board Director with Sanimax and Solotech, two global organizations.

Katya is also a member of the Ordre des conseillers en ressources humaines agrees (ORHRI), as well as a certified coach with Integral Coaching Canada. Katya is actively involved in her community, having served many years on the Board of Pour 3 Points (P3P), as well as mentoring women leaders within the Governance au Féminin organization and Monday Girl.

1.   [](https://1password.com/)
2.   [Company](https://1password.com/company)
3.   [Meet the team](https://1password.com/company#meet-the-team)
4.   [Katya Laviolette](https://1password.com/company/meet-the-team/katya-laviolette)

English

Deutsch

Español

Français

Italiano

日本語

한국어

Português

简体中文

繁體中文

English

Show options

###### Downloads

*   [macOS](https://1password.com/downloads/mac) 
*   [Windows](https://1password.com/downloads/windows) 
*   [iOS](https://1password.com/downloads/ios) 
*   [Android](https://1password.com/downloads/android) 
*   [Browser](https://1password.com/downloads/browser-extension) 
*   [Linux](https://1password.com/downloads/linux) 
*   [CLI](https://1password.com/downloads/command-line) 

###### 1Password products

*   [Extended Access Management](https://1password.com/extended-access-management) 
*   [Enterprise Password Manager](https://1password.com/product/enterprise-password-manager) 
*   [Device Trust](https://1password.com/product/device-trust) 
*   [Trelica by 1Password](https://1password.com/product/access-governance) 
*   [Personal Password Manager](https://1password.com/product/password-manager) 
*   [MSP Edition](https://1password.com/product/enterprise-password-manager-msp-edition) 
*   [Passage](https://1password.com/product/passage) 
*   [Password generator](https://1password.com/password-generator) 
*   [Username generator](https://1password.com/username-generator) 
*   [Comparison](https://1password.com/compare/password-manager) 
*   [Demos](https://1password.com/demos) 
*   [Switch](https://1password.com/switch) 
*   [Pricing](https://1password.com/pricing/xam) 

###### Features

*   [Autofill](https://1password.com/features/autofill) 
*   [Access reviews](https://1password.com/features/access-reviews) 
*   [Access requests](https://1password.com/features/access-requests) 
*   [Posture checks](https://1password.com/features/security-posture-check) 
*   [Extended Device Compliance](https://1password.com/features/extended-device-compliance) 
*   [Trelica integrations](https://1password.com/features/trelica-integrations) 
*   [SaaS discovery](https://1password.com/features/saas-discovery) 
*   [License management](https://1password.com/features/software-license-management) 
*   [Watchtower insights](https://1password.com/features/watchtower-identifies-security-risks) 
*   [Secrets Management](https://1password.com/features/secrets-management) 
*   [Password sharing](https://1password.com/features/secure-password-sharing) 
*   [Two-factor authentication](https://1password.com/features/two-factor-authentication) 
*   [Passkeys](https://1password.com/product/passkeys) 

###### Solutions

*   [Passwordless](https://1password.com/solutions/passwordless) 
*   [Device Security](https://1password.com/solutions/device-security) 
*   [Shadow IT Discovery](https://1password.com/solutions/shadow-it) 
*   [SaaS Access Governance](https://1password.com/solutions/saas-governance) 
*   [SaaS Spend Management](https://1password.com/solutions/saas-spend-management) 
*   [Compliance and Cyber Insurance](https://1password.com/solutions/cybersecurity-compliance) 
*   [Agentic AI Security](https://1password.com/solutions/agentic-ai) 

###### Resources

*   [Webinars](https://1password.com/webinars) 
*   [Customer stories](https://1password.com/customer-stories) 
*   [Res

*[... truncated, 3,935 more characters]*

---

### Leadership perspectives: 1Password’s chief people officer on navigating a startup environment | Insights | Heidrick & Struggles
*1,646 words* | Source: **EXA** | [Link](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment)

Leadership perspectives: 1Password’s chief people officer on navigating a startup environment | Insights | Heidrick & Struggles

===============

Identified Country: 

 Skip to [content](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment#main) or [footer](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment#footer)

Pause Animations

[](https://www.heidrick.com/en)

[![Image 1: Heidrick & Struggles Homepage](https://www.heidrick.com/Project/HeidrickCom/assets/public/images/nav-logo.svg)](https://www.heidrick.com/)

*   [Profile Login](https://leaders.heidrick.com/login)
*   [Create Your Profile](https://leaders.heidrick.com/register)
*   [Global Site Selector](https://www.heidrick.com/en/global-site-selector)
*   [Contact](https://www.heidrick.com/en/contact-us)
*   [Heidrick Connect](https://connect.heidrick.com/signin)
*   
English
    *   English
    *   [日本語](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment#)

*   Services
*   Industry Expertise
*   [Insights](https://www.heidrick.com/en/insights)
*   About

Open Menu
*   [People](https://www.heidrick.com/en/people)
*   [Offices](https://www.heidrick.com/en/offices)
*   [Careers @ Heidrick](https://www.heidrick.com/en/careers)
*   [Investor Relations](https://investors.heidrick.com/)
*   [Newsroom](https://heidrick.mediaroom.com/)

[](https://www.heidrick.com/en/insights/videos/leadership-perspectives-1password-chief-people-officer-on-navigating-a-startup-environment)

Services
--------

[Executive Search](https://www.heidrick.com/en/services/executive-search)
*   [Chief Executive Officer & Board of Directors](https://www.heidrick.com/en/services/executive-search/ceo-board-of-directors)
*   [Digital Officers](https://www.heidrick.com/en/services/executive-search/digital-officers)
*   [Financial Officers](https://www.heidrick.com/en/services/executive-search/financial-officers)
*   [Human Resources Officers](https://www.heidrick.com/en/services/executive-search/human-resources-officers)
*   [Legal, Risk, Compliance & Government Affairs](https://www.heidrick.com/en/services/executive-search/legal-risk-compliance-government-affairs)
*   [Marketing, Sales & Strategy Officers](https://www.heidrick.com/en/services/executive-search/marketing-sales-strategy-officers)
*   [Supply Chain & Operations Officers](https://www.heidrick.com/en/services/executive-search/supply-chain-operations-officers)
*   [Technology Officers](https://www.heidrick.com/en/services/executive-search/technology-officers)

*   [View all Industry Expertise](https://www.heidrick.com/en/industries)

[Leadership](https://www.heidrick.com/en/services/leadership)
*   [Agile Leader Potential](https://www.heidrick.com/en/services/leadership/agile-leader-potential)
*   [Board Effectiveness](https://www.heidrick.com/en/services/leadership/board-effectiveness)
*   [CEO Succession Planning](https://www.heidrick.com/en/services/leadership/ceo-succession-planning)
*   [Chief Executive Acceleration](https://www.heidrick.com/en/services/leadership/chief-executive-acceleration)
*   [Coaching](https://www.heidrick.com/en/services/leadership/coaching)
*   [Digital Leadership](https://www.heidrick.com/en/services/leadership/digital-leadership)
*   [Leadership Assessment](https://www.heidrick.com/en/services/leadership/leadership-assessment)
*   [Leadership Development](https://www.heidrick.com/en/services/leadership/leadership-development)
*   [M&A Talent Planning](https://www.heidrick.com/en/services/leadership/mergers-acquisition-talent-planning)
*   [Team Acceleration](https://www.heidrick.com/en/services/leadership/team-acceleration)

[Corporate Transformation](https://www.heidrick.com/en/services/corporate-transformation)
*   [Carve-Outs](https://www.heidrick.com/en/services/corporate-transformation/carve-outs)
*   [Cost Advantage](https://www.heidrick.com/en/services/corporate-transformation/cost-advantage)
*   [Distress Response & Restructuring](https://www.heidrick.com/en/services/corporate-transformation/distress-response-restructuring)

[On-Demand Talent](https://www.heidrick.com/en/services/on-demand-talent)
*   [Interim Executives](https://www.heidrick.com/en/services/on-demand-talent/interim-executives)
*   [On-Demand Project Leaders, Consultants, and Experts](https://www.heidrick.com/en/services/on-demand-talent/project-leaders-consultants-experts)

[Organization & Culture](https://www.heidrick.com/en/services/organization-culture)
*   [Culture Shaping](https://www.heidrick.com/en/services/organization-culture/culture-shaping)
*   [Organization Acceleration](https://www.heidrick.com/en/services/organization-culture/organization-acceleration)
*   [Organizational Simplicity](https://www.heidrick.com/en/services/organization-culture/organizational-simp

*[... truncated, 19,759 more characters]*

---

### Katya Laviolette - Forbes Human Resources Council
*2,063 words* | Source: **EXA** | [Link](https://www.forbes.com/councils/katyalaviolette/)

Katya Laviolette - Forbes Human Resources Council

===============

[](https://www.forbes.com/)

[Newsletters](https://account.forbes.com/newsletters/)[Games](https://www.forbes.com/games)[Share a News Tip](https://www.forbes.com/sites/forbesstaff/article/tips-and-confidential-sources/)

[](https://www.forbes.com/search/?q=)

*   Featured 

Featured 

    *   [Breaking News](https://www.forbes.com/news/) 
    *   [White House Watch](https://www.forbes.com/trump/) 
    *   [Daily Cover Stories](https://www.forbes.com/daily-cover-stories/) 
    *   [Celebrating Top Fundraisers Uniting To End Blood Cancers| Paid Program](https://www.forbes.com/sites/bloodcancerunited/2025/12/01/celebrating-top-fundraisers-uniting-to-end-blood-cancers/) 
    *   [America's 2025 Top Wealth Management Teams Private Wealth List | Paid Program](https://www.forbes.com/lists/top-wealth-management-teams-private-wealth/) 
    *   [The Forbes CIO Next List: 2025| Paid Program](https://www.forbes.com/sites/richardnieva/2025/11/18/the-forbes-cio-next-list-2025/) 
    *   [America's 2025 Top Wealth Management Teams High Net Worth List](https://www.forbes.com/lists/top-wealth-management-teams-high-net-worth/) 
    *   [When Teens Fundraise To End Blood Cancer, They Change Lives, Including Their Own| Paid Program](https://www.forbes.com/sites/bloodcancerunited/2025/11/19/when-teens-fundraise-to-end-blood-cancer-they-change-lives-including-their-own/) 
    *   [The Employee Well-Being Imperative| Paid Program](https://www.forbes.com/sites/american-heart-association/2025/10/22/the-employee-well-being-imperative/) 
    *   [Best-In-State Top Next-Gen Wealth Advisors 2025](https://www.forbes.com/lists/best-in-state-next-gen-advisors/) 
    *   [AI’s Nuanced Impact And A Quest To Quantify It](https://www.forbes.com/sites/forbes-research/2023/10/26/c-suite-data-reveals-ais-nuanced-impact--a-quest-to-quantify-it/) 
    *   [DNA of Success](https://www.forbes.com/sites/forbesvideo/2023/11/01/dna-of-success-2023/) 
    *   [Embracing And Bracing For AI](https://www.forbes.com/sites/forbes-research/2023/10/26/new-forbes-survey-reveals-how-executives-are-embracing---and-bracing-for---ai/) 
    *   [Facing A Volatile Market, C-Suites Look To The CFO For Strategic Guidance](https://www.forbes.com/sites/forbes-research/2023/11/01/facing-a-volatile-market-c-suites-look-to-the-cfo-for-strategic-guidance/) 
    *   [Your Four-Part Blueprint To Unlock AI Value In 2025| Paid Program](https://www.forbes.com/sites/avanade/2025/02/05/your-four-part-blueprint-to-unlock-ai-value-in-2025/) 
    *   [By The Numbers: Meet The Forbes 30 Under 30 Europe Class Of 2025](https://www.forbes.com/30-under-30/2025/europe/) 
    *   [Next Billion-Dollar Startups 2025](https://www.forbes.com/sites/amyfeldman/2025/08/12/next-billion-dollar-startups-2025/) 
    *   [Four Reasons To Rethink Your Savings Strategy](https://www.forbes.com/sites/insights-synchrony-bank/2025/10/13/four-reasons-to-rethink-your-savings-strategy/) 
    *   [America's Most Powerful Women In Sports](https://www.forbes.com/sites/maggiemcgrath/2025/10/22/americas-most-powerful-women-in-sports-2025/) 
    *   [Navigating Retirement In Today’s Economic Landscape](https://www.forbes.com/video/b45397ed-a6eb-44dd-b00b-47e1ad5e2913/navigating-retirement-in-todays-economic-landscape/) 
    *   [Forbes Iconoclast: How Top Investors Find Opportunities In Times Of Uncertainty](https://www.forbes.com/sites/courtneyconnley-hampton/2025/11/21/how-top-investors-find-opportunities-in-times-of-uncertainty/) 
    *   [The Joy Of Checking Out](https://www.forbes.com/sites/forbesliveteam/2025/11/24/the-joy-of-checking-out/) 
    *   [The Performance Layer| Paid Program](https://www.forbes.com/sites/forbesvideo/2025/11/25/the-performance-layer/) 
    *   [Do You Know The True Cost Of Your Legacy Finance Tech? Take This Quiz To Find Out| Paid Program](https://www.forbes.com/sites/anaplan/2025/11/18/do-you-know-the-true-cost-of-your-legacy-finance-tech-take-this-quiz-to-find-out/) 
    *   [CXO Spotlight| Paid Program](https://www.forbes.com/sites/forbesvideo/2024/02/21/cxo-spotlight) 

More...

*   [Billionaires](https://www.forbes.com/worlds-billionaires/) 

Billionaires[See All](https://www.forbes.com/worlds-billionaires/)  

    *   [World's Billionaires](https://www.forbes.com/billionaires/) 
    *   [Forbes 400](https://www.forbes.com/forbes-400/) 
    *   [America's Richest Self-Made Women](https://www.forbes.com/self-made-women/) 
    *   [China's Richest](https://www.forbes.com/lists/china-billionaires/) 
    *   [India's Richest](https://www.forbes.com/lists/india-billionaires/) 
    *   [Indonesia's Richest](https://www.forbes.com/lists/indonesia-billionaires/) 
    *   [Korea's Richest](https://www.forbes.com/lists/korea-billionaires/) 
    *   [Thailand's Richest](https://www.forbes.com/lists/thailand-billionaires/) 
    *   [Japan's Richest](https://www.forbes.com/lists/japan-billionaires/) 
    *   [Australia's Riche

*[... truncated, 40,987 more characters]*

---

### foHRsight
*375 words* | Source: **EXA** | [Link](https://www.deezer.com/en/show/5508797)

[The Wisdom of Ignorance with Guest Alan Gregerman](https://www.deezer.com/en/episode/818543772)[foHRsight](https://www.deezer.com/en/show/5508797)39:49
[Celebrating 150 Episodes with Our Friends Anna Petosa & Greg Smith](https://www.deezer.com/en/episode/815967272)[foHRsight](https://www.deezer.com/en/show/5508797)38:55
[Why Feeling Ideas Works Better Than Hearing Them with Guest Andrea Guertin](https://www.deezer.com/en/episode/813343822)[foHRsight](https://www.deezer.com/en/show/5508797)36:56
[Play As a Tool For Learning and Culture Building with Guest Alex Suchman](https://www.deezer.com/en/episode/810559792)[foHRsight](https://www.deezer.com/en/show/5508797)33:33
[Collecting Workspaces with Guest Aamna Coskun](https://www.deezer.com/en/episode/808249812)[foHRsight](https://www.deezer.com/en/show/5508797)43:56
[Using AI to 10x Performance by Focusing On Humans with Guest Jodi Baker Calamai](https://www.deezer.com/en/episode/805632172)[foHRsight](https://www.deezer.com/en/show/5508797)33:46
[Leading Change with Guest Yvonne Ruke Akpoveta](https://www.deezer.com/en/episode/802874442)[foHRsight](https://www.deezer.com/en/show/5508797)36:15
[Collaboration and the Need for Collective Intelligence with Guest Nigel Scott](https://www.deezer.com/en/episode/800241812)[foHRsight](https://www.deezer.com/en/show/5508797)42:25
[Stress Mastery with Guest Dr. Safia Debar](https://www.deezer.com/en/episode/797941832)[foHRsight](https://www.deezer.com/en/show/5508797)41:30
[Are We the Clutter We're Trying to Cut Through? How We're Adapting to AI at future foHRward](https://www.deezer.com/en/episode/795382631)[foHRsight](https://www.deezer.com/en/show/5508797)20:55
[Does HR Still Need Humans?](https://www.deezer.com/en/episode/792940271)[foHRsight](https://www.deezer.com/en/show/5508797)26:51
[The AI Gender Gap with Guests Jeanne Meister and Leo Goncalves](https://www.deezer.com/en/episode/790535531)[foHRsight](https://www.deezer.com/en/show/5508797)41:51
[The Power of Simplicity with Guest Ben Clarke](https://www.deezer.com/en/episode/788217321)[foHRsight](https://www.deezer.com/en/show/5508797)35:34
[The Purpose of Purpose with Guest Ron Tite](https://www.deezer.com/en/episode/785789231)[foHRsight](https://www.deezer.com/en/show/5508797)39:20
[The Curiosity Advantage with Guest Kayla Campbell](https://www.deezer.com/en/episode/783578251)[foHRsight](https://www.deezer.com/en/show/5508797)37:15
[Loving to Human with Guest Ruth Penfold](https://www.deezer.com/en/episode/781282751)[foHRsight](https://www.deezer.com/en/show/5508797)43:11
[Flourishing at Work with Guest Julian Chapman](https://www.deezer.com/en/episode/779164741)[foHRsight](https://www.deezer.com/en/show/5508797)39:14
[How to Think Like a Marketer and Train Like an L&D Pro with Guest Bianca Baumann](https://www.deezer.com/en/episode/776970521)[foHRsight](https://www.deezer.com/en/show/5508797)38:27
[How the Aging Workforce Can Close the Wisdom Gap with Guest Steve Hatfield](https://www.deezer.com/en/episode/774525041)[foHRsight](https://www.deezer.com/en/show/5508797)43:49
[The Future of the HR Operating Model](https://www.deezer.com/en/episode/772176791)[foHRsight](https://www.deezer.com/en/show/5508797)33:20
[Onboarding as a Chief People Officer with Guest Margot Lackenbauer](https://www.deezer.com/en/episode/769611241)[foHRsight](https://www.deezer.com/en/show/5508797)35:06
[Balancing AI Transformation and Humanity](https://www.deezer.com/en/episode/767464421)[foHRsight](https://www.deezer.com/en/show/5508797)27:23
[Why HR is Made to Measure for AI with Guest Mark Jesty](https://www.deezer.com/en/episode/765408701)[foHRsight](https://www.deezer.com/en/show/5508797)38:23
[Being a Catalyst with Guests Shannon Lucas and Tracey Lovejoy](https://www.deezer.com/en/episode/763070331)[foHRsight](https://www.deezer.com/en/show/5508797)39:46
[AI as a Talent Acquisition Partner with Guest Ariana Moon](https://www.deezer.com/en/episode/760992511)[foHRsight](https://www.deezer.com/en/show/5508797)40:16
[The Power of Feedback with Guest Sharon Jones](https://www.deezer.com/en/episode/758801101)[foHRsight](https://www.deezer.com/en/show/5508797)43:40
[Flexible Leadership with Guest Kevin Eikenberry](https://www.deezer.com/en/episode/756582801)[foHRsight](https://www.deezer.com/en/show/5508797)39:29
[The Generous Leader with Guest Joe Davis](https://www.deezer.com/en/episode/754288161)[foHRsight](https://www.deezer.com/en/show/5508797)34:23
[How to Build a Culture People Don’t Want to Leave with Guest Katya Laviolette](https://www.deezer.com/en/episode/751890571)[foHRsight](https://www.deezer.com/en/show/5508797)33:44
[The Erosion of Trust with Guest Cydney Roach](https://www.deezer.com/en/episode/749467071)[foHRsight](https://www.deezer.com/en/show/5508797)31:27
[Post-traumatic Growth with Guest Carey-Ann Oestreicher](https://www.deezer.com/en/episode/747148341)[foHRsight](https://www.deezer.com/en/show/5508797)32:20
[A Strategic Approach to Internal Communications with

*[... truncated, 1,457 more characters]*

---

### Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap)
*526 words* | Source: **GOOGLE** | [Link](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap)

===============

Opens in a new window Opens an external website Opens an external website in a new window

This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. To learn more, view the following link: [Privacy Policy](https://workleap.com/trust-center/privacy/)

Manage Preferences 

[![Image 18](https://cdn.prod.website-files.com/66eab063c614790046e87eef/66f3c89500f8c53829f06098_Logotype.svg)](https://workleap.com/)

Products

[Officevibe ![Image 19](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c2f9de4d3cf62ef3d49931_Dropdown%20Menu%20Officevibe.avif) Engagement surveys and feedback Discover Officevibe ![Image 20](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c1d41a177442bb4a4c1142_feature-product-background.avif)](https://workleap.com/officevibe)[Performance ![Image 21](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c2f9de1fb868153773ef76_Dropdown%20Menu%20Performance.avif) Performance review management and tracking Discover Performance ![Image 22](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c1d41a177442bb4a4c1142_feature-product-background.avif)](https://workleap.com/performance)[Compensation ![Image 23](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c1d2f1da7b7a622ea8a3ca_Dropdown-menu_Compensation-2x.avif) Compensation and total rewards management Discover Compensation ![Image 24](https://cdn.prod.website-files.com/66eab063c614790046e87eef/68c1d41a177442bb4a4c1142_feature-product-background.avif)](https://workleap.com/compensation)

[Platform All Workleap products integrated in one platform](https://workleap.com/platform)[Workleap AI Transforming HR with AI](https://workleap.com/ai)[Integrations Connect Workleap to your HR technology](https://workleap.com/integrations)

Solutions

Industries

[Financial services Empowering secure and compliant financial workflows](https://workleap.com/industry/financial-services)[Technology Driving innovation and digital collaboration](https://workleap.com/industry/technology)[Professional services Enhancing productivity and client engagement](https://workleap.com/industry/professional-services)

Resources

##### Learning hub

[Resource Library](https://workleap.com/resources)[Survey generator](https://workleap.com/survey-generator)[Tools](https://workleap.com/resources-type/tool)[Courses](https://workleap.com/resources-type/course)[Ebooks](https://workleap.com/resources-type/ebook)[Template library](https://workleap.com/template-categories)[Webinars and events](https://workleap.com/resources-type/webinars-events)[Podcasts](https://workleap.com/resources-type/podcast)

##### More Workleap

[Blog](https://workleap.com/blog)[Success stories](https://workleap.com/success-stories)[Newsletter](https://workleap.com/newsletter)

##### Company

[About us](https://workleap.com/about)[Careers](https://workleap.com/careers)[Media](https://workleap.com/media)

[![Image 25](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/68e3dfd714bfef92d2117fa1_Redesgining%20Hybrid%20Work1.avif) Webinars & Events ###### Redefining flexible work with intention Watch now](https://workleap.com/resources/redefining-flexible-work-with-intention)

[Pricing](https://workleap.com/pricing)

[Log in](https://login.workleap.com/)[Get started free](https://workleap.com/get-started)[Request a demo](https://workleap.com/demo)

[Resources](https://workleap.com/resources)[Podcasts](https://workleap.com/resources-type/podcast)

Leading culture

Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap)
====================================================================================================

How do you scale fast without losing what makes your culture special? In this episode, Workleap’s CPO Kahina Ouerdane sits down with Katya Laviolette, CPO at 1Password, to talk about growing a global, remote team—while staying true to your values. They dive into codifying culture, onboarding with intention, and why clarity and candor are must-haves in a high-growth world.A must-listen for anyone building culture at scale.

[](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap#)[](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap#)[](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap#)

![Image 26](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/6865d053051d4044c25fa6a1_Workleap_Intro-Katya_v01.avif)

Subscribe to the podcast
------------------------

From uncomfortable truths to heart-to-heart conversations, the Culture First Podcast uncovers what it really takes to build a better world of work.

[Youtube](https://www.youtube.com/@workleap)[Spoti

*[... truncated, 7,314 more characters]*

---

### Purpose, performance, and trust: Inside the culture powering 1Password’s next chapter
*1,913 words* | Source: **GOOGLE** | [Link](https://1password.com/blog/inside-the-culture-powering-1passwords-next-chapter)

In today’s complex digital world, trust is everything. And trust starts with people. That’s why at 1Password, we’ve built a culture rooted in shared purpose, clarity, and accountability. Our culture begins with a commitment to something bigger than ourselves: the success of our customers. We believe in the power of _we:_ a mindset that puts customers first, prioritizes the team over the individual, and anchors everything we do in our mission: building a safer, simpler digital future for everyone.

As our company grows, so do our ambitions. That’s why we’re committed to a high-performance culture that enables us to move with speed, alignment, and integrity, while staying true to our belief that great outcomes are only possible when we grow and work together. We believe in setting a high bar because the work we do matters. The stakes are high to ensure we protect our customers, and that bar is constantly being raised as we scale.

A culture anchored in purpose
-----------------------------

1Password isn’t just adapting to a fast-changing digital world – we’re helping shape it. But meaningful innovation doesn’t happen in isolation. It happens when teams come together with a clear mission and a commitment to delivering what matters most to our customers.

As our CEO, David Faugno, puts it:

> _“Curiosity, adaptability, and a winning mindset are essential to our evolving culture._**_\_We are moving toward high-performance by focusing on clear goals, open communication, shared accountability, and pushing for excellence as a team.\__**_High-performance is not about speed for its own sake. It is about moving forward together, with focus and alignment.”_

High-performance at 1Password is not just a goal—it’s a way of working that ensures we can protect our customers’ digital lives while fostering an environment where people are empowered to learn, grow, and innovate.

What is a high-performance culture?
-----------------------------------

At its core, a high-performance culture is about creating an environment where shared purpose, clarity, and accountability are embedded in daily work.

Alignment across teams and individual accountability empower people to own their contributions, ask for help, give feedback, and learn from mistakes. These qualities ensure we keep learning, remain open to new ideas, and push ourselves to do better.

### Growth in experience

During a [recent Workleap podcast](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap), I described our approach to scaling a high-performance culture in remote and distributed teams.

I often say our journey at 1Password is like riding a long train. Some people stay for the entire ride and grow alongside us. Others join for part of the journey and move on when it is time. We move quickly, and not everyone will follow the same path or pace. What matters is that we are open with each other and support one another through each stage of growth and change.

Benefits of a high-performance culture
--------------------------------------

A high-performance culture at 1Password accelerates value for the customers we serve. This means a faster pace of innovation. Our teams are equipped to deliver secure, reliable, and forward-thinking security products built for how people and AI agents work today. By working with greater focus and urgency, we can bring solutions to market faster than ever.

For employees, high-performance provides a clear sense of shared purpose. When people see how their work connects to our mission, they are motivated to learn, grow, and tackle new challenges. This focus on high performance is also what drives 1Password’s market leadership.

[McKinsey found](https://www.mckinsey.com/capabilities/people-and-organizational-performance/our-insights/in-the-spotlight-performance-management-that-puts-people-first) that organizations with people-first performance management are over four times more likely to outperform their peers, with 30% higher revenue growth and lower attrition. When people are empowered to do their best work, the whole organization benefits.

Ultimately, a high-performance culture is about more than results. It is about building a place where people can thrive, support one another, and continually discover new ways to add value for themselves and our customers. This is how we fulfill our promise of a safe digital future, built by people, for people.

How we build a high-performance culture
---------------------------------------

Every decision, large or small, shapes the culture we create together.

This approach begins during hiring. We are candid with candidates about our environment: The pace, the expectations, and the sense of ownership required. Candor in these conversations sets expectations early, builds trust from day one, and allows people to assess whether this is the right place for them to thrive.

Leaders set the tone for our teams and help drive

*[... truncated, 8,239 more characters]*

---

### Podcasts
*197 words* | Source: **GOOGLE** | [Link](https://workleap.com/resources-type/podcast)

[![Image 1](https://cdn.prod.website-files.com/66eab063c614790046e87eef/66f3c89500f8c53829f06098_Logotype.svg)](https://workleap.com/)

Podcasts
--------

Looking for fresh perspectives? Explore episodes with thought leaders shaping the future of work.

On-demand recordings

![Image 2](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/689d101e1a653adedb87a7dc_Workleap_Intro-Manuela_v01.avif)![Image 3](https://cdn.prod.website-files.com/66eab063c614790046e87eef/67408fa8d275e92b25e7f2e8_photo_2024-11-22_12-14-37.avif)

![Image 4](https://cdn.prod.website-files.com/66eab063c614790046e87eef/670d0076323563ea4881c4f6_Ellipse%203500.svg)

### What if HR and IT weren’t separate functions, but one team? (Manuela Paoletta, SVP of People and Culture at AlayaCare, and Kahina Ouerdane, CPO at Workleap)

Enroll in course

Get this resource

Get this resource

Watch now

![Image 5](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/6865d053051d4044c25fa6a1_Workleap_Intro-Katya_v01.avif)![Image 6](https://cdn.prod.website-files.com/66eab063c614790046e87eef/67408fa8d275e92b25e7f2e8_photo_2024-11-22_12-14-37.avif)

![Image 7](https://cdn.prod.website-files.com/66eab063c614790046e87eef/670d0076323563ea4881c4f6_Ellipse%203500.svg)

### Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap)

Enroll in course

Get this resource

Get this resource

Watch now

![Image 8](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/686532532253f8261ccf7835_Workleap_Intro-Shrivani_v02.avif)![Image 9](https://cdn.prod.website-files.com/66eab063c614790046e87eef/67408fa8d275e92b25e7f2e8_photo_2024-11-22_12-14-37.avif)

![Image 10](https://cdn.prod.website-files.com/66eab063c614790046e87eef/670d0076323563ea4881c4f6_Ellipse%203500.svg)

### Beyond Ratings: Performance Without the Box (Shirvani Mudaly, CPO at Lightspeed, and Kahina Ouerdane, CPO at Workleap)

Enroll in course

Get this resource

Get this resource

Watch now

![Image 11](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/685f24503f6a0797cfb66d95_Workleap_Intro-Afro_v02.avif)![Image 12](https://cdn.prod.website-files.com/66eab063c614790046e87eef/67408fa8d275e92b25e7f2e8_photo_2024-11-22_12-14-37.avif)

![Image 13](https://cdn.prod.website-files.com/66eab063c614790046e87eef/670d0076323563ea4881c4f6_Ellipse%203500.svg)

### Leading Through Change with Intent (Afroditi Ladovrechis, CPO at Innocap, and Kahina Ouerdane, CPO at Workleap)

Enroll in course

Get this resource

Get this resource

Watch now

![Image 14](https://cdn.prod.website-files.com/66f7b0f5cf40968468bc4d84/68260cb955e82c615141668d_Large-Featured_podcast%20(1)%20(1).avif)![Image 15](https://cdn.prod.website-files.com/66eab063c614790046e87eef/67408fa8d275e92b25e7f2e8_photo_2024-11-22_12-14-37.avif)

![Image 16](https://cdn.prod.website-files.com/66eab063c614790046e87eef/670d0076323563ea4881c4f6_Ellipse%203500.svg)

### Meaning at Work vs Meaning in Work (Mike Ross, former CHRO at Simons, and Kahina Ouerdane, CPO at Workleap)

Enroll in course

Get this resource

Get this resource

Watch now

---

### How the Red Bull Racing Pepe Jeans Academy Programme and 1Password are driving female excellence on and off the track | 1Password
*2,025 words* | Source: **GOOGLE** | [Link](https://1password.com/blog/how-the-red-bull-racing-pepe-jeans-academy-programme-and-1password-are-driving-female-excellence)

As the [Exclusive Cybersecurity Partner of Oracle Red Bull Racing](https://1password.com/blog/1password-oracle-red-bull-racing-melton-interview), we’re proud to work with a partner that believes excellence isn’t just about results, but about impact.

1Password’s partnership with the Red Bull Racing Pepe Jeans Academy Programme showcases how excellence manifests in the form of a shared commitment to uplifting the next generation of women in motorsport, cybersecurity, and any other field they choose to pursue. From the paddock to the boardroom, these efforts reinforce a shared vision — one where women have the support, visibility, and opportunity to lead with confidence.

With two female co-founders and strong representation in the C-suite, including the Chief Operating Officer, Chief People Officer, and Chief Legal Officer, women lead from the front at 1Password.

“At 1Password, women don’t just have a seat at the table—they help shape it. Women hold influential leadership roles across the company, from co-founders to executive decision-makers. Inside our walls, our Women’s Employee Resource Group supports growth at every level—offering leadership development, community-building, access to networks like AnitaB.org, and volunteer opportunities with organizations like Rewriting the Code. Beyond our team, we’re helping shape a more inclusive future in tech and cybersecurity through our 1Password for Good program, supporting global and grassroots organizations like Women in Cybersecurity, Mamas for Mamas, Black Women’s Health Imperative, and the Global Fund for Women. This isn’t just about representation—it’s about building a future where more women lead, thrive, and belong,” said Katya Laviolette, Chief People Officer, 1Password.

Together, the organizations are helping to build more inclusive pathways by providing mentorship, tools, and support to young talent ready to lead in high-performance environments. As part of this mission, 1Password proudly supports rising star Alisha Palmowski, whose determination and ambition exemplify the spirit of progress.

### Alisha’s excellence

After [winning in Shanghai earlier this year](https://www.f1academy.com/Latest/1Tjkym7HpycG9OuXi8xMgM/race-1-palmowski-claims-maiden-victory-in-shanghai-after-penultimate-lap), her first win in the F1® Academy, Alisha Palmowski embodies what community, perseverance, and self-belief can achieve: conquering your goals while doing it your way.

![Image 1: A photo of Alisha Palmowski on the podium after winning in Shanghi, the first race of 2025.](https://images.ctfassets.net/3091ajzcmzlr/3K4iVVDAP8nyOM3fHOXN5C/9a18efa164208f4f16ec4a33067c4968/_Users_andrewhill_Projects_blog.1password.com_content_posts_2025_how-the-red-bull-racing-pepe-jeans-academy-programme-and-1p.jpg)

In an interview with the New York Times last year, when asked about being a role model for the next generation of women in racing, Alisha Palmowski had this to say:

> _“When I was sort of five to six years old, I didn’t think I could be a racing driver, and I can’t say I was sad about that. I just didn’t realize that motorsport was an avenue that was open to me...[W]hereas now I think, with F1 Academy and the next generation of five to six-year-olds, now, when they turn the TV on, they see all this female representation, which is just absolutely incredible, and it should stop them being in the same position that I was in, and they can realize that motorsport is an avenue that they can go down, should they want to.”_

That said, to accomplish anything you set out to achieve, you need the right tools to get the job done. Just as Alisha’s car gets her across the finish line, Alisha safeguards her digital life with 1Password [(and you can too)](https://1password.com/pricing/password-manager). 1Password ensures that her most sensitive personal information — credentials, credit cards, and private race notes — remains secure and accessible wherever she goes, including this weekend in Montreal.

As Alisha readies to race the Canadian Grand Prix, inspiring a new generation to win on and off the track, in technology, business, and beyond, the Red Bull Racing Pepe Jeans Academy Programme and 1Password have proudly commissioned a bespoke livery that will adorn Alisha Palmowski’s car during the race weekend.

To learn more about the bespoke livery, let’s dive into what put this special design into motion.

A livery designed to inspire
----------------------------

When it came to the car’s design, we required someone who knew how to bring their creativity to such a unique canvas. That’s why 1Password and the Oracle Red Bull Racing brand teams partnered with Canadian muralist Kirsten McCrea, entrusting her with the creative lead to approach this livery as a conduit for storytelling that’s dynamic, powerful, and designed to reflect movement and growth.

Kirsten McCrea, who built her career in the male-dominated worlds of muralism and street art, drew inspiration from Alisha’s rise thro

*[... truncated, 8,990 more characters]*

---

### Leading Culture: Building the Future of Work
*2,136 words* | Source: **GOOGLE** | [Link](https://podcasts.apple.com/ca/podcast/leading-culture-building-the-future-of-work/id1808838377)

Leading Culture: Building the Future of Work - Podcast - Apple Podcasts

===============

[](https://podcasts.apple.com/ca/new)

*   [Home](https://podcasts.apple.com/ca/home)
*   [New](https://podcasts.apple.com/ca/new)
*   [Top Charts](https://podcasts.apple.com/ca/charts)
*   [Search](https://podcasts.apple.com/ca/search)

Open in Podcasts

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

![Image 1](https://podcasts.apple.com/assets/artwork/1x1.gif)

Leading Culture: Building the Future of Work
============================================

Workleap Podcasts

*    5.0 (1) 
*   [BUSINESS](https://podcasts.apple.com/ca/genre/1321?l=en-CA)
*   UPDATED SEMIMONTHLY

Leading Culture: Building the Future of Work brings together Workleap’s Chief People Officer, Kahina Ouerdane, and a guest CHRO or senior HR leader for candid, thought-provoking conversations about shaping the workplace of tomorrow. Together, they delve into how collective intelligence—the combined insights, experiences, and creativity of teams and leaders—can unlock new possibilities in HR and fuel our progress toward better workplaces. Each episode offers listeners a front-row seat to inspiring conversations filled with real stories, strategic insights, and practical takeaways.

MORE

Leading Culture: Building the Future of Work
============================================

Leading Culture: Building the Future of Work brings together Workleap’s Chief People Officer, Kahina Ouerdane, and a guest CHRO or senior HR leader for candid, thought-provoking conversations about shaping the workplace of tomorrow. Together, they delve into how collective intelligence—the combined insights, experiences, and creativity of teams and leaders—can unlock new possibilities in HR and fuel our progress toward better workplaces. Each episode offers listeners a front-row seat to inspiring conversations filled with real stories, strategic insights, and practical takeaways.

 Latest Episode 

Follow

Episodes
--------

1.   [AUG 14 ### What if HR and IT weren’t separate functions, but one team? (Manuela Paoletta, SVP of People and Culture at AlayaCare, and Kahina Ouerdane, CPO at Workleap) In this episode of Leading Culture, Kahina Ouerdane chats with Manuela Paoletta, SVP of People and Culture at AlayaCare, about what it really looks like to lead both HR and IT, and why more companies should consider it. They dive into the power of breaking down silos, how tech impacts culture and onboarding, and the evolving role of HR in driving AI adoption 28 min](https://podcasts.apple.com/ca/podcast/what-if-hr-and-it-werent-separate-functions-but-one/id1808838377?i=1000721941828) 
2.   [JUL 3 ### Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap) How do you scale fast without losing what makes your culture special? In this episode, Workleap’s CPO Kahina Ouerdane sits down with Katya Laviolette, CPO at 1Password, to talk about growing a global, remote team—while staying true to your values. They dive into codifying culture, onboarding with intention, and why clarity and candor are must-haves in a high-growth world. A must-listen for anyone building culture at scale. 29 min](https://podcasts.apple.com/ca/podcast/scaling-culture-remotely-katya-laviolette-cpo-at-1password/id1808838377?i=1000715595147) 
3.   [JUN 19 ### Beyond Ratings: Performance Without the Box (Shirvani Mudaly, CPO at Lightspeed, and Kahina Ouerdane, CPO at Workleap) What if ratings aren’t the only (or even the right) answer to better performance? And what would happen if we trusted people more — not less — to grow, stretch, and lead? In this episode, Kahina Ouerdane, Chief People Officer at Workleap, sits down with Shirvani Mudaly, Chief People Officer at Lightspeed, for an honest conversation about reimagining performance management. Together, they explore why traditional systems often create noise instead of clarity, how feedback and trust build the foundation for high-performing teams, and why great leadership is more about meaningful conversations than perfect frameworks. From practical tips on goal-setting to the deeper question of purpose at work, this episode is packed with wisdom for anyone rethinking what performance can look like in today’s world of work. It’s an invitation to shift from control to connection — and lead with the kind of clarity that truly moves people. 28 min](https://podcasts.apple.com/ca/podcast/beyond-ratings-performance-without-the-box-shirvani/id1808838377?i=1000713572713) 
4.   [MAY 7 ### Leading Through Change with Intent (Afroditi Ladovrechis, CPO at Innocap, and Kahina Ouerdane, CPO at Workleap) What happens when you’re leading people through transformation—while transforming yourself at the same time?In this episode, Kahina, Chief People Officer at Workleap, is joined by Afroditi Ladovrechis, Chief

*[... truncated, 24,147 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Katya Laviolette - Meet the Team | 1Password](https://1password.com/company/meet-the-team/katya-laviolette)**
  - Source: 1password.com
  - *Katya Laviolette is the Chief People Officer at 1Password, where she's grown the fully remote workforce to over 1,400 employees across five countries ...*

- **[Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password ...](https://workleap.com/resources/scaling-culture-remotely-katya-laviolette-cpo-at-1password-and-kahina-ouerdane-cpo-at-workleap)**
  - Source: workleap.com
  - *Podcasts. Leading culture. Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap). How do you scale fast...*

- **[Purpose, performance, and trust: Inside the culture powering ...](https://1password.com/blog/inside-the-culture-powering-1passwords-next-chapter)**
  - Source: 1password.com
  - *Aug 13, 2025 ... Purpose, performance, and trust: Inside the culture powering 1Password's next chapter. by Katya Laviolette ... 1Password isn't just a...*

- **[Podcasts](https://workleap.com/resources-type/podcast)**
  - Source: workleap.com
  - *Podcasts. Looking for fresh perspectives? Explore ... Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workl...*

- **[How the Red Bull Racing Pepe Jeans Academy Programme and ...](https://1password.com/blog/how-the-red-bull-racing-pepe-jeans-academy-programme-and-1password-are-driving-female-excellence)**
  - Source: 1password.com
  - *Jun 12, 2025 ... ... Katya Laviolette, Chief People Officer, 1Password. Together, the organizations are helping to build more inclusive pathways by pr...*

- **[Leading Culture: Building the Future of Work - Podcast - Apple ...](https://podcasts.apple.com/ca/podcast/leading-culture-building-the-future-of-work/id1808838377)**
  - Source: podcasts.apple.com
  - *Scaling Culture, Remotely (Katya Laviolette, CPO at 1Password, and Kahina Ouerdane, CPO at Workleap). How do you scale fast without losing what makes ...*

- **[Keeping Your Core Culture Intact as Your Company Scales](https://www.15five.com/blog/keeping-your-core-culture-intact-as-your-company-scales/)**
  - Source: 15five.com
  - *Jun 12, 2024 ... I'm Katya Laviolette, Chief People Officer at 1Password, and I dove into this topic with 15Five on the HR Superstars Podcast. Here ar...*

- **[How Companies Should Respond to Political Events - CB](https://canadianbusiness.com/strategies/how-companies-should-respond-to-political-events-1password/)**
  - Source: canadianbusiness.com
  - *Oct 14, 2022 ... Podcasts · Canadian Business – How to Do Business Better. People ... A photo of 1Password's chief people officer, Katya Laviolette Ka...*

- **[David Faugno latest addition to 1Password as first-ever president ...](https://betakit.com/david-faugno-latest-addition-to-1password-as-first-ever-president-and-chief-operating-officer/)**
  - Source: betakit.com
  - *Sep 29, 2023 ... ... Katya Laviolette as chief people officer. 1Password has also celebrated significant revenue milestones recently. CEO Jeff Shiner ...*

- **[Fake Interview Scam??? : r/1Password](https://www.reddit.com/r/1Password/comments/1le17vp/fake_interview_scam/)**
  - Source: reddit.com
  - *Jun 17, 2025 ... And I was brought to a chat with Katya Laviolette and I was then told the interview was for...1Password? (I know... I know). I mentio...*

---

*Generated by Founder Scraper*
