# Clement Roy

## Position actuelle

**Titre** : Founder and CEO at Nukleo
**Entreprise** : Nukleo
**Durée dans le rôle** : 3 years 7 months in role
**Durée dans l'entreprise** : 3 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

As CEO of Nukleo, I bring over a decade of experience as an agency founder and partner, leading large-scale digital transformations, national campaigns, and high-profile fundraising initiatives. My expertise lies in structuring complex projects, aligning strategy with compliance requirements, and delivering measurable impact for organizations across sectors.

Beyond business, I’m deeply committed to culture and community. I serve as Co-President of the Young Philanthropists Circle at the Montreal Museum of Fine Arts Foundation and sit on the Board of the Conseil des arts de Montréal, continuing to champion projects that combine creativity, innovation, and purpose.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABv5EWsB59vIhwZD2N_gd97jWioIB3Kh1m8/
**Connexions partagées** : 119


---

# Clement Roy

## Position actuelle

**Entreprise** : Nukleo

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Clement Roy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401684469570699267 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFrWRRcvm77CA/feedshare-shrink_800/B4EZrgQwP0GoAg-/0/1764699087538?e=1766620800&v=beta&t=PS-zXbbo0IEckMlF1ZCpQhbHwQcARsXQXiZEz-1tWQs | Life is full of defining moments, and this was definitely one of them.

Traveling with Alexei to London was an adventure that did not disappoint.

3 days in the Uk capital for SaaStr.ai, thanks to the Canadian Atlantic delegation and to its champions, Judith Dardon (Invest Nova Scotia), Erin Clendenning (Opportunities New Brunswick) & Derek Leung (Digital Nova Scotia).

It was also three days filled with amazing encounters and the beginning of meaningful business partnerships, especially with our friends Paul McIntosh and Jai Mcintosh from Bridgehead International Agency Ltd.

A special mention as well to Sura Hussein (London & Partners) for her renewed and valuable advice, helping us open doors for our future UK office in 2026.

And of course the soft launch of our AI product coming in 2026:https://causepilot.ai 

All in all, just great times 🔥🔥🔥 | 68 | 7 | 9 | 5d | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:52:59.468Z |  | 2025-12-02T18:11:34.193Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7390079659163693056 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG7zdctP5pKjQ/feedshare-shrink_800/B4EZo7UuQ3KkAg-/0/1761931880901?e=1766620800&v=beta&t=rq6-nuIDfeAudVltGGEbgWfHKuXElLsED_d8ntckZMA | Vraiment heureux de participer à cette campagne pour une 5e année. Merci Ann-Julie pour la confiance renouvellée! | 28 | 0 | 0 | 1mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:52:59.471Z |  | 2025-10-31T17:38:11.785Z | https://www.linkedin.com/feed/update/urn:li:activity:7390077941294006272/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386512163840114689 | Article |  |  | I almost have tears in my eyes writing these words.
Proud. Moved. Grateful.

In just four years, we’ve built something truly special.
And today marks a major milestone:
Nucléus Stratégie officially becomes Nukleo.

A new name, a new image, but the same mission: helping organizations build their digital future with clarity and confidence.

We’re now a team of 15, collaborating with clients across 5 countries, and every day I can feel our vision taking shape a little more.

I’m so lucky to be on this journey with such a talented, curious, and passionate crew. Thank you, from the bottom of my heart, you are truly exceptional.

And to everyone who’s been following us since the beginning…
You haven’t seen the last of us.

nukleo.com 
Alexei, Margaux, Antoine, Sarah, Omar, Camille, Maxime, Hind, Ricardo, Marie-Claire, Meriem, Jean-Francois, Séverine, Timothé. | 159 | 22 | 8 | 1mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.841Z |  | 2025-10-21T21:22:14.619Z | http://nukleo.com/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7380956627157360641 | Article |  |  | Qu'est-ce qui fait battre le 💙 d'une ville ?

Ce sont ses citoyens, ses entrepreneurs, mais aussi ses artistes et ses créateurs. Ce sont les arts qui nous rassemblent, nous inspirent et nous définissent.

Avec 74 autres leaders montréalais, nous avons cosigné une lettre ouverte publiée dans Le Devoir. Notre message est clair : les arts ne sont pas un luxe. Ils sont une nécessité.

La culture, c'est le ciment de notre identité. C'est ce qui dynamise nos quartiers, inspire nos entrepreneurs et attire les talents. Il est temps de considérer le milieu des arts et de la culture pour ce qu'il est vraiment : un véritable moteur de l'économie montréalaise.

Pourtant, malgré une nouvelle politique culturelle, aucun financement n'a été annoncé. Nous demandons un engagement concret : porter le budget du Conseil des arts de Montréal à 30 millions $ d'ici 2030.

Bâtir une ville forte, c'est bâtir une ville culturellement vibrante.

https://lnkd.in/ej4pwigy
Avec entre autres : Mathieu Bouchard, Yves-Alexandre Comeau, Milly A. Dery, Nassib El-Husseini, Roxanne Sayegh. | 50 | 1 | 2 | 2mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.843Z |  | 2025-10-06T13:26:31.457Z | https://www.ledevoir.com/opinion/idees/922692/idees-montreal-doit-prioriser-arts-culture |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7377352118309109760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHlH448ZTuJ5Q/feedshare-shrink_800/B4EZmGepsGIQAg-/0/1758897808107?e=1766620800&v=beta&t=eZO3TTrIMml3IrdtqXHpeKzCyaH4e_komOwwPV8fUOU | Hier avait lieu la grande soirée d’ouverture de l’incroyable exposition Kent Monkman : L’Histoire est dépeinte par les vainqueurs au Montreal Museum of Fine Arts.

Une exposition puissante et incontournable, et un autre bon moment entouré de la merveilleuse communauté qui soutient la Montreal Museum of Fine Arts Foundation. 

📷 avec Margaux par Bryn. | 81 | 2 | 1 | 2mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.844Z |  | 2025-09-26T14:43:29.579Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7373394506647306240 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPfePrIbAsdw/feedshare-shrink_800/B4EZlOOvmmK0Ag-/0/1757954235258?e=1766620800&v=beta&t=Y_BPBc9tswFXWD91E3tBuf-Tt06Pu08KVfnCVHvRiW4 | « On a besoin d’entendre la moitié de qui on est. » ✨ 
Ces mots d’Adèle Blais ont résonné avec force ce matin à Sherbrooke, où elle était présente aux côtés de la mairesse Évelyne Beaudin pour inaugurer la Murale FORTES.

Cette œuvre à ciel ouvert, conçue comme une salle d’exposition muséale ancrée dans l’espace public, rend hommage à 11 femmes inspirantes, souvent oubliées, qui ont, chacune à leur manière, façonné notre monde.

Grâce à l’application Adèle Blais – Peindre l’Histoire, chaque portrait s’anime en réalité augmentée. Textes biographiques, narrations et ambiances sonores viennent enrichir l’expérience, dévoilant des fragments trop souvent absents de notre mémoire collective.

Parce que, malgré ce que racontent parfois les livres, l’histoire s’écrit avec des femmes ET des hommes d’exception.

Je suis profondément honoré d’avoir contribué à ce projet porteur de sens, à travers le développement de l’application mobile qui accompagne la murale et permet au public de découvrir ces histoires inspirantes de façon vivante et immersive.

Un immense bravo à Adèle, à Jacinthe, à Publiforme et à toute l’équipe derrière cette réalisation artistique et technique impressionnante. 

Et un clin d'œil tout particulier à notre l’équipe de feu de Nukleo et Eugeniuses qui a travaillé sur l’application : Alexei, Jean-Daniel, Mathieu, Margaux et Sarah🙌

👉 Découvrez le projet ici : https://lnkd.in/eZ_WqAiQ | 45 | 6 | 3 | 2mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.845Z |  | 2025-09-15T16:37:21.430Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7359360534506283010 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEkP1CVGGJYLg/feedshare-shrink_2048_1536/B4EZiE4HclHoAs-/0/1754575961410?e=1766620800&v=beta&t=R0AGouSID2ihNUQzCdLlOJEDznJjoiKo1DnVv2p2bFw | Life can be an amazing journey.

A year ago I was meeting Rick, Andy and Brieana from Humankind Global Recruitment in Halifax at the first edition of the Waterfront mixer, as we were just launching our Halifax office.

Fast forward 12 months:
We’re now collaborating on exciting projects together—and we’re proud to be co-hosting the second edition of the Waterfront Mixer! 🔥

From first meetings to meaningful partnerships—this is what growth looks like.

Join us as we celebrate community, collaboration, and the next chapter of our Halifax story. 💼🌊 | 25 | 1 | 0 | 4mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.847Z |  | 2025-08-07T23:11:21.733Z | https://www.linkedin.com/feed/update/urn:li:activity:7359224977205694465/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7346609907460169728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEEH5JKT8nP7w/feedshare-shrink_800/B4EZfMn31dHIAs-/0/1751484694662?e=1766620800&v=beta&t=v_a_GWSKKnHXHOUUKMxEDcCXp_C0m3biWAjWe26KNmA | 🎉 Une campagne qui atteint son objectif, c’est toujours une belle fierté, surtout quand elle défend une mission aussi essentielle.

Je suis particulièrement heureux que notre équipe ait pu prêter main forte au Centre québécois du droit de l'environnement pour marquer ses 35 ans de façon aussi mobilisatrice.

👏 Bravo à Omar pour le support stratégique et l’exécution, à Margaux pour la direction créative, et à Camille pour la création des visuels.

Et surtout, bravo au CQDE pour son travail indispensable depuis 35 ans. 

Pour découvrir et soutenir la cause : https://cqde.org | 23 | 0 | 1 | 5mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:01.849Z |  | 2025-07-03T18:44:55.350Z | https://www.linkedin.com/feed/update/urn:li:activity:7346259264442687491/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7339707575199784960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGWT7eooBiwaA/feedshare-shrink_800/B4EZdvhHkGHgAg-/0/1749922644402?e=1766620800&v=beta&t=xVNokRMDLKmwwI7Dedbp0j8rij_Kgs66454dFNG7Myk | A few months ago, I made a bet—we’d open a European office in 2026. And this week, it all felt within reach. What a whirlwind 🔥🔥

Last Sunday, Alexei and I kicked off a 3-week strategic mission across Europe, with key stops in London, Paris, Lyon, and Manchester.

It’s all part of our roadmap toward opening a Nukleo office in Europe by 2026 — and strengthening the value we deliver to the organizations we work with.

📍 Week 1 — Highlights so far 👇

Our European mission began in London, made possible by the invitation from Opportunities New Brunswick and Invest Nova Scotia (thank you Judith Dardon).

🤝 The week kicked off with initial exchanges at the European startups evening organized by London & Partners—a perfect opportunity to connect with teams from across the continent (thanks Chloë for the invitation).
🧠 Two full days at London Tech Week, diving into themes like AI development, sustainable innovation, and the AI agents ecosystem. 
🔥A inspiring meeting at Canada House London with the Atlantic delegation, where we were received by Trade Commissionner Sanjay Purohit, to dive into the UK tech market landscape—invaluable insights for our European expansion strategy.
🏛️ An amazing Cocktail reception at the Old Bailey Courthouse (very glad to have met Juha Berghäll! 
🌎 Further enriching meetings and discussions followed, including with Jeff Gordon-Johnson from Opportunities New Brunswick, to discuss our next moves in the Atlantic region.

And because we never have enough, we then traveled to Paris to attend VivaTech. Even more special moments! 

🎯 Being on-site at VivaTech to support Zú's official launch of their transatlantic strategic partnership—congrats to Dimitri Gourdin, Adm.A., PRP, Jeanne Dorelli & Pierre-Olivier Bontems. 
🍽️ A celebratory dinner with the Zú team and partners—an incredible evening connecting friends from both sides of the Atlantic. Special shoutout to Rachelle Sorin & Lynda Gagnon for the amazing conversations.
🏛️ The cocktail reception at the Ambassador of Canada's Residence, bringing together delegations from four Canadian provinces—thank you, Erin Clendenning, for the invitation!
👥 Reconnecting with familiar faces, including Alexandre Bouchard & Alex Côté CIMᴹᴰ CRIC! 
🥂 A connection moment with the Frenchfounders community.
🍴 A fantastic lunch with Ali Roberts from Manchester Central discussing an exciting future project ( 🤗 Lori) 
☕ A perfect Parisian coffee with Mélodie Labbé from KIBLIND before heading to Lyon next to meet the entire team.

And this is just the beginning. Europe, we’re here to build. 🚀 | 122 | 24 | 2 | 5mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:07.192Z |  | 2025-06-14T17:37:31.100Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7329503567415840768 | Article |  |  | Déjà 80 % de l’objectif atteint en une semaine! 🎉

Le théâtre des Béloufilles, c’est bien plus qu’une création, c’est une aventure artistique et féminine au cœur de notre magnifique Côte-Nord.

Si vous souhaitez soutenir un projet qui en vaut vraiment la peine et en profiter pour visiter cette région incroyable cet été (parce que la culture, ça fait voyager!) 🌊🎭👉 https://lnkd.in/eYsrtceG

Chez Nukleo, nous croyons fermement que notre culture doit être soutenue partout au Québec. Et je suis particulièrement fier de contribuer à la campagne des Béloufilles à travers une commandite en services.

Aidez-les à atteindre leur objectif et faites partie de cette belle aventure! | 19 | 0 | 0 | 6mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:07.196Z |  | 2025-05-17T13:50:26.063Z | https://laruchequebec.com/fr/projets/pour-un-retour-des-beloufilles |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7319061737813504003 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGRx8Ww0uwpgQ/feedshare-shrink_800/B4DZZKH2vrH4Ag-/0/1745000297387?e=1766620800&v=beta&t=iFwLhMGEiVkaafyb_JsnWN6lMm6eI2Wy8NhyAZdJaLQ | C’est à titre de Partenaire des Arts que nous avons eu le privilège de participer au Grand Prix du Conseil des arts de Montréal hier midi. Un moment extraordinaire, hors du temps et une bulle de bonheur qui fait du bien!

Merci à nos chers amis et complices* qui ont pris le temps de venir célébrer les arts et la culture de notre métropole et de participer par leur présence à la mission de Nukleo de soutenir le milieu culturel.

Bravo aux finalistes, aux lauréats et à toute l’équipe du CAM pour cet événement réussi, entre autres Nathalie Maillé, Julien Valmary, Hugo Couturier, François FRITSCH et Talar Agopian (et tous les autres)!



*avec Margaux, Adèle, Serge, Ron, Eloi, Emmanuel, William, Julia, Dominique, Fabien, Bruno, Mathieu, Héloïse, Arnaud, Étienne, Eric & Gabriel. | 67 | 5 | 2 | 7mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:07.198Z |  | 2025-04-18T18:18:19.886Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7317185599726080000 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHU2SHXWyKHMg/image-shrink_800/B4EZYvdhGIHUAc-/0/1744552991739?e=1765774800&v=beta&t=BCouAAZXN1F_VuayAym4ssU_B_rocgaFgmrvO5R_aNg | Je suis très heureux de participer à la Grande rencontre de la relève d’affaires de Montréal 2025, organisée par la Jeune Chambre de commerce de Montréal et présidée par Sun Life Québec, en tant qu’intervenant au panel « Innover pour l’avenir : leadership et philanthropie au service de la jeunesse » aux côtés de Karine Eid, Linda Tchombé, et Camille Benoit .

📅 Rendez-vous le 24 avril, de 14h30 à 15h30 au Centre PHI !

Ce sera l’occasion de réfléchir à la manière dont l’engagement social, le leadership et la philanthropie peuvent favoriser l’émergence d’une nouvelle génération de leader·euse·s engagé·e·s.

👉 Découvrez la programmation complète ici : https://lnkd.in/e-sb-6_c

Un grand merci à Cecile Martin et l'équipe du GRRAM pour l'invitation ! | 80 | 2 | 1 | 7mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:07.200Z |  | 2025-04-13T14:03:13.709Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7311084118073589760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFclKQj_ynlAg/feedshare-shrink_800/B4EZXYaXW.HgAk-/0/1743092545678?e=1766620800&v=beta&t=Q-y-diJe7zlHRFs-ZLvINpaCMoa46Anvs3gt4N-WFBo | J'adore ce projet : une cause qui nous tient à cœur, une artiste incroyable (Adèle Blais), de la réalité augmentée et une application mobile. La parfaite rencontre entre l'art, la technologie et un impact positif. 🔥💖 | 28 | 3 | 0 | 8mo | Post | Clement Roy | https://www.linkedin.com/in/clement-roy | https://linkedin.com/in/clement-roy | 2025-12-08T04:53:07.202Z |  | 2025-03-27T17:58:07.123Z | https://www.linkedin.com/feed/update/urn:li:activity:7311060042634481664/ |  | 

---



---

# Clement Roy
*Nukleo*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [#48 - Néo Arrête Freenode Pour Se Mettre Aux NFT](https://clever-cloud.com/podcast/48-neo-arrete-freenode-pour-se-mettre-aux-nft)
*2024-12-06*
- Category: podcast

### [Clément Le Roux: Creativity on the Open Sea](https://stagelync.com/news/clement-le-roux-creativity-on-the-open-sea)
*2025-02-03*
- Category: article

### [Marketing Buddy #1: "The very idea of community is anti-AI" with Clément Le Roux](https://yourbrandingletter.substack.com/p/hello-marketing-buddy)
*2023-07-04*
- Category: blog

### [Clement Delangue of Hugging Face on building the GitHub of machine learning | The Robot Brains Podcast](https://shows.acast.com/the-robot-brains/episodes/clement-delangue-hugging-face-on-building-the-github-of-ml)
*2022-05-25*
- Category: article

### [“A Great Strategy is Only Valuable When Executed Effectively” – An Interview with Clément Lelong](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/)
*2023-12-12*
- Category: article

---

## 📖 Full Content (Scraped)

*5 articles scraped, 8,088 words total*

### #48 - Néo Arrête Freenode Pour Se Mettre Aux NFT
*1,588 words* | Source: **EXA** | [Link](https://clever-cloud.com/podcast/48-neo-arrete-freenode-pour-se-mettre-aux-nft)

#48 - Néo Arrête Freenode Pour Se Mettre Aux NFT | Clever Cloud

===============

*   [Skip to menu](https://clever-cloud.com/podcast/48-neo-arrete-freenode-pour-se-mettre-aux-nft#navigation)
*   [Skip to content](https://clever-cloud.com/podcast/48-neo-arrete-freenode-pour-se-mettre-aux-nft#content)

*   [Jobs](https://www.clever.cloud/jobs/)
*   [Documentation](https://www.clever.cloud/developers)
*   [Login](https://console.clever-cloud.com/)
*   [Signup](https://api.clever-cloud.com/v2/sessions/signup)

[![Image 3: Clever Cloud](https://cdn.clever-cloud.com/uploads/2023/03/logoonwhite.svg)![Image 4](https://cdn.clever-cloud.com/uploads/2023/03/logowhitetext-1.svg)](https://www.clever.cloud/)

*    The Company 

 The Company 
    *   [Presentation](https://www.clever.cloud/presentation/) Presentation 

 Presentation [Presentation](https://www.clever.cloud/presentation/)
        *   [Read more](https://www.clever.cloud/presentation/)
        *   [Key benefits](https://www.clever.cloud/key-benefits/)
        *   [Executive Approach](https://www.clever.cloud/executive-approach/)
        *   [DevOps Approach](https://www.clever.cloud/devops-approach/)
        *   [Developper Tools](https://www.clever.cloud/developper-tools/)

    *   [Compliance](https://www.clever.cloud/solutions/compliance/) Compliance 

 Compliance [Compliance](https://www.clever.cloud/solutions/compliance/)
        *   [Read more](https://www.clever.cloud/solutions/compliance/)
        *   [Health Data Hosting](https://www.clever.cloud/health-data-hosting/)
        *   [ISO 27001](https://www.clever.cloud/iso-27001-security-by-default-at-clever-cloud/)
        *   [SecNumCloud](https://www.clever.cloud/secnumcloud-trusted-cloud/)

    *   [Our values](https://www.clever.cloud/our-values/) Our values 

 Our values [Our values](https://www.clever.cloud/our-values/)
        *   [Read more](https://www.clever.cloud/our-values/)
        *   [Sovereign Cloud](https://www.clever.cloud/sovereign-cloud/)
        *   [Security](https://www.clever.cloud/security/)
        *   [Open Source](https://www.clever.cloud/open-source/)
        *   [Cloud and Green IT](https://www.clever.cloud/cloud-and-green-it/)

    *   [Our expertises](https://www.clever.cloud/our-expertises/) Our expertises 

 Our expertises [Our expertises](https://www.clever.cloud/our-expertises/)
        *   [Read more](https://www.clever.cloud/our-expertises/)
        *   [Testimonials](https://www.clever.cloud/testimonials/)

    *   [Ecosystems](https://www.clever.cloud/partners-and-ecosystems/) Ecosystems 

 Ecosystems [Ecosystems](https://www.clever.cloud/partners-and-ecosystems/)
        *   [Read more](https://www.clever.cloud/partners-and-ecosystems/)
        *   [Partners](https://www.clever.cloud/partners/)
        *   [Built with Clever](https://www.clever.cloud/home-3/built-with-clever/)
        *   [Marketplace](https://www.clever.cloud/marketplace/)

*    Products 

 Products 
    *   [PaaS Features](https://www.clever.cloud/clever-cloud-paas/) PaaS Features 

 PaaS Features [PaaS Features](https://www.clever.cloud/clever-cloud-paas/)
        *   [Read more](https://www.clever.cloud/clever-cloud-paas/)
        *   [Interoperability](https://www.clever.cloud/interoperability/)
        *   [Cloud Observability](https://www.clever.cloud/cloud-observability/)
        *   [Automated and Flexible Deployment](https://www.clever.cloud/automated-and-flexible-deployment/)
        *   [IAM and Governance](https://www.clever.cloud/iam-and-governance/)

    *   [Runtimes](https://www.clever.cloud/runtimes/) Runtimes 

 Runtimes [Runtimes](https://www.clever.cloud/runtimes/)
        *   [Read more](https://www.clever.cloud/runtimes/)
        *   [.NET.core Applications](https://www.clever.cloud/product/net-core-applications/)
        *   [Docker Applications](https://www.clever.cloud/product/docker-applications/)
        *   [Elixir Applications](https://www.clever.cloud/product/elixir-applications/)
        *   [GO Applications](https://www.clever.cloud/product/go-applications/)
        *   [Haskell Applications](https://www.clever.cloud/product/haskell-applications/)
        *   [Java Applications](https://www.clever.cloud/product/java-applications/)
        *   [Meteor.js Applications](https://www.clever.cloud/product/meteor-js-applications/)
        *   [Node.js Applications](https://www.clever.cloud/product/node-js-applications/)
        *   [PHP Applications](https://www.clever.cloud/product/php/)
        *   [FrankenPHP applications](https://www.clever.cloud/product/frankenphp/)
        *   [Python Applications](https://www.clever.cloud/product/python-applications/)
        *   [Ruby Applications](https://www.clever.cloud/product/ruby-applications/)
        *   [Rust Applications](https://www.clever.cloud/product/rust-applications/)
        *   [Scala Applications](https://www.clever.cloud/product/scala-applications/)
        *   [Static Applications](https://www.clever.cloud

*[... truncated, 22,000 more characters]*

---

### Clément Le Roux: Creativity on the Open Sea - StageLync
*2,538 words* | Source: **EXA** | [Link](https://stagelync.com/news/clement-le-roux-creativity-on-the-open-sea)

Clément Le Roux: Creativity on the Open Sea - StageLync

===============

[](https://stagelync.com/news)

[STAGELYNC PRO](https://stagelync.com/pro)[Login](https://stagelync.com/login)[Join](https://stagelync.com/signup)Open main menu

*   [News](https://stagelync.com/)
*   [Behind the Curtain](https://stagelync.com/news/sl/behind-the-curtain)
*   [Opinion](https://stagelync.com/news/sl/opinion)
*   [Podcast](https://stagelync.com/news/sl/podcast)

*   [News](https://stagelync.com/)
    *   [Latest News](https://stagelync.com/news/sl/industry-news)
    *   [Behind the Curtain](https://stagelync.com/news/sl/behind-the-curtain)
    *   [Opinion](https://stagelync.com/news/sl/opinion)
    *   [Reviews](https://stagelync.com/news/sl/reviews)
    *   [Podcast](https://stagelync.com/news/sl/podcast)

*   [News By Genre](https://stagelync.com/news/sl/industry-news)
    *   [Circus News](https://stagelync.com/news/sl/circus-news)
    *   [Comedy News](https://stagelync.com/news/sl/comedy-news)
    *   [Dance News](https://stagelync.com/news/sl/dance-news)
    *   [Music News](https://stagelync.com/news/sl/music-news)
    *   [Opera News](https://stagelync.com/news/sl/opera-news)
    *   [Theater News](https://stagelync.com/news/sl/theater-news)

*   [Podcast](https://stagelync.com/news/sl/podcast)
    *   [StageLync Podcast](https://stagelync.com/news/sl/podcast)
    *   [Partner Podcasts](https://stagelync.com/news/sl/partner-podcast)

[](https://www.facebook.com/StageLync)[](https://x.com/StageLync)[](https://www.instagram.com/stagelync/)[](https://www.linkedin.com/company/stagelync/)[](https://www.youtube.com/@StageLync)[](https://news.google.com/publications/CAAqMAgKIipDQklTR1FnTWFoVUtFMk5wY21OMWMzUmhiR3N1WTI5dEwyNWxkM01vQUFQAQ?hl=en-US&gl=US&ceid=US%3Aen)[](https://stagelync.com/news/'.home_url().'/sl/podcast)

[Behind the Curtain](https://stagelync.com/news/sl/behind-the-curtain)

Clément Le Roux: Creativity on the Open Sea
===========================================

[February 3, 2025 October 28, 2025](https://stagelync.com/news/clement-le-roux-creativity-on-the-open-sea "8:14 am")[Anna Robb](https://stagelync.com/news/author/theater-art-life "Anna Robb")[Artistic-Creation](https://stagelync.com/news/tag/artistic-creation)

![Image 2: Clément Le Roux](https://stagelync.com/news/app/uploads/2025/02/Cle%CC%81ment-Le-Roux.jpg)

###### At StageLync, we love exploring the intersection of art, performance, and community. Next week, we’re joined by Clément Le Roux—a storyteller, sailor, and community worker whose work spans France, Canada, and Scandinavia. From leading a transatlantic artistic voyage to supporting Indigenous filmmaking and transforming a Swedish sailing ship into an artistic residency, Clément’s journey is as captivating as his performances. Tune in as we dive into his world of immersive storytelling, exploration, and the power of performance to connect communities!

****How did magic become a part of your life?****

Magic has always been a passion for me. As a child, I loved playing, and magic became an extension of that—a way to connect with people through wonder and storytelling. Over time, I became more professional, meeting other artists, working as a consultant for shows in Paris and Montreal, and incorporating magic into various artistic projects. Today, I think about and create magic almost every day.

****How did you get into sailing?****

My family had connections to sailing, but I never really engaged with it until 2019. I saw a job listing for a sailor who was also a community worker, which intrigued me. I applied and within two weeks got a call inviting me to sail for four months. I jumped at the opportunity, and since then, I’ve never looked back. It became a huge part of my life, blending adventure, community work, and art.

****Can you tell us about the transatlantic sailing project and how it came to be?****

In 2020, during the pandemic, I learned about a previous transatlantic sailing project focused on community engagement. I wanted to revive it, so I started reaching out to organizations and fundraising. Though the pandemic halted my progress, I connected with people involved in rebuilding a Swedish ship in Denmark, which eventually led me to another opportunity. A sailing boat, the _Rava Avice_, contacted me about an expedition to Canada, asking if I had a project. I had no funds, participants, or organization at the time, but I asked for three months to make it happen. I secured funding through a France-Quebec cultural initiative, partnered with a nonprofit, recruited artists, and built the project from scratch. By December 2023, it was officially funded, and by 2024, we set sail with 37 people on board, including seven artists who engaged in creative exploration during the journey.

****What was life like on the boat for the artists?****

It was a truly immersive experience. Everyone participated in sailing, cooking, and cleaning—this wasn’t a cruise, it was a working exped

*[... truncated, 23,550 more characters]*

---

### Marketing Buddy #1: "The very idea of community is anti-AI" with Clément Le Roux
*1,569 words* | Source: **EXA** | [Link](https://yourbrandingletter.substack.com/p/hello-marketing-buddy)

[![Image 1](https://substackcdn.com/image/fetch/$s_!q2yQ!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cea9fda-5589-4442-9f84-844c054098d2_1440x1048.png)](https://substackcdn.com/image/fetch/$s_!q2yQ!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F9cea9fda-5589-4442-9f84-844c054098d2_1440x1048.png)

👋 Hello, Branding enthusiast, how are you doing today?

[![Image 2](https://substackcdn.com/image/fetch/$s_!-0L5!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F4e47d97e-efcf-45f0-bc5e-6cefa02ea7e5_239x83.png)](https://substackcdn.com/image/fetch/$s_!-0L5!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F4e47d97e-efcf-45f0-bc5e-6cefa02ea7e5_239x83.png)

**This week, let's explore a new section of the letter: Marketing Buddy**— a great addition to our dear **Brand Revealers**. Occasionally, we will invite them to join the letter and share marketing wisdom and strategies. We have to become friends with the craft of Marketing, so let’s bring them in and grow!

I asked a few questions to **[Clément Le Roux](https://www.linkedin.com/in/lerouxclement)**, whom I discovered through the French **[crème de la crème](https://www.cremedelacreme.io/)** community. He is a freelance Community Builder and Marketing expert. I thought he would make a great first **Marketing Buddy, a proactive one!**

[![Image 3](https://substackcdn.com/image/fetch/$s_!o0sa!,w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3d991c46-b8e0-43d5-868d-f7add3477c2a_1344x481.png)](https://substackcdn.com/image/fetch/$s_!o0sa!,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F3d991c46-b8e0-43d5-868d-f7add3477c2a_1344x481.png)

**🇫🇷 Let’s be bilingual!**I am trying to bridge the gap of language as I evolve with this letter. For French guests, we will listen to some of their voices in French and read them in English. If the audio format works for some English guests, we will do the same and reverse the experience. Enjoy!

0:00

-7:09

Audio playback is not supported on your browser. Please upgrade.

**🇬🇧🇺🇸 Here is the translation for my English readers**

It is official! I am launching**Marketing Buddy**, a curated group of marketing experts, I also call them the **Marketing Revealers**. They will help us better understand what marketing stands for. As for me, I am creative, and I must admit that marketing and I didn't get along well. It wasn't a harmonious relationship. 

But little by little, I realized how essential it was in branding, and how much of an ally it is in expressing a brand. I decided to invite marketing experts who will come and give us advice along with their vision of branding and marketing.

> A relationship that is a bit like cat and dog, or like Yin and Yang, one doesn't go without the other.

For this first edition, we have as a guest **Clément Le Roux**, who is a Community Builder and Marketing expert. He helps shape and develop communities. I met him through the **"crème de la crème"** community, where I observed him connect with freelancers. He engages and speaks about their freelance challenges and journey. On the administrative, communication, and positioning side. He highlights pivotal information to become a professional freelance today. In any case, I find it important, for it can remind us of many meaningful things.

For me, it is a good complement to what I am trying to do in this newsletter – discussing topics on various eclectic themes. It brings a different perspective, while also being a space for other Brand Revealers to share their definition of Branding. But also, how they perceive branding in their way of working with clients, as well as their mindset.

For me, it was crucial. I had an AHA moment! I knew it was time. I know it is a combination that I can not overlook anymore. It was no longer possible for me to not integrate it into the newsletter. So, here I am, bringing them one by one.

> There is a **Spanish studio** that sheds light on the difference between marketing and branding very well and in a visually compelling way.
> 
> 
> _**Marketing is like asking someone to come on a date, 
> 
> and Branding is the reason why they say yes and stay!**_
> 
> Visual, right?

**Who are you? What is your profession?**

> My name is **Clément Le Roux**. I am a freelance Community Builder. It involves bringing people together around a project, whether they are clients or collaborators. 
> 
> Typically, communities gather on platforms like _Discord_, _Slac_ k, or _WhatsApp_. That is what sets me apart from a community manager, who primarily focuses on so

*[... truncated, 8,092 more characters]*

---

### Clement Delangue of Hugging Face on building the GitHub of machine learning | The Robot Brains Podcast
*591 words* | Source: **EXA** | [Link](https://shows.acast.com/the-robot-brains/episodes/clement-delangue-hugging-face-on-building-the-github-of-ml)

![Image 1: cover art for Clement Delangue of Hugging Face on building the GitHub of machine learning](https://open-images.acast.com/shows/6053a29a0d11b0148adcfc96/1617091773845-808cfbe200b5e99e0a9deac35e5f0dab.jpeg?height=750)

Clement Delangue of Hugging Face on building the GitHub of machine learning
---------------------------------------------------------------------------

Season 2, Ep.21

•

Wednesday, May 25, 2022

Originally created to be an open domain conversational AI, your own ‘artificial BFF' that you could chat with when your real friends weren’t available — fast forward six years, and [Hugging Face](https://tcrn.ch/3wFlWqV) is the leading [Natural Language Processing](https://www.ibm.com/cloud/learn/natural-language-processing) (NLP) start-up. The company is currently valued at $2B with over 10,000 companies using the open-source AI platform - including Bing, Apple, and Monzo.

Our guest, [Clement Delangue](https://twitter.com/ClementDelangue), CEO of [Hugging Face](https://huggingface.co/), believes in the sustainable long-term benefits of [open-science](https://bigscience.huggingface.co/) and open-source collaboration and has built a community that fosters this goal. And while Hugging Face was initially mainly aimed at NLP, recently it is expanding to more [machine learning](https://www.forbes.com/sites/kenrickcai/2022/05/09/the-2-billion-emoji-hugging-face-wants-to-be-launchpad-for-a-machine-learning-revolution/?sh=5790f99cf732) domains, including computer vision and reinforcement learning.

SUBSCRIBE TO THE ROBOT BRAINS PODCAST TODAY | Visit[therobotbrains.ai](https://www.therobotbrains.ai/)and follow us on YouTube at[TheRobotBrainsPodcast](https://www.youtube.com/c/TheRobotBrainsPodcast), Twitter[@therobotbrains](https://twitter.com/therobotbrains), and Instagram[@therobotbrains](https://www.instagram.com/therobotbrains/).

#### More episodes

[#### View all episodes](https://shows.acast.com/the-robot-brains/episodes)

*   [![Image 2](https://open-images.acast.com/shows/6053a29a0d11b0148adcfc96/1617091773845-808cfbe200b5e99e0a9deac35e5f0dab.jpeg?height=250)](https://shows.acast.com/the-robot-brains/episodes/jitendra-malik-building-ai-from-the-ground-up-sensorimotor-b)[20. Jitendra Malik: Building AI from the ground-up, sensorimotor before language --------------------------------------------------------------------------------](https://shows.acast.com/the-robot-brains/episodes/jitendra-malik-building-ai-from-the-ground-up-sensorimotor-b)
01:15:50|Thursday, August 17, 2023|Season 3, Ep.20

Jitendra Malik, Professor of EECS at UC Berkeley discusses with host Pieter Abbeel building AI from the ground-up and sensorimotor before language. Subscribe to the Robot Brains Podcast today | Visit therobotbrains.ai and follow us on YouTube at TheRobotBrainsPodcast and Twitter at @pabbeel. 
*   [![Image 3](https://open-images.acast.com/shows/6053a29a0d11b0148adcfc96/1617091773845-808cfbe200b5e99e0a9deac35e5f0dab.jpeg?height=250)](https://shows.acast.com/the-robot-brains/episodes/seb-boyer-of-farmwise-ai-that-helps-feed-the-world)[19. Seb Boyer of Farmwise: AI that helps feed the world -------------------------------------------------------](https://shows.acast.com/the-robot-brains/episodes/seb-boyer-of-farmwise-ai-that-helps-feed-the-world)
50:26|Friday, August 11, 2023|Season 3, Ep.19

Seb Boyer of Farmwise discusses with host Pieter Abbeel AI that helps feed the world. Subscribe to the Robot Brains Podcast today | Visit therobotbrains.ai and follow us on YouTube at TheRobotBrainsPodcast and Twitter at @pabbeel. 
*   [![Image 4](https://open-images.acast.com/shows/6053a29a0d11b0148adcfc96/1617091773845-808cfbe200b5e99e0a9deac35e5f0dab.jpeg?height=250)](https://shows.acast.com/the-robot-brains/episodes/john-schulman-of-openai-on-chatgpt-invention-capabilities-an)[18. John Schulman of OpenAI on ChatGPT: invention, capabilities and limitations -------------------------------------------------------------------------------](https://shows.acast.com/the-robot-brains/episodes/john-schulman-of-openai-on-chatgpt-invention-capabilities-an)
42:29|Thursday, August 3, 2023|Season 3, Ep.18

John Schulman, co-founder OpenAI, discusses with host Pieter Abbeel the invention, capabilities, and limitations of ChatGPT. Subscribe to the Robot Brains Podcast today | Visit therobotbrains.ai and follow us on YouTube at TheRobotBrainsPodcast and Twitter at @pabbeel. 
*   [![Image 5](https://open-images.acast.com/shows/6053a29a0d11b0148adcfc96/1617091773845-808cfbe200b5e99e0a9deac35e5f0dab.jpeg?height=250)](https://shows.acast.com/the-robot-brains/episodes/yaniv-altshuler-reducing-cow-methane-emissions-with-ai)[17. Yaniv Altshuler: reducing cow methane emissions with AI -----------------------------------------------------------](https://shows.acast.com/the-robot-brains/episodes/yaniv-altshuler-reducing-cow-methane-emissions-with-ai)
53:49|Wednesday, July 26, 2023|Season 3, Ep.17

Yaniv Altshuler, MIT Media Lab researcher, jo

*[... truncated, 3,077 more characters]*

---

### “A Great Strategy is Only Valuable When Executed Effectively” – An Interview with Clément Lelong
*1,802 words* | Source: **EXA** | [Link](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/)

Dec 12, 2023 9 min read

![Image 1: “A Great Strategy is Only Valuable When Executed Effectively” – An Interview with Clément Lelong](https://room8group.com/wp-content/uploads/2023/12/cover-1-1720x0-c-default.jpg)

Embark on a captivating journey through the dynamic landscapes of the game industry together with Clément Lelong, Head of Art at Solid Bash (by Room 8 Group).

Table of content
----------------

1.   [The Career Journey in Gaming](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-1)
2.   [Strategic Showdown: Strategy vs. Tactics](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-2)
3.   [How a Data-Driven Approach Propels the Creative Process](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-3)
4.   [Hidden Gems of Creativity: Drawing Inspiration from the Unexpected](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-4)
5.   [The Essential Traits that Define a Successful Team](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-5)
6.   [Key Takeaways](https://room8group.com/news/a-great-strategy-is-only-valuable-when-executed-effectively-an-interview-with-clement-lelong/#head-6)

The Career Journey in Gaming
----------------------------

I started my “in gaming” journey at Mattel-Megabrands, a construction toy company, building branding and designing packaging for IPs such as Need For Speed, Skylanders, World of Warcraft, and Call of Duty. The actual gaming experience started at a Montreal-based mobile gaming studio. 2014 was a significant period for mobile gaming, a pivotal moment when the free-to-play business model was emerging and being defined. _The shift from traditional paid games to free-to-play models necessitated rethinking the entire gaming ecosystem: the product, the audience, and the game design._ Starting on a pitch team to support Business Development, I was quickly exposed to the basics of game design, game economy, user experience, and more. The perfect mobile gaming crash course!

After this, I served as the Art Director on Magic: The Gathering Puzzle Quest. Match-three games gained popularity then, and Puzzle Quest started partnering with prominent brands like Magic. Fast forward a couple of years later, I joined my friend and esteemed colleague Benjamin Paquette – current Head of Design at Solid Bash – at Nvizzio. Working on one of Atari’s iconic games, Roller Coaster Tycoon Touch, was an exciting experience for the gamer in me! Then came “Monopoly Tycoon” with Hasbro. Primarily in charge of marketing and UA creatives, my team and I proudly built the brand identity in and out of the game. After Nvizzio, my journey led me to Unity, where I delved deeper into user acquisition, particularly in monetization for casual and hyper casual mobile games. This was when I fully understood the value of creating with data and started working with the machine learning teams to develop analytic tools for creators.

Currently, at Solid Bash, as the Head of Art, I drive a Team of talented Artists for our games and pitches. My main goal is to support the growth of the Art Team – or A-Team as I call ourselves- regarding skills, vision, and cohesion. It’s essential to shift from merely operating as a group of individuals to functioning as a tightly integrated and unified team.

Strategic Showdown: Strategy vs. Tactics
----------------------------------------

One key lesson I’ve garnered from my previous experiences is the paramount importance of strategic thinking, complemented by excellence in tactics. _A great strategy and a vision for the future are only valuable when executed effectively._ A vision that is improper or lacks execution is useless. You need to communicate the vision effectively to the team, ensuring they understand it and know how to contribute to its realization.

I often use the analogy of a plane to illustrate this concept. A good strategy is like a plane flying at 10,000 or 20,000 feet, providing an excellent overall market vision and anticipating potential headwinds. The strategic vision provides direction and guidance to stay on course and to anticipate upcoming challenges. However, you also need the ground team to execute that vision. Without our dedicated and talented Artists, any strategy – no matter how relevant or sharp – would remain just an idea. While our incredible Art Director, Don Toledo, and I provide the vision and the support, the Artists make it real. In any project, turbulence is inevitable, and when faced with intense challenges, it’s crucial to the Team that I provide a sound distance to keep our eyes on the prize. That allows decisions to be made with long-term objectives in min

*[... truncated, 7,486 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
