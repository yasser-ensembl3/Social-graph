# David Lederhendler

## Position actuelle

**Titre** : AI project evaluator
**Entreprise** : IVADO
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Research Services

## Description du rôle

Expertise for investment in AI projects

## Résumé

-- Founder & CEO at Yeji Data Lab, pioneering in cutting-edge technology and AI-driven solutions
-- Tech-driven executive with a focus on innovation, AI strategy, and advanced product management
-- Expert in tech scaling: from talent acquisition and business development to market strategy and product execution
-- Strategist in leveraging AI and machine learning for operational efficiency and data-driven decision making
-- Lead on numerous initiatives in key global markets including Asia, Europe, Middle East/GCC, and the US
-- Recognized speaker at global forums, sharing insights on technology, innovation, and AI
-- Active board member, contributing strategic guidance and leadership

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAKfKSsB0GP7nUnREa_3FPTsJOacxbdlrRE/
**Connexions partagées** : 47


---

# David Lederhendler

## Position actuelle

**Entreprise** : Yeji Data Lab

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# David Lederhendler

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392576721272844289 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHqIYQyQlPxdA/feedshare-shrink_800/B4EZpe1WaWKYAo-/0/1762527636520?e=1766620800&v=beta&t=21YC0D7PGno6k5pmViFJc5tKYJWlvbq1wX9nLGmY1h8 | The AI debate in one (or three) line(s): hockey-stick dreams meet J-curve reality. 

My take -- ship AI models, engineer the plumbing: org design, data quality, training, guardrails. 

Hype fades; compounding sticks. 

https://lnkd.in/euPBbY3W

#AI #Execution #Ops | 14 | 2 | 1 | 1mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:12.602Z |  | 2025-11-07T15:00:37.785Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384500963811680256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6KA2s6ZyLRQ/feedshare-shrink_800/B4EZnsEe1RKYAg-/0/1760602223773?e=1766620800&v=beta&t=Nm6CfoMvOmCOni8kZ7fSH1mv2OTDxdyfYAJ3voUcYI8 | Grateful to have moderated a powerhouse session in Tokyo on how #AI is reshaping planning & design across the built world. 

From generative design and predictive modelling to integrated project workflows, the conversation cut through hype and dug into what’s working now, and what still keeps leaders up at night.

Huge thanks to Rosemarie Lipman and the BuiltWorlds team for bringing everyone together so thoughtfully. 

Key highlights:

 - Global adoption: where Asia and North America are moving in sync, and where they’re not
 - Practical wins: faster decisions, reduced risk, and new creative possibilities in early stages
 - Human element: skills, judgment, and culture as the invisible accelerators (or brakes)
 - What’s next: AI + BIM convergence and constructability-aware workflows

Grateful to our panelists for their candour and insights:

Atul Khanzode (DPR Construction)
Eliot Jones (Trimble Inc. Ventures)
 Dr Takuma Nakabayashi (OBAYASHI CORPORATION)

#AI #AECO #ConstructionTech #Design #BIM #Innovation #Tokyo #BuiltWorlds | 78 | 8 | 3 | 1mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.681Z |  | 2025-10-16T08:10:27.166Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7383866504242692096 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEet-otTJZHDQ/feedshare-shrink_800/B4DZni7HFSH4Ak-/0/1760448772387?e=1766620800&v=beta&t=wMugVWkm1tg6TpEHyBETAcCs9ffE2AjwY3kAfrnotp8 | Proud to have joined this roundtable on the sidelines of GITEX with Minister Evan Solomon and leaders across industry and research. 

The dialogue made one thing clear: Canada’s AI depth is a powerful match for real-world impact in infrastructure, aerospace, supply chains, energy, and healthcare, agriculture, and other key sectors, globally.

At Yeji Data Lab, we’re excited to help turn these partnerships into deployable solutions that drive growth and value for businesses and governments. 

#AI #GITEX | 30 | 0 | 1 | 1mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.682Z |  | 2025-10-14T14:09:20.217Z | https://www.linkedin.com/feed/update/urn:li:activity:7383857347288395776/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7378770693498499072 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEU1Y5wkdIdXg/feedshare-shrink_800/B56ZmZ3SbVHUAg-/0/1759223162687?e=1766620800&v=beta&t=kIrG_OasU4HXUsKA7uNEZjcQ_GhMmefqlqzxnPcNhww | Rami Kiwan   🇨🇦 🇱🇧, thrilled to have been on stage with you for the fireside chat with on AI & digital twins. | 14 | 0 | 0 | 2mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.685Z |  | 2025-09-30T12:40:24.260Z | https://www.linkedin.com/feed/update/urn:li:activity:7378717234585784320/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7378329701184081920 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGE2pndLPie0Q/feedshare-shrink_800/B4EZmUXsaQKQAg-/0/1759130879757?e=1766620800&v=beta&t=Er0C9hD6mNDuRNpBbp1IZwmxv7zHF9o4I1iEpxmVBPc | Honoured to have spoken at Investopia Global on September 25 2025, discussing Artificial Intelligence, Automation & Digital Twins, with Rami Kiwan Senior Economist, Minister's Office UAE Ministry of Economy & Tourism.

This brought together leaders including HE Abdulla Bin Touq, UAE Minister of Economy & Chairman of Investopia, The Hon. Jean Charest, and Premier Danielle Smith, a powerful forum for Canada-UAE collaboration.

Thanks to Investopia, the organizers, my co-panelists, and the audience. A powerful forum for Canada–UAE collaboration. #Investopia #AI #DigitalTwins #CanadaUAE Nour Kechacha | 77 | 3 | 1 | 2mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.685Z |  | 2025-09-29T07:28:03.499Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7376220831632482305 | Article |  |  | Companies can’t stop talking about AI, most still struggle to explain the upside.

Why that gap isn’t surprising:

Companies are used to deterministic systems, software that either works or doesn’t. 

AI behaves probabilistically: it returns a distribution of possible answers rather than a single deterministic response.

That requires new capabilities (robust validation, human-in-the-loop workflows, monitoring, and change management) to turn pilots into reliable, repeatable value.

A Financial Times analysis of hundreds of S&P 500 10‑Ks and earnings calls finds AI mentions soaring. 

Filings skew toward risks, while on earnings calls 374 companies referenced AI in the past 12 months and 87% were wholly positive. 

What stands out:

Clear wins cluster around the AI/datacenter build‑out: energy and industrials (e.g., Caterpillar, Entergy) cite demand tailwinds, and have outperformed the average S&P 500 stock since late 2022. 

Elsewhere, use cases (customer support, testing, asset tracking) are narrow, and adoption hasn’t guaranteed stock outperformance, yet. 

Top concerns dominate filings: cybersecurity (cited by more than half of filers), implementation failure, and legal exposure. 

Reality check: 95% of enterprise genAI pilots fail, often due to weak memory, customization, and low employee uptake. 

Leadership takeaway:

- Start with a P&L‑anchored problem, not FOMO.
- Define success up front (ROI + adoption metrics).
- Invest early in governance and security.
- Pilot small, integrate deeply, then scale. 

https://lnkd.in/eYZa3get | 30 | 0 | 4 | 2mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.687Z |  | 2025-09-23T11:48:09.817Z | https://www.ft.com/content/e93e56df-dd9b-40c1-b77a-dba1ca01e473?accessToken=zwAGP3cam25gkdPpPlbf3ZtAwdO3etuhygHkcw.MEUCIGb-QfCdw3uvRGYTi_KjL2JQ2RPxPmn4fvaYsEf0Y3d7AiEAhcyrmlM0I5um-ewf6pQ7z3PnKYmolica-D5E7G1L0BQ&sharetype=gift&token=a201aa5d-ddba-4bda-9ab9-aadb89320734 |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7359271066893967362 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGS14Ng6_MnRw/feedshare-shrink_800/B4EZiFiCU8HgAk-/0/1754586949894?e=1766620800&v=beta&t=qKbEub-fhiTV5rMKvq1idrAuPcVKffGwLwY5ApTnSes | 🇨🇦🤝🇦🇪 Building Bridges Between Canada and the UAE, through AI and Innovation.

It was an honour to meet H.E. Abdulrahman Ali Almur Ali Alneyadi at the Embassy of the United Arab Emirates in Ottawa.

We had an engaging and forward-looking discussion on how Canada and the UAE can deepen their collaboration in the field of Artificial Intelligence and  innovation ecosystems. 

With Canada's robust AI research talent and the UAE’s bold vision and investment in emerging technologies, there is immense potential to co-create solutions that tackle real-world challenges.

#AI #Innovation #CanadaUAE #TechnologyDiplomacy #InternationalPartnerships | 159 | 0 | 1 | 4mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.693Z |  | 2025-08-07T17:15:50.992Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7350510986518257665 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEllBupAmLDlA/feedshare-shrink_800/B4EZgJCxzzGwAk-/0/1752498382591?e=1766620800&v=beta&t=mrpgnF91WsSKdZb2niRshslWgIkj8uDj4-NtoC73nNE | Deepening International Collaboration on AI and Innovation 🇨🇦🤝🇰🇷

We were proud to attend the inaugural Canada–South Korea Track 1.5 Dialogue on Artificial Intelligence in Seoul last week, in collaboration with the science and technology policy institute (stepi), the Asia Pacific Foundation of Canada, and the Canadian Embassy in Seoul.

This high-level exchange brought together thought leaders from government, academia, and industry to explore:

🔍 The current landscape of cooperation on AI governance
 🚀 New pathways for collaborative innovation and commercialization
 🌏 Opportunities to strengthen AI diplomacy across the Indo-Pacific region

Grateful to Ambassador Tamara Mawhinney for hosting us and to all the participants who made this such a meaningful and forward-looking dialogue. 

This is just the beginning, we’re excited about the potential of sustained international engagement on responsible and strategic AI development.

Special thanks to Vina Nadjibulla, JEEHYE KIM, Amanda Doyle, and Yuko Uchida for driving such an important topic.

Ann Fitz-Gerald, Trevor Kennedy, Stephanie Carvin, Jan De Silva, Sean Mullin, Handol Kim

#CanadaKorea #AIgovernance #ArtificialIntelligence #IndoPacific #TechDiplomacy #CanadaInAsia #ScienceDiplomacy #InnovationPartnerships #YejiDataLab #GlobalAI | 77 | 2 | 1 | 4mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.696Z |  | 2025-07-14T13:06:25.076Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7341781907656900610 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGwC2j-_guJ0Q/feedshare-shrink_800/B4EZeM822xHIAg-/0/1750416453581?e=1766620800&v=beta&t=CPWtxOLhsaT2r7johFYHSwVFehOJz2bu7v7PvH-lEN4 | 🚢 How can we expect quantum computing and AI to impact port cybersecurity?

37% of the ports surveyed by the International Association of Ports and Harbors (IAPH) are adopting AI-led business case solutions in their ports, with only 1% starting to look at quantum computing. What should ports be aware of as they look at these game-changing technologies to improve their operations? Which proactive steps can they take to protect themselves effectively?

Join us as leading voices in tech, data, and maritime innovation come together to tackle one of the most pressing challenges facing global trade: AI & cybersecurity at our ports.

📅 Wednesday, 25 June 2025
 🕓 16:00 BST / 17:00 CEST / 11:00 EST

🎙️ Panelists & Moderator
Gadi Benmoshe - Vice Chair, IAPH Data Collaboration Committee & Managing Director, Marinnovators Consulting
Chloe Rowland - Senior Manager, Data Collaboration, Risk & Resilience, IAPH
Victor Shieh - Strategy and Communications Director - IAPH 
David Lederhendler - Founder & CEO, Yeji Data Lab

https://lnkd.in/emBinbPA

🔹 Hosted by: International Association of Ports and Harbors (IAPH)

Let’s explore how the fusion of AI and quantum computing can help us build resilient, future-ready ports.

#Ports2030 #CyberSecurity #AI #QuantumComputing #MaritimeInnovation #IAPH #SmartPorts #Logistics #SupplyChain | 54 | 2 | 5 | 5mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.698Z |  | 2025-06-20T11:00:10.497Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7338546993310416897 | Article |  |  | It’s encouraging to see the Government of Canada signalling a more strategic and innovation-driven approach to AI. 

While safety and ethical guardrails remain critical, this pivot toward embracing AI’s economic potential sends the right message to the innovation ecosystem.

This evolution is happening in tandem with the rise of organizations like LawZero — an initiative that underscore the need to embed ethics and safety into AI from the ground up, without slowing down progress.

Responsible innovation isn’t about choosing between regulation or growth, it’s about ensuring safe scaling, building AI ecosystems that are both globally competitive and deeply human-centric.

Kudos to everyone helping shape this next chapter in Canada’s AI journey. 

Let’s make it one where prosperity and responsibility go hand in hand.

#AI #EthicalAI #SafeAIFuture #InnovationPolicy #ResponsibleAI

https://lnkd.in/eSABCVjH | 14 | 0 | 1 | 5mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.699Z |  | 2025-06-11T12:45:46.815Z | https://www.theglobeandmail.com/business/technology/article-ottawa-will-focus-more-on-economic-benefits-of-ai-less-on-regulation/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7336010258303053824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHS0vBSHTvdJA/feedshare-shrink_800/B4EZc6pLYfHQAk-/0/1749035563023?e=1766620800&v=beta&t=6ZfodQ8IE0bRMdaGXhUkdxVfZT9BdmrqXp2xJ_ICK0Q | Excited to speak alongside Gadi Benmoshe and Chloe Rowland and engage with the International Association of Ports and Harbors (IAPH) audience on this vital issue. | 19 | 1 | 0 | 6mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.700Z |  | 2025-06-04T12:45:42.059Z | https://www.linkedin.com/feed/update/urn:li:activity:7335986861795909632/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7331374860037726208 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ddd841bf-7365-4d57-8907-90dc7e23315f | https://media.licdn.com/dms/image/v2/D4E05AQGTJ-ZdeI3WIQ/videocover-low/B4EZbtQ1a_HMBk-/0/1747737437121?e=1765778400&v=beta&t=zeXdPT_57ARdbIRiTaUhdJzF85yNeHSuCT335I5-ZI8 | Thank you Victor Shieh!  Always a pleasure chatting with you.

International Association of Ports and Harbors (IAPH) Yeji Data Lab | 10 | 1 | 0 | 6mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.700Z |  | 2025-05-22T17:46:16.991Z | https://www.linkedin.com/feed/update/urn:li:activity:7330542164172509184/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7299675781776003072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEx1nVbEgIG_w/feedshare-shrink_800/B4EZU2oZuzG0Ag-/0/1740378324949?e=1766620800&v=beta&t=lDtDbxGYAaGpXxoe323FGRzI3qIU216im-7_8EowDHM | I had the pleasure of speaking to Georgetown University McDonough School of Business' Executive MBA class in Dubai yesterday.  A fantastic discussion with a deeply engaged and insightful group.

Big thanks to professor Nick Lovegrove and Marwan Al Naqi for the kind invitation—always great to connect with the next generation of global business leaders.

#Dubai #BusinessTransformation #AI

Shuja Ali Alina Sophia A. Jordan Guerguiev Romain Benon Mehdi Mahnam Rahul Rawat Jonathan Yi Kris Brice Saimir Baci Lalit Canaran Max Leca Miguel F. Anjos Loubna Benabbou Blake Richards Gendreau Michel Okan Arslan | 53 | 0 | 0 | 9mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.703Z |  | 2025-02-24T06:25:27.793Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7298392738415194113 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEyut50B0Tmxg/feedshare-shrink_800/B4EZUkZgxoGYAg-/0/1740072423520?e=1766620800&v=beta&t=DMJ2gpvyZaInd-kVEDWEkJwSZ0Txrj_KGUKKFrFxs9Q | Greening Grids Through AI: Unlocking the Future of Energy 

Honoured to have moderated an insightful discussion at the Canada-in-Asia Conference 2025 in Singapore on how #AI is transforming the power sector for a greener, more resilient future.

With a panel of incredible experts—including leaders from academia, industry, and policy—we explored:

✅ AI-driven energy forecasting and grid optimization
✅ Scaling AI solutions beyond pilots to real-world impact
✅ Collaboration opportunities between Canada and Asia in the energy transition

Looking forward to continuing these important conversations and driving impactful AI-powered innovations.

#AI #EnergyTransition #GreeningGrids #CanadaInAsia #Sustainability #SmartGrids

Jeff Nankivell Pierre Pettigrew Laurel West Vina Nadjibulla Jordan Dupuis Alexander King Alexandre Veilleux Hema Nadarajah, Ph.D. Melissa Kennedy Lisa de Wilde Asia Pacific Foundation of Canada | 62 | 2 | 2 | 9mo | Post | David Lederhendler | https://www.linkedin.com/in/davidlederhendler | https://linkedin.com/in/davidlederhendler | 2025-12-08T05:12:18.704Z |  | 2025-02-20T17:27:06.418Z |  |  | 

---



---

# David Lederhendler
*Yeji Data Lab*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 12 |
| Press & Mentions (Google) | 17 |

---

## 📚 Articles & Blog Posts

### [David Lederhendler - Yeji Data Lab | LinkedIn](https://ca.linkedin.com/in/davidlederhendler)
*2025-01-01*
- Category: article

### [LEDERHENDLER, David - Yeji Data Lab - ICCC](https://italchamber.qc.ca/speakers/lederhendler-david-yeji-data-lab/)
*2025-10-01*
- Category: article

### [376: David (Ledge) Ledgerwood: Revolutionizing B2B Sales and Podcasting](https://www.podcastjunkies.com/376-david-ledge-ledgerwood-revolutionizing-b2b-sales-and-podcasting/)
*2025-08-01*
- Category: podcast

### [Understanding AI through Yeji Data Lab’s perspectives](https://yejidatalab.com/blog)
*2023-09-22*
- Category: blog

### [How David "Ledge" Ledgerwood Turns $0 Podcasts Into $150K+ Enterprise Deals - How to Scale a Business](https://scale-business.captivate.fm/episode/how-david-ledge-ledgerwood-turns-0-podcasts-into-150k-enterprise-deals)
*2025-02-18*
- Category: podcast

---

## 🎬 YouTube Videos

- **[Contemporary Antisemitism in the United States: A historical and social background](https://www.youtube.com/watch?v=KZa4PRNPEqE)**
  - Channel: INSS ISRAEL
  - Date: 2021-08-31

- **[&quot;It Should Be Just Like a Photograph&quot;: Collecting Ghetto Songs with Shmerke Kaczerginski](https://www.youtube.com/watch?v=iVEHzOFDtA0)**
  - Channel: Yiddish Book Center
  - Date: 2018-10-04

- **[Plenary: The American Jewish Relationship with Israel: Crisis Point or Opportunity?](https://www.youtube.com/watch?v=R_TcGRZBaCk)**
  - Channel: J Street
  - Date: 2018-04-15

- **[Zionism 3.0 (2016) - Israel in the Minds of American Jews](https://www.youtube.com/watch?v=R7Jb_i7xw7o)**
  - Channel: Oshman Family JCC
  - Date: 2016-09-30

- **[American Jews and Israel: A Relationship in Transition (3/4)](https://www.youtube.com/watch?v=TBXimrm_rL8)**
  - Channel: New York University
  - Date: 2015-09-22

- **[What Is the Jewish Belief About Moshiach?](https://www.youtube.com/watch?v=LJW5SWzHunI)**
  - Channel: Ask My Jewish Question
  - Date: 2022-05-31

- **[Jewish History Lecture Series by Rabbi Dovid Katz Winter 2013 Lecture 13](https://www.youtube.com/watch?v=sg60ar0N0WE)**
  - Channel: Baruch Atta
  - Date: 2014-04-10

- **[2022 Liberty Medal Ceremony Honoring President Volodymyr Zelenskyy (HD)](https://www.youtube.com/watch?v=0tC-lf4Qq0I)**
  - Channel: National Constitution Center
  - Date: 2022-11-09

- **[Annie&#39;s Wedding](https://www.youtube.com/watch?v=tCySC7emL7s)**
  - Channel: Release - Topic
  - Date: 2015-09-13

- **[&#39;Unfortunately, It&#39;s True&#39;: Anti-Semitism on the Rise &#39;Everywhere&#39;](https://www.youtube.com/watch?v=umUxTWs_qVk)**
  - Channel: CBN News
  - Date: 2021-11-03

---

## 🔎 Press & Mentions

- **[David Lederhendler | Asia Pacific Foundation of Canada](https://www.asiapacific.ca/about-us/board-directors/david-lederhendler)**
  - Source: asiapacific.ca
  - *David Lederhendler is Founder and CEO of Montréal-based Yeji Data Lab, an ... Podcast Archive · Publications · Asia Watch · Insights · Dispatches · Re...*

- **[SCALE AI is announcing investments of more than $20 million in 5 ...](https://www.newswire.ca/news-releases/scale-ai-is-announcing-investments-of-more-than-20-million-in-5-ai-projects-for-intelligent-supply-chains-884964329.html)**
  - Source: newswire.ca
  - *Sep 28, 2023 ... Radio & Podcast · Television · Entertainment & Media Overview · View ... From left to right : David Lederhendler (Yeji Data Lab), Sté...*

- **[Who We Are | Asia Pacific Foundation of Canada](https://www.asiapacific.ca/about-us/who-we-are)**
  - Source: asiapacific.ca
  - *Founder, President, CEO, and Chair, Westcap Mgt. Ltd. David Lederhendler headshot. David Lederhendler. Founder and CEO, Yeji Data Lab....*

- **[FINAL TECHNICAL REPORT_ASIA-PACIFIC FOUNDATION OF ...](https://idl-bnc-idrc.dspacedirect.org/bitstreams/a26aeeb5-0470-4c58-bc99-567cf0e88ac7/download)**
  - Source: idl-bnc-idrc.dspacedirect.org
  - *depth side event, and a podcast reaching broader audiences. We are grateful ... • David Lederhendler, Founder and CEO, Yeji Data Lab (Canada). • Bala ...*

- **[Who We Are | Asia Pacific Foundation of Canada](http://www.cwsasiapacific.org/who-we-are.html)**
  - Source: cwsasiapacific.org
  - *Ltd. David Lederhendler headshot · David Lederhendler. Founder and CEO, Yeji Data Lab. Lois Nahirney headshot · Dr. Lois Nahirney. President and CEO, ...*

- **[Untitled](https://www.asiapacific.ca/sites/default/files/filefield/AR_23-24_EN.pdf)**
  - Source: asiapacific.ca
  - *Jul 17, 2024 ... Interview Series. 1. 2. PARTNER NETWORKS. Supporting 2024 Annual Plan ... David Lederhendler. Founder and CEO, Yeji Data Lab. Lois Na...*

- **[APEC Business Advisory Council](https://www.asiapacific.ca/networks/abac)**
  - Source: asiapacific.ca
  - *... David Lederhendler (Yeji Data Lab). | Photo courtesy ABAC Korea. SOM III ... interview series on food security. The meetings concluded with key .....*

- **[Yeji Data Lab Joins the Canada-UAE Business Council - Canada ...](https://canadauaebusinesscouncil.org/yeji-data-lab-joins-the-canada-uae-business-council/)**
  - Source: canadauaebusinesscouncil.org
  - *David Lederhendler, Founder and Chief Executive Officer of Yeji Data Lab ... Conference 2025. October 28, 2025. x. Do you like it? Read more · ADIPEC ...*

- **[Mapping Out the Global Innovation Landscape Conference ...](https://uwaterloo.ca/events/events/mapping-out-global-innovation-landscape-conference)**
  - Source: uwaterloo.ca
  - *David Lederhendler, Founder and Chief Executive Officer, Yeji Data Lab Mark Manantan, Director of Cybersecurity and Critical Technologies, Pacific For...*

- **[Research Track - AI & Machine Learning - BuiltWorlds](https://builtworlds.com/research-track-ai-ml/)**
  - Source: builtworlds.com
  - *In-Person Working Group Session @ BuiltWorlds AI/ML Conference | February 2026 ... EllisDon. david-modified. David Lederhendler. CEO, Yeji Data Lab, I...*

---

*Generated by Founder Scraper*
