# Eric Boyko

## Position actuelle

**Titre** : President, Co-Founder and CEO
**Entreprise** : Stingray
**Durée dans le rôle** : 18 years 11 months in role
**Durée dans l'entreprise** : 18 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Media

## Résumé

A passionate entrepreneur with over two decades of experience developing and scaling start-ups, Eric Boyko is a proven business innovator.  

Mr. Boyko founded and was President of eFundraising.com, an e-commerce success story that became a leading player in the North American fundraising industry. In 2006, he was named one of Canada’s “Top 40 Under 40” for his achievements.  

In May 2007, Mr. Boyko co-founded Stingray Group Inc..  He has served as President since its founding and was named Chief Executive Officer in 2010. A leading B2B, multi-platform music and in-store media solutions provider, Stingray now operates worldwide, reaching an estimated 400 million Pay TV subscribers (or households) in 152 countries. The company completed a successful IPO in June 2015 and is listed on the Toronto Stock Exchange (RAY.A; RAY.B).  

Mr. Boyko also sits on the board of Alimentation Couche-Tard, a global leader in the convenience sector and home to retail brands Couche-Tard, Circle K and Ingo. He is also a member of the Board of Directors of Intelcom Courier Canada Inc. As a committed philanthropist, he serves on the Montréal Canadiens Children’s Foundation’s board of directors. 

Mr. Boyko holds a Bachelor of Commerce degree from McGill University, from which he graduated with great distinction. He is also a Certified General Accountant (CPA). He currently lives and works from his hometown of Montréal, Québec, Canada.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAaWFhwBOujrrfHVhtSWORM_s682jakaYTQ/
**Connexions partagées** : 39


---

# Eric Boyko

## Position actuelle

**Entreprise** : Stingray

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Eric Boyko

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394833687915433984 | Article |  |  | Quel plaisir d'avoir discuté avec Gérald Fillion à Zone Économie sur ICI RDI de notre acquisition de TuneIn!

L'entrevue complète est ici : https://lnkd.in/e86MDw6k | 169 | 8 | 2 | 3w | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:32.977Z |  | 2025-11-13T20:29:00.565Z | https://ici.radio-canada.ca/info/videos/1-10521283/societe-montrealaise-stingray-3e-au-monde-apres-youtube-et-spotify?liste=28-23005 |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394151723105275904 | Article |  |  | What a quarter for Stingray! 🚀 I’m thrilled to share our Q2 results, with revenues soaring 21% to $113.3M and net income more than doubling!
Today marks a pivotal moment for us. I'm ecstatic to announce the second largest acquisition in Stingray's history: TuneIn is joining the family! A warm welcome to CEO Richard Stern and the entire TuneIn team. This transformative move creates a global audio streaming and advertising powerhouse. We're especially excited to leverage TuneIn's comprehensive ad platform, giving advertisers unparalleled access to 75 million highly engaged listeners worldwide.

Quel trimestre exceptionnel pour Stingray ! 🚀 Je suis fier de vous annoncer nos résultats du deuxième trimestre : des revenus en hausse de 21 % pour s'établir à 113,3 M$ et un bénéfice net qui a plus que doublé. Aujourd'hui représente un tournant majeur pour nous. Je suis particulièrement enthousiaste d'annoncer la deuxième plus grande acquisition de l'histoire de Stingray : TuneIn ! Je souhaite la bienvenue au chef de la direction Richard Stern et à toute l'équipe de TuneIn. Cette acquisition donne naissance à un chef de file mondial de la diffusion audio et de la publicité. Nous sommes très heureux de pouvoir intégrer la plateforme publicitaire complète de TuneIn, qui offrira aux annonceurs un accès sans précédent à 75 millions d'auditeurs très engagés partout dans le monde.

https://lnkd.in/e5MEdUVT | 505 | 43 | 35 | 3w | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:32.978Z |  | 2025-11-11T23:19:07.484Z | https://corporate.stingray.com/financial-information/stingray-reports-second-quarter-results-for-fiscal-2026/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7389664315613609984 | Article |  |  | Proud to announce we've acquired DMI. This move expands our footprint to 33,500 locations in North America and makes us the definitive leader in in-store audio advertising for the U.S. pharmacy sector.
 
Fier d'annoncer l'acquisition de DMI. Notre présence passe à 33 500 emplacements en Amérique du Nord, faisant de nous le leader incontesté de la publicité audio en magasin dans le secteur pharmaceutique américain. | 211 | 15 | 7 | 1mo | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:32.979Z |  | 2025-10-30T14:07:46.166Z | https://corporate.stingray.com/acquisitions/stingray-acquires-dmi/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7386402276476678144 | Article |  |  | What a fantastic collaboration! Teaming up with LG Electronics to bring Stingray Music to LG Radio+ takes our global reach to the next level. We're delivering the best music experience to even more listeners around the world. Incredible work by everyone involved!

Quelle fantastique nouvelle ! Je suis tellement fier de notre partenariat avec LG Electronics qui propulse Stingray Musique sur la scène mondiale avec LG Radio+. Nous allons offrir la meilleure expérience musicale à des millions de nouveaux auditeurs. Un immense bravo à toute l'équipe pour ce succès phénoménal ! | 93 | 3 | 6 | 1mo | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:35.193Z |  | 2025-10-21T14:05:35.430Z | https://www.advanced-television.com/2025/10/21/lg-radio-adds-stingray-music/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7383847639647424512 | Article |  |  | I'm thrilled to announce our partnership with Just For Laughs Distribution. This is a natural fit, combining their world-class content with Stingray's global reach. Two Canadian powerhouses joining forces to bring laughter to millions of new viewers worldwide. A big congratulations to both teams for making this happen.
 
Je suis fier d'annoncer notre partenariat avec Just For Laughs Distribution. Une collaboration naturelle entre deux leaders canadiens pour faire rayonner le meilleur de l'humour sur la scène mondiale. En combinant leur contenu exceptionnel à notre réseau de distribution global, nous allons rejoindre des millions de nouveaux fans. Bravo aux équipes pour ce superbe travail. | 142 | 8 | 5 | 1mo | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:35.193Z |  | 2025-10-14T12:54:22.547Z | https://corporate.stingray.com/products-and-services/just-for-laughs-stingray-partnership/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379540620815785984 | Article |  |  | We're moving FAST. Proud to team up with TELUS again to bring seven new, free Stingray channels to homes across Canada. Congratulations to both teams for making it happen.
 
Stingray en mode FAST. Fiers d'approfondir notre partenariat avec TELUS en lançant sept nouvelles chaînes pour les téléspectateurs canadiens. Bravo aux équipes qui ont rendu ce projet possible. | 132 | 7 | 3 | 2mo | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:37.238Z |  | 2025-10-02T15:39:49.237Z | https://corporate.stingray.com/products-and-services/stingray-telus-7-new-fast-channels/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7371590025299509248 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGO4igvuWFYrg/feedshare-shrink_800/B56Zk0CAKTI0Ag-/0/1757514566800?e=1766620800&v=beta&t=h3rHfceKmFyzHuIIbQUzoDEbp7GctoKE8p7FqwuaiS0 | This is the future! I'm thrilled that Stingray is providing the music for the incredible Zoox robotaxi service in Las Vegas. We're all about enhancing life's moments, and now riders can enjoy a vast selection of our music to match their journey. Congratulations to the entire Zoox team on this game-changing launch. We're excited to be along for the ride. | 70 | 6 | 1 | 2mo | Post | Eric Boyko | https://www.linkedin.com/in/eric-boyko-47800a31 | https://linkedin.com/in/eric-boyko-47800a31 | 2025-12-08T05:17:37.239Z |  | 2025-09-10T17:06:59.551Z | https://www.linkedin.com/feed/update/urn:li:activity:7371550384303058944/ |  | 

---



---

# Eric Boyko
*Stingray*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 29 |

---

## 📚 Articles & Blog Posts

### [Eric Boyko - Investors & Press](https://corporate.stingray.com/team/eric-boyko/)
*2025-05-02*
- Category: article

### [Q&A with Stingray’s Eric Boyko](https://www.broadbandtvnews.com/2015/03/10/qa-with-stingray-digitals-eric-boyko/)
*2015-03-10*
- Category: article

### [Eric Boyko](https://en.wikipedia.org/wiki/Eric_Boyko)
*2024-07-04*
- Category: article

### [Eric Boyko - Stingray | LinkedIn](https://ca.linkedin.com/in/eric-boyko-47800a31)
*2024-02-08*
- Category: article

### [Eric Boyko: Stingray's entrepreneur à go-go-go](https://www.theglobeandmail.com/report-on-business/careers/careers-leadership/eric-boyko-stingrays-entrepreneur-a-go-go-go/article4887145/)
*2012-11-02*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Montreal's Stingray Group buys audio streamer TuneIn for up to ...](https://www.theglobeandmail.com/business/industry-news/article-montreals-stingray-group-buys-audio-streamer-tunein-for-more-than-175/)**
  - Source: theglobeandmail.com
  - *Nov 11, 2025 ... Eric Boyko, CEO of Stingray, has said his vision is to be the in-car ... Stingray's stable of curated playlists, as well as radio and...*

- **[Music Choice Acquisition or Stingray's patent defense? | Edwin ...](https://edwinhernandez.com/2018/08/08/music-industry-updates-music-choice-acquisition-or-patent-defense/)**
  - Source: edwinhernandez.com
  - *Aug 8, 2018 ... Eric Boyko, president and CEO of ... podcast PTAB software startups stingray digital streaming tech techedtv technology uspto wireless...*

- **[Eric Boyko - Investors & Press](https://corporate.stingray.com/team/eric-boyko/)**
  - Source: corporate.stingray.com
  - *Eric Boyko. President, Co-Founder and CEO. An entrepreneur with nearly ... Stingray Digital Media Group in Canada, the United States of America and/or...*

- **[Stingray acquires 30% stake in The Podcast Exchange (TPX ...](https://broadcastdialogue.com/stingray-acquires-30-stake-in-the-podcast-exchange-tpx/)**
  - Source: broadcastdialogue.com
  - *Mar 6, 2020 ... ... podcast market thus supplementing our radio and digital audio products,” said Eric Boyko, president, co-founder, and CEO of Stingr...*

- **[Eric Boyko - Top podcast episodes](https://www.listennotes.com/top-podcasts/eric-boyko/)**
  - Source: listennotes.com
  - *Apr 10, 2019 ... Eric Boyko (born 1970) is a Canadian tech entrepreneur and the founder, president and CEO of digital music provider Stingray Digital....*

- **[Stingray to acquire TuneIn - Broadcast Dialogue](https://broadcastdialogue.com/stingray-to-acquire-tunein/)**
  - Source: broadcastdialogue.com
  - *Nov 11, 2025 ... ... Stingray President & Co-Founder Eric Boyko. “We are crafting an ... Radio + Podcast · TV + Film · Online · Tech · General News · ...*

- **[Stingray Acquires TuneIn, Creating an Audio Streaming and ...](https://podnews.net/press-release/stingray-tunein)**
  - Source: podnews.net
  - *Nov 11, 2025 ... ... Eric Boyko, President, Co-founder, and CEO of Stingray. “We are crafting an unmatched audio ecosystem by merging Stingray's exten...*

- **[Inside The TuneIn-Stingray Combination: How The Deal Came ...](https://www.insideradio.com/free/inside-the-tunein-stingray-combination-how-the-deal-came-together/article_aea44cac-32b0-480d-9c04-4339920afbf9.html)**
  - Source: insideradio.com
  - *Nov 17, 2025 ... TuneIn's growing business initially had it pointing toward acquisitions, but discussions with Stingray CEO Eric Boyko shifted the equ...*

- **[On n'a pas tout dit - Podcast - Apple Podcasts](https://podcasts.apple.com/kn/podcast/on-na-pas-tout-dit/id1769427650)**
  - Source: podcasts.apple.com
  - *Listen to Cogeco Média's On n'a pas tout dit podcast on Apple Podcasts ... PDG de Stingray, Eric Boyko commente l'importante acquisition réalisée par ...*

- **[Montreal-based media company Stingray sees karaoke taking over ...](https://www.theglobeandmail.com/business/article-stingray-car-karaoke/)**
  - Source: theglobeandmail.com
  - *Aug 11, 2025 ... CEO Eric Boyko says his company is well-positioned to become the ... Manufacturers sell ads on Stingray channels and the revenue is t...*

---

*Generated by Founder Scraper*
