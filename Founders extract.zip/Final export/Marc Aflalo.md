# Marc Aflalo

## Position actuelle

**Titre** : Digital Media Consultant: Spot On Entertainment Inc. (SuperDogs)
**Entreprise** : SuperDogs
**Durée dans le rôle** : 15 years 11 months in role
**Durée dans l'entreprise** : 15 years 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Entertainment

## Description du rôle

Marc Aflalo provided live production support and technical consulting for the President’s Choice SuperDogs, a nationally recognized entertainment group combining canine agility with theatrical performance. Working closely with show directors and technical teams, Marc helped modernize the show’s audiovisual experience—supporting remote workflow integration, sound design, and live show logistics across touring venues.

His contributions helped streamline tech operations, improve show consistency across locations, and enhance audience engagement through better sound and visual synchronization. Whether in stadiums or exhibition halls, Marc ensured that every show ran flawlessly—delivering high-quality entertainment in fast-paced, live environments.

## Résumé

Broadcast & Podcast Production Executive | Live & Remote Workflow Specialist | Media Consultant | Accessibility-Focused Storyteller

I’m a media executive with 30+ years of experience producing and delivering high-quality content across radio, television, podcasts, and digital platforms. My background blends live broadcast operations, remote podcast production, and creative content strategy—anchored by deep technical expertise and a “no problem” mindset.

As the head of Aflalo Communications Inc., I’ve led end-to-end productions for major broadcasters, including SiriusXM, AMI, and XM Canada, as well as global brands across sports, tech, and accessibility. I specialize in:
	•	Remote and hybrid production workflows (vMix, IP audio/video, Riverside, NDI, Dante)
	•	Podcast creation, editing, and distribution at scale
	•	Live event streaming and real-time media delivery
	•	Accessible content development for diverse audiences
	•	Technical direction, team leadership, and operations strategy

Whether it’s a live broadcast, a multi-cam podcast, or a fully remote workflow, I thrive on solving complex production problems and delivering content that connects—on time, on budget, and with impact. I’m especially passionate about integrating new tools (AI, automation, cloud-native systems) to simplify media creation and scale storytelling in smarter ways.

Let’s connect if you’re building something ambitious—podcasts, shows, streams, or systems—and want a steady hand to help bring it to life.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABkYZIBRgULLXMoGWPTd2nelIYXXCDirkA/
**Connexions partagées** : 17


---

# Marc Aflalo

## Position actuelle

**Entreprise** : Aflalo Communications Inc.

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Marc Aflalo
*Aflalo Communications Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [Marc, Author at Aflalo Communications Inc.](https://aflalo.com/author/marc/)
- Category: article

### [5 Things You Should Do To Become a Thought Leader In ...](https://medium.com/authority-magazine/marc-aflalo-of-aflalo-communications-5-things-you-should-do-to-become-a-thought-leader-in-your-6490a0c693db)
- Category: blog

### [Podcasting as the New Thought Leadership Platform](https://aflalo.com/podcasting-as-the-new-thought-leadership-platform/)
*2025-08-20*
- Category: podcast

### [Top Tech Tidbits Podcast](https://open.spotify.com/show/6IWvTWpzsZMedagnH0hLVq)
- Category: podcast

### [Overcoming Podcasting Fears: Lack of Confidence](https://aflalo.com/overcoming-podcasting-fears-lack-of-confidence/)
*2025-08-23*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Podcast Strategy for Engaging Content Creation](https://aflalo.com/)**
  - Source: aflalo.com
  - *Aflalo Communications Inc. Menu. Consulting · Blog · Marc Aflalo · Contact. Full ... Marc Aflalo on SiriusXM'ss Original VJ Podcast". Marc was an INTE...*

- **[Marc Aflalo - Podcast Editor, TV Host, Producer and Content Creator](https://aflalo.com/marc-aflalo/)**
  - Source: aflalo.com
  - *Marc Aflalo is a distinguished podcast producer and editor, celebrated ... ABOUT AFLALO COMMUNICATIONS INC. Aflalo Communications Inc. is a broadcast ...*

- **[Marc Aflalo - President, Aflalo Communications Inc. | Intch](https://intch.org/4861767)**
  - Source: intch.org
  - *Marc Aflalo. President @Aflalo Communications Inc. TVYouTubeAudio ProductionSound engineerEntertainmentJournalistProducerActor Influencer or BloggerVi...*

- **[YourTechReport - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/yourtechreport/id948401741)**
  - Source: podcasts.apple.com
  - *Listen to Aflalo Communications Inc., Double Tap Productions, Marc Aflalo, Mitchell Whitfield's YourTechReport podcast on Apple Podcasts....*

- **[A Game-Changing Partnership: Double Tap, Mind Vault Solutions ...](https://at-newswire.com/double-tap-mind-vault-aflalo-comms-top-tech-tidbits-forge-global-access-partnership/)**
  - Source: at-newswire.com
  - *May 1, 2025 ... ... Aflalo Communications, Inc ... Marc Aflalo as the broadcast engineer with more satellite uplinks than most news networks....*

- **[EPISODE 16: Terry David Mulligan — Erica Ehm](https://www.ericaehm.com/reinvention-of-the-vj/2021/2/15/episode-16-terry-david-mulligan)**
  - Source: ericaehm.com
  - *Feb 15, 2021 ... Editing and coordination, Aflalo Communications Inc. Copyright ... Marc Aflalo February 22, 2021 · Next. EPISODE 15: Natalie Richard....*

- **[Best Consumer Electronics Podcasts (2025)](https://player.fm/podcasts/Consumer-Electronics)**
  - Source: player.fm
  - *Aflalo Communications Inc., Double Tap Productions, Marc Aflalo, Mitchell Whitfield. icon 11. icon 540. icon. Subscribe. Unsubscribe. icon. 9 days ago...*

- **[Best Product Reviews Podcasts (2025)](https://player.fm/podcasts/Product-Reviews)**
  - Source: player.fm
  - *Aflalo Communications Inc., Double Tap Productions, Marc Aflalo, Mitchell Whitfield ... Techstination interview: Innovative backpacks and tech gear fr...*

- **[Best Consumer Protection Podcasts (2025)](https://player.fm/podcasts/consumer-protection)**
  - Source: player.fm
  - *Each episode, Auditor Keith will interview a different member of ... Aflalo Communications Inc., Double Tap Productions, Marc Aflalo, Mitchell Whitfie...*

---

*Generated by Founder Scraper*
