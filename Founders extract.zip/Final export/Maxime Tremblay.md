# Maxime Tremblay

## Position actuelle

**Titre** : Président et fondateur
**Entreprise** : Fin Finaud Consultant
**Durée dans le rôle** : 20 years 8 months in role
**Durée dans l'entreprise** : 20 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Créateur du logiciel de gestion d'entreprise La Casserole.
Heureux dirigeant d'une équipe de 10 personnes ultras compétentes.

## Résumé

An entrepreneur since 1992 (before the Internet! 😂), I've worn many hats: graphic designer, amateur photographer, programmer, UX designer... and father!
Passionate about entrepreneurship, I've also been sharing my experience as a mentor with Réseau Mentorat for the past ten years.

For my first company, I concocted La Casserole, then Casserole Nova, and now Casserole.pro, a management software designed for service companies juggling a thousand projects and billing fees. With La Casserole, you keep all the ingredients (budgets, milestones, costs and invoices...) in a single dish, without breaking your head too much - and it simmers like a charm!

My company, Fin Finaud Consultant, is 100% dedicated to the development and promotion of Casserole.pro, an even tastier rewrite of Casserole Nova, but entirely online.

Want to lighten your project management load?
Let's talk over a cup of coffee (virtual or real) and see how Casserole.pro can help you reinvent the way you work.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACIc5gB32sDqyNoGeGmkuCkF6EBQttt_S4/
**Connexions partagées** : 29


---

# Maxime Tremblay

## Position actuelle

**Entreprise** : Casserole.pro

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Maxime Tremblay

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402455740788998144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFcrmmZyT_uIw/feedshare-shrink_800/B4EZrrORRFKcAg-/0/1764882978268?e=1766620800&v=beta&t=qsRaL6g0NilscGQMpxRqrOWnAuHvZ8M2DqYjJrrggLk | Je vous partage un petit truc qui me fait gagner pas mal de temps.

Depuis un certain temps, j'utilise l'application MacWhisper pour créer les sous-titres des vidéos YouTube que je prépare pour mon application Casserole.pro. Dans une mise à jour, ils ont ajouté une fonction de dictée. Je l'ai essayé et j'ai été un peu déçu de la qualité du texte que cela produisait.

Récemment, en fouillant un peu plus loin dans les paramètres de l'application, j'ai constaté qu'on peut dicter des choses à MacWhisper et qu'ensuite MacWhisper envoie cela à notre AI préféré pour nous retourner un texte mieux présenté, mieux formaté et mieux écrit. La beauté de la chose, c'est qu'on peut éditer le prompt pour faire en sorte que le texte soit vraiment bien adapté à ce qu'on souhaite avoir.

Par exemple, dans mon cas, je nomme souvent l'application Casserole.pro ou Casserole Nova, et à peu près tous les systèmes de dictée ne l'écrivent pas de la bonne façon parce que cela ne fait pas partie de leur dictionnaire. Mais là, je peux éditer mon prompt à Gemini pour qu'il puisse vraiment écrire le nom de mes applications de la bonne façon.

Je raffine mon prompt depuis quelques semaines et j'en viens à une productivité vraiment étonnante, où je peux répondre à de longs courriels et à de longues demandes d'assistance avec des explications détaillées et claires, en dictant simplement mon message. D'ailleurs, ce billet LinkedIn a été écrit complètement de cette façon. Je l'ai simplement dicté à l'ordinateur et il a été formaté comme ça. | 9 | 3 | 0 | 3d | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.820Z |  | 2025-12-04T21:16:19.581Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397385232867512320 | Text |  |  | J'ai un nouveau problème... et je l'adore.

La partie que je préfère de ma job, c'est celle où je vous montre à quel point Casserole.pro peut vous faire gagner du temps.

Sauf que là... c'est moi qui n'ai plus de temps !

Pour la première fois de l'histoire de la Casserole, mon agenda de la semaine prochaine est 100% plein. Plus aucune place pour une nouvelle démo.

C'est un sentiment incroyable de voir que notre travail porte ses fruits et que le bouche-à-oreille fonctionne.

Si vous voulez voir à quoi ressemble la plateforme qui rend mon agenda si chargé, il faudra patienter une petite semaine de plus.

Premier arrivé, premier servi pour la semaine d'après ! 👇 | 31 | 2 | 0 | 2w | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.821Z |  | 2025-11-20T21:27:56.287Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394841821954347010 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH4l4wPOqgwIg/feedshare-shrink_800/B4EZp_BdAsIwAk-/0/1763067679224?e=1766620800&v=beta&t=-qEXxyx1ykGFVTAgHh_CXrp3yVXabUk4FibEciPDEaU | Bien triste nouvelle. Quand tu t'impliques durant des années, bénévolement... ça crée un sentiment d'appartenance. Je sais que le mentorat (au sens large) n'est pas mort, mais je suis quand même fâché.

Croire aux entrepreneurs, c'est un élément essentiel pour avoir mon vote. | 44 | 17 | 2 | 3w | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.821Z |  | 2025-11-13T21:01:19.871Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394364607965962240 | Text |  |  | On jase. Mettons.

Avec les dérapages qui s’enchaînent dans les projets informatiques gouvernementaux, je me demande sérieusement : est-ce qu’il ne serait pas temps d’avoir un vrai «Ministère de l’infrastructure technologique» ?

On en a un pour les routes, un pour la santé, un pour les forêts. Pourquoi pas un pour le numérique ?

Imagine un ministère qui documente les meilleures pratiques, qui crée des fondations communes, qui s’assure que les systèmes puissent se connecter entre eux. Une sorte de «bureau des normes technos du Québec», quoi.

Pas nécessairement eux qui codent. Mais au moins, une tête qui définit les choses correctement.

Qu’en pensez-vous ? | 14 | 10 | 0 | 3w | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.822Z |  | 2025-11-12T13:25:03.190Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7389263853244657665 | Text |  |  | Les temps sont durs ? L’incertitude flotte dans l’air ? Vos clients sont hésitants ?

À mes yeux, c’est le moment parfait pour peaufiner sa gestion.

Je pense (bien évidemment) à un logiciel centré sur les coûts de projets et la rentabilité.

Parce que lorsque le vent souffle de face, vaut mieux avoir le bon équipement. | 7 | 0 | 0 | 1mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.822Z |  | 2025-10-29T11:36:28.497Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7388555582019932160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvICaWINB1yw/feedshare-shrink_800/B4EZolr71OKcAg-/0/1761568866252?e=1766620800&v=beta&t=ooLbYXWgGY39RErxlyY7AV1-kbt-93uq2O6CeiNJm_0 | On a divisé… pour mieux régner sur vos projets 😄 | 2 | 0 | 0 | 1mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.823Z |  | 2025-10-27T12:42:03.478Z | https://www.linkedin.com/feed/update/urn:li:activity:7388555346006396929/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7386035170648276992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvrKgwSTtwpQ/feedshare-shrink_800/B4EZoB32UtHoAg-/0/1760968009698?e=1766620800&v=beta&t=KoizSnKNKe7Uq8G22AnpYVUUwJsB-7o_y8-z5E5DBh0 | Chez Casserole.pro, on a nos chevaliers du code.

Et aujourd’hui, je te présente Raphaël, développeur frontend, alias le preux défenseur de l’expérience utilisateur.

Dans son univers, les bugs sont des dragons, les lignes de code sont des quêtes, et son destrier préféré… c’est une moto de trail. 🏍️💨

Entre deux batailles de pixels, il forge les interfaces de Casserole.pro pour qu’elles soient aussi efficaces que belles.

Son portrait complet (et son parcours de chevalier du clavier) est à découvrir dans notre blogue.

⬇️ Lien dans le premier commentaire ! | 5 | 1 | 0 | 1mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.823Z |  | 2025-10-20T13:46:50.580Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7384932011829952512 | Text |  |  | S’il y a une leçon que j’ai apprise en plus de 30 ans d’entrepreneuriat, c’est celle-là : garde ça simple.

Oui, tu pourrais tout faire toi-même.
Tu pourrais vouloir tout contrôler.
Mais tu finirais par t’épuiser à gérer… au lieu de créer.

Avec les années, j’ai compris que simplifier, c’est faire confiance.
Faire confiance à ton équipe.
Faire confiance à tes partenaires.
Et, parfois, faire confiance à des outils qui font très bien le travail à ta place.

Chez nous, par exemple, on confie nos paiements récurrents, la gestion des taxes et la sécurité des cartes à Paddle.
Pour le soutien client et notre base de connaissances, c’est Intercom.
Ces services sont simples, fiables, et surtout… ils nous libèrent du temps.

C’est exactement dans cet esprit qu’on développe Casserole.pro :
un outil simple, efficace et digne de confiance.
Un allié à qui tu peux confier tes projets, ta facturation, tes calculs de rentabilité.

Parce qu’au fond, simplifier, ce n’est pas en faire moins.
C’est se concentrer sur ce qui compte vraiment : tes clients, ta créativité et ton plaisir d’entreprendre.

Et si on en jasait ? | 12 | 1 | 0 | 1mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.824Z |  | 2025-10-17T12:43:17.022Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7382135535366062081 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgs-0CT2qM-w/feedshare-shrink_800/B4EZnKdJoyIkAk-/0/1760038264064?e=1766620800&v=beta&t=12Ddmw9UBfo9Ybl1rklsfHJD-b5aSZj-30icWFVsjZY | Derrière Casserole.pro, il y a un bon designer.

Cette personne, c’est Simon Ronsmans.
C’est lui qui transforme nos idées (parfois un peu farfelues 😅) en une expérience fluide, claire et agréable pour les entrepreneurs qui utilisent notre outil au quotidien.

Mais je vais être honnête : ce n’est pas la job la plus reposante du monde.
Parce qu’une bonne partie de nos clients… sont eux-mêmes designers ! 😬
Imagine un chef qui cuisine pour d’autres chefs. Simon, lui, conçoit des interfaces pour des gens qui savent exactement où les icônes devraient être.

Et malgré la pression, il réussit à livrer un produit élégant, efficace et (surtout) apprécié par ceux qui ont l’œil le plus critique. L'avez-vous essayé ?

Dans notre plus récent article de blogue, on lui donne la parole :
https://lnkd.in/eWhgNr4G

Toi, tu ferais confiance à un designer… pour impressionner des designers ? 😅 | 14 | 2 | 0 | 1mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:28.824Z |  | 2025-10-09T19:31:05.077Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7379537209961664512 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEQ_qoMZjtuCQ/feedshare-shrink_800/B4EZmlh_KBHcAo-/0/1759418775343?e=1766620800&v=beta&t=jgThdWr6LHks1rXGyYvIit1Mfktn2x5viNVWjqNpLIg | Durant mes 34 ans de vie d’entrepreneur, j’ai beaucoup aimé… chacune de mes gangs.

Avec le recul, je me demande si ce n’est pas ce que je préfère dans l’aventure entrepreneuriale : former des équipes.

Rien ne me fait plus plaisir que de voir un groupe de beaux cerveaux travailler ensemble, débattre, chercher la meilleure idée, puis finir par trouver une solution qui fait « wow ». (Et fêter ça en levant leurs verres) 😉

Ma gang actuelle est spéciale. Comme on est en télétravail 99 % du temps, on ne partage pas souvent le café ni de lunch d’équipe du vendredi… mais ça ne nous empêche pas d’être soudé.

Une gang dédiée au meilleur de Casserole.pro

Et j’en suis fier. 💙

👉 Venez les découvrir ici : https://lnkd.in/eAQAPj9A | 20 | 2 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.834Z |  | 2025-10-02T15:26:16.026Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7377374648411250688 | Text |  |  | Postes Canada en grève : plus de courrier livré.

Tu veux savoir l’impact que ça a sur ma famille ou sur mon entreprise?
Aucun. Zéro. Nada. Mais, ça bouscule ma tête d'entrepreneur... et de contribuable.

Il y a 20 ans, une grève de Postes Canada, ça pouvait paralyser bien du monde. 

Ça confirme une chose : les temps changent, et si une entreprise n’évolue pas… elle se fait dépasser. | 23 | 12 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.834Z |  | 2025-09-26T16:13:01.174Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7376226896826564608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEsvSG7m4r5Cw/feedshare-shrink_800/B4EZl2fRmNIUAk-/0/1758629534848?e=1766620800&v=beta&t=q2QCTuhludANbaCwt5AYl6mIrGfb1FokJJoAup2U1ws | Cette semaine, ma grande fille aura 20 ans (c’est fou). Elle vient de commencer sa première année d’université. Et moi (avec mon diplôme d'étude secondaire), je suis assez admiratif de sa détermination.

Bien sûr, elle a déjà eu plusieurs emplois étudiants. Et disons que… ça n’a pas toujours été facile. La chance n'a pas été de son côté question «bons patrons». Tsé, ce genre de boss-là :

- Ceux qui font des horaires basés sur le favoritisme, la jalousie ou la rancune.
- Ceux qui se mettent à deux dans un bureau pour lui reprocher des broutilles.
- Ceux qui ne reconnaissent pas les bons coups et les efforts.

On a eu plusieurs conversations sur le sujet et l’autre jour, elle m’a dit que le mieux pour elle serait peut-être… d’être son propre patron. Comme sa mère. Comme son père. Comme son grand-père (qu’elle n’a pas connu).

Je vous avoue que je ne la pousserai jamais dans cette direction. La vie d’entrepreneur, ce n’est pas toujours un conte de fées.

Mais boswell que ça m’a fait plaisir de l’entendre. Parce que moi, malgré les tempêtes, j’aime profondément ma vie d’entrepreneur. Et si un jour elle trouve la même joie dans cette aventure, je serai le père le plus fier du monde. | 41 | 4 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.835Z |  | 2025-09-23T12:12:15.872Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7375911626333659136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8jKrLvFIHxg/feedshare-shrink_800/B4EZlyAiKYIkAg-/0/1758554368124?e=1766620800&v=beta&t=hP-27pruOf-fRDs3A-gocV26jjWjsXAlqcmuPyRXLY8 | 🚀 Nouvelle version de Casserole.pro = nouvelles astuces pour mieux gérer tes projets !

On a préparé deux petites vidéos pour te montrer concrètement les nouveautés :
👉 Les grilles de tarifs intelligentes (6 min)
👉 La gestion des coûts simplifiée (5 min)

Promis, pas de blabla technique inutile, juste des démos claires pour que tu voies comment ça peut vraiment t’aider dans ta business.

Tu veux jeter un coup d’œil ? Les vidéos sont dans le premier commentaire.

Et si tu veux en jaser ou planifier une démo rapide, écris-moi directement ! 😉 | 4 | 1 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.836Z |  | 2025-09-22T15:19:29.529Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7372349056276123648 | Text |  |  | J’avais prévu une escapade pour aujourd’hui (c'était dans mon agenda) : la course de vélo à Québec, suivie du match des Capitales en soirée, tout ça avec mon vieux chum Christian.

Mais ce matin, en regardant ma liste de tâches, j’ai pris une décision « raisonnable » : rester travailler. 🙄

Là, il fait un soleil radieux. Je regarde la course d'un oeil sur mon troisième écran. Et moi, je regrette. Je regrette de ne pas m’être offert cette journée. Quel con je suis!

Parce qu’au fond, ça aurait changé quoi dans ma vie, de décrocher pour quelques heures ? Une journée de grand air, de jasette avec un chum, de sport et de fun… je pense que mon hamster aurait carburé encore mieux lundi matin.

Être entrepreneur, c’est souvent dire « non » à ce genre de petits bonheurs, au nom de l’efficacité. Mais parfois, on se prive pour rien. | 6 | 0 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.836Z |  | 2025-09-12T19:23:06.638Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7371979906752335872 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFq9hgCSaLRMw/feedshare-shrink_800/B56Zk6IqO7G0Ag-/0/1757616973851?e=1766620800&v=beta&t=IoJ630Km3OFXXLIzApYDYX8_X-6RzlbBv4kI9lCkk6s | Traitez-moi de vieux si vous voulez… mais je m’ennuie de l’époque d’avant le télétravail.

Bien sûr, je reconnais les avantages :
- Je n’ai plus de voiture depuis 3 ans.
- Je fais le trajet maison-bureau en 15 secondes.
- Le café du bureau est aussi bon que celui de la maison.
- Je suis probablement plus productif.

Mais… Les jours où j’enfile les Zoom, ça me manque :
- De serrer la pince d’un client.
- D’aller boire un verre avec un collègue après le boulot.
- Aller luncher avec un client et visiter ses bureaux.

Je sais bien que ça ne reviendra pas comme avant. Je fais mon deuil. Mais je me demande quand même : quelle sorte de société sommes nous est en train de construire, sans ces petits moments humains qui donnaient du relief à nos journées ? Les habiletés sociales des futures générations ?

Et vous ? Est-ce que ça vous manque un peu… ou pas du tout ?
Et je le dis : Oui, je suis partant pour un lunch. (pour vrai) | 12 | 17 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.837Z |  | 2025-09-11T18:56:14.533Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7370828986794528768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFksXdYdFZj7Q/feedshare-shrink_800/B4EZkpx5wJHEAg-/0/1757342572395?e=1766620800&v=beta&t=81wO5wsc_W07XMPPzSZ15xSVUxlS85IPveebT2fE7Og | Entrepreneur depuis 35 ans… sans jamais porter de cravate. 👔

J’ai commencé comme graphiste : jeans, t-shirt, parfois un hoodie si j’avais froid.

Ensuite, direction le monde de l’informatique, avec l’aura « startup » (où une paire de Converse fait office d’uniforme).

J’ai fréquenté des conférences de PDG, des colloques bien guindés, rencontré des politiciens, serré des mains dans des bureaux où tout le monde avait la cravate bien nouée… sauf moi.

Et pourtant… zéro cravate.
Je n’en possède pas une seule.

Et, si tu m’en prêtes une… je devrai aller sur YouTube pour savoir comment faire le nœud.

Même pas pour un mariage. Même pas pour des funérailles.

Ce n’est pas moi.

Je crois profondément à l’authenticité. Et j’ai besoin d’être moi-même.
Si je me déguise en « homme d’affaires » avec complet et cravate, ça ne marche plus.

Parce qu’au fond, mieux vaut un gars en t-shirt qui dit ce qu’il pense… qu’un gars en complet qui joue un rôle.

P.S. L’image a été générée avec Nano Banana… et j’ai l’impression de voir un croque-mort avec la même tête que moi ! 😂 | 61 | 22 | 0 | 2mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.838Z |  | 2025-09-08T14:42:53.832Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7368992163717677057 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQECWPEJRLIDnQ/feedshare-shrink_800/B4EZkPrU3FGcAo-/0/1756904640456?e=1766620800&v=beta&t=KMZn0C4f_s8S24fCN-uAo2XT5Xkk-h6nf95XNQ5Cq0c | Yeah 🎉 Casserole.pro souffle sa première bougie !
On a lancé l’application dans les derniers jours d’août 2024. Honnêtement, il fallait être un peu baveux pour se lancer dans un marché déjà bien occupé par des géants (avec des produits solides).

Mais on y croyait. Et on y croit encore.
On savait qu’il manquait quelque chose pour les entrepreneurs dans le secteur des services : un outil simple, efficace, qui aide à bâtir une entreprise solide et rentable. Parce que jongler avec plusieurs projets en parallèle, on sait à quel point ça peut devenir un sacré casse-tête.

En un an, on a sorti plusieurs nouvelles versions, ajouté des dizaines de fonctionnalités, et surtout, grandi grâce aux retours de nos utilisateurs. 🙏

Le plus beau là-dedans ?
Casserole.pro est 100 % québécois, pensé et développé ici à Montréal, avec une qualité de service exceptionnelle.

Alors aujourd’hui, j’ai envie de lancer deux invitations :
➡️ Viens jeter un œil à ce qu’on fait : casserole.pro
➡️ Si ce n’est pas pour toi, pense à partager l’info avec quelqu’un de ton réseau que ça pourrait aider.

Parce qu’une bonne casserole, ça se partage ! 🍲 | 23 | 0 | 0 | 3mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.839Z |  | 2025-09-03T13:04:01.084Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7363573756843159552 | Text |  |  | Mon aventure SEO… version entrepreneur autodidacte

Au départ, j’ai fait le choix de garder tout le budget pour développer Casserole.pro. J’aurais aimé faire affaire avec des pros pour le site web et le SEO (et y en a plein dans nos clients), mais… c’est moi qui m’y suis collé.

Ça n’a pas été instantané (loin de là 😅). J’ai eu besoin de :
➡️ Quelques rencontres avec des experts (merci Philippe, merci Yannick)
➡️ Passer des heures à lire, visionner des vidéos, demander à ChatGPT de résumer des articles
➡️ M’abonner à des outils pour suivre les performances

Pendant longtemps, les résultats étaient… disons, tranquilles. Puis, petit à petit, ça a commencé à bouger. Et là, je le vois : notre trafic monte, Casserole.pro apparaît dans de plus en plus de recherches (même sur Perplexity 🤩).

Ça me rend fier. Parce que oui, c’est un peu mystérieux le SEO, mais avec de la persévérance, ça finit par fonctionner.

Être entrepreneur, c’est exactement ça : faire face, apprendre vite, s’adapter et jouer l’homme-orchestre. Pis, je le dis simplement : c’est bien un aspect qui me plait beaucoup dans la vie d’entrepreneur.

Et mes oreilles sont grandes ouvertes, as-tu des conseils pour moi ? Pour pousser encore plus loin mes résultats SEO ? 👂🏻 | 22 | 13 | 0 | 3mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.840Z |  | 2025-08-19T14:13:12.216Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7361118062990827520 | Text |  |  | Je suis un homme de 55 ans, père de famille, entrepreneur, animé de plusieurs passions et pourtant... depuis 3 ans, je n'ai plus de voiture. Voici un bilan. | 40 | 11 | 2 | 3mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.840Z |  | 2025-08-12T19:35:09.177Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7360642916056190976 | Text |  |  | J'ai fait une salle de bain pour la première fois de ma vie, pis j'ai aimé ça. Je raconte l'histoire et je vous parle de la fois où j'ai filmé mes fesses ! | 8 | 0 | 0 | 3mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.840Z |  | 2025-08-11T12:07:05.320Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7358921706087882752 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHupNkGuVRLeQ/feedshare-shrink_800/B4EZiAkS6aGYAg-/0/1754503655514?e=1766620800&v=beta&t=9cyQtaplsbarDdSwsUMijbVU2Qb4NEeGxi7Dy6LW0IM | 20 ans pour Fin Finaud… et je suis encore là ! 😄

En 2005, j’ai lancé Fin Finaud Consultant avec une idée un peu floue… mais une envie très claire : aider les entreprises à mieux gérer leurs projets.

Au début, c’était «pas mal» bricolé. FileMaker, des idées plein la tête et un vieux nom de logiciel né d’un concours interne douteux : La Casserole.

20 ans plus tard, je suis encore debout (et la Casserole aussi). Elle a changé de forme, de techno, d’équipe… mais pas d’ADN. On a maintenant Casserole.pro, un outil fait pour les entreprises de services, testé, peaufiné, aimé par des centaines d’utilisateurs.

Mais au fond, ce que j’ai le plus construit, c’est une entreprise à taille humaine, une gang soudée, des clients avec qui on jase pour vrai… et un projet qui me motive chaque matin.

Alors merci à tous ceux qui ont embarqué dans l’aventure (collègues, collaborateurs, partenaires et clients), depuis 2005 ou depuis hier.

20 ans, c’est vieux pour une startup. Mais pour une bonne casserole, c’est juste assez pour que ça commence à coller un peu au fond… et que ça goûte meilleur. 😉

👇 Pour les curieux, j’ai raconté toute l’histoire ici – lien dans le premier commentaire ! | 68 | 14 | 1 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.841Z |  | 2025-08-06T18:07:36.885Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7358910673642213376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHoVtiTctwuyw/feedshare-shrink_800/B4EZiAaQnoHEAg-/0/1754501025321?e=1766620800&v=beta&t=ny34lDwJX2_VjvPZDfp8cKJys09hhyejU4V-uUKPxu4 | Je suis passé chez mon marchand de «rafraîchissements estivaux» ce midi et je n'ai pu m'empêcher d'acheter celle-ci. Ceux et celles qui ont déjà utilisé Casserole.pro (ou une autre itération) comprendront la référence. ⚾️

Et mes salutations à une de mes microbrasseries préférées : Sir John (à Lachute) | 5 | 0 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.842Z |  | 2025-08-06T17:23:46.545Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7356782190451388420 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFlbayqJAU_3Q/feedshare-shrink_800/B4EZhiKah_GcAE-/0/1753993555519?e=1766620800&v=beta&t=MvPc80MoRIDKDe8xx1MhqfWm4f7_-61u43soSw-5FXQ | Hier, j’ai passé la journée à l’Omnium Banque Nationale, au parc Jarry, en compagnie d’un ami… qui n’est pas pantoute un client! J’étais là pour décrocher, pour respirer, pour passer un bon moment. Profiter du spectacle et des émotions d’un bon match. Pis ouais, le dernier match de Genie était fou! Le stade vibrait vraiment fort quand elle a brisé son adversaire au début de 3e set.

Mais je dois avouer que ça m’a aussi fait réfléchir… Non pas à brasser des affaires, ou à réseauter (je vois tellement de billets LinkedIn sur ça que ça me fait un ti-peu rouler des yeux… en tout respect!). Non, simplement réfléchir à l’importance de décrocher. Tout ce qu’on fait n’a pas besoin d’être relié aux affaires, non?

Bien sûr, quand je croise un client par hasard et qu’il me parle de Casserole.pro, je suis toujours heureux d’en discuter! Il va de soi qu’en tout temps et en tout lieu, je suis toujours partant pour parler de notre bébé. Mais il faut savoir laisser ses affaires à la maison de temps en temps.

Alors je lance ça comme ça : on a aussi le droit d’aller voir un match, jouer au golf ou à la pêche sans forcément en faire un événement d’affaires… tellement inspirant. Juste pour le simple plaisir.

Ha oui. J’ai aussi pris quelques photos.
📷 Celle-ci, je l’aime bien. | 11 | 2 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.842Z |  | 2025-07-31T20:25:56.607Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7356061436659343360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGLA4UtdTALJQ/feedshare-shrink_800/B4EZhX6483HEAk-/0/1753821714237?e=1766620800&v=beta&t=gTyHGza9SJnlfDfL01aQ9jc6HRrP03OjmQJ4sZeYH6U | Rester à Montréal tout l’été ? Plus le fun que tu penses.

Depuis que ma fille est assez grande pour travailler tout l’été (et se payer ses vêtements), on a adopté une formule qui nous va à merveille : on part en vacances hors-saison, et on passe l’été à Montréal.

Et franchement, c’est dur à battre :
🎣 Les weekends de pêche en début d’été,
🎇 Un soir de feux d’artifice,
🚴 Du vélo aux aurores,
🎾 Une soirée au tournoi de tennis,
⚾ Un match de baseball à Québec,
🏊 Des baignades chez les amis de banlieue,
🏡 Des escapades aux chalets de nos amis.

Les festivals, les terrasses, les soirées improvisées… on ne s’ennuie pas.

Et côté travail ?

Pendant que tout le monde est en vacances, j’avance. Je reprends les dossiers mis de côté, je remplace les collègues en vacances, je prends le temps de réfléchir. Je me permets même de finir plus tôt certains jours — pour mieux flâner en regardant les étoiles... pour trouver les meilleures idées pour Casserole.pro.

Et j’en profite pour préparer la nouvelle année financière, qui commence le 1er septembre chez nous. C’est mon moment de planification, de réajustements, de vision à long terme.

Et si tu passes par Montréal cet été… je suis là. Toujours content de sortir de ma tanière. 🦊

Partant.e pour un café, un verre, un lunch ? | 12 | 5 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.843Z |  | 2025-07-29T20:41:55.512Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7352069477468889089 | Text |  |  | Liberté 55 ? Nooooon… mais oui (aussi).

Demain, j’aurai 55 ans. Suis-je libre ? Financièrement… pas encore. Mais dans ma vie d’entrepreneur ? Oui. Et pas à peu près.

J’ai façonné ma vie pour pouvoir choisir : mes projets, mes clients, mon horaire. Dire non. Dire oui. Aller travailler en forêt chaque année. Partir pêcher dès que possible. Jouer ma guitare. Bricoler une belle pièce de bois. Travailler fort… et relaxer fort. Parce que les deux, c’est essentiel.

Mais ma plus grande fierté, c’est pas ma business. C’est de regarder ma grande fille de 19 ans devenir une adulte resplendissante, brillante, drôle et engagée. Elle me challenge, elle m’inspire… et elle me garde jeune d’esprit (même quand mes genoux me rappellent le chiffre 55).

C’est cette liberté-là que j’ai construite. Celle d’avoir du sens, des projets, du plaisir… et des humains formidables autour de moi.

Alors non, je ne prends pas ma retraite demain. Mais je prends une grande respiration, un petit verre ce soir… et je souris en me disant : je suis pas mal bien, là. | 48 | 3 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.844Z |  | 2025-07-18T20:19:18.274Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7349157161458900996 | Article |  |  | Si je disais que je rêvais de ce jour depuis au moins 10 ans. Une vraie App Casserole.pro 😍📱🚀 | 19 | 0 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.845Z |  | 2025-07-10T19:26:48.029Z | https://www.casserole.pro/mobile |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7349049520460095489 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHRPsg9niTUXw/feedshare-shrink_800/B56Zf0Rl2zG0Ag-/0/1752149942999?e=1766620800&v=beta&t=lXrSLNbHfNuSlWq5xnw0AqCzs4WnJ7f-g_rMM5wIG_Q | Mon cockpit de juillet : un rythme plus lent, du soutien client… et un quatrième écran pour le Tour de France en direct !

Chaque été, c’est pareil : je réorganise mon bureau pour ajouter un 4ᵉ écran. Pas pour surveiller mes KPI. Pas pour faire plus de productivité, non non. Pendant que mes collègues profitent de leurs vacances bien méritées, c’est moi qui prends la relève à l’assistance-client de Casserole.pro. Et entre deux courriels de soutien, j’ai toujours un œil sur les exploits des meilleurs cyclistes du monde.

Ma passion pour le Tour a commencé il y a une vingtaine d’années, quand ma fille était bébé. On se levait tôt, elle avec son biberon, moi avec les paysages de la France sur la télé. Au début, je regardais pour les châteaux, les villages et les montagnes. Et puis, je me suis fait prendre au jeu. Les attaques, les échappées, les alliances tactiques… j’suis devenu fan fini.

Le Tour me donne un rythme doux pour ce mois plus calme. Je jongle entre les demandes d’utilisateurs et les cols de haute montagne, et honnêtement, c’est un combo qui me plaît pas mal. Mais si je prends trois minutes de plus à répondre aux courriels… c’est peut-être que Pogacar vient d’attaquer dans l’Alpe d’Huez. 😄

P.S. Oui, c’est mon vrai bureau sur la photo.
P.S.S. J’ai encerclé le 24 juillet dans mon agenda : une étape de montagne qui promet du grand spectacle (et qui risque de me rendre un brin distrait pendant l’assistance, je vous préviens 😅).

D’autres fans du Tour dans la salle ? | 9 | 2 | 0 | 4mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.845Z |  | 2025-07-10T12:19:04.415Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7347615465164210178 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQG-a7LRdgGzpQ/image-shrink_800/B4EZff5QRaHYAc-/0/1751808018428?e=1765778400&v=beta&t=9iCW8aSKBVvA8ledpTKZOOSNwxTYlvAPOI6rOY3UJvs | Mon fond d’écran présentement : une photo prise lors de mon récent voyage en Islande. (Il s’agit du célèbre geyser Strokkur dans la vallée de Haukadalur) un rappel de ces délicieux moments passés en Islande, un pays qui m’a vraiment fasciné.

Cette image évoque bien plus que des paysages grandioses, je suis resté curieux d’une certaine richesse apparente pour un si petit pays : 
▸ Population : seulement ~390 000 habitants (équivalent à Laval). 
▸ Infrastructures publiques étonnantes : de belles routes (mais pas parfaites), 70 km de tunnels, des écoles modernes et … des piscines municipales partout. 
▸ On compte entre 120 et 160 piscines publiques à travers le pays (y en a 27 à Laval). 
▸ À raison d’une piscine environ pour 2 000 habitants, elles ne sont pas seulement des lieux de baignade : c’est un coeur social, un point de rencontre intergénérationnel (et elles sont bien chaudes).
▸ Pourtant l’Islande n’a pas de pétrole ni de mines, mais une géothermie abondante — couplée à un bon modèle de gestion des flux touristiques (environ 2M de visiteurs/an). 
▸ Le revenu par habitant en Islande est d’environ 67 300 USD alors qu’au Canada, c’est autour de 53 400 USD (en 2023).

C’est quoi la «recette magique» ? Juste une bonne gestion ? Ils ont une bonne industrie touristique, la pêche et 3 alumineries… mais ça n’explique pas tout.

Ça donne envie d’un «état d’esprit islandais» ici : 
▸ Utiliser l’énergie locale propre (géothermie là-bas, hydro-électricité ici). 
▸ Offrir des infrastructures publiques accessibles, bien réparties, et encourageant le lien social. 
▸ Planifier pour que tourisme + qualité de vie coexistent.

Bref, si on pouvait envoyer quelques politiciens «en stage» là-bas, on repartirait peut-être avec de bonnes idées pour nos villages, nos écoles, nos hôpitaux , nos routes !

… et je me dis que je pourrais faire une adaptation «en islandais» de Casserole.pro pour ne donner un bon prétexte pour y retourner ! 😉 | 7 | 1 | 0 | 5mo | Post | Maxime Tremblay | https://www.linkedin.com/in/maxime-finfinaud | https://linkedin.com/in/maxime-finfinaud | 2025-12-08T05:20:32.846Z |  | 2025-07-06T13:20:38.989Z |  |  | 

---



---

# Maxime Tremblay
*Casserole.pro*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [](https://medium.com/@maxime_tremblay/why-did-i-decide-to-rewrite-la-casserole-for-the-web-e1017461979f)
- Category: blog

### [The Real Maxime Podcast](https://rss.com/podcasts/therealmaxime/)
*2022-11-22*
- Category: podcast

### [Maxime-tremblay - maxime-tremblay.com : Maxime Tremblay | Gamer, Technophile, Podcasteur, Formateur, Papa](https://maxime-tremblay.com.clearwebstats.com/)
*2017-01-04*
- Category: article

### [Is a home inspection a pre-purchase must? | Mortgages Planners](https://www.planipret.com/en/broker/maxime-tremblay/post/is-a-home-inspection-a-pre-purchase-must)
*2024-03-01*
- Category: article

### [Profiles & Interviews](https://ourtheatrevoice.com/profiles/)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Why did I decide to rewrite La Casserole for the web? | by Maxime ...](https://medium.com/@maxime_tremblay/why-did-i-decide-to-rewrite-la-casserole-for-the-web-e1017461979f)**
  - Source: medium.com
  - *Feb 21, 2025 ... Written by Maxime Tremblay · 187 followers. ·169 following. Fin Finaud. Casserole.pro. Photosmax....*

- **[Les 3 piliers d'une bonne gestion de projet | Casserole.pro](https://www.casserole.pro/blogue/les-trois-piliers-de-la-gestion-de-projet)**
  - Source: casserole.pro
  - *Aug 4, 2025 ... Maxime Tremblay, chef de produit pour Casserole.pro et président de Fin Finaud Consultant inc., développe des logiciels de gestion dep...*

- **[Centre d'aide Casserole.pro](https://help.casserole.pro/fr/)**
  - Source: help.casserole.pro
  - *Ce qu'il faut savoir pour utiliser Casserole.pro. Maxime Tremblay avatar. Par ... Vous trouverez ici de l'aide à l'utilisation de votre Casserole.pro ...*

- **[Pourquoi le suivi du temps de travail est vital pour la rentabilité de ...](https://www.casserole.pro/blogue/suivi-temps-travail-rentabilite)**
  - Source: casserole.pro
  - *Pourquoi le suivi du temps de travail est vital pour la rentabilité de votre entreprise Casserole.pro. Maxime Tremblay-. 2 mai 2025. Gestion de projet...*

- **[Calculating net and gross margins in project mode … really? | by ...](https://medium.com/@maxime_tremblay/calculating-net-and-gross-margins-in-project-mode-really-16262e825055)**
  - Source: medium.com
  - *Dec 12, 2018 ... Get Maxime Tremblay's stories in your inbox. Join Medium for free to ... Casserole.pro. Photosmax. Montréal. Famille. Photos. Vins .....*

- **[Suivi du temps de travail : simplifier la gestion des feuilles de temps](https://www.casserole.pro/blogue/mesurer-le-temps-est-important)**
  - Source: casserole.pro
  - *Sep 22, 2025 ... Maxime Tremblay, chef de produit pour Casserole.pro et président de Fin Finaud Consultant inc., développe des logiciels de gestion de...*

- **[Préparatifs avant décollage | Centre d'aide Casserole.pro](https://help.casserole.pro/fr/collections/6856019-preparatifs-avant-decollage)**
  - Source: help.casserole.pro
  - *Ce qu'il faut savoir pour utiliser Casserole.pro. Maxime Tremblay avatar. Par Maxime1 auteur 5 articles. Comment démarrer une période d'essai....*

- **[Qu'avez-vous fait le 19 janvier 2017? | by Maxime Tremblay | Medium](https://medium.com/@maxime_tremblay/quavez-vous-fait-le-19-janvier-2017-8041da9201b1)**
  - Source: medium.com
  - *Aug 15, 2018 ... ... article à tous vos collègues des types B et C… même au ... Written by Maxime Tremblay · 187 followers. ·169 following. Fin Finaud...*

- **[Oui, c'est possible de survivre aux feuilles de temps! | by Maxime ...](https://medium.com/@maxime_tremblay/oui-cest-possible-de-survivre-aux-feuilles-de-temps-c9eccb997388)**
  - Source: medium.com
  - *Aug 6, 2018 ... Casserole.pro. Photosmax. Montréal. Famille. Photos. Vins. Whisky. Vélo. Plaisir. No responses yet. More from Maxime Tremblay ... Blog...*

---

*Generated by Founder Scraper*
