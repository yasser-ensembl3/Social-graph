# Michal Seta

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Lab148
**Durée dans le rôle** : 2 years 9 months in role
**Durée dans l'entreprise** : 2 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT System Design Services

## Résumé

Michal Seta is a composer, improviser and researcher in Digital Arts. A transdisciplinary, transcalar and integrative magic practitioner, he incites Metalab's software in a collective and improvised harmony.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAOncvIBrBVe7bSrSHmoO8Fc3oiKz50rrP4/
**Connexions partagées** : 1


---

# Michal Seta

## Position actuelle

**Entreprise** : Lab148

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Michal Seta

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397052958305103872 | Video (LinkedIn Source) | blob:https://www.linkedin.com/65a2b64f-d5bd-4993-9456-874269bbd35a | https://media.licdn.com/dms/image/v2/D4E05AQG8Q3lcwQWltg/videocover-low/B4EZqdjrz7GYBQ-/0/1763579970232?e=1765785600&v=beta&t=0TmEw9EK2U3qy56yLE3SD1ZJfT8xG7s_bQt3J7gUZu0 | C'est la saison des formations autour des IAs auto-hébergées. N'hésitez pas! | 1 | 0 | 0 | 2w | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:42.664Z |  | 2025-11-19T23:27:35.858Z | https://www.linkedin.com/feed/update/urn:li:activity:7396990540933734400/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394758435604537344 | Article |  |  | C'est paradoxal que les features les plus cool de Splash soient le moins connues. Ce poste en révèle deux ou trois... | 5 | 0 | 0 | 3w | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:42.664Z |  | 2025-11-13T15:29:59.016Z | https://see.lab148.xyz/w/9PP17K16eHUSG29pRzVUdQ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386008649217003520 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFbANNvIy3Ibg/feedshare-shrink_800/B4DZn8T_plJEAg-/0/1760874726395?e=1766620800&v=beta&t=9coqtCOAHrVys-9Gtw-fz37Lh6fO3LMRXqTe1y8OjuE | Ce mercredi, Emmanuel Durand et moi, pour vous. | 8 | 0 | 0 | 1mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.099Z |  | 2025-10-20T12:01:27.378Z | https://www.linkedin.com/feed/update/urn:li:activity:7385796896029765632/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7386007877934608384 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGpgkmxDbvNNA/feedshare-shrink_800/B4EZoBfBbWIwAw-/0/1760961501950?e=1766620800&v=beta&t=0nf-hg6N959woDA6em9RRszaJtPa8MRVedtK-e-wVxQ | Rejoignez-moi et Emmanuel Durand ce mercredi pour une classe techno autour des IA auto-hébergées, version Lab148. 

La programmation complète: https://lnkd.in/eSzeMAR8 | 12 | 0 | 0 | 1mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.099Z |  | 2025-10-20T11:58:23.490Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7366594084892733440 | Text |  |  | Nouvelle série. En semaine, cette fois-ci, pour les gens qui ne pouvaient pas être présents les fins de semaines lors de la première saison. | 3 | 0 | 0 | 3mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.101Z |  | 2025-08-27T22:14:54.538Z | https://www.linkedin.com/feed/update/urn:li:activity:7366167552047202304/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7361766078693142528 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEia1b9Yba3cA/feedshare-shrink_800/B4EZikaXXYGYAg-/0/1755105034577?e=1766620800&v=beta&t=H9j4bgTt11pm_VCjbHMONF0lkRGym-xfqsWbRiu4HdA | Nouvelle saison, nouvelle série d'ateliers! | 12 | 0 | 0 | 3mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.102Z |  | 2025-08-14T14:30:08.160Z | https://www.linkedin.com/feed/update/urn:li:activity:7361444073800441856/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7345497576676220928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXr6FBPmSxxw/feedshare-shrink_800/B4EZebf3.TG4Ao-/0/1750660514154?e=1766620800&v=beta&t=orC0C6WvEe9uA8QaXcgQbcVL0TZ1yv3j30UlGQc-Yes | Nous sommes fiers d'être parmi les premiers membres fournisseurs de AQLL! | 12 | 0 | 0 | 5mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.104Z |  | 2025-06-30T17:04:55.025Z | https://www.linkedin.com/feed/update/urn:li:activity:7343967528525721600/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7338673201339613184 | Article |  |  | ça commence maintenant, et il n'est pas encore trop tard. | 0 | 0 | 0 | 5mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.105Z |  | 2025-06-11T21:07:17.154Z | https://www.meetup.com/mtlbug/events/307925450 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7333162593450135556 | Video (LinkedIn Source) | blob:https://www.linkedin.com/440fdda4-ff80-4191-b52c-a6bc507b3ef8 | https://media.licdn.com/dms/image/v2/D4E05AQE8_MVfdT_yIw/videocover-high/B4EZcRxWlhHYBs-/0/1748349842867?e=1765785600&v=beta&t=thlA3lMx6UEJGAlOE_-osjY0-WipERHpuHwzLruStcw | Le temps d'une autre formation s'approche! Les inscriptions sont ouvertes. N'hésitez pas à communiquer avec nous pour plus amples informations. | 2 | 0 | 0 | 6mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.106Z |  | 2025-05-27T16:10:05.851Z | https://www.linkedin.com/feed/update/urn:li:activity:7333110747574517760/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7331732469609607169 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHqRvVB5S1I5w/feedshare-shrink_800/B4DZb9zu1iG8Ak-/0/1748014920591?e=1766620800&v=beta&t=K1RWx3lONxxp60op9wTdRJcJy48EHzl5i2eFhyumFBA | Ça commence ce soir, et la pluie ne sera pas un obstacle! | 2 | 0 | 0 | 6mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.107Z |  | 2025-05-23T17:27:17.757Z | https://www.linkedin.com/feed/update/urn:li:activity:7331705983825588224/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7331009897305694209 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ba76a824-4d6b-4734-b30a-88338b42319b | https://media.licdn.com/dms/image/v2/D4E05AQGNMrjnvZwyoA/feedshare-thumbnail_720_1280/B4EZby3ENvGUAw-/0/1747831244332?e=1765785600&v=beta&t=yNxmpASIQF-JbFTLGW8sBa9bZmkhLNUzfmqwZNoPmN8 | Remember Mimoidalaube, the videogame piece I did for T-Stick (the thing on my head you see in my profile picture)?  Well, I adapted it for multiperson interaction via computer vision (part of the Lab148 in-house interaction system). Second part coming soon... | 16 | 2 | 1 | 6mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.109Z |  | 2025-05-21T17:36:03.095Z | https://www.linkedin.com/feed/update/urn:li:activity:7330935676365922304/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7330367485214355457 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE3lzXqlfbxaw/feedshare-shrink_800/B4EZbLoRISGQAk-/0/1747173053754?e=1766620800&v=beta&t=DM4bf7rfQdniKUhC00bMJGoIcc1k4AvfWq76YDFDKSY | J'ai hâte! | 5 | 0 | 0 | 6mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.110Z |  | 2025-05-19T23:03:20.117Z | https://www.linkedin.com/feed/update/urn:li:activity:7328174937003732994/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7327189413266939904 | Text |  |  | Yesterday, it came to my attention, that David Cope has passed on May 4, 2025. What gave me an extra spook, was the fact, that I had mentioned him, and his EMI (Experiments in Musical Intelligence) system, on that very day in the workshop on #AI, that I was conducting with my colleague.
I first learned of David Cope through Douglas Hosftaeder, when he was invited to speak at McGill, when I was a student there, way back towards the end of the previous century. He even presented one of his "musical Turing tests", where a pianist would play two pieces, one, a piece of a well-known classical composer (I believe it was Prokofiev in that particular experiment), and the other composed in that composer's style by EMI. The audience voted for which was composition was genuine, and the vote was not conclusive. Cope was mainly interested in the notion of a composer's "style." 
This news made me revisit some literature by him and about his work. What I learned this time around, is that in 2005 he has destroyed EMI's entire database of musical features that characterized the studied composers. One of the reasons for this, was that those who appreciated EMI's scores did not consider them as #music, but as computer output. They were devalued, because they were infinitely reproducible. I found that decision, and the reason, particularly interesting in the light of today's hype about AI. | 14 | 4 | 1 | 6mo | Post | Michal Seta | https://www.linkedin.com/in/michal-seta-92a64518 | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.114Z |  | 2025-05-11T04:34:48.719Z |  |  | 

---



---

# Michal Seta
*Lab148*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Nicolas Bouillot Email & Phone Number | Lab148 Co-Founder Contact Information](https://rocketreach.co/nicolas-bouillot-email_93571354)
*2025-01-01*
- Category: article

### [News](https://matralab.hexagram.ca/news/page/27/)
*2025-01-01*
- Category: article

### [Life after PhD with Michal Boháč, entrepreneur and angel investor](https://www.ceitec.eu/life-after-phd-with-michal-bohac-entrepreneur-and-angel-investor/a5099)
*2025-04-05*
- Category: article

### [Teaching Soft Skills with Science in VR Labs, with Labster CEO Michael Jensen - XR for Learning](https://xrforlearning.io/teaching-soft-skills-with-science-in-vr-labs-with-labster-ceo-michael-jensen/)
*2023-12-07*
- Category: article

### [S.Hrg. 117-722 — NOMINATION TO THE FEDERAL ...](https://www.congress.gov/event/117th-congress/senate-event/331161/text)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[SELF-HOSTED AI](https://www.easternbloc.ca/post/self-hosted-ai)**
  - Source: easternbloc.ca
  - *Apr 16, 2025 ... May 4, 2025 | Michal Seta & Emmanuel Durand. https://shorturl.at/ngZca ... AI Conference - Lab148....*

- **[(PDF) Live Ray Tracing and Auralization of 3D Audio Scenes with ...](https://www.researchgate.net/publication/352330278_Live_Ray_Tracing_and_Auralization_of_3D_Audio_Scenes_with_vaRays)**
  - Source: researchgate.net
  - *... Lab148. Nicolas ... A Scalable Haptic Floor Dedicated to Large Immersive Spaces. February 2019. Nicolas Bouillot · Michal Seta....*

- **[L'intelligence artificielle, partenaire de création scénique](https://www.ledevoir.com/culture/881536/intelligence-artificielle-partenaire-creation-scenique)**
  - Source: ledevoir.com
  - *May 20, 2025 ... Article. Pourquoi faire confiance au Devoir ? L'intelligence ... Michal Seta, artiste et cofondateur de Lab148. On peut aussi mesurer...*

- **[Arts de la scène: Créer avec l'intelligence artificielle, mais pas à n ...](https://www.ledevoir.com/culture/theatre/882439/comment-creer-facon-ethique-ia)**
  - Source: ledevoir.com
  - *May 22, 2025 ... L'artiste Michal Seta croit aussi que la réflexion sur l'éthique et l'utilisation responsable de l'IA est fondamentale. Cofondateur d...*

---

*Generated by Founder Scraper*
