# Thane Calder

## Position actuelle

**Titre** : Founder, Chairman
**Entreprise** : CloudRaker
**Durée dans le rôle** : 25 years 11 months in role
**Durée dans l'entreprise** : 25 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Digital Missions for the AI Era: We help companies turn complexity into clarity—with digital products, platforms, and AI-powered solutions that deliver real-world results.

Trusted by Bristol-Myers Squibb, Merck, RBC, L’Oréal, Organon, eBay, Servier, Santé Québec, Dialogue Health, The Fertility Partners, Novo Nordisk, TripAdvisor, Stubhub, Kijiji and more, we specialize in building secure, scalable experiences across:

Health & Pharma
Finance & Insurance
Public & Utilities
Food & AgTech
High-Tech Marketplaces

## Résumé

Serial entrepreneur and investor focused on digital and AI. Passionate about creatively making disruptive technology useful. My core business belief is that a good company culture is all about giving a sh*t.

Specialties: breaking stupid rules, celebrating failure (even if it hurts), thriving on collaboration, and holding the door for others.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABqVj8BwdedOakIjDvIT_-0e0LmfndMR2s/
**Connexions partagées** : 128


---

# Thane Calder

## Position actuelle

**Entreprise** : CloudRaker

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Thane Calder
*CloudRaker*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Thane Calder – Medium](https://medium.com/@thanecalder?source=read_next_recirc---------3---------------------b472fc48_dc0b_4890_aef1_48f98037654e-------)
*2021-11-08*
- Category: blog

### [CloudRaker | LinkedIn](https://ca.linkedin.com/company/cloudraker)
*2024-07-15*
- Category: article

### [The evolution of healthcare integrations in the cloud age (Podcast Tester) - Calian Health](https://health.calian.com/blogs/the-evolution-of-healthcare-integrations-in-the-cloud-age-podcast-tester/)
*2025-06-04*
- Category: podcast

### [Reflections on the Cloud Evolution (with special guest)](https://thecloudcast.net/2024/08/reflections-on-cloud-evolution-with.html)
*2024-08-01*
- Category: article

### [Expansion  Podcast: The Death of Rollup Costs | Matt Katz, Caldera - Blockworks](https://blockworks.co/podcast/expansion/84677f2c-933e-11ef-acca-232a85fbfbcc)
*2024-10-26*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Thane Calder, Founder of CloudRaker - The CEO Series with ...](https://www.iheart.com/podcast/962-the-ceo-series-with-mcgill-84791643/episode/thane-calder-founder-of-cloudraker-301325208/)**
  - Source: iheart.com
  - *Oct 19, 2025 ... This week on The CEO Series, Karl Moore speaks with Thane Calder, Founder and Chairman of CloudRaker. ... Music, radio and podcasts, ...*

- **[The CEO Series with McGill's Karl Moore - Émission - Apple Podcasts](https://podcasts.apple.com/ca/podcast/the-ceo-series-with-mcgills-karl-moore/id1356596659?l=fr-CA)**
  - Source: podcasts.apple.com
  - *Écoutez le podcast The CEO Series with McGill's ... This week on The CEO Series, Karl Moore speaks with Thane Calder, Founder and Chairman of CloudRak...*

- **[The CEO Series with McGill's Karl Moore | Podcast on Spotify](https://open.spotify.com/show/5ZeMcn6sXasPyNib6xaorx)**
  - Source: open.spotify.com
  - *Thane Calder, Founder of CloudRaker. This week on The CEO Series, Karl Moore speaks with Thane Calder, Founder and Chairman of CloudRaker. Thane share...*

- **[The CEO Series with McGill's Karl Moore - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/the-ceo-series-with-mcgills-karl-moore/id1356596659)**
  - Source: podcasts.apple.com
  - *Listen to iHeartRadio's The CEO Series with McGill's Karl Moore podcast on Apple Podcasts ... Thane Calder, Founder of CloudRaker. This week on The CE...*

- **[The CEO Series with McGill's Karl Moore - Podcast - Apple Podcasts](https://podcasts.apple.com/ca/podcast/the-ceo-series-with-mcgills-karl-moore/id1356596659)**
  - Source: podcasts.apple.com
  - *Thane Calder, Founder of CloudRaker. This week on The CEO Series, Karl Moore ... Well structured interviews that allow the invités to open up and shar...*

- **[The CEO Series with McGill's Karl Moore | iHeart](https://www.iheart.com/podcast/962-the-ceo-series-with-mcgill-84791643/)**
  - Source: iheart.com
  - *This week on The CEO Series, Karl Moore speaks with Thane Calder, Founder and Chairman of CloudRaker. Thane shares the story behind founding CloudRake...*

- **[What is CloudRaker? Company Culture, Mission, Values | Glassdoor](https://www.glassdoor.ca/Overview/Working-at-CloudRaker-EI_IE855883.11,21.htm)**
  - Source: glassdoor.ca
  - *Thane Calder. 79% approve of CEO. Companies can't alter or remove ... How do job seekers rate their interview experience at CloudRaker? 83% of job ......*

- **[Designing a digital portfolio [2nd ed] 9780321637512, 0321637518 ...](https://dokumen.pub/designing-a-digital-portfolio-2nd-ed-9780321637512-0321637518.html)**
  - Source: dokumen.pub
  - *... interview. Self-assessments are subjective, not scientific. You'll ... Thane Calder co-founded CloudRaker on Valentines Day 2000 in order to launc...*

- **[The Pharma Report: Make it meaningful » Strategy](https://strategyonline.ca/2020/11/13/the-pharma-report-make-it-meaningful/)**
  - Source: strategyonline.ca
  - *Nov 13, 2020 ... CloudRaker executive director, pharma Joyce Thuss and CEO Thane Calder in the agency's Montreal office. “Our whole essence as a team ...*

- **[SOCIAL NOTES - PressReader](https://www.pressreader.com/canada/montreal-gazette/20181201/282561609239354)**
  - Source: pressreader.com
  - *Dec 1, 2018 ... ... Talk Radio Tommy” Schnurmacher for our outta-the-box stage debut of ... Cloudraker founder/CEO Thane Calder with wife, Sandrine Du...*

---

*Generated by Founder Scraper*
