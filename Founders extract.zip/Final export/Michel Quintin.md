# Michel Quintin

## Position actuelle

**Titre** : Co-Founder / CEO
**Entreprise** : Technologies doclinc
**Durée dans le rôle** : 5 years 4 months in role
**Durée dans l'entreprise** : 5 years 4 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Information Technology & Services

## Description du rôle

Secure Document Sharing | SaaS | Microsoft 365 Integration

At doclinc, I lead the vision, growth, and strategy behind a secure document-sharing platform tailored for professionals in accounting, insurance, banking, healthcare, and other regulated industries.
Our solutions—including a Microsoft Outlook add-in and a client-facing upload portal—streamline how sensitive documents or large files are requested, received, and managed, without sacrificing security or compliance. Hosted on SOC 2 Type II infrastructure and built on AES-256 encryption, doclinc empowers professionals to protect client information while simplifying their daily workflows.
As CEO, I focus on product trust, sales automation, and strategic partnerships—ensuring our tools integrate seamlessly with Microsoft 365 and support compliance in high-stakes environments.

## Résumé

I'm a digital transformation strategist and entrepreneur passionate about building secure, frictionless solutions for professionals handling sensitive information.

As Co-founder & CEO of doclinc Technologies, I lead the development and growth of our secure document-sharing platform, trusted by professionals in accounting, insurance, financial services, and healthcare. Our mission is simple: make it effortless—and compliant—for clients to send and receive sensitive documents, without passwords, portals, or friction.

With a strong background in business analysis and IT strategy, I bring over two decade of experience helping organizations modernize operations, align tech with business needs, and deliver measurable impact.

Currently focused on scaling doclinc for Outlook, a Microsoft-certified add-in that enables secure document exchange directly from Outlook, with full integration into existing workflows.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACz56oB8bErtcDgpDN0886tyRDbCM7JASg/
**Connexions partagées** : 73


---

# Michel Quintin

## Position actuelle

**Entreprise** : doclinc technologies

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Michel Quintin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396890187668168704 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1efe56ac-33f2-4b0a-9cb1-0500bc5d45d8 | https://media.licdn.com/dms/image/v2/D4E05AQHMznMFbq9uVA/videocover-high/B4EZqcGYEBHMBU-/0/1763555513527?e=1765778400&v=beta&t=SnXWtiLR3Ow0enmEvrkIUIHn-eUHk0EPewlKgYLvpsU | ALERTE ‼️
Le Québec fait l’objet de phishing massif ces derniers jours! 
Assurez-vous d’activer l’authentification à double facteur sur votre boîte courriel.

Partagez avec vos proches afin d’éviter que leur courriel soit compromis.
❤️ | 13 | 6 | 0 | 2w | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:13.772Z |  | 2025-11-19T12:40:48.314Z | https://www.linkedin.com/feed/update/urn:li:activity:7396888028969066497/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396730093869432832 | Text |  |  | 🚨 ALERTE!! Les attaques de phishing ciblant les cabinets comptables explosent!!
Des faux portails Microsoft 365, des comptes compromis, des documents sensibles exposés… et toujours le même point faible : la transmission de documents par courriel.
Nous publions aujourd’hui un article pour CPA Québec afin d’aider les cabinets à mieux comprendre — et surtout prévenir — ces attaques.
👉 Consultez l’article :
https://lnkd.in/e-uBYekN | 5 | 0 | 0 | 2w | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:13.773Z |  | 2025-11-19T02:04:38.978Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7389831637078790144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEAFrOMBqW1FA/feedshare-shrink_1280/B4EZo30txSGcAs-/0/1761873157874?e=1766620800&v=beta&t=KD2kH3j-cvGUjjDle6jNWPGSaO66XiLkoAK3EvsChps | 🎯 L’humilité et le plaisir : deux forces qui rassemblent
(english version below)

Après près de 30 ans à bâtir, innover, créer, apprendre —
avec des échecs formatifs… mais aussi des succès reconnus qui m’ont donné envie de continuer à me dépasser —
 j’en suis venu à croire ceci :

👉 On va toujours plus loin lorsque l’humilité et le plaisir guident notre façon de travailler.
En début de carrière, j’ai eu la chance de travailler avec un véritable leader.
Pas celui qui impose. Pas celui qui cherche à impressionner.
Celui qui fait grandir les autres.
Il me motivait, me poussait à apprendre…
et savait me dire quand je faisais une gaffe 😅
Mais toujours sans jugement, souvent avec humour.

On ne le respectait pas pour son titre, on le respectait pour la personne qu’il était.
✨ Ce que j’ai appris de lui :
 • Le plaisir soude une équipe
 • L’humilité ouvre les portes du dialogue
 • Le leadership se gagne… jamais ne s’impose
 • Les meilleurs savent rire d’eux-mêmes

Aujourd’hui, j’essaie de suivre son exemple :
Apprendre. Partager. Contribuer.
Et garder le sourire en chemin.

Parce qu’au final :
 L’humilité fait avancer.
 Le plaisir fait rassembler.
 Les deux font grandir.
💬 Quel leader vous a marqué dans votre parcours?
---------------------------------------------------------------------
🎯 Humility + Enjoyment: two forces that bring people together

After nearly 30 years of building, innovating, creating, learning —
with formative failures… and meaningful successes that pushed me to keep aiming higher —
I’ve come to believe this:

👉 We always go further when humility and enjoyment guide how we work.
Early in my career, I was lucky to work with a true leader.
Not the one who commands. Not the one who needs to impress.
The one who lifts others up.
He motivated me, pushed me to grow…
and wasn’t afraid to tell me when I messed up 😅
But always without judgment, often with humor.

📌 We didn’t respect him for his title, we respected him for the person he was.

✨ Key lessons he taught me:
 • Enjoyment brings teams together
 • Humility opens the door to real conversations
 • Leadership is earned… never enforced
 • The best leaders know how to laugh at themselves

Today, I try to follow his example:
Learn. Share. Contribute.
And keep smiling along the way.
Because in the end:
Humility moves us forward.
Enjoyment brings us together.
Both help us grow.
💬 Who has been a meaningful leader in your journey? | 15 | 2 | 0 | 1mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:13.774Z |  | 2025-10-31T01:12:38.712Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7327648788993486848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHPoIPDmx9TQQ/feedshare-shrink_800/B4EZbB0ZGdHIAg-/0/1747008460434?e=1766620800&v=beta&t=5WUYvTCvm4r3RWz_cVZAShFVirh5pSOyr6hYbdJZ_5E | doclinc for Outlook – Version 3 is now live!

We’re excited to share that version 3 of doclinc for Outlook is officially live — packed with powerful new features to make secure document sharing even easier and more efficient for professionals. Here’s what’s new 👇
🔐 Smarter security options
→ Add an automated voice call or a custom security question as an alternative to PIN by SMS.
🔁 Reusable links for ongoing exchanges
→ Recipients can now send documents multiple times using the same secure link, valid for up to 3 months.
📥 Multiple downloads + automatic reminders
→ Your recipients receive automatic email reminders before links expire or if they haven't completed a request.
📎 Auto-detection of unsecured attachments
→ doclinc detects attachments added to emails the usual way and suggests sending them securely instead.
✅ All updates are now live in your Outlook account.
If you don’t see the new version right away, simply right-click inside the doclinc panel and select "Refresh", or restart Outlook to force the update.

💡 Haven’t tried doclinc yet?
Try it for free — forever: https://lnkd.in/eKrZXx5d

#doclinc #OutlookAddin #SecureSharing #Productivity #Microsoft365 #DataSecurity #Accountants #LegalProfessionals #BusinessTools | 12 | 3 | 1 | 6mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:13.776Z |  | 2025-05-12T11:00:12.427Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7305543152390590464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a7823675-73bf-4b17-aac9-422063bddfce | https://media.licdn.com/dms/image/v2/D4E05AQED84aZ3WDY6Q/videocover-high/B4EZWHqkSNGwBs-/0/1741737892537?e=1765778400&v=beta&t=gVjYdLU94zPc_FiHQWncoxHVJEeHSV5F4pv-tbK_Tug | 🚨 Comptables, CPA et Notaires - Stressés par les échanges incessants de documents confidentiels en pleine période fiscale ?
Découvrez comment doclinc pour Outlook vous permet de sécuriser et simplifier le partage de documents sensibles directement depuis votre boîte Outlook.

✅ Aucun compte à créer, aucun mot de passe à gérer : juste un lien sécurisé, un PIN unique, et vos clients partagent facilement leurs documents avec vous.
✅ Conformité garantie : infrastructure canadienne certifiée SOC 2 Type II, cryptage AES-256, conforme aux meilleures pratiques OWASP.
✅ Simplicité absolue : Installation instantanée via Microsoft AppSource, utilisable immédiatement par toute votre équipe.

Épargnez-vous du stress, gagnez du temps et offrez une expérience professionnelle et moderne à vos clients dès maintenant.

👉 Cliquez sur le lien ci-dessous pour essayer doclinc sans frais et simplifier votre période fiscale !
https://lnkd.in/eRk9nXdC | 22 | 2 | 2 | 8mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:18.232Z |  | 2025-03-12T11:00:17.958Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7298740302956118016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGDlyLKb-YMsQ/feedshare-shrink_800/B4EZUpVoOfG0Ag-/0/1740155291128?e=1766620800&v=beta&t=aNDDGl8Uja7_-sWw-oD5SUXAx-gcexJ6Ts7Rp9hDRrE | 🏆 Équipe Canada triomphe aux 4 Nations : une leçon pour les entrepreneurs 🇨🇦💼

Hier soir, Équipe Canada a remporté le prestigieux Tournoi des 4 Nations, s’imposant face aux États-Unis dans un duel intense et hautement symbolique. Un match qui allait bien au-delà du sport : il représentait la résilience, la détermination et la fierté d’un pays face à l’adversité.
Et si cette victoire était aussi une métaphore pour l’entrepreneuriat?

🏒 L’ADN du succès : travail, persévérance et stratégie
 Tout comme les entrepreneurs qui se battent chaque jour pour faire grandir leur entreprise, les joueurs de Team Canada n’ont pas laissé place au doute. Détermination, entraînement rigoureux et vision claire : c’est cette mentalité qui fait la différence, que ce soit sur la glace ou en affaires.

💼 L’équipe avant tout
 On parle souvent du "hockey canadien" comme d’un modèle de collectif. En startup, c’est pareil : une équipe unie, où chaque membre joue son rôle à la perfection, peut surpasser des concurrents plus gros, mieux financés et parfois mieux positionnés.

🌎 Affronter les géants et s’imposer
 Le Canada, que ce soit en affaires ou en sport, doit souvent prouver qu’il peut rivaliser avec les puissances mondiales. Hier soir, c’était un rappel clair : on ne se contente pas de jouer, on est là pour gagner.
Cette victoire nous rappelle que le succès ne se donne pas, il se prend. Que ce soit en affaires ou en compétition, c’est en gardant le cap, en se battant pour chaque opportunité et en croyant en nos capacités que l’on peut marquer l’histoire.

Bravo à Équipe Canada! Inspirons-nous de leur mentalité pour bâtir nos propres succès! 💪🍁

#ÉquipeCanada #Entrepreneuriat #Leadership #Détermination #HockeyCanada #Victoire | 10 | 2 | 0 | 9mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:18.233Z |  | 2025-02-21T16:28:12.262Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7288911757803175937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEcKaGJr5XO4A/feedshare-shrink_800/B4EZSdqnmRGYAo-/0/1737811983192?e=1766620800&v=beta&t=y76Mcl2DgP0Jl56oXd5giGy-_BRZBMr2k-Fz1bX1Edg | Canadians are known for being polite, but don’t mistake kindness for weakness.
Recent moves—like U.S. tariff threats, price hikes targeting only Canadian consumers, and major corporations pulling out of Quebec—are a blatant reminder that economic bullying is alive and well. But here’s the thing: when you push Canadians too far, we push back.
If companies and politicians think we’ll just sit back and accept unfair treatment, they’ve seriously underestimated us. Canadian businesses, entrepreneurs, and consumers have a choice in where we spend our money and who we support. It’s time to stand up, call out this nonsense, and make sure our voices are heard.
When I was in high school, I remember our school director—a strong woman who wasn’t easily intimidated—often saying:
 "It only takes one imbecile to make us all look like imbeciles."
I know many of our American friends are educated enough to understand the situation, and we sympathize with them. The friendship between Canadians and Americans has always been strong, and we will continue to cherish that bond. But to those making these reckless decisions: rethink your approach. You don’t want to see what happens when Canadians stop playing nice. | 17 | 3 | 1 | 10mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:18.233Z |  | 2025-01-25T13:33:04.492Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7284539745383137280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/25be3377-55d4-4b9f-b830-0526b97e5edf | https://media.licdn.com/dms/image/v2/D4E05AQGgivjgZzg44A/videocover-high/B4EZRdEyiTGcBs-/0/1736728377586?e=1765778400&v=beta&t=NprYM_QgthBPiWaDu32CUIT1h3E0Yj_yKZ_affQ8NFs | Proudly Canadian, simplifying secure document sharing.
In today’s world, document-sharing tools are often secure but overly complex. And let’s face it—complexity leads to bad habits, like sharing sensitive information the wrong way.

With doclinc for Outlook, we’ve made it simple:
✅ No accounts to create
✅ No passwords to remember
✅ Just a secure link and a PIN sent to your mobile device
📩 It’s easy, affordable, and seamlessly integrates directly into Outlook via Microsoft AppSource.

This solution is built on over 50 years of combined expertise in digital transformation and security—including experience with Canada’s largest financial institutions.
🎥 Watch this short video to see how doclinc transforms collaboration while protecting privacy.
👉 Check it out and let us know your thoughts in the comments!

Get your free version today: https://lnkd.in/eKrZXx5d

#ProudlyCanadian #Security #Innovation #DocSharing #doclinc | 11 | 0 | 0 | 10mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:18.234Z |  | 2025-01-13T12:00:15.503Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7282727747368484866 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ce7912aa-777b-411e-bd9d-6e784bf266fa | https://media.licdn.com/dms/image/v2/D4E05AQEx4DY3NkroWQ/videocover-high/B4EZRD8uehGcBw-/0/1736306904888?e=1765778400&v=beta&t=7tyf0fYtdR5dDAuHvd4WO-Nlcc1SNevGofZeaEbZHtw | 🔒 Simplifier le partage de documents sensibles : c’est notre mission chez doclinc.
Aujourd’hui, les solutions de partage de documents sont souvent sécurisées, mais beaucoup trop complexes. Et cette complexité pousse parfois à adopter des pratiques moins sécurisées…
Avec doclinc pour Outlook, nous avons changé la donne :
✅ Aucun compte à créer
✅ Aucun mot de passe à retenir
✅ Juste un lien sécurisé et un PIN envoyé au mobile
📩 Une solution simple, abordable et facile à intégrer directement dans Outlook via Microsoft AppSource.

Découvrez dans cette courte vidéo comment doclinc transforme la collaboration entre vous et vos clients, tout en respectant les normes de sécurité et de confidentialité. 🎥

👉 Regardez la vidéo et dites-nous ce que vous en pensez dans les commentaires !
#Sécurité #Innovation #PartageDeDocuments #Doclinc

Obtenez votre version gratuite: 
https://lnkd.in/eRk9nXdC | 29 | 1 | 3 | 10mo | Post | Michel Quintin | https://www.linkedin.com/in/michelquintin | https://linkedin.com/in/michelquintin | 2025-12-08T05:08:18.235Z |  | 2025-01-08T12:00:01.511Z |  |  | 

---



---

# Michel Quintin
*doclinc technologies*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 18 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [doclinc technologies | LinkedIn](https://ca.linkedin.com/company/doclinc)
*2025-01-01*
- Category: article

### [doclinc](https://doclinc.io/)
*2020-01-01*
- Category: article

### [Eva Quintas and Michel Lefebvre, From Digital Writing to Artificial Intelligence: An interview by Jean Gagnon / Eva Quintas et Michel Lefebvre, De l’écriture numérique à l’intelligence artificielle : un entretien de Jean Gagnon – Ciel variable](https://www.erudit.org/fr/revues/cv/2023-n123-cv08033/102085ac.pdf)
*2025-11-09*
- Category: article

### [Michel Elings - Selling the company to Apple, Moving to Cupertino, Building products used by millions, Cultural differences, Surround yourself with people that believe in you  by Venture Europe: Entrepreneurship | Technology | Venture Capital | Eu/Acc](https://creators.spotify.com/pod/profile/ventureeurope/episodes/Michel-Elings---Selling-the-company-to-Apple--Moving-to-Cupertino--Building-products-used-by-millions--Cultural-differences--Surround-yourself-with-people-that-believe-in-you-e27bk08)
*2025-05-13*
- Category: podcast

### [Quentin Adam joins Micode on the Underscore_ podcast](https://clever-cloud.com/blog/company/2025/03/27/quentin-adam-joins-micode-on-the-underscore_-podcast)
*2025-03-27*
- Category: podcast

---

## 🎬 YouTube Videos

- **[Michel Quintin - Suggestions 2 - SLPA 2020](https://www.youtube.com/watch?v=LmE7ZkWubAk)**
  - Channel: Salon du livre de la Péninsule acadienne
  - Date: 2020-10-01

- **[Michel Quintin - Suggestions - SLPA 2020](https://www.youtube.com/watch?v=wNiviDP0z-c)**
  - Channel: Salon du livre de la Péninsule acadienne
  - Date: 2020-10-01

- **[L&#39;envers du décor](https://www.youtube.com/watch?v=XyRwZZUX8vg)**
  - Channel: Éditions Michel Quintin
  - Date: 2015-10-01

- **[Premier rendez-vous 1 - Le pire meilleur ami - Extrait](https://www.youtube.com/watch?v=D6bzQwuklQ8)**
  - Channel: Éditions Michel Quintin
  - Date: 2021-05-26

- **[Carine Paquin  « Le cochon qui voulait dire non » ( Éditions Michel Quintin)](https://www.youtube.com/watch?v=KsnyrtLe_vA)**
  - Channel: Association nationale des éditeurs de livres - ANEL
  - Date: 2021-10-28

- **[Épisode spécial #3: Noël avec Philippe Lemieux](https://www.youtube.com/watch?v=kDATNYw47d8)**
  - Channel: Dans Le Noir Avec Du Beurre
  - Date: 2024-06-29

- **[Épisode 58 - Captain Sonar - Pushing Daisies - U-Merlin - TRUCS d&#39;études - BABY SHOWER!](https://www.youtube.com/watch?v=4Joy3w46wm0)**
  - Channel: La Vie Secrète des Geekettes
  - Date: 2019-09-26

- **[7 magnifiques documentaires pour les enfants](https://www.youtube.com/watch?v=I8MzssRDOIM)**
  - Channel: Un Autre Blogue de Maman
  - Date: 2024-06-04

- **[10e édition (2022) Épisode 1 : Entrevue avec Freg](https://www.youtube.com/watch?v=xp9lYF9H8_g)**
  - Channel: Festival de la BD de Prévost
  - Date: 2022-04-25

- **[4 documentaires jeunesse](https://www.youtube.com/watch?v=ozoVeyNssWk)**
  - Channel: PauseLectureNet
  - Date: 2016-03-27

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
