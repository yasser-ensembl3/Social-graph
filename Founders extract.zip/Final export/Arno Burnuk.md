# Arno Burnuk

## Position actuelle

**Titre** : Founder/CEO/CTO
**Entreprise** : Autoflows.dev
**Durée dans le rôle** : 1 year 1 month in role
**Durée dans l'entreprise** : 1 year 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

-Design and develop a full-stack AI web application (web scraping, UI/UX, databases, prompt engineering...)
-Customer and Market Validation.
-Social Media and Search Marketing

## Résumé

I'm currently working as Founder/CEO/CTO of an AI automation startup, Autoflows.dev.

My tasks involve business initiatives such as customer discovery, market research, competitor analysis, business model design, online marketing, pitching and networking. 

On the technical side, I'm building a full-stack Next.js chatbot web app from scratch: I designed its UI/UX, architected the backend APIs, built a reliable database, designed custom tools and prompts, and wrote comprehensive tests, among other things. During this project, I developed deep expertise in system-level architecture and agentic AI frameworks.

Previously I worked as a Technology Analyst at Morgan Stanley where I gained valuable experience in numerous full-stack, data engineering and AI projects.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAsvUdQBeZqufB-4pT2sKKbg6YAoVwQrnJY/
**Connexions partagées** : 31


---

# Arno Burnuk

## Position actuelle

**Entreprise** : Autoflows.dev

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Arno Burnuk

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396995278844678145 | Text |  |  | Looking for a developer position in a startup. 

My background is in full-stack, data and AI engineering.

Any leads would be greatly appreciated. 🙂 | 31 | 8 | 3 | 2w | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:03.987Z |  | 2025-11-19T19:38:24.003Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384360726104231937 | Text |  |  | Anyone else notice Cursor seems to be using an older version of Claude this week, even when you explicitly specify claude-4.5-sonnet?? | 3 | 2 | 0 | 1mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.073Z |  | 2025-10-15T22:53:11.891Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7377471538624892929 | Text |  |  | A colleague is looking for the following:

"Searching for a Technical Director at ATEK who combines strategic vision with hands-on technical expertise. This role would oversee our Google Cloud infrastructure and lead development of our primary product built on the MEAN stack (MongoDB, Express, Angular, Node.js). Additionally, they would implement and manage our back-office technology ecosystem, including Retool, PostgreSQL, NocoDB, and OpenWebUI deployments.

The candidate should meet this technical profile and also possess strategic business acumen. ATEK is experiencing significant growth, and we're looking for technical leaders who can help us scale efficiently while maintaining our edge."

DM for more details. | 9 | 0 | 0 | 2mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.076Z |  | 2025-09-26T22:38:01.601Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7369852696339689472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEBqcXsxHMxrQ/feedshare-shrink_800/B4EZkb5.ZNIMAg-/0/1757109807091?e=1766620800&v=beta&t=X_Se0_AUsEyak1-aT-leN6KU54fWZubL-lv-HyGCxRE | I'm working on a "Vibe Scraping" SaaS app. If anyone is interested in a demo, DM me. | 14 | 1 | 0 | 3mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.077Z |  | 2025-09-05T22:03:28.049Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7341631117986279424 | Article |  |  | Bootstrapped solopreneurs rejoice.

https://lnkd.in/ddgVmijq | 8 | 2 | 0 | 5mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.082Z |  | 2025-06-20T01:00:59.438Z | https://techcrunch.com/2025/06/18/six-month-old-solo-owned-vibe-coder-base44-sells-to-wix-for-80m-cash/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7328498449904005120 | Article |  |  | This is the best meeting minutes tracker. 🙂 | 3 | 0 | 0 | 6mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.084Z |  | 2025-05-14T19:16:27.374Z | https://app.fireflies.ai/login?referralCode=01JV512NN1KSGAN21Q78M8BXYC |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7326310267217211393 | Text |  |  | Just had my first session with the genius startup coach Riley Ghiles I.! 🙂 

Would highly recommend him to any founders out there looking to grow their customer base. 💵 

He was able to keenly devise a multi-step plan to help me acquire new leads. He has a very in depth understanding of modern digital marketing and growth hacking techniques. 📈 

He offers free first time consultations. Feel free to send him a dm. ✉️ You won't be disappointed. | 13 | 1 | 0 | 6mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.085Z |  | 2025-05-08T18:21:23.967Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7326259504184979459 | Article |  |  | The future of vibe coding. | 5 | 0 | 0 | 6mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.086Z |  | 2025-05-08T14:59:41.117Z | https://youtube.com/watch?v=kkf3q1KsBDc&si=gi9Nvlq60WPuFcVe |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7323085036197498880 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEz-z9bqXPFxQ/feedshare-shrink_800/B56ZaC.2TgHAAg-/0/1745954243962?e=1766620800&v=beta&t=MAg6DISWDfhtdsJ-kWCPF-30E7kKOrm284q6ln8_1PQ | Great meetup on a Monday! | 5 | 2 | 0 | 7mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.086Z |  | 2025-04-29T20:45:28.970Z | https://www.linkedin.com/feed/update/urn:li:activity:7323062878154936320/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7322243923760844800 | Article |  |  | 🚀✨ Transform Your Workday with AI-Powered Automation! ✨🚀 

Tired of juggling tasks and feeling overwhelmed? Meet Autoflows.dev —the automation workflow platform that creates complete workflows at the speed of thought! 💡🤖

Imagine effortlessly streamlining your projects, enhancing productivity, and freeing up precious time for what truly matters. With our cutting-edge AI technology, you'll transform chaos into clarity in just a few clicks! 🖱️💼 

Don’t wait to elevate your efficiency—join the revolution in workplace automation today. Click the link below to learn more and unlock a world of possibilities! ⬇️👇

Autoflows.dev

#Automation #AI #ProductivityHacks #WorkSmart | 7 | 3 | 0 | 7mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.087Z |  | 2025-04-27T13:03:12.138Z | http://autoflows.dev/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7320447673684103169 | Article |  |  | Check out Autoflows.dev

Welcome to hassle-free automation. Use natural language prompts only to build, test, deploy and monitor business automation workflows.

Key Features:
-Universal API integrations
-One-click authentication
-End-to-end testing
-Super fast setup
...

Learn more:

https://autoflows.dev | 7 | 0 | 0 | 7mo | Post | Arno Burnuk | https://www.linkedin.com/in/arnoburnuk | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.087Z |  | 2025-04-22T14:05:32.747Z | https://autoflows.dev/ |  | 

---



---

# Arno Burnuk
*Autoflows.dev*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [⬛️ Playbook: Semi-Autonomous Innovation](https://www.heyarnoux.com/p/playbook-semi-autonomous-innovation)
*2025-01-29*
- Category: article

### [Startup Chat | Ep 4: Arno from Evolvize - Fevenim - Medium](https://medium.com/@fevenim/startup-chat-ep-4-arno-from-evolvize-2c06446be73f)
*2024-01-09*
- Category: blog

### [Trust the process OR automate it! A Conversation with Nick Arnot on the Age of Automation by WNY Entrepreneur](https://creators.spotify.com/pod/profile/wnyentrepreneur/episodes/Trust-the-process-OR-automate-it--A-Conversation-with-Nick-Arnot-on-the-Age-of-Automation-e2q9gn4)
*2025-04-28*
- Category: podcast

### [Introduction to "AI Over Coffee" - Exploring the Latest in AI Developments | FlowHunt](https://flowhunt.io/blog/introduction-to-ai-over-coffee-exploring-the-latest-in-ai-developments)
*2025-05-30*
- Category: blog

### [Building AI workflow automation for enterprises — E2B Blog](https://e2b.dev/blog/building-ai-workflow-automation-for-enterprises)
*2024-06-03*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[How AI Automates Your Entire Business | E140 - YouTube](https://www.youtube.com/watch?v=aMULc9yxtsI)**
  - Source: youtube.com
  - *4 days ago ... Guest: Arno Burnuk 00:01 — Introduction 00:08 — What Are Workflows ... Autoflows.dev....*

---

*Generated by Founder Scraper*
