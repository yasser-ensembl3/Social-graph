# Warren Wilansky

## Position actuelle

**Titre** : President & Founder
**Entreprise** : Plank
**Durée dans le rôle** : 27 years in role
**Durée dans l'entreprise** : 27 years in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Design Services

## Description du rôle

I am the President and Founder of Plank, a digital agency that designs and develops websites for mission-driven, creative organizations. I grew Plank from a dream into one of Canada's most respected digital studios, trusted by cultural and non-profit organizations to create meaningful, engaging online experiences.

Over the years, I've remained deeply committed to our core values of collaboration, evolution, empathy, accountability, and doing work that matters. We've built strong relationships with clients like The Canadian Encyclopedia, Ford's Theatre, and the Canadian National Exhibition, consistently delivering high-quality work with an attention to detail that defines us. 

As a B Corp, Plank is committed to running an ethically driven business. My approach to leadership is rooted in empathy, which I learned early on from my days at summer camp.

## Résumé

Warren Wilansky is the President and Founder of Plank, a digital agency with a mission to make the internet a better place. With over 25 years of experience, Warren leads Plank with a focus on empathy, collaboration, and accountability, ensuring the team delivers impactful website projects that reflect their clients’ values and benefit their communities.

Under his leadership, Plank has become a trusted partner for prominent clients across arts and culture, as well as in the non-profit and higher education sectors. Warren is committed to fostering innovation, ethical design, and meaningful work that makes a difference to all of our clients and their users.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAB8HMBhB29ItdsdNk9KbLnPgHJVS6lTjc/
**Connexions partagées** : 41


---

# Warren Wilansky

## Position actuelle

**Entreprise** : Plank

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Warren Wilansky

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7395169695341109248 | Article |  |  | Looking at our travel plans for Plank in 2025, we decided to attend one WordPress related event. While we were considering events like PressConf (https://pressconf.events/), WordCamp US and WordCamp Europe, we decided to stay local this year and invest our time in WordCamp Canada community.

If you are interested, I've written a short recap on my website, link is in the comments! | 11 | 4 | 0 | 3w | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.319Z |  | 2025-11-14T18:44:10.978Z | https://pressconf.events/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391199603339190272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHT-O2DIzISlA/feedshare-shrink_800/B4EZpK9yafKcAg-/0/1762194303105?e=1766620800&v=beta&t=XUq7prPGRsbihqcZIKM4YJXDlb2-irbDASoZY_LhJmg | Looking forward to attending my ninth Boot Camp in a row and eighth time as a sponsor! | 2 | 0 | 0 | 1mo | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.323Z |  | 2025-11-03T19:48:27.284Z | https://www.linkedin.com/feed/update/urn:li:activity:7391178682087657472/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7388929156778008576 | Text |  |  | Over the 25+ years that I have been collaborating with different organizations while running Plank, David Mahaffey is one of the most talented people I have ever had the pleasure of working with. He is thoughtful, has a strong attention to detail and is dedicated. There is no one I would rather work with again. | 5 | 3 | 2 | 1mo | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.325Z |  | 2025-10-28T13:26:30.641Z | https://www.linkedin.com/feed/update/urn:li:activity:7388918736222842880/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387173364857188352 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGeniaLXu5aWg/feedshare-shrink_800/B56ZoNfa_4KEAk-/0/1761162932774?e=1766620800&v=beta&t=daBXHDhw09Gkl6PFlkSMvDZfF1uRFEP0xHfTjsC9bno | I can't believe it's been almost a decade since I first attended Capacity Interactive's Boot Camp, and I am happy to say we are sponsoring for the 8th year in a row! I'm proud that we can support this community of arts marketers and professionals.

If you are attending, please pass by the Plank booth to chat about all things digital, from your website, ticketing challenges and audience development. If you want a high-level website audit, we would be more than happy to explore it with you.

We are also hosting an intimate, early-evening cocktail event on November 6th in Brooklyn, NY. If you are interested in attending, please DM me, and I would be happy to add you to our waiting list.
See you there!

#BootCamp2025 #CapacityInteractive #DigitalMarketing #ArtsandCulture | 5 | 0 | 0 | 1mo | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.327Z |  | 2025-10-23T17:09:37.226Z | https://www.linkedin.com/feed/update/urn:li:activity:7386852736950202369/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7386397942829563904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8SDgX_rH6pQ/feedshare-shrink_800/B4EZoDQjaZKsAg-/0/1760991264583?e=1766620800&v=beta&t=hkaUU5wyLCU8_alzpW4u3SiXfgUWLtZtrVPwdJZpndk | I am looking forward to spending time with the whole Boot Camp community in a few weeks! | 4 | 0 | 0 | 1mo | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.328Z |  | 2025-10-21T13:48:22.208Z | https://www.linkedin.com/feed/update/urn:li:activity:7386132710290903041/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7386067141415976960 | Text |  |  | While a few members of the Plank team attended the inaugural WordCamp Canada last year, this was my first opportunity to attend myself, and spent a couple of days learning, discussing and thinking about all things WordPress.

Of all of the questions we fielded over the two days while at our shared booth with ONIK, the one that kept coming up was “what was your reason for attending and sponsoring WordCamp Canada”? My answer was consistently the same, which was to invest in and be present for the WordPress community. After years of doing WordPress development, I wanted to elevate our place in the community and be more actively involved.

It was a real pleasure to get to see old friends, meet a slew of new people and get 20 new LinkedIn connections!

#WCCanada2025 | 37 | 8 | 1 | 1mo | Post | Warren Wilansky | https://www.linkedin.com/in/warrenwilansky | https://linkedin.com/in/warrenwilansky | 2025-12-08T05:16:07.329Z |  | 2025-10-20T15:53:53.005Z |  |  | 

---



---

# Warren Wilansky
*Plank*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 26 |

---

## 📚 Articles & Blog Posts

### [The Year Ahead – Warren Wilansky](https://warrenwilansky.com/2025/01/2025-at-plank-the-year-ahead/)
*2025-01-20*
- Category: article

### [](https://10-twenty.ca/2021/09/09/warren-wilansky-plank/)
- Category: article

### [Plank Year in Review 2018](https://medium.com/plank/plank-year-in-review-2018-4491b3a89032)
- Category: blog

### [E138:Why 'I'll Just Do It Myself' is Costing Your Business](https://creators.spotify.com/pod/profile/techyourbusiness/episodes/E138Why-Ill-Just-Do-It-Myself-is-Costing-Your-Business-e2uk3ad)
- Category: podcast

### [Four case studies from grant-funded GLAM projects](https://creators.spotify.com/pod/profile/mcnsessions/episodes/Negotiating-collaboration-Four-case-studies-from-grant-funded-GLAM-projects-e92g4n)
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Tech Your Business - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/tech-your-business/id1687571773)**
  - Source: podcasts.apple.com
  - *Listen to Tech your Business Podcast's Tech Your Business podcast on Apple Podcasts ... Warren Wilansky, Founder of Plank Digital Agency with 25+ year...*

- **[Peter Banigo » Contributors: Expert Voices On Baby Boomer Life ...](https://babyboomer.org/contributors/peterbanigo/)**
  - Source: babyboomer.org
  - *... podcast - Tech your Business and also my business. When I'm not doing that ... Warren Wilansky, Founder of Plank Digital Agency with 25+ years exp...*

- **[The Juno Beach Centre Announces From Vimy to Juno, A New ...](https://www.junobeach.org/press-room/the-juno-beach-centre-announces-from-vimy-to-juno-a-new-digital-educational-resource-exploring-canadas-involvement-in-the-two-world-wars/)**
  - Source: junobeach.org
  - *... Podcast · Witnesses to History · Legacy of Honour · Educator Resources · Maple ... Warren Wilansky, President and Founder of Plank. “With the help...*

- **[The KeyBARD Podcast – Thembi Duncan](https://thembiduncan.com/keybard-podcast/)**
  - Source: thembiduncan.com
  - *Plank: https://plank.co/en/. Ethical Web Collective: https ... Episode Artwork Ethical Web Design and Digital Storytelling with Warren Wilansky 26:25 ...*

- **[Home - Mark MacLeod](https://markmacleod.me/home/)**
  - Source: markmacleod.me
  - *... PODCAST · CONTACT. Logo. Image ... I've since then always referred to Mark as our "Business Physiatrist"." Image. Warren Wilansky Co-founder and C...*

- **[Attendees - Avery Swartz](https://creativemornings.com/talks/avery-swartz/attendees)**
  - Source: creativemornings.com
  - *Podcast · About; About. About · Contact · Patrons · Corporate partners · Press ... Warren Wilansky. President & Founder at Plank. View profile. Wilig8...*

- **[Judges - Digital Alberta](https://digitalalberta.com/judges/)**
  - Source: digitalalberta.com
  - *Warren Wilansky. President & Founder, Plank. Warren is the President and Founder of Plank, a Montreal-based digital agency that specializes in develop...*

- **[McGill Law – Internet Law | Allen Mendelsohn](https://allenmendelsohn.com/mcgill/)**
  - Source: allenmendelsohn.com
  - *Warren Wilansky of Plank Multimedia presentation slides (PDF). Audio ... podcast/962-the-elias-makos-show-271419288/episode/what-does-quebec-bill-109 ...*

- **[10 Best Museum Websites – Plank](https://plank.co/en/10-best-museum-websites/)**
  - Source: plank.co
  - *Apr 19, 2024 ... 10 Best Museum Websites. Design. Author. Warren Wilansky. Date. April 19 ... With just enough Taylor Swift content to make much of th...*

- **[ANNUAL REPORT](http://bellfund.ca/annual-report/2016/Bell_AR2016.pdf)**
  - Source: bellfund.ca
  - *Warren Wilansky, Aaron Hancox, Judy Holm,. Michael McNamara. SERVICE COMPANY. Plank Design. TV ... video, season recaps, cast interviews, and discussi...*

---

*Generated by Founder Scraper*
