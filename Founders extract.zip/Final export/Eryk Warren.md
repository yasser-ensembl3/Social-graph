# Eryk Warren

## Position actuelle

**Titre** : Cofounder CTO
**Entreprise** : Unito
**Durée dans le rôle** : 10 years 2 months in role
**Durée dans l'entreprise** : 10 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAEGu0BdfO-561EqRgjG1TKXr8OUmabRUA/
**Connexions partagées** : 49


---

# Eryk Warren

## Position actuelle

**Entreprise** : Unito

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Eryk Warren

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392216730078552066 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGsDedD-KIjVA/feedshare-shrink_800/B4EZpZnbu5IwAg-/0/1762440103950?e=1766620800&v=beta&t=P-FxCk6C0usZwb2tB6cDjeiLOEAntMyd7IakYmTdFic | Proud to partner with Asana and honored to see our collaboration recognized. Excited for what’s ahead as we continue to innovate together! | 14 | 0 | 0 | 1mo | Post | Eryk Warren | https://www.linkedin.com/in/erykwarren | https://linkedin.com/in/erykwarren | 2025-12-08T06:14:37.367Z |  | 2025-11-06T15:10:09.196Z | https://www.linkedin.com/feed/update/urn:li:activity:7392209585190850560/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7381755637182963713 | Article |  |  | Intelligent automation only works when your AI sees what you see. Yet today, enterprise data is fragmented between multiple SaaS tools.

That's why I'm excited to announce Unito's new connectors for Atlassian's Teamwork Graph, giving Rovo direct access to data from Salesforce, ServiceNow, Asana, and Wrike.

Unito syncs complete workgraphs, breaking down data silos and giving tools like Rovo the context they need.

👉 Full press release: https://lnkd.in/eqy5DN7E | 22 | 0 | 1 | 1mo | Post | Eryk Warren | https://www.linkedin.com/in/erykwarren | https://linkedin.com/in/erykwarren | 2025-12-08T06:14:37.367Z |  | 2025-10-08T18:21:30.292Z | https://www.prweb.com/releases/unito-launches-enterprise-grade-connectors-for-atlassian-teamwork-graph-supercharging-rovo-ai-search-and-workflow-automation-across-tools-302577942.html |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7376313392774668308 | Text |  |  | 🙌 Excited to see Unito + Asana take our partnership to the next level! | 30 | 1 | 0 | 2mo | Post | Eryk Warren | https://www.linkedin.com/in/erykwarren | https://linkedin.com/in/erykwarren | 2025-12-08T06:14:37.368Z |  | 2025-09-23T17:55:58.113Z | https://www.linkedin.com/feed/update/urn:li:activity:7376286764430422018/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7328172407112822784 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEMvUZDwd89Ww/feedshare-shrink_800/B4DZbKEGfuG8Ag-/0/1747146799230?e=1766620800&v=beta&t=DbyLl2R3tn83rEozgFbDvrh9T-Z7Y9gN7N29o66X3PA | What a way to kick off FY2026 🚀

Feeling incredibly lucky and proud to be building Unito with this incredible team.

Here’s to another year of syncing, shipping, and surprising ourselves. Let’s go, Unitoes!!! 💙💙💙 | 28 | 0 | 0 | 6mo | Post | Eryk Warren | https://www.linkedin.com/in/erykwarren | https://linkedin.com/in/erykwarren | 2025-12-08T06:14:40.818Z |  | 2025-05-13T21:40:52.715Z | https://www.linkedin.com/feed/update/urn:li:activity:7328064813585063937/ |  | 

---



---

# Eryk Warren
*Unito*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Case studies Archive](https://unito.io/case-studies/)
*2025-01-01*
- Category: article

### [Home - Unito](https://unito.io/)
*2025-03-25*
- Category: article

### [About us - Unito](https://unito.io/about-us/)
*2023-07-19*
- Category: article

### [Blog - Page 47 of 68 - Unito](https://unito.io/page/47/?p=t&reviews_page=3)
*2023-06-02*
- Category: article

### [Press and media - Unito](https://unito.io/press/)
*2023-06-02*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[244: How a Canadian College Dropout transferred to a Tech Savvy ...](https://millionaire-interviews.com/podcast/marc-boscher/)**
  - Source: millionaire-interviews.com
  - *Marc Boscher is the Co-Founder and CEO of Unito. Marc and Eryk Warren struck gold when they came up with an unconventional solution to the perpetual b...*

- **[Workflow SaaS integrator Unito raises $20 million to build more ...](https://betakit.com/workflow-saas-integrator-unito-raises-20-million-to-build-more-integrations/)**
  - Source: betakit.com
  - *Oct 27, 2022 ... Founded in 2015 by co-founders Marc Boscher (CEO) and Eryk Warren (CTO), Unito integrates disparate SaaS applications, enabling workf...*

- **[Unito, a platform for managing SaaS apps, raises $20M | TechCrunch](https://techcrunch.com/2022/10/26/unito-a-platform-for-managing-saas-apps-raises-30m/)**
  - Source: techcrunch.com
  - *Oct 26, 2022 ... Unito ... On a mission to uncover a solution — or invent a new one — Boscher and Eryk Warren joined Montreal's Founder Institute prog...*

- **[Explore 69 Best Data Integration Startups to watch in 2025. Discover ...](https://www.seedtable.com/best-data-integration-startups)**
  - Source: seedtable.com
  - *Unito is a project management tool connection software founded in 2015 by Eryk Warren, Marc Boscher and John Espinoza. ... Podcast · Statistics · Rece...*

- **[SaaSpasse chez Unito](https://www.saaspasse.com/startups/unito)**
  - Source: saaspasse.com
  - *Unito. Montréal. Remote. Financée. 100 - 500. Automatisation. + 1. Job du mois ... Eryk Warren. CTO, co-fondateur. Suivre. Unito. Offres d'emploi chez...*

- **[TeslaやNetflixも使用する企業ソフトの統合プラットフォーム 「共通 ...](https://techblitz.com/startup-interview/unito/)**
  - Source: techblitz.com
  - *Aug 5, 2024 ... image: Unito 共同創業者のMarc Boscher㊧とEryk Warren. ―近年はSaaSアプリの統合ソフトも増えていますが、ユニトー・シンク・プラットフォームの強み ......*

- **[About Us :: Meet the Unito Team | Unito](https://unito.io/about-us/)**
  - Source: unito.io
  - *Wherever your data needs to go, we have an integration for you. In October 2016, Marc Boscher and Eryk Warren launched Unito to transform the way team...*

- **[Unito - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/unito)**
  - Source: crunchbase.com
  - *Photo of Marc Boscher. Marc Boscher: Founder & CEO. Photo of Eryk Warren. Eryk Warren: Co-founder & CTO. Details. Legal Name Unito Inc. Operating Stat...*

- **[Unito Review | Features, Pricing & User Reviews](https://project-management.com/unito-software-review/)**
  - Source: project-management.com
  - *Jun 13, 2019 ... Unito is a privately held software company based in Montreal, QC, Canada. It was founded in 2015 by Marc Boscher, CEO; Eryk Warren, C...*

- **[Why Bessemer Venture Partners invested in Unito](https://www.alexanderjarvis.com/why-bessemer-venture-partners-invested-in-unito/)**
  - Source: alexanderjarvis.com
  - *Here's why we're excited to partner with Unito's co-founders Marc Boscher and Eryk Warren. ... Get Blog Updates. Copyright © 2025 50Folds LLC. Logo....*

---

*Generated by Founder Scraper*
