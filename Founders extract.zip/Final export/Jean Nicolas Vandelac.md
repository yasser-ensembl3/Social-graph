# Jean-Nicolas Vandelac

## Position actuelle

**Titre** : Founder CEO
**Entreprise** : Hoppin'​  - Solution de réalité virtuelle pour les Destinations - VR sociale multi-utilisateurs
**Durée dans le rôle** : 7 years 4 months in role
**Durée dans l'entreprise** : 7 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Travel Arrangements

## Description du rôle

Creating the first Social VR platform allowing for customers, families and friends to meet in 360 videos of real locations. Promotion of culture, tourism and entertainment. Virtual tours, group telepresence and remote presentations. Starting up and growing a team through innovation.
* AR, MR and VR market analysis
* Segments and business opportunities identification
* Business models and financial planning
* Proof of concept design and development
* Business creation, setup and management
* Key partners identification and onboarding
* Team management
* Business development
* Investor pitch and raise
* Strategy, direction and operation

## Résumé

Promoting culture, tourism and entertainment through social VR, where users meet in immersive destinations and plan their visit for real. Showcase real locations, virtual tours, group telepresence and remote presentations. We’re growing, take part in the revolution!
More than 20 years bridging the gap between consumers, brands and producers through digital entertainment platforms.
Thriving in innovation and trends anticipation: multi-player virtual party in 2001, contextual advertising before ubiquitous Google and Facebook, first passenger mobile inflight entertainment, and now leading social virtual reality.
Driving teams, products, projects and development, in small and large organizations or as an entrepreneur, developing international business.
Unique combination of education in computer graphics, 3D animation, computer engineering - artificial intelligence and robotics, education and business administration.
Loves life, the world and its people.
Looking forward to collaborating with you.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAmr6v8B85i_nEU2PwVtrZmnLzjS2sEu-tk/
**Connexions partagées** : 28


---

# Jean-Nicolas Vandelac

## Position actuelle

**Entreprise** : Hoppin'​ World

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jean-Nicolas Vandelac
*Hoppin'​ World*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [About Us – Hoppin' World](https://hoppin.world/about-hoppin/)
*2024-03-11*
- Category: article

### [COVID and the Remote Work Trend Drive Silicon Valley ...](https://maccelerator.la/en/blog/los-angeles/covid-and-the-remote-work-trend-drive-silicon-valley-exodus/)
*2020-11-16*
- Category: blog

### [Hoppin’ Virtual Reality Telepresence Platform Teleports Users in Lockdown](https://www.insta360.com/blog/enterprise/hoppin-vr-telepresence-platform.html)
*2020-06-16*
- Category: blog

### [The Founder And CEO Of Hopper Explains How He Utilized "Mobile Only" To Create A Thriving Company — TechDay](https://techdayhq.com/blog/2023/08/15/the-founder-and-ceo-of-hopper-explains-how-he-utilized-mobile-only-to-create-a-thriving-company)
*2023-08-15*
- Category: blog

### [New reality interview Fred lalonde hopper](https://www.phocuswire.com/New-reality-interview-Fred-lalonde-hopper)
*2020-11-05*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Demain est déjà là ! Tomorrow is Now! | Events - Concordia University](https://www.concordia.ca/cuevents/offices/provost/fourth-space/2025/01/16/demaindeja.html)**
  - Source: concordia.ca
  - *Jan 16, 2025 ... Jean-Nicolas Vandelac Hoppin' World CEO. Jean-Luc Pellerin The Dunes Agency, Web3Montreal , Swancloud. Organisé en collaboration avec...*

- **[25 Top Entertainment Companies in Montreal · December 2025 | F6S](https://www.f6s.com/companies/entertainment/canada/montreal/co)**
  - Source: f6s.com
  - *7 days ago ... Hoppin' World · See full page People, funding & more. Immersive Sales & Marketing Platform for the Real World. Jean-Nicolas Vandelac | ...*

- **[49 Top Live Music Events Companies · December 2025 | F6S](https://www.f6s.com/companies/live-music-events/mo)**
  - Source: f6s.com
  - *7 days ago ... Hoppin' World · See full page People, funding & more. Immersive Sales & Marketing Platform for the Real World. Jean-Nicolas Vandelac | ...*

- **[100 Top Sports Media Companies · December 2025 | F6S](https://www.f6s.com/companies/sports-media/mo)**
  - Source: f6s.com
  - *7 days ago ... Hoppin' World · See full page People, funding & more. Immersive Sales & Marketing Platform for the Real World. Jean-Nicolas Vandelac | ...*

- **[100 Top Hospitality Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/hospitality/canada/co)**
  - Source: f6s.com
  - *Hoppin' World · See full page People, funding & more. Immersive Sales & Marketing Platform for the Real World. Jean-Nicolas Vandelac | F6S - Images Se...*

- **[Hoppin' Virtual Reality Telepresence Platform Teleports Users in ...](https://www.insta360.com/blog/enterprise/hoppin-vr-telepresence-platform.html)**
  - Source: insta360.com
  - *Nov 16, 2025 ... ” said Jean-Nicolas Vandelac, Founder & CEO of Hoppin' World. Mel O ... On our blog, you'll find the latest news, tips and tricks to ...*

---

*Generated by Founder Scraper*
