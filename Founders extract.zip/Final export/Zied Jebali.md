# Zied Jebali

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : vvd
**Durée dans le rôle** : 10 months in role
**Durée dans l'entreprise** : 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

Changing the way we tell stories at vvd.world

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABN5-vABetwxMIFYcorElq0ZKiCbrnR3Asg/
**Connexions partagées** : 22


---

# Zied Jebali

## Position actuelle

**Entreprise** : vvd

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Zied Jebali

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398830170654081024 | Article |  |  | If you are or know a great developer who'd like to be involved in a creative project that's growing quickly please DM me I'd like to meet you.

We are moving quickly, incredibly ambitious and looking to completely change how the highest level of storytellers are working. 

Role is Montreal based or remote

https://lnkd.in/e5H2NPJR | 27 | 0 | 6 | 1w | Post | Zied Jebali | https://www.linkedin.com/in/ziedjebali | https://linkedin.com/in/ziedjebali | 2025-12-08T04:54:33.954Z |  | 2025-11-24T21:09:36.301Z | https://www.workwithindies.com/careers/vvd-founding-engineer-mobile |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394907687483822080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPTDb-jECcWg/feedshare-shrink_800/B4EZp_9WprGcAg-/0/1763083382309?e=1766620800&v=beta&t=p4UqHqgc54cxv8W8BTrk653fSHjEVyMblgqTAWrz5q4 | Hey everyone,

We’d love your help.

vvd has been growing fast with 200% month-over-month growth. We crossed 20,000 users today after going viral on Instagram where we reached over 2.5 million people and hit 700 CCU increasing our MRR by almost 100%

We're looking to change how we tell stories, not by replacing creativity with AI but with tools that enhance their craft and we're certain that's something people want.

We’re starting investor conversations and would appreciate introductions to domain experts in games, film, and fiction. If that’s you or you know someone, please reach out. Your perspective would be invaluable!

You can check it out here: https://vvd.world/ | 63 | 3 | 4 | 3w | Post | Zied Jebali | https://www.linkedin.com/in/ziedjebali | https://linkedin.com/in/ziedjebali | 2025-12-08T04:54:33.955Z |  | 2025-11-14T01:23:03.437Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7366898707608391680 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQGip2qBQZhhfw/image-shrink_800/B56ZjsW25zHAAc-/0/1756312072403?e=1765774800&v=beta&t=8Ka5p0ivgtUvYSGm9bMBsdwToul-cCglDPqk8FVDvco | Hey everyone, vvd is growing and I need some help! If you know someone who'd be a great fit, feel free to DM me | 17 | 1 | 2 | 3mo | Post | Zied Jebali | https://www.linkedin.com/in/ziedjebali | https://linkedin.com/in/ziedjebali | 2025-12-08T04:54:33.955Z |  | 2025-08-28T18:25:22.253Z | https://www.linkedin.com/feed/update/urn:li:activity:7366506837468250113/ |  | 

---



---

# Zied Jebali
*vvd*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Zied Jebali – Medium](https://medium.com/@ziedjebali)
*2019-04-04*
- Category: blog

### [Zied Jebali](https://en.wikipedia.org/wiki/Zied_Jebali)
*2024-03-10*
- Category: article

### [What I Know For Sure — Mazen (Saleh) AlDarrab, Founder and CGO, Zid](https://medium.com/@lhlovinglife/what-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089)
*2022-12-28*
- Category: blog

### [Zid Engineering](https://zid.engineering/)
*2024-03-28*
- Category: article

### [An untold story of the Tunisian startup scene](https://www.realisticoptimist.io/an-untold-story-of-the-tunisian-startup/)
*2023-06-29*
- Category: article

---

## 📖 Full Content (Scraped)

*6 articles scraped, 5,211 words total*

### Zied Jebali – Medium
*369 words* | Source: **EXA** | [Link](https://medium.com/@ziedjebali)

Zied Jebali – Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2F%40ziedjebali&%7Efeature=LoOpenInAppButton&%7Echannel=ShowUser&%7Estage=mobileNavBar&source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=---two_column_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---two_column_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

![Image 1](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

![Image 2: Zied Jebali](https://miro.medium.com/v2/resize:fill:96:96/1*C2Vq9YkVyXqfnABKtgpKlA.png)

Zied Jebali

[26 followers](https://medium.com/@ziedjebali/followers?source=user_profile_page----------------------43cf22b1341----------------------)

Follow

[Home](https://medium.com/@ziedjebali?source=user_profile_page----------------------43cf22b1341----------------------)

[About](https://medium.com/@ziedjebali/about?source=user_profile_page----------------------43cf22b1341----------------------)

[Ubisoft Game Lab Competition Post-Mortem Tips & T ------------------------------------------------- ### Hey reader!](https://medium.com/@ziedjebali/ubisoft-game-lab-competition-post-mortem-tips-t-5e9310bef9f9?source=user_profile_page---------0-------------43cf22b1341----------------------)

Apr 4, 2019

[21](https://medium.com/@ziedjebali/ubisoft-game-lab-competition-post-mortem-tips-t-5e9310bef9f9?source=user_profile_page---------0-------------43cf22b1341----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F5e9310bef9f9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali%2Fubisoft-game-lab-competition-post-mortem-tips-t-5e9310bef9f9&source=---------0-------------43cf22b1341----bookmark_preview------------------)

Apr 4, 2019

[21](https://medium.com/@ziedjebali/ubisoft-game-lab-competition-post-mortem-tips-t-5e9310bef9f9?source=user_profile_page---------0-------------43cf22b1341----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F5e9310bef9f9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali%2Fubisoft-game-lab-competition-post-mortem-tips-t-5e9310bef9f9&source=---------0-------------43cf22b1341----bookmark_preview------------------)

[Beyond a Single Path in Game Design ----------------------------------- ### I’d like to start off by saying I’m not an accomplished game designer in anyway and this is purely an analysis of what I think should be…](https://medium.com/@ziedjebali/beyond-a-single-path-in-game-design-cf636da99fa9?source=user_profile_page---------1-------------43cf22b1341----------------------)

Jan 15, 2018

[2](https://medium.com/@ziedjebali/beyond-a-single-path-in-game-design-cf636da99fa9?source=user_profile_page---------1-------------43cf22b1341----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fcf636da99fa9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali%2Fbeyond-a-single-path-in-game-design-cf636da99fa9&source=---------1-------------43cf22b1341----bookmark_preview------------------)

![Image 3: Beyond a Single Path in Game Design](https://miro.medium.com/v2/da:true/resize:fill:160:106/1*jue8QA-AOEHrdVROVjzZgQ.gif)

![Image 4: Beyond a Single Path in Game Design](https://miro.medium.com/v2/da:true/resize:fill:320:214/1*jue8QA-AOEHrdVROVjzZgQ.gif)

Jan 15, 2018

[2](https://medium.com/@ziedjebali/beyond-a-single-path-in-game-design-cf636da99fa9?source=user_profile_page---------1-------------43cf22b1341----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fcf636da99fa9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40ziedjebali%2Fbeyond-a-single-path-in-game-design-cf636da99fa9&source=---------1-------------43cf22b1341----bookmark_preview------------------)

[Be Accountable -------------- ### I’ve been binging on self improvement books lately and I believe I’ve found a way that can truly help make a positive change to not only…](https://medium.com/@ziedjebali/be-accountable-1da86096b1f7?source=user_profile_page---------2-------------43cf22b1341----------------------)

Nov 24, 201

*[... truncated, 8,809 more characters]*

---

### Zied Jebali
*3,041 words* | Source: **EXA** | [Link](https://en.wikipedia.org/wiki/Zied_Jebali)

Zied Jebali - Wikipedia

===============
[Jump to content](https://en.wikipedia.org/wiki/Zied_Jebali#bodyContent)

- [x] Main menu 

Main menu

move to sidebar hide

 Navigation 

*   [Main page](https://en.wikipedia.org/wiki/Main_Page "Visit the main page [alt-z]")
*   [Contents](https://en.wikipedia.org/wiki/Wikipedia:Contents "Guides to browsing Wikipedia")
*   [Current events](https://en.wikipedia.org/wiki/Portal:Current_events "Articles related to current events")
*   [Random article](https://en.wikipedia.org/wiki/Special:Random "Visit a randomly selected article [alt-x]")
*   [About Wikipedia](https://en.wikipedia.org/wiki/Wikipedia:About "Learn about Wikipedia and how it works")
*   [Contact us](https://en.wikipedia.org/wiki/Wikipedia:Contact_us "How to contact Wikipedia")

 Contribute 

*   [Help](https://en.wikipedia.org/wiki/Help:Contents "Guidance on how to use and edit Wikipedia")
*   [Learn to edit](https://en.wikipedia.org/wiki/Help:Introduction "Learn how to edit Wikipedia")
*   [Community portal](https://en.wikipedia.org/wiki/Wikipedia:Community_portal "The hub for editors")
*   [Recent changes](https://en.wikipedia.org/wiki/Special:RecentChanges "A list of recent changes to Wikipedia [alt-r]")
*   [Upload file](https://en.wikipedia.org/wiki/Wikipedia:File_upload_wizard "Add images or other media for use on Wikipedia")
*   [Special pages](https://en.wikipedia.org/wiki/Special:SpecialPages)

[![Image 1](https://en.wikipedia.org/static/images/icons/wikipedia.png)![Image 2: Wikipedia](https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en.svg)![Image 3: The Free Encyclopedia](https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-en.svg)](https://en.wikipedia.org/wiki/Main_Page)

[Search](https://en.wikipedia.org/wiki/Special:Search "Search Wikipedia [alt-f]")

Search

- [x] Appearance 

Appearance

move to sidebar hide

Text

*   Small  Standard  Large   

This page always uses small font size

Width

*   Standard  Wide   

The content is as wide as possible for your browser window.

Color (beta)

*   Automatic  Light  Dark   

This page is always in light mode.

*   [Donate](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=en.wikipedia.org&uselang=en)
*   [Create account](https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Zied+Jebali "You are encouraged to create an account and log in; however, it is not mandatory")
*   [Log in](https://en.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Zied+Jebali "You're encouraged to log in; however, it's not mandatory. [alt-o]")

- [x] Personal tools 

*   [Donate](https://donate.wikimedia.org/?wmf_source=donate&wmf_medium=sidebar&wmf_campaign=en.wikipedia.org&uselang=en)
*   [Create account](https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Zied+Jebali "You are encouraged to create an account and log in; however, it is not mandatory")
*   [Log in](https://en.wikipedia.org/w/index.php?title=Special:UserLogin&returnto=Zied+Jebali "You're encouraged to log in; however, it's not mandatory. [alt-o]")

 This is what we are up against. 

December 8: An important update for readers in the United States. 

Please don't skip this 1-minute read. It's Monday, December 8, and this fundraiser will soon be over, but we haven't yet hit our goal. If you're like us, you've used Wikipedia countless times. To settle an argument with a friend. To satisfy a curiosity. Whether it's 3 in the morning or afternoon, Wikipedia is useful in your life. Please give $2.75.

After nearly 25 years, Wikipedia is still the internet we were promised—created by people, not by machines. It's not perfect, but it's not here to push a point of view. It's owned by a nonprofit, not a giant technology company or a billionaire.

Just 2% of our readers donate, so if you have given in the past and Wikipedia still provides you with $2.75 worth of knowledge, donate today. If you are undecided, remember any contribution helps.

25 years of the internet at its **best**

 How often would you like to donate? 
*   Once 
*   Monthly 
*   Annual 

 Support Wikipedia year-round 

 Thanks for your generous support 

Please select an amount (USD)

The average donation in the United States is around$13.
*   $2.75 
*   $15 
*   $25 Celebrate & Give 🎉 
*   $50 
*   $100 
*   $250 
*   $500 
*   Other amount Other 

- [x] I'll generously add a little to cover the transaction fees so you can keep 100% of my donation. 

 Please select a payment method 

![Image 4](https://upload.wikimedia.org/wikipedia/donate/b/be/Trustly_logos_only.png)Online Banking 

Credit / Debit Card 

Continue Donate  one time Donate  monthly Donate  annually

Please select an amount (minimum $1)

We cannot accept donations greater than 25000 USD through our website. Please contact our major gifts staff at benefactors@wikimedia.org.

Please select a payment method

 Maybe later 

 Can we follow up and let you know if

*[... truncated, 29,610 more characters]*

---

### What I Know For Sure — Mazen (Saleh) AlDarrab, Founder and CGO, Zid
*1,386 words* | Source: **EXA** | [Link](https://medium.com/@lhlovinglife/what-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089)

What I Know For Sure — Mazen (Saleh) AlDarrab, Founder and CGO, Zid | by LHLovingLife | Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F73c6e8f40089&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40lhlovinglife%2Fwhat-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40lhlovinglife%2Fwhat-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

What I Know For Sure — Mazen (Saleh) AlDarrab, Founder and CGO, Zid
===================================================================

[![Image 4: LHLovingLife](https://miro.medium.com/v2/resize:fill:64:64/1*bygDvb1AUezvIHPvjrc0VQ.jpeg)](https://medium.com/@lhlovinglife?source=post_page---byline--73c6e8f40089---------------------------------------)

[LHLovingLife](https://medium.com/@lhlovinglife?source=post_page---byline--73c6e8f40089---------------------------------------)

Follow

3 min read

·

Dec 28, 2022

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F73c6e8f40089&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40lhlovinglife%2Fwhat-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089&user=LHLovingLife&userId=4e93b20cdc37&source=---header_actions--73c6e8f40089---------------------clap_footer------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F73c6e8f40089&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40lhlovinglife%2Fwhat-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089&source=---header_actions--73c6e8f40089---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3D73c6e8f40089&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40lhlovinglife%2Fwhat-i-know-for-sure-mazen-saleh-aldarrab-founder-and-cgo-zid-73c6e8f40089&source=---header_actions--73c6e8f40089---------------------post_audio_button------------------)

Share

Press enter or click to view image in full size

![Image 5](https://miro.medium.com/v2/resize:fit:700/1*E0VaQ4oep294ewz9RXJLGg.jpeg)

Hosting Mazen on Loving Life Conversation Series @Riyadh, Saudi Arabia

When I first started planning the trip to the Middle East, Mazen (Saleh) AlDarrab, Founder and CGO from Zid was the first one to confirm coming to my show. Even the invitation process inspired me to write a piece called “Keeping My Hands Free,” as inviting him, an influential figure in the entrepreneur ecosystem in the Middle East, turned out to be very simple (and a pleasure). He told me he would come, and was flexible on timing. I wrote in my article, “The best people keep their hands free.” Confirmation from him gave me the confidence to pull my team together and booked our flights.

The night before our interview, as President of China Xi Jinping was visiting Riyadh, Mazen texted me that the roads would be closed from 6AM to 6PM. We shifted our shooting to the next day. He had arranged his people to come earlier to help us tour the office and set up our cameras. We decided to record the conversation in his office with the energetic yellow backdrop.

When Mazen walked into the room, the air became vividly different. He is someone who brings life to a place. His energy. His passion. His focus. His expertise. And his total dedication to whatever he sets his mind to do.

We discussed the early journey of how Zid came into being, how product market fit found itself by them picking up the phone and talking to the customers. How Mazen’s journey transformed from developing e-commerce to now preaching “modern retail”, the new way to empower retailers to make smart decisions through data analytics every day all the while supporting them with tools to grow and manage businesses better in a sustainable manner.

Mazen is a world-class entrepreneur not just by the num

*[... truncated, 24,559 more characters]*

---

### Zid Engineering
*411 words* | Source: **EXA** | [Link](https://zid.engineering/)

Mar

28

Zaddy: Why and How We Have Our Own Proxy?
-----------------------------------------

Since launching Zid in 2017, we have always relied on using off-the-shelf infrastructure components. We did most of the heavy

Mar 28, 2024

6 min read

[](https://zid.engineering/zaddy-why-and-how-we-have-our-own-proxy/)

Mar

31

A Weird Incident With Aurora: A Boot Loop
-----------------------------------------

On March 15th, we had a two-hour platform-wide outage caused by a database anomaly. The story goes back to two

Mar 31, 2023

3 min read

[](https://zid.engineering/a-weird-side-of-aurora-a-boot-loop/)

Aug

21

زد شب : من 0 إلى +100 ألف شحنة (حول المنتج والتقنية)
----------------------------------------------------

English version: Here [http://zid.engineering/zidship-from-0-to-100k-shipments-the-product-and-the-engineering/] في أبريل الماضي، زد شب وصل لـ 100 ألف شحنة مكتملة. لذلك رأينا

Aug 21, 2021

[](https://zid.engineering/zidship-from-0-to-100k-shipments-the-product-and-the-engineering-ar/)

Aug

21

ZidShip: From 0 to 100k Shipments (the Product and the Engineering)
-------------------------------------------------------------------

النسخة العربية : هنا [http://zid.engineering/zidship-from-0-to-100k-shipments-the-product-and-the-engineering-ar/] In April of 2021, ZidShip has reached 100K delivered shipments, so we think

Aug 21, 2021

7 min read

[](https://zid.engineering/zidship-from-0-to-100k-shipments-the-product-and-the-engineering/)

Apr

04

![Image 1: إدارة: حول أهميّة الاجتماعات الفردية (one on one)](https://zid.engineering/content/images/size/w750/2021/06/priscilla-du-preez-K8XYGbw4Ahg-unsplash-1.jpg)

إدارة: حول أهميّة الاجتماعات الفردية (one on one)
-------------------------------------------------

> Treat your employees as interesting fellow humans, and you might be surprised what it does for their motivation, dedication,

Apr 4, 2021

1 min read

[](https://zid.engineering/hwl-hmyw-ljtmaat-lfrdyw-1-1/)

Mar

26

![Image 2: Laravel and Domain Driven Development, File Structure Part 1](https://zid.engineering/content/images/size/w750/2021/06/ross-sneddon-sWlDOWk0Jp8-unsplash.jpg)

Laravel and Domain Driven Development, File Structure Part 1
------------------------------------------------------------

This article was originally written by one of the best minds who've worked in Zid, Bartosz Stecko [https:

Mar 26, 2021

3 min read

[](https://zid.engineering/laravel-and-domain-driven-development-file-structure/)

Feb

13

![Image 3: A Rewrite Story (and How It Didn’t Go As Planned)](https://zid.engineering/content/images/size/w750/2021/06/marius-masalar-LN_gdbQtzvk-unsplash.jpg)

A Rewrite Story (and How It Didn’t Go As Planned)
-------------------------------------------------

In a previous article [http://zid.engineering/serving-the-first-million-orders-part-2/], Hussam Almarzooq [http://zid.engineering/author/hussam/] talked in short about how

Feb 13, 2021

6 min read

[](https://zid.engineering/a-rewrite-story-and-how-it-didnt-go-as-planned/)

Jun

03

![Image 4: Amazon Aurora Serverless: A Love–Hate Relationship](https://zid.engineering/content/images/size/w750/2021/06/jan-antonin-kolar-lRoX0shwjUQ-unsplash.jpg)

Amazon Aurora Serverless: A Love–Hate Relationship
--------------------------------------------------

As mentioned in a previous post [http://zid.engineering/serving-the-first-million-orders-part-2/], we migrated to Amazon Aurora Serverless [https://aws.amazon.com/

Jun 3, 2020

4 min read

[](https://zid.engineering/amazon-aurora-serverless-a-love-hate-relationship/)

May

08

![Image 5: Serving The First Million Orders - Part 2](https://zid.engineering/content/images/size/w750/2021/06/photo-1509315703195-529879416a7d-1.jpeg)

Serving The First Million Orders - Part 2
-----------------------------------------

In the previous part [http://zid.engineering/serving-the-first-million-orders-part-1/], we talked about how Zid bootstrapped on OpenCart to launch in very

May 8, 2020

3 min read

[](https://zid.engineering/serving-the-first-million-orders-part-2/)

Apr

14

![Image 6: Serving The First Million Orders - Part 1](https://zid.engineering/content/images/size/w750/2021/06/photo-1509315703195-529879416a7d.jpeg)

Serving The First Million Orders - Part 1
-----------------------------------------

Photo by Micheile Henderson [https://unsplash.com/@micheile?utm_source=ghost&utm_medium=referral&utm_campaign=api-credit] / Unsplash

Apr 14, 2020

3 min read

[](https://zid.engineering/serving-the-first-million-orders-part-1/)

---

### wellfound.com
*2 words* | Source: **GOOGLE** | [Link](https://wellfound.com/company/vvd-world)

wellfound.com

===============

---

### wellfound.com
*2 words* | Source: **GOOGLE** | [Link](https://wellfound.com/jobs/3388813-social-media-community-manager)

wellfound.com

===============

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[vvd.world Careers - Insights and Opportunities](https://wellfound.com/company/vvd-world)**
  - Source: wellfound.com
  - *Zied Jebali. Founder. Avatar for Zied Jebali. About vvd.world. Website. vvd.world. Location. Montreal. Company size; 1-10 people: Markets; SoftwareOnl...*

- **[Social Media & Community Manager at vvd.world • Montreal ...](https://wellfound.com/jobs/3388813-social-media-community-manager)**
  - Source: wellfound.com
  - *Zied Jebali. Founder. image. About the job. About vvd. vvd (vivid) is a worldbuilding and campaign-tracking platform where creators can bring their st...*

---

*Generated by Founder Scraper*
