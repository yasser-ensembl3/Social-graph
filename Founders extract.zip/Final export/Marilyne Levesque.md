# Marilyne Levesque

## Position actuelle

**Titre** : Fondatrice
**Entreprise** : Marelle Communications
**Durée dans le rôle** : 7 years 7 months in role
**Durée dans l'entreprise** : 7 years 7 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Public Relations and Communications Services

## Description du rôle

Agence de communication et de relations publiques.
Marelle Communications vous accompagne afin de mettre en lumière le succès de votre entreprise et de vos talents.  
Services: relations publiques, conseils stratégiques, gestion des médias sociaux et événements. 
Clients: Complexe Desjardins, Salon de l'Auto de Montréal, Salon du livre de Montréal, Salon international du Tourisme, ExpoHabitations, Hôtel Warwick - Le Crystal, Défilé du père Noël, Société de développement économique de la Petite-Italie, Montréal Centre-Ville, Orchestre de la Francophonie.
Courriel: info@marellecommunications.com

## Résumé

Marilyne Levesque cumule plus de 20 ans d’expérience en communication, relations publiques et médias. Visionnaire reconnue dans l’industrie, elle accompagne des organisations de haut niveau en leur offrant des conseils stratégiques pour accroître leur rayonnement et atteindre leurs objectifs.

Son parcours au sein d’agences réputées, combiné à ses années comme chroniqueuse et journaliste à la télévision et à la radio, lui a permis de développer une expertise de pointe en stratégie de communication et en gestion de l’image publique.

Entrepreneure dans l’âme, elle fonde en 2018 Marelle Communications, une agence qui reflète son approche basée sur l’écoute, l’innovation et l’esprit entrepreneurial. Forte d’un réseau d’influence allant du milieu politique aux arts et spectacles, elle propose un accompagnement unique, à la fois humain et orienté vers les résultats.

Communicatrice reconnue, Marilyne est également Formatrice Infopresse et intervient régulièrement dans les médias. Son professionnalisme, sa vision et sa capacité à inspirer en font une référence incontournable dans le domaine des communications et des relations publiques.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAu0P74B765t41N0Qtlq13gFm4umijTvtq0/
**Connexions partagées** : 57


---

# Marilyne Levesque

## Position actuelle

**Entreprise** : Marelle Communications

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Marilyne Levesque

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402173609785315328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9a92hqDvKvg/feedshare-shrink_800/B4EZrnNq5qHcAg-/0/1764815712245?e=1766620800&v=beta&t=YfqFbcKEmLmvP8otWFDmClYn1s93eapar2MicX11M4I | Le party de Noël de Tourisme Montréal est sans contredit un incontournable de la saison des fêtes à Montréal pour l’industrie.

Soirée mémorable en compagnie de Valérie Lavoie, MBA, PRP, Stéphanie Lepage, Pascale Grignon et de nombreux amis 🎅💫 | 30 | 0 | 0 | 4d | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:31.805Z |  | 2025-12-04T02:35:14.308Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401671645620305920 | Article |  |  | J'ai le plaisir de vous annoncer que Christine Beaudoin se joint à Marelle Communications à titre de collaboratrice spéciale ✨

Forte de 20 ans d’expérience en communication, dont plus de 10 ans dans les médias, Christine vient enrichir l’expertise stratégique de Marelle. Elle mettra à profit son savoir-faire en relations de presse, gestion de crise, communication promotionnelle, prise de parole et création de contenu.

Dotée d’une connaissance approfondie de l’écosystème médiatique et d’une compréhension fine des enjeux communicationnels, elle accompagnera nos clients avec finesse et contribuera à faire rayonner l’agence encore plus loin.

Bienvenue Christine 💛

https://lnkd.in/eUHqg9NQ | 32 | 0 | 0 | 5d | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:31.806Z |  | 2025-12-02T17:20:36.725Z | https://www.grenier.qc.ca/actualites/52739/marelle-communications-accueille-christine-beaudoin-en-tant-que-collaboratrice-speciale |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401004114261782528 | Article |  |  | 🎉 Belle opportunité professionnelle !

En tant que fière membre du Conseil d’administration de la Fondation de L'Oratoire Saint-Joseph du Mont-Royal, j’ai le plaisir de vous partager une ouverture de poste : celui de directeur·trice générale de la Fondation.

La Fondation a pour mission de préserver, soutenir et faire rayonner cette institution emblématique — un véritable bijou de notre patrimoine québécois et canadien, et l’un des sites touristiques les plus appréciés de Montréal. ⛪ ⛪ ⛪ 

Parmi ses projets phares, l’Oratoire rouvrira son dôme, le plus haut point d’observation à 360° de Montréal. 

👉 Si ce défi vous interpelle, je vous invite à m’écrire en privé.
👉 Et si vous connaissez quelqu’un qui pourrait correspondre, merci de partager l’offre dans votre réseau.

https://lnkd.in/ejG2Qv4b | 10 | 0 | 0 | 1w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:31.806Z |  | 2025-11-30T21:08:04.847Z | https://www.grenier.qc.ca/emplois/88490/directeurtrice-generale-fondation-de-loratoire-saint-joseph-du-mont-royal |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7400229090231943168 | Article |  |  | Ça y est, c'est confirmé: BMW et Audi feront leur grand retour au Salon de l'Auto de Montréal 🚘 💫 
 
Du 16 au 25 janvier 2026, le Salon de l’Auto revient au Palais des congrès de Montréal avec plus de 30 marques, en plus de trois nouvelles zones thématiques :

➡️ Zone Famille St-Hubert – mini-voitures électriques pour enfants et activités interactives
 ➡️  Zone plein air Overlanding – véhicules d’expédition et accessoires spécialisés
➡️ Zone Performance – une trentaine de voitures modifiées dans une salle entièrement repensée

Jusqu'à minuit ce soir, profitez d’un rabais exclusif de 50 % sur les billets du Salon de l’Auto de Montréal 2026 ! 🎅 🎅 🎅 

https://lnkd.in/eR7QKYdb
Marelle Communications | 8 | 1 | 0 | 1w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:31.807Z |  | 2025-11-28T17:48:24.719Z | https://www.salonautomontreal.com/fr/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398862062635913216 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b3286a8a-00b7-4669-aa36-f879dee3ca57 | https://media.licdn.com/dms/image/v2/D4E05AQE_EwE2zxmj5w/videocover-high/B4EZq3h8qHGcBU-/0/1764015724168?e=1765782000&v=beta&t=0DM-lGx1VuZEJk8EubtGPh_qhy02WZBK2lOxwHqE4EM | Découvrez notre directrice communications et opérations chez Marelle Communications,
Valérie Lavoie, MBA, PRP 👇👇

Depuis son arrivée dans l’équipe, Valérie s’est vite démarquée par son sens stratégique et son service client exemplaire. 💫 | 5 | 0 | 0 | 1w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:31.808Z |  | 2025-11-24T23:16:19.942Z | https://www.linkedin.com/feed/update/urn:li:activity:7398818243525836800/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394519196019314688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEIpS_LOImcSA/feedshare-shrink_800/B4EZp6cAVQIUAk-/0/1762990759025?e=1766620800&v=beta&t=nADiEad5UHLhShXFPehVGrOmNB4tvTTXxDPn6JzDM9w | C'est ce matin que Marelle Communications a dévoilé l'identité de la fée des étoiles du Défilé du Père Noël 2025 de Montréal centre-ville: la championne mondiale de boxe Kim Clavel ! 🎅 🎅 

On a hâte de vous retrouver pour le Défilé le samedi 22 novembre au centre-ville! Joignez-vous à nous pour cette grande fête familiale gratuite ! ⚡ 💫 | 21 | 0 | 0 | 3w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.351Z |  | 2025-11-12T23:39:19.854Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394154060259532800 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGD3svTCf56rw/feedshare-shrink_800/B4EZpz38pGKkAg-/0/1762880640946?e=1766620800&v=beta&t=HaP5f60faMmX0p8vlI-9XKjO34mEGOkaVU-FiQeefAM | Qui dit première neige dit qu’il est temps de penser aux cadeaux de Noël ! 🎄

Marelle Communications vous invite à vous procurer dès maintenant vos billets pour le Salon des métiers d'art du Québec à Montréal, qui se tiendra du 11 au 21 décembre au Palais des congrès de Montréal. 🎅

Des cadeaux uniques, fabriqués avec soin par des artisans d’ici — un incontournable de la période des Fêtes à Montréal ! 🎁 | 16 | 0 | 0 | 3w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.352Z |  | 2025-11-11T23:28:24.705Z | https://www.linkedin.com/feed/update/urn:li:activity:7394057330029469696/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7393844344429899776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGB6B4sJdbXjQ/feedshare-shrink_800/B4EZpvPv3VHoAs-/0/1762802992994?e=1766620800&v=beta&t=-s2AHur3xy5QgIsGCyTQrOPe4Oew-jy_kiXyhNI8nKQ | Encore un honneur cette année d'accompagner la Fédération professionnelle des journalistes du Québec - FPJQ pour les relations de presse entourant les prix Judith-Jasmin (meilleurs reportages de l'année) et Antoine-Désilets (meilleures photos).

Je ne le dirai jamais assez: à notre époque, où l'on se questionne sur la place de l'intelligence artificielle, le rôle des médias traditionnels est plus important que jamais pour la démocratie.

Gros coup de coeur pour la photo de l'année, réalisée par Campanozzi Marco pour La Presse. | 5 | 0 | 0 | 3w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.353Z |  | 2025-11-11T02:57:42.697Z | https://www.linkedin.com/feed/update/urn:li:activity:7393731650611888128/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7393028737992249344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c3447f60-929d-4ecf-84e4-5f3551b67814 | https://media.licdn.com/dms/image/v2/D4E05AQEjNsW3GQtW7Q/videocover-high/B4EZplQbm.HoBU-/0/1762635400469?e=1765782000&v=beta&t=5DyOj-LdYU17N38scU-tm0EFHNFE0lnK0cCnlZ1KfmQ | Le Salon International Tourisme Voyages a lieu tout le week-end au Palais des congrès de Montréal et l'équipe de création de contenu de Marelle Communications est sur place ! | 6 | 0 | 0 | 4w | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.354Z |  | 2025-11-08T20:56:46.969Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7390393859916107776 | Article |  |  | 📣 Il faut sauver le Salon du livre de Montréal !

Le milieu littéraire se mobilise ce matin dans une lettre ouverte pour encourager une résolution rapide du conflit de la STM.

À lire dans La Presse

https://lnkd.in/eYbjCu5p | 16 | 1 | 0 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.354Z |  | 2025-11-01T14:26:43.082Z | https://www.lapresse.ca/dialogue/opinions/2025-11-01/il-faut-sauver-le-salon-du-livre.php |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7389043622114992128 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d93363e6-9c98-4e3b-af55-6cee6e67f455 | https://media.licdn.com/dms/image/v2/D5605AQGQNOo80KB_qw/videocover-high/B56ZomAAgGG0BI-/0/1761574130411?e=1765782000&v=beta&t=xyzygAp8_ZSelwFge4vLzbXYBRr4LWGYzm4-2l68FaA | Je vote aussi pour le candidat proposé par Montréal centre-ville🎅 🎅🎅

Pour bien comprendre, je vous invite sa candidature dans la vidéo ci-dessous et à bien noter la date de son entrée en fonction: le 22 novembre.

#perenoel 
Glenn Castanheira
Marelle Communications | 6 | 0 | 1 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.357Z |  | 2025-10-28T21:01:21.304Z | https://www.linkedin.com/feed/update/urn:li:activity:7388577458549264385/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7386494538510680065 | Article |  |  | Je suis heureuse d'annoncer que Marelle Communications amorce une nouvelle étape en accueillant Valérie Lavoie, MBA, PRP à titre de directrice, communications et opérations.

Avec plus d’une douzaine d’années d’expérience en direction et en conseil stratégique, Valérie a accompagné des organisations issues de secteurs variés : art de vivre, consommation, culture et OBNL.

Dotée d’une solide formation en gestion (MBA, Université de Sherbrooke) et en communications (Université McGill et Concordia), elle se distingue par sa vision stratégique, sa rigueur et sa capacité à mobiliser les équipes autour d’objectifs communs. 🤝

Son arrivée vient renforcer notre structure, tout en nous permettant d’offrir à nos clients un accompagnement encore plus intégré et stratégique. ✨

https://lnkd.in/evh5GH7D | 13 | 3 | 0 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.358Z |  | 2025-10-21T20:12:12.413Z | https://www.grenier.qc.ca/actualites/51739/valerie-lavoie-se-joint-a-marelle-communications |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7385675977260965889 | Video (LinkedIn Source) | blob:https://www.linkedin.com/529bb753-412a-470d-b86e-5c35b942c060 | https://media.licdn.com/dms/image/v2/D4E05AQFDzL0YICXiug/videocover-high/B4EZnoc3zAIIB8-/0/1760541519501?e=1765782000&v=beta&t=ymrXrMzu401OZKBM39UEoS-p_JtpLxt9MMPSTaY7Ki4 | Le communiqué de presse, est-ce encore utile pour diffuser une nouvelle de votre organisation en 2025?

Je réponds à cette question dans la vidéo ci-dessous 👇 

#relationspubliques | 26 | 0 | 1 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.359Z |  | 2025-10-19T13:59:32.203Z | https://www.linkedin.com/feed/update/urn:li:activity:7384256779011977216/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7384696599572238336 | Article |  |  | Bonne nouvelle : le Salon International Tourisme Voyages confie ses communications à Marelle Communications pour les trois prochaines années! ☀️ 🚤 ✈️ 

Un immense merci à EXPO MÉDIA pour sa confiance. 

Cette collaboration s’inscrit aussi dans le souhait de Marelle Communications de poursuivre son évolution dans l'industrie des communications et du tourisme avec le TravelLifestyleNetwork. 

https://lnkd.in/ewRhG_dt | 28 | 1 | 0 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.360Z |  | 2025-10-16T21:07:50.366Z | https://www.grenier.qc.ca/actualites/51599/le-salon-international-tourisme-voyages-confie-ses-communications-a-marelle-communications |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7382521675029950465 | Article |  |  | C’est avec beaucoup d'enthousiasme que j’annonce la promotion de Charlotte Isambert au poste de gestionnaire de comptes chez Marelle Communications. 

Depuis plus de deux ans et demi, Charlotte se démarque par sa rigueur, sa créativité et son expertise en relations de presse et marketing d’influence. Elle a contribué au succès de nombreux mandats d’envergure à l'agence.

Bravo Charlotte, et bienvenue dans ce nouveau chapitre!
#Nomination #RelationsPubliques 

https://lnkd.in/eGizRVhe | 37 | 2 | 0 | 1mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.361Z |  | 2025-10-10T21:05:27.947Z | https://www.grenier.qc.ca/actualites/51478/charlotte-isambert-promue-au-poste-de-gestionnaire-de-comptes-chez-marelle-communications |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7379514489861275650 | Article |  |  | Je salue le retour du Journal Métro dans notre écosystème. 

Alors qu'on annonce depuis longtemps la mort des médias traditionnels, d'autres reviennent, plus forts que jamais, prêts à combattre le cynisme ambiant.

Ça me rassure. Célébrons ensemble le retour de la bonne information. 👏 

https://journalmetro.com/ | 46 | 2 | 1 | 2mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.361Z |  | 2025-10-02T13:55:59.132Z | https://journalmetro.com/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7376646860427534337 | Article |  |  | C'est ce soir que débute la 21e édition du Festival international du film black de Montréal, qui se déroule cette année sous la présidence d’honneur de Dany Laferrière, écrivain, cinéaste et membre de l’Académie française.

Pour l'occasion, la fondatrice du FIFB, Fabienne Colas,  nous donne ses recommandations de films à voir. À lire dans La Presse:

https://lnkd.in/ebzGP2Jt

Marelle Communications | 7 | 0 | 0 | 2mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.362Z |  | 2025-09-24T16:01:02.997Z | https://www.lapresse.ca/cinema/2025-09-24/festival-international-du-film-black-de-montreal/les-choix-de-la-presidente.php |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7375206740067393536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzkt3NERyZGg/feedshare-shrink_800/B4EZln_cAmIQAg-/0/1758386309155?e=1766620800&v=beta&t=kxNcM4iIRrzSlmNKnm0JMmcn3VQC5KUBs7UAlxuIHck | ✨ Des capteurs de rêve géants au Quartier des spectacles 💫

Cette semaine, Marelle Communications eu la chance de procéder au lancement de Weci | Koninut, une œuvre immersive grandiose présentée en grande première canadienne au Partenariat du Quartier des spectacles.

Imaginée par les artistes autochtones Julie-Christina Picher et Dave Jenniss, cette création fait résonner les six saisons atikamekw, de Pitcipipon (le pré-hiver) à Takwakin (l’automne), dans un dialogue poétique entre territoire, images et sons.

Le public est invité à s'immerger dans six capteurs de rêve géants, qui transforment l’espace en un territoire de rencontres et de résonances ancestrales.

👉 Je peux déjà vous dire que l’œuvre bénéficie d’un bel écho médiatique, reflétant toute la richesse et la profondeur de cette expérience culturelle. Faites vite et allez capturer vos rêves avant que l’installation ne parte en tournée vers d’autres lieux ☀️

Co-produite par Init et Houston First, l'œuvre est propulsée par Creos, fleuron québécois de l’art public nomade. | 30 | 0 | 0 | 2mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.363Z |  | 2025-09-20T16:38:31.547Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7369836108966428673 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a1824740-89c1-4d77-9084-5b9672f8809c | https://media.licdn.com/dms/image/v2/D4D05AQF6AvGTX_0OoA/videocover-high/B4DZkalFlSJECI-/0/1757087571249?e=1765782000&v=beta&t=JnYCTsmiVO8DELtWvc1Xyae7d4eUC7YJeu-PPmOXUfc | J'adore la nouvelle identité visuelle du Salon du livre de Montréal réalisée par l'agence Caserne et l'illustrateur québécois Mathieu Dionne. 

Quel travail exceptionnel ! | 13 | 0 | 0 | 3mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.364Z |  | 2025-09-05T20:57:33.311Z | https://www.linkedin.com/feed/update/urn:li:activity:7369759448313061379/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7369404204676706304 | Article |  |  | À vos agendas ! Le Festival international du film Black de Montréal (FIFBM), créé par la Fabienne Colas Foundation, sera sous la présidence d'honneur de Dany Laferrière du 24 au 28 septembre prochain.

Le FIFBM c'est 
⚡ 70 films 
⚡ 20 pays
⚡ 40 films canadiens
⚡ et la série « Être Noir·e au Canada », réalisés par 27 cinéastes noir·e·s canadien·ne·s âgé·e·s de 18 à 30 ans.

Un superbe nouveau mandat pour Marelle Communications.

https://lnkd.in/ecjcRMHw | 10 | 0 | 0 | 3mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.365Z |  | 2025-09-04T16:21:19.304Z | https://www.grenier.qc.ca/actualites/50645/le-fifbm-choisit-marelle-communications-pour-faire-rayonner-sa-21e-edition |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7366576442039615488 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ac337f53-b579-4678-abbd-c6ad595dbb62 | https://media.licdn.com/dms/image/v2/D4D05AQGTFO9HOybVug/feedshare-thumbnail_720_1280/B4DZjr_A5AGkA0-/0/1756305823353?e=1765782000&v=beta&t=FzHodV7ald0kYlc7B3Rery-coRpWDVxZHilhpZ8zTKM | C'est demain ! | 8 | 0 | 0 | 3mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.366Z |  | 2025-08-27T21:04:48.154Z | https://www.linkedin.com/feed/update/urn:li:activity:7366480649664319504/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7364358623407341569 | Article |  |  | On sent une énergie sans pareille en cette rentrée dans le milieu des communications à Montréal — tant chez Marelle Communications que chez nos pairs. Et ça fait du bien ! Pour notre industrie, et pour l’économie en général.

L’automne s’annonce déjà bien rempli (et ô combien excitant) : plusieurs renouvellements de mandats, de nouveaux clients qui nous rejoignent… Bref, beaucoup de beaux défis à relever.

👉 Dans ce contexte, nous cherchons toujours à enrichir notre équipe avec des personnes passionnées et créatives, prêtes à grandir avec nous:

https://lnkd.in/eaGkYaBv | 52 | 1 | 5 | 3mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.367Z |  | 2025-08-21T18:11:58.987Z | https://www.grenier.qc.ca/emplois/86863/directeurtrice-communications-et-relations-publiques |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7363674702759796737 | Article |  |  | ⚡ Quoi de plus inspirant que de voir les talents grandir au sein de Marelle Communications ? ⚡ 

Nous sommes heureux d’annoncer la promotion de Clémence Thibaud au poste de stratège, création de contenu et marketing d’influence.

En un an seulement, Clémence s’est imposée comme une véritable force créative et stratégique. Sa capacité à transformer les idées en campagnes percutantes et à allier esthétique, pertinence et performance a contribué à des projets remarqués pour des clients tels que le Salon du bateau de Montréal, le Salon international du tourisme de Montréal, SIAL Canada et l’Hôtel Warwick – Le Crystal.

Au-delà de ses réalisations, Clémence incarne notre conviction que la création de contenu est bien plus qu’un exercice visuel : c’est un levier stratégique qui permet aux marques de connecter avec leurs publics de façon durable et authentique.
 
Bravo Clémence, cette étape marque une progression pleinement méritée et prometteuse pour l’avenir de Marelle !

https://lnkd.in/eUea3mzr | 20 | 1 | 0 | 3mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.368Z |  | 2025-08-19T20:54:19.598Z | https://www.grenier.qc.ca/actualites/50377/clemence-thibaud-promue-a-titre-de-stratege-creation-de-contenu-et-marketing-dinfluence-chez-marelle-communications |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7358149530246074369 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhN1wgnu_upg/feedshare-shrink_800/B4EZh1l_wzGoAg-/0/1754319554527?e=1766620800&v=beta&t=uPznXRKs44pF9flqqfNeyanvtWeRv0ui3ngvTFWlGyI | Le pouvoir des vacances et l’entreprenariat ☀️ 

Depuis que je suis entrepreneure (oui, j’ai encore une petite gêne à dire ce mot — il est tellement galvaudé — mais après sept ans, je crois qu’il est temps de me l’approprier), les vraies vacances ont été rares.

Oui, j’ai eu la chance de voyager aux quatre coins du monde, notamment grâce au réseau TravelLifestyleNetwork auquel mon agence Marelle Communications est fièrement associée. Ce réseau me permet d’assister à des congrès en communication et tourisme un peu partout sur la planète. Mais soyons honnêtes : ce ne sont pas des vacances… 

Depuis trois ans surtout, les vraies pauses se sont faites rares. Alors, je me suis enfin permis, en toute liberté, un road trip de deux semaines en Italie. Et je ne le regrette pas une seconde.

Ma santé mentale en ressort renforcée. Je reviens ressourcée, ancrée, et surtout plus combative que jamais. Et la combativité, c’est essentiel en entrepreneuriat — encore plus à l’ère de l’intelligence artificielle, des bouleversements dans les médias et des défis constants auxquels notre industrie fait face. Les entrepreneurs en communication sauront de quoi je parle.

Des souvenirs plein la tête, une énergie renouvelée : c’est clair, le pouvoir des vacances est transformateur. ⚡ | 90 | 2 | 0 | 4mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.369Z |  | 2025-08-04T14:59:15.818Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7353702777555951616 | Document |  |  | 🎉🥳🙏👇👇👇 | 15 | 1 | 1 | 4mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.370Z |  | 2025-07-23T08:29:27.360Z | https://www.linkedin.com/feed/update/urn:li:activity:7353547565000204288/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7351707307652616192 | Article |  |  | Pas peu fière du tapis rouge que Marelle Communications a orchestré hier pour la première médiatique du spectacle hommage à Daniel Bélanger par le Cirque du Soleil Entertainment Group à l'Amphithéâtre Cogeco de Ville de Trois-Rivières. 

Roy Dupuis et Christine Beaulieu, Grégory Charles, Chantal Lacroix, Pierre Bruneau, Guylaine Tremblay, Guy Mongrain, Josélito Michaud et plusieurs autres: ils étaient tous rassemblés pour célébrer l'oeuvre du grand Daniel Bélanger !

https://lnkd.in/eBxagb4R

Alice Picard
Sandrine Rose | 24 | 2 | 0 | 4mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.371Z |  | 2025-07-17T20:20:10.261Z | https://www.7jours.ca/2025/07/17/rare-tapis-rouge-pour-roy-dupuis-et-christine-beaulieu |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7349513955465129984 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d731fd50-45f1-441c-8a82-8661d87afddd | https://media.licdn.com/dms/image/v2/D4E05AQHVS-Y_dw0yLg/videocover-high/B4EZf6mFDPGcCI-/0/1752256026233?e=1765782000&v=beta&t=AoCXis0dO1bhaooqlhCMSpb-qlEZT6tg_ZP-5I0wQQY | Le Soulfest a lieu toute la fin de semaine au parvis de l’église unie Saint-James sur Sainte-Catherine ouest à Montréal et en salle au Balcon.

Venez célébrer le meilleur de la musique soul, motown, disco et plus encore!

Pour avoir un avant-goût 👇 | 6 | 0 | 0 | 4mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.372Z |  | 2025-07-11T19:04:34.349Z | https://www.linkedin.com/feed/update/urn:li:activity:7349494494381203458/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7344496680576180224 | Document |  |  | 🎉Aujourd’hui, je souligne avec fierté les 2 ans de Charlotte Isambert parmi nous chez Marelle Communications 🥳

Voir évoluer de jeunes talents comme elle est un vrai privilège. C’est un plaisir de les dans leur développement et de contribuer à former, jour après jour, les meilleurs de notre industrie. Car excellence et agence riment toujours ensemble. 

Merci Charlotte pour ton engagement, ton énergie et ta collaboration! 🚀

#teammarelle | 20 | 2 | 0 | 5mo | Post | Marilyne Levesque | https://www.linkedin.com/in/marilyne-levesque-62691755 | https://linkedin.com/in/marilyne-levesque-62691755 | 2025-12-08T06:01:37.374Z |  | 2025-06-27T22:47:42.799Z | https://www.linkedin.com/feed/update/urn:li:activity:7344428557164576769/ |  | 

---



---

# Marilyne Levesque
*Marelle Communications*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 27 |

---

## 📚 Articles & Blog Posts

### [](https://www.agilitypr.com/pr-agency-news/marilyne-levesque-founder-of-marelle-communications-appointed-to-the-board-of-directors-of-travel-lifestyle-network/)
- Category: article

### [Marelle Communications joins TRAVEL LIFESTYLE NETWORK, the world's leading network of travel and lifestyle PR agencies](https://www.newswire.ca/news-releases/marelle-communications-joins-travel-lifestyle-network-the-world-s-leading-network-of-travel-and-lifestyle-pr-agencies-831720849.html)
*2022-03-23*
- Category: article

### [Marelle Communications obtient le mandat des relations de presse de la Série Hommage du Cirque du Soleil à l’Amphithéâtre Cogeco - Marelle Communications](https://www.marellecommunications.com/en/news/marelle-communications-obtient-le-mandat-des-relations-de-presse-de-la-serie-hommage-du-cirque-du-soleil-a-lamphitheatre-cogeco/)
*2025-10-01*
- Category: article

### [Marelle Communications accueille Barbara Philip - Marelle Communications](https://www.marellecommunications.com/en/news/marelle-communications-accueille-barbara-philip/)
*2025-10-01*
- Category: article

### [Our team | Marelle Communication](https://www.marellecommunications.com/about-us/?lang=en)
*2025-04-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Marilyne Levesque, founder of Marelle Communications, appointed ...](https://www.newswire.ca/news-releases/marilyne-levesque-founder-of-marelle-communications-appointed-to-the-board-of-directors-of-travel-lifestyle-network-827671359.html)**
  - Source: newswire.ca
  - *Jul 4, 2024 ... Radio & Podcast ... Marilyne Levesque, founder of Marelle Communications, appointed to the Board of Directors of Travel Lifestyle Netw...*

- **[Podcast: La santé mentale des communicateurs & Cannes/SXSW ...](https://www.grenier.qc.ca/nouvelles/17266/podcast-la-sante-mentale-des-communicateurs-cannessxsw)**
  - Source: grenier.qc.ca
  - *Nov 29, 2018 ... ... Marilyne Levesque (Marelle Communications) reçoivent Valérie Charest du Bénévolat d'entraide aux communicateurs avec qui ils disc...*

- **[PR News | PR Firm News: WPP Open Adds TikTok's AI Tools - Mon ...](https://www.odwyerpr.com/story/public/23155/2025-06-16/pr-firm-news-wpp-open-adds-tiktoks-ai-tools.html)**
  - Source: odwyerpr.com
  - *Jun 16, 2025 ... ... Marelle Communications (Canada) president Marilyne Levesque ... O'Dwyer's Podcast · Obituary · Personnel Appointments · Podcastin...*

- **[Podcast : Le gain et la perte de comptes majeurs & La relation client ...](https://www.grenier.qc.ca/actualites/17832/podcast-le-gain-et-la-perte-de-comptes-majeurs-la-relation-clientagence)**
  - Source: grenier.qc.ca
  - *Feb 21, 2019 ... Dans cet épisode, les animateurs Marilyne Lévesque (Marelle communications) et Eric Chandonnet (Grenier aux nouvelles) reçoivent Séba...*

- **[Board of Directors and Advisory Committees | A2C](https://a2c.quebec/en/discover-the-a2c/board-and-committees/)**
  - Source: a2c.quebec
  - *... Marilyne Levesque (Marelle Communications). Partner agencies. Immédia: OPC événements (organization);; Leader's Summit: Oxygène (organization);; 2...*

- **[À écouter en travaillant: 5 podcasts québécois sur le marketing ...](https://effet-b.ca/a-ecouter-en-travaillant-5-podcasts-quebecois-sur-le-marketing-numerique/)**
  - Source: effet-b.ca
  - *Ce podcast animé par Eric Chandonnet, président du Grenier aux nouvelles, et de Marilyne Levesque, fondatrice de Marelle Communications, est un podcas...*

- **[Une nouvelle agence de communication en RP arrive à Montréal ...](https://isarta.com/infos/une-nouvelle-agence-de-communication-en-rp-arrive-a-montreal-marelle-communications/)**
  - Source: isarta.com
  - *Apr 20, 2018 ... Une nouvelle agence de communication et de relations publiques vient de voir le jour : Marelle Communications. Dirigée par Marilyne L...*

- **[“Enseigner, ça me parle!” - CTF-FCE](https://www.ctf-fce.ca/enseigner-ca-me-parle/)**
  - Source: ctf-fce.ca
  - *Oct 19, 2020 ... Podcast · Graphics Standards · French. “Enseigner, ça me parle!” Home ... Media contact. Marilyne Lévesque, Marelle Communications ml...*

- **[Valérie Lavoie nouvelle directrice, communications et opérations de ...](https://isarta.com/infos/valerie-lavoie-nouvelle-directrice-communications-et-operations-de-marelle-communications/)**
  - Source: isarta.com
  - *Oct 21, 2025 ... Podcasts · EMPLOIS · FORMATIONS · logo image Emplois / Formations ... Marilyne Levesque, présidente et fondatrice de Marelle Communic...*

- **[CONTENFEST | JUNE 3, 2025](https://contenfest.com/)**
  - Source: contenfest.com
  - *Jun 3, 2025 ... Animateurs de podcast. Citron Rose. Créatrice de Contenu. Valérie ... Marilyne Levesque. Fondatrice Marelle Communications. Mlle Perez...*

---

*Generated by Founder Scraper*
