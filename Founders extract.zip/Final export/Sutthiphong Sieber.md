# Sutthiphong Sieber

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : SieberSolutions
**Durée dans le rôle** : 1 year 2 months in role
**Durée dans l'entreprise** : 1 year 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Consulting and Services

## Description du rôle

I know what it feels like when sales feels scattered. Too many leads, no clear process, and pressure building with every quarter.

Before launching SieberSolutions, I spent over a decade in technical B2B sales across Europe, Southeast Asia, and North America. I led long-cycle enterprise deals in manufacturing, aerospace, and SaaS.

I wasn’t building other people’s systems. I built my own. Frameworks that helped me stay focused, build trust, and deliver results in complex environments.

Today I help founders build calm, clear sales systems that match how they think and help them deliver consistent value to their customers. That way, the right deals move forward and the team can breathe again.

## Résumé

I'm Suti. I help B2B founders build sales systems that actually work.

Here's the thing about sales advice: most of it comes from people who've never actually sold anything complex.

I spent over a decade in the trenches of technical B2B sales. Aerospace, manufacturing, SaaS. Long sales cycles, complicated stakeholders, deals that took months to close.

From Europe to Southeast Asia to North America, I learned one uncomfortable truth: there's no magic sales framework that works for everyone.

What works? Building a system that fits your reality.

A clear, practical approach that matches how you actually think and sell.

That's what I do now. I work with founders and small sales teams who are tired of sales advice that sounds impressive but doesn't work in the real world.

We build sales systems together that are clear, grounded, and built to last. No fluff. No theory. Just what actually moves deals forward.

Because the best sales system isn't the most sophisticated one. It's the one you'll actually use.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACrxXY8Bjakis2AY1KQaulFAlW64XAzKeHk/
**Connexions partagées** : 34


---

# Sutthiphong Sieber

## Position actuelle

**Entreprise** : SieberSolutions

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Sutthiphong Sieber

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399157864985997313 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFlwdIwqqIzYA/feedshare-shrink_800/B4EZq8W3O4HEAg-/0/1764096702565?e=1766620800&v=beta&t=_3uosIHKp19XuPNZQcyqRq9WF93nOpU3AwqujGRiCfA | The best conversations at NEXT AI didn’t happen in the sessions, they started in the coffee line.

While waiting for a cappuccino this morning, I ended up talking with two founders.
Not about what they built.
But why they’re building it.

Why this problem matters to them.
Why the pain is real.
Why their AI solution deserves to exist.

And that’s where connection happens.
Not in perfectly structured pitches,
but in curiosity.
In hearing the story underneath the product.

So if you’re at NEXT AI today, come find me.
I’m the guy asking the question most people skip:

“Why this? Why now?”

Because the best founders don’t just pitch features.
They start with the reason that moves them.

Events like NEXT AI remind me of something simple:
You don’t connect through what people do.
You connect through why they care.

My takeaway?
Start asking people why they’re doing what they’re doing.
It sounds almost too simple.
But almost nobody does it.
And that one question opens doors you can’t script. | 10 | 2 | 0 | 1w | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:48.125Z |  | 2025-11-25T18:51:44.718Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397280367172485120 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH2JaoR-AcUuQ/image-shrink_800/B4EZqhrNJdHMAc-/0/1763649053355?e=1765778400&v=beta&t=2W46fOTvmxYVtty_9E4hidrP_EUqMdYDogjw-z-6rrE | We spent 2 weeks mapping it out.
The entire customer journey.

Every touchpoint. Every persona. Every “pain trigger.”

It looked great on a whiteboard.
Until we tried to use it in real sales conversations.

Nobody followed the steps.
Buyers didn’t match the personas.
And reps? More confused than confident. 

The map didn’t sell.
The moment of truth did.

So we simplified everything.

We ditched the theoretical journey.
And focused on one simple insight:

What does the buyer need to feel to move forward?

We rebuilt the messaging around that.
Tied follow-ups to real urgency, not just stages.
And gave reps room to adapt in real-time.

Result?
Increased quote-to-close rate: 17% → 31%
Deal velocity up.
Trust built faster.

Sometimes the best “map”… is knowing when to ignore it.

What’s one buyer insight you learned the hard way, but never forgot? | 7 | 5 | 0 | 2w | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:48.126Z |  | 2025-11-20T14:31:14.357Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396917890005901313 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGNk6kL-YDvBw/image-shrink_800/B4EZqchh_nHoAc-/0/1763562631142?e=1765778400&v=beta&t=0QoD01hC-05qr6Jx2HvWrStd7n7NeIjWFmHrYtBYYUY | I used to give way too much.

Quick advice? Sure.
Jump on a free call? Of course.
Review your pitch deck, rebuild your strategy, rewrite your emails?
No problem.

Except… it was.

Not because I didn’t want to help!
But because there was no line.
No structure.
No container.

Helping without a container becomes a leak.
It drains your time, your energy, your confidence.
And slowly...your business.

Here’s what changed:

Before: 10+ hours/week on free advice
After: 2 paid intensives/month with actual results

Same heart.
Stronger boundaries.
Clearer expectations.

Now, when I help, it’s deep, intentional, and respected.
Because I’ve learned that real support needs real structure.

→ Where do you still struggle to draw the line between helping and overgiving? | 10 | 3 | 0 | 2w | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:48.126Z |  | 2025-11-19T14:30:53.066Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396555506900938754 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHqtaT3WO3P2A/image-shrink_800/B4EZqXX8_YKoAc-/0/1763476231887?e=1765778400&v=beta&t=qYF6MBDVTbv1oZ8qyWkMWgYmzDg6Rw9Qk2WPvnwFVI8 | It started with good intentions.

Work from anywhere. Choose your own hours. Total freedom.
But six months in, their pipeline stalled.

Nobody knew who was doing what or when.
Team leads didn’t want to micromanage.
Reps said they were “on it.”
Deals drifted. Follow-ups slipped.
And no one could tell if momentum was building or dying.

That’s when we installed a system.
Not to take away freedom, but to anchor it.

We introduced:
 •	Sprint weeks for focus (what matters now?)
 •	Simple dashboards (so progress was visible)
 •	2 weekly rituals (Monday priorities + Friday momentum check)

And within 4 weeks, we saw 3x more deals moved to proposal stage.

When everyone sees the same scoreboard:
Accountability isn’t forced. It flows.
You can still be flexible.
But not invisible.

What’s one structure that made your team more accountable, without killing morale? 
Mine: Jira Board | 9 | 6 | 0 | 2w | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:48.127Z |  | 2025-11-18T14:30:54.201Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7394743628973309954 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH2H5fhaq5bQA/image-shrink_800/B4EZp9oC4bIwAc-/0/1763044244572?e=1765778400&v=beta&t=l4PfatnBfyphveVgW8UrcpWtA5kCLsq925rNHmtMldo | There’s a reason most sales teams confuse activity with progress.

They chase every lead.
Run every play.
Say yes to every request.

And then wonder why nothing sticks.

Real strategy isn’t about doing more.
It’s about doing less with intention.

One client had 3 reps chasing 9 ICPs across 5 industries.
Every week, new outreach angles.
Every month, a new “priority.”
No traction. No clarity. Just noise.

We paused everything.

I sat down with their founder and asked:

“If you could only win one type of client this quarter, who would it be AND why?”

That question broke the deadlock!

We got specific.
We rebuilt the messaging.
We trimmed the pipeline fat.

But here’s the catch:

We stuck with that system for 3 months, no tweaks, no detours.
Only then could we see what was actually working.

Six weeks in, they landed two high-fit clients and finally had a system to grow.

Focus isn’t a luxury. It’s a multiplier.
Consistency is what activates it.

If your sales strategy feels like a treadmill, you don’t need more speed.
You need a decision and the patience to let it play out.


What’s one type of lead you should stop chasing? But haven’t yet? | 7 | 4 | 0 | 3w | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:48.127Z |  | 2025-11-13T14:31:08.840Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7391482027851804673 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGIg3-mpJl3sw/image-shrink_800/B4EZpPRpM1GYAg-/0/1762266620866?e=1765778400&v=beta&t=TFaAlDf98qfC7mB3oB9oVWDPpwh_jJh0fsS91ryBorU | You Can Automate a Lot. Just Not This!

At @MTL Connect, I sat in on a panel where Samir Mounir, Ph.D., MBA. 
called Tesla “a pioneer in automation.”

Not just for cars, but for how they’ve automated almost everything behind the scenes.
Manufacturing. Logistics. Support. Even decision-making.

And honestly?
It’s impressive.

Because smart automation, done right, gives you back time.
It reduces errors.
It keeps teams focused on what matters most.

But here’s what really stayed with me:

30 minutes earlier, I had a conversation with another founder…
In a stairwell.
Between floors 2 and 3.
Because every meeting room was packed.

We didn’t talk strategy decks or tech stacks.
We talked about family.
About moving across the world and finding your way again.

And that...
You don’t automate.

Because while smart systems scale faster,
trust still travels slower.

So yes! Let’s automate what should be automated:
Lead scoring. CRM routing. Onboarding flows.
No question.

But let’s protect what should stay human:
Listening.
Connecting.
The unscalable moments that build real partnership.

The future isn’t either/or. It’s knowing what to hand off and what to hold close.

🧠 What’s one part of your work you’d never hand over to a bot?
👇 I’d love to hear. | 16 | 2 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.067Z |  | 2025-11-04T14:30:42.535Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7391119659267268608 | Text |  |  | Not everyone should be in sales.
And that’s okay.

A client brought someone onto their team to lead sales.
This person was kind, trustworthy, and genuinely cared.

They could close warm leads, no problem.
But here’s what kept stalling growth:

They avoided outreach like it was spam.
Hesitated to talk to new leads.
Pushed back on coaching.

“That just doesn’t feel like me.”

We tried frameworks.
Paired calls.
Nothing stuck.

Why?
Because it wasn’t a skill gap.
It was a fit gap.

Sales felt uncomfortable 
so it was never really owned.

Then someone else on the team (not in sales) stepped up.
Different energy.
Open to feedback.
Booked 3 meetings in their first week.

Sometimes, the fix isn’t more training.
It’s giving the right person the mic.

Ever seen someone struggle in a role they were never built for? | 7 | 5 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.068Z |  | 2025-11-03T14:30:47.132Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7389655268843737089 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE5vVW33NFSng/feedshare-shrink_800/B4EZo1UTIXHoAg-/0/1761831107665?e=1766620800&v=beta&t=9AqQdzu_oNSD7GomhpSzjFhNfA0bGttVBi9D19_6cc4 | Sometimes the most important part of a partnership… is your childhood.

Yesterday, I was back at @MTL Connect and also joined the DisruptHR event.

Between panels and packed rooms, I found myself having a conversation in the hallway with someone who could become a future collaborator.

We started with business.

But what stuck with me was his story, about growing up in his family’s restaurant.

And just like that, we bonded.
Not over strategy or goals.
But over grease-stained aprons, late-night cleanups, and the quiet pride of watching your parents serve people with heart.

I used to help out in a restaurant too when I was younger.
It taught me more about relationships, reading people, and staying grounded than any sales book ever did.

That moment reminded me:

Shared roots build more trust than shared metrics.
You can work with someone…
But when you see each other’s story, that’s when it really clicks.

What’s one early experience that shaped how you build relationships today?

PS:
Grateful for the stories and connection this week especially the hallway conversations that didn’t feel like “networking” at all. Shout out to:
Javier Castillo , Axel Rea , Paul Lecurieux-Lafayette , Antoine Laganiere ,Wissale Jaouate ,Alexandre Cloutier-Sanchez ,Yohan Poirier, Auky GONZALES GYSIN ,Alicia Djouab , Pierre-emmanuel Goffi and many more | 34 | 10 | 4 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.069Z |  | 2025-10-30T13:31:49.248Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7389294628329398273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHx8HMLmxvR3g/feedshare-shrink_800/B4EZowMTU9IwAg-/0/1761745124233?e=1766620800&v=beta&t=odre5YEKb1aFwmAkQOOD199lREzu2lOig2aihKYTFAo | Yesterday at MTL Connecte, every room was booked.
So a founder and I ended up talking on the stairwell, halfway between floors 2 and 3.

No pitch.
No agenda.
Just two people, sharing stories.

We talked about startups, sure.
But also about traveling through Australia, lessons from past jobs, and how strangely similar our paths have been, even lived in different lives.

That’s when I remembered:
Connection doesn’t need a meeting room.
It needs honesty.
Curiosity.
And a bit of time.

Some of the best conversations don’t happen because of business.
They happen because you find someone who gets your story, even before they know what you do.

If you’re around MTL Connecte today and this resonates, come say hi.
I’ll probably be lingering somewhere between two floors again.

Also feeling thankful for a few other conversations that stuck with me:
Mehdi Benboubakeur, Hortensia, Samir Mounir, Ph.D., MBA. Siyang Zheng, Ph.D., .,Auky GONZALES GYSIN, David Latortue, Maëva BOTREL and many more | 35 | 7 | 3 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.070Z |  | 2025-10-29T13:38:45.849Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7388930543230275585 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGpVW63qSIPHg/image-shrink_800/B4EZorBFshGoAc-/0/1761658300107?e=1765778400&v=beta&t=sb1HEjfel9OlekHyPPsV8e4vF5gF12gYqUa2kc358_4 | Buried in Leads. Starving for Clarity.

A client once told me they had a “privileged problem”:

“We’ve got too many leads. We can’t even reply to them all.”

But under the hood?

It wasn’t privilege.
It was chaos.

Unqualified conversations
Disjointed follow-ups
No time to warm people up

It created pressure, not growth.
So we slowed down, to speed up.

Cut lead gen by 50%
Rebuilt the qualification flow
Added a warm-up layer (so no one shows up cold)
Locked in 9–10am daily for focused outreach
Capped replies at 10 per day, but made each one count

Because the real bottleneck wasn’t volume
It was focus.

The early signs?

Fewer leads.
Better conversations.
More conversions.

Sometimes the smartest move isn’t “scale.”
It’s simplify.

→ Have you ever had to reduce noise to find momentum again? | 3 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.071Z |  | 2025-10-28T13:32:01.197Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7387480936407543809 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFUrdJZtJTo_Q/image-shrink_800/B4EZoWartjIMAc-/0/1761312686766?e=1765778400&v=beta&t=azzftqEvsnKveejWlspbCtiihdPrjzy-7keYEvD3cQA | Before every call, I turn into a detective. 
Not because I have to, because it’s the only way to actually help someone 

Before every call, I open too many tabs:
Perplexity, Indeed, LinkedIn, company blog, even comment sections.
Not because I’m obsessed.
Because I want to understand the person and the company behind the title.

Who they sell to.
What they’ve been struggling with.
Where their story shifted over time.

It’s amazing what you can learn if you read between the lines.

This little habit changes everything.
It turns small talk into insight, and a “sales call” into an honest conversation.

Curiosity isn’t just polite, it’s powerful.
People can feel when you’ve done your homework.

Curiosity closes deals.

How deep do you go before your first call? | 6 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.072Z |  | 2025-10-24T13:31:47.998Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7387118379091779584 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFVJQdFzdXKWA/image-shrink_800/B4EZoRQ8AiJ0Ac-/0/1761226246243?e=1765778400&v=beta&t=CawBcEx1MWXfRyXCawetgMpht-n5RiMU2_YdFNTaJ2E | If your offer "works for everyone," it’s landing with no one.
That was the real reason their sales were stalling. 
Not the product. Not the team. Just… vague targeting. 

That’s the problem.

When your audience is everyone, your message resonates with no one.

One client I worked with was targeting “tech companies.”
Sounds legit, but it included everything from early-stage SaaS to 200-person dev shops.

The pitch kept changing.
The outreach fell flat.
And every sales call felt like starting from zero.

So we picked a lane:
Seed-stage SaaS founders doing $20-80K MRR who lacked a sales system.

That changed everything.
•	Messaging got sharper
•	Demos got easier
•	Referrals got better
•	Pipeline got healthier

Takeaway:

Niche ≠ small.
It’s how you stop pitching and start resonating.

💬 What’s a niche you overlooked, that’s now working? | 4 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.073Z |  | 2025-10-23T13:31:07.598Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7386756149649350657 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGpqWFZW8sNCw/image-shrink_800/B4EZoMHfnyIUAc-/0/1761139884652?e=1765778400&v=beta&t=DK_Qqzevs_jB4TA57Qwt6ZsKG10mEdL5yjP6bkVN8zw | Deals don’t die on price.
They die quietly...in your inbox.

One founder told me:
“I don’t want to be annoying, so I only follow up once.”

Sounded respectful.
But it was quietly killing deals.

They did all the work to spark interest…
Then disappeared before a decision was ever made.

No reminders.
No rhythm.
No structure.

So we built one:
 •	Each follow-up had a reason, not just a nudge
 •	The message shifted at each stage: 
 clarify → reassure → re-engage
 •	We made “no ghosting” a two-way rule

Within weeks, replies doubled.
One prospect even said:
“Thanks for the reminder! I would’ve missed this.

Takeaway:

Follow-up isn’t pressure.
It’s a signal that you care enough to stay present.

What’s one way you follow up without sounding pushy? | 7 | 5 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.074Z |  | 2025-10-22T13:31:45.369Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7386393487870414848 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEQP7aZ9xsq-Q/image-shrink_800/B4EZoG9p_ZHEAc-/0/1761053419167?e=1765778400&v=beta&t=UbqrttdTBjemnGc4p3QrIDPbz0MpEyWaMwK2fWT5lok | For a long time, I felt the need to explain every number.
Why it costs this much.
Why it’s fair.
Why I wasn’t “too expensive.”

I thought I was helping people understand.
But all I was doing was defending a value they hadn’t even challenged yet.

It wasn’t about price.
It was about confidence.

Once I stopped over-explaining, something shifted.
I started sharing the outcome, not the math.
I got quiet after saying the price.
I let it land.

And the funny part?
The more confident I got in the value,
the fewer pricing questions I got.

Takeaway:

You don’t owe anyone a debate.
Just a clear offer and the courage to stand behind it.

What helped you start owning your pricing? | 6 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.075Z |  | 2025-10-21T13:30:40.063Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7384944173084409857 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFy8f2hkYg9jQ/image-shrink_800/B4EZnyXfzmGcAc-/0/1760707876324?e=1765778400&v=beta&t=Rb4nEV8pCrbogQbwIVNNpPxNJfInZhup0wvRkJNydio | I used to stack 5-6 calls back-to-back.
Fuelled by coffee. Proud of the hustle.
I thought I was being productive.

But by the afternoon, I’d start slipping.
Repeating myself. Forgetting names.
My brain was on the call
but not really in it.

So I tried something different:
I blocked 20 minutes between sessions.
No phone. No inbox. No Slack.

Just silence.
Sometimes I nap.
Sometimes I just sit.

That one pause gave me more clarity
than any productivity hack I’d ever tried.

It’s not lazy.
It’s how I recharge to think clearly and listen better.

Takeaway:

Rest isn’t the reward.
It’s part of the work.

What’s one tiny pause that makes your work better? | 10 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.076Z |  | 2025-10-17T13:31:36.491Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7384581722853617665 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEbYkOn4bnMuw/image-shrink_800/B4EZntN20jHEAg-/0/1760621460448?e=1765778400&v=beta&t=zd-dEbQD1-7yQt8dY81pVD16p66pX9xsJ7KqQn0WIVM | Most “personalized” emails sound the same.
Even the ones that take hours.

Researching. Writing clever intros.
Trying to sound human.

Reply rate?
4%.

They weren’t connecting.
They were overfitting.
Writing for applause! Not response.

So we stripped it back:
No more first names.
No more “loved your podcast.”
Just relevance.

Now they lead with one simple question:
“Are you dealing with [real problem] right now?”

No flattery. No tricks.
Just straight to the point.

Reply rate?
14%.

Takeaway:

Personalization isn’t about showing effort.
It’s about showing you get their world.

Cut the clever.
Start being useful.

What’s one line in your cold email that adds nothing? | 12 | 7 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.077Z |  | 2025-10-16T13:31:21.622Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7384219339085778944 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQG840p67x98OQ/image-shrink_800/B4EZnoERf4HgAc-/0/1760535061518?e=1765778400&v=beta&t=N01Drma_8o1a0bMENsSzDANTXocP-cFtirwFOeyHNpc | One of my clients spent $10K on sales training.
Nobody used it.

Not because it was bad content.
Because it had zero context.
No real conversations.
No follow-up.
No one owned the implementation.

It sat in a shared folder while the team kept winging it.

When I asked why they chose that training, the sales lead said:
“It had good reviews… and we needed to do something.”

Here’s what we focused on instead:
Real calls. Real objections. Real-time coaching.
Short modules, built from what the team was actually facing.

That’s the kind of training I saw work best! Especially back in Germany,
where one of the best coaches I’ve met, Anwar El Younoussi, taught me a simple principle:
“If your team isn’t training for the cons, they’re just rehearsing false confidence.”

We didn’t just cover what to say.
We worked through what buyers push back on.
That made all the difference.

Takeaway:

Don’t buy your team answers.
Help them build better questions! 
From their own calls.

What’s one piece of training your team actually used? | 13 | 5 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.078Z |  | 2025-10-15T13:31:22.599Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7383856833456783362 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGX1dF0yqsIIw/image-shrink_800/B4EZni6kxpGUAc-/0/1760448632927?e=1765778400&v=beta&t=tDcXj4im0zappgSsnFgPuEOuaiS1I9Y7715UlHFmOD8 | Objections used to scare me. 
Now I look for them! 

A prospect once told me:
“We love the offer. Just not sure we can commit to 12 months upfront.”

Old me would’ve panicked and tried to convince.
New me paused, then asked:
“What would make that feel safer?”

We shortened the term, added a cancellation clause and closed that week.

The objection wasn’t a “no.”
It was a “show me how.”! 

Takeaway:
Objections are proof someone’s thinking.
They’re not walls. They’re invitations.

What’s one objection you could listen to differently this week? | 6 | 2 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.078Z |  | 2025-10-14T13:30:54.522Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7382407360062840832 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH99Kzv8lh5dg/image-shrink_800/B4EZnOUQnHHIAk-/0/1760103052427?e=1765778400&v=beta&t=HPH916ha5f0r2MUPpgffZvgDhXIB1MYjjZrFPcJNJdM | Best practices never built my businesses.
My gut did.

I’ve read the playbooks.
Tried the frameworks.
Watched the experts.

But the more I followed what worked for them,
the less things worked for me.

Why?
Because best practices are context-dependent.
Your team, your stage, your values! 
They matter more than the template.

Everyone told me to cold pitch on autopilot.
Instead, I built a waitlist from warm intros and honest conversations.
Slower? Yes.
Better? Absolutely.

I trust my gut now.
Not because it’s always right,
but because it’s been trained through failure, reflection, and reps.

Like Kahneman famously said:
"Intuition is thinking that you know without knowing why you do"

When something feels off, I pause.
When a tactic feels misaligned, I skip it.
When my gut says, “This isn’t how we build trust,”
I listen.

Takeaway:

Your experience isn’t anecdotal.
It’s data! Just labeled differently.

What’s one “rule” you’ve learned to break? | 5 | 2 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.079Z |  | 2025-10-10T13:31:13.135Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7382044972474183680 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQG-5wdjaT_Fhw/image-shrink_800/B4EZnJKs.6IwAc-/0/1760016652572?e=1765778400&v=beta&t=c264EbH_e4sYV8Vu0VE0JlUtVqt4iNHNT4ojdh5vQ6E | Most teams think price kills deals.
It’s not even close.

A client showed me their “professional” 15-page proposal.
Charts, certifications, thirty bullet points.
Impressive and unread.

They thought more meant trust.
The buyer felt overwhelmed.

One buyer literally said:
“I’m looking through 5 different quotes… who’s going to read all this?”

We cut it down to two pages:
Page 1: the problem and the plan
Page 2: potential Value, proof and the next step

Clean. Clear. Fast.

The next client closed in 8 days.
The one before? Didn’t.

Takeaway:
Buyers don’t read walls of text.
They scan for clarity and confidence.

What’s one thing you could simplify this week to make your offer stand out? | 9 | 4 | 0 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.080Z |  | 2025-10-09T13:31:13.201Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7381682467558146050 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOCuQE5eQ8nA/feedshare-shrink_800/B4EZnAfGAuHIAo-/0/1759871003102?e=1766620800&v=beta&t=qxGypMj77HHhBhTN5vi9rW82mx4QogIksfm5XBOm9u4 | Most founders underestimate how much proximity shapes success.
I met my current team not through LinkedIn,  but at events like these! 

No cold emails. No polished pitches. 
Just real people, real energy and conversations that turned into partnerships.

That’s why I’m giving these three events a strong push this year (links in the comments):

🫧 Beyond the Bubble,  AI Without Borders
A full day connecting newcomers, founders, and AI builders who care about inclusion and impact.

🚪 Startup Open House (Montreal)
A citywide open door to see how startups really build, think, and collaborate.

🧠 AI Build Day 2025
One day. One idea. One chance to turn “I should build this” into “we did.”

If you’re in Montreal, come.
If you can’t, share this with someone who should.

Every year, I’m reminded that progress starts with proximity!
You never know who’s one conversation away from changing your trajectory.

Special thanks to Simran, Mohamed, Sara for pushing this forward 👏 | 19 | 10 | 1 | 1mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.081Z |  | 2025-10-08T13:30:45.294Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7376264084943695874 | Document |  |  | Why Your Best Prospects Ghost You?

The prospect who ghosts you isn’t rude.
They’re overwhelmed.

I used to take ghosting personally.
Great discovery call. Perfect fit. They loved our approach.
Then… nothing.

Radio silence for weeks.

Here’s what I learned about the ghosting epidemic, and the one question that prevents it.

The Problem:
We assume silence means “not interested.”
Usually it means: “too busy to think about this right now.”

Your prospect isn’t avoiding your solution.
They’re avoiding another decision while drowning in fires.

Back when I chased 6-month consulting deals, I lived this frustration.
Now I help B2B founders avoid the same trap.

The Question That Changes Everything:
“What’s your process for making a decision on this?”

Why it works:
It creates psychological commitment.
They now have to think through how they decide.

How I use it:

After Cold Outreach:
“If this resonates, what’s your typical process for evaluating something like this?”

After Demo:
“You seem interested. What’s your process for moving forward with a solution like this?”

Before Sending Proposal:
“Before I put together a proposal, what’s your process for reviewing and deciding on something like this?”

What happens next:
They walk you through timelines, decision-makers, blockers and most importantly, their buying psychology.

And once they’ve said it out loud…
Ghosting becomes harder.
People don’t disappear from processes they helped define.

My Framework Now:
 1.	Ask about their process (not your timeline)
 2.	Confirm the steps they outlined
 3.	Schedule the next milestone based on their words
 4.	Reference their process in every follow-up

Most founders focus on preventing objections.
Smart founders prevent ghosting.

Your prospects want to make good decisions.
Help them understand how.

Curious, what’s the most memorable ghosting moment you’ve had with a “perfect fit” prospect? | 13 | 4 | 0 | 2mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.083Z |  | 2025-09-23T14:40:02.210Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7371921510636240897 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQE5Izc29qawSw/image-shrink_800/B4EZk5TZSvKcAc-/0/1757603011861?e=1765778400&v=beta&t=5ugh8rEWwzUetO-fmN_-ADvI-8MeCognBgnkLWtY4YA | The Discovery Question I Wish I'd Asked Sooner

I spent 6 months chasing a "perfect fit" prospect who never bought.

• Great discovery calls
• Asked detailed questions
• Introduced me to the team
• Loved our demos 

Then went silent when it came time to sign.

Here's the question that would have saved me months of wasted effort.

The Problem: 
I was asking all the right questions about their pain, budget, and timeline. 
But I missed the most important one.

My discovery calls went like this: 
--> What's your biggest challenge with your process? 
--> How are you handling it now? 
--> What's your budget? 
--> When do you want to implement?

All textbook stuff. All completely useless for predicting if they'd actually buy.

This was back when I worked as a Key Account Manager. 
Now I help B2B founders who make the same mistake, focusing on problems instead of consequences.

The Question That Changed EVERYTHING: 
"What happens if you don't solve this problem in the next 90 days?"

Their answer tells you everything.

Responses that kill deals: 
• "Well, we'd like to fix it eventually..." 
• "It's not critical, just annoying" 
• "We're exploring options for next year"

Responses that close deals: 
• "We're losing money every month this continues" 
• "My boss said fix it by Q2 or else" 
• "Our biggest client is threatening to leave"

Here's what I learned: People buy when they have to, not when they want to.

I missed the most important question.

That “perfect fit” prospect? 
When I finally asked it, six months in, he said:
“Honestly, we can probably live with the current process for another year.”

Ouch. Six months of my life I’ll never get back! 

The framework I use now:

1. Understand the problem (standard discovery)
2. Identify the consequences (the magic question)
3. Confirm the timeline (based on urgency, not preference)
4. Most founders waste time on prospects who are curious, not desperate.

Your job isn't to create urgency. It's to find it.

What’s your magic discovery question? Always curious to learn from others. | 11 | 2 | 0 | 2mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.084Z |  | 2025-09-11T15:04:11.814Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7371558679092940800 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGGbJOH-2anPw/image-shrink_800/B4EZk0JdURKkAc-/0/1757516522929?e=1765778400&v=beta&t=82dc0AJCrl0ec1CnDcBs9-826bBs7W0nB712Z9vaUBo | I Used to Hate Cold Calling (Here's What Changed My Mind)

Cold calling used to make me physically sick.

I'd stare at my phone for 20 minutes before dialing. Rehearse scripts in my head. Pray for voicemail.

Here's what changed everything.

The Problem: I was trying to sound like a salesperson instead of a human being.

My opening went something like: 
"Hi, this is Sutthiphong Sieber from Schroeder Valves. We manufacture special ARC  valves for high-performance systems, and I wanted to see if you’re currently optimizing your pump protection strategy…"

By the time I finished that sentence, they'd already checked out.

This was back when I worked in technical sales at Schroeder Valves, a niche manufacturer of protective valves for industrial pump systems. 

I was 23. Green. Overthinking every word. 

Now I help B2B founders who are stuck in that same cycle, overthinking intros, avoiding calls, and missing out on conversations that could change their business.

The Breakthrough: I stopped trying to pitch.

I started trying to help. 

My new 30-second opener: "Hi Jordan, this is Suti. I work with B2B founders who are frustrated with inconsistent sales results. I'm not sure if that's something you're dealing with, but if it is, I might be able to help. Do you have 30 seconds for me to explain why I'm calling?"

That's it.

What's different: 
• I identify a specific problem, not my solution 
• I acknowledge I might be wrong ("I'm not sure if...") 
• I ask for permission to continue 
• I keep it conversational, not scripted

The result: My connect rate went from 12% to 43%. More importantly, the conversations that followed were actually productive.

Here's what I learned: People don't hate being sold to. They hate being interrupted by strangers who don't understand their problems.

When you lead with their pain instead of your product, everything changes.

The framework I use now:

1. Name + brief intro (5 seconds)
2. Specific problem they might have (10 seconds)
3. Acknowledge uncertainty (5 seconds)
4. Ask permission to continue (10 seconds)

Most founders avoid cold calling because they're trying to sound professional instead of helpful.

Your prospects don't need another sales pitch. They need someone who understands what keeps them up at night.

Stop selling your solution. Start acknowledging their problem.

What was your biggest cold call mistake? Always curious to learn from others. | 6 | 3 | 0 | 2mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.086Z |  | 2025-09-10T15:02:26.033Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7371199085640384512 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQExowndbSRhSg/image-shrink_800/B4EZkvCbXfGwAg-/0/1757430791812?e=1765778400&v=beta&t=tMvRYjYYwl5_scpnAtWGKX6sB5Tvs3f1d12EuYkkT0g | “You should talk to other consultants too!”
It builds trust. And wins the right clients! 

Every sales training I took hammered this rule. Act like you're the only solution. Dodge the "who else could help us" question.

I followed this for years. And kept losing deals to competitors I pretended didn't exist.

Then I tried something different.

Now when prospects ask "Who else could help with this?" I tell them.

They're shocked. In a good way. "Wait, you're actually suggesting other consultants?"

Yes. Because they need the right fit, not just any consultant.

This creates three shifts:

Trust goes through the roof When you're confident enough to suggest alternatives, prospects believe you genuinely want what's best for them.

You demonstrate expertise:
"If you need pure training, talk to X. 
If you want software implementation, Y is excellent. 
I focus on building the sales process itself, here's when that's what you need..."

They understand your unique value. 
By explaining when you're NOT the right fit, you clarify exactly when you ARE.

Real example from last week:

Prospect: "We're talking to a few consultants..."

Me: "Good. You should!
If you're looking for someone to just run training workshops, 
I'm probably not your best option. 
If you need someone to diagnose why deals are stalling and rebuild your sales process, that's exactly what I do. What's your actual challenge?"

Prospect: "Nobody's ever been that direct with us."

Started the engagement two weeks later.

The hard lesson: Prospects aren't choosing between identical services. 
They're trying to figure out which type of help they actually need.

When you clarify that for them, even if it means you're not the right fit,  they remember you as the consultant who actually listened.

And when they DO need what you offer? You're the obvious choice.

How do you handle the "shopping around" conversation? | 9 | 0 | 0 | 2mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.087Z |  | 2025-09-09T15:13:32.273Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7370892448119689216 | Video (LinkedIn Source) | blob:https://www.linkedin.com/85336729-a817-460a-a6c8-32bed784a4d1 | https://media.licdn.com/dms/image/v2/D4E05AQHlHQdxdIdC0w/videocover-low/B4EZkqJrJOIkCE-/0/1757348816334?e=1765778400&v=beta&t=dxibhqS9yPm5aAsB8pXveypEbM-uHcqn9W1-BmwPjX4 | This is what organic product-market fit looks like.

When other platforms start integrating your tool without you having to pitch them, you know you've built something people actually need.

Senja has become a go-to choice for testimonials, and now Umso users can add these widgets directly to their landing pages. 
Clean integration that benefits both platforms.

The best partnerships (Shout out to Olly & Alexis) happen when the value is clear to everyone involved! 
The tools, the platforms, and most importantly, the end users.

What's the best organic integration you've seen that just made perfect sense? | 1 | 1 | 0 | 2mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.088Z |  | 2025-09-08T18:55:04.191Z | https://www.linkedin.com/feed/update/urn:li:activity:7370855184735965184/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7369802964850483200 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7f5c23c0-d692-4275-a746-7b9414f82356 | https://media.licdn.com/dms/image/v2/D5610AQEb1S_hTYVsYA/videocover-high/B56ZkVwqbIG0BY-/0/1757006705341?e=1765778400&v=beta&t=1MRmKsjxeCtgo8HUf_vnyEsI42JJ4uwuwZveMEXWD54 | Here's what real product-market fit looks like!
A business professor at Leeds (Top 20 Business Schools) tells me his students are "amazed" by Umso and immediately want to use it for their own projects.

Matt Brady uses it in his entrepreneurship courses: 
"I describe it as the easiest platform for building content for the web. I haven't found anything more frictionless."

Most founders think validation is about surveys and feedback forms. 

Actually, it's when people choose your tool for their real work, not just because they have to learn it.

That's the difference between "this is cool" and "I need this!" | 6 | 2 | 0 | 3mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.089Z |  | 2025-09-05T18:45:51.138Z | https://www.linkedin.com/feed/update/urn:li:activity:7369420332950020099/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7366439854529855490 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHMUgaDfRA-Qg/image-shrink_800/B4EZjrZ6brHoAg-/0/1756296097706?e=1765778400&v=beta&t=hJ1U8K0stF-jxyx-iMk6RWWyZjvIlHeaSVYq0KZU06E | Most Sales Managers are expensive Task Managers 
The Gemini + ClickUp Stack That Replaced Sales Managers
Not literally. But it handles 80% of what a sales manager used to do.

I see this pattern constantly. Founders hire sales managers who spend most of their time in spreadsheets and chasing reps for updates. The actual coaching? Maybe 2 hours a week.

That's when I realized we were solving the wrong problem.

What sales teams actually need: 
• Automatic call recording and insights 
• Deal tracking that updates itself
• Follow-up that happens without nagging

Here's the stack that changed everything:

Gemini captures every call No more "what did the prospect say?" Every conversation is searchable. Commitments tracked. Objections documented.

ClickUp becomes your command center Deal stages, follow-up tasks, pipeline health - all automated from call insights. No manual CRM updates.

The magic happens in between When Gemini spots "send proposal by Friday" it creates a ClickUp task. When deals stall, you get alerts. When patterns emerge, you see them.

The uncomfortable truth? Most sales managers are expensive task managers.

Your reps don't need someone asking "did you follow up?" They need systems that make follow-up automatic.

What I've seen when founders implement this: 
• Follow-up rates improve dramatically 
• Deal velocity increases significantly
• Reps spend hours less per week on admin tasks

Cost? Under $100/month per rep.

You're not replacing humans. 
You're freeing them to do human things - build relationships, solve problems, close deals.

The best part? It scales. 5 reps or 50, the system works the same.

What manual sales process is killing your team's momentum right now?

DM "stack" if you want the exact automation setup. | 1 | 0 | 0 | 3mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.090Z |  | 2025-08-27T12:02:03.154Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7366077283435978754 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGq0n4YYYrTCw/image-shrink_800/B4EZjmQLYfGcAc-/0/1756209658441?e=1765778400&v=beta&t=5wG1PpL08LDtvXUA29yiJ5o1fp7EfCHQdyX9NMM3TIk | The One Question That Disqualifies 40% of "Hot" Leads

Actually, let me be honest. 
It disqualifies about 40% of the leads I thought were hot.

Been testing this for the past month. 
One simple question. 
Saves me hours of wasted demos and follow-ups.

"What happens if you don't solve this problem in the next 90 days?"

Their answer tells you everything.

The responses that kill deals:
❌ "Well, we'd like to fix it eventually..."
❌  "It's not critical, just annoying"
❌  "We're exploring options for next year"
❌  "Good question, I'll have to think about that"

The responses that close deals:
✅ "We're losing money every month this continues"
✅ "My boss said fix it by Q2 or else"
✅ "Our biggest client is threatening to leave"
✅  "We literally can't scale without solving this"

Here's what I learned the hard way: 
Most "interested" prospects are just curious. 
They'll waste your time for months because they're bored, not desperate.

I spent 6 weeks nurturing a "sure thing" who loved our demos, asked great questions, introduced me to the team.

Then went silent when it was time to sign...

Why? Because their problem was a "nice to fix" not a "must fix now!"

How I use it now:
First call after initial interest: 
"Before we dive in, what happens if this problem isn't solved in 90 days?"

If they struggle to answer, I know to either:
Help them see the real cost of inaction
Put them in the "check back in 6 months" pile

The insight? URGENCY BEATS INTEREST every time. 
People buy when they have to, not when they want to.

What's your go-to question for separating real prospects from tire kickers? | 4 | 2 | 0 | 3mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.091Z |  | 2025-08-26T12:01:19.469Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7365487609587974145 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQExwqMQNLxdBg/feedshare-shrink_800/B4EZjd38kbGoAk-/0/1756069088765?e=1766620800&v=beta&t=ip1HgEZkhH0N3f_QQio_iGSGVtdQFhqOPyS8CnujjQ4 | I used to think networking meant shaking hands and swapping business cards.

Turns out, it can be something completely different.

Here's the thing about networking. I hate that word. 
It feels so transactional. I'd rather just connect with people.

What drives me is curiosity about how others think. 
Why do they see it that way? What shaped that perspective?

The problem with most networking events? 
You never get that deep. 
You're stuck with surface-level small talk, polite questions, or jumping straight into business.

When you try to dig deeper, to actually understand the why behind someone's thinking, people usually switch subjects or give you surface-level answers.

At least that's been my experience.

Then I went to Le Club Intellectual DEMONT GROUP where Alicia prepared cards with questions like: 

"Have we turned authenticity into a content strategy?"

That hit different! 
It led to the kind of conversation that stuck with me for days.

Here's what I realized: 
Most networking is just small talk with business cards. 
People are hungry for thoughtful conversations, but nobody creates space for them.

Building genuine connections doesn't require perfect questions or techniques. It requires genuine curiosity about how other people think.

Most founders I meet are tired of surface-level networking but don't know how to go deeper without being weird about it.

The solution? 
Stop trying to impress people. 
Start trying to understand them.

Connected with Jean-Hamilton, Auky, Caroline, Janson, Henrique, Nicolas, Aimen and many more 
I'm curious, which questions hit you different? | 19 | 13 | 0 | 3mo | Post | Sutthiphong Sieber | https://www.linkedin.com/in/ssieber-693345181 | https://linkedin.com/in/ssieber-693345181 | 2025-12-08T05:23:52.093Z |  | 2025-08-24T20:58:10.268Z |  |  | 

---



---

# Sutthiphong Sieber
*SieberSolutions*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Sales Consultant for Startups & Industrial Firms | SieberSolutions](https://siebersolutions.com/)
*2024-01-01*
- Category: article

### [EP. 03: How AI is Shaping the Future: Six Essential Transformations in SaaS by The Product Launch Show](https://creators.spotify.com/pod/profile/sieber-consulting/episodes/EP--03-How-AI-is-Shaping-the-Future-Six-Essential-Transformations-in-SaaS-e2pn6bb)
*2024-11-10*
- Category: podcast

### [Interview: Beryl 8 (BE8) | ThaiCapitalist](https://www.thaicapitalist.com/interview-beryl-8-be8/)
*2025-02-24*
- Category: article

### [#36: The Power of a Global Network with Stephan Sieber CEO of Transporeon](https://alcottglobal.com/podcast/leaders-in-tech-and-ecommerce-podcast/36-the-power-of-a-global-network-with-stephan-sieber-ceo-of-transporeon)
*2025-03-03*
- Category: podcast

### [In Conversation: Combining Storytelling and Chess with Jon Sieber, CEO of Chess at Three](https://www.augustman.com/sg/people/in-conversation-how-to-think-three-moves-ahead-with-jon-sieber-ceo-of-chess-at-three/)
*2023-09-05*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[CRM Full, Growth flat, Why?](https://siebersolutions.com/blog/lead-enhancing)**
  - Source: siebersolutions.com
  - *CRM Full, Growth flat, Why? June 6, 2025 - Sutthiphong Sieber. CRM Full, Growth flat, Why? ... It is exactly the kind of work I do with SaaS teams. © ...*

- **[Untitled](https://siebersolutions.com/blog-lead-habit)**
  - Source: siebersolutions.com
  - *How to Make Lead Scoring a Habit (Without Hating It). June 6, 2025 - Sutthiphong Sieber ... Gross. But ... Read More. © 2024 SieberSolutions ......*

- **[Why Your Sales Team Keeps Chasing the Wrong Leads (And How ...](https://siebersolutions.com/blog/brokenleadgen)**
  - Source: siebersolutions.com
  - *Why Your Team Keeps Chasing the Wrong Leads. June 6, 2025 - Sutthiphong Sieber ... Whe... Read More. © 2024 SieberSolutions. Features. My Offer ......*

---

*Generated by Founder Scraper*
