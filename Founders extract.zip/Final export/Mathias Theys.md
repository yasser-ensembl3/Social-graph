# Mathias Theys

## Position actuelle

**Titre** : Founder
**Entreprise** : BadRez Games
**Durée dans le rôle** : 6 years 3 months in role
**Durée dans l'entreprise** : 6 years 3 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Computer Games

## Résumé

I read all the messages, but have to pick those I answer to. Don't feel offended if I don't get back to you :)

Strongly motivated and passionate hard-working video game programmer with 8+ years of experience in the professional game industry.

I have been mostly working with the technology team as a tools programmer. I have contributed to deliver many game development tools (level editors, content editors, pipeline and automation tools) for independent, mobile and AAA projects.

As a tools programmer, what I like the most is to work on efficient and high quality products, in collaboration with the content and production teams, to help them have a better day, everyday.

My preferred missions are mainly oriented on setting up and enhancing game development processes, pipelines and quality integration (smoke testing, continous integration, automation tools, etc.). I consider myself between a Tools Programmer and a Build Engineer.

Additionnally, I've been growing some skills in project management and team leading through personal projects (using Scrum, XP), and I would like to be a game/technology producer in the long run.

I want to make life easier for everyone !
And if we turn out to work together, no matter how high challenges become, I will not let you down.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAfn81wBVjDkcno3epC0VlW5icvpodT39yc/
**Connexions partagées** : 3


---

# Mathias Theys

## Position actuelle

**Entreprise** : BadRez Games

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mathias Theys

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389127947267502080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGFfjhp5o7KbA/feedshare-shrink_800/B4EZotz_QVHUAg-/0/1761705196112?e=1766620800&v=beta&t=WlI5tqgMrINzwaUd-FefjQCw5J4zrqM_rlzuBxzrNko | BadRez est à la recherche de son prochain animateur 3D!
Si vous faites des belles animations de combat et que ça vous intéresse, c'est le moment de les mettre en avant! ;) | 26 | 2 | 7 | 1mo | Post | Mathias Theys | https://www.linkedin.com/in/mathias-theys-25050838 | https://linkedin.com/in/mathias-theys-25050838 | 2025-12-08T06:12:10.237Z |  | 2025-10-29T02:36:25.987Z | https://www.linkedin.com/feed/update/urn:li:activity:7389127157354119168/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7383877696315023361 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGsic002XYdQA/feedshare-shrink_800/B56ZnjNAMAJwAk-/0/1760453461425?e=1766620800&v=beta&t=AnXYgWDvH5j_0iZ20bATX8IfLJ-7pHAjFFtdXE9uQjo | On est à la recherche d'un Community Manager chez BadRez :)
On est une super cool équipe avec qui travailler et on fait des projets intéressants.

Sans oublier qu'on est des super humains! | 12 | 3 | 1 | 1mo | Post | Mathias Theys | https://www.linkedin.com/in/mathias-theys-25050838 | https://linkedin.com/in/mathias-theys-25050838 | 2025-12-08T06:12:10.237Z |  | 2025-10-14T14:53:48.615Z | https://www.linkedin.com/feed/update/urn:li:activity:7383877001453121537/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7327753328526860289 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZQODg9qz8HQ/feedshare-shrink_800/B4EZbE_MIZGQAk-/0/1747061621770?e=1766620800&v=beta&t=fNw7mO-QSl3LiVwlckWuP17ZVHuvkEP_EALSXpPVE_0 | Un poste intéressant ouvert à l'Asylum! | 3 | 0 | 0 | 6mo | Post | Mathias Theys | https://www.linkedin.com/in/mathias-theys-25050838 | https://linkedin.com/in/mathias-theys-25050838 | 2025-12-08T06:12:10.238Z |  | 2025-05-12T17:55:36.594Z | https://www.linkedin.com/feed/update/urn:li:activity:7327707551574245377/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7316162479158427649 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3xE05kH9gDA/feedshare-shrink_800/B4EZYg6xFCHcAg-/0/1744308999151?e=1766620800&v=beta&t=w4Nxzx9UuaY9KuE54jSr8H5OJXJ3-kf0URaZSOx9tK0 | Our next fighting game just got funded and we're looking for people to help :) | 72 | 9 | 15 | 7mo | Post | Mathias Theys | https://www.linkedin.com/in/mathias-theys-25050838 | https://linkedin.com/in/mathias-theys-25050838 | 2025-12-08T06:12:12.266Z |  | 2025-04-10T18:17:42.757Z | https://www.linkedin.com/feed/update/urn:li:activity:7316162217626783744/ |  | 

---



---

# Mathias Theys
*BadRez Games*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 17 |

---

## 📚 Articles & Blog Posts

### [Mathias Royer: Publishing, Team Building & Studio Development](https://byteaction.substack.com/p/mathias-royer-publishing-team-building?utm_campaign=post&utm_medium=web)
*2024-07-18*
- Category: blog

### [Mathias Royer: Publishing, Team Building & Studio Development | ByteAction](https://byteaction.podbean.com/e/from-france-to-barcelona-building-a-gaming-empire/)
*2024-07-19*
- Category: article

### [Interviews - Indie Goodies](https://indiegoodies.com/interviews)
*2024-10-21*
- Category: article

### [Developing Chess Fighting Game Checkmate Showdown](https://80.lv/articles/developing-chess-fighting-game-checkmate-showdown/)
*2023-06-30*
- Category: article

### [Zefyr Developer on 11 Year Development and Childhood Inspirations](https://www.respawnstation.com/2024/10/zefyr-developer-interview/)
*2024-10-17*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Developing Chess Fighting Game Checkmate Showdown](https://80.lv/articles/developing-chess-fighting-game-checkmate-showdown)**
  - Source: 80.lv
  - *Jun 30, 2023 ... BadRez Games' Mathias Theys and ManaVoid Entertainment's Christopher ... Podcasts Round Table. © 2025. 80 level. All rights reserved....*

- **[Checkmate Showdown Announced! — Analog Stick Gaming](https://www.analogstickgaming.com/news-1/2023/6/13/checkmate-showdown-announced)**
  - Source: analogstickgaming.com
  - *Jun 13, 2023 ... Podcast · About · Contact · Analog Stick Gaming · News. Reviews. GOTY · 2025 ... Founded by Mathias Theys and Jon Cote, BadRez Games ...*

- **[TORQ produit « Qui s'en charge » pour Unis TV - Qui fait Quoi / Lien ...](https://qfq.com/spip.php?article105260&debut_dossier_10DerniersArticles=2424)**
  - Source: qfq.com
  - *Mathias Theys développe des jeux de combat atypiques à la tête de BadRez Games....*

- **[« Pervers ordinaire », une comédie policière qui fait grincer des ...](https://qfq.com/spip.php?article67599&debut_dossier_10DerniersArticles=2328)**
  - Source: qfq.com
  - *Oct 26, 2018 ... Mathias Theys développe des jeux de combat atypiques à la ......*

- **[12e Cinema on the Bayou : les films canadiens font bonne figure ...](https://qfq.com/spip.php?article57706&debut_dossier_10DerniersArticles=2328)**
  - Source: qfq.com
  - *Mathias Theys développe des jeux de combat atypiques à la tête de BadRez Games....*

- **[Le jeu, une passion innée pour Élodie Grenier - Qui fait Quoi / Lien ...](https://qfq.com/spip.php?article70016&debut_dossier_10DerniersArticles=2448)**
  - Source: qfq.com
  - *Mathias Theys développe des jeux de combat atypiques à la tête de BadRez Games....*

- **[Alex Boya voit l'animation comme un langage universel - Qui fait ...](https://qfq.com/spip.php?article106719&debut_dossier_10DerniersArticles=2448)**
  - Source: qfq.com
  - *May 22, 2025 ... Mathias Theys développe des jeux de combat atypiques à la ......*

- **[« Rue de la Victoire » est le portrait sensible d'un dévoué à son art ...](https://qfq.com/spip.php?article59266&debut_dossier_10DerniersArticles=2376)**
  - Source: qfq.com
  - *Mathias Theys développe des jeux de combat atypiques à la tête de BadRez Games....*

- **[S'engager au nom des artistes : la mission de Stanley Février - Qui ...](https://qfq.com/spip.php?article100242&debut_dossier_10DerniersArticles=2256)**
  - Source: qfq.com
  - *Mathias Theys développe des jeux de combat atypiques à la tête de BadRez Games....*

- **[Les Barr Brothers dévoilent « English Harbour » avec Jim James et ...](https://qfq.com/spip.php?article108146&debut_dossier_10DerniersArticles=2352)**
  - Source: qfq.com
  - *Aug 21, 2025 ... Mathias Theys développe des jeux de combat atypiques à la ......*

---

*Generated by Founder Scraper*
