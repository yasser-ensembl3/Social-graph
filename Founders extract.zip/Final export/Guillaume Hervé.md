# Guillaume Hervé

## Position actuelle

**Titre** : CEO and Co-Founder
**Entreprise** : Zetane Systems
**Durée dans le rôle** : 7 years 11 months in role
**Durée dans l'entreprise** : 7 years 11 months in company

## Localisation & Industrie

**Localisation** : Kirkland, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

At Zetane Systems, we empower organizations to leverage ZetaForge, a workspace packed with GenAI powered tools that are easy and pain-free to use, and ensure employee adoption with tools they will love to use and share; all at much lower risk, cost and schedule. Our AI pipeline and development environment, ZetaForge, is available on GitHub and provides a easy to use, easy to deploy development environment to develop safe, trustworthy and explainable AI solutions efficiently, saving you time and money.

## Résumé

Everywhere I've been, I've been an agent of change, an entrepreneurial leader, a mentor to my teams, and an incubator of talent.

> My purpose: Helping leaders succeed

I help leaders and businesses grow by working alongside founders, C-suite executives, and leadership teams of organizations seeking to achieve strategic clarity, striving to deliver results via focused execution and alignment and aiming to develop and foster entrepreneurial cultures. I can help you succeed in the following manner:

> An active member of your Board of Directors
> Deploying corporate entrepreneurship (Intrapreneurship) systems and processes
> Assessing growth options
> Acquisitions and integrations, joint ventures and strategic partnerships
> Achieving results via strategic business objectives and organizational alignment
> An interim leadership role: senior executive, entrepreneur or intrapreneur in residence, agent of change
> A partner in your first 100 days
> A committed coach and mentor
> An engaging key note speaker and facilitator for leadership teams
> An extensive international experience in the aviation, aerospace, high technology, healthcare, software, academic, and government sectors.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADXbaABPvZIt0KEMnN_scJLMFDkETbz_Uk/
**Connexions partagées** : 90


---

# Guillaume Hervé

## Position actuelle

**Entreprise** : Zetane

## Localisation & Industrie

**Localisation** : Kirkland, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Guillaume Hervé

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399485526099046400 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFEXBp6yazBbg/image-shrink_800/B4EZoxUyB3IQAg-/0/1761764123600?e=1765778400&v=beta&t=VBtKvjw1S_aij17nq7rUk6I2iy37VBleMDcpPhu1qcw | The ready now alternative to the long, expensive, resource-intensive AI consulting projects.  Canada-built, ready now agentic AI productivity platform for business. | 2 | 1 | 0 | 1w | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:03.053Z |  | 2025-11-26T16:33:45.215Z | https://www.linkedin.com/feed/update/urn:li:activity:7389374316074860545/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7393621549775495169 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a235d926-8741-4f51-ac60-b0ae76a77f5f | https://media.licdn.com/dms/image/v2/D4E10AQGziGQCufJkXg/videocover-high/B4EZnd4Qs4KYAo-/0/1760364140735?e=1765778400&v=beta&t=M7NJqj1LCeCAfv-e9dKR4M9xQLBaCq4BiJ5L_DYcLIU | Beneficial disruption. | 10 | 2 | 0 | 3w | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:03.054Z |  | 2025-11-10T12:12:24.312Z | https://www.linkedin.com/feed/update/urn:li:activity:7383502433303560192/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7390878464746168321 | Text |  |  | Un plaisir d’avoir été invité par Jon Druker et PME MTL pour apporter la voix de Zetane riche  de notre expérience acquise dans le cadre de plus de 50 projets concrets d'IA réalisés pour l'industrie. | 9 | 1 | 0 | 1mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:03.055Z |  | 2025-11-02T22:32:21.877Z | https://www.linkedin.com/feed/update/urn:li:activity:7390183508473815040/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7379186119730700288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF2CRUtQuggbg/feedshare-shrink_800/B4EZmgiqduIIAg-/0/1759335067904?e=1766620800&v=beta&t=qb2QbydiV-orWnlGinpAKFr2TKCg5Bh7tSMk7GTwJNU | Isabelle Turcotte, Charlotte BA and Sergio Morales A warm THANK YOU / Grand MERCI from Zetane.  Of all the AI conferences we attended in the past 6 years, ALL IN 2025 was by far the most successful.  I can summarize it in three points:
1. The most meaningful business conversations on using our Agentic AI plarform to help companies right away.
2. Results with 150 new registered users of the ZetaForge generative AI tools for RFPs, Bids and Proposals and large document management.
3. A great vibe with an AI edge and lots of help from many people. 

Go CANADA Go.... Those three A's in Canada are for AI AI AI, eh! | 31 | 3 | 1 | 2mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:03.057Z |  | 2025-10-01T16:11:09.592Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7363896664266272768 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8a467ca5-973e-4016-be40-8fffdc3c4a30 | https://media.licdn.com/dms/image/v2/D4E10AQEPsJchESKtig/ads-video-thumbnail_720_1280/B4EZg3l_TrHgAg-/0/1753279363276?e=1765778400&v=beta&t=iknoGoCxrtQt4F7Jan1gNnq_aY800AT62U5lOLTaOrI | Looking for rapid adoption of AI to save time in day to day tasks! Our head of marketing and product manager walks you through a quick overview of our Agentic workspace loaded with GenAI powered tools that are easy to use and really easy to get started. | 4 | 0 | 0 | 3mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.538Z |  | 2025-08-20T11:36:19.345Z | https://www.linkedin.com/feed/update/urn:li:activity:7353786966095634432/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7361022047864459264 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH55vZszoctcg/feedshare-shrink_800/B56ZieaitFHUAk-/0/1755004415891?e=1766620800&v=beta&t=D2eLBUwO_ezeANZYiROjPTlVlYrVXJmmH-tb4LIwI54 | Quand consacrer son temps précieux correspond à ses valeurs. Merci à Confiance IA de me donner l'occasion de diriger le comité directeur de cette importante initiative sur la #trustAI #responsibleAI au Québec. C'est un honneur de siéger aux côtés de leaders d'opinion du coté industriel: David Chapdelaine de CAE, Jean-François Gagnon de Thales, Amine Salah de FENETEC, et Francoys Labonté du CRIM. Zetane était un membre fondateur en tant que jeune entreprise en démarrage, et c'est formidable de voir cette vision devenir réalité. Merci pour son support Philippe Duguay, Ph.D. du Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE) et le visionnaire Philippe Molaret. 
--------
When giving precious time aligns with your values. Thanks to Confiance IA for this opportunity to lead the Directing Committee for this important initiative on #trustAI #responsibleAI in Québec. An honour to sit alongside thought leaders from industry: David Chapdelaine of CAE, Jean-François Gagnon of Thales, Cortaix, Amine Salah of FENETEC et Françoys Labonté of CRIM.  Zetane was a founding member as a fledging startup and it's cool to see vision become reality. Thank you for your support Philippe Duguay and for your vision Philippe Molaret. | 96 | 9 | 4 | 3mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.540Z |  | 2025-08-12T13:13:37.387Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7358580531560607745 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFf5P-OkYCsEw/feedshare-shrink_800/B4EZh7t_23HEAg-/0/1754422313532?e=1766620800&v=beta&t=VfV5wFFUVgcFNono7yZ1zlrznIIuhKebGqen2Ouzm4s | Who knew we had Canada’s most active FinTech accelerator in downtown Montreal? Great experience today visiting Station Fintech Montréal hosted by the always engaging Aboubacar Any and his team. Great space and services at 4 Place Ville Marie. | 15 | 1 | 0 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.540Z |  | 2025-08-05T19:31:54.539Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7356155306944438272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/46c61fc1-efb1-42b8-8376-7fc061157d06 | https://media.licdn.com/dms/image/v2/D4E05AQFLnclVObRf2w/feedshare-thumbnail_720_1280/B4EZhXE7SUGUA8-/0/1753807567817?e=1765778400&v=beta&t=UU8dSoNmPgqtb3asL7CYpw_httLbwbYTN8OhrXuMUB4 | Look what Québec Tech just shared. | 16 | 0 | 1 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.541Z |  | 2025-07-30T02:54:55.932Z | https://www.linkedin.com/feed/update/urn:li:activity:7356002168396521474/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7354236499690749952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0121be11-1613-41b4-a9b8-ae34d11ae46a | https://media.licdn.com/dms/image/v2/D4D10AQFreZOhG4j15A/ads-video-thumbnail_720_1280/B4DZg82PfFGsAg-/0/1753367509996?e=1765778400&v=beta&t=gnj7a_LukThO2hWQ-sF06DrmuKnm61K5juenAEhnN1g | Chat GPT on lots of steroids. Ready now. Very generous free trial. Save hours a week. Out of the box. | 4 | 0 | 0 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.543Z |  | 2025-07-24T19:50:16.633Z | https://www.linkedin.com/feed/update/urn:li:activity:7354156440925696000/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7353745824855588866 | Article |  |  | You have kids making career choices?  You are in the acquisition and management of talent? You are a leader in an organization? You are wondering what up-skilling training you might want to invest in?  Read these fascinating insights from World Economic Forum. | 9 | 0 | 0 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.544Z |  | 2025-07-23T11:20:30.636Z | https://www.weforum.org/publications/the-future-of-jobs-report-2025/digest/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7351618691907616769 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2a05e563-9ee6-4166-8a3a-7ab39e56d767 | https://media.licdn.com/dms/image/v2/D4E05AQEqWoZwT3za4A/feedshare-thumbnail_720_1280/B4EZgU2GOMGoBA-/0/1752696384035?e=1765778400&v=beta&t=qVtf8GnglbgsDJRfpJMKq-qH0i289ZMsAUoxLRC6-60 | Some very important strategic points on Canada's position on AI being raised in this video.  What an honour for Zetane to have been asked to join this select group at the AI table and interact with the honourable Evan Solomon and other Canadian thought leaders.  Thanks to our partners who joined us: Stéphane Oehrli of Ivaco Rolling Mills, shyma hassan of Maison Social and Pascal Meunier and Francis Perron of Trinary. | 10 | 1 | 3 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.545Z |  | 2025-07-17T14:28:02.621Z | https://www.linkedin.com/feed/update/urn:li:activity:7351589014203703296/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7350919191866081280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4c063686-13f0-47bd-8a00-146e8eb4818b | https://media.licdn.com/dms/image/v2/D5610AQHUZbph6x8cyw/ads-video-thumbnail_720_1280/B56ZgOp7njHMAc-/0/1752592531162?e=1765778400&v=beta&t=ouKGVj9t6RahBzgtDp2RDdIo_VwzJpPYOJqFsbyDsU8 | You want to be the leading GenAI platforms for rapid adoption by Canada’s SMEs? This is what it takes.  It certainly grabbed minister Evan Solomon’s attention at the SCALE AI - Canada's AI Cluster offices last week.  Thank you Scale AI and our partners. #GenAI #AgenticAI | 8 | 0 | 0 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.546Z |  | 2025-07-15T16:08:28.815Z | https://www.linkedin.com/feed/update/urn:li:activity:7350905972913025024/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7349072573646729217 | Video (LinkedIn Source) | blob:https://www.linkedin.com/aab96c90-f971-41ea-ac1d-fd9f4a6a7613 | https://media.licdn.com/dms/image/v2/D5605AQG8jBkYnmB6tA/videocover-low/B56Zf0mQYxHoCE-/0/1752155431086?e=1765778400&v=beta&t=dk8pqlRNzPkhsUKAq0_8xJcY1nNOf5wYzsA_6L1sBHw | Recognition and thank you. Some of the most active and giving people in the startup community in Montreal with a coast to coast influence. Congratulations to Jean-Nicolas Delage for being added this year. | 17 | 1 | 0 | 4mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.547Z |  | 2025-07-10T13:50:40.723Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7347995184288194561 | Video (LinkedIn Source) | blob:https://www.linkedin.com/58fc2ab6-8bab-4327-9625-6d94ba3773d5 | https://media.licdn.com/dms/image/v2/D4E10AQF5jpCGpB-ySA/ads-video-thumbnail_720_1280/B4EZflMmA_HgAc-/0/1751896974572?e=1765778400&v=beta&t=FvrQFlcXJQDxcFKuRTBITTsE_SBEGl_NNCgE58VSnVY | We changed the rules. 

We were tired of seeing a large AI  consultancy industry charge large amounts and demand large commitments from companies wanting to undertake a digital transformation. So we changed the rules. To make #GenAI and #DigitalTransformation affordable and accessible to all. 

Check us out. 
Check out ZetaForge | 14 | 0 | 1 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.548Z |  | 2025-07-07T14:29:31.083Z | https://www.linkedin.com/feed/update/urn:li:activity:7347988635348090880/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7346588099566600192 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5ebb9393-4d48-4ac3-ad65-68fbfb9c9901 | https://media.licdn.com/dms/image/v2/D4E10AQFp0PsVj5xzpg/ads-video-thumbnail_720_1280/B4EZfQoUknHwAg-/0/1751551921587?e=1765778400&v=beta&t=aHWdJ_FlwBi9n6BSw89O4VY7VW2tai08dYGt3D8H1tk | Thoughts ? | 2 | 0 | 0 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.549Z |  | 2025-07-03T17:18:15.943Z | https://www.linkedin.com/feed/update/urn:li:activity:7346541298260058114/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7343679098474381313 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7752e7ac-0c6a-4354-8763-420474c26e37 | https://media.licdn.com/dms/image/v2/D4E10AQH5cWFX3RAc5A/videocover-low/B4EZenZkhyHYBQ-/0/1750860203054?e=1765778400&v=beta&t=796kb2YtylOgyjc2Ggh_tUt8zQmkzpCxDO9g6wIzsg4 | Many many people have asked me how Zetane got started. From a great idea to a great prototype to explainable AI to now, a toolbox of Gen AI powered time savers. Well, thanks to the magic of 🇨🇦 Brooke Davidson Hoareau, here is a vignette. What a great ride it’s been with Patrick St-Amant , Jon Magoon and the great Zetaners! | 19 | 1 | 0 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.550Z |  | 2025-06-25T16:38:56.036Z | https://www.linkedin.com/feed/update/urn:li:activity:7343640078495150081/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7339709696368422912 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9d9b69df-4a5b-400b-9591-fecdde3af88b | https://media.licdn.com/dms/image/v2/D4E05AQGBKZWiT1VZCQ/videocover-low/B4EZdvi3p3HIB0-/0/1749923149596?e=1765778400&v=beta&t=XBNsK29XGSUBzkn59R4omc_r9aeR_03FMTbn8Rk46aw | Proudly Canadian and on the wall of fame. Zetaining new heights at Zetane . | 26 | 2 | 2 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.550Z |  | 2025-06-14T17:45:56.826Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7339214092705955840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1x3Lm8Hd1_w/feedshare-shrink_800/B4EZdogTHXGwAg-/0/1749804994287?e=1766620800&v=beta&t=j4vp1KsRDXLJrmLOAJ6-z4PpelC2-xDRxFhJfWUNIeI | Le Québec très bien représenté a VIVA Tech à Paris. Merci Québec Tech et SCALE AI - Canada's AI Cluster. Richard Chenier serait fier. Je garde la tradition casquette. | 77 | 9 | 1 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.551Z |  | 2025-06-13T08:56:35.705Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7338465196174155776 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d3f9e818-60ba-4dd9-946a-88adfbc7b388 | https://media.licdn.com/dms/image/v2/D4E05AQGEY_lQc5yDqQ/videocover-high/B4EZdd3C1IGcB4-/0/1749626431900?e=1765778400&v=beta&t=MARQqlQbPl6NUaRA0LHzm5LUedZb2Ijl2QnKzN84rFI | Thanks to SCALE AI - Canada's AI Cluster and @ALL IN and the great leadership and organization of Isabelle Turcotte and Charlotte BA and their team. | 28 | 1 | 3 | 5mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.552Z |  | 2025-06-11T07:20:44.858Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7336767649659461632 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d7abd3ab-35f8-4f23-8e83-5c50c9b27f60 | https://media.licdn.com/dms/image/v2/D4D10AQGg7Z8hEK5hYQ/ads-video-thumbnail_720_1280/B4DZdAgQ8gGUAo-/0/1749133890190?e=1765778400&v=beta&t=EjVp8VJoRczblUg0m9drXZ2N0YyI80898qkshF3zeD0 | Guess what? I will represent our great Zetaners at VIVA Tech next week, representing the best of Canadian AI at the Canadian pavilion. Zetane was selected from across Canada. How cool is that. 🇨🇦🍁proud! | 10 | 2 | 0 | 6mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.553Z |  | 2025-06-06T14:55:18.230Z | https://www.linkedin.com/feed/update/urn:li:activity:7336399328812412929/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7327707247201964037 | Article |  |  | Very timely discussion.  Live event in Ottawa  or Live stream option. | 5 | 2 | 0 | 6mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.554Z |  | 2025-05-12T14:52:29.950Z | https://www.eventbrite.ca/e/bluwave-ai-summit-h1-2025-the-canadian-energy-sector-in-the-world-economy-tickets-1334477601429?aff=oddtdtcreator |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7326640860035518466 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9433bd70-e51e-4d97-9873-167f6f37a123 | https://media.licdn.com/dms/image/v2/D4E10AQGWw8uMoX50BQ/videocover-high/B4EZa1WykdHoAw-/0/1746799374567?e=1765778400&v=beta&t=4W1yUOXLL6Ii504b4Y_SUUHU1ylGN9PS2uElBk5e0Js | To all our followers interested in the convergence of AI and the global energy transition, please check this line up of incredible soeakers. 
Stephen Lecce Ontario Minister of Energy, Erin O'Toole former leaders of the Conservative party of Canada and former lawyer at the Independent Electricity System Operator (IESO), Jeff Wright from energy major Brookfield Renewable, Pierre Rivard Chairman of TUGLIQ Energy Corp. decarbonizing the far north, and Devashish Paul, Founder and CEO BluWave-ai 

Please join us in person at 1330 EDT on 13 May at Invest Ottawa or online for the livestream at 1400 EDT. | 6 | 1 | 0 | 6mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.555Z |  | 2025-05-09T16:15:03.437Z | https://www.linkedin.com/feed/update/urn:li:activity:7326607645891616771/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7325918374012596224 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a4412b9a-bf81-46dc-bc53-9beeec0cff4c | https://media.licdn.com/dms/image/v2/D4D05AQFrW2j8aamSjw/videocover-high/B4DZamL7nFG8Bg-/0/1746544872783?e=1765778400&v=beta&t=It02JGpvBXfLovvLzlLrAAtYU1TcPrSSn9vZWXyHIwM | Great sense of 🇨🇦 pride with this one.  Showcasing the best of Canada's innovative companies. | 11 | 0 | 0 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.556Z |  | 2025-05-07T16:24:09.346Z | https://www.linkedin.com/feed/update/urn:li:activity:7325882119283462167/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7325126407724875777 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHVDoHHZ_I3nQ/feedshare-shrink_800/B56ZaZKLI3HUAg-/0/1746326303774?e=1766620800&v=beta&t=9PbRCQacG79rV9tfI6LuD8cbpQBIdoTfQiUAMiCl_o4 | Very insightful piece by Stephen Klein on the fear mongering happening in AI consulting. My latest keynote explained how the industry got here and how deploying AI/GenAI tools to support many of your business needs does not have to cost you months and lots of money. | 3 | 1 | 0 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.557Z |  | 2025-05-05T11:57:09.869Z | https://www.linkedin.com/feed/update/urn:li:activity:7324623407336054784/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7323681393891319808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2YO57IaRhUg/feedshare-shrink_800/B4EZaLxalKHMAg-/0/1746101710924?e=1766620800&v=beta&t=iiOWo8Vgr3EPNPUIgIlsTEGN-gwIkKJFJ46NvVzPfbw | "EVERYTHING I'VE LEARNED IS FROM THE GENEROSITY OF SOMEONE ELSE." Spoken by John Sicard at the EY Techopia event held in Ottawa at the EY wavespace facility.  I have spent 2 full days of meetings and panels and speakers with brilliant insights, yet that is the one quote that sticks the most.  We must do a better job promoting entrepreneur successes from outside of respective provinces.  I am ashamed to admit that I did not know about John and the astonishing success of Kinaxis.  Shout out to Warren Tomlin for his vision of Techopia and for the invitation. Zetane #entrepreneurs, #startups, #canadianstartups, #genai | 14 | 2 | 1 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.558Z |  | 2025-05-01T12:15:11.724Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7323061812785012737 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGBxCJ8w_DqLQ/feedshare-shrink_800/B4EZaCsp6LHIAg-/0/1745949480809?e=1766620800&v=beta&t=mXyD1nZbOobgA14raeLP3lBP2BpwLx-qtWmbgslyzjY | Lots of learning at the NACO summit in Ottawa. Alongside successful entrepreneur Devashish Paul from BluWave-ai revolutionizing the EV infrastructure. Learning from VCs, fellow entrepreneurs, LPs, family offices, and ecosystem actors.  The GenAI message is resonating very loud and clear. Zetane | 19 | 0 | 1 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.558Z |  | 2025-04-29T19:13:12.077Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7323042899162505216 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGBxCJ8w_DqLQ/feedshare-shrink_800/B4EZaCsp6LHIAg-/0/1745949480809?e=1766620800&v=beta&t=mXyD1nZbOobgA14raeLP3lBP2BpwLx-qtWmbgslyzjY | Lots of learning at the NACO summit in Ottawa. Alongside successful entrepreneur Devashish Paul from BluWave-ai revolutionizing the EV infrastructure. Learning from VCs, fellow entrepreneurs, LPs, family offices, and ecosystem actors.  The GenAI message is resonating very loud and clear. Zetane | 11 | 0 | 2 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.559Z |  | 2025-04-29T17:58:02.718Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7321884605895094272 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E10AQHNEU0RBdXl_Q/ads-video-thumbnail_720_1280/B4EZZpQwlQHEAY-/0/1745522723906?e=1765778400&v=beta&t=UMDeVy3zfmfmijqXwqMIvrDaVcebYHhrZparKp_Aay0 | 300 AI practitioners and leaders from industry chose this session over many others.  The title and key insights resonated strongly and led to dozens of conversations. You want to hear about why GenAI is an extinction level event for SMEs and other large companies? You seek to understand why AI consulting charges so much money? Are you heading towards death by a thousand cuts? How about 50X to 100X savings over traditional AI implementation approaches?
#GenAI, #ML, #DeepLearning, #IndustrialAI, #WSAI, World Summit AI, #AIServices, #digitaltransformation, #SME | 5 | 0 | 0 | 7mo | Post | Guillaume Hervé | https://www.linkedin.com/in/guillaume3point0herve | https://linkedin.com/in/guillaume3point0herve | 2025-12-08T05:13:08.560Z |  | 2025-04-26T13:15:24.083Z | https://www.linkedin.com/feed/update/urn:li:activity:7321252992354041856/ |  | 

---



---

# Guillaume Hervé
*Zetane*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 31 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [Feasting on Peanut Butter in a Basement: An Interview with ...](https://medium.com/zetane-blog/feasting-on-peanut-butter-in-a-basement-an-interview-with-the-founders-of-zetane-b061feb0019)
*2020-12-08*
- Category: blog

### [2023 Speakers - All In AI Event](https://allinevent.ai/pages/2023-speakers)
- Category: article

### [Interview: Gwénaëlle Hervé on the types of cloud](https://proximus.be/en/id_b_cl_gwenaelle_herve_cloud_types/companies-and-public-sector/news/news-blog/webinars-keynotes-and-videos/interview-gwenaelle-herve.html)
*2025-05-28*
- Category: blog

### [Zetane Systems: Empowering Industries with Scalable AI Solutions](https://www.cioreview.com/zetane)
*2025-01-01*
- Category: article

### [Zetane Systems | The Org](https://theorg.com/org/zetane)
*2025-02-13*
- Category: article

---

## 🎬 YouTube Videos

- **[Certificat Digital Native : trois questions à Guillaume Hervé](https://www.youtube.com/watch?v=NP2vEYeVtbM)**
  - Channel: Mines Paris - PSL
  - Date: 2022-05-31

- **[FEX Symposium 2017 - Guillaume Herve](https://www.youtube.com/watch?v=pPjXkTOOoeI)**
  - Channel: Family Enterprise Canada
  - Date: 2017-12-12

- **[#ScaleupInsights: Zetane, démystifier l’IA dans les industries à haut risque](https://www.youtube.com/watch?v=GN7SOVxwk8M)**
  - Channel: Startup Montréal
  - Date: 2023-03-01

- **[guillaume hervé trampo 2011](https://www.youtube.com/watch?v=LQtwUvZ33xw)**
  - Channel: billout069
  - Date: 2011-12-03

- **[Visite officielle le 24 mars 2021 - Mise en œuvre du plan de relance / Ségur de la Santé](https://www.youtube.com/watch?v=2pX0bvURJNY)**
  - Channel: Croix-Rouge Compétence NORMANDIE
  - Date: 2021-04-01

- **[Maieusthesie - #9 Un quelqu&#39;un en habit de personne](https://www.youtube.com/watch?v=Wm41f8mQWes)**
  - Channel: Pod Castor
  - Date: 2021-02-28

- **[Obtain more trustworthy AI solutions for enterprise with more transparency: conference presentation](https://www.youtube.com/watch?v=E6Sb6MB0VgY)**
  - Channel: Zetane
  - Date: 2021-06-21

- **[Say Whaaat?! AI Adoption In Your Company Does Not Need to Take Months and Cost Hundreds of Thousands](https://www.youtube.com/watch?v=4k_pN2rSFTQ)**
  - Channel: Zetane
  - Date: 2025-04-24

- **[The Canadian Energy Sector in the World Economy | BluWave-ai Global Energy Transition Summit H1 2025](https://www.youtube.com/watch?v=yHAf_HNw0DM)**
  - Channel: BluWave-ai
  - Date: 2025-05-14

- **[Présentation - Guillaume HERVE](https://www.youtube.com/watch?v=E1G_xaHpYtA)**
  - Channel: guillaume herve
  - Date: 2021-10-18

---

## 🔎 Press & Mentions

- **[Guillaume Hervé – Helping Businesses and Leaders Grow Through ...](https://canadiansme.ca/guillaume-herve-helping-businesses-and-leaders-grow-through-innovation-steered-strategies/)**
  - Source: canadiansme.ca
  - *Mar 6, 2022 ... Guillaume Hervé is the co-founder and CEO of Zetane. Previously, Mr ... Podcast · Business Partners · Strategic Partners · Contact Us ...*

- **[Artificial Intelligence for Construction Estimating | For Construction ...](https://www.forconstructionpros.com/construction-technology/article/22056304/artificial-intelligence-for-construction-estimating)**
  - Source: forconstructionpros.com
  - *Feb 15, 2022 ... ... Zetane Systems today announced an initiative with its customer ... Guillaume Herve' told ForConstructionPros in a phone interview...*

- **[SPEAKERS - World Summit AI Canada](https://americas.worldsummit.ai/speakers/)**
  - Source: americas.worldsummit.ai
  - *... Zetane Systems. Aleksandra Faust. Research Director. Google DeepMind. Guillaume Herve ... podcasts, including the Regulating AI Podcast with Sanja...*

- **[June | 2022 | janaaxline](https://janaaxline.com/2022/06/)**
  - Source: janaaxline.com
  - *Jun 29, 2022 ... Guillaume Herve, co-founder and CEO of Zetane Systems, is a serial ... Podcast (125), project management (7), Radio (19), Uncategoriz...*

- **[ALL IN | 2023 Speakers – ALL IN Website](https://allinevent.ai/pages/2023-speakers)**
  - Source: allinevent.ai
  - *Rob Kenedi. Co-Host, BetaKit Podcast. More information. Co-Host, BetaKit ... Guillaume Hervé. CEO and cofounder, Zetane Systems. More information. CEO...*

- **[Untitled](https://conseilinnovation.quebec/wp-content/uploads/2024/02/Recueil_Contributions_VF.xlsx)**
  - Source: conseilinnovation.quebec
  - *Guillaume Hervé, Au nom d'une organisation (veuillez la nommer en 10 mots ou ... Zetane pour démontrer objectivement que la solution répond à un nivea...*

- **[ALL IN | 2023 Programming – ALL IN Website](https://allinevent.ai/pages/2023-programming)**
  - Source: allinevent.ai
  - *Rob Kenedi | Co-Host, BetaKit Podcast. Schedule 12:00-12:20. Location Stage 2 ... Guillaume Hervé | CEO and cofounder, Zetane Systems. Moderator. Fran...*

- **[The Canadian Energy Sector in the World Economy | BluWave-ai ...](https://www.youtube.com/watch?v=yHAf_HNw0DM)**
  - Source: youtube.com
  - *May 14, 2025 ... ... Guillaume Hervé: CEO and Founder, Zetane Systems • Erin O'Toole: President and Managing Director, ADIT North America (Former Lead...*

- **[Guillaume Hervé: Mission to Make Artificial Intelligence Safer, More ...](https://madeinca.ca/guillaume-herve-zetane-systems/)**
  - Source: madeinca.ca
  - *Jul 1, 2022 ... Home » Interviews » Guillaume Hervé: Mission to Make Artificial ... Zetane's mission is to make artificial intelligence safer, more .....*

- **[Zetane launches Online Service to Streamline the production of ...](https://blog.worldsummit.ai/zetane-launches-online-service-to-streamline-production-robust-ai-computer-vision)**
  - Source: blog.worldsummit.ai
  - *May 4, 2022 ... ... Zetane, Guillaume Hervé. “To solve this pressing need in industry ... Interview (64) · AIbrains (27) · AI ethics (20) · Machine Le...*

---

*Generated by Founder Scraper*
