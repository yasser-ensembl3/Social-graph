# Mathieu Boulianne

## Position actuelle

**Titre** : Co-Founder and CEO
**Entreprise** : Aviron
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Software Development

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAL1T6cBcpaWzMcVJI-6LedbuA7200eEwDE/
**Connexions partagées** : 215


---

# Mathieu Boulianne

## Position actuelle

**Entreprise** : Aviron

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 1st


---

# Mathieu Boulianne

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402725641202335744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEnqSgEd45TLA/feedshare-shrink_800/B4EZrvBucTHoAg-/0/1764946798733?e=1766620800&v=beta&t=Wv8212OzSoNg9D5PoZit5w7U2HOq_6iQCM80kjj5NBg | Comme entrepreneur, je crois profondément que l’avenir du secteur manufacturier passe par la collaboration, l’innovation et l’adoption intelligente des technologies. Rejoindre le STIQ est une étape naturelle pour nous: cela nous permet de nous rapprocher encore plus des acteurs qui façonnent l’industrie d’aujourd’hui et de demain. | 15 | 1 | 0 | 2d | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:50.518Z |  | 2025-12-05T15:08:48.854Z | https://www.linkedin.com/feed/update/urn:li:activity:7402723423153442816/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401658087503417344 | Text |  |  | I believe AI will transform the enterprise, but not through generic copilots.
The real impact will be in the back office, where fragmented processes slow growth, bleed revenue, and strain teams.

Yet finance teams are still trapped in brittle automations, email chains, spreadsheets, and manual handoffs. ERPs were never designed to automate the last mile, and tools like RPA, OCR, and BPOs require months to deploy, break on exceptions, and automate only a fraction of the work.

That is why we built Aviron.
We learn how your business actually operates, then execute Procure-to-Pay and Order-to-Cash workflows with consistency, auditability, and governance across the systems you already use.

Fast. Adaptive. Resilient.
This is what the intelligent back office looks like. | 18 | 1 | 1 | 5d | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:50.518Z |  | 2025-12-02T16:26:44.218Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399487208723881984 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFwDmjQ8gaD2Q/feedshare-shrink_800/B4EZrBCZ40KcAg-/0/1764175225128?e=1766620800&v=beta&t=sL6uetSoUEGI6sFgGIKY2Nil1IdF5RL5Xp4z9yfWheQ | I'm proud to share a big milestone at Aviron today: we have officially achieved SOC 2® Type I compliance.

From day one, we built Aviron on a simple principle: security is not a feature - it is the foundation. Our clients trust us with their most sensitive financial and operational data, and that trust extends across every customer we serve, from SMBs to government agencies operating in mission-critical environments.

SOC 2® Type I is independent validation that our controls, processes, and protections meet the highest industry standards. And it is only the beginning - our SOC 2® Type II audit is already underway.

Aviron is an applied AI company transforming finance and procurement through agentic automation. Our platform deploys in days, integrates seamlessly with ERPs, CRMs, Outlook, Teams, and internal systems, and creates a unified workspace where finance and procurement work gets done. Whether procure-to-pay or order-to-cash, every workflow our agents execute is built on bank-grade security, complete auditability, and infrastructure hosted entirely in Canada.

No matter your size, every customer receives the same level of protection, privacy, and rigor.

Security has always been the bedrock of Aviron, and today’s milestone is a meaningful step forward in that commitment.

Onward. | 51 | 2 | 7 | 1w | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:50.519Z |  | 2025-11-26T16:40:26.384Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396970874081345536 | Text |  |  | Merci Jean-Francois Harvey! Très hâte de collaborer ensemble. Le Québec doit jouer un rôle clé dans l’accélération de l’innovation au Canada, et je suis très enthousiaste d’apporter la contribution d’Aviron - une entreprise basée à Montréal - au sein du CCI. | 2 | 0 | 0 | 2w | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:50.519Z |  | 2025-11-19T18:01:25.454Z | https://www.linkedin.com/feed/update/urn:li:activity:7396935885897867264/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7391948121502662656 | Text |  |  | 📣 Looking for a Fractional Office Manager (Downtown Montreal)

I’m currently looking for a fractional office manager to help us out 1–2 days per week at our downtown Montreal office.

If you know someone who’s looking for a flexible, part-time role or if you can share a trusted resource, I’d really appreciate your recommendations@

Please feel free to DM me or comment below.

Thanks in advance for helping spread the word! | 23 | 2 | 2 | 1mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.849Z |  | 2025-11-05T21:22:47.921Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7386385804937494528 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFe-Hyrb4p9pg/feedshare-shrink_1280/B4EZoE8s2tHMAs-/0/1761019613026?e=1766620800&v=beta&t=ybSZeenKWweTtzT5FNHNxQ67QA9L7IT5P6L-6QNarnE | Excited to share that this Wednesday, October 22, I’ll be representing Aviron at the Source Canada Summit!

I can’t help but feel this marks the beginning of a revival for Canada – a time when enterprises start embracing our innovators and builders.

Decline is a choice. Time to build Canada. 🇨🇦 | 31 | 2 | 2 | 1mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.851Z |  | 2025-10-21T13:00:08.309Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7359575067061542912 | Text |  |  | When finance teams hesitate on AI, it’s often for a good reason.

Most AI tools today are built for one narrow thing - AP automation, expense categorization, whatever - and they live in their own little world.

That’s the opposite of what CFOs need.

At Aviron, we don’t drop in another isolated bot.
We connect the dots - your ERP, your bank feeds, your email, your workflows - and make them work together.

It’s not about adding more tools.
It’s about finally making the ones you already have work like one brain. | 38 | 0 | 2 | 3mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.853Z |  | 2025-08-08T13:23:50.280Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7342994758178398209 | Text |  |  | It hit me recently:
I’m in the knowledge business.

Not software. Not automation.
Knowledge.

At Aviron, what we really do is capture fragmented expertise—SOPs buried in docs, workflows that live in someone’s head, the “unwritten rules” of how things get done—and turn it into structured, usable intelligence.

Our agents don’t just automate tasks.
They operationalize your institutional knowledge, so execution becomes scalable, consistent, and intelligent.

When you realize how much of your company’s value lives in how work gets done—not just what gets done—it changes how you think about growth. | 39 | 0 | 3 | 5mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.853Z |  | 2025-06-23T19:19:36.595Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7341269452547624962 | Text |  |  | A customer told me recently:
“For the first time, we can grow revenue without having to grow our backoffice.”

That one stuck with me.

Traditionally, more contracts meant more overhead. But not anymore.

At Aviron, we’re helping companies unlock their internal knowledge and streamline operations so they can scale revenue without scaling complexity.

It’s not just about doing more with less.
It’s about finally feeling like your company’s intelligence is compounding. | 51 | 0 | 2 | 5mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.854Z |  | 2025-06-19T01:03:51.678Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7320878562075439107 | Text |  |  | We’re hiring a Deployment Strategist at Aviron to help turn cutting-edge AI into real business outcomes. If you’re passionate about solving hard problems and making impact with AI, we’d love to talk. 

We’re looking for someone with a background in consulting, product, or data roles—someone who can navigate both technical and business conversations, and thrives in fast-moving environments. | 28 | 0 | 4 | 7mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.854Z |  | 2025-04-23T18:37:44.545Z | https://www.linkedin.com/feed/update/urn:li:activity:7320772076410212353/ | https://www.linkedin.com/jobs/view/4215053161/ | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7295909054781026304 | Article |  |  | We’re hiring a Forward Deployed Engineer (FDE) at Aviron—and this is a special role.

We’re not just looking for another engineer. We’re looking for someone based in Montreal who thrives on solving real-world business problems with AI and cutting-edge tech.

At Aviron, we believe AI is the key to making Canadian businesses 🇨🇦 more competitive, efficient, and resilient. Our FDEs are at the front lines of this transformation—embedding AI-driven solutions into enterprise operations to create massive impact.

If you:
✅ Love working with Go, system integrations, cloud services, and the Web Platform
✅ Think like an entrepreneur and move with speed & precision
✅ Enjoy the challenge of turning complex problems into elegant solutions

…then you belong at Aviron.

This is an opportunity to work with some of the smartest, most driven people in AI and automation. Let’s build something extraordinary together.

Interested or know someone who would be a great fit? Reach out or apply here: https://lnkd.in/eQeZP3DR | 14 | 0 | 2 | 9mo | Post | Mathieu Boulianne | https://www.linkedin.com/in/mathieuboulianne | https://linkedin.com/in/mathieuboulianne | 2025-12-08T05:15:54.856Z |  | 2025-02-13T20:57:50.095Z | https://aviron.ai/careers/forward-deployed-engineer |  | 

---



---

# Mathieu Boulianne
*Aviron*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [Aviron Interactive Inc.: Bootstrapping a Gamification Fitness Startup Case Study Solution, Information Technology Case Solution | Assignment Help](https://fernfortuniversity.com/essay/itech_case/aviron-interactive-inc-bootstrapping-gamification-fitness-startup-272)
*2025-06-03*
- Category: article

### [Montréal Startups List](https://builtinmtl.com/people)
*2017-01-01*
- Category: article

### [How 11 founders validated their ideas before building businesses that last](https://heraldcourier.com/news/nation-world/business/personal-finance/article_22480a87-5f8e-502f-a002-66c149e06adc.html)
*2025-12-07*
- Category: article

### [Video Games as part of Sports Communities](https://worldsofwordcraft.wordpress.com/2024/02/12/video-games-as-part-of-sports-communities/)
*2024-02-12*
- Category: article

### [The Strong Mind Strong Will Podcast](https://www.buzzsprout.com/2147967/episodes/13121937-what-two-startup-founders-have-learned-about-time-management-with-guests-mehdi-bouassami-and-jon-hsu)
*2023-06-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Le quotidien, lundi 24 octobre 1994 | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/4225565)**
  - Source: numerique.banq.qc.ca
  - *Oct 24, 1994 ... ... aviron, 7,000$ négociable.Tél.542-7804.210 CHALET-MAISON situé à l ... Mathieu Boulianne ont fait bouger les cordages.Dans la deu...*

- **[Mathieu Boulianne - Co-Founder & CEO @ Aviron - Crunchbase ...](https://www.crunchbase.com/person/mathieu-boulianne)**
  - Source: crunchbase.com
  - *Mathieu Boulianne is the Co-Founder and CEO at Aviron AI ... Talk With Sales. What We Do. Crunchbase Pro · Crunchbase Business · Marketplace · Data Li...*

- **[Confluence - The Portage Networking Event - Portage](https://portageinvest.com/confluence/)**
  - Source: portageinvest.com
  - *Mathieu Boulianne. Co-Founder & CEO. Aviron. Mathieu Provencher. COO & CFO. Novisto. Mathieu Provost. Managing Director, Venture Capital ......*

- **[Le quotidien, lundi 20 janvier 1997 | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/4238173)**
  - Source: numerique.banq.qc.ca
  - *Jan 20, 1997 ... ... Aviron de Québec créera un collège technique thaïlandais en vertu d ... Mathieu Boulianne, Rémi Pouliot et Christian Cloutier ont...*

- **[Le quotidien, mercredi 22 janvier 1997 | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/4238175)**
  - Source: numerique.banq.qc.ca
  - *Jan 22, 1997 ... ... aviron, qui 54 Fea nous mene, qui nous mene» que les manifestants ... Mathieu Boulianne, Dolbeau 21 23 44 Patrice Gagnon, Alma 13...*

- **[Alexandre Bourget Email & Phone Number | Aviron Co-Founder and ...](https://rocketreach.co/alexandre-bourget-email_49492413)**
  - Source: rocketreach.co
  - *Aviron Employee Mathieu Boulianne's profile photo · Mathieu Boulianne. Co ... Blog · Contact Us. © 2025 RocketReach.co....*

- **[Stratégie IA : l'écosystème mobilisé pour la feuille de route ...](https://vitrine.ia.quebec/strategie-ia-lecosysteme-mobilise-pour-la-feuille-de-route-quebecoise-c82102b8-a12d-47ef-812d-359df6c80eae)**
  - Source: vitrine.ia.quebec
  - *Nov 10, 2025 ... Mathieu Boulianne (Aviron AI). Maxime Boissonneault (Nectar). Maxime ... Une entreprise en IA Une étude de cas Un article. Informatio...*

- **[Le quotidien, vendredi 15 décembre 1995 | BAnQ numérique](https://numerique.banq.qc.ca/patrimoine/details/52327/4232618)**
  - Source: numerique.banq.qc.ca
  - *Dec 15, 1995 ... ... Mathieu Boulianne.Mistassini 28 22 50 Bernard Parent, Marquis 25 17 ... aviron du Québec (FAQ) s'est montrée plus sévère dans le ...*

---

*Generated by Founder Scraper*
