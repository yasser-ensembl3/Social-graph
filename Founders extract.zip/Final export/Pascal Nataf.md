# Pascal Nataf

## Position actuelle

**Titre** : Co-founder
**Entreprise** : Affordance Studio
**Durée dans le rôle** : 13 years 1 month in role
**Durée dans l'entreprise** : 13 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Professional Training and Coaching

## Description du rôle

Smart games for business. We design games tailored to our clients' needs in terms of corporate training and marketing. Affordance Studio specializes in gamification, serious gaming and new technologies.

## Résumé

I am a co-founder and investor in indie video game studios. I am interested in the new trends of games.  
I teach video game development in several universities.
I am involved in the Montreal indie video game industry and in the startup ecosystem.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAtqkbsBN2hQ6s_a4iMuYIeBREWZIjv9JzM/
**Connexions partagées** : 119


---

# Pascal Nataf

## Position actuelle

**Entreprise** : Indie Asylum

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pascal Nataf

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402007490915303425 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGqW-UNBwlTuQ/feedshare-shrink_800/B4EZrf8UgpGcAg-/0/1764693726359?e=1766620800&v=beta&t=np_kYhR6GmOIcFwhfD0FXwnEGgR_szdlRnufuPOW_Hs | Good fun at the Indie Asylum ! The fellowship was strong… and so were the answers. | 17 | 0 | 0 | 4d | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:49.808Z |  | 2025-12-03T15:35:08.483Z | https://www.linkedin.com/feed/update/urn:li:activity:7401661963434618880/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396617075924045824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFZhL2l6-PQsA/feedshare-shrink_800/B4EZqXq1f7IwAg-/0/1763481180929?e=1766620800&v=beta&t=Tg35fTNAgzY6qB--A7hx4owFow2pHee9vxYtTz08PZQ | If you're making games in Quebec, you should be in that Steam sale. | 33 | 2 | 0 | 2w | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:49.809Z |  | 2025-11-18T18:35:33.400Z | https://www.linkedin.com/feed/update/urn:li:activity:7396576175747190784/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386826875425234944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJk41fRLPQXA/feedshare-shrink_800/B4EZoNH4yBKwAk-/0/1761156763811?e=1766620800&v=beta&t=m6IFUb1jj-3RScgu2inOPBLPkt7APGwkbDbj9_Ey_wk | On a connu Luc Rabouin il y a douze ans, alors que qu'on faisait nos débuts dans le jeu vidéo. On a croisé peu de personnes avec autant de flair et de conviction que lui. Quand d’autres doutaient, lui voyait le potentiel. Grâce à son appui, Le Responsable, un jeu éducatif sur la finance responsable, a pu voir le jour et donner le coup d’envoi à notre studio de jeu vidéo Affordance Studio. 

Quelques années plus tard, c’est encore lui qui a cru en La Guilde du jeu vidéo du Québec, nous aidant à obtenir le financement nécessaire pour devenir le plus grand regroupement de développeurs de jeux vidéo.

En tant que maire du Plateau et membre du comité exécutif, il a de nouveau soutenu l’Indie Asylum, permettant de déployer 18 studios et de rassembler plus de 200 créatrices et créateurs qui font briller Montréal à travers le monde.

Luc comprend ce que c’est d’entreprendre, de créer, de bâtir du neuf. Il agit, il écoute, il fait confiance. C’est un allié vrai, un partenaire de terrain, et surtout un maire qui croit au talent d’ici sans détour, et comme il le dit lui-même : « sans bullshit ».

#montréal #LucRabouin #jeuvidéo | 139 | 0 | 8 | 1mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:49.809Z |  | 2025-10-22T18:12:47.708Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7383499029298561024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGAihdDYae6dA/feedshare-shrink_800/B4EZnchfcdGcAg-/0/1760341392058?e=1766620800&v=beta&t=mQ3ndblOWpTkBwccIR7Q6XZkzqQtrwM-3Na1yMAgmQk | Cool project from an Asylum team.  FTL in first person. | 37 | 0 | 1 | 1mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:49.810Z |  | 2025-10-13T13:49:07.363Z | https://www.linkedin.com/feed/update/urn:li:activity:7383408664906465280/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7382430867060867072 | Text |  |  | Merci Carl-Edwin pour la discussion. | 19 | 2 | 0 | 1mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:49.811Z |  | 2025-10-10T15:04:37.640Z | https://www.linkedin.com/feed/update/urn:li:activity:7382428230823305216/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7366830538243973120 | Article |  |  | À mes ami.e.s qui cherchent, c'est un super projet. | 9 | 1 | 4 | 3mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.392Z |  | 2025-08-28T13:54:29.410Z | https://jobs.smartrecruiters.com/Gameloft/744000077990955--d-d-pc-console-concepteur-trice-de-jeu-technique-technical-game-designer?trid=463ac537-35c8-4256-8fe4-47ea285de0a6 |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7333956885798150144 | Document |  |  | Two Falls has been selected for the Xbox Indie Selects Collection this May!

Each month, the program highlights six standout indie titles that Xbox believes players will love — and we're honored to be among them. | 50 | 2 | 2 | 6mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.395Z |  | 2025-05-29T20:46:19.904Z | https://www.linkedin.com/feed/update/urn:li:activity:7333915125814304768/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7333946043639734272 | Text |  |  | Best of luck to Two Falls - Nishu Takuatshina and the talented teams at Unreliable Narrators and Awastoki at the NUMIX Awards tonight! | 22 | 0 | 0 | 6mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.396Z |  | 2025-05-29T20:03:14.932Z | https://www.linkedin.com/feed/update/urn:li:activity:7333864587840143361/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7327724721247068163 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZQODg9qz8HQ/feedshare-shrink_800/B4EZbE_MIZGQAk-/0/1747061621770?e=1766620800&v=beta&t=fNw7mO-QSl3LiVwlckWuP17ZVHuvkEP_EALSXpPVE_0 | Join us... | 13 | 0 | 0 | 6mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.397Z |  | 2025-05-12T16:01:56.087Z | https://www.linkedin.com/feed/update/urn:li:activity:7327707551574245377/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7325209460656803840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGRmbME5gZUNw/feedshare-shrink_800/B4EZaSlZouGYAk-/0/1746216000927?e=1766620800&v=beta&t=rM6BF7j-nG7OUrukP8dgZJeZH3pUJECjlm-0CzmR3jY | Two Falls is now available on Xbox and PlayStation !

https://lnkd.in/esFEBFuT | 48 | 0 | 2 | 7mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.398Z |  | 2025-05-05T17:27:11.231Z | https://www.linkedin.com/feed/update/urn:li:activity:7324160763592388608/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7323057193069469700 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOaO0Gt-EOaQ/feedshare-shrink_800/B4EZaCt4JIIAAo-/0/1745949791814?e=1766620800&v=beta&t=EF2jnFByEHcdKtETWwwBQC32EH_f95NXVP8OXyVGq_s | Fun at the Asylum. | 27 | 0 | 0 | 7mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.398Z |  | 2025-04-29T18:54:50.651Z | https://www.linkedin.com/feed/update/urn:li:activity:7323044219395203072/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7303534859262578690 | Article |  |  | Here’s the official trailer for our next game : Inhuman Ressources. If you love the choose-your-own-adventure vibes from the ‘80s, wrapped in a dystopian corporate setting, this one’s for you. 
#NewGame #IndieGame #GameDev #Dystopian #InteractiveFiction | 90 | 6 | 6 | 9mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.399Z |  | 2025-03-06T22:00:03.564Z | https://www.youtube.com/watch?v=zijVtEKIPCY |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7288235666696527873 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFSY2fep19yZw/feedshare-shrink_800/B56ZSQciLxGsAk-/0/1737590187348?e=1766620800&v=beta&t=n8N1ROYcfIs-CwLHG-BB6UCvwKR7aZ3s4zEVzMh__Eo | If you’re a game developer from Quebec and would like to attend GDC next March, you can join our group. Even if you already have your ticket for the event, you’re still welcome to join our mission. You can contact Mariève Beauchemin | 24 | 2 | 4 | 10mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.400Z |  | 2025-01-23T16:46:31.811Z | https://www.linkedin.com/feed/update/urn:li:activity:7287981480700481536/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7273386607565488129 | Article |  |  | Excellent article de Mario J. Ramos. Je suis d’accord avec lui ; le jeu vidéo est de la culture, et son article le démontre en donnant l’exemple de plusieurs jeux québécois qui font rayonner notre culture, notre histoire et notre savoir-faire créatif. 

J’en profite d’ailleurs pour saluer le travail de plusieurs amis journalistes qui couvrent le jeu vidéo indépendant québécois dans plusieurs médias. Je suis heureux de constater que le jeu vidéo prend de plus en plus sa place dans l’actualité. 

Bonne lecture. | 28 | 0 | 2 | 11mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.401Z |  | 2024-12-13T17:21:40.232Z | https://videoludique.ca/2024/12/12/lettre-ouverte-aux-medias-dinformations-generalistes-au-quebec-pour-que-le-jeu-video-soit-traite-comme-un-produit-culturel/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7273380916842926080 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF55mPufpkayg/feedshare-shrink_800/B56ZO94TF1GsAg-/0/1734057475878?e=1766620800&v=beta&t=iFbcHD-javpNxWfDIEB-HWfNl8WcbpoLMT1tEbmFaE0 | Quand j’ai commencé dans les jeux vidéo il y a presque 15 ans, je voulais créer des jeux qui ont un impact social et éducatif. Tout le monde me disait que c’était impossible. Luc Rabouin a été un des premiers à travailler avec nous sur Le Responsable – un jeu sur la finance solidaire et responsable. 

Quelques années plus tard, avec Louis-Félix Cauchon et plusieurs autres, nous avons voulu regrouper les développeurs de jeux vidéo dans une coopérative de producteurs afin de nous entraider et de faire rayonner la culture du Québec, tout le monde nous a dit que c’était impossible. Luc Rabouin a été un des premiers à nous soutenir. Aujourd’hui, la coopérative La Guilde du jeu vidéo du Québec est le plus grand groupe de développeurs de jeux vidéo au monde.

Lorsque j’ai co-fondé, avec Christopher Chancey et Kim Berthiaume, Indie Asylum, un incubateur et accélérateur de jeux vidéo unique qui aide les créatifs passionnés à structurer leur projet d’affaires, Luc Rabouin et 
la Ville de Montréal ont encore été parmi les premiers à nous soutenir. Aujourd’hui, l’Asylum compte une quinzaine de studios, qui emploient deux cents employés et fait partie d’un consortium avec le CEIM et nos partenaires du Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE) et de La Guilde.

Depuis 15 ans, Luc Rabouin soutient des créateurs et des entrepreneurs de Montréal, et c’est pour cette raison que j’ai été honoré d’être présent lors de l’annonce de sa candidature à la chefferie de Projet Montréal, et de le soutenir à mon tour.

Les idées sont cruciales autant en politique que dans le monde des affaires. Mais les idées s’incarnent dans des humains, qui les portent et les défendent. Finalement, pour le citer, on sait qu’on aura un politicien avec qui il n’y aura « pas de bullshit ».

Bonne course, Luc. | 58 | 1 | 3 | 11mo | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.402Z |  | 2024-12-13T16:59:03.458Z | https://www.linkedin.com/feed/update/urn:li:activity:7273164218734915584/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7270149596163526656 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHHGaZ4Gvw8Zw/feedshare-shrink_800/feedshare-shrink_800/0/1733317382033?e=1766620800&v=beta&t=Q_NtkPVAYJBQRJuf8qODY0SZJdoLnPGr_6zYcUuJbWg | L’Indie Asylum est fier de joindre ses efforts à ceux du CEIM et de La Guilde du jeu vidéo du Québec pour contribuer à perpétuer le miracle québécois du jeu vidéo.

Dans chaque jeu vidéo qui s’exporte, c’est la culture et le savoir-faire du Québec qui brillent sur la scène internationale.

Un grand merci à l'équipe du Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE) pour son soutien précieux dans nos efforts. 

Pour plus de détails sur le consortium et ses initiatives, lisez le communiqué officiel ici : https://lnkd.in/gXV_TSki 
----
Indie Asylum is proud to join forces with the CEIM and La Guilde du jeu vidéo du Québec to help showcase the Quebec video game miracle.

With every video game that reaches international markets, it’s Quebec’s culture and expertise that shine on the global stage.

A heartfelt thank you to the Ministry of Economy, Innovation, and Energy of Quebec (MEIE) for its invaluable support in our efforts. | 71 | 0 | 2 | 1yr | Post | Pascal Nataf | https://www.linkedin.com/in/pascalnataf | https://linkedin.com/in/pascalnataf | 2025-12-08T05:18:54.403Z |  | 2024-12-04T18:58:56.573Z | https://www.linkedin.com/feed/update/urn:li:activity:7270074413855719424/ |  | 

---



---

# Pascal Nataf
*Indie Asylum*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [Learn more](https://static-wordpress.akamaized.net/montreal.ubisoft.com/wp-content/uploads/2023/07/13175203/UBISOFT_RapportImpact2023_ENG.pdf)
*2023-07-13*
- Category: article

### [Yogomi: Gambit Digital Launches in Montreal to Redefine Indie Game Publishing](https://www.yogomi.com/2025/09/gambit-digital-launches-in-montreal-to-redefine-indie-game-publishing/)
*2025-09-09*
- Category: article

### [Navigating the turbulence of the indie Montreal game scene in the 2020s](https://cultmtl.com/2024/06/navigating-the-turbulence-of-the-indie-montreal-game-scene-in-the-2020s/)
*2024-06-17*
- Category: article

### [Inside 'La Guilde,' Quebec's new independent development cooperative](https://www.gamedeveloper.com/business/inside-la-guilde-quebec-s-new-independent-development-cooperative)
*2023-10-08*
- Category: article

### [Stop being a stupid indie-gamedeveloper](https://www.gamedeveloper.com/business/stop-being-a-stupid-indie-gamedeveloper)
*2023-12-08*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Former Kepler Interactive VP starts new indie publisher](https://www.gamedeveloper.com/business/former-kepler-interactive-vp-is-leading-a-new-indie-publisher)**
  - Source: gamedeveloper.com
  - *Sep 10, 2025 ... ... Pascal Nataf (founding partner of Indie Asylum), and Kim Berthiaume ... Podcast Ep. 58. Oct 31, 2025. See all. Game Developer Col...*

- **[Collective Around Gambit Digital Buys Fae Farm IP](https://www.gamesmarket.global/acquisition-collective-around-gambit-digital-buys-fae-farm-ip-d3262bcadf64a136337d41d3f4ddd211/)**
  - Source: gamesmarket.global
  - *Sep 15, 2025 ... Pascal Nataf, Co-Founder of Gambit Digital (part of Montreal's Indie Asylum) ... Podcast Channel "Game Studies" (New Books Network); ...*

- **[Fae Farm hits 500k+ players, game acquired by Gambit Digital ...](https://www.gonintendo.com/contents/52860-fae-farm-hits-500k-players-game-acquired-by-gambit-digital)**
  - Source: gonintendo.com
  - *Sep 15, 2025 ... Pascal Nataf, Co-Founder of Gambit Digital, added: “Fae Farm has ... As part of Montreal's Indie Asylum, home to 200+ developers and ...*

- **[Inhuman Resources: A playable book, a readable game](https://www.newswire.ca/news-releases/inhuman-resources-a-playable-book-a-readable-game-861974073.html)**
  - Source: newswire.ca
  - *Apr 16, 2025 ... ... Pascal Nataf ... The game studio collective-slash-incubator Indie Asylum also closely collaborated with Affordance and Alto durin...*

- **[Affordance Studio : Savoir quand activer son «doomsday device ...](https://www.24heures.ca/2021/06/10/affordance-studio--savoir-quand-activer-son-doomsday-device)**
  - Source: 24heures.ca
  - *Jun 10, 2021 ... David Duguay, directeur des technologies, Kim Berthiaume, co-fondatrice et directrice créativité, et Pascal Nataf, président d'Afford...*

- **[Inhuman Resources: A playable book, a readable game](https://finance.yahoo.com/news/inhuman-resources-playable-book-readable-130000691.html)**
  - Source: finance.yahoo.com
  - *Apr 16, 2025 ... ... Pascal Nataf, co-founder of Affordance Studio. More than just an ... The game studio collective-slash-incubator Indie Asylum also...*

- **[Lost Records: Bloom & Rage credits (Windows, 2025) - MobyGames](https://www.mobygames.com/game/237586/lost-records-bloom-rage/credits/windows/)**
  - Source: mobygames.com
  - *... Pascal Nataf, Christopher Chancey, Indie Asylum, Christian Nguyen (ASN), Carmelo Sala (ASN), Devin Oxman (and his dear cat Isabelle [June 2010 - A...*

- **[Fae Farm findet neues Zuhause unter neuer Eigentümerschaft ...](https://www.spielemagazin.de/spiele/news/fae-farm-findet-neues-zuhause-unter-neuer-eigentuemerschaft/21774)**
  - Source: spielemagazin.de
  - *Pascal Nataf, Mitbegründer von Gambit Digital, fügte hinzu: „Fae Farm hat ... Als Teil von Montreals Indie Asylum, der Heimat von über 200 Entwicklern...*

- **[Gambit Digital : Un ancien leader de Kepler Interactive lance un ...](https://www.dualmedia-esports.com/vp-kepler-gambit-digital/)**
  - Source: dualmedia-esports.com
  - *... Pascal Nataf (partenaire fondateur d'Indie Asylum) et Kim Berthiaume (producteur et UX designer chez BadRez Games). Ensemble, ils incarnent une Di...*

- **[Inhuman Resources: A playable book, a readable game](https://ca.finance.yahoo.com/news/inhuman-resources-playable-book-readable-130000010.html)**
  - Source: ca.finance.yahoo.com
  - *Apr 16, 2025 ... ... Pascal Nataf, co-founder of Affordance Studio. More than just an ... The game studio collective-slash-incubator Indie Asylum also...*

---

*Generated by Founder Scraper*
