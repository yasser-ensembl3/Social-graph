# Amélie Chagnon

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393629290074046464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGVURNXwGsl6g/feedshare-shrink_800/B4EZptyqDhHMAk-/0/1762778588887?e=1766620800&v=beta&t=Op9qgXyNJCSJOgEgt-qTV_TbfVGwjawjzxSetra7JW8 | This one matters to me.
Today, I’m joining Avatek Technologies Inc. as COO and late co-founder. 

We’re a small team with a big ambition: give nurses their time back. They deserve tools that support them, not slow them down.

Richard Philippe and Francois Gaouette, thank you for the trust. 
I’m proud to build this with you.

Alright, enough talking. 
Time to get to work! 🚀 | 194 | 71 | 0 | 3w | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.595Z |  | 2025-11-10T12:43:09.743Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387117158163718144 | Text |  |  | Best business books you’ve ever read.

 Don’t overthink it. Just drop it 👇

Need a new reading lineup. | 13 | 7 | 0 | 1mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.596Z |  | 2025-10-23T13:26:16.506Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7373776631041245184 | Article |  |  | Content that sells. 
Brands that connect.
Creators that win. 

Affiliate marketing done right.

Let's go! | 10 | 0 | 0 | 2mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.596Z |  | 2025-09-16T17:55:46.985Z | https://nomix.group/shopnomix-invests-in-creator-co-to-power-an-agentic-marketplace-for-content-to-commerce/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7371203679590445056 | Article |  |  | 🚀 Big corporate milestone today!

When I took on the Demand Sales team at Shopnomix a year ago, I knew we were building something strong, that would evolve into an entire ecosystem.

Today, that vision became official with the launch of Nomix Group.
We’re bringing together talent and technology from Shopnomix, Appnomix, Fanomix, Pronomix (and yes, even Creatornomix) under one roof.

Why does it matter? Because performance marketing has changed.

Attribution is messy. Channels are multiplying. 
Shoppers are transforming into educated prompters: they scroll, swipe, compare, get inspired, ask their favorite AI agent's opinion, and then decide.

Nomix Group is built to meet them where they are.

Proud of the team, proud of the journey, and excited for what’s next. 

It's a day to celebrate!

👉 Full press release here: https://lnkd.in/e3e2kh_X | 43 | 2 | 1 | 2mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.597Z |  | 2025-09-09T15:31:47.556Z | https://www.prweb.com/releases/nomix-group-launches-to-solve-the-modern-challenges-of-performance-marketing-and-the-future-of-ai-shopping-302548991.html |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7349187817639419904 | Text |  |  | My colleague Ian is hiring a founding SDR at Appnomix and he is doing it right:

 ✅ $50/hr to start (part-time)
 ✅ Remote (East Coast only)
 ✅ Clear expectations & ramp
 ✅ Validated ICP
 ✅ Product that actually delivers
 ✅ Real support
 ✅ Direct path to AE

This isn’t a volume shop. 

It’s a chance to join early, be coached by smart leaders, and build something meaningful — with structure and growth baked in.

📩 If that sounds like you (or someone you’d vouch for), check out Ian’s post below. | 6 | 0 | 0 | 4mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.599Z |  | 2025-07-10T21:28:37.032Z | https://www.linkedin.com/feed/update/urn:li:activity:7349164142034857987/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7343956233881546753 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFgdRH3dN0LRg/feedshare-shrink_800/B4EZer5ROgGcAo-/0/1750935608403?e=1766620800&v=beta&t=KQutFDA7nR1U4rpnA4rpOMKAGOnQ-LhMHca3qD4v7N4 | Yesterday's team call turned into something unexpected:
Black Tank Top Wednesday. 🖤💻🔥

4 out of 6 of us showed up in the same outfit, completely unplanned. 
The other 2?

They changed!
Because when your team shows up in a heat wave uniform, you commit. 😎

Next step?

Obviously launching a band: Jonathan and the Sell Sisters. 🪩 🕺💃 
Our first single ''We got the links'' coming soon!

Remote work doesn’t always give you water cooler moments — but it definitely gives you gems like this.

Jonathan Kluger, Rebecca Charest, Catherine Ponton, Amy Tabash & Anna Cornog - Thanks for making my day! | 58 | 1 | 0 | 5mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:18.600Z |  | 2025-06-26T11:00:10.266Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7304826158812975104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGeEvm9bFl85Q/feedshare-shrink_800/B4EZV88k_IH0Ag-/0/1741558010368?e=1766620800&v=beta&t=VW7d5JpyuiuD2jS52IsvbVpzCxq7xP7VHvTU81UWqCA | If You Care Enough, You’ll Figure It Out !

This is my husband and I, babysitting my brother’s newborn twins.

We don’t have kids. We had no idea what we were doing. But my brother and his partner trusted us—with the most precious thing in their lives.

And we trusted ourselves (even though we were slightly terrified and definitely felt like impostors). Not because we were experts (we weren’t). Not because we felt ready (we didn’t). But because we knew we cared enough to make it work and figure it out.

That’s the thing about imposter syndrome. It convinces you that you’re not enough. That you don’t know enough. That you’re not ready.

But the truth? You’ll figure it out if you want to.

You don’t need all the answers today. You just need to trust that, when the moment comes, you’ll rise to the challenge.

Because confidence isn’t about knowing it all. It’s about believing in yourself enough to figure it out along the way.


*****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 162 | 8 | 0 | 8mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.284Z |  | 2025-03-10T11:31:13.368Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7302521923375157248 | Text |  |  | Need Help?  Don’t Just Assign Tasks—Explain the Problem!

One of the biggest mistakes I see when people ask for help?
They show up with a task request—but skip the context.

Ever asked a colleague to tweak a process or take on a project, only to get pushback? 

Before assuming they don’t want to help, ask yourself:
✅ Did I give them the chance to solve the problem their way?
✅ Or did I just hand them a task to complete?

You don’t know what you don’t know. Your idea might make sense from where you stand, but someone else’s perspective could unlock a smarter, easier solution.

The best way to get help isn’t by dictating a solution. 
Instead:
✔️ Explain the problem you’re trying to solve.
✔️ Share the solution you had in mind.
✔️ Stay open—because they might have a better way.

Most people want to help—they just need the space to do it. When you frame the conversation around the problem, not just your solution, you create collaboration instead of delegation.

At the end of the day, you want the problem solved. 

If they find a way that works even better than yours, isn’t that a win?

Great problem-solving isn’t about having all the answers—it’s about creating focus and making space for the best solution to emerge.

*****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 17 | 0 | 0 | 9mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.285Z |  | 2025-03-04T02:55:00.829Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7299778849888743424 | Article |  |  | Twice last week, I was reminded of the power of clear communication—
✅ Once, when I did it well.
❌ And once, when I didn’t.

The difference?
In the first case, expectations were clear, alignment was easy, and things moved forward smoothly.
In the second, I assumed people understood what I meant. They didn’t. And the confusion caused friction.

Lesson learned (again): Clarity isn’t just nice—it’s necessary.

✨ Brené Brown says, "Clear is kind." Kim Scott calls it "Radical Candor."
Both mean this: Being direct isn't about being harsh. It’s about respecting others enough to be honest, specific, and constructive.

💡 So how can we be clearer communicators?
🔹 Say what you mean. Don’t assume people will “read between the lines.”
🔹 Set expectations early. Unspoken assumptions lead to disappointment.
🔹 Be candid, but kind. Honesty + empathy = trust.
🔹 Check for understanding. “Does this make sense?” is a game-changer.

Clarity makes work smoother, relationships stronger, and leadership more effective.

Want to learn more about where you can grow as a daring leader? 
Take the Dare to Lead assessment: https://lnkd.in/efUQrrZJ


*****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 11 | 0 | 0 | 9mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.287Z |  | 2025-02-24T13:15:01.146Z | https://daretolead.brenebrown.com/assessment/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7297242139481034753 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8TeloNSAAhQ/feedshare-shrink_800/B4EZUQC6s1GYAg-/0/1739730955563?e=1766620800&v=beta&t=LPq5Vy-wqcQrNVUhZVsvrgBefwLkymtwJWKRw8Xp4_c | How are you doing?
No, really—how are you REALLY doing?

We often default to surface-level emotions: happy, sad, angry.

But emotions are more complex than that. 
Just look at the Wheel of Emotion (attached)!

💡 Being able to dig deeper and name what we’re feeling is a superpower.
Why? Because clarity fuels action.

Feeling angry? Go deeper. Are you actually annoyed, betrayed, or skeptical? Each requires a different response.

Feeling sad? Is it disappointment, loneliness, or powerlessness? 
Recognizing it helps you move forward.

Instead of brushing emotions aside, label them.

👉 Next time someone shares a first-degree emotion, pull out the wheel. Help them dig deeper and name what’s really going on.

Only then can we truly understand and offer support.

So… how are YOU feeling today?

Shoutout to Colleen McNamara & Christine Dupuis for the inspiration behind this post!

*****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 34 | 3 | 0 | 9mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.288Z |  | 2025-02-17T13:15:02.255Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7294699247587786752 | Text |  |  | Not feeling motivated today?
Good! You have a big opportunity in front of you.

What you do on the days you don’t feel like it is what separates those who achieve their goals from those who don’t.

This isn’t just about work. 
This is true at the gym, in your career, in relationships—everywhere.

Motivation is unreliable—it comes and goes. 
If you only take action when you feel like it, you’ll move as fast as your mood allows.

Discipline is different. 
It’s showing up, even when you’d rather not. 
It’s doing the work when no one’s watching. 
It’s the quiet consistency that leads to real results.

💡 Next time motivation is low, try this:
1️⃣ Lower the bar: Just start. Commit to 10 minutes. Often, action sparks motivation—not the other way around.
2️⃣ Focus on the outcome: Remind yourself why this matters. What’s the bigger goal behind it?
3️⃣ Remove friction: Set up your environment to make it easier. No distractions, no overthinking—just do.

The people who succeed? 
They don’t wait for motivation. 
They build habits that make motivation irrelevant. 

I don't know who needs to hear it, but here it comes:
SHOW UP TODAY! Even if you don’t feel like it.

Naomi Ban - See you at the gym tonight! 💪 🫡 

****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 24 | 0 | 0 | 9mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.289Z |  | 2025-02-10T12:50:29.583Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7292161175155331073 | Text |  |  | "I want a more strategic job."

I heard this often, and I get it—being strategic sounds exciting. 
But here’s the truth: strategy isn’t a job—it’s a mindset. 

Every job involves execution. A lot of it.
Strategy is how you approach your work to give it direction and purpose. 

Any job can include strategy if you choose to work thoughtfully.

When I worked as a server at Eggsquis, I felt my tips didn’t match my effort. To change that, I had two choices:
1️⃣ Sell more to increase tips.
2️⃣ Work smarter to reduce stress.

I got strategic. I offered every customer extras (bacon, juice, beans—name it, I got it!). I started prepping tables with ketchup, mayo, peanut butter... basically, I turned into a condiment ninja. And because who doesn’t carry pre-cut pieces of cardboard in their pockets to level tables in less than 10 seconds, right?

The result? Happier customers, better earnings, and less stress.
More than 20 years later, that Eggsquis restaurant manager still remembers me!

How to think strategically in your role:
🧠 Identify pain points: What slows you down or creates friction?
🧠 Find small wins: Where can you add value or efficiency?
🧠 Experiment systematically: Test ideas that improve results for you, your team, or your clients.
🧠Communicate clearly: Share your ideas, progress, and results with your team. Collaboration amplifies impact and builds trust.

It's not a big job title that provides you the opportunity and time to do strategy work.
Opportunities to practice strategic thinking are everywhere and if you don't make an effort to recognize them now, you won't see them in another role either.

Strategy starts with YOU—and how you decide to execute your job today.

**************

✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 50 | 6 | 0 | 10mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.290Z |  | 2025-02-03T12:45:05.960Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7289635788009426944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHt9kIycl1pOw/feedshare-shrink_800/B4EZSFRjHrHMAk-/0/1737402757960?e=1766620800&v=beta&t=qQKqNvRdeynfmq1vD18W6vCYHPmNE-ZWLkZXmZ_NbTU | Do you know which tasks fuel your energy and which ones drain it?

I ask this question to my team every quarter during performance reviews and growth discussions. 
Why? Because understanding your energy flow is the key to thriving in your role.

💡 Take action:
1. Identify what fuels you: What tasks energize you? What do you naturally tackle first?

2. Spot what drains you: Which activities feel exhausting or get procrastinated?

3. Swap and align. What drains you might fuel a teammate. Can you trade tasks to maximize everyone’s strengths?

4. Plan smartly. If you can’t delegate, schedule draining tasks strategically—perhaps between two energizing ones or before treating yourself to something enjoyable.

For me: Hands-on execution, brainstorming and fixing things with my team fuel me. Predicting trends 3–5 years out or building long-term plans? Those drain me.

That’s why I thrive in early-stage sales leadership—it keeps me in battery-fueling mode, focused on agility, collaboration, and creativity.

**The takeaway? Work with your energy, not against it.**

Success looks different for everyone, and the best leaders help their teams align their roles with their natural strengths.


------
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 21 | 5 | 0 | 10mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.291Z |  | 2025-01-27T13:30:06.745Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7287091521244311552 | Text |  |  | When things go wrong—and they will—how and when you communicate can make or break you.

💡 Here’s the truth: setbacks are inevitable. Deadlines will be missed, targets won’t be hit, and sometimes the ROI won’t match expectations. What truly matters is how you handle it.

✨ Get ahead of it. As soon as you realize something’s off, speak up.
✨ Acknowledge the issue, take ownership, and share your plan to address it.
✨ Transparency builds trust. It shows integrity, resilience, and a commitment to improvement.

Mistakes and challenges don’t define you—your response does. By facing them head-on, you’ll earn more respect than if you tried to brush them under the rug or delay the conversation.

Don’t wait for things to spiral out of control. 
Be the person who addresses challenges early, owns the narrative, and works toward solutions—not the one who stays silent until it’s too late.

Real leaders face reality and rise to meet it.

So, the next time something goes sideways, ask yourself: “Am I getting ahead of this?”




-----
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 With 15 years of experience exploring psychology and emotional intelligence in leadership, I’m here to share what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership in sales. | 18 | 0 | 0 | 10mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.292Z |  | 2025-01-20T13:00:06.278Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7284910570569359361 | Poll |  |  | I’m curious—how long do you think is reasonable to get back to a client via email in 2025?

In a world where speed often equals quality of service, and instant communication platforms dominate our day-to-day, how much patience do we still have as consumers for email responses?

There are numbers available online, but I want to see it for myself. 

Vote below and share your perspective in the comments! | 3 | 2 | 0 | 10mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.292Z |  | 2025-01-14T12:33:47.117Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7284589738215243776 | Text |  |  | When’s the last time you kicked off a meeting with a solid icebreaker?

Starting a strategic team meeting with the right icebreaker can shift the energy in powerful ways—whether you’re in a physical room or on a virtual call.

✨ It helps everyone loosen up and connect.
✨ It sparks creativity and opens minds to fresh ideas.
✨ Most importantly, it reminds us we’re not just coworkers—we’re a team.

One of my favorites? 
Ask everyone to browse their phone and share a photo they love, along with the story behind it. 
It’s quick, fun, and a great way to learn something new about each person.

Icebreakers aren’t just warm-up activities—they’re tools to build trust, strengthen connections, and kick things off with a positive mindset.

What’s YOUR favorite icebreaker for meetings? 
I’d love to hear your ideas!


*****
✋ Hi, I’m Amélie, a sales leader in tech startups.
💡 After 15 years of exploring psychology and emotional intelligence in leadership, I’m sharing what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 28 | 10 | 0 | 10mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.293Z |  | 2025-01-13T15:18:54.723Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7282032040680546304 | Text |  |  | One of the most important lessons I’ve learned in leadership is this:
🤓 Knowing what needs to be done and being right is only 20% of the equation.
😎 Getting others to see it, believe in it, and embrace it? That’s the other 80%.

Here’s the thing:
If you’re right but act like a dictator, you’ll fail. 
You might win the argument, but you’ll lose the team. 
And in leadership, that’s game over! 😵 

People do better work when they believe in it.
And change happens when people see the benefits and understand why it needs to be done.

True leadership isn’t about being the smartest or having all the answers—it’s about inspiring others to see the solution, believe in the direction, and feel part of something bigger.

**The best leaders don’t push ideas—they cultivate buy-in.**

They listen, empathize, and bring people along for the journey.

Next time you’re sure you’re right, ask yourself:
👍 Am I helping others see and understand this too?
👍 Am I leading with empathy, or just trying to win?

Being right gets you 20%. 
Getting others on board? That’s where success happens.

One tool I use to inspire belief and buy-in is workshops. Instead of presenting the solution, I bring the team together to find it collaboratively. 

When people feel ownership, they do their best work—and change becomes real.

Happy New Year! | 34 | 1 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.294Z |  | 2025-01-06T13:55:32.111Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7280601307483181056 | Poll |  |  | Are you more of an on-off switch or a dimmer? 

I’ve always been an on-off switch. 
I operate at two speeds: 0% or 100%. 
When I’m “off,” I’m fully unplugged, recharging my energy. 
But when I’m “on,” I’m all in—focused, driven, and giving it everything I’ve got. 

Then, there are dimmers—people who adjust their energy and intensity based on the situation, the environment, or their capacity in the moment. 
They can dial things up or down as needed, finding balance across a spectrum. 

Both approaches have their strengths. 

The key is knowing yourself and how you work best. 

So, what about you? 
Are you more of an on-off switch, a dimmer, or maybe something else entirely? 

I’d love to hear your thoughts in the comments!

****

🌟 Hi, I’m Amélie, a sales leader in tech startups.
💡 After 15 years of exploring psychology and emotional intelligence in leadership, I’m sharing what I’ve learned.
✨ Follow me for insights on growth, connection, and inspiring leadership. | 14 | 7 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.295Z |  | 2025-01-02T15:10:18.735Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7277063718650228736 | Text |  |  | As 2024 comes to a close, I want to wish you all something we often undervalue and rarely grant ourselves: time.

✨ Time to reflect on all you've achieved, no matter how big or small.
✨ Time to recharge, to nurture yourself, and to simply be.
✨ Time to connect with the people who matter most and deepen the relationships that enrich your life.
✨ Time to dream, plan, and create for the year ahead without the weight of unnecessary urgency.

In a world that moves faster every day, giving yourself and others the gift of time is an act of grace. 

Let's remember: progress isn’t always about moving quicker—it’s about moving meaningfully.

So as we step into 2025, may you find the moments to pause, appreciate, and grow. 

Here's to making time for what truly matters. 🥂 | 23 | 0 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.296Z |  | 2024-12-23T20:53:11.832Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7275136483928244224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEtZbvNGXkeA/feedshare-shrink_800/B4EZPVWC9THAAk-/0/1734451149378?e=1766620800&v=beta&t=d4jRKLyIt2O1xbSdg_m2TOiX7ugZ8mBbUp4KYu3MArY | This weekend, my dek hockey team won our league's championship. 🏒🎉

I’ve played with this group for a long time, and I’ll be honest—I’m the worst player on the team. 
Every team needs one, and well… that’s me. 🤷‍♀️ 

But I have a role: make sure the woman I face doesn’t score. That’s it!
It’s not my job to score goals—that’s for my teammates.

It took me a while to accept that. 
I used to feel like I wasn’t contributing if I didn’t score. 
But then I shifted my focus: play strong defense, keep the opposing woman from getting a shot, and get the ball back for my teammates.

In our mixed league, if a woman scores, it’s worth two points. Saving those points became my goal.

And guess what? The moment I stopped judging myself on goals I scored and owned my defensive role, I became a better player for my team.

This championship reminded me:
Success happens when everyone understands their role, owns it, and executes it well.

Whether it’s in team sports, startups, or any big goal, individual execution drives collective success.

You don’t have to do it all. 
You just need to:
👍 Define the right metrics for success in YOUR role
👍 Do YOUR job well
👍 TRUST your teammates to do theirs
👍 ENCOURAGE each other along the way


Now - on to 2025! 
The Hunters are ready to defend the title! 💪 | 46 | 2 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.297Z |  | 2024-12-18T13:15:03.268Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7274777907640643588 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEAyd5R4uHx5A/feedshare-shrink_800/feedshare-shrink_800/0/1734020362794?e=1766620800&v=beta&t=RgecBsNRZos4R1lgNTt_ciDeLDIQ72qSDEIEpcfP_A0 | Do you make the time to celebrate small wins? 🥳 
If not, you are missing out on the chain reaction of positivity.

In a corporate setting, big wins don’t happen every day. 

But every step forward—learning from failure, solving a problem, hitting a milestone—deserves recognition.

At Heyday by Hootsuite, we called these ‘kudos.’ 
At Planned, they were ‘claps.’ 
We even had a dedicated slack channel for them.

When leaders celebrate small wins, employees feel seen, valued, and it sparks a chain reaction. 
People start celebrating each other, building a culture of positivity and collaboration.

Big successes are built on small wins, so let’s make the time to see and recognize them.

Today, I challenge you: take 2 minutes to recognize a small win from a colleague—a great idea, a breakthrough, or simply giving their best.

And then, do it again tomorrow. 
And again, and again... 
And see what happens! 
🤩 | 37 | 9 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.298Z |  | 2024-12-17T13:30:12.019Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7272694221025771520 | Text |  |  | Work has filled my life with true friendships. ❤️
It’s something I’ve never really paused to appreciate before!

As I look at my social calendar leading up to the holidays, I can’t help but reflect on the incredible impact work has had on my personal life.

Isabelle Martin & Karine Larouche: Two of my bridesmaids, who I first met while buttering toasts at a breakfast restaurant.

Jean-Philippe Coutu-Gadoua: One of my best friends (and worst card-playing nemesis), who was also my go-to colleague at Yellow Pages when we both managed remote teams.

Christine Dupuis, Jessie Lambert, Nathaly Brosseau: Powerhouses and fearless leaders I built Heyday with, who now join me for board games and cooking traditional holiday meals.

Andres Lozano MBA, Marie-Claude Valade, Matt Wall: Teammates turned foodie partners, always up for trying new restaurants.

And, of course, the ultimate work-turned-personal relationship: my husband Stéphan Lion, whom I met in the office cafeteria 18 years ago. ❤️

There are so many others I don’t have room to mention here, but all of them remind me why I always bring my best self and A-game to work.

It’s given me more than just professional success—it’s brought me personal happiness, connection, and lifelong memories.



Ian Newfeld - Can't wait for our next beer together!
Danielle de Montbrun - Wish you lived closer! Miss you!
Brad Wing - We are overdue for lunch #DreamTeam2012
Maxime Guérin-Touet - When are you coming to Montreal next?
Lucie Loubet - So excited to see you tonight! With the rest of THE gang: David Cottingham, Austin McCarthy, Cooper Young, Preslea Jane, Rachel Côté, Max Berkowitz | 74 | 17 | 0 | 11mo | Post | Amélie Chagnon | https://www.linkedin.com/in/ameliechagnon | https://linkedin.com/in/ameliechagnon | 2025-12-08T04:50:23.299Z |  | 2024-12-11T19:30:22.417Z |  |  | 

---

