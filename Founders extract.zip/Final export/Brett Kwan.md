# Brett Kwan

## Position actuelle

**Titre** : Founder
**Entreprise** : Pleasant Shimo
**Durée dans le rôle** : 1 year 5 months in role
**Durée dans l'entreprise** : 1 year 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Retail Art Dealers

## Description du rôle

• Founded Pleasant Shimo, a cross-cultural art and storytelling venture connecting local artists with global audiences. Led all aspects of the business, including brand development, artist outreach, product design, marketing, and distribution.
• Developed the business model, negotiated partnerships, and managed the full go-to-market strategy.
• Debut collection features 20+ artists across Tokyo and Vancouver.  Used field research, design thinking, and editorial strategy to shape emotionally resonant, commercially viable work.

## Résumé

Former CBC and NHK World journalist, now applying a decade of storytelling experience to creative entrepreneurship. After years producing international news in Vancouver and Tokyo, I pursued an MBA at McGill to explore new ways of connecting culture, commerce, and community.

I’m the founder of Pleasant Shimo — an art-driven platform that partners with emerging artists to create prints rooted in real neighbourhoods and lived experience. We launched our first collection in 2025 with works from 20 artists across Vancouver and Tokyo.

Open to new collaborations and opportunities where storytelling, strategy, and purpose meet.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAS-hI8BvUddBWWjWE_Vt5Dv_y4Xb3iOG1w/
**Connexions partagées** : 4


---

# Brett Kwan

## Position actuelle

**Entreprise** : Pleasant Shimo

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Brett Kwan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394748534668828673 | Article |  |  | When we launched Pleasant Shimo a few months ago, our goal was to make something meaningful — high-quality illustrated prints that reflect real neighbourhoods, through the eyes of artists who know them intimately.

This week, we made the Vancouver Magazine Wish Book — their annual list of the best local gift ideas from across the city. 

It’s a big win for us.  Not just for visibility, but because it shows the work is resonating with people.

We’re still early, and there’s a long way to go. But this kind of recognition means a lot as we keep building. Thanks to everyone who’s supported us so far. And if you’re discovering us for the first time — welcome.

https://lnkd.in/efMmYGU9 | 40 | 3 | 1 | 3w | Post | Brett Kwan | https://www.linkedin.com/in/brettkwan | https://linkedin.com/in/brettkwan | 2025-12-08T07:09:27.773Z |  | 2025-11-13T14:50:38.449Z | https://vanmag.com/style/general/shop-local-holiday-gift-guide-vancouver/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7351994779544522752 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7130e432-9c14-4613-a33f-d1d05446a595 | https://media.licdn.com/dms/image/v2/D4E05AQFn0vV0bGD5_w/videocover-high/B4EZgeIIsaHoCI-/0/1752852141907?e=1765785600&v=beta&t=aDV-pvYMR5wunoBnsLU-V2Brr6SMAdc-MRIBdWsWI1c | Before Pleasant Shimo, I was a journalist. Vancouver. Istanbul. Tokyo. Everywhere I lived, I wanted to bring something meaningful back with me.

What I found never felt quite right.
Plenty of prints—but few made by people who truly knew the place.
More souvenir than story.

In a world of AI-generated images, mass production, and overtourism, I wanted to bring people closer to iconic neighbourhoods in the world's most beloved cities.

Pleasant Shimo’s debut collection features Vancouver and Tokyo.

From Shibuya to Stanley Park, every artist we work with has a deep connection to the neighbourhood they’re depicting.

It’s lived memory, designed with clarity and produced with care.

Follow our journey on Instagram: @pleasantshimo | 73 | 0 | 1 | 4mo | Post | Brett Kwan | https://www.linkedin.com/in/brettkwan | https://linkedin.com/in/brettkwan | 2025-12-08T07:09:27.773Z |  | 2025-07-18T15:22:28.901Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7341864759585075201 | Article |  |  | We’re officially launching Pleasant Shimo at the Concord Pacific Dragon Boat Festival!

There’s no better place to begin. The Dragon Boat Festival is one of Vancouver’s most vibrant celebrations of Asian heritage—a gathering that bridges communities, histories, and cultures. That spirit of connection is exactly what Pleasant Shimo was built on.

We’re showcasing our entire Vancouver x Tokyo collection. Some artists will be dropping by, and we’ll have a few festival exclusives available too.

Thanks to Vancouver Magazine for profiling Pleasant Shimo. Their feature unpacks how the project began, the neighbourhoods we’re highlighting, and why this kind of art matters right now.

Come say hi if you’re around this weekend!

📍 Got Craft Market, Dragon Boat Festival
🗓 June 21–22 | 34 | 2 | 0 | 5mo | Post | Brett Kwan | https://www.linkedin.com/in/brettkwan | https://linkedin.com/in/brettkwan | 2025-12-08T07:09:27.774Z |  | 2025-06-20T16:29:23.936Z | https://www.vanmag.com/city/arts-and-culture/pleasant-shimo-debut-brett-kwan/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7341086033444302848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE20WmroI397g/feedshare-shrink_800/B4EZd_tsfvHgAg-/0/1750194375187?e=1766620800&v=beta&t=c1D3CTT_c-CutAbgVX-rz76kQPSVyJXkoVSor4kgt7U | This has been a long time coming.

After nearly a year of working behind-the-scenes, I’m proud to finally share Pleasant Shimo (www.pleasantshimo.com). What started as a simple idea—to depict neighbourhoods through the eyes of the artists who know them—has evolved into a thoughtfully curated collection of Vancouver and Tokyo prints.

The name Pleasant Shimo comes from two places that shaped my journey: Mount Pleasant in Vancouver, and Shimokitazawa in Tokyo. Vancouver is where I grew up and began my journalism career. Tokyo is where I produced international breaking news and, more importantly, started a family.

I started working on Pleasant Shimo during a period of personal change. My brother passed away in June 2023, halfway through my MBA at McGill.

Pleasant Shimo gave me something to build while navigating grief. It also carries forward what I value most in journalism: shining a spotlight on people and perspectives that deserve to be seen.

Every Pleasant Shimo piece is created in collaboration with an artist who has ties to the neighbourhood they illustrate. The artist tells their story: what this neighbourhood means to them, what inspired the piece, and how they approached it creatively. 

There are faster ways to make art, especially with the rising use of artificial intelligence. But Pleasant Shimo is a project built on care, collaboration, and connection.

You can follow our journey on Instagram @pleasantshimo for the latest updates.

Thanks for being here at the start. | 111 | 10 | 4 | 5mo | Post | Brett Kwan | https://www.linkedin.com/in/brettkwan | https://linkedin.com/in/brettkwan | 2025-12-08T07:09:27.774Z |  | 2025-06-18T12:55:01.156Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7313219969503092736 | Article |  |  | With U.S. tariffs dominating the headlines, Trump declaring today “Liberation Day”, and an upcoming federal election, questions about Canadian identity are everywhere.

What does it mean to be Canadian — and how do we show it?

That's what led me to create Canada Colour, a new project that turns familiar provincial and national symbols into bold, minimalist prints. Our goal is simple: help people celebrate where they’re from, wherever life takes them.

After nearly a decade in journalism and earning my MBA from McGill University, I wanted to build something that blended storytelling, design, and cultural identity. This has been a huge learning curve — but also one of the most fulfilling things I’ve done.

Tanya Saggi, your creative vision and expertise have been pivotal.

And a huge thanks to my wife, Keiko Rose, and daughter for their support as I try to bring this idea to life.

I’d love to hear your thoughts—on the designs, the website, or opportunities for collaboration. If you’re interested or just want to catch up, please reach out. Let’s start a conversation that’s long overdue. | 66 | 11 | 5 | 8mo | Post | Brett Kwan | https://www.linkedin.com/in/brettkwan | https://linkedin.com/in/brettkwan | 2025-12-08T07:09:29.853Z |  | 2025-04-02T15:25:13.786Z | http://www.canadacolour.ca/ |  | 

---



---

# Brett Kwan
*Pleasant Shimo*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [This Collection of Prints Captures How a Neighbourhood Feels](https://www.vanmag.com/city/arts-and-culture/pleasant-shimo-debut-brett-kwan/)
*2025-06-19*
- Category: article

### [A chat with Knoma’s Founder — Brett Shanley - Knoma.io - Medium](https://medium.com/@Knoma.io/a-chat-with-knomas-founder-brett-shanley-7206a3654762?source=read_next_recirc---------0---------------------fe0c12d7_6fc9_467f_9da9_714816ebf3af-------)
*2022-06-28*
- Category: blog

### [How Brett Williams @ designjoy Makes $1.5M/Year At A 98% Profit Margin](https://novumhq.com/brett-williams-interview/)
*2023-09-05*
- Category: article

### [[Hong Kong] Shimo 霜月](https://www.supertastermel.com/2015/07/shimo-hong-kong.html)
*2016-06-21*
- Category: article

### [China's 're-education' / concentration camps in Xinjiang / ...](https://uhrp.org/wp-content/uploads/2021/08/Chinas-re-education-concentration-camps-in-Xinjiang-BIBLIOGRAPHY-1.pdf)
*2021-08-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[About – Pleasant Shimo](https://pleasantshimo.com/pages/about)**
  - Source: pleasantshimo.com
  - *The process includes interviews, creative consultations, and feedback sessions. ... Pleasant Shimo was founded in 2024 by Brett Kwan, a former interna...*

- **[JET Streams - Issue #60 (Summer 2025) - JET Programme](https://jetprogramme.org/en/jetstreams/summer2025/)**
  - Source: jetprogramme.org
  - *Brett Kwan being interviewed by NHK Kanazawa about his reporting on the ... Pleasant Shimo spotlights iconic global neighbourhoods through local ......*

---

*Generated by Founder Scraper*
