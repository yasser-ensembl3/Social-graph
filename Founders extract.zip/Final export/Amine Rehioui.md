# Amine Rehioui

## Position actuelle

**Titre** : Founder
**Entreprise** : Frantic
**Durée dans le rôle** : 8 years 1 month in role
**Durée dans l'entreprise** : 8 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Software development & consulting

## Résumé

I'm currently building Powerplay, an RTS with a focus on resource management and industrial automation.

I've been in the Video Games Industry since 2007 and held senior leadership roles in Montreal. In particular in mobile gaming, but also working on in-flight entertainment apps, console games, and games for handhelds (Nintendo DS, Leapster Explorer).

Notable Experience:
- Architecture, design, and implementation of a web-based game engine, scene editor and project hub using React, CSS, Node.js, Express, Typescript, Javascript and WebGL. (https://spiderengine.io)

- Lead the tools team at the core technology group of Ludia where we developped the in-house editors and tools used by production, and then a team of game programmers where we shipped "What's Your Story" on iOS from concept to final product.

- Extensive (10+ years) experience in C/C++/C# and Object Oriented design
- 3D Game Engine architecture and implementation in C++
- Cross platform Multi-Threading and Network programming in C++ and C sockets
- Wide experience in Graphics Programming: GL / GLES / DX11
- User Interface and tools programming with wxWidgets, C#, Win32/MFC, or Java Swing
- Embedded systems design and development (including hardware design using VHDL)
- Notions in image and video processing with OpenCV

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAFaSOoBUSawPW1adqAGA4kpF7UuGJXsv_A/
**Connexions partagées** : 14


---

# Amine Rehioui

## Position actuelle

**Entreprise** : Frantic Software

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Amine Rehioui

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403383250083012608 | Video (LinkedIn Source) | blob:https://www.linkedin.com/436fbb10-148e-439f-82f6-86468caaf110 | https://media.licdn.com/dms/image/v2/D4E05AQEY-1xE2hggXw/feedshare-thumbnail_720_1280/B4EZr0dKinGoA0-/0/1765037882021?e=1765785600&v=beta&t=9VDIcV4thimD8ggcPX0thrLwgRC9rjzgaD36YgnPaKA | Here is how the main theme music for powerplay was made, with annotations by Pierre-Henri Barralis. I couldn't have found a better composer and I highly recommend him! The full OST will be available to download when the game is ready. | 5 | 0 | 0 | 20h | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:29.601Z |  | 2025-12-07T10:41:55.029Z | https://www.linkedin.com/feed/update/urn:li:activity:7403105570624319488/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402000916607832064 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e30a479a-7c19-43c2-9458-da49b91af89b | https://media.licdn.com/dms/image/v2/D4D05AQE3UjDhkJU6_g/videocover-low/B4DZrkwjZJG0BU-/0/1764774528706?e=1765785600&v=beta&t=rBucgkr7xLDSYnJu7ROCsA11FnMKLJi2RnGGkDsg240 | Logistics bay construction complete. This will be one of the core buildings in the game. It's meant to help scale production across bases. Trucks can be configured to a cargo type, and a source / destination logibay pair. Then they autonomously transport cargo between them.

We are one step closer to creating an automated military industrial complex! The inserters interact with the logistics bays like any other building, but the logistics bays are just proxies for the trucks that are inside. I'm super happy with this design. | 36 | 6 | 1 | 4d | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:29.602Z |  | 2025-12-03T15:09:01.046Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401062953673969664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGvYZGEQz95Lg/feedshare-shrink_800/B4EZrXbictJ0Ak-/0/1764550912580?e=1766620800&v=beta&t=S4klbN4wCSrfpjmTzjQ3Pgcu48n3dFrWRz7P9wxweDs | We finally have new key art. Great job Colin Searle! | 49 | 3 | 1 | 1w | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:29.602Z |  | 2025-12-01T01:01:53.256Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399394694541246464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3ab09dc6-eb3b-48c1-95f4-2cf98610bb5c | https://media.licdn.com/dms/image/v2/D4E05AQEUQXzuGCULOw/videocover-low/B4EZq_uPw.IUBU-/0/1764153165484?e=1765785600&v=beta&t=lfWSrMONU1CXyzYM8BHAwjEdVBt6DsAq6kygc_wJQAY | An important optim for any isometric RTS: split the map into sectors, and do frustum culling. I know that Unity already has great culling, but it feel wrong to only rely on it, what if we want to have huge maps?

Things to look out for:
1. Logic and rendering has to be completely decoupled, because entities in invisible sectors still need to "think"
2. The minimap needs special attention: ensure you turn off culling when rendering it, otherwise you will have missing sectors like in the video :)

Another added benefit of sectors is the potential to speed up pathfinding. I don't think it's necessary for us since our pathfinding is already fast, but it can be potentially improved like this:
1. Do a coarse A* pass on the sectors
2. Do a final A* pass on the cells, but early-reject cells that are not in the walkable sectors in Pass1

Only worth doing if you are calculating a path across far apart sectors. And it has complexities, because you need to keep track of walkability across sectors. As if you put a huge line of trees you can obstruct movement from sector X to sector Y and it needs to be taken into account in the coarse pass.

https://powerplayrts.com | 54 | 8 | 3 | 1w | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:29.603Z |  | 2025-11-26T10:32:49.284Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398662390730620928 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2990cb33-30b8-4be6-a7fc-9b50993b6020 | https://media.licdn.com/dms/image/v2/D4E05AQG8U5gke4uQVQ/videocover-low/B4EZq1UMkeKoBQ-/0/1763978565692?e=1765785600&v=beta&t=88uEhJOYRn-kOY2qiqpCjC1aOhWJ1VYiE5WXGuLc49k | We have new character models (worker + soldier). I think they fit very well in the game. The workers look more like engineers as they will have a core repair mechanic. Art team is cooking! | 54 | 5 | 0 | 1w | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:29.604Z |  | 2025-11-24T10:02:54.450Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7395582813166804992 | Video (LinkedIn Source) | blob:https://www.linkedin.com/85be9c47-7048-4175-b9ca-daade44ea7e1 | https://media.licdn.com/dms/image/v2/D4E05AQGj-8pD4mLO6A/videocover-low/B4EZqJjTcvIQCE-/0/1763244337844?e=1765785600&v=beta&t=WYUyQh3CHHjOSUj8yhQRHeYN0-e2v05UbNfYrCsuxqk | we finally have walls! a must have in any RTS imo. I am not sure how important it is to prevent units from shooting through walls. I think it could be frustrating if ranged units are just sitting behind a wall and unable to attack. https://powerplayrts.com | 49 | 8 | 0 | 3w | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.488Z |  | 2025-11-15T22:05:45.943Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394544980318605312 | Video (LinkedIn Source) | blob:https://www.linkedin.com/aea1e384-0a2b-4e9d-a160-6f4c6bab49b7 | https://media.licdn.com/dms/image/v2/D4E05AQHa_rBr57wnMw/videocover-low/B4EZp6zbMAIICE-/0/1762996901128?e=1765785600&v=beta&t=VkGclBatnD6S66G4DyeJ-GWKfVSO1_N3z7xbVAFQNRg | What ~2 years of progress on Powerplay RTS looks like | 74 | 12 | 1 | 3w | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.488Z |  | 2025-11-13T01:21:47.310Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7386779787534581762 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGQJWrbPvmn1w/feedshare-shrink_800/B4EZoMdEgiIQAg-/0/1761145539608?e=1766620800&v=beta&t=YQduQkploKcLv84C2wtK1x5x0UtmhNzBwcBlgNjOIds | our wishlist graph is throwing metal horns🤘

we broke 3K wishlists. I'm aiming for at least 10K before considering a release, so we are at 33% of target. It should grow faster when we have a public demo, which I should announce very soon! | 50 | 8 | 0 | 1mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.488Z |  | 2025-10-22T15:05:41.080Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7383877129614258177 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEDneaS8m9ZiA/feedshare-shrink_800/B56ZnjNHjrI4Ag-/0/1760453491432?e=1766620800&v=beta&t=hHB5vidykkcjaEuOIp1_8yJ4f3GV6soFNZ1Hf96Fiog | it feels good to see Powerplay regain wishlist momentum after a long drought. This is after only a few days of sharing updates. By looking at my analytics I think almost all of the conversion is coming from X. I will continue to share regular updates on X, on reddit at a bi-weekly basis, and LinkedIn at random times (probably just the big milestones) because there is almost zero correlation between my Linkedin posts and wishlist additions. | 34 | 5 | 0 | 1mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.489Z |  | 2025-10-14T14:51:33.503Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7383136575750033408 | Video (LinkedIn Source) | blob:https://www.linkedin.com/aeefa494-d14b-4a6c-9a21-ff299b63f72c | https://media.licdn.com/dms/image/v2/D4E05AQERL--zc23nUA/videocover-low/B4EZnYrhwHIwB4-/0/1760276923179?e=1765785600&v=beta&t=Hz6Yj4NKVSoMnhil_Lnpgm3uJLFUn-nHXpJifv6nvT0 | I'm happy to release the full source code to the initial Powerplay prototype made in Three.js: https://lnkd.in/eHaPa8dj

Read my thread 🧵on X if you want to know more about the move from Threejs to Unity: https://lnkd.in/ejzJ2nmV | 51 | 1 | 1 | 1mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.489Z |  | 2025-10-12T13:48:51.703Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7382369559602827264 | Article |  |  | I made a website for Dr. Yassine Rimaoui, a young and talented dentist who is just starting up in Rommani (80km from Rabat)

Pro tip: take an appointment on Wednesday, because it's also Souk day. You will be able to get all kinds of locally grown vegetables and meats, 100% organic (aka beldi))

If you or someone you know needs a website, my link is in my bio!

Dr. Yassine Rimaoui's website: https://lnkd.in/eA986eWG | 28 | 2 | 0 | 1mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.490Z |  | 2025-10-10T11:01:00.803Z | https://dryassinerimaoui.ma/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7381127430146781184 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a03179c8-79ab-4cf2-adc7-8940d31bb128 | https://media.licdn.com/dms/image/v2/D4E05AQHQ0zzEJzaTRg/videocover-low/B4EZm8IOYSHgB4-/0/1759797907387?e=1765785600&v=beta&t=RrViqQwdeDbfcMzZEIe4fCJsG2GR6wSJ-ChB7r0QPV0 | It’s been a while! I have an update on Powerplay RTS 🎮

The past few months have been tough. I struggled to make the game fun and almost lost confidence in it. I took a break, traveled a bit, and worked on other projects. I never gave up, but I definitely kept delaying it.

A few weeks ago, I realized I had to face it again if I wanted half a chance at a solid 2026 release. This time, I focused more on game design. And it finally feels right again.

The game changed a lot, but somehow became more true to the original vision: Running an automated military-industrial complex (basically, if Factorio and C&C had a baby).

Powerplay RTS is officially back on track ☢️
I’ll update the Steam page tomorrow with a more detailed announcement! | 63 | 6 | 0 | 2mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.490Z |  | 2025-10-07T00:45:14.063Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7373492164577660928 | Article |  |  | Google's Nano Banana is one of the best image models out there. I'm impressed at how generalist it is, from high quality portraits, to random marketing material, like this 1995 exclusive edition of Powerplay RTS, only available on CD-ROM. 

We are lucky to witness this AI arms race in real-time. For now, my money is on Google, but this will probably change next week, when I try the new Chinese models 🐉 | 15 | 0 | 0 | 2mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.491Z |  | 2025-09-15T23:05:24.895Z | https://photopro.ma/share/?key=c07a0e8c-153d-4f6a-b4a6-44b6ad7a8926_1088-960 |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7371459807238594560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFa23ssPjAgqw/feedshare-shrink_800/B4EZkyvoW7KoAg-/0/1757492971756?e=1766620800&v=beta&t=uENvfy2PYezlm0cuwuuULH6Gf_Q2i7yKQNBfMXg-Qf0 | J’ai le plaisir de présenter Photopro.ma, l’un des premiers outils de génération de photos par IA au Maroc. J’ai beaucoup travaillé sur la ressemblance et je continuerai à l’améliorer. N’hésitez pas à l’essayer et à le partager avec vos amis! Disponible ici: https://photopro.ma | 74 | 12 | 5 | 2mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.491Z |  | 2025-09-10T08:29:33.146Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7357753162889396224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGOnhI84xZvYA/feedshare-shrink_800/B4EZhv9gtvHoAg-/0/1754225053199?e=1766620800&v=beta&t=BKv8pWFrq9OIv5t195-yfz9NFb68r6CQasJMpz6-fB4 | If you are a solo founder, a freelancer, or a small business owner interested in DIY solutions and saving costs, I recommend this tool for reporting your business expenses. I used it to report my yearly operating expenses to my accountant. You can throw all your receipts into it, and it produces an accountant-ready report, while taking into account multiple currencies and taxes! Here is the link: https://fiscal.tools

Don't hesitate to DM me if you need a new feature or you found a bug, I'm happy to keep improving this tool. | 43 | 0 | 2 | 4mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.491Z |  | 2025-08-03T12:44:14.476Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7335976398756438017 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b7d8a8a1-cc00-4d64-b0f1-614cb9180137 | https://media.licdn.com/dms/image/v2/D4E05AQEixfAoUBY0GA/videocover-high/B4EZc6fnRYH0Bk-/0/1749033067238?e=1765785600&v=beta&t=WWnKJpvrCuVwisBPNTCkQy7KvzOu-Vky0YkFglKsaxs | Day 2 at PGC Barcelona 
Meeting a lot of really cool people! | 35 | 2 | 0 | 6mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.492Z |  | 2025-06-04T10:31:09.314Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7334420096372654080 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d2078fae-d5cb-4f6d-ae45-b057b60d17c3 | https://media.licdn.com/dms/image/v2/D4E05AQFeSPvtpBY5jg/videocover-low/B4EZckYJHtG4Bg-/0/1748662008893?e=1765785600&v=beta&t=i5tePf1Phfgcdo0uabCsziBb_KW56SpPOzx8xBTKy3M | We made good progress on our game. Specially the new air and naval units, the LUA scripting system, and the new campaign missions (thanks Alexander Tanasie!) 
Our public demo will be released When it's Done™. Until then, you can try the game physically at PGC Barcelona (June 3-4) and Morocco Gaming Expo (July 2-6), or through our steam playtests! | 83 | 13 | 0 | 6mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.493Z |  | 2025-05-31T03:26:57.911Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7333402826770993153 | Article |  |  | Babe wake up, an RTS soundtrack has just dropped!
I'm very happy about the Powerplay OST, made by Pierre-Henri Barralis. He drew inspiration from C&C by Frank Klepacki. ZERO generative AI used. If you like it, give it a buy, we need to support human creators!

https://lnkd.in/ehfFTBGA | 26 | 0 | 1 | 6mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.494Z |  | 2025-05-28T08:04:41.938Z | https://phbarralis.bandcamp.com/album/powerplay-original-game-sountrack |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7310800143774068736 | Text |  |  | It's very cool to see this project evolve. Congratulations on launching v1.0, Etienne Cabane, Kyle Meisterling, and Justin Boucher! | 10 | 1 | 0 | 8mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.494Z |  | 2025-03-26T23:09:42.374Z | https://www.linkedin.com/feed/update/urn:li:activity:7310639365309779968/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7290291261469569024 | Article |  |  | Thank you camilo sanin for this nice interview! I love your channel and your chill vibe, keep it up 🙌 | 25 | 0 | 0 | 10mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.495Z |  | 2025-01-29T08:54:43.796Z | https://youtu.be/ubtqY1Txr0s?si=ofAzXW76oKKUy1jl |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7287851615594688512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/97d028bf-f86b-4481-ace1-3a26afeda622 | https://media.licdn.com/dms/image/v2/D4E05AQGDeABKWmGahQ/videocover-low/B4EZSOiL2JHgCM-/0/1737558236003?e=1765785600&v=beta&t=ygDqBGbBn6Q9C7c7IB7KQ0iP9BlEaHJTDGVlG36NJR0 | POV: You are an up-and-coming music composer in the video game industry. Very touching! | 4 | 0 | 0 | 10mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.495Z |  | 2025-01-22T15:20:26.893Z | https://www.linkedin.com/feed/update/urn:li:activity:7287847545769230336/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7287396775282245632 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9b5ed12c-dd96-4797-8f25-8413a93ed076 | https://media.licdn.com/dms/image/v2/D4E05AQG9YF2nrAyczw/videocover-low/B4EZSIIsWCGYCM-/0/1737450775674?e=1765785600&v=beta&t=StvxG7xyBuHqElMCEOh19YNQyFObIj3B9IcZ279knpE | Finally!! The Powerplay Demo is available this week during the Steam Real-time Strategy Fest!
Play it here: https://lnkd.in/e4dDMcxs | 78 | 4 | 2 | 10mo | Post | Amine Rehioui | https://www.linkedin.com/in/aminerehioui | https://linkedin.com/in/aminerehioui | 2025-12-08T07:08:34.496Z |  | 2025-01-21T09:13:04.512Z |  |  | 

---



---

# Amine Rehioui
*Frantic Software*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [August 2015 – Amine Rehioui](https://amine.franticsoftware.com/2015/08/)
*2015-08-30*
- Category: article

### [The Most Important Lesson
I Learned From Building 8
SaaS Businesses in 4 Years](https://aminekhaoui.medium.com/the-most-important-lesson-i-learned-from-building-8-saas-businesses-in-4-years-d88ddf69abbc)
*2024-05-20*
- Category: blog

### [November 2018 – Amine Rehioui](https://amine.franticsoftware.com/2018/11/)
*2018-11-25*
- Category: article

### [Spider Engine in Beta – Amine Rehioui](https://amine.franticsoftware.com/2018/05/09/spider-engine-in-beta/)
*2018-05-09*
- Category: article

### [Procedural Spider Animation in Araknoids – Amine Rehioui](https://amine.franticsoftware.com/2018/11/25/araknoids-devlog-1-technical-overview/)
*2018-11-25*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Amine Rehioui de Frantic Software vise le multi-joueurs avec son ...](https://lienmultimedia.com/spip.php?article68614)**
  - Source: lienmultimedia.com
  - *OUBLIÉ ? CONNEXION. Abonnement · Publicité · Contact · Guide industrie · Vidéos · Podcasts ... Amine Rehioui de Frantic Software vise le multi-joueurs...*

- **[Frantic Software - Qui fait Quoi / Lien MULTIMÉDIA](https://lienmultimedia.com/spip.php?mot6222&debut_block_mots=5950)**
  - Source: lienmultimedia.com
  - *... Amine Rehioui, fondateur de Frantic Software. Le jeu proposera de prendre le ... [ Interviews vidéo | Développement | Jeux indépendants (indie) .....*

---

*Generated by Founder Scraper*
