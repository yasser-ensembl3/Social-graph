# Sébastien Notari

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403075370788216832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEjbPQTHjZFUg/feedshare-shrink_800/B4EZr0B0ZwHoAg-/0/1765030709195?e=1766620800&v=beta&t=aowiwaDj4ue9c8xvbVGOB9SqUq4vExBF8w4jDXvaSwc | 6,800 - c'est le nombre de visiteurs uniques sur www.beehivesaas.com en Novembre.

Après seulement 2 mois de mise en marché nous sommes confiants que nous avons bien identifié un Gap dans le marché - la recherche de logiciels simple et efficace.

Nos annonces sur Meta et Google sont claires et définies, les entreprises du commerce de détail, de la construction, la  restauration et les gyms sont bien visés.

Vous êtes un fournisseur de logiciel, votre produit est sûrement déjà sur Beehive allez le réclamer et connnectez avec des clients qui sont informés et qualifiés!

#saas #smb #software #search #beehive | 12 | 0 | 0 | 1d | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:51.537Z |  | 2025-12-06T14:18:30.885Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402557613441306624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF--OiYYFyuNw/feedshare-shrink_800/B4EZrsq647IoAo-/0/1764907266247?e=1766620800&v=beta&t=F9esCVbKeeiFIA6DTzZjQ_0rrmiN0w3829wEO17Balc | The best evenings happen at the end of the year!

Quelle belle soirée pour les Startup community awards aux bureaux de Ax-C avec les meilleurs entrepreneurs et leurs exploits comme BETA Labs et Heylist !
Et croiser des gens avec une énergie hors du commun comme Gwenaël Bégasse et Richard Chenier.

Shoutout a Stay22 pour votre reconnaissance!

On a entamé Décembre en force! On fini 2025 avec de l'intensité! | 30 | 0 | 0 | 3d | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:51.538Z |  | 2025-12-05T04:01:07.914Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402329774905516032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvO1LeNf1__g/feedshare-shrink_800/B4EZrpbs7cIQAg-/0/1764852944861?e=1766620800&v=beta&t=ACfIMNsAYYh2lKriJhO7i-8I9K8K7Ljmy4gUk3AAorE | 🐝 Seb’s Weekly Buzzworthy Software : Reelcruit - L’outil qui transforme l’analyse de CV grâce à l’IA

Mon jour préféré de la semaine : celui où je mets en lumière un logiciel qui fait vraiment une différence. Aujourd’hui, je vous parle de Reelcruit, une solution québécoise qui repense complètement le recrutement. J'ai eu la chance de rencontrer Fred Gauthier au lancement de la cohorte 2025-2026 du programme jeunes entreprises de l'AQT et en tant que ex-Indeed, j'ai tout de suite trippé sur leur produit!

Reelcruit utilise l’intelligence artificielle pour :
- Analyser des milliers de CV en quelques secondes
- Identifier les meilleurs talents selon des critères objectifs
- Réduire drastiquement le temps passé en présélection
- Offrir une base de données vivante et enrichie automatiquement
Et les résultats - agnostiques! Vous obtenez vraiment la meilleure personne pour le poste!

Pour les équipes RH débordées, c’est un gain incroyable : moins de tâches répétitives, plus de décisions stratégiques.
Et pour les entreprises en croissance, c’est une façon de sécuriser les bons candidats… avant la concurrence.
Une équipe d’ici, un produit d’impact, et une vision claire : rendre le recrutement plus rapide, plus intelligent et plus humain.

👏 Bravo à l’équipe Reelcruit — vous êtes définitivement buzzworthy.

Of course qu'ils sont sur Beehive - https://lnkd.in/eFu_8Hvn

#SaaS #Recrutement #AI #QuébecTech #RH #Innovation | 12 | 2 | 0 | 3d | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:51.539Z |  | 2025-12-04T12:55:46.974Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401603752371056640 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE97R3fEU8PLg/feedshare-shrink_800/B4EZrfHZC8KMAk-/0/1764679848470?e=1766620800&v=beta&t=2ykIx0AKXtqOJgdxKey7-hFHl_SpSWidcfPfbRLA9hk | 🔥 Hot Take: The way SMBs choose software was officially broken.

For the past decade, the world was told:
 “Just pick the top-rated tool on G2, Capterra, Software Advice.”

But here’s the truth nobody says out loud,
The “top tools” are often just the biggest ones, not the best fit.
And SMBs are paying the price.

Choosing the wrong software costs them:
 💸 Thousands of dollars
 ⏳ Months of wasted onboarding
 😩 Teams frustrated before they even start

Why?
Because the traditional model is built on reviews.
And reviews benefit the brands with the most users… not the most relevance.
But B2B isn’t Amazon.
 - Your business is unique.
 - Your workflows are unique.
 - Your needs are unique.
So why are we still choosing tools like everyone is the same?
👉 This is exactly why we built Beehive.
Not to rank software.
Not to crown “leaders”
But to match SMBs with the right tools, based on their real needs, not on popularity.
Because one-size-fits-all doesn’t exist in B2B software.

🐝  Want to test it yourself? It’s free.
 www.beehivesaas.com | 18 | 0 | 1 | 5d | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:51.540Z |  | 2025-12-02T12:50:49.713Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400188340903489536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHnV0X9Gf6uUw/feedshare-shrink_800/B4EZrLAFGRHcAg-/0/1764342388191?e=1766620800&v=beta&t=vJ4Kd8j5UHr3qWLcBZx-FM7VfEo9BBHIsn8RnNDltk4 | Don’t get me wrong — G2 has built an impressive business over the years, now valued at $1.2B

But their model is built on reviews. And while that approach worked extremely well for the past decade, we’re now seeing its limits. 

😎  The same “usual suspects” often end up at the top, not necessarily because they’re the best fit… but because they’re the biggest players.

In B2B, that’s a problem.

Choosing software isn’t like buying headphones on Amazon.
Every business operates differently. Every SMB has its own workflows, constraints, and goals.
A “category leader” doesn’t mean “the right tool for you.”

That's why we built Beehive - not everything fits everyone 🐝 .

Check it out and test it for yourself - it's Free
www.beehivesaas.com | 11 | 1 | 2 | 1w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:51.541Z |  | 2025-11-28T15:06:29.322Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7397648872161910784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKWFroLxra1A/feedshare-shrink_800/B4EZqm6cBeJ0Ak-/0/1763736931884?e=1766620800&v=beta&t=MsLxkiu-i0PYBDp0xJUsI1Z70M122byjXULRumxC3pY | Yesterday, I had the chance to attend an incredible session with Hubble:
 “From First Meeting to First Check: The Art of Fundraising.”

As a founder, you’re constantly navigating unknowns — but sessions like this one help bring clarity to a process that often feels like a black box. As Sasha Cayward - MSc. said from the get go - the first step is showing up!

A few insights that really hit home:
Fundraising isn’t about convincing - it’s about aligning.
The first meeting is rarely about the pitch deck… it’s about the relationship.
The best founders don’t chase checks; they build momentum.
And yes… timing matters more than we like to admit.
Kevin Jurovich was genuine, blunt and so inspiring.

We’re in the middle of our own fundraising journey at Beehive, and hearing directly from people who have been through the trenches was both energizing and grounding.
Bettina Briz your energy is contagious, hope you enjoy Mexico!

Grateful for the opportunity to connect, learn, and sharpen the craft.
Onward - moving forward!

#tech #vc #fundraise #boardy #hubble #beehive | 15 | 7 | 0 | 2w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.036Z |  | 2025-11-21T14:55:32.793Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7397280295059656704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8XIGdEVBcSw/feedshare-shrink_800/B4EZqhrOt6IwAg-/0/1763649056280?e=1766620800&v=beta&t=qFJ9guUykkHcz0XKh_gRXjqMEOVyDBRQFtL1zL_raqU | 🐝 Seb’s Weekly Buzzworthy Software : eZsign

Aujourd’hui, je mets en lumière eZsign, une solution de signature électronique conçue au Québec!

Pourquoi eZsign mérite mon coup de coeur, personnellement parce que je suis encore surpris du nombre de personne qui m'envoient des contrats a imprimer et signer... gang on est en 2025!!!

Mais aussi parce que:
- Les données dont entièrement hébergées au Canada, conformité assurée avec la Loi 25 et les normes SOC 2 Type II.
- Pour les PME comme pour les grandes organisations : signature illimitée, processus automatisés, API intégrée - plusieurs plans sur mesure disponibles.
- Une alternative locale forte aux grands acteurs internationaux — data canadienne, support bilingue, prix compétitifs.

Ce que cela signifie pour les PME & les SaaS
Pour une PME : plus de feuilles volantes, des impressions, des allers-retours ; documents signés en quelques minutes, et non quelques jours.
Pour les SaaS ou intégrateurs : voilà un bel exemple de logiciel verticalisé, franco-québécois, qui tient ses promesses et peut s’intégrer dans tout type de workflow digital.
Pour l’écosystème tech du Québec : un nouveau symbole que “local” + “sérieux” peut rimer avec “global” 🌎 .

De plus si vous êtes de Montréal, vous ne pouvez pas les manquer sur les terrains de Football des Alouettes de Montréal ou encore des Carabins. Et peu importe où vous êtes au Québec, je vous encourage fortement de vous inscrire au génial podcast de Judith Fetzer - Un café avec Judith!

👏 Bravo à toute l’équipe eZsign pour ce que vous accomplissez — vous êtes réellement buzzworthy !

Disponible sur Beehive - https://lnkd.in/exhwzKkV

#SaaS #TechQuébec #SignatureÉlectronique #PME #Innovation | 20 | 1 | 2 | 2w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.037Z |  | 2025-11-20T14:30:57.164Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7396978878730326017 | Text |  |  | Great opportunity in an incredible Montreal institution - please share! | 3 | 0 | 0 | 2w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.039Z |  | 2025-11-19T18:33:13.911Z | https://www.linkedin.com/feed/update/urn:li:activity:7396976965305397249/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7396204858116083712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZK3o7bHte9w/feedshare-shrink_800/B4EZqSTDZdGYAo-/0/1763391060734?e=1766620800&v=beta&t=YN26GAqYPGxHnUy0v62ylyTHDgokCEEe_T0qUaNeZtY | We did something pretty cool this weekend... | 12 | 0 | 0 | 2w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.040Z |  | 2025-11-17T15:17:33.016Z | https://www.linkedin.com/feed/update/urn:li:activity:7396198184340910082/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7394759016771567616 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEJ_YPmW_J7Iw/feedshare-shrink_800/B56Zp92Io7KEAg-/0/1763047935880?e=1766620800&v=beta&t=P_o1-sH1x9vcOf3SLZkQowQhgBjf1Vt9jUYZblI2-hA | 🐝 Seb’s Weekly Buzzworthy Software : Applauz — la plateforme qui transforme la reconnaissance en culture d’entreprise!

Aujourd’hui, je mets en lumière Applauz, une solution canadienne d’engagement des employés conçue pour donner vie à la reconnaissance, jour après jour.

Ce qui rend Applauz remarquable:
- Une plateforme complète: reconnaissance 360°, flux d’actualités interne, badges & points, marketplace de récompenses. 
- Des outils de feedback puissants: sondages pulse, données analytiques en temps réel pour mesurer l’engagement et la satisfaction.
- Intégration fluide: se connecte aux principaux systèmes RH et plateformes de communication pour une expérience sans interruption. 
- Une équipe soudée sous le leadership expérimenté de François Fortier

Ce que cela signifie pour les PME & la tech au Québec:
- Pour les PME : plus qu’un logiciel, Applauz est un levier pour renforcer la culture, motiver les équipes et mieux retenir les talents.
- Pour l’écosystème tech québécois : fier de voir une équipe locale penser « people first » et délivrer à grande échelle.

👏 Bravo à toute l’équipe Applauz pour ce que vous accomplissez — vous êtes vraiment buzzworthy !

Disponible sur Beehive: https://lnkd.in/gaeHzdJP

#SaaS #HRTech #EmployeeEngagement #QuébecTech #PME #CultureEntreprise #beehive | 32 | 4 | 3 | 3w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.042Z |  | 2025-11-13T15:32:17.577Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7394346092626345984 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF3XTuMRHAqHg/feedshare-shrink_2048_1536/B4DZptIdDYKIAw-/0/1762767524637?e=1766620800&v=beta&t=eq-6DC3UeA156nlAVqahS-t4mN8eFhsEnPq8YDVUIX8 | If you are not following Guillermo Flor - this is your cue. Every day he shares great applicable insights for us - the founders! | 4 | 0 | 0 | 3w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.043Z |  | 2025-11-12T12:11:28.789Z | https://www.linkedin.com/feed/update/urn:li:activity:7394267841983750144/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7394153176863760384 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGEZzQ5Atgztw/feedshare-shrink_800/B4EZp1PHvQIoAg-/0/1762903490708?e=1766620800&v=beta&t=rjrxAX-Byq3KFrwbf34EDos94qbzP9vtqGVhvyYYa2c | La première journée a STRATÉGIES PME n'a pas déçu!

Des centaines de compagnies axées sur les besoins des petites et moyennes entreprises du Québec (dont la plupart se retrouvent sur Beehive), une atmosphère vibrante et des conversations enrichissantes!

Ce salon pour moi c'était des retrouvailles, un peu de business et des découvertes. On a vraiment du bon monde au Québec! Pour ne nommer que ceux qui figurent sur mes selfies:

Mon amie (et ex-collègue haha) Heidi de chez Intuit Canada
Mes anciens partenaires d'affaire de chez Desjardins les merveilleuses Julie et Flavie
La sympathique équipe d'Altee - David, Jade & Luana
Le duo dynamique de Go RH - Sandra et Yoann (ex-collègue Indeed)
Une petite partie de mes amis chez Folks - Jeff & Alexis
Le responsable du développement de affaires pour les PME aux Québec de chez ADP (et mon collègue à la Chamber of Commerce of Metropolitan Montreal) Guillaume
Mes découvertes de la journée Laurence & Mehdi
Sans oublier mon ex collègue Erwan et ma nouvelle partner of getting sh*t done Julie-Maude!

L'avenir est prometteur

#tech #pme #networking #tech #beehive | 76 | 14 | 0 | 3w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.045Z |  | 2025-11-11T23:24:54.087Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7393656079173328896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGCX1KQGJQDDA/feedshare-shrink_800/B4EZpuLA4MIQAg-/0/1762784975864?e=1766620800&v=beta&t=6FFbrrTV4p69qLvI-IBGTP47gdmbwfX4hVIqoRpwIDU | La souveraineté numérique est un sujet important et passe parfois en dessous du radar. 

Croître les PME et créer la confiance autour de l'IA. 
Il y'a plusieurs programmes en charge de propulser les entreprises Québecoises pour mettre de l'avant la culture - c'est une des missions de Zú qui aide les jeunes entreprises dans l'atteinte de leurs ambitions.

Merci Gwenaël Bégasse pour l'invitation à cette conférence/réseautage fort interessante!

#tech #ai #quebec #souveraineté #zù | 22 | 0 | 0 | 3w | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.046Z |  | 2025-11-10T14:29:36.762Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7392202186476199936 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZGCKR5Bhy4A/feedshare-shrink_800/B4EZpZgt2HKYAo-/0/1762438340658?e=1766620800&v=beta&t=HlVhDbVnjY6XAN7cy8lJE9cQm4diU9FOB0dy7ZsH5WQ | 🐝 Seb’s Weekly Buzzworthy Software : BETA Labs — la start-up qui transforme le réseautage d’affaires grâce à l’intelligence

Bon, cette compagnie là est mon coup de coeur 2025 (et celui des juges de la SaaSpasse Conf) BETA Labs, une entreprise québécoise qui réinvente la façon dont les événements d’affaires créent des connexions.

Leur plateforme dote les organisateurs d’un outil de réseautage intelligent basé sur l’IA et les données. L’objectif ? Faire en sorte que les rencontres lors d’un salon ou d’une conférence soient pertinentes, ciblées et réellement utiles. Comme le dit si bien Elizabeth Tremblay - tant qu'a payer pour envoyer des employés à une conférence, rendons les rencontres pertinentes! Return on Investment (ROI)

- Pour les organisateurs : plus de valeur, plus de participants satisfaits.
- Pour les entreprises : moins de small talk inutile, plus de vraies opportunités.
- Pour l’écosystème tech québécois : un autre bel exemple de solution locale, bien nichée et prête à s’étendre.

Chez Beehive, on croit que ce n’est pas la quantité qui compte, mais la pertinence des matchs — que ce soit pour trouver un logiciel… ou le bon contact d’affaires lors d'une conférence.
Et c’est exactement ce que BETA Labs réussit à faire. 👏

Bravo à toute l’équipe pour votre vision et votre exécution !

Certainement disponible sur notre plateforme: https://lnkd.in/eQFFuv_Y

#SaaS #EventTech #Réseautage #QuébecTech #Innovation #PME | 26 | 3 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.048Z |  | 2025-11-06T14:12:21.731Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7391914758028828672 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG-1xsRZWcpkQ/feedshare-shrink_800/B4EZpVbToDKYAg-/0/1762369813522?e=1766620800&v=beta&t=4sWLCiIZxRrUH_tXwdfjbHovlHcIEmhT5AiodmtN-wY | Are we a RaaS servicing SaaS?

While listening to Michael Litt's great conference at #SaaSNorth it got me thinking... 

🐝 We built Beehive on the promise to deliver results. Qualified Leads. 
SMB's that actually understand what your company offers and why it's a fit for their business. But as a SaaS you only pay a low subscription fee (starting at 99$) and pay-per-performance after that.
 
No leads - No additional cost. 
No demos requests - No additional cost.
Subscriptions are monthly. If we don't deliver, you leave anytime. No strings. Just results.

From now on, we will be known as a RaaS4SaaS - yeahhh more acronyms!

#saas #raas #tech #smb #beehive | 6 | 0 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.049Z |  | 2025-11-05T19:10:13.449Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7391860325626589184 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEUcODnufjpfA/feedshare-shrink_2048_1536/B4DZpUpyBaIEAw-/0/1762356833002?e=1766620800&v=beta&t=9FsUyGzGDALY53Zo1wesHJZKyFgOFecuWrcZKu-E-OY | Getting things started at #SaaSNorth in Ottawa. 
Great opportunity to learn about market trends, discovering emerging tools like Boardy and seeing familiar faces like Guillaume Jacquet from Vasco.
Travelling with the quite large group of Le Camp.

#saas #tech | 40 | 0 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:54.051Z |  | 2025-11-05T15:33:55.753Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7391232364808601600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFtWS8nj1HPZg/feedshare-shrink_800/B4EZpLuq7WHgAk-/0/1762207117503?e=1766620800&v=beta&t=Phm-DoXK4fgn0-SvZWAzwUW3_pZqNOvXsdqqC9hgNdQ | The Evolution of Software Buying 🐝 

Word-of-mouth → Analyst reports → G2/Capterra → Beehive’s AI-driven matching

Let’s be honest… SMBs don’t have time to scroll through 200 CRMs or decipher endless 5-star reviews written by someone’s cousin.

They want clarity, not chaos.
They want recommendations, not research papers.

That’s exactly what we’re building at Beehive: a smarter, simpler way for businesses to find the right software for their needs.

AI-powered, transparent, and built with love (and caffeine) in Montreal
Because the future of software discovery isn’t about more choices —
it’s about better matches. 

Is your Software on beehive?
▶️ https://lnkd.in/e8rY9-4Q

#SaaS #AI #SMB #Beehive #SoftwareBuying #FutureOfWork | 12 | 2 | 1 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.250Z |  | 2025-11-03T21:58:38.227Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7389653812522741760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzG8qm0PrETw/feedshare-shrink_800/B4EZo1S.7LHUAg-/0/1761830761118?e=1766620800&v=beta&t=b0rxY_dekPIBtUrHaPF6QduWyFjo5bLzQW2DAW0bjos | 🐝 Seb’s Weekly Buzzworthy Software : Folks — la solution RH pensée pour les humains, par des humains.

Si vous ne les connaissez pas déjà, il est temps de les découvrir! 
Folks est une entreprise québécoise que je respecte énormément. Construite avec une vraie vision humaine, elle aide les PME à gagner des heures précieuses chaque semaine en centralisant tout ce qui touche aux RH :

🤝 Embauche et intégration
📊 Gestion quotidienne et données employé
📈 Suivi de la performance
💸 Et maintenant… la paie 

Après avoir conquis le marché des PME, Folks est en pleine expansion vers le marché des grandes entreprises.

C’est l’exemple parfait d’une équipe locale qui écoute ses clients, bâtit un produit sur une base solide et contribue au rayonnement de la tech québécoise.

Shoutout à ceux que j'ai eu la chance de côtoyer dans mon ancienne vie: Jimmy Plante ; Jeff Pelletier ; Catherine Maheux-Rochette ; Charles Aubry ; Alexis Cliche-Langlais ; Steph Morin

👏 Bravo à toute l’équipe Folks HR pour ce que vous accomplissez — vous êtes vraiment Buzzworthy.

Et bien sûr Folks se retrouve sur Beehive - https://lnkd.in/e3anm2Dk

#SaaS #HRTech #QuébecTech #PME #Entreprises | 26 | 5 | 4 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.251Z |  | 2025-10-30T13:26:02.034Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7389318184094351360 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFUJeZH0bGFag/feedshare-shrink_800/B56Zowhtn8JsAg-/0/1761750739002?e=1766620800&v=beta&t=8bsAPxt7lq4pGlaZiZE0pJsvLkel8n25iW3WsvTQKM4 | Scaling is a Science. 

It's not luck, it's not wishful thinking, it's planning and executing.

Attending #revstar today, the event i didn't realize i needed. We all need that reality check. We are not even half way through the day and i feel enlightened - thanks JD Saint-Martin & Sarah Chmielewski for 2 killer presentations, great way to lead the day!

Time to roll in the Mud!

Guillaume Jacquet - bravo, ce que tu fait est inspirant. On a du talent de fou ici a Montreal!

#saas #revops #leadership | 43 | 4 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.251Z |  | 2025-10-29T15:12:21.981Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7388612611329839105 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF7AyOwaJJFIQ/feedshare-shrink_800/B4DZomgA9wH0Ag-/0/1761582519457?e=1766620800&v=beta&t=prcV1a4HulsgY8PqoGHDeiMtVzUY9GM29z_qCD63aAs | En choisissant les mauvais logiciels - Les coûts cachés s’accumulent

Lorsqu’un logiciel ne correspond pas à vos besoins :
- Vous perdez du temps à cause d’une utilisation ou intégration difficile.
- Vous payez pour des fonctionnalités inutilisées ou des licences superflues.
- L’implantation prend du retard ou échoue complètement.
- Vous devez remplacer ou bricoler des solutions temporaires.
- L’expérience client et la motivation des employés en souffrent.

Chiffres au Canada :
94 % des PME canadiennes affirment que les technologies numériques sont essentielles à leur stratégie de revenus. (Sage, 2024)
76 % des PME canadiennes prévoient d’augmenter leurs investissements en technologie dans l’année à venir. (Sage, 2024)
Les PME utilisant des outils inefficaces ou non intégrés sont deux fois plus susceptibles de déclarer un manque de visibilité sur leurs flux de trésorerie. (Float, 2024)
60,6 % des entreprises canadiennes ont adopté au moins une technologie avancée en 2022. (Statistique Canada)

La vocation de Beehive est simple - recommander les bons logiciels aux PMEs pour qu'ils perdent moins de temps et moins d'argent!


#saas #marketplace #beehive #pme | 10 | 0 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.252Z |  | 2025-10-27T16:28:40.325Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7387275404711211008 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHqfjXVueypag/feedshare-shrink_2048_1536/B4EZoTfy0.IMAw-/0/1761263702282?e=1766620800&v=beta&t=E9OLwDwGWwXWgp6XZ23EQO1MhByGgX9cmmCNL2wCwRc | Soirée double en ce jeudi soir.

Launch de la nouvelle serie de l'artiste Antoine Tava – AntoineTava

Suivi du podcast de SaaSpasse chez EY pour parler de risque et IA. 

Busy Busy mais ô combien interessant! | 22 | 1 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.253Z |  | 2025-10-23T23:55:05.423Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7385990554284609536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGe1EBjHzSS4w/feedshare-shrink_800/B4EZoBPRI3HMAg-/0/1760957371354?e=1766620800&v=beta&t=Z7JivKUttQsAe7ZUfG7OcnIQSaoheJkpXy7zTDc3rRA | 🐝  The SaaS Discovery Paradox 🐝 

After conducting our market analysis, one thing is sure - SMBs don’t need more software. They need the right ones.

Yet today, the buying process is broken:

 ❌ Endless review sites listing thousands of tools
 ❌ Marketing hype that overshadows real capabilities
 ❌ Businesses wasting time and money on poor-fit solutions

The result? Frustration. Low adoption. Expensive mistakes.
At Beehive, we believe the future of SaaS discovery is curation, not confusion.

Instead of forcing SMBs to dig through noise, we reverse the process:
 👉 They tell us who they are,
 👉 We recommend the tools that best match their needs (65%+ fit score).

Less noise. More clarity. Better decisions.
Because there are no bad softwares, only bad matches.

#software #saas #smb #help #beehive | 10 | 0 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.254Z |  | 2025-10-20T10:49:33.210Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7384903937293721600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTZVAZRFbM1Q/feedshare-shrink_800/B4EZnxy_tBIoAg-/0/1760698302707?e=1766620800&v=beta&t=M6kUG5jwl4oOd3n1Ibs5J8HDsTNKq6ag890B8hCVveo | Il ne faut pas sous-estimer la puissance des tendances. 

Il n'ya pas un jour où j'ouvre mon Linkedin sans voir des posts sur l'Intelligence artificielle, à quel point cela va redéfinir le monde du travail, que c'est essentiel de jump onboard. Mais la réalité c'est que les petites entreprises ne sont pas là. 

Votre Boucher, votre Garagiste, votre Fleuriste, votre Café ont d'autres priorités, mais la bonne nouvelle pour les SaaS c'est que le mouvement vers la digitalisation et l'automatisation fait boule de neige. En entendant parler d'IA ils réalisent qu'ils sont très loin de ça et qu'il est temps de s'activer.

C'est la fin des fichiers Excel pour planifier leur staff, ils se tournent vers des Evolia, des Agendrix ou encore Planifico – Fini les pertes de temps

Le factures manuelles et la gestion des stocks sur un note pad sont remplacées par des Alice POS, Lightspeed Commerce ou Octogone

Le momentum est là - il est temps d'en profiter et de leur parler!

ps: si toi aussi ton enfant de 12 ans utilise chaque occasion de te lancer un wooohaaa six-sevennnn, fais moi signe, je suis pas seul right? | 8 | 1 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.254Z |  | 2025-10-17T10:51:43.531Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7384532788701716480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdTd325iL9CQ/feedshare-shrink_800/B4EZnshcI9KcAk-/0/1760609814020?e=1766620800&v=beta&t=nW-3N--EK7OTA0S2ip-gGo2-pR9tirOeawsgfWr7JDk | 🐝 Seb’s Buzzworthy Software : Manni — l’intelligence dans vos réunions

J’ai découvert récemment Manni, une application qui rend vos réunions beaucoup plus productives :

Elle transcrit automatiquement vos conversations (calls ou réunions)
Elle extrait les points-clés, actions & résumés intelligents
Elle indexe vos notes de façon “smart”, pour retrouver rapidement les échanges passés

Bonus : l’app comprend les accents québécois / français, pour éviter les erreurs de transcription
Pourquoi c’est pertinent pour les entreprises et les fondateurs comme nous ?
Parce que le temps est la ressource la plus précieuse. Ne plus devoir prendre des notes manuelles, pouvoir se concentrer sur les idées, et disposer d’un historique structuré — c’est un gain énorme.

Les gars qui ont lancé ça sont brillants et regorgent d'idées, donc attendez vous à des améliorations en continu!
Si tu veux tester, je te recommande d’essayer leur version gratuite ou demander une démo. En plus c'est Made in QUEBEC!

Et oui bien sûr vous pouvez retrouver l'application sur Beehive - https://lnkd.in/eFG-SY_c | 40 | 9 | 3 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.255Z |  | 2025-10-16T10:16:54.811Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7384412382049013760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbvCNsDMry_A/feedshare-shrink_2048_1536/B4EZnqz74RKYAw-/0/1760581107598?e=1766620800&v=beta&t=jywocqvVOyXPOi3n3C2K6ArPhWcFelv7Se_20ldMDss | Quelle belle soirée avec la Chamber of Commerce of Metropolitan Montreal pour faire du réseautage et échanger avec des membres engagés. Merci pour l'accueil chaleureux Productions Arborescence et pour la visite des bureaux Natasha Krummen (so nice to see you). J'en profite pour vous dire BRAVO pour votre belle mission de faire rayonner les femmes dans le marché du travail, c'est un mandat qui mérite d'avoir toute l'attention nécessaire.

J'adore ces soirées et mes échanges très pertinents avec Sarra Mamlouk ساره مملوك et Sarah Maston propos du marché de la PME, du recrutement et du besoin primordial de déconnecter!

Merci Danielle Vitor pour l'invitation - Until next time ✌🏼

#network #montreal #smb | 19 | 2 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.256Z |  | 2025-10-16T02:18:27.628Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7384249628201922561 | Article |  |  | Tu es en charge du lead Gen dans une compagnie SaaS, et tu n'as pas encore pris en charge votre profil d'entreprise sur Beehive?

Chez Beehive, nous croyons qu’il n’y a pas de mauvais logiciels, mais plutôt des mauvaises décisions.
Et une mauvaise décision, c’est de laisser passer l’occasion d’être découvert par les bonnes PME.

🐝  Dans notre dernier article de blog, on vous explique comment revendiquer et optimiser votre profil SaaS sur Beehive pour :

 Gagner en visibilité
 Attirer des leads qualifiés
 Renforcer votre crédibilité auprès des PME québécoises et canadiennes

Votre logiciel mérite d’être vu. Votre profil mérite d’être réclamé.

Lisez l’article ici : https://lnkd.in/ddNxmyPG - en bonus on a même mis un step-by-step sur notre chaîne Youtube!

Bonne lecture 🤓 | 6 | 0 | 1 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.257Z |  | 2025-10-15T15:31:44.087Z | https://www.beehivesaas.com/fr/blogs/claim-your-digital-identity |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7383874358022164480 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHdW2V0TTWhAQ/feedshare-shrink_800/B56ZnjKmZaG4As-/0/1760452831697?e=1766620800&v=beta&t=sFWcF54e4EmQpdT80gPz2VW_WFciZCjagKvl4yQegnE | "Beehive, quel est le meilleur point de vente pour mon restaurant"
- Isabelle de chez Cora Déjeuners

Notre algorithme unique ne se fie pas à l'opinion des autres mais analyse le besoin d'affaire de l'entreprise selon plusieurs critères. C'est comme ça qu'Isabelle peut voir que Maitre'D POS sort avec un "Match" de 90%, elle peut donc comparer plusieurs outils et valider la pertinence pour elle.

Nous offrons une approche novatrice qui permet aux entreprises de voir tout les outils dans toutes les catégories et faire un choix éclairé.

Les PME viennent sur www.beehivesaas.com pour trouver leur prochain logiciel, assurez vous de réclamer et mettre à jour votre profil pour contrôler le narratif!

#marketplace #saas #tech #smb | 16 | 2 | 0 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.257Z |  | 2025-10-14T14:40:32.704Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7383497281997598721 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHPcRbYb07-Ag/feedshare-shrink_800/B4EZndzp0fKkAg-/0/1760362929869?e=1766620800&v=beta&t=BnY-Q06XsugAUeJfgWzuLn_DCFSomym1zFpCtH5xapQ | Our bold move? We reversed engineered the process.

All the Marketplaces that list software (G2, Captera, SoftwareAdvice, SourceForge, etc.) work the same way - you have to tell them what you are looking for and based on peers review you'll know if others liked them. Others. But what about you? Is it because others liked it that it is a good fit for you?

Too many SMBs waste time and money testing software that doesn’t fit their needs. At Beehive, we flipped the process: instead of asking SMBs to search endlessly, we ask WHO they are and recommend the best software matches. That’s the future of SaaS discovery - simple, transparent, efficient and personalized!

Test it out - www.beehivesaas.com - and give us some feedback! | 11 | 0 | 1 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.258Z |  | 2025-10-13T13:42:10.774Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7382420273393926144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbSuO0lzkm4w/feedshare-shrink_800/B4EZnOgHiOJgAk-/0/1760106150691?e=1766620800&v=beta&t=aLKa9ngKigydVloa5McuxBpa0dCaDZFW9b_FxIjxyzw | Salut cher réseau!

Nous sommes à la recherche d'une personne qui peut créer du contenu et gérer nos médias sociaux (IG, TikTok, YT et FB) - Nous cherchons quelqu'un qui peut faire des montages vidéos (basic) avec des vox pops comme ceux que tu vois sur notre site de compagnie Beehive et qui peut gérer les activités sur nos autres plateformes. Nous envisageons un mandat d'environ 4-5hrs semaine, un(e) pigiste en gros. Il faut être bilingue car notre audience est Nord-Américaine.

Si tu es cette personne DM moi directement. Si tu connais cette personne, tag la dans ce post ou dit lui de m'écrire directement. On est pas mal fun à travailler avec et on aime le contenu funky. 

En plus tu va collaborer étroitement avec notre marketing Boss - Stéphanie Bédard - cherry on the Sunday comme on dit! 🍨 | 9 | 7 | 1 | 1mo | Post | Sébastien Notari | https://www.linkedin.com/in/sebnotari | https://linkedin.com/in/sebnotari | 2025-12-08T05:14:58.258Z |  | 2025-10-10T14:22:31.913Z |  |  | 

---

