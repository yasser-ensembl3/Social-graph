# Martin Weiss

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Tiptree Systems
**Durée dans le rôle** : 2 years 2 months in role
**Durée dans l'entreprise** : 2 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Information Services

## Description du rôle

Building AI-powered knowledge routers that connect the right expertise to the right person at the right time. Our omnichannel AI assistant analyzes real-time work patterns to understand who knows what, then proactively facilitates collaborations that save weeks of duplicated effort. Deploying to leading research institutions including Mila (1,400 researchers) and billion-dollar enterprises.

## Résumé

Building AI-powered knowledge routers to solve the coordination problems I witnessed firsthand as Mila grew from 70 to 1,400 researchers. After spending years training models and co-authoring papers with top researchers, I realized the meta-problem underlying a lot of surface problems is how information flows through groups of people.

At Tiptree, we're ensuring brilliant minds don't waste weeks on problems their colleagues already solved. Our AI analyzes real-time work patterns to understand who knows what and proactively facilitates the collaborations that lead to breakthroughs.

Before my PhD, I was an early employee at a social graph analysis startup in SF that was acquired by Lyft. Met my co-founder Nasim 5 years ago building COVID contact tracing systems with Yoshua Bengio - we've been collaborating on research and building together ever since.

Passionate about creating the infrastructure to enable a world where knowledge and credit flows to the people who can do the most good.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAgyGnwBSBgCHhbkjnYJIaMfEwTmBqgJo4E/
**Connexions partagées** : 65


---

# Martin Weiss

## Position actuelle

**Entreprise** : Tiptree Systems

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Martin Weiss

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402078911083364352 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHKWuBQOVpsuw/feedshare-shrink_800/B4EZrl3QcxKYAo-/0/1764793135668?e=1766620800&v=beta&t=Qq1cn6TXf8qDxMLViAOuJSsoTRqT7gUjLHkTb2mNU-8 | Had a great lunch at NeurIPS with Anirudh Goyal, Nan Rosemary Ke, and Nasim Rahaman. Talking about the old days at Mila - Quebec Artificial Intelligence Institute -- maybe good AI, maybe bad AI, but always good people. | 59 | 2 | 0 | 4d | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:09.672Z |  | 2025-12-03T20:18:56.378Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7400972130177409026 | Article |  |  | Overwhelmed by 5,500+ #NeurIPS posters? I vibe-coded a Poster Navigator this morning to rank every poster based on your interests: https://lnkd.in/emqcysdi

... made using the same technology the generated most of those 5,500 #neurips papers :P | 22 | 3 | 2 | 1w | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:09.672Z |  | 2025-11-30T19:00:59.247Z | https://neurips2025.tiptreesystems.com/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399994187644968960 | Article |  |  | Come hang out with the Tiptree team at NeurIPS! | 12 | 0 | 2 | 1w | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:09.673Z |  | 2025-11-28T02:14:59.578Z | https://luma.com/xmlayefi |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7313198939703246848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9F5_PMyYJIg/feedshare-shrink_800/B4EZX2zrjFGgAg-/0/1743602499087?e=1766620800&v=beta&t=cUKz-6-S-F9--s0nSXWlKCD6watjlV9R1iF6RMqQjsc | I'm defending my PhD on AI agents this Friday at 9 AM EST. 

I began at Mila back in 2017 training graph convolutional neural networks on gene regulatory networks under Joseph Paul Cohen PhD and Yoshua Bengio. During my Master's, I worked on multi-modal RL agents to help the blind navigate (which turned into a product sold by HumanWare), then on proactive covid contact tracing with Tegan MaharajNasim RahamanPrateek GuptaPierre-Luc St-CharlesVictor SchmidtTristan DeleuEilif Benjamin MullerJoumana GhosnBernhard SchölkopfAndrew Robert Williams and so many others.

I began my doctorate obsessed with getting neural networks to learn to do arithmetic. This led to developing new neural architectures, applying them to different tasks, and participating on team Limelight Rainforest where we won the $10M XPrize for rainforest biodiversity assessment.

I finish my doctorate obsessed with understanding how AI agents will transform society. My core thesis: agents are a new form of media—like radio or television before them—that will carve entirely new channels of information flow, reshaping society far more profoundly than social media ever did. And that's why I co-founded Tiptree Systems with Nasim Rahaman, to build these channels.

If you want to give me a graduation gift, then signup at Tiptree Systems and try out the most capable AI agent out there.  If you want to watch my defense, you can comment on this post and I'll send you a zoom link. | 161 | 32 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.914Z |  | 2025-04-02T14:01:39.891Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7312466235156279296 | Text |  |  | I recently spoke with a master's student about Anthropic's new interpretability paper, which introduces "cross-layer transcoders"—interpretable features that replace traditional neurons. 

This method feels like a significant step forward, especially as a practical tool to explore findings about how pruning shapes model fairness (building on Sara Hooker's work). It could help us revisit classic interpretability questions from the BERTology era with more sophisticated tools, or even uncover architectural biases in vision models like CLIP and multimodal architectures. 

I'm old now, so I got to share a little historical perspective on how far interpretability research has come: from Christopher Manning's pioneering work extracting syntactic hierarchies from BERT, to Neel Nanda🔸's mechanistic interpretability, and Been Kim's foundational work on interpretable ML—we've steadily improved our ability to open these black boxes. 

I'm curious to hear from the interpretability community: How might this new technique complement existing approaches? What classic interpretability questions could we revisit with these improved tools? | 19 | 0 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.915Z |  | 2025-03-31T13:30:09.514Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7312038325442306048 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEa1bfKOs5Jrg/feedshare-shrink_800/B56ZXisX0eGoAk-/0/1743265179333?e=1766620800&v=beta&t=JGFq0m3xzHQDYkq86_69rQInbnOQipppyZ9vSJRvnJI | Interestingly, numerical data in AI-generated images often fail statistical tests like Benford's Law—the fact that in many real-world datasets, numbers are far more likely to start with a 1 (about 30% of the time!) than a 9 (~5%). The reason has to do with sampling from log-normal distributions, which is tricky to model if you've got an image generation model in the mix.

I had GPT 4o generate some images of census data which in reality would obey Benford's Law, but does not in that image with statistical significance. | 4 | 1 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.915Z |  | 2025-03-30T09:09:47.888Z | https://www.linkedin.com/feed/update/urn:li:activity:7311784122090168320/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7305230991936098304 | Article |  |  | My second startup was a music sharing silent disco app. I spent a summer micing dance music and throwing parties in public space. The first time I visited SF was to host one of these events with 2,000 people dancing on the embarcadero.

This weekend I got to break out the media editing software for tiptree systems. Enjoy! | 7 | 1 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.916Z |  | 2025-03-11T14:19:53.106Z | https://www.youtube.com/watch?v=GciIAL9olZQ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7304482347989520384 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8cd09252-cb25-4047-bbe8-f8d5ea610bb9 | https://media.licdn.com/dms/image/v2/D4E05AQH3twpbTTRDhQ/videocover-high/B4EZVrp3NPG0B0-/0/1741267940281?e=1765774800&v=beta&t=AJk3q-Vzmix8b3mpP6VjlIwmmVVlyE24DMTwtIQ19Ok | Intelligence is commoditizing, empowerment and context are appreciating in value. These trends determine what you should build as an startup. | 4 | 0 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.916Z |  | 2025-03-09T12:45:02.480Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7304138876107829249 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f2fdca97-28c7-448f-a29a-6f8fe2e412ff | https://media.licdn.com/dms/image/v2/D4E05AQF1i1MkxUfs3w/videocover-high/B4EZVrt1lLH0Bs-/0/1741268959471?e=1765774800&v=beta&t=ApQC_eLJ0QwWltSG0GdEWnlNy-2mxb1bu5qP-w0a_Dk | We built the best way to find, understand, and compare research papers. You can try it now at Tiptree Systems. | 1 | 0 | 0 | 8mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.917Z |  | 2025-03-08T14:00:12.402Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7303791636797378561 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8e95c9a2-0841-41e3-8ae5-dc86363cbc18 | https://media.licdn.com/dms/image/v2/D4E05AQH1yxXnrQvEXA/videocover-high/B4EZVr64vvHgBw-/0/1741272387502?e=1765774800&v=beta&t=BaH_ERgZuCu6F_aEmn3YFUt0txSv8UwVtC9vhB4wX9c | It’s important to find the best people to work with, to invest, and to use your products. 

That’s why we made our AI agent crush at finding the right people. | 15 | 0 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.917Z |  | 2025-03-07T15:00:24.099Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7303519619946827776 | Article |  |  | Hit me up if you want some API keys | 6 | 0 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.918Z |  | 2025-03-06T20:59:30.228Z | https://tiptreesystems.com/platform |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7303403846909788160 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5be39410-93c0-4af5-a29f-17058f6c312b | https://media.licdn.com/dms/image/v2/D4E05AQGBvTJgWvgLkA/videocover-high/B4EZVrm_AkGYBs-/0/1741267161413?e=1765774800&v=beta&t=xEgix2fjfOMrud7E5oYNxmw3RNY28vyNQnxZ3kH0dfw | Learning to delegate work to AI is more important now than ever. | 10 | 0 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.918Z |  | 2025-03-06T13:19:27.785Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7302680279096176640 | Text |  |  | I was just asked how to get a job at a startup, and it reminded me of a startegy I used to get a job at an YC/A16Z-backed startup, and into Mila (sub-1% acceptance rate) with a 3.0 CGPA from McGill.

1. Make a list of target companies.
2. Make a list of the people you want to work for at those companies.
3. Make a list of people you know who may know someone who may hire you. 
4. Meet with people on list 3 and show them list 2 and ask for introductions. Literally open your computer and show them the list.

This strategy works when you're reasonably connected to the target population. If you're not, it's harder. As I learned when I tried to get into Mila.

Mila profs are too busy to reply to email, and before I joined I didn't know anyone at Mila. I didn't even know anyone who knew anyone at Mila (it was only ~70 people then). 

So I made a 4th list: a list of PhD students at Mila. Then I read their papers. PhD students love it when you read their papers. They reply to your emails about their papers. They talk your ear off about their papers. And they know the institution and the profs. Over time, list 4 becomes your friends and colleagues. Then list 4 introduces you to the people who hire you. | 56 | 3 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.919Z |  | 2025-03-04T13:24:15.775Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7302330230600286208 | Text |  |  | We recently started running workloads on Groq's Language Processing Unit (LPU) hardware at Tiptree Systems. Before, processing and summarizing retrieved messages using GPT-4o-mini introduced up to ~9 seconds of overhead. Switching to Qwen-32B hosted on Groq reduced this latency to ~2 seconds — a ~78% improvement.

Agent runtimes execute tasks with varying computational demands, where tasks are often conditionally dependent on each other. Assigning simple summarization tasks to expensive, slower models is inefficient, just as assigning complex reasoning tasks to lightweight models is ineffective. Groq's LPU architecture is specifically optimized for transformer inference, making it ideal for rapid, predictable execution of simpler cognitive tasks like summarization and low-risk decision-making.

Latency isn't merely a UX metric — it's a fundamental constraint on the space of agentic systems. Fast, specialized inference hardware like Groq's LPU enables us to build more capable systems than previously possible, expanding the latency-quality pareto frontier. | 50 | 3 | 3 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.919Z |  | 2025-03-03T14:13:17.710Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7300950688233115649 | Text |  |  | Some reflections on AI automation architecture:

I think automation builders (those drag-and-drop pipelines, no-code platforms like Zapier) are a local minimum in the loss landscape of AI interfaces. They existed before LLMs, and LLMs fit naturally with that system architecture (e.g., It’s a new block that writes an email!), so it makes sense that we see an explosion in their adoption.

The problem is this: I don't think they scale particularly well. As organizations accumulate more of these workflows, they accumulate a form of technical debt (primarily managed by non-technical folks), which causes diminishing returns on each incremental workflow.

The alternative: contextual, intent-based AI workers. Instead of rigid workflows, these systems maintain state, understand context, and autonomously orchestrate tools to achieve objectives. These systems will scale more effectively because each AI worker can autonomously adapt to systemic change. And as LLM capabilities improve, this architecture will compound exponentially rather than linearly.

This matters because companies are developing new processes that will determine their future growth and operational efficiency. While traditional automation will incrementally improve with better LLMs ("it wrote a nicer email"), intent-based architectures will scale exponentially ("woah, I didn't have to change it cause it read our slack and saw that we changed the marketing copy on the website and now it's just doing the right thing"). | 14 | 0 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.920Z |  | 2025-02-27T18:51:29.179Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7300556985626681345 | Text |  |  | Had an insightful conversation with Maxime Corbani about open source and AI. He introduced me to Twenty, an open source CRM.

Looking at Twenty got me thinking about the evolution of business software: CRMs were once custom-built for each business until standardization emerged.

Today everyone's trying to build their own AI coordination layers, but soon this will consolidate into a few patterns:

- Open communication protocols
- Standard authentication and consent patterns
- Shared security models

Unlike CRMs though, these AI systems are going to need to work together across different businesses. When your AI agent needs to collaborate with a customer's or partner's system, it's going to suck to be in a closed ecosystem.

Anthropic's Model Context Protocol is a good first step - the first snowflake in what I suspect will be a three-day blizzard of consensus building and standardization that will ultimately yield a cohesive infrastructure layer. | 7 | 1 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.920Z |  | 2025-02-26T16:47:03.163Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7300265543238864897 | Text |  |  | Hands-on testing with Claude 3.7 on our dev environment at Tiptree Systems revealed some interesting limitations. E.g., the non-thinking model really does not like to be told to think. 

Hybrid reasoning models are cool, and dynamic test-time compute is here to stay, but I'm looking forward to a world with cleaner APIs and prompt caching. Until then, gotta keep thinking

 "content": [
 {
 "type": "thinking",
 "thinking": "To approach this, let's think about what we know about prime numbers...",
 },
 {
 "type": "text",
 "text": "Yes, there are infinitely many prime numbers such that..."
 }
 ] | 13 | 0 | 0 | 9mo | Post | Martin Weiss | https://www.linkedin.com/in/martin-clyde-weiss | https://linkedin.com/in/martin-clyde-weiss | 2025-12-08T04:46:11.920Z |  | 2025-02-25T21:28:57.883Z |  |  | 

---



---

# Martin Weiss
*Tiptree Systems*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Martin Weiss - Tiptree Systems | LinkedIn](https://ca.linkedin.com/in/martin-clyde-weiss)
*2025-04-07*
- Category: article

### [Tiptree Systems | LinkedIn](https://ca.linkedin.com/company/tiptree-systems)
*2025-04-02*
- Category: article

### [Martin Weiss – Medium](https://medium.com/@salesweiss?source=post_internal_links---------2----------------------------)
*2023-03-16*
- Category: blog

### [How can treasurers keep up with the industry changes – interview with TIS and TIPCO](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco)
*2024-12-02*
- Category: article

### [Tiptree Systems | The Org](https://theorg.com/org/tiptree-systems)
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*8 articles scraped, 20,438 words total*

### Martin Weiss - Tiptree Systems | LinkedIn
*7,642 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/martin-clyde-weiss)

Martin Weiss - Tiptree Systems | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/martin-clyde-weiss#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-lawrenceville-ga?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fmartin-clyde-weiss&fromSignIn=true&trk=public_profile_nav-header-signin)[Join for free](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=martin-clyde-weiss&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fmartin-clyde-weiss&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fmartin-clyde-weiss&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/D4E16AQG2w55d7PZlOQ/profile-displaybackgroundimage-shrink_200_800/B4EZVjEGUXHMAU-/0/1741123775069?e=2147483647&v=beta&t=dXgL7g4ZYdfReFIrCDa1GYhJbUgrjInQAASQFn7Lyf4)

![Image 3: Martin Weiss](https://media.licdn.com/dms/image/v2/D4E03AQF8Pp21X2mViA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1678399114587?e=2147483647&v=beta&t=TqMIMEuROYqS34scnun5Y7jsPKzAg9TJD00wvEIrBYI)

![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQF8Pp21X2mViA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1678399114587?e=2147483647&v=beta&t=TqMIMEuROYqS34scnun5Y7jsPKzAg9TJD00wvEIrBYI)
Sign in to view Martin’s full profile
-------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=martin-clyde-weiss&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=martin-clyde-weiss&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Martin Weiss
============

![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQF8Pp21X2mViA/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1678399114587?e=2147483647&v=beta&t=TqMIMEuROYqS34scnun5Y7jsPKzAg9TJD00wvEIrBYI)
Sign in to view Martin’s full profile
-------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=martin-clyde-weiss&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_join-link)

or

New

*[... truncated, 74,134 more characters]*

---

### Tiptree Systems | LinkedIn
*1,789 words* | Source: **EXA** | [Link](https://ca.linkedin.com/company/tiptree-systems)

Tiptree Systems | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/company/tiptree-systems#main-content)[LinkedIn](https://ca.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Ftiptree-systems&fromSignIn=true&trk=organization_guest_nav-header-signin)[Create an account](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Ftiptree-systems&trk=organization_guest_nav-header-join)

![Image 1: Tiptree Systems’ cover photo](https://media.licdn.com/dms/image/v2/D4E3DAQHZaLOEmNRigA/image-scale_191_1128/B4EZUk8uvNHUAc-/0/1740081655321/tiptree_systems_cover?e=2147483647&v=beta&t=N4IBtEINr9nq5rnJvjjt6u0qzF5GPV9kSZ28PzM6iFk)

![Image 2: Tiptree Systems](https://media.licdn.com/dms/image/v2/D4E0BAQGSRBr9pzZrAw/company-logo_200_200/company-logo_200_200/0/1687537872778?e=2147483647&v=beta&t=nQijkT_Dl8sMYpk14YBCG4FjISysAj4C3XIqkkJWpDs)

Tiptree Systems
===============

Information Services
--------------------

### Montreal, QC  258 followers

#### Althea is thinking...

[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Ftiptree-systems&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://media.licdn.com/dms/image/v2/D4E03AQF8Pp21X2mViA/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1678399114587?e=2147483647&v=beta&t=UYBX4IffnsddvgiuiqmaIEIHt5OjnJuM_Oz2mOTOm0M)![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQHy_ocWH82vWA/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1692915028168?e=2147483647&v=beta&t=mGQEEiCulrqspZTqlfMbMItsuN_UaRevY7g563Dp-a4) View all 3 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B98108409%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Ftiptree-systems&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

Tiptree Systems (tiptreesystems.com) is building AI-powered knowledge routers that ensure the right knowledge finds the right person at the right time. As organizations scale, their information systems break down - researchers waste weeks on solved problems, miss critical collaborations, and duplicate expensive work. Our AI assistant analyzes real-time work patterns across SMS, email, WhatsApp and web to understand who knows what, then proactively connects people who should be collaborating. We're starting with AI research institutions where this problem is most acute.

 Website [tiptreesystems.com](https://www.linkedin.com/redir/redirect?url=http%3A%2F%2Ftiptreesystems%2Ecom&urlhash=n_GX&trk=about_website)
External link for Tiptree Systems

 Industry  Information Services 

 Company size  2-10 employees 

 Headquarters  Montreal, QC 

 Type  Privately Held 

Locations
---------

*    Primary Montreal, QC, CA [Get directions](https://www.bing.com/maps?where=Montreal+QC+CA&trk=org-locations_url)

Employees at Tiptree Systems
----------------------------

*   [![Image 5: Click here to view Martin Weiss’ profile](https://ca.linkedin.com/company/tiptree-systems)### Martin Weiss](https://ca.linkedin.com/in/martin-clyde-weiss?trk=org-employees)
*   [![Image 6: Click here to view Nasim Rahaman’s profile](https://ca.linkedin.com/company/tiptree-systems)### Nasim Rahaman](https://de.linkedin.com/in/nasim-rahaman?trk=org-employees)

[See all employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B98108409%255D&trk=public_biz_employees-join)

Updates
-------

*   
[](https://www.linkedin.com/posts/tiptree-systems_multi-agent-systems-scientific-discovery-activity-7399958792039464962-CYmO)

[![Image 7: View organization page for Tiptree Systems](https://ca.linkedin.com/company/tiptree-systems)](https://ca.linkedin.com/company/tiptree-systems?trk=organization_guest_main-feed-card_feed-actor-image)[Tiptree Systems](https://ca.linkedin.com/company/tiptree-systems?trk=organization_guest_main-feed-card_feed-actor-name) 
258 followers

 1w    

    *   [Report this post](https

*[... truncated, 37,453 more characters]*

---

### Martin Weiss – Medium
*377 words* | Source: **EXA** | [Link](https://medium.com/@salesweiss?source=post_internal_links---------2----------------------------)

Martin Weiss – Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2F%40salesweiss&%7Efeature=LoOpenInAppButton&%7Echannel=ShowUser&%7Estage=mobileNavBar&source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=---two_column_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---two_column_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

![Image 2](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

![Image 3: Martin Weiss](https://miro.medium.com/v2/resize:fill:96:96/0*4eyzSVkH1uWeCjCa.jpg)

Martin Weiss

[2 followers](https://medium.com/@salesweiss/followers?source=user_profile_page----------------------58403e5292d----------------------)

Follow

[Home](https://medium.com/@salesweiss?source=user_profile_page----------------------58403e5292d----------------------)

[About](https://medium.com/@salesweiss/about?source=user_profile_page----------------------58403e5292d----------------------)

[Email Critique #1 -----------------](https://medium.com/@salesweiss/email-critique-1-af7ca232bb3c?source=user_profile_page---------0-------------58403e5292d----------------------)

Mar 16, 2023

[](https://medium.com/@salesweiss/email-critique-1-af7ca232bb3c?source=user_profile_page---------0-------------58403e5292d----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Faf7ca232bb3c&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss%2Femail-critique-1-af7ca232bb3c&source=---------0-------------58403e5292d----bookmark_preview------------------)

Mar 16, 2023

[](https://medium.com/@salesweiss/email-critique-1-af7ca232bb3c?source=user_profile_page---------0-------------58403e5292d----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Faf7ca232bb3c&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss%2Femail-critique-1-af7ca232bb3c&source=---------0-------------58403e5292d----bookmark_preview------------------)

[Outbound Lead Generation 2022: we booked 728 meetings for our clients ---------------------------------------------------------------------](https://medium.com/@salesweiss/outbound-lead-generation-2022-we-booked-728-meetings-for-our-clients-afa4ef4d752b?source=user_profile_page---------1-------------58403e5292d----------------------)

Jan 1, 2023

[](https://medium.com/@salesweiss/outbound-lead-generation-2022-we-booked-728-meetings-for-our-clients-afa4ef4d752b?source=user_profile_page---------1-------------58403e5292d----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fafa4ef4d752b&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss%2Foutbound-lead-generation-2022-we-booked-728-meetings-for-our-clients-afa4ef4d752b&source=---------1-------------58403e5292d----bookmark_preview------------------)

![Image 4: Outbound Lead Generation 2022: we booked 728 meetings for our clients](https://miro.medium.com/v2/resize:fill:160:106/0*xvGryA2JvWl_XH3e.png)

![Image 5: Outbound Lead Generation 2022: we booked 728 meetings for our clients](https://miro.medium.com/v2/resize:fill:320:214/0*xvGryA2JvWl_XH3e.png)

Jan 1, 2023

[](https://medium.com/@salesweiss/outbound-lead-generation-2022-we-booked-728-meetings-for-our-clients-afa4ef4d752b?source=user_profile_page---------1-------------58403e5292d----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fafa4ef4d752b&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40salesweiss%2Foutbound-lead-generation-2022-we-booked-728-meetings-for-our-clients-afa4ef4d752b&source=---------1-------------58403e5292d----bookmark_preview------------------)

[2022: All BizXpand Campaign Metrics -----------------------------------](https://medium.com/@salesweiss/2022-all-bizxpand-campaign-metrics-3a4cd7b60936?source=user_profile_page---------2-------------58403e5292d----------------------)

Jan 1, 2023

[](https://medium.com/@salesweiss/2022-all-bizxpand-campaign-metrics-3a4cd7b60936?source=user_profile_page---------2-------------58403e5292d----------------------)

[](https://medium.com/m/sig

*[... truncated, 13,094 more characters]*

---

### How can treasurers keep up with the industry changes – interview with TIS and TIPCO
*9,215 words* | Source: **EXA** | [Link](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco)

How can treasurers keep up with the industry changes – interview with TIS and TIPCO

===============

![Image 5: logo](blob:http://localhost/4eb6460ab93a7ae1978320dda45af1eb)

[](https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/)

*   [Consent](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)
*   [Details](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)
*   [[#IABV2SETTINGS#]](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)
*   [About](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)

Welcome to The Paypers: Insights at the Forefront of Fintech & Payments

At The Paypers, we're dedicated to bringing you the latest in payments, fintech, and the digital economy. Our focus? Providing you with valuable insights and news that keep you ahead of the curve.

****Why Cookies?****

They're essential for us to tailor our content specifically to your interests, ensuring you receive relevant updates and a smooth browsing experience. While we use cookies to personalize content and our own ads, your privacy remains our priority.

****Your Options:****

*   Allow All Cookies: Enjoy a customized experience with content curated just for you.
*   Customize Settings: Control how we use cookies to better suit your preferences.

Your consent allows us to offer you the most relevant insights and news. You can change your preferences anytime, keeping your experience aligned with your interests.

****Dive into the world of The Paypers, where every piece of information is a step ahead.****

Consent Selection

**Necessary** 

- [x] 

**Preferences** 

- [x] 

**Statistics** 

- [x] 

**Marketing** 

- [x] 

[Show details](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)

Details

*   
Necessary  6- [x]   Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies. 

    *   [Cookiebot 1](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)[Learn more about this provider![Image 6](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.cookiebot.com/goto/privacy-policy/ "Cookiebot's privacy policy")**CookieConsent**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 1 year**Type**: HTTP Cookie   
    *   [Google 2](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)[Learn more about this provider![Image 7](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://business.safety.google/privacy/ "Google's privacy policy")Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.

**rc::e**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Session**Type**: HTML Local Storage  **rc::h**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Persistent**Type**: HTML Local Storage   
    *   [LinkedIn 2](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)[Learn more about this provider![Image 8](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.linkedin.com/legal/privacy-policy "LinkedIn's privacy policy")**bcookie**Used in order to detect spam and improve the website's security. **Maximum Storage Duration**: 1 year**Type**: HTTP Cookie  **li_gc**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [thepaypers.com 1](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)**SESS#**Preserves users states across page requests.**Maximum Storage Duration**: Session**Type**: HTTP Cookie   

*   
Preferences  3- [x]   Preference cookies enable a website to remember information that changes the way the website behaves or looks, like your preferred language or the region that you are in. Preference cookies include using Google Ad Services (Google AdSense / Syndication / DoubleClick) to serve The Paypers partners' banners. No data is shared with external partners, and the Google Ad Services platform is only used to serve banners of The Paypers partners. 

    *   [Google 3](https://thepaypers.com/fintech/interviews/how-can-treasurers-keep-up-with-the-industry-changes-interview-with-tis-and-tipco#)[Learn more about this provider![Image 9](blob:htt

*[... truncated, 118,639 more characters]*

---

### Tiptree Systems | The Org
*329 words* | Source: **EXA** | [Link](https://theorg.com/org/tiptree-systems)

Tiptree Systems | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

This is an unverified company page

![Image 1: Tiptree Systems logo](https://cdn.theorg.com/feee8284-4929-4550-8fee-e9ca99de3274_thumb.jpg)

Tiptree Systems
===============

[1 person](https://theorg.com/people/search)·[0 jobs](https://theorg.com/jobs)

Follow

Tiptree is building AI-powered knowledge routers that ensure the right knowledge finds the right person at the right time. As organizations scale, their information systems break down - researchers waste weeks on solved problems, miss critical collaborations, and duplicate expensive work. Our AI ass... Read more

Industries

[AI/ML,](https://theorg.com/explore/industries/ai-ml)[Enterprise Software](https://theorg.com/explore/industries/enterprise-software)+1

Employees

[1-10](https://theorg.com/explore/employee-ranges/1-10)

Links

[](https://linkedin.com/company/tiptree-systems "View on linkedIn")[](http://tiptreesystems.com/ "View the website")

Org chart

Teams

Offices

* * *

Org chart
---------

Full screen

[MW](https://theorg.com/org/tiptree-systems/org-chart/martin-weiss "View Martin Weiss on The Org")

[Martin Weiss](https://theorg.com/org/tiptree-systems/org-chart/martin-weiss "View Martin Weiss on The Org")

Co-founder & CEO

0

MW

Martin Weiss

Collapse

No reports!

* * *

Teams
-----

View all (0)

This company has no teams yet

* * *

Offices
-------

View all (0)

This company has no offices yet

Similar companies
-----------------

[![Image 2: Harvey logo](https://cdn.theorg.com/9272e0b2-4c15-4794-9fe5-7e289e0c68fb_thumb.jpg) Harvey 17 followers](https://theorg.com/org/harvey-ai)[![Image 3: Exa (prev. Metaphor) logo](https://cdn.theorg.com/2a0c03a3-610b-4f85-adfa-127076c9ccb8_thumb.jpg) Exa (prev. Metaphor) 3 followers](https://theorg.com/org/exa-prev-metaphor)[![Image 4: Bland AI logo](https://cdn.theorg.com/eb9f3655-a024-4d54-a028-337b508d2aef_thumb.jpg) Bland AI 2 followers](https://theorg.com/org/bland-ai)[![Image 5: Together AI logo](https://cdn.theorg.com/5a2d169f-9f73-413a-ac22-7efa84926bae_thumb.jpg) Together AI 11 followers](https://theorg.com/org/together-ai)[![Image 6: OpenText logo](https://cdn.theorg.com/d513d47a-ffe2-4436-b849-70da2afdcb7d_thumb.jpg) OpenText 150 followers](https://theorg.com/org/opentext)[![Image 7: Intel logo](https://cdn.theorg.com/9877c999-8391-4264-83e3-0fbaee939469_thumb.jpg) Intel 951 followers](https://theorg.com/org/intel)[![Image 8: OpenAI logo](https://cdn.theorg.com/8c196111-c56d-4f9d-82d1-672e155311be_thumb.jpg) OpenAI 711 followers](https://theorg.com/org/openai)[![Image 9: Atlassian logo](https://cdn.theorg.com/d327b9d7-8468-4c11-a28c-5ba9aa8cd07c_thumb.jpg) Atlassian 533 followers](https://theorg.com/org/atlassian)[![Image 10: TNO logo](https://cdn.theorg.com/c27f648c-7ab0-4ae1-b201-ddbb6555a783_thumb.jpg) TNO 22 followers](https://theorg.com/org/tno)[![Image 11: Laivly logo](https://cdn.theorg.com/3464686a-9b95-4c9d-b0f0-af30b7d45b69_thumb.jpg) Laivly 2 followers](https://theorg.com/org/laivly)[![Image 12: CloudFactory logo](https://cdn.theorg.com/7edd7bc6-4b4c-42bb-8c19-5a35bde45e31_thumb.jpg) CloudFactory 15 followers](https://theorg.com/org/cloudfactory-limited)[Explore companies](https://theorg.com/explore)

Transparency starts here

Join the world's biggest network of public org charts

[Sign up](https://theorg.com/signup)[Log in](https://theorg.com/login)

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

![Image 13: Cookiebot session tracker icon loaded](https://imgsct.cookiebot.com/1.gif?dgi=46b327ce-c3bf-4c3a-94d7-32411fa4e7b8)

---

### PowerPoint-Präsentation
*394 words* | Source: **GOOGLE** | [Link](https://www.summerschool.bmw/content/dam/grpw/websites/summerschool_bmw/2023_Draft_Schedule_BMW_Summer_School-_v2.pdf)

BMW Summer School. | EURECOM/BMW/BayFrance/Tum | 2023 

INTELLIGENT CARS ON DIGITAL ROADS. FRONTIERS IN MACHINE INTELLIGENCE .

Highlight Topic: Trust and Safety for Intelligent Algorithms 

• Functional Safety and Artificial Intelligence 

• Advanced user experience and user interaction 

• User acceptance and trust in autonomous systems 

• Ethics of intelligent automation, Future of Work, UN SDG 

• Latest trends: Generative AI, Quantum Machine Learning, 6G 

9 th French-German Summer School. 

Sofia Antipolis, France – Jul 03 -Jul 08, 2023. 

Check for updates: http://summerschool.bmw 

# 2023 BMW SUMMER SCHOOL. 

> Seite 1

BMW Summer School. | EURECOM/BMW/BayFrance/Tum | 2023  Seite 2 

2023 BMW SUMMER SCHOOL. DRAFT SCHEDULE. 

Monday  Tuesday  Wednesday  Thursday  Friday  Saturday 

09:00 

10:00 

11:00 

12:00 

13:00 

14:00 

15:00 

16:00 

17:00 

18:00 

19:00 

20:00 

Welcome Address Speaker: Prof. David Gesbert (EURECOM) 

Poster Pitches 

Coffee Break 

Cocktail Reception & Dinner 

Lunch 

Dinner 

Midweek Social Event 

Fireside Chat 

Speaker: Dr. Peter Lehnert (BMW) & Dr. Corina Apachite (Continental) 

Business & Regulation 

Speaker: 

Dr. Florian Dötzer (TUM Venture Labs) 

Prof. Jean-François Bruneau (IVADO) 

Martin Weiss (Tiptree Systems) 

Keynote AI in Industry Speaker: Dr. Peter Lehnert (BMW) 

Quantum Computing 

(Quantum ML, Quantum Generative Design, …) 

Speaker: 

Prof. Hao Wand (Leiden University) Tbc: Prof. Vedran Dunjko (Leiden University) 

Tbc: Christian Sarra-Bournet (IQ, Sherbrooke) 

Tbc: Prof. Alexandre Blais (Sherbrooke) 

Dinner 

Social Break 

Morning Coffee 

DRAFT PROGRAMME. 

• Keynote/breakout track – Learning from invited speakers presenting their views and/or research. 

• Poster track – presentation & discussion of conference submissions. 

• Lean startup machine – develop innovative ideas in a competitive startup pitching format. 

Apero Poster Fair 

Lean Startup Machine: Final Pitches, Awards 

Closure, Farewell 

Dinner 

Safe AI Research 

Speaker: 

Prof. Foutse Khomh (IVADO) 

Morning Coffee 

Lunch  Lunch 

AI in Mobility & Services 

Speaker: 

Dr. Corina Apachite (Continental) 

Cornelia Schaurecker (Vodafone) 

Prof. Nick Dutt (UC Irvine) 

Opportunities in AI 

Speaker: 

Yann-Seing Law-Kam Cio (Designbot.tech) 

Serena Striegel (BMW) 

tbc: Markus Schmitz (Aleph Alpha) 

Lunch 

Lean Startup Machine 

Dinner 

Breakout Workshop 

Speaker: 

Topcis and speakers to be announced 

Apero Poster Fair 

Morning Coffee 

The future is bright, isn‘t it? Speaker: 

Tbc: Theo Priestley 

Lunch 

Apero Poster Fair: 

Coffee Break 

Lean Startup Machine 

Speaker / Coach: 

n.n. (EURECOM Startup Studio) n.n. (EURECOM EDHEC Incubator) 

Business Model Canvas 

Ideation 

Design Thinking 

Speaker: 

n.n. (EURECOM Startup Studio) BMW Summer School. | EURECOM/BMW/BayFrance/Tum | 2023  Seite 3 

2023 BMW SUMMER SCHOOL. INVITED SPEAKERS. 

Confirmed Inquired / Pending

---

### Tiptree Advanced Systems Corporation
*452 words* | Source: **GOOGLE** | [Link](https://tiptreesystems.com/about)

Meet the Team
-------------

![Image 1: Martin Weiss, PhD](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/martin.3435af51.jpg)

### Martin Weiss, PhD

Serial entrepreneur and AI researcher. Early employee at YesGraph (acquired by Lyft) and IVADO Postdoctoral Entrepeneur Fellow.

![Image 2: Nasim Rahaman, PhD](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/nasim.45003e72.jpg)

### Nasim Rahaman, PhD

Background in theoretical physics and machine learning, with experiences at Facebook AI Research and AWS Science.

![Image 3: Victoria Feere](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/victoria.01e7c034.jpeg)

### Victoria Feere

Ex-Shopify Sr. Staff Engineer, early-stage startup veteran with hands-on experience scaling two companies through funding and exit, 10+ years infrastructure expertise.

Our Advisors
------------

Guiding our vision with decades of expertise in AI, entrepreneurship, and innovation

![Image 4: Dr. Manuel Wüthrich](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/manuel_wuthrich.dbf7d7b8.jpg)

### Dr. Manuel Wüthrich

Midjourney Collective intelligence researcher. Former Harvard SEAS researcher and collaborator on our COLM 2024 Information Markets paper.

![Image 5: Dr. Sherjil Ozair](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/sherjil_ozair.b66529cd.jpeg)

### Dr. Sherjil Ozair

Founder of General Agents. Former staff research scientist at Tesla and senior research scientist at DeepMind.

![Image 6: Dr. Hugo Larochelle](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/hugo_larochelle.feb860f9.jpeg)

### Dr. Hugo Larochelle

Mila Scientific Director, an ex-DeepMind Principal Scientist.

![Image 7: Dino Di Palma](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/dino_dipalma.72107659.jpeg)

### Dino Di Palma

COO of Acme Packet (exited to Oracle for $2.2B). Former CEO of Emissary expert network.

![Image 8: Dr. Chris Pal](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/chris_pal.8ee997c6.jpeg)

### Dr. Chris Pal

Canada CIFAR AI Chair, professor at Polytechnique Montréal, and Distinguished Scientist at ServiceNow Research.

![Image 9: Dr. Tegan Maharaj](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/tegan_maharaj.966d3d4d.jpeg)

### Dr. Tegan Maharaj

Assistant professor at Mila working on AI alignment and safety. Board member and early supporter.

![Image 10: Dr. Erran Li](https://d2prbapnmi2ezb.cloudfront.net/public/assets/images/erran_li.bd746273.jpeg)

### Dr. Erran Li

Research scientist at AWS AI and adjunct professor at Columbia. Long-time thought partner and sounding board.

Our Story
---------

Nasim and Martin met in 2020 at Mila, one of the world's premier AI research institutes, working on decentralized network of message-passing AI agents to trace COVID-19 contacts with [Yoshua Bengio](https://en.wikipedia.org/wiki/Yoshua_Bengio).

As the technology matured, we continued conducting research and publishing papers. As we neared graduation, we realized that we could build a company that would enable the next generation of AI researchers to collaborate, learn, and solve complex problems together, using AI agents.

Our Core Values
---------------

### Open Technology

Building resilient, transparent, and accessible AI infrastructure for a more collaborative future.

### Research-Driven

Advancing AI through rigorous scientific inquiry and continuous innovation at the cutting edge.

### Empowered Agents

Creating powerful tools and frameworks that enable AI agents to learn, adapt, and collaborate effectively.

Join Our Mission
----------------

We have active research and development programs in the following areas:

*   Decentralized AI agent protocols
*   AI agents for scientific research
*   Forecasting based on deliberative multi-agent interactions
*   Building more robust and reliable AI agents

We are always looking for new collaborators, interns, and partners. If you are interested in working with us, please contact us.

---

### Martin Weiss - Co-founder & CEO at Tiptree Systems | The Org
*240 words* | Source: **GOOGLE** | [Link](https://theorg.com/org/tiptree-systems/org-chart/martin-weiss)

Martin Weiss - Co-founder & CEO at Tiptree Systems | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

*   [![Image 1: Tiptree Systems logo](https://cdn.theorg.com/feee8284-4929-4550-8fee-e9ca99de3274_thumb.jpg) Tiptree Systems](https://theorg.com/org/tiptree-systems)
*   Martin Weiss

Unverified

MW

Martin Weiss
============

### Co-founder & CEO

Contact

No bio yet

* * *

Org chart
---------

MW

Martin Weiss

Co-founder & CEO

No direct reports

* * *

Teams
-----

This person is not in any teams

* * *

Offices
-------

This person is not in any offices

* * *

Related people
--------------

*   [![Image 2: David Connors' profile picture](https://cdn.theorg.com/44cdcc69-7d5b-4699-92c0-bfa95e32154d_thumb.jpg) ![Image 3: Company logo](https://cdn.theorg.com/1129c42d-dd0c-4a40-8814-0ff48b80bce4_thumb.jpg) ### David Connors The Swarm](https://theorg.com/org/the-swarm/org-chart/david-connors) 
*   [![Image 4: Michael Brizendine's profile picture](https://cdn.theorg.com/cb60a7c2-9de4-40cf-a6ad-322ebd81b46f_thumb.jpg) ![Image 5: Company logo](https://cdn.theorg.com/442b29e5-2e3e-4728-9e47-39cf1db3e2ec_thumb.jpg) ### Michael Brizendine Scoop](https://theorg.com/org/scoop-chat/org-chart/michael-brizendine) 
*   [![Image 6: Janusz Dutkowski's profile picture](https://cdn.theorg.com/ba350fd4-1394-4ea5-9fe2-afeafb2a0148_thumb.jpg) ![Image 7: Company logo](https://cdn.theorg.com/e2d0b375-00f1-40ee-9b5d-4fd5689fa639_thumb.jpg) ### Janusz Dutkowski Data4Cure](https://theorg.com/org/data4cure/org-chart/janusz-dutkowski) 
*   [![Image 8: Kota Kubo's profile picture](https://cdn.theorg.com/ef4c8682-57ae-493e-aeaa-a23c708f77ec_thumb.jpg) ![Image 9: Company logo](https://cdn.theorg.com/a76e9624-5eaf-4dae-9a8d-970e3b2ea517_thumb.jpg) ### Kota Kubo Ubie](https://theorg.com/org/ubie/org-chart/kota-kubo) 
*   [![Image 10: Tavo Zambrano's profile picture](https://cdn.theorg.com/1ca6c21f-2ab7-4b40-af84-73297a011468_thumb.jpg) ![Image 11: Company logo](https://cdn.theorg.com/5f80c19a-e561-49e6-b2b0-110e37f15ee9_thumb.jpg) ### Tavo Zambrano Skydropx](https://theorg.com/org/skydropx/org-chart/tavo-zambrano) 

View more

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[2023 BMW SUMMER SCHOOL.](https://www.summerschool.bmw/content/dam/grpw/websites/summerschool_bmw/2023_Draft_Schedule_BMW_Summer_School-_v2.pdf)**
  - Source: summerschool.bmw
  - *Jul 8, 2023 ... Martin Weiss (Tiptree Systems). Keynote AI in Industry. Speaker: Dr. Peter Lehnert (BMW). Quantum Computing. (Quantum ML, Quantum. Gen...*

- **[Martin Weiss, PhD](https://tiptreesystems.com/about)**
  - Source: tiptreesystems.com
  - *Tiptree Logo Tiptree Systems Tiptree Advanced Systems Corporation. About Us ... Martin Weiss, PhD. Serial entrepreneur and AI researcher. Early employ...*

- **[Martin Weiss - Co-founder & CEO at Tiptree Systems | The Org](https://theorg.com/org/tiptree-systems/org-chart/martin-weiss)**
  - Source: theorg.com
  - *View Martin Weiss at Tiptree Systems on The Org. ... AboutContactBlog. Product. LearnExploreIterate. Business. SolutionsTrustPricing. Enrich. Browser ...*

---

*Generated by Founder Scraper*
