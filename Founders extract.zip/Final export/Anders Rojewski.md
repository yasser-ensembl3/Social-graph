# Anders Rojewski

## Position actuelle

**Titre** : Co-Founder & Head of Product
**Entreprise** : Neatro
**Durée dans le rôle** : 5 years 6 months in role
**Durée dans l'entreprise** : 5 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Whether we call them "hybrid" or "virtual", teams need to improve to maintain a competitive advantage and create a healthy and fun working atmosphere. 

Neatro helps modern teams continuously improve through the best possible online retrospective experience.

Thousands of distributed teams trust Neatro all over the world, one retro at a time! 🔥

Want to know more about Neatro?
👉 https://www.neatro.io
👉 poke me on LinkedIn :)

## Résumé

Hello and welcome to my LinkedIn profile! 👋 I'm Anders, but please, call me Andy.

I am interested in entrepreneurship, Agility, continuous improvement, management and development of technological products, and digital marketing.

Otherwise, I spend most of my time making Neatro grow.
Neatro is an online retrospective tool designed for remote teams looking to improve continuously. We help thousands of distributed Agile teams to experience playful, intuitive, and rewarding retrospectives.

Besides, don't hesitate to try Neatro with your team and share your feedback with me. It would be super handy to us, and I'm sure your team will like it :)

👉 https://www.neatro.io

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAQgnngBkgfcSdsXo_UYcsiCcvCEb1Sr4Ms/
**Connexions partagées** : 80


---

# Anders Rojewski

## Position actuelle

**Entreprise** : Neatro

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Anders Rojewski

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7371977027652005888 | Article |  |  | 🚨 ALERTE WEBINAIRE 🚨

Vous aimeriez explorer le potentiel des rétrospectives d’équipe, mais vous ne savez pas par où commencer ?

HOP HOP HOP je vous arrête ici tout de suite, et je vous ordonne de rejoindre ce webinaire gratuit et de qualité !

"Introduction à la Rétrospective : vers des équipes plus alignées et performantes".
Tel est son nom.

Sylvain Bonneville (Coach Agile chevronné) et moi-même. 
Tel est son duo d'animateurs.

​Dans une ambiance conviviale, nous allons partager :
​- les bases simples et efficaces de la rétrospective,
​- des conseils pratiques et des retours d’expérience concrets,
- ​une démonstration en conditions réelles de l’outil Neatro,
​- et bien sûr, un temps dédié pour répondre à toutes vos questions.
​
À la fin du webinaire, non seulement la pratique de la rétrospective n’aura plus de secret pour vous, mais vous serez aussi prêt·e à animer gratuitement vos premières rétrospectives avec votre équipe grâce à Neatro.

Jeudi 18 septembre. 
12h (heure de Montréal) // 18h (heure de Paris).

Inscription gratuite et ouverte à toutes et à tous.
Juste ici : https://luma.com/frvbia69 | 31 | 11 | 4 | 2mo | Pierre-Luc Thivierge reposted this | Anders Rojewski | https://www.linkedin.com/in/andersrojewski | https://linkedin.com/in/pierrelucthivierge | 2025-12-08T05:23:27.329Z |  | 2025-09-11T18:44:48.102Z | https://luma.com/frvbia69 |  | 

---



---

# Anders Rojewski
*Neatro*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Anders Rojewski Email | Co-Founder of Neatro 👉 neatro.io](https://www.success.ai/profile/anders-rojewski-894967485)
*2020-06-01*
- Category: article

### [Neatro - 2025 Company Profile - Tracxn](https://tracxn.com/d/companies/neatro/__Zx5Aaaxt37vg1I5x9KAD5VKvOZmElOaAV3Z6rpwmvpE)
*2025-04-05*
- Category: article

### [Introduction to the Agile Retrospective: the Why, the What, and the How](https://www.neatro.io/blog/agile-retrospective/)
*2024-09-18*
- Category: blog

### [Groupthink kills your retrospectives!](https://www.neatro.io/blog/groupthink-retrospective/)
*2023-03-28*
- Category: blog

### [What's the Role of the Manager in Sprint Retrospectives?](https://www.neatro.io/blog/retrospective-manager/)
*2022-06-21*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Que des numéros 10 Agile | #11 - Anders Rojewski |](https://podcast.ausha.co/que-des-numeros-10-agile/11-l-amelioration-continue-pour-batir-une-equipe-performante-avec-anders-rojewski)**
  - Source: podcast.ausha.co
  - *Oct 30, 2023 ... ... Anders Rojewski ICI (https://www.linkedin.com/in/andersrojewski/) (sur LinkedIn)Site : https://www.neatro ... podcast/que-des-num...*

- **[Code Café et Agilité | Podcast on Spotify](https://open.spotify.com/show/1KXChe2b3SDRejuMeByUUq)**
  - Source: open.spotify.com
  - *... podcast « Change & Chill » et créateur du programme « Nature Change ... Anders Rojewski, co-fondateur de Neatro. Jun 27. 31 min ......*

- **[120 Questions to Improve your Sprint Retrospectives](https://www.neatro.io/blog/sprint-retrospective-questions/)**
  - Source: neatro.io
  - *Mar 30, 2023 ... 120 Powerful Questions to ask in Sprint Retrospectives. Anders Rojewski's picture. By Anders Rojewski ... At Neatro, we've been craft...*

- **[Neatroverse | Neatro](https://www.neatro.io/neatroverse/)**
  - Source: neatro.io
  - *Explore the retrospective templates shared by the Neatro community then join our users by sharing your own templates....*

- **[6 tips to help introverts talk in your retrospectives](https://www.neatro.io/blog/retrospective-introverts/)**
  - Source: neatro.io
  - *Sep 12, 2022 ... 6 tips to boost participation from introverts in Retrospectives. Anders Rojewski's picture. By Anders Rojewski ... How Neatro increas...*

- **[How long should a Sprint Retrospective last?](https://www.neatro.io/blog/retrospective-length/)**
  - Source: neatro.io
  - *Mar 21, 2023 ... As co-founder of the online retrospective tool Neatro, I often talk with Scrum Masters, Agile Coaches, or simply team members who hav...*

- **[Demo | Neatro](https://www.neatro.io/demo/)**
  - Source: neatro.io
  - *Two simple ways to discover Neatro: an interactive retrospective demo with the bots or a call with Andy, Neatro's co ... Anders Rojewski's picture. Sc...*

- **[A guide to Agile retrospective: Drop Add Keep Improve (DAKI) | Neatro](https://medium.com/neatro/a-guide-to-agile-retrospective-drop-add-keep-improve-daki-13615b42f871)**
  - Source: medium.com
  - *Mar 3, 2020 ... Neatro. ·. Follow publication. Neatro. Talking about Agile retrospectives and ... Anders Rojewski · La Rétrospective Agile “pour les n...*

- **[The Sailboat: Break your team's fatigue of Agile retrospectives with ...](https://medium.com/neatro/break-your-teams-fatigue-of-agile-retrospectives-with-the-sailboat-activity-5645e2420073)**
  - Source: medium.com
  - *Mar 16, 2020 ... I hope this article helped you perform the Sailboat retrospective. You can find this retrospective template on Neatro. Give it a try,...*

- **[7 conseils pour réussir vos rétrospectives en télétravail - Myagile ...](https://blog.myagilepartner.fr/index.php/2021/04/16/7-conseils-pour-reussir-vos-retrospectives-en-teletravail/)**
  - Source: blog.myagilepartner.fr
  - *7 conseils pour réussir vos rétrospectives en télétravail. 16/04/ ... N'hésitez pas à faire un tour sur notre article consacré à Neatro. Les tableaux ...*

---

*Generated by Founder Scraper*
