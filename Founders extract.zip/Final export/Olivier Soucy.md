# Olivier Soucy

## Position actuelle

**Titre** : Founder
**Entreprise** : Okube
**Durée dans le rôle** : 2 years 4 months in role
**Durée dans l'entreprise** : 2 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Data Infrastructure and Analytics

## Description du rôle

Founder and Principal Data Engineer of Okube, a business building open source data and ML engineering frameworks and offering consulting / contracting services. Okube is an official Databricks Partner.

- Designed, implemented and owned Laktory (www.laktory.ai), a DataOps framework for building Lakehouses. It makes it possible to express and bring to life your data vision, from raw data to enriched analytics-ready datasets and finely tuned AI models, while adhering to basic DevOps best practices such as source control, code reviews and CI/CD.

- Led Okube's consulting and contracting services, delivering high-quality and reliable solutions that significantly benefited clients such as Taiga Motors and CAE, enhancing their operational efficiency and driving innovation.

- Created content for the data community with blogs posts, demos and tutorials.

## Résumé

Highly skilled big data expert, specialized in building large-scale data platforms and delivering value. Leader of multiple cost and time saving innovations for pilot evaluation and flight simulation. Passionate, ambitious and not afraid of thinking outside of the box.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAQmjQkBMj1llrrOehO0yRexOEocFstSsCY/
**Connexions partagées** : 7


---

# Olivier Soucy

## Position actuelle

**Entreprise** : Okube

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Olivier Soucy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402723440316534784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH0UpgF1l0IIw/feedshare-shrink_800/B4EZrX_va8GYAg-/0/1764560404604?e=1766620800&v=beta&t=96Iib-QRv5HnPdYhyq_O5_zm2gL9bLrltPNYK_079N4 | 🐍 Dask – Performing Advanced Aggregations with groupby + agg ⚡📊
Dask extends pandas’ API to the cluster — meaning you can run complex aggregations on datasets that don’t fit in memory, all with familiar syntax. Perfect for rollups, metrics, and distributed analytics. 🚀

💡 Example
See code snippet below

🔗 Why this is powerful:
- Scales pandas-style analytics to massive datasets
- Runs aggregations in parallel across partitions
- Supports complex metrics & multi-aggregation patterns
- Works great with Parquet + partition pruning

💡 Pro Tip: Call .persist() on the input DataFrame before running multiple aggregations to avoid recomputation across tasks.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 12 | 0 | 0 | 2d | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:49.507Z |  | 2025-12-05T15:00:04.122Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401998681484234753 | Text |  |  | 🪶 Ibis – Streaming Live Data Transformations with Ibis + Kafka ⚡📡
Yes — you can use Ibis for real-time pipelines.
Instead of writing SQL by hand or juggling Python parsing logic, Ibis lets you apply declarative transformations to Kafka streams, then push the transformed data to any backend you want.

💡 Example
See code snippet below.

🔗 Why this is powerful:
- Use pure Python/Ibis expressions instead of inline SQL or UDF chaos
- Ibis transformations are portable across pandas, DuckDB, BigQuery, Snowflake
- Perfect for real-time ETL, stream cleanup, and event enrichment
- Kafka ingestion + Ibis logic = lightweight streaming pipeline without Spark/Flink

💡 Pro Tip: Swap the pandas backend for DuckDB to batch-transform micro-batches at lightning speed before loading into a warehouse.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 4 | 3 | 0 | 4d | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:49.508Z |  | 2025-12-03T15:00:08.151Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401273945187909633 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFviMgdb_Cj2A/feedshare-shrink_800/B4EZrX9JJ.HoAk-/0/1764559723635?e=1766620800&v=beta&t=jkvraBzA6Qcj8czzuWths1xob6aLJiYdjTd8hyB_j98 | 🐍 Dask - Processing nested Parquet files with Dask DataFrame
Working with partitioned / nested Parquet layouts (e.g. year=2024/month=01/day=01)? Dask can read the whole dataset as a single DataFrame and push filters down to partitions efficiently. 🚀

💡 Example:
See code snippet below.

🔗 Why this is great:
- Automatically discovers partition columns from folder names (year=..., month=...)
- Uses predicate pushdown → only reads relevant Parquet files
- Works seamlessly with S3/ADLS/GCS paths and huge datasets

💡 Pro Tip: Add columns=[...] and filters=[("year", "=", 2024)] in read_parquet to aggressively prune data before it even reaches the cluster.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 2 | 0 | 0 | 6d | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:49.508Z |  | 2025-12-01T15:00:17.553Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7400186756131737600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGi_zqvDrJc6Q/feedshare-shrink_800/B4EZqz4eXlIIAg-/0/1763954519417?e=1766620800&v=beta&t=mqADK3rQnM2uWPvBBg7z9-NAB1Q_XBwOuChLDV3pngM | LinkedIn Post
⚡ Spark – Monitoring Memory Usage with DAG Scheduler Insights & the Spark UI 
If your Spark jobs are dying with OOMs, spending ages in GC, or constantly restarting tasks, the DAG Scheduler and Spark UI are your best debugging allies. They won’t fix memory for you—but they show exactly where you’re in trouble. 

💡 Quick code hook to inspect memory from Spark
See code snippet

💡 What to look at in the Spark UI (driven by the DAG Scheduler):
- Stages tab
-   Stages with very long task times → likely spilling / GC pressure
-   Repeated task retries / failures → potential OOM or memory skew
- Tasks view (inside a stage)
-    Columns like GC Time, Input Size / Spill → memory stress signals
- Storage & Executors tabs
-  How much data is cached vs available memory
-  Executors running near 100% memory or heavy spilling
💡 Pro Tips:
- If you see a single task much slower than others in a stage → data skew + memory hot-spot.
- If many tasks show high GC Time or spill metrics → too many / too large shuffles or oversized partitions.
- Combine this with AQE, smarter partitioning, and selective caching (only hot DataFrames) to keep memory under control.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 5 | 0 | 0 | 1w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:49.509Z |  | 2025-11-28T15:00:11.483Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396940327464644609 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFAW5IeOzchfA/feedshare-shrink_800/B4EZqOl.xeGoAg-/0/1763328914393?e=1766620800&v=beta&t=oRVO43IhE09ajBtWgo8_jqNaALtrQQ4B_GYGRatPBOA | ❄️ Polars – Dynamic Column Renaming & Reordering Using Expressions 🔄
When your dataset has dozens (or hundreds!) of columns, renaming or reordering them manually is painful.
Polars solves this with expressions — letting you transform column names programmatically and rearrange them with ease. ⚡

💡 Example:
See code snippet below.

📌 Why this is powerful:
- Rename based on patterns or functions (e.g., prefix/suffix/date logic)
- Reorder using wildcards or regex
- Works seamlessly with LazyFrame for pipeline optimization

⚡ Pro Tip: Use with_columns + .alias() to build renaming logic directly inside a transformation pipeline — perfect for large ETL jobs.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 6 | 0 | 0 | 2w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.703Z |  | 2025-11-19T16:00:02.573Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396200453098721280 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkEoivVOBiag/feedshare-shrink_800/B4EZqOlp9uIUAg-/0/1763328829123?e=1766620800&v=beta&t=xtoSEXAUPwhRhoSr_8xA1F3r8rz2wvajpL1P4fFrKhk | ❄️ Polars – Handling Categorical Data with the Categorical Type
Working with string-heavy columns that repeat often (like country names, product codes, or categories)? Convert them to Categorical in Polars — it drastically reduces memory use and speeds up operations like joins and group-bys. ⚡

💡 Example:
See code snippet below.

📊 Why it’s awesome:
- Stores string values as integer codes under the hood
- Reduces memory footprint and improves join/groupby performance
- Perfect for high-cardinality categorical columns

⚡ Pro Tip: You can persist categories across DataFrames using pl.Categorical(remapping=True) — ideal for consistent encoding between training and inference datasets.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 3 | 0 | 0 | 2w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.704Z |  | 2025-11-17T15:00:02.778Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7395113313967169537 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFA39YrF8vDog/feedshare-shrink_800/B4EZpqJgRRKkAg-/0/1762717469952?e=1766620800&v=beta&t=aR7E4VC97GXEL-KvBBalmxkwb1yCXWFTxipGQS-GVyo | 🐼 Pandas – Working with JSON Columns Efficiently Using json_normalize 🧩
Have JSON objects nested inside your DataFrame columns? Instead of writing loops or custom parsing, let pandas do the heavy lifting with json_normalize — a fast, elegant way to flatten JSON data into tabular form. 🚀

💡 Example:
See code snippet below.

📊 Why it’s great:
- Automatically flattens nested dictionaries/lists
- Preserves clear column naming (skills.python)
- Works perfectly for API responses, logs, or nested NoSQL exports

⚡ Pro Tip: Use record_path and meta parameters for even deeper nesting — ideal for JSONs with lists inside lists.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 0 | 0 | 0 | 3w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.706Z |  | 2025-11-14T15:00:08.611Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394388599091408896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHSw7mGOl-z5g/feedshare-shrink_800/B4EZpqJVfFKoAg-/0/1762717425929?e=1766620800&v=beta&t=BL30O_nOSSD_4RURfUYkjLv98I1HOahTZplGviPb1E4 | 🐼 Pandas – Efficient Data Normalization Using StandardScaler ⚖️
Need to standardize your numerical columns (mean = 0, std = 1)?
You don’t need to leave pandas for scikit-learn — just use StandardScaler directly with DataFrame operations. 🚀

💡 Example:
See code snippet below

📌 Why it’s great:
- Works seamlessly inside pandas pipelines
- Keeps column names and DataFrame structure
- Perfect for ML preprocessing and feature engineering

⚡ Pro Tip: Wrap this in a function or pipeline step to normalize only numeric columns automatically using df.select_dtypes("number").

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 1 | 0 | 0 | 3w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.708Z |  | 2025-11-12T15:00:23.120Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7393663763620499456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHagM9XaxvtbQ/feedshare-shrink_800/B4EZpqJIYHKgAg-/0/1762717372171?e=1766620800&v=beta&t=pQe7XohcpPoRj57TpzSEjvDNDYGSrD1WgYWqQuukwY0 | 🐼 Pandas – Speeding Up Filtering with Boolean Indexing over apply ⚡
Still filtering rows with .apply() and custom lambdas? That’s slow. Real slow. 😅
When possible, switch to boolean indexing — it’s vectorized, faster, and cleaner.

💡 Example:
See code below

📌 Why it’s better:
- Vectorized operations in C → much faster than Python loops
- Cleaner syntax & easier to read
- Scales beautifully on large DataFrames

⚡ Pro Tip: Combine multiple conditions using & (AND), | (OR), and ~ (NOT) — just remember to wrap each condition in parentheses.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 2 | 0 | 0 | 3w | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.708Z |  | 2025-11-10T15:00:08.877Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7392576645901012992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGtSek3GXmtYA/feedshare-shrink_800/B4EZpGK4NGIIAk-/0/1762113849963?e=1766620800&v=beta&t=2vF_CG4uLnHVHj_xiesjL_LqnXw4YCQ9x7LDDVf7wZo | 🪶 Ibis – Chaining Expressions for Clean & Modular Transformations 🧩
Tired of messy SQL or long, unreadable transformation scripts? With Ibis, you can chain expressions just like you do in pandas or Polars — making complex transformations modular, testable, and composable. 🚀

💡 Example
See code snippet below

📌 Why this rocks:
- Each step is declarative and composable (no SQL strings!).
- Easier to debug and unit test parts of your pipeline.
- Works across multiple backends — BigQuery, DuckDB, Snowflake, and more.

⚡ Pro Tip: You can modularize reusable transformations as Python functions returning Ibis expressions — perfect for shared analytics logic across teams.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 1 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.709Z |  | 2025-11-07T15:00:19.815Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7391851857381433344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG037H1ffljBw/feedshare-shrink_800/B4EZpGKsArHoAk-/0/1762113800041?e=1766620800&v=beta&t=uQfNapdRkyc9en0bM7G_3wVDK9yDBAgN4-jTW65y8II | 🐍 Dask – Building Distributed ETL Pipelines with Dask + Prefect ⚙️☁️
Need to orchestrate massive ETL pipelines across clusters without breaking the bank? Combine Dask’s parallel DataFrame engine with Prefect’s orchestration to scale Python-based data pipelines—cleanly and reliably. 🚀

💡 Example:
See code snippet below

📌 Why it’s powerful:
- Dask = distributed DataFrame engine (parallel processing on your laptop or cluster).
- Prefect = modern workflow orchestrator with retries, caching, and monitoring.
- Together = clean, scalable, fault-tolerant Python-native ETL.

⚡ Pro Tip: Prefect can dynamically scale Dask workers with adaptive clusters — perfect for cloud-based workflows.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 8 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.711Z |  | 2025-11-05T15:00:16.766Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7391127132367695873 | Text |  |  | 🪶 Ibis – Using Ibis with BigQuery for Serverless Data Exploration ☁️
Tired of writing endless SQL queries in the BigQuery console? With Ibis, you can explore data interactively in Python — while BigQuery does the heavy lifting behind the scenes. 💪

💡 Example:
See code snippet below.

📌 Why it’s awesome:
- Write Pythonic expressions, not SQL strings
- All computation runs serverlessly on BigQuery
- Perfect for exploratory analysis, dashboards, and ML feature prep

⚡ Pro Tip: You can reuse the same Ibis code with other backends (like DuckDB or Snowflake) — no query rewrite needed.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 1 | 3 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.711Z |  | 2025-11-03T15:00:28.858Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7391127056702398464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQExT2-JEkvhGg/feedshare-shrink_800/B4EZpGIqZEGUAo-/0/1762113269576?e=1766620800&v=beta&t=U__vhLDDiVwaMGL8OZcRQz9Wsw23iC0mbhOmgK7CQt0 | 🪶 Ibis – Using Ibis with BigQuery for Serverless Data Exploration ☁️
Tired of writing endless SQL queries in the BigQuery console? With Ibis, you can explore data interactively in Python — while BigQuery does the heavy lifting behind the scenes. 💪

💡 Example:
See code snippet below.

📌 Why it’s awesome:
- Write Pythonic expressions, not SQL strings
- All computation runs serverlessly on BigQuery
- Perfect for exploratory analysis, dashboards, and ML feature prep

⚡ Pro Tip: You can reuse the same Ibis code with other backends (like DuckDB or Snowflake) — no query rewrite needed.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 3 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.712Z |  | 2025-11-03T15:00:10.818Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7391127023080972288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHjzPsMBKfrag/feedshare-shrink_800/B4EZpGKdjCIIAg-/0/1762113740870?e=1766620800&v=beta&t=E7CEJHAByyp5mrXTUMiXD7xzch13kJ0Rh5nOOooS18s | 🪶 Ibis – Using Ibis with BigQuery for Serverless Data Exploration ☁️
Tired of writing endless SQL queries in the BigQuery console? With Ibis, you can explore data interactively in Python — while BigQuery does the heavy lifting behind the scenes. 💪

💡 Example:
See code snippet below.

📌 Why it’s awesome:
- Write Pythonic expressions, not SQL strings
- All computation runs serverlessly on BigQuery
- Perfect for exploratory analysis, dashboards, and ML feature prep

⚡ Pro Tip: You can reuse the same Ibis code with other backends (like DuckDB or Snowflake) — no query rewrite needed.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 1 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.712Z |  | 2025-11-03T15:00:02.802Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7390024771574378496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGe7d3JCyExHA/feedshare-shrink_800/B4EZodxn6.KgAg-/0/1761436141798?e=1766620800&v=beta&t=oopkqOZ81-6Ma6SvlSvE85rD53_r6oVPBCjHp3MyD0k | ⚡ Spark – Advanced Sorting with repartition + sortWithinPartitions 🔀
Sorting massive datasets in Spark isn’t as simple as orderBy. Full dataset sorts = expensive shuffles that slow everything down. Instead, you can combine partitioning + local sorting for efficiency. 🚀

💡 Example:
See code snippet below.

📌 Why this works:
- repartition groups related rows together (fewer shuffle headaches).
- sortWithinPartitions orders data locally, without requiring a full global sort.
Together, they make downstream range queries, joins, and aggregations much faster.

⚠️ Pro Tip: Choose partition keys that align with your query patterns (e.g., country, date). Bad keys = skew and wasted compute.
Efficient sorting in Spark = fewer shuffles, faster pipelines, and happier clusters. 💡

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 3 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.714Z |  | 2025-10-31T14:00:05.564Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7389299990931664897 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFmDFeVudVKrQ/feedshare-shrink_800/B4EZodxbQTGcAk-/0/1761436089660?e=1766620800&v=beta&t=2t_mMq4uuh6Sf4P4s9nYLSwphxcdIkKTWQJ0v-2hniY | ⚡ Spark – Using Isolation Levels for Transactional Writes 🔒
When multiple jobs write to the same dataset, you risk dirty reads, lost updates, or inconsistent snapshots. Spark (with Delta Lake) supports ACID transactions, and you can control consistency with isolation levels.

💡 Two main isolation levels:
Snapshot isolation (default) → Readers see a consistent snapshot while writers safely commit in parallel.
Serializable isolation → Stronger guarantees, but higher overhead. Ensures transactions behave as if executed sequentially.

💡 Example with Delta Lake:
See code snippet below.

📌 Why it matters:
- Prevents race conditions in concurrent pipelines
- Protects critical tables (e.g., financial, inventory, logs)
- Lets you balance between speed (snapshot) and safety (serializable)
Isolation levels = production-grade data reliability. Don’t ship Spark jobs without them. 🚀

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 2 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.714Z |  | 2025-10-29T14:00:04.393Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7388575272012398592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH6s9XOMfz5xw/feedshare-shrink_800/B4EZodxMVTIMAg-/0/1761436028254?e=1766620800&v=beta&t=THYPKdC9cKSEZRg_xHWj8HgvmAI_zE_7QfYJGp9LSZk | ⚡ Spark – Avoiding Wide Transformations with Pre-Partitioned Data 🧩
Ever notice Spark jobs struggling when you perform wide transformations (like groupBy or joins across many columns)? These trigger full shuffles, which are expensive and slow.
A better approach: pre-partition your data so Spark can minimize shuffling and keep execution local whenever possible. 🚀

💡 Example:
See code snippet below.

📌 Why it helps:
- Reduces shuffle cost by colocating related rows
- Keeps partitions balanced for parallelism
- Great for workloads with repeated groupBy/join patterns

⚠️ Pro Tip: Choose partition keys wisely. Too many partitions = overhead, too few = skew. Aim for a sweet spot based on data distribution.

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 6 | 2 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.716Z |  | 2025-10-27T14:00:17.938Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7387488187033739264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGA3AmepUlQOg/feedshare-shrink_800/B4EZn.2dKWGUAg-/0/1760917314264?e=1766620800&v=beta&t=6_VA0pzevab10UYEC_uOnuvPW_9h-4uagrahB70rcrc | ❄️ Polars – Optimizing Column Selection with Wildcard Expressions 🎯
Tired of manually typing column names? With Polars, you can use wildcard expressions to select or transform groups of columns at once. Super handy when working with wide datasets! ⚡

💡 Example:
See code snippet below.

📌 Why it’s awesome:
- Use patterns (*) to select related columns.
- Avoids repetitive code in wide tables.
- Works seamlessly with expressions for aggregations & transformations.
- Perfect when your datasets have systematic column naming like years, regions, or categories. 🚀

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 3 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.717Z |  | 2025-10-24T14:00:36.682Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7386763389823508480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZf4VUDmc_DA/feedshare-shrink_800/B4EZn.1Xa5KYAg-/0/1760917028554?e=1766620800&v=beta&t=bafLE99w4VXkxkS3goNQ9xzCV675IyYvR1TRK-57ImE | ❄️ Polars – Performing In-Place Updates with replace and set ✍️
Need to update values in a DataFrame? With Polars, you don’t mutate rows directly—you create expressions that cleanly and efficiently replace or set values. 🚀

💡 Example:
See code snippet below.

📌 Key Takeaways:
- .replace() → map values to new ones (like a dictionary).
when / then / otherwise → flexible conditional updates.
- Operations are lazy + expression-based, so they scale seamlessly.
- Instead of modifying rows imperatively (like in pandas), Polars embraces -functional, parallel-safe transformations—perfect for big data. ⚡

🔹 Follow me for daily DataFrame manipulation tips and other great data engineering content! | 3 | 0 | 0 | 1mo | Post | Olivier Soucy | https://www.linkedin.com/in/olisoucy | https://linkedin.com/in/olisoucy | 2025-12-08T04:49:53.718Z |  | 2025-10-22T14:00:31.561Z |  |  | 

---



---

# Olivier Soucy
*Okube*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Blog - oKube](https://okube-attribution.com/en/blog-2/)
*2023-06-18*
- Category: blog

### [Building a Data Pipeline with Polars and Laktory — okube](https://www.okube.ai/blog/building-a-data-pipeline-with-polars-and-laktory)
*2024-11-23*
- Category: blog

### [The Business of Open Source podcast: From open source to enterprise, Alex Olivier on Cerbos' evolution](https://cerbos.dev/news/the-business-of-open-source-podcast-from-open-source-to-enterprise-alex-olivier-on-cerbos-evolution)
*2024-04-14*
- Category: podcast

### [Getting Your Pricing Model Right-ish with Alex Olivier  | Emily Omier](https://www.emilyomier.com/podcast/getting-your-pricing-model-right-ish-with-alex-olivier)
*2024-04-10*
- Category: podcast

### [HBI News Archive - Harvard Brain Science Initiative](https://brain.harvard.edu/hbi-news?type=topic&slug=cellular-and-molecular-neuroscience)
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 23,968 words total*

### Blog - oKube
*533 words* | Source: **EXA** | [Link](https://okube-attribution.com/en/blog-2/)

Blog - oKube

===============
[Skip to content](https://okube-attribution.com/en/blog-2/#content "Skip to content")

[EN](https://okube-attribution.com/en/blog-2/)

*   [FR](https://okube-attribution.com/)
*   [ES](https://okube-attribution.com/es/blog/)

[![Image 3](https://okube-attribution.com/wp-content/uploads/2020/05/oKube-logo-black.png)](https://okube-attribution.com/en/)

*   [Technos](https://okube-attribution.com/en/technos/)
*   [Blog](https://okube-attribution.com/en/blog-2/)
*   [Resources](https://okube-attribution.com/en/resources/)
    *   [Customer case studies](https://okube-attribution.com/en/resources/#customer-case-studies)
    *   [White papers](https://okube-attribution.com/en/resources/#white-papers)

*   [Technos](https://okube-attribution.com/en/technos/)
*   [Blog](https://okube-attribution.com/en/blog-2/)
*   [Resources](https://okube-attribution.com/en/resources/)
    *   [Customer case studies](https://okube-attribution.com/en/resources/#customer-case-studies)
    *   [White papers](https://okube-attribution.com/en/resources/#white-papers)

[Request a demo](https://okube-attribution.com/en/contact/)

[![Image 4](https://okube-attribution.com/wp-content/uploads/2020/05/oKube-menu-icon.png)](https://okube-attribution.com/en/blog-2/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjMwNSIsInRvZ2dsZSI6ZmFsc2V9)

[EN](https://okube-attribution.com/en/blog-2/)

*   [FR](https://okube-attribution.com/)
*   [ES](https://okube-attribution.com/es/blog/)

[![Image 5](https://okube-attribution.com/wp-content/uploads/2020/05/oKube-logo-black.png)](https://okube-attribution.com/en/)

*   [Technos](https://okube-attribution.com/en/technos/)
*   [Blog](https://okube-attribution.com/en/blog-2/)
*   [Resources](https://okube-attribution.com/en/resources/)
    *   [Customer case studies](https://okube-attribution.com/en/resources/#customer-case-studies)
    *   [White papers](https://okube-attribution.com/en/resources/#white-papers)

*   [Technos](https://okube-attribution.com/en/technos/)
*   [Blog](https://okube-attribution.com/en/blog-2/)
*   [Resources](https://okube-attribution.com/en/resources/)
    *   [Customer case studies](https://okube-attribution.com/en/resources/#customer-case-studies)
    *   [White papers](https://okube-attribution.com/en/resources/#white-papers)

[Request a demo](https://okube-attribution.com/en/contact/)

[![Image 6](https://okube-attribution.com/wp-content/uploads/2020/05/oKube-menu-icon.png)](https://okube-attribution.com/en/blog-2/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjMwNSIsInRvZ2dsZSI6ZmFsc2V9)

oKube news
==========

[Twitter](https://twitter.com/okube_st)[Linkedin-in](https://www.linkedin.com/company/okube-attribution/)

Here are the latest oKube News. Don’t forget to follow oKube on social medias !

BLOG
----

Coming soon...
--------------

oKube latest news
=================

[Visit our blog](https://okube-attribution.com/en/blog/)

NEWS
----

![Image 7: logo_FW](https://okube-attribution.com/wp-content/uploads/2020/05/logo_FW-300x300.jpg)

![Image 8: téléchargement](https://okube-attribution.com/wp-content/uploads/2020/05/te%CC%81le%CC%81chargement-300x97.jpeg)

![Image 9: Logo_French_Tech](https://okube-attribution.com/wp-content/uploads/2020/05/Logo_French_Tech-300x227.jpg)

![Image 10: Logo-jei-300x300](https://okube-attribution.com/wp-content/uploads/2020/05/Logo-jei-300x300-1-300x300.jpg)

![Image 11: top_5](https://okube-attribution.com/wp-content/uploads/2020/05/top_5-300x103.png)

![Image 12: Alliance-Entreprendre-logo-220](https://okube-attribution.com/wp-content/uploads/2020/05/Alliance-Entreprendre-logo-220.png)

![Image 13: logo_FW](https://okube-attribution.com/wp-content/uploads/2020/05/logo_FW-300x300.jpg)

![Image 14: téléchargement](https://okube-attribution.com/wp-content/uploads/2020/05/te%CC%81le%CC%81chargement-300x97.jpeg)

![Image 15: Logo_French_Tech](https://okube-attribution.com/wp-content/uploads/2020/05/Logo_French_Tech-300x227.jpg)

![Image 16: Logo-jei-300x300](https://okube-attribution.com/wp-content/uploads/2020/05/Logo-jei-300x300-1-300x300.jpg)

![Image 17: top_5](https://okube-attribution.com/wp-content/uploads/2020/05/top_5-300x103.png)

![Image 18: Alliance-Entreprendre-logo-220](https://okube-attribution.com/wp-content/uploads/2020/05/Alliance-Entreprendre-logo-220.png)

![Image 19: logo_FW](https://okube-attribution.com/wp-content/uploads/2020/05/logo_FW-300x300.jpg)

![Image 20: téléchargement](https://okube-attribution.com/wp-content/uploads/2020/05/te%CC%81le%CC%81chargement-300x97.jpeg)

![Image 21: Logo_French_Tech](https://okube-attribution.com/wp-content/uploads/2020/05/Logo_French_Tech-300x227.jpg)

![Image 22: Logo-jei-300x300](https://okube-attribution.com/wp-content/uploads/2020/05/Logo-jei-300x300-1-300x300.jpg)

Book a demo
-----------

[Schedule a demo](https://okube-attribution.com/en/contact/)

![Image 23](https://okube-attribution.com/wp-content/uploads

*[... truncated, 3,623 more characters]*

---

### Building a Data Pipeline with Polars and Laktory — okube
*197 words* | Source: **EXA** | [Link](https://www.okube.ai/blog/building-a-data-pipeline-with-polars-and-laktory)

Building a Data Pipeline with Polars and Laktory — okube

===============

[0](https://www.okube.ai/cart)

[Skip to Content](https://www.okube.ai/blog/building-a-data-pipeline-with-polars-and-laktory#page)

[![Image 1: okube](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/930a4a6a-06b6-4215-9dfa-64b7f9d3124a/okube_logotype_wcolor.png?format=1500w)](https://www.okube.ai/)

[kubes](https://www.okube.ai/kubes)

[services](https://www.okube.ai/services)

[blog](https://www.okube.ai/blog)

[partners](https://www.okube.ai/partners)

[about](https://www.okube.ai/about)

[contact](https://www.okube.ai/contact)

[](https://www.linkedin.com/company/okube-ai)[](https://www.youtube.com/@okube-ai)[](https://www.instagram.com/okube.ai/)[](http://okube.slack.com/)

Open Menu Close Menu

[![Image 2: okube](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/930a4a6a-06b6-4215-9dfa-64b7f9d3124a/okube_logotype_wcolor.png?format=1500w)](https://www.okube.ai/)

[kubes](https://www.okube.ai/kubes)

[services](https://www.okube.ai/services)

[blog](https://www.okube.ai/blog)

[partners](https://www.okube.ai/partners)

[about](https://www.okube.ai/about)

[contact](https://www.okube.ai/contact)

[](https://www.linkedin.com/company/okube-ai)[](https://www.youtube.com/@okube-ai)[](https://www.instagram.com/okube.ai/)[](http://okube.slack.com/)

Open Menu Close Menu

[kubes](https://www.okube.ai/kubes)

[services](https://www.okube.ai/services)

[blog](https://www.okube.ai/blog)

[partners](https://www.okube.ai/partners)

[about](https://www.okube.ai/about)

[contact](https://www.okube.ai/contact)

[](https://www.linkedin.com/company/okube-ai)

[](https://www.youtube.com/@okube-ai)

[](https://www.instagram.com/okube.ai/)

[](http://okube.slack.com/)

Building a Data Pipeline with Polars and Laktory
================================================

Jul 8

Written By [Olivier Soucy](https://www.okube.ai/blog?author=65cd9af38a71e5742a98fdfa)

When discussing data pipelines, distributed engines like Spark and big data platforms such as Databricks and Snowflake immediately come to mind. However, not every problem requires these super powers. Many businesses default to these large-scale solutions, but they can be overkill for the data sizes at hand. Additionally, those still learning the basics of data engineering and data modeling need access to simple and cost-effective setups to master their craft. That's why today we'll explore how to leverage Polars dataframes and the Laktory ETL framework to build an end-to-end data pipeline that can be executed on your local machine.

[Read More](https://www.linkedin.com/pulse/building-data-pipeline-polars-laktory-olivier-soucy-rrjce/)

[![Image 3](https://images.squarespace-cdn.com/content/v2/namespaces/memberAccountAvatars/libraries/65cd9af38a71e5742a98fdfa/22003836-68f6-4c92-ae25-0482642245fd/thirdPartyMemberAvatar-65cd9af38a71e5742a98fdfa-ee231269-daf4-4b30-b8d4-0e1712f640e7?format=300w&format=100w)Olivier Soucy](https://www.okube.ai/blog?author=65cd9af38a71e5742a98fdfa)

[Previous Previous Databricks AI Playground | How to bring your own model ------------------------------------------------------](https://www.okube.ai/blog/databricks-ai-playground-how-to-bring-your-own-model)[Next Next Laktory Introduction --------------------](https://www.okube.ai/blog/laktory-introduction)

Copyright © 2023-2024. Okube® is a registered trademark.

---

### The Business of Open Source podcast: From open source to enterprise, Alex Olivier on Cerbos' evolution
*5,644 words* | Source: **EXA** | [Link](https://cerbos.dev/news/the-business-of-open-source-podcast-from-open-source-to-enterprise-alex-olivier-on-cerbos-evolution)

In a recent episode of "[The Business of Open Source](https://www.emilyomier.com/podcast/getting-your-pricing-model-right-ish-with-alex-olivier)" podcast, hosted by Emily Omier, Alex Olivier, Co-Founder and CPO of Cerbos, shared insights into the nuances of open-source business models and Cerbos' journey in refining its pricing strategy. Check out the full discussion, rich with real-world challenges and strategic thinking from a software engineering perspective, below.

Or read on for the main takeaways of the episode, as well as the transcript.

The evolution of Cerbos' pricing model
--------------------------------------

Alex discussed the evolution of Cerbos' pricing framework, emphasizing the transition from an [open-source](https://www.cerbos.dev/product-cerbos-pdp) project to a [commercial](https://www.cerbos.dev/product-cerbos-hub) product. He highlighted the importance of choosing a [pricing](https://www.cerbos.dev/pricing) metric that resonates with both the company and its customers. Cerbos opted for a model based on "monthly active principles," a more encompassing metric than just active users, which accounts for all unique identities interacting with the system, be they human or machine.

Addressing market needs through open core strategy
--------------------------------------------------

Cerbos operates on an open core business model, which offers core functionalities for free while charging for advanced features. Alex detailed how Cerbos initially open-sourced its authorization solution, providing basic services without charge, and how customer feedback led to the development of enhanced, paid features designed to support large-scale, enterprise needs such as [audit logs](https://www.cerbos.dev/features-benefits-and-use-cases/audit-logs) and enhanced security.

Customer-centric approach to product development
------------------------------------------------

A significant portion of the podcast was dedicated to how Cerbos listens to its customers to shape its offerings. Alex shared anecdotes about discussions with enterprise users that directly influenced the additional features in the commercial layer of Cerbos. This approach not only aligns product development with actual market demands but also ensures that Cerbos remains a customer-first company.

The challenges of pricing in the open source ecosystem
------------------------------------------------------

Alex discussed the intrinsic challenges of pricing within the open-source ecosystem, where perceptions about cost versus value can significantly vary. He revealed how Cerbos navigated these challenges by focusing on value provision rather than just cost recuperation, aiming to make the pricing predictable and transparent to eliminate customer surprises and hesitance.

Conclusion
----------

The podcast episode with Alex Olivier offers invaluable insights into the strategic thinking behind Cerbos' approach to open source and commercial product development. For anyone involved in SaaS, open-source projects, or product management, this discussion sheds light on balancing community-driven products with commercial viability.

To learn about how Cerbos empowers developers to implement, manage, and delegate fine-grained access control in software applications, in a fraction of the time spent building and maintaining it in-house, [click here.](https://www.cerbos.dev/product-cerbos-hub)

Transcript
----------

Emily: Welcome to the business of open source. I am Emily Omier, your host. And today I am chatting with Alex Olivier, who is the co founder and CPO at Cerbos. We are recording on site in Paris at KubeCon EU. And today we're going to have a really sort of in depth discussion that's about the process Cerbos went through after launching their commercial product to get pricing.

Maybe not like perfect, maybe not. I'm not even sure if we can say right, but hopefully like more right. But before I really dive into that discussion, Alex, can you introduce yourself for people who don't know you and also introduce Cerbos a little bit?

Alex: Absolutely. Thank you for having me. Yes, I'm Alex Olivier.I work on Cerbos and I am, at heart, a software engineer that turned into the OXIDA product. And now we have built launch servers to ultimately solve us a pain. We had many, many times in previous businesses around authorization. So anyone that's building a SaaS business, of which I'm sure many of you are, you have to worry about kind of user roles and permissions.

And this is something that's very simple to start with. You might just have, you know, employees or regular users, and your checks are pretty simple. But as your business grows, particularly if you start signing bigger clients, enterprise deals, these sort of things, you end up having to implement much more fine grained permissions and access controls that not only are manageable and scalable, but also auditable as you start going for compliance and these sort of things.

So Cerbos is a sol

*[... truncated, 27,167 more characters]*

---

### Getting Your Pricing Model Right-ish with Alex Olivier  | Emily Omier
*345 words* | Source: **EXA** | [Link](https://www.emilyomier.com/podcast/getting-your-pricing-model-right-ish-with-alex-olivier)

Getting Your Pricing Model Right-ish with Alex Olivier | Emily Omier

===============

[![Image 1: Emily Omier Consulting](https://images.squarespace-cdn.com/content/v1/5fc555ef5720c63c9f70c2fd/1606853669471-2P2GOOGYK3JRYVX1D3FF/eoc-logo-dual-light-bg.png)](https://www.emilyomier.com/)

[](https://www.emilyomier.com/search)

[Speaking](https://www.emilyomier.com/speaking)Resources[Podcast](https://www.emilyomier.com/podcast)[Positioning FOSS](https://www.emilyomier.com/free-e-book)[Blog](https://www.emilyomier.com/blog)[About](https://www.emilyomier.com/about-2)[Work with Me](https://www.emilyomier.com/work-with-me)

Back[Entrepreneurship for Engineers @ TNS](https://www.emilyomier.com/writing)[eBook: Positioning for FOSS](https://www.emilyomier.com/free-e-book)

[Speaking](https://www.emilyomier.com/speaking)[Resources](https://www.emilyomier.com/resources)[Entrepreneurship for Engineers @ TNS](https://www.emilyomier.com/writing)[eBook: Positioning for FOSS](https://www.emilyomier.com/free-e-book)[Podcast](https://www.emilyomier.com/podcast)[Positioning FOSS](https://www.emilyomier.com/free-e-book)[Blog](https://www.emilyomier.com/blog)[About](https://www.emilyomier.com/about-2)

[![Image 2: Emily Omier Consulting](https://images.squarespace-cdn.com/content/v1/5fc555ef5720c63c9f70c2fd/1606853669471-2P2GOOGYK3JRYVX1D3FF/eoc-logo-dual-light-bg.png)](https://www.emilyomier.com/)

[Work with Me](https://www.emilyomier.com/work-with-me)

Getting Your Pricing Model Right-ish with Alex Olivier
======================================================

In the second episode that I recorded on-site at KubeCon EU in Paris, I spoke with [Alex Olivier](https://www.linkedin.com/in/alexolivier/), CPO and co-founder of [Cerbos](https://www.cerbos.dev/). This was not a general discussion: It was focused on the process that Cerbos went through to figure out pricing.

Here’s what we talked about:

*   The first step of figuring out your pricing is not the number, but rather what you’re charging for. Is it API calls, or amount of data you’re processing, or monthly active users, or monthly active principles… that last one is what Cerbos is charging for

*   Why it’s important to have a pricing system that allows potential users to be able to roughly estimate for themselves how much using your software is going to cost them

*   You also want to avoid pricing models that encourage people to look for ways to hack around to find ways to lower their monthly costs

*   Why your pricing model should be about the value you’re providing, not about how much it costs you to run your system

*   Discovering what your price anchors are / what your customers are comparing you to

Check out the full episode for more details!

And join us at [Open Source Founders Summit](https://05f5.com/)for more discussions about the specifics of pricing for open source companies.

[Emily Omier](https://www.emilyomier.com/podcast?author=5fc69a7fe00c5e6b91662b72)April 10, 2024

[Facebook 0](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.emilyomier.com%2Fpodcast%2Fgetting-your-pricing-model-right-ish-with-alex-olivier)[Twitter](https://twitter.com/intent/tweet?url=https%3A%2F%2Fwww.emilyomier.com%2Fpodcast%2Fgetting-your-pricing-model-right-ish-with-alex-olivier&text=)[Pinterest 0](https://www.pinterest.com/pin/create/link/?description=&media=https://images.squarespace-cdn.com/content/v1/5fc555ef5720c63c9f70c2fd/1712604025729-UHVBTXYXHE1V4WO6SYIG/image-asset.jpeg&url=https%3A%2F%2Fwww.emilyomier.com%2Fpodcast%2Fgetting-your-pricing-model-right-ish-with-alex-olivier)[0 Likes](https://www.emilyomier.com/podcast/getting-your-pricing-model-right-ish-with-alex-olivier#)

[Previous #### Taking a hard look at what community means and if every OSS company needs one with Deepak Prabhakara Emily Omier April 17, 2024](https://www.emilyomier.com/podcast/taking-a-hard-look-at-what-community-means-and-if-every-oss-company-needs-one-with-deepak-prabhakara)[Next #### Nailing Customer Acquisition with Patrick Backman of MariaDB and OpenOcean VC Emily Omier April 3, 2024](https://www.emilyomier.com/podcast/nailing-customer-acquisition-with-patrick-backman-of-mariadb-and-openocean-vc)

Free eBook Download: Positioning Free Open Source Software
----------------------------------------------------------

[Download Now ↓](https://www.emilyomier.com/s/Positioning-Free-Open-Source-Software-Emily-Omier.pdf)

© 2024 Emily Omier Consulting. All rights reserved. Site by [Knapsack](https://knapsackcreative.com/).

---

### HBI News Archive - Harvard Brain Science Initiative
*15,148 words* | Source: **EXA** | [Link](https://brain.harvard.edu/hbi-news?type=topic&slug=cellular-and-molecular-neuroscience)

[HOME](https://brain.harvard.edu/) / [NEURO TOPICS](https://brain.harvard.edu/neurotopics/) / Cellular and Molecular Neuroscience
Neuro Topics - Cellular and Molecular Neuroscience

SEARCH OTHER RESEARCH AREAS

[![Image 1: Catherine Dulac, Vikrant Kapoor, and Adam Nelson](https://brain.harvard.edu/wp-content/uploads/2025_dulac-cell_hex.jpg)](https://brain.harvard.edu/hbi_news/neural-circuit-and-molecular-mechanism-underlying-social-hierarchy-identified/)

August 21, 2025

The formation of social hierarchies is a fundamental aspect of group living, reducing conflict and guiding behavior across species—from animals to humans. However the precise neural and molecular processes that underlie this behavioral adaptation remain poorly understood. New research identifies a brain circuit and molecular mechanism that becomes modified as animals establish their position within a social hierarchy.

Original article in: [Cell >](https://pubmed.ncbi.nlm.nih.gov/40795854/)

[![Image 2: Zeng_Sunze150](https://brain.harvard.edu/wp-content/uploads/Zeng_Sunze150.png)](https://brain.harvard.edu/hbi_news/a-silent-spinal-pathway-awakens-in-chronic-pain/)

August 20, 2025

New research reveals that acute and chronic insults both reshape how pain signals are sent to the brain, but through distinct mechanisms. By using long-term calcium imaging in mice, researchers from the Woolf lab tracked the same spinal cord neurons over time and found that acute pain temporarily increases sensitivity, while chronic nerve injury recruits a previously ‘silent’ group of neurons – offering a potential key to understanding chronic pain.

[![Image 3: microscope images of stem cells](https://brain.harvard.edu/wp-content/uploads/Microglia-150px.jpg)](https://brain.harvard.edu/hbi_news/improving-creation-of-microglia-in-a-dish-for-brain-research/)

June 18, 2025

New research from Jenny M. Tam, Soumya Raychaudhuri, George M. Church and colleagues, co-first authors Songlei Liu, Li Li, Fan Zhang, and Mariana Garcia-Corral pioneers a novel method of creating microglia,immune cells in the brain and spinal cord,with “strong functional similarities” to human microglia in four days, as opposed to the 35 days it takes to obtain less fine-tuned cells in a conventional stem-cell differentiation process.

[![Image 4: image depicting Effects of selective experience rearing on thalamic neuron properties](https://brain.harvard.edu/wp-content/uploads/sonoda_image150.png)](https://brain.harvard.edu/hbi_news/more-than-a-relay-how-the-visual-thalamus-adapts-to-sensory-experience/)

June 16, 2025

It was long thought that only neurons in the outermost regions of the brain, called the cortex, could adapt and change their properties in response to visual experience. Takuma Sonoda and Chinfei Chen share new findings revealing that the visual thalamus, a structure in the center of the brain, at an earlier stage in the visual pathway than the cortex, can also change based on what animals see. Their discovery expands our understanding of how sensory systems learn and adapt.

Original article in: [Cell >](https://pubmed.ncbi.nlm.nih.gov/40112812/)

[![Image 5: Florian Engert, Alex Chen, and Marc Duque Ramirez](https://brain.harvard.edu/wp-content/uploads/2025_Engert_science_9331_hex.jpg)](https://brain.harvard.edu/hbi_news/new-stars-in-neural-circuits-astrocytes-guide-brain-state-changes/)

May 28, 2025

Astrocytes are the most abundant non-neuronal cell type in the brain, though the mechanisms they use to communicate with neurons remains unclear. A new study from Florian Engert (Harvard), Misha Ahrens (Janelia) and colleagues, first author Alex B Chen. has identified a role for astrocytes in implementing feedforward inhibition over slow timescales and filled in critical molecular details in a biochemical pathway that astrocytes use to signal to neurons

[![Image 6: Cohen_Adam_Headshot](https://brain.harvard.edu/wp-content/uploads/Cohen_Adam.jpg)](https://brain.harvard.edu/hbi_news/tracking-precisely-how-learning-memories-are-formed/)

May 19, 2025

New research from Adam Cohen and colleagues, first author Doyeon Kim, has unveiled a way to map the molecular underpinnings of how learning and memories are formed, a groundbreaking new technique expected to offer insights that may pave the way for new treatments for neurological disorders such as dementia.

[![Image 7: Microscopy image indicating a plethora of abnormal RNAs in fibroblast cells from a patient with an Integrator mutation](https://brain.harvard.edu/wp-content/uploads/gene-quality-control.png)](https://brain.harvard.edu/hbi_news/what-happens-when-a-gene-quality-control-mechanism-fails/)

May 19, 2025

New research from Karen Adelman and colleagues, first author Apoorva Baluapuri, shows how failure of a gene-reading quality-control mechanism called Integrator leaves cells littered with abnormal RNA strands that increase cell stress and may contribute to diseases such as cancer and neurodegeneration.

Original article in

*[... truncated, 145,683 more characters]*

---

### okube
*401 words* | Source: **GOOGLE** | [Link](https://www.okube.ai/)

### Open source solutions for data intelligence.

![Image 1](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/9f4d4f0e-0cb1-41b7-9e55-d0f61b8e5a70/kubes.png)

Okube is dedicated to building open source frameworks, known as the [kubes](https://www.okube.ai/kubes), empowering businesses to build, deploy and operate highly scalable data platforms and AI models.

We enable our clients to thrive in the data intelligence era by offering comprehensive consulting services, including the efficient and optimized integration of the [kubes](https://www.okube.ai/kubes).

![Image 2](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/19f6b8f5-6d49-41ef-90bd-148997cf4466/okube_logo_edge.png)

### DataOps and MLOps frameworks

[![Image 3](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/d7546ad9-2023-4d13-b3b9-ceca9ee6edaa/laktory_app.png)](https://www.okube.ai/kubes)

[![Image 4](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/b19bb88b-1b4a-4d3b-8309-3cf024530ee3/planck_app.png)](https://www.okube.ai/kubes)

### Who we’ve worked with.

[![Image 5](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/de2257e8-377e-4e04-8dfa-2faa7b27761d/energir.jpg)](https://energir.com/)

[![Image 6: CAE Inc. logo](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/93b9f19a-625e-4ba2-80ed-21e2071e308a/cae.png)](https://www.cae.com/)

[![Image 7: Taiga Motors logo](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/968ce5e3-137a-4801-a4dc-7d1791752bda/taiga.png)](https://www.taigamotors.com/)

[![Image 8: newton crypto logo](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/a6b9da28-fc51-46a5-aee2-dd244b219e72/newton.png)](https://www.newton.co/)

![Image 9](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/daa4e975-9beb-4c87-8336-77d7c4bdce5b/okube_headshot_andy.png)

“Working with Olivier is an absolute delight. His thorough knowledge of the Databricks platform has helped us better organise, categorize, secure, and access our data. Olivier has been instrumental in helping us modernize our data pipelines by migrating our legacy codebase to fully leverage Unity Catalog.

He can provide technical recommendations but is also able to quickly understand business processes and ensure that the technical solutions meet the business requirements. Olivier has been a great addition to the team.”

Andy Paul, Data Architect, Énergir

![Image 10](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/a3eace7a-5df5-4d56-8182-537b565c1489/okube_headshot_bijil.png)

“I've had the pleasure of working closely with Olivier on multiple Databricks projects, and his ability to transform complex environments into simple, scalable architectures is truly remarkable.

In addition to his pragmatism, as a valued Databricks SME, I can always lean on his expertise, trust his judgement and advice on all things Databricks. I would highly recommend Olivier and most definitely will be working with him again in the future.”

Bijil Subhash, Nimblestax, Founder

![Image 11](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/eeffdfd5-3fa1-4487-b899-871b2b8f5bef/okube_headshot_gab.png)

“Ensuring swift time-to-market remains a paramount concern at Taiga. Laktory has proven instrumental in expediting the establishment of our data science platform, without compromising on security or performance.

The adept team at Okube demonstrates profound expertise and exemplifies exceptional collaboration.”

Gabriel Bernatchez, CTO, Taiga

![Image 12](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1064b285-a1a8-487e-8c58-8316313a8330/okube_headshot_shaun.png)

“Olivier Soucy was an invaluable asset to Newton, where he was brought on board to spearhead our big data strategy. His exceptional technical vision combined with his ability to communicate effectively with stakeholders at all levels has significantly propelled our projects forward.

Olivier's leadership in navigating complex datasets and crafting clear, actionable strategies has not only met but exceeded our expectations. His contributions have been pivotal to our success in leveraging data to drive innovation, produce insights, and improve efficiency.”

Shaun Martin, Director of Engineering, Newton

### We’d love to work with you.

### Our Partners

[![Image 13](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/85f2251a-5129-4038-a6cc-b8e88ac89842/databricks_logotype.png)](https://www.okube.ai/partners)

---

### blog — okube
*1,700 words* | Source: **GOOGLE** | [Link](https://www.okube.ai/blog)

[![Image 1: Lakehouse as Code | 04. Delta Live Tables Data Pipelines](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1732342654340-O0NXWCGRQEIRD0XW3I4L/1728447917654.png)](https://www.okube.ai/blog/lakehouse-as-code-04-delta-live-tables-data-pipelines)
2024-10-15 Olivier Soucy 2024-10-15

[Lakehouse as Code | 04. Delta Live Tables Data Pipelines](https://www.linkedin.com/pulse/lakehouse-code-03-delta-live-tables-data-pipelines-olivier-soucy-fovte/)
------------------------------------------------------------------------------------------------------------------------------------------------------------------

Welcome to the Lakehouse as Code mini-series! In this series, we'll walk you through deploying a complete Databricks lakehouse using infrastructure as code with Laktory. In this fourht part, we focus on configuring a Databricks workspace.

[Read More](https://www.linkedin.com/pulse/lakehouse-code-03-delta-live-tables-data-pipelines-olivier-soucy-fovte/)[![Image 2: Lakehouse as Code | 03. Data Pipeline Jobs](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1732342490390-MMI33Y2NOF29HERP51YD/1728320769185.png)](https://www.okube.ai/blog/lakehouse-as-code-03-data-pipeline-jobs)
Olivier Soucy 2024-10-08 Olivier Soucy 2024-10-08

[Lakehouse as Code | 03. Data Pipeline Jobs](https://www.linkedin.com/pulse/lakehouse-code-03-data-pipeline-jobs-olivier-soucy-ywowe/)
--------------------------------------------------------------------------------------------------------------------------------------

Welcome to the Lakehouse as Code mini-series! In this series, we'll walk you through deploying a complete Databricks lakehouse using infrastructure as code with Laktory. In this second part, we focus on configuring a Databricks workspace.

[Read More](https://www.linkedin.com/pulse/lakehouse-code-03-data-pipeline-jobs-olivier-soucy-ywowe/)[![Image 3: Lakehouse as Code | 02. Workspace](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1732342247566-IK0QP2SCR6ZQ1K4TN3RE/1727656793817.png)](https://www.okube.ai/blog/lakehouse-as-code-02-workspace)
Olivier Soucy 2024-09-30 Olivier Soucy 2024-09-30

[Lakehouse as Code | 02. Workspace](https://www.linkedin.com/pulse/lakehouse-code-02-workspace-olivier-soucy-gskme/)
--------------------------------------------------------------------------------------------------------------------

Welcome to the Lakehouse as Code mini-series! In this series, we'll walk you through deploying a complete Databricks lakehouse using infrastructure as code with Laktory. In this second part, we focus on configuring a Databricks workspace.

[Read More](https://www.linkedin.com/pulse/lakehouse-code-02-workspace-olivier-soucy-gskme/)[![Image 4: Lakehouse as Code | 01. Unity Catalog](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1732341051450-8FKYM2XCNY46YLFCH4ZA/1727158080709.png)](https://www.okube.ai/blog/lakehouse-as-code-01-unity-catalog)
Olivier Soucy 2024-09-24 Olivier Soucy 2024-09-24

[Lakehouse as Code | 01. Unity Catalog](https://www.linkedin.com/pulse/lakehouse-code-01-unity-catalog-olivier-soucy-5oule/)
----------------------------------------------------------------------------------------------------------------------------

Welcome to the Lakehouse as Code mini-series! In this series, we'll walk you through deploying a complete Databricks lakehouse using infrastructure as code with Laktory. In this first part, we focus on laying the foundation for Unity Catalog.

[Read More](https://www.linkedin.com/pulse/lakehouse-code-01-unity-catalog-olivier-soucy-5oule/)[![Image 5: Data Pipelines | To merge, or not to merge](https://images.squarespace-cdn.com/content/v1/65cda5755f8ae2040890df8f/1732256550259-NX42TADWCXLGWOX59R72/1725762918801.png)](https://www.okube.ai/blog/l5ffpqsomrqhlrw5q8v8uls0hj7xdg)
Olivier Soucy 2024-09-10 Olivier Soucy 2024-09-10

[Data Pipelines | To merge, or not to merge](https://www.linkedin.com/pulse/data-pipeline-merge-olivier-soucy-c1xwe/)
---------------------------------------------------------------------------------------------------------------------

In recent years, data has shifted towards a more streaming-centric nature. Online transactions, website clicks, TikTok likes, and even your car's real-time energy consumption now contribute to an ecosystem where each data point represents a new, immutable event. This evolution has led to the rise of [incremental data pipelines](https://www.linkedin.com/pulse/mastering-streaming-data-pipelines-kappa-architecture-olivier-soucy-0gjgf/), which process data as it arrives, in contrast to traditional batch processing of large historical datasets.

Most online transaction processing (OLTP) systems have adapted by generating streams of events through techniques like Change Data Capture (CDC), where every row-level change in a database is tracked and delivered in real time. SQL operations, such as MERGE INTO, enable these events to 

*[... truncated, 16,555 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[okube](https://www.okube.ai/)**
  - Source: okube.ai
  - *Okube is dedicated to building open source frameworks, known as the kubes ... “Olivier Soucy was an invaluable asset to Newton, where he was brought o...*

- **[blog — okube](https://www.okube.ai/blog)**
  - Source: okube.ai
  - *Olivier Soucy 2024-10-15 Olivier Soucy 2024-10-15. Lakehouse as Code | 04. ... Copyright © 2023-2024. Okube® is a registered trademark....*

---

*Generated by Founder Scraper*
