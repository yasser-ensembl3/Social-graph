# Tomasz Zemla

## Position actuelle

**Entreprise** : DictionaryGames

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Tomasz Zemla
*DictionaryGames*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [DictionaryGames.io](https://www.dictionarygames.io/)
*2025-01-01*
- Category: article

### [Ignacy Trzewiczek part 2 – Magazines, Machina, and Michał](https://dicetowerdish.com/2024/07/18/ignacy-trzewiczek-part-2-magazines-machina-and-michal/)
*2024-07-18*
- Category: article

### [tomaszdzierza.com – Blog About design](https://blog.tomaszdzierza.com/)
*2012-12-21*
- Category: blog

### [Ignacy Trzewiczek part 3 – Gatherings, GMT, and Giveaways](https://dicetowerdish.com/2024/07/22/ignacy-trzewiczek-part-3-gatherings-gmt-and-giveaways/)
*2024-07-22*
- Category: article

### [Allusionist 192 Word Play part 2 transcript — The Allusionist](https://www.theallusionist.org/transcripts/wordplay2)
*2024-05-13*
- Category: article

---

## 📖 Full Content (Scraped)

*5 articles scraped, 14,140 words total*

### DictionaryGames.io
*195 words* | Source: **EXA** | [Link](https://www.dictionarygames.io/)

**10,000**Words

In Your Head
-----------------------------

There are more than 100,000 words in the English language. A typical native speaker knows more than 10,000. How many do you know?

Bored with your static vocabulary flashcards? Nervous about the upcoming language exam? Want to expand your vocabulary beyond 'good' and 'bad'?

The 21st century flashcards and word games for learning English vocabulary have arrived! This website is for ESL (English as a Second Language) students, teachers and language lovers.

**PLAY**

Short word games to expand your vocabulary.

**FREE**

Want to get a taste of DictionaryGames? Try the free version. No registration. No tracking. No wait.

[Try Free Version Now !](https://www.dictionarygames.io/play)

**STUDY**

Learn vocabulary using 21st century flashcards.

**$25 / YEAR

INTRODUCTORY PRICE**

Master English vocabulary with the help of sophisticated application that adapts to your language level, your needs and subject interests.

**Coming January 2026**

**TEACH**

Generate custom practice exercises for ESL students.

**$10 / MONTH**

Interactive and PDF based vocabulary exercises designed for classroom work. For language tutors, parents and self-learners.

**Coming Fall 2026**

Want to talk to the non-AI generated human behind this project? Get notified about product updates? Have questions? Send email to **[tomek@dictionarygames.io](mailto:tomek@dictionarygames.io)**.

---

### Ignacy Trzewiczek part 2 – Magazines, Machina, and Michał
*3,252 words* | Source: **EXA** | [Link](https://dicetowerdish.com/2024/07/18/ignacy-trzewiczek-part-2-magazines-machina-and-michal/)

![Image 1](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Venetian-Front.jpg?resize=597%2C937&ssl=1)

Welcome back to an interview dinner with Portal Games founder and designer Ignacy Trzewiczek, that I was lucky enough to hold during Dice Tower East 2022. Ignacy was describing the gaming scene in post-communist Poland around 1991; Role Playing Games were heard of, magazines were starting to come out, but there were no games as of yet.

**IT:** There’s no roleplaying games. There’s just magazines about them. Because the publisher decides that he tries to introduce role playing games to Poland. And he starts with the magazine. I buy the magazine. And many people of my generation, we have no clue what we are reading. This is a funny thing, like we are buying magazine, we are reading about role-playing games. We never played them. We don’t have them. We don’t know what it is. But it’s very interesting. Fascinating.

**DTD:** But you _want_ them.

One of the great draw of media magazines for me has always been reading about games or video games or movies that haven’t come out yet. This sounds like the ultimate version – reading about a genre and industry that does not exist.

**IT:** Yeah. And this publisher of this magazine figured out that his readers have no clue what this magazine is, but they are still keep buying that. And the 7th issue, is more than a year from the first issue, he publishes in the magazine, inside the magazine, a mini role playing game, so we all can actually finally see a role playing game, and start playing.

**DTD:** Wow.

**IT:** So it took… For the whole year, he was selling the magazine, and we were buying not knowing what we were reading about. But it was fascinating world that we wanted to, you know, to touch, to understand.

![Image 2](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Magia-2.jpg?resize=209%2C300&ssl=1)

**DTD:** Wow!

The magazine in question most likely was [Magia i Miecz](https://en.wikipedia.org/wiki/Magia_i_Miecz), or “Magic and Sword”, started in 1993.

**IT:** And it was my high school. So in this period, teenagers like… dive in.

**DTD:** Wow. So… There was no way to get _any_ of these games that he was talking about?

**IT:** There was literally like, I guess, 20 people in different cities in Poland who had role playing games that they imported, because their parents were ambassador, or because their father…

![Image 3](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Fenix.jpg?resize=211%2C300&ssl=1)

**DTD:** Wow.

**IT:** And the interesting, interesting, fact. This mini role-playing game published in this magazine was written by [Andrzej Sapkowski](https://en.wikipedia.org/wiki/Andrzej_Sapkowski), writer of [The Witcher](https://en.wikipedia.org/wiki/The_Witcher).

The roleplaying game in question is probably [Oko Yrrhedesa](https://pl.wikipedia.org/wiki/Oko_Yrrhedesa), The Eye of Yrrhedes. Very rough rules first appeared in the magazine Fenix in 1990, then in more detail within Magia i Miecz in 1994. Oko Yrrhedesa was published on its own in 1995 with a second edition in 1999.

**DTD:** Alright!

**IT:** Because, before he became a writer, before he became a full-time writer, he was working sales, so he was working internationally. And he was fan of science fiction. So, being outside Poland, he bought couple of role-playing games. So he knew what this is. So he wrote this mini role playing game to introduce it in Poland. So, like, it was crazy time. And I say, I wrote a piece about that in Polish, in Poland. These days, kids who have Googled, and they have everything. They will never have such a discovery. Like, I was buying a magazine, and there was no “Googling”. It was… everything I had was these pages, and I was trying to figure out what I was reading about. And it was like, really like discovering something absolutely new and unknown and fascinating.

**DTD:** Yes.

![Image 4](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2020/11/creative-computing.jpg?resize=223%2C300&ssl=1)

**IT:** And no Google that will explain it. No YouTube, no.

**DTD:** No, no. Reminds me of… like the video game industry in America in the 70’s and in early 80’s. It’s just the magazines. That’s all we had.

This is the closest comparison I have, a pre-internet world. Where I would type in code for computer games published in magazines. Although Ignacy is tslking about a pre-game, pre-internet world.

**Waiter:** Any questions we may have about the menu and anything that is here?

**DTD:** No, I think I want everything. I think it might hurt me, though.

**Waiter:** Yes, it might. It might just.

I am not one to back down from a challenge.

**DTD:** [laughs] Are you ready, Ignacy?

**IT:** I’m ready, yes.

**DTD:** OK. So, you recommend getting a few sides, and…?

**Waiter:** It depends on how hungry you are.

![Image 5](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Lamb-Chop.png?resize=300%2C232&ssl=1

*[... truncated, 18,142 more characters]*

---

### tomaszdzierza.com – Blog About design
*1,741 words* | Source: **EXA** | [Link](https://blog.tomaszdzierza.com/)

We continue the interview with American McGee…

**T: Big Head Bash, Crazy Fairies and Akaneiro are all “Free to Play” titles. What draws you to this model? What opportunities do you see in it? and what’s your own definition of Free to Play?**

A: I like to think of it like a ‘pay what you want’ model. You can get into any of our games and access 100% of the content for free – though you have to exchange your time in order to do so. Or, if you don’t feel like waiting, you can pay for access to those things you don’t feel like earning. That means it’s up to the players whether or not – or how much – they pay. If they feel like the game is worthwhile or the content is interesting, they’ll pay for it. If not, they aren’t out of pocket. It also provides a wonderful way for us to maintain a connection with the audience and provide constant updates to the content and game play. Coming from the world of console games, this is probably one of my favorite aspects of the model (which is really more related to being an online game in general.) [Continue reading “Interview with American McGee Part 2”](https://blog.tomaszdzierza.com/2012/12/21/interview-with-american-mcgee-part-2/#more-1037)

To celebrate the release of Toy Glider and to spice up the blog a bit I thought I start a series of interviews with other developers from the game dev community. Who’s better to start than somebody who has been making games for a long time without any signs of slowing down. Enter American McGee.

**T: Beta testing Akaneiro, regularly adding content to Big Head Bash as well as Crazy Fairies and now planning your Kickstarter Campaign.You’re keeping yourself busy. How do you manage all these projects at the same time?**

A: Over the years the studio has developed an internal culture that expects and rewards multi-disciplined people who are comfortable wearing lots of hats and jumping between a variety of tasks and projects. At times it can feel a little disorienting to keep track of everything that’s going on – but no one has ever complained of boredom from repetition. For everyone in the studio the balancing act requires decent organizational and prioritization skills. We all try our best to maintain basic tracking sheets with an understanding of priority based on feedback from the studio at large. We hold a weekly meeting where we assign resources for the next week – and from that basic resource planning flows the detailed planning that makes each department hum along for another week.

**T: Over the years, I’ve noticed that you have a very refined daily routine. Could you share a bit how you developed it and how has it evolved over the course of your career?**

[Continue reading “Interview with American McGee Part 1”](https://blog.tomaszdzierza.com/2012/12/18/interview-with-american-mcgee-part-1/#more-1029)

It’s been several months since this blog first started. Today is a another “first”. The first guest post comes from Aaron. Aaron is an experienced game developer who shares his experience as a game contractor/freelance developer. Happy to have him here to share his insights and experience so far.

Enter Aaron,

Hi all – great to ‘be’ here. First, a quick shout-out for Tomasz – it’s awesome to see how another game contractor is making it work, so thanks for being so open. I hope my post adds something to the conversation.

I’ve been developing games since 1995, and mostly as a Designer, though recently as a Project Manager / Executive Producer. My background is Computer Science, with an Art minor – I know my way around Photoshop, Illustrator, and a sketchbook, and spent 5 years building levels in 3D Studio Max.

I mention this because as a freelance developer, you never know which skillset you’ll be called on to use in a given day. The client may need artwork cleaned up, or a prototype written, or a new feature implemented. As you delve into various tasks, of course, you’ll need to have the “Producer” hat on at all times to be asking “Is this getting me towards the client’s goals”, and “Am I on track?”

[Continue reading “An Inside Look Into Freelance Game Development”](https://blog.tomaszdzierza.com/2012/04/28/freelance_game_development/#more-927)

There are different levels of engagement/commitment to any specific task or project. I’ve been thinking recently about the different tasks a game developer has and trying to decide at what level of depth I’d like to get involved in each.

Let’s take Photoshop as an example.

I’ve used Photoshop for many years but until recently never dug very deep behind the basics. Photoshop is an interesting example because it’s used by both amateurs and professionals. At the most basic level Photoshop is an image editing program and at that level it does what it needs to. Perhaps a person who just wants to edit a photo they took of their dog might learn how to open a document, use different selection tools, crop the image and perhaps do basic colour manipulation.

[Continue reading “Depth of Engage

*[... truncated, 5,598 more characters]*

---

### Ignacy Trzewiczek part 3 – Gatherings, GMT, and Giveaways
*3,187 words* | Source: **EXA** | [Link](https://dicetowerdish.com/2024/07/22/ignacy-trzewiczek-part-3-gatherings-gmt-and-giveaways/)

![Image 1](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Lamb-Chops.jpg?resize=1024%2C730&ssl=1)

Welcome back to another edition of dinner with Ignacy. The food is arriving, and Ignacy is on a roll talking about creating an industry in the wake of the fall of communism. Today – creating a user base through conventions.

![Image 2](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Detective.webp?resize=300%2C300&ssl=1)

**DTD:**Well, Poland is one of the top countries now for board games. I don’t know… Does Poland beat Germany at this point…?

**IT:**Not yet, but we are very close.

**DTD:**But very close.

**IT:**When I compare the print runs between… because, you know, we do [Detective](https://boardgamegeek.com/boardgame/223321/detective-a-modern-crime-board-game) in Germany, in Poland, and Spain.

**DTD:**Of course.

![Image 3](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Bruno-Faidutti.jpg?resize=300%2C300&ssl=1)

**IT:**So, I know that our print runs are very, very solid and we are top three in Europe. And it started very late, but very intense, like when it exploded. And the one thing that I also did that had a lot, and I strongly recommend to all other countries to do it. I found a website of [Bruno Faidutti](https://boardgamegeek.com/boardgamedesigner/125/bruno-faidutti) – he had a blog back then. And his blog was called [The Ideal Game Library](https://faidutti.com/blog/blog/2023/09/26/archive-de-la-ludotheque-ideale-an-archive-of-the-ideal-game-library/). He was publishing reviews of the board games.

**DTD:**OK.

Bruno Faidutti is the designer behind such classics as [Mystery of the Abbey](https://boardgamegeek.com/boardgame/915/mystery-of-the-abbey), [Mission Red Planet](https://boardgamegeek.com/boardgame/18258/mission-red-planet) and [Queen’s Necklace](https://boardgamegeek.com/boardgame/6068/queens-necklace). Interestingly, Faidutti is also one of the world’s leading experts on Unicorns. And now you know…

**IT:**So, I was learning about the games from him. And one day he posted a report from his own convention. Now we know it as Bruno Faidutti’s Gathering of Friends. Back then, it was just a convention. So, I saw the pictures, and I read the report. It said, “Bruno Faidutti invited his friends and played board games.” I said, “I can do it.”

**DTD:**“I can do that!” [laughs]

![Image 4](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2022/09/Gathering-logo.png?resize=300%2C66&ssl=1)

Several successful game designers have for years had small yearly get togethers with their friends and colleagues, and sometimes these turn into conventions of some note. The two most famous ones are The Gathering of Friends, originally started by [Ticket to Ride](https://boardgamegeek.com/boardgame/9209/ticket-to-ride) designer [Alan R Moon](https://boardgamegeek.com/boardgamedesigner/9/alan-r-moon), and Bruno Faidutti’s aforementioned convention. Bruno famously takes over a small town in France, and people just play games, eat nice food, and drink good wine.

**IT:**So, I posted, so I posted on the Polish forum that I’m starting this new initiative. “Hey, guys. Let’s meet face to face. There’s, like, 50 of us in Poland, so we can meet.” I rented a space, and invited them. 20 people, 20 people came.

**DTD:**Twenty?

**IT:**Twenty. Each of them came with their own board game. because each of us back then had one board game in the collection, like…

**DTD:**“Look what I imported.”

**IT:**Yeah. Yeah. [laughs] So, we had these 20 or 30 games.

**DTD:**Wow.

**IT:**Almost like a private meeting, but it was like for the first time, board gamers in Poland met in one place. We played the whole weekend. And everyone said, “Ignacy, we meet again, right?” And I said, “Yes, yes, yes. We meet again. We meet again.”

**DTD:**Was that Portal Con One?

Portal does have it’s own convention, PortalCon which started around 2006. PortalCon 2024 occurred in early January, and had to cap its attendance at 1000 people.

![Image 5](https://i0.wp.com/dicetowerdish.com/wp-content/uploads/2024/07/Pionek-Logo.jpg?resize=300%2C300&ssl=1)

**IT:**That was [Pionek](https://boardgamegeek.com/wiki/page/Pionek) 1. Pawn. I called it “pawn”, Pionek. And I did it and I said, “Yes. We meet in three months, in one quarter.” For the next convention, and I’m not making it up, it’s really true… The next edition, 40 people. So exactly twice as much. We play board games. Everybody brings their own board game. We have a great time. “Ignacy, next time…?” “Yes. In one quarter we meet.” And really, really – next time 80 people. Once again exactly twice as much.

Pionek is the Polish word for “pawn”. Pionek is still happening in Ignacy’s home town of Gliwice, Poland.

**DTD:**Wow.

**IT:**And the next time, 120 people. And for this 4th convention… This is a convention, now it is a convention. 120 people playing those games.

The waiter sneakily dropped off lots of food. 80% for me, and a smattering of 

*[... truncated, 17,368 more characters]*

---

### Allusionist 192 Word Play part 2 transcript — The Allusionist
*5,765 words* | Source: **EXA** | [Link](https://www.theallusionist.org/transcripts/wordplay2)

### **Listen to this episode and find out more about the topics therein at**[**theallusionist.org/wordplay2**](https://theallusionist.org/wordplay2)

This is the Allusionist, [in which](https://inwhiches.tumblr.com/) I, Helen Zaltzman, am checkmated by language.

This episode and the next couple are about word games; fun! Today we’ll hear from game-makers who have come up with very different approaches to making games about language. In a way, this is a sequel to [the episode featuring Leslie Scott](http://theallusionist.org/wordplay), who invented Jenga when she was a teen and has since made dozens of other games, including the word games Ex Libris, Anagram and Flummoxed. That was episode sixteen of the show, so we’re operating on a _Before Sunset_ sequel speed.

By the way! If you’re in the UK, you can listen to this show on BBC Sounds! And you know who else is on there? The Infinite Monkey Cage, the show hosted by Brian Cox - the celebrity physicist one not the _Succession_ and _Manhunter_ one - and comedian Robin Ince, and guess what? My first ever professional radio recording was with none other than Robin Ince, nineteen years ago wow. And just look at him now! OK listen to him now, on the Infinite Monkey Cage, the show wherein scientists and comedians look at science in a comedic way, and consider matters dark and non-dark, like the creatures that live in the deepest depths of the oceans and how illusions work on our credulous human minds and whether fish can count and how big is big data exactly and why do we laugh and what so astronauts really get up to in space. Episodes will be released on Wednesdays, wherever you get your podcasts. But if you’re in the UK, you can listen to the latest episodes, a week early, first on BBC Sounds.

Speaking of astronauts, on 18th April 2024 there’s a special Allusionist live show happening in the planetarium at the H.R. MacMillan Space Centre in Vancouver BC! It’ll be packed full of edutainment about language of the cosmos, while galaxies swirl over your head, and your ticket also includes all the space centre’s exhibits AND a talk by the very cool astronomer Marley Leacock. What a delightful evening! I’ve linked to tickets at [theallusionist.org/events](http://theallusionist.org/events).

On with the show.

HZ: People assume _to my face_ that a podcast about language won't be fun, and they're like, “Why would you do something that sounds so boring and dry and like a punishment?” What kind of reactions do you get when people learn that you make games about language?

KATHRYN HYMES: It's so interesting - for some people there's a similar reaction, but for a set of people, it's like you have given them the thing that they have most wanted in the world and maybe didn't realise or articulate or hope that such a thing could be made. And it's somewhat shocking that there's enough of those people and that the internet is able to connect it, you know, connect us to them that we end up finding each other.

JOSHUA BLACKBURN: The simplest way to describe League of the Lexicons, and I'm not very happy with it as a description, is that it is Trivial Pursuit for word lovers. But I'm not over the moon with that description because it sounds a little bit flat.

HZ: Really? People love Trivial Pursuit!

JOSHUA BLACKBURN: I _hated_ Trivial Pursuit.

HZ: I think we only played once in my family, and my dad refused to play but then sat in the corner of the room shouting out all the answers.

JOSHUA BLACKBURN: I am Joshua Blackburn. I am the founder of [Two Brothers Games](https://www.twobrothersgames.co.uk/) and the creator of League of the Lexicon, a game about words and language. League of the Lexicon is a quiz game about words and language. It almost has quite an encyclopaedic scope in terms of what words mean, where they come from, interesting bits of trivia about the evolution of language and how we use language.

**HZ: Joshua didn't set out to be a maker of word games. He was a designer and artist and photographer - he made a book of photos of every laundrette in London, all 462 of them. But this latest iteration of his career as word game maker came about as a result of homeschooling his two sons during the covid lockdowns.**

JOSHUA BLACKBURN: And they were getting their homework sent to them from school, and it was just really depressing. I was seeing the English that they were being sent, and it was uninspiring. It sucked all of the love, all of the fun, all of the passion out of language. And was also really boring to do with them. And so I started inventing word games and language games to get them to think about language differently - and hopefully to inspire more curiosity about where words came from, how we used words, why we used words. And that was my lockdown distraction.

**HZ: League of the Lexicon was not the first word game Joshua invented for his sons.**

JOSHUA BLACKBURN: I was test driving a few different ideas. There was a game called Word War. Dojo. Word Spl

*[... truncated, 29,290 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
