# Tahar Ali-Yahia

## Position actuelle

**Titre** : Founder, Senior Strategic Advisor
**Entreprise** : NexGedia Enterprise
**Durée dans le rôle** : 16 years 11 months in role
**Durée dans l'entreprise** : 16 years 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : IT Services and IT Consulting

## Description du rôle

Guiding organizations through the complex convergence of artificial intelligence, telecommunications, cybersecurity, and cloud computing.

## Résumé

For over 14 years, I have been the founder, innovation consultant and strategic advisor of NexGedia Enterprise, a consulting and professional services company that helps clients achieve their goals through innovation, technology, and leadership. With more than 25 years of experience in executive management, engineering management, marketing, business development and sales, I have a passion for solving complex problems and generating value for customers, partners, and stakeholders.

As an expert in information technology, telecom, and semiconductor industry, I leverage my skills in project management, R&D, strategic planning and partnership, talent acquisition and retention, intellectual property, technology transfer, and digital transformation. I work with clients across various sectors and regions, providing them with customized and tailored solutions that meet their needs and expectations. I am always eager to learn new things, explore new opportunities, and collaborate with other professionals who share my vision and values.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAALB5EBCs9CSfgMw0vzslwY6QaQTcCuKls/
**Connexions partagées** : 9


---

# Tahar Ali-Yahia

## Position actuelle

**Entreprise** : NexGedia Enterprise

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Tahar Ali-Yahia

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397491235508137984 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHB6MVn3RdtCA/feedshare-shrink_800/B56ZqS5yqBHQAg-/0/1763401215488?e=1766620800&v=beta&t=mMFcoHj90E3zs1zohoHfAEOwW3pk1X8kgz1G4MSLydI | NVIDIA is still central to global compute strategy and AI integration accelerating across industries, the “exodus” appears more like **strategic rotation** than leaving a sinking boat. | 0 | 0 | 0 | 2w | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:02.600Z |  | 2025-11-21T04:29:09.286Z | https://www.linkedin.com/feed/update/urn:li:activity:7396240778236354560/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396744940053168128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvgglZ9Verfw/feedshare-shrink_800/B4EZqTXi5eGcAg-/0/1763409014973?e=1766620800&v=beta&t=7UVWGAq91VugCQDfMS2olFtuzf8IOyaolKFajJemJeo | AI is indeed accelerating a structural shift in professional services, and the traditional time-and-materials (T&M) consulting model is under significant pressure. But whether this marks the beginning of the end depends on how we define “end”—and what we mean by “traditional.” | 0 | 2 | 0 | 2w | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:02.600Z |  | 2025-11-19T03:03:38.584Z | https://www.linkedin.com/feed/update/urn:li:activity:7396547741340033024/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393384801027649537 | Text |  |  | Dans cet article, j'aborde le fossé en matière de résilience dans les entreprises et propose des pistes pour y remédier. Si votre entreprise se trouve dans cette situation et que vous souhaitez en discuter, n'hésitez pas à me contacter. | 2 | 0 | 0 | 4w | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:02.601Z |  | 2025-11-09T20:31:39.012Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7393375387734523904 | Text |  |  | In this article, I discuss the resilience gap in companies and suggest ways to address it. If your company is in this situation and you would like to discuss it, please feel free to contact me. | 3 | 0 | 0 | 4w | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:02.601Z |  | 2025-11-09T19:54:14.708Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7375684150638387200 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHYAhyyc7JWPw/feedshare-shrink_800/B4DZlQ9ZbRJIAg-/0/1757999899210?e=1766620800&v=beta&t=tYH6K8UF8MSdRFKSXBempPPPbBrx_-eM2gYrS-mtF2g | Risk of privacy issues with travel eSIM. | 1 | 0 | 0 | 2mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.283Z |  | 2025-09-22T00:15:35.097Z | https://www.linkedin.com/feed/update/urn:li:activity:7373586014893699072/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7368804424481292289 |  |  |  |  | 6 | 3 | 0 | 3mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.284Z |  | 2025-09-03T00:38:00.562Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7368755491436535808 | Text |  |  | The IA imperative in IT & Telecom | 2 | 0 | 0 | 3mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.284Z |  | 2025-09-02T21:23:34.015Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7363291255318953985 | Text |  |  | My weekend readings inspired me to say this: 

We don't repair an injustice with another one. 
We don't repair a crime with another one. 
And We don't repair a genocide with another one.

In fact, evil cannot justify evil, not even in response to great suffering. This reminds us that revenge, violent reciprocity or collective punishment do not lead to justice, but to an endless cycle of hatred and destruction.

The tragic events of the last twenty-five (25) years lead me to wonder whether History continues, or whether we are on the verge of an explosion that could jeopardize the future of humanity.

What do you think? | 6 | 4 | 0 | 3mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.285Z |  | 2025-08-18T19:30:38.604Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7363289895399739394 | Text |  |  | Mes lectures du week-end m'ont inspiré ceci : 

On ne répare pas une injustice par une autre. 
On ne répare pas un crime par un autre. 
Et on ne répare pas un génocide par un autre. 

En fait, le mal ne saurait justifier le mal, pas même en réponse à une grande souffrance. Ceci nous rappelle que la vengeance, la réciprocité violente ou la punition collective ne mènent pas à la justice, mais à un cycle sans fin de haine et de destruction.

Les évènements tragiques des vingt-cinq (25) dernières années me poussent à m'interroger est-ce l'Histoire qui continue, ou sommes-nous à l'aube d'une déflagration qui risque de mettre en péril l'avenir de l'Humanité. 

Qu'en pensez-vous ? | 5 | 0 | 0 | 3mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.286Z |  | 2025-08-18T19:25:14.374Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7356449011215597568 | Text |  |  | Later on,

There'll be no “later” because later the coffee gets cold, later there'll be no interest, later it'll be dark, later the kids will have grown up and later it'll be too late.

Then you'll wish you'd done it sooner, because later is often too late.

So, what are you waiting for to make sure it's not too late? | 23 | 0 | 0 | 4mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.286Z |  | 2025-07-30T22:22:00.487Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7356448632209825793 | Text |  |  | Plus tard,

Il n'y aura pas de "plus tard" car plus tard le café refroidira, plus tard il n'y aura plus d'intérêt, plus tard il fera nuit, plus tard les enfants auront grandi et plus tard il sera trop tard.

Puis, on regrettera de ne pas l'avoir fait avant car plus tard c'est souvent trop tard. 

Alors, qu'attendez-vous pour qu'il ne soit pas trop tard ? | 13 | 1 | 0 | 4mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.287Z |  | 2025-07-30T22:20:30.125Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7343045741860323328 |  |  |  |  | 3 | 0 | 0 | 5mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.287Z |  | 2025-06-23T22:42:12.052Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7343037859852894210 |  |  |  |  | 2 | 0 | 0 | 5mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.287Z |  | 2025-06-23T22:10:52.835Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7324101590745817088 | Article |  |  | https://lnkd.in/eQ2fYMgU | 1 | 0 | 0 | 7mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.292Z |  | 2025-05-02T16:04:54.461Z | https://www.onf.ca/film/posthumains/?utm_source=meta&utm_medium=conversion&utm_campaign=pan_posthumains&utm_content=qc-ont_socialissues_faces_poster_static_fr&fbclid=IwZXh0bgNhZW0BMABhZGlkAasaIrb2rjUBHjHjUGx2t4kpEdXfplP6KGA_DpbDgjmDuWy7ymDO701osoRYEsofAbhulmVw_aem_4gALwceRLzJF3bqFjt3oaw&utm_id=120218236039530117&utm_term=120218237467250117 |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7320866849947099137 | Article |  |  | https://lnkd.in/eRXkAPGK 
Lorsqu'on passe d'un slogan comme « De la musique pour tous » à l'exploitation du travail des artistes, c'est l'innovation qui dérive et qui conduit à des comportements condamnables. | 1 | 0 | 0 | 7mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.292Z |  | 2025-04-23T17:51:12.156Z | https://youtu.be/VtvfbGRDJbY |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7275271552558895104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGDpUuS3bZyOg/feedshare-shrink_800/B4EZPUMXIVHkAg-/0/1734431831901?e=1766620800&v=beta&t=ei_Aa3g2gZWVRNzDGC14enlw8rt1gprnmGa7GV5gcrI | Pendant tout le processus de l'investissement dans Northvolt, le gouvernement du Québec 🙊 🙉 🙈 ... | 1 | 0 | 0 | 11mo | Post | Tahar Ali-Yahia | https://www.linkedin.com/in/tahar-ali-yahia-3812aa | https://linkedin.com/in/tahar-ali-yahia-3812aa | 2025-12-08T04:47:07.297Z |  | 2024-12-18T22:11:46.139Z | https://www.linkedin.com/feed/update/urn:li:activity:7274734374393155586/ |  | 

---



---

# Tahar Ali-Yahia
*NexGedia Enterprise*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [NexGedia Enterprise | LinkedIn](https://ca.linkedin.com/company/nexgedia-enterprise)
*2024-05-29*
- Category: article

### [Nexford is integrating AI into all its programs - CEO, Fadl AI Tarzi | TechCabal](https://techcabal.com/2025/01/31/nexford-is-integrating-ai-into-all-its-programs-ceo-fadl-ai-tarzi/)
*2025-01-31*
- Category: article

### [Inspiring Entrepreneurs Leading the Fintech Scene in the MENA Region](https://en.arageek.com/inspiring-entrepreneurs-leading-the-fintech-scene-in-the-mena)
*2025-02-05*
- Category: article

### [Connecting Africa Podcast: S3 Ep. 6 - Building next-gen payment systems](https://www.connectingafrica.com/financial-inclusion/connecting-africa-podcast-s3-ep-6-building-next-gen-payment-systems)
*2025-05-13*
- Category: podcast

### [Nassreddine Riahi, CEO of the Franco-Tunisian start-up Cynoia : “The investment climate in Algeria has improved”.](https://africa-news-agency.com/nassreddine-riahi-ceo-of-the-franco-tunisian-startt-up-cynoia-the-investment-climate-in-algeria-has-improved/)
*2023-11-17*
- Category: article

---

## 📖 Full Content (Scraped)

*6 articles scraped, 11,523 words total*

### NexGedia Enterprise | LinkedIn
*1,325 words* | Source: **EXA** | [Link](https://ca.linkedin.com/company/nexgedia-enterprise)

NexGedia Enterprise | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/company/nexgedia-enterprise#main-content)[LinkedIn](https://ca.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fnexgedia-enterprise&fromSignIn=true&trk=organization_guest_nav-header-signin)[Join now](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fnexgedia-enterprise&trk=organization_guest_nav-header-join)

![Image 1: NexGedia Enterprise’s cover photo](https://media.licdn.com/dms/image/v2/C4E1BAQH2z1jGQKR_dw/company-background_1536_768/company-background_1536_768/0/1583801870537?e=2147483647&v=beta&t=BdqKkmSegsdr8bgTpmhiiaiTKsLWwXFdnbrd4dpFW8M)

![Image 2: NexGedia Enterprise](https://ca.linkedin.com/company/nexgedia-enterprise)

NexGedia Enterprise
===================

IT Services and IT Consulting
-----------------------------

### Montreal, Quebec  707 followers

#### Innovation is our power

[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fnexgedia-enterprise&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://ca.linkedin.com/company/nexgedia-enterprise) View all 2 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B10536337%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Fnexgedia-enterprise&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

We develop the future. We have the most creative ideas - Technologies of the 21st century. We have fast online services with the most advanced technologies. We have reliable customer support. For more information, visit our company site:www.nexgedia.com or our career site: jobs.nexgedia.com

 Website [http://www.nexgedia.com](https://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fwww%2Enexgedia%2Ecom&urlhash=x6jx&trk=about_website)
External link for NexGedia Enterprise

 Industry  IT Services and IT Consulting 

 Company size  2-10 employees 

 Headquarters  Montreal, Quebec 

 Type  Privately Held 

 Founded  2003 

Locations
---------

*    Primary 7140 Albert-Einstein

Montreal, Quebec H4S 2C1, CA [Get directions](https://www.bing.com/maps?where=7140+Albert-Einstein+Montreal+H4S+2C1+Quebec+CA&trk=org-locations_url)

Employees at NexGedia Enterprise
--------------------------------

*   [![Image 4: Click here to view NexGedia Talent Acquisition’s profile](https://ca.linkedin.com/company/nexgedia-enterprise)### NexGedia Talent Acquisition](https://ca.linkedin.com/in/nexgedia-talent-acquisition-39a3ab1b2?trk=org-employees)

[See all employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B10536337%255D&trk=public_biz_employees-join)

Updates
-------

*   
[](https://www.linkedin.com/posts/nexgedia-enterprise_orchestration-the-path-from-fragmentation-activity-7393780186309238784-lQG4)

[![Image 5: View organization page for NexGedia Enterprise](https://ca.linkedin.com/company/nexgedia-enterprise)](https://ca.linkedin.com/company/nexgedia-enterprise?trk=organization_guest_main-feed-card_feed-actor-image)[NexGedia Enterprise](https://ca.linkedin.com/company/nexgedia-enterprise?trk=organization_guest_main-feed-card_feed-actor-name) 
707 followers

 3w    

    *   [Report this post](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Fnexgedia-enterprise&trk=organization_guest_main-feed-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[https://lnkd.in/ezd-knKu](https://lnkd.in/ezd-knKu?trk=organization_guest_main-feed-card-text)

[![Image 6: Orchestration, the Path from Fragmentation to Resilience. ](https://ca.linkedin.com/company/nexgedia-enterprise) Orchestration, the Path from Fragmentation to Resilience. Tahar Ali-Yahia on LinkedIn](https://www.linkedin.com/pulse/resilience-gap-isnt-technology-its-orchestration-tahar-ali-yahia-qhd5e?trk=organization_guest_main-feed-card_feed-article-content)

[![Image 7

*[... truncated, 31,759 more characters]*

---

### Nexford is integrating AI into all its programs – CEO, Fadl AI Tarzi – TechCabal
*922 words* | Source: **EXA** | [Link](https://techcabal.com/2025/01/31/nexford-is-integrating-ai-into-all-its-programs-ceo-fadl-ai-tarzi/)

**_…Almost 40 percent of our graduates have already studied AI_**

**_…1200 students graduate; 7 Nigerians bag special awards_**

**_…solve problems, prioritize skills, Ezekwesili tells graduates_**

**_…bring change, influence better society – Peter Obi urges youths_**

![Image 1](https://c76c7bbc41.mjedge.net/wp-content/uploads/tc/2025/01/image1-5-1024x683.jpg)

**_**FADL AL TARZI, THE CHIEF EXECUTIVE OFFICER (CEO) OF NEXFORD UNIVERSITY.**_**

Fadl Al Tarzi, the Chief Executive Officer (CEO) of Nexford University (NXU), a next-generation online university based in Washington DC, America has emphasized that Nexford gradually integrating Artificial Intelligence into all its courses and programs.

Al Tarzi made this revelation while speaking at the Nexford University Graduation Ceremony held at the Landmark Event Centre, Victoria Island, Lagos.

“So whether you’re studying business or finance or entrepreneurship or data science or software, you’re going to be studying how to use AI in each of these fields. It’s becoming the essential requirement, just like, basic English reading skills to understand AI,” he said.

Meanwhile, the Nexford CEO said as the institution is integrating AI into all of programs, “Today, almost 40 percent of our graduates have already studied artificial intelligence. And most importantly, it (AI) can connect Nigerian talent with global Talent. So it can enable Nigerians to use AI to compete more effectively against talents and other markets that are not using AI,” Al Tarzi said.

At the 2024 Graduation, a total of 1200 students graduated successfully. NXU, which prides itself for skill-education awarded seven Nigerian students for their outstanding academic performance and demonstrated character during their course of study.

Tarzi commended the graduating students for their quest for knowledge and skills to compete globally.

The graduation ceremony was graced by Peter Obi, the Former Governor of Anambra State; Dr. Oby Ezekwesili, CEO, Human Capital Africa; Mrs. Bola Adesola Chairman, Ecobank Nigeria; Jennifer L. Scott, Ph.D Chief Academic Officer, Nexford University.

Other include Commissioner Olatubosun Alake Commissioner, Innovation, Science & Technology, Lagos State; Mrs. Olamidun Ogundoyin Founder, Sooyah Bistro; Former Country Director, Nexford University and Dr. Okechukwu Enelamah Chairman, African Capital Alliance.

The outstanding students awarded are Omolade Ganiyat Yusuf and Eganoyemi Oloruntosin Adetayo, who emerged Best Peer Mentor in the BBA Program and Best Peer Mentor in the MBA Program respectively.

Christopher Chukwuka Otakpor emerged Outstanding Volunteer Award in the BBA, while Kayode Olaitan Owoyemi won the Outstanding Volunteer Award – MBA.

Outstanding Brand Ambassador Awards category, Abdul Shakur Haruna was awarded Outstanding Brand Ambassador – Ghana while Christian Arimoku Ebhoma was awarded Outstanding Brand Ambassador – Nigeria.

Meanwhile, with a loud applause, Oluwasegun Anuoluwapo Ogundiran, who finished with an impressive a 4.0 CGPA was awarded as the Valedictorian of the Year for Class 2024.

Also speaking on the 2024 graduation, the Nexford Country Director, Oghogho Inneh, noted that the graduands emerged from various programs, which include Undergrad – BBA, Post Grad – MBA, MSDT, MSDA and MSE. Oghogho noted that he MSE was launched last year, with potential to attract more uptakes.

According to Oghogho, the MBA program (1606) has the most graduates in the class of 2024 followed by the BBA program (141).

Oghogho said the Class of 2024 represents a dynamic and inspiring cohort of learners from around the world, united by their ambition to excel in their careers and contribute meaningfully to their communities.

“The class has embraced Nexford’s focus on workplace-relevant skills. Many have already applied their learning to solve real-world challenges in industries such as technology, healthcare, entrepreneurship, and business management,” she added.

In his keynote address, Peter Obi urged the graduates to influence change for a better society and make meaningful contributions to the economy.

“You have acquired more than anyboby can acquire. If people in other countries go through the experience you pass through here, they won’t even pass. So go out there and influence change in the society that you live in.

“Don’t go about thinking about only making money. Go check anybody that makes meaningful wealth, they do so by creating value, by giving themselves out to serve the society. It is for you to help solve problems in the society.”

Tarzi who commended Nigerian students for their resilience, urged the 2024 graduating to showcase deliver real-time solutions that will change the world.

He said, “We are really proud of our Nigerian students. Nexford will continue to help Nigerian students bridge skill gap to be able to fit into the real world job market place globally.

“We are excited that over 75 per cent of our students have achieved their goa

*[... truncated, 1,124 more characters]*

---

### Inspiring Entrepreneurs Leading the Fintech Scene in the MENA Region
*2,548 words* | Source: **EXA** | [Link](https://en.arageek.com/inspiring-entrepreneurs-leading-the-fintech-scene-in-the-mena)

The financial landscape of the MENA region is undergoing a seismic shift, driven by a new generation of trailblazing entrepreneurs redefining the way businesses and individuals interact with money. These visionaries are not just building companies; they are crafting the infrastructure of a digital-first economy—one that prioritizes accessibility, efficiency, and financial inclusion.

From revolutionizing payments and SME financing to democratizing financial services through AI and embedded finance, these leaders are breaking barriers, unlocking new opportunities, and challenging the status quo. Their startups are securing record-breaking investments, expanding across borders, and reshaping the fintech ecosystem with disruptive solutions.

In this feature, we spotlight the minds behind the most influential fintech startups in MENA—innovators who are not only driving technological advancements but also empowering businesses, fostering inclusion, and paving the way for a cashless future.

![Image 1](https://en.arageek.com/_next/image?url=https%3A%2F%2Fcdn.arageek.com%2Fen-magazine%2FTemplate-1-1-825x1024.png&w=3840&q=75)

_Anand Nagaraj_ is a prominent figure in the MENA fintech landscape, renowned for his innovative contributions to SME financing. He co-founded _[Invoice Bazaar](https://invoicebazaar.com/)_ in 2016, a Dubai-based supply chain finance platform that facilitated early receivables for underserved SMEs, enhancing their working capital. The platform's success led to its acquisition by _Triterras_ in May 2021.

In February 2024, _Nagaraj_ launched _[CredibleX](https://crediblex.io/)_, an embedded finance platform designed to provide instant lending solutions to SMEs through partnerships with businesses. Under his leadership, _CredibleX_ secured a **$55 million** seed round to expand its services, aiming to empower SMEs across the MENA region.

Before his entrepreneurial ventures, _Nagaraj_ held significant roles in the banking sector, including Senior Vice President at _[Citi](https://www.citi.com/)'s Commercial Banking_ division in the Middle East and Assistant Vice President at _[ICICI Bank](https://www.icicibank.com/)_. His extensive experience in banking and fintech has been instrumental in addressing the financing challenges faced by SMEs in the region.

![Image 2](https://en.arageek.com/_next/image?url=https%3A%2F%2Fcdn.arageek.com%2Fen-magazine%2FTemplate-2-2-825x1024.png&w=3840&q=75)

_Mounir Nakhla_ is a pioneering Egyptian entrepreneur renowned for advancing financial inclusion in the MENA region. He co-founded _[MNT-Halan](https://mnt-halan.com/)_ in 2018, a fintech ecosystem offering services such as microloans, consumer finance, and digital payments to unbanked and underbanked populations. Under his leadership, _MNT-Halan_ became **Egypt's first private tech firm to surpass a $1 billion valuation**, marking it as **Africa's first unicorn in 2023**.

Before _MNT-Halan_, _Nakhla_ founded several microfinance ventures. In 2009, he established _[Mashroey](https://mashroey.com/)_, an asset-based microfinance company providing financing for utility vehicles and later expanding to electronics and affordable housing. In 2015, he launched _[Tasaheel](https://tasaheelfinance.com/)_, focusing on microloans for skilled working women. Both companies have significantly contributed to financial inclusion in Egypt.

![Image 3](https://en.arageek.com/_next/image?url=https%3A%2F%2Fcdn.arageek.com%2Fen-magazine%2FTemplate-3-2-825x1024.png&w=3840&q=75)

_Soulaimane Lahrech_ is a Moroccan entrepreneur specializing in data technologies and artificial intelligence (AI). He is the Founding Partner and Chief Operating Officer at _[AIOX Labs](https://www.aiox-labs.com/)_, an AI studio and venture builder dedicated to leveraging data science to address critical business challenges.

In December 2022, _Lahrech_ founded _[Talaty](https://www.talatypay.com/)_, where he serves as Chief Executive Officer. _Talaty_ utilizes deep AI-powered behavioral finance models to provide instant loans for small and medium-sized businesses, aiming to reduce costs and default rates.

Lahrech's career includes co-founding _[Akumen IA](https://en.akumenia.com/)_, a joint venture between _[Valyans Consulting](https://www.valyans.com/)_ and _AIOX Labs_, specializing in artificial intelligence and big data solutions. He has also served as an advisor for startups like _[Deepecho](https://deepecho.io/)_ and _[ToumAI](https://www.toumai-voice-analytics.com/)_, focusing on AI applications in medical imaging and speech-to-insight technologies, respectively.

His academic background includes studies at the _London School of Economics and Political Science_, where he earned a Master of Science in Development. Through his ventures, Lahrech is at the forefront of integrating AI and data science into business solutions, contributing significantly to technological innovation in the MENA region.

![Image 4](https://en.arageek.com/_next/image?url=htt

*[... truncated, 17,129 more characters]*

---

### Connecting Africa Podcast: S3 Ep. 6 - Building next-gen payment systems
*2,860 words* | Source: **EXA** | [Link](https://www.connectingafrica.com/financial-inclusion/connecting-africa-podcast-s3-ep-6-building-next-gen-payment-systems)

Connecting Africa Podcast: S3 Ep. 6 - Building next-gen payment systems

===============

Connecting Africa is part of the Informa Connect Division of Informa PLC

[Informa PLC](https://informa.com/ "Informa PLC")|[ABOUT US](https://informa.com/about-us/ "ABOUT US")|[INVESTOR RELATIONS](https://informa.com/Investors/ "INVESTOR RELATIONS")|[TALENT](https://informa.com/Talent/ "TALENT")

This site is operated by a business or businesses owned by Informa PLC and all copyright resides with them. Informa PLC's registered office is 5 Howick Place, London SW1P 1WG. Registered in England and Wales. Number 8860726.

![Image 3](blob:http://localhost/88486f41f63c8d090d5605f786e1c2d2)

[Events](https://www.connectingafrica.com/events)[Podcasts](https://www.connectingafrica.com/podcasts)[About Us](https://www.connectingafrica.com/about-us)[Advertise with Us](https://get.knect365.com/connecting-africa-digital-opportunities/?utm_source=Connecting+Africa+Website&utm_medium=Top+website+CTA&utm_campaign=2024+DDG+Acquisition&_gl=1*1jegoct*_gcl_au*MTk0NTIyODA1MC4xNzE4OTg3MTMz)

[![Image 4: Your logo](https://eu-images.contentstack.com/v3/assets/blta47798dd33129a0c/blt85a4eec1580c5a65/66fae0a9b162c5985da36781/Logo_-_Connecting_Africa.svg?width=476&auto=webp&quality=80&disable=upscale)](https://www.connectingafrica.com/)

[Stay Updated](https://ca-resources.connectingafrica.com/free/w_defa4989/prgm.cgi?a=1)

[](https://x.com/connect__africa)[](https://www.linkedin.com/company/connecting-africa-news/)[](https://www.facebook.com/ConnectingAfricaSeries)[](https://www.youtube.com/@ConnectingAfrica)[](https://www.instagram.com/connectingafrica_/)[](https://www.connectingafrica.com/rss.xml)

[Stay Updated](https://ca-resources.connectingafrica.com/free/w_defa4989/prgm.cgi?a=1)

Connectivity

#### Related Topics

*   [Broadband](https://www.connectingafrica.com/connectivity/broadband)
*   [Cloud Networking](https://www.connectingafrica.com/connectivity/cloud-networking)
*   [Data Centers](https://www.connectingafrica.com/connectivity/data-centers)

*   [4G Networks](https://www.connectingafrica.com/connectivity/4g-networks)
*   [5G Networks](https://www.connectingafrica.com/connectivity/5g-networks)
*   [Fiber Networking](https://www.connectingafrica.com/connectivity/fiber-networking)

#### Recent in[Connectivity](https://www.connectingafrica.com/connectivity)

[See All](https://www.connectingafrica.com/connectivity)

[![Image 5: 5G logo on blue background](https://eu-images.contentstack.com/v3/assets/blta47798dd33129a0c/blta0182894a5cac67f/6932a65e11c06330d17c32ee/5G_logo_image_(1)_(1)_(1)_(1).jpg?width=1280&auto=webp&quality=80&disable=upscale)](https://www.connectingafrica.com/5g-networks/algeria-launches-5g-rollout)[5G Networks](https://www.connectingafrica.com/connectivity/5g-networks)

[Algeria launches 5G rollout](https://www.connectingafrica.com/5g-networks/algeria-launches-5g-rollout)[Algeria launches 5G rollout](https://www.connectingafrica.com/5g-networks/algeria-launches-5g-rollout)

by[Matshepo Sehloho](https://www.connectingafrica.com/author/matshepo-sehloho)

Dec 5, 2025

2 Min Read

[![Image 6: Kenyan man using a laptop inside a warehouse showing stacked bags of grain behind him. ](https://eu-images.contentstack.com/v3/assets/blta47798dd33129a0c/bltc5ef37c242aad8fb/69317f14d5794c1cb92fd3a6/Kenya_Internet_image_from_Microsoft_(1).jpg?width=1280&auto=webp&quality=80&disable=upscale)](https://www.connectingafrica.com/digital-inclusion/microsoft-exceeds-connectivity-target-connecting-117m-africans)[Digital Inclusion](https://www.connectingafrica.com/digital-inclusion)

[Microsoft exceeds connectivity target, connecting 117M Africans](https://www.connectingafrica.com/digital-inclusion/microsoft-exceeds-connectivity-target-connecting-117m-africans)[Microsoft exceeds connectivity target, connecting 117M Africans](https://www.connectingafrica.com/digital-inclusion/microsoft-exceeds-connectivity-target-connecting-117m-africans)

by[Eden Harris](https://www.connectingafrica.com/author/eden-harris)

Dec 4, 2025

4 Min Read

Enterprise Networking

#### Related Topics

*   [Enterprise Technology](https://www.connectingafrica.com/enterprise-networking/enterprise-technology)
*   [Cybersecurity](https://www.connectingafrica.com/enterprise-networking/cybersecurity)
*   [Partnerships](https://www.connectingafrica.com/enterprise-networking/partnerships)

*   [Regulation](https://www.connectingafrica.com/enterprise-networking/regulation)
*   [Investment](https://www.connectingafrica.com/enterprise-networking/investment)
*   [eCommerce](https://www.connectingafrica.com/enterprise-networking/ecommerce)

#### Recent in[Enterprise Networking](https://www.connectingafrica.com/enterprise-networking)

[See All](https://www.connectingafrica.com/enterprise-networking)

[![Image 7: 5G logo on blue background](https://eu-images.contentstack.com/v3/assets/blta47798dd33129a0c/blta0182894a5cac67f/6932a65e11c06330d17c32ee/5G_logo_image_(1)_(1)_(1)_(1).jp

*[... truncated, 36,222 more characters]*

---

### Nassreddine Riahi, CEO of the Franco-Tunisian start-up Cynoia : “The investment climate in Algeria has improved”.
*1,692 words* | Source: **EXA** | [Link](https://africa-news-agency.com/nassreddine-riahi-ceo-of-the-franco-tunisian-startt-up-cynoia-the-investment-climate-in-algeria-has-improved/)

Nassreddine Riahi, CEO of the Franco-Tunisian start-up Cynoia : “The investment climate in Algeria has improved”. - Africa News Agency

===============

 lundi, 8 décembre 2025

**ANA NEWS**
*   [Aérien : Royal Air Maroc lance la première liaison directe Afrique–côte Pacifique vers Los Angeles](https://africa-news-agency.com/aerien-royal-air-maroc-lance-la-premiere-liaison-directe-afrique-cote-pacifique-vers-los-angeles/)
*   [Air : Royal Air Maroc opens first direct Africa–Pacific Coast route to Los Angeles](https://africa-news-agency.com/air-royal-air-maroc-opens-first-direct-africa-pacific-coast-route-to-los-angeles/)
*   [Indice mondial de compétitivité des talents 2025: Maurice leader continental](https://africa-news-agency.com/indice-mondial-de-competitivite-des-talents-2025-maurice-leader-continental/)
*   [2025 Global Talent Competitiveness Index :Mauritius tops continental talent competitiveness](https://africa-news-agency.com/2025-global-talent-competitiveness-index-mauritius-tops-continental-talent-competitiveness/)
*   [Égypte : 15,6 millions de visiteurs entre janvier et octobre 2025](https://africa-news-agency.com/egypte-156-millions-de-visiteurs-entre-janvier-et-octobre-2025/)
*   [Egypt : 15.6 million tourists from Jan to Oct 2025](https://africa-news-agency.com/egypt-15-6-million-tourists-from-jan-to-oct-2025/)
*   [Tunisie : lancement de RISE AFRICA 50 pour valoriser la jeunesse entrepreneuriale](https://africa-news-agency.com/tunisie-lancement-de-rise-africa-50-pour-valoriser-la-jeunesse-entrepreneuriale/)
*   [Tunisia : launch of RISE AFRICA 50 to celebrate african youth entrepreneurs](https://africa-news-agency.com/tunisia-launch-of-rise-africa-50-to-celebrate-african-youth-entrepreneurs/)
*   [Ghana : Sommet de la diaspora 2025 les 19–20 décembre 2025](https://africa-news-agency.com/ghana-sommet-de-la-diaspora-2025-les-19-20-decembre-2025/)
*   [Ghana : 2025 diaspora summit 19–20 december 2025)](https://africa-news-agency.com/ghana-2025-diaspora-summit-19-20-december-2025/)
*   [Botswana : accord de 5,5 Mds$ avec Ulsan pour moderniser Morupule et développer de nouvelles capacités](https://africa-news-agency.com/botswana-accord-de-55-mds-avec-ulsan-pour-moderniser-morupule-et-developper-de-nouvelles-capacites/)
*   [Botswana : 5.5bn$ MoU with Ulsan to upgrade Morupule and add clean energy capacity](https://africa-news-agency.com/botswana-5-5bn-mou-with-ulsan-to-upgrade-morupule-and-add-clean-energy-capacity/)
*   [Cabo Verde : La BAD approuve 17,71 M€ pour la 2e phase de gouvernance numérique](https://africa-news-agency.com/cabo-verde-la-bad-approuve-1771-me-pour-la-2e-phase-de-gouvernance-numerique/)
*   [Cabo Verde : AfDB approves €17.71m for Phase II of digital governance](https://africa-news-agency.com/cabo-verde-afdb-approves-e17-71m-for-phase-ii-of-digital-governance/)
*   [Kenya : USA-Kenya $2.5B Health Agreement Signed](https://africa-news-agency.com/kenya-usa-kenya-2-5b-health-agreement-signed/)
*   [Kenya : Signature d’un accord santé USA-Kenya de 2,5 milliards $](https://africa-news-agency.com/kenya-signature-dun-accord-sante-usa-kenya-de-25-milliards/)
*   [Guinée : Départ historique du premier chargement commercial de minerai de fer de Simandou](https://africa-news-agency.com/guinee-depart-historique-du-premier-chargement-commercial-de-minerai-de-fer-de-simandou/)
*   [Guinea : Historic Departure of First Commercial Iron Ore Shipment from Simandou](https://africa-news-agency.com/guinea-historic-departure-of-first-commercial-iron-ore-shipment-from-simandou/)
*   [Afrique orientale et australe : Les IDE atteignent un record en 2024 (Rapport CNUCED)](https://africa-news-agency.com/afrique-orientale-et-australe-les-ide-atteignent-un-record-en-2024-rapport-cnuced/)
*   [Eastern and Southern Africa : FDI hits record level in 2024 (UNCTAD report)](https://africa-news-agency.com/eastern-and-southern-africa-fdi-hits-record-level-in-2024-unctad-report/)

*   [Menu](https://africa-news-agency.com/nassreddine-riahi-ceo-of-the-franco-tunisian-startt-up-cynoia-the-investment-climate-in-algeria-has-improved/#)

[![Image 4: ANA](https://africa-news-agency.com/wp-content/uploads/2025/01/ANA-Logo-p-removebg-preview.png)![Image 5: ANA](https://africa-news-agency.com/wp-content/uploads/2025/01/ANA-Logo-p-removebg-blanc.png)](https://africa-news-agency.com/ "ANA")

*   [Rechercher](https://africa-news-agency.com/nassreddine-riahi-ceo-of-the-franco-tunisian-startt-up-cynoia-the-investment-climate-in-algeria-has-improved/#)
*   [Switch skin](https://africa-news-agency.com/nassreddine-riahi-ceo-of-the-franco-tunisian-startt-up-cynoia-the-investment-climate-in-algeria-has-improved/# "Switch skin")
*   [Voir votre panier](https://africa-news-agency.com/panier/ "Voir votre panier") Votre panier est actuellement vide. [Aller au magasin](https://africa-news-agency.com/boutique/)   

[![Image 6](https://africa-news-agency.com/wp-content/uploads/2025/11/ANA-2026-V2-1.png)](https://africa-news-agency.com/

*[... truncated, 20,737 more characters]*

---

### Court - Online Justice now available in Canada
*2,176 words* | Source: **GOOGLE** | [Link](https://e-court.ca/how_it_works/civil_cases.php)

e-Court - Online Justice now available in Canada

===============

[How It Works-Civil Laws](https://e-court.ca/how_it_works/index.html)
=====================================================================

[![Image 1: envelope](https://e-court.ca/images/overview9.jpg)](https://e-court.ca/Landing-Page2/with_colorpicker/landing.html)[![Image 2: envelope](https://e-court.ca/images/overview11.jpg)](https://e-court.ca/registration/login.php)

    *   [ABOUT US](https://e-court.ca/about/index.php)
        *   [INTRODUCTION](https://e-court.ca/about/index.php)
        *   [Benefits](https://e-court.ca/about/benefits.php)
        *   [Scope - Legal](https://e-court.ca/about/scope.php)
        *   [Directorate](https://e-court.ca/about/directorate.php)
        *   [Supervisory](https://e-court.ca/about/supervisory-board.php)
        *   [Advisory Council](https://e-court.ca/about/committee_of_recommendation.php)
        *   [Origin - Partners](https://e-court.ca/about/originating_partners.php)
        *   [e-Court & ADR](https://e-court.ca/about/partners5.php)
        *   [Articles](https://e-court.ca/about/general_conditions.php)
        *   [Privacy](https://e-court.ca/about/privacy.php)
        *   [Legal Info](https://e-court.ca/about/legal.php)
        *   [Copyright](https://e-court.ca/about/copyright.php)
        *   [In the News](https://e-court.ca/about/in_the_news.php)
        *   [e-Court vs.ADR](https://e-court.ca/about/ADR-ECOURT.php)
        *   [](https://e-court.ca/about/index.php)

    *   [HOW](https://e-court.ca/how_it_works/index.php)
        *   [INTRODUCTION](https://e-court.ca/how_it_works/index.php)
        *   [Small Claims](https://e-court.ca/how_it_works/smallclaims.php)
        *   [How it works](https://e-court.ca/how_it_works/how.php)
        *   [Civil Law](https://e-court.ca/how_it_works/civil_cases.php)
        *   [Standard](https://e-court.ca/how_it_works/standard_procedure.php)
        *   [Appeals](https://e-court.ca/how_it_works/appeal_process.php)
        *   [Hearings](https://e-court.ca/hearings/index.php)
        *   [Legally binding](https://e-court.ca/how_it_works/a_real_sentence.php)
        *   [Membership](https://e-court.ca/how_it_works/member_of_e-Court.php)
        *   [Join us](https://e-court.ca/how_it_works/join.php)
        *   [Regulations](https://e-court.ca/how_it_works/regulation.php)
        *   [Find Arbitrator](https://e-court.ca/how_it_works/FindaLawyer5.php)
        *   [](https://e-court.ca/how_it_works/index.php)

    *   [ARBITRATION](https://e-court.ca/find_a_lawyer/index.php)
        *   [INTRODUCTION](https://e-court.ca/find_a_lawyer/index.php)
        *   [Ethics](https://e-court.ca/EthicalPrinciples.pdf)
        *   [Profiles](https://e-court.ca/find_a_lawyer/profiles.php)
        *   [Selection](https://e-court.ca/find_a_lawyer/selectionboard.php)
        *   [Procedures](https://e-court.ca/find_a_lawyer/selectionprocedures.php)
        *   [FIRST CHOICE](https://e-court.ca/find_a_lawyer/first-choice.php)
        *   [Find Arbitrator](https://e-court.ca/how_it_works/FindaLawyer5.php)
        *   [](https://e-court.ca/find_a_lawyer/index.php)

    *   [COSTS](https://e-court.ca/costs/index.php)
        *   [INTRODUCTION](https://e-court.ca/costs/index.php)
        *   [Membership](https://e-court.ca/costs/membership5.php)
        *   [Court Fees](https://e-court.ca/costs/court_fee.php)
        *   [Escrow](https://e-court.ca/costs/escrow5.php)
        *   [Hearing Costs](https://e-court.ca/costs/costs_hearings.php)
        *   [Attestation](https://e-court.ca/costs/attestations.php)
        *   [Extra Judicial](https://e-court.ca/costs/extrajudicial.php)
        *   [Judicial](https://e-court.ca/costs/judicial.php)
        *   [Other](https://e-court.ca/costs/other.php)
        *   [](https://e-court.ca/costs/index.php)

    *   [REGISTER](https://e-court.ca/registration/index.php)
        *   [INTRODUCTION](https://e-court.ca/registration/index.php)
        *   [Member](https://e-court.ca/registration/member_of_e-Court.php)
        *   [REGISTRATION](https://e-court.ca/registration/register.php)
        *   [FAQ](https://e-court.ca/faq/index.php)
            *   [INTRODUCTION](https://e-court.ca/faq/index.php)
            *   [Quick Answers](https://e-court.ca/about/Preliminary5.php)
            *   [Bench Lawyers](https://e-court.ca/faq/benchlawyers.php)
            *   [Arbitrators](https://e-court.ca/faq/lawyers.php)
            *   [Notaries](https://e-court.ca/faq/notaries.php)
            *   [Insurance Co's](https://e-court.ca/faq/insurancecompanies.php)
            *   [Companies](https://e-court.ca/faq/companies.php)
            *   [Private](https://e-court.ca/faq/privateindividuals.php)
            *   [Bailiffs](https://e-court.ca/faq/bailiffs.php)
            *   [Security](https://e-court.ca/faq/security5.php)
            *   [](https://e-court.ca/faq/index.php)

        *   [Demo's](https://e-court.ca/StartYourDossier.html)
    

*[... truncated, 19,048 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[e-Court - Online Justice now available in Canada](https://e-court.ca/how_it_works/civil_cases.php)**
  - Source: e-court.ca
  - *Tahar Ali-Yahia Founder, Corporate Leadership NexGedia Enterprise; Anthony ... ** | Blog ** | Facebook ** Linkedin ** | Twitter **. Address:Ottawa ......*

- **[Untitled](https://cdn2.f-cdn.com/files/download/202228087/Project.xlsx)**
  - Source: cdn2.f-cdn.com
  - *NexGedia Enterprise, Tahar, Ali-Yahia, Montreal, Founder, taliyahia@nexgedia.com, https://www.linkedin.com/in/tahar-ali-yahia-3812aa/ ... brad.clark@a...*

---

*Generated by Founder Scraper*
