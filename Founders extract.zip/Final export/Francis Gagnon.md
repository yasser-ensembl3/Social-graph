# Francis Gagnon

## Position actuelle

**Titre** : Founder
**Entreprise** : Voilà Information Design
**Durée dans le rôle** : 12 years 2 months in role
**Durée dans l'entreprise** : 12 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Information Services

## Description du rôle

Voilà: is an information design firm. We combine analysis and design to convey complex information visually. We care about sustainable development, climate change, gender equality, social development, transparency, diversity and inclusion.

## Résumé

Founder of Voilà:, Francis Gagnon shares with his clients his experience and training that combine analysis and design.

Francis worked and studied in four countries on two continents. He holds a master's degree in political science from Université Laval (Quebec City) and a master's degree in Development Studies from the London School of Economics. He worked in Geneva, Switzerland, teaching diplomats from developing countries about international economics. In Washington D.C., he worked at the World Bank Group to establish partnerships for the sustainable development of the private sector in emerging markets, and then as a business intelligence officer managing and designing analytical reports. He's a member of the Quebec Association of Economists.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAA71WwBKGYid4sOWcpn_qwbhcNpWyVw7dw/
**Connexions partagées** : 14


---

# Francis Gagnon

## Position actuelle

**Entreprise** : Voilà:

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Francis Gagnon

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402047132842483712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFIWhK8TGJtlw/feedshare-shrink_800/B4EZrlaoE_KkAg-/0/1764785556670?e=1766620800&v=beta&t=wlP3cfB_wRwviV16tRle25O1ZTpvPvnzQjR9Rmwv168 | J'ai donné une formation sur la visualisation de données 📊 pour la Factry à Radio-Canada et j'ai rencontré une célébrité: Les noces de juin, de Jean-Paul Lemieux. Je n'arrive toujours pas à croire qu'ils avaient l'original dans la salle de réunion. | 35 | 0 | 0 | 4d | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:50.126Z |  | 2025-12-03T18:12:39.855Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397239218172801024 | Article |  |  | It's finally online. | 30 | 2 | 1 | 2w | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:50.126Z |  | 2025-11-20T11:47:43.671Z | https://www.youtube.com/watch?v=HuaznmqXnhU |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395484387376791552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEonXXZYIShrA/feedshare-shrink_800/B4EZp6FdeHHUAg-/0/1762984848212?e=1766620800&v=beta&t=o2ewKB9Nb_LN3fNkFF0rjpn0oRaVcUfmfgw3Ld0vnv8 | Sport brands elevate athletes to heroic levels: Nike with Serena Williams and Michael Jordan, Adidas with Lionel Messi, for instance.

Increasingly, this is how I think of Voilà:'s relationship to its clients: they are the heroes that are changing the world for the better and our role is to elevate them, to help them achieve or replicate their success.

This project is a great example, with Nature Conservancy of Canada/Conservation de la nature Canada and Dr Michael Proctor doing real work to restore biodiversity and the grizzly population. Our role is to help them show that conservation truly works, so that more of these initiatives are funded and implemented, making our world better one project at a time.

#biodiversity #informationdesign #natureconservancy | 2 | 0 | 0 | 3w | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:50.127Z |  | 2025-11-15T15:34:39.406Z | https://www.linkedin.com/feed/update/urn:li:activity:7394720758620536833/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7388725119730282496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFeNYzTcGZgfQ/feedshare-shrink_800/B4EZndngk4KcAk-/0/1760359746882?e=1766620800&v=beta&t=cio-ZwHhRnjYrydKS6G_dUfSlmwx9pEKG_oT8n9TMiE | I want to carefully manage expectations because this invitation is a tall order, but I'm truly honoured to be a speaker at this event. 

First, On Data And Design is a prestigious and successful community for data visualisation specialists and information designers. This is their 31st event and they had a string of the most admired people in the business. I can't wait to hear Pei Ying Loh and Jose Duarte.

Second, the topic (Hope) is something I really want to talk about these days. I strongly, strongly believe that it is a responsibility, to hope. And we have opportunities to help people hope.

It's this Wednesday at 6 pm CET (Zurich) and 1 pm EDT (Montreal).
👉 https://lnkd.in/exdDUieU | 9 | 1 | 0 | 1mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:50.127Z |  | 2025-10-27T23:55:44.418Z | https://www.linkedin.com/feed/update/urn:li:activity:7383483932073443328/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7385297929101824000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE0sZemk63dwQ/feedshare-shrink_800/B4EZn3ZOrqKgAk-/0/1760792217968?e=1766620800&v=beta&t=qJwK2o0u7wJdeoWBDxt8UF4UHNiuuRAy1seSWv-xGYY | I post mostly as an information designer but I’m also an entrepreneur. 

And it’s something I need to keep learning again and again. That’s why I just spent two days at an intensive training about decision-making at the École d'Entrepreneurship de Beauce as part of the Parcours Novaré.

I was reminded how much entrepreneurship is both an individual and collective adventure. 

Individual because the decisions are yours in the end, and the consequences that come with it. Sometimes it’s good, sometimes less so. It’s a privilege and a burden. 

Collective because people depend on you and fuel that adventure. How could you be an entrepreneur without a team? Without clients? Without partners? It is jumping into the fabric of the economy, of society even and attempting to become one of the connecting pieces. 

And collective too through the shared experiences of other entrepreneurs, which is what these two days were all about. 

Kudos to the Ecole for giving us so many opportunities to have structured, meaningful conversations between ourselves. | 62 | 1 | 0 | 1mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:50.128Z |  | 2025-10-18T12:57:18.498Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7356689966028005378 | Document |  |  | 🇫🇷  De la nouvelle chez Voilà: ! Très très content de voir Andrea se joindre à l'équipe. 
 🇬🇧 Very happy to report on the latest hire at Voilà: ! | 17 | 0 | 0 | 4mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.394Z |  | 2025-07-31T14:19:28.591Z | https://www.linkedin.com/feed/update/urn:li:activity:7356685065923268608/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7342175388824969216 | Article |  |  | Data visualization can change the world.

The warming stripes are proof.

No labels. No axes. Just color. And yet they’ve cut through the noise—making climate change visible, urgent, and impossible to ignore.

This is the power of clear, bold design.

What can we learn from their success?
At Voilà:, we spoke to one of their authors and wrote about it.

https://lnkd.in/eSV_KXUA | 19 | 12 | 3 | 5mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.395Z |  | 2025-06-21T13:03:43.718Z | https://chezvoila.com/blog/warmingstripes/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7336355993372557312 | Document |  |  | C'est notre première ouverture de poste en design graphique en quatre ans. Une rare chance à saisir pour joindre notre équipe. 🧑‍🎨 | 10 | 0 | 2 | 6mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.395Z |  | 2025-06-05T11:39:31.723Z | https://www.linkedin.com/feed/update/urn:li:activity:7336077059909210113/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7335989259947978754 | Article |  |  | One of the most fun part of winning an Information is Beautiful Award was the controversy that ensued. Looks like it has some enduring power! Andy Cotgreave has the right take.

https://lnkd.in/e5NDBFJk | 10 | 1 | 0 | 6mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.396Z |  | 2025-06-04T11:22:15.661Z | https://nightingaledvs.com/business-dashboard-designers-learn-from-iib/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7330741520129531906 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFJ8rrWT_Axzg/feedshare-shrink_800/B56Zbv4R22G4Ak-/0/1747781230371?e=1766620800&v=beta&t=lHDK7zoN89uOP31rb4QNZN50NWwUv0iKcVWbK8YF0ws | Quel bonheur de voir apparaître dans mon fil les graphiques de Voilà:. 📊

Le travail du Canadian Climate Institute / Institut climatique du Canada est fondamental pour comprendre l’impact que les changements climatiques auront sur nous et comment s’y préparer. 

Ce ne sont pas des rapports pour les tablettes, mais bien pour les médias sociaux, les conférences, les médias, le grand public et les espaces décisionnels. 

Merci Blaise de leur donner une voix. | 14 | 1 | 0 | 6mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.397Z |  | 2025-05-20T23:49:36.990Z | https://www.linkedin.com/feed/update/urn:li:activity:7330725812532326400/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7323778538573107200 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGNmnoeo-0wQg/feedshare-shrink_800/B56ZaNC3YHGoAk-/0/1746123061152?e=1766620800&v=beta&t=90HsSkoEtQAH5qxJY_O_BUTAquSXxDAx7-gSAQig4OI | I have seen charts "unlocked" just by changing the order in which it is presented. They become clarifying and useful.

Alphabetical order should be your last resort. It only does only one thing: help you find a category slightly faster. But using the "order of performance" for your chart will show:

- Who's at the top
- Who's at the bottom
- Who's similar or comparable
- Where the drop-off is (if any)
- What the distribution looks like

All this work is now done by the chart, instead of your audience, who are free to take the analysis further, or just spend less time looking at it.

#dataviz #dataviztips | 11 | 4 | 1 | 7mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.399Z |  | 2025-05-01T18:41:12.821Z | https://www.linkedin.com/feed/update/urn:li:activity:7323770942323654658/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7322636739905294337 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEcDgk7iVslCQ/feedshare-shrink_800/B4EZZ8xjwGHoAg-/0/1745850088946?e=1766620800&v=beta&t=ed8ReydOQBPeMPbzJqiNfE4cHva3HNKoPwViGkm31-0 | Ça fait deux ans que je vais au Sommet et j'y serai encore cette année. C'est LE rendez-vous annuel pour la communauté climatique de Montréal. J'y ai rencontré plein de gens avec qui j'ai ensuite gardé un lien et lancé des collaborations. Un très bon investissement de temps et d'argent. #SommetClimatMtl25 | 3 | 0 | 0 | 7mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.400Z |  | 2025-04-28T15:04:06.805Z | https://www.linkedin.com/feed/update/urn:li:activity:7322626015174823936/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7318752612269391873 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2RKtuVhR2Zg/feedshare-shrink_800/B4EZZE0TFHHYAg-/0/1744911284410?e=1766620800&v=beta&t=4SenU2BfP0RZINMJCe49YhiWc9Lnn5AZTIbMGAFbyiM | A "best of the web" award for this Voilà: project! ✨ The prestigious Webby Awards just made it official. 🏅 

The heat pump calculator is one of our most fun and best looking interactives, not an obvious task with so much technical data. I'm glad it has already received multiple recognitions.

Bravo to the team members!
Patricia A. | Marie-Blanche Rossi | Mathieu Grégoire | Jessie Cabot-King | Joey Cherdarchuk

#dataviz #webbyawards #heatpumps | 28 | 6 | 1 | 7mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.401Z |  | 2025-04-17T21:49:58.613Z | https://www.linkedin.com/feed/update/urn:li:activity:7318688383071891456/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7313567594182041600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHD_eKCqbCrWA/feedshare-shrink_800/B4EZX8C.MjGgBE-/0/1743690392696?e=1766620800&v=beta&t=0m0BCrtO1JAzuWWOBvp-T2xXoGhyuveELQJtQJXyDEU | Want to know my secrets to find good dataviz? One of them is the (free) monthly newsletter by Andy Kirk. He covers a very wide range of topics, regions, chart types, sources, etc. You have to subscribe to receive it two weeks before they are made public.

Find it here ➡️ https://lnkd.in/efFGQ5xS

I mention it today because we just made the list with a presentation of our charts for the landmark report by the Canadian Climate Institute / Institut climatique du Canada. It's quite an honour.

Here is the Bluesky thread with the charts ➡️ https://lnkd.in/e_ETeN3e

Thank you Andy for the hard work! | 18 | 0 | 0 | 8mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.402Z |  | 2025-04-03T14:26:33.968Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7312808488714293248 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF1rUOyd8bHmA/feedshare-shrink_800/B4EZXxQkN2HcAg-/0/1743509408232?e=1766620800&v=beta&t=JVEA6X0JKJrARWpNjW6zA8Ir5PTO35tXiQPE2_T_JHA | 🗺️ If you like maps, if you like urban design, you'll love these fascinating maps of the 15-minute cities. How far are your on foot from food, supplies, education, physical exercice, etc?

There are 10,000 cities in there.

Go find yours. ➡️ https://lnkd.in/egyvpPe8 | 719 | 29 | 50 | 8mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.402Z |  | 2025-04-01T12:10:09.121Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7310012797583540224 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFWvb64oV2VxQ/feedshare-shrink_800/B56ZXJPp43GUAg-/0/1742838079435?e=1766620800&v=beta&t=xtNbIRHGAy1tfQZIxscvdKLEXtQlReJOFFkeWVLib0Y | Always use horizontal text in your charts.
Always? Always.

Why? 

Because there is room for longer labels.
Because vertical text takes twice as long to read.
Because we read horizontal text fast and even automatically.

Most important:
--->>> Because our eyes skip over vertical and slanted text. <<<---

Show me a chart with vertical text and I'll show you how to make it horizontal.

#dataviztips #dataviz #datavisualization | 41 | 4 | 2 | 8mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.403Z |  | 2025-03-24T19:01:04.414Z | https://www.linkedin.com/feed/update/urn:li:activity:7309992734553952257/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7308275198795939840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGNpIhWeTNggw/feedshare-shrink_800/B4EZWw1glBHUAo-/0/1742428574859?e=1766620800&v=beta&t=hx4YOzcI2IfPtWIKljLtTWmT76XKfuXE9a2oPjMXaQA | A rare visit to Ottawa this week to deliver a data visualization training at the Library of Parliament. Quite a treat for a political science graduate and former employee of the Quebec National Assembly. A return to my roots, in a way. 

I also took the opportunity to visit another client, the Canadian Museum of Nature. It is simply magnificent. Such a treat to know that our work will be on display there in a few months. Stay tuned! 🐟 🦆 | 95 | 3 | 0 | 8mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.404Z |  | 2025-03-19T23:56:28.580Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7304173291567472640 | Text |  |  | Today, we think about the role that women leaders have played in our journey. To this long list, which probably skips over too many, I will add Masha Zhdanava, who expends much energy and patience in the shadows as a trusted advisor. Thank you! | 9 | 1 | 0 | 8mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.404Z |  | 2025-03-08T16:16:57.687Z | https://www.linkedin.com/feed/update/urn:li:activity:7304171932378148864/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7301832838121746444 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f8192d7b-c0c0-4505-9362-72db6f79a30d | https://media.licdn.com/dms/image/v2/D4E05AQE6pERvFRG2Ww/videocover-low/B4EZVB53UaHMCU-/0/1740567532991?e=1765782000&v=beta&t=mdamDQ_Bfw6Wu9qrM45ZXMIXWbpsdTyGyrUDrWvx_KM | I am generally not a big fan of dataviz on TV but this is above average and very relevant right now. | 146 | 8 | 17 | 9mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.405Z |  | 2025-03-02T05:16:50.102Z | https://www.linkedin.com/feed/update/urn:li:activity:7300469656371318786/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7296534164470714368 | Article |  |  | The most dangerous charts are the ones you agree with.

Because we don't question them. We lower our guard. We share them widely, we remember them, we repeat them.

If we disagree with a chart, then we suddenly become critical thinkers again. What about that axis? Is this the right period? What is the source of this data?

Approach all charts, even the ones that confirm your preferences, with a high level of skepticism.

This tool just published by Nathan Yau will help you.

#dataviz #dataliteracy #datavisualization #disinformation

https://lnkd.in/e2igAiJB | 49 | 4 | 4 | 9mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.406Z |  | 2025-02-15T14:21:47.859Z | https://flowingdata.com/projects/dishonest-charts/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7288227722458185728 | Document |  |  | An annual tradition at Voilà: our visualization of a year's work. ✨ 

From reports and presentations to dashboards and infographics, everything we create is in service of the environment, social development, and good governance.

This is a heartfelt THANK YOU to our clients.  You are the reason we exist, but even more importantly, you are what makes this world a little better. You make a difference.  🌏 ♻️ 📘 

Canadian Climate Institute / Institut climatique du Canada
Institute for Research on Public Policy (IRPP)
CPP Investments | Investissements RPC
Commissaire à la santé et au bien-être
Réseau de transport de Longueuil
Les Éditions Écosociété inc
Global Environment Facility
Éco Entreprises Québec
The World Bank Group
Arctic Eider Society
Adaptation Fund
Le Devoir
Factry
M361, Moteur de stratégies sociales
... and more! | 20 | 1 | 1 | 10mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.407Z |  | 2025-01-23T16:14:57.757Z | https://www.linkedin.com/feed/update/urn:li:activity:7288216097978273793/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7287866077500309504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGfEPMdwf59pQ/feedshare-shrink_800/B4EZSOzlA5HMAg-/0/1737562673579?e=1766620800&v=beta&t=ryfJ6Z57JaXW02Uhv0oKTvvO1pwv66OfsbMwjItEk_0 | I really like overlapping column charts like this to compare two years. To me, they seem easier to read than parallel columns. 📊

Source: The Outlier. https://lnkd.in/eExF-Fez | 24 | 4 | 0 | 10mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.407Z |  | 2025-01-22T16:17:54.880Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7285656997604032512 | Article |  |  | Such fantastic news. A former participant to our dataviz training has won a RESEARCH award for her creative use of data visualization.

Sandrine and her colleagues' work have taught me so much about what dataviz can accomplish, especially in the field of personal health. I wrote about it three years ago when I first became aware of her work.

Blog post >> "This dataviz has wings" https://lnkd.in/euWEKuMP | 8 | 0 | 0 | 10mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.408Z |  | 2025-01-16T13:59:49.190Z | https://arthritis.ca/about-us/what-we-do/research/top-10-research-advances-of-2024 |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7283479028164952064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFa24nqJi5T5g/feedshare-shrink_800/B4EZRPlRbEHEAg-/0/1736501959397?e=1766620800&v=beta&t=5pqvHsqEr5fSADP3EJU6BheCZDbg0KVo6qWJ-8S-7Gk | In my dataviz training, I ask those who have never seen the warming stripes below what this chart is about. They always get it right: climate change. 

But how? There are no axis, no numbers, no legend, no title, no text at all in fact.

There are two main reasons.

1. We associate blue with cold and red with warmth. 🔵 Blue is ice. 🔴 Red is fire. It's a hint that this chart shows temperature data.

2. We recognize the trend. Something changes fast towards the end. If it's temperature and it gets much hotter very fast, it matches what we know about climate change in our time. 📈 

Combine these two clues and it works: the warming stripes have become a global symbol of climate change. They've been on the cover of magazines, painted on walls and electric cars, used for clothes, and more.

-> There is a lesson there: your charts should strive to represent the underlying reality, not just the data in a generic way.

Very few people know the origin story of the warming stripes, so we wrote a blog post about it. 👇 

https://lnkd.in/eSV_KXUA | 30 | 5 | 1 | 10mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.409Z |  | 2025-01-10T13:45:20.811Z | https://www.linkedin.com/feed/update/urn:li:activity:7283417120938360832/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7274413261368750080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFQyMXZ0hmgw/feedshare-shrink_800/B4EZPPoTZsHwAk-/0/1734355272060?e=1766620800&v=beta&t=rPtgdXDpI9MYRE1hTDWhMubt1MBxr5T-MfNPj_zpyfw | I asked you last week if I should share dataviz tips on here. Your answer is very clear! 🌊  Thanks a lot for the comments and likes, which have sent it across the network.

Now, let's check the charts that LinkedIn produced about the post and see what we can learn from it.

-> Time period matters

What do we see in each of these charts?

7 days - The post is losing steam
14 days - It was a surge
28 days - These surges are rare
90 days - This post looks special
365 days - This post really stands out

Carefully choose the time period of your charts, depending on context and message!

#dataviz #dataviztips #voila #datavisualization | 28 | 2 | 0 | 11mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.409Z |  | 2024-12-16T13:21:13.573Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7271885195601969152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH4UJ4bAnU9Ow/feedshare-shrink_800/feedshare-shrink_800/0/1733752534291?e=1766620800&v=beta&t=gN0ETDjdalcIei6Oa77HGcfe91O9S58gcUI0T-wL_cU | I've been pondering using LinkedIn more to share dataviz tips, which I usually do on Bluesky. What do you think?

Like for instance, this chart from the Financial Times shows elegantly the decrease in days with sea ice in the Arctic. Why is it so elegant? 

-> Double encoding. 

The sea ice data is shown both through position and colour. Encoding the same data in two different ways automatically creates a pattern (here: white on the right, blue on the left) that is both aesthetic and clear, because it adds one more way to understand the data. Try it!

#dataviz #datavisualization #dataviztips #voila | 249 | 37 | 5 | 11mo | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.410Z |  | 2024-12-09T13:55:35.725Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7270517379690860544 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXtU0d-s9osg/feedshare-shrink_800/feedshare-shrink_800/0/1733172562394?e=1766620800&v=beta&t=K6dPVojW-OaZMQlz2_RRZ_0w16zvlTv4wYeXiAQkltY | This is  me holding two trophies because the team keeps on doing outstanding work and my job is to go get the trophies on their behalf. It's a busy job. | 50 | 10 | 0 | 1yr | Post | Francis Gagnon | https://www.linkedin.com/in/gagnonf | https://linkedin.com/in/gagnonf | 2025-12-08T06:20:55.411Z |  | 2024-12-05T19:20:22.999Z | https://www.linkedin.com/feed/update/urn:li:activity:7269704470878371841/ |  | 

---



---

# Francis Gagnon
*Voilà:*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 20 |

---

## 📚 Articles & Blog Posts

### [Francis Gagnon, Author at Voilà:](https://chezvoila.com/blog/author/francis/)
*2024-01-01*
- Category: blog

### [Francis Gagnon, Author at Voilà: - Page 2 of 8](https://chezvoila.com/blog/author/francis/page/2/)
*2024-01-01*
- Category: blog

### [Reflecting on “Citoyenneté 3.0 : L’aventure technopédagogique en milieu franco-ontarien”](https://ecampusontario.ca/reflecting-on-citoyennete-3-0-laventure-technopedagogique-en-milieu-franco-ontarien)
*2024-02-22*
- Category: article

### [Announcing Voilà](https://chezvoila.com/blog/voila/)
*2013-11-27*
- Category: blog

### [How we rebranded an information design firm](https://chezvoila.com/blog/voilabrand/)
*2020-03-04*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Episode #196: Francis Gagnon - PolicyViz](https://policyviz.com/podcast/episode-196-francis-gagnon/)**
  - Source: policyviz.com
  - *May 4, 2021 ... Francis Gagnon is the founder of Voilà:, an information design company specializing in sustainable development. In addition to leading...*

- **[Voilà: Francis Gagnon (@chezvoila@vis.social) - vis.social](https://vis.social/@chezvoila)**
  - Source: vis.social
  - *Voilà: Francis Gagnon @chezvoila@vis.social vis.social. Follow. Information designer from Montreal Founder of Voilà: (2013) Data visualization. Sustai...*

- **[Interview: Andy Kirk's favorite tweet and dataviz pick up lines - Voilà:](https://chezvoila.com/blog/andykirk/)**
  - Source: chezvoila.com
  - *Jul 28, 2014 ... Francis Gagnon is an information designer and the founder of Voilà: (2013), a data visualization agency specialized in sustainable de...*

- **[visualizing death — storytelling with data](https://www.storytellingwithdata.com/blog/2021/3/29/visualizing-death)**
  - Source: storytellingwithdata.com
  - *Mar 29, 2021 ... I sat in on an interesting conversation between Andy Kirk and Francis Gagnon on Clubhouse* last week about visualizing death. In addi...*

- **[2022 Retrospective - Voilà:](https://chezvoila.com/blog/retro2022/)**
  - Source: chezvoila.com
  - *Dec 31, 2022 ... Francis Gagnon is an information designer and the founder of Voilà: (2013), a data visualization agency specialized in sustainable de...*

- **[Miriam Quick on communicating sustainability data to hard-to-reach ...](https://infogr8.com/miriam-quick-communicating-sustainability-data-hard-to-reach-audiences/)**
  - Source: infogr8.com
  - *Jun 13, 2023 ... In our podcast Loud Numbers, Duncan Geere and I ... May it have a long (shelf) life! — Voilà: Francis Gagnon (@chezVoila) December 1,...*

- **[S3E9 Highlights - FRANCIS GAGNON - YouTube](https://www.youtube.com/watch?v=k2ticbHQybI)**
  - Source: youtube.com
  - *Sep 7, 2023 ... ... podcast series all about data visualisation design. In this ninth episode I am delighted to welcome Francis Gagnon, founder of 'Vo...*

- **[Balado - Carrières à l'Assemblée nationale du Québec](https://www.assnat.qc.ca/carrieres/fr/emplois/10-balado)**
  - Source: assnat.qc.ca
  - *Francis GAGNON, Chef d,équipe, captation ... Être une ou un témoin privilégié des débats et des décisions qui ont un effet direct sur la société québé...*

- **[A Stark Rendering of a Life Incomplete | by Allen Hillery | Medium](https://alglobehopper.medium.com/a-stark-rendering-of-a-life-incomplete-8166640cd418)**
  - Source: alglobehopper.medium.com
  - *Nov 4, 2021 ... Francis Gagnon, founder of Voilà, describes the work as very powerful. ... I told him how much I admired his work and wanted to interv...*

- **[Karim Douieb (@karimdouieb.bsky.social) — Bluesky](https://bsky.app/profile/karimdouieb.bsky.social)**
  - Source: bsky.app
  - *Give him a follow and read his interview: ... Great starting pack to (re)connect with the #dataviz community! ‪Voilà: Francis Gagnon‬ ‪@chezvoila.com‬...*

---

*Generated by Founder Scraper*
