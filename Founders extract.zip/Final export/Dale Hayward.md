# Dale Hayward

## Position actuelle

**Titre** : Co-Founder, Teacher
**Entreprise** : See Learn
**Durée dans le rôle** : 6 years 10 months in role
**Durée dans l'entreprise** : 6 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : E-Learning Providers

## Description du rôle

For years I have worked on productions from all aspects of the animation industry and now I'm sharing that knowledge with you through online courses and resources tailored to develop the best animators possible.

## Résumé

Stop motion has been my creative playground for two decades. In that time, I’ve worked as a director, producer, and educator, helping ideas move from sketchbook to screen.

As co-founder of See Creature Animation and See-Learn Academy, I’ve had the chance to collaborate on projects that range from indie shorts to global campaigns. 

Highlights include The Little Prince (Netflix), Kiri & Lou, Bone Mother (NFB), commercials for Nike and Hot Wheels, and co-directing CNESST’s Hanging by a Thread, which won Gold + Grand Prix at the Idéa Awards.

If there’s one thing I’ve learned, it’s this: great animation has a human touch, and stop motion brings that. Over the years, we’ve developed a production system that delivers handcrafted stop motion at competitive rates, often faster and more affordable than most people expect. That combination of authenticity and efficiency is what keeps clients coming back.

If you’re interested in animation that feels human, tactile, and unforgettable or want to learn how to produce it without losing your mind, let’s connect.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAKPhNkBtB_3PRfy-eEbm8y7FV4cQXQ1P18/
**Connexions partagées** : 6


---

# Dale Hayward

## Position actuelle

**Entreprise** : See Creature animation

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Dale Hayward
*See Creature animation*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Episode 235: Stop Motion Animator Dale Hayward On Perfectionism In Animation](https://podcasts.apple.com/ie/podcast/episode-235-stop-motion-animator-dale-hayward-on-perfectionism/id1450974754?i=1000636852260)
*2023-11-29*
- Category: podcast

### [Bone Mother: An Interview with Dale Hayward & Sylvie Trouvé](https://puppetplace.wordpress.com/2018/12/10/bone-mother-an-interview-with-dale-hayward-sylvie-trouve/)
*2018-12-10*
- Category: article

### [Podcast interview with ‘Bone Mother’ directors Sylvie Trouvé & Dale Hayward](https://skwigly.co.uk/podcast-bone-mother)
*2018-10-31*
- Category: podcast

### [Skwigly Animation Podcast #86 – Sylvie Trouvé & Dale Hayward - Animation Podcast](https://skwigly.co.uk/podcasts/skwigly-animation-podcast-86)
*2018-10-31*
- Category: podcast

### [Credits - Maura McHugh](https://splinister.com/about/credits/)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Interview with Dale Hayward and Sylvia Trouvé (Bone Mother ...](https://www.skwigly.co.uk/dale-hayward-sylvia-trouve-bone-mother/)**
  - Source: skwigly.co.uk
  - *Oct 31, 2018 ... ... Podcast (Direct download or listen below):. In this article: Dale HaywardNational Film Board of CanadaNFBSee Creature AnimationSy...*

- **[Podcast EP 235: Stop-Motion Animator Dale Hayward on ...](https://www.awn.com/news/podcast-ep-235-stop-motion-animator-dale-hayward-perfectionism-animation)**
  - Source: awn.com
  - *Nov 29, 2023 ... This episode features Montreal-based See Creature Animation Studio co-owner/stop-motion animator Dale Hayward. His credits include th...*

- **[Bone Mother – Maura McHugh](https://splinister.com/fiction/bone-mother/)**
  - Source: splinister.com
  - *... podcast publisher Pseudopod. I blogged ... It was adapted as a short stop-motion animated film by Sylvie Trouvé and Dale Hayward (See Creature ani...*

- **[The Animation Industry Podcast – Terry Ibele: Toronto Stop Motion ...](https://terryibele.com/animation-industry-podcast/)**
  - Source: terryibele.com
  - *This chat features renowned stop motion animator Dale Hayward, co-owner of See Creature Animation Studio in Montreal, Canada. His credits include the ...*

- **[Animation Industry Podcast 235: Stop Motion Animator Dale ...](https://www.youtube.com/watch?v=Jy2-OQin9sU)**
  - Source: youtube.com
  - *Nov 28, 2023 ... This chat features renowned stop motion animator Dale Hayward, co-owner of See Creature Animation Studio in Montreal, Canada....*

- **[stop-motion animation – Maura McHugh](https://splinister.com/tag/stop-motion-animation/)**
  - Source: splinister.com
  - *You can now watch the full short stop-motion animation of Bone Mother, created by Dale Hayward ... See Creature animation company in Canada. It's a lo...*

- **[Podcast interview with 'Bone Mother' directors Sylvie Trouvé & Dale ...](https://www.skwigly.co.uk/podcast-bone-mother/)**
  - Source: skwigly.co.uk
  - *Oct 31, 2018 ... Podcast interview with 'Bone Mother' directors Sylvie Trouvé & Dale Hayward ... Working together as See Creature Animation, Dale and ...*

- **[Artist - André Michaud - Canadian Animation Blog](http://www.canadiananimation.com/2015/01/Canadian-Animators-Andre-Michaud.html)**
  - Source: canadiananimation.com
  - *Jan 17, 2015 ... I could also name Dale Hayward and Sylvie Trouvé. They also ... See Creature - Animation reel 2014 from See Creature on Vimeo. What ....*

- **[See Creature Animation, Cossette, Rodeo FX Team for 'Hanging by ...](https://www.awn.com/news/see-creature-animation-cossette-rodeo-fx-team-hanging-thread)**
  - Source: awn.com
  - *Dec 16, 2024 ... ... Dale Hayward, co-director and CEO of See Creature Animation. The ... Talk Stop-Motion Comedy Magic · Podcast EP 244: Lachlan Pend...*

- **[LulzBot Mini 3D printer: Buy or Lease at Top3DShop](https://top3dshop.com/product/lulzbot-mini-3d-printer)**
  - Source: top3dshop.com
  - *The Montreal-based See Creature animation studio founded by Dale Hayward and ... talk about. Fast response time. 93% of surveyed customers are satisfi...*

---

*Generated by Founder Scraper*
