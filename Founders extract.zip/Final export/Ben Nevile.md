# Ben Nevile

## Position actuelle

**Titre** : Founder
**Entreprise** : contextgraph.dev
**Durée dans le rôle** : 6 months in role
**Durée dans l'entreprise** : 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Your agents need a planning layer that keeps up.

## Résumé

As an experienced founder and CTO, I’ve led teams in various fields, from full-stack programming to growth to UX research to data science and machine learning operations, I’m driven to lead in both product development and team dynamics. I love the process of crafting software and software companies.

- I began my professional software career as an engineer for Cycling '74 and developed algorithms for high data rate signal processing and computer vision, programming and transcoding, and SIMD optimization.

- Developed popular Facebook apps and founded Mainsocial, a 5-person software consultancy specializing in the UX of social design and the development of massively scaled web apps. 

- Managed teams at Breather, overseeing growth from 7 to 250+ employees and raising $160m+ to democratize urban space access.

- Raised $10m+ from Andreessen Horowitz as Co-founder & former CTO of Practice, aiming to improve coaching practices and outcomes.

I do a lot of mentoring and advising for startups. I find immense fulfillment in guiding emerging ventures through the complexities of product development and team building, helping them navigate toward success.

Most recently I've been bootstrapping https://contextgraph.dev , an AI-heavy planning layer for engineers living in the future.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAJENvsBd2PFXgq6wefNos2PtgBfzaLXnj0/
**Connexions partagées** : 115


---

# Ben Nevile

## Position actuelle

**Entreprise** : contextgraph.dev

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Ben Nevile

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394425364577533953 | Article |  |  | Another silly-productive week of product work powered by the context graph. Big focus on long-running autonomous executions and quality of input data for the learning algorithms. I also had super valuable feedback sessions with a couple of early users that validated the platform as an organizing force within the AI coding landscape. These early conversations are so meaningful for helping shape the core workflow. 

https://lnkd.in/ekUCDWRq | 2 | 0 | 0 | 3w | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.476Z |  | 2025-11-12T17:26:28.695Z | https://www.contextgraph.dev/done/c70f8794-ce64-44dc-9156-fb662f40b6b2?start=2025-11-05T18%3A00%3A00Z&end=2025-11-12T18%3A00%3A00Z |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391883323989716994 | Article |  |  | Weekly update: with the help of my context graph I completed 155 actions, +11,514/-3,194 lines of tightly calibrated, well-aimed code. Not AI slop. 

The context graph connects planning and execution into a self-improving loop.

Highlights: 
- Add Branch Inheritance System for Actions (20 actions)
- improved the automatic changelog system (17 actions)
- UI & dev experience issues (12 actions)
- made the MCP tools tighter, faster, and more complete (11 actions)
- improved context engineering for specs via siblings (9 actions)
- began next automation system for self-improvement (9 actions) 

More details here:
https://lnkd.in/eCWAcW2r | 12 | 3 | 0 | 1mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.477Z |  | 2025-11-05T17:05:18.990Z | https://www.contextgraph.dev/done/c70f8794-ce64-44dc-9156-fb662f40b6b2?start=2025-10-29T00:00:00Z&end=2025-11-06T00:00:00Z |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7389694785663483904 | Article |  |  | contextgraph.dev changelog -> Polishing Done Magazine: A Retrospective Dive into UI and Header Enhancements Explore our journey from Oct 23-30, 2025, across 20 work streams.


https://lnkd.in/g7V8cbm3 | 4 | 0 | 0 | 1mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.478Z |  | 2025-10-30T16:08:50.792Z | https://www.contextgraph.dev/done/c70f8794-ce64-44dc-9156-fb662f40b6b2?start=2025-10-23T16%3A00%3A00.000Z&end=2025-10-30T16%3A00%3A00.000Z |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7350311772995682305 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ec5d8353-baad-49d6-8acf-4e2fea03714c | https://media.licdn.com/dms/image/v2/D5605AQHGTbMQPIgyqg/videocover-low/B56Zf7PZ2FHQCE-/0/1752266811900?e=1765782000&v=beta&t=a7DbFubgPuRsDC7RnC2YUxruje2C1Pteol7Vk7e5osQ | Agree 100% that the bottleneck is moving from engineering (how?) to product management (who? what? where? why?) | 4 | 2 | 0 | 4mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.479Z |  | 2025-07-13T23:54:48.871Z | https://www.linkedin.com/feed/update/urn:li:activity:7349539732105687040/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7344526995994664960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEjiVkZMCIuog/feedshare-shrink_800/B4EZe0AYr8GcAg-/0/1751071689984?e=1766620800&v=beta&t=VlOOl2tmGFGNnaRRdrzhOwhcByo_S0aUqtVSoNjVzFI | current vibe | 19 | 0 | 0 | 5mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.479Z |  | 2025-06-28T00:48:10.558Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7342976279412981762 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGpnPaBEMSI4Q/feedshare-shrink_800/B4EZed9.3DHcAo-/0/1750701965346?e=1766620800&v=beta&t=hLQ9spPN73Ch2UWGcMbXOAk13kXgyAMj5VRnVbtp7no | Software engineering in 2025: | 5 | 0 | 0 | 5mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.480Z |  | 2025-06-23T18:06:10.914Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7337468517148999680 | Text |  |  | distribution > product. plus ça change | 2 | 0 | 0 | 5mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.480Z |  | 2025-06-08T13:20:18.061Z | https://www.linkedin.com/feed/update/urn:li:activity:7326639205231534080/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7337244552937832448 | Text |  |  | The moral panic of the old-school, highly-skilled engineers in my feed is the strongest evidence that vibe coding is, in fact, great | 15 | 2 | 0 | 6mo | Post | Ben Nevile | https://www.linkedin.com/in/nevile | https://linkedin.com/in/nevile | 2025-12-08T06:02:25.481Z |  | 2025-06-07T22:30:20.832Z |  |  | 

---



---

# Ben Nevile
*contextgraph.dev*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Context Engineering: The Graph-Powered Evolution of AI Context](https://www.startuphub.ai/ai-news/ai-video/2025/context-engineering-the-graph-powered-evolution-of-ai-context/)
*2025-11-25*
- Category: article

### [Stateless Intelligence Is Not Safe Intelligence](https://medium.com/@ben.havis1/stateless-intelligence-is-not-safe-intelligence-29a6a4f48f66)
*2025-11-12*
- Category: blog

### [Context is Everything: Analyzing Your Context Data using Knowledge Graphs and Graph Data Science](https://medium.com/@bukowski.daniel/context-is-everything-part-2-analyzing-your-context-data-using-knowledge-graphs-and-graph-data-afb832ce894c)
*2024-01-01*
- Category: blog

### [Toward AI Standards: Why Context Is Critical for Artificial Intelligence](https://neo4j.com/emil/toward-ai-standards-why-context-is-critical-for-artificial-intelligence)
*2024-06-06*
- Category: article

### [The Future of Efficiency Is Here: Add Planning to Your Schema! - Benjie Gillam, Graphile<!-- -->](https://cotalks.dev/talks/the-future-of-efficiency-is-here%3A-add-planning-to-your-schema%21-benjie-gillam-graphile)
*2023-09-21*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
