# Nick Martire

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : norda run
**Durée dans le rôle** : 5 years 9 months in role
**Durée dans l'entreprise** : 5 years 9 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Sporting Goods Manufacturing

## Description du rôle

www.nordarun.com
instagram: @nordarun

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAGgv48BJKyh4BGc7TrCpvoY8AGJXTdBXk4/
**Connexions partagées** : 92


---

# Nick Martire

## Position actuelle

**Entreprise** : norda run

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nick Martire

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393794129635221504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFlbxSPb5bhw/feedshare-shrink_800/B4EZpwIiquHgAk-/0/1762817881297?e=1766620800&v=beta&t=JC9swJiep-mXu1WARXApU_l4oZX1WSKWLWeTnI_7uKg | norda run is coming to TRE – The Running Event Dec 3-4, 2026.
Henry B. Gonzalez Convention Centre: San Antonio, Texas: Stand #14075

We will unveil the new norda 055, a technical all-mountain tool, which builds on the platform we created with the 005, the world’s lightest and strongest trail shoe ever made. There has never been a shoe this powerful in trail.

For Appointments: 
Global Sales Director
Julie Papineau
julie@nordarun.com

PR + Media
Ross Dwyer
ross@nordaun.com

nordarun.com
IG: @nordarun

Julie Papineau
Brian Ratay Jimmy Elam David Lam
IG: @nordarun
nordarun.com | 81 | 1 | 0 | 3w | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.111Z |  | 2025-11-10T23:38:10.557Z | https://www.linkedin.com/feed/update/urn:li:activity:7393794098026983424/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7383494166082691073 | Article |  |  | "When you’ve been to hell and back with a small team, you can accomplish great things. The team just, like, snapped their fingers and set up the whole operation in three months," Nick said. He credits a core group of six who have "been together for 15 plus years…" - Nick Martire

Author: John MacFarlane | Yahoo Finance
nordarun.com
IG: @nordarun
📷 : Ben Johnson @b3n.co

#run #running #trailrunning #canada #quebec
https://lnkd.in/eg3Kj4DD | 151 | 13 | 0 | 1mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.113Z |  | 2025-10-13T13:29:47.882Z | https://ca.finance.yahoo.com/news/a-tiny-canadian-shoe-startup-outpaced-hoka-and-on--then-crippling-tariffs-changed-the-math-110055206.html |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7382763487980208129 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPIwyeLRAw4Q/feedshare-shrink_800/B4EZnTYKLDIwAg-/0/1760187970765?e=1766620800&v=beta&t=y30YffEQJ9TNahRIMGXZ3cqCSwMl_1AUF5m58VTW4-s | The Ultra Gobi 400km: Gratitude is at the root of Jovica Spajic’s running practice. It’s what helps him block out the inevitable challenges of a multi-day race — remonstrances from body and mind, challenges presented by navigation, fueling, and water — and remain focused on the task at hand, no matter how fractious the internal battle becomes.

And, across 400 kilometres of the Gobi Desert (whose name means “Waterless Place” in Mongolian) at Ultra Gobi 2025, Jovica’s gratitude carried him to another podium finish. Through scree and sand, in the blazing sun and the chill of the desert night, Jovica ran onwards, staunch in his determination, grateful for both the experience and the body that enabled him to face it head-on. 

As is to be expected from an athlete who’s exclusively raced distances over 300k for the last five years, Jovica has extremely high personal standards. That, coupled with a burning internal desire to push himself to his limits, have made him a force to be reckoned with. What makes him truly special, however, is that he wants to compete the right way. To help and uplift his fellow racers, not crush them. As is his tradition, he crossed the finish line side-by-side with another podium finisher. 

The terrain, the distance, the experiences, the gear — in this case, a single pair of the norda run 001A — all change, but nothing changes who Jovica is as a person, and that’s why we’re so proud to support him. 

“I’m super tired, but filled with positive energy and beautiful emotions,” Jovica said in a WhatsApp message after the race. “I could literally go for a run right now if it was needed.”

Congratulations, Jovicia. We’re already looking forward to your next adventure.

IG: @nordarun @ultragobi
nordarun.com
📷  @danielkeppler_bow
#running #run #trailrunning
Vibram Group Dyneema® Envalior | 71 | 2 | 0 | 1mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.115Z |  | 2025-10-11T13:06:20.647Z | https://www.linkedin.com/feed/update/urn:li:activity:7382763455323463680/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7376643233470369792 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFWsa_xqMflMQ/feedshare-shrink_800/B56Zl792dJG0Ag-/0/1758721436943?e=1766620800&v=beta&t=mpPg4HUCocSPHJ0KMaC5rwOsMRez_9uD0U26Tb4H1CY | When we launched norda run as a small four person team back in 2021, we had zero expectations to be on the top right side of the running industry.  I mean - we truly aspired to get there - and now we are there (statistically and also in the eyes of our peers).  We are a small family company committed to making the finest running footwear. 

Thank you Marcio A. Porcher for your passionate and highly detailed analyses of the footwear industry.  It's a fun time to be in running. 

nordarun.com
IG @nordarun 

Willamina Martire Gerard Cleal Ethan Song Alexandre Martin Julie Papineau 
#running #trailruning #run #canada
Dyneema® Vibram Group Envalior | 216 | 35 | 5 | 2mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.116Z |  | 2025-09-24T15:46:38.263Z | https://www.linkedin.com/feed/update/urn:li:activity:7376612365280141312/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7372743630052306944 | Article |  |  | Earlier this week Richard Kuchinsky declared that "norda run has broken the shoe industry".  Constant refinement is true innovation - a performance upgrade you cannot see, yet totally improves the experience.

Thank you Believe in the Run for the detailed review of the new norda run 001A.

"Visually, the Norda 001A is identical to the original model. That’s purposeful for the continuation of the instant-classic styling and to leverage the existing performance. I’m here for it, because even though the 001 debuted four years ago, it is still involved in trail runners every day rotation. I can’t think of any other shoe from 2021 that still exists in this way." - Taylor Bodin - Believe in the Run

nordarun.com
IG @nordarun
#canada #run #running #trailrunning
https://lnkd.in/exgV_d9k | 99 | 5 | 1 | 2mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.117Z |  | 2025-09-13T21:31:00.357Z | https://believeintherun.com/shoe-reviews/norda-001a-review/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7369006397839163396 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFD4LPoLr5Wdg/feedshare-shrink_800/B4EZkP4IzuIoAk-/0/1756908011643?e=1766620800&v=beta&t=OfNXy9ITBva_VOzDxfx4GB2P4JS_pgICbd0Y3Ds22mQ | As summer gives way to fall, the trail running world descends on Chamonix, a small town in the French Alps just north of Mont Blanc, for race week. 

Since the races kicked off in 2003, the area’s sharp elevation gains and technical trails have served as a proving ground for the world’s finest ultrarunners (seven members of norda’s elite trail team partook this year). And, over time, the week has become just as important to the brands that support those runners. 

It serves as an opportunity to show up with your latest and greatest products, to bring your community together, to define the zeitgeist for the next year and beyond. 

norda’s home during race week was SANGLARD SPORTS , a family-owned business founded in 1924 and one of our first French stockists. Inside Sanglard, we officially revealed our new 001A — the next generation of our foundational 001 that’s equipped with an all-new Arnitel® midsole — by way of an immersive pop-up experience, free shoe demos and an official launch event.

Besides the reveal of the 001A, we partnered with cult-favorite meme maker @yaboyscottjurek for custom “Power Hiker” camo hats, Chamonix-exclusive race bags, and even complementary “Power Hiker” espresso for visitors to our space, plus a packed Friday night race watch party where attendees could get their hands on the “Power Hiker” hats for free.

Until next year, Chamonix. Stay tuned for more …

nordarun.com
IG: @nordarun

Dyneema® Vibram Group Envalior
#run #running #trailrunning | 107 | 7 | 1 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.118Z |  | 2025-09-03T14:00:34.763Z | https://www.linkedin.com/feed/update/urn:li:activity:7369006359352229889/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7367849546900459520 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVxu88j2cXug/feedshare-shrink_800/B4EZj_by2GHEAk-/0/1756632207942?e=1766620800&v=beta&t=o9xvHW3bEMTfcFrlD-HR3AGFAbXJKarF5C0Lyi94nEA | 11 hours. 48 minutes. 18 seconds. 101 kilometres, from Courmayeur to Champex to Chamonix. A third-place finish in what's already being hailed as "one of the greatest races in CCC history", with only three minutes separating the top three women.

All in a day's work for norda run trail team athlete Anna Tarasova.

We first met Anna - and felt the strength of her indomitable spirit — during the Girona stop of our 002 World Tour in 2023, when she handily won our Storm the Castle event. She's been family ever since, and officially became a member of the norda trail team in 2024.

Our deepest congratulations to Anna on her historic accomplishment and a heartfelt Happy Birthday today, from the entire norda family.

📷  Martí Miró
IG: @any.tarasova @nordarun
https://lnkd.in/eKwvC8Cb
Vibram Group Envalior Dyneema®
#run #running #trailrunning | 89 | 2 | 0 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.119Z |  | 2025-08-31T09:23:40.006Z | https://www.linkedin.com/feed/update/urn:li:activity:7367849520237400065/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7364306694006321154 | Article |  |  | It's POWER HIKER Summer.  Ready to kick off the norda way in Chamonix next week for the annual races.  We've teamed up with IG: @Yaboyscottjurek

All events at SANGLARD SPORTS
Wednesday Aug 27 10am - grand opening of the norda Power Hiker Outpost and unveiling the new 001A 

Thursday Aug 28 - Saturday Aug 30 demo the 001A

Friday Aug 29 6:30pm?? watch party (right after UTMB starts and awaiting CCC first finishers) pizza and lots of Power Hiker hats 

Follow IG @nordarun and @Yaboyscottjurek for live coverage all week

https://lnkd.in/guwe_BGQ | 46 | 6 | 1 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.120Z |  | 2025-08-21T14:45:38.053Z | https://www.instagram.com/p/DNnp8EJR3C_/?utm_source=ig_web_copy_link&igsh=aGF0ZWFyMnRrcjVj |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7364024177235828736 | Article |  |  | When we first launched norda run back in 2021, the statement the "world's most durable trail running shoe" made us uneasy.  Four years later, with hundreds of thousands of pairs already pushed to their limits, multiple races won, this proclamation no longer keeps us up at night.  In fact, its' now our reason for being. 

We broke boundaries to pioneer the world's first ever shoes made with bio-circular Dyneema® , the world's strongest and lightest fibre™️.  At our customer service desk, we now have a saying if someone sends us a pair with a tear in the upper: "What chainsaw did you use, because it's just not possible to tear it."

Thank you to our community for 4+ years of tremendous support for "little norda"

The 001A releases Wed Aug 27th at 9:00am EST
nordarun.com
IG: @nordarun
Author: Jack Seemer | Gear Patrol
Dyneema® Vibram Group Envalior
#canada #running #trailrunning 
https://lnkd.in/edC3QBNY | 92 | 16 | 0 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.120Z |  | 2025-08-20T20:03:00.806Z | https://www.gearpatrol.com/outdoors/norda-001a-trail-shoe/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7363268061652500480 | Article |  |  | The norda 001, the debut offering from Canada’s expert in hi-tech trail gear, was launched four years ago as a lightweight running shoe using rugged fabric technology never seen before. The shoes were aptly named “Lamborghini's for your feet,” by Highsnobiety.

Now, the trail runner has been re-tuned and re-engineered to deliver even more speed. Enter the norda 001A.

“This isn’t just an upgrade,” Nick Martire, co-founder and CEO of norda tells me via email. “It’s a redefinition of what a trail shoe can deliver, from the first kilometre to the thousandth."

Releasing Wednesday August 27th - Chamonix, France - Sanglard Sports
nordarun.com
IG: @nordarun
Author: Tom Barker | Highsnobiety
Vibram Group Envalior Dyneema®
https://lnkd.in/eywU3eVr | 92 | 9 | 2 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.121Z |  | 2025-08-18T17:58:28.803Z | https://www.highsnobiety.com/p/norda-001a/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7362865212527452160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGRorgSbOR1xw/feedshare-shrink_800/B4EZi4mwCdHoAg-/0/1755443847972?e=1766620800&v=beta&t=3Uoc2_J43UUgCYCFe1K2HvyRx_i9CHGRWnDr2tHjDug | Even the most casual observer can glean the challenge of the aptly-titled Canadian Death Race from its name alone. Dig behind the macabre moniker, however, and you’ll see the true effort required: 118 kilometers of pure movement across the Grande Cache in Alberta, Canada, complete with 4,770 meters of elevation gain.

For a runner like norda Trail Team athlete Ethan Peters, however, the Canadian Death Race is nothing short of an ascent to transcendence. This last weekend, Ethan, born and raised in Toronto, Ontario, took home first place at the 2025 Canadian Death Race, smashing the course record by almost 40 minutes and finishing more than an hour and a half ahead of his nearest competitor, all despite unrelenting rain.

Ethan flew down the front of Grande Mountain, ascended Mt. Hamel in gusting winds and sheets of precipitation, soared across the slippery rocks on the very bottom of the Smoky River valley floor and even took a joyful, intentional dip in the river before boarding the boat that took him towards the last leg of the race, all with a near-omnipresent smile glued to his face, enjoying the beauty of the challenge he was undertaking.

We’re proud to champion Ethan’s skill, resilience, endless levels of stoke, and growth — the gusto-filled kid now from Fernie, BC who cold-messaged us in our early early days for a pair of shoes just keeps climbing higher and higher. Congratulations, Ethan.

nordarun.com
IG @nordarun

Sinister Sports: Canadian Death Race 2025
Vibram Group Dyneema® Envalior
#running #trailrunning #canada | 57 | 1 | 0 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.123Z |  | 2025-08-17T15:17:42.087Z | https://www.linkedin.com/feed/update/urn:li:activity:7362865159142313984/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7360772761746636801 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGXfq3gzvjxvw/feedshare-shrink_800/B4EZia3wBTGUAg-/0/1754944967610?e=1766620800&v=beta&t=8mkGcp0V2vrhKNe4XUZRW1UOZ4n40zuIsWa2EK4f8KU | "From I'll never do Fat Dog 120" to a win and a course record. I am so grateful we got to run this course and see the deep and isolated wilderness prior to the more familiar trails of Manning Park, BC.   Thank you @fatdog120 Team for your unparalleled work and dedication to sharing this route with your racers and allowing us to move through these spaces safely." Jenny Quilty

Epic weekend for norda trail team athlete Jenny Quilty
For the rest of us mere mortals, the race was 203km, 8,500+ metres in only 31:59:32
Shout out to Scotty Maguire | SkiUphill - RunUphill also for the Men's race win

Another two 1st place podiums for the norda 005 this weekend here at home in Canada

📷 Matt: @yota_ventures 
IG: @2scotttotrot
Race: IG: @fatdog120
nordarun.com
https://lnkd.in/eKwvC8Cb
Vibram Group Dyneema® Envalior
#canada #trailrunning #running | 60 | 0 | 0 | 3mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:45.124Z |  | 2025-08-11T20:43:02.945Z | https://www.linkedin.com/feed/update/urn:li:activity:7360772705630965761/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7358871420749103104 | Article |  |  | Collab culture has hit a dangerous hay day, with many collabs either underwhelming, overdone, or forced. In a world where collabs cover the spectrum, it’s refreshing when two brands jive so fundamentally that it brings the culture back to its roots, where respect for each other’s work prompts a genuine product and design.

That’s precisely what the Norda x Raide LF 2L Belt represents. It’s a merger of two of the best in the outdoor biz that share a similar ethos of function, quality, and simplicity.

Author: Believe in the Run (Thomas Neuberger Robbe Reddinger)
Raide | Kyle Siegel
nordarun.com
IG @nordarun and @raide.research
https://lnkd.in/dFJsWM4z | 66 | 0 | 0 | 4mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.192Z |  | 2025-08-06T14:47:47.926Z | https://believeintherun.com/gear-reviews/norda-x-raide-lf-2l-running-belt/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7356409459025289216 | Article |  |  | The Maclean Brother are about to make history with the fastest self-supported row across the Pacific Ocean.  Day 110.  6978.34 nautical miles covered so far.  They departed from Lima, Peru, and now are close to making landfall somewhere in Australia in only two weeks from now.

Way back in 2022 shortly after we launched norda run, we met the Brothers on a video chat. Transparently, they were complaining about a defect in one of the early norda’s where the Dyneema® was delaminating on the mudguard. They had used Dyneema ropes back in 2020 on their record setting Atlantic crossing, and they immediately jumped for our footwear made with the same fibre. We struck a bond, and only a few months later, we were on our way to meet in Edinburgh. We went far north to Assynt, their favourite playground where’re they spent summers in Scotland. During the 5 days together we witnessed the exceptional strength, discipline and camaraderie of Jamie, Lachlan and Ewan Maclean

Trained by Chloe Lanthier, trail running comprises a large part of their preparations. For this journey, we custom-made a special norda 002 with a highly breathable and quick drying Dyneema® upper which would not be affected by the never ending saltwater, and a custom rubber soleplate designed for anti-slip on the boat.

Their purpose is to raise funding for clear water projects. It’s an incredible human endeavour and incredibly inspiring: If you have an opportunity to support, here are the links below:
https://lnkd.in/gCxC56XY

https://lnkd.in/egyXWxFt

W: themacleanbrothers.com 
IG: @themacleanbrothers
E: info@themacleanbrothers.com
nordarun.com
IG: @nordarun | 29 | 0 | 0 | 4mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.193Z |  | 2025-07-30T19:44:50.510Z | https://www.youtube.com/watch?v=sEA7QA4UbT8 |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7345836245203255296 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHtU0WUoQV1hA/feedshare-shrink_800/B4EZfGnFojGwAg-/0/1751383828623?e=1766620800&v=beta&t=6tYIjcjsZZ0_WuotPrKr9EPWCq9CFTaNkwO85YphFuU | Resilience. Pain and perseverance. Collapse and renewal. 
When you push the body to the extreme, how do you respond when it wants to stop, when the mind tells you to quit? 

This weekend, Ryan Montgomery completed his third Western States 100—his 18th lifetime 100-miler—claiming a second Top-10 finish (7th overall). Traversing 100 miles of mountains and extreme heat, resilience was a theme for this year’s race. Ryan had to recommit again and again.

For those who weren’t watching, the race started out incredibly fiery, with the lead men all running ahead of course record pace, playing a dangerous game of Icarus. From Olympic Valley to Auburn, Ryan hung on at a smart distance, all while meeting every excuse to ease off or give in—and he answered each with renewed commitment. 

“I’m proud of this one. I had every reason to play it safe or drop out after a fall and GI issues, but I kept recommitting. That recommitment turned into closing hard, passing several competitors in the final 20 miles, and locking in 7th place. When I get into hunting mode, I execute.” 

We are honoured to have been able to join Ryan’s continued journey to test the limits of human endurance—where resilience is not a single race, but a series of choices in the face of adversity. Bravo, Ryan.

Western States 100-Mile Endurance Run
📷: @johnlarracas
nordarun.com
IG @nordarun

Dyneema® Vibram Group Envalior
#running #trailrunning | 58 | 0 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.195Z |  | 2025-07-01T15:30:39.894Z | https://www.linkedin.com/feed/update/urn:li:activity:7345836209232879617/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7345485405573537792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGF10gAeUKsIg/feedshare-shrink_2048_1536/B4EZfBoAqrHIAo-/0/1751300185076?e=1766620800&v=beta&t=mFLmeRt-Xg1Pdv7qoEw5aoOniqI4YygHmUXmUjR5zGg | Viva Italia  🇮🇹 – Viva Anna!
Huge congrats to our norda run Trail Team athlete Anna Tarasova for achieving another win this weekend in Italy.  It’s a major stop on the global UTMB® Group calendar, the 80km Lavaredo course runs through the iconic Dolomites and has 4600+ metres of elevation gain.  Congrats Anna!

Anna Tarasova (IG @any.tarasova) 
1st place 80km Lavredo by UTMB
nordarun.com
IG: @nordarun

Vibram Group Dyneema® Envalior
#running #trailrunning | 84 | 4 | 1 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.196Z |  | 2025-06-30T16:16:33.208Z | https://www.linkedin.com/feed/update/urn:li:activity:7345485380663599104/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7341340375325806593 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEy1-KLDt7fhA/feedshare-shrink_800/B56ZeGuJoiGQAw-/0/1750311935254?e=1766620800&v=beta&t=66W9fIDBOw2y3BgGxhuLN-7xWVYNG19SwgXyGw2ps2k | norda run is coming to Paris Fashion Week. 

Come see the new 001A and the 008 -  in addition to the Fall 2025 and Spring 2026 footwear and equipment.

Book an appointment to see us at the at: 43 Rue Des Tournelles.
Dates: June 24 – 29, 2025.

For Appointments: 
France | Europe | Germany – All Seasons :
Alban Le Pellec
alban@all-seasons.me

International:
Julie Papineau
julie@nordarun.com

nordarun.com
IG: @nordarun

Julie Papineau Alban Le Pellec
#running #trailrunning | 73 | 2 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.197Z |  | 2025-06-19T05:45:40.986Z | https://www.linkedin.com/feed/update/urn:li:activity:7341340355683938304/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7340112883663446016 | Article |  |  | 4mins 57seconds with norda - The Future of Running Supershoes

A brief history of norda run, how we cracked the code to make shoes with Dyneema®, the world's lightest, strongest and most durable fibre. 

Fun fact: this video was actually recorded back in January 2025, 2 months prior to the release of the norda 005 - our expression of the foremost trail supershoe. 

"A brand is not what You say it is, rather what They say it is". 
As we go back to read the 29+ comments, 3 months since the release - we are grateful to the running community for their advocacy of our passion in striving to make the finest

Thank you to Josh Rosenthal | borderlands.cc for telling the norda run story with equal passion and energy.

IG: @nordarun
nordarun.com
Vibram Group Envalior Avient Corporation Dyneema®
#canada, #running, #trailrunning
https://lnkd.in/eRmJxgfy | 62 | 2 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.198Z |  | 2025-06-15T20:28:04.168Z | https://www.youtube.com/watch?v=_-oK8nYDjHI |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7339045977443430401 | Article |  |  | Don’t worry, we get it.
Introducing the 008, designed with zero judgement of any post-run ritual.

In collaboration with actor Anders Holm:  @ders808
📽️  @thedirtyboy
📷  @ritt_faced
008 available now: nordarun.com 
https://lnkd.in/eHF7Bf73
#notrunning #running #trailrunning | 59 | 5 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.198Z |  | 2025-06-12T21:48:33.903Z | https://www.youtube.com/watch?v=Kdlmues-JBg |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7338581015285665793 | Article |  |  | "Times change and nowhere more quickly than in running. First it was super shoes. Can you even call yourself a serious running brand without one in your catalog? Having crossed that milestone of the list earlier this year, Canadian upstart norda run steps into trail running’s latest arms race, releasing a recovery slide to take on Nike, Hoka and countless others that have made it one of the sport’s most competitive battlegrounds.” - Gear Patrol

Author: Jack Seemer 

Release date: June 12th at nordarun.com
IG: @nordarun

Vibram Group
#running #trailrunning #notrunning
#canada

https://lnkd.in/g7pxk5RA | 76 | 4 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.199Z |  | 2025-06-11T15:00:58.286Z | https://www.gearpatrol.com/outdoors/norda-008-recovery-slide/?utm_source=flipboard&utm_content=topic/trailrunning |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7338265888137109504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGndPzE5moG7Q/feedshare-shrink_800/B4EZdbB4qzHYAo-/0/1749578917031?e=1766620800&v=beta&t=S_tP4eSCipFyqPmOXeWIeY_JKmqG0ZUbItinqWa0iks | Huge congrats to our norda run Trail Team athletes for achieving another three podiums this weekend.  From Austria to right here at home in Canada, it's awesome to see athletes achieving their full potential

Anna Tarasova (IG @any.tarasova) - 1st place 100km Mozart by UTMB - UTMB
- Of note, Anna finished nearly an hour ahead of her nearest competitor

Sarah Bergeron Larouche(IG @sarah_bergeron_larouche)  - 1st Place at La Clinique du Coureur Lac Beauport Trail 50km 
- Of note, Sarah finished over an hour 

Jean-François Cauchon (IG @teamcauchon) - 3rd Place at La Clinique du Coureur Lac Beauport Trail 50km 

nordarun.com
IG: @nordarun
Vibram Group Dyneema® Envalior
#canada #quebec #trailrunning #running | 73 | 0 | 0 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.200Z |  | 2025-06-10T18:08:46.119Z | https://www.linkedin.com/feed/update/urn:li:activity:7338265859540328448/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7337805273941651456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGNJRadGfh98Q/feedshare-shrink_800/B4EZdUdwnUGcAk-/0/1749468913719?e=1766620800&v=beta&t=O-oOwl8svhIwKq9jnahI9D4LsUYoZwwbadea_ulWuU0 | The hometown crowd was out in full force Friday night, the grand finale of the norda run 005 world tour events.  Huge thanks to Boutique Endurance and their team for welcoming us to the shop on Saturday evening.  Over 125 runners showed up for the 13km run, culminating with the iconic Montreal Winneburger truck.  Thank you to all who came out for Saturday Night.  Even one of the runners chose the celebrate their 30th birthday with us!

IG: @nordarun
nordarun.com
boutiqueendurance.ca
#canada #montreal | 81 | 3 | 1 | 5mo | Post | Nick Martire | https://www.linkedin.com/in/nick-martire-6931919 | https://linkedin.com/in/nick-martire-6931919 | 2025-12-08T06:05:50.201Z |  | 2025-06-09T11:38:27.137Z | https://www.linkedin.com/feed/update/urn:li:activity:7337804505650016256/ |  | 

---



---

# Nick Martire
*norda run*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 17 |

---

## 📚 Articles & Blog Posts

### [The Brand That Did What No Other Shoe Company Could Do: A Conversation With Nick Martire of norda](https://hypebeast.com/2024/8/features-norda-hbx-journal-hypebeast-interview)
*2024-08-16*
- Category: article

### [On The Run with norda’s Nick Martire  | Lane Crawford](https://www.lanecrawford.com/discover/on-the-run-with-norda-s-nick-martire-200000001-20250320/shop/)
*2025-03-20*
- Category: article

### [Norda 005 | Shoes are Never Really Just Shoes](https://www.borderlands.cc/norda/)
*2025-11-06*
- Category: article

### [NORDA: YEAR 001 [Interview]](https://techuntermagazine.com/norda-interview-year001)
*2022-11-25*
- Category: article

### [VIBRAM FIVEFINGERS – Your Tool To Feel The Earth [ ...](https://techuntermagazine.com/vibram-fivefingers-firstfeelings-review)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[norda 005: zapatillas trail running competición y nueva vibram ...](https://carrerasdemontana.com/2025/03/13/norda-005-review-mayayo/)**
  - Source: carrerasdemontana.com
  - *Mar 13, 2025 ... ... Nick Martire. Su vocación fue desde un principio buscar soluciones ... Etiquetas: norda 005, norda 005 review, norda run, norda t...*

- **[EY Entrepreneur Of The Year Canada | Made in Canada | EY ...](https://www.ey.com/en_ca/entrepreneur-of-the-year-canada/made-in-canada)**
  - Source: ey.com
  - *Podcasts · Webcasts · Case studies · Operations leaders · Technology leaders ... Nick Martire, Willamina Martire – Norda Run Inc. 2023, Keith McIntosh...*

- **[รู้จัก Norda แบรนด์รองเท้าจากแคนาดาที่ถูกยกให้เป็น Lamborghini แห่ง ...](https://capitalread.co/norda/)**
  - Source: capitalread.co
  - *hatchetsupply.com/blogs/chop-talk/norda-co-founder-nick-martire-on · hypebeast ... highsnobiety.com/p/norda-run-interview · sneakerfreaker.com/feature...*

- **[norda 003. zapatillas de montaña sin cordon, desde canada](https://carrerasdemontana.com/2024/05/20/norda-003-zapatillas-de-montana-sin-cordon-desde-canada/)**
  - Source: carrerasdemontana.com
  - *May 20, 2024 ... ... Nick Martire. Su vocación fue desde un principio buscar soluciones ... Etiquetas: norda 003, norda 003 review, norda run, norda t...*

- **[Small data e netnografia: analisi delle community di running per lo ...](https://webthesis.biblio.polito.it/25186/1/tesi.pdf)**
  - Source: webthesis.biblio.polito.it
  - *May 10, 2022 ... Norda Run, un brand di prodotti sportivi di nicchia, è stato ... 2020 dai coniugi Willamina and Nick Martire. Il progetto nasce da un...*

- **[Norda Run Interview: Up Close With the Astonishing Running Shoes](https://www.highsnobiety.com/p/norda-run-interview/)**
  - Source: highsnobiety.com
  - *Dec 19, 2022 ... Just before the pandemic began, footwear industry veterans and endurance runners Willamina and Nick Martire found themselves looking ...*

- **[DISCOVERING LEVANTE: A LIGURIAN JOURNEY](https://athletamag.com/en/discovering-levante-a-ligurian-journey/)**
  - Source: athletamag.com
  - *A Ligurian experience to celebrate the synergy between Artcrafts and Norda Run, in collaboration with Runaway and Athleta....*

- **[노다 창립자, 닉 마티리 인터뷰: 러너들을 위한 '진짜' 신발을 만드는 그 ...](https://hypebeast.kr/2024/11/norda-run-nick-martire-interview)**
  - Source: hypebeast.kr
  - *Nov 15, 2024 ... 브랜드의 철학과 비전을 엿볼 수 있는 토크 세션과, '005' 신제품의 처음으로 선보이는 특별한 자리까지 마련됐고, 트레일 러닝을 중심으로 활동하는 ......*

- **[Nick Martire - Co-Founder @ Norda Run - Crunchbase Person Profile](https://www.crunchbase.com/person/nick-martire-fbde)**
  - Source: crunchbase.com
  - *Nick Martire has 2 current jobs as Associate at Creative Destruction Lab (CDL) and Co-Founder at Norda Run . Additionally, Nick Martire has had 2 past...*

- **[Norda Run 005 Multi Tester Review: A Marvel! 10 ... - Road Trail Run](https://www.roadtrailrun.com/2025/02/norda-run-005-multi-tester-review.html)**
  - Source: roadtrailrun.com
  - *Feb 28, 2025 ... Norda Run 005 Multi Tester Review: A Marvel! 10 Comparisons. Article ... Nick Martire, co-founder of norda describes it as a “pure” 1...*

---

*Generated by Founder Scraper*
