# Bilal Dhouib

## Position actuelle

**Titre** : Founder
**Entreprise** : Incubella Technologies
**Durée dans le rôle** : 5 years 6 months in role
**Durée dans l'entreprise** : 5 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Incubella is a software development, marketing, and design studio with extensive experience in the tech industry (AI, DeFi, Gaming, SaaS), helping startups and traditional enterprises launch custom internal or commercial software for the modern era. Oh, and we also build fancy websites.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACjZ6aEBiGhJN_DHWfM5aYFLiCQe8v2ml6Q/
**Connexions partagées** : 36


---

# Bilal Dhouib

## Position actuelle

**Entreprise** : Incubella

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Bilal Dhouib

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403286660756426752 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQHh38vgQx71QA/mp4-720p-30fp-crf28/B4EZrqHarBIwCI-/0/1764864430941?e=1765782000&v=beta&t=a3JEEB7WlUiEO9sEfNHHWA6_tcvL7HGbqqxAL6FkvZo | https://media.licdn.com/dms/image/v2/D4E05AQHh38vgQx71QA/videocover-low/B4EZrqHarBIwBQ-/0/1764864422222?e=1765782000&v=beta&t=U6Xniykj-4FsDF9CocIVXc-G-U2Tz_fzNl4KKx8oT-4 | Excited to share a recent site Incubella delivered for Groupe Classique International, a North-American leader in custom millwork & cabinetry focused on hotels, multi-residential and commercial projects. They’ve done projects many of you have probably walked through without realizing who built them!

They came to us wanting something simple, modern, and honest. A site that explains what they do without the fluff and gives their craftsmanship the space it deserves.

Proud of how this one turned out (classiquefurniture.com)

If you’re a traditional business looking to modernize your digital presence without losing the soul of your brand, we're taking on 2 more projects before the new year! | 18 | 0 | 1 | 3d | Bilal Dhouib reposted this | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:18.851Z |  | 2025-12-07T04:18:06.339Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402378008512135170 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e6387a9b-5ff7-4437-bac4-b540a5523141 | https://media.licdn.com/dms/image/v2/D4E05AQHh38vgQx71QA/videocover-low/B4EZrqHarBIwBQ-/0/1764864422222?e=1765782000&v=beta&t=U6Xniykj-4FsDF9CocIVXc-G-U2Tz_fzNl4KKx8oT-4 | Excited to share a recent site Incubella delivered for Groupe Classique International, a North-American leader in custom millwork & cabinetry focused on hotels, multi-residential and commercial projects. They’ve done projects many of you have probably walked through without realizing who built them!

They came to us wanting something simple, modern, and honest. A site that explains what they do without the fluff and gives their craftsmanship the space it deserves.

Proud of how this one turned out (classiquefurniture.com)

If you’re a traditional business looking to modernize your digital presence without losing the soul of your brand, we're taking on 2 more projects before the new year! | 18 | 0 | 1 | 3d | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:18.852Z |  | 2025-12-04T16:07:26.762Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400298029624496128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHhebSC6tY6Vg/feedshare-shrink_800/B4EZrMj0iXIoAg-/0/1764368534204?e=1766620800&v=beta&t=OzfGPaZbFDVP4EesHuiyBgi6Zm7rk6pfnODslDscId0 | There’s a part of my story most people don’t know, and I rarely talk about it: 

From 2010-2018, I was a Minecraft YouTuber. The image below is from 2018 (at the end of my YouTube career) when I got invited by Microsoft as a featured creator to tour Minefaire events around the world. I got to meet thousands of fans, speak on panels in front of 10,000+ people, and participate in cool events with other big Minecraft creators. Being 18 at the time, it really opened my mind to what was possible. 

That was the first job I did from 10-18 years old. No team. No mentor. Just me, a terrible laptop, and the hope that someone out there might watch the content I made. My channel went on to grow to 190 thousand subscribers, garnering over 70 million monetized views and just shy of 1 billion impressions. I sold custom channel merch, had my Minecraft servers filled with players, and worked with multiple tech brands on affiliate marketing. 

At first, I didn’t think of it as business. I was a kid making wacky gaming videos, editing until 2AM on school nights, learning how to be consistent, and out of pure curiosity because I loved watching other creators do it. Looking back, that era was the most powerful and important training I could’ve asked for. I built without anticipation, without expectation. 

Even today, we are constantly unhappy with under delivering expectations for ourselves and/or our clients, when in reality the greatest things happen at the most random occasions. When you’re on YouTube, you learn to create without permission. You learn to communicate clearly and with patience, not quitting after 10 videos because you got no views. It took me 3 years to get my first thousand subscribers, and it quickly compounded. You had to learn how to make strangers care. And learn how to ship, even though you might be getting zero views or attention.

Those instincts carried me into the real world. I didn’t come from a traditional tech background nor did I have any higher education. I used everything YouTube taught me to bootstrap my career as a marketer in tech, and it ended up landing me CMO/Head of Growth/Marketing Manager roles across Gaming, DeFi, Web3, and AI which have completely changed my life and career. 

People see what I do today and assume it came from a straight line. It didn’t. In fact, I slowly built my service business on the side for over the last 8 years while working in and out of multiple roles at tech startups as well as building my own products. I've also tried launching multiple businesses / startups before starting Incubella and often failed miserably. 

All that to say, if you treat the internet as a playground to learn and create, great things will eventually come. | 73 | 7 | 0 | 1w | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:18.852Z |  | 2025-11-28T22:22:21.151Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399823024855687168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErINllDMIDsg/feedshare-shrink_800/B4EZq36FbjGcAk-/0/1764022049659?e=1766620800&v=beta&t=11ytZNu9OJPjTNmpQm9vqmQr1M7x17xOb3fO9IGhu3c | Over the last few years, we've quietly grown a small, high-output team that blends software development, AI, design, and growth, all in-house. 

4 months ago, Incubella finally got its official headquarters, right in the heart of downtown, Montreal. We're taking free consultations in-person by the way!

We work with two types of companies:

1 - Tech startups that need a team who actually understands their market.

2 - Traditional businesses that have been doing great work for years, but want to modernize without burning money.

Sometimes that means full custom software.

Sometimes it’s process automation powered by AI.

Sometimes it’s a landing page that sets a new tone for your brand.

Sometimes it’s the entire digital backbone of an enterprise.

The common thread: We solve real problems and build things that drive growth to your business.

If you’re building something ambitious, have an idea for custom software, or you’re a long-standing business that wants to move quicker and have the brand appearance you deserve, we're taking on new projects for Q1 and Q2. 

Happy to chat. 

Shoutout to our team who've contributed over the years: Stephen Edvi Coby Birenbaum Ivane Midelashvili Giorgi Matsukatovi Daniel Lam Umer Farooqui Bhavya Patel Talha Amin and the 50+ more contractors we've worked with! | 45 | 13 | 8 | 1w | Bilal Dhouib reposted this | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:18.853Z |  | 2025-11-27T14:54:51.189Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7399106902493646848 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a75f5e8b-4279-4767-b971-80894beaac46 | https://media.licdn.com/dms/image/v2/D4E05AQEK3Y-24EqdsQ/videocover-low/B4EZqS825bIUCE-/0/1763402113901?e=1765782000&v=beta&t=VpnWhdyZYhredX3881f9TONkfNxhnJvZatXBzPfGmTo | Check out what Incubella recently delivered for XDUB (www.xdub.io), an AI dubbing agent that enables you to dub your voice in 65+ languages on all 𝕏 videos and spaces, and still sound the same! 

They are powered by Speechlab, a high-tech AI provider part of Andrew Ng's AI startup portfolio.

Congrats to the team on launching their first AI agent demo live on 𝕏  🎉

If your company needs a new fancy landing page, grab a free consultation here: https://lnkd.in/eRkEQjAZ | 16 | 2 | 3 | 2w | Bilal Dhouib reposted this | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:18.853Z |  | 2025-11-25T15:29:14.313Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7397021447317143552 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4970f24f-2bb4-4f55-b4dd-1098b03f8bc1 | https://media.licdn.com/dms/image/v2/D4E05AQEgunUFHdU2WQ/videocover-high/B4EZp.GUUdIwCI-/0/1763052277709?e=1765782000&v=beta&t=ROQgRFV5TLoNOgj69Vw6boSNwkapeKotLnz34Enm2WQ | Proud to finally showcase a product I've been building since August, and now in free public beta! (www.mysentiment.ai) 

SentimentAI helps brands, political teams, and companies with active communities understand what everyone is saying about them in real time: visualize sentiment shifts, trending narratives, engagement patterns, and more.

The problem:

Over 500 million tweets are posted every single day, making X the largest stream of human sentiment on the planet. No team — and no traditional LLM like ChatGPT or Grok — can manually or passively make sense of that firehose. That’s why understanding community pulse is becoming a competitive advantage.

A quick use-case example:

Imagine a major video game studio drops a new update. Overnight, thousands of players flood X/Twitter, Reddit, and Discord with reactions — excitement, frustration, bug reports, balance complaints, memes. Community managers and social media managers need to analuze thousands of data points and summarize the pulse of their community, often leading to inaccurate data points (for example: 30% of negative sentiment was saying our new in-game skin was ugly).

Traditional LLMs (including GROK) can summarize text, but they can’t truly capture the pulse of the community to specific numbers, as it shifts minute-by-minute, in real-time, and summarize accurately. 

SentimentAI does exactly that.

How it works (in simple terms):
 ➡️ Ingests all latest posts that include your keyword via the public 𝕏 API
 ➡️ Data runs through our proprietary AI model and algorithms
 ➡️ Classifies nuances, themes, sarcasm, narratives, and anomalies
 ➡️ Uses Grok-5 to process the data, summarize it, display it, and find unique and actionable data points. 

The goal is to give brands and creators actionable insights in order for them to improve their marketing / output initiatives, and eventually across the entire internet. 

We’re still very early, which is why your feedback means a lot right now!

SentimentAI is currently in open beta (meaning its free). Please make an account, give it a try, and let me know your thoughts! Be as brutally honest as possible with what works/doesn't work. 

Try it for free here 👉 www.mysentiment.ai | 52 | 15 | 4 | 3w | Bilal Dhouib reposted this | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:22.637Z |  | 2025-11-19T21:22:23.053Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7397012614318559232 | Video (LinkedIn Source) | blob:https://www.linkedin.com/94004d70-e61b-4663-9a68-d12244199c95 | https://media.licdn.com/dms/image/v2/D4E05AQEz-chGzoecnw/videocover-low/B4EZqd3uYTKgBQ-/0/1763585225179?e=1765782000&v=beta&t=JSVIa_i_VNJnJUQeWyu0guol5aJOTHMn7ISGgCBKQZc | At Incubella, we don’t just work with tech startups, we also help long-established businesses modernize, digitize, and present themselves the way they deserve.

Conex Cabinets is a custom cabinetry manufacturer that specializes in custom medical workspaces across Canada (Dentists, Veterinary, Podiatry clinics) and have been doing exceptional work for years.

We designed and built them a high-end, conversion-focused website that:

- Positions Conex as a premium, detail-obsessed cabinetry provider
- Showcases their portfolio and process in a clean, modern visual language
- Helps them convert more inbound interest 
- Clear and strong positioning and value proposition

If you run a construction, manufacturing, or design business and want your online presence to finally reflect the quality of your work, reach out. We’d love to help: https://lnkd.in/eRkEQjAZ | 23 | 1 | 3 | 2w | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:22.638Z |  | 2025-11-19T20:47:17.102Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7396244599872303104 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d7b79118-e10c-41c8-a2e8-b46c817b8e14 | https://media.licdn.com/dms/image/v2/D4E05AQEK3Y-24EqdsQ/videocover-low/B4EZqS825bIUCE-/0/1763402113901?e=1765782000&v=beta&t=VpnWhdyZYhredX3881f9TONkfNxhnJvZatXBzPfGmTo | Check out what Incubella recently delivered for XDUB (www.xdub.io), an AI dubbing agent that enables you to dub your voice in 65+ languages on all 𝕏 videos and spaces, and still sound the same! 

They are powered by Speechlab, a high-tech AI provider part of Andrew Ng's AI startup portfolio.

Congrats to the team on launching their first AI agent demo live on 𝕏  🎉

If your company needs a new fancy landing page, grab a free consultation here: https://lnkd.in/eRkEQjAZ | 16 | 2 | 3 | 2w | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:22.638Z |  | 2025-11-17T17:55:28.189Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7395129352255926272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e102b87b-cbf4-466f-8b1d-976791e5697c | https://media.licdn.com/dms/image/v2/D4E05AQGsGaanzA4VQg/videocover-low/B4EZqDG3KsKoCE-/0/1763136225242?e=1765782000&v=beta&t=fHn19u2BHDK2itOXHt5n5AAAMvV_4xuqpeMzd1nm3W4 | I rarely post about the work we do at Incubella, but this one deserves a moment. And I'll start highlighting more of our work on here. 

We just shipped a new landing page for the SHAFT Foundation, the "Strategic Hub For AI-Focused Technology" which currently has a ton of momentum in the web3 community with over 10k developers and community members part of the foundation.

How did we do? If you need a landing page or custom software that’s clean, unique, fast, and built to convert, please reach out! We’re taking on a few more builds before year-end. | 19 | 3 | 3 | 3w | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:22.639Z |  | 2025-11-14T16:03:52.437Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7394777389194686464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/60273b2c-c912-46ba-b971-ac90c4f907a0 | https://media.licdn.com/dms/image/v2/D4E05AQEgunUFHdU2WQ/videocover-high/B4EZp.GUUdIwCI-/0/1763052277709?e=1765782000&v=beta&t=ROQgRFV5TLoNOgj69Vw6boSNwkapeKotLnz34Enm2WQ | Proud to finally showcase a product I've been building since August, and now in free public beta! (www.mysentiment.ai) 

SentimentAI helps brands, political teams, and companies with active communities understand what everyone is saying about them in real time: visualize sentiment shifts, trending narratives, engagement patterns, and more.

The problem:

Over 500 million tweets are posted every single day, making X the largest stream of human sentiment on the planet. No team — and no traditional LLM like ChatGPT or Grok — can manually or passively make sense of that firehose. That’s why understanding community pulse is becoming a competitive advantage.

A quick use-case example:

Imagine a major video game studio drops a new update. Overnight, thousands of players flood X/Twitter, Reddit, and Discord with reactions — excitement, frustration, bug reports, balance complaints, memes. Community managers and social media managers need to analuze thousands of data points and summarize the pulse of their community, often leading to inaccurate data points (for example: 30% of negative sentiment was saying our new in-game skin was ugly).

Traditional LLMs (including GROK) can summarize text, but they can’t truly capture the pulse of the community to specific numbers, as it shifts minute-by-minute, in real-time, and summarize accurately. 

SentimentAI does exactly that.

How it works (in simple terms):
 ➡️ Ingests all latest posts that include your keyword via the public 𝕏 API
 ➡️ Data runs through our proprietary AI model and algorithms
 ➡️ Classifies nuances, themes, sarcasm, narratives, and anomalies
 ➡️ Uses Grok-5 to process the data, summarize it, display it, and find unique and actionable data points. 

The goal is to give brands and creators actionable insights in order for them to improve their marketing / output initiatives, and eventually across the entire internet. 

We’re still very early, which is why your feedback means a lot right now!

SentimentAI is currently in open beta (meaning its free). Please make an account, give it a try, and let me know your thoughts! Be as brutally honest as possible with what works/doesn't work. 

Try it for free here 👉 www.mysentiment.ai | 52 | 15 | 4 | 3w | Post | Bilal Dhouib | https://www.linkedin.com/in/bilaldhouib | https://linkedin.com/in/bilaldhouib | 2025-12-08T06:20:22.640Z |  | 2025-11-13T16:45:17.904Z |  |  | 

---



---

# Bilal Dhouib
*Incubella*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Incubella -  Product and Marketing Studio](https://www.incubella.co/)
*2025-04-21*
- Category: article

### [Apply To Work With Us — Incubella Technologies](https://www.incubella.co/contact)
*2025-09-24*
- Category: article

### [Riipen | Incubella](https://app.riipen.com/companies/Wzw3NWzb)
*2025-09-05*
- Category: article

### [Bilel Tlohi - Co-fondateur - Ubby | LinkedIn](https://fr.linkedin.com/in/bilel-tlohi)
*2025-04-15*
- Category: article

### [Incubella: Reviews, Location, Price and More | MobileAppDaily](https://mobileappdaily.com/company/incubella)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
