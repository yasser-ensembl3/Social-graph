# Djalil Chikhi

## Position actuelle

**Titre** : Founder
**Entreprise** : erudi
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Leading a cross-functional team to shape and deliver the platform of tomorrow for locally specialized AIs. The future of AI specialization is here. Local, secure, and accessible to everyone.

## Résumé

My passion for science led me to pursue studies within the multidisciplinary MPCI program, subsequently guiding me to join the Computer Science department at INSA Lyon. Over the course of my academic journey, I became increasingly fascinated by the world of Information Technology and its profound global impact. I am currently pursuing a double degree at Polytechnique Montréal, where I specialize in research on LLMs. My aspiration is to deepen my expertise and contribute meaningfully to the advancement of the field of artificial intelligence.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADrvYxoBdldgfEe5SyRMF0ZMNglnRGn27cs/


---

# Djalil Chikhi

## Position actuelle

**Entreprise** : erudi

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Djalil Chikhi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391904763652571136 | Document |  |  | YOUR CHATS WITH AI DON’T BELONG ON SOMEONE ELSE’S COMPUTER.

Good news, your Mac can now do the job! Take back control of your data and install Erudi today, completely free 👉 erudi.app/download

We’ve poured so much effort into bringing this app to life, and we’re not done yet. Your feedback is the next step in our journey. | 8 | 0 | 0 | 1mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:27.117Z |  | 2025-11-05T18:30:30.604Z | https://www.linkedin.com/feed/update/urn:li:activity:7391806566850785281/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379394736496783360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJn0AaycHzdA/feedshare-shrink_800/B4EZmhQaeGGoAg-/0/1759347059384?e=1766620800&v=beta&t=WSl4hw9He4dxgA90jpHWOO_k45EWan0oTa1iUAIn348 | A little throwback to my summer internship at Onepoint Paris 🌍

I worked on a project involving code migration, where we had to move a company’s codebase (Scala -> PySpark). To make it work, I designed an architecture using AI agents, MCPs, and big context prompt engineering to handle very large code files. On top of that, we implemented full automation: CI/CD, automatic reports, and GitHub integration.

What I take away from this experience is how much AI can truly accelerate processes in companies when applied to concrete problems. With some research and development, we turned the project into a tool that's now used as a sales argument for major contracts and helps reduce migration time for teams.

This experience, combined with my time at RTE international , really strengthened my ability to reflect on large-scale company processes and build POCs ultimately accelerating existing workflows through the power of AI.

Big thanks to the great team I got to work with; Mathis BONKOUNGOU , Rachelle Nasr , Héloïse ROBIN and especially to Dian KANG for supervising the project, without whom it wouldn’t have been possible! | 34 | 4 | 0 | 2mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:27.119Z |  | 2025-10-02T06:00:07.705Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7366110356647084033 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABwEEXEeLoHISM2cU9LdzliLaQ.gif | J’ai le plaisir de vous annoncer que j’ai commencé mon diplôme de Research Master’s in AI à Polytechnique Montréal ! | 47 | 2 | 0 | 3mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:27.120Z |  | 2025-08-26T14:12:44.737Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7364597237953273857 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH-57nZYJ7jVA/feedshare-shrink_800/B4EZjRL6o0HoAg-/0/1755856220386?e=1766620800&v=beta&t=QtXMrwjg4qUppQzI3jVI6kxc9bI5TVbxMVl1rTLZIqQ | I was surprised to see that fine-tuning isn’t obvious to many clients but once they understood its potential use cases, they were truly impressed. A good reminder that even the greatest innovation only shines when it’s properly explained.

On a lighter note, I’m having a blast learning and growing with Erudi, and I’m really excited for its future. 😄 | 31 | 3 | 1 | 3mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:29.150Z |  | 2025-08-22T10:00:09.128Z | https://www.linkedin.com/feed/update/urn:li:activity:7364594779495505920/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7361743476020969472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHLKWdgnyQXSQ/feedshare-shrink_800/B4EZiltTORGoAk-/0/1755126773444?e=1766620800&v=beta&t=tSg0n6ZdRKC47RdQ8uf7ixAcUL-DS68M0DLdcbIgZf8 | 💬 First conversations with clients are always exciting!

This week I spoke to a lawyer and together we discussed erudi for his practice. In no time he had a personal AI assistant that could instantly tell him everything about his clients’ cases 📂, streamlining his work and saving him hours each week.

This was possible because erudi guarantees total privacy 🔒. The fine-tuned model now runs locally on a personal computer, so his sensitive client data never leaves his hands.

It is important to talk to your user base and truly understand their needs. We discussed features to add in the next version of erudi and we cannot wait for you to try it out.

Get a glimpse of the fine-tuning performance down below, and if you think erudi could help you too, head over to erudi.app and sign up for the waiting list. The application is launching very soon ⏳ | 31 | 2 | 7 | 3mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:29.152Z |  | 2025-08-14T13:00:19.263Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7357474154763223040 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABgBrZ2daanMQJ-egBdqUfzcNg.gif | J’ai le plaisir de vous annoncer que je commence un nouveau poste de CEO & Founder . | 44 | 1 | 0 | 4mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:29.162Z |  | 2025-08-02T18:15:33.755Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7356738136124583936 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGOwDXSW5QIpw/feedshare-shrink_2048_1536/B4DZhhd47FHYAo-/0/1753981886417?e=1766620800&v=beta&t=zGsQh74wnnGaXXkZBw6F91lWyNC68QpndAXseHSu1UY | I’ve never been prouder! Introducing Erudi, our new platform for local AI. 
I’m so proud of what our team has accomplished and it’s just the beginning.
Join us on our adventure! 
erudi.app | 29 | 7 | 6 | 4mo | Post | Djalil Chikhi | https://www.linkedin.com/in/djalil-chikhi | https://linkedin.com/in/djalil-chikhi | 2025-12-08T07:13:29.164Z |  | 2025-07-31T17:30:53.237Z | https://www.linkedin.com/feed/update/urn:li:activity:7356733248468594689/ |  | 

---



---

# Djalil Chikhi
*erudi*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Around the circular law - Libres pensées d'un mathématicien ordinaire](https://djalil.chafai.net/blog/2011/09/16/around-the-circular-law/)
*2011-09-16*
- Category: blog

### [start [جلیل]](https://djalil.chafai.net/wiki/)
*2025-04-16*
- Category: article

### [Erudience AI Solutions | লিংকডইন](https://bd.linkedin.com/company/erudience-ai)
*2025-05-11*
- Category: article

### [Erudera, the Higher Education Platform Built On AI featured in Forbes | Albania Tech](https://albaniatech.org/erudera-the-higher-education-platform-built-on-ai-by-gent-ukehajdaraj-from-kosovo/)
*2022-05-11*
- Category: article

### [ErudiFi - JDI Group](https://jdi.group/erudifi)
*2023-09-19*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
