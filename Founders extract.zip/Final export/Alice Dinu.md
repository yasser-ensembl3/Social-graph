# Alice Dinu

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Saris AI
**Durée dans le rôle** : 2 years 6 months in role
**Durée dans l'entreprise** : 2 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Building AI agents to streamline back-office workflows for banks and credit unions

## Résumé

Alice is a Customer-Centric Co-Founder of the largest international Ed-Tech mobile platform, Ready Education. She was recognized by Forbes 30 under 30 as a leader in the education space. Ready Education is an international company with offices in the USA, Canada, the UK, France, and the Netherlands, serving over 700 institutions world-wide and 7 million students.
 
Alice has over ten years of experience in customer success, data strategy, product-market fit, and M&A processes. She built and scaled B2B and B2C user acquisition and retention strategies for 400 Educational institutions across 4 million students. Build the thought leadership strategy by developing a research-based data strategy that measures student outcomes ROI, like retention and engagement at a series B Stage. 
 
Alice worked with renowned researchers to develop content and intervention strategies to increase a sense of belonging and mental health and reduce risky behaviors for college students. In addition, she participates in the start-up community as an angel investor, advisor, and guest speaker to numerous start-up networks like YCombinator, Founder Institute, and Founder Fuel.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAQnLQkBd17-NeOhfogNqyMkHgPaA3tLPCY/
**Connexions partagées** : 38


---

# Alice Dinu

## Position actuelle

**Entreprise** : Saris AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Alice Dinu

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396647036814630913 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEiHXEl9Y1RYQ/feedshare-shrink_800/B4EZqYrQ2mIoAg-/0/1763498073548?e=1766620800&v=beta&t=CsMYXZqy9WXCm3I92CdMjJN6etqkW-7M8cveLPseI4c | Honored to speak at the Women Leading in AI breakfast session at the #MomentumAI in Finance summit this morning.

Huge thank you to Erika Musso (Reuters) and the Reuters team for bringing together such a powerful group of leaders, and to my incredible co-panelists Charu M. (Mastercard) and Nina Edwards (Prudential) for such a rich, and inspiring panel.

A core idea we discussed:
👉 AI succeeds when teams communicate clearly and align on the impact they want to create.

Back-office operations like loan origination emerged as some of the highest-leverage areas, where AI can take on administrative work while teams stay in the loop and focus on the tasks that truly drive ROI.

Inspiring to see so many women leaders shaping the future of AI in financial services.
Onward. 🚀

#WomenInAI #AIBanking #AICreditUnion #AIStrategy #MomentumAI #Aidinance #ReutersEvents #SarisAI | 33 | 2 | 1 | 2w | Post | Alice Dinu | https://www.linkedin.com/in/alice-dinu-b214011b | https://linkedin.com/in/alice-dinu-b214011b | 2025-12-08T04:59:24.647Z |  | 2025-11-18T20:34:36.633Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7383306396232065025 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFRYoX_7ja72g/feedshare-shrink_800/B56ZmrRIRqH8Ag-/0/1759515018866?e=1766620800&v=beta&t=zfjY5AdcKlktpPX8oFdHh3w5h8sBs8bnC599DnjsiVc | 🚀 Saris AI is scaling!
We’re looking for exceptional #ProductManagers and Solution Engineers with a consulting background in banking operations to join our growing team.

If you’re passionate about transforming how financial institutions work with AI, let’s connect! | 23 | 2 | 1 | 1mo | Post | Alice Dinu | https://www.linkedin.com/in/alice-dinu-b214011b | https://linkedin.com/in/alice-dinu-b214011b | 2025-12-08T04:59:24.647Z |  | 2025-10-13T01:03:40.061Z | https://www.linkedin.com/feed/update/urn:li:activity:7379940885221986304/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7323043846311796736 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQExCattyBQlCw/feedshare-shrink_800/B4DZaCInBIGcAg-/0/1745940021058?e=1766620800&v=beta&t=qWm9sTIg33xN-Cyg5xdimL5pGpsjkofEJ3z63nhm6kQ | Great to be at #MomentumAI in NYC where Danial Jameel from #SarisAI spoke alongside leaders from Prudential and TIAA. A powerful conversation on how agentic AI is driving real, measurable impact in banking. | 14 | 0 | 0 | 7mo | Post | Alice Dinu | https://www.linkedin.com/in/alice-dinu-b214011b | https://linkedin.com/in/alice-dinu-b214011b | 2025-12-08T04:59:24.648Z |  | 2025-04-29T18:01:48.536Z | https://www.linkedin.com/feed/update/urn:li:activity:7323003222556598272/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7274466008633860096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGmJJPjIiPh1A/feedshare-shrink_800/B4EZPLg1X7HwAg-/0/1734286203818?e=1766620800&v=beta&t=dnOYx7HEmX8eMkVSds3k0-7eV_S6M5o3M060Yfro-CI | What an incredible book! Mindmasters: The Data-Driven Science of Predicting and Changing Human Behavior by Sandra Matz 

I’m forever grateful to Sandra for introducing me to the fascinating intersection of data, AI, and human behavior. This book is a must-read for anyone curious about how technology shapes our decisions and how our digital footprints, in turn, shape technology itself.

Check it out: https://a.co/d/69wHux9 | 7 | 2 | 1 | 11mo | Post | Alice Dinu | https://www.linkedin.com/in/alice-dinu-b214011b | https://linkedin.com/in/alice-dinu-b214011b | 2025-12-08T04:59:24.649Z |  | 2024-12-16T16:50:49.501Z | https://www.linkedin.com/feed/update/urn:li:activity:7274123568471281664/ |  | 

---



---

# Alice Dinu
*Saris AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Customer Success Best Practices: A Startup Master Session with Alice Dinu](https://fi.co/insight/customer-success-best-practices-with-alice-dinu)
*2024-11-27*
- Category: article

### [Alice Dinu Email & Phone Number | Saris AI Co-Founder Contact Information](https://rocketreach.co/alice-dinu-email_5699975)
*2025-01-01*
- Category: article

### [The implementation of Saro marks the most important step in integrating AI into Romania's education system - Business Review](https://business-review.eu/education/the-implementation-of-saro-marks-the-most-important-step-in-integrating-ai-into-romanias-education-system-281416)
*2025-04-03*
- Category: article

### [Meet Alice: The AI That Thinks With You, Not For You](https://medium.com/@curiouser.ai/meet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174)
*2024-08-25*
- Category: blog

### [Alice - World's AI SDR | 11x AI](https://11x.ai/f/alice)
*2024-11-01*
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 10,675 words total*

### Customer Success Best Practices: A Startup Master Session with Alice Dinu
*1,020 words* | Source: **EXA** | [Link](https://fi.co/insight/customer-success-best-practices-with-alice-dinu)

[Alice Dinu](https://www.linkedin.com/in/alice-dinu-b214011b/?originalSubdomain=ca) is a Forbes 30under30 business leader, and the Co-Founder & VP for Student Success and Research at[Ready Education](https://www.readyeducation.com/), the leading mobile platform in the Ed-tech space.Dinu is a mentor for the [Montreal Founder Institute](http://fi.co/apply/montreal/blog), and brings nearly a decade of customer success experience in scaling Ready Education from a small mobile app to what is today a team of 70+ whose platform serves 350+ higher educational institutions and universities.

**The topic of Customer Success can at times feel abstract. But in reality, nothing is more tangibly important to your startup's own success than ensuring your customers achieve their desired result when using your product or service. In this latest FI Alumni webinar, EIR [Mike Suprovici](https://www.linkedin.com/in/mikesuprovici/)speaks with Customer Success expert Alice Dinu about the best practices Founders can use when****building****an exceptional customer experience that drives renewals and long-term growth.**

Watch to gain an in-depth understanding of Customer Success best practices:define what success looks like for your own startup’s customers,and how you can build a customer journey that ensures renewals and set your customers up for success:

Below, we highlight some the top takeaways from Dinu’s presentation – but we encourage you to watch the full video interview above to view her entire presentation!

* * *

Dinu opens her presentation with some conceptual equations:

*   **New business + Renewals/Upsells = Startup Survival**
*   **New business - Churn = Eventual Startup Death**
*   **New sales ≠ Renewals**

![Image 1](https://fi-hatchbox-production-uploads.s3.amazonaws.com/drive/CustomerSuccessTeam_Liaise.png)

Dinu says that Customer Success teams should produce cross-functional impact—so to be most effective, they should be working directly with Sales, Product, and Marketing teams to facilitate upsells, referrals, customer feedback, partnerships, case studies, and more to ensure best CS practices.

* * *

**Customer Success ≠ Customer Support**
---------------------------------------

*   Customer Support – reactive, firefighting immediate requests
*   Customer Success – proactive, managing lifecycle & driving growth
*   (Source, Slide 12: [Natero](https://www.natero.com/customer-success/))

For early-stage companies, it is perfectly okay and normal for the same individual to be doing both roles—but it is very important to not fall into the trap of _waiting_ for customers to bring issues up, but instead to have your CS team working with your customers proactively to deliver the success they expect.

* * *

![Image 2](https://fi-hatchbox-production-uploads.s3.amazonaws.com/drive/CustomerJourneyMap.png)

**Customer Journey Maps** - charting the path a customer takes from beginning of their journey until the satisfaction of their particular need. (Source, Slide 14: [CMSC Media](https://www.cms-connected.com/News-Archive/November-2018/Customer-Journey-Mapping-for-the-Growing-Business))

**Why do you need a Customer Journey?**
---------------------------------------

*   Engineer repeatable success results
*   Blueprint for future iterations
*   Clarity on customer interactions

* * *

**Customer Success Approaches: High Touch VS Low Touch**
--------------------------------------------------------

*   **High Touch:** High Annual Contract, B2B/Enterprise Sales, >$20k+ contracts, complex technical setup or extensive training after purchase
*   **Low Touch:**SMBs/Consumer products, simple onboarding experience requiring little training

* * *

**Understanding B2B Model Customers: Executives VS End Users**
--------------------------------------------------------------

*   **Executives: Above the Line = “ATL”**– demand ROI (cost savings, increased productivity), care less about small product features and prefer to have strategic conversations.
*   **End Users: Below the Line = “BTL”**– care a lot about your product, and want it to make their lives easier.

1.   You need to create relationships with BOTH executives and end users!
2.   While end user input is valuable to executives, executives also trump end users in all decision-making
3.   Onboarding: define very specifically what a successfully “launched customer” means for your business.
4.   BOTH ATL & BTL stakeholders (executives & end users) should be engaged in the Kickoff call
5.   Implement Net Promoter Score!
6.   Executive reviews (whether reports or reviewing a dashboard) are all about ROI (quantitative) & strategy (qualitative) – this is a chance to set objectives, as well as present expansion opportunities

![Image 3](https://fi-hatchbox-production-uploads.s3.amazonaws.com/drive/OnboardingProcess.png)

> Renewal strategy should start at Day 0.

* * *

Customer Success KPIs:
----------------------

*   Renewals & Churn
*   Customer Engagement – are they see

*[... truncated, 2,541 more characters]*

---

### Just a moment...
*26 words* | Source: **EXA** | [Link](https://rocketreach.co/alice-dinu-email_5699975)

![Image 1: Icon for rocketreach.co](https://rocketreach.co/favicon.ico)rocketreach.co
-------------------------------------------------------------------------------------

Verify you are human by completing the action below.

rocketreach.co needs to review the security of your connection before proceeding.

---

### The implementation of Saro marks the most important step in integrating AI into Romania's education system - Business Review
*1,299 words* | Source: **EXA** | [Link](https://business-review.eu/education/the-implementation-of-saro-marks-the-most-important-step-in-integrating-ai-into-romanias-education-system-281416)

The implementation of Saro marks the most important step in integrating AI into Romania's education system - Business Review

===============

[](http://www.facebook.com/pages/Business-Review/90107703284?ref=nf)[](http://www.twitter.com/BR_RO)[](https://www.linkedin.com/company/business-review/)[](https://www.instagram.com/businessreview_br/)[](https://www.youtube.com/c/business-review)

[![Image 7](https://business-review.eu/wp-content/themes/business-review/assets/images/logo.svg)](https://business-review.eu/)

[![Image 8](https://business-review.eu/wp-content/uploads/2025/02/BGB_Work-Life-Business_Review_728x90-px.png)](https://bucharest.businessgarden.eu/)

[](javascript:void(0))

*   [Events](https://business-review.eu/events)
*   [Magazine](https://business-review.eu/category/magazine)
*   [#FutureofWork](https://business-review.eu/category/future-of-work)
*   [#CIRCULARIO](https://business-review.eu/category/circulario)
*   [#COMPETITIV](https://business-review.eu/category/competitiv)
*   [Business](https://business-review.eu/category/business)
*   [Property](https://business-review.eu/category/property)
*   [Money](https://business-review.eu/category/money)
*   [Tech](https://business-review.eu/category/tech)
*   [Investments](https://business-review.eu/category/investments)
*   [Sustainability](https://business-review.eu/category/sustainability)
*   [Lifestyle](https://business-review.eu/category/lifestyle)

[Education](https://business-review.eu/category/education)

The implementation of Saro marks the most important step in integrating AI into Romania’s education system
==========================================================================================================

[Simona Hrincescu](https://business-review.eu/author/simona-hrincescu)03/04/2025 | 12:25

[Twitter](http://twitter.com/share?text=The%20implementation%20of%20Saro%20marks%20the%20most%20important%20step%20in%20integrating%20AI%20into%20Romania%E2%80%99s%20education%20system&url=https://business-review.eu/education/the-implementation-of-saro-marks-the-most-important-step-in-integrating-ai-into-romanias-education-system-281416)[Facebook](http://www.facebook.com/sharer.php?u=https://business-review.eu/education/the-implementation-of-saro-marks-the-most-important-step-in-integrating-ai-into-romanias-education-system-281416)[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://business-review.eu/education/the-implementation-of-saro-marks-the-most-important-step-in-integrating-ai-into-romanias-education-system-281416)

![Image 9](https://media.business-review.eu/unsafe/420x250/smart/filters:contrast(5):quality(80)/business-review.eu/wp-content/uploads/2025/04/CP_Ro.png)

**Digital Nation and the Ministry of Education and Research announce a partnership for the implementation of Saro, a concrete and functional AI-based solution, in schools and universities across Romania — the most significant step within the ministry’s initiative to integrate Artificial Intelligence into education.**

The Ministry of Education and Research will support the implementation of the solution in educational institutions across the country. Soon, the first university in Romania where students will directly benefit from Saro’s support will be officially announced.

[![Image 10](https://business-review.eu/wp-content/uploads/2023/07/myhive_banner_970x250px_2.gif)](https://myhive-offices.com/en/)

For the first time in Romania, students, pupils, and teachers will have access to an AI-powered assistant designed to address major challenges in education—such as school dropout, excessive bureaucracy, declining motivation, the need for personalized learning, and low class attendance. For instance, students may be greeted in the morning with conversations about weekly planning, important academic events, or reflections on a recent exam.

So far, Saro has demonstrated a measurable impact on the learning process. The solution was piloted through the Generația Tech program with 1,900 young people and adults, providing impressive results: participants who interacted with Saro completed 28% more assignments compared to those who did not, and attendance at extracurricular events introduced by Saro increased by 89%. Additionally, nearly 20,000 messages have been exchanged between program participants and Saro to date.

[![Image 11](https://media.business-review.eu/unsafe/400x236/smart/filters:contrast(5):quality(80)/business-review.eu/wp-content/uploads/2025/12/Valentin-Ivanescu-CEO-FDP-scaled.jpg)](https://business-review.eu/profiles1/whoss-news/fabrica-de-profile-strengthens-its-management-team-by-appointing-valentin-ivanescu-as-ceo-291618)

Read more about

[Fabrica de Profile strengthens its management team by appointing Valentin Ivănescu as CEO](https://business-review.eu/profiles1/whoss-news/fabrica-de-profile-strengthens-its-management-team-by-appointing-valentin-ivanescu-as-ceo-291618)

[read more](https://business-review.eu/profiles1/whoss-news/

*[... truncated, 17,012 more characters]*

---

### Meet Alice: The AI That Thinks With You, Not For You
*1,329 words* | Source: **EXA** | [Link](https://medium.com/@curiouser.ai/meet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174)

Meet Alice: The AI That Thinks With You, Not For You | by Curiouser.AI | Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F0b6b5e8bb174&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40curiouser.ai%2Fmeet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40curiouser.ai%2Fmeet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

Meet Alice: The AI That Thinks With You, Not For You
====================================================

[![Image 4: Curiouser.AI](https://miro.medium.com/v2/resize:fill:64:64/1*RQhuSiBeykiTK6qLSmOt8Q.png)](https://medium.com/@curiouser.ai?source=post_page---byline--0b6b5e8bb174---------------------------------------)

[Curiouser.AI](https://medium.com/@curiouser.ai?source=post_page---byline--0b6b5e8bb174---------------------------------------)

Follow

3 min read

·

Aug 25, 2024

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F0b6b5e8bb174&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40curiouser.ai%2Fmeet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174&user=Curiouser.AI&userId=b3f7c93c4ed2&source=---header_actions--0b6b5e8bb174---------------------clap_footer------------------)

3

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F0b6b5e8bb174&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40curiouser.ai%2Fmeet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174&source=---header_actions--0b6b5e8bb174---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3D0b6b5e8bb174&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40curiouser.ai%2Fmeet-alice-the-ai-that-thinks-with-you-not-for-you-0b6b5e8bb174&source=---header_actions--0b6b5e8bb174---------------------post_audio_button------------------)

Share

Press enter or click to view image in full size

![Image 5](https://miro.medium.com/v2/resize:fit:700/1*uTfu9JBzcxAdBecw-mDZfQ@2x.jpeg)

In today’s rapidly evolving technological landscape, AI is becoming a ubiquitous tool in businesses of all sizes. Yet, as AI adoption grows, so does a peculiar trend – many of us are becoming prompt engineers, learning how to communicate with AI in its language instead of the other way around. Why are we bending ourselves to fit the needs of machines? Shouldn’t it be the other way around?

Introducing Alice, an AI designed with a fundamentally different approach. Alice doesn’t just perform tasks; she collaborates with you. She’s not just another tool in your arsenal; she’s a partner in your success, guiding you through the complexities of modern business with intelligence, empathy, and creativity.

### What Makes Alice Different?

Alice is a custom-built, enterprise-grade Generative AI that transcends traditional automation. Here’s how Alice stands out:

### 1. Collaborative Intelligence

Alice is more than just a machine that executes commands; she’s an AI that thinks alongside you. Through meaningful and intelligent dialogue, Alice engages in conversations that help you unlock deeper insights, generate new ideas, and think more strategically. She’s not about replacing your thinking – she’s about enhancing it.

One of Alice’s core strengths is her ability to remember past interactions. This memory allows her to build on previous conversations, providing contextually relevant advice and ensuring continuity in your strategic thinking. Whether you’re brainstorming, planning, or executing, Alice is there to guide and support you, helping you see around corners and anticipate opportunities.

### 2. Empowerment Over Automation

While many AI solutions focus on automating tasks to save time and reduce costs, Alice takes a different approach. Alice empowers you by enhancing your creativity, problem-solving abilities, and critica

*[... truncated, 24,578 more characters]*

---

### Alice - World's AI SDR | 11x AI
*1,009 words* | Source: **EXA** | [Link](https://11x.ai/f/alice)

Hi, I'm Alice.
--------------

The world's best SDR. I track every data point of your market, identify your ideal buyers, and engage decision-makers 24/7 to book you meetings on autopilot.

Alice - AI SDR

Avaliable now

![Image 1](https://cdn.prod.website-files.com/66fe5a1a88c73ef8f270d312/672e2369f29e8f8dbc5d1fe0_Group%201000006017.png)

Use Cases
---------

All of your outbound running on autopilot, using the power of AI Agents. From start to finish, Alice will turn your market signals into SQLs.

![Image 2: Track Your Market](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/c778822e-45df-4e71-b186-46b7fa37cb07.webp)

### Track Your Market

Track every lead in your market in real-time. Produce detailed research on demand, monitor for key buying signals, or find new ICPs.

![Image 3: Engage Key Accounts](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/388693ab-ef6f-4ece-929a-aa9b6e5fd071.webp)

### Engage Key Accounts

Account-based marketing at scale. Engage key decision-makers with multithreading and personalized value propositions.

![Image 4: Generate Demand](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/47a16b67-1d92-428c-b6e1-b109bb50de06.webp)

### Generate Demand

Bring all stakeholders into the conversation. Drive event sign-ups, share case studies, and spread awareness to convert leads to buyers.

![Image 5: Activate High-Intent Leads](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/ef2b2ede-a774-4b97-be25-8b4d8c28db59.webp)

### Activate High-Intent Leads

Automatically action high-intent leads visiting your website, changing jobs, or actively searching for solutions like yours.

![Image 6: Revive Leads](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/5cb8c30e-2826-4056-b6c3-8208e61ae91a.webp)

### Revive Leads

Alice resurrects dead and old leads. She rekindles old conversations and uncovers fresh opportunities from your CRM. Turn your forgotten leads into a goldmine of new revenue.

![Image 7: Reach New Markets](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/4bf10df2-d006-429f-83ae-5ced5301fc21.webp)

### Reach New Markets

Accelerate your expansion to international markets in over 105 languages.

01

### Intelligent Buyer Targeting

Deep market research that goes beyond traditional contact databases to autonomously book meetings with buyers at scale.

Track and engage every buyer on Earth in real-time

Lead scoring engine that targets your highest-intent prospects

02

### Personalized and Adaptive Messaging

Ditch the email templates. Alice combines deep prospect research with self-improving messaging to craft conversations that convert.

Leverage behavioral signals to pinpoint each prospect's true pain points

Strategic, multi-touch campaigns that make you stand out, executed autonomously

03

### Always-On, Always Improving

Built on breakthrough AI agent research to book you meetings autonomously from day one, and improve with every interaction.

Continuously prospects, handles replies, and schedules meetings to build you pipeline 24/7

Autonomous prospecting that improves with every interaction

![Image 8: Feature 1 illustration](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/2c62c002-19b7-4364-9033-1ce037abf145.webp)

### Sales

10x your pipeline and never miss quota again. Alice fills your calendar with qualified buyers so your team can focus on closing deals.

![Image 9: Feature 2 illustration](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/94a3306e-634a-424d-8f8f-498bdb37a8ef.webp)

### Marketing

Activate leads across across every stage of the funnel. Automatically nurture leads, drive event sign-ups, and re-engage stale prospects.

![Image 10: Feature 3 illustration](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/e7b23b31-1ee6-4aca-888a-f4716e2f6123.webp)

### Revenue Operations

Qualify inbound leads, clean and enrich your CRM data, and streamline your team's tech stack.

### Before Alice

Human Workforce

![Image 11: SDR Profile 1](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/374bd7f4-35a3-4f64-9216-e8ace77feb0d.webp)

SDR

![Image 12: SDR Profile 2](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/529ab182-7f7a-41e2-82ff-2ed6ce6af98e.webp)

SDR

![Image 13: SDR Profile 3](https://rwqqrnsxhishecvdnalx.supabase.co/storage/v1/object/public/assets/2a0880b5-7a21-4f52-a4a2-4ff13a8569e8/f350671b-68a5-4829-96d

*[... truncated, 13,985 more characters]*

---

### Alice Dinu | How Women Lead
*304 words* | Source: **GOOGLE** | [Link](https://www.howwomenlead.com/all-cohorts-global-advisors/alice-dinu)

About

 Me.
-----------

I am Alice Dinu, 37 years old, a passionate entrepreneur dedicated to empowering and supporting aspiring female entrepreneurs.

I co-founded and successfully exited Ready Education, the largest international Ed-Tech mobile platform, impacting the lives of 7 million students across 700 institutions worldwide.

With over a decade of expertise in customer success, data strategy, and product-market fit, I have positively influenced millions of students through innovative strategies for educational institutions. I had the honor of being recognized as leader in education by Forbes 30 under 30 and had the opportunity to collaborate with renowned researchers from Duke Health and Columbia University to further enhance the student experience in colleges and universities.

Currently, I'm embarking on my second startup journey in AI while advising a diverse range of startups in industries like education, biotech, manufacturing software, and health applications. My comprehensive expertise spans critical aspects of entrepreneurial growth, including customer success, data strategy, thought leadership, and M&A processes. As an angel investor, advisor, and speaker at esteemed startup networks like YCombinator, Founder Institute, and Founder Fuel, I am wholeheartedly dedicated to nurturing the next generation of entrepreneurs.

In addition to entrepreneurship, I strongly believe in the importance of maintaining a healthy lifestyle and fostering an environment that supports personal well-being. Prioritizing self-care practices such as nutrition, mental health awareness, exercise, and meditation is crucial for entrepreneurs to excel in all aspects of life.

I genuinely believe in the power of mentorship to unlock one's full potential. Together, we can navigate the intricacies of entrepreneurship, identify growth opportunities, and strategize for long-term success. My ultimate goal is to empower you with knowledge, resources, and the confidence necessary to thrive in the competitive business landscape. I am excited about the possibility of working together and supporting you on your entrepreneurial journey to create exceptional results.

---

### Momentum AI Finance 2025
*5,688 words* | Source: **GOOGLE** | [Link](https://events.reutersevents.com/momentum/finance/agenda)

Momentum AI Finance 2025

===============

[](https://events.reutersevents.com/momentum/finance/agenda)

![Image 1: Reuters Events](https://d3m889aznlr23d.cloudfront.net/img/events/id/459/459187412/assets/1adf505aeddb53e0b2ce79993c20b8c5.logo.png)

[](https://events.reutersevents.com/momentum/finance/agenda)

Momentum AI Finance 2025

[](https://events.reutersevents.com/momentum/finance/agenda)

[](https://events.reutersevents.com/momentum/finance/agenda)

17

Nov

–

18

Nov

,

2025

[](https://events.reutersevents.com/momentum/finance/agenda)

New York

[](https://events.reutersevents.com/momentum/finance/agenda)

1200+

[](https://events.reutersevents.com/momentum/finance/agenda)

Attendees

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

Time • Day

[](https://events.reutersevents.com/momentum/finance/agenda)

Presentation

[](https://events.reutersevents.com/momentum/finance/agenda)

 Title

[](https://events.reutersevents.com/momentum/finance/agenda)

Speakers

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

•

[](https://events.reutersevents.com/momentum/finance/agenda)

The plenary, panel, and forum will all be joined from your main Virtual Event Page personalized link.

[](https://events.reutersevents.com/momentum/finance/agenda)

![Image 2: Reuters Events](https://d3m889aznlr23d.cloudfront.net/img/events/id/459/459187412/assets/1adf505aeddb53e0b2ce79993c20b8c5.logo.png)

[](https://events.reutersevents.com/momentum/finance/agenda)

![Image 3: Reuters Events](https://d24wuq6o951i2g.cloudfront.net/img/events/id/458/458201271/assets/9c4520bcce8406676ca17d90ee48df94.Reuters_Dark-Logo.png)

[](https://events.reutersevents.com/momentum/finance/agenda)

Home

[Home](https://events.reutersevents.com/momentum/finance)

[Speakers](https://events.reutersevents.com/momentum/finance/speakers)

[Agenda](https://events.reutersevents.com/momentum/finance/agena)

[Sponsors](https://events.reutersevents.com/momentum/finance/sponsors)

[Become A Sponsor](https://events.reutersevents.com/momentum/finance/become-sponsor)

[Download Brochure](ht

*[... truncated, 69,637 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Alice Dinu | How Women Lead](https://www.howwomenlead.com/all-cohorts-global-advisors/alice-dinu)**
  - Source: howwomenlead.com
  - *< Back. Previous. Alice Dinu. Co-Founder - Saris AI /Ready Education. Technical Expertise. Content Expertise. Other Areas of Expertise. Board/ ......*

- **[Momentum AI Finance 2025](https://events.reutersevents.com/momentum/finance/agenda)**
  - Source: events.reutersevents.com
  - *This interview is being conducted by a Reuters journalist under the Reuters Trust Principles ... Alice Dinu, Co-Founder, Saris AI. Nina Edwards, VP, E...*

---

*Generated by Founder Scraper*
