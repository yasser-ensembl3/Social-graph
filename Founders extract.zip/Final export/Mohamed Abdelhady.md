# Mohamed Abdelhady

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : BinWin
**Durée dans le rôle** : 7 months in role
**Durée dans l'entreprise** : 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Backed by McGill's Dobson and Engine Centres for Entrepreneurship, BinWin is a B2B software platform that turns waste into wealth. At BinWin, we connect businesses with excess resources—such as surplus, scraps, and obsolete inventory—to businesses that need them. By enabling sellers to monetize unused materials and buyers to source valuable inputs at lower cost, BinWin helps businesses save costs, generate value, and drive sustainability.

## Résumé

Co-Founder & CEO of BinWin, a B2B platform turning waste into wealth. Computer Engineering student and scholarship recipient at McGill University. Previous experience includes roles as a Technology Summer Analyst at Morgan Stanley, Space Systems Engineering Intern at MDA Space, Data Engineering & BI Intern at SC Johnson, and Software Engineering Intern at Trax Group.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAD5tTycBcLj0GI_YiabYRYIFc-Y1N1meWjw/
**Connexions partagées** : 5


---

# Mohamed Abdelhady

## Position actuelle

**Entreprise** : IBM

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mohamed Abdelhady

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400985154262888448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHsfDYK6vMcxQ/feedshare-shrink_800/B4EZrWCcEMJ0Ag-/0/1764527556660?e=1766620800&v=beta&t=88cr5lgAMqC9mlz9WkgHCkG9hz5Lf15H07Ub-YS9cCs | Three months of hard work with an incredible team — really proud of the work we delivered. | 64 | 24 | 0 | 1w | Post | Mohamed Abdelhady | https://www.linkedin.com/in/mohamedabdelhady-mcgill | https://linkedin.com/in/mohamedabdelhady-mcgill | 2025-12-08T06:21:04.461Z |  | 2025-11-30T19:52:44.431Z | https://www.linkedin.com/feed/update/urn:li:activity:7400964997125713920/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7376353134320775168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHwJkRhqSxDzw/feedshare-shrink_800/B4EZl4SFojIUAk-/0/1758659632039?e=1766620800&v=beta&t=cvE86YJS-X-pKkPUFTaV9L0tUzw9sjhkp76_JrQ7mqs | Excited to share that I am starting a role as an Associate Consultant at IBM through the IBM Pro-Bono Consulting Program.

Honored to be selected as Project Manager, leading a team of McGill consultants in delivering client-focused solutions under IBM’s mentorship.

Looking forward to applying structured problem-solving and teamwork to drive real impact. | 186 | 82 | 0 | 2mo | Post | Mohamed Abdelhady | https://www.linkedin.com/in/mohamedabdelhady-mcgill | https://linkedin.com/in/mohamedabdelhady-mcgill | 2025-12-08T06:21:04.462Z |  | 2025-09-23T20:33:53.236Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7323068006660534272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEBl_fnwA9eQ/feedshare-shrink_800/B4EZaDDi2eHIAg-/0/1745955467165?e=1766620800&v=beta&t=ZLcVGWTfYus4tPdNXmo0oeOwLgYOcsnu0dECGfvMKsI | Excited to share that I’ll be joining Morgan Stanley as a Technology Summer Analyst for the Summer of 2025.

Looking forward to contributing to impactful projects and continuing to grow in a fast-paced environment. | 208 | 140 | 0 | 7mo | Post | Mohamed Abdelhady | https://www.linkedin.com/in/mohamedabdelhady-mcgill | https://linkedin.com/in/mohamedabdelhady-mcgill | 2025-12-08T06:21:04.462Z |  | 2025-04-29T19:37:48.812Z |  |  | 

---



---

# Mohamed Abdelhady
*IBM*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [](https://www.egypes.com/speaker-collection/tc-co-chair-api-2024/mohamed-abd-elhady/)
- Category: article

### [Mohamed Abdelhady](https://scholar.google.com/citations?user=tQGdPcwAAAAJ&hl=en)
*2016-10-20*
- Category: article

### [Mohamed Ahmed](https://newsroom.ibm.com/mohamed-ahmed)
*2025-01-01*
- Category: article

### [IBM Newsroom - Middle East & Africa](https://mea.newsroom.ibm.com/podcasts)
*2025-01-01*
- Category: podcast

### [IBM Champion Spotlight: Mahmoud Abdelrahman](https://community.ibm.com/community/user/blogs/oussama-el-jendoubi/2025/06/03/ibm-champion-spotlight-mahmoud-abdelrahman)
*2025-06-03*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Effects of Prehospital Thrombolysis in Stroke Patients With Prestroke ...](https://www.ahajournals.org/doi/10.1161/strokeaha.117.019060)**
  - Source: ahajournals.org
  - *Feb 19, 2018 ... For statistical analyses of the data, we used IBM SPSS Statistics version 22 (IBM ... Mohamed Abdelhady Mostafa,; Mohamed Elfil,; Moh...*

- **[Comparison of worldwide prevalence of stroke over the last 20 years ...](https://www.researchgate.net/figure/Comparison-of-worldwide-prevalence-of-stroke-over-the-last-20-years_tbl3_40041212)**
  - Source: researchgate.net
  - *Mohamed Abdelhady Mohamed · Amir Abd-Alghafar · Abdel-Azim ... A structured database containing the data was utilized, and IBM SPSS Statistics for Win...*

- **[PriMera Scientific Engineering | International Journal](https://primerascientific.com/psen/editorialboard)**
  - Source: primerascientific.com
  - *Asmaa Abdelhady Mohamed Abdelhady. Department of Computer and Information ... ), DMS(IBM), and Honorary Doctors in SW/Humanities. He has 18 years of ....*

- **[(PDF) The Effect of Ambient Conditions and Space/Function on ...](https://www.researchgate.net/publication/371038490_The_Effect_of_Ambient_Conditions_and_SpaceFunction_on_Favorable_Behavioral_Intentions_of_Philippine_Airlines_Passengers)**
  - Source: researchgate.net
  - *Aug 7, 2025 ... Discovering statistics using IBM SPSS statistics (4th ed.). Sage ... Mohamed Abdelhady · Nancy M. Fawzy Gamal ......*

- **[Proceedings of the 2021 Conference of the North American Chapter ...](https://aclanthology.org/2021.naacl-industry.0.pdf)**
  - Source: aclanthology.org
  - *May 20, 2021 ... Yunyao Li, IBM, Inc. (yunyaoli@us.ibm.com). Owen Rambow, Stony Brook University (owen.rambow@stonybrook.edu). Reviewers. We thank our...*

- **[Proceedings of the 2024 Conference of the North American Chapter ...](https://aclanthology.org/2024.naacl-industry.0.pdf)**
  - Source: aclanthology.org
  - *Jun 21, 2024 ... Mohamed Abdelhady, Amazon. Sachin Agarwal, Apple. Prabhat Agarwal ... Ankush Gupta, IBM India Research Lab. Dilek Hakkani-Tur, Univer...*

- **[Interspeech 2021 Conference Sessions, Speakers and Papers – Rob](https://banagale.com/interspeech-2021-conference-sessions-speakers-and-papers.htm)**
  - Source: banagale.com
  - *Aug 29, 2021 ... ... Mohamed AbdelHady · Personalized PercepNet: Real-time, low ... IBM? wp:paragraph –>. Daniel Korzekwa, Jaime Lorenzo-Trueba, Thoma...*

- **[IDENTIFYING PREDICTIVE COMPONENTS OF EGG WEIGHT IN ...](https://journals.ekb.eg/article_436828_0cadda76683d225d0e1c6c1f727d6a16.pdf)**
  - Source: journals.ekb.eg
  - *Jun 16, 2025 ... of Agric., Assiut Uni. Corresponding author: Mohamed Abdelhady E-mail: Mohamed.abdelhady@agr.aun.edu.eg ... Using IBM SPSS statistics...*

- **[Workshop on Machine Learning in Speech and Language ...](https://homepages.inf.ed.ac.uk/htang2/sigml/mlslp2021/)**
  - Source: homepages.inf.ed.ac.uk
  - *Sep 6, 2021 ... ... Mohamed Abdelhady Amazon Alexa AI; Context Shuffling and ... Xiaodong Cui IBM. Bhuvana Ramadabran Google. Liang Lu Microsoft. Huay...*

- **[P- ISSN: 2636-4174 E- ISSN: 2682-3780](https://journals.ekb.eg/article_384738_0901bd4d9ba87f6e4ba04c5d495c95af.pdf)**
  - Source: journals.ekb.eg
  - *... Mohamed Abdelhady Alkhrsawy 2,. El Sayed Abouzid Ibrahim 1, Amr Al ... It was created by IBM Corporation and is based in Armonk, New. York. The da...*

---

*Generated by Founder Scraper*
