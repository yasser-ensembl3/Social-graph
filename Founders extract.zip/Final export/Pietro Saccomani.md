# Pietro Saccomani

## Position actuelle

**Titre** : Founder
**Entreprise** : MobiLoud
**Durée dans le rôle** : 12 years 5 months in role
**Durée dans l'entreprise** : 12 years 5 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

MobiLoud helps ecommerce brands turn their websites into high performance mobile apps with push notifications that drive retention, engagement, and repeat purchases. Reuse your existing site, design, and integrations to launch fully branded iOS and Android apps in weeks with expert ongoing support.

We worked with brands like ONLY, Vero Moda, Jack&Jones, buybuyBaby, Rainbow Shops, John Varvatos to launch their mobile apps faster and more affordably than with any alternative.

## Résumé

Hi, I’m Pietro. I run MobiLoud, where we help ecommerce brands turn their websites into high-performance mobile apps with push notifications, driving retention and revenue.

We work with fast-growing retail and DTC brands, marketplaces, and subscription businesses. Our platform lets teams launch fully functional mobile apps without rebuilding anything or managing a separate codebase. The goal is simple: make mobile a high-leverage owned channel that drives repeat purchases.

I also publish The Retention Edge, a weekly newsletter with practical insights on ecommerce retention, covering loyalty tactics, personalization, and lessons from real operators.

Beyond MobiLoud, I run MixBloom, which offers white-label content services for digital marketing agencies.

I live in Montréal with my wife and three kids. If you're building an ecommerce brand and thinking seriously about retention and mobile, follow me here.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABYSukBKu_gg-5vu1yaI45Awh0UAV1HpHc/
**Connexions partagées** : 134


---

# Pietro Saccomani

## Position actuelle

**Entreprise** : MobiLoud

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 1st


---

# Pietro Saccomani

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402697028012777474 | Text |  |  | Every time I post about mobile apps, I get the same comment:

“I never download apps”

If it’s not that, it’s some variation of “push notifications are annoying”.

These comments aren’t wrong. Many people legitimately feel this way. If they want to shop from a brand, they’ll go to their site.

They don't need the extra step of downloading an app.

But the thing is, apps aren’t for everyone.

You’re not launching a mobile app so you can shut down your site and migrate all your traffic to the app.

You’re not aiming for 80% of your customers to download the app.

An app is for your top customers. Those who love your brand, who WANT to be close to you, who WANT to hear from you whenever you have a new promo or product drop.

With all the privacy controls and filtering and algorithms today, it’s becoming increasingly harder to provide this close connection with just a website and legacy retention channels.

That means you end up losing touch with a lot of these customers that could have ended up being hyper-profitable, regular buyers.

The goal isn’t to reach your entire customer base.

It’s to make it easier for the top 20%, who contribute 80% of your profits.

It’s easier for them (one tap, they’re in — push notifications reach them instantly). And it’s easier for you, the brand, to connect with them, and retain their business.

All you really need is a ~10% revenue lift to justify the cost of launching (covering the cost, plus enough extra to make it worthwhile).

Anything above that is found money.

An app’s not for everyone.

It’s for the top 20%. Your VIPs.

You’re not inconveniencing them. You’re giving them what they WANT.

Check out MobiLoud to see how you can launch your own app now, for as little effort as possible. | 1 | 0 | 0 | 2d | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.255Z |  | 2025-12-05T13:15:06.938Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402474292506042368 | Text |  |  | Shopify brands drove $14.6 billion in sales over Black Friday & Cyber Monday.

A lot of these sales are new buyers. They're people who only just learned about your brand, or who had their eye on you for a while, and your 25% off was enough to convince them to give it a try.

While you probably just brought in a record number of new customers (Congrats, by the way), acquisition is only the beginning.

Your #1 priority now needs to be on nurturing these buyers towards their second purchase.

Get to this milestone, and it becomes a lot more likely you'll make it to the third, fifth, tenth purchases too.

If you want to turn those BFCM first-timers into regulars, here's what your game plan should look like:

1. Send a REAL welcome. No corporate "order confirmed" manifestos. Send a human note. 

Can be as simple as "Glad you're here".

2. Solve the "Onboarding" problem. Most retention problems are just because first-time buyers don't know how to get value from the product. 

Send tips, routines, and "how-to" videos.

If they win with the product, they come back.

3. Sow the seeds for Sale #2 (Softly). Don't pitch immediately. Just nudge. 

"Most people who liked X also really love Y."

4. Don't Ghost. Silence is the biggest retention killer. 

Stay consistent, stay helpful, and stay top of mind.

How are you following up with your new BFCM cohort?

Drop a comment below - and for a deeper dive into retaining your newly acquired customers (plus the latest data from BFCM), check out this week's Retention Edge newsletter: | 0 | 0 | 0 | 3d | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.255Z |  | 2025-12-04T22:30:02.655Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401934488836022273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHF6Pvi7Ehq0w/feedshare-shrink_800/B4EZreGIfbGYAk-/0/1764662741661?e=1766620800&v=beta&t=cnfhIvh4oxiUNfN41Ez-oJCItD3nAFFRIZnKvlHIHgg | We tested nearly 100 shopping apps over BFCM.

We wanted to see how brands were using their apps during the busiest time of the year; when low-cost, high-touch channels like apps matter most.

What shocked me:

Just ~28% of brands had abandoned cart notifications running.

That means only around a quarter of brands were taking advantage of one of the easiest ways to add net-new revenue... at the time of the year it has the biggest impact.

We consistently see huge results from brands using push notifications for abandoned carts at MobiLoud.

In the top examples, we had brands who recovered over $300K in just 30 days from abandoned cart notifications.

That’s revenue that would’ve otherwise disappeared. Walked out the (metaphorical) door and disappeared into the ether.

Even on the low end, brands pull in $10K+ every month from abandoned cart push.

That alone covers the cost of having an app.

Pound for pound, push is the strongest cart recovery channel there is.

It's direct, it's low-friction, and notifications are almost guaranteed to be seen.

Abandoned cart push notifications work -- one brand we work with gets 22% conversion rates on theirs.

And even better? You set up your abandoned cart flow in your app once, and forget about it.

it adds net-new revenue on autopilot. 

If you have an app, there's zero reason not to have abandoned cart notifications set up.

And tbh if you don't have an app, abandoned cart notifications may be enough of a reason, on their own to launch one.

Drop a comment below or connect and I'll show you how to go live with your own app in just 30 days. | 0 | 0 | 0 | 4d | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.256Z |  | 2025-12-03T10:45:03.431Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401579655889133568 | Text |  |  | This BFCM, I noticed one problem happening too often.

I go on a brand's website, and it shows all the excitement and hype of BFCM.

Full site takeover, the best deals highlighted on the homepage. the site gives you the feeling that you can’t afford to miss out on their deals.

But you open their mobile app… nothing. It looks exactly like any other day.

Zero indication BFCM is on at all.

I noticed this personally with multiple apps I use.

There are two realistic explanations for this.

#1: the brand actually doesn’t want their app users to take part in the deals.

They figure “these people are already loyal customers, they’ll buy at full price.”

Less common — but it happens.

And it’s a huge mistake. You should offer BETTER deals to your existing customers, not hide them.

Use BFCM as an opportunity to reward loyalty, not punish it.

#2: the app has just fallen behind the website; perhaps the brand decided it was too much work, and abandoned it.

This is super common with ecom brands.

That’s because with most mobile app solutions, the app exists separately from your website.

Pricing, coupons, product descriptions might be synced up.

But all the big flourishes you make for BFCM aren’t.

Site takeovers, banners, the hero showcase that changes every day.

You need to make these changes separately in your app. 

The result? Many brands forget — or decide it’s just not worth it.

And that creates a self-fulfilling prophecy.

- they ignore the app, leave it as is
- the app experience isn’t up to date with the website
- app users find it’s better to just shop on the site
- the app doesn’t do numbers; you see the decision to ignore the app as justified

This is, imo, the biggest problem we solve at MobiLoud.

Instead of launching an app that exists separately to your site and adds a ton of work for you - your app and site are automatically synced.

Your hero changes and banners and deal showcases carry over to the app with no extra work.

You can still do app-specific pages and deals if you need to. But it’s not double work by default.

It’s as close as you can get to a passively running mobile app.

A closer connection to your customers — zero-cost push notifications — a spot on your customer’s home screen.

Without the workload. | 1 | 0 | 0 | 5d | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.256Z |  | 2025-12-02T11:15:04.664Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400137646812909568 | Article |  |  | More hotels should have apps.

Every hotel says repeat guests are everything.

But the problem is, those same guests go back to Booking.com or Expedia to rebook; because the hotel has no real way to reach them directly.

So you end up paying commissions... to win back the people who already love you.

It’s wild.

Imagine if guests had your brand on their home screen.

- One tap → their past stays
- One tap → member rates
- One tap → rebook

And during the stay?
 
Mobile check-in.
Digital key.
Spa, dining, upgrades, late checkout.
 
All in the same place.

No hunting through emails. No calling the front desk. No kiosk queues.

The big players already know this.

Apps are now the majority of bookings for platforms like Booking, Airbnb, and Expedia. Guests want an app-first experience; because it’s easier, faster, and more personal.

Hotels should have the same advantage.

Not a “download our PDF of amenities” app.

A real app that handles booking, loyalty, check-in, offers, upgrades, and day-of-travel messaging.

A direct channel. A better guest experience. More repeat bookings. Lower service friction. Higher in-stay revenue.

It’s the rare win-win-win.

Most hotels don’t do it because they think an app is expensive, complex, and a whole new product to maintain.

Totally fair. Historically… it was.

But at MobiLoud we're making it easy.

We take your existing website + booking engine and turn it into a premium mobile app. No rebuild, no extra systems, and live in weeks.

As long as you can build this on the web, you can launch a native app for your hotel for zero effort and minimal cost.

Your CRS/PMS logic, rates, inventory, loyalty rules… all stay in sync because the app is powered by your site.

You get the direct channel guests prefer, without the cost or complexity hotels are scared of.

Get a demo and see some other examples of hospitality brands leaning into their own apps at mobiloud.com | 2 | 0 | 0 | 1w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.257Z |  | 2025-11-28T11:45:02.909Z | http://mobiloud.com/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7399488367031177217 | Text |  |  | BFCM doesn't start on Friday, or Thursday. It started last week.

I've spent the past few days in nearly 100 DTC brands' apps. The most immediate takeaway is that more than 75% were already in full BFCM mode at the start of this week.

Promos live, homepage takeovers, banners, "BFCM Sale" collections. Most brands don't wait for Thanksgiving anymore.

If you’re treating this like a 5-day sprint, you’re already behind.

A few other early signals stood out.

A surprising number of brands have their promos live, but hidden. No takeover. No clear announcement. No moment.

That’s a miss (imo) — you miss out on the emotional lift that BFCM naturally creates.

And I’m betting the same pattern will show up post-purchase. Many brands will mail in the experience, which leaves a huge advantage for the ones that think ahead.

Across everything I tracked, I had seven major takeaways. Patterns, early data points, positioning for brands with low repeat purchase potential, and some random thoughts I had regarding BFCM as a tentpole event.

Full breakdown in this week’s Retention Edge: | 2 | 0 | 0 | 1w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.258Z |  | 2025-11-26T16:45:02.546Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7399435515017449472 | Text |  |  | Most brands still underestimate how much revenue their own app can unlock.

We’re talking 10x more revenue per customer once they’re in the app.

The data keeps repeating itself across every brand we work with.

And it makes sense when you zoom out.

App customers behave differently.

Not a little bit. A lot.

Here’s what actually happens when someone moves from mobile web to your app:

1. They stick around longer. A lot longer.

Mobile web is a minefield of distractions.
A dedicated app isn’t.

Brands consistently see 3–7x longer sessions and 10–50% higher AOV from app users because they can finally browse without friction.

2. They buy more often.

A spot on the home screen is premium real estate.

When your brand is one tap away, you earn more repeat visits—3–5x more than mobile web.

This compounds. More sessions → more carts → more purchases.

3. You get a direct, free communication channel.

Push notifications are wildly underrated.

Zero cost. Instant delivery. Massive impact.

We’ve seen 6%+ conversion on regular campaigns and up to 22% on abandoned carts.

That’s revenue you’d lose forever without a way to reach people.

4. Apps create true loyalty.

If someone downloads your app, they’re raising their hand:

“I want a closer relationship with this brand.”

That becomes your VIP community; your highest LTV customers, your most frequent buyers, your repeat revenue engine.

And yet… most brands don’t have an app.

Not because they don’t want these results. But because app development has always sounded expensive, slow, and risky.

Totally reasonable.

The good news: that wall is gone.

This is exactly what MobiLoud solves.

We turn your existing website into a fully native mobile app - no rebuilding, no templates, no double work.

We build it, publish it, maintain it, and you get a high-performing revenue channel that starts paying for itself within weeks.

Want to see what it would look like? Get a free preview at app.mobiloud.com | 4 | 0 | 0 | 1w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:07.258Z |  | 2025-11-26T13:15:01.644Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7398695646452453376 | Text |  |  | For luxury and designer brands, the experience IS the product.

People don’t buy high-end pieces on impulse. They shop slowly. They compare. They want to feel something.

And every touchpoint either strengthens that feeling. Or breaks it.

That’s why a mobile app is such a power move for luxury brands.

An app is the closest you can get to your best customers digitally.

More repeat visits. Longer sessions. Higher purchase rates.

For high-ticket brands, that translates to serious revenue.

But it’s not just the numbers.

Being in the App Store signals status.

It tells customers: we’re established, we’re trusted, we’re worth your time.

We've seen these results with brands we work with at MobiLoud.

Luxury brands like John Varvatos and Tadashi Shoji have seen:

- 10x higher revenue per user
- 2–4x longer sessions
- 4x higher purchase rates

An app doesn’t just boost metrics.

It deepens loyalty. It creates a VIP lane.

It puts your brand one tap away from customers who spend big in each order.

Just one additional purchase from a customer moves the needle in a big way.

It's honestly such an easy win, I'm surprised more brands, especially high-end luxury & designer brands, don't have an app.

When you launch with MobiLoud, there's no risk. 

You're building off the experience that already works, that your customer already loves - and there's basically no extra work to maintain the app.

You get a VIP destination and a direct line for your best customers... without rebuilding or redesigning anything.

Go to app.mobiloud.com or drop a comment below to learn how you can go live with your own app in just a few weeks. | 3 | 0 | 0 | 1w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.358Z |  | 2025-11-24T12:15:03.232Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7397608520700829696 | Text |  |  | Here’s a strategic trap we see even the smartest DTC leaders fall into.

You want to launch an app. You know it’s the most powerful retention channel you can have, a direct line to your best customers.

But you never considered it because you’ve got the wrong picture of what it costs.

You think you need a fully custom app, designed from scratch. The traditional way of building an app.

You talk to an agency. They quote you $80K… $150K… sometimes more. 

And that’s just to get started. Then there’s the 15-25% annual maintenance fees, the server costs, the operational drag of managing a second platform.

And for what?

To rebuild everything your team has already built, tested, and perfected on your website.

^^ This is the fundamental misunderstanding of app development for ecommerce.

You don't realize that your mobile-optimized, conversion-tested website already does 95% of what your app needs to do. 

It is your brand. It works.

Why pay six figures to reinvent the wheel? Why create a second storefront to manage in perpetuity?

The most efficient brands understand that simplicity is a strategy. They don’t rebuild; they leverage what already works.

A different approach: instead of building from scratch, convert your existing, high-performing website into a native mobile app.

This simple shift in thinking saves over 99% of the cost and months of development time. 

It eliminates the operational drag of managing two separate platforms, because your website powers the app. There's no duplicate work. Ever.

This is the strategy we've built our entire service around at MobiLoud. We partner with brands to execute this playbook, handling the entire conversion process and ongoing maintenance so they can focus on their business.

The result is a powerful, retention-driving mobile app, with push notifications and a frictionless shopping experience, without the six-figure headache.

It’s leveraging what works and focusing on outcomes, not unnecessary overhead.

Want to see how? Get a preview of your app at app.mobiloud.com | 1 | 0 | 0 | 2w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.359Z |  | 2025-11-21T12:15:12.255Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7396898834150502400 | Text |  |  | A lot of brands assume, when they launch a mobile app, the app has to be some totally new, reinvented experience…

That it's got to be different from their website.

But that’s not the point.

Your app doesn’t need to be better than your website.

It just needs to be as good — because the real power of an app is two things:

1. the icon on the home screen - making it easier for regular customers to come back, making sure you're not forgotten
2. push notifications - a zero-cost, high-visibility channel to re-engage your shoppers

That’s the whole game.

Here's where launching an app can go wrong:

When you try to reinvent the wheel, create something "unique", because you think the app has to be a different experience from your site ...

… and you end up creating something worse.

See the thing is, your app doesn't need to be better than your site. But it CAN'T be worse.

If your website is better than your app, what's the reason for someone to download and use the app?

Yet brands do this all the time.

They change layouts that already convert, throw away their optimized PDPs, start from zero.

A lot of platforms force you into this; they have stock templates, pre-built UI, a limited number of integrations. And you can't replicate the same features, same design that your web shoppers love.

Sure, it's different. But different isn't always better.

That’s exactly why brands use MobiLoud.

We turn your existing site into the app, feature-for-feature, automatically synced with your site.

You keep everything that already converts, and add the basic features that make your app look, feel and function like a real native app.

It's not about taking a big swing and trying to create a whole new experience.

It's about building on what already works. And that makes your decision to launch an app risk-free.

If you want to see what your store could look like as an app, go to app.mobiloud.com, or drop a comment below if you have any questions. | 4 | 0 | 0 | 2w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.360Z |  | 2025-11-19T13:15:09.796Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7396532680110133249 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGp2KHDeUJhRQ/feedshare-shrink_800/B56ZpTPomBJ8Ag-/0/1762333199834?e=1766620800&v=beta&t=UA7brat9y6V9-Q_BapE2v9pCmqfDhczbC15pG_2ieoY | There are more no-code app builders on the market now than ever before.

It's a major leap for ecommerce brands to not have to spend six figures on a custom app anymore, unlocking the benefits of apps for ecom businesses that don't have VC money to burn.

But no-code doesn't mean no-work.

The thing you're not told about most no-code app builders is that you're creating a new platform to manage.

That means double the work for every promo, banner change, homepage update, etc.

Is it hundreds of hours per week? Is it a six-figure yearly cost, like if you had to maintain a custom native app? No.

But it's a sneaky big impact on your workflow. It drags you down, prevents you from moving fast, and dissuades you from iterating on your website, when you know you're creating more work for your app.

That's why we do what we do at MobiLoud. We let you launch an app that's fully synchronized with your website, in real time.

No double work - whenever you update your website, your app updates instantly.

It makes launching an app actually risk-free. Because there's no massive change to your day to day, no new platform to manage.

It takes away one of the biggest hidden costs of launching an app - the impact on you/your team's time.

It's the perfect way for a brand to test the waters and see the impact a mobile app can have. | 2 | 0 | 0 | 2w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.361Z |  | 2025-11-18T13:00:11.870Z | https://www.linkedin.com/feed/update/urn:li:activity:7392138681899421696/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396469036613521408 | Video (LinkedIn Source) | blob:https://www.linkedin.com/85b92679-84f8-472b-9a8b-b23cbcd6e339 | https://media.licdn.com/dms/image/v2/D4E05AQHE3U4jlrcscA/videocover-high/B4EZqWJY2HKgBU-/0/1763455636230?e=1765778400&v=beta&t=qV3IXq_5iIs-EjLiYzAenATo3dGFa1xyqv1mByr6HXw | The Google vs OpenAI wars are underway.

It's not that long since OpenAI announced ChatGPT Instant Checkout -- Shopify products directly integrated with ChatGPT, so users can search, ask questions, and buy, without leaving the platform.

Now Google is doing the same (right in time for peak season).

Whether it's AI mode or the Gemini app, Google has become your personal shopper.

Ask it what to buy, it serves up products instantly. You can ask follow up questions to refine the results and find exactly what you're looking for. You can even choose specific products from the list of results and have Google compare them for you.

The Gemini apps also features shoppable product listings, comparison tables, prices from across the web and places to buy.

But the biggest feature? Google's AI shopping agent lets shoppers track an item's price and get notified (or even buy it for you) when it drops below a specific price.

This could have major implications for how brands run discount campaigns.

We're seeing online shopping evolve before our eyes, in real time.

How we buy (and sell) online is going to look extremely different by this time next year. | 4 | 2 | 0 | 2w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.362Z |  | 2025-11-18T08:47:18.078Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7395101973726797824 | Text |  |  | Every brand wants recurring revenue. Few know how to actually build it.

"Subscribe & Save" sounds simple. Add a checkbox, offer 15% off, watch the money roll in.

Except it doesn't work that way.

Most subscription products don't take off. Because it's not easy to convince someone to keep paying you on a recurring basis.

Most brands fail because of the same things. Chasing the wrong metrics (like ROAS). Poorly structured offers. No onboarding.

Or they fear "reminding customers to cancel", so they go silent and lose the customer anyway.

And the #1 churn reason isn't what you think.

It's not product dissatisfaction. It's "too much product." 

Customers cancel because they're drowning in inventory. 

Getting the cadence right, offering flexible cycles, and making pauses frictionless preserves more subscriptions than any retention hack.

We just published a full breakdown on the Retention Edge, covering the 8 things you need to know about setting up a profitable subscription product, plus examples of brands running successful subscriptions in "non-subscription" categories (furniture rental, designer clothing, hockey equipment).

Check it out now: | 2 | 1 | 0 | 3w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.363Z |  | 2025-11-14T14:15:04.887Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7395027233406500865 | Text |  |  | Too often, launching an app is seen as a choice: 

"Is our mobile website good enough, or do we need an app?"

That's the wrong question.

Building an app isn't about replacing your website. It's about giving your customers another place to find you, another way to interact with your brand, on their own terms.

Let's be clear: a lot of your customers won't download your app. And that's perfectly fine. They'll continue to shop on your website, and you'll serve them well there.

But a significant group of your best customers will download it.

These are your loyalists, your VIPs, the ones who want a deeper connection with your brand. 

They're actively choosing to give you a permanent spot on their home screen, right next to their most-used apps.

Why would you say no to that?

By offering an app, you're not abandoning your website. You're catering to the customers who drive a disproportionate amount of your revenue. 

The data is clear on this: app users visit 2-5x more often, spend 10-50% more per order, and have a 3-7x higher revenue per user than mobile web visitors.

They're not just browsing; they're committed. An app is the best way to nurture that commitment.

It's about letting your customers choose their own adventure. Some prefer the open web. Some prefer the focused, convenient experience of an app. 

A smart brand meets them in both places.

You've already built a great mobile-optimized website. You've done the hard part. Now, it's time to leverage that investment and give your best customers the experience they're asking for.

MobiLoud turns your website into a mobile app, letting you say yes to web shoppers, and yes to those who want to shop on your app.

It's not about choosing one or the other. It's about choosing to grow.

Ready to see your site as an app? Go to app.mobiloud.com to get a free preview. | 7 | 1 | 0 | 3w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.364Z |  | 2025-11-14T09:18:05.406Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7394377189288202240 | Text |  |  | I love this advice. You don't need to have a stunningly unique product and create a new market to be successful.

It's often about finding a new way to get attention.

There are always going to be new places people go online, on their phones, the next TikTok Shop for example. 

These channels get commoditized eventually, but at the start, they present a major growth opportunity.

It's not about a differentiated product, it's about a new approach.

It aligns nicely with what we're doing at MobiLoud.

You're scaling ad spend, trying to crack the code of Meta ads, TikTok, Applovin, etc.

All while your retention system is the exact same as everyone else's.

A new approach? Launch a mobile app that lives on your best customers' phones, with push notifications that reach them instantly, and a much easier path to repeat purchases.

Relatively few brands are doing this. They're leaving money on the table from people who could be loyal, repeat buyers, but for the lack of this close connection.

Yet your existing customers are your most profitable, easiest to sell to, and present the biggest opportunity, for most brands, to drive higher revenue without scaling ad spend. | 2 | 0 | 0 | 3w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.365Z |  | 2025-11-12T14:15:02.811Z | https://www.linkedin.com/feed/update/urn:li:activity:7389002706193014784/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7393969499156291584 | Article |  |  | Every brand wants recurring revenue.

That's why subscription products get so much hype. It seems like a cheat code for winning at ecommerce. Customers sign up for a subscription, you automatically make sales every month. Game over. You won.

Of course, it's not quite that easy in real life.

There are products that don't make sense as subscriptions.
There's churn.
There's competition.

You end up launching a subscription with a great offer to get people in the door, but 80% cancel after a month and you lose money on it.

Like with anything, subscription products need good execution, and the right fit (square pegs round holes etc)

But they're a goldmine when done right, and free you from constant reliance on Meta, Google, and make or break first order profitability.

That's why we had 🇺🇦 Andriy Rudnyk from Good Subscription Agency on the Retention Edge podcast to share everything you need to know about doing a successful subscription product.

I love this one. And if you want to build an ecommerce brand that makes recurring revenue, you're gonna love it too.

Check it out now:
https://lnkd.in/e9dTNd9t | 8 | 1 | 0 | 3w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.366Z |  | 2025-11-11T11:15:01.909Z | https://youtu.be/TdAk2HCeK5Y?si=mvOw7koujuCmOvuO |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7393629796825726976 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE-lVBFa3Ftyw/feedshare-shrink_800/B56ZniSkdyJQAg-/0/1760438143802?e=1766620800&v=beta&t=1SnRi3tcTN6n9K43Xhdm1xFI_F8qtrY1OUGx48aUjOA | I'd say just about every brand in beauty & skincare should have a mobile app.

These brands live on regular purchases from loyal customers. Restocks & replenishments, new shades, new products for the customer to add to their routine.

A mobile app gives you a closer connection with these customers, and an easier way to drive repeat purchases and cross-sells.

But the thing that a lot of brands don't get is that your customers want an app too.

They want it to be easier to buy again. 

They want to be notified when they need to re-up, when new products drop, when you're running a promo.

It's not about launching a flashy asset. It's about giving your customers what they want.

We found that when we helped Kiokii launch. Nearly half of all their mobile revenue comes through their app, clearly validating their choice to launch.

With MobiLoud it's so easy as well - if your site is fast and looks and works great on mobile, 90% of the work is already done. So there's really no excuse for a beauty brand not to have an app anymore. | 3 | 0 | 0 | 3w | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.367Z |  | 2025-11-10T12:45:10.562Z | https://www.linkedin.com/feed/update/urn:li:activity:7383812763116224512/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7392569042818981888 | Text |  |  | BFCM is changing faster than most brands realize.

If you want to win, you need to stay on top of it.

Here's what's shifting:

- The holiday shopping window is stretching. Shoppers start researching in late October, and momentum continues through December.
- Pure discounting is out. Consumers want better value, not just bigger percentages. Margins are too thin to race to the bottom.
- Mobile now drives 70% of BFCM spending globally. Your entire funnel (ads, site, checkout) needs to be built mobile-first, not desktop-adapted.

This week's Retention Edge newsletter breaks down 6 major trends to follow this holiday season; including how AI is changing discovery and why December might outperform November.

Ecommerce moves fast.

Make sure you're up to date.

Check out the newsletter below: | 2 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.367Z |  | 2025-11-07T14:30:07.099Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7390013427982688256 | Text |  |  | Most brands think they "won" BFCM when the sales numbers come in.

Here's what actually happens:

You spend premium CPMs acquiring customers during the most competitive weekend of the year. You offer deep discounts to close them. Your Slack fills with champagne emojis.

Then December hits. You go quiet because nobody wants another promo right after stocking up.

By January, those customers have forgotten you exist.

Now you're paying to re-acquire the same people you just bought at peak prices.

The real BFCM winners aren't announced in December. They're revealed six months later when you see who actually kept their customers.

Unless you really nail profitability with high-value discounts, the biggest impact of BFCM should be turning momentum into a pipeline of customers who come back and buy again at real margins.

Most brands treat BFCM like a finish line. The best ones treat it like a starting gun.

The difference? A retention blueprint that starts the second someone hits "buy."

The latest Retention Edge newsletter features a full breakdown on exactly how to do this, including the post-purchase window strategy, the messaging framework for December, and how to build both mental and physical availability without burning out your list.

Check it out now: | 3 | 1 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.368Z |  | 2025-10-31T13:15:01.041Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7388926289849655296 | Text |  |  | You spent $150 getting that customer.

Don't lose them because you had no retention system.

Too many ecommerce brands optimize acquisition down to the penny, then wing it on keeping customers engaged.

No communication strategy. No channel mix. Just hope they come back.

You need a system to get them to come back.

Most brands have part of this in place; but they're missing a key channel.

You're sending emails. It's cheap, the foundation of your retention system. But 80% never see your emails.

Spam filters kill you. Promotions tabs bury you. It's necessary but not sufficient.

SMS converts, but it's expensive. $0.10 per message adds up fast.

Use it for high-intent moments, but the economics don't work as a daily driver.

Push notifications are the last piece of the puzzle.

Direct. Unfiltered. Underused. No cost per send. No carrier fees. No spam filters. No algorithm deciding if your customer sees your message.
It's perfect for consistent presence without bleeding your budget.

The limitation is that you're only reaching out to your app users. But that's one of the best parts, too.

It's a direct line to your best customers - those who actually want to see your messages, who are most likely to convert, those who will spend the most.

That's why push is such a key part of your system; it's designed for your most valuable customers, your VIPs.

You can't rely on one channel only. Not if you want to scale.

A retention system uses all three strategically.

Email for volume and nurture. SMS for conversion moments.

Push for staying top-of-mind without the per-message cost destroying your margin, and a reliable channel to reach out to your best customers.

If you want to unlock a new retention channel for your brand, go to mobiloud.com and see how we'll turn your website into a mobile app, with push built in and ready to go. | 16 | 4 | 1 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.369Z |  | 2025-10-28T13:15:07.112Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7387491835289653248 | Text |  |  | Most brands are about to make the same BFCM mistakes they made last year.

Not the obvious ones like site crashes or running out of stock.

I'm talking about the strategic mistakes that quietly leak profit and kill your momentum after the sale ends.

Here are 3 I see every year:

- Treating BFCM as a four-day window.

Your customers start shopping earlier every year. By the time Black Friday hits, their inboxes are already overflowing. If you only show up then, you're competing in the noisiest part of the season.

- Overly complex offers.

If customers have to think about how your discount works, it's too complicated. You have limited control over their attention at the best of times. Least of all during BFCM.

- Treating new customers better than your VIPs. 

It's easy to chase new buyers, but doing it at the expense of loyal ones is a big mistake. 

Your VIPs are the ones who buy regularly and talk about your brand. If they see better deals going to first-timers, it feels like a slap in the face.



These aren't the mistakes that get someone fired. They're the high-level ones that quietly cost you - and have you coming back from your holiday break wondering why things have plateaued.

I broke down 8 inevitable mistakes (and how to avoid them) in this week's Retention Edge newsletter. 

Check it out now: | 1 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.370Z |  | 2025-10-24T14:15:06.494Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7387465595572625408 | Text |  |  | The decision to build an app is often framed as app vs web.

Like by choosing to build an app, you're choosing to prioritize this channel over your website.

This is the wrong way of thinking about it.

Here's what most companies miss:

You're not choosing between channels. You're letting your customers choose.

Some people want apps. Some want browsers. Just like some prefer Instagram over TikTok. You can't force them to switch. They've already decided.

But here's where it gets interesting:

The customers who choose apps? They're not just different in preference. They're different in behavior.

- Higher conversion rates
- Higher average order value
- Shop more frequently

We find brands typically get 10-35% of their revenue through their apps.
This 10-35% comes from customers who self-sort into a VIP group.

They download your app because they love your brand, and they want it to be easier to shop and spend money with you.

By giving them the option, you're strengthening this bond, and giving them what they want.

Most businesses waste time and energy debating which channel to prioritize. Smart ones realize: customer preference IS the signal.

With MobiLoud, it's a small cost for a disproportionate return: stronger loyalty and higher engagement from your best customers.

Stop asking which channel is better. Start asking: can you afford to ignore your VIPs? | 5 | 3 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.371Z |  | 2025-10-24T12:30:50.458Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7386023393797623809 | Text |  |  | As an ecommerce brand, when you drop $50,000 to $150,000 upfront to build an app, you're taking a huge risk.

Will customers download it?
Will they actually use it?
What if it fails after six months?
Is the revenue we're getting through the app incremental?
Can we afford to find out?

These are a lot of questions to answer.

And when you add the recurring costs - likely 5 figures per month to keep it running - you're taking on a whole lot of risk.

It's a bet that can certainly pay off. We've seen numerous brands doing millions in revenue through their mobile apps.

But in today's climate, it's a tough call to make.

Here's the thing, though: that's not the only option anymore.

MobiLoud lets you launch for a fraction of the cost of traditional development.

Your app built in weeks, not months.

Powered by your site, low cost to launch, virtually no effort to maintain.

It completely flips the risk factor with apps. In fact, many customers we talk to use the term "no-brainer."

Because it really is.

Launching an app for around $1-2K upfront, with no rebuilding, no duplicate work to maintain it, removes all the risk.

All you need is a small, engaged group of customers buying in your app, and you'll pay it off in days.

Just the constant touchpoint of having an app that lives in your customer's pockets, with push notifications that can reach them for free, more than justifies doing it.

And the bottom line impact we've seen from our users is more than just a minor lift:

3.5-10x higher revenue per user
10-35% of total revenue through the app
Up to 22% conversion rates on push campaigns

It's a direct line to your best customers.

Who wouldn't want that?

Honestly, most brands today should have their own app.

Even if you don't think your brand is a natural fit for an app, the risk is so low, there's almost no argument against it.

You don't need a six-figure budget anymore.

Just a mobile-friendly site, a few hours of your time, and a small group of engaged customers, who'll be more likely to stick around if you give them an app.

It's one of the easiest value-adds for your business.

Go to app.mobiloud.com or drop a comment below to see what your site can look like as an app. | 27 | 4 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.373Z |  | 2025-10-20T13:00:02.760Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7384924913771372544 | Text |  |  | “Never discount.”

You hear this advice everywhere. Protect your margins, don’t cheapen your brand, stay “premium.”

There’s certainly some truth to that. But here’s the real truth:

Discounts don’t kill brands. Lazy discounting does.

If you’re running promos just to hit a number or because “it’s what everyone does,” you’ve already lost.

The problem isn’t the tactic. It’s the lack of intent.

Even Shein and Temu, with their wild, constant discounts, are doing it strategically.

This week’s Retention Edge breaks down why you shouldn’t avoid discounting, and how to use it to engineer real growth.

👉Read it here: | 1 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.373Z |  | 2025-10-17T12:15:04.713Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7384917362397044736 | Text |  |  | Adobe just dropped their holiday forecast, projecting $142.7B in mobile ecommerce sales. That's 56% of all spending.

8.5% increase YoY in mobile sales. 2.9% higher revenue share vs 2024.

If you're not mobile-first yet, you're leaving money on the table.

A mobile-native site is table stakes.

Not just responsive. Your site needs to feel like it was actually built for mobile -- not like a desktop site crammed onto a phone.

Fast load times. Frictionless checkout. Easy navigation. Spacing designed for mobile.

But even a mobile-optimized site isn't enough.

You should have an app too.

Not all your customers will use the app. The download barrier is too much for some.

But roughly one in five will prefer shopping on your app.

These shoppers want mobile-first convenience. They want one-tap access. No browser distractions. Push notifications when their favorite items go on sale.

If you don't have an app, you risk sending them to a competitor that does.

It's not about turning ever website visitor into an app user.

It's about giving your customers the option. Your best customers, no less. Those who want to engage with you the most.

You shouldn't turn these customers away, just because you think an app is a luxury.

With mobile taking more and more revenue share each year, apps are becoming a crucial revenue channel for ecommerce brands -- especially those built around retention & repeat purchases.

Visit MobiLoud to see how to launch your own app, risk-free (in time for Black Friday). | 3 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.374Z |  | 2025-10-17T11:45:04.325Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7384435347742543872 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEAK1uMZZeD0w/feedshare-shrink_800/B56ZnJ6nRMG4Ag-/0/1760029211425?e=1766620800&v=beta&t=y38mnyygUbQPuOU_89gGsqkBqpuBKWKEn2tym6otf6w | SMS is essentially email now.

It does work. It's a viable channel. It drives better, faster results than email (albeit at a higher price).

But it's become somewhat diluted as a channel from how many brands are showing up in your inbox, and the reputation it now has. It's not as personal and direct as it used to be.

(notable - these are going to start getting filtered into a secondary inbox now as well, with the new iOS update).

This is a major reason why push notifications stand out.

They're like SMS - direct, instant, appear on the lock screen - but without getting swallowed up in your inbox. (and without the per-send cost).

Instead of the silhouette avatars, push notifications come with your brand's logo attached.

They just look more trustworthy - you're not sending the customer a message from random 5-digit number.

The downside is reach - you don't have the same volume, because you can only send push notifications to people who have your app.

But the upside of that is each recipient is high-intent, and actually wants to get your messages.

This might sound anti-SMS, but it's not really. SMS still works, it's still worth it. Just like email, as much as it's declined in effectiveness, is still a key tool for any brand.

But brands who have an app, and can send push notifications to their top customers, their VIPs, their loyal repeat buyers, are at a major competitive advantage; especially once the holiday season hits and sending volume goes up.

Push cuts through the noise. | 2 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.375Z |  | 2025-10-16T03:49:43.076Z | https://www.linkedin.com/feed/update/urn:li:activity:7382101299720491008/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7384200122651287553 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-XCDn-genlg/feedshare-shrink_800/B4EZnh9n8nHcAg-/0/1760432652783?e=1766620800&v=beta&t=WtxjUkF8qe5jBhaMDvBE-uZNinf_uoX7ucwndRWB58c | Shopify just declared war on WooCommerce.

They released a plugin that lets you sell products on your WordPress site using Shopify’s commerce backend.

Here's how it works:

1. Set up your catalog in Shopify
2. Embed products in your WordPress pages
3. Customers checkout through Shopify (still on your site)
4. Manage everything from Shopify's dashboard

It's Shopify's checkout & backend, integrated with the platform that owns 60.7% of the CMS market share, and powers 43.3% of the internet.

Essentially, it's WooCommerce.

Shopify already controls over 26% of all ecommerce stores. And they’re about to add a ton of WooCommerce’s market share to that number.

This isn't just a product launch. It's a land grab. | 9 | 2 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.376Z |  | 2025-10-15T12:15:01.044Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7383509333256409088 | Text |  |  | Your customers vanish after adding to cart. Apps bring them back.

Customer acquisition costs have surged 60% while email open rates drop to 25%. You're paying more than ever to get someone to your store, then losing them before they finish their checkout.

Cart abandonment hits 70% on desktop, 86% on mobile. Not because your site is broken - because people forget. They get distracted, switch tabs, move on.

Your abandoned cart emails? 2-3% conversion rates if you're lucky.

Apps work differently.

Push notifications hit the lock screen instantly. No inbox competition. No delays. While interest is still warm.

The results: up to 22% conversion rates on abandoned cart push notifications. That's 10x better than email.

One brand we worked with recovered $360K in 30 days from cart abandonment push alone. 

Another company hit $31K in their first month.

This isn't just about cart recovery - app users convert 3-7x better overall and have 5x higher lifetime value than web-only customers.

The math: Even if only 10% of customers use your app, the combination of higher conversion rates and superior cart recovery often pays for the entire app from fixing the abandoned cart problem alone.

While competitors fight for expensive traffic, you're building direct access to customers who already trust you. | 0 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.377Z |  | 2025-10-13T14:30:04.018Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7382376876004089856 | Text |  |  | If there’s one theme running through ecommerce right now, it’s control.

Apple’s latest iOS update takes more of it from advertisers.
ChatGPT’s shopping push takes it from brands.
Tariffs are eating into margins and limiting where you can sell.

If you run a brand, your next moves should be about getting control back.

- Build audiences through channels you own
- Prioritize first-party data
- Expand into new channels and markets, so you decide where your growth comes from

I unpacked these trends (plus a slept-on channel that might be making a comeback) in this week’s Retention Edge newsletter.

It’s a quick breakdown of the 5 shifts shaping ecommerce right now (and how to stay ahead of them).

Read it here 👉 | 1 | 2 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.378Z |  | 2025-10-10T11:30:05.169Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7382078658284376065 | Text |  |  | The BFCM CPM spike is a yearly reminder of whether you're renting or owning your audience.

You might have seen it happening already. Mid-October, CPMs start rising.

The cost to advertise on Meta & Google reaches a peak for basically all of Q4.

Most brands scramble to pay these platforms for attention, because that's all they have.

Meanwhile, businesses who own their audience can just hit send.

Email & SMS pull some weight. But they're also bogged down with every brand sending their holiday sales.

The real difference comes when you have a mobile app.

It's the ultimate "owned" channel.

A touchpoint that lives on your customer's phone.

A direct, instant, and zero-cost line to your customers via push notifications.

All completely in your control, with no algorithm, no CPMs, no promotional inboxes.

And Q4 is when having this app, nurturing it, getting your best customers to shop in the app, pays off in a massive way.

Brands we work with at MobiLoud typically get anywhere from 10-35% of their revenue through their app.

That's revenue that's insulated from Q4 CAC spikes, from iOS updates that break attribution, from Google sending all your emails to die in the promotional tab.

-

Right now, it's running close to BFCM.

There's still time to launch, and to make the app a part of your BFCM strategy.

But the real value will be a year from now, when you've got a powerful, reliable channel that lets you opt out of the Meta/Google/Gmail attention war. | 4 | 0 | 0 | 1mo | Post | Pietro Saccomani | https://www.linkedin.com/in/pietrosaccomani | https://linkedin.com/in/pietrosaccomani | 2025-12-08T05:06:11.379Z |  | 2025-10-09T15:45:04.524Z |  |  | 

---



---

# Pietro Saccomani
*MobiLoud*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 22 |

---

## 📚 Articles & Blog Posts

### [Pietro Saccomani - Founder and CEO | MobiLoud](https://mobiloud.com/author/pietro-saccomani)
*2025-07-02*
- Category: article

### [11 High-Impact Newsletters for DTC Ecommerce Leaders](https://www.mobiloud.com/blog/ecommerce-newsletters)
*2025-07-03*
- Category: blog

### [LBM Audible #17: Building a Mobile App for your Blog with Pietro ...](https://londonbloggers.net/2338/lbm-audible-17-building-a-mobile-app-for-your-blog-with-pietro-saccomani/)
- Category: blog

### [Building Mobile Apps for WP with Pietro Saccomani of Mobiloud](https://wpcast.fm/mobiloud)
*2015-04-01*
- Category: article

### [A five-step process to fix retention](https://ca.linkedin.com/in/pietrosaccomani)
*2025-05-08*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 17,241 words total*

### Pietro Saccomani - Founder and CEO | MobiLoud
*1,023 words* | Source: **EXA** | [Link](https://mobiloud.com/author/pietro-saccomani)

Pietro Saccomani - Founder and CEO | MobiLoud

===============

[![Image 6](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/67879fc60fb80cabe1f65a3a_logomark-2025.svg)](https://mobiloud.com/?r=0)

![Image 7](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/6448bf820b476d63868c5886_close.svg)

[Case Studies ![Image 8: Expand button.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/63b7c1782e792605fdc451b9_expand.svg)](https://mobiloud.com/author/pietro-saccomani#)

[Case Studies We've worked with 2,000+ companies since 2013, from young startups to Fortune 500s.](https://mobiloud.com/case-studies)[Reviews Read what 100+ customers have to say about our fast and easy-to-use development solution.](https://mobiloud.com/reviews)[App Examples Browse and test real apps built by MobiLoud customers.](https://mobiloud.com/examples)[Ecom Mobile App Report Real data and insights from ecommerce brands on mobile app growth, engagement, and ROI.](https://mobiloud.com/reports/ecommerce-benchmark-report)

[Solutions ![Image 9: Expand button.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/63b7c1782e792605fdc451b9_expand.svg)](https://mobiloud.com/author/pietro-saccomani#)

By Industry

[eCommerce](https://mobiloud.com/ecommerce-mobile-app)[Marketplaces](https://mobiloud.com/marketplaces)[Fashion &Apparel](https://mobiloud.com/industry/fashion-apparel)[Beauty & Cosmetics](https://mobiloud.com/industry/beauty-cosmetics)[Health & Wellness](https://mobiloud.com/industry/health-wellness)[Grocery](https://mobiloud.com/industry/grocery)[Pharmacy](https://mobiloud.com/industry/pharmacy)[Publishing](https://mobiloud.com/news-magazine-mobile-apps)[SaaS](https://mobiloud.com/saas)[Custom Web Apps](https://mobiloud.com/convert-website-to-app)[B2B](https://mobiloud.com/industry/b2b)[View all](https://mobiloud.com/industries)

By CMS

[![Image 10: Shopify icon.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65c6cff6fad0c4b1f7a38703_Shopify%20app%20icon%20(1).avif) Shopify](https://mobiloud.com/cms/shopify-mobile-app-builder)[![Image 11: BigCommerce icon.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65c6d22989cca18d7179f78f_BigCommerce%20app.webp) BigCommerce](https://mobiloud.com/cms/bigcommerce-mobile-app-builder)[![Image 12: Adobe Commerce icon](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65c6d2a22946316fcd225f91_Adobe%20Commerce%20App%20Icon.avif) Adobe Commerce](https://mobiloud.com/cms/adobe-commerce-mobile-app-builder)[![Image 13: Wordpress icon](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65c9126eb02e7eb54f969fa6_WordPress%20blue%20logo.avif) WordPress](https://mobiloud.com/wordpress-mobile-app)[![Image 14: WooCommerce icon.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65d4c5b6d125c1b0a5e730b1_WooCommerce%20logo.svg.avif) WooCommerce](https://mobiloud.com/cms/woocommerce-mobile-app-builder)[![Image 15: Salesforce Commerce Cloud icon.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/65c6d22489cca18d7179f638_Salesforce%20Commerce%20Cloud%20Icon.avif) Salesforce Commerce Cloud](https://mobiloud.com/cms/salesforce-commerce-cloud-mobile-app-builder)[![Image 16](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/68b84dff3552bfbfca8d86de_prestashop_logo.png) PrestaShop](https://mobiloud.com/cms/prestashop-mobile-app-builder)

By Feature

[Push Notifications](https://mobiloud.com/features/push-notifications)[Retain Website Features](https://mobiloud.com/features/retain-website-features)[Manage Single Codebase](https://mobiloud.com/features/management)[Improved Mobile UX](https://mobiloud.com/features/mobile-ux)[Custom Branding & UI](https://mobiloud.com/features/custom-branding-ui)[In-App Exclusive Products & Content](https://mobiloud.com/features/in-app-exclusive-products-content)[App Promotion](https://mobiloud.com/features/promotion)[Analytics &CRO](https://mobiloud.com/features/analytics-cro)[Multi-Language & Multi-Currency Support](https://mobiloud.com/features/multi-language-multi-currency-support)[All Features](https://mobiloud.com/features)

[Resources ![Image 17: Expand button.](https://cdn.prod.website-files.com/63894f0e251e5628a4443bcd/63b7c1782e792605fdc451b9_expand.svg)](https://mobiloud.com/author/pietro-saccomani#)

[Blog Our blog covers useful advice, tools and strategy for digital businesses, publishers, startups and site owners.](https://mobiloud.com/blog)[Features Discover how we accelerate mobile app development, platform approval, monetization and user engagement.](https://mobiloud.com/features)[About Us We've been making mobile app development fast and inexpensive since 2013. Learn more about who we are.](https://mobiloud.com/about)[Help Center Read our frequently asked questions organized by topic, or our documentation for more in-depth guides on onboarding and setup.](https://mobiloud.com/faqs)[Documentation Everything you need to know about building, customizing and publi

*[... truncated, 18,524 more characters]*

---

### 11 High-Impact Newsletters for DTC Ecommerce Leaders
*1,713 words* | Source: **EXA** | [Link](https://www.mobiloud.com/blog/ecommerce-newsletters)

Winning in DTC isn’t just about great products. It’s about staying ahead of the curve.

The best operators know that insights, trends, and executional tactics make or break a brand. But let’s be real: not all newsletters are worth your time, attention, or inbox real estate.

We’ve curated the **top 11 newsletters** that actually deliver value... whether it’s actionable growth strategies, deep dives on emerging trends, or insider playbooks from the best in the game.

If you’re running a DTC brand, scaling an ecom business, or just obsessed with the space, these are the emails you’ll actually look forward to opening.

The Best Ecommerce Newsletters
------------------------------

### Operators Newsletter

![Image 1: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349d5_20250702T0923-76d5c034-3d0e-4b2c-bd97-7aae65df7769.webp)

The [Operators Newsletter](https://operatorscontent.com/) is an amazing intelligence hub for direct-to-consumer (DTC) brands navigating the complexities of scaling to nine-figure revenues.

Curated by Aaron Orendorff, and featuring content from the likes of Sean Frank (Ridge), Matt Bertulli (Lomi & Pela Case), Mike Beckham (Simple Modern), Cody Plofker (Jones Road Beauty) and Jason Panzer (HexClad), this publication distills hard-won insights from executives behind industry titans into actionable frameworks.**‍**

*   ‍**Content Focus**: Hard-won lessons from scaling nine-figure DTC brands, tactical playbooks (e.g., checkout optimization), and breaking consumer news.**‍**
*   **Frequency**: Weekly.**‍**
*   **Target Audience**: DTC founders, C-suite executives, and operators managing high-growth brands.**‍**
*   **Unique Selling Proposition**: Leaked strategies and unfiltered case studies from celebrity-backed brands, offering a rare look at overcoming operational bottlenecks.**‍**
*   **Subscription**: Free signup via [operatorscontent.com](https://operatorscontent.com/).

### The Retention Edge by MobiLoud

![Image 2: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349c4_20250702T0923-180e6aff-7863-4339-b14e-b4a29ef79401.webp)

From[MobiLoud](https://www.mobiloud.com/) founder Pietro Saccomani, [The Retention Edge](https://retentionedge.co/) puts the focus on sustainable growth strategies, interviewing and curating retention and LTV tactics from the world’s top DTC brands.

The Retention Edge Features a free weekly newsletter and podcast, where the team interviews top thought leaders in retention marketing, all with the goal of helping brands drive long-term growth and profitability.

*   ‍**Content Focus**: Retention marketing tactics driven by real examples of what’s really working for successful DTC brands.**‍**
*   **Frequency**: Weekly.**‍**
*   **Target Audience**: DTC founders and leaders at 7 figure+ brands.**‍**
*   **Unique Selling Proposition**: Easily digestible, actionable insights, driven from interviews with DTC, ecommerce and retail leaders.**‍**
*   **Subscription**: Free at [retentionedge.co](https://retentionedge.co/)

### Chew On This

![Image 3: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349e6_20250702T0923-42548626-ceb0-4342-a502-8336f74d5cab.webp)

Founded by Ron Shah and Ankit Patel, whose Obvi brand scaled to $90M in five years, [Chew On This](https://www.subscribe.chewonthis.io/) synthesizes battlefield-tested strategies with forward-looking industry analysis.

Chew On This redefines DTC thought leadership by merging street-level execution insights with boardroom-caliber strategy. For founders committed to profitable scaling in an era of platform uncertainty, its combination of transparency, tactical specificity, and future-proof frameworks makes it indispensable.

*   ‍**Content Focus**: Profitability tactics for scaling DTC brands, including Meta ad structures, influencer programs, and landing page optimization.**‍**
*   **Frequency**: Twice weekly.**‍**
*   **Target Audience**: Founders aiming to scale beyond $10M–$100M revenue.**‍**
*   **Unique Selling Proposition**: Battle-tested frameworks from growing Obvi to $90M in five years, emphasizing capital efficiency and retention.**‍**
*   **Subscription**: Free at [subscribe.chewonthis.io](https://www.subscribe.chewonthis.io/).

### Nik Sharma Newsletter

![Image 4: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349d8_20250702T0923-0c665bb7-1aaa-4e51-a48f-5b1ec26a066f.webp)

The [Nik Sharma Newsletter](https://workweek.com/discover-newsletters/sharma/) is perfect for DTC operators seeking actionable growth strategies. With 100,000+ weekly readers across 45 countries, this publication distills Sharma's decade of experience scaling brands like Hint and Chamberlain Coffee into five-minute tactical briefs.

Nik Sharma’s newsletter cuts through theory with tactical advice, whether it's optimizin

*[... truncated, 10,838 more characters]*

---

### LBM Audible #17: Building a Mobile App for your Blog with Pietro Saccomani
*569 words* | Source: **EXA** | [Link](https://londonbloggers.net/2338/lbm-audible-17-building-a-mobile-app-for-your-blog-with-pietro-saccomani/)

LBM Audible #17: Building a Mobile App for your Blog with Pietro Saccomani | LondonBloggers.net

===============

[](https://londonbloggers.net/2338/lbm-audible-17-building-a-mobile-app-for-your-blog-with-pietro-saccomani/#)

*   [About](https://londonbloggers.net/about/)
*   [Sponsor](https://londonbloggers.net/support/)
*   [Archives](https://londonbloggers.net/archives/)
*   [Write a Guest Post](https://londonbloggers.net/write-a-guest-post/)
*   [Contact](https://londonbloggers.net/contact/)

 Thursday, June 18, 2015 

*   [About](https://londonbloggers.net/about/)
*   [Sponsor](https://londonbloggers.net/support/)
*   [Archives](https://londonbloggers.net/archives/)
*   [Write a Guest Post](https://londonbloggers.net/write-a-guest-post/)
*   [Contact](https://londonbloggers.net/contact/)

[![Image 3](https://londonbloggers.net/wp-content/uploads/2013/11/lbm-net-logo.png)](https://londonbloggers.net/)

[Select a page](https://londonbloggers.net/2338/lbm-audible-17-building-a-mobile-app-for-your-blog-with-pietro-saccomani/#)

*   [Home](https://londonbloggers.net/category/all/)
*   [Blogging Community](https://londonbloggers.net/category/blog-community/)
    *   [Blogging Tips](https://londonbloggers.net/category/blogging-tips/)
    *   [Blogger Interviews](https://londonbloggers.net/category/blogger-interviews/)
    *   [Competitions](https://londonbloggers.net/category/competitions/)

*   [Meetups](https://londonbloggers.net/category/meetup/)
*   [Workshop](https://londonbloggers.net/workshop/)
*   [Archives](https://londonbloggers.net/archives/)

*   [Home](https://londonbloggers.net/category/all/)
*   [Blogging Community](https://londonbloggers.net/category/blog-community/)
    *   [Blogging Tips](https://londonbloggers.net/category/blogging-tips/)
    *   [Blogger Interviews](https://londonbloggers.net/category/blogger-interviews/)
    *   [Competitions](https://londonbloggers.net/category/competitions/)

*   [Meetups](https://londonbloggers.net/category/meetup/)
*   [Workshop](https://londonbloggers.net/workshop/)
*   [Archives](https://londonbloggers.net/archives/)

[All posts](https://londonbloggers.net/category/all/)[LBM Audible](https://londonbloggers.net/category/lbm-audible/)[London](https://londonbloggers.net/category/london/)

![Image 4: Pietro Saccomani](https://londonbloggers.net/wp-content/uploads/2013/12/MG_9912.jpg)

LBM Audible #17: Building a Mobile App for your Blog with Pietro Saccomani
==========================================================================

January 22, 2014 / by [Bernie J Mitchell](https://londonbloggers.net/author/berniejmitchell/ "Posts by Bernie J Mitchell") / 0 Comment

REVIEW OVERVIEW

* * *

0

0

![Image 5: Pietro Saccomani](https://londonbloggers.net/wp-content/uploads/2013/12/MG_9912-300x300.jpg)**This episode was recorded after the Mobiloud crew presented at the London Bloggers Meetup last year – you can see a report of that meet up and slides on this[post here](https://londonbloggers.net/2320/building-a-mobile-app-for-your-blog/). It was also recorded before the Christmas holiday so please excuse the festive singing.**

We were left feeling incredibly well informed after just a few minutes with Pietro from [Mobiloud](http://www.mobiloud.com/)on our podcast.

**He talked to us about…**

> Why both a responsive AND a mobile app are worth having for your site.

> Is RSS dead? What was RSS started for?

> What platform is best? iOS,Android, Windows, Blackberry

> What is the best place to start for a blogging app for your blog

> How do you make money out an app?

**You can listen to the podcast here:**

[Subscribe to the show in iTunes](https://itunes.apple.com/gb/podcast/lbm-audible/id590143377?mt=2&ign-mpt=uo%3D4)

**We mention these people and companies in the show…**

[Avinash Kaushik](http://www.kaushik.net/avinash/)

[Blog Tyrant](https://londonbloggers.net/2271/lbm-audible-15-how-to-blog-like-a-tyrant/)

[Trello](http://buff.ly/1hLaf3i)

[Nimble](https://www.nimble.com/register/business_trial/?type=business_trial&lead_source=partner&lead_source_id=yourpartnerid)

Scriggler

**You can find Pietro online here:**

For the Mobiloud website [click here](http://www.mobiloud.com/).

_On twitter:_

**For more information on the London Bloggers Meetup and to register for forthcoming events visit:**

[http://www.meetup.com/londonbloggersmeetup](http://www.meetup.com/londonbloggersmeetup)

**You can connect with Andy here:**

On

 His b2b marketing blog

**And you can connect with Bernie here:**

On

 His Sharing Economy Podcast

 SHARE 

 TAGS 

[london bloggers meetup podcast](https://londonbloggers.net/tag/london-bloggers-meetup-podcast/)[wordpress mobile app](https://londonbloggers.net/tag/wordpress-mobile-app/)

ABOUT THE AUTHOR

![Image 6](http://1.gravatar.com/avatar/b3bc0cd7a72b25143f93f8c8afdc485e?s=60&d=http%3A%2F%2F1.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D60&r=G)

Bernie J Mitchell
Blogger, New Dorker, Purveyor of Tribes, 

*[... truncated, 3,588 more characters]*

---

### Building Mobile Apps for WP with Pietro Saccomani of Mobiloud
*360 words* | Source: **EXA** | [Link](https://wpcast.fm/mobiloud)

Building Mobile Apps for WP with Pietro Saccomani of Mobiloud

===============

[WPcast.fm](https://wpcast.fm/)

The Professional WordPress Podcast

*   [Episodes](https://wpcast.fm/episodes)
*   [Reviews](https://wpcast.fm/reviews)
*   [About](https://wpcast.fm/about)
*   [Subscribe](https://wpcast.fm/subscribe)
*   [Contact](https://wpcast.fm/contact)

Building Mobile Apps for WordPress with Pietro Saccomani of Mobiloud – WPCAST039
================================================================================

April 1, 2015

In this episode, our guest Pietro Saccomani discusses how his business, [Mobiloud](http://www.mobiloud.com/), builds mobile apps for WordPress sites.

Audio Player

[http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3)

00:00

00:00

00:00

[Use Up/Down Arrow keys to increase or decrease volume.](javascript:void(0);)

Podcast: [Play in new window](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3 "Play in new window") | [Download](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3 "Download") (Duration: 23:11 — 21.3MB)

The Core
--------

### What Is Mobiloud?

*   [Mobiloud](http://www.mobiloud.com/) builds great looking, native mobile apps for your WordPress site.
*   Full service solution (iOS and Android developer licenses taken care of).
*   Most used as a retention tool for publishers with existing audiences.
*   Push notifications for content, including categories and custom post types.
*   The free WordPress plugin allows you to design, configure, preview, and test it.
*   Pricing: subscriptions from $69-199/month, or lifetime licenses.

### About the Business

*   Started out as a consultancy, and this service evolved from a client’s project.
*   Over 2 million downloads across all customer apps.
*   Marketing channels: content marketing, email course, SEO, WP plugin directory.
*   Future plans: expand to platforms outside of WordPress.

### Connect with Mobiloud

*   [Mobiloud.com](http://www.mobiloud.com/)
*   [Blog](http://www.mobiloud.com/blog/)
*   [Twitter](http://www.twitter.com/mobiloudapp)
*   [Facebook](http://www.facebook.com/mobiloudapp)

Audio Player

[http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3)

00:00

00:00

00:00

[Use Up/Down Arrow keys to increase or decrease volume.](javascript:void(0);)

Podcast: [Play in new window](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3 "Play in new window") | [Download](http://media.blubrry.com/wpcast/wpcast.fm/wp-content/blogs.dir/483/files/episodes/WPCAST039.mp3 "Download") (Duration: 23:11 — 21.3MB)

Thanks for listening! If you liked this episode, please[leave us a review in iTunes](https://itunes.apple.com/us/podcast/professional-wordpress-podcast/id885696994).

We’d love for you to comment below, or leave us a [voicemail](https://www.speakpipe.com/WPcastfm) or [message](http://wpcast.fm/contact) with your feedback.

Filed Under: [Podcast](https://wpcast.fm/category/podcast) • Tagged With: [android](https://wpcast.fm/tag/android), [apps](https://wpcast.fm/tag/apps), [ios](https://wpcast.fm/tag/ios), [mobiloud](https://wpcast.fm/tag/mobiloud), [pietro saccomani](https://wpcast.fm/tag/pietro-saccomani), [saas](https://wpcast.fm/tag/saas), [software as a service](https://wpcast.fm/tag/software-as-a-service)

![Image 1](https://wpcast.fm/wp-content/themes/dynamik-gen/images/content-filler.png)

#### Recommendations

_Disclosure: Some of the links mentioned throughout the site are affiliate links, meaning we may receive commissions for purchases made through them. We only recommend products and services that we’ve used ourselves._

[![Image 2](http://wpcast.fm/wp-content/blogs.dir/483/files/2022/12/kinsta-affiliate-240x240-v1.png)](https://kinsta.com/?kaid=ESZBOKRCSNDU)

[![Image 3](http://wpcast.fm/wp-content/blogs.dir/483/files/2018/01/gravity-forms-250x250.png)](https://www.e-junkie.com/ecom/gb.php?cl=54585&c=ib&aff=156014)

Copyright ©2025 WPcast.fm. All rights reserved. Brought to you by [![Image 4](http://wpcast.fm/wp-content/blogs.dir/483/files/2015/02/efficientwp-white-bg-120x20.png)](https://efficientwp.com/) and [![Image 5](http://wpcast.fm/wp-content/blogs.dir/483/files/2014/08/fatcat-apps-logo-113x20.png)](http://fatcatapps.com/?utm_campaign=wpcast-byline&utm_source=http%3A%2F%2Fwpcast.fm%2F&utm_medium=referral).

---

### Pietro Saccomani - MobiLoud | LinkedIn
*8,531 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/pietrosaccomani)

Pietro Saccomani - MobiLoud | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/pietrosaccomani#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-cocoa-beach-fl?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fpietrosaccomani&fromSignIn=true&trk=public_profile_nav-header-signin)[Create an account](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=pietrosaccomani&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fpietrosaccomani&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fpietrosaccomani&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/D4E16AQEe6tkJPLO0LQ/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1727803505384?e=2147483647&v=beta&t=dCiHWSK7n65A2kv3QubEjf-6rmaWkwOyUerqnv-G-14)

![Image 3: Pietro Saccomani](https://media.licdn.com/dms/image/v2/D4E03AQG3adjQIN7mbw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1730565620506?e=2147483647&v=beta&t=-NfKnSGN2DDbC3uEEuaxDRwAXHaWIxElCuR_GBu7G5s)

![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQG3adjQIN7mbw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1730565620506?e=2147483647&v=beta&t=-NfKnSGN2DDbC3uEEuaxDRwAXHaWIxElCuR_GBu7G5s)
Sign in to view Pietro’s full profile
-------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=pietrosaccomani&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=pietrosaccomani&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Pietro Saccomani
================

![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQG3adjQIN7mbw/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1730565620506?e=2147483647&v=beta&t=-NfKnSGN2DDbC3uEEuaxDRwAXHaWIxElCuR_GBu7G5s)
Sign in to view Pietro’s full profile
-------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=pietrosaccomani&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_jo

*[... truncated, 82,880 more characters]*

---

### The Retention Edge by MobiLoud
*539 words* | Source: **GOOGLE** | [Link](https://retentionedge.co/t/Podcast)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 1: Retention Edge E19: The Truth About Agencies, YouTube Ads, and AI Creative](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/007f2089-e82c-4f1d-ae6d-cb7d91b1ea83/graph_image.png)](https://retentionedge.co/p/retention-edge-e19-the-truth-about-agencies-youtube-ads-and-ai-creative)

[Dec 01, 2025 Retention Edge E19: The Truth About Agencies, YouTube Ads, and AI Creative -------------------------------------------------------------------------- Insights from 15+ years scaling 8 & 9-figure brands.](https://retentionedge.co/p/retention-edge-e19-the-truth-about-agencies-youtube-ads-and-ai-creative)[![Image 2: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 3: Retention Edge E18: $29M Shopify Email Marketing Secrets](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/9b5f843e-f305-4ed4-8d03-68f6a1226422/graph_image__2_.png)](https://retentionedge.co/p/retention-edge-e18-29m-shopify-email-marketing-secrets)

[Nov 17, 2025 Retention Edge E18: $29M Shopify Email Marketing Secrets -------------------------------------------------------- How to get more out of your highest-volume retention channel.](https://retentionedge.co/p/retention-edge-e18-29m-shopify-email-marketing-secrets)[![Image 4: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 5: Retention Edge E17: The Subscription Playbook for 2.5-3x Higher LTV](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/dab9fa7e-7456-46df-ae75-555a68aa92f6/graph_image__1_.png)](https://retentionedge.co/p/retention-edge-e17-the-subscription-playbook-for-2-5-3x-higher-ltv)

[Nov 10, 2025 Retention Edge E17: The Subscription Playbook for 2.5-3x Higher LTV ------------------------------------------------------------------- How to craft a winning offer for recurring subscription products.](https://retentionedge.co/p/retention-edge-e17-the-subscription-playbook-for-2-5-3x-higher-ltv)[![Image 6: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 7: Retention Edge E16: GA4, GEO & the "Golden Era" of Google Ads](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/4f4c2ebc-d42a-4a97-b67b-c4a3721326f7/graph_image.png)](https://retentionedge.co/p/retention-edge-e16-ga4-geo-the-golden-era-of-google-ads)

[Nov 04, 2025 Retention Edge E16: GA4, GEO & the "Golden Era" of Google Ads ------------------------------------------------------------- Why most ecommerce brands are using their data wrong, plus what AI means for your brand.](https://retentionedge.co/p/retention-edge-e16-ga4-geo-the-golden-era-of-google-ads)[![Image 8: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 9: Retention Edge E15: Max Your Exit](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/059e3b8e-497e-43c0-a790-f4b961415bef/Emmett_Kilduff.png)](https://retentionedge.co/p/retention-edge-e15-max-your-exit)

[Oct 27, 2025 Retention Edge E15: Max Your Exit --------------------------------- All you ever needed to know about building a higher price tag for your brand.](https://retentionedge.co/p/retention-edge-e15-max-your-exit)[![Image 10: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 11: Retention Edge E14: Planning to Win BFCM](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/eaed2fc5-ee22-4067-8e46-721509f8391b/ben_zettler.png)](https://retentionedge.co/p/retention-edge-e14-planning-to-win-bfcm)

[Oct 20, 2025 Retention Edge E14: Planning to Win BFCM ---------------------------------------- Your BFCM planning schedule, avoiding the most c

*[... truncated, 6,160 more characters]*

---

### The Retention Edge by MobiLoud
*837 words* | Source: **GOOGLE** | [Link](https://retentionedge.co/)

The Retention Edge by MobiLoud

===============

[![Image 13: The essential weekly digest helping ecommerce brands build sustainable growth through better customer retention.](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/publication/logo/4ecacad2-e69c-4045-9644-ea0ed8128cac/thumb_Group_2.png) The Retention Edge by MobiLoud](https://retentionedge.co/)

Login[Subscribe](https://retentionedge.co/subscribe)

![Image 14: The Retention Edge by MobiLoud](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/publication/logo/4ecacad2-e69c-4045-9644-ea0ed8128cac/Group_2.png)

The Retention Edge by MobiLoud
==============================

The essential weekly digest helping ecommerce brands build sustainable growth through better customer retention.

Written by[Pietro Saccomani](https://retentionedge.co/authors)

Connect

[](https://twitter.com/mobiloud)[](https://www.linkedin.com/company/mobiloud/)[](https://www.youtube.com/@Mobiloud)[](https://www.facebook.com/mobiloudapp)[](https://rss.beehiiv.com/feeds/GCPaa0D1wI.xml)

#### Featured Posts

[![Image 15: How to Build Recurring Revenue That Sticks](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/15802316-8fad-4279-a243-08ea80b85ead/Linkedin_Newsletter_Banner_27_.png)](https://retentionedge.co/p/the-data-behind-ecom-s-most-overlooked-retention-channel)

[Jun 05, 2025 The data behind ecom’s most overlooked retention channel -------------------------------------------------------- The retention engine that converts higher, retains high-value customers, and delivers dependable ROI.](https://retentionedge.co/p/the-data-behind-ecom-s-most-overlooked-retention-channel)[![Image 16: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 17: Retention Edge E11: Unlocking Growth with Country Life Natural Foods](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/2e51cc67-042c-4e74-933f-f4339f9bc8df/youtube_thumbnail__1_.png)](https://retentionedge.co/p/retention-edge-e11-unlocking-growth-with-country-life-natural-foods)

[Oct 01, 2025 Retention Edge E11: Unlocking Growth with Country Life Natural Foods -------------------------------------------------------------------- How this independent organic food brand is scaling profitably with innovative acquisition strategies, a killer membership program, and their mobile app.](https://retentionedge.co/p/retention-edge-e11-unlocking-growth-with-country-life-natural-foods)[![Image 18: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 19: Retention Edge E13: MASC's Proven Retention Formula](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/cdc02fbd-3804-4170-8019-ca8f7566aacb/patrick_masc.png)](https://retentionedge.co/p/retention-edge-e12-masc-s-proven-retention-formula)

[Oct 13, 2025 Retention Edge E13: MASC's Proven Retention Formula --------------------------------------------------- This skincare brand's focus on retention, loyalty and elite CX continues to drive results after 18 years in business.](https://retentionedge.co/p/retention-edge-e12-masc-s-proven-retention-formula)[![Image 20: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[![Image 21: How to Build Recurring Revenue That Sticks](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/15802316-8fad-4279-a243-08ea80b85ead/Linkedin_Newsletter_Banner_27_.png)](https://retentionedge.co/p/7-takeaways-from-bfcm-2025-so-far)

[Nov 26, 2025 7 Takeaways from BFCM 2025 (So Far) ----------------------------------- Black Friday isn’t here yet — but the patterns are. See what the early signals show.](https://retentionedge.co/p/7-takeaways-from-bfcm-2025-so-far)[![Image 22: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 23: Retention Edge E19: The Truth About Agencies, YouTube Ads, and AI Creative](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,on

*[... truncated, 12,803 more characters]*

---

### The Retention Edge by MobiLoud
*499 words* | Source: **GOOGLE** | [Link](https://retentionedge.co/archive?page=2)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 1: Retention Edge E14: Planning to Win BFCM](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/eaed2fc5-ee22-4067-8e46-721509f8391b/ben_zettler.png)](https://retentionedge.co/p/retention-edge-e14-planning-to-win-bfcm)

[Oct 20, 2025 Retention Edge E14: Planning to Win BFCM ---------------------------------------- Your BFCM planning schedule, avoiding the most common mistakes, and retention strategies that work.](https://retentionedge.co/p/retention-edge-e14-planning-to-win-bfcm)[![Image 2: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[![Image 3: What winners do differently on Black Friday](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/db432973-74e9-4705-be65-ad6e2cb866a1/Copy_of_Retention_Edge_-_Templates__1200_x_630_px__1_.png)](https://retentionedge.co/p/strategic-discounting)

[Oct 16, 2025 Strategic Discounting --------------------- How to use the "D" word smartly to drive growth.](https://retentionedge.co/p/strategic-discounting)[![Image 4: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 5: Retention Edge E13: MASC's Proven Retention Formula](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/cdc02fbd-3804-4170-8019-ca8f7566aacb/patrick_masc.png)](https://retentionedge.co/p/retention-edge-e12-masc-s-proven-retention-formula)

[Oct 13, 2025 Retention Edge E13: MASC's Proven Retention Formula --------------------------------------------------- This skincare brand's focus on retention, loyalty and elite CX continues to drive results after 18 years in business.](https://retentionedge.co/p/retention-edge-e12-masc-s-proven-retention-formula)[![Image 6: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[![Image 7: What winners do differently on Black Friday](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/db432973-74e9-4705-be65-ad6e2cb866a1/Copy_of_Retention_Edge_-_Templates__1200_x_630_px__1_.png)](https://retentionedge.co/p/5-ecom-shifts-you-can-t-afford-to-ignore)

[Oct 09, 2025 5 Ecom Shifts You Can’t Afford to Ignore ---------------------------------------- From iOS privacy chaos to creator-led marketing, here’s what actually matters right now.](https://retentionedge.co/p/5-ecom-shifts-you-can-t-afford-to-ignore)[![Image 8: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://retentionedge.co/t/Podcast)Podcast

[![Image 9: Retention Edge E12: How Yon-Ka Paris Gets a 50% Repeat Purchase Rate](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/2bf122cc-8cd8-45be-b188-1b97c5fdbf7c/youtube_thumbnail__2_.png)](https://retentionedge.co/p/retention-edge-e12-how-yon-ka-paris-gets-a-50-repeat-purchase-rate)

[Oct 06, 2025 Retention Edge E12: How Yon-Ka Paris Gets a 50% Repeat Purchase Rate -------------------------------------------------------------------- Global beauty brand Yon-Ka Paris lifts the hood on their successful retention strategy.](https://retentionedge.co/p/retention-edge-e12-how-yon-ka-paris-gets-a-50-repeat-purchase-rate)[![Image 10: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[![Image 11: What winners do differently on Black Friday](https://media.beehiiv.com/cdn-cgi/image/format=auto,width=800,height=421,fit=scale-down,onerror=redirect/uploads/asset/file/db432973-74e9-4705-be65-ad6e2cb866a1/Copy_of_Retention_Edge_-_Templates__1200_x_630_px__1_.png)](https://retentionedge.co/p/is-chatgpt-the-new-amazon)

[Oct 02, 2025 Is ChatGPT The New Amazon? -------------------------- 10 Takeaways from the ChatGPT Announcement](https://retentionedge.co/p/is-chatgpt-the-new-amazon)[![Image 12: Pietro Saccomani](https://beehiiv-images-production.s3.amazonaws.com/uploads/user/profile_picture/760dc52c-810c-49ba-91c7-06072927cf4d/1730565620526.jpeg) Pietro Saccomani](https://retentionedge.co/authors)

[Podcast](https://ret

*[... truncated, 5,434 more characters]*

---

### 11 High-Impact Newsletters for DTC Ecommerce Leaders
*1,713 words* | Source: **GOOGLE** | [Link](https://www.mobiloud.com/fr/blog/ecommerce-newsletters)

Winning in DTC isn’t just about great products. It’s about staying ahead of the curve.

The best operators know that insights, trends, and executional tactics make or break a brand. But let’s be real: not all newsletters are worth your time, attention, or inbox real estate.

We’ve curated the **top 11 newsletters** that actually deliver value... whether it’s actionable growth strategies, deep dives on emerging trends, or insider playbooks from the best in the game.

If you’re running a DTC brand, scaling an ecom business, or just obsessed with the space, these are the emails you’ll actually look forward to opening.

The Best Ecommerce Newsletters
------------------------------

### Operators Newsletter

![Image 1: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349d5_20250702T0923-76d5c034-3d0e-4b2c-bd97-7aae65df7769.webp)

The [Operators Newsletter](https://operatorscontent.com/) is an amazing intelligence hub for direct-to-consumer (DTC) brands navigating the complexities of scaling to nine-figure revenues.

Curated by Aaron Orendorff, and featuring content from the likes of Sean Frank (Ridge), Matt Bertulli (Lomi & Pela Case), Mike Beckham (Simple Modern), Cody Plofker (Jones Road Beauty) and Jason Panzer (HexClad), this publication distills hard-won insights from executives behind industry titans into actionable frameworks.**‍**

*   ‍**Content Focus**: Hard-won lessons from scaling nine-figure DTC brands, tactical playbooks (e.g., checkout optimization), and breaking consumer news.**‍**
*   **Frequency**: Weekly.**‍**
*   **Target Audience**: DTC founders, C-suite executives, and operators managing high-growth brands.**‍**
*   **Unique Selling Proposition**: Leaked strategies and unfiltered case studies from celebrity-backed brands, offering a rare look at overcoming operational bottlenecks.**‍**
*   **Subscription**: Free signup via [operatorscontent.com](https://operatorscontent.com/).

### The Retention Edge by MobiLoud

![Image 2: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349c4_20250702T0923-180e6aff-7863-4339-b14e-b4a29ef79401.webp)

From[MobiLoud](https://www.mobiloud.com/) founder Pietro Saccomani, [The Retention Edge](https://retentionedge.co/) puts the focus on sustainable growth strategies, interviewing and curating retention and LTV tactics from the world’s top DTC brands.

The Retention Edge Features a free weekly newsletter and podcast, where the team interviews top thought leaders in retention marketing, all with the goal of helping brands drive long-term growth and profitability.

*   ‍**Content Focus**: Retention marketing tactics driven by real examples of what’s really working for successful DTC brands.**‍**
*   **Frequency**: Weekly.**‍**
*   **Target Audience**: DTC founders and leaders at 7 figure+ brands.**‍**
*   **Unique Selling Proposition**: Easily digestible, actionable insights, driven from interviews with DTC, ecommerce and retail leaders.**‍**
*   **Subscription**: Free at [retentionedge.co](https://retentionedge.co/)

### Chew On This

![Image 3: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349e6_20250702T0923-42548626-ceb0-4342-a502-8336f74d5cab.webp)

Founded by Ron Shah and Ankit Patel, whose Obvi brand scaled to $90M in five years, [Chew On This](https://www.subscribe.chewonthis.io/) synthesizes battlefield-tested strategies with forward-looking industry analysis.

Chew On This redefines DTC thought leadership by merging street-level execution insights with boardroom-caliber strategy. For founders committed to profitable scaling in an era of platform uncertainty, its combination of transparency, tactical specificity, and future-proof frameworks makes it indispensable.

*   ‍**Content Focus**: Profitability tactics for scaling DTC brands, including Meta ad structures, influencer programs, and landing page optimization.**‍**
*   **Frequency**: Twice weekly.**‍**
*   **Target Audience**: Founders aiming to scale beyond $10M–$100M revenue.**‍**
*   **Unique Selling Proposition**: Battle-tested frameworks from growing Obvi to $90M in five years, emphasizing capital efficiency and retention.**‍**
*   **Subscription**: Free at [subscribe.chewonthis.io](https://www.subscribe.chewonthis.io/).

### Nik Sharma Newsletter

![Image 4: __wf_reserved_inherit](https://cdn.prod.website-files.com/63894f0e251e567f6e443bfa/6865a531ba5fdc39361349d8_20250702T0923-0c665bb7-1aaa-4e51-a48f-5b1ec26a066f.webp)

The [Nik Sharma Newsletter](https://workweek.com/discover-newsletters/sharma/) is perfect for DTC operators seeking actionable growth strategies. With 100,000+ weekly readers across 45 countries, this publication distills Sharma's decade of experience scaling brands like Hint and Chamberlain Coffee into five-minute tactical briefs.

Nik Sharma’s newsletter cuts through theory with tactical advice, whether it's optimizin

*[... truncated, 10,838 more characters]*

---

### Brits spend nearly £2,000 a year online, study finds
*1,457 words* | Source: **GOOGLE** | [Link](https://internetretailing.net/brits-nearly-spend-2000-a-year-online-study-finds/)

Brits spend nearly £2,000 a year online, study finds - InternetRetailing

===============

[![Image 1](https://internetretailing.net/wp-content/uploads/2022/04/17IRlogo3.svg)](https://internetretailing.net/)

[![Image 2: InternetRetailing Logo](https://internetretailing.net/wp-content/uploads/2022/04/17IRlogo3.svg)](https://internetretailing.net/ "InternetRetailing Home Page")

Search 

*   [](https://internetretailing.net/channel/retail-media/)
    *           *               *   [Retail MediaX News](https://internetretailing.net/channel/retail-media/)
            *   [Retail MediaX Commentary](https://internetretailing.net/channel/retail-media/#commentary)
            *   [Retail MediaX Case Studies](https://internetretailing.net/channel/retail-media/#casestudies)
            *   [Retail MediaX Event](https://retailx.events/retailmediax/)
            *   [Retail MediaX Reports](https://internetretailing.net/channel/retail-media/#research)
            *   [Retail MediaX Podcast](https://internetretailing.net/media/retail-media-podcast/)
            *   [Retail MediaX Newsletter](https://retailx64559.activehosted.com/f/65)

*   [](https://internetretailing.net/channel/subscriptions/)
    *           *               *   [SubscriptionX News](https://internetretailing.net/channel/subscriptions/)
            *   [SubscriptionX Commentary](https://internetretailing.net/channel/subscriptions/#commentary)
            *   [SubscriptionX Case Studies](https://internetretailing.net/channel/subscriptions/#casestudies)
            *   [SubscriptionX Event](https://retailx.events/subscriptionx/)
            *   [SubscriptionX Reports](https://internetretailing.net/channel/subscriptions/#research)
            *   [SubscriptionX Podcast](https://internetretailing.net/subscription-podcast/)
            *   [SubscriptionX Newsletter](https://communication.retailx.net/f/75)

*   [News](https://internetretailing.net/internetretailing-channel/)
    *           *               *   [InternetRetailing](https://internetretailing.net/internetretailing-channel/)
            *   [Channels](https://internetretailing.net/category/themes/channels/)
            *   [Sustainability](https://internetretailing.net/themes/sustainability/)
            *   [Merchandise](https://internetretailing.net/category/themes/merchandising/)
            *   [Strategy](https://internetretailing.net/themes/strategy-and-innovation/)
            *   [Digital](https://internetretailing.net/category/themes/digital/)
            *   [Frontline](https://internetretailing.net/views/frontline/)

*   [Podcasts](https://internetretailing.net/channel/retail-media/)
    *           *               *   ### Media 
            *   [FMCG Podcast](https://internetretailing.net/media/fmcg-podcast/)
            *   [The Retail Media Podcast](https://internetretailing.net/media/the-retail-media-podcast/)
            *   [Marketing Unlearned](https://internetretailing.net/media/marketing-unlearned/)
            *   [RetailCraft Podcast](https://internetretailing.net/media/retailcraft-podcast/)
            *   [SubscriptionX Podcast](https://internetretailing.net/subscription-podcast/)
            *   [ChannelX Podcast](https://internetretailing.net/channelx-podcast-2024/)
            *   [Video Channel](https://internetretailing.net/media/video-channel/)

*   [Reports](https://internetretailing.net/research/)
    *           *               *   ### Research 
            *   [Sector Reports](https://internetretailing.net/research/retailx-sector-reports/)
            *   [Whitepapers](https://internetretailing.net/research/whitepapers/)
            *   [Bluepapers](https://internetretailing.net/research/bluepapers/)
            *   [Ranking Reports](https://internetretailing.net/research/top500-reports/)
            *   [Country Reports](https://internetretailing.net/research/retailx-country-reports/)
            *   [Marketplace Reports](https://internetretailing.net/research/rxeu-marketplace-report/)
            *   [Upcoming Reports](https://internetretailing.net/reports-coming-soon/)
            *   [Browse All Reports](https://internetretailing.net/browse-all-reports/)

        *               *   ### Featured Reports 
            *   [Top500 2025](https://internetretailing.net/report-hub/retailx-united-kingdom-top500-2025/)
            *   [Global Homeware Sector Report 2025](https://internetretailing.net/report-hub/global-homeware-sector-report-2025)

*   [Events](https://internetretailing.net/upcoming-events/)
    *           *               *   [Events](https://internetretailing.net/upcoming-events/)
            *   [Upcoming Webinars](https://internetretailing.net/upcoming-events/upcoming-webinars/)
            *   [On-demand webinars](https://internetretailing.net/upcoming-events/past-webinars/)

        *               *   [RetailX Events](https://retailx.events/)
            *   [Retail MediaX](https://retailx.events/retailmediax/)
            *   [Spring Retail Fes

*[... truncated, 18,605 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Building Mobile Apps for WP with Pietro Saccomani of Mobiloud](https://wpcast.fm/mobiloud)**
  - Source: wpcast.fm
  - *Apr 1, 2015 ... Building Mobile Apps for WordPress with Pietro Saccomani of Mobiloud – WPCAST039 ... Podcast: Play in new window | Download (Duration:...*

- **[Podcast | The Retention Edge by MobiLoud](https://retentionedge.co/t/Podcast)**
  - Source: retentionedge.co
  - *The Retention Edge by MobiLoud logo. The Retention Edge by MobiLoud ... Insights from 15+ years scaling 8 & 9-figure brands. Pietro ......*

- **[The Retention Edge by MobiLoud](https://retentionedge.co/)**
  - Source: retentionedge.co
  - *The retention engine that converts higher, retains high-value customers, and delivers dependable ROI. Pietro Saccomani · PodcastPodcast....*

- **[Archive | The Retention Edge by MobiLoud](https://retentionedge.co/archive?page=2)**
  - Source: retentionedge.co
  - *Oct 20, 2025 ... How to use the "D" word smartly to drive growth. Pietro Saccomani · PodcastPodcast. Retention Edge E13: MASC's Proven ......*

- **[11 High-Impact Newsletters for DTC Ecommerce Leaders](https://www.mobiloud.com/fr/blog/ecommerce-newsletters)**
  - Source: mobiloud.com
  - *Aug 23, 2025 ... From MobiLoud founder Pietro Saccomani, The Retention Edge puts the ... podcast interviews (e.g., segmentation tips from retention ex...*

- **[Brits spend nearly £2,000 a year online, study finds - InternetRetailing](https://internetretailing.net/brits-nearly-spend-2000-a-year-online-study-finds/)**
  - Source: internetretailing.net
  - *Nov 10, 2025 ... SubscriptionX Podcast · SubscriptionX Newsletter · News ... Pietro Saccomani, founder and CEO of MobiLoud, attributes this to ......*

- **[LBM Audible | LondonBloggers.net](https://londonbloggers.net/category/lbm-audible/)**
  - Source: londonbloggers.net
  - *LBM Audible #17: Building a Mobile App for your Blog with Pietro Saccomani ... This episode was recorded after the Mobiloud crew presented at the Lond...*

- **[6 Best AI Agent Courses for Beginners and Non-Coders in 2025 ...](https://www.classcentral.com/report/best-ai-agent-courses/)**
  - Source: classcentral.com
  - *Oct 15, 2025 ... I spoke to Pietro Saccomani, too, a no-code enthusiast and founder of MobiLoud: “AI-powered automation tools like Zapier or Lindy let...*

- **[Testimonials- OLD | Remote First Recruiting](https://remotefirstrecruiting.com/testimonials)**
  - Source: remotefirstrecruiting.com
  - *Pietro Saccomani. Founder of MobiLoud. “We loved working with Remote First Recruiting. They made the job listing process extremely quick and easy on o...*

- **[Mental Health App Development: Case Study-Based Guide](https://stormotion.io/blog/how-to-develop-a-mental-health-app/)**
  - Source: stormotion.io
  - *5 days ago ... Pre-appointment patient interviews;; Payment processing ... Pietro Saccomani, Founder. MobiLoud. Was it helpful? Questions you may ......*

---

*Generated by Founder Scraper*
