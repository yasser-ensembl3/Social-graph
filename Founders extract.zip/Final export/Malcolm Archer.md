# Malcolm Archer

## Position actuelle

**Titre** : Head of Supply
**Entreprise** : Stay22
**Durée dans le rôle** : 5 months in role
**Durée dans l'entreprise** : 2 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Tasked with building and scaling the supply side of Stay22’s marketplace, focusing on strategic partnerships that power our product and unlock incremental value for publishers.

Working closely with Product, Engineering, and the Commercial team to ensure supplier integrations directly support monetization, user experience, and long-term growth. Building a new team to manage partner success, optimize inventory performance, and lay the foundation for new revenue channels.

Mandate includes:

Expanding and diversifying our supply footprint across key verticals

Improving supply efficiency and user conversion across the platform

Developing internal systems to support supplier-facing operations

Ensuring alignment with Commercial to match supply with market needs and partner opportunities

## Résumé

Father of two, beach volleyball enthusiast, and someone who asks a lot of questions, I have an endless curiosity and I'm genuinely interested in people's stories. I’ve spent the last few years helping scale Stay22 from $5M to $40M ARR by building out and leading our Sales team, launching new functions, and chasing ambitious targets with a group of smart, driven people.

I now lead our Supply team, focused on strengthening the partnerships and integrations that power our product and drive real value for our users and publishers. That means working closely with Product, Engineering, and the Commercial team to make sure what we source is bookable, profitable, and useful - without wasting anyone’s time.

Before Stay22, I helped scale Lightspeed pre- and post-IPO, led the first unified Account Management team at ShopKeep and Vend (now X-Series), co-founded a real estate tech venture called Geoclique, and started out at Wavefront’s wireless incubator.

I like solving problems that don’t have a playbook, building teams that know how to figure things out, and keeping things human in a space that’s easy to over-complicate.

I don’t typically add people to my network unless we’ve worked together or had a proper conversation. I like to know I can vouch for the people I’m connected to. So if you're reaching out, let’s start with a quick chat.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAOVSKsB9Wwlz-I_22f1ySzCcNh8FdCJIeA/
**Connexions partagées** : 33


---

# Malcolm Archer

## Position actuelle

**Entreprise** : Stay22

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Malcolm Archer
*Stay22*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Malcolm Archer Email & Phone Number | Davies Maguire Director Contact Information](https://rocketreach.co/malcolm-archer-email_96606147)
*2025-01-01*
- Category: article

### [Podcast: How Stay22 Revolutionizes Event Travel](https://blog.stay22.com/podcast-how-stay22-revolutionizes-event-travel)
*2024-09-09*
- Category: podcast

### [- YouTube](https://www.youtube.com/watch?v=pmh97Kq3xhM)
*2025-04-25*
- Category: video

### [112. Have Bookings Dropped? This Little Device is the Answer! Interview with StayFi](https://podcasts.apple.com/bg/podcast/112-have-bookings-dropped-this-little-device-is-the/id1620243933?i=1000657895312)
*2024-06-05*
- Category: podcast

### [The Changing Landscape of Vacation Rental Marketing with StayFi's Arthur Colker | Behind the Stays](https://behindthestays.podbean.com/e/the-changing-landscape-of-vacation-rental-marketing-with-stayfis-arthur-colker/)
*2024-09-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Councils, Committees, Task Forces and Working Groups](https://www.iab.com/councils-committees-task-forces-and-working-groups/?key=a7d5b000000H7HXAA0)**
  - Source: iab.com
  - *Shows & Podcasts. Shows & Podcasts. IAB There · IAB Pulse ... Malcolm Archer. Stay22. Katie Arena. Clinch. Akshay Arora. Adapex. Kandi Arrington....*

- **[Stay22 in the News](https://www.stay22.com/press)**
  - Source: stay22.com
  - *ITB Berlin 2024: Rami Nuseir, Head of Marketing, and Malcolm Archer, Head of Sales at Stay22. ... Optimizing Hotel Affiliates – Interview With Stay22'...*

- **[Stay22 strengthens leadership to drive next... | Travolution](https://www.travolution.com/news/people/stay22-strengthens-leadership-to-drive-next-phase-of-expansion/)**
  - Source: travolution.com
  - *Sep 19, 2025 ... Malcolm Archer takes new role and Geordie Kingsbury recruited. Travel tech firm Stay22 has bolstered its leadership team in a bid to ...*

- **[Stay22 strengthens leadership to drive next phase of expansion](https://money-tourism.gr/en/stay22-strengthens-leadership-to-drive-next-phase-of-expansion/)**
  - Source: money-tourism.gr
  - *Sep 18, 2025 ... Tagged Geordie Kingsbury leadership Malcolm Archer sales Stay22. Post ... INTERVIEW (17); MONEY (311); OPINION (31); ORGANIZATIONS (6...*

- **[Stay22 - 2025 Company Profile, Team, Funding & Competitors ...](https://tracxn.com/d/companies/stay22/__T45gmIr_hvVDBbj6XEUQne8LAqnZgJREp4W2v3n39-c)**
  - Source: tracxn.com
  - *Nov 5, 2025 ... Stay22 bolsters leadership team to drive expansion; Malcolm Archer ... Conference or ConventionExhibitor•Jun 14, 2018•Stay22, 7 Gate ....*

- **[Frederic Aouad - Chief Commercial Officer (cco) at Stay22 | The Org](https://theorg.com/org/stay22/org-chart/frederic-aouad)**
  - Source: theorg.com
  - *In 2019, they founded Consult-X and took on the role of Chief Revenue Officer at Stay22 ... Malcolm Archer. Head of Sales. Hiring. Enterprise Partners...*

- **[Celine Harwood Email & Phone Number | Stay22 Head of HR ...](https://rocketreach.co/celine-harwood-email_62549820)**
  - Source: rocketreach.co
  - *Stay22 Employee Malcolm Archer's profile photo. Malcolm Archer. Head of Supply ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
