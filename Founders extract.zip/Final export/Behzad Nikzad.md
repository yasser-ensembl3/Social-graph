# Behzad Nikzad

## Position actuelle

**Titre** : Founder & Principal Architect
**Entreprise** : Tempered AI
**Durée dans le rôle** : 2 years 3 months in role
**Durée dans l'entreprise** : 2 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : IT Services and IT Consulting

## Description du rôle

Leading and delivering data science & data engineering projects.

## Résumé

I lead a talented group of consultants who enjoy solving interesting data science and data engineering problems. We are focused on delivering solutions on Databricks and specialize in ML, MLOps, and the newest applications of LLMs to industry problems.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACczZqoBzJIkFa51NeHz3q12yTZ21zwWncg/
**Connexions partagées** : 26


---

# Behzad Nikzad

## Position actuelle

**Entreprise** : Tempered AI

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 1st


---

# Behzad Nikzad

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402589491066314752 | Text |  |  | One of the coolest announcements I have been anticipating is branching in #lakebase.

It's one of the most applicable yet strangest ideas I have encountered in my career. Branching on databases. I can't shake the fact that I first heard about and understood the concept at #DAIS from a vendor, specifically lakeFS. It was Oz Katz and his team that introduced me to the paradigm that data can be versioned.

https://lnkd.in/gtn5a_dw | 13 | 3 | 0 | 2d | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:18.339Z |  | 2025-12-05T06:07:48.132Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396193399424372736 | Document |  |  | Most CxOs we speak with tell us the same thing:

“We’re investing heavily in Databricks, but I'm concerned we're not using it the right way.”

You see spend going up, teams getting bigger, roadmaps getting longer.

But you don't have a clear view of:
 • Revenue and margin
 • Cost and productivity
 • Risk and resilience

Instead you get fragmented updates, technical language and no single version of the truth.

This is the gap that AMPLIFY, our new Advisory Partnership Program is built to close.

We've partnered with Dan Williams and DecisionForest so that not just one, but TWO Databricks MVPs sit across your data estate, from board priorities down to delivery.

You get:
 • One portfolio view of all Databricks work, tied to your strategic outcomes
 • Clear ownership, milestones and value per workstream
 • A health and risk view that you can use in your planning
 • Fast escalation paths so decisions are made quickly

If this is the kind of visibility you want, 𝐣𝐨𝐢𝐧 𝐨𝐮𝐫 𝐩𝐫𝐢𝐯𝐚𝐭𝐞 𝐒𝐥𝐚𝐜𝐤 𝐜𝐡𝐚𝐧𝐧𝐞𝐥 to see how AMPLIFY works in practice and how we can get started:

https://lnkd.in/eRKmDUcB | 39 | 1 | 1 | 2w | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.006Z |  | 2025-11-17T14:32:01.051Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395240442071629825 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF2VwvBf7d0Og/feedshare-shrink_800/B4EZqEr_oeKcAg-/0/1763162717308?e=1766620800&v=beta&t=49KbVN4exG9p9DPSUi7exKrhRZtBaJ-9Yk-IaO_73qU | If you are building #Genie spaces in Databricks, you really should start using Metric Views. #MetricViews already provide: 

 • An unified path to building Dashboards with AI embedded by design. 
 • Business friendly field descriptions and definitions by design. 
 • A meaningful way to define the KPIs business cares about.
 • A structured way to give look up synonyms for fields. 

All this means you get a more comprehensive and more accurate Genie space. You also future proof your work, as the same semantic layer will be used again by others in the organization. | 452 | 6 | 34 | 3w | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.007Z |  | 2025-11-14T23:25:18.313Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394109886080479232 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEQlc18KRXVJg/feedshare-shrink_800/B56Zp0nwj9I8Ag-/0/1762893171338?e=1766620800&v=beta&t=wgObHNjOy18ozj3-UBNbhK9V52rk4GBzfRN8YFbRKdE | My team at Tempered AI has been developing a ton of PDF / OCR Readers and we did not see this coming ... 

We recently got the opportunity to work on multiple PDF reading projects, and one of them was a real world use case at industrial scale. As part of our exploration we tested Azure Document Intelligence, but in the end developed our own parser (on top of OSS and gpt-4o-mini) which was 4 times faster and 5 times cheaper than Azure DI and just as accurate. 

Now, Databricks is launching "ai_parse_document" as a managed service! See for yourself: https://lnkd.in/gXR4RFDb

This will drastically reduce development cost and give results just as good as we achieved for our client. I recently got to see a demo of ai_parse_document and some numbers on it. My team also got to speak to Archika Dogra at Databricks who is working on the product. Coming right off of our own project, we were very impressed with what we saw. 
 
The price is great and Databricks beats out the main competition by far. However, what I am most excited about is the configurability. If I am already working inside Databricks, ai_parse_document is available to me as a function. What does this mean? I can use it as part of a pipeline e.g. if the naming convention means something for my files, then I can classify documents and pass them through a configured instance for that class! | 213 | 22 | 12 | 3w | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.008Z |  | 2025-11-11T20:32:52.760Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7391957780628201472 | Article |  |  | Is Gen AI even good? I mean ... we put lightening into rocks and used counting to make it talk ...

https://lnkd.in/g7Y9rBxC | 7 | 0 | 0 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.008Z |  | 2025-11-05T22:01:10.836Z | https://www.youtube.com/watch?v=PdFB7q89_3U |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7391117022102859776 | Text |  |  | Why is it that we, at Tempered AI, deliver success where other consulting firms fail?


I'll give you the secret, and if you run a consulting firm, you can implement it for yourself. We follow a simple set of ideas, all born from years of hands-on keyboard experience and some knowledge of political science and anthropology. 

𝗪𝗵𝗮𝘁 𝗸𝗶𝗹𝗹𝘀 𝗽𝗿𝗼𝗷𝗲𝗰𝘁𝘀: 

Tech is usually relegated to delivering tasks. At best a CTO / Partner gets to sit in the decision making table. This is wrong. The person that ought to lead a project and make all the decisions from a delivery perspective is ... the one delivering it. 

"What if they are a junior?" you say, it doesn't matter. If you can't trust the person that is doing the delivery to make decisions, then you need a better team. Your job as a mentor, leader, account executive, project manager, etc is to 𝘢𝘴𝘴𝘪𝘴𝘵 the technical person that is doing the delivery. That's it. Your job is not to set deadlines or expectations. You can track results, you can not demand them.

𝗪𝗵𝗮𝘁 𝗺𝗮𝗸𝗲𝘀 𝗽𝗿𝗼𝗷𝗲𝗰𝘁𝘀 𝘀𝘂𝗰𝗰𝗲𝗲𝗱: 

The solution to every technical problem is competent staff and time. That's it. That's the entire secret. Hire the right people, present them with an interesting problem, empower them to solve it, and at most track their progress for project management. 

𝗪𝗵𝘆 𝗶𝘀 𝘁𝗵𝗶𝘀 𝗼𝗯𝘃𝗶𝗼𝘂𝘀: 

The techncial folk already know what I said is true. For the non-technical folk, would your work in sales / marketing get better or worse if you had a coder dictating timelines and expectations to you? Would you achieve better results if you can make decisions or if a coder was deciding for you? You only need them to assist you, right? Same thing. 

𝗕𝘂𝗶𝗹𝗱𝗶𝗻𝗴 𝗯𝗲𝘁𝘁𝗲𝗿 𝘄𝗼𝗿𝗸 𝗲𝗻𝘃𝗶𝗿𝗼𝗻𝗺𝗲𝗻𝘁𝘀:

I recommend everyone reads David's Graeber's "Bullshit Jobs". Together, we can build a better work culture, deliver more projects, and have more fun! | 14 | 2 | 2 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.009Z |  | 2025-11-03T14:20:18.383Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7389574849628856320 | Text |  |  | I think everyone is overestimating what AI is because they don't understand it. 

Modern AI algos are at their core really good index-search algorithms.

Euclid's Elements is famous because it was a good index-search algorithm. 

Ibn Sina's Cannon of Medicine (القانون فی الطب) was for a millenia the authoritative source on medicine because it is a good index-search algorithm. 

The Dewey Decimal system is famous because it is a good index-search algorithm. 

Google search launched an industry titan because it is a good index-search algorithm. 

Modern AI is an extension of what we have been doing for millenia. Writing gave us external memory. Index-Search algorithms give us external intelligence. 

One can ultimately argue that much of human intelligence is a good index-search algorithm. Still, that would mean modern AI is an extension of what we have been doing all along, creating better and better index-search algorithms. | 30 | 1 | 3 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.010Z |  | 2025-10-30T08:12:15.813Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7388911652215222272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGcIXy8-l6_tA/feedshare-shrink_800/B4EZoqVPq6GoAg-/0/1761646806230?e=1766620800&v=beta&t=_GRGJZ37BQ-Fwjp7_om7DDzO-bIyHiQSFo5dtXwk6Jo | For the curious. This is the equivalent of a person "thinking about thinking". 

Love the reference to the Münchhausen trilemma. | 2 | 0 | 0 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.010Z |  | 2025-10-28T12:16:57.228Z | https://www.linkedin.com/feed/update/urn:li:activity:7388882252065185792/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7387894558677921792 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGFPSR5RddtKw/feedshare-shrink_800/B56ZocS8GgIsAg-/0/1761411320907?e=1766620800&v=beta&t=dNnj0pH3fA7vKKc4-m-eanmcD8vfe-N7vrkLLuwm3gw | In the last 2 months, I have had 4 clients ask if we can embed Databricks #Genie into #Tableau and other visualization tools. The answer is yes. We can do it for you, but we prefer not to do it. Instead we recommend to our clients that they look forward and future-proof their business by using Databricks native products. 

1. Consumption: This is the biggest source of hesitancy so let me address that first. #DatabricksOne is the consumption layer for business users going into the future. You don't have to worry about your business users getting lost in the development environment. 

2. Security: Everything and I mean #Everything in Databricks is governed through #UnityCatalog. This means access to dashboards, Genie, and column level / row level restricting can be all done inside Databricks, and it all integrates together. 

3. The unified semantic layer. Databricks has introduced #MetricViews and they are only going to get better going forward. The same semantic model will feed Genie and your dashboard. 

4. The managed service. You can get this set up today, without any need for extra development using external tools and you don't need ongoing support. New features and integrations will be released inside the Databricks ecosystem and many of the features will be using the new semantic layer. 

If you need to learn more about how to future-proof your business and streamline the change management that will let you access AI on your Data, give us a call at Tempered AI and we will be happy to give you expert guidance. | 181 | 4 | 10 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.011Z |  | 2025-10-25T16:55:23.232Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7386767740310605824 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHd6cjdg4kPdg/feedshare-shrink_800/B56ZoHug77IsAg-/0/1761066230518?e=1766620800&v=beta&t=8vb7xQpjQE3xOf9_V3B6XUOAqRZOhxSIiAOstyz7oVI | One of the coolest papers I have seen this year. It is essentially an exploration of how an LLM "thinks". 

What is interesting here is that the authors recover a human understandable framework by which the LLM has learned to calculate a simple task. Reminds me of the work researchers did to uncover how bees encode information in their dance: https://lnkd.in/gMN86CDU

We are uncovering what we would call "abstract thinking", which has come as an emergent phenomenon. 

This is that actual edge of AI "thinking" and it's very cool to see it shown in such a nice paper. Kudos to the authors. As an aside, the most impressive thing LLMs do today are still just indexing and searching, and it's impressive to us humans because we don't have the compute power and memory that goes into training an LLM. Otherwise we would consider them very dumb. | 6 | 1 | 0 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.012Z |  | 2025-10-22T14:17:48.798Z | https://www.linkedin.com/feed/update/urn:li:activity:7386447137963831296/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7386426479892586496 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGb6LbRFxWWxg/feedshare-shrink_800/B56ZoHbvgWIsAk-/0/1761061304782?e=1766620800&v=beta&t=kpsKxw0nXpA0RFaG-cvY2Yu46Pj5DPiOKp4QxHwvLEU | Let me tell you why Tempered AI is the best Databricks implementation firm to work with:

 1. 𝗪𝗲 𝗹𝗶𝗸𝗲 𝗼𝘂𝗿 𝗷𝗼𝗯𝘀! The team really enjoys working with Databricks and we are all nerds who can't get enough of a good data science problem. This is our hobby. Get us interested in your problem, and we will be working late because it's fun.

 2. 𝗪𝗲 𝗮𝗿𝗲 𝗶𝗻𝗱𝘂𝘀𝘁𝗿𝘆 𝘃𝗲𝘁𝗲𝗿𝗮𝗻𝘀. The majority of our staff are seasoned veterans. They come with experience in many different industries and technologies. We know how to manage our projects. We know how to communicate in difficult situations. You can expect data engineering best practices out of the gate.

 3. 𝗪𝗲 𝗮𝗿𝗲 𝗗𝗮𝘁𝗮𝗯𝗿𝗶𝗰𝗸𝘀 𝗽𝗿𝗼𝘃𝗲𝗻. We have solved some of the most challenging problems. From text-extraction for insurance firms to chatbots for Mastercard. When we take on a project, we deliver it. Databricks staff can attest to the quality of our work.

 4. 𝗪𝗲 𝗮𝗿𝗲 𝗼𝗻-𝘀𝗵𝗼𝗿𝗲 (𝗖𝗮𝗻𝗮𝗱𝗮). This means we have the experience you need, but at competitive prices. The fact that we don't have non-technical management also means savings for you. 

 5. 𝗪𝗲 𝗸𝗻𝗼𝘄 𝘄𝗵𝗲𝗿𝗲 𝗗𝗮𝘁𝗮𝗯𝗿𝗶𝗰𝗸𝘀 𝗶𝘀 𝗵𝗲𝗮𝗱𝗶𝗻𝗴. As a Databricks MVP & Solution Architect Champion, I am well aligned with the future vision of Databricks and so are my team. We can future-proof the implementation for you.

If you are a Databricks AE / SA looking for a team that can deliver on the promise of Databricks, DM me. 

If you are a Databricks client and you want to achieve a best in class Databricks implementation, DM me. | 21 | 0 | 1 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.013Z |  | 2025-10-21T15:41:45.974Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7385361049413165056 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQETWDAQISY-ow/feedshare-shrink_800/B56Zn4SvI7KEAg-/0/1760807286789?e=1766620800&v=beta&t=HxVl81c6InlooCchNw9QWjVgEipys8fGrwTcTzFVNus | Evidence set #374 that modern LLMs are an extension of index-search algorithms.

How many truly novel math problems has modern AI solved? Not much really. However they are quite good at literature review etc. 

I see the same idea being passed around in coding. That LLMs speed up search and code reviews more so than writing code. | 4 | 0 | 0 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.013Z |  | 2025-10-18T17:08:07.553Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7384761708101373952 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH46m6J1I4Lbw/feedshare-shrink_800/B56Znvxo4uI0Ag-/0/1760664391976?e=1766620800&v=beta&t=c7y3nALg_o0SjwFWLfY0xt21D35NSG4lxvO7aLrPkJU | The list of Databricks connectors is growing daily. Is #LakeflowConnect worth the cost?

I always wondered why Databricks didn't build these connectors earlier. Whatever the reason, they are here. I always recommend that clients use native Databricks features as opposed to a third party tool. Why? Future compatibility and knowing that these tools will get better very quickly. Databricks has proven this to all of us. In this regard the cost is absolutely worth it. 

However, one conversation I have had with multiple clients now is that the cost of using Lakeflow Connect can be prohibitive. This is because an ingestion gateway can only connect to one source at a time. Even if the client doesn't need live mirroring, the ingestion gateway stays on to not lose logs. The DBUs can add up over time.

For some very specific use cases, we at Tempered AI have developed a low cost method of using lakeflow connect. We want our clients to use the newest Databricks feature, and we make the cost works for them. If you are using #LakeflowConnect and want to know how to save on costs, you know where to find us. | 76 | 1 | 7 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.014Z |  | 2025-10-17T01:26:33.449Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7384428723216932864 | Text |  |  | After a decade in the industry, I can definitely confirm what is being said here by Parker Holzer, Ph.D. | 7 | 0 | 0 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.014Z |  | 2025-10-16T03:23:23.666Z | https://www.linkedin.com/feed/update/urn:li:activity:7382517797823660032/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7383607913950474242 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG5S8zZBJPSYw/feedshare-shrink_800/B56ZnfYRdNJkAg-/0/1760389306644?e=1766620800&v=beta&t=pgEKq8CeWCkXwAwKWMinND9wYtixUWAYCNGek3CLYcs | This post is going to be a humble brag about Tempered AI. 

We are in the process of delivering a real world project at industrial scale involving pdf-parsing and key-value extraction. At first we considered Microsoft Azure's Document Intelligence, but then pivoted to building an in-house opensource solution. 

How are we doing? We are beating Azure Document Intelligence by 5X on budget and 2X on speed, without losing on accuracy. I am pleasantly surprised. I have always had faith in the idea that if you put technical people together and empower them to solve problems they love great things will happen. I didn't expect us to do this well, this quickly. 

Follow our journey at Tempered AI as we become an elite team of hyper-technical Databricks implementation engineers / data scientists. We plan to do it based on a vision that technical people can deliver great work without the overhead of non-technical management. | 34 | 2 | 3 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.015Z |  | 2025-10-13T21:01:47.487Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7382116283749924864 | Text |  |  | I recently posted a job for a Junior Consultant and I am saddened by the overwhelming response. 

In about 3 days, we got 300 candidates, about 50 of which are qualified for the job (at least on paper). Why does this sadden me? There is a few trillion dollars currently being shuffled around the economy based on the amazing work done by Data Engineers and Data Scientists. 

There are many people who are earning six figure salaries in the industry who are not technical themselves. This is okay and there will always be non-technical roles. Sometimes there is organizational bloat with many non-technical people in sales, partnerships, marketing, product and other teams. Even this is okay. However, what is sad is to see how relegated the technical talent has already become in this global AI race. Why can't the big companies hire more junior technical people? Even if they don't currently need them. They already have massive organizational bloat from non-technical people they don't need either. A bored technical person innovates!

At Tempered AI we are trying to do things differently. We are a pure implementation team, without any non-technical management. This makes our work fun, efficient, and relatively more affordable than our competitors. If you are a technical person, I encourage to begin to speak up for and stand up for other technical people. We built the world, and like others, we have a right to live in it! | 51 | 5 | 2 | 1mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.015Z |  | 2025-10-09T18:14:35.134Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7379736799390257152 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGfRQs5jWiXKg/feedshare-shrink_800/B56ZmoXgu0KIAg-/0/1759466360523?e=1766620800&v=beta&t=wZ4nNqUSPk2F-DmDCHvSoN3r5M6cNXLKvk-0PM7tMok | I recently got an amazing opportunity to work on evaluating the Databricks #MLProfessionalExam. Honestly, I was surprised at the absolute pace of ML feature releases that have happened in the last year. Is there anyone out there who knows "all" of Databricks or even ML on Databricks at this point? If so, my bet is on Maria Vechtomova.

I got to learn a whole bunch about psychometrics and got yet another reminder of the dedication to the craft which can be found in Databricks. I also got this really cool looking badge! | 63 | 4 | 0 | 2mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.017Z |  | 2025-10-03T04:39:21.854Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7379666063120109568 | Text |  |  | We are looking to hire 1 to 3 junior consultants. 


𝗤𝘂𝗮𝗹𝗶𝗳𝗶𝗰𝗮𝘁𝗶𝗼𝗻𝘀 (𝗔𝗽𝗽𝗹𝘆 𝗶𝗳 𝘆𝗼𝘂 𝗵𝗮𝘃𝗲 𝗮𝗻𝘆 𝟯 𝗼𝘂𝘁 𝗼𝗳 𝟰):

 • Experience with Databricks.
 • Experience with product development & design thinking.
 • Strong mathematical / physics background.
 • Experience with MLOps.

𝗩𝗮𝗹𝘂𝗲𝘀 𝗪𝗲 𝗟𝗼𝗼𝗸 𝗙𝗼𝗿:

 • You have read “Bullshit Jobs” and loved it.
 • You have read "NVC" by Marshall Rosenberg and loved it.

It's okay if you just looked those up and see the value behind the ideas. | 27 | 0 | 5 | 2mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.017Z |  | 2025-10-02T23:58:17.013Z |  | https://www.linkedin.com/jobs/view/3806487141/ | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7377501219222716417 | Article |  |  | DevConnect is coming to #Montreal! 

Ping me if you are attending, I know all the best restos / coffee shops here! | 7 | 0 | 0 | 2mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.018Z |  | 2025-09-27T00:35:58.007Z | https://luma.com/ktbi1sky |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7374906768788996097 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEDnngonPPfVg/feedshare-shrink_800/B56Zljun9QKIAg-/0/1758314791112?e=1766620800&v=beta&t=LYxAf7iWGGIFCcAyOURYmxoSZVgaUBsnbNOLjSE5lsI | To all my friends at Databricks,

At Tempered AI we have been delivering Databricks implementations over the last 2 years. It's been a wonderful journey, and we couldn't be happier with the platform. At Tempered AI, we have a fantastic team with a tech-first vision. What does that mean? It means that we put the technical folks first. We take their advice and consideration at every step of the implementation. There is always a seat at the table for technical considerations.

How has it worked out for us? We have a great Canadian on-shore team, that understands Databricks, and is delivering Gen AI usecases, as well as classic ML and Data Engineering at scale. We succeed almost every time, because technical consultants are allowed to surface their objections early and often. We focus on the tech, and Databricks delivers every time.

We are looking to partner with more Databricks AEs and SAs, and help deliver successful implementations. If you are looking for a great team with the right technical chops, reach out to me directly, and let's talk. | 42 | 1 | 2 | 2mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.019Z |  | 2025-09-19T20:46:32.821Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7373725964809334785 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE3ATYaOFEC0g/feedshare-shrink_800/B56ZlS8r6PI8Ag-/0/1758033265719?e=1766620800&v=beta&t=FVdR-eHHcLaF4tZ-MKFEq7mQ7fMQImG-BBoxGbFmgiI | 𝗗𝗲𝗰𝗹𝗶𝗻𝗲 𝘁𝗵𝗲 𝗿𝗲𝗾𝘂𝗲𝘀𝘁 𝘁𝗼 𝗷𝗼𝗶𝗻 𝗮𝘀 𝗮 𝗳𝗼𝘂𝗻𝗱𝗶𝗻𝗴 𝗖𝗧𝗢. 𝗛𝗲𝗿𝗲 𝗶𝘀 𝘄𝗵𝘆:


The imbalance is almost always baked in: the CTO brings skill capital, is directly responsible for hiring and architecture, solves the hard technical problems, often writes code when the team is small, and owns the execution risk when things break or timelines slip.

By contrast, the typical "business cofounder" is not personally doing sales and is not investing capital. Their plan is to approach a VC, who usually deploys other people’s money. Then they will hire some SDRs and a head of sales. This is simply not the same type of contribution and does not shoulder the same execution load.

Flip it around: would they accept a "CTO" whose only contribution is an introduction to a recruiting firm? Of course not. And yet, that is the mirror image of "I guarantee that I’ll raise from a VC". Why would you give cofounder status to someone whose only real contribution is an introduction to a VC firm?

So what should founding CTOs do? Bite the bullet and build it yourself, slowly, very slowly. It is an uphill because our economy is now more neo-feudal than capitalist. Connections do matter more than merit, but you can build connections, gradually. 

Learn the business well enough to hire for business development, in the same way many business partners "know enough tech" to hire a CTO. Only after you have that knowledge should you consider a business cofounder, and only if they bring present concrete value e.g. a proven ability to sell, a network to sell to, the ability to manage business operations on a day to day basis, etc. | 12 | 4 | 0 | 2mo | Post | Behzad Nikzad | https://www.linkedin.com/in/behzad-nikzad | https://linkedin.com/in/behzad-nikzad | 2025-12-08T04:40:25.021Z |  | 2025-09-16T14:34:27.214Z |  |  | 

---



---

# Behzad Nikzad
*Tempered AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 11 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Behzad Nikzad: Data Scientist on Bad Modeling and the Religion of Science - Discernable®](https://discernable.io/behzad-nikzad-data-scientist-on-bad-modeling-and-the-religion-of-science/)
*2022-05-07*
- Category: article

### [Behzad Nikzad – Medium](https://medium.com/@behzad_47244?source=read_next_recirc---------3---------------------b34e3d61_6817_4e99_be95_6353afcb3f25-------)
*2022-01-13*
- Category: blog

### [Ensuring Safe AI in the Automotive Industry - Behzad Benam - Medium](https://medium.com/@bhbenam/ensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9)
*2024-12-28*
- Category: blog

### [Data Fabric for Self-Driving Cars - Behzad Benam - Medium](https://medium.com/@bhbenam/data-fabric-for-self-driving-cars-d9bd16077ed4)
*2022-04-02*
- Category: blog

### [David Nikzad // Co-founder of Emotional Intelligence Ventures](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?i=1000518159512)
*2021-04-22*
- Category: podcast

---

## 📖 Full Content (Scraped)

*7 articles scraped, 5,899 words total*

### Behzad Nikzad: Data Scientist on Bad Modeling and the Religion of Science - Discernable®
*649 words* | Source: **EXA** | [Link](https://discernable.io/behzad-nikzad-data-scientist-on-bad-modeling-and-the-religion-of-science/)

Behzad Nikzad: Data Scientist on Bad Modeling and the Religion of Science - Discernable®

===============

[![Image 1: logo](https://discernable.io/wp-content/uploads/2022/02/Discernable-Logo-2022-90PXH.png)](https://discernable.io/)

*   [Home](https://discernable.io/ "Home")
*   [Interviews](https://discernable.io/interviews/ "Interviews")
*   [People’s Project](https://discernable.io/project/ "People’s Project")
*   [News](https://discernable.io/news/ "News")
*   [Town Halls](https://discernable.io/townhall/ "Town Halls")
*   [About](https://discernable.io/about/ "About")

The Discernable Interviews
--------------------------

Behzad Nikzad:Data Scientist on Bad Modeling and the Religion of Science
------------------------------------------------------------------------

1hr 13min
---------

8 May 2022

Behzad Nikzad is a data scientist with a keen interest in mathematics and data modeling. He lives in Quebec, Canada and has experienced the same historic lockdowns as in Melbourne Australia, but under the Trudeau government. He has noticed the models relied upon for lockdowns becoming ever more ridiculous and unjustifiable and sees a sad demise of the scientific method as a technocratic priesthood emerges.

He has written a book on this phenomenon where large swathes of the population are dazzled and/or suppressed by a ruling elite who claim insurmountable knowledge for the layperson. Just like priests before the printing press being the only ones allowed and capable of reading and interpreting holy texts.

In this conversation he walked me through a retrospective data analysis where I was forced to guess which cities and countries had the strongest restrictions based on their results. We also uncovered absolute irrationality on display by SAGE.

We ran out of time to discuss the parallels to his family’s experience under the Taliban in Afghanistan, so Behzad provided this written account:

”

My mom was a teacher in Afghanistan. When the Taliban took over our city in 1995 (the first time) they closed schools for all girls. She could no longer work. She was no longer allowed out of the house without a chaperon. Every woman was required to cover their face.

The Taliban justified this by saying that, through mandates such as face coverings, they would build a better society. Anyone who questioned their logic was told that they were being immoral. My mom experienced the citizen-policing that happened then with people telling each other to cover up their faces. If she felt hot under the face covering and pulled it up for a minute, someone would show up to warn her that it was important for her to wear her face covering.

My mom had to relive that trauma as she became policed by her peers for not wearing her face mask. She told me that she once decided to go a very short distance in an indoor space without a mask and that someone yelled at her for it. She said the experience felt eerily similar to her experiences in Afghanistan during the (first) Taliban era.

“

* * *

BEHZAD NIKZAD

[https://www.linkedin.com/in/behzad-nikzad](https://www.linkedin.com/in/behzad-nikzad)

[https://www.amazon.com.au/Gyaan-Yoga-Knowledge-Behzad-Nikzad/dp/B09T833WZ8](https://www.amazon.com.au/Gyaan-Yoga-Knowledge-Behzad-Nikzad/dp/B09T833WZ8)

[https://www.covidchartsquiz.com](https://www.covidchartsquiz.com/)

[https://twitter.com/FraserNelson/status/1472226949389037573](https://twitter.com/FraserNelson/status/1472226949389037573)

OUR TOP INTERVIEWS
------------------

[![Image 2](https://discernable.io/wp-content/uploads/2022/07/int101-uai-258x145.jpg)](https://discernable.io/emeritus-professor-thomas-s-harrington-the-worldwide-milgram-experiment/)

### [Emeritus Professor Thomas S. Harrington – The Worldwide Milgram Experiment](https://discernable.io/emeritus-professor-thomas-s-harrington-the-worldwide-milgram-experiment/)

11 July 2022

[![Image 3](https://discernable.io/wp-content/uploads/2022/06/int96-1-uai-258x145.jpg)](https://discernable.io/kirsten-finger-20-year-registered-nurse-and-paramedic-goes-from-hero-to-zero/)

### [Kirsten Finger: 20 Year Registered Nurse and Paramedic Goes from Hero to Zero](https://discernable.io/kirsten-finger-20-year-registered-nurse-and-paramedic-goes-from-hero-to-zero/)

25 June 2022

[![Image 4](https://discernable.io/wp-content/uploads/2022/06/int90-uai-258x145.jpg)](https://discernable.io/professor-robert-clancy-covid-19-narratives-vaccine-adverse-events-evidence-based-medicine-the-who-and-cartography/)

### [Professor Robert Clancy: Covid-19 Narratives, Vaccine Adverse Events, Evidence Based Medicine, the WHO, and Cartography](https://discernable.io/professor-robert-clancy-covid-19-narratives-vaccine-adverse-events-evidence-based-medicine-the-who-and-cartography/)

4 June 2022

[![Image 5](https://discernable.io/wp-content/uploads/2021/05/int88-uai-258x145.jpg)](https://discernable.io/professor-gigi-foster-explains-inflation-and-cost-of-living/)

### [Professor Gigi Foster Explains Inf

*[... truncated, 3,817 more characters]*

---

### Behzad Nikzad – Medium
*104 words* | Source: **EXA** | [Link](https://medium.com/@behzad_47244?source=read_next_recirc---------3---------------------b34e3d61_6817_4e99_be95_6353afcb3f25-------)

Behzad Nikzad – Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2F%40behzad_47244&%7Efeature=LoOpenInAppButton&%7Echannel=ShowUser&%7Estage=mobileNavBar&source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40behzad_47244&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=---two_column_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---two_column_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=---two_column_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40behzad_47244&source=user_profile_page---two_column_layout_nav-----------------------global_nav------------------)

![Image 1](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

![Image 2: Behzad Nikzad](https://miro.medium.com/v2/resize:fill:96:96/0*B00K_TiM6P0E3wjw)

Behzad Nikzad

[1 follower](https://medium.com/@behzad_47244/followers?source=user_profile_page----------------------54cb088ea7bf----------------------)

Follow

[Home](https://medium.com/@behzad_47244?source=user_profile_page----------------------54cb088ea7bf----------------------)

[About](https://medium.com/@behzad_47244/about?source=user_profile_page----------------------54cb088ea7bf----------------------)

[Mullah Nasruddin and Covid-19 ----------------------------- ### Mullah Nasruddin jokes are simple, witty stories that often have profound lessons hidden in them. They are commonly found within the…](https://medium.com/@behzad_47244/mullah-nasruddin-and-covid-19-82b58fb3644f?source=user_profile_page---------0-------------54cb088ea7bf----------------------)

Jan 13, 2022

[1](https://medium.com/@behzad_47244/mullah-nasruddin-and-covid-19-82b58fb3644f?source=user_profile_page---------0-------------54cb088ea7bf----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F82b58fb3644f&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40behzad_47244%2Fmullah-nasruddin-and-covid-19-82b58fb3644f&source=---------0-------------54cb088ea7bf----bookmark_preview------------------)

![Image 3: Mullah Nasruddin and Covid-19](https://miro.medium.com/v2/resize:fill:160:106/1*N8C33o-BKtAidhgt7RGYDA.jpeg)

![Image 4: Mullah Nasruddin and Covid-19](https://miro.medium.com/v2/resize:fill:320:214/1*N8C33o-BKtAidhgt7RGYDA.jpeg)

Jan 13, 2022

[1](https://medium.com/@behzad_47244/mullah-nasruddin-and-covid-19-82b58fb3644f?source=user_profile_page---------0-------------54cb088ea7bf----------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F82b58fb3644f&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40behzad_47244%2Fmullah-nasruddin-and-covid-19-82b58fb3644f&source=---------0-------------54cb088ea7bf----bookmark_preview------------------)

![Image 5: Behzad Nikzad](https://miro.medium.com/v2/da:true/resize:fill:176:176/0*B00K_TiM6P0E3wjw)

Behzad Nikzad
-------------

[1 follower](https://medium.com/@behzad_47244/followers?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

Follow

[Help](https://help.medium.com/hc/en-us?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Status](https://status.medium.com/?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[About](https://medium.com/about?autoplay=1&source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Careers](https://medium.com/jobs-at-medium/work-at-medium-959d1a85284e?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Press](mailto:pressinquiries@medium.com)

[Blog](https://blog.medium.com/?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Privacy](https://policy.medium.com/medium-privacy-policy-f03bf92035c9?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Rules](https://policy.medium.com/medium-rules-30e5502c4eb4?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Terms](https://policy.medium.com/medium-terms-of-service-9db0094a1e0f?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

[Text to speech](https://speechify.com/medium?source=user_profile_page---user_sidebar-------------------54cb088ea7bf----------------------)

---

### Ensuring Safe AI in the Automotive Industry
*840 words* | Source: **EXA** | [Link](https://medium.com/@bhbenam/ensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9)

Ensuring Safe AI in the Automotive Industry | by Behzad Benam | Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F2ddb18ec03d9&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

Member-only story

Ensuring Safe AI in the Automotive Industry
===========================================

[![Image 4: Behzad Benam](https://miro.medium.com/v2/resize:fill:64:64/1*aRhl6P_Yigj--vo9NoeK1Q@2x.jpeg)](https://medium.com/@bhbenam?source=post_page---byline--2ddb18ec03d9---------------------------------------)

[Behzad Benam](https://medium.com/@bhbenam?source=post_page---byline--2ddb18ec03d9---------------------------------------)

Follow

4 min read

·

Dec 28, 2024

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F2ddb18ec03d9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9&user=Behzad+Benam&userId=8ea7c33a8c7d&source=---header_actions--2ddb18ec03d9---------------------clap_footer------------------)

51

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F2ddb18ec03d9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9&source=---header_actions--2ddb18ec03d9---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3D2ddb18ec03d9&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9&source=---header_actions--2ddb18ec03d9---------------------post_audio_button------------------)

Share

Activities and Verification Techniques

Press enter or click to view image in full size

![Image 5](https://miro.medium.com/v2/resize:fit:700/1*6DYlXGCm7KQVePU9Pf-44g.jpeg)

The automotive industry is experiencing a profound transformation due to the integration of artificial intelligence (AI), enabling advances in autonomous driving, Advanced Driver Assistance Systems (ADAS), and predictive maintenance. However, as AI systems play an increasingly important role in vehicles, ensuring their safety has become a paramount concern.

Safe AI in the automotive industry is both a technical challenge and an ethical and regulatory necessity. It involves managing risks such as system failures, adversarial attacks, and unintended consequences that can lead to accidents or loss of life. This article outlines the essential activities for developing safe AI systems for automotive applications. It explores the techniques for verifying their safety to ensure their trustworthiness and compliance with industry standards.

Activities Required for the Development of Safe AI
--------------------------------------------------

The most essential activities to ensure AI development are listed below.

### Requirement Specification

*   Definition of safety-critical functions and ODD (Operational Design Domains)
*   Identification of potential risks and failure modes specific to automotive…

Create an account to read the full story.
-----------------------------------------

The author made this story available to Medium members only.

If you’re new to Medium, create a new account to read this story on us.

[Continue in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F2ddb18ec03d9&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=regwall&source=-----2ddb18ec03d9---------------------post_regwall------------------)

Or, continue in mobile web

[Sign up with Google](https://medium.com/m/connect/google?state=google-%7Chttps%3A%2F%2Fmedium.com%2F%40bhbenam%2Fensuring-safe-ai-in-the-automotive-industry-2ddb18ec03d9

*[... truncated, 21,532 more characters]*

---

### Data Fabric for Self-Driving Cars
*863 words* | Source: **EXA** | [Link](https://medium.com/@bhbenam/data-fabric-for-self-driving-cars-d9bd16077ed4)

Data Fabric for Self-Driving Cars | by Behzad Benam | Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2Fd9bd16077ed4&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fdata-fabric-for-self-driving-cars-d9bd16077ed4&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fdata-fabric-for-self-driving-cars-d9bd16077ed4&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

Member-only story

Data Fabric for Self-Driving Cars
=================================

How important is data for AI applications in the automotive industry
--------------------------------------------------------------------

[![Image 4: Behzad Benam](https://miro.medium.com/v2/resize:fill:64:64/1*aRhl6P_Yigj--vo9NoeK1Q@2x.jpeg)](https://medium.com/@bhbenam?source=post_page---byline--d9bd16077ed4---------------------------------------)

[Behzad Benam](https://medium.com/@bhbenam?source=post_page---byline--d9bd16077ed4---------------------------------------)

Follow

4 min read

·

Apr 2, 2022

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2Fd9bd16077ed4&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fdata-fabric-for-self-driving-cars-d9bd16077ed4&user=Behzad+Benam&userId=8ea7c33a8c7d&source=---header_actions--d9bd16077ed4---------------------clap_footer------------------)

4

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fd9bd16077ed4&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fdata-fabric-for-self-driving-cars-d9bd16077ed4&source=---header_actions--d9bd16077ed4---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3Dd9bd16077ed4&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40bhbenam%2Fdata-fabric-for-self-driving-cars-d9bd16077ed4&source=---header_actions--d9bd16077ed4---------------------post_audio_button------------------)

Share

Press enter or click to view image in full size

![Image 5](https://miro.medium.com/v2/resize:fit:700/1*gTKpW04SfIdZp-I_rmGzag.jpeg)

Photo by [NASA](https://unsplash.com/@nasa?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/s/photos/data-center?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)

The amount of data is growing exponentially, and with each passing day, data management becomes more significant to making the right decisions in the AI application. **Data is the future engine of the vehicle.** Expert heads deal with questions about the efficient storage and use of data or the required access rate and how they can be made climate-friendly for large amounts of data.

Embedded or edge devices have limited memory, communication rate, energy, and processing power resources. Still, they must be able to access all collected data that help to make an accurate decision. **Data Fabric is a data architecture that optimizes access to distributed data.**

Different applications require data management in different usage levels, mobile edge devices, IoT devices, sensors, and the cloud. There are functional and non-functional requirements for data storage. This article discusses a couple of essential needs and partially available solutions in the automotive industry, focusing on autonomous driving applications.

Data Availability and performance guarantee
-------------------------------------------

The data should be available at a certain speed for different applications that use the data…

Create an account to read the full story.
-----------------------------------------

The author made this story available to Medium members only.

If you’re new to Medium, create a new account to read this story on us.

[Continue in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2Fd9bd16077ed4&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=regwall&source=-----d9bd16077ed

*[... truncated, 21,700 more characters]*

---

### David Nikzad // Co-founder of Emotional Intelligence Ventures
*1,679 words* | Source: **EXA** | [Link](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?i=1000518159512)

David Nikzad // Co-founder of … - Investing in Impact | Impact Investing - Apple Podcasts

===============

[](https://podcasts.apple.com/us/new)

*   [Home](https://podcasts.apple.com/us/home)
*   [New](https://podcasts.apple.com/us/new)
*   [Top Charts](https://podcasts.apple.com/us/charts)
*   [Search](https://podcasts.apple.com/us/search)

Open in Podcasts

PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

![Image 1: Investing in Impact | Impact Investing](https://podcasts.apple.com/assets/artwork/1x1.gif)

*   04/22/2021
*   EPISODE 21
*   32 MIN

David Nikzad // Co-founder of Emotional Intelligence Ventures
=============================================================

[Investing in Impact | Impact Investing](https://podcasts.apple.com/us/podcast/investing-in-impact-impact-investing/id1515387588)

 Play 

_This content is for informational and entertainment purposes only, you should not construe any such information or other material as legal, tax, investment, financial, or other advice._

----------------------------------------

If you enjoyed this episode, don't forget to subscribe, review, and share this podcast!

In episode 21 of the Investing in Impact podcast, I speak with David Nikzad, founder of Emotional Intelligence Ventures, on his angel investor journey and the future of the psychedelic industry.

Over the past 2.5 decades he has invested in real estate, nightlife, technology and wellness. He left the mainland over a decade ago to work on a retreat center in Maui called Lumeria, working there on his own emotional intelligence (Ei) while continuing to invest in and guide startups.

Through his family venture fund Reinmkr Satsang and his holding company Orthogonal Thinker Inc., David put the first checks into companies such as Betterment🦄, Vidyard🦄, InstantCab Ridecell🦄, Wefunder, June Software TaptoLearn, Talkable, Aisle50, TutorSpree, OrangeFund2, Quartzy, Ridejoy, GazeHawk, RealCrowd, InvoiceASAP, Meadow, Mellows, ConfidentCannabis, FOBO Yardsale, BlockRx, SericaPay, Solti, AdStage, Arcview Capital and more.

He has personally incubated companies through Orthogonal Thinker like SuryaSpa, KitchenNation, MauiRaw, Randy’s Remedy, EI.Ventures, and Pure Mushrooms.

Orthogonal holds secondary shares in anchor companies such as Airbnb, Republic, and Equipment Share.

Over this last decade, David has become hyper-focused on his two children who live on Hawaii, and on his current role as Executive Chairman of Orthogonal Thinker Inc, which encompasses all of David’s family’s holdings.

His latest journey, Emotional Intelligence Ventures, is focused on creating the new standard of mental wellness through developing novel psychedelic therapeutics, medicinal mushroom formulations, and unique treatment protocols and delivery mechanisms.

Listen to more Causeartist podcasts here.

**We are powered by:**ImpactInvestor - Discover Impact Investors from around the world.****Podcast Made with Transistor

Podcast cover design Made with Canva

Build amazing web platforms with Webflow

----------------------------------------

Investing in Impact is powered by **Causeartist**, a nonprofit media company dedicated _to_ bridging the gap between **_capital_** and **_culture_** by spotlighting founders, investors, and organizations reimagining how business can serve people and the planet.

Through storytelling, events, and open-access education, Causeartist helps create a shared language of impact, inspiring more founders to build with purpose and more funders to invest with intention.

By amplifying ideas and innovations across industries, Causeartist transforms awareness into action and cultivates a community where paying it forward is part of the foundation for growth.

[Episode Webpage](https://share.transistor.fm/s/6fbde819)

Information
-----------

*   Show [Investing in Impact | Impact Investing](https://podcasts.apple.com/us/podcast/investing-in-impact-impact-investing/id1515387588) 
*   Channel [Causeartist](https://podcasts.apple.com/us/channel/causeartist/id6442505068) 
*   Frequency Updated Weekly 
*   Published April 22, 2021 at 6:23 AM UTC 
*   Length 32 min 
*   Episode 21 
*   Rating Clean 

United States
*   [Español (México)](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?l=es-MX)
*   [العربية](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?l=ar)
*   [Русский](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?l=ru)
*   [简体中文](https://podcasts.apple.com/us/podcast/david-nikzad-co-founder-of-emotional-intelligence/id1515387588?l=zh-Hans-CN)
*   [Français (France)](https://podcasts.apple.com/us/podcast/da

*[... truncated, 21,937 more characters]*

---

### Behzad Nikzad – Tempered
*161 words* | Source: **GOOGLE** | [Link](https://tempered.ai/author/behzad/)

Behzad Nikzad – Tempered

===============

[Scroll Top](https://tempered.ai/author/behzad/#page)

[![Image 1: Tempered](https://tempered.ai/wp-content/uploads/thegem/logos/logo_3483552d1e09ff447ca0acad35caf013_1x.png)![Image 2: Tempered](https://tempered.ai/wp-content/uploads/thegem/logos/logo_794786b9d9f6034822fad7f92f758668_1x.png)](https://tempered.ai/)

Primary Menu
*   [SOLUTIONS](https://tempered.ai/solutions/)
*   [FORGE](https://tempered.ai/forge/)
*   [BLOG](https://tempered.ai/blog/)
*   [CAREERS](https://tempered.ai/careers/)
*   [HIRE US](https://tempered.ai/hire-us/)
*   [](https://tempered.ai/author/behzad/#) 

Behzad Nikzad
=============

[Home](https://tempered.ai/)Posts by Behzad Nikzad

[![Image 3: germans-celebrate-the-fall-of-berlin-wall-q4tsbzpx7gk2s4ex](https://tempered.ai/wp-content/uploads/2025/03/germans-celebrate-the-fall-of-berlin-wall-q4tsbzpx7gk2s4ex-thegem-blog-default-large.jpg)](https://tempered.ai/databricks-snowflake-and-the-berlin-wall/)

[0](https://tempered.ai/author/behzad/# "Like this")

By Behzad Nikzad[Databricks](https://tempered.ai/category/databricks/ "View all posts in Databricks")

### [Databricks, Snowflake and The Berlin Wall](https://tempered.ai/databricks-snowflake-and-the-berlin-wall/)

Introduction In 1961, the Berlin Wall was constructed to prevent people from leaving East Berlin. It blocked movement, split families,…

[](https://tempered.ai/author/behzad/#)

[](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F "Facebook")[](https://twitter.com/intent/tweet?text=Databricks%2C+Snowflake+and+The+Berlin+Wall&url=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F "Twitter")[](https://pinterest.com/pin/create/button/?url=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F&description=Databricks%2C+Snowflake+and+The+Berlin+Wall&media=https%3A%2F%2Ftempered.ai%2Fwp-content%2Fuploads%2F2025%2F03%2Fgermans-celebrate-the-fall-of-berlin-wall-q4tsbzpx7gk2s4ex-thegem-blog-timeline-large.jpg "Pinterest")[](https://www.tumblr.com/widgets/share/tool?canonicalUrl=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F "Tumblr")[](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F&title=Databricks%2C+Snowflake+and+The+Berlin+Wall&summary=Introduction+In+1961%2C+the+Berlin+Wall+was+constructed+to+prevent+people+from+leaving+East+Berlin.+It+blocked+movement%2C+split+families%2C... "LinkedIn")[](https://www.reddit.com/submit?url=https%3A%2F%2Ftempered.ai%2Fdatabricks-snowflake-and-the-berlin-wall%2F&title=Databricks%2C+Snowflake+and+The+Berlin+Wall "Reddit")

[Read More](https://tempered.ai/databricks-snowflake-and-the-berlin-wall/)

[![Image 4: pexels-andrea-piacquadio-756484](https://tempered.ai/wp-content/uploads/2023/12/pexels-andrea-piacquadio-756484-1-thegem-blog-default-large.jpg)](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/)

[2](https://tempered.ai/author/behzad/# "Like this")

By Behzad Nikzad[Databricks](https://tempered.ai/category/databricks/ "View all posts in Databricks")

### [Skepticism to Conviction: A Data Scientist’s Journey with Databricks](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/)

Introduction As a data scientist, I’ll admit I had my doubts about whether notebooks could ever find their place in…

[](https://tempered.ai/author/behzad/#)

[](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-databricks%2F "Facebook")[](https://twitter.com/intent/tweet?text=Skepticism+to+Conviction%3A+A+Data+Scientist%26%238217%3Bs+Journey+with+Databricks&url=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-databricks%2F "Twitter")[](https://pinterest.com/pin/create/button/?url=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-databricks%2F&description=Skepticism+to+Conviction%3A+A+Data+Scientist%26%238217%3Bs+Journey+with+Databricks&media=https%3A%2F%2Ftempered.ai%2Fwp-content%2Fuploads%2F2023%2F12%2Fpexels-andrea-piacquadio-756484-1-thegem-blog-timeline-large.jpg "Pinterest")[](https://www.tumblr.com/widgets/share/tool?canonicalUrl=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-databricks%2F "Tumblr")[](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-databricks%2F&title=Skepticism+to+Conviction%3A+A+Data+Scientist%26%238217%3Bs+Journey+with+Databricks&summary=Introduction+As+a+data+scientist%2C+I%26%238217%3Bll+admit+I+had+my+doubts+about+whether+notebooks+could+ever+find+their+place+in... "LinkedIn")[](https://www.reddit.com/submit?url=https%3A%2F%2Ftempered.ai%2Fskepticism-to-conviction-a-data-scientists-journey-with-da

*[... truncated, 849 more characters]*

---

### Skepticism to Conviction: A Data Scientist's Journey with Databricks
*1,603 words* | Source: **GOOGLE** | [Link](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/)

Skepticism to Conviction: A Data Scientist’s Journey with Databricks – Tempered

===============

[Scroll Top](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/#page)

[![Image 1: Tempered](https://tempered.ai/wp-content/uploads/thegem/logos/logo_3483552d1e09ff447ca0acad35caf013_1x.png)![Image 2: Tempered](https://tempered.ai/wp-content/uploads/thegem/logos/logo_794786b9d9f6034822fad7f92f758668_1x.png)](https://tempered.ai/)

Primary Menu
*   [SOLUTIONS](https://tempered.ai/solutions/)
*   [FORGE](https://tempered.ai/forge/)
*   [BLOG](https://tempered.ai/blog/)
*   [CAREERS](https://tempered.ai/careers/)
*   [HIRE US](https://tempered.ai/hire-us/)
*   [](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/#) 

Skepticism to Conviction: A Data Scientist’s Journey with Databricks
====================================================================

[Home](https://tempered.ai/)[Databricks](https://tempered.ai/category/databricks/)Skepticism to Conviction: A Data Scientist’s Journey with Databricks

![Image 3: pexels-andrea-piacquadio-756484](https://tempered.ai/wp-content/uploads/2023/12/pexels-andrea-piacquadio-756484-1-thegem-blog-default.jpg)

[2](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/# "Like this")

By Behzad Nikzad December 19, 2023

**Introduction**
================

As a data scientist, I’ll admit I had my doubts about whether notebooks could ever find their place in a professional coding environment. My skepticism stemmed from the disconnect I felt between the data science world and the realm of established best practices in software development. The question loomed: Could notebooks, known for their interactive and exploratory nature, truly be harnessed for professional coding? My journey with Databricks eventually led me to a different perspective, but it began with valid concerns (in fact, insecurities) and skepticism that many data scientists share.

### **The Skepticism**

At the heart of my skepticism was the prevailing wisdom about professional coding. Best practices were etched in stone, [or so it seemed](https://nvie.com/posts/a-successful-git-branching-model/). Version control, continuous integration, disciplined coding practices, and the use of Integrated Development Environments (IDEs) were not just norms but sacred principles. It felt like heresy to believe that all that could be done with notebooks.

Notebooks have their place in the data scientist’s toolkit, no doubt. They are perfect for exploration, experimentation, and sharing insights with teammates. However, when it comes to the meticulous and regimented world of professional coding, notebooks appear to fall short. Namely:

1.       1.   **Version Control:** How can we possibly maintain version control when using notebooks? Unlike traditional code files that neatly track changes, notebooks were like living documents, constantly evolving with each execution. The fear of losing track of code changes is haunting.

1.       1.   **Continuous Integration:** Continuous integration and continuous delivery (CI/CD) pipelines are the bedrock of professional software development. How could notebooks fit into this highly structured workflow? Their dynamic and ad-hoc nature seems incompatible with the rigorous CI/CD processes we rely upon.

1.       1.   **Disciplined Coding:** Best practices demand disciplined coding habits, adherence to coding standards, and rigorous code reviews. Notebooks, often perceived as a mix of code snippets and explanatory text, seem to defy this discipline.

### **Databricks**

Amidst this skepticism about Notebooks, Databricks emerged as a transformative technology in the world of data science. Databricks offers an ecosystem where data science can thrive while meeting the standards of practice upheld in the world of professional coding.

At the heart of Databricks’ mission is the commitment to simplify and unify data analytics and machine learning. Databricks envisions a world where data-driven insights are within the reach of every organization, regardless of size or industry. They strive to empower organizations to unlock the full potential of data through a collaborative and integrated platform. Databricks seeks to democratize data and accelerate innovation by providing tools and solutions that bridge the gap between data science and engineering, enabling organizations to harness the power of data for improved decision-making and transformative discoveries.

### **Databricks Repos**

[Databricks Repos](https://docs.databricks.com/en/repos/index.html)totally transformed the way I interact with notebooks, and ultimately my opinion about notebooks.Databricks Repos offers a seamless way to automatically connect and push notebook work to external repositories using Databricks CLI and GitHub actions, making version control possible.

Databricks Repos was a game-changer for my work because it allows 

*[... truncated, 9,492 more characters]*

---

---

## 🎬 YouTube Videos

- **[Behzad Nikzad at the Data+AI Summit 2025 #Databricks](https://www.youtube.com/watch?v=CLdLVmy7nYo)**
  - Channel: NextGenLakehouse
  - Date: 2025-08-03

- **[He Left Academia to Build a Databricks Consulting Firm | E4](https://www.youtube.com/watch?v=Xbr8BeD2g54)**
  - Channel: Antoine Nehme 
  - Date: 2025-03-24

- **[Behzad Musik ft  Sahil Khan - Dhadak Title Track Cover](https://www.youtube.com/watch?v=UYnYD4TvT9c)**
  - Channel: NiKZAD PRODUCTiONS
  - Date: 2018-11-08

- **[Hit Lahza ba Lahza ‌Tamim Ansari &amp; Omid Nikzad | هیت لحظه به لحظه تمیم انصاری و امید نیکزاد](https://www.youtube.com/watch?v=AjOszM6QP7A)**
  - Channel: TOLO TV
  - Date: 2023-07-08

- **[Hit Lahza ba Lahza Edris Nikzad &amp; Mustafa Nikzad | هیت لحظه به لحظه با ادریس نیکزاد و مصطفی نیکزاد](https://www.youtube.com/watch?v=oOnsvt2HsQw)**
  - Channel: TOLO TV
  - Date: 2023-01-03

- **[The Voice of Afghanistan S.2 - Registration - TOLO TV /  آواز افغانستان - پروسه ثبت نام - طلوع](https://www.youtube.com/watch?v=WKrWNoUKOJ8)**
  - Channel: The Voice Of Afghanistan
  - Date: 2014-04-16

- **[فهیم رحیمی - من مست بهار حسنت - کنسرت دیره / Fahim Rahimi - Man Mast Bahare Hosnat - Dera Concert](https://www.youtube.com/watch?v=uOnXHlI5F9I)**
  - Channel: TOLO TV
  - Date: 2017-11-07

- **[۵ دسامبر ۲۰۲۵](https://www.youtube.com/watch?v=6CkUTaHc9qA)**
  - Channel: Behzad Nikzad
  - Date: 2025-12-05

- **[🥰🥰🥰🥰](https://www.youtube.com/watch?v=ZFN6YJXRacA)**
  - Channel: Behzad Nikzad
  - Date: 2025-10-16

- **[۱۹ اکتبر ۲۰۲۵](https://www.youtube.com/watch?v=nuLcmmKThuQ)**
  - Channel: Behzad Nikzad
  - Date: 2025-10-19

---

## 🔎 Press & Mentions

- **[Behzad Nikzad – Tempered](https://tempered.ai/author/behzad/)**
  - Source: tempered.ai
  - *Behzad Nikzad. Home Posts by Behzad Nikzad. germans-celebrate-the-fall-of-berlin-wall-q4tsbzpx7gk2s4ex. 0. By Behzad Nikzad Databricks ... 2023 © temp...*

- **[Skepticism to Conviction: A Data Scientist's Journey with Databricks ...](https://tempered.ai/skepticism-to-conviction-a-data-scientists-journey-with-databricks/)**
  - Source: tempered.ai
  - *Mar 24, 2025 ... Behzad Nikzad / About Author. More posts by Behzad Nikzad. Related Posts. Databricks, Snowflake and The Berlin ... email: SALES@tempe...*

---

*Generated by Founder Scraper*
