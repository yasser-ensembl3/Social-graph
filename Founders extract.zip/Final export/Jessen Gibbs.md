# Jessen Gibbs

## Position actuelle

**Titre** : Co-founder, CEO
**Entreprise** : Shadow Research
**Durée dans le rôle** : 1 year 9 months in role
**Durée dans l'entreprise** : 1 year 9 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Software Development

## Description du rôle

Turning Agencies into Agents

## Résumé

Building things that tell stories

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACIMF_wBxi-np6aFRXU10ZWTNffU28leaew/
**Connexions partagées** : 30


---

# Jessen Gibbs

## Position actuelle

**Entreprise** : Shadow Inc

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jessen Gibbs

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400254241610743808 | Text |  |  | Over the last few months Shadow Inc has been working with world’s best in PR to pull together campaigns for companies like Lovable, Roblox, and 1X. 

Three things I’ve learned:

1. PR is about manufacturing context: The best campaigns don't push a story - they create conditions where their story becomes the obvious one to tell.
2. Distribution beats content: You can have the best story in the world, but if you're pushing it to the wrong places, you'll go nowhere. Spend 20% of your time on content, 80% on finding the people and channels that get it in front of the right audience.
3. You're now marketing to LLMs, not just people: AI is reshaping how content gets discovered - through search, social feeds, and chat apps. The teams thinking about LLM-readability will dominate. GEO is worth getting up to speed on.

The PR playbook is being rewritten and most of the industry hasn’t caught on yet. | 18 | 2 | 0 | 1w | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:33.601Z |  | 2025-11-28T19:28:21.275Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379620712606654464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0IA9hz7PyhQ/feedshare-shrink_800/B4EZmmhLpDGUAg-/0/1759435341191?e=1766620800&v=beta&t=2LGsj8pFJz73NPPjZEM3wNhF4dKmmAgVlIZV2oiz6iw | Such a pleasure presenting at the Front Row Ventures AGM yesterday.

Canada's tech future starts with backing young, ambitious talent willing to put it all on the line, and FRV is leading the charge. 

It's time for Canada to step up and unlock it's next generation of builders. LFG y'all.  🇨🇦 | 17 | 1 | 0 | 2mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:33.601Z |  | 2025-10-02T20:58:04.608Z | https://www.linkedin.com/feed/update/urn:li:activity:7379606709092372480/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7361081883788496896 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHGPUcxXe3EUA/feedshare-shrink_800/B56ZifQ9pBG4Ag-/0/1755018682190?e=1766620800&v=beta&t=OXNOwBiaQ817-Ht-xXeblzcdgjxjk6t2lgWAzcHxRfQ | We're bringing to together Montreal's boldest for round #2 of Embedded Montreal! Here's what you need to know:

After our first Embedded Montreal event (Building Your AI Enterprise) completely blew us away with a packed room of Montreal's boldest builders, we're doubling down on what worked: no agenda, no corporate BS, just pure builder energy.

​This month we're leaning fully into the no-structure approach. Open conversations, spontaneous demos, and the kind of authentic connections that happen when you put Montreal's most ambitious founders, operators, and AI builders in the same space.

Optional battle ground: Shadow Inc is hiring a Founding Engineer! Bring your best and come battle for the role in our optional battle ground. We'll prompt the group, give you 5 minutes to plan + 30 minutes to build, and the top 3 builders get interviewed for the role! Let's see what you can do 🫡 

​Whether you're building your first startup or your fifth, if you're thinking about AI as a foundation, this is your crowd.

Hosted by Shadow Inc and Drive Capital

Registration link below ⬇️

cc: Nazuk Thakkar Landon W. Campbell Nils Root Dalyan Parker | 18 | 1 | 2 | 3mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:33.602Z |  | 2025-08-12T17:11:23.383Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7359271321601523733 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG5nA3gEvayrw/feedshare-shrink_800/B56ZiFiRVYHMAs-/0/1754587010782?e=1766620800&v=beta&t=Cs0tR_oaBK3eyo9EjTu8VAuwGpJ47BrjMI7BAZ0iCvk | Hiring a seasoned Engineer to accelerate our velocity towards $1M ARR at Shadow Inc. Checkout the image for more info!

Your code ships to clients, not committees.

Do whatever drives client impact. Features, infra, AI—if it moves the needle, you own it. 

You scratch for ownership instead of offloading. Good hires for this role will be allergic to unnecessary hiring. 

DM me if this is you. I'd love to talk. 😊 

Referral bonus if you connect me to the right person - Comment or DM for details! | 19 | 0 | 1 | 4mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:33.602Z |  | 2025-08-07T17:16:51.719Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7358913987838685184 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFDGWJTpg3FAQ/feedshare-shrink_800/B56ZiAdRSFHMAg-/0/1754501815467?e=1766620800&v=beta&t=5q3BekKkm41rwQ-KbiFB7eoamRfLl9PPBl6u7Ao9BfA | Y Combinator put out their call for startups yesterday. Shadow Inc is building for 3 of the 6.

Call #3: The First 10-person, $100B Company - Can each person in the org bear $10B of responsibility?

Call #4: Infrastructure for Multi-agent Systems - Our org-wide KPI is # of engineering hours spent building and maintaining client solutions/wk. This should converge to zero. Best in class observability and debugging is critical for efficiency and scalability.

Call #5: AI Native Enterprise Software - Shadow isn't a tool, it's an always on, 24/7 team member. Clients should simply have less work to do.

Good to see looking at the right problems. And we're excited to lead the surge of builders coming into this space 😉 | 23 | 0 | 0 | 4mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:33.603Z |  | 2025-08-06T17:36:56.711Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7342613495667924992 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG788jyN3XZOg/feedshare-shrink_800/B56ZeYv.LWHQAg-/0/1750614402467?e=1766620800&v=beta&t=5f7qbY7q_QaPcMvHLitqkr-Nt1m6QXtVLNlzBNvoFhg | Come hang with us! | 4 | 0 | 0 | 5mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.838Z |  | 2025-06-22T18:04:36.529Z | https://www.linkedin.com/feed/update/urn:li:activity:7342608997797064705/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7340871526545559552 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHlqiVc7f4G9g/feedshare-shrink_800/B56Zd_KAYwHEAg-/0/1750185019477?e=1766620800&v=beta&t=VXolgOImlF14zen6bt-RQDwtqpT812PbPvEAJqmZ2dU | This is step change. If you're building with AI - and you should be - Kylan Gibbs & the Inworld AI team are cooking up the next level of developer experiences. They've saved me & Shadow Inc hundreds of sleepless hours. Building is fun, but scaling and evolving is truly a beast. | 12 | 0 | 0 | 5mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.838Z |  | 2025-06-17T22:42:38.726Z | https://www.linkedin.com/feed/update/urn:li:activity:7340808036141191170/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7282814908809785344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5d5cc1d0-26c4-4272-b2c2-5c1f1964b2fd | https://media.licdn.com/dms/image/v2/D5605AQGWuC-6NRxUlw/videocover-high/B56ZRHBhAkG8Bw-/0/1736358370856?e=1765782000&v=beta&t=pyxjwsuljAN9trc8szvUEQSrkesJCyOPyKiXpTQ2Suo | "Agents" are already becoming a central theme in 2025. To illustrate how Shadow Inc. is thinking about an agent-based future, we built an experimental feature in our Studio called AI Discussion Room. This allows users to invite specialized AI Agents into a self-guided discussion, where they can leverage Shadow’s tools to analyze complex data and compose meaningful insights.

In this demo, we gave three Agents a broad discussion topic, and had Shadow’s Studio analysis tool observe their conversation and respond to their questions in real time.

This showcases how we can—and should—position both humans and Agents as first-class users of our applications and tools.

Moments like this are where we start to see the through line to a future in which AI does the work while humans orchestrate it.

Want access? Reach out! 👋 | 24 | 0 | 0 | 10mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.839Z |  | 2025-01-08T17:46:22.418Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7282514528230166529 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGQIJsRBBsXgA/feedshare-shrink_800/B4DZQ8PPizGUAg-/0/1736177417174?e=1766620800&v=beta&t=wzFbqQGNmHtiCOcOJ97IWESaHjwzaBLIe9an2t5lioY | Tal's 2025 Canadian Fintech predictions align with what we’re seeing at Shadow Inc. We’ve been talking with the “Big Three” (KPMG, EY, Deloitte), where each is actively integrating AI-driven automation into their processes, and we’re bringing the same AI firepower to the rest of the market. Through 2025, we’ll be improving our real-time AI learning mechanism and agent-native platform alongside seasoned experts. We're already leading the charge with SR&ED and grant writing services and we have loan origination on the horizon.

Although we offer embedded AI, we’re not an agent platform—Shadow is a learning mechanism, knowledge manager, and tool suite that empowers AI to observe and mimic expert methodologies. Our “BYO agents” approach supports dynamic, multi-party workflows (human-human, human-agent, and agent-agent), making it effortless for experts to upskill agents and for agents to scale experts. Right now, we’re perfecting our learning mechanism in a closed environment, but soon we’ll make it portable so you can integrate Shadow with any tool suite and train AI on cross-platform workflows with lossless knowledge transfer.

Our 2025 goal? 10x our partners’ annual client volume while cutting operations costs in half.

If you’re interested in learning how you can meaningfully integrate AI automation into your services, reach out—I’m happy to help however I can. | 12 | 1 | 1 | 11mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.840Z |  | 2025-01-07T21:52:46.107Z | https://www.linkedin.com/feed/update/urn:li:activity:7282055890722050050/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7275676227842056192 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHVsrkORzFN6A/feedshare-shrink_800/B56ZPhk.W4G4Ag-/0/1734656387200?e=1766620800&v=beta&t=XgNfSD68uE5XNxSdSUkBAOW1EZuvyHPLmMqmhcFOlv8 | Did you know that shadows are darkest where they meet the light? It's called the "umbrella effect" or sometimes "contact shadow"

I'm excited to get this little dude out of the shop. He's been around for a while - playing in the shadows. | 18 | 0 | 0 | 11mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.840Z |  | 2024-12-20T00:59:48.245Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7272723773173174272 | Text |  |  | Richie Cartwright is a good friend and killer operator. Reach out to him if you're an S-tier Marketing, Customer, or Product mind. | 3 | 1 | 0 | 11mo | Post | Jessen Gibbs | https://www.linkedin.com/in/jessen-gibbs | https://linkedin.com/in/jessen-gibbs | 2025-12-08T06:00:36.841Z |  | 2024-12-11T21:27:48.198Z | https://www.linkedin.com/feed/update/urn:li:activity:7272343918191472640/ |  | 

---



---

# Jessen Gibbs
*Shadow Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [About – Jessen Gibbs – Medium](https://medium.com/@jessengibbs/about)
*2025-05-14*
- Category: blog

### [- YouTube](https://www.youtube.com/watch?v=hqrqBNHrCWI)
*2025-05-14*
- Category: video

### [It's enough, Jessen Gibbs - Qobuz](https://www.qobuz.com/us-en/album/its-enough-jessen-gibbs/mlhrtsqhokhqa)
*2025-07-01*
- Category: article

### [Jessen Gibbs - At Least lyrics | Musixmatch](https://www.musixmatch.com/lyrics/Jessen-Gibbs/At-Least)
*2025-01-09*
- Category: article

### [Ashley Jessen CEO & Co-Founder](https://profilebooster.com.au/author/ashley-jessen/)
*2024-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Companies - Front Row Ventures | Canada's first student-run ...](https://frontrow.ventures/companies/)**
  - Source: frontrow.ventures
  - *Founded by Jessen Gibbs, Nico Bent. McGill, Polytechnique. shadow.inc · Sibli ... Blog · Contact Us. © Copyright 2017-2025 Front Row Ventures. All Rig...*

---

*Generated by Founder Scraper*
