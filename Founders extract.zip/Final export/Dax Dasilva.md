# Dax Dasilva

## Position actuelle

**Titre** : Chief Executive Officer
**Entreprise** : Lightspeed Commerce
**Durée dans le rôle** : 1 year 10 months in role
**Durée dans l'entreprise** : 20 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Dax Dasilva is the CEO and founder of Lightspeed Commerce. Founded in 2005, Lightspeed is the unified POS and payments platform for ambitious entrepreneurs to accelerate growth, provide the best customer experience and become a go-to destination in their space. With thousands of employees worldwide, Lightspeed powers hundreds of thousands of customer locations around the globe.

Dax is also the founder of Age of Union, which debuted as a book he authored in 2019. Since then, the concept has evolved into an environmental alliance which brings together leadership, culture, spirituality, and environmental guardianship to support and inspire impactful changemakers. Since its launch, Age of Union has invested $40 million CAD in ten impactful projects across five countries, focusing on protecting endangered species and restoring critical ecosystems.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABaX0QBxaOP21DOXScKyFrBbzGCO-ytfnE/
**Connexions partagées** : 245


---

# Dax Dasilva

## Position actuelle

**Entreprise** : Lightspeed Commerce

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Dax Dasilva

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402004927700566016 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHB5fEkKjp5Xw/feedshare-shrink_1280/B4DZrk0QLtGkAs-/0/1764775495269?e=1766620800&v=beta&t=KBgtGhj-WiXhSetTX3YPmSrJ-SUP_gbFzsu6ZIrH0b0 | Something that’s really become clear to me lately: I love being in the office.
 
Whenever I spend time at our headquarters or one of our other offices, I’m reminded of a simple truth: in-person connection is so valuable.

When we’re in the same space — sharing ideas over coffee or troubleshooting around a whiteboard — moments add up. They’re small, but they’re not insignificant. Each respectful, intentional interaction builds traction. And that drives real outcomes.

That said, remote working and collaboration absolutely have a place. We’re not going back to the way things were — nor should we. But we also shouldn’t underestimate what happens when people gather in real life. It’s not just good for morale. It’s good for business.

My advice: give your team opportunities to connect and collaborate in person. Shared experiences and small interactions help develop trust, which is crucial for true teamwork.

Would love to hear from colleagues: Have you seen great examples of balancing remote and in-office? Any hacks for improving the remote experience? | 120 | 1 | 0 | 4d | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:37.876Z |  | 2025-12-03T15:24:57.365Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7400275984966627328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGH56i24ShNCQ/feedshare-shrink_800/B4EZrMPyeDJgAg-/0/1764363283779?e=1766620800&v=beta&t=u-KiR2p0QY-ePlX17wOPfhFIiu22Cf6musd21UvAI3s | Ever since our team at Lightspeed Commerce surveyed folks for Black Friday, I've been thinking about how younger shoppers are really changing these sales events.

When I started in retail, Black Friday was all about big-ticket items: TVs, game consoles, the splurges. There’s still a lot of excitement around holiday shopping — but there's also an economic reality: affordability matters. 

70% of Gen Z are planning to shop during Black Friday and Cyber Monday, but they're approaching it completely differently by choosing everyday essentials and small luxuries that add real value to their lives.

Some are calling this the "lipstick effect," where little treats provide an emotional lift when larger luxuries feel out of reach. 

This holiday season, shoppers of all ages are under the pressure of a higher cost of living. So, fairness, transparency and empathy are essential for building trust. 

The short game is discounts, but the sustainable win is cultivating the genuine confidence that brings customers back. 

Grateful to Morgan L Brennan from CNBC’s Closing Bell: Overtime for the thoughtful conversation today. You can watch the full CNBC interview below: https://lnkd.in/ep3_dj4c | 127 | 2 | 1 | 1w | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:37.877Z |  | 2025-11-28T20:54:45.295Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399836128239067136 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b62684eb-53bd-4d7f-a470-da3121f45904 | https://media.licdn.com/dms/image/v2/D4E05AQEr5xdJXdkzxA/videocover-high/B4EZrF_u47KMBg-/0/1764258411606?e=1765778400&v=beta&t=Ixl8BVK6Naj1x8GSHvYDDVUkBhbxev8GiPDvDmt7oWU | Hands up if you’ve ever fallen for an irresistible Black Friday deal? I’ll go first 🙋‍♂️

It’s that time of year when prices magically “drop,” shipping fees vanish, and the bargains start sounding a little too good to be true.

Turns out most people feel the same. According to recent Lightspeed data, 84% of shoppers think Black Friday discounts are fake: https://lnkd.in/eyt_PxWm

Trust is eroding in retail, which means transparency is your company’s best asset, and in the long run, it’s just good business. 

TT: shaun.hermes | 22 | 2 | 0 | 1w | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:37.877Z |  | 2025-11-27T15:46:55.279Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399466241800916993 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZSMyo710ybw/feedshare-shrink_800/B4EZrAvUPoJgAk-/0/1764170225659?e=1766620800&v=beta&t=-uCVl12VFGJ2s81pWH-YPgwYWXYjE0BQMlnEvXc6Gjc | Ever notice how service in the best restaurants feels perfectly choreographed? Everything happens exactly when it should.

That's why I was so excited to attend Lightspeed Commerce EDGE in Paris last week, where we introduced Tempo, our new service pacing dashboard for restaurants.

France, with its legacy of culinary artistry and hospitality, was the perfect place to debut. The local restaurant culture embodies everything we hope our product will help clients achieve.

Tempo gives restaurants visibility they’ve never had before. It lets teams see the rhythm of service as it’s unfolding, so they don’t have to rely on instinct. 

With Tempo, teams can:

- Serve at the right rhythm by tracking dining moments so service feels natural and attentive
- Avoid delays and slowdowns quickly, before they impact the guest experience
- Stay consistent and create memorable moments that keep guests coming back

I think Tempo is going to be a real game changer for restaurant teams. It turns the hidden art of pacing into a performance metric that restaurants can manage — and makes it easier than ever for leaders to coach their teams. 

Twenty years in, and I’m still thinking a lot about what drove us in the early days. This launch felt like a full-circle moment because the mission hasn’t changed: we’re still empowering independent businesses with technology that elevates their craft. We’re just getting better.

Thank you to everyone who joined us in Paris. Let’s keep raising the bar!

Learn more about Tempo: 
https://lnkd.in/egES3_W2
https://lnkd.in/eRtMB6Gx | 141 | 7 | 1 | 1w | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:37.878Z |  | 2025-11-26T15:17:07.480Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7399113239168667648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHiwZhbKgnu6Q/feedshare-shrink_800/B4EZq7uSIAHEAg-/0/1764086064444?e=1766620800&v=beta&t=k3JwmtfyAubK310yhK0JnA7GWmxeR17OO-tR9RsRjd4 | The Main's First Annual Holiday Market this weekend again reminded me why I love this city so much.

Over two days, hundreds of people came through — artists, entrepreneurs, families, longtime locals, and first-time visitors. It was a fantastic experience. 
 
As the title sponsor, Lightspeed Commerce was also proud to power the event and help shine a light on Montreal’s local businesses in one of the best places to shop this season: a holiday market.

While headlines are dominated by Black Friday, what shoppers really want is authenticity and connection. Markets are an antidote to the endless scroll. There’s a human face and a warm smile behind every product. And every item, from a handcrafted piece of art to a locally made treat, comes with a story.

This is why people love holiday markets so much. It's about relationships. No algorithms, no gimmicks. Just a great atmosphere, great people, and great products. 

A special thank you to The Main for hosting, and to everyone who stopped by to share a moment or story as I signed copies of my new book, Echoes of Eden. It meant a lot. | 115 | 10 | 1 | 1w | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:37.879Z |  | 2025-11-25T15:54:25.094Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7393686825254518784 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEbNVbUOG_EpQ/feedshare-shrink_800/B4DZpum.5xJEAk-/0/1762792306093?e=1766620800&v=beta&t=Da4XH4aCEU9CG8lKl5lHGXLwotLmdbA4nefZqrGyHPU | I've been visiting Lightspeed Commerce offices around the world lately and trying something a little different. I host unfiltered Q&A sessions where anyone in the company can ask anything—no pre-submissions, no intermediaries. Just open dialogue.

For me, too many town halls feel like theater: questions submitted (and vetted) in advance; just a few minutes at the end of the session dedicated to Q&A; leadership delivering polished answers on safe topics.

I see it as a wasted opportunity. Your team wants to share raw information and insight. Give them a voice, and they will highlight opportunities, challenges, fixable frustrations, brewing customer issues, and so much more.

And when that inevitable tough question gets asked? Well, it’s not easy, but that’s a good thing too. It provides an opportunity for honest conversation, which builds trust and ensures that we’re all operating from a shared set of values.

One of the most memorable questions I’ve been asked? Whether there’s a disconnect between our sustainability mission and our work with retail and hospitality businesses. It was a fair challenge. My position: We serve independent businesses that are part of the solution. Many of them are on the frontlines of sustainability—sourcing locally, cutting waste, and building community. Supporting them is environmental action.

Would love to hear from others. How do you handle town halls and Q&A sessions? What’s a tough question you’ve been asked? | 261 | 14 | 2 | 3w | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.786Z |  | 2025-11-10T16:31:47.199Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7392249806544592896 | Document |  |  | A clear focus. Strong execution. Continued momentum into FY26.

We just announced our Q2 results, and the story is simple: our renewed strategy is working and it’s accelerating our growth.

In Q2, we exceeded expectations across the board:

 🚀 Revenue, gross profit, and Adjusted EBITDA all came in above our outlook
 💡 Our strategic focus on retail in North America and hospitality in Europe continues to deliver
 📈 We’re building real operating leverage while driving product innovation

These results are proof that when we focus on our strengths and deliver for ambitious businesses, success follows.

New customers highlights from Q2:

 🎨  40-location Crock A Doodle Inc., which operates pottery painting franchises across Canada 
 🌟 Hirschen – a two Michelin star restaurant in Germany
 ⛳ On Top of the World Communities – a three restaurant and two course golf club in Florida
 🏞️ Texas Big Bend National Park – will be running five locations on Lightspeed

We’re proud to partner with incredible merchants like these, innovators who trust Lightspeed Commerce to power their growth.

To our team: thank you for your relentless focus and belief in what we’re building. The best is still ahead.

For the full story, read our Q2 press release and infographic here: https://lnkd.in/eFkjKCf3 | 165 | 6 | 2 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.787Z |  | 2025-11-06T17:21:35.240Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391534626940395521 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEqxRCRMk6PoQ/feedshare-shrink_800/B4EZpQBkf1HEAg-/0/1762279181434?e=1766620800&v=beta&t=ZEUruOEAI31GAvep2802-1M8m7AsOp1hIVLmxF94_mE | This Black Friday stat from our new survey really stood out to me: 84% of shoppers think retailers inflate prices to fake discounts. But they still plan to shop.

The real challenge for retailers lies in this gap between what shoppers spend and the trust they’re willing to give. They’re moving fast, but thinking twice. Nearly one in three regret a purchase within a day. Almost a quarter expect to return at least some of what they buy.

Skepticism, second-guessing, and the returns that come with it, make things challenging for retailers. But there’s also an opportunity to earn back trust.
 
Customers return the favor when retailers are upfront about sizing, delivery, availability, etc. Clear info leads to better decisions and fewer returns.

Beyond that, it’s about understanding the broader economic climate. Shoppers are under the pressure of a higher cost of living, so fairness and empathy matter more than ever.

My key takeaway is that transparency goes a long way during the busy retail season. It’s not just about discounts — it’s about building trust and confidence that bring customers back long after the holidays.

Lightspeed Commerce’s latest research digs into all of this: spending priorities, shifting buyer behavior, and how retailers can navigate the season with customers in mind. Check out the full report — link in comments. | 31 | 4 | 1 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.788Z |  | 2025-11-04T17:59:43.135Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391202737365086208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFyRVNv2vZCMA/feedshare-shrink_800/B4EZownUzPKYAk-/0/1761752207104?e=1766620800&v=beta&t=K9OcyofeJHInNFwUf_Y82HdABF8qa5UFsKczegyNlvI | Looking forward to this tonight! Karl Moore @ McGill University - Desautels Faculty of Management | 32 | 1 | 0 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.789Z |  | 2025-11-03T20:00:54.494Z | https://www.linkedin.com/feed/update/urn:li:activity:7389324337826250753/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389718453760303104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEuIgio609mw/feedshare-shrink_800/B4EZo2NxQvHoAg-/0/1761846172127?e=1766620800&v=beta&t=VDfFYJtqxwP3F2JehX9ysTOrSJeOIp-aCP0eC7bZlvc | Some words to live by right now: it’s not hope that generates action. It’s the other way around: action generates hope.

Jane Goodall actually shared this sentiment with me during our time working together in the Amazon. But I think it applies just the same, whether we’re talking conservation, politics or business.

We’re living through a time of uncertainty: inflation, AI disruption, global conflict, and DEI rollbacks. It’s a lot. But I’ve learned something working with conservationists, Indigenous activists, and entrepreneurs:

→ Headlines aren’t everything; your actions shape your future
→ Values are your anchor when plans shift
→ Small moments build real momentum
→ Don’t overlook the people on the ground; they often know more than the “experts”

I break down how to channel uncertainty into action in my latest Entrepreneur Media article: https://lnkd.in/e_K7c3m6

Curious to hear from other leaders: When things feel most uncertain, what's your first move? | 136 | 3 | 0 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.790Z |  | 2025-10-30T17:42:53.706Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7388950273752313856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHykcpHhsu4_w/feedshare-shrink_800/B4EZorTHSjHoAg-/0/1761663023933?e=1766620800&v=beta&t=RAhWWTB19RRE538pYYCTSuQAmVc12yiGET_fkRVeVlk | What is it about gut instinct? I’m a big data and metrics guy, but I have to say there’s absolutely something to the idea of instinctive, gut responses. 

I recently sat down for a great conversation with Lance Chung of Glory Media for his Mission Critical podcast. 

Lance asked me a question that really made me think about the power of trusting your gut: How has my perspective on leadership evolved in the 20 years I’ve been building Lightspeed?

Without a doubt, the biggest lesson I’ve learned is to listen to my gut. When I started out, I lacked the confidence to trust my instincts. But whenever I ignored my gut, I tended to make mistakes.

Part of this is just growing as an entrepreneur and leader — the more time you spend in the trenches, the more you learn and the better your instincts become. 

But it’s also about values. In my experience, when you stay true to your values and purposefully choose to act on them, you tend to make the right decisions. 

Lightspeed is much bigger now — and the world around it is very different — but I believe the same vision, mission, and values still guide us. 

How about you? Any examples where you should have listened to your gut? Or where your gut steered you in the right direction? | 97 | 2 | 1 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.792Z |  | 2025-10-28T14:50:25.320Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7387181664227000320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHOIVVWaHM_Wg/feedshare-shrink_800/B4EZoSKk7WKgAs-/0/1761241354913?e=1766620800&v=beta&t=xeAtsNRuCdRzSIlSQ2-1Oh4J-xSNLANEdYcEa0h0_bo | So proud that Lightspeed has been honored as a winner in the Enterprise — Industry Leaders category of the Deloitte Technology Fast 50 program. 

In 2025, Lightspeed was honored for its 318% growth. This is all the more impressive considering that we’re now in our 20th year and still growing strong. 

This isn’t just about the award. It’s about what the growth and recognition represent: trust from our customers, hard work from our team, and confirmation that our mission is having a real impact.

Thank you to our customers and partners. And thank you to all the Lightspeeders. Sustained growth at this level is only possible because of you. 

As we look ahead, the aim isn’t growth for growth’s sake — it’s staying firmly rooted in what matters: supporting independent business and helping drive commerce that lifts communities. 

Here’s to the next chapter! | 377 | 9 | 6 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.794Z |  | 2025-10-23T17:42:35.950Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7386423880606818305 | Text |  |  | Anyone else struggle with leaving a bad restaurant review online? I always wonder if maybe the restaurant just had an off night. 

Do I really want to call them out for a random bad dish or because one server was in a bad mood? Plus, negative reviews have a huge consequence. 

85% of diners trust online reviews as much as personal recommendations — even one slip-up can lose a restaurant loyal customers (and live online forever). No wonder 1 in 5 restaurants doesn’t make it past their first year. 

But I know not everyone is so understanding. So what’s a restaurant to do? For me, an increasingly important part of the answer is the right tech. 

Whether it’s integrated ordering systems, AI-powered menus, timing tools, or handheld POS devices, the right tools can help restaurants avoid the missteps that spark negative reviews.

I go over how the right tech stack in your restaurant can help you focus on customer service and flourish in a tough economy in my latest newsletter. | 39 | 12 | 0 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.794Z |  | 2025-10-21T15:31:26.256Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7384580643529170944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEm7D2kTqjyBA/feedshare-shrink_800/B4EZnsNh89GYAg-/0/1760604594810?e=1766620800&v=beta&t=gukq-Sfp7FhRlMx15ZzO_gIFs89lqzPbKLsn3804Bl8 | Join me at Lightspeed Edge, our hospitality tech conference in Paris on Nov 24! | 45 | 0 | 3 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.795Z |  | 2025-10-16T13:27:04.291Z | https://www.linkedin.com/feed/update/urn:li:activity:7384510898679291904/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7384229876301447168 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHHF8oRULxrAg/feedshare-shrink_800/B4DZnoN8ERJUAg-/0/1760537592943?e=1766620800&v=beta&t=VyxETZ_-Qqh2uMccFg2NIoPEOyoc6quGL9_qKAHs2cY | Really interesting dining trend here: adults ordering from the kids' menu. A recent Lightspeed Commerce study found 44% of adult diners occasionally opt for kids’ meals, citing smaller portions, simpler dishes, and more affordable prices.

That surprised me at first… but the more I think about it, the more it makes sense. We’re living in a time when portion sizes often feel out of step with how people actually want to eat. Plus, as restaurant prices rise, diners are becoming more discerning about what they spend their money on.

One possible takeaway for restaurants: It seems like there’s an opportunity to provide smaller portions and customize menus to accommodate lighter eating habits and even solo diners looking for a quick bite.

I saw this in action earlier this year in New York at Avant Garden, where I got to eat at a solo table alongside a curated menu for solo diners. 

I’d love to know how many colleagues out there have actually ordered off a kids menu?! | 130 | 31 | 0 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.796Z |  | 2025-10-15T14:13:14.867Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7382058984712589312 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGCJd9pVafzTQ/feedshare-shrink_800/B4EZnJXho2KgAg-/0/1760020012662?e=1766620800&v=beta&t=gxhMhUNvaT6hQ3f1jadixDQRDZtQdfhY8gNWWyaKCAA | Touchy subject here: tipping fatigue. We surveyed 1,000 diners across North America and it turns out you’re not the only one feeling awkward about tipping. 

Some intriguing stats:
- 54% of diners say they feel pressured by preset tipping screens
- 44% of consumers say they’re tipping less
- 29% would like to eliminate tipping altogether
- 59% say tipping delivery drivers is important, but only 33% feel the same for coffee shop staff
- The most common range for strong service is 15% – 20%

I can see both sides here. Restaurants and cafes are under more pressure than ever now to deliver on high expectations with dwindling margins. But diners are feeling the crunch, too, as prices continue to rise. 

This is a little simplistic, but I think when service is memorable, tipping aligns naturally. But when it feels performative and obligatory, it loses meaning. And customers feel frustrated.

Has tipping fatigue shown up in your dining experiences lately? | 44 | 7 | 1 | 1mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.797Z |  | 2025-10-09T14:26:53.979Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7381047661459578880 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGbOakkONDAAQ/feedshare-shrink_800/B4EZm6_uX0KUAk-/0/1759778893219?e=1766620800&v=beta&t=ukPILTdxtPjZvNW7m8GIo6iF_F3You0q6LMYpg4OoAI | I’m so proud of the Lightspeed Commerce team! The Globe and Mail just named Lightspeed to its 2025 list of Canada’s Top Growing Companies. 

Growth like this doesn’t happen by accident. It’s what you get when product craft meets customer obsession. And when a culture actually lives its values.
 
To every Lightspeeder, thank you. You’ve stayed focused through change and shipped with care. Most importantly, you kept our mission clear: help independent businesses compete and thrive. 

To our customers and partners, you give us purpose and push us to be better. This recognition belongs to you as much as to us.

It’s so important to celebrate these wins — and use them to stay motivated. We’ll keep building tools that make a real difference on the sales floor, in the kitchen and at the counter. | 484 | 15 | 6 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.797Z |  | 2025-10-06T19:28:15.726Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7379556120597536768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGLDB793TRITQ/feedshare-shrink_800/B4EZmlzL0sHcAo-/0/1759423283463?e=1766620800&v=beta&t=Jw0i_HATdwQksqD25zgvSIuQIUok65b0JSlpFl3XRZQ | It’s hard to find words for the loss of someone who made the world more humane simply by how she moved through it.

Since I first began my environmental journey over 30 years ago, as part of the Clayoquot protests in Vancouver, Dr. Jane Goodall has been an inspiration to me.

More recently, I had the extraordinary privilege of spending time with her in both the Amazon and in Gombe, where her groundbreaking work with chimpanzees began. I watched wildlife—elephants, primates—approach her without fear, as though recognizing an old friend. That kind of peace between species isn’t accidental. It’s earned, over a lifetime of compassion, patience and fierce advocacy.

Jane once told me that hope is not passive. It’s a discipline. A practice. I think about that often, especially in moments like this.

We had talked about legacy. Hers was never about fame. It was about ensuring the next generation had the tools—and the wild spaces—to carry the work forward. I was honored that she wrote the foreword to my recent book Echoes From Eden. All proceeds will go to the Jane Goodall Legacy Fund.

If you’ve ever felt the tug of the natural world on your spirit, you’ve felt her impact. Let’s not let it fade.

What are the wild places you’d fight to protect?

#JaneGoodall | 777 | 21 | 5 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.798Z |  | 2025-10-02T16:41:24.673Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7378494378975141889 | Video (LinkedIn Source) | blob:https://www.linkedin.com/42223a48-2ddd-4a05-94f8-5a6a54e23968 | https://media.licdn.com/dms/image/v2/D4E05AQFMpUYCNfr0Kw/feedshare-thumbnail_720_1280/B4EZmWtXpJGUAw-/0/1759170101156?e=1765778400&v=beta&t=HJoAZf5nfV0sdogOpsJnK1K0pSSHTiXGZXA-nsZvdWs | I LOVE this: build your own retail showroom online  — from scratch — just by answering a couple quick questions. Hats off to the team at Lightspeed Commerce for taking AI to the next level here with Lightspeed AI Showroom!

Most retailers didn’t open their stores to become web designers or online admins. But they still deserve a beautiful, AI-powered website with real-time visibility into inventory. 

That’s the idea behind Lightspeed AI Showroom, the new product we’re launching today. It helps businesses build a compelling online presence without committing to ecommerce. 

And, best of all, it’ll use their Lightspeed Retail data to automatically create their site. 

No shopping cart, no complicated setup. Just your store, your story and your products in an elegant and easy-to-navigate interface.

Here’s what AI Showroom offers:

1️⃣ Instantly generate a website from your Lightspeed Retail data
2️⃣ Real-time product visibility, synced from your in-store inventory
3️⃣ Effortless onboarding guided by AI
4️⃣ Customizable designs based on your brand’s look and feel
5️⃣ Easily scalable into full ecommerce… when you’re ready

We’re all very proud of AI Showroom. We built it to help store owners focus on what they love. With AI Showroom, AI handles the busywork so you can focus on what makes your store special.

Would love to hear feedback from retailers in my network on this. Is this something you’d find useful? | 134 | 7 | 3 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.801Z |  | 2025-09-29T18:22:25.744Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7377049341007392768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEKzUT1pPeNAg/feedshare-shrink_800/B4EZmCLR3lHgAo-/0/1758825619846?e=1766620800&v=beta&t=tdYirU1eb7QUiRC7cSD2CLC__jySV2FoExT2c1FqQGE | I'm pleased to announce two new additions to Lightspeed Commerce’s Board of Directors: Sameer Samat, President of Android Ecosystem at Google, and Odilon AJ., a former CEO and seasoned global fintech leader.

Sameer brings world-class product and tech expertise from building Android across devices, and was a founding member of Google's Commerce team. 

Odilon has over 40 years of experience driving growth and transformation across the finserv, fintech, technology, and consumer goods sectors. Among his previous roles, he served as president at Western Union, where he oversaw a $5B consumer business across more than 200 countries and territories.

Both join us on October 1st, and I couldn't be more excited about their strategic insights as we innovate and scale globally.

Their appointments to the Board will help guide our product-led growth strategy and profitability initiatives.

I would also like to take a moment to sincerely thank Patrick Pichette and Rob Williams for their years of service and leadership on our Board. Their guidance, discipline, and passion have been instrumental in shaping Lightspeed’s journey, and we are deeply grateful for the impact they’ve had on our company.

Read more: https://lnkd.in/eYEMyQJU | 141 | 4 | 1 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.802Z |  | 2025-09-25T18:40:21.845Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7375899984610852864 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGMdxOm-bxjag/feedshare-shrink_800/B56Zlx18Y6KMAk-/0/1758551591620?e=1766620800&v=beta&t=fl6ypj1SsCuFtWeWNyTUM7vTyRF1A9nhTn3wzZi2sH0 | Hosting a book discussion and signing at my own company was a little surreal but also lots of fun! 

My Echoes of Eden co-author Eric Hendrikx recently joined me at Lightspeed Commerce HQ. We talked about our journey across continents and ecosystems and signed a few copies for the team. 

A big thank you to all the Lightspeeders who showed up and asked thoughtful questions. Your energy reminded me why this work matters.

I learned so much while traveling and putting this book together. I met people who put everything on the line to protect the planet; people like Dr. Jane Goodall and Juma Xipaya deep in the Amazon, Suzan Baptiste protecting Trinidad’s leatherback turtles, Dr. Russell Mittermeier working to save Madagascar’s endangered lemurs and courageous environmental defenders across Indonesia, Canada and other parts of the world. 

The lessons I learned from them will stay with me forever. I hope I can pass their wisdom along to everyone who reads Echoes from Eden and make the goal of protecting Earth’s last wild places feel urgent but achievable.

PS: If you don’t have a copy yet, you can grab one at the link below. All proceeds from the book go to the The Jane Goodall Legacy Foundation.

https://shorturl.at/9Uhcv | 163 | 5 | 2 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.803Z |  | 2025-09-22T14:33:13.926Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7374476271617089536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE39Z8VofMF0A/feedshare-shrink_800/B4EZldnFmeK0Ag-/0/1758212152792?e=1766620800&v=beta&t=oRqBjbrSvXfE_KVsnxBCPUZnke5CLAqrKu8blP7R87Q | I saw this stat and had to stop and read it twice: According to the latest GoDaddy Consumer Pulse survey, nearly half of Gen Z and millennials prefer shopping WITHOUT interacting with anyone. 

For so long, I’ve said that what sets retail apart is the human element. But I’m realizing it’s more complicated than that. 

What makes in-store retail special isn’t necessarily people… it’s value. Shoppers aren’t coming to your store to interact; they’re coming to get something they can’t online: 

→ a chance to try before they buy
→ expert advice they can’t get anywhere else 
→ streamlined browsing and purchasing (and instant gratification)

I outline how retailers can hop on this trend and provide a better experience for these shoppers in my latest Entrepreneur article: https://bit.ly/3VU9L54

Interested in hearing others’ thoughts on this: Are the findings surprising? How do you prefer your shopping experience — more or less human? | 41 | 11 | 0 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.803Z |  | 2025-09-18T16:15:54.297Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7373736908390318080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHxy5rKoYnbFg/feedshare-shrink_2048_1536/B4EZlTGpMIK0Aw-/0/1758035875099?e=1766620800&v=beta&t=Nowc0pNkuewNBVjEOjmVnWXjFE-gEy5_5DcSALZ7574 | Humbled to be featured as one of Canada's '40 New Nation Makers' in the most recent edition of Maclean's Magazine with Canadian Business!

It’s amazing to be mentioned amongst so many exceptional Canadians who are shaping the future with purpose, creativity, and a drive to make a real impact.

From business and sports to fashion, conservation, and everything in between, Canada proves itself as a leader on the world stage time and time again. 

Thanks to Maclean’s for the shoutout and for highlighting the work that Lightspeed Commerce does to support Canadian businesses! 
Read the full list here: https://lnkd.in/eSEP9js2 | 289 | 27 | 3 | 2mo | Post | Dax Dasilva | https://www.linkedin.com/in/daxdasilva | https://linkedin.com/in/daxdasilva | 2025-12-08T05:16:42.804Z |  | 2025-09-16T15:17:56.367Z |  |  | 

---



---

# Dax Dasilva
*Lightspeed Commerce*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Five Questions with Lightspeed Founder & CEO Dax Dasilva](https://www.canadianinnovators.org/content/five-questions-with-lightspeed-founder-ceo-dax-dasilva)
*2025-03-18*
- Category: article

### [Retail Podcast 304: Dax Dasilva On Creating Change Through Diverse Minds](https://www.retaildoc.com/podcast/retail-podcast-304dax-dasilva-on-creating-change-through-diverse-minds)
*2025-01-01*
- Category: podcast

### [Dax Dasilva, CEO of Lightspeed - CJAD 800](https://omny.fm/shows/cjad-800/dax-dasilva-ceo-of-lightspeed-1?in_playlist=the-ceo-series)
*2025-06-02*
- Category: article

### [20VC: Why VC is Distorting a Generation of SaaS Companies & With $900M in ARR and a Market Cap of $2.6BN is Lightspeed the Most Misunderstood Public Company with Dax Dasilva, Founder & CEO @ Lightspeed](https://www.thetwentyminutevc.com/dax-dasilva)
*2025-05-06*
- Category: article

### [Dax Dasilva, Founder and CEO of Lightspeed, on How to Embrace the…](https://appdirect.com/blog/how-to-embrace-the-changemaker-mentality-with-dax-dasilva)
*2021-03-15*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Inside Lightspeed](https://inside.lightspeedhq.com/)**
  - Source: inside.lightspeedhq.com
  - *Leading Lightspeed to profitable growth with Dax Dasilva. August 14th, 2024 | 25 mins 18 secs. lightspeed, lightspeed commerce, technology. A conversa...*

- **[Lightspeed Announces the Return of Dax Dasilva as CEO](https://www.prnewswire.com/news-releases/lightspeed-announces-the-return-of-dax-dasilva-as-ceo-302062596.html)**
  - Source: prnewswire.com
  - *Feb 15, 2024 ... PRNewswire/ - Lightspeed Commerce Inc. (NYSE: LSPD) (TSX: LSPD) announced today the reappointment of Founder Dax Dasilva as interim C...*

- **[How Dax Dasilva plans to get Lightspeed to $1 billion in revenue ...](https://betakit.com/dax-dasilva-lightspeed-1-billion-revenue/)**
  - Source: betakit.com
  - *Jun 9, 2024 ... Lightspeed Commerce founder and CEO Dax Dasilva. Dax is back: why he stepped down, then returned, as the company he founded approaches...*

- **[Kill the business plan](https://www.strategyzer.com/library/kill-the-business-plan)**
  - Source: strategyzer.com
  - *Aug 28, 2024 ... ... podcast while preparing for the day. Today, I caught his interview with Lightspeed Commerce founder and CEO Dax Dasilva. One of t...*

- **[Lightspeed's Dax Dasilva on 20 Years of Company Building ...](https://markmacleod.me/lightspeeds-dax-dasilva-on-20-years-of-company-building-strategic-acquisitions-and-how-spirituality-shaped-his-leadership-philosophy/)**
  - Source: markmacleod.me
  - *In this candid conversation, Lightspeed ... ABOUT · SERVICES · TESTIMONIALS · FAQ · DEALS COACHING · BLOG · PODCAST · CONTACT. Logo. July 11, 2025 - S...*

- **[From Bootstrapped to Public: Lightspeed's 20-Year Evolution - The ...](https://podcast.markmacleod.me/episode/from-bootstrapped-to-public-lightspeeds-20-year-evolution)**
  - Source: podcast.markmacleod.me
  - *Mar 31, 2025 ... In this episode of the Startup CEO Show, host Mark MacLeod welcomes Dax Dasilva, the founder and CEO of Lightspeed Commerce, ......*

- **[Bootstrapping to a Billion-Dollar IPO: Dax Dasilva on Lightspeed's ...](https://tanktalks.substack.com/p/bootstrapping-to-a-billion-dollar)**
  - Source: tanktalks.substack.com
  - *Oct 10, 2024 ... Dax Dasilva is the Founder and CEO of Lightspeed Commerce. Founded ... Favorite Podcast: 20VC. Favorite Newsletter: Nate Silver's Sil...*

- **[Inside Lightspeed - Podcast - Apple Podcasts](https://podcasts.apple.com/ca/podcast/inside-lightspeed/id1601262623)**
  - Source: podcasts.apple.com
  - *Listen to Lightspeed Commerce's Inside Lightspeed podcast on Apple Podcasts ... Special Guest: Dax Dasilva. 25 min....*

- **[Social Impact Heroes Helping Our Planet: Why & How Dax Dasilva ...](https://medium.com/authority-magazine/social-impact-heroes-helping-our-planet-why-how-dax-dasilva-of-lightspeed-is-helping-to-change-7b98f2063d1d)**
  - Source: medium.com
  - *Mar 10, 2022 ... ... interviewing Dax Dasilva. Dax Dasilva is a global tech leader and ... Lightspeed Commerce Inc. and Founder of Age of Union Allian...*

- **[Lightspeed's Dax Dasilva launches environmental nonprofit ...](https://betakit.com/lightspeeds-dax-dasilva-launches-environmental-nonprofit-pledges-40-million-for-conservation-restoration-projects/)**
  - Source: betakit.com
  - *Oct 19, 2021 ... Lightspeed Commerce founder and CEO Dax Dasilva has launched Age of ... In an interview, Dasilva, who has roots as an environmental ....*

---

*Generated by Founder Scraper*
