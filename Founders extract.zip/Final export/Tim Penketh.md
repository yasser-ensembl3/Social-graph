# Tim Penketh

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : TheFutureEconomy.ca
**Durée dans le rôle** : 9 years 3 months in role
**Durée dans l'entreprise** : 9 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Media Production

## Description du rôle

Founder & CEO of TheFutureEconomy.ca, a multimedia publishing house that produces original content on the future of Canada’s economy and its key industries and lays out leaders' visions and calls to action on what must be done now – and by who – for Canada to lead in the future economy.

The site features leaders' interviews and op-eds on Canadian competitiveness, entrepreneurship, talent, innovation and sustainability across all key industries.

Our purpose is to promote Canada’s prosperous and sustainable future economy by fostering national dialogue and debate, and connecting people and their bold ideas on the country’s major business issues and opportunities in the future economy.

www.TheFutureEconomy.ca

## Résumé

𝐓𝐡𝐞𝐅𝐮𝐭𝐮𝐫𝐞𝐄𝐜𝐨𝐧𝐨𝐦𝐲.𝐜𝐚 – 𝐬𝐢𝐠𝐧 𝐮𝐩 𝐟𝐨𝐫 𝐨𝐮𝐫 𝐰𝐞𝐞𝐤𝐥𝐲 𝐧𝐞𝐰𝐬𝐥𝐞𝐭𝐭𝐞𝐫 ➡️ www.TheFutureEconomy.ca/Newsletter

TheFutureEconomy.ca features Canada's brightest and most passionate leaders in business, government, academia, finance, research and more to define what must be done now – and by who – for Canada 🇨🇦 to lead and win in the future economy.

We cover critical industries and topics that are shaping Canada's future.
-Industries such as tech, life sciences, agriculture, finance, natural resources, education, clean tech, energy and more.
-Topics such as the future of work, the Indigenous economy, diversity and inclusion, sustainable business and others.

Canada has limitless potential.

My mission – and that of TheFutureEconomy.ca – is to define a strong vision for what we must do now to maximize that potential and the benefits it will bring for all Canadians – current and future.

🍁

#Canada #Economy #Innovation #Business #Government #Policy #Future

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAByjrHoBEXGK_ztyWMfEth7OfI5dyEGFgcI/
**Connexions partagées** : 117


---

# Tim Penketh

## Position actuelle

**Entreprise** : TheFutureEconomy.ca

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Tim Penketh

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397402297485549569 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEsOZBB6mmV1g/feedshare-shrink_800/B56ZqjaLIDJoAg-/0/1763678143721?e=1766620800&v=beta&t=NpH5ze7B5p2Sey8MrW5fK3U8YHJnbIFhlSvzrbwSyXo | In his op-ed, David Hughes, President and CEO of Generate Canada, argues that we’re using old tools to fight new, wicked problems - issues so tangled that traditional, siloed approaches don’t just fail… they often make things worse. https://shorturl.at/v4npa | 7 | 1 | 1 | 2w | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:48.657Z |  | 2025-11-20T22:35:44.809Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384720731865141248 | Text |  |  | Nation-building is back on the agenda - but who’s really building it?

For decades, Canada’s biggest infrastructure projects - pipelines, ports, highways - were built through Indigenous lands, not with Indigenous peoples.
That’s changing fast.

Here’s what stood out to me in an op-ed by Michael Fox, MBA, President & CEO of Indigenous Community Engagement (ICE):

-> Indigenous ownership is reshaping Canada’s economy. From LNG to mining, Nations are now equity partners, developers, and financiers.
-> Equity means efficiency. Projects with Indigenous ownership move faster, face fewer legal challenges, and build real trust.
-> But access to capital remains a barrier. NACCA estimates an $80B Indigenous capital shortfall through 2030 - a gap that limits growth and shared prosperity.
-> True nation-building demands inclusion. It’s not just about participation - it’s about embedding Indigenous ownership, procurement, and financing into Canada’s economic future.

This isn’t about inclusion in someone else’s economy.

It’s about recognizing that Indigenous economies are already nation-making. | 13 | 3 | 0 | 1mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:48.657Z |  | 2025-10-16T22:43:43.953Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7384301445543776256 | Video (LinkedIn Source) | blob:https://www.linkedin.com/91fd18d9-da8d-4eec-86fb-75a41dc0d1d8 | https://media.licdn.com/dms/image/v2/D5605AQHP0yiu2VmrwA/videocover-high/B56ZnpO8w.J8CE-/0/1760554647626?e=1765774800&v=beta&t=AHKOE4FCkp6Xh_aZKdF95zwNkucDIH5wr6couge2W5w | Numbers don’t lie: 

With 29% of Canadian SMBs still managing their finances manually, the skills gap in accounting is widening - and it’s clear the industry needs more than small fixes. It needs transformation.

Here’s what stood out to me in an article from Stephen Edginton CPTO at Dext, on how AI can help solve the accounting skills gap:

-> The talent shortage is real - fewer young professionals are entering the field as senior accountants retire.

->  AI isn’t replacing accountants; it’s empowering them to move from repetitive admin to strategic advisory work.

->  Firms that embrace AI tools can attract new talent, boost productivity, and stay competitive in a fast-moving digital economy.

->  Adopting AI isn’t just about technology - it’s about creating a future-ready profession that blends human expertise with machine intelligence.

The future of accounting won’t be defined by who has the most people - but by who uses technology most intelligently. | 4 | 1 | 1 | 1mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:48.658Z |  | 2025-10-15T18:57:38.304Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7383552672089649152 | Text |  |  | Good food shouldn’t be getting harder to afford. 🍎

As food prices climb more than 27% in five years, it’s clear Canada’s food system needs more than patchwork fixes — it needs transformation.

Here’s what stood out to me in an article from Firat E, CEO of Bunz Inc., on building an affordable, sustainable food system:

- We must redefine productivity — not by how much we produce, but how efficiently, sustainably, and fairly we do it.

- Agri-tech innovation can help farmers cut waste, boost yields, and stabilize prices.

- Infrastructure investments—from irrigation and energy to digital access—are essential to scale this transformation.

- A stronger food system means more resilient communities, better jobs, and healthier futures.

If we can’t make sustainable food affordable, how sustainable is it really? | 6 | 2 | 0 | 1mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:48.658Z |  | 2025-10-13T17:22:16.801Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7382574643066433536 | Text |  |  | Canada used to dream big. I think it’s time we do it again.

I’ve been sitting with this a lot lately — how a country that once led in aerospace, science, and even lunar exploration started to lose its edge not because of a lack of talent, but because we stopped believing in ourselves.

Here’s what I’ve learned from TheFutureEconomy.ca’s new Future in Focus on World Space Week:

🚀 Engineering & Talent: We have brilliant minds leaving because we’re not building enough for them to stay.

🌕 Lunar Opportunity: We had a head start in space mining — and let it go. That still stings.

🛰️ Science as Strategy: Science has always been one of Canada’s quiet superpowers. CASTOR could remind the world of that.

🧪 Lab to Launchpad: Our researchers don’t lack ideas. They lack a system that bets on them

🌍 Global Leadership: Canada can help write the rules of the future, not just follow them.

We have the talent. We have the track record. What’s missing is the boldness to lead again.

Check out the new Future In Focus at the link below, featuring op-eds from:

- Alex Ellery, Professor of Mechanical and Aerospace Engineering of Carleton University
- Dr. Sarah Gallagher, Director of the Institute for Earth and Space Exploration at Western University, Dr. Valerie Oosterveld, Professor and Western Research Chair at the Faculty of Law at Western University, Dr. Pauline Barmby, Professor and Chair of Physics & Astronomy at Western University
- David Zingg, Distinguished Professor of Computational Aerodynamics and Sustainable Aviation at the University of Toronto Institute for Aerospace Studies

#WorldSpaceWeek #Space #Engineering #BrainDrain #FutureInFocus | 6 | 1 | 0 | 1mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:48.659Z |  | 2025-10-11T00:35:56.511Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379251821128757249 | Text |  |  | Canada’s healthcare system is failing too many of us. 🏥

Dr. Andrew Nathaniel F., Partner of Technology Strategy and AI-led Digital Transformation at KPMG Canada, reminds us of the human cost behind the numbers:

30 weeks is the average wait to see a specialist.

6.5 million people don’t even have a family doctor.

Doctors lose 18.5 million hours a year to paperwork instead of patients.

By 2031, elder care costs will nearly double.

These aren’t just stats — they’re neighbours, friends, and families waiting for care that isn’t coming soon enough.

We need to stop patching a broken system and start reimagining it — from digital health records that actually follow patients, to reducing the crushing admin burden on our healthcare workers.

If you had the chance to change one thing first, what would it be? | 6 | 2 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.751Z |  | 2025-10-01T20:32:14.026Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7378577375690715138 | Text |  |  | Canadians want energy that works for everyone.

Whenever Canada’s energy future is discussed, I hear the same message over and over: yes, we need to build — but we need to do it right.

Professor Monica Gattinger, Founding Chair of Positive Energy at University of Ottawa, sums it up excellently: 

- Over 70% of Canadians support growing our energy exports to strengthen global security.
- At the same time, people want reassurance that projects respect Indigenous rights, protect the environment, and listen to communities.
- The challenge isn’t just about speed — it’s about trust, stability, and ensuring projects stand the test of time.

👉 What do you think is the hardest balance to strike: growth, environment, or trust? | 5 | 1 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.751Z |  | 2025-09-29T23:52:13.703Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7377439861009481728 | Text |  |  | Tourism is about more than postcards.

Canada’s tourism story isn’t just about economic numbers—it’s about people, communities, and the future we want to build together.

Here’s what I’ve learned from TheFutureEconomy.ca’s new Future in Focus on World Entrepreneurs’ Day:

- Tourism generates $130 billion annually, employing 10% of Canada’s workforce and sustaining 265,000 businesses across 5,000+ communities.
- Travellers today are demanding more purposeful, authentic experiences that benefit local and Indigenous communities.
- Overtourism is real—we must protect fragile ecosystems and cultural heritage while diversifying destinations.
- Bold investments in climate-resilient infrastructure and smart policy will strengthen Canada’s competitiveness and unite our country.

If tourism is this powerful, how do we make sure we grow it with care, purpose, and long-term vision?

Check out the new Future In Focus at the link below, featuring op-eds from:

Jean Hébert, Executive Director of  the Canadian Association of Tour Operators (CATO)
Amy Butcher, Vice President of Public Affairs of the Tourism Industry Association of Canada
Bruce Poon Tip OC, Founder of G Adventures

#WorldTourismDay #SustainableTourism #Tourism #CanadaTourism #TraditionalTourism #FutureInFocus | 2 | 1 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.752Z |  | 2025-09-26T20:32:09.069Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7376705565319815168 | Text |  |  | Extreme weather is no longer a future threat.

It’s here, and it’s reshaping how Canadians live, work, and invest. If we don’t prepare, we risk undermining our own economic security.

Here’s what I learned from a recent expert conversation on climate resilience in Canada:

- Transition risks like decarbonization matter—but physical risks such as floods, wildfires, and rising seas can be just as disruptive.

- Resilient infrastructure—whether airports in the North, stronger buildings, or climate-smart energy grids—must be designed for the conditions we’ll face in 2050, not just today.

- Indigenous-led projects are showing us what works: on time, on budget, and grounded in long-term stewardship of land and community.

- Private capital has to step up too—blending with public investment to make climate readiness possible at scale.

For me, this isn’t just about climate strategy. It’s about building a Canada that my kids—and yours—can thrive in for generations to come.

What’s one investment you believe Canada must prioritize now to secure our climate resilience by 2050?

The fifth episode of the #WickedSolutions series, hosted by Generate Canada’s President and CEO David Hughes, and Priya Bala-Miller PhD, Managing Director of the Nature Investment Hub, explores the answers to this question. It features Don Iveson, Executive Advisor of Climate Investing & Community Resilience at Co-operators, and Hillary Thatcher, Managing Director of Investments at Canada Infrastructure Bank/ Banque de l'infrastructure du Canada.

A highly recommended watch => link in the comment section below.

#WickedProblems #RegenerativeAgriculture #FutureOfFarming #AgInnovation #TheFutureEconomy #CanadianAgriculture #CdnAg #AgritechCanada | 11 | 1 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.754Z |  | 2025-09-24T19:54:19.334Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7374854523292606465 | Text |  |  | Canada’s defence challenge goes beyond spending.

I think we can all agree: when billions are budgeted, Canadians expect results. 

Yet according to Jean-François Godbout, Head of Office at the Airbus Defence and Space in Canada, and Dwayne Charette, President of Airbus Helicopters in Canada, the numbers tell a different story:

In 2021–2022, nearly $2.5B went unspent, and almost half of our fleet sat idle.

By 2029–2030, we’ll spend ~1.76% of GDP on defence. But if procurement stalls, that funding won’t translate into the capability we actually need.

The problem isn’t commitment—it’s execution. We need to move faster, cut red tape, and partner with those already embedded in Canada’s ecosystem who can deliver now.

I see the same challenge every time a business scales. Vision is essential—but it’s execution that builds resilience, creates capability, and earns trust.

Canada has the talent, the partners, and the resources. The question is—will we have the courage to turn budgets into outcomes, and words into real capability? | 6 | 2 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.754Z |  | 2025-09-19T17:18:56.524Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7374197531100172289 | Text |  |  | Canada can’t afford to lose entrepreneurs.

When I read Andrew Haughian (Partner of Pangaea Ventures)’s article highlighting that Canada has 100,000 fewer entrepreneurs today than two decades ago, it struck me deeply. 

Behind that number are dreams deferred, businesses never launched, and jobs that never came to be.

As a founder, I know how hard it is to start something new. The risks are real. The capital is scarce. But I also know the flip side: the rush of solving a problem no one else has, and seeing your vision take root in the world.

That’s why this trend worries me. We need more, not fewer, Canadians willing to take that leap. 

Small and medium-sized businesses are the backbone of our economy, but the entrepreneurial pipeline is drying up just when we need innovation most.

Without new businesses, we fall behind on global competitiveness.

Without new ideas, we risk stagnation in productivity and growth.

Without founders, we lose the spark that drives Canada forward.

The question is—how do we make it easier, not harder, for the next 100,000 entrepreneurs to step forward? | 7 | 4 | 1 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.755Z |  | 2025-09-17T21:48:17.379Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7373485561837318144 | Text |  |  | We’re rich in AI talent—but poor in IP.

That gap is something that was highlighted in an article by Claudia Krywiak, President and CEO of Ontario Centre of Innovation (OCI).

She points out that Canada is home to 10% of the world’s top-tier AI researchers. These researchers have brilliant minds, and their work is nothing short of world-changing.

But here’s the problem: only 7% of AI intellectual property under the Pan-Canadian AI Strategy is held by Canadian firms. The ideas are born here, but too often the value leaves.

I know from my own conversations that this isn’t about lack of ambition—it’s about missing links between research, capital, and commercialization.

I want to see Canadian ideas scale here, create jobs here, and shape industries here. We can’t keep being the training ground for talent that fuels someone else’s economy.

So the question we need to ask ourselves is: how do we finally close the gap between research and commercialization, and make sure Canada reaps the rewards of its own innovation? | 8 | 5 | 1 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.756Z |  | 2025-09-15T22:39:10.679Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7372373268193996800 | Text |  |  | Truck drivers deserve better than this.

I was reading an article by Stephen Laskowski, President and CEO of the Canadian Trucking Alliance, and it highlighted something we often forget: trucking isn’t just about moving goods, it’s about moving lives forward. Families depend on those paycheques. Communities depend on those wheels turning.

Yet over 20,000 driver positions are sitting empty.

In one CTA survey, 36% of applicants said yes to working under the illegal “Driver Inc” model—not because they wanted to, but because they felt they had no choice.

Too many newcomers are being pushed into misclassified jobs that strip them of protections and drive wages back decades.

And the silence from Ottawa? A 14-year moratorium on enforcement that keeps the playing field tilted against honest workers and honest fleets.

This isn’t a future problem—it’s happening right now. And behind every stat is a person: someone who deserves dignity, fair pay, and the basic protections of our labour laws.

If we can’t stand up for the truckers who keep our shelves stocked and our economy moving, who will we stand up for? | 9 | 1 | 1 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.757Z |  | 2025-09-12T20:59:19.209Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7371581176395821058 | Text |  |  | Strong economies are built on strong care.

The lack of affordable, reliable child care doesn’t just impact parents — it ripples through our workforce, our communities, and ultimately, our economy.

According to Sarah Kaplan, Distinguished Professor at University of Toronto - Rotman School of Management and Susan Prentice, Professor of Sociology at the University of Manitoba, here's why it matters:

- Since 2021, the Canada-Wide Early Learning and Child Care agreements have dropped average fees by 40% to 75% in many provinces.

- Yet demand far exceeds supply, and families are still struggling to find spaces.

- Over 96% of early childhood educators are women, but the sector faces retention and recruitment challenges tied to low pay and limited career growth.

- Investing in care creates jobs, boosts tax revenues, and drives long-term economic and social outcomes for children, parents, and communities.

I believe child care isn’t just a social good — it’s economic infrastructure. Every dollar invested pays back in jobs, tax revenues, and stronger families. But more than that, it gives women the freedom to participate fully in the workforce, closing stubborn gaps in income and opportunity.

This isn’t abstract for me. I’ve watched talented colleagues — brilliant, ambitious people — have to step back from opportunities because care wasn’t there when they needed it. That’s a loss we can’t afford as a country.

If we want a more equal, more resilient Canada, strengthening the care economy must be part of our growth strategy.

How can we make sure child care is seen not as a cost, but as a cornerstone of Canada’s future? | 3 | 1 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.758Z |  | 2025-09-10T16:31:49.808Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7370989890261438464 | Text |  |  | Trust is the foundation of real climate progress.

After reading an article by Yingzhi Sarah Tang, Senior Research Associate of the Institute for Sustainable Finance (ISF) at Smith School of Business at Queen's University, I’ve been reflecting on how fragile—but also how important—that trust really is. 

Here are the key takeaways:

🌍 The voluntary carbon market was worth USD 4.04 B in 2024 and could surge to USD 23.99 B by 2030.

🏢 Buyers are no longer “checking a box”—they’re demanding high-quality, transparent credits tied to real impact.

🌲 Demand is shifting toward durable carbon removals (nature-based and engineered), though prices and trust remain hurdles.

📈 Canada has unique advantages—abundant natural resources, clean power, and strong innovation capacity—to lead in high-quality removals.

🔑 But without clearer governance, better standards, and credible verification, this market risks stalling when we need it most.

This isn’t just about markets—it’s about whether we can align finance with real solutions to climate change.

👉 What will it take for Canadians—and the world—to truly trust the carbon market as a tool for climate action? | 8 | 2 | 0 | 2mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.758Z |  | 2025-09-09T01:22:16.208Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7369858873890906114 | Text |  |  | As founders and leaders, the question we face is simple: Will Canada settle for fictional growth, or will we build genuine prosperity that future generations can actually thrive on?

For me, this is about redefining what real growth means. 

Not fictional wins on paper—but prosperity that my kids, and their kids, can actually live in.

According to Jury Gualandris, Associate Professor of Operations Management & Sustainability at Ivey Business School at Western University, we’ve been chasing efficiency for decades, but efficiency isn’t enough anymore. 

It’s time to move from less harm to real regeneration. 

Here’s what that looks like:

- Eco-efficiency isn’t eco-effectiveness. Cutting emissions or waste helps, but it doesn’t restore ecosystems or communities.

- The numbers don’t lie. In 2021, Canada ranked as the 2nd-largest per capita GHG emitter in the world at 17.7 metric tons per person.

- Nature shows us the blueprint. Ecosystems thrive by cycling resources endlessly, with no waste—businesses can, too.

- The future is regenerative. From zero-waste operations to circular supply chains, companies must design models that actively heal, not just avoid harm.

- Policy and finance must step up. Incentives should reward businesses that restore soil health, biodiversity, and ecosystems—not just those that reduce footprints.

So here’s the question I keep asking myself: Will Canada stay stuck in old definitions of success, or will we choose genuine, regenerative growth that leaves something better behind? | 9 | 4 | 1 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.759Z |  | 2025-09-05T22:28:00.892Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7369724343058120709 | Article |  | https://media.licdn.com/dms/image/v2/D4E12AQHzqyck8w_04g/article-cover_image-shrink_423_752/B4EZjpK5DKIMAU-/0/1756258604835?e=1766620800&v=beta&t=4lnrcJnrqc_fiylSOlov_mmZxr_IbU0l76E5SW4VaO8 | Super important piece by Fate Saghir, CPA of Mackenzie Investments.

War's toll on humans is uncountable. But what impacts does it have on the environment? How should we account for these? And how should we deal with companies who position themselves to profit from it?

Please share – the piece and your opinions. | 4 | 1 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.760Z |  | 2025-09-05T13:33:26.242Z | https://www.linkedin.com/pulse/when-sustainability-collides-conflict-fate-saghir-cpa-hleme |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7368773892212998145 | Text |  |  | I can’t stop thinking about this gap.

In 2022, Canada exported $2.47B in semiconductor products—but imported $7.18B. 

That’s not just a number. 

It’s a reminder that while Canadian researchers and entrepreneurs are building world-class innovations in quantum, photonics, and AI chips, we’re still not owning enough of the value chain.

According to Gordon Harling, President and CEO of CMC Microsystems, programs like FABrIC are starting to change that, giving startups and innovators the tools to scale smarter and faster.

But the truth is, if we don’t double down now, we risk watching our best ideas commercialized elsewhere.

For me, this isn’t only about chips—it’s about economic sovereignty. About whether Canada leads in the technologies that will define the next century.

How do we turn this momentum into true global leadership before the window closes? | 9 | 1 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.760Z |  | 2025-09-02T22:36:41.102Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7367312826660503552 | Text |  |  | No Canadian should have to wait years for a safe place to call home.

Yet according to Andrea Nemtin (M.S.M.), CEO of Social Innovation Canada, here’s the reality we’re facing:

- Nearly 246,000 households are on subsidized housing waitlists, most for two years or more.
- 1 in 10 Canadians is living in poverty.
- And every climate disaster adds more pressure to families already on the edge.

These aren’t just statistics—they’re stories of neighbours, friends, and families trying to make ends meet. 

That’s why I believe in social innovation: bringing business, government, and communities together to stop treating these challenges as separate problems and start building solutions that actually last.

I know this won’t be easy. But if we’re serious about prosperity, resilience, and equity, we need to move now.

How do we shift from conversations about poverty and housing to real action that changes lives? | 5 | 2 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.761Z |  | 2025-08-29T21:50:55.929Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7366621031446274048 | Text |  |  | Canada’s productivity slide worries me deeply.

When I saw that labour productivity in 2023 dropped 1.8%—the worst in the OECD - OCDE—it hit home. 

It wiped out every gain we’ve made since 2017.

For me, productivity isn’t just a metric. It’s about whether we can give our kids good jobs, whether small businesses can scale globally, and whether Canada can compete in a world that won’t wait for us to catch up.

Some great insights from Doug Heintzman, Chief Catalyst of BRI Blockchain Research Institute: 

👉 Our growth has lagged at 0.8% a year for two decades, while peers moved twice as fast.

👉 Falling behind means losing investment, innovation, and opportunities that should be ours.

👉 Turning this around requires bold leadership, not tweaks at the edges.d in a world where innovation and efficiency define success.

As a founder, I know that building systems that unlock people’s potential is the real engine of productivity. That’s how we compete. That’s how we thrive.

The question is: what bold steps will Canada take now to reverse this trend? | 10 | 3 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.762Z |  | 2025-08-28T00:01:59.097Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7365885466333564930 | Text |  |  | Climate targets don’t mean much if we miss them.

BC has long been seen as a climate leader, but the reality is sobering:

👉 Transportation alone accounts for 40% of BC’s total emissions.

👉 Despite billions invested, BC is on track for only a 20% reduction by 2030, not the promised 40%.

👉 Rural and resource-based regions carry a disproportionate burden while climate disasters cost the province billions each year.

👉 Current policies remain siloed—missing the chance to align climate goals with economic growth, social well-being, and regional development.

According to Tamara Krawchenko, Associate Professor of the University of Victoria, we need to treat climate action as territorial development if we want durable, inclusive progress.

We have to build a future where every region and community in BC feels part of the solution. 

Climate policy has to be more than “green goals.” It has to be territorial development: grounded in people, place, and prosperity.

Do you think BC is ready to lead again by putting “place” at the centre of its climate strategy? | 9 | 2 | 1 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.762Z |  | 2025-08-25T23:19:06.708Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7364497162849746944 | Text |  |  | Canada’s future depends on its entrepreneurs.

As a founder, I’ve seen firsthand how ambition, innovation, and resilience can drive growth—not just for a single company, but for our country.

Here’s what I’ve learned from TheFutureEconomy.ca’s new Future in Focus on #WorldEntrepreneurs’Day:

- Empowering founder-led innovation to make Canada a true global leader.
- Keeping ownership in Canadian hands instead of giving our future away.
- Making entrepreneurship accessible through capital, mentorship, and supportive policies.
- Closing the productivity gap by equipping SMEs with trusted, practical AI tools.
- Driving jobs and growth through a thriving entrepreneurial ecosystem that competes globally.

I believe Canada is already an incredible place to build—but with the right systems, support, and vision, we can go so much further.

What do you think Canada needs most right now to unleash its next generation of entrepreneurs?

Check out the new Future In Focus at the link below, featuring op-eds from:

- Rachel Rodrigues, Program Director of EY Canada Entrepreneur Of The Year
- Allen Lau, Co-Founder and Operating Partner of Two Small Fish, and Praveen K. Principal of Varshney Capital Corp.
- Shael Weinreb, Founder and CEO of The Home Equity Partners
- Cinzia Bazzo, Managing Director of Sage Canada
- Peter-Paul Van Hoeken, Founder and CEO of FrontFundr

#WorldEntrepreneursDay #Entrepreneurship #FutureLeaders #Startup #SMEs #Founders #CanadianTalent #FutureInFocus | 8 | 2 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.764Z |  | 2025-08-22T03:22:29.364Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7364397305472405505 | Text |  |  | We all want a secure food future.

But here’s the truth: for Indigenous communities, food insecurity is 5–6 times higher than the national average. 

That’s not just a statistic—it’s a crisis we can’t keep ignoring.

What gives me hope is seeing Indigenous farmers, harvesters, and entrepreneurs revitalizing food systems across the country—rooted in traditional knowledge, but also powered by innovation.

I enjoyed reading Kallie Wood, President & CEO of the NCIAF’s piece on this topic. 

From wild rice to aquaponics, she highlighted that these solutions aren’t “alternatives.” They’re some of the smartest paths forward.

When we invest in Indigenous food systems, we’re not just addressing hunger—we’re creating jobs, restoring ecosystems, and building resilience for future generations. 

This isn’t charity. It’s smart nation-building.

The question is: what will it take for Canada to finally treat Indigenous food systems as essential infrastructure, not side projects? | 6 | 2 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.764Z |  | 2025-08-21T20:45:41.510Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7363367723109634049 | Text |  |  | We all want better public services in Canada.

That’s why I believe AI can’t just be about cost-cutting—it has to be about people.

I just read Graham 📊 Dobbs, Senior Research Associate of The Conference Board of Canada’s op-ed, and he makes a few important points about AI:

- Used strategically, AI could add 1.97% to our GDP.
- It can free public servants from repetitive tasks so they can focus on the human side of their work—empathy, judgment, creativity.
- But if we get it wrong, we risk eroding trust instead of building it.

I’m convinced AI can make government more responsive and transparent. 

The real question is: how do we make sure AI empowers people instead of replacing them? | 4 | 2 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.765Z |  | 2025-08-19T00:34:29.946Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7362212687998566401 | Text |  |  | Canada can’t afford to waste potential.

According to Alvaro Santos Pereira, Chief Economist and G20 Finance Deputy of the OECD - OCDE, and Katja Schmidt, Senior Economist and Head of the Canada Desk of OECD - OCDE’s Economics Department, we’re leaving too much on the table.

In the past eight years, Canada’s labour productivity has grown just 0.8% a year—lagging far behind our peers.

Over 30% of immigrants with university degrees are in jobs that don’t use their skills.

Barriers to innovation, investment, and interprovincial trade keep businesses from reaching their potential.

I know Canada has the talent, ideas, and drive to do better. 

So why aren’t we using all we’ve got? | 2 | 4 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.766Z |  | 2025-08-15T20:04:48.116Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7360787694437748739 | Text |  |  | Menopause shouldn’t force women to step back.

Too many brilliant, experienced women have been sidelined.

Not because they’ve lost their skills, but because they didn’t get the support they needed during menopause.

Janet Ko, President and Co-Founder of the Menopause Foundation of Canada, presents some important stats in her article:

- Women aged 45–55 are the fastest-growing segment of Canada’s workforce—yet most workplaces offer little to no support during menopause.
- One in two women feel unprepared for menopause, blindsided by symptoms affecting their health, focus, and confidence.
- The result? A $3.5 billion annual hit to the economy from lost productivity and missed work.

With better education, healthcare training, and workplace inclusion, we can keep experienced, talented women thriving in their roles.

If we can support women in this, why wouldn’t we? | 39 | 2 | 4 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.766Z |  | 2025-08-11T21:42:23.176Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7359654831210328064 | Text |  |  | Strong financials and strong values go hand in hand.

A McKinsey & Company study found that companies excelling in revenue growth, profit, and ESG are over 50% more likely to achieve 10%+ annual revenue growth.

In other words—doing right by the planet and society isn’t just good ethics. It’s good business.

For Canadian companies, this means one thing: prove your environmental, social, and governance performance, and you open the door to massive new opportunities.

According to Alex Todorovic, CEO and Co-Founder of Arbor, if Canadian companies want to lead in the low-carbon economy, the path forward is clear:

- Build profitability with purpose

- Invest in real, measurable ESG results

- Treat sustainability as a growth strategy, not a checkbox

Do you think most businesses see ESG as a cost or as an opportunity? | 4 | 2 | 0 | 3mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.767Z |  | 2025-08-08T18:40:47.535Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7358937238308577281 | Text |  |  | Clean energy should be Canada's next legacy.

We’re sitting on an opportunity that could define our energy future—and we’re not starting from scratch. 

According to Emily Smejkal, Fellow of Cascade Institute, here's what you need to know:

- Geothermal energy offers zero-emission, 24/7 baseload power.

- Canada has the terrain, talent, and tools—but no national strategy.

- 80% of geothermal’s workforce and investment needs already exist in our oil and gas sector.

- Globally, this is a $1 trillion opportunity by 2035—and we’re falling behind.

- A national policy, new R&D authority (GEOSTRA), and investment signals could jumpstart a homegrown industry.

This isn’t just about power. It’s about prosperity, energy sovereignty, and clean growth that builds on what Canada already does best.

Will we lead—or be left buying tech we could’ve built? | 6 | 1 | 0 | 4mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.768Z |  | 2025-08-06T19:09:20.055Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7358276740919554049 | Text |  |  | Clean energy should power Canadian innovation.

Here’s the truth I keep coming back to:

If we get the grid right, we don’t just enable the energy transition—we unlock a whole new chapter of Canadian prosperity.

Josh Wong, Founder & CEO of ThinkLabs AI, Inc., makes some great points:

⚡ Canada already has one of the world’s cleanest electricity systems—80% non-emitting.

🤖 Pair that with world-class AI talent, and we’re sitting on a massive opportunity: AI-powered smart grids.

📉 But much of our infrastructure is aging, slow, and not built for what’s coming next.

🌐 AI can help us plan, optimize, and operate the grid in real time—saving money, reducing emissions, and boosting industrial productivity.

💡 This isn’t just tech—it’s a new national advantage. Think energy security, exportable IP, and jobs in every province.

We have the tools. We have the talent.

Now the question is: Will we move fast enough to lead? | 8 | 2 | 0 | 4mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.768Z |  | 2025-08-04T23:24:45.206Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7357076129544892416 | Text |  |  | Electric vehicle growth shouldn’t strain the grid.

If we’re serious about hitting EV targets, we need smarter infrastructure solutions—not just more expensive ones.

Here’s where Edward Chiang, Chief Executive Officer at Moment Energy, sees real opportunity:

- Retired EV batteries still hold 60–80% of their storage power.
- Repurposing them into on-site battery energy storage systems (BESS) helps lower charging costs, ease demand spikes, and reduce grid strain.
- Globally, reusing just half of the 14 million projected end-of-life EV batteries by 2040 could create 3,000 GWh of energy storage capacity.

This isn’t just smart climate policy—it’s good business. Repurposed batteries turn a liability into a long-term asset.

So the question is:

Will we let aging batteries become scrap—or turn them into the engine of our energy future? | 4 | 1 | 1 | 4mo | Post | Tim Penketh | https://www.linkedin.com/in/tim-penketh-622ab8114 | https://linkedin.com/in/tim-penketh-622ab8114 | 2025-12-08T04:59:51.769Z |  | 2025-08-01T15:53:57.148Z |  |  | 

---



---

# Tim Penketh
*TheFutureEconomy.ca*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [TheFutureEconomy.ca Podcast](https://podcasts.apple.com/ca/podcast/thefutureeconomy-ca-podcast/id1484252467)
*2025-05-14*
- Category: podcast

### [TheFutureEconomy.ca - Defining Canada's Economic Issues and Solutions](https://thefutureeconomy.ca/about-us/)
*2025-02-04*
- Category: article

### [Emission Reduction in Canada’s Future Energy Economy - TheFutureEconomy.ca](https://thefutureeconomy.ca/interviews/glen-murray/)
*2024-03-21*
- Category: article

### [Spotlight on the Impact Economy - TheFutureEconomy.ca](https://thefutureeconomy.ca/spotlights/impact-economy/)
*2024-02-28*
- Category: article

### [Sustainability and Economic Growth – The Roles of Policy and Finance - TheFutureEconomy.ca](https://thefutureeconomy.ca/interviews/mark-carney-brookfield-united-nations-sustainability-economic-growth-policy-finance/)
*2025-04-08*
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 20,612 words total*

### TheFutureEconomy.ca Podcast
*1,730 words* | Source: **EXA** | [Link](https://podcasts.apple.com/ca/podcast/thefutureeconomy-ca-podcast/id1484252467)

1.   [OCT 8 ### Canada's Food System Revolution | Dana McCauley, Marie-Claude Bourgie, Nick Betts and David Hughes Canada stands at a turning point in building a food system that is both affordable and sustainable. In this episode of The Wicked Solutions Series presented by Generate Canada and Farm Credit Canada, Dana McCauley, CEO, Canadian Food Innovation Network, Marie-Claude Bourgie, VP Sustainability, Farm Credit Canada, Nick Betts, Managing Director, Canadian Alliance for Net Zero Agri-food, and David Hughes, President & CEO, Generate Canada, explore how redefining agricultural productivity, scaling agri-tech innovation, and investing in infrastructure and trade can unlock resilience and growth. Discover the financing shifts, data strategies, and national vision needed to help food-tech ventures scale, strengthen supply chains, and reduce food inflation for Canadians. Read the full interview and key takeaways: https://thefutureeconomy.ca/interviews/how-to-build-affordable-sustainable-food-system-for-canada/ Explore the series here: https://thefutureeconomy.ca/content-series/the-wicked-solutions-series/ Watch more videos from the series: https://youtube.com/playlist?list=PL2vcORABmSd7wk6rWKoc2d9Jxp-RCnHTL&si=irLK6XaO0iwRs3o3 Subscribe for exclusive previews of upcoming episodes and updates on new releases: https://bit.ly/3ri2IUu Follow us on social media: https://linkin.bio/thefutureeconomy.ca ===== About TheFutureEconomy.ca ===== TheFutureEconomy.ca is a Canadian online media outlet and thought leadership platform that produces interviews, panels and op-eds featuring leaders from industry, government, academia and more to define a strong vision for our future economy. Our content emphasizes our interviewees’ insights and calls-to-action on what we must do now to improve the competitiveness and sustainability of Canada’s future economy. Check out our website: https://thefutureeconomy.ca/ #WickedSolutions #FutureOfFood #RegenerativeFarming #SustainableAg #CanadaAg #FoodInnovation #AgriFood #NetZeroAg #GlobalTrade 36 min](https://podcasts.apple.com/ca/podcast/canadas-food-system-revolution-dana-mccauley-marie/id1484252467?i=1000730864530) 
2.   [SEP 24 ### Why Climate Readiness Matters Now | Don Iveson, Hillary Thatcher, Priya Bala-Miller, David Hughes Canada faces an urgent test of resilience. In this episode of The Wicked Solutions Series presented by Generate Canada and Co-operators, Don Iveson, Executive Advisor of Climate Investing & Community Resilience at Co-operators, Hillary Thatcher, Managing Director of Investments at Canada Infrastructure Bank, Priya Bala-Miller, Managing Director of Nature Investment Hub, and David Hughes, President & CEO of Generate Canada, explore how climate-ready investments can safeguard infrastructure, protect communities, and strengthen long-term prosperity. From managing transition and physical climate risks to embedding Indigenous leadership in infrastructure design, the path forward requires systemic collaboration, smarter financing, and resilient planning to withstand tomorrow’s storms today. Read the full interview and key takeaways: https://thefutureeconomy.ca/interviews/arctic-ottawa-investing-climate-resilience-too-late/ Explore the series here: https://thefutureeconomy.ca/content-series/the-wicked-solutions-series/ Watch more videos from the series: https://youtube.com/playlist?list=PL2vcORABmSd7wk6rWKoc2d9Jxp-RCnHTL&si=irLK6XaO0iwRs3o3 Subscribe for exclusive previews of upcoming episodes and updates on new releases: https://bit.ly/3ri2IUu Follow us on social media: https://linkin.bio/thefutureeconomy.ca ===== About TheFutureEconomy.ca ===== TheFutureEconomy.ca is a Canadian online media outlet and thought leadership platform that produces interviews, panels and op-eds featuring leaders from industry, government, academia and more to define a strong vision for our future economy. Our content emphasizes our interviewees’ insights and calls-to-action on what we must do now to improve the competitiveness and sustainability of Canada’s future economy. Check out our website: https://thefutureeconomy.ca/ #WickedProblems #ClimateResilience #WickedSolutions #ClimateDisasters #TheFutureEconomy #ClimateChange #ClimateInvesting #CanadianLeadership #CanadianInfrastructure 42 min](https://podcasts.apple.com/ca/podcast/why-climate-readiness-matters-now-don-iveson-hillary/id1484252467?i=1000728252552) 
3.   [AUG 13 ### Regenerative Agriculture Is Canada’s Big Bet | Dan Lussier, Craig Klemmer, Nick Betts, David Hughes Canada’s agricultural future hinges on productivity, resilience, and innovation. In this episode of The Wicked Solutions Series, presented by Generate Canada and Farm Credit Canada, Dan Lussier, Former Director of Canadian Agri-Food Data Initiative, Craig Klemmer, Principal Economist at Farm Credit Canada, Nick Betts, Managing Director of Canadian Alliance for Net-Zero Agri-food, and David Hughes, President and CEO of Generate Canada, explore how regenerative 

*[... truncated, 10,519 more characters]*

---

### TheFutureEconomy.ca - Defining Canada's Economic Issues and Solutions
*1,018 words* | Source: **EXA** | [Link](https://thefutureeconomy.ca/about-us/)

TheFutureEconomy.ca - Defining Canada's Economic Issues and Solutions

===============

[Skip to content](https://thefutureeconomy.ca/about-us/#content)

[![Image 7](https://thefutureeconomy.ca/wp-content/themes/tfe/img/tfe-logo-sm-b-en.svg)TheFutureEconomy.ca](https://thefutureeconomy.ca/)

*   [Topics](https://thefutureeconomy.ca/topics/)
    *   [Agriculture](https://thefutureeconomy.ca/topics/agriculture/)
    *   [Artificial Intelligence](https://thefutureeconomy.ca/topics/ai/)
    *   [Building and Infrastructure](https://thefutureeconomy.ca/topics/building-the-future/)
    *   [Cleantech](https://thefutureeconomy.ca/topics/cleantech/)
    *   [Crypto and Blockchain](https://thefutureeconomy.ca/topics/crypto/)
    *   [Digital Transformation and Tech](https://thefutureeconomy.ca/topics/digital-transformation/)
    *   [Diversity, Equity and Inclusion](https://thefutureeconomy.ca/topics/diversity-equity-and-inclusion/)
    *   [Education](https://thefutureeconomy.ca/topics/education/)
    *   [Energy](https://thefutureeconomy.ca/topics/energy/)
    *   [Entrepreneurship](https://thefutureeconomy.ca/topics/entrepreneurship/)
    *   [Finance](https://thefutureeconomy.ca/topics/finance/)
    *   [Future of Work](https://thefutureeconomy.ca/topics/future-of-work/)
    *   [Healthcare](https://thefutureeconomy.ca/topics/healthcare/)
    *   [Impact](https://thefutureeconomy.ca/topics/impact/)
    *   [Indigenous Economy](https://thefutureeconomy.ca/topics/indigenous-economy/)
    *   [Life Sciences](https://thefutureeconomy.ca/topics/life-sciences/)
    *   [Macroeconomics](https://thefutureeconomy.ca/topics/macroeconomics/)
    *   [Natural Resources](https://thefutureeconomy.ca/topics/natural-resources/)
    *   [Research and Innovation](https://thefutureeconomy.ca/topics/research/)
    *   [Tariffs](https://thefutureeconomy.ca/topics/tariffs/)

*   [Expert Series](https://thefutureeconomy.ca/content-series/)
*   [Spotlights](https://thefutureeconomy.ca/spotlights/)
*   [Featured Interviews](https://thefutureeconomy.ca/interviews/)
*   [Future in Focus](https://thefutureeconomy.ca/future-in-focus/)
*   [Op-Eds](https://thefutureeconomy.ca/op-eds/)
*   [Panels](https://thefutureeconomy.ca/panels/)
*   [Subscribe to Newsletter](https://thefutureeconomy.ca/newsletter/)

Search Menu

Search

About Us
========

Defining Canada’s Future Economy
--------------------------------

_TheFutureEconomy.ca_ is a Canadian online media outlet and thought leadership platform that produces interviews, op-eds and video reports featuring leaders from industry, government, academia and more to define a strong vision for our future economy.

Our content is focused on the individuals, organizations, forces and industries shaping our nation’s economic future, with an emphasis on our experts’ insights and calls-to-action on what we must do now to improve the competitiveness and sustainability of Canada’s future economy.

![Image 8](https://thefutureeconomy.ca/wp-content/uploads/2021/05/Logo-Breakdown.png)

Vision
------

Canadians are inspired to define and rally around a bold vision for Canada’s future economy.

Mission
-------

To define Canada’s future economy by building the premier forum for leaders to engage Canadians with thought-provoking insights and calls-to-action on key economic issues. And to empower Canadians with a bold national vision of an inclusive, innovative, sustainable and world-leading future economy.

Our Logo
--------

### The Shape

The logo’s twisting circular shape, inspired by the never-ending Mobius, represents a sustainable economy encompassing industry and all elements of the environment – people included. The merging, interconnectedness and balance between the various components represents continuity in an economy cycling towards sustainable growth and prosperity.

### The Gradients

The colours and gradients used in our logo represent industry, the different natural resources, the elements, people and society that are affected by our economic activities, and upon which our economy rests. Each of these components must be considered in any decision related to what we want our future economy to be, and how we are to execute our transition towards it.

* * *

Diversity and Inclusion Statement
---------------------------------

TheFutureEconomy.ca is committed to amplifying diverse voices, including women, racialized people, Indigenous communities, LGBTQ2S+ individuals, and other underrepresented groups. We believe diversity strengthens Canada’s society and economy, and we pledge to reflect this in our content.

This is an ongoing commitment, and we welcome feedback at office@TheFutureEconomy.ca to help us improve and uphold this mission.

Team
----

![Image 9: tim-penketh](https://thefutureeconomy.ca/wp-content/uploads/2017/03/b1dbb939e52c482091b1fa282b2ff593.jpg)

Tim Penketh

Founder & CEO

 Bio 

![Image 10](https://thefutureeconomy.ca/wp-content/uploads/2024/11/1555609806810-300x300.jpg)

Doroth

*[... truncated, 5,384 more characters]*

---

### Emission Reduction in Canada’s Future Energy Economy - TheFutureEconomy.ca
*2,149 words* | Source: **EXA** | [Link](https://thefutureeconomy.ca/interviews/glen-murray/)

Published on January 22, 2018

Takeaways
---------

1.   Right now, Canada is not on track to meet its 2030 targets, however we are making progress, especially at the provincial level.
2.   There are two Canadas when it comes to climate change: On one hand, Ontario and Quebec are the only two jurisdictions in North America that are significantly below 1990 emission levels. On the other, emissions are going up in most other parts of Canada.
3.   If Alberta retools its fossil fuel expertise into a new suite of low carbon technologies, there is a very exciting future for the province given its incredible competence in energy development.

Action
------

One strategy that could dramatically alter emissions in our nation is the retrofitting of all Canadian buildings as net zero structures. This would not only combat climate change but would also be the biggest job creation project in the history of Canada.

* * *

### How is Canada performing with respect to its international carbon reduction commitments and what has been their economic impact so far?

We are not, right now, on track to meet our 2030 commitments in the Paris Agreement. That being said, we have been making more progress recently, especially on the provincial level. Real leadership is emerging in Alberta and British Columbia under newer governments with much stronger commitments to climate change. Even Manitoba’s conservative government – a party that has been hesitant to get involved in environmental politics – is stepping up with a price on carbon. The Quebec and Ontario economies, along with the California regional economy, are probably the three strongest economies in the Americas right now. All three were early adapters of carbon pricing. Toronto is outpacing New York and Chicago in construction. Ontario’s unemployment rate is at a record low after coming out of a recession. In fact, if Ontario were a G7 country, it would be leading the G7 in economic growth.

These jurisdictions are proving what is right for the environment is also right for the economy. This high alignment is not just because of carbon pricing either. It represents those jurisdictions that are most heavily invested in the new economy and have implemented the most progressive platform for change. They are reaping the early benefits of higher job growth rates, greater levels of investment in the economy, more direct foreign investment and increased government revenues. California, Ontario and Quebec have seen real growth in their revenues as well, not from growing the tax burden, but by growing their tax base. Overall, there is cause for cautious optimism in Canada. Still, we have a lot more work to do to align our public policy, business leadership and behaviour to achieve our 2030 targets.

* * *

### What is necessary for overall Canadian emissions to begin to decline?

There are two Canadas when it comes to climate change. There is Ontario and Quebec, which are the only two jurisdictions in North America that are significantly below 1990 emission levels. Certainly, coal plant closures in Ontario were the most significant contributor to that reduction. In most other parts of Canada, however, emissions are going up. The challenge is creating a carbon pricing system across the country that is rigorous enough to actually deliver results. Can a cap-and-trade system, the litmus test for emissions reduction, have a reduction rate steep enough to meet the federal government’s 2030 targets? If Ontario, Quebec and Nova Scotia, the provinces that use the cap-and-trade system, do not keep their cap decline rates at 3% or 4% they will not meet federal reduction targets. That is much higher than most other jurisdictions that are at a 1-2% range. Ontario’s current reduction rate is 4.3% per year, which is about the steepest in the world. Quebec is going to have to keep a reduction rate fairly comparable to that, as will California, otherwise the cap-and-trade system starts to become greenwashing.

For hybrid systems like Alberta or tax systems like Manitoba, the tax per ton rate will have to be in the $70 to $90 range according to economists like Dave Sawyer. It would certainly have to be much higher than the $50 floor price backstop the federal government has implemented. If you only have a $10 to $30 carbon tax that is essentially greenwashing too, because you have a tax but it is so light it is inconsequential. Part of the challenge with the carbon tax system is you have to have politicians set the rate. In a cap-and-trade system, you can get reductions at $18 or $20 a ton because you have a cap and cap decline rate. But with a tax system that does not have a cap, you are relying only on price to drive reduction. That means a very significant spike in gas prices, which is very unattractive to politicians. Outside of Norway, there is no legislature or parliament in the world that has come anywhere near setting a tax rate high enough to make a difference. In order for either of these e

*[... truncated, 7,951 more characters]*

---

### Spotlight on the Impact Economy - TheFutureEconomy.ca
*770 words* | Source: **EXA** | [Link](https://thefutureeconomy.ca/spotlights/impact-economy/)

Spotlight on the Impact Economy - TheFutureEconomy.ca

===============

[Skip to content](https://thefutureeconomy.ca/spotlights/impact-economy/#content)

[![Image 2](https://thefutureeconomy.ca/wp-content/themes/tfe/img/tfe-logo-sm-b-en.svg)TheFutureEconomy.ca](https://thefutureeconomy.ca/)

*   [Topics](https://thefutureeconomy.ca/topics/)
    *   [Agriculture](https://thefutureeconomy.ca/topics/agriculture/)
    *   [Artificial Intelligence](https://thefutureeconomy.ca/topics/ai/)
    *   [Building and Infrastructure](https://thefutureeconomy.ca/topics/building-the-future/)
    *   [Cleantech](https://thefutureeconomy.ca/topics/cleantech/)
    *   [Crypto and Blockchain](https://thefutureeconomy.ca/topics/crypto/)
    *   [Digital Transformation and Tech](https://thefutureeconomy.ca/topics/digital-transformation/)
    *   [Diversity, Equity and Inclusion](https://thefutureeconomy.ca/topics/diversity-equity-and-inclusion/)
    *   [Education](https://thefutureeconomy.ca/topics/education/)
    *   [Energy](https://thefutureeconomy.ca/topics/energy/)
    *   [Entrepreneurship](https://thefutureeconomy.ca/topics/entrepreneurship/)
    *   [Finance](https://thefutureeconomy.ca/topics/finance/)
    *   [Future of Work](https://thefutureeconomy.ca/topics/future-of-work/)
    *   [Healthcare](https://thefutureeconomy.ca/topics/healthcare/)
    *   [Impact](https://thefutureeconomy.ca/topics/impact/)
    *   [Indigenous Economy](https://thefutureeconomy.ca/topics/indigenous-economy/)
    *   [Life Sciences](https://thefutureeconomy.ca/topics/life-sciences/)
    *   [Macroeconomics](https://thefutureeconomy.ca/topics/macroeconomics/)
    *   [Natural Resources](https://thefutureeconomy.ca/topics/natural-resources/)
    *   [Research and Innovation](https://thefutureeconomy.ca/topics/research/)
    *   [Tariffs](https://thefutureeconomy.ca/topics/tariffs/)

*   [Expert Series](https://thefutureeconomy.ca/content-series/)
*   [Spotlights](https://thefutureeconomy.ca/spotlights/)
*   [Featured Interviews](https://thefutureeconomy.ca/interviews/)
*   [Future in Focus](https://thefutureeconomy.ca/future-in-focus/)
*   [Op-Eds](https://thefutureeconomy.ca/op-eds/)
*   [Panels](https://thefutureeconomy.ca/panels/)
*   [Subscribe to Newsletter](https://thefutureeconomy.ca/newsletter/)

Search Menu

Search

Spotlight on the Impact Economy
===============================

[Impact](https://thefutureeconomy.ca/?s=Impact)[Entrepreneurship](https://thefutureeconomy.ca/?s=Entrepreneurship)[Policy](https://thefutureeconomy.ca/?s=Policy)

![Image 3: marc-andre-blanchard-canada-united-nations-un-sdg-business-private-sector-1-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Marc-Andre-Blanchard-Canada-United-Nations-UN-SDG-Business-Private-Sector-1-Cropped-100x100.jpg)

Marc-André Blanchard

Canada’s Ambassador and Permanent Representative to the UN

Canada’s Permanent Mission at the UN

![Image 4: helle-bank-jorgensen-un-sdg-boards-canada-economy-2-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Helle-Bank-Jorgensen-UN-SDG-Boards-Canada-Economy-2-Cropped-100x100.jpg)

Helle Bank Jorgensen

Founder & CEO

Competent Boards

![Image 5: paul-allard-impak-finance-sdg-canada-economy-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Paul-Allard-Impak-Finance-SDG-Canada-Economy-Cropped-100x100.jpg)

Paul Allard

Co-Founder and Chief Ecosystem Officer

Impak Finance

![Image 6: dustyn-lanz-responsible-investment-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Dustyn-Lanz-Responsible-Investment-Cropped-100x100.jpg)

Dustyn Lanz

CEO

Responsible Investment Association

Published on April 29, 2019 February 28, 2024

 Watch and Read the Experts’ Full Interviews: 

*   [![Image 7: social-impact-5-cropped-2](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Social-Impact-5-Cropped-2-720x390.jpg) Canada’s Private Sector Needed to Achieve SDGs ![Image 8: Small thumbnail of Marc-André Blanchard](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Marc-Andre-Blanchard-Canada-United-Nations-UN-SDG-Business-Private-Sector-1-Cropped-200x200.jpg)Marc-André Blanchard Canada’s Ambassador and Permanent Representative to the UN Canada’s Permanent Mission at the UN Impact Strategy Sustainability](https://thefutureeconomy.ca/spotlights/impact-economy/marc-andre-blanchard/)
*   [![Image 9: social-impact-3-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Social-Impact-3-Cropped-720x390.jpg) The Power of Leading with Purpose ![Image 10: Small thumbnail of Helle Bank Jorgensen](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Helle-Bank-Jorgensen-UN-SDG-Boards-Canada-Economy-2-Cropped-200x200.jpg)Helle Bank Jorgensen Founder & CEO Competent Boards Women Leaders Impact Sustainability](https://thefutureeconomy.ca/spotlights/impact-economy/helle-bank-jorgensen/)
*   [![Image 11: social-impact-cropped](https://thefutureeconomy.ca/wp-content/uploads/2019/04/Social-Impact-Cropped-

*[... truncated, 6,436 more characters]*

---

### Sustainability and Economic Growth – The Roles of Policy and Finance - TheFutureEconomy.ca
*1,677 words* | Source: **EXA** | [Link](https://thefutureeconomy.ca/interviews/mark-carney-brookfield-united-nations-sustainability-economic-growth-policy-finance/)

Published on July 7, 2022

Takeaways
---------

1.   Policymakers must develop the intangible finance ecosystem through regulations for intellectual property protection, data portability and decentralized finance.
2.   Canada must continue to build out its financial system for the net-zero transition.
3.   Canada needs clear and deep decarbonization policies as this will help drive investment over the next decades.

Action
------

Policymakers and financial institutions in Canada have important roles to play in the advancement of Canada’s future economy and they must adapt to the changing economy by creating the right policies and investments for our fastest-growing sectors.

* * *

### **What must be done in terms of policy, regulation, finance and investment in Canada to adapt to our changing economy?**

I will suggest two on the policy and finance side. Both relate to the changing nature of our economies and many economies around the world. The first is in and around the nature of data and digital services. The nature of investments has shifted quite substantially over the course of the last 30 years or so, more away from tangible investments into investments in intangibles like ideas, goodwill, marketing, processes and all those aspects.

It is much easier to raise money against a physical asset such as a building or against a plant and machinery. It provides a degree of comfort and protection for the bank. It is much harder to lend against intangibles even though intellectual property (IP) is the one that is primarily increasing the economy’s competitiveness.

The good news is that part of the changing nature of the economy provides part of the solution to the problem. Many Canadian companies such as [Shopify](https://www.shopify.com/about) are at the forefront of this. Canadian companies are using the rich data that exists to provide better predictiveness of viability, allowing investors to lend to them earlier. Banks and investors can lend more and help these companies grow more rapidly.

We need to grow that whole ecosystem around intangible finance and the financing of small entrepreneurial businesses. We need to look at intellectual property protection, data portability and the development of decentralized finance in rapid order. I put a tremendous emphasis on rapidly growing that ecosystem because many companies and innovators need to access capital from the ecosystem. Also, that ecosystem is not just relevant to Canada. It has global applications. Canada is good in finance and if we really focus our mindset, we can build it out.

The other big block I would focus on is that Canada must continue to build out its financial system for the net-zero transition. It starts with disclosure and it includes tools such as stress testing and looking at how well-aligned companies are to the transition. We need to get capital to the innovators, businesses and people with the ideas on how to get emissions down. A financial system that is oriented to that combined with what the public wants and public policy can really accelerate innovation and growth in this country.

* * *

### **Which opportunity should Canada be focusing on to drive our future economy forward? What must we do to become leaders in this space?**

Canada can pick many, but I will pick only one and focus on the transition to net-zero. The net-zero transition is a $2 trillion investment opportunity in Canada over the course of the next couple of decades. It is about a $150 trillion investment opportunity around the world over the course of the next 25 years. Those are enormous numbers.

A third to a half of those numbers already lie in existing technologies that are applied at scale across our economy. That money is putting people to work in those fields. We can always do things better by saving more costs and being more efficient, and so there are definitely some innovative opportunities there.

But what is really exciting and necessary for our medium and longer-term success is focusing on the next wave of technology. These are technologies like hydrogen, carbon capture, storage and use as well as some elements of direct air capture. These are technologies that are close to being commercial and there are huge markets for them. They are hugely important for the development of the next phase of energy security and sustainability here in Canada.

Then, there is a final set of technologies such as small modular reactors, direct air capture and sustainable aviation fuels, which are more at the venture capital end of the spectrum.

A slice through all of this is artificial intelligence and machine learning, and the role they play in optimizing everything across the grid. Canada can also lead in that.

If something is going to cost an estimated $2 trillion in Canada and an estimated $150 trillion around the world, by definition it is an amazing opportunity. I challenge Canadian business innovators to focus on this area.

* * *

### **What policies and

*[... truncated, 5,540 more characters]*

---

### Press - Livestock Water Recycling, Inc.
*4,318 words* | Source: **GOOGLE** | [Link](https://www.livestockwaterrecycling.com/newsroom/press/)

Press - Livestock Water Recycling, Inc.

===============

[* ![Image 1](https://www.livestockwaterrecycling.com/media/home/livestock-logo-img.webp) * ![Image 2](https://www.livestockwaterrecycling.com/media/home/livestock-logo-text.webp)](https://www.livestockwaterrecycling.com/)

[BECOME A DEALER](https://www.livestockwaterrecycling.com/contact/become-a-dealer)

*   [](https://www.facebook.com/LWRinc)
*   [](https://twitter.com/LWR_Inc)
*   [](https://ca.linkedin.com/company/lwr)
*   [![Image 3: instagram circle](https://www.livestockwaterrecycling.com/media/icons/instagram-circle.png)](https://www.instagram.com/lwr_inc)
*   [](https://www.pinterest.com/lwrinc/)
*   [](https://www.youtube.com/channel/UCKLSQi8OWP6tuCHpCswMvFw)

*   [FAQ](https://www.livestockwaterrecycling.com/faq)
*   [MyPlant](https://manure.app/)

*   [Home](https://www.livestockwaterrecycling.com/)
*   [](https://www.livestockwaterrecycling.com/d51d7ee999cfbc57/)
*   [Our Story](https://www.livestockwaterrecycling.com/our-story/)

    *   [History](https://www.livestockwaterrecycling.com/our-story/history/)
    *   [Our Team](https://www.livestockwaterrecycling.com/our-story/our-team/)
    *   [Upcoming Events](https://www.livestockwaterrecycling.com/our-story/upcoming-events/)
    *   [Innovation Center](https://www.livestockwaterrecycling.com/our-story/innovation-center/)
    *   [Jenkins](https://www.livestockwaterrecycling.com/our-story/jenkins/)

*   [The System](https://www.livestockwaterrecycling.com/the-system/plant/)

    *   [Plant](https://www.livestockwaterrecycling.com/the-system/plant/)
    *   [First Wave](https://www.livestockwaterrecycling.com/the-system/first-wave/)
    *   [Renewable Natural Gas](https://www.livestockwaterrecycling.com/the-system/renewable-natural-gas/)

*   [Installations](https://www.livestockwaterrecycling.com/installations/)
*   [Manurewards](https://www.livestockwaterrecycling.com/manurewards/)
*   [Newsroom](https://www.livestockwaterrecycling.com/newsroom/featured/)

    *   [Featured](https://www.livestockwaterrecycling.com/newsroom/featured/)
    *   [Press](https://www.livestockwaterrecycling.com/newsroom/press/)

*   [Careers](https://www.livestockwaterrecycling.com/careers/why-work-with-us/)

    *   [Why Work With Us?](https://www.livestockwaterrecycling.com/careers/why-work-with-us/)
    *   [Current Job Openings](https://www.livestockwaterrecycling.com/careers/current-job-openings/)

*   [Contact](https://www.livestockwaterrecycling.com/contact/contact-us/)

    *   [Contact Us](https://www.livestockwaterrecycling.com/contact/contact-us/)
    *   [Request a Quote](https://www.livestockwaterrecycling.com/contact/quote/)
    *   [Become a Dealer](https://www.livestockwaterrecycling.com/contact/become-a-dealer/)

Press
-----

![Image 4: Foodbytes by Rabobank Features Livestock Water Recycling in 2024 EOY Report](https://www.livestockwaterrecycling.com/media/Rabobank.jpg)

### Foodbytes by Rabobank Features Livestock Water Recycling in 2024 EOY Report

**Livestock****Water Recycling is leading the charge in sustainable innovation, transforming agricultural waste into high-value resources for the circular economy.**

This year LWR systems have processed**over 1.5 billion gallons of manure and digestate**, resulting in**1.6 million metric tons of CO2e reductions**— equivalent to taking 349,000 cars off the road!

Read the full Foodbytes by Rabobank 2024 EOY Report[here](https://www.livestockwaterrecycling.com/media/EOY%20Report%20+%20Market%20Map_%20Harnessing%20Sustainable%20Business%20Models%20to%20Catalyze%20Growth%20(1).pdf).

![Image 5: Canadian Business Magazine Features Livestock Water Recycling](https://www.livestockwaterrecycling.com/media/newsroom/press/Website_Events.webp)[](https://www.canadianbusiness.com/sponsored/karen-schuett-strikes-entrepreneurial-gold/)

### [Canadian Business Magazine Features Livestock Water Recycling](https://www.canadianbusiness.com/sponsored/karen-schuett-strikes-entrepreneurial-gold/)

**Livestock Water Recycling has developed a way to transform animal manure into high-value products that can be sold into the circular economy**

It started with pigs. Or, more accurately, the “manure lagoon” they created on an Alberta hog farm. In search of help for this football field–sized problem, the local farmer reached out to Karen Schuett, who was running a water treatment business focused on groundwater that had been contaminated with hydrocarbons—organic chemicals found in oil, natural gas and coal.

Since then, LWR has started building a revenue model that is poised to transform the livestock sector. There are even predictions that manure could become more valuable to farmers than milk. “This new profit dynamic has the potential to make the industry more economically and environmentally robust,” says Schuett. It’s an unexpected twist, but Schuett is finding a way to spin manure into gold.

Check out the article [here](https://www.canadianbusiness.com/sponsore

*[... truncated, 46,005 more characters]*

---

### Supporting Canada’s Research Ecosystem - TheFutureEconomy.ca
*8,950 words* | Source: **GOOGLE** | [Link](https://thefutureeconomy.ca/panels/killam-prize-winner-supporting-canada-research-ecosystem/)

Published on May 17, 2022

_Le texte français suit[ci-dessous.](https://thefutureeconomy.ca/panels/killam-prize-winner-supporting-canada-research-ecosystem/#french)_

Takeaways
---------

1.   Research priorities that are solely focused on economic returns may result in research outcomes that do not benefit the populace. 
2.   With the wealth we have, Canada must play a bigger role in developing research capabilities worldwide. 
3.   A better research environment in Canada will help the country retain more of its research talent and perform better at commercializing research. 

Action
------

The Canadian government must provide more avenues for long-term funding for research in order to capitalize on research talent and ensure Canadian researchers are producing the best solutions for complex issues globally.

* * *

**Tim Penketh:**Welcome to our digital roundtable where we will be celebrating the accomplishments of researchers in Canada and exploring the future of Canada’s research ecosystem and its impacts on society and Canada’s future economy.Caroline Lussier, the Director for Arts Promotion for the Canada Council for the Arts, will introduce this session.

**Caroline Lussier:** Thank you for the introduction, Tim. It is a great pleasure to be here today to celebrate Canada’s most inspiring scholars. I would like to thank the [Killam Trusts](https://killamlaureates.ca/), the members of the Killam Selection Committee and our partner institutions for their contributions. This important program would not be possible without them.

The [Canada Council for the Arts](https://canadacouncil.ca/) is proud and honoured to have administered the Killam program for more than 50 years. This year, we are handing the baton to the [National Research Council of Canada (NRC)](https://nrc.canada.ca/en), which will take on the administration of the Killam Program going forward.

This marks an exciting new era for the Killam Program and we are very pleased to be part of this journey. This makes the 2022 cohort of researchers, the last to win the Killam Prize under the administration of the Canada Council, all the more special to us.

I hope you will enjoy spending some time with these amazing people in our panel discussion today. Thank you for being with us.

* * *

### **Esteemed panellists, thank you for being with us today. Please introduce yourselves and your area of focus.**

**Françoise Baylis:** I am a philosopher by training and I work on issues to do with human reproduction and the manipulation of the human embryo. Most recently, I am working on embryonic stem cell research and the study of induced pluripotent stem (iPS) cells, as well as on different ways of modifying the human genome.

My work is typically around the issues that are at the intersection of policy and practice. I deal with a lot of questions about research ethics but also questions about translational research as things move from the lab into clinical trials. Currently, most of my work is on human genome editing and the idea of making better humans, whatever that might mean to some people.

**Jeff Dahn:** I have been working in the area of rechargeable lithium batteries and lithium-ion batteries for 43 years, and my research group at the moment is supported through an [NSERC Alliance Grant](https://www.nserc-crsng.gc.ca/innovate-innover/alliance-alliance/index_eng.asp) with [Tesla](https://www.tesla.com/).

We have been associated with Tesla since 2016 and it has been quite an amazing ride. Tesla has a mission of helping the world transition to renewables and electrified transportation. They are the only company in the world that produces solar solutions, electric vehicles and grid energy storage products, all of which can get us where we need to go.

My research group is thrilled to have this opportunity to work with a world leader and help to improve the lithium-ion battery products that are used in their devices.

**Carl James:** My work is in the area of race and racialization. I am very keen on understanding how race informs the experiences of racialized youth and people in Canadian society. I also want to study how race informs the opportunities that they have access to and how they use those opportunities to survive and succeed in society.

Much of my research started with Black youth around 30 years ago. I was looking at how youths were trying to adjust to Canadian society. My focus was on how multiculturalism enables or disables the kind of opportunities and challenges they face.

From there, I started to pay attention to the experiences of racialized young people by looking at the [Canadian Census](https://www12.statcan.gc.ca/census-recensement/index-eng.cfm). One of my priorities is constantly revisiting people I interviewed in the past to find out whether over a period of time things have changed or remained the same for them. I am interested in the longitudinal aspect of people’s lives.

**Salim Yusuf:** I am a cardiologist. I started 

*[... truncated, 51,468 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Defining Canada's Economic Issues and ... - TheFutureEconomy.ca](https://thefutureeconomy.ca/about-us/)**
  - Source: thefutureeconomy.ca
  - *This is an ongoing commitment, and we welcome feedback at office@TheFutureEconomy.ca to help us improve and uphold this mission. Team. tim-penketh. Ti...*

- **[Press - Livestock Water Recycling, Inc.](https://www.livestockwaterrecycling.com/newsroom/press/)**
  - Source: livestockwaterrecycling.com
  - *Moderated by Tim Penketh, Founder & CEO, TheFutureEconomy.ca. DAIRY TECH START-UP SPOTLIGHT. On October 1st, 2020 dairy ......*

- **[Supporting Canada's Research Ecosystem - TheFutureEconomy.ca](https://thefutureeconomy.ca/panels/killam-prize-winner-supporting-canada-research-ecosystem/)**
  - Source: thefutureeconomy.ca
  - *May 17, 2022 ... Tim Penketh: Welcome to our digital roundtable where we will be ... TheFutureEconomy.ca 2025. Cookies · Privacy Policy · Terms and .....*

---

*Generated by Founder Scraper*
