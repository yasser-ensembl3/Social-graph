# Dov Punski

## Position actuelle

**Titre** : Co-Founder of DogPack App
**Entreprise** : DogPack
**Durée dans le rôle** : 4 years 3 months in role
**Durée dans l'entreprise** : 4 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Pet Services

## Description du rôle

Building the go-to platform for dog lovers, alongside my 3 brothers.

## Résumé

Starting out as a dog-walker, I identified a gap in the market and teamed up with my three brothers to build the solution.

Founded in 2021, the DogPack platform has become the go-to app for over 1 million users worldwide, connecting dog owners and lovers alike. Our mission is simple: to create a community where every dog and their human feel welcome, supported, and inspired.

Through DogPack, we’ve built more than just a tech product. We have fostered a global community driven by a shared love for dogs. From daily walks to discovering new local spots, DogPack helps you connect with fellow dog enthusiasts, making every day, truly, an adventure.

I’m passionate about building products that bring people together and enrich their lives, one dog walk at a time.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADsognUBcR9-DRp-6aX8ePJfZHKtlS3nsrQ/
**Connexions partagées** : 3


---

# Dov Punski

## Position actuelle

**Entreprise** : DogPack

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Dov Punski

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7377373252165201920 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFrtSUji3MGHw/feedshare-shrink_800/B4EZmGuC6_IUAg-/0/1758901843554?e=1766620800&v=beta&t=KOCXc_6bOGYGtlr0gDpz-a_-wbGp2ZnVgzO5T-9MGnw | 🚨 We just teamed up with WME | William Morris Endeavor 🚨
The leading talent agency in Hollywood. A dream partner. A milestone we could only imagine a year ago.

But let’s rewind for a second…

What started as a small test turned into a viral sensation. 

In the last two months alone, DogPack videos have been viewed over 300 million times across social media. Millions of people, from every corner of the world, laughing, crying, and connecting over stories of dogs.

Then came the influencers. Some of the biggest dog names on the internet joined in, amplifying the DogPack voice and fueling our global growth.

And now… the crème de la crème. WME has signed with us. The same agency behind some of the world’s most iconic names in entertainment.

This validates the vision we’ve been building and opens the door to global opportunities we could have only dreamed of a year ago. 

More importantly, it gives DogPack access to unmatched reach, storytelling power, and partnerships that will help us scale our platform, grow our brand worldwide, and bring even more dog lovers into the pack.

The road ahead is massive, and we’re just getting started. 🐾✨ | 63 | 11 | 4 | 2mo | Jonathan Punski reposted this | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.597Z |  | 2025-09-26T16:07:28.283Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389694397682016257 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF4MQSgm33OaQ/feedshare-shrink_800/B4DZo135PjHwAk-/0/1761840437372?e=1766620800&v=beta&t=B9YjmjkXiu_SmF6UkyOQ42H93WdO7q-xh_-ZqPETpoQ | Huge thank you to Lucia Moses from Business Insider for capturing our story so perfectly. From the very first “Pawdcast” episode to now, seeing Goldie and Frenchie reach millions of people (and even making WME | William Morris Endeavor say “let’s build this out”) still feels surreal.
What started as a fun idea to get people onto DogPack, somehow turned into two AI dogs with real-world impact. Raising awareness for rescues and bringing laughter & tears to millions.
Appreciate the amazing write-up, Lucia 🙏
And thank you Business Insider for helping share our journey.

SEE THE FULL ARTICLE: https://lnkd.in/dBSDJyjK | 44 | 2 | 3 | 1mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:13:59.734Z |  | 2025-10-30T16:07:18.290Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7363656362393800704 | Video (LinkedIn Source) | blob:https://www.linkedin.com/90510b9b-e64c-44be-9b67-010594e4757c | https://media.licdn.com/dms/image/v2/D4E05AQEeHGtl7cWuUA/videocover-high/B4EZjD2b3mHECQ-/0/1755632485629?e=1765782000&v=beta&t=cLVScTEgmlA3sYwIXNnyiNaVVR_-CpqCXe6lhcgrR28 | Last week we collaborated with “@BrodieThatDood”, one of the biggest dog accounts on social media in the entire world.

There’s nothing like working with a big creator who doesn’t just have reach, but also a sense of humor. That’s what makes moments like this so powerful.

These Pawdcasts started as an experiment, and now they’re blowing up. 

This collab is proof that when you try new things, you never know what doors it can open.

Grateful to Brodie for playing along, grateful to Cliff Brush , Brodies amazing owner for making it happen, and couldn’t be more energized for what’s ahead.

Be sure to follow @officialdogpack on all socials and stay tuned for many more collabs to come! | 30 | 0 | 0 | 3mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.588Z |  | 2025-08-19T19:41:26.914Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7360792764424282113 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGanmAlXbPNiQ/feedshare-shrink_800/B4EZibKAgnHEAg-/0/1754949749847?e=1766620800&v=beta&t=pJ_yo5wegjpu1mch6j8LNkFq6NeK-LJ7pqLk4z-YQzs | Just wrapped an amazing few days at AppCamp in Boston with my brother Jonathan, thanks to a warm hospitable invite from adjoe.
It’s not every day you get to sit alongside some of the sharpest minds in User Acquisition, Retention, and Engagement all swapping ideas that actually move the needle and make a difference.
I had the chance to join a panel discussion and share how we’ve been scaling DogPack’s social presence including the tactics that helped us blow up our Instagram & TikTok audience. That surge in reach has been driving a big spike in organic sign-ups.
Huge shoutout to the other speakers and attendees for the insights and energy. Events like these remind me why I love this space. 🚀🐾 | 67 | 7 | 0 | 3mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.589Z |  | 2025-08-11T22:02:31.955Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7358466811970920448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7RAOKxiifOg/feedshare-shrink_2048_1536/B4EZh3Fx2nGUAs-/0/1754344662407?e=1766620800&v=beta&t=_0-nD5WXywDVuRg5973m_kpV8TJ3FY8VQf8SEos2guE | We were skeptical about posting AI videos on Instagram.
Early reactions? “Stop posting this AI junk.” Not exactly the feedback we hoped for.
But everything changed when we launched our “Pawdcast” series 3 days ago. Two dogs, mic’d up, talking about life, relationships, squirrels… you name it. Nothing about DogPack directly, just pure entertainment for our community.
Now? Our IG is blowing up. 25K new followers in the last 24 hours.
We’ve been flooding the feed with these, and the audience response?
 “Post more!” “I can’t stop watching!”
It’s been wild to see how fast things turned around once we hit the right tone.
Take feedback seriously but also take it with a grain of salt.
Sometimes it’s just about finding the right angle.
Check out our IG for the latest hits: https://lnkd.in/evEDGHPn | 46 | 11 | 0 | 4mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.589Z |  | 2025-08-05T12:00:01.676Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7356414616110809089 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAAAMDzOJ8AjwSRx6e4fdD_CFVCw.gif | As DogPack shifts from a free community app for dog owners to a monetized worldwide platform, there’s no one we’d rather have leading that charge than our new CRO, Zaiaad Khan.
Grit, tenacity, and relentless drive, he’s got all of it. We have 100% confidence he’ll take us from growth to profitability, and do it the right way.
Looking forward to what's next 🔥 | 26 | 2 | 0 | 4mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.590Z |  | 2025-07-30T20:05:20.055Z | https://www.linkedin.com/feed/update/urn:li:activity:7356360849457848320/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7355988571142430721 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFJPv0kC8tLpQ/feedshare-shrink_800/B4EZhW4oAaGcAk-/0/1753804342162?e=1766620800&v=beta&t=nsY87Ymv0xDX5zXZ8g-muLuW167u0a-8d5TffO5oZOE | In a room full of brilliant marketers and founders in the app industry, I wanted this talk to be real. Not just a highlight reel.
So I walked through the real story, how we bootstrapped DogPack from a messy start, the growth hacks that worked (and the ones that didn’t), specifically for user growth as a pre revenue company. Then I got into how our marketing is now evolving and changing as we just launched V1 of our monetization strategy. 
I wasn’t sure how it would land, but the response was incredible. Turns out, people connect with honesty just as much as strategy.
Beyond that, I learned a ton from seriously brilliant speakers and 1 on 1 discussions with some of the best in the industry. I left feeling energized and full of new ideas.
Big thanks to Jeet Niyogi and Mobile Growth Association for giving me the opportunity to share our journey.
🎥 Full talk is up here: https://lnkd.in/eZAV5AMm | 80 | 12 | 1 | 4mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.591Z |  | 2025-07-29T15:52:23.019Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7351531108934582274 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFoVj0oEhNeHQ/feedshare-shrink_800/B4EZgWPY8KHEAg-/0/1752719790588?e=1766620800&v=beta&t=eQLhI6-ab4srH5jnyfYx6SF71YfADG4RLst_C2RoBh4 | Thank you to Mobile Growth Association for having me speak about DogPack , especially in front of a crowd I’m just as excited to learn from!

I’ll be sharing how we went from scrappy, early day marketing tactics to scaling with more traditional strategies. As well as our shift from transitioning from a free app built on user trust and retention to our monetization strategy which we are rolling out in the coming weeks.

Hope people take away a tip or two and if you’ll be there, come say hi and let’s connect. | 32 | 8 | 0 | 4mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.593Z |  | 2025-07-17T08:40:01.213Z | https://www.linkedin.com/feed/update/urn:li:activity:7351439632640708609/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7343963842504253440 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHqHaKnDuKM6w/feedshare-shrink_2048_1536/B4EZeqJ4xmHYAo-/0/1750906408769?e=1766620800&v=beta&t=fbzVUc9luU3U7ChBUKEP2Q-wJC_umZtW8PUNCC1C5wI | Holy smokes we just got verified on TikTok!!


Five years ago, during COVID, before we even had an app, just an idea and a dream, I created our very first TikTok post. 
No real brand, no users, just hope.
Today, that little blue checkmark might seem silly to some. But for me it hit different.

It made DogPack feel real.

It’s something that’s sat in the back of my mind for years and now, seeing that blue tick genuinely made my week.

Maybe it’s dramatic. Maybe it’s just a symbol.
But honestly… heck freakin’ yes. I am fired up about it.
This feels like more than a small win. It’s fuel. It’s validation. It’s momentum.

To every dog, every follower, every early believer: thank you.

Let’s keep building. Let’s keep barking. Let’s keep going. | 106 | 26 | 3 | 5mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.596Z |  | 2025-06-26T11:30:24.303Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7336110815567114242 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f5e04e8f-4dd4-4a0b-8ad8-f59a55db0b00 | https://media.licdn.com/dms/image/v2/D5605AQG3DRMlUmqIKg/videocover-high/B56Zc8VfurHoBs-/0/1749063965659?e=1765782000&v=beta&t=93TNls_nksunPxwZugeqwDFntnK9_6CtTPXZCjLXrvo | Who here would trade their dog for a million dollars? (This is a judgement free zone) 👀 
Personally, I would never!!
Fun question we were asking dog owners at our event hosted by ATD Clubhouse | 19 | 3 | 0 | 6mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.598Z |  | 2025-06-04T19:25:16.779Z | https://www.linkedin.com/feed/update/urn:li:activity:7336106009431547906/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7335478765768126464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHb-OTIWKWHlQ/feedshare-shrink_800/B4EZczbEEsHkAg-/0/1748914422909?e=1766620800&v=beta&t=6ZZrjPi6wpqO4ERd2Vy2PpHVHIGwYm_FBbUg1fHMRJo | Ever drive across the city just because a stranger on an app told you to?

I did last week.

A user suggested this spot on DogPack about a 20 minute drive away from me.

As I was approving it, I knew I had to make my way over.

Found myself standing in an open field by the river, tucked between warehouses. Not on any list, not on Google Maps. Just a random spot only locals know.

Bear ran free, loving every second. Leash free. Worry free.
My wife and I loved it just as much.

Whether you like finding open fields, trails, beaches, cafes, breweries, malls or any spot to take your dog, you know where to look next time! | 54 | 2 | 0 | 6mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.599Z |  | 2025-06-03T01:33:44.364Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7331729909616103426 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-H07j23LQ4w/feedshare-shrink_800/B4EZb.JdkYHIAg-/0/1748020625310?e=1766620800&v=beta&t=CJTH6InzKVXir8gVRQHkfiSrUUxul1-P-62-WQ71MIc | Just wrapped up an incredible few days at MAU Vegas 

Learned a ton of actionable marketing strategies I can’t wait to implement and share with the rest of the DogPack team. Seriously game-changing stuff that’ll help us scale fast.

Even more valuable? The people. From early-stage startups to massive apps, I had the chance to connect face to face with some of the best minds in mobile. Conversations you just can’t replicate over email.

If you’re building or growing an app, go to this event. The ROI on relationships alone is worth it. | 45 | 2 | 0 | 6mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.600Z |  | 2025-05-23T17:17:07.407Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7321212229272440835 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ab772749-4532-45bc-ae80-848e249cd5b3 | https://media.licdn.com/dms/image/v2/D4E05AQEt1AtGTqEDzQ/videocover-high/B4EZZorpFyHEBo-/0/1745513008318?e=1765782000&v=beta&t=1t8dXv-ZUNAgjqK_MvwaaOuobLDHfXWxWKg5Pli968s | We recently started experimenting with UGC videos for DogPack and the results have been very encouraging across every language we’ve tested. 

Already learnt a ton on what works and what simply doesn’t.

But the authenticity, relatability, and scroll-stopping creativity are outperforming our polished brand ads by a mile.

We’ve tested these UGCs in English, Spanish, French, Italian, Portuguese, Dutch and German and the impact has been consistent. People love seeing real moments, real dogs, and real owners just like them.

Here’s one of our latest videos (in Italian) that’s been crushing it 👇(Some context: She is walking blindfolded with her dog, showing that she had no idea where to taker her dog….but then she found DogPack…)

We’re doubling down on this and looking to collaborate with more creators globally. If you’ve been running UGCs for your app or brand, I’d love to hear what’s working (or not working) for you!
Are UGC videos part of your 2025 playbook?
Let’s swap notes if they are. | 21 | 2 | 0 | 7mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.603Z |  | 2025-04-24T16:43:37.004Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7320915962038247426 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGEPvfmgroUQA/feedshare-shrink_2048_1536/B4DZZkeRZdG8Ao-/0/1745442379919?e=1766620800&v=beta&t=kXkOT8I9AbnUu4d9JrWuwXm6ZOg9hB3AmxsMIxo_6E8 | When we first started DogPack, we had no ad budget. This is exactly how we got our first 100K users which was a big factor to securing our seed round of funding.
Not gonna lie, it was pretty scrappy. But it worked.
I posted in every local community group on Facebook I could find. From my personal account, my brothers accounts, my moms account… even a few fake ones. Ten posts a day, per account. Every day for about 2 years.
I would do this like my life depended on it (which it kind of did). I would have to research local landmarks just to pass group entry questions and blend in as a “local.” 
The post you see below? It’s the exact one that brought in our first 100K users. It worked because it spoke directly to a real community and offered real value to dog owners.
Yes, I got flagged by Facebook more times than I could count. Yes, I got called out many times for not being local. And no, it wasn’t glamorous. 
But all of the positive comments, installs and 5 star ratings coming in, is what really kept me going. | 58 | 5 | 2 | 7mo | Post | Dov Punski | https://www.linkedin.com/in/dov-punski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.603Z |  | 2025-04-23T21:06:21.391Z |  |  | 

---



---

# Dov Punski
*DogPack*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [A Q&A with DogPack App’s Dov Punski: Minding your business](https://www.thesuburban.com/business/a-q-a-with-dogpack-app-s-dov-punski-minding-your-business/article_f8be30fa-d795-11ef-be7e-1358736b784b.html)
*2025-01-22*
- Category: article

### [Best Bets for Pets](https://www.petliferadio.com/bestbets.html)
- Category: article

### [How DogPack's Talking Dog Podcast Took Over the Internet](https://www.dogpackapp.com/blog/dogpack-talking-dog-podcast/)
*2025-10-30*
- Category: podcast

### [Social media for dogs? The DogPack app is uniting furry, ...](https://region.com.au/social-media-for-dogs-the-dogpack-app-is-uniting-furry-four-legged-friends-in-canberra/607957/)
*2022-11-05*
- Category: article

### [AI dog podcasters are making a splash in Hollywood](https://www.businessinsider.com/ai-dog-podcasters-dogpack-sign-with-talent-giant-wme-2025-10)
*2025-10-30*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[AI Dog Podcasters Are Making a Splash in Hollywood - Business ...](https://www.businessinsider.com/ai-dog-podcasters-dogpack-sign-with-talent-giant-wme-2025-10)**
  - Source: businessinsider.com
  - *Oct 30, 2025 ... DogPack's AI dog podcast signed with WME after gaining over 1 ... Dov Punski, one of the four brothers behind the company, said they'...*

- **[How much do people love this podcast hosted by AI dogs?](https://www.govtech.com/question-of-the-day/how-much-do-people-love-this-podcast-hosted-by-ai-dogs)**
  - Source: govtech.com
  - *Oct 31, 2025 ... The marketing approach certainly worked, with the DogPack app now boasting 2 million users in 20 countries. ... Dov Punski, one of th...*

- **[How DogPack's Talking Dog Podcast Took Over the Internet](https://www.dogpackapp.com/blog/dogpack-talking-dog-podcast/)**
  - Source: dogpackapp.com
  - *Oct 30, 2025 ... “Our tear jerkers do best right now,” said DogPack's CMO and co founder Dov Punski in Business Insider. “People don't like to feel li...*

- **[How man's best friend became man's favorite podcaster](https://thehustle.co/news/how-mans-best-friend-became-mans-favorite-podcaster)**
  - Source: thehustle.co
  - *Nov 6, 2025 ... In the few months since its debut, the show's drawn 2m users across 20 countries to DogPack's ... Dov Punski told BI. Compared to othe...*

- **[Wird dieser KI-Podcast von zwei Hunden das neue große Ding in ...](https://www.businessinsider.de/wirtschaft/wird-dieser-hunde-ki-podcast-das-neue-grosse-ding-in-hollywood/)**
  - Source: businessinsider.de
  - *Oct 30, 2025 ... Dogpack, eine App für Hundebesitzer, hat mit seinem KI-Hunde ... Dov Punski, einer der vier Brüder hinter dem Unternehmen, erklärte ....*

- **[Social media for dogs? The DogPack app is uniting furry, four ...](https://region.com.au/social-media-for-dogs-the-dogpack-app-is-uniting-furry-four-legged-friends-in-canberra/607957/)**
  - Source: region.com.au
  - *Nov 5, 2022 ... The DogPack app is uniting furry, four-legged friends in Canberra. 5 ... Photo: Dov Punski. Two brothers, a couple of their pets and o...*

- **[Wird dieser KI-Podcast von zwei Hunden das neue große Ding in ...](https://de.finance.yahoo.com/nachrichten/ki-podcast-zwei-hunden-neue-144959045.html)**
  - Source: de.finance.yahoo.com
  - *Oct 30, 2025 ... Dogpack, eine App für Hundebesitzer, hat mit seinem KI-Hunde ... Dov Punski, einer der vier Brüder hinter dem Unternehmen, erklärte ....*

- **[DogPack: Dog Parks & Services - Crunchbase Company Profile ...](https://www.crunchbase.com/organization/dogpack)**
  - Source: crunchbase.com
  - *Founders Aryeh Punski, Dov Punski, Eric Punski, Jonathan Punski ... January 11, 2022: Global News Interview: https://globalnews.ca/video/8502695/dogpa...*

- **[CJAD 800 Radio interview with Dov Punski - YouTube](https://www.youtube.com/watch?v=8yEjPORYMCw)**
  - Source: youtube.com
  - *Jan 27, 2025 ... We were happy to be featured on Montreals CJAD 800 radio station, yesterday on Sunday January 26, 2025. The founder of DogPack, Dov P...*

- **[Best Bets for Pets – Pet Product Reviews & Must-Have Finds on Pet ...](https://www.petliferadio.com/bestbets.html)**
  - Source: petliferadio.com
  - *A fascinating book and an interview you won't want to miss! ... This week Michelle Fern is joined by Dov Punski, creator of the Dog Pack App. The DogP...*

---

*Generated by Founder Scraper*
