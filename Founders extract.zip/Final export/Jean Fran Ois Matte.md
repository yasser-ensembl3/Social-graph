# Jean-François Matte

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397670518902132736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGlocQUUzxrlg/feedshare-shrink_800/B4EZqnOIp1GUAg-/0/1763742093012?e=1766620800&v=beta&t=gLOfw2hNV8PuMvSwY56KEknm5OZP6w5ZSPjBZHpmtFw | The EZO 2025 Roster! 🇨🇦 | 138 | 27 | 1 | 2w | Post | Jean-François Matte | https://www.linkedin.com/in/jean-francoismatte | https://linkedin.com/in/jean-francoismatte | 2025-12-08T05:00:23.769Z |  | 2025-11-21T16:21:33.778Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7346245889390239745 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnJjsJLcoQmQ/feedshare-shrink_800/B4EZfMRDhCGcAg-/0/1751478713025?e=1766620800&v=beta&t=eX8MOe6byvjlZGzrvKtCbc-7bdtjXLKAqo0nxfMiNng | Charles-André and I will be at Startupfest in Montreal next week 🇨🇦 🏄‍♂️ 

Special thanks go to Jean-Luc Pellerin and Station Fintech Montréal for selecting EZO Systems to pitch! | 37 | 0 | 1 | 5mo | Post | Jean-François Matte | https://www.linkedin.com/in/jean-francoismatte | https://linkedin.com/in/jean-francoismatte | 2025-12-08T05:00:28.382Z |  | 2025-07-02T18:38:26.679Z | https://www.linkedin.com/feed/update/urn:li:activity:7346234178335588353/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7325564007912718336 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7hEuqbeXipQ/feedshare-shrink_800/B4EZamhoqeHoAk-/0/1746550561119?e=1766620800&v=beta&t=asjliZrt8qBGwXlaUrrnqlItbS5-Bfieqg8CmsueiaA | The EZO Systems team is at The Payments Canada SUMMIT!

We have been LIVE in Canada since January after receiving our licences and have already processed several millions in volume.

There is a huge market in Canada to disrupt the current crypto players. We offer zero spread crypto transactions, always the market rate and transparent fees.

At the Summit we will be discussing the EZO SuperApp for emerging markets.

Special thanks to Elizabeth Dempsey and the Payments Canada team for the organisation. Also to our early customers who have trusted us for several months and to our partners. | 73 | 3 | 1 | 7mo | Post | Jean-François Matte | https://www.linkedin.com/in/jean-francoismatte | https://linkedin.com/in/jean-francoismatte | 2025-12-08T05:00:30.485Z |  | 2025-05-06T16:56:01.884Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7316564098513580033 | Video (LinkedIn Source) | blob:https://www.linkedin.com/95fa80a9-7a3d-4bfe-9c73-9254ac7810c6 | https://media.licdn.com/dms/image/v2/D4E05AQHFgAzjNZHQjQ/feedshare-thumbnail_720_1280/B4EZYk72QuHMA8-/0/1744376391348?e=1765778400&v=beta&t=5ILJFqEHSl9wmHfwfBTlElBiLN0QZ9Za3uo2m5Tao_s | Dimedove is live! A great tool for Canadians 🇨🇦 to access financial pros. 

Felix realized that Reddit was not the best place to get financial advice tailored to specific situations. On Dimedove, AI answers are complemented by real experts answering your questions. Try it out :-) | 14 | 1 | 0 | 7mo | Post | Jean-François Matte | https://www.linkedin.com/in/jean-francoismatte | https://linkedin.com/in/jean-francoismatte | 2025-12-08T05:00:30.487Z |  | 2025-04-11T20:53:36.273Z | https://www.linkedin.com/feed/update/urn:li:activity:7316444953075748864/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7272628199073763329 | Article |  |  | Large Canadian banks pay $0.06 per Interac transfer! Fintechs like EZO Systems are charged over $1.15 for Interac transfer.

"Toward the end of a 90-minute interrogation, Conservative lawmaker Adam Chambers urged Wilmot (Interac's CEO) to be more forthcoming.

“Help us with transparency, so that we don’t make unwise or very radical regulatory recommendations — because in the absence of any information we’re left with what looks to be an ownership structure that is working really hard to protect its profit pool,” Chambers said." | 20 | 2 | 0 | 11mo | Post | Jean-François Matte | https://www.linkedin.com/in/jean-francoismatte | https://linkedin.com/in/jean-francoismatte | 2025-12-08T05:00:32.868Z |  | 2024-12-11T15:08:01.557Z | https://financialpost.com/fp-finance/banking/canadian-mps-target-interac |  | 

---

