# Jeremy Rubier

## Position actuelle

**Titre** : Creative Partner
**Entreprise** : Runway
**Durée dans le rôle** : 11 months in role
**Durée dans l'entreprise** : 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Jeremy Rubier is a versatile and talented filmmaker who co-founded DMBZ, a collective of filmmakers based in Tokyo, where he also works as a film director for 3rd Culture Kids, a cinematographer for Red Bull, and a filmmaker for monopo. He holds a master's degree in Cinematography and Film/Video Production from Concordia University and a bachelor's degree from Temple University Japan.

With a career spanning over a decade across the globe, he has won multiple awards and recognition for his work, such as the Best Director accolade at the Fantasia Film Festival in 2014 and the inclusion of his documentary "3rd Culture Kids" in the official competition at Slamdance in 2015. He is proficient in Final Cut Pro and has a keen eye for visual aesthetics and narrative depth, drawing inspiration from artists such as Nicolas Winding Refn and Hayao Miyazaki. He is passionate about Japan and its culture, having studied the language since the age of 15 and lived in Nagoya for two months. He strives to disrupt, elevate, and inspire the world through his creative vision.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACMV9p8BxPP7FO6oMV7JH3NwSET5A5iTb_M/
**Connexions partagées** : 4


---

# Jeremy Rubier

## Position actuelle

**Entreprise** : 3rd Culture Kids

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jeremy Rubier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392677259150647296 | Article |  |  | I had the privilege of spending an hour with Clipless in Canada, talking about my journey, discoveries, challenges, and how cycling has transformed my vision of filmmaking. I hope you enjoy it!  Perfect podcast for a rainy day. 

J’ai eu le privilège de passer une heure avec Clipless in Canada pour parler de mon parcours, de mes découvertes, de mes défis et de la façon dont le vélo a transformé ma vision du cinéma. J’espère que vous apprécierez l’épisode ! Un podcast parfait pour un week-end 
pluvieux.

https://lnkd.in/g6NaiJ2V | 0 | 0 | 0 | 1mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.372Z |  | 2025-11-07T21:40:07.883Z | https://open.spotify.com/episode/6tMlkKkxylK98PEg2mPsVN |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384663447051018240 | Article |  |  | Cet été, j’ai traversé tout le Québec à vélo.
 3 200 km, 8 régions, des centaines de visages, des paysages à couper le souffle… et une question simple, mais immense :
 C’est quoi, être Québécois ?
De cette traversée est né Le Grand Détour, un documentaire sur l’appartenance, la lenteur et la rencontre.
Mais c’est aussi un projet collectif : au fil du voyage, j’ai créé des vidéos personnalisées pour chacun de mes partenaires et sponsors, afin de mettre en valeur ceux qui m’ont soutenu et qui incarnent eux aussi les valeurs du projet — authenticité, durabilité, lien humain.
Exemple : voici celle réalisée avec Panorama Cycles, qui m’a accompagné sur chaque kilomètre:
https://lnkd.in/gGcqGPJS
Ces collaborations ne sont pas de simples placements de logo.
 Elles racontent une vision commune : celle d’un Québec qui avance autrement — à vélo, à visage humain, en cherchant à comprendre plutôt qu’à consommer.
Aujourd’hui, il reste 48 heures pour boucler la levée de fonds Ulule et finaliser la postproduction du film.
Vous pouvez en savoir plus en écoutant mon interview pour Radio-Canada ici: https://lnkd.in/gp3kfSxq
 Chaque contribution compte, pour que ce projet voie le jour et puisse inspirer d’autres à voyager, à ralentir, à se reconnecter.
Soutenir Le Grand Détour, c’est croire en un cinéma humain, écologique et profondément québécois.
 👉 https://lnkd.in/gDWi_srf | 3 | 0 | 3 | 1mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.373Z |  | 2025-10-16T18:56:06.189Z | https://www.youtube.com/watch?v=MgrZwMXF4zk |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7383527916455968768 | Article |  |  | On entre dans la dernière ligne droite du Grand Détour. Un immense merci à toutes celles et ceux qui m’ont soutenu jusqu’ici — le support a été incroyable, et 10 000 $ est déjà une très belle somme.
Mais pour la première fois de ma vie, je veux consacrer les six prochains mois à un seul projet. Et avec le coût de la vie à Montréal, je ne peux pas y arriver avec cette somme. 
Dans le passé, j’ai déjà travaillé à temps partiel tout en essayant de mener  à terme mes projets personnels.
Et ils n’ont jamais atteint leur plein potentiel.
Je ne veux pas faire la même erreur avec ce projet
Je n’ai jamais demandé d’aide financière, ni de subvention. Ce n’est pas dans ma nature. Mais cette fois, je sens que ce projet mérite d’aller au bout.
Le Grand Détour, c’est une série que je fais seul, caméra à l’épaule, pour comprendre ce que ça veut dire « être Québécois ».
Il reste une semaine pour m’aider à finaliser le projet.
Contribuez si vous pouvez, sinon, partagez. 
Merci du fond du coeur. 
https://lnkd.in/gDWi_srf
https://lnkd.in/gqRbWv7j
Tourisme durable Québec Aventure Écotourisme Québec (AEQ) | Québec Adventure Outdoor PhysioExtra Panorama Cycles Arkel Bike Bags | 2 | 0 | 1 | 1mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.374Z |  | 2025-10-13T15:43:54.598Z | https://youtu.be/6tggURKZZWc |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7376977665175728129 | Article |  |  | Super article sur mon aventure à découvrir sur Quebec le Mag
https://lnkd.in/gRjhYcd3

Si vous voulez me soutenir, ou même partager le projet
👉 https://lnkd.in/gPedMv9Z | 1 | 0 | 0 | 2mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.375Z |  | 2025-09-25T13:55:32.995Z | https://www.quebeclemag.com/jeremy-rubier-road-trip-quebec-velo-hauteur-homme/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7373475464134189056 | Article |  |  | Cet été, j’ai parcouru plus de 3 000 km à vélo à travers le Québec, caméra à l’épaule, pour aller à la rencontre de celles et ceux qui habitent ce territoire. Des dizaines de visages, d’histoires et de voix se sont rassemblés autour d’une question simple mais immense : c’est quoi, être Québécois ?
Quand j’ai partagé la première vidéo de lancement du projet, je ne m’attendais pas à ce qu’elle devienne virale : plus de 200 000 vues sur Instagram et 1 500 partages en quelques jours. Cet élan m’a confirmé deux choses :
Ce projet résonne bien au-delà de moi.
Il ne peut exister que grâce au financement participatif.
Au-delà de cette série, cette campagne est aussi une manière pour moi de construire l’avenir : raconter les histoires que je veux, à ma façon, et vivre directement de mon audience. Faire du cinéma indépendant, humain et libre, sans compromis.

👉 Aujourd’hui, j’ai besoin de votre aide.
 Si ce projet vous parle, vous pouvez y participer ici : https://lnkd.in/gPedMv9Z

Merci à celles et ceux qui prendront le temps de soutenir, partager ou simplement en parler autour d’eux. C’est ensemble qu’on peut faire exister ce genre d’aventure.

Vidéo d'annonce:
https://lnkd.in/guZnGpbJ

Merci a tout mes partenaires, Tourisme durable Québec Aventure Écotourisme Québec (AEQ) | Québec Adventure Outdoor Outdoor MT LabMetro Inc. La Cordée Canon Canada Panorama Cycles Arkel Bike Bags PhysioExtra Web

#LeGrandDetour #Documentaire #Cyclotourisme #TourismeDurable #Crowdfunding #Ulule | 5 | 0 | 3 | 2mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.376Z |  | 2025-09-15T21:59:03.199Z | https://www.youtube.com/watch?v=Z99mmLxfOXw&ab_channel=JeremyRubier |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7343738037018759169 | Video (LinkedIn Source) | blob:https://www.linkedin.com/45ee58b1-262c-42a8-817a-8a6ff6842c2d | https://media.licdn.com/dms/image/v2/D5605AQEm-VM82DjZNA/feedshare-thumbnail_720_1280/B56ZeoyjsDHEA0-/0/1750883517240?e=1765789200&v=beta&t=V87hDk3dLSDAzYve5pWCdNCdEu5RiqUz884LbNny0rk | jeremyrubier 21h
Le 15 juin à 6h42, j'ai quitté Montréal à vélo.
Depuis... j'ai traversé des ponts, des forêts, des orages.
J'ai dormi près de l'eau, roulé sous la pluie, et fait des rencontres que j'oublierai jamais.
C'est dur. Mon dos le confirme. Mes cuisses aussi.
Et si tout va bien (et que j'ai du Wi-Fi), Chaque jour, je découvre un peu plus ce territoire... et un peu plus ce que ça veut dire "vivre ici".
Si tout va bien, je vous balance une petite vidéo-résumé chaque semaine.
je vous prépare une vidéo chaque semaine.
Joyeuse Saint-Jean à tout le monde, j'arrive à Québec ce soir.
La route continue.
Merci a mes partenaires Tourisme durable Québec Aventure Écotourisme Québec (AEQ) | Québec Adventure Outdoor MT Lab Metro Inc. La Cordée Canon Canada Panorama Cycles Arkel Bike Bags PhysioExtra
#LeGrandDetour #SaintJean | 6 | 0 | 1 | 5mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.377Z |  | 2025-06-25T20:33:08.080Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7340760807204405248 | Video (LinkedIn Source) | blob:https://www.linkedin.com/39c6bb62-b426-414e-8cfd-72b1e82006f9 | https://media.licdn.com/dms/image/v2/D5605AQGgciSQQEUtJQ/feedshare-thumbnail_720_1280/B56Zd.ey2KHUA4-/0/1750173694108?e=1765789200&v=beta&t=jBSrBvv_zUcAt2VoJ5-SikOO3KwSTD0rLRhcvyTdZ3U | Bon. Je pars.
Un trip à vélo à travers le Québec.
Un documentaire qui me trotte dans la tête depuis des années.
Ça s’appelle Le Grand Détour.
C’est ma façon à moi d’essayer de devenir québécois pour vrai.
Pas juste sur le papier.
Pendant que mes amis font des bébés ou se marient (je vous aime 🫶),
je me suis dit :
quitte à pas faire de bébé, autant vivre un truc qui me dépasse.
Je pars de Montréal, je vais traverser presque tout :
la Mauricie, Charlevoix, la Côte-Nord, la Gaspésie, le Bas-Saint-Laurent, l’Estrie…
À vélo. En solo. Caméra dans le sac.
Je vais rencontrer du monde, filmer, me perdre un peu —
et essayer de comprendre le Québec à travers ceux qui y vivent.
Merci à ceux qui rendent ça possible :
Tourisme durable Québec Aventure Écotourisme Québec (AEQ) | Québec Adventure Outdoor Québec Le Mag'​
Et un gros merci à ceux qui m’ont équipé pour survivre là-dedans :
Metro Inc. Arkel Bike Bags Panorama Cycles XACT NUTRITION Canon Canada La Cordée PhysioExtra
Si vous avez des coins à me recommander,
ou si vous voulez rouler un bout avec moi,
écrivez-moi.
Je pose l’itinéraire chaque jour sur Strava.
À tantôt.
#legranddetour | 8 | 1 | 2 | 5mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.379Z |  | 2025-06-17T15:22:41.178Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7304852653514141696 | Video (LinkedIn Source) | blob:https://www.linkedin.com/011c638a-2d85-41ab-8ce9-85779fcadf51 | https://media.licdn.com/dms/image/v2/D5605AQGSSMCgExOtag/feedshare-thumbnail_720_1280/B56ZWAMXIGHsBA-/0/1741612480866?e=1765789200&v=beta&t=vhRTzaGQtSJ_CYVnlH7IE-zIH3TMg0osEvn89tGmcdE | AI has completely transformed my vision of filmmaking, opening doors I never thought possible.

I’ve always been a filmmaker grounded in reality, capturing human stories. I don’t want to lose that—I want to amplify it. AI isn’t a replacement for filmmaking; it’s a tool to push boundaries, dream bigger, and create the impossible. It allows us to move beyond budget constraints that have long limited creativity in the independent filmmaking world. 

I want to collaborate with musicians, writers, performers—anyone who, like me, wants to expand their vision and explore new creative frontiers. Let’s see how far we can take it. Let's dream.

Made with Midjourney, Kling, Haluai, Runway, and ElevenLabs.
Music by the amazing Common Saints. | 39 | 8 | 2 | 8mo | Post | Jeremy Rubier | https://www.linkedin.com/in/jeremy-rubier-33b175145 | https://linkedin.com/in/jeremy-rubier-33b175145 | 2025-12-08T08:00:47.379Z |  | 2025-03-10T13:16:30.197Z |  |  | 

---



---

# Jeremy Rubier
*3rd Culture Kids*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Why it's So Hard to Work in Japan as a Film Director with Jeremy Rubier #7 – Illectric Sheep – Podcast](https://podtail.com/de/podcast/illectric-sheep/why-it-s-so-hard-to-work-in-japan-as-a-film-direct/)
*2022-04-27*
- Category: podcast

### [Jeremy Rubier - Filmmaker | Canvas Tokyo - Creative Platform](https://www.canvas.co.com/creatives/jeremy-rubier)
*2017-05-09*
- Category: article

### [New Zealand’s ‘Third Culture Kids’: Creating Identity From the ‘Other’ Box](https://www.vice.com/en/article/new-zealands-third-culture-kids-creating-identity-from-the-other-box/)
*2023-03-22*
- Category: article

### [Interview with a Multilingual Person: Jeremy](https://www.esperanzaeducation.ca/blog/multilingualism/interview-multilingual-person-jeremy)
*2013-11-19*
- Category: blog

### [S1/E18: #Third Culture Kids - The Impact of Growing Up Among Worlds with Ruth Van Reken](https://culturexchange.podigee.io/18-new-episode)
*2024-01-26*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[SKATERS AND THIEVES - YouTube](https://www.youtube.com/watch?v=feOMWjEBAKc)**
  - Source: youtube.com
  - *Mar 12, 2018 ... ... Jeremy Rubier and AD Jennings (3rd Culture Kids) when they were ... Best TV News Interviews Of The Decade (so far). Funny Local N...*

---

*Generated by Founder Scraper*
