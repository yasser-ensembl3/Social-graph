# Bárbara Castro

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392330498229874688 | Article |  |  | 🇨🇦 A milestone in my entrepreneurial journey
I’m beyond excited to share that we’ve (Me and my co-founder Sabrina Naderer - Moara) been selected to join the new cohort of the NEXT AI bootcamp program, one of Canada’s leading accelerators for startups leveraging artificial intelligence. (nextcanada.com)

Out of so many inspiring projects, being chosen as one of the selected teams is both an honor and a powerful validation of our vision and potential. 🏅

Over the next five weeks, we’ll immerse ourselves in a transformative experience learning from world-class mentors, professors, investors, and founders who have built globally impactful ventures.

📌 What excites me most:
Strengthening how we ideate, validate, and scale solutions that truly matter.
Refining our pitching and fundraising strategy to clearly communicate our impact.

Building a strong foundation for team culture, growth, and execution at scale.
Connecting with a community of brilliant, driven founders and innovators.
This program is truly life-changing a chance to grow, refine, and bring our vision to life.

✨ Huge thanks to the NEXT AI team for believing in our project we’re ready to learn, grow, and make a difference.


🇧🇷 Um marco na minha jornada empreendedora
Tenho a imensa alegria de compartilhar que (eu e minha co-fundadora Sabrina Naderer - Moara) fomos selecionadas para participar do novo ciclo do programa bootcamp da NEXT AI, um dos mais renomados aceleradores de startups baseadas em inteligência artificial do Canadá. (nextcanada.com)

Entre tantos projetos incríveis, sermos escolhidas como uma das equipes participantes é uma grande honra e também um forte reconhecimento do potencial e impacto da nossa visão. 🏅

Serão 5 semanas intensas de aprendizado e crescimento, com mentorias de especialistas, professores premiados, investidores e founders que já transformaram ideias em negócios de alcance global.

📌 O que mais me entusiasma:
Fortalecer nossa capacidade de idear, validar e escalar soluções reais para o mercado.

Aprimorar nossa narrativa e estratégia de pitching e captação.
Trabalhar temas essenciais de cultura, crescimento e liderança em startups.
Conectar-nos a uma comunidade brilhante de empreendedores e inovadores.

Este programa representa uma oportunidade verdadeiramente transformadora, uma chance de elevar nossa startup com estrutura, mentoria e propósito.

✨ Gratidão à equipe do NEXT AI por acreditar no nosso projeto. Estamos prontas para aprender, evoluir e causar impacto.

#NEXTAI #NEXTCanada #Startup #Inovação #ArtificialIntelligence #Empreendedorismo #Crescimento #Pitching #Founders | 25 | 3 | 0 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:08.755Z |  | 2025-11-06T22:42:13.637Z | http://nextcanada.com/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391954400950509568 | Article |  | https://media.licdn.com/dms/image/v2/D4E0BAQG4QTypKaW2ow/company-logo_400_400/B4EZm6gX2xHgAY-/0/1759770672928?e=1766620800&v=beta&t=gTO1fou6hT8z35u3e3XAuFBa1fpCnjpimb9oELRfgSM | ✨ Estamos construindo algo que começou com uma ideia simples: tinha que haver uma maneira melhor.

Após décadas de experiência em manufatura de madeira e comércio internacional, minha cofundadora, Sabrina Naderer, viu de perto quanto tempo e potencial eram perdidos em processos manuais e ultrapassados.

Foi assim que nasceu a Moara: uma plataforma com inteligência artificial projetada para simplificar orçamentos e operações para fabricantes, distribuidores e fornecedores.

Nosso objetivo é revolucionar o setor, unindo tradição e inovação. Queremos levar tecnologia moderna a uma indústria que mantém o mundo em movimento, mas que por muito tempo foi ignorada pelo Vale do Silício.

Estamos apenas começando e adoraríamos que você acompanhasse nossa jornada. 

🔗 Confira nosso site: usemoara.com
 📲 Siga-nos: https://lnkd.in/eNiaQDUx

#IA #Manufatura #Inovação #TecnologiaParaOBem #Startup #Automação #Moara #RevoluçãoIndustrial | 6 | 0 | 1 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:08.756Z |  | 2025-11-05T21:47:45.058Z | https://www.linkedin.com/company/usemoara |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391178144285888512 | Article |  | https://media.licdn.com/dms/image/v2/D4E0BAQG4QTypKaW2ow/company-logo_400_400/B4EZm6gX2xHgAY-/0/1759770672928?e=1766620800&v=beta&t=gTO1fou6hT8z35u3e3XAuFBa1fpCnjpimb9oELRfgSM | ✨ We’re building something that started with a simple idea: there had to be a better way.

After decades of experience in wood manufacturing and international trade, my co-founder, Sabrina Naderer, witnessed firsthand how much time and potential were lost in manual, outdated processes.

That’s how Moara was born: an AI-powered platform designed to simplify quoting and operations for manufacturers, distributors, and suppliers.

Our goal is to revolutionize the industry, bridging tradition and innovation. We want to bring modern technology to a sector that keeps the world running but has long been overlooked by Silicon Valley.

We’re just getting started and we’d love for you to follow our journey. 🌍

Check our website: usemoara.com
Follow us: https://lnkd.in/eNiaQDUx

#AI #Manufacturing #Innovation #TechForGood #Startup #Automation #Moara #IndustrialRevolution | 15 | 1 | 1 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:08.756Z |  | 2025-11-03T18:23:11.047Z | https://www.linkedin.com/company/usemoara |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7389326815749754881 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHqsShf6Z01Ug/feedshare-shrink_800/B4EZowplMMJgAg-/0/1761752798487?e=1766620800&v=beta&t=UXrCqvrd-gEKUGI0PTvMK43zztEL6VyrgElvawnlQkA | 🇧🇷
Sabemos que essa rede é para compartilharmos conhecimento, mas também é para celebrar pequenas conquistas. E, depois de três anos e alguns dias, conseguimos a tão sonhada Residência Permanente no Canadá.

De um planejamento que começou em janeiro de 2020 até a sua concretização, foram anos de pesquisa, formulários, aprendizado constante de dois outros idiomas, estar longe da família e aprender uma nova cultura.

Tivemos que abdicar de alguns (muitos) sonhos, da nossa carreira e dar tempo ao tempo para alcançar um objetivo maior. Não sabíamos se isso ia dar certo, se iríamos nos adaptar, se conseguiríamos algo após essa tentativa mas, nunca nos desviamos do nosso propósito.

O caminho foi longo: entre empregos que sugavam nossa alma e bem-estar, uma rotina tão desgastante que causou burnouts, insegurança financeira e momentos em que duvidamos de nós mesmos.

E então você lembra que está em outro país, falando outro idioma que teve que aprender na raça, e que já realizou muito mais do que um dia imaginou. 
Que se redescobriu e que encontrou outros mil sonhos para realizar.

Hoje, consigo também chamar este país de meu lar, pois, desde 15 de outubro, uma nova jornada começou.

_____________
🇺🇸 
We know this network is meant for sharing knowledge, but it’s also a place to celebrate small victories. And after three years and a few days, we finally achieved our long-awaited Permanent Residency in Canada.

From a plan that started back in January 2020 to its realization, it’s been years of research, endless forms, constantly learning two new languages, being away from family, and embracing a new culture.

We had to give up some (many) dreams, our careers, and let time take its course in pursuit of a greater goal. We didn’t know if it would work out, if we would adapt, or if we would find something after this attempt but we never lost sight of our purpose.

The road was long: through jobs that drained our souls and well-being, routines so exhausting they led to burnout, financial insecurity, and moments of deep self-doubt.

And then you remember that you’re in another country, speaking another language you had to learn the hard way, and that you’ve already accomplished far more than you ever imagined. You rediscovered yourself and found a thousand new dreams to chase.

Today, I can also call this country my home because since October 15th, a new chapter has begun. | 26 | 5 | 0 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:12.804Z |  | 2025-10-29T15:46:39.928Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7382549841022853121 | Article |  |  | 💡 Como as indústrias brasileiras estão lidando com cotações e pedidos de orçamento (RFQs)?

Se você trabalha no setor industrial, sabe o quanto o processo de cotações e RFQs (Requests for Quotation) pode ser lento, repetitivo e impactar diretamente a produtividade.

Estamos realizando uma pesquisa rápida (3 minutos) para entender como as empresas industriais gerenciam seus processos de compras e onde há espaço para inovação e automação.

Nosso objetivo é identificar oportunidades reais de eficiência e automação no fluxo de cotações sem comprometer a qualidade nem o relacionamento com fornecedores.

Se você atua nas áreas de compras, supply chain, engenharia ou operações, sua opinião será extremamente valiosa!

👉 Participe da pesquisa: https://lnkd.in/eUnTcaC5

Todas as respostas são totalmente confidenciais e nos ajudarão a construir o futuro do procurement industrial no Brasil. | 6 | 0 | 2 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:12.805Z |  | 2025-10-10T22:57:23.243Z | https://docs.google.com/forms/d/e/1FAIpQLSeWDzA0UxxHXzMTMucNgPG8th8SFzZi42wj-qJZFxP2o64bGw/viewform?usp=header |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7382549075482648577 | Article |  |  | 💡 How are Montreal’s industrial companies handling quotations and RFQs?

If you work in the industrial sector, you know how time-consuming and repetitive the quotation and RFQ (Request for Quotation) process can be and how much it impacts productivity.

We’re conducting a short 3-minute survey to better understand how industrial companies manage their procurement processes and where there’s room for innovation.

Our goal is to identify real opportunities for automation and efficiency in the quotation workflow without compromising quality or supplier relationships.

📊 If you work in purchasing, supply chain, engineering, or operations, your input will be incredibly valuable!

👉 Take the survey here: https://lnkd.in/eD-4tDHc

All responses are completely confidential and will help us shape the future of industrial procurement in Montreal. | 10 | 1 | 1 | 1mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:12.806Z |  | 2025-10-10T22:54:20.724Z | https://docs.google.com/forms/d/e/1FAIpQLSev-0NoDq3eYlfn7BqS3qemXfdUIQDd1c1p21kkE5mm0IqItw/viewform?usp=header |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7376061631019106304 | Text |  |  | Nos últimos dias tenho tentado me desafiar a sair da zona de conforto e expandir meus conhecimentos na área de tecnologia.
Finalizei recentemente o curso “Conceitos de DevOps” do Cláudio Antônio que está hospedado na Udemy pois é uma área que sempre tive muito interesse e resolvi trazer alguns pontos essenciais que vão muito além de ferramentas:
- DevOps é cultura, não cargo.
- A importância da integração, entrega e feedback contínuos.
- Automação e Infra como Código como pilares para eficiência.
- Monitoramento e telemetria para identificar falhas rapidamente.
- Valor de pequenas mudanças em vez de grandes lotes difíceis de corrigir.
- E por último achei incrível o insight da Lei de Conway que diz que os sistemas refletem a forma como as pessoas se comunicam dentro da organização.

Dos mesmos criadores de build in public, quis trazer também uma visão de learn in public, como já fazemos na #100DaysOfCode na “rede vizinha”.
Compartilhar aprendizados, por menores que sejam, ajudam a fixar o conhecimento e ainda podem inspirar outras pessoas que estão começando também.

🚀 Sendo esse só o início de uma longa jornada, espero fazer desse compartilhamento um hábito. Vamos juntos pois nunca é tarde!

#DevOps #LearnInPublic #AprendizadoContínuo #Automação #InfraAsCode #CarreiraTech | 14 | 0 | 0 | 2mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:12.811Z |  | 2025-09-23T01:15:33.433Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7276270745125621761 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABgBrZ2daanMQJ-egBdqUfzcNg.gif | Gostaria de compartilhar que finalizei meu curso de Pós-graduação em Bioinformática na instituição de ensino Faculdade Unyleya. | 28 | 7 | 0 | 11mo | Post | Bárbara Castro | https://www.linkedin.com/in/babecastro | https://linkedin.com/in/babecastro | 2025-12-08T07:16:12.815Z |  | 2024-12-21T16:22:12.211Z |  |  | 

---

