# Ben Maunier

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : OwlSight UX
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

With a background as a Senior UX Researcher and Designer, now evolved into a Product Manager in the cybersecurity space, I bring a unique blend of user empathy and scientific rigor to product development. My foundation in UX fuels a passion for customer-centric, evidence-based design—ensuring that every product not only achieves strategic goals but also genuinely improves people’s lives.

Over the past 8+ years, I’ve developed a comprehensive perspective on the product lifecycle, consistently advocating for experiences that place users at the heart of every decision. My mission is to shape intuitive, empowering products that help people excel—driving both user satisfaction and sustainable business growth.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABFEgyEBNKEaWVNZw3blhAHSbMvezG-8wWE/
**Connexions partagées** : 33


---

# Ben Maunier

## Position actuelle

**Entreprise** : Flare

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Ben Maunier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391831870646374400 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHR8KAdliB4bw/feedshare-shrink_800/B4EZpUH38gKkAg-/0/1762347942477?e=1766620800&v=beta&t=pPguvzm_ShuvB3kh_33ihAaR9StVEWZBGgpbiQwVxwY | The best is yet to come! | 7 | 0 | 0 | 1mo | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:11:58.860Z |  | 2025-11-05T13:40:51.557Z | https://www.linkedin.com/feed/update/urn:li:activity:7391823027627536384/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387125977685913600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8xa4GoP0A_A/feedshare-shrink_800/B4EZoRVl8.IoAg-/0/1761227465176?e=1766620800&v=beta&t=7QRAKAGcRhQGMZCW-cwHoShhhpqU0npEEW-R0-6y-ng | 🚀 | 7 | 0 | 0 | 1mo | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:11:58.861Z |  | 2025-10-23T14:01:19.244Z | https://www.linkedin.com/feed/update/urn:li:activity:7387123406481149952/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7384204276463456256 | Article |  |  | Proud to have contributed to this incredible milestone at Flare 🚀

With stolen credentials driving 88% of web app attacks (Verizon DBIR 2025) and 50M identities traded weekly across Telegram and the dark web, fast action is critical.

Our new Identity Exposure Management (IEM) automates the detection, validation, and remediation of exposed credentials for organizations — cutting response time from days to seconds and helping security teams act, not just alert. | 12 | 0 | 0 | 1mo | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:11:58.861Z |  | 2025-10-15T12:31:31.390Z | https://www.newswire.com/news/flare-launches-identity-exposure-management-to-combat-50-million-22658197 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7376611238690312192 | Article |  |  | Hello! We’re hiring a Director of UX at Flare — an incredible chance to join a passionate team dedicated to fighting cybercrime.

Our mission is to empower organizations to protect what matters most — their data, their people, and their brand. By uncovering external threats, we help our customers stay ahead of risks and take back control in an increasingly complex digital world.

Feel free to reach out! 

https://lnkd.in/etxKkFym | 33 | 1 | 1 | 2mo | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:11:58.862Z |  | 2025-09-24T13:39:30.113Z | https://flare.bamboohr.com/careers/119 |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7339034027707756548 | Article |  |  | "According to TRM Labs’ 2025 Crypto Crime Report, illicit cryptocurrency transaction volumes reached at least $45 billion in 2024. Although that staggering sum covers every corner of the digital underground, including darknet retail, sanctions evasion, and outright cyber extortion, cybercrime remains one of its most powerful engines."

Excellent work by Oleg O.!

🔗 Read the full article:
👉 https://lnkd.in/edEpBaCB | 13 | 0 | 1 | 5mo | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:12:02.743Z |  | 2025-06-12T21:01:04.864Z | https://www.cybercrimediaries.com/post/from-dirty-crypto-to-clean-money-the-laundering-playbook-of-russophone-cybercriminals |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7270469122566635521 | Article |  |  | "We’re dumping half-baked thoughts on Linkedin, hoping for the recognition we don't get at work. This year, the lack of job security also made designers double down on our “online presence”, in an attempt to remain relevant within their network. We’re writing catchy Linkedin posts to please the algorithm; we’re making our thoughts more polarizing than they need to be. There’s no place for longer-form discussions or nuanced back and forth. We're building echo chambers, not communities. It’s easier to build an audience using controversy than real thought."

https://lnkd.in/e8PDKyTS | 27 | 3 | 0 | 1yr | Post | Ben Maunier | https://www.linkedin.com/in/benjaminmaunier | https://linkedin.com/in/benjaminmaunier | 2025-12-08T06:12:02.746Z |  | 2024-12-05T16:08:37.604Z | https://trends.uxdesign.cc/ |  | 

---



---

# Ben Maunier
*Flare*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Q & A with Tomas Maunier from Fazenda – Sugarvine](https://www.sugarvine.com/blog/q-a-tomas-maunier-from-fazenda/)
*2015-10-29*
- Category: blog

### [AMA & Interviews](https://flare.network/news/category/ama-interviews)
*2025-03-14*
- Category: article

### [Flare Co-Founder: Decentralized Data Will Power ‘Future Value’ of Crypto Industry](https://decrypt.co/292593/flare-co-founder-decentralized-data-will-power-future-value-of-crypto-industry)
*2024-11-21*
- Category: article

### [Q&A: Alex Hooper – Co-founder and CTO, Flare | Retail Bulletin](https://www.theretailbulletin.com/interviews/qa-alex-hooper-co-founder-and-cto-flare-01-05-2024/)
*2024-05-01*
- Category: article

### [Exclusive interview with Flare founder Hugo Philion: How to use "blockchain of data" to promote mass adoption? | MEXC News](https://www.mexc.com/he-IL/news/995)
*2024-10-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
