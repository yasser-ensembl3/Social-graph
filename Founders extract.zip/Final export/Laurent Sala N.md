# Laurent Salaün

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396256542800461824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHpi1aCS9uF5g/feedshare-shrink_800/B4EZqSpVu8GcAg-/0/1763396902916?e=1766620800&v=beta&t=r1iaN0FMbi0hr0RABKizxtlsSPFWj9lL0Sa9exDPc3w | This was our third MIGS, and without a doubt, it was our best one ever.
First, the venue and organization were truly awesome, and it always feels great to see an event of this caliber happening right here at home.
Second, our game was so wonderfully received. We had an absolute blast showing it off, and the enthusiastic reactions from everyone who played were simply the best part of the week!
Thank you to everyone who stopped by, took some time to chat, and played the game. We're leaving energized and can't wait to show you the next version! | 48 | 6 | 1 | 2w | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:08.840Z |  | 2025-11-17T18:42:55.605Z | https://www.linkedin.com/feed/update/urn:li:activity:7396222690518532096/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7345846120088059904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYYYFDhBX4vg/feedshare-shrink_1280/B4EZfGph7ZHIAk-/0/1751384465503?e=1766620800&v=beta&t=jGacNYYxBWKswzMKT41LNRBu6c7YMeZTPOzeca4yFjM | Let's celebrate the prolific Canadian Game industry!! | 15 | 0 | 0 | 5mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:08.840Z |  | 2025-07-01T16:09:54.250Z | https://www.linkedin.com/feed/update/urn:li:activity:7345838875484848128/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7345488921163685888 | Video (LinkedIn Source) | blob:https://www.linkedin.com/01a4b9ed-0943-4927-89e0-8a34ef7d7a9d | https://media.licdn.com/dms/image/v2/D4E05AQFMLkKkVynNtA/videocover-low/B4EZfBlrEjHgCI-/0/1751299580794?e=1765785600&v=beta&t=DhK9ZuQKbmPbq1iBuZmwzDqQvO9pBYUJBhKthtDbp-E | The new playtest of Isles of Krom is now live!
Go play it! 
Share your feedback with us and be the first to defeat the Botanist! | 25 | 1 | 2 | 5mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:08.841Z |  | 2025-06-30T16:30:31.390Z | https://www.linkedin.com/feed/update/urn:li:activity:7345482875829469185/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7341132118829187072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpLj8p8TkkbA/feedshare-shrink_800/B4EZd.aiEGHsAo-/0/1750172575312?e=1766620800&v=beta&t=2T1XFp_TPRLbQSuz_Ql_4YVEuPRjQIdlxin1sgs3OIY | Another great event for the Floppy Team! It's always incredibly exciting and humbling to see other people try your game live.
Now get ready for what's next! | 25 | 0 | 0 | 5mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:08.841Z |  | 2025-06-18T15:58:08.768Z | https://www.linkedin.com/feed/update/urn:li:activity:7340755841131667456/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7336485510418247680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEeMQ4w0I0-7Q/feedshare-shrink_800/B4EZdBusllG4Ak-/0/1749154450145?e=1766620800&v=beta&t=IIbBALqsx7Rp0c82rKo67Ic567gZfrzsihi4yesNS_E | I'll be with Vassili Etienne at Toronto next week for the XP Game Summit to show case Isles of Krom. Join us!

https://islesofkrom.com/

#FloppyGoat #XP25 | 45 | 7 | 0 | 6mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:08.842Z |  | 2025-06-05T20:14:10.993Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7310358501145391104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTqWl9eL43gA/feedshare-shrink_800/B4EZXI5xilHcAw-/0/1742832350012?e=1766620800&v=beta&t=ekxeF2XRDby75l78VOqS-4uaes88LDRNAFQ018DYDOw | First GDC ever! What a great time we had! It was a big thing to check on my to do list. | 17 | 0 | 0 | 8mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:10.922Z |  | 2025-03-25T17:54:46.566Z | https://www.linkedin.com/feed/update/urn:li:activity:7309968699493351425/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7306367977195532288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGZzNQov26YnQ/feedshare-shrink_800/B4EZWVu9aKGYAs-/0/1741973870682?e=1766620800&v=beta&t=i_qwFxv4VJROJpvTGFH5EYCW88WHPLsxwQCqynhuD7g | GDC is next week, and Floppy Goat Inc. will be there!!

I'll be with Vassili Etienne🔜GDC, Benoit Scappazzoni 🔜 GDC and all the amazing folks from the Indie Asylum, CEIM and La Guilde du jeu vidéo du Québec mission.

We'll be more than happy to show you how our first IP, Isles of Krom, is growing.

See you there!

#GDC #IslesOfKrom #IndieDev | 61 | 6 | 1 | 8mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:10.923Z |  | 2025-03-14T17:37:51.516Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7289723822411296768 | Video (LinkedIn Source) | blob:https://www.linkedin.com/345ca374-2fd6-443c-8494-13899bb57416 | https://media.licdn.com/dms/image/v2/D4E05AQH07XJ2rS27Kw/feedshare-thumbnail_720_1280/B4EZSohJ6IHoBA-/0/1737994052857?e=1765785600&v=beta&t=pepyNlV2eJJcQdWzf92Jqke0fQ3ITjd7qBQFrvurdaQ | This is it! The work of our dedicated team! 
Try it! | 33 | 3 | 1 | 10mo | Post | Laurent Salaün | https://www.linkedin.com/in/laurent-sala%C3%BCn-61b58824 | https://linkedin.com/in/laurent-sala%C3%BCn-61b58824 | 2025-12-08T07:04:10.924Z |  | 2025-01-27T19:19:55.782Z | https://www.linkedin.com/feed/update/urn:li:activity:7289688633941348354/ |  | 

---

