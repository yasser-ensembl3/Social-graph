# Evan Ryer

## Position actuelle

**Titre** : CEO & Co-Founder
**Entreprise** : BRAVO READY
**Durée dans le rôle** : 3 years 11 months in role
**Durée dans l'entreprise** : 3 years 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Computer Games

## Description du rôle

• Heading deal flow with VCs and other organizations, raised $3.5M USD.
• Monetization Design, over $3M USD in revenue. 
• Negotiated multiple acquisitions, most recently Honeyland (raised $5M at $25M in ‘23, acquired in ‘25)
• Game & Product Design 
• Financing project as seed investor.

## Résumé

Evan Ryer is a highly motivated leader providing expertise in Software, Product Design, and Emerging Technologies. He specializes in managing teams, taking ideas from concept to fruition, establishing large-scale industrial operations for bare metal assets,  investment due diligence, and business development.

Let's build the future together. 

Current Business Passions: Augmented Reality, Gaming, Lifestyle Technology, Solana, VR, Robotics, Social Communities, FinTech,

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABov25wBLPQURBrDT20-J0KKjQ4lid9Ia88/
**Connexions partagées** : 19


---

# Evan Ryer

## Position actuelle

**Entreprise** : BRAVO READY

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Evan Ryer
*BRAVO READY*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### ['Flappy Bird' Is Making a Crypto Gaming Push After All](https://decrypt.co/323735/flappy-bird-crypto-gaming-push)
*2025-06-04*
- Category: article

### [- YouTube](https://www.youtube.com/watch?v=xJSehRMF7Wo)
*2025-05-13*
- Category: video

### [](https://podcast.theempodcast.com/1953393/episodes/14544003-epi-34-curing-the-cancel-culture-crisis-evan-nierman-red-banyon-ceo)
- Category: podcast

### [The next great recruiters will be grown, not hired](https://content.metaview.ai/evan-connor/)
*2025-10-23*
- Category: article

### [The freeCodeCamp Podcast: #192 Evan You – From Art School Kid to Open Source Legend](https://freecodecamp.libsyn.com/192-evan-you-from-art-school-kid-to-open-source-legend)
*2025-10-10*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Evan Ryer | CEO of Bravo Ready — Decential Media](https://www.decential.io/podcasts/evan-ryer-ceo-of-bravo-ready)**
  - Source: decential.io
  - *Evan Ryer | CEO of Bravo Ready. Evan talks about how you can earn money playing a game while waiting for your Uber. Lights Camera CryptoPodcast · Appl...*

- **[Solana Ventures, Twitch co-founder buy into Bravo Ready's play-to ...](https://betakit.com/solana-ventures-twitch-co-founder-buy-into-bravo-readys-play-to-earn-web3-video-game/)**
  - Source: betakit.com
  - *Jul 11, 2022 ... Podcast · Newsletter · Quiz · Jobs. Solana Ventures, Twitch co-founder ... Bravo Ready co-founder and CEO Evan Ryer grew up playing a...*

- **[Solana Meme Coin Bonk Launches 'Kill-to-Earn' Shooter Game ...](https://decrypt.co/323296/solana-meme-coin-bonk-kill-to-earn-shooter-game)**
  - Source: decrypt.co
  - *Jun 2, 2025 ... Bravo Ready CEO Evan Ryer said that the game will generate ... Podcasts · News Explorer · Bitcoin Halving. About. Team · Disclosures ·...*

- **[Evan Ryer | CEO of Bravo Ready - YouTube](https://www.youtube.com/watch?v=be2NLafMMvo)**
  - Source: youtube.com
  - *Jul 28, 2023 ... CEO of BRAVO READY Evan Ryer discusses leaving an accounting career ... podcast/decent-people/id1607186272 Decent People on Spotify ....*

- **[Lights, Camera, Crypto | Podcast on Podbay](https://podbay.fm/p/lights-camera-crypto)**
  - Source: podbay.fm
  - *CEO of BRAVO READY Evan Ryer discusses leaving an accounting career to mine ... Former DeCent People Podcast guest and Virtual Brand Group (VBG) CEO ....*

- **[2 大Solana 迷因幣熱爆幣圈淘金市場$SOLX 與Bonk 狂吸社群人數令 ...](https://abmedia.io/2-big-solana-meme-coins-are-hot-in-the-gold-rush-market-of-the-cryptocurrency)**
  - Source: abmedia.io
  - *Jun 4, 2025 ... 據Bravo Ready 執行長Evan Ryer 表示，《Bonk Arena》預計將為BONK 帶來龐大的鏈上交易量，並藉此擴展其用戶基礎。目前遊戲已能在網頁與Phantom 錢包 ......*

- **[The Publishing Herald: Homepage](https://thepublishingherald.com/)**
  - Source: thepublishingherald.com
  - *Bravo Ready (1), BravoCon (1), Brazil (3), brazil 2022 (1), brazil's independent ... Evan Ryer (1), Evangeline Lilly (1), eve (1), Eve Crevoshay (1), ...*

- **[Bravo Ready Acquires Honeyland to Expand Web3 Gaming ...](https://playtoearn.com/news/bravo-ready-acquires-honeyland-to-expand-web3-gaming-ecosystem)**
  - Source: playtoearn.com
  - *Jul 11, 2025 ... "This acquisition strengthens our ecosystem and accelerates our multi-product strategy," said Evan Ryer, CEO of Bravo Ready. "It's a ...*

- **[BRAVO READY acquires web3 game Honeyland to boost ...](https://esportsinsider.com/2025/07/bravo-ready-acquires-web3-game-honeyland)**
  - Source: esportsinsider.com
  - *Jul 11, 2025 ... Evan Ryer, CEO of BRAVO READY, emphasised that the acquisition is about more than adding another title. “Honeyland is a beautifully c...*

- **[Solana Meme Coin BONK Launches Web3 Shooter 'Bonk Arena ...](https://playtoearn.com/news/solana-meme-coin-bonk-launches-web3-shooter-bonk-arena)**
  - Source: playtoearn.com
  - *Jun 3, 2025 ... ... Evan Ryer, co-founder and CEO of Bravo Ready, in an interview with Decrypt. Half of the revenue generated by the game will be used...*

---

*Generated by Founder Scraper*
