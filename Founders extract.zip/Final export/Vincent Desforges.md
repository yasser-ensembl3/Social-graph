# Vincent Desforges

## Position actuelle

**Titre** : Co-Founder – Bloom IA
**Entreprise** : Bloom Inc
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Software Development

## Description du rôle

I lead Bloom IA, a Sales AI technology dedicated to improving commercial performance through call analysis and automated coaching.

Key responsibilities:
• Define the AI strategy and product roadmap (MVP → V1 → roadmap 2026)
• Lead Go-To-Market and SaaS model development
• Manage client relationships and early adopters
• Oversee product iterations, market needs, and feature prioritization
• Drive commercial activities, fundraising, and strategic partnerships

Traction & achievements:
• Early revenue generated in pre-product phase
• MVP completed (VoIP technology + post-call analysis + automated coaching)
• First POCs delivered with B2B sales teams
• Active presence in Quebec’s AI ecosystem (Centech)
• Development of our proprietary call analysis model

## Résumé

I co-founded Bloom IA, a Sales AI technology that analyzes calls and strengthens commercial performance, conversation after conversation.

Our belief is simple: sales excellence doesn’t come from dashboards or CRM automation. It comes from the ability to transform every interaction into concrete, measurable improvement.

Bloom IA combines voice analysis, conversation intelligence, and automated coaching to help sales teams sell better, faster, and with more consistency.
We support organizations looking to close the gap between strategic expectations and field execution by giving their teams a real sales coach in their pocket.

If you’re exploring how AI can transform sales performance, I’m always open to connecting.

https://www.bloomai.io/

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACJIh-0BOq_qQhppLUqanydqD-shanN-th8/
**Connexions partagées** : 18


---

# Vincent Desforges

## Position actuelle

**Entreprise** : Bloom Inc

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Vincent Desforges

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402375000747552768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE7doOxgbbzVQ/feedshare-shrink_800/B4EZrqE1hMKMAg-/0/1764863728586?e=1766620800&v=beta&t=qrqoYOgQqkoZb0E_UbBiCoVCkzyhPY-uJoRZcB5xO6M | Des mois intensifs au Centech Mtl.
Et un constat clair : on ne sort pas du programme comme on y entre.

Accélération impose un rythme et une discipline que peu d’entreprises appliquent réellement :
 → Valider le marché chaque semaine (appels, retours terrain).
 → Confronter sa solution au besoin réel.
 → Renforcer sa traction et prioriser ce qui crée de la valeur.

On en ressort plus structuré, plus discipliné, plus lucide.
Mais surtout : on en ressort différent grâce aux personnes qui composent ce parcours.

Au-delà des ateliers, des validations marché, des barrières technologiques et des remises en question, ce sont les échanges, les discussions franches, les moments de doute comme d’élan qui marquent vraiment.

Ce programme crée un environnement rare : exigeant, bienveillant et profondément stimulant.

Ces mois ont compté pour Bloom Inc.

Ils ont aussi compté pour moi.

La suite : Une commercialisation en Q1 2026.

Merci à chaque membre de l’équipe du Centech pour leur passion : Franck Louesdon, Karina R., Martin Enault, Jocelyne Fortier, Myreille Hébert, Marilou Bibeau, Sarah DeGrâce, Daleyne Guay, EMBA.

Et à toute la cohorte : Vous élevez le niveau. Fier d’avancer avec vous : Jean-Marc Lagacé, Mikaël De Lachevrotière, Xavier de Lisle, Alec Neely, Hiba Al Hakim, Daniel Couillard, Marie Membrado, Lylia Bouiche, Paul Bertin, Guillaume Bachelot, Stéphane Mark, Peguy Dountio, M. Ing., Jad A. Taher, Charles Simard, Nurra Barry, Ana Karolyna Naddaf, Hana Maalaoui, Sarah Lavigne, Olivier Fontaine, Jonathan Dubuc, Ania Saadi, Madline Sauvage, Sonia Hudon, Meriem Aissiou. Ishkhan Ishkhanian

L’ambition ne suffit pas.
L’exécution décide.
Et nous sommes prêts.

#Centech #Acceleration2025 #StartupQuébec #TechQuébécoise #Entrepreneuriat #Innovation #SaaS #DeveloppementDAffaires #Leadership #GoToMarket #BloomInc | 57 | 5 | 0 | 3d | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:38.254Z |  | 2025-12-04T15:55:29.655Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399105685889904641 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEsggS5WmB4pA/feedshare-shrink_800/B4EZq7naIsIwAg-/0/1764084262601?e=1766620800&v=beta&t=qxFcTNIa8-_zzXaqBDTL7PaPHUIVY3lUjcMhVJUKqQ8 | Le vrai chemin d’un entrepreneur : construire, déconstruire, puis reconstruire en mieux.

On parle beaucoup de croissance.
On parle moins du travail invisible : tout ce que tu dois casser pour avancer.
Voilà pourquoi une vraie commercialisation peut prendre du temps.

La vérité, c’est que l’entrepreneuriat n’est pas une ligne droite.

C’est une boucle continue.

→ Tu construis une première version.
→ Elle tient… mais pas longtemps.
→ Tu réalises que tes fondations ne sont pas assez solides.
→ Tu déconstruis ce que tu pensais “bon”.
→ Tu reconstruis, mais cette fois avec une vision plus précise, plus exigeante, plus alignée.

Le modèle, ce n’est pas l’ascension. C’est l’itération.
N’est-ce pas, Corentin Alonso ? 📸 

Ce que les autres ne voient pas :
Chaque pivot, chaque révision, chaque remise en question fait partie du jeu.
C’est même l’une des compétences les plus sous-estimées en startup : savoir renoncer pour créer mieux.

Le vrai problème, ce ne sont pas les erreurs.
C’est l’ego qui empêche de les corriger.

Les implications sont simples :
Les entrepreneurs qui progressent sont ceux qui acceptent d’ajuster leur système en continu.

Voici ma position :
Le succès ne vient pas seulement de ce que tu construis.
Il vient de ta capacité à reconstruire, sans relâche, ce qui doit l’être.

Et vous, qu’est-ce que vous avez dû déconstruire récemment pour avancer ?

#entrepreneuriat #tech #innovation #startup #saas #productmanagement #scalabilité #exécution #vision | 38 | 4 | 1 | 1w | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:38.255Z |  | 2025-11-25T15:24:24.252Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397281078979219456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEg4TC9GNVzow/feedshare-shrink_800/B4EZqhr7okIIAg-/0/1763649241149?e=1766620800&v=beta&t=Zmw6Vy2pTv4miqH7X6VorRBom8Br9dAzn2rI6P5gJpU | Aujourd’hui, on a pitché Bloom Inc au Demo Day du Centech Mtl à Ax-C.

Trois minutes. Une salle pleine. Une seule mission : montrer ce que l’IA peut vraiment changer dans la performance commerciale.

→ Les dirigeants demandent plus.
→ Les représentants manquent de soutien réel.
→ Et les organisations pensent que le CRM suffit.

Voici la vérité : le vrai problème, c’est le manque de coaching intégré au quotidien.

Bloom Inc apporte une réponse simple : un coach de vente augmenté qui analyse chaque appel, identifie ce qui fait gagner, et transforme la compétence commerciale en avantage durable. Le but : vendre mieux, vendre plus.

Merci au Centech Mtl pour cette tribune et à Corentin Alonso pour la performance. Merci à toute l’équipe du Centech pour l'organisation (notamment Karina R., Myreille Hébert, Jocelyne Fortier, Sarah DeGrâce...)

Un grand merci à Martin Enault et Franck Louesdon pour la qualité de leur accompagnement tout au long du programme Accélération. Leur expertise, leur regard et leur capacité à transmettre un savoir concret nous ont permis de nous dépasser. 

Un remerciement spécial à notre coach en résidence, Daleyne Guay, EMBA, pour son soutien constant, sa rigueur et sa manière unique de nous pousser à élever notre niveau.

On continue.
Et on accélère.

#Centech #Startup #Entrepreneuriat #Innovation #Tech #SaaS #IA #DemoDay #Vente #pitch | 63 | 2 | 3 | 2w | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:38.255Z |  | 2025-11-20T14:34:04.065Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394768269099978752 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF8lwU76-F8Fw/feedshare-shrink_800/B56Zp9.jZLJsAg-/0/1763050142590?e=1766620800&v=beta&t=7km668mzbRJDDuYi_TAsXaVALHD8yVkhmUnlXo8a9Uc | Les directeurs demandent plus. Les représentants se sentent seuls.
Et tout le monde pense que le CRM va régler ça.

C’est l’erreur la plus répandue dans les organisations commerciales.
On met la pression au sommet.

On demande de la performance en bas.
Mais entre les deux… il y a un vide.

→ Le langage stratégique des dirigeants ne descend pas.
→ Le langage opérationnel des vendeurs ne remonte pas.
→ Le CRM devient une béquille censée tout synchroniser.

Voici la vérité.

Le problème, ce n’est pas le CRM. C’est le gap.

Ce gap crée toujours les mêmes symptômes :

 → Des dirigeants convaincus d’avoir donné de la clarté.
 → Des représentants persuadés d’être livrés à eux-mêmes.
 → Une data CRM incohérente, donc inexploitable.
 → Une pression qui monte, mais aucune montée en compétence réelle.

On passe à côté de l’essentiel. 

Ce n’est pas un sujet d’outillage.
C’est un sujet d’accompagnement.

Quand les équipes ne sont pas coachées dans leur quotidien, aucun système, aussi bien configuré soit-il, ne peut absorber l’écart entre la stratégie et le terrain.

Ce qu’il faut, ce n’est pas plus d’outils.
C’est plus de coaching intégré au quotidien des vendeurs.

Elle vient d’équipes qui savent exactement quoi faire… et comment le faire. C'est ce que nous faisons avec Bloom Inc.

Envie d'en savoir plus ? ➡️ https://www.bloomai.io/

#SalesCoaching #VenteB2B #LeadershipCommercial #SalesEnablement #CRM | 23 | 0 | 1 | 3w | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:38.256Z |  | 2025-11-13T16:09:03.504Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7386762934502260736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQExa3wHXBY_Cw/feedshare-shrink_800/B4EZoMNvu2KoAg-/0/1761141522159?e=1766620800&v=beta&t=QGhppFb-JDO68CbyRwEXhm1B33JItd_udInyxtche38 | 10 ans à soutenir ceux qui osent.

Hier soir, on a célébré les 10 ans de PME MTL dans Ax-C.
On a vu toute la puissance de cet écosystème en mouvement.

Startups, PME, esprits créatifs et cerveaux allumés :
Montréal a du 🔥 dans le ventre.

Et ça fait du bien de se rappeler qu’on n’est pas seuls à vouloir bousculer les modèles.

Chez Bloom Inc, on avance avec la même mission :

 ➤ Rendre les pros de la vente encore meilleurs au téléphone

Merci à PME MTL et à Amel Chatti pour l'invitation.

Merci à toutes celles et ceux qui créent, testent, ratent, recommencent, itèrent.
Ce sont vos idées qui font bouger les lignes.


📸 Tora photography
#BloomINC #SalesCoaching #Centech | 21 | 0 | 1 | 1mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.092Z |  | 2025-10-22T13:58:43.004Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7378770449461088256 | Text |  |  | Fier de voir Corentin Alonso, co-fondateur de Bloom, prendre la parole sur CIBL 101,5 FM pour démystifier l’Intelligence Artificielle et partager une vision inspirante : loin de la science-fiction, l’IA est un allié puissant pour gagner du temps, améliorer nos vies et nous concentrer sur l’essentiel.

Un grand merci à Alexandre Escure pour l’invitation et l’opportunité de nourrir la réflexion autour de ce sujet qui nous passionne chez Bloom. 🙏

🎙 Rendez-vous dès 16h pour écouter l’émission et plonger dans cette conversation stimulante !

#IntelligenceArtificielle #Innovation #HumainAugmenté #BloomIA #CIBL | 18 | 0 | 0 | 2mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.093Z |  | 2025-09-30T12:39:26.077Z | https://www.linkedin.com/feed/update/urn:li:activity:7378425197919506433/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7377002712674185216 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE8BPgBCI0b5Q/feedshare-shrink_800/B56ZmBg34_JoAk-/0/1758814503193?e=1766620800&v=beta&t=5djcVFRQGZEr5iLSVh02jZh5c41tHnazmwZafqeR4SE | L'humain va être remplacé par L'IA

Tout le monde en parle :
 👉 L’IA va bouleverser nos métiers
 👉 L’IA va automatiser nos tâches
 👉 L’IA va même… nous remplacer ?

Chez Bloom, on voit les choses autrement.

On est convaincus que le futur ne s’écrit pas contre l’humain.
Il s’écrit avec lui. Mieux : grâce à lui.

L’IA ne remplace pas le talent. Elle débloque le potentiel.

Imaginez un vendeur/commercial qui :

✔ S’améliore appel après appel grâce à l’IA
✔ Prépare mieux (et plus vite) ses rencontres
✔ Gagne du temps pour ce qui compte : vendre

👉 C’est ça, un humain augmenté !
C’est ça, la mission de Bloom.

L’IA ne va pas vendre à ta place.
Elle va t’aider à mieux le faire.

🔗 Sois le premier averti : https://www.bloomai.io/

Et toi, tu penses que l’IA va remplacer ou augmenter l’humain ? 👇


#IA #IntelligenceArtificielle #HumainAugmenté #VentesB2B #BloomIA #SaaS | 12 | 0 | 0 | 2mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.094Z |  | 2025-09-25T15:35:04.784Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7368662438541484032 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFlMz2GRy8aNQ/feedshare-shrink_800/B4DZkK_b1nHwAk-/0/1756826027212?e=1766620800&v=beta&t=mZzDyM56R3O4hnvjRzJ3-8e_BmgErt7WC-By9q09Txw | 💥 BLOOM 💥 On vient d’embarquer dans l’un des meilleurs accélérateurs de startups au monde : le programme Accélération du #Centech !

C’est une immense fierté de rejoindre cette aventure aux côtés de projets innovants, de coachs de haut niveau… et d’un écosystème qui respire l’ambition.

Mais… pourquoi le Centech alors que vous connaissez surtout #Bloom pour ses formations en développement d’affaires ?

✨ En coulisse, on peaufine quelque chose de grand, depuis presque un an maintenant.
Un projet qui mêle IA, performance commerciale et routines de succès.
On l’appelle déjà Bloom IA... mais 🤫, on vous en dira plus très vite.

La seule chose que je peux vous dire, on ne verra plus la montée en compétences des équipes de vente de la même manière.

Hâte de commencer notre collaboration avec Daleyne Guay, EMBA qui nous suivra lors de ce programme !

Si tu veux qu’on te prévienne quand l’application sort, envoi moi un message en privé. 

Alors restez connectés.
Ce n’est que le début.

#Centech #StartupMTL #MontréalTech #Innovation | 95 | 12 | 0 | 3mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.096Z |  | 2025-09-02T15:13:48.476Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7361775559812468736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHf0RGjOvl64Q/feedshare-shrink_800/B4EZipH2.FHIAg-/0/1755184067630?e=1766620800&v=beta&t=KBeFGNeNyjkFdyA8wPtcXGVfaezRi0bsf4JSFru3FaI | Il pensait que ses meilleurs clients étaient acquis…

Marc, représentant depuis 10 ans, connaissait leurs prénoms, anniversaires, habitudes.
Il m'a dit au début du coaching : « Pas besoin de m’en occuper tant que ça, ils sont fidèles »

Résultat ?
En passant 60 % de son temps à chercher de nouveaux clients :

 1 client de son Top 10 est parti
 2 clients de son Top 10 ont réduit leurs achats

On a agi :
 ➡️ Plan d’action par compte
 ➡️ Points de contact à forte valeur
 ➡️ Visites régulières planifiées 

4 mois plus tard :
 ✅ +18 % de CA sur son Top 10
 ☑️ Client perdu en passe d’être récupéré
 ☑️ Plus qu’un seul client “dans le rouge”

Les meilleurs clients ne partent pas parce que vous avez mal travaillé…
Ils partent parce que vous avez cessé de leur montrer qu’ils comptaient.

❓Et vous, comment entretenez-vous vos Top clients ❓

#Top10Clients #FidélisationClient #CoachingCommercial #StratégieCommerciale #PerformanceCommerciale | 11 | 0 | 0 | 3mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.097Z |  | 2025-08-14T15:07:48.635Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7356693541210714112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvSDEnxev0-g/feedshare-shrink_800/B4EZhg5yrTGwAg-/0/1753972419815?e=1766620800&v=beta&t=OjjK4bIsYE0Bm3fiZ56Qxj0qhmvM1wPQdeRPW6SAS0Q | Je pensais qu’un bon vendeur, c’était un bon parleur. Jusqu’à ce jour-là.

Début de carrière. Rendez-vous avec un grand compte dans les semi-conducteurs.

J’arrive avec mes plus belles slides, je déroule sans tarder mon pitch.
Je parle. Je démontre. Je crois convaincre.
Mais le client reste poli… et distant.

À la fin, il me regarde et me dit :
“Merci pour la présentation. Mais est-ce que vous savez ce que je fais, moi ?”

Silence gênant. Et déclic brutal.

Ce jour-là, j’ai compris : vendre, c’est d’abord écouter.
Poser des questions. Se taire. Reformuler et APRÈS présenter.

Depuis, j’applique une règle d’or : 
👉 70% du temps, c’est le prospect qui parle. 30%, c’est moi.

Le plus fou ?

❌ Aujourd’hui encore, je vois des commerciaux expérimentés monopoliser la parole. Aller trop vite. Parler à la place du client. Combler les silences.
Et parfois même lui couper la parole quand il exprime ses besoins... ❌ 

Un bon pitch, c’est surtout après un bon diagnostic.
Et un bon diagnostic, ça commence par une écoute active.

❓Et vous, c’est quoi le déclic qui a changé votre manière de vendre❓

Je suis curieux de vous lire.

#VenteB2B #LeadershipCommercial #Prospection #SalesTips #EcouteActive #Closing | 23 | 4 | 0 | 4mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.098Z |  | 2025-07-31T14:33:40.981Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7351610726173605890 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFewuXMmckTIQ/feedshare-shrink_800/B4EZgYq_zOGcAg-/0/1752760582186?e=1766620800&v=beta&t=0aYtX3rBPUiNcBnEFntgyKfN928WipzRAfiDs2LVPF0 | “Mes équipes vendent déjà bien, pas besoin de formation.” 

C’est vrai... jusqu’au jour où ça ne l’est plus. On croit souvent que la formation, c’est pour ceux qui débutent. 
Mais en vente, comme dans le sport de haut niveau, ceux qui performent sont ceux qui se forment. Encore. Et encore. 

Et pourtant, les réticences persistent : “Pas le temps” / “Pas le budget” / “On a déjà de l’expérience” 

Mais si on retournait la question ? 
Et si le vrai coût, c’était de ne pas se former ? 

Ce coût, il est souvent invisible : 
 ❌ Des opportunités qu’on ne capte pas 
 ❌ Des ventes qu’on perd sans comprendre pourquoi 
 ❌ Des projets qu’on aurait pu closer plus vite (ou plus gros) 

Chez BLOOM, on forme des personnes de tous niveaux. Et on voit une constante : Ceux qui progressent sont ceux qui acceptent de remettre leur jeu à plat. Pas pour “tout refaire”. Mais pour ajuster, affiner, challenger leurs réflexes. 

Alors, sans pression, je te pose la question : À quand remonte ta dernière vraie montée en compétence ? | 22 | 0 | 0 | 4mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.099Z |  | 2025-07-17T13:56:23.442Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7341464793616121862 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHRWuTNRcJqog/feedshare-shrink_800/B4DZeE9Wy3GgB8-/0/1750282367112?e=1766620800&v=beta&t=BAE_s4eaF72NspI12iSKKb9rHsNXwt_lijauc5b7cX8 | Ceux qui restent, ce sont ceux dans qui on INVESTIT. 

Vous perdez vos meilleurs éléments ?

Et si la vraie question, c’était : qu’avez-vous fait pour qu’ils restent ?

💡 Un talent qu’on ne forme pas, c’est un talent qu’on laisse partir.
💡 Un employé qu’on n’écoute pas, c’est un employé qu’on perd.
💡 Une équipe qu’on ne soutient pas, c’est une équipe qui s’éteint.

Et pourtant, les leviers existent :

➜ ⓵ Coaching personnalisé
➜ ⓶ Formations concrètes (oui, qui donnent vraiment envie !)
➜ ⓷ Accompagnement sur le terrain, pas juste en PowerPoint
➜ ⓸ Onboarding structuré et motivant

✅ On n’achète pas la loyauté d’un collaborateur, on la cultive, un geste à la fois.

👉 Directeurs, vous avez plus de pouvoir que vous ne le croyez.
Misez sur vos talents. Investissez dans leur évolution.

C’est eux qui feront grandir votre entreprise.

Et si on en parlait ?

#Formation #Coaching #Evolution #Ventes #Bloom | 21 | 1 | 0 | 5mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.100Z |  | 2025-06-19T14:00:04.618Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7336397176073244673 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHObEmyJVEF9A/feedshare-shrink_800/B4DZdAeVvpHwAg-/0/1749133389204?e=1766620800&v=beta&t=HsZN8RgJxl6BG_LnrHKrDBOBctDQXdZRcaavWG9qiKg | Un immense merci au Centech Mtl de nous avoir acceuillis dans leurs tout nouveaux bureaux à l'Espace Ax-C. 

On a eu la chance de découvrir de près leur programme Accélération, une belle vitrine de ce que l'écosystème entrepreneurial montréalais a de plus dynamique à offrir !

On repart inspirés, motivés... et prêts à construire de belles synergies.

#Accélération #EntrepreneuriatMontréal #Centech #BusinessDevelopment | 21 | 0 | 0 | 6mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.101Z |  | 2025-06-05T14:23:10.444Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7330599647310176256 | Document |  |  | Tu crois que ton RDV client s’est bien passé ?
Ton prospect, lui, t’a déjà oublié.

On en parle ?
7 erreurs en rendez-vous client.
Des petites bombes à retardement… que tu déclenches sans le savoir.

👉 Dans ce carrousel, tu vas découvrir comment :
 ✔ Éviter les pièges classiques qui ruinent ta crédibilité
 ✔ Reprendre le contrôle sans forcer la main
 ✔ Conclure tes ventes avec assurance (et pas dans l’angoisse)

#ProspectionB2B #VenteStratégique #SalesTips #RDVClient | 15 | 2 | 1 | 6mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.101Z |  | 2025-05-20T14:25:51.874Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7328070678614622208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGTByW8rZBk9A/feedshare-shrink_800/B4EZbKJcsIHwAg-/0/1747148197613?e=1766620800&v=beta&t=rmdVWrtK3pAU9qYwWCHV-kSPETwdoD4xq-u7Ss78K0g | La vente est terminée ? Parfait. Maintenant, le vrai travail commence. 

Appeler un client après la livraison d'un service / produit...
 C’est bien plus qu’un geste commercial.
 C’est un signe de considération. Un vrai moment humain. 

🎯 Pourquoi passer ce coup de fil “post-livraison” ?

➜ Pour savoir si tout s’est bien passé (et le montrer !)
➜ Pour désamorcer un éventuel irritant avant qu’il n’explose
➜ Pour recueillir un feedback à chaud, précieux et sincère
➜ Pour renforcer la confiance → un client écouté, c’est un client fidèle

📞 “Bonjour, je voulais juste savoir comment s’est passée l’installation ?”
 → Simple. Authentique. Puissant.

Ce petit appel :
✅ Crée un point de contact inattendu
✅ Humanise la relation (tu n'appelles pas pour vendre)
✅ Et parfois… génère une nouvelle opportunité (up-sell, reco, témoignage client)

💬 En vrai, on oublie trop souvent que la meilleure fidélisation, 
c’est juste : prendre des nouvelles. 

Parce que l’humain, c’est ce qui reste quand tout le reste change. 🤖 

#RelationClient #ExpérienceClient #VenteHumaine #SuiviClient #Fidélisation | 14 | 0 | 0 | 6mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.102Z |  | 2025-05-13T14:56:38.751Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7323722172684734464 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH3QabZhEG5sA/feedshare-shrink_800/B56ZaMWgFHGoAo-/0/1746111432658?e=1766620800&v=beta&t=WZPZK3w-xMuoBXI_F-nwRBJ3MMu0vi0aUnoI76lJqvI | ❌ Ce n’est pas la motivation qui manque.
❌ Ce n’est pas le marché qui est saturé.
❌ Ce n’est pas non plus votre CRM.

Si vos commerciaux sous-performent, c’est souvent pour 3 raisons cachées :

Ils n'ont pas de cadre clair.
➡️ Ils improvisent à chaque appel au lieu de suivre une méthode éprouvée.

Ils sont formés une fois... puis oubliés.
➡️ La vraie montée en compétences vient du coaching continu, pas d'une formation unique.

Ils n'ont pas de feedback terrain régulier.
➡️ Sans retour d'expérience sur des cas concrets, on répète les mêmes erreurs en boucle.

🔑 Comment on corrige ça chez Bloom ?
Formation ultra terrain en continu ✅
Simulations et jeux de rôles ✅
Coaching en plusieurs étapes, répété jusqu'à maîtrise ✅

Résultats en 3 mois : 
+50% de RDV
-70% de suivis oubliés 
Et des commerciaux de plus en plus motivés !

Ça vous parle ? On en discute ?

#salescoaching #onboarding #businessdevelopment #B2B | 23 | 0 | 0 | 7mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.103Z |  | 2025-05-01T14:57:14.146Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7300893559975530496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEJ2JyFE3aeQ/feedshare-shrink_800/B4EZVH8AOGGYAk-/0/1740668667382?e=1766620800&v=beta&t=3baqAKrMImL2yXYELAwpyi3fZgHuJWHJ9t6QPTCE6wU | Vendre, c’est bien. Fidéliser ses clients, c’est LA clé ! 🔑 

On parle souvent de prospection – mais soyons honnêtes : décrocher un nouveau client coûte plus cher (et plus d’énergie) que de chouchouter ceux qu’on a déjà.

💡 Le secret qui sépare un bon commercial d’un excellent commercial ?

· Le bon vend une fois et passe à autre chose.
· L’excellent bâtit une relation qui rapporte des ventes… encore et encore.

Un client bien suivi, c’est du concret :

✅  Il rachète sans hésiter.
✅  Il recommande à son réseau.
✅  Il t’évite de passer ta vie à prospecter. 

3 réflexes simples pour un suivi client réussi :

📞 Garde le contact : Un appel, un message, un petit "Comment ça se passe pour vous ?" peut déclencher une nouvelle opportunité.

🎁 Apporte de la valeur : Un conseil utile, un partage d’info, une astuce… sois plus qu’un vendeur, sois un allié.

📝 Personnalise tes échanges : Un client n’est pas un dossier Excel. Plus tu le connais, plus tu l’accompagnes avec justesse.

Et bien sûr, la régularité est primordiale !

👉 Et toi, quel est ton meilleur conseil pour fidéliser un client ?

#FidélisationClient #RelationClient #Vente #Business #StratégieCommerciale | 19 | 0 | 0 | 9mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.106Z |  | 2025-02-27T15:04:28.741Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7295819562019635200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKVP25dNoBLQ/feedshare-shrink_800/B4EZT_1O2yHcAg-/0/1739458932621?e=1766620800&v=beta&t=QYouvbcx2AScPW8TRXbwsPX7ZKdeVsWHy8ea8UWBS-Y | "Petit mais puissant : le mindset du lionceau en business !" 🦁🔥

On sous-estime souvent les petits joueurs. Mais regarde ce lionceau en costume : il a l’air prêt à signer des deals, pas vrai ?

En business, ce qui fait la différence, c’est :

✅ La confiance (Même si tu es junior, agis comme un pro)
✅ L’audace (Ose contacter ce prospect que tu penses inatteignable)
💡 On a tous, un jour, signé ce deal que personne ne croyait possible… Jusqu’à ce qu’on le fasse.
✅ L’apprentissage (Chaque échec, chaque retour négatif = une leçon de plus pour grandir)

Les vrais leaders commencent toujours quelque part… et souvent plus petits qu’on ne le pense !

Alors, aujourd’hui, quel est le grand pas que tu vas oser faire ? 

#Audace #GrandirPourRéussir #DéveloppementCommercial | 23 | 0 | 0 | 9mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.107Z |  | 2025-02-13T15:02:13.358Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7293287099145814017 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4kuFqovX4wA/feedshare-shrink_800/B4EZTb19_4GwAg-/0/1738855146039?e=1766620800&v=beta&t=iUSf-v1_7__qQvsP60PK_Gvje5CqUVmPcqyWnhQsh0w | Pourquoi le téléphone met KO l’e-mail ? 🥊

1️⃣ Un vrai échange, pas un monologue en mode "vu" 

Un mail, c’est comme jeter une bouteille à la mer. Un appel, c’est direct, vivant, humain. Tu crées une connexion en quelques secondes avec ta voix, ton énergie, ton charisme (oui oui, même si tu es encore en pyjama).

2️⃣ Les objections ? Terminées en live ! 

"Je dois réfléchir" – ah oui ? Réfléchissons ensemble !
"C’est trop cher" – comparé à quoi ?
Un appel, c’est comme une partie de ping-pong : tu rebondis, tu argumentes, et tu ne laisses pas filer l’opportunité.

3️⃣ Un taux de réponse qui donne le smile 

Les e-mails finissent en mode "Oups, désolé, j’ai oublié de répondre" (t’as pas oublié, on le sait tous).

4️⃣ Une conversation sur-mesure 

Tu ajustes ton discours en fonction de ton prospect. S’il est pressé, tu vas droit au but. S’il est bavard, tu écoutes et tu crées du lien. Bref, fini le copier-coller, place au vrai échange !

5️⃣ Des décisions sur-le-champ 

Un bon call, et c’est un rendez-vous calé, une signature avancée ou une relation amorcée (au lieu d’un "je vais voir et je te reviens… jamais").

👉 Alors, prêt à attraper ton téléphone et faire décoller tes résultats ? 

#Vente #Prospection #ConnexionHumaine #DéveloppementBusiness #SuccèsCommercial | 24 | 3 | 1 | 10mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.108Z |  | 2025-02-06T15:19:07.158Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7290039247447748610 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1dcSLMDPblg/feedshare-shrink_800/B4EZStsEG8GYAg-/0/1738080797690?e=1766620800&v=beta&t=xcsiAndY0JyiK18uz3A9yAUWBfF6K22jbNn8eF9yLYo | ⏰ L’Impact du Timing dans la Prospection : Tout est une Question de Moment !

Vous avez déjà tenté d’appeler un prospect en plein rush du lundi matin ? Mauvaise idée… 😬 Un mauvais timing, et votre appel tombe aux oubliettes. Un bon timing, et BOOM 💥 vous ouvrez la porte à une conversation qui peut tout changer.

💡 Les clés pour un timing parfait :

1️⃣ Le bon jour, la bonne heure = le jackpot 🎯

📞 Pour les appels : Visez mardi et jeudi, entre 9h-11h (bien réveillés, mais pas encore noyés sous les mails) et 16h-18h (avant la déconnexion mentale).
📨 Pour les emails : Envoyez vos messages entre 16h et 17h. Vous serez en haut de leur boîte de réception pile au moment où ils la checkent avant de partir.

⏳ À éviter :

❌ Lundi matin (trop de réunions)
❌ Vendredi après-midi (déjà en week-end mentalement)
❌ L’heure du déjeuner (on ne dérange pas quelqu’un qui mange 🤷‍♂️)

2️⃣ Adaptez-vous au rythme de vos prospects 🕵️‍♂️

💼 Chaque secteur a ses petites habitudes :

👉 Industrie : Plutôt le matin, avant le rush de production.
👉 Startups : Fin d’après-midi, après les meetings interminables.
👉 B2B : Avant ou après la pause déjeuner, quand les boîtes mail sont plus légères.

Alors, ajustez vos montres, affûtez votre discours et… à vos téléphones ! 🚀

#TimingGagnant #ProspectionEfficace #BoostezVosVentes #TechniquesDeProspection #SalesPower | 19 | 3 | 0 | 10mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.109Z |  | 2025-01-28T16:13:18.971Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7284983866187026433 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG0EDVYZ1gi5Q/feedshare-shrink_800/B4DZRl2OHVHYAg-/0/1736875500476?e=1766620800&v=beta&t=nzx7uKjwPqrJnVj96aXdUHDTQH-bOxSZkyzpHi7GFuA | 🤫 Apprivoise le Silence : Un Tuto simple pour tes interactions pro au quotidien

Le silence, ce n’est pas seulement pour les pros de la négo. C’est une arme redoutable, même dans des situations simples qu’on vit tous au travail. 

Teste ces 3 exercices faciles et vois la différence :

1️⃣ En réunion : Pose une question, puis tais-toi.
👉 Exemple : "Quel est ton avis sur ce plan ?"
🔍 Pourquoi ça marche ? Tu laisses de l’espace pour des réponses réfléchies. Si la réponse ne te convient pas, reste silencieux. Ton interlocuteur va souvent approfondir ses propos pour combler le vide.

2️⃣ Face à une critique : Respire et compte mentalement jusqu’à 5.
👉 Exemple : Ton manager te dit : "Ce rapport aurait pu être plus précis."
✅ Ce que tu fais : Pause. Pas de défense immédiate. Attends quelques secondes, puis réponds calmement : "Qu’est-ce que tu entends par là exactement ?"
🔍 Le résultat : Tu évites de réagir impulsivement et tu montres de la maîtrise, tout en obtenant des précisions utiles.

3️⃣ Dans une discussion tendue avec un client : Fais une pause après avoir exprimé ton point de vue.
👉 Exemple : "Je pense qu’il serait judicieux de revoir nos priorités pour ce projet." (pause de 3 secondes)
🔍 Pourquoi ? Tes mots prennent plus de poids, et tu laisses à l’autre le temps d’assimiler ton message avant de répondre.

À tester aujourd’hui :
Fais une pause de 3 secondes après une question ou une affirmation clé.
Note la réaction des autres : parlent-ils plus ? Sont-ils plus attentifs ?

Teste, ajuste, et vois ce qui fonctionne pour toi. 

#CommunicationPro #SilenceEfficace #SoftSkills #CoachingVente #TechniquesDeCommunication | 20 | 0 | 0 | 10mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.110Z |  | 2025-01-14T17:25:02.154Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7272992778609950723 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6ca905ef-1951-4aff-91ce-13a480c29620 | https://media.licdn.com/dms/image/v2/D4E05AQHyXiKu3y8QTQ/videocover-low/B4EZO7cVuUHsCQ-/0/1734016592135?e=1765782000&v=beta&t=oqB7BZ5dNrLtYFBpBaJlvHU69iVR4AXbl_UisPj6VVc | Non, tu n’es pas intrusif : tu fais ton travail ! 

👉 Approcher de nouveaux clients ou partenaires n’est pas une intrusion, c’est une démarche proactive essentielle pour construire des opportunités. Le secret ? Transformer cette approche en une interaction utile et enrichissante pour les deux parties.

🔸 Tu es là pour aider : Quand tu te présentes avec une intention claire et des solutions concrètes, tu apportes de la valeur, pas une gêne.

🔸 La clé, c’est le respect : Adapte ton timing, personnalise ton message et fais preuve d’écoute. Cela montre que tu considères ton interlocuteur comme une priorité, pas comme un simple contact.

🔸 L’intrusion, c’est un mythe : Si ton approche est sincère, professionnelle et orientée vers les besoins de l’autre, elle sera perçue comme une opportunité, pas une interruption.

💡 Rappelle-toi : le développement de marché, c’est semer des graines. Chaque appel ou message bien pensé est une chance de créer une connexion authentique. 🚀

#DéveloppementDeMarché #RelationsHumaines #Opportunités #Professionnalisme #ÉcouteActive #Sora | 23 | 2 | 1 | 11mo | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.111Z |  | 2024-12-12T15:16:44.092Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7270844964643778560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEy5loc7yWc8A/feedshare-shrink_800/feedshare-shrink_800/0/1733504524347?e=1766620800&v=beta&t=zQhS5_7NJIaOGUDgsgp630Cj3-FiTDgUj0XFZaKdaIo | Un grand merci à Propulsion Quebec, Michelle LLambias Meunier et son équipe pour cet événement inspirant sur les véhicules électriques et innovants.

Merci à Romain Gayet (Propulsion Québec), Olivier Bernatchez (Dana TM4), Edwin Richard (Nationex), et Mathieu Chevigny (Institut du Véhicule Innovant) pour leurs interventions intéressantes et leur vision de la transition énergétique.  🚗⚡

Et enfin, merci à Dana TM4 pour l'accueil et la visite de ses installations. 

Le Québec a un bel avenir devant lui, porté par l'innovation et l'engagement vers des solutions durables.

#Innovation #VéhiculesInnovants #PropulsionQuébec #TransitionÉnergétique | 27 | 0 | 2 | 1yr | Post | Vincent Desforges | https://www.linkedin.com/in/vincentdesforges | https://linkedin.com/in/vincentdesforges | 2025-12-08T06:19:42.111Z |  | 2024-12-06T17:02:05.338Z |  |  | 

---



---

# Vincent Desforges
*Bloom Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Mark DeSantis](https://www.frontlines.io/podcasts/mark-desantis-ceo-of-bloomfield/)
*2024-02-15*
- Category: podcast

### [Vincent DESFORGES - Real estate agent on Properstar](https://www.properstar.ph/real-estate-agent/vincent-desforges)
*2024-07-23*
- Category: article

### [Contact Vincent DESFORGES - immobilier à Nilvange](https://vincent-desforges.optimhome.com/en/contact)
*2025-01-01*
- Category: article

### [12 or 20 (second series) questions with Jaclyn Desforges](https://robmclennan.blogspot.com/2023/02/12-or-20-second-series-questions-with_0368044892.html)
*2023-02-12*
- Category: blog

### [5 Questions for Jaclyn Desforges](https://youngadulting.ca/2021/01/04/5-questions-for-jaclyn-desforges/)
*2021-01-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
