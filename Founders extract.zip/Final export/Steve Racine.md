# Steve Racine

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Relevance Studio
**Durée dans le rôle** : 5 years 11 months in role
**Durée dans l'entreprise** : 5 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Description du rôle

CEO of Relevance Studio (Montreal). We transform career pages into immersive recruitment platforms with video, AI, and seamless ATS integration. Our clients include Cirque du Soleil, Desjardins, Metro, and more.

Passionate about reinventing recruitment, I help companies stand out, attract top talent, and turn candidate experience into a true competitive advantage.

## Résumé

I help businesses transform their recruitment strategies to attract top talent and optimize candidate experience through innovative SaaS solutions.

At Relevance Studio, we specialize in converting job seekers into engaged candidates by optimizing career pages and integrating seamless recruitment tools, all without disrupting your existing workflow.  If you're ready to take your recruitment to the next level and attract the best talent, let's connect and discuss how Relevance Studio can help you achieve your goals.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACU_KQBss6zIoSutPQvggX-yrpJQ-kv3eE/
**Connexions partagées** : 146


---

# Steve Racine

## Position actuelle

**Entreprise** : Relevance Studio

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Steve Racine

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7388890958810996736 | Article |  |  | Le merveilleux et magnifique nouveau portail de recrutement de Jean Coutu est maintenant en ligne:
https://lnkd.in/edMg_uiQ | 38 | 3 | 8 | 1mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.107Z |  | 2025-10-28T10:54:43.536Z | http://talent.jeancoutu.com/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387226928690126850 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHyY7iEGji4-A/feedshare-shrink_800/B4EZoSzvx3KgAg-/0/1761252146830?e=1766620800&v=beta&t=0mGwLozZ2eHmMz6LBJQ_pScv0W4nX3z7RhgWY9FKKQc | Quelque chose de gros s'en vient / Something big is coming.... https://lnkd.in/e8Tj6GHd | 24 | 0 | 0 | 1mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.107Z |  | 2025-10-23T20:42:27.839Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7381283172166115329 | Article |  |  | À lire absolument: https://lnkd.in/eyzYarfj | 5 | 0 | 0 | 2mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.107Z |  | 2025-10-07T11:04:05.854Z | https://lessourceshumaines.ca/fr/blogue/pourquoi-vos-ats-decoivent-encore-vos-candidats |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7380931809540329472 | Article |  |  | Un accomplissement digne de mention !  Nous sommes en ligne depuis ce matin avec le Centre de services scolaire des Mille-Iles (CSSMI).  Nous avons réussit, à la demande du client, de livrer complètement un nouveau portail + un ATS complet et tout ceci en seulement 3 semaines. 🥳 🦾   Ceci fait de Relevance Studio un partenaire de tout premier choix !! https://lnkd.in/eVHhYZtG | 30 | 4 | 0 | 2mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.108Z |  | 2025-10-06T11:47:54.476Z | https://emplois.cssmi.qc.ca/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7371986092339675136 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGx37A8OHbaag/feedshare-shrink_800/B4DZk6BRsqJgAg-/0/1757615069697?e=1766620800&v=beta&t=0SjE68OoCBsETVEikPobXvIat2uVpibfwT6KqWv_I-g | Une matinée productive avec des gens fantastiques Laurentian Bank | 3 | 0 | 0 | 2mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.109Z |  | 2025-09-11T19:20:49.292Z | https://www.linkedin.com/feed/update/urn:li:activity:7371971945132699649/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7363844089722597380 | Text |  |  | 🚀 Grande nouvelle chez Relevance Studio !

Nous sommes fiers d’annoncer une entente stratégique de 5 ans avec le Centre de services scolaire des Mille-Îles (CSSMI), l’un des plus grands du Québec :
🏫 82 établissements (61 écoles primaires, 13 écoles secondaires)
👩‍🎓 Des dizaines de milliers d’élèves desservis

Dans un contexte de pénurie critique d’enseignants et de personnel scolaire, notre technologie va jouer un rôle clé pour attirer et retenir les meilleurs talents.

⸻

💡 Pourquoi c’est important

✅ Notre portail carrière et notre ATS/CRM vont soutenir le CSSMI dans ses efforts de recrutement et d’expérience candidat
✅ Déjà adopté par 400+ entreprises québécoises, notre ATS/CRM a prouvé sa robustesse
✅ Innovation, automatisation et performance mesurable, là où les besoins sont les plus urgents

⸻

🌟 Ce que ça démontre

📌 Relevance Studio est un acteur incontournable, autant dans le privé que dans l’éducation publique
📌 Notre plateforme est une solution SaaS évolutive, pas un simple outil
📌 Nous répondons aux enjeux critiques du marché du travail avec efficacité

⸻

🙌 Si un organisme comme le CSSMI nous fait confiance pour moderniser son recrutement à grande échelle, imaginez ce que nous pouvons faire pour vous.

👉 N’hésitez pas à me contacter pour en discuter !!! | 40 | 16 | 1 | 3mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.110Z |  | 2025-08-20T08:07:24.597Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7354607662795235328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGtVMDv17XsLQ/feedshare-shrink_800/B4EZhDQsW7HEAg-/0/1753475107970?e=1766620800&v=beta&t=yPq49H298dMZ4-_Pr3QEXMwg0tljzRGXImKrsYSlNyU | 🔍 Pourquoi autant d’entreprises font encore affaire avec des agences/entreprises ou des consultants qui n’ont jamais, au grand jamais, fait de recrutement pour vrai ?

Je parle de ceux qui n’ont jamais lu un CV, jamais mené une entrevue, jamais eu la pression de combler un poste difficile avec un bon fit.

 Mais qui vendent quand même des services en “expérience candidat” ou en “marque employeur” parce que c’est à la mode.

👉 Avant de signer avec quelqu’un comme ça, pose une seule question :
« As-tu déjà recruté pour vrai ? »

Parce que confier ton recrutement à quelqu’un qui n’a jamais fait ça,
 c’est comme te faire opérer par un mécanicien…
 Oui, il est bon avec des outils. Mais c’est pas ça le point.

💬 Et si ces gens-là étaient vraiment des experts, alors explique-moi :
* Pourquoi chercher une job, c’est encore aussi plate ?
* Pourquoi on voit encore des offres d’emploi qui veulent rien dire ?
* Pourquoi ça n’évolue pas ? Juste du texte, encore du texte, tout pareil ?

🚨 Le recrutement mérite mieux.
 Fais affaire avec des gens qui comprennent vraiment les candidats, les recruteurs, puis les vraies affaires.
#Recrutement #MarqueEmployeur #RH #ExpérienceCandidat | 4 | 1 | 0 | 4mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:53.110Z |  | 2025-07-25T20:25:08.813Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7349391417003180032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFXovWZsHehJQ/feedshare-shrink_800/B4EZf5Ii6IGwAk-/0/1752231457527?e=1766620800&v=beta&t=rkJzW2Z7vn_Oj7GQTdNdM7DzAaySIqyej5nRsE7ObC4 | Vraiment ?  Et oui...mais vous ne croyez pas que les choses devraient un peu évoluer en 2025 ?
#recrutement #rh | 7 | 1 | 0 | 4mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.176Z |  | 2025-07-11T10:57:38.903Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7348685668119707648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGrM-0llP6bdA/feedshare-shrink_800/B4EZfvGrF5GwAs-/0/1752063194438?e=1766620800&v=beta&t=ZEDMCfbnXlPHNFWTaPQ8UvMBR4DfVb2Gfj3yQK_c2xo | Il ne faut JAMAIS oublier que vos candidats sont potentiellement et très souvent vos clients !! 
#recrutement #rh #emploi | 3 | 0 | 0 | 4mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.177Z |  | 2025-07-09T12:13:15.257Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7348324060562399233 | Poll |  |  |  | 3 | 5 | 0 | 4mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.177Z |  | 2025-07-08T12:16:21.297Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7342982649952559104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGhveyI3kzfnA/feedshare-shrink_800/B4EZeeDzhHG4Ag-/0/1750703488390?e=1766620800&v=beta&t=kjxMm0tIRKH1poLgJtX57kryR6MT1pxOe_SipCdUPwo | 💼 Did you know that the very first job posting in a newspaper dates back to... 1705?
 It was a call for “a man able to drive a team in Boston”!
💻 And the first online job posting?
 That was in 1992, on Online Career Center (OCC) — a pioneering site… which later became Monster.
📅 1705 → 1992 → 2025
 ➡️ And yet… job postings have barely changed in over 300 years.
According to our clients' analytics, candidates spend an average of 4 seconds reading a job post.
Everyone laughs when they hear:
 "Oh, we've always done it this way!" 😆
 But seriously...
Are your job postings really any different from those written 300 years ago?
👉 Don’t tell me to be creative and original with the writing — no one reads it.
 Tell me how you are different... I’m genuinely curious.
#recruiting #hiring #jobposting #talentacquisition #HRtech #futureofwork #employerbranding | 1 | 0 | 0 | 5mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.178Z |  | 2025-06-23T18:31:29.769Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7342982369051631616 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGkzNpT1u6z8Q/feedshare-shrink_800/B4EZeeDjU1HwAg-/0/1750703422037?e=1766620800&v=beta&t=VGcVOwmx8nK8M9H5wUHgCF9goNW1bI-1WQv557YK5J4 | 💼 Saviez‑vous que la toute première offre d’emploi publiée dans un journal remonte à… 1705 ?
 Un appel pour “un homme capable de conduire un attelage à Boston” !
💻 Et la première offre d’emploi sur Internet ?
 C’était en 1992, sur Online Career Center (OCC) — un site pionnier… qui allait devenir Monster quelques années plus tard.
📅 1705 → 1992 → 2025
 ➡️ Et pourtant… les offres d’emploi n’ont pratiquement pas changé depuis plus de 300 ans.
Selon les données analytiques de nos clients, les candidats passent en moyenne 4 secondes à lire une offre.
Tout le monde rigole quand on entend :
 “Ah, on a toujours fait comme ça !” 😆
 Mais sérieusement…
Vos offres d’emploi sont-elles vraiment différentes de celles d’il y a 300 ans ?
👉 Ne me dites pas qu’il faut être créatif et original dans vos textes : personne ne lit ça.  Dites-moi en quoi vous êtes différent...je suis très curieux ? | 6 | 0 | 0 | 5mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.179Z |  | 2025-06-23T18:30:22.797Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7341832606616829952 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8gYH_J_FvAw/feedshare-shrink_1280/B4EZeNt1RVHsAk-/0/1750429295148?e=1766620800&v=beta&t=P-E_jQ8mhJYQGksWYMLAhh90iZnEhXe32xny_VAOMw4 | Merci beaucoup à La Vie En Rose de nous avoir invité en tant que fournisseurs pour fêter les 40 ans de la marque.  Ce fût une soirée mémorable ! 👏 🎉 🥳 | 14 | 0 | 0 | 5mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.179Z |  | 2025-06-20T14:21:38.071Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7335258584429043712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETVEMwD3Ww9w/feedshare-shrink_800/B4EZcwSz.NHYAg-/0/1748861928115?e=1766620800&v=beta&t=Nxtw60E-TRV98rTfstIy0q_EYp6f8wjKCQX_hSjx51A | ❌🚫 Ça n’a aucun sens d’utiliser des plateformes externes pour postuer sur vos offres d’emploi ! 🚫❌
Imaginez : vous achetez un objet sur un site Shopify 🛒, vous êtes redirigé(e) pour payer sur Amazon 📦… et 8 secondes plus tard, Amazon envoie un produit similaire à moindre coût ! 😱💸
➡️ Pire encore, quand vos candidats postulent via un portail externe (Jobillico, Indeed, LinkedIn, etc.), et ces plateformes se permettent d’envoyer immédiatement des offres de vos concurrents à VOS propres talents ! 🔄🎯
🙅‍♀️🙅‍♂️ Pourquoi laisser un tiers capter et distraire vos meilleurs profils ?
Vos candidats méritent une expérience fluide, cohérente et respectueuse de leur temps. ⏳❤️
En redirigeant vers une plateforme externe, vous perdez le contrôle de votre message employeur et de votre marque. 🎭🔍
Vos concurrents profitent de cette ouverture pour vous voler la vedette et vos talents ! 🚀✨
💡 La solution ?
Investissez dans votre propre portail de carrière (SaaS, AI, multilingue)…
Offrez une expérience 100 % immersive : pages d’entreprise attractives, formulaires simples, suivi en temps réel, témoignages vidéo… 🎥🤖
Gardez vos données et vos candidats sous contrôle, sans passer par des intermédiaires. 🔒📊
🔑 Travailler, c’est important ! N’exposez pas vos candidats à des distractions inutiles. Créez un environnement où ils se sentent valorisés et engagés, dès la première visite sur votre site Carrières. 🌟🚀
#Recrutement #TalentAcquisition #EmployerBranding #ExpérienceCandidat #Innovation #RH #ATS #MarqueEmployeur | 10 | 0 | 0 | 6mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.184Z |  | 2025-06-02T10:58:49.042Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7335049193327124483 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGk3BFUHZymsw/feedshare-shrink_800/B4EZctUXdRHYAg-/0/1748812004528?e=1766620800&v=beta&t=Z-iYin_Xz0AEwq_uyScJdppfjQPjM2rzL-nSw6C-gpU | 🤔 Pourquoi la recherche d’emploi est-elle si plate ? 📰➡️💻
Avant, on feuilletait les annonces classées dans les journaux… Aujourd’hui, ce sont toujours des annonces classées, mais en version web ! Pourtant, chercher un job ne devrait pas être ennuyeux, car travailler, c’est important. 🚀
👉 Employeurs, faites des efforts pour vous démarquer !
 • Rendez vos offres attrayantes : racontez votre histoire, partagez votre culture d’entreprise, ajoutez des visuels inspirants. 🎬
 • Offrez une expérience interactive : vidéos de présentation, témoignages d’équipes… 🗣️🎥
 • Soyez transparents : précisez clairement le rôle, la croissance possible, les avantages… 📈🎯
 • Impliquez votre marque : montrez ce qui rend votre environnement de travail unique ! 🌟
La recherche d’emploi peut (et doit) être excitante, tant pour les candidats que pour les recruteurs. Transformons ensemble ces annonces classées en opportunités captivantes ! 💥
#Recrutement #EmployerBranding #ExpérienceCandidat #Innovation 🚀 | 6 | 0 | 0 | 6mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.184Z |  | 2025-06-01T21:06:46.313Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7330604704424493056 | Article |  |  | La Vie en Rose
Un espace moderne, inspirant et 100 % pensé pour mettre en valeur la culture, les équipes et les opportunités incroyables chez La Vie en Rose. 💖🎥
Curieux de voir à quoi ressemble une expérience candidat qui se démarque ? Découvrez-le ici 👇
#Recrutement #ExpérienceCandidat #Innovation #LaVieEnRose

https://lnkd.in/eXjC8X-H | 9 | 0 | 0 | 6mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.185Z |  | 2025-05-20T14:45:57.584Z | https://talent.lavieenrose.com/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7328400525933035520 | Article |  |  | 🎙️ J’ai eu le plaisir de participer à une entrevue avec Efience, animée par le dynamique Alexandre Maher.
On y parle de :
 👉 L’importance de l’expérience candidat (et pourquoi elle est souvent négligée)
 👉 Comment Relevance Studio aide les entreprises à se démarquer pour attirer les meilleurs talents
 👉 Mon parcours, ma vision du recrutement... et ce qu’on peut apprendre du Cirque du Soleil, Metro, Desjardins et d’autres grands joueurs 👀
🔗 Pour voir l’entrevue complète : https://lnkd.in/ejMsuZsM
Merci à toute l’équipe pour cette belle invitation !
 #recrutement #expériencecandidat #RH #talentacquisition #RelevanceStudio | 6 | 1 | 1 | 6mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.186Z |  | 2025-05-14T12:47:20.480Z | https://www.youtube.com/watch?v=k565OBuxtNQ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7308921635196002304 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHAq2ZXqqocKA/feedshare-shrink_800/B4EZW6BfyQHMAk-/0/1742582710208?e=1766620800&v=beta&t=0inqeTtZbhYR4-h7sGj3OyGen2f3PfGrF3wkdfWdFsw | Une super nouvelle à partager !  Depuis hier, Relevance Studio est devenu officiellement un partenaire certifié SAP !! 😊   Alors, si vous utilisez les technologies de SAP, vous savez à qui vous adresser pour rendre votre recrutement incroyable !! 😇 | 34 | 6 | 0 | 8mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.187Z |  | 2025-03-21T18:45:11.028Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7294411913394814976 | Text |  |  | 🎯 Rethinking Talent Selection: A Fresh Approach
🚀 Hiring the best talent is a top priority for every organization. Many invest heavily in multi-step selection processes to pinpoint the "best of the best." But is this the most effective approach?
🔍 Recent research by Monika Kackovic & Dirk Deichmann suggests that traditional selection methods can lead to indecision and inefficiencies. Instead, they propose a more inclusive and strategic way to approach hiring:
✅ Expand selection criteria beyond just hard skills—focus on diversity and cultural fit.
 ✅ Engage experts early in the process to gain different perspectives and improve decision-making.
 ✅ Build a community of finalists to foster collaboration, inclusivity, and adaptability.
💡 The result? A more efficient hiring process, greater organizational diversity, and teams that adapt faster to challenges.
🤔 How does your organization approach talent selection? Have you seen positive changes from adopting inclusive hiring practices? Let’s discuss! 👇 #Hiring #TalentSelection #Diversity #Innovation | 8 | 2 | 0 | 9mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.188Z |  | 2025-02-09T17:48:43.773Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7276598202747764736 | Text |  |  | https://lnkd.in/e4Z6Qy8k | 6 | 0 | 0 | 11mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.189Z |  | 2024-12-22T14:03:24.192Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7276598047462064128 | Text |  |  | L’IA et le recrutement : une solution sans biais ? | 13 | 2 | 0 | 11mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.189Z |  | 2024-12-22T14:02:47.169Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7273343939405918209 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFtgl9V9TzCQ/feedshare-shrink_800/B4EZPAbxP9GQAg-/0/1734100326125?e=1766620800&v=beta&t=bqCnnnhtp7211lIWuvgBPvTyi_cnKOLVus692WIcBLo | Si le Père Noël était sur LinkedIn...🎅🎅🎅🎅 | 8 | 0 | 0 | 11mo | Post | Steve Racine | https://www.linkedin.com/in/steveracine | https://linkedin.com/in/steveracine | 2025-12-08T04:57:58.189Z |  | 2024-12-13T14:32:07.350Z |  |  | 

---



---

# Steve Racine
*Relevance Studio*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Justin Racine Archives - Fluent Commerce](https://fluentcommerce.com/resources/blog/podcast-guest/justin-racine/)
*2025-01-01*
- Category: podcast

### [Steve Cleary from Revelation Media & iBible | Revolutionizing Christian Media: The Vision Behind iBible - Reliant Creative](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/)
*2024-11-27*
- Category: podcast

### [Building Resilient Organizations: Steve Garcia on Navigating Effectiveness in Today’s Rapidly Changing World](https://www.functionly.com/org-design-podcast/building-resilient-organizations-steve-garcia)
*2025-02-28*
- Category: podcast

### [Ep 42: Steve Raggiani by Gourmand](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-42-Steve-Raggiani-e2rq28p)
*2025-05-13*
- Category: podcast

### [Sub Club podcast with Steve P. Young, App Masters](https://revenuecat.com/blog/growth/steve-p-young-podcast)
*2024-11-20*
- Category: podcast

---

## 📖 Full Content (Scraped)

*8 articles scraped, 17,439 words total*

### Justin Racine Archives - Fluent Commerce
*1,816 words* | Source: **EXA** | [Link](https://fluentcommerce.com/resources/blog/podcast-guest/justin-racine/)

Justin Racine Archives - Fluent Commerce

===============

Fluent Order Management named a Leader in The Forrester Wave™: Order Management Systems, Q1 2025

[Access report](https://fluentcommerce.com/forrester-wave-order-management-systems-q1-2025/)

*   [EN](https://fluentcommerce.com/)
*   [FR](https://fluentcommerce.com/?lang=fr)

[![Image 2](https://fluentcommerce.com/wp-content/uploads/2019/07/fluent-commerce-logo.svg)![Image 3: Fluent Commerce logo](https://fluentcommerce.com/wp-content/uploads/fluent-commerce-logo-light.svg)](https://fluentcommerce.com/)
*   [Solutions](https://fluentcommerce.com/resources/blog/podcast-guest/justin-racine/#)

SOLUTIONS 
    *   [Fluent Order Management The powerful platform that drives growth](https://fluentcommerce.com/product/)
    *   [Fluent Big Inventory Intelligent enterprise inventory availability hub](https://fluentcommerce.com/product/fluent-big-inventory/)
    *   [Fluent Order Promising Show customers delivery and pickup options they can trust](https://fluentcommerce.com/product/fluent-order-promising/)
    *   [Fluent Order Orchestration Manage the entire order lifecycle and automate manual processes](https://fluentcommerce.com/product/fluent-order-orchestration/)
    *   [Fluent Store Create flexible pick, pack, ship & pickup experiences](https://fluentcommerce.com/product/fluent-store/)

PLATFORM

    *   [Architecture Cloud-native platform designed for future growth](https://fluentcommerce.com/product/architecture/)
    *   [Orchestration Engine Control how inventory data, sourcing logic and orders are processed](https://fluentcommerce.com/product/omnichannel-orchestration/)
    *   [Order Management Experience (OMX)Get the tools you need to create new workflows and UI components](https://fluentcommerce.com/product/order-management-experience/)

INTEGRATIONS

    *   [Carrier Connectors Quickly connect with multiple carriers](https://fluentcommerce.com/product/carrier-connectors/)
    *   [Commerce Connectors Adobe, commercetools, Salesforce & Shopify](https://fluentcommerce.com/product/commerce-connectors/)
    *   [Commerce Search Connectors Increase conversions from search results](https://fluentcommerce.com/product/commerce-search-connectors/)
    *   [Customer Service Connectors Reduce change management and accelerate rollout](https://fluentcommerce.com/product/customer-service-connectors/)
    *   [Payment & Tax Connectors Quickly connect payment and tax solutions](https://fluentcommerce.com/product/payment-tax-connectors/)

[![Image 4](https://fluentcommerce.com/wp-content/uploads/product-ebook.png) ### Order Management: A fresh perspective From monolith to microservices and beyond Download now](https://fluentcommerce.com/resources/digital-resources/order-management-a-fresh-perspective/)

*   [Use Cases](https://fluentcommerce.com/resources/blog/podcast-guest/justin-racine/#)

    *   [Multibrand / Multi-national Manage inventory availability and fulfillment logic for each region and/or brand](https://fluentcommerce.com/solutions/multi-brand-multi-national/)
    *   [Optimize Fulfillment Increase your fill rate and reduce split shipments](https://fluentcommerce.com/solutions/fulfillment-optimization/)
    *   [Manage in-store pick & pack Create flexible pick, pack, ship & pickup experiences](https://fluentcommerce.com/solutions/in-store-pick-and-pack/)

    *   [Reduce Canceled Orders Get accurate inventory visibility so you can make more sales](https://fluentcommerce.com/solutions/underselling/)
    *   [Single view of inventory Get a unified view of all the inventory you have available to promise](https://fluentcommerce.com/solutions/single-view-of-inventory/)
    *   [Ship From Store Make your inventory work harder](https://fluentcommerce.com/solutions/ship-from-store/)

    *   [Click & Collect / Pickup Manage the buy online pickup in-store (BOPIS) experience](https://fluentcommerce.com/solutions/click-collect/)
    *   [Customer Service Edit orders, manage returns, exchanges and appeasements](https://fluentcommerce.com/solutions/customer-service/)
    *   [B2B Inventory & Order Lifecycle Management Increase supply chain visibility and reduce costs](https://fluentcommerce.com/solutions/b2b/)

[![Image 5](https://fluentcommerce.com/wp-content/uploads/ebook-43-questions-to-ask-a-vendor-thumbnail.png) ### Order Management System selection 43 smart questions to ask a vendor Download now](https://fluentcommerce.com/resources/digital-resources/order-management-system-selection-43-smart-questions-to-ask-a-vendor/)

*   [Industries](https://fluentcommerce.com/resources/blog/podcast-guest/justin-racine/#)

    *   [DTC Brands Grow your DTC business and increase conversions](https://fluentcommerce.com/industry/dtc-order-management/)
    *   [Retailers Increase conversions and roll out new offerings faster](https://fluentcommerce.com/industry/retail-distributed-order-management/)
    *   [Luxury Brands Craft the delivery and pickup experiences your cus

*[... truncated, 24,088 more characters]*

---

### Steve Cleary from Revelation Media & iBible | Revolutionizing Christian Media: The Vision Behind iBible - Reliant Creative
*3,273 words* | Source: **EXA** | [Link](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/)

Steve Cleary from Revelation Media & iBible | Revolutionizing Christian Media: The Vision Behind iBible - Reliant Creative

===============

 Login 

Username or Email Address

Password

- [x]  Remember Me

[Lost Your Password?](https://reliantcreative.org/all4jesus/?action=lostpassword&redirect_to=https%3A%2F%2Freliantcreative.org%2Fpodcast%2Fsteve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible%2F%3Fld-resetpw%3Dtrue%23login)

![Image 11: Loading](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)

 Register 

Don't have an account? Register one!

[Register an Account](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#ld-user-register)

Username

Email

Registration confirmation will be emailed to you.

[Skip to content](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#content "Skip to content")

[![Image 13](blob:http://localhost/2c134f90cbaeaa2b13c472ca71873b51)](https://reliantcreative.org/)

*   [WHO WE SERVE](https://reliantcreative.org/)
    *   [Christian Nonprofits](https://reliantcreative.org/nonprofits/)
    *   [Churches](https://reliantcreative.org/churches/)
    *   [Disciple-Making & Spiritual Formation](https://reliantcreative.org/disciple/)
    *   [Poverty Alleviation & Wholistic Development](https://reliantcreative.org/poverty/)
    *   [Global Missions & Sending Agencies](https://reliantcreative.org/global-missions/)
    *   [Pro-Life Ministries](https://reliantcreative.org/pro-life/)
    *   [Pro-Israel Ministries](https://reliantcreative.org/israel/)
    *   [Church Planting Organizations](https://reliantcreative.org/church-planting/)
    *   [Clean Water Ministries](https://reliantcreative.org/clean-water/)
    *   [Orphan Care & Child Sponsorship](https://reliantcreative.org/orphan-care/)
    *   [Freedom & Justice Ministries](https://reliantcreative.org/freedom-and-justice/)
    *   [Campus Ministries](https://reliantcreative.org/campus-ministry/)
    *   [Faith Enterprise & Marketplace Missions](https://reliantcreative.org/marketplace-missions/)
    *   [Adoption & Foster Care Ministries](https://reliantcreative.org/adoption-foster-care/)
    *   [Addiction Recovery, Homelessness, & Restoration](https://reliantcreative.org/recovery/)
    *   [Agricultural & Creation Stewardship Ministries](https://reliantcreative.org/creation-stewardship/)
    *   [Public Theology & Christian Advocacy](https://reliantcreative.org/advocacy/)
    *   [Prison & Jail Ministries](https://reliantcreative.org/incarceration/)
    *   [Digital Evangelism & Discipleship Ministries](https://reliantcreative.org/digital-discipleship/)
    *   [Leadership Development](https://reliantcreative.org/leadership/)

*   [SERVICES](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#)
    *   [Coaching](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#)
        *   [Major Donor Coaching](https://reliantcreative.org/major-donor-coaching/)
        *   [Leadership Formation](https://reliantcreative.org/storyquest-a-reliant-consultancy-service/)

    *   [Messaging & Strategy](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#)
        *   [Messaging Strategy](https://reliantcreative.org/messaging-for-christian-nonprofits-and-churches/)
        *   [Visual Identity](https://reliantcreative.org/brand-development-service/)
        *   [Brand Guidelines](https://reliantcreative.org/brand-development-service/)
        *   [Content Marketing Strategy](https://reliantcreative.org/content-marketing-service/)
        *   [Copywriting Strategy](https://reliantcreative.org/content-writing-services/)
        *   [Campaign Strategy](https://reliantcreative.org/campaign-strategy-and-development-service/)
        *   [Succession Planning](https://reliantcreative.org/ministry-succession-planning/)
        *   [Augmented Staffing](https://reliantcreative.org/augmented-staffing-service/)

    *   [Digital](https://reliantcreative.org/podcast/steve-cleary-from-revelation-media-ibible-revolutionizing-christian-media-the-vision-behind-ibible/#)
        *   [UX/UI](https://reliantcreative.org/story-based-web-design/)
        *   [Information Architecture](https://reliantcreative.org/story-based-web-design/)
        *   [Web Design](https://reliantcreative.org/story-based-web-design/)
        *   [Web Development](https://reliantcreative.org/story-based-web-design/)
        *   [Content Marketing Execution](https://reliantcreative.org/content-marketing-service/)
        *   [Content Writing](https://reliantcreative.org/content-writing-services/)
        *   [Google Ad Grant

*[... truncated, 63,739 more characters]*

---

### Building Resilient Organizations: Steve Garcia on Navigating Effectiveness in Today’s Rapidly Changing World
*4,777 words* | Source: **EXA** | [Link](https://www.functionly.com/org-design-podcast/building-resilient-organizations-steve-garcia)

Listen to the episode
---------------------

🎧 [Spotify](https://open.spotify.com/episode/7uFG1rDXohWWPTvTK0NXnP?si=c195c95627d1404a), [Apple](https://podcasts.apple.com/us/podcast/building-resilient-organizations-steve-garcia-on-navigating/id1501527726?i=1000667133180) 📺 [YouTube](https://youtu.be/Bs1yMoZBt1M?si=jzWfXqk9U7nefu7d)

Please hit subscribe wherever you consume our podcast ✌️

About the guest
---------------

Steve Garcia, Ed.D., is the co-founder and Managing Partner at Contemporary Leadership Advisors (CLA) and a recognized expert in organizational design and leadership development. With an MBA from the University of Virginia and an Ed.D. in Adult Learning from North Carolina State University, he specializes in leveraging organizational network analysis to foster adaptive and resilient organizations. Learn more about Steve Garcia and his Org Design experience on his [expert page](https://www.functionly.com/author/steve-garcia)

Summary
-------

In this episode of the Org Design Podcast, Tim Brewer and Amy Springer engage with Steve Garcia, co-founder of Contemporary Leadership Advisors, to discuss the evolving landscape of organizational design. Steve shares his insights on how leaders can navigate the challenges of restructuring and enhancing organizational effectiveness in today's rapidly changing business environment.

Key Takeaways:

*   Understanding Organizational Challenges: Steve highlights the differing issues faced by private equity-backed companies and Fortune 500 firms, from missing financial targets to talent retention problems.
*   The Importance of Inclusive Discovery: He emphasizes the necessity of involving a broader range of stakeholders in the discovery phase to understand challenges before implementing solutions.
*   Balancing Speed and Thoroughness: While acting quickly is vital, Steve advises leaders to take the time to gather insights and create a shared understanding of the issues at hand.
*   Continuous Adaptation: The discussion underscores the need for organizations to be more resilient and adaptable in an era of rapid change.
*   Integration of Strategy and Execution: Steve advocates for moving away from traditional cascade goal-setting to a more integrated approach, utilizing tools like OKRs for better adaptability.
*   The Value of External Perspective: He explains how consulting firms can provide valuable insights and facilitate the organizational design process.

Join us for this insightful conversation on building resilient, effective organizations capable of thriving in a fast-paced business landscape.

Show Notes
----------

Contemporary Leadership Advisors - [https://contemporaryleadership.com/](https://contemporaryleadership.com/)

The End of Leadership as we Know it - [Amazon](https://www.amazon.com/End-Leadership-We-Know-Volatile/dp/1394171730/ref=sr_1_1?crid=1GG3S63P23SB&keywords=the+end+of+leadership+as+we+know+it&qid=1685458425&sprefix=the+end+of+leade%2Caps%2C89&sr=8-1)

Transcript
----------

[00:00:00] **Tim Brewer:** That, that little intro section, you're bound to say something super clever when we're not recording and we'll both be like, no,

[00:00:07] **Steve Garcia:** Murphy's Law. And then when you try to recreate it, it just doesn't have the same,

[00:00:10] **Tim Brewer:** yeah, it just didn't work. Just, just say that thing.

[00:00:13] **Steve Garcia:** Yeah, like a bad actor.

[00:00:16] **Tim Brewer:** Right. Well, welcome to the Org Design Podcast. Joining me here today is my co-host, Amy Springer. Welcome Amy back from vacation. Good to have you back. And we are excited to have Steve Garcia with us, co-founder and author. Steve, thanks so much for joining us today on the show.

[00:00:35] **Steve Garcia:** Thank you, Tim and Amy. Really pleased to be here.

[00:00:38] **Tim Brewer:** Well, look, I'm going to hit you with the same question we hit everyone. How the heck did you get into org design? Tell us a little bit about the journey getting to where you're at today.

[00:00:49] **Steve Garcia:** It's a, it's a good question. I think in some way we're all in org design. They say that, the organization that you have today is perfectly designed for the results that you achieve. And I think as leaders we're all, always trying to improve results and so in a sense, we're all always thinking about how do we redesign or optimize the design of the organization? I think I, I got into it in a more formal way, people started, reaching out and asking for help when I became a consultant and it became apparent that pretty much all the problems that we were trying to solve for you know, had their roots, in how the organization was designed and the people that were part of it. So It was really when I became a consultant back in probably 2005 that we really started to focus in a not just on our own organization, but on others as well.

[00:01:45] **Tim Brewer:** Yeah. Did you study, I always wonder what people studied to get into org design. Steve, 

*[... truncated, 22,973 more characters]*

---

### Ep 42: Steve Raggiani by Gourmand
*4,461 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-42-Steve-Raggiani-e2rq28p)

![Image 1: Ep 42: Steve Raggiani](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1733194368696-4f4f689c39a86.jpg)

Ep 42: Steve Raggiani
---------------------

Gourmand Dec 03, 2024

00:00

57:26

[![Image 2: Ep 46: Fidel Caballero](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1751664852099-5632d141ef1ba.jpg) #### Ep 46: Fidel Caballero On today’s episode of Gourmand, I sat down with Fidel Caballero from Corima. We discussed his early career as a chef and his time running a food truck, the crazy story of how he ended up cooking in Shanghai, the process of building the Corima brand and the concept of progressive Mexican cuisine, the experience of earning their first Michelin star, and so much more. So let’s dig in! Jul 04, 2025 58:38](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-46-Fidel-Caballero-e354aau)[![Image 3: Ep 45: Mike Puma](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1747095511014-c6af2f24ead2.jpg) #### Ep 45: Mike Puma On today’s episode of Gourmand, I sat down with Mike Puma from Gotham Burger Social Club. We discussed how Gotham Burger started as a community burger tour, the pop-up to brick-and-mortar journey, how they built their iconic smash burger, building relationships and mutual trust in the industry, and so much more. So let’s dig in!This episode uses Royalty Free Music - (Music: www.bensound.com). May 13, 2025 48:43](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-45-Mike-Puma-e32omnm)[![Image 4: Ep 44: Kevin Cardenas](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1743524219370-9e47355c26a6d.jpg) #### Ep 44: Kevin Cardenas On today’s episode of Gourmand, I sat down with Kevin Cardenas from Solo Diner. We discussed his experience working in fine dining and how the skills translate to his pop-up, how Solo Diner presents Filipino American cuisine through embodying nostalgia while incorporating elements from their position in NYC, the collaborative nature of pop-ups and those who supported them during their first year, and so much more. So let’s dig in! This episode uses Royalty Free Music - (Music: www.bensound.com). Apr 01, 2025 54:18](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-44-Kevin-Cardenas-e30vc99)[![Image 5: Ep 43: Rishi Talati](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1739238110571-9393d9758ce62.jpg) #### Ep 43: Rishi Talati On today’s episode of Gourmand, we sat down with Rishi Talati from Hotplate. We discussed how Hotplate began out of a college dorm, their business model and how they help small food businesses, the trajectory of pop-ups since the pandemic and their importance to the food scene, and so much more. So let’s dig in!This episode uses Royalty Free Music - (Music: www.bensound.com). Feb 11, 2025 45:51](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-43-Rishi-Talati-e2umt0m)[![Image 6: Ep 42: Steve Raggiani](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1733194368696-4f4f689c39a86.jpg) #### Ep 42: Steve Raggiani On today’s episode of Gourmand, I sat down with Steve Raggiani from the 8it app. We discussed how he got his start in experiential marketing, his experience of building the app and finding their niche in the culinary industry, thinking from the perspective of a hungry New Yorker, how they use the app to build community, and so much more. So let’s dig in! This episode uses Royalty Free Music - (Music: www.bensound.com). Dec 03, 2024 57:26](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-42-Steve-Raggiani-e2rq28p)[![Image 7: Ep 41: Alexis Sicklick](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1728677400835-76272f312bc74.jpg) #### Ep 41: Alexis Sicklick On today's episode of Gourmand, I sat down with Alexis Sicklick from Syncopated. We discussed her roles at several iconic NYC restaurants and the importance of women-run kitchens, her Nutcracker themed cookbook, how she implements thematic elements and rhythm into her pop-up menus at Syncopated, and so much more. So let’s dig in! This episode uses Royalty Free Music - (Music: www.bensound.com). Oct 11, 2024 52:42](https://creators.spotify.com/pod/profile/gourmand/episodes/Ep-41-Alexis-Sicklick-e2phstf)[![Image 8: Ep 40: Reid Webster](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/4845797/4845797-1723470952382-3c111f8fd0716.jpg) #### Ep 40: Reid Webster On today’s episode of Gourmand, I sat down with Reid Webster from Bad Larry’s. We discussed how Bad Larry’s started with an epic pizza party in Central Park, how he keeps a fun and lighthearted brand while also honing his techniques as a chef, the camaraderie and community of the pop-up scene in New York, and so much more. So let’s dig in! This episode 

*[... truncated, 32,357 more characters]*

---

### Are you willing to break the rules to succeed? — Steve P. Young, App Masters
*942 words* | Source: **EXA** | [Link](https://revenuecat.com/blog/growth/steve-p-young-podcast)

Sub Club podcast with Steve P. Young, App Masters

===============

![Image 1](https://d.adroll.com/cm/b/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 2](https://d.adroll.com/cm/bombora/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 3](https://d.adroll.com/cm/experian/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 4](https://d.adroll.com/cm/g/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 5](https://d.adroll.com/cm/index/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 6](https://d.adroll.com/cm/l/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 7](https://d.adroll.com/cm/n/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 8](https://d.adroll.com/cm/o/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 9](https://d.adroll.com/cm/outbrain/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 10](https://d.adroll.com/cm/pubmatic/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 11](https://d.adroll.com/cm/taboola/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 12](https://d.adroll.com/cm/triplelift/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)![Image 13](https://d.adroll.com/cm/x/out?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&advertisable=R5ZLI2FJMJFOVP4TEBUELJ)

![Image 14](https://ipv4.d.adroll.com/seg4/R5ZLI2FJMJFOVP4TEBUELJ/C2B3E4BS6ZD23GIQ5R7YNH?adroll_fpc=d89d184262fa16c3f91770b193b8b3a8-1765177983289&pv=35557770763.792564&arrfrr=https%3A%2F%2Fwww.revenuecat.com%2Fblog%2Fgrowth%2Fsteve-p-young-podcast%2F&cookie=&adroll_s_ref=&keyw=&p0=2197&adroll_external_data=&adroll_version=2.0)

[![Image 15: RevenueCat](https://revenuecat.com/static/logo-10968976818e28fd8eee91f66d535d9a.svg)RevenueCat](https://revenuecat.com/ "← Back to the homepage")
*   [Features](https://revenuecat.com/blog/growth/steve-p-young-podcast#)
*   [Solutions](https://revenuecat.com/blog/growth/steve-p-young-podcast#)
*   [Developers](https://revenuecat.com/blog/growth/steve-p-young-podcast#)
*   [Resources](https://revenuecat.com/blog/growth/steve-p-young-podcast#)
*   [Integrations](https://revenuecat.com/blog/growth/steve-p-young-podcast#)
*   [Blog](https://revenuecat.com/blog/)
*   [Pricing](https://revenuecat.com/pricing/)

[Log In](https://app.revenuecat.com/login)[Sign Up](https://app.revenuecat.com/signup)

[Growth](https://revenuecat.com/blog/growth/)

Are you willing to break the rules to succeed? — Steve P. Young, App Masters
============================================================================

And why many of the top apps in your category probably are.

3 min read

![Image 16](blob:http://localhost/ad923bba7a956d92de7f4932cf90c3eb)

![Image 17: Sub Club podcast episode with Steve P. Young](https://revenuecat.com/static/5ff7dc9669d3b0f93d3d3508dbf2f1ab/f2ab1/podcast-blog-steve-young.png)

![Image 19](blob:http://localhost/be3cfa5a4bfaeb5660ef48b88688bc4d)

![Image 20: David Barnard](https://revenuecat.com/static/f48b32303256f201c3f981094bc7e1ae/a9d3e/David-Barnard.JPG-scaled.jpg)

[David Barnard](h

*[... truncated, 8,578 more characters]*

---

### Expérience candidat | Les Sources Humaines
*360 words* | Source: **GOOGLE** | [Link](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 1: etudiant](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-11/etudiants.jpg?itok=e2RTmECG)

04 novembre 2025

##### [Centraliser le recrutement de stagiaires : enfin une solution made in Québec](https://lessourceshumaines.ca/fr/blogue/centraliser-le-recrutement-de-stagiaires-enfin-une-solution-made-quebec)

Il est 9h12 et Leïla, spécialiste acquisition de talent, tente pour la troisième fois d’accéder au portail de l’…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 2: TRU](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-11/capture-d-ecran--le-2025-11-07-a-00.15.12.png?itok=C2q7jrIW)

29 octobre 2025

##### [Retour sur truMontréal 2025 : une journée qui fait école](https://lessourceshumaines.ca/fr/blogue/retour-sur-trumontreal-2025-une-journee-qui-fait-ecole)

Le 31 octobre dernier,…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 3: rv](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-10/capture-d-ecran--le-2025-10-04-a-06.47.49.png?itok=TvRfSnWN)

30 septembre 2025

##### [Pourquoi vos ATS déçoivent (encore) vos candidats ?](https://lessourceshumaines.ca/fr/blogue/pourquoi-vos-ats-decoivent-encore-vos-candidats)

**En 2022, j’avais rencontré Steve Racine, fondateur de SpinCV et Relevance Studio, pour parler de sa vision…**

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 4: r](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-06/riviere.jpg?itok=JKPeAxzo)

03 juin 2025

##### [Et si votre site carrière parlait vraiment aux personnes candidates ?](https://lessourceshumaines.ca/fr/blogue/et-si-votre-site-carriere-parlait-vraiment-aux-personnes-candidates)

**J’ai rencontré**…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 5: NOOTA](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-03/banniere-noota.jpg?itok=R_MZcseA)

05 mars 2025

##### [Noota, l'IA qui capture tout pendant que vous écoutez](https://lessourceshumaines.ca/fr/blogue/noota-lia-qui-capture-tout-pendant-que-vous-ecoutez)

La transcription et l'automatisation des notes d’entrevue sont en plein essor grâce à l’IA. Mais tous les outils ne…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 6: headlinker](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-02/capture-d-ecran--le-2025-02-27-a-09.16.49.png?itok=pWhKEWMl)

27 février 2025

##### [Collaborer pour mieux recruter: le modèle innovant de HeadLinker](https://lessourceshumaines.ca/fr/blogue/collaborer-pour-mieux-recruter-le-modele-innovant-de-headlinker)

Et si les recruteurs indépendants pouvaient transformer leurs candidats non placés…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 7: ia](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-01/capture-d-ecran--le-2025-01-08-a-15.11.01.png?itok=QBTrP5U4)

09 janvier 2025

##### [500 candidatures en une nuit: Le nouveau défi des recruteurs face à l'IA](https://lessourceshumaines.ca/fr/blogue/500-candidatures-en-une-nuit-le-nouveau-defi-des-recruteurs-face-lia)

Imaginez : une personne postule à 500 emplois en une nuit, sans jamais cliquer sur un bouton. C'est aujourd’hui une…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 8: t](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2024-10/capture-d-ecran--le-2024-10-31-a-21.02.04.png?itok=CUhvvpBB)

30 octobre 2024

##### [Mesurez-vous l'impact de votre marque employeur ?](https://lessourceshumaines.ca/fr/blogue/mesurez-vous-limpact-de-votre-marque-employeur)

Comment évaluer une marque employeur qui existe depuis toujours, mais dont l'impact reste difficile à quantifier ?…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 9: Une femme présente des notes autocollantes à des collègues dans une salle de réunion.](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2024-09/atelier.jpg?itok=V_65aizw)

28 août 2024

##### [Créer son Manifeste pour fédérer son équipe en acquisition de talent](https://lessourceshumaines.ca/fr/blogue/creer-son-manifeste-pour-federer-son-equipe-en-acquisition-de-talent)

J'ai souvent constaté dans nos formations que chaque recruteur adopte ses propres méthodes, développées au fil du…

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)![Image 10: truquebec](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2024-05/Capture%20d%E2%80%99e%CC%81cran%2C%2

*[... truncated, 499 more characters]*

---

### Blogue | Les Sources Humaines
*1,104 words* | Source: **GOOGLE** | [Link](https://lessourceshumaines.ca/fr/blogue)

Blogue | Les Sources Humaines

===============
[Aller au contenu principal](https://lessourceshumaines.ca/fr/blogue#main-content)

[![Image 1: Logo Les Sources Humaines](https://lessourceshumaines.ca/sites/default/files/logo_petit.02.png)](https://lessourceshumaines.ca/fr "Home")

[](https://lessourceshumaines.ca/fr/blogue#)

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal](https://lessourceshumaines.ca/fr/blogue)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos](https://lessourceshumaines.ca/fr/blogue)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles](https://lessourceshumaines.ca/fr/blogue)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal](https://lessourceshumaines.ca/fr/blogue)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos](https://lessourceshumaines.ca/fr/blogue)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles](https://lessourceshumaines.ca/fr/blogue)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

*   [en](https://lessourceshumaines.ca/en/blog)

*   [en](https://lessourceshumaines.ca/en/blog)

[![Image 2: Accueil](https://lessourceshumaines.ca/sites/default/files/Logo_Sources_Humaines.png)](https://lessourceshumaines.ca/fr "Accueil")

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal »](https://lessourceshumaines.ca/fr/blogue)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos »](https://lessourceshumaines.ca/fr/blogue)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles »](https://lessourceshumaines.ca/fr/blogue)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

Blogue
------

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/le-chaos-des-partenaires-rh-et-si-pouvait-enfin-comparer-avant-de-choisir)![Image 3: K](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-12/capture-d-ecran--le-2025-12-04-a-19.07.20.png?itok=4nUXeSfZ)

3 décembre 2025

##### [Le chaos des partenaires RH : et si on pouvait enfin comparer avant de choisir ?](https://lessourceshumaines.ca/fr/blogue/le-chaos-des-partenaires-rh-et-si-pouvait-enfin-comparer-avant-de-choisir)

Le marché des services RH est devenu un terrain difficile à lire : offres qui se ressemblent sans être comparables, expertises qui se fragmentent, budgets sous pression et partenaires qui se mult

*[... truncated, 13,869 more characters]*

---

### ATS | Les Sources Humaines
*706 words* | Source: **GOOGLE** | [Link](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)

ATS | Les Sources Humaines

===============
[Aller au contenu principal](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats#main-content)

[![Image 9: Logo Les Sources Humaines](https://lessourceshumaines.ca/sites/default/files/logo_petit.02.png)](https://lessourceshumaines.ca/fr "Home")

[](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats#)

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

*   [en](https://lessourceshumaines.ca/en/blog/tags/ats)

*   [en](https://lessourceshumaines.ca/en/blog/tags/ats)

[![Image 10: Accueil](https://lessourceshumaines.ca/sites/default/files/Logo_Sources_Humaines.png)](https://lessourceshumaines.ca/fr "Accueil")

*   [Formations](https://lessourceshumaines.ca/fr/formations)
*   [TruMontreal »](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Le Concept](https://lessourceshumaines.ca/fr/trumontreal/le-concept)
    *   [TruMontreal 2025](https://lessourceshumaines.ca/fr/trumontreal/2025)
    *   [TruMontreal 2024](https://lessourceshumaines.ca/fr/trumontreal/2024)
    *   [TruMontreal 2023](https://lessourceshumaines.ca/fr/trumontreal/2023)
    *   [TruMontreal 2022](https://lessourceshumaines.ca/fr/trumontreal/2022)

*   [Blogue](https://lessourceshumaines.ca/fr/blogue)
*   [À propos »](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Qui nous sommes](https://lessourceshumaines.ca/fr/a-propos/qui-nous-sommes)
    *   [Notre comité aviseur](https://lessourceshumaines.ca/fr/a-propos/comite-aviseur)
    *   [Revue de presse](https://lessourceshumaines.ca/fr/a-propos/revue-de-presse)

*   [Nouvelles »](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)
    *   [Emplois disponibles](https://lessourceshumaines.ca/fr/nouvelles/emplois-disponibles)
    *   [Ça bouge](https://lessourceshumaines.ca/fr/nouvelles/ca-bouge)

*   [Événements](https://lessourceshumaines.ca/fr/evenements-a-venir)
*   [Contact](https://lessourceshumaines.ca/fr/contact)

ATS
===

[En savoir plus...](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)![Image 11: rv](https://lessourceshumaines.ca/sites/default/files/styles/large/public/blog/2025-10/capture-d-ecran--le-2025-10-04-a-06.47.49.png?itok=TvRfSnWN)

30 septembre 2025

##### [Pourquoi vos ATS déçoivent (encore) vos candidats ?](https://lessourceshumaines.ca/fr/blogue/pourquoi-vos-ats-decoivent-encore-vos-candidats)

**En 2022, j’avais rencontré Steve Racine, fondateur de SpinCV et Relevance Studio, pour parler de sa vision…**

[En savoir plus..

*[... truncated, 8,935 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Stratégies Innovantes pour l'Emploi : Entretien avec Steve Racine ...](https://www.youtube.com/watch?v=k565OBuxtNQ)**
  - Source: youtube.com
  - *May 12, 2025 ... ... relevance.studio/ Vous désirez faire partie du podcast comme invité ? ... Stratégies Innovantes pour l'Emploi : Entretien avec St...*

- **[Expérience candidat | Les Sources Humaines](https://lessourceshumaines.ca/fr/blogue/categories/experience-candidat)**
  - Source: lessourceshumaines.ca
  - *En 2022, j'avais rencontré Steve Racine, fondateur de SpinCV et Relevance Studio, pour parler de sa vision… ... Conférence · Outil · Expérience candid...*

- **[Blogue | Les Sources Humaines](https://lessourceshumaines.ca/fr/blogue)**
  - Source: lessourceshumaines.ca
  - *En 2022, j'avais rencontré Steve Racine, fondateur de SpinCV et Relevance Studio ... J'ai récemment assisté au panel-conférence intitulé "Futur du Tra...*

- **[ATS | Les Sources Humaines](https://lessourceshumaines.ca/fr/blogue/etiquettes/ats)**
  - Source: lessourceshumaines.ca
  - *Pourquoi vos ATS déçoivent (encore) vos candidats ? En 2022, j'avais rencontré Steve Racine, fondateur de SpinCV et Relevance Studio, pour parler de s...*

---

*Generated by Founder Scraper*
