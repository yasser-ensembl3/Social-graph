# Thomas Milan

## Position actuelle

**Titre** : Freelancer – Founder of Sciences À La Carte
**Entreprise** : Sciences À La Carte
**Durée dans le rôle** : 3 years 1 month in role
**Durée dans l'entreprise** : 3 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Online Audio and Video Media

## Description du rôle

I work as a freelance consultant and content creator in science communication. My mission: supporting research organizations, institutions, and nonprofits in showcasing their projects, while developing Sciences À La Carte, my own science communication platform broadcast live on Twitch and YouTube.

📍 Core Services
🎬 Video Production – Science capsules, carousels, social media videos, livestreams.
🎤 Event Hosting – Conferences, panels, festivals, online or on stage.
🧩 Training & Workshops – Science communication, pitching, social media.
🧭 Strategic Consulting – Tailored science communication strategies and content.

📍 Key Clients
FRQ, Génome Québec, Acfas, LaSciencedAbord, Ordre des chimistes du Québec.

📍 Other Notable Collaborations
Oncopole, Conseil de l’innovation du Québec, IVADO, Institut TransMedTech, Réseau Technoscience, Centre Déclic, COlab, European Patent Office, Scilabus (Viviane Lalande), Association des archivists du Québec.

📍 Sciences À La Carte – My Public Showcase
Alongside B2B mandates, I founded Sciences À La Carte, a live science communication channel (Twitch & YouTube). This project acts as an innovation lab where I test new formats and build a curious, engaged French-speaking community.

✅ Hundreds of hours of live science shows (press reviews, interviews, special events).
✅ Partnerships with Acfas, Espace pour la Vie, Réseau Technoscience.

## Résumé

🎯 Looking to showcase a scientific project? Host an event? Produce engaging content?

🧬 As a biologist (PhD) and passionate science communicator, I bridge the gap between rigorous research and the art of creating content that is engaging, accessible, and tailored to your target audiences.

My strength lies in a dual approach:
👉 For organizations (like FRQ, Génome Québec, Conseil de l'innovation du Québec...), I design and implement strategies to transform complex science into impactful content.
👉 For the general public, I host Sciences À La Carte, my own media platform on Twitch. It’s my laboratory for building a community of curious minds and testing formats that truly captivate.

My missions:
🎬 Content production: From ideation to distribution of videos (long and short form), graphics, and accessible science articles.
🎤 Event orchestration: Designing, scripting, and hosting conferences, panels, and workshops (both online and in-person).
🧩 Training & Workshops: Designing and leading custom workshops to empower the scientific community with stronger communication skills (social media, science communication, video production, event management, etc.).
🧭 Consulting & Strategy: Advising on how to optimize your communication strategies, monitor key trends, and maximize your impact.

✅ My added value: Blending scientific rigor with creativity to deliver relevant content that is perfectly aligned with your goals.

👉 Need to make your scientific messages clear and engaging? Let's talk!

🌐 Available in French and English | Disponible en français et en anglais

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACBro5MB_DQbXuh92A0zF1nK-VozMU55MDo/
**Connexions partagées** : 3


---

# Thomas Milan

## Position actuelle

**Entreprise** : Sciences À La Carte

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Thomas Milan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401598761334091776 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEME5OlJ-I6QA/image-shrink_800/B4EZrfC1NsIQAc-/0/1764678654434?e=1765785600&v=beta&t=iACnAKJMiyjTLP0gjQAwKQFtOS4yG4EjxO0IwUOZC1Q | Du nouveau pour Sciences À La Carte ! 🤩

Depuis 3 ans, je mène une sorte de double vie :
👉 créateur de contenu et communicateur scientifique en freelance
👉 et, en parallèle, animateur de Sciences À La Carte, mon projet de vulgarisation en direct sur Twitch

À l’origine, Sciences À La Carte, c’était surtout du direct sur Twitch : on jasait de science, on visitait des musées, on rencontrait des chercheur·euse·s, le tout dans une ambiance relax. Ça le sera toujours mais...

Aujourd’hui, le projet évolue.
🎬 Je déploie désormais Sciences À La Carte sur mes autres plateformes, en vidéos et infographies pour parler d’actualités scientifiques fraîchement sorties des laboratoires, des sujets chauds qui concernent le Québec, le Canada et l'international.

Une nouvelle façon pour moi de tester des formats, de faire de la #science d'une autre manière à l'heure où elle est plus que jamais menacée et surtout de continuer à avoir du fun !

Et si tu veux qu'on collabore ensemble sur un projet en particulier ou si tu souhaites me soutenir dans mon travail, n'hésite pas à me contacter ! 👋 | 98 | 22 | 4 | 5d | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:02.213Z |  | 2025-12-02T12:30:59.757Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399093385028083712 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH7cuzi8UFAdg/image-shrink_800/B4EZq7cOXnKkAc-/0/1764081330738?e=1765785600&v=beta&t=MYAr6PyynQ15maZQVD-ZW8rDJ_lwobGXu7QtFiBwy9w | Toi, comment tu t'y prends pour couper des oignons sans pleurer ? 😅

🥹 On a finalement trouvé comment ne pas pleurer en coupant un oignon... Voici le tuto coupage d'oignon avec Viviane Lalande !
🤖 Une imprimante 3D pour réparer des cordes vocales ?! On s'emballe pas tout de suite !
📵 Téléphone et santé mentale : une nouvelle (grosse) étude nous en dit plus sur cette relation amour haine !
🤫 Et comme d'habitude, notre actualité mystère ! Il paraît que les indices sont faciles pour une fois !

Bonne écoute ! 😊 | 35 | 5 | 0 | 1w | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:02.214Z |  | 2025-11-25T14:35:31.498Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393980824108408832 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHn_x_hyj_s2Q/image-shrink_800/B4EZpyyXJRHcAk-/0/1762862398151?e=1765785600&v=beta&t=wnXG--B7PAGysg-f4HojOwX6QjbUB5KXqChNlTLEecI | 🎥 Dimanche dernier, j'ai eu le plaisir de couvrir en direct sur Twitch pour la 3ème année consécutive, le concours de design industriel, l'Odyssée de l'objet en 48h organisé par le Réseau Technoscience ! ☺️ 

37 objets imaginés en 48 heures par des élèves du Cégep provenant des 4 coins de la province du Québec en lien avec la thématique 2025: objet d'hiver ! ❄️

J'ai condensé tout ça dans un replay qui est disponible sur ma chaîne Youtube (lien en commentaire) ! Dis-moi dans les commentaires si tu as un objet coup de coeur !


******


📢 Si tu souhaites qu'on travaille ensemble pour couvrir en direct un événement scientifique, créer du conteu vidéo pour les médias sociaux ou produire une émission ou un live autour d’un sujet scientifique ➡️ je serais ravi d’en discuter ! | 20 | 2 | 0 | 3w | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:02.215Z |  | 2025-11-11T12:00:01.988Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7393752857868455936 | Video (LinkedIn Source) | blob:https://www.linkedin.com/53680347-52f9-4b91-9c2c-15df5895714d | https://media.licdn.com/dms/image/v2/D4E05AQF3rPerCNgMMA/videocover-high/B4EZpvZrW9GUCI-/0/1762805694693?e=1765785600&v=beta&t=Uv2wbUpvIxJEcvYUVMiDV78MEIeRz8TSWjFXA8omeV0 | 🧬 code Béluga, ça te dit quelque chose ?

Un projet de science participative lancé par Espace pour la vie et Génome Québec dans lequel TU pouvais aider la communauté scientifique à mieux comprendre la biodiversité du Saint-Laurent.

Les premiers résultats sont disponibles et présentés sous forme de carte interactive ! 👇 | 22 | 1 | 1 | 3w | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:02.217Z |  | 2025-11-10T20:54:10.601Z | https://www.linkedin.com/feed/update/urn:li:activity:7393743123270492160/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7374527858565648384 | Document |  |  | Le congrès annuel de l'Association des communicateurs scientifiques à ne pas manquer 👇 

J'aurai l'occasion d'animer un atelier sur le cyberharcèlement en communication scientifique et de présenter un guide de survie. Un projet sur lequel je bosse depuis quelques semaines avec mes collègues Gabrielle Anctil, Estelle Chamoux, Stéphanie Jolicoeur et Gabrielle B Durand. Très hâte de vous en parler au congrès ! | 17 | 0 | 4 | 2mo | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:02.218Z |  | 2025-09-18T19:40:53.584Z | https://www.linkedin.com/feed/update/urn:li:activity:7374514880135208960/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7359255760435884032 | Video (LinkedIn Source) | blob:https://www.linkedin.com/72e32830-1014-4a59-87cb-b7da4f1a5894 | https://media.licdn.com/dms/image/v2/D4E10AQF1bgWe6RFp-A/videocover-high/B4EZh10COlHEBU-/0/1754323260714?e=1765785600&v=beta&t=Ews7BU7nLkZpf9zFwXXQDnN__aNeU50iE2mBjvLWwCc | 🧠 Et si l’on pouvait renforcer sa mémoire… en dormant ?

C’est ce que laisse entrevoir Portiloop, un projet de science ouverte alliant IA et neurosciences, soutenu par le Fonds de recherche du Québec.

Une innovation à suivre de près 🎥

Concordia University Polytechnique Montréal
#communautéFRQ | 14 | 1 | 1 | 4mo | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:04.692Z |  | 2025-08-07T16:15:01.648Z | https://www.linkedin.com/feed/update/urn:li:activity:7358165152166232064/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7358185199546896384 | Video (LinkedIn Source) | blob:https://www.linkedin.com/537da9cb-dfff-4711-862c-4e2a77c660db | https://media.licdn.com/dms/image/v2/D4E10AQGH9UnLX7h8mA/videocover-high/B4EZhrgxnEHoBU-/0/1754150437351?e=1765785600&v=beta&t=FJZuek_eucifbIph1Rf8PUuqqGGiPppTzFSBqSC6_Z8 | 🌧️ 150 mm de pluie en 24h à Montréal.

Quand la tempête Debby a frappé en août 2024, elle a rappelé l’urgence de mieux comprendre et gérer les risques d’inondation au Québec.

Alors, comment le Québec s'organise-t-il pour mieux s’y adapter?

🎥 Avec le Fonds de recherche du Québec, je te parle d'une initiative portée par le RIISQ - Réseau inondations intersectoriel du Québec. Leur mission? Décentraliser la lutte contre les #inondations en s'appuyant sur des antennes régionales, des expertises locales et une approche ancrée dans les réalités de chaque territoire.

#communautéFRQ | 20 | 0 | 2 | 4mo | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:04.693Z |  | 2025-08-04T17:21:00.042Z | https://www.linkedin.com/feed/update/urn:li:activity:7357440281920561152/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7348005758250217475 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7ad081d3-b7e5-4de2-aafb-206ba6bf0fea | https://media.licdn.com/dms/image/v2/D4E10AQGu5VL-dHEqZg/ads-video-thumbnail_720_1280/B4EZffm9zKHsAc-/0/1751803244643?e=1765785600&v=beta&t=y6-dHKuF8cHU8SSey7uyzyYbojpUmUzcmZn5xaHolQ8 | Très fier d'avoir collaboré avec le Fonds de recherche du Québec pour l'écriture, la réalisation et le montage de cette capsule vidéo. La 2ème d'une série de plusieurs vidéos qui présentent des projets propulsés par le FRQ.

Je parle ici d'un projet de recherche mené par l'équipe de Michel Maziade de l'Université Laval. L'objectif : explorer de nouvelles pistes pour la prévention en santé mentale chez les jeunes, en misant sur une aide personnalisée offerte au bon moment.

Merci le FRQ (et Julien Chapdelaine, M.A. !) de me faire confiance!

#santémentale #prévention #recherchescientifique #communication #vidéo | 40 | 1 | 0 | 5mo | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:04.694Z |  | 2025-07-07T15:11:32.112Z | https://www.linkedin.com/feed/update/urn:li:activity:7347595470082351106/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7270563869478027266 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH724zCqfnd1A/feedshare-shrink_800/feedshare-shrink_800/0/1733437506085?e=1766620800&v=beta&t=pST0YS-BRWQPQrTHWDfFcLzrtJICVrPXCdfghg3WE_w | Ça y est ? Tu as un projet de vulgarisation scientifique solide sur lequel tu bosses depuis des jours ? C'est le moment de partager ta passion avec le monde entier ! 🤩🌎

Mais... comment toucher un public plus large que le milieu universitaire ? 🤔

Une grosse question que se posent de nombreuses personnes du monde académique souhaitant faire tomber les murs de leur laboratoire... 🙋‍♂️ 

Et une grosse question à laquelle j'ai dû répondre quand Frédéric Macé m'a approché pour produire une vidéo sur ce sujet pour la plateforme RaccourSci, propulsée par l'Acfas et l'AUF ! Merci pour ce défi !

Comment constuire ma réponse ? En me replongeant dans mon parcours de communicateur depuis 2018, quand j'ai testé tout un tas de formats différents, de la conférence, à l'entrevue radio, en passant par l'article écrit, le kiosque durant un festival de science, Ma Thèse en 180 secondes puis le format vidéo (qui m'allume de plus en plus !). Bref, l'occasion pour moi de faire une rétrospective...

Évidemment que le numérique permet de rejoindre du monde (et c'est ce qui me fait d'ailleurs le plus tripper dans mon métier !) mais il ne faudrait pas oublier ce que j'ai appelé le "monde réel", t'sais, le fait de voir et d'interagir avec des gens en 3D ! 

Je te laisse découvrir tout ça dans mon analyse de la question et la p'tite boîte à outils que je t'offre en moins de 5 minutes ! ⌛

Et toi, c'est quoi ta manière de diffuser tes projets de recherche ? Dis-moi dans les commentaires ! C'est le moment de balancer tes initiatives ! 👇 

👉 Découvre la vidéo complète sur la chaîne YouTube RaccourSci ! Le lien est dans les commentaires !

#vulgarisation #science #communication #comsci #scicomm

ComSciCon-QC ComSciCon France Fonds de recherche du Québec Association des communicateurs scientifiques Sciences 101 - La Fibre Agence PhDesign David Mendes da Silva, PhD | 60 | 2 | 4 | 1yr | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:04.695Z |  | 2024-12-05T22:25:07.028Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7269777760942804993 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEGSaq1it7Acg/feedshare-shrink_800/feedshare-shrink_800/0/1733250082893?e=1766620800&v=beta&t=iUrJJEDMhczzu4eHJKH_WQaI7eJWrWBBZMUw4deje28 | 🔬📢 Nouvelle émission d’actu' scientifique avec Viviane Lalande sur sa chaîne Scilabus !

Dans cet épisode, on discute de pas mal de sujets:
💡 L’effet yo-yo des régimes : pourquoi est-il si difficile de perdre du poids ?
♻️ PFAS et solutions : ces "polluants éternels" pourraient-ils enfin être éliminés ?
🐾 Pourquoi les chiens mouillés se secouent-ils ? Élément de réponse sur ce réflexe !

👀 Dites-nous ce que vous en pensez ! Commentez, partagez, likez ! On vous lit et on prend en compte tous vos commentaires !

🎥 Le lien dans les commentaires !

#Science #Vulgarisation #ActualitéScientifique | 33 | 1 | 1 | 1yr | Post | Thomas Milan | https://www.linkedin.com/in/thomas-milan | https://linkedin.com/in/thomas-milan | 2025-12-08T07:21:04.696Z |  | 2024-12-03T18:21:24.148Z |  |  | 

---



---

# Thomas Milan
*Sciences À La Carte*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Thomas McKinlay 🎓 - Science Says | LinkedIn](https://es.linkedin.com/in/thomasdmckinlay)
*2025-01-01*
- Category: article

### [Podcast | Thomas Scientific](https://www.thomassci.com/Podcast)
*2024-01-01*
- Category: podcast

### [Llama 2, Llama 3, Agents & AGI with Thomas Scialom #55 - AI Stories](https://www.buzzsprout.com/1861907/episodes/16459858-llama-2-llama-3-agents-agi-with-thomas-scialom-55)
*2025-01-23*
- Category: article

### [Podcast: Médéric Thomas, data science and international](https://www.ensae.fr/en/testimonials/podcast-mederic-thomas-data-science-international)
*2024-07-24*
- Category: podcast

### [Jackman Scholars-in-Residence (SiR) 2026 at U of T ...](https://www.utsc.utoronto.ca/vpdean/jackman-scholars-residence-sir-2026-u-t-scarborough)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Entrevue avec Thomas Milan, communicateur scientifique ...](https://sciences101.ca/entrevue-avec-thomas-milan-communicateur-scientifique/)**
  - Source: sciences101.ca
  - *Nov 13, 2022 ... Thomas Milan Avant toute chose, il faut savoir que j'ai créé ma chaîne Twitch « Sciences à la carte » en octobre 2020, donc en pleine...*

- **[DE L'ACS](https://www.acs.qc.ca/client_file/upload/Congr%C3%A8s/Programmation_congres_2022.pdf)**
  - Source: acs.qc.ca
  - *Animation : Thomas Milan, communicateur scientifique et fondateur de la chaîne Twitch. Sciences À La Carte. Salle. 2. -. Comment trouver du financemen...*

- **[Douance et relations intimes avec Éliane Dussault LIVE - Entropie ...](https://shows.acast.com/entropie/episodes/douance-et-relations-intimes)**
  - Source: shows.acast.com
  - *Nov 17, 2021 ... ... podcast Buzzé tête sur toutes vos plateformes de podcast et suivez ... Sciences à la carte avec Thomas Milan. 31:58| jeudi 8 avri...*

- **[Communication scientifique | Formations](https://www.acfas.ca/formations)**
  - Source: acfas.ca
  - *Les réseaux socionumériques tels que Twitter, LinkedIn… Date à venir. Thomas Milan ... Il est également le fondateur de Sciences À La Carte, une chaîn...*

- **[Pandémie](https://www.veriteouquoi.com/pandemie)**
  - Source: veriteouquoi.com
  - *Sciences à la CARte. Par Thomas Milan · Tête à Tête avec la Science Par Myriam ... Podcast CHUT. En mars 2020 avec l'annonce de la pandémie, le monde ...*

- **[ACTES DES SESSIONS PARALLÈLES DE SCIENCE&YOU 2021](http://www.science-and-you.com/sites/science-and-you.com/files/users/documents/web_livre_actes_sessions_paralleles_def_isbn.pdf)**
  - Source: science-and-you.com
  - *... podcast ou de la vidéo montée. Cela nous semblait indispensable pour ... Thomas, Milan, Université de Montréal, animateur de la chaîne. Sciences À...*

- **[Peut-on vacciner le cerveau contre les fake news ? Oui. [actu avec ...](https://www.youtube.com/watch?v=vfuck6aLAUw)**
  - Source: youtube.com
  - *Sep 22, 2025 ... articles/c4g0x2x3e00o 30:46 Quoi voir ensuite --- Texte et animation : Viviane Lalande et Thomas Milan ... Sci+ and Sciences À La Car...*

- **[super expo-sciences hydro-québec, quebec final 2025](https://technoscience.ca/wp-content/uploads/2025/04/Press-release_Super-Expo-sciences-Quebec-final_2025-First-Prize_VF.pdf)**
  - Source: technoscience.ca
  - *Apr 13, 2025 ... Catch the replay of Thomas Milan's Twitch livestream of the event on his channel. Sciences à la carte. The awards ceremony webcast is...*

- **[La vulgarisation scientifique sur les réseaux en temps de pandémie ...](https://www.pieuvre.ca/2021/06/06/science-vulgarisation-internet-twitch-tiktok/)**
  - Source: pieuvre.ca
  - *Jun 6, 2021 ... ... Thomas Milan, doctorant à l'Université de Montréal. Sur sa chaîne Twitch Sciences à la carte ... Au programme: des interviews, des...*

- **[Collégial - L'Odyssée de l'objet](https://lodysseedelobjet.ca/concours/collegial/)**
  - Source: lodysseedelobjet.ca
  - *Pour ceux et celles qui n'ont pas pu être sur place, Thomas Milan de Sciences À La Carte s'est rendu à l'évènement pour le transmettre en direct sur T...*

---

*Generated by Founder Scraper*
