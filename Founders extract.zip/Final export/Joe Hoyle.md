# Joe Hoyle

## Position actuelle

**Titre** : Co-founder, CTO
**Entreprise** : Human Made
**Durée dans le rôle** : 15 years 5 months in role
**Durée dans l'entreprise** : 15 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Human Made helps organisations drive customer engagement, reinforce brand value and improve operations with digital solutions powered by Altis, our WordPress digital experience platform.

## Résumé

Co founder and CTO Human Made & Altis. I've been building WordPress based things for around 15 years, and had a few year stint of contributing to WordPress Core via the REST API.

In one way or another I think virtually everything I do is connected to WordPress somehow, and I'm very interested in the future of the project and how it will evolve and technology moves forward. I have many partial projects and ideas of smashing novel tech with WordPress, for fun and not-so-much profit which I'm always happy to discuss!

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAPiwUwB7glAXD-m1yyJaj3zB1zcj6LYenA/


---

# Joe Hoyle

## Position actuelle

**Entreprise** : Human Made

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Joe Hoyle

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399517148378841088 | Text |  |  | If you're interested in Personalization and A/B Testing for #WordPress, tune-in in 20 mins where I'll be doing an Accelerate plugin deep dive with Chris Reynolds / Pantheon | 0 | 0 | 1 | 1w | Post | Joe Hoyle | https://www.linkedin.com/in/justjoehoyle | https://linkedin.com/in/justjoehoyle | 2025-12-08T07:11:23.395Z |  | 2025-11-26T18:39:24.554Z | https://www.linkedin.com/feed/update/urn:li:activity:7399513012606332928/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7390385509744738304 | Article |  |  | Nant-y-Cwm Steiner school is raising money to expand their kindergarten, as part of a larger expansion project. This is the school where I spent my education, so great to see them doing so well! They also have matched donations up to 50KGBP so double the impact!

https://lnkd.in/ePwuPaTX | 9 | 0 | 1 | 1mo | Post | Joe Hoyle | https://www.linkedin.com/in/justjoehoyle | https://linkedin.com/in/justjoehoyle | 2025-12-08T07:11:23.395Z |  | 2025-11-01T13:53:32.246Z | https://www.crowdfunder.co.uk/p/nant-y-cwm-steiner-school |  | 

---



---

# Joe Hoyle
*Human Made*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 24 |

---

## 📚 Articles & Blog Posts

### [Press This: AI's Place in a WordPress Agency](https://torquemag.io/2023/05/press-this-ai-wordpress-agency/)
*2023-05-24*
- Category: article

### [WordPress & AI Innovation: What's Changing and Why](https://openchannels.fm/innovations-in-ai-and-wordpress-with-joe-hoyle/)
*2023-05-09*
- Category: article

### [AI in CMS: A WordPress Plugin & The Future of Content Workflows with Joe Hoyle](https://smartlink.ausha.co/wpai-wordpress-and-ai/ai-in-cms-a-wordpress-plugin-and-the-future-of-content-workflows-with-joe-hoyle)
*2023-08-24*
- Category: article

### [12 Best WordPress Podcasts - Developer Drive](https://www.developerdrive.com/12-best-wordpress-podcasts/)
- Category: podcast

### [A Conversation With Joe Hoyle, Co-founder Of Human Made, On ‘A Day Of REST’](https://torquemag.io/2015/09/a-conversation-with-joe-hoyle-co-founder-of-human-made-on-a-day-of-rest)
*2015-09-22*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Joe Hoyle on Building Human Made, Family Life, and WordPress ...](https://seriouslybud.com/episode/joe-hoyle/)**
  - Source: seriouslybud.com
  - *Jun 6, 2025 ... In this engaging conversation, Joe Hoyle, CTO and co-founder of Human Made, discusses his work-life balance, emphasizing the importanc...*

- **[Human Made Press Kit](https://humanmade.com/press/)**
  - Source: humanmade.com
  - *CTO: Joe Hoyle CGO: Noel Tock Humans: 70+ across 5 continents. Headquarters: Human Made ... Interview with Tom and Noel – WP Elevation podcast · Inter...*

- **[Human Made - YouTube](https://www.youtube.com/@humanmadeltd)**
  - Source: youtube.com
  - *Being Human Podcast The Freelancer Experience. 17 views. 7 ... Accelerating AI in WordPress - Joe Hoyle of Human Made - Word on the Future: AI for Wor...*

- **[WordPress Security -- Draft podcast • Post Status](https://poststatus.com/wordpress-security-draft-podcast/)**
  - Source: poststatus.com
  - *May 8, 2016 ... Post Status Draft is hosted by Joe Hoyle — the CTO of Human Made — and Brian Krogsgard. Security — in WordPress core, distributed plug...*

- **[WordPress REST API Round-table — Draft Podcast • Post Status](https://poststatus.com/wordpress-rest-api-round-table-draft-podcast/)**
  - Source: poststatus.com
  - *Feb 5, 2016 ... Post Status Draft is hosted by Joe Hoyle — the CTO of Human Made — and Brian Krogsgard. Joe and Brian were joined by Ryan McCue, the L...*

- **[Video: The WordPress REST API Guide for Non-developers – Petya ...](https://petya.in/video-the-wordpress-rest-api-guide-for-non-developers/)**
  - Source: petya.in
  - *Dec 13, 2016 ... Director of Agency Operations @ Human Made. ... I'd like to thank Siobhan McKeown, Ryan McCue, Nikolay Bachiyski and Joe Hoyle for th...*

- **[Learn JavaScript & The WP REST API Deeply at a Day of REST ...](https://wp.zacgordon.com/2016/12/13/learn-javascript-and-wp-api-deeply-at-a-day-of-rest/)**
  - Source: wp.zacgordon.com
  - *Dec 13, 2016 ... Half Day – WP API Authentication w Joe Hoyle (Worth the entire trip) ... But Human Made is also a VIP WP Partner, they build producti...*

- **[php - Persistent 504 Timeouts with WooCommerce - Stack Overflow](https://stackoverflow.com/questions/38531633/persistent-504-timeouts-with-woocommerce)**
  - Source: stackoverflow.com
  - *Jul 22, 2016 ... Menu Exporter: by Joe Hoyle - Human Made Limited – 1; PDF Image ... What is the word used in this podcast? References for Burnside's ...*

- **[Data Classification Policy – Handbook](https://handbook.hmn.md/working-here/security/data-classification-policy/)**
  - Source: handbook.hmn.md
  - *Oct 22, 2024 ... Interviewing at Human Made · Pre-Application Checklist · Your ... This will contact everyone who needs to know, including Joe Hoyle, ...*

- **[Publish presentation announcements • Post Status](https://poststatus.com/publish-presentation-announcements/)**
  - Source: poststatus.com
  - *Nov 1, 2016 ... Tom runs Human Made and Scott runs The Look & Feel. We'll listen ... Joe Hoyle and I do a live podcast. To close out the day, Joe and ...*

---

*Generated by Founder Scraper*
