# Emmanuel Durand

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Lab148
**Durée dans le rôle** : 2 years 9 months in role
**Durée dans l'entreprise** : 2 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT System Design Services

## Résumé

Specialist in Virtual Reality and Image Processing

Experience with the whole mixed reality chain, from the capture (through cameras / photography) to image rendering and user interface.

Interest in designing and building innovative virtual and mixed reality devices (experience in mechanical prototyping applied to interactive virtual device).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADwjkkB4lQaT3ntRyJyjzvqSKFl1yGTgwI/
**Connexions partagées** : 8


---

# Emmanuel Durand

## Position actuelle

**Entreprise** : Lab148

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Emmanuel Durand

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393668253795102720 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b410c9a2-51fb-4997-ae08-ffc250a614d2 | https://media.licdn.com/dms/image/v2/D4E05AQHpHtye26-oSA/videocover_350_624/B56ZplPpvZJkAI-/0/1762635193430?e=1765785600&v=beta&t=RNM0DwoZy1XPLK09tYZ2llQFPFNp-XM36HX95d0rgSE | On peut faire plein de belles choses en audio avec l'apprentissage machine et l'apprentissage profond, sur son propre ordinateur (ou la machine avec un GPU la plus proche) !

Et mes collègues Nicolas Bouillot et Michal Seta de Lab148 peuvent vous aider à y voir plus clair, en mettant directement en pratique certains des outils. C'est sur deux soirées, et ça commence ce mercredi ! | 3 | 0 | 1 | 3w | Michal Seta reposted this | Emmanuel Durand | https://www.linkedin.com/in/durandemmanuel | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:42.665Z |  | 2025-11-10T15:17:59.418Z | https://www.linkedin.com/feed/update/urn:li:activity:7393026077650235392/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7376814957096607744 | Video (LinkedIn Source) | blob:https://www.linkedin.com/88a76ca9-b2c5-4221-9009-c3516b9745f5 | https://media.licdn.com/dms/image/v2/D4E05AQEg46wzj2oq2Q/feedshare-thumbnail_720_1280/B4EZlyEtWWKgAw-/0/1758555461758?e=1765785600&v=beta&t=1-W9uHjh7bLngsdti-LPpRhghd50biCL_vj60QIgv0Y | Venez découvrir de nombreux outils tirant parti d'algorithmes d'apprentissage profond (et donc de l'IA) pour analyser, générer, organiser, détecter, reproduire des sons !

C'est la semaine prochaine, nous vous accueillerons dans nos locaux dans une ambiance chaleureuse ! Nicolas Bouillot et Michal Seta feront leur maximum pour vous transmettre leurs connaissances et leur intérêt pour les nombreuses possibilités de ces outils. Et je serai peut être dans le coin pour les questions annexes ;) | 5 | 0 | 1 | 2mo | Michal Seta reposted this | Emmanuel Durand | https://www.linkedin.com/in/durandemmanuel | https://linkedin.com/in/michal-seta-92a64518 | 2025-12-08T07:14:47.100Z |  | 2025-09-25T03:09:00.366Z | https://www.linkedin.com/feed/update/urn:li:activity:7375916268257824768/ |  | 

---



---

# Emmanuel Durand
*Lab148*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [](https://emmanueldurand.net/about/)
*2023-01-01*
- Category: article

### [Bonus: Emmanuel Straschnov, Bubble](https://codestory.co/podcast/bonus-emmanuel-straschnov-bubble/)
*2025-06-09*
- Category: podcast

### [‎Entrepreneur Talks by STATION F : Interview with Emmanuel Straschnov, Founder of Bubble sur Apple Podcasts](https://podcasts.apple.com/fr/podcast/interview-with-emmanuel-straschnov-founder-of-bubble/id1479056989?i=1000538589629)
*2021-10-14*
- Category: podcast

### [An equation for measuring emergencies?](https://msf-crash.org/en/blog/medicine-and-public-health/equation-measuring-emergencies)
*2022-08-12*
- Category: blog

### [About RxLab.](https://rxlaboratory.org/about/)
*2023-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Réalité virtuelle, réalité augmentée - Qui fait Quoi / Lien MULTIMÉDIA](https://lienmultimedia.com/?mot407)**
  - Source: lienmultimedia.com
  - *Le Lab148 travaille au développement d'« Ensens », un logiciel dédié à l ... Emmanuel Durand et Nicolas Bouillot ont porté une attention particulière ...*

- **[SELF-HOSTED AI](https://www.easternbloc.ca/post/self-hosted-ai)**
  - Source: easternbloc.ca
  - *Apr 16, 2025 ... June 28, 2025 | Emmanuel Durand. https://shorturl.at/4evB0. This ... AI Conference - Lab148....*

- **[Emmanuel Durand](https://emmanueldurand.net/about/)**
  - Source: emmanueldurand.net
  - *With Nicolas Bouillot and Michał Seta, I co-founded the Lab148 cooperative ... © 2023 Emmanuel Durand. Powered by Jekyll using the Minimal Mistakes th...*

- **[Audiodice: an open hardware design of a distributed dodecahedron ...](https://dl.acm.org/doi/abs/10.1145/3616195.3616208)**
  - Source: dl.acm.org
  - *Oct 11, 2023 ... Lab148 and CIRMMT, Canada. https://orcid.org/0009 ... Nicolas Bouillot, MichałSeta, Émile Ouellet-Delorme, Zack Settel, and Emmanuel ...*

- **[(PDF) Live Ray Tracing and Auralization of 3D Audio Scenes with ...](https://www.researchgate.net/publication/352330278_Live_Ray_Tracing_and_Auralization_of_3D_Audio_Scenes_with_vaRays)**
  - Source: researchgate.net
  - *... Lab148 ... Sketching Pipelines for Ephemeral Immersive Spaces. July 2023. Michal Seta · Emmanuel Durand · Eduardo Meneses · Christian Frisson · Re...*

- **[Six conférences sur l'IA en rediffusion (2025) | SYNTHÈSE](https://polesynthese.com/actualites/programmation-agir-sur-nos-competences-en-ia)**
  - Source: polesynthese.com
  - *Feb 19, 2025 ... Cette conférence mettra en lumière l'inventaire des différents ... Emmanuel Durand est co-fondateur de la coopérative Lab148, dont la...*

- **[Bruno ROY | Manager/Research Scientist | Ph.D. Computer Science ...](https://www.researchgate.net/profile/Bruno-Roy)**
  - Source: researchgate.net
  - *Emmanuel Durand; Bruno Roy. Three-hundred-sixty ... Lab148. Emmanuel Durand. Society for Arts and Technology....*

- **[Emmanuel DURAND Email & Phone Number | Loewe Global ...](https://rocketreach.co/emmanuel-durand-email_6751639)**
  - Source: rocketreach.co
  - *Others Named Emmanuel DURAND. Lab148 Employee Emmanuel Durand's profile photo ... Blog · Contact Us. © 2025 RocketReach.co....*

- **[Showcasing usages of Splash - Splash Forum](https://community.splashmapper.xyz/t/showcasing-usages-of-splash/16)**
  - Source: community.splashmapper.xyz
  - *Sep 13, 2024 ... 1920×1440 590 KB. Credit: Emmanuel Durand. Projection onto a 3D ... https://lab148.xyz/assets/videos/2024-03-23_BAnQ_VideoDoc.mp4. Yo...*

- **[Marion DESLANDES MARTINEAU | PhD student | University of ...](https://www.researchgate.net/profile/Marion-Deslandes-Martineau)**
  - Source: researchgate.net
  - *... article presents our findings specific to the impact on primary and ... Lab148. Emmanuel Durand. Society for Arts and Technology. All ......*

---

*Generated by Founder Scraper*
