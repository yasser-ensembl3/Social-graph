# Bruno Lambert

## Position actuelle

**Titre** : Software architect Entrepreneur
**Entreprise** : Self-employed
**Durée dans le rôle** : 14 years 11 months in role
**Durée dans l'entreprise** : 14 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Building Applications

## Résumé

Possédant un bagage de plus de 20 ans d'expérience en développement logiciel et toujours à l'affût des nouvelles technologies, je me distingue dans toutes les phases de l'analyse, la conception et l'implémentation de solutions informatiques.

J'ai à coeur l'expérience utilisateur et je m'assure de développer des solutions performantes, robustes et répondant au besoin du client.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAFN0ZcBii9OSxhP_VAIhtwhptwWBr8VQ0w/
**Connexions partagées** : 14


---

# Bruno Lambert

## Position actuelle

**Entreprise** : Deck

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Bruno Lambert
*Deck*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [Bruno Lambert - Deck | LinkedIn](https://ca.linkedin.com/in/bruno-lambert-4733b07)
*2025-01-01*
- Category: article

### [Bootstrapping a Subscription App to 5M MAU and 2X+ Revenue Growth — Bruno Virlet, Genius Scan | Sub Club Podcast](https://subclub.com/episode/bootstrapping-a-subscription-app-to-5m-mau-and-2x-revenue-growth-bruno-virlet-genius-scan)
*2025-01-22*
- Category: article

### [DeCent People With Nick Lambert of Dock  — Decential Media](https://www.decential.io/podcasts/decent-people-with-nick-lambert-of-dock)
*2023-07-28*
- Category: podcast

### [Writing damn good decks with LLMs - Bruno Scheufler](https://brunoscheufler.com/blog/2023-07-09-writing-good-decks)
*2023-07-09*
- Category: blog

### [Building Momentum: Reflecting on 2024 and Aiming Higher](https://blog.usebruno.com/building-momentum-reflecting-on-2024-and-aiming-higher)
*2024-12-31*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Deck raises $12M to 'Plaid-ify' any website using AI | TechCrunch](https://techcrunch.com/2025/04/16/deck-raises-12m-to-plaid-ify-any-website-using-ai/)**
  - Source: techcrunch.com
  - *Apr 16, 2025 ... Deck, a startup that claims to be building “the Plaid for ... President Frederick Lavoie, CEO Yves-Gabriel Leboeuf, and CTO Bruno Lam...*

- **[Gene Manipulation | BoardGameGeek](https://boardgamegeek.com/thread/2581322/gene-manipulation)**
  - Source: boardgamegeek.com
  - *Jan 16, 2021 ... Bruno Lambert @Bruno_L ... I guess recruit troops if they are all in the garrison or conflict and draw a card if your deck is thinned...*

- **[Does Ix improve the two player game? | BoardGameGeek](https://boardgamegeek.com/thread/2975453/does-ix-improve-the-two-player-game)**
  - Source: boardgamegeek.com
  - *Nov 21, 2022 ... ... deck builder designed period, following Dominion), but mostly ... Bruno Lambert. Belgium flag. @Bruno_L · @Bruno_L · Nov 27, 2022...*

- **[Flinks co-founders trade open banking for open utility with new ...](https://betakit.com/flinks-co-founders-trade-open-banking-for-open-utility-with-new-startup-deck/)**
  - Source: betakit.com
  - *Oct 15, 2024 ... Repeat founders Yves-Gabriel Leboeuf & Frédérick Lavoie have raised $4.5 million for Deck, a new API that allows businesses to track ...*

- **[Deck raises $12M to 'Plaid-ify' any website using AI](https://au.finance.yahoo.com/news/deck-raises-12m-plaid-ify-150000199.html)**
  - Source: au.finance.yahoo.com
  - *Apr 16, 2025 ... President Frederick Lavoie, CEO Yves-Gabriel Leboeuf, and CTO Bruno Lambert (pictured above, left to right) co-founded Deck in June 2...*

- **[Interstate 5 Recommendations, Joint Cover Letter](https://wsdot.wa.gov/sites/default/files/2023-07/I5-MasterPlan-InterimReport-June2023.pdf)**
  - Source: wsdot.wa.gov
  - *Jun 30, 2023 ... ... Deck Overlay and Expansion. Joints. • I-5/SR 161/SR 18 Project ... Bruno Lambert. Steering Committee. Greg Briggs. Advisory Counc...*

- **[HBO Documentary Claims Bitcoin's Inventor Is Some Random Kid ...](https://www.fintechgrowthinsider.com/p/hbo-documentary-claims-bitcoins-inventor)**
  - Source: fintechgrowthinsider.com
  - *... interviews with “bitcoin ambassador” Samson Mow, who is in the strange ... Bruno Lambert and Julien Bélisle, have launched a new start-up called D...*

- **[Tom Kundig](https://www.usmodernist.org/kundig.htm)**
  - Source: usmodernist.org
  - *Sold to Bruno Lambert and Elizabeth Dunn. Built by dboone ... When lowered, they add 600 square feet of deck and sweeping views of the landscape....*

- **[About Us | Deck](https://www.deck.co/about)**
  - Source: deck.co
  - *Deck is backed to redefine how the internet is accessed and used. Deck founders: Fred Lavoie, Bruno Lambert, Julien Belisle, Yves-Gabriel Leboeuf. Now...*

- **[Luge Capital invests in Deck.](https://www.luge.vc/backing-deck/)**
  - Source: luge.vc
  - *Oct 15, 2024 ... Having worked with Yves-Gabriel Leboeuf, Fred Lavoie, Julien Belisle and Bruno Lambert during the success of Flinks, we've seen first...*

---

*Generated by Founder Scraper*
