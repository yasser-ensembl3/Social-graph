# Madani Boukalba

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : T-RIZE GROUP
**Durée dans le rôle** : 3 years 5 months in role
**Durée dans l'entreprise** : 3 years 5 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Blockchain Services

## Description du rôle

I lead the development of an interconnected institutional platform and infrastructure designed to transform global capital markets through tokenization. My focus is on execution: securing institutional contracts, scaling operations, and embedding risk analytics at the core of our infrastructure. Under my leadership, T-RIZE has become operational, fully integrated with the Canton Network, and is actively onboarding a multi-billion-dollar pipeline of projects across real estate, private equity, and carbon credits.

I bring together technology, compliance, and market adoption—balancing innovation with disciplined governance and delivery. Our federated intelligence framework eliminates single points of failure and provides institutions with the transparency, resilience, and scalability required to trust tokenized markets.

With a growing team of PhD researchers, engineers, and business operators, my role is to ensure that T-RIZE scales as a trusted, revenue-generating marketplace and establishes itself as a global reference in institutional tokenization.

## Résumé

Madani leads T-RIZE Group, a Fintech transforming how global capital flows through the tokenization of RWA. With a foundation built on institutional security and precision, T-RIZE delivers tailor-made solutions that combine advanced technology with strategic deal structuring to unlock liquidity at scale.

Positioned as a validator and FeaturedApp in the Canton Network, T-RIZE operates within one of the most trusted ecosystems in finance, aligning with the highest standards of compliance and resilience. Through multi-billion-dollar agreements already secured, the company is building the infrastructure for markets that demand both innovation and reliability.

At the core of T-RIZE’s vision is a commitment to sustainability and carbon neutrality, embedding environmental responsibility into the architecture of financial systems. Supported by T-RIZE Labs and the Industrial Research Chair in Tokenization, the group advances applied research in blockchain and decentralized machine learning, ensuring the platform not only serves today’s institutions but anticipates the needs of tomorrow’s economy.

Madani’s leadership reflects discipline and foresight — building bridges between traditional finance and decentralized infrastructure, and positioning T-RIZE to define the next generation of global market infrastructure.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADpgJDoBqS2y65jkK1q3jYargNJWFErjGlw/
**Connexions partagées** : 191


---

# Madani Boukalba

## Position actuelle

**Entreprise** : T-RIZE GROUP CORPORATION

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 1st


---

# Madani Boukalba

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401016800823451649 | Article |  |  | Bravo! | 3 | 0 | 0 | 1w | Post | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/madani-boukalba | 2025-12-08T04:54:56.613Z |  | 2025-11-30T21:58:29.559Z | https://www.zeffy.com/fr-CA/ticketing/lancement-de-la-fondation-isabelle-et-luc-poirier?impact_chain_source=madaniboukalba@t-rize.io |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389470732642328576 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3000293e-23fb-415a-b065-fcd03b7537aa | https://media.licdn.com/dms/image/v2/D4E05AQF42kl3Gcse1w/feedshare-thumbnail_720_1280/B4EZoq_X_0GUAw-/0/1761657848195?e=1765774800&v=beta&t=Nql_ar6s1VrMjYmppD5kzgPvkY5ITPkD-yTZg7AA65o | Really great job Dfns for this precise report and for capturing the magnitude of what’s being built around the Canton Network.

The Canton Network represents a turning point in the evolution of financial infrastructure — a synchronized, privacy-preserving framework where regulated institutions can finally interoperate efficiently across all major markets.

The scale of collaboration emerging across the ecosystem is remarkable: major financial institutions, infrastructure providers, and innovators are now aligning around a shared standard of trust, interoperability, and regulatory compliance.

Within this network, T-RIZE GROUP CORPORATION is advancing tokenization and decentralized intelligence at institutional scale — bridging real-world assets, compliant distribution, and data-driven efficiency.

This is a structural shift in how finance connects, settles, and scales globally.

Digital Asset Canton Network Dfns T-RIZE GROUP CORPORATION | 3 | 0 | 1 | 1mo | Post | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/madani-boukalba | 2025-12-08T04:54:59.244Z |  | 2025-10-30T01:18:32.389Z | https://www.linkedin.com/feed/update/urn:li:activity:7388952714543669248/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386011984577732608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFWVYXqvv26QA/feedshare-shrink_800/B4EZnxgGPYJ0Ag-/0/1760693348713?e=1766620800&v=beta&t=o8YQLbNAHnyEOu1ievKJwqqEuu0NJYjTWkO7z89F_Cs | Canton Network : The Financial Internet Is Here

Canton isn’t just another L1 blockchain — it’s the foundation on which global finance is being rebuilt.
If Ethereum was the sandbox of innovation,
Canton is the infrastructure of global finance.

A network of networks, designed for institutions that demand privacy, compliance, and scale — all on a single synchronized ledger.

This is where $6 trillion in tokenized assets already move.
Where $280 billion in daily repo trades are settled.
Where 400+ institutions, from global banks to market infrastructure leaders, are already connected.

No token speculation. No VC games.
Just real adoption, real assets, real volume.

Every major financial institution knows the paradox:
they want the speed and finality of blockchain — without the transparency risks.
Canton solved it.

The next evolution of blockchain is institutional at scale — and it’s already happening on Canton.

#joinCanton #programmableprivacy #CantonNetwork | 11 | 0 | 3 | 1mo | Post | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/madani-boukalba | 2025-12-08T04:55:01.367Z |  | 2025-10-20T12:14:42.590Z | https://www.linkedin.com/feed/update/urn:li:activity:7384951340671856640/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384629741154246656 | Article |  |  | Very honoured to see T-RIZE GROUP CORPORATION and Professor Kaiwen Zhang’s Research Chair recognized by Natural Sciences and Engineering Research Council of Canada (NSERC) and Mitacs for our work in Federated Learning and Tokenization. Very grateful for the huge support from École de technologie supérieure.

This milestone is more than major funding — it’s validation of our vision to build privacy-preserving, scalable, and secure digital infrastructure for the next decade.

Proud of our incredible research team and partners for pushing the boundaries of what’s possible. The future of decentralized intelligence is being built today. | 25 | 3 | 4 | 1mo | Post | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/madani-boukalba | 2025-12-08T04:55:01.369Z |  | 2025-10-16T16:42:10.077Z | https://markets.businessinsider.com/news/stocks/canada-backs-advanced-tokenization-and-distributed-federated-learning-research-with-over-3-million-in-funding-1035386358 |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7340986215170506752 | Article |  |  | 🌍 When Crypto Gets Real
CoinGecko’s latest 2025 RWA report paints a clear picture: the quiet rise of real-world assets is becoming the loudest signal in digital finance.

📈
 •	Stablecoins hit a record $224.9B
 •	Tokenized Treasuries grew +544% YoY, now at $5.6B
 •	Even commodities and private credit are steadily gaining on-chain traction
 •	Kraken and Coinbase are both leaning into tokenized equities — it’s no longer fringe

What stands out isn’t just the numbers—it’s the shift in tone. This space is no longer a thought experiment. It’s infrastructure. And the institutions are coming.

⚡️ At the center of this momentum, the projects that built early, with compliance and scale in mind, are getting serious tailwinds.

T-RIZE GROUP CORPORATION being listed on Kraken ($RIZE) is just one milestone. The road ahead for RWA is getting clearer—and it’s looking global, regulated, and very real.

https://lnkd.in/eznSjSmc

#RWA #CryptoFinance #Tokenization #Kraken #CoinGecko #DigitalAssets #Stablecoins #Treasuries #Institutions #RizeToken #Web3Finance | 20 | 2 | 3 | 5mo | Eduardo Furtado, M.Eng reposted this | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/eduardofromthefuture | 2025-12-08T07:03:13.292Z |  | 2025-06-18T06:18:22.625Z | https://www.coingecko.com/research/publications/rwa-report-2025 |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7340805565473812482 | Text |  |  | 🚨 We're hiring — Front-End Developer at T-RIZE
We’re not looking for someone who just ships code.
 We’re looking for someone who gives a damn about the product.
At T-RIZE, we’re building something serious — a tokenization platform backed by real research, institutional partnerships, and a pipeline that’s already captured the attention of some of the most sophisticated players in the space.
We need a Front-End Developer who wants in early,
 Who wants to shape what users see and feel,
 Who can move fast, without cutting corners,
 And who wants their work to matter.
We're not offering bean bags or free smoothies.
 We're offering ownership, momentum, and the chance to be part of a company that’s already changing the game.
If that speaks to you — or if it should speak to someone you know — 

here’s the link to apply: https://lnkd.in/ech2Wqu8

This is the kind of role you’ll talk about ten years from now.

#TRIZE #FrontendDeveloper #Web3 #Tokenization #EngineeringRoles #BuildingSomethingThatMatters #StartupJobs | 20 | 2 | 5 | 5mo | Eduardo Furtado, M.Eng reposted this | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/eduardofromthefuture | 2025-12-08T07:03:13.293Z |  | 2025-06-17T18:20:32.381Z |  | https://www.linkedin.com/jobs/view/4250406815/ | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7336412536029831169 | Article |  |  | I’m honestly overwhelmed.

Three years ago, we started with a belief:
That real-world value could — and must — move at the speed of trust.

Today, with $RIZE live on Kraken as part of their exclusive REEF Program, that belief becomes a reality.

This moment is more than a listing. It’s a declaration:
Real utility, built on real infrastructure, is finally onchain.

To our early believers — you saw it before the world did.
To our brilliant team — your discipline, passion, and resilience made this possible.
To our community — you gave us the energy to keep going.
To our partners at IBC Group - International Blockchain Consulting — thank you for helping us make this launch a success.
And to our institutional partners behind the scenes — the ones shaping what’s next with us — we see you, we thank you, and we’re about to unveil something together that will redefine this space.

This is just the beginning.
The rails are ready. The architecture is live. The real economy is coming onchain.

From Montreal to the world —
Thank you.

#RIZE #TGE #Kraken #OnchainRealEstate #DigitalAssets #TrustTheProcess #Gratitude #RWA #AI #TRIZE | 48 | 11 | 7 | 6mo | Eduardo Furtado, M.Eng reposted this | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/eduardofromthefuture | 2025-12-08T07:03:13.298Z |  | 2025-06-05T15:24:12.543Z | https://crypto.news/unlocking-the-10t-housing-gap-how-t-rize-is-solving-the-g20s-real-estate-crisis/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7333235971993374720 | Text |  |  | We didn’t raise a massive seed round.
We didn’t start with headlines, hype, or a crypto bull run at our backs.

We started with vision. With grit. With belief.

A belief that real-world assets can — and should — be tokenized transparently.
That compliance isn’t a bottleneck — it’s a competitive edge.
That regulatory-first doesn’t mean moving slow — it means building to last.

I remember those early calls…
No sleep.
No weekends.
Just a team of true believers coding, negotiating, pitching — all at once.

No shortcuts. No bailouts. No VC safety nets.
Just sheer conviction.

They said:
“Why build another blockchain?”
“Why tackle regulation head-on?”
“Why go so hard when the market’s quiet?”
“Why the US market?”
“Is it real AI or ChatGPT stuff?”

Because we weren’t chasing trends.
We were laying rails.
Rails for a $2B+ pipeline. For compliant global listings.
Next gen AI-Powered risk analysis with descentralized Federated Learning.
For smart cities. Real estate. Carbon markets. Infrastructure.

For a billion-dollar dream that is now becoming reality.

Today, we’re LIVE.

 •	A scalable, intuitive, yet institutional-grade tokenization platform.
 •	Backed by world-class research on Federated Learning.
 •	A patent-pending, public-permissioned ecosystem designed to onboard the real economy.
 •	A global network of strategic alliances: including Canton Network and more.
 •	Built to be simple for users. Sophisticated for regulators. Powerful for institutions.

T-RIZE GROUP CORPORATION is not just a startup.
It’s a statement: You don’t need to start with everything to build something unstoppable.

We started from zero.
Now we’re building the future.

To every founder grinding in the dark,
To every believer told “it’ll never work,”
To every builder who chose mission over noise —
Keep rising.

We are proof that patience and precision beat hype every time.

Let’s tokenize the world — and do it the right way.

#Web3 #Tokenization #RealAssets #Leadership #FoundersJourney #Blockchain #ComplianceFirst #TRIZE #MadaniBoukalba | 82 | 8 | 7 | 6mo | Eduardo Furtado, M.Eng reposted this | Madani Boukalba | https://www.linkedin.com/in/madani-boukalba | https://linkedin.com/in/eduardofromthefuture | 2025-12-08T07:03:13.302Z |  | 2025-05-27T21:01:40.659Z |  |  | 

---



---

# Madani Boukalba
*T-RIZE GROUP CORPORATION*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Madani Boukalba | President & CEO - T-RIZE Group Corporation | Forbes Technology Council](https://councils.forbes.com/profile/Madani-Boukalba-President-CEO-T-RIZE-Group-Corporation/1ab2e0a5-31f7-4bcf-8a70-d305da4d9903)
*2023-11-29*
- Category: article

### [Madani Boukalba - CEO at T-RIZE GROUP | RWA Tokenization & DML | The Org](https://theorg.com/org/t-rize-group-rwa-tokenization-dml/org-chart/madani-boukalba)
*2024-10-30*
- Category: article

### [T-RIZE and Republic Launch ‘Vision 60’ to Expand Institutional Access to Tokenized Real Estate](https://medium.com/@T-RIZE/t-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307)
*2025-09-04*
- Category: blog

### [Team | Rizenet & T-RIZE Documentation](https://docs.t-rize.io/docs/trize/Team)
*2025-08-28*
- Category: article

### [T-RIZE Group secured a $300M tokenization deal, supercharging a $2B Global pipeline and redefining decarbonized institutional-grade Real World Asset (RWA) investments](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html)
*2024-12-17*
- Category: article

---

## 📖 Full Content (Scraped)

*5 articles scraped, 6,126 words total*

### Madani Boukalba | President & CEO - T-RIZE Group Corporation | Forbes Technology Council
*649 words* | Source: **EXA** | [Link](https://councils.forbes.com/profile/Madani-Boukalba-President-CEO-T-RIZE-Group-Corporation/1ab2e0a5-31f7-4bcf-8a70-d305da4d9903)

Madani Boukalba | President & CEO - T-RIZE Group Corporation | Forbes Technology Council

===============

![Image 2: Forbes Technology Council](https://s3.amazonaws.com/cco-organizations/forbes/ftc/logo-white.png)

[Log in](https://councils.forbes.com/app)[Do I Qualify?](https://councils.forbes.com/qualify)

[Do I Qualify?](https://councils.forbes.com/qualify)

![Image 3: Madani Boukalba's avatar](https://councils.forbes.com/profile/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fcco-avatars%2Fd1d8db64-9530-494a-bc7d-54f3119744d8.png&w=384&q=75)

Madani Boukalba
===============

President & CEO T-RIZE Group Corporation
----------------------------------------

Montreal, QC, Canada

[](https://www.linkedin.com/in/madani-boukalba/)[](https://www.facebook.com/madani.boukalba)

### Skills

Algorithms

Agile and Lean Startups

Large-Scale Distributed Systems

### About

Madani Boukalba brings a solid 15-year background in the capital market, establishing him as a respected figure in Digital Assets. As the Co-Founder and the driving force behind T-Rize Group, Madani is set on harnessing the potential of blockchain and AI not just to ride the wave of innovation, but to shape the future of finance. His vision is clear: to democratize access to high-quality investment opportunities, making them available to everyone, regardless of their starting point. With a history of building meaningful partnerships and launching user-friendly platforms, Madani and his team at T-Rize are working diligently to simplify the complexities of the financial world. As the digital landscape evolves, Madani is dedicated to ensuring that T-Rize stands as a beacon for inclusivity and excellence in the investment realm.

![Image 4: Madani Boukalba's avatar](https://councils.forbes.com/profile/_next/image?url=https%3A%2F%2Fs3.amazonaws.com%2Fcco-avatars%2Fd1d8db64-9530-494a-bc7d-54f3119744d8.png&w=128&q=75)

#### Madani Boukalba

President & CEO

[Published content](https://councils.forbes.com/profile/Madani-Boukalba-President-CEO-T-RIZE-Group-Corporation/1ab2e0a5-31f7-4bcf-8a70-d305da4d9903#published-content)[Company details](https://councils.forbes.com/profile/Madani-Boukalba-President-CEO-T-RIZE-Group-Corporation/1ab2e0a5-31f7-4bcf-8a70-d305da4d9903#company-details)

Published content
-----------------

![Image 5: 20 Ways Tech Startups Could Tap Into A Trillion-Dollar Space Industry](https://councils.forbes.com/profile/_next/image?url=https%3A%2F%2Fimageio.forbes.com%2Fspecials-images%2Fimageserve%2F65666218ba67d3da6da54eb1%2F0x0.jpg%3Fformat%3Djpg%26height%3D900%26width%3D1600%26fit%3Dbounds&w=3840&q=75)

expert panel

[20 Ways Tech Startups Could Tap Into A Trillion-Dollar Space Industry](https://www.forbes.com/sites/forbestechcouncil/2023/11/29/20-ways-tech-startups-could-tap-into-a-trillion-dollar-space-industry/)
Nov 29, 2023

Globally, eyes are turning to the skies again, and the economic impact could be huge: Morgan Stanley has estimated that the space industry could generate revenue of more than $1 trillion or more by 2040. Obviously, the space industry can’t function without technology, but the technology industry also stands to benefit from the renewed pursuit of space research and travel. With foresight and ingenuity, ambitious startups could not only support space operations, but also improve daily life here on Earth. From providing support products and services for space-focused efforts to leveraging newly acquired access to unique resources, an exciting time for new tech startups may be on the horizon. Below, 20 members of Forbes Technology Council discuss ways tech companies could soon both serve and benefit from the burgeoning space industry.

[Read Article](https://www.forbes.com/sites/forbestechcouncil/2023/11/29/20-ways-tech-startups-could-tap-into-a-trillion-dollar-space-industry/)

![Image 6: Protecting Your Hardware: 20 Ways To Extend The Life Of Tech Devices](https://councils.forbes.com/profile/_next/image?url=https%3A%2F%2Fimageio.forbes.com%2Fspecials-images%2Fimageserve%2F654966fa75335ebb7b3bd614%2F0x0.jpg%3Fformat%3Djpg%26height%3D900%26width%3D1600%26fit%3Dbounds&w=3840&q=75)

expert panel

[Protecting Your Hardware: 20 Ways To Extend The Life Of Tech Devices](https://www.forbes.com/sites/forbestechcouncil/2023/11/07/protecting-your-hardware-20-ways-to-extend-the-life-of-tech-devices/)
Nov 7, 2023

Both businesses and consumers have compelling reasons to prolong the lives of their tech devices. Regularly replacing computers and mobile devices is not only expensive, but it can also have serious environmental consequences, especially in communities that lack electronic recycling services. Fortunately, there are proven ways to extend the life of digital devices; some are actually quite simple. Below, 20 members of Forbes Technology Council share their expert advice to help both companies and consumers ensure their tech devices have long, productive lives.

[Read Article](https://www.forbes.com/sites/forbestechcou

*[... truncated, 1,677 more characters]*

---

### Madani Boukalba - CEO at T-RIZE GROUP | RWA Tokenization & DML | The Org
*207 words* | Source: **EXA** | [Link](https://theorg.com/org/t-rize-group-rwa-tokenization-dml/org-chart/madani-boukalba)

![Image 1: Madani Boukalba's profile picture](https://cdn.theorg.com/d0e4fae9-a175-4006-9a2e-6a82ff319bd0_thumb.jpg)

### CEO

Madani Boukalba is the Co-Founder and CEO of T-RIZE GROUP, leading a platform that specializes in RWA Tokenization and investment opportunities in diverse asset classes, including real estate and carbon credits, since July 2022. Additionally, Madani serves as the Strategic Development Committee Director at ÉTS x T-RIZE Lab, focusing on innovative technology in AI and Blockchain. With extensive experience in capital markets, Madani held the position of Senior Trader at Caisse de dépôt et placement du Québec from 2010 to 2022, where skills included international equity trading, risk assessment, and algorithmic trading. Previous roles include Business System Analyst and Information Technology Business Analyst at notable financial institutions. Madani's educational background includes a Sustainable Business Strategy Online Certificate from Harvard Business School Online, a Bachelor of Business Administration from HEC Montréal, and a technology degree from Lund University.

Links

Previous companies

[![Image 2: Caisse de dépôt et placement du Québec logo](https://cdn.theorg.com/fb2f5bf9-57dc-4d35-b72c-7f8b729d4db0_thumb.jpg)](https://theorg.com/org/caisse-de-depot-et-placement-du-quebec "Caisse de dépôt et placement du Québec")[![Image 3: HSBC logo](https://cdn.theorg.com/52b54b2f-9b3d-4e41-a466-37fa7dcdc068_thumb.jpg)](https://theorg.com/org/hsbc "HSBC")[![Image 4: Financière Banque Nationale logo](https://cdn.theorg.com/89db4b1e-e387-45a9-9fb5-a85e059d4a5d_thumb.jpg)](https://theorg.com/org/financiere-banque-nationale "Financière Banque Nationale")

* * *

Org chart
---------

* * *

Teams
-----

This person is not in any teams

* * *

Offices
-------

This person is not in any offices

---

### T-RIZE and Republic Launch ‘Vision 60’ to Expand Institutional Access to Tokenized Real Estate
*1,473 words* | Source: **EXA** | [Link](https://medium.com/@T-RIZE/t-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307)

T-RIZE and Republic Launch ‘Vision 60’ to Expand Institutional Access to Tokenized Real Estate | by T-RIZE | Medium

===============

[Sitemap](https://medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F1c3bcf526307&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40T-RIZE%2Ft-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmedium.com%2F%40T-RIZE%2Ft-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

T-RIZE and Republic Launch ‘Vision 60’ to Expand Institutional Access to Tokenized Real Estate
==============================================================================================

[![Image 4: T-RIZE](https://miro.medium.com/v2/resize:fill:64:64/1*puRnXkoDpHujMx69iZ2mQQ.png)](https://medium.com/@T-RIZE?source=post_page---byline--1c3bcf526307---------------------------------------)

[T-RIZE](https://medium.com/@T-RIZE?source=post_page---byline--1c3bcf526307---------------------------------------)

Follow

4 min read

·

Sep 4, 2025

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F1c3bcf526307&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40T-RIZE%2Ft-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307&user=T-RIZE&userId=f71290affb48&source=---header_actions--1c3bcf526307---------------------clap_footer------------------)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F1c3bcf526307&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40T-RIZE%2Ft-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307&source=---header_actions--1c3bcf526307---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3D1c3bcf526307&operation=register&redirect=https%3A%2F%2Fmedium.com%2F%40T-RIZE%2Ft-rize-and-republic-launch-vision-60-to-expand-institutional-access-to-tokenized-real-estate-1c3bcf526307&source=---header_actions--1c3bcf526307---------------------post_audio_button------------------)

Share

QUEBEC, MTL, Aug. 27, 2025 — T-RIZE Group, a global fintech firm offering institutional-grade tokenization infrastructure, is launching Vision 60 by Ste-Rose, a $24.2 million, 60-unit energy-efficient residential development in Laval, Québec. This project is part of a 500+ unit new construction deal with T-RIZE Group, valued at $200 million. Tokenized by T-RIZE, the offering is being launched through a strategic collaboration with [Republic](https://republic.com/), one of the world’s leading regulated investment platforms with over 3 million users, $3 billion in deployed capital, and more than 2,500 ventures backed. Accredited investors will be able to participate using both fiat and cryptocurrency.

Press enter or click to view image in full size

![Image 5](https://miro.medium.com/v2/resize:fit:700/1*9_kMha8G28AAynnZWM664w.jpeg)

**Pipeline Execution in Motion**

Vision 60 by Ste-Rose follows [Vision 87](https://vision87.com/) by Champfleury, an 87-unit, $23 million tokenized offering that forms part of a separate $300 million, 956-unit residential development. Together, these offerings reflect the ongoing execution of T-RIZE’s multi-billion-dollar pipeline, applying a scalable, compliant framework for bringing real-world assets onchain.

T-RIZE leads tokenization, including asset digitization, legal structuring, and smart contract deployment. Republic’s affiliate broker-dealer, OpenDeal Broker LLC , Member FINRA & SiPC, oversees investor onboarding and distribution under Regulation D.

**Token-Powered Infrastructure**

Vision 60 will be deployed on an EVM-compatible blockchain such as Base or Avalanche, two leading infrastructures supporting institutional adoption of real-world assets. Base, 

*[... truncated, 26,839 more characters]*

---

### Team | Rizenet & T-RIZE Documentation
*1,037 words* | Source: **EXA** | [Link](https://docs.t-rize.io/docs/trize/Team)

Madani Boukalba
---------------

### Co-Founder and CEO

Madani brings over 15 years of institutional experience in capital markets. As a former Senior Trader at [CDPQ](https://www.cdpq.com/), he specialized in risk analysis, market strategies, and tokenization technologies. At CDPQ, he was renowned for establishing industry benchmarks and driving strategic innovation. Madani's leadership at T-RIZE is pivotal in integrating real estate and private credit into cutting-edge blockchain solutions.

Kaiwen Zhang Ph.D
-----------------

### Chair holder of the T-RIZE Research Chair at ÉTS

Professor Kaiwen Zhang serves as a professor at [ÉTS Montréal](https://www.etsmtl.ca/) where he specializes in Software and IT Engineering. Holding a Ph.D. from the University of Toronto, he also completed an Alexander von Humboldt postdoctoral fellowship in Computer Science at the TU Munich from 2015 to 2017. He leads pioneering research in blockchain technologies focused on tokenization, federated learning, and distributed systems. His significant contributions to major conferences like IEEE ICDCS and ACM Middleware have helped set industry standards.

Eduardo Furtado, M.Eng.
-----------------------

### Founding Partner, CTO

Eduardo is an expert in Distributed Ledger Technology, Cyber Security, and complex systems architecture. He began his tech journey more than 20 years ago and holds a Bachelors degree in Computer Science and Master's degree in Software Engineering.

Eduardo is recognized for his hands-on expertise in full-stack development, software design, innovative blockchain applications that significantly impact the industry, and for being a polyglot in human and computer languages.

Michael Duchesne, M.Eng
-----------------------

### Founding Partner, Head of AI & Web3

Michael holds a Master’s degree in Software Engineering from ÉTS. He focuses on Machine Learning and Blockchain, particularly in Federated Learning and Decentralized Finance (DeFi). Michael combines his practical experience and theoretical knowledge to lead projects that push the boundaries of data privacy and transaction security.

Thien Duy Tran, M.Sc. CFA, CAIA
-------------------------------

### Founding Partner, Director & Head Product Strategy

Thien brings extensive financial expertise from his former role as an investment consultant for pension funds, foundations, and endowments. He holds CFA and CAIA charters along with a Master’s degree in Financial Engineering. His robust background in strategic asset allocation, financial modeling and market research has recently led him to specialize in DeFi, Web3, and RWA Tokenization. Over the last four years, he has leveraged his deep institutional finance knowledge and embraced cutting-edge technologies to develop new innovative product strategies.

Helmi Trabelsi, M.Eng.
----------------------

### Head Blockchain

Helmi brings over seven years of specialized blockchain experience from École de Technologie Supérieure. His work includes enhancing Hyperledger Fabric to improve system efficiency and security, and he has been instrumental in developing advanced personal data tokenization systems.

Mikaeil Mayali, M.Eng.
----------------------

### AI engineer

Mikaeil brings 4 years of experience in blockchain and decentralized machine learning, specializing in federated learning and blockchain analysis. Holding a Master’s in Software Engineering from ÉTS, he focuses on onchain federated learning at T-RIZE Group. Proficient in LLMs, TypeScript, and Python. He is an Honor Student and published researcher exploring AI applications in blockchain, including Bitcoin transaction analysis.

Yahya Shahsavari Ph.D
---------------------

### AI & DLT Technology Architect

Dr. Yahya Shahsavari is an esteemed expert in cybersecurity, AI, and blockchain. After earning his Ph.D. from ÉTS and serving as a postdoctoral researcher at the University of Montreal, he has made notable contributions to the industry as a distinguished reviewer for IEEE and consultant, leveraging his academic expertise to tackle complex challenges.

Jeremy Larente LLB, MBA
-----------------------

### General Counsel

Attorney Larente, specializing in corporate restructuring and tax planning, brings a focused approach to mergers, acquisitions, and optimizing fiscal structures at T-RIZE. Holding an LLB and an MBA from Université de Sherbrooke, his ongoing study for a Master’s in Taxation is enhancing his ability to navigate complex tax laws effectively.

Isabelle Godin
--------------

### Head of Branding​

Isabelle has over 15 years of branding and marketing experience, leading strategic initiatives that position T-RIZE prominently in the financial sector. She specializes in elevating brand visibility and market impact, contributing to significant growth in brand equity.

Andrée-Anne Godin
-----------------

### Organizational Resources Strategist

Andrée-Anne brings a decade of HR expertise, focusing on transformative strategies that enhan

*[... truncated, 2,687 more characters]*

---

### T-RIZE Group secured a $300M tokenization deal, supercharging a $2B Global pipeline and redefining decarbonized institutional-grade Real World Asset (RWA) investments
*2,760 words* | Source: **EXA** | [Link](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html)

T-RIZE Group secured a $300M tokenization deal, supercharging a $2B Global pipeline and redefining decarbonized institutional-grade Real World Asset (RWA) investments

===============

[Close menu](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-0)

*   [News](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-news)
*   [Products](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-products)
*   [Contact](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-contact)

[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-default)
*   [Send a Release](https://www.prnewswire.com/account/online-membership-form/)
*   [Client Login](https://www.prnewswire.com/account/online-membership-form/)
*   [Resources](https://www.prnewswire.com/resources/)
*   [Blog](https://www.prnewswire.com/resources/articles)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [RSS](https://www.prnewswire.com/rss/)
*   [](https://twitter.com/PRNewswire)[](https://www.facebook.com/pages/PR-Newswire/26247320522)[](https://www.linkedin.com/company/pr-newswire/)

[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-news)
*   _3_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-1)News in Focus
*   _5_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-2)Business & Money
*   _5_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-3)Science & Tech
*   _5_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-4)Lifestyle & Health
*   _0_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-5)Policy & Public Interest
*   _1_[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-6)People & Culture
*   [Send a Release](https://www.prnewswire.com/account/online-membership-form/)
*   [Client Login](https://www.prnewswire.com/account/online-membership-form/)
*   [Resources](https://www.prnewswire.com/resources/)
*   [Blog](https://www.prnewswire.com/resources/articles)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [RSS](https://www.prnewswire.com/rss/)
*   [](https://twitter.com/PRNewswire)[](https://www.facebook.com/pages/PR-Newswire/26247320522)[](https://www.linkedin.com/company/pr-newswire/)

[](https://www.prnewswire.com/news-releases/t-rize-group-secured-a-300m-tokenization-deal-supercharging-a-2b-global-pipeline-and-redefining-decarbonized-institutional-grade-real-world-asset-rwa-investments-302333212.html#mm-panel-products)
*   [Explore Our Platform](https://www.prnewswire.com/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.prnewswire.com/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.prnewswire.com/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.prnewswire.com/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.prnewswire.com/multichannel-amplification/ "Amplify Content ")
*   [All Products](https://www.prnewswire.com/products/all-products/ "All Products")
*   [

*[... truncated, 74,245 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Madani Boukalba | President & CEO - T-RIZE Group Corporation ...](https://councils.forbes.com/profile/Madani-Boukalba-President-CEO-T-RIZE-Group-Corporation/1ab2e0a5-31f7-4bcf-8a70-d305da4d9903)**
  - Source: councils.forbes.com
  - *Nov 7, 2023 ... Find articles by Madani Boukalba, President & CEO of T-RIZE Group Corporation ... Read Article. Protecting Your Hardware: 20 Ways To E...*

---

*Generated by Founder Scraper*
