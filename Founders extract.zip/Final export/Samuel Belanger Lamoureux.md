# Samuel Belanger Lamoureux

## Position actuelle

**Titre** : Co-Founder, Co-President, CRO | Cemiar inc.
**Entreprise** : Cemiar
**Durée dans le rôle** : 4 years 3 months in role
**Durée dans l'entreprise** : 4 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Transforming Insurance with Technology: Web Engineering Solutions, APIs, Integration, Artificial Intelligence

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABtOlS0BgXr5ndNIF23uHvTIA1c94pDqLfU/
**Connexions partagées** : 32


---

# Samuel Belanger Lamoureux

## Position actuelle

**Entreprise** : Cemiar

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Samuel Belanger Lamoureux

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399485723382525953 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG2EaQVz2bc-w/feedshare-shrink_800/B4EZrAxWRCGUAg-/0/1764170753851?e=1766620800&v=beta&t=Dl5DU6xmQzyWsDlzYx7E5aAuNtdO66YjBGBJbHiCUG4 | This is a big milestone for us and an important one for the entire Canadian P&C ecosystem.

Being the first and only vendor in Canada to achieve CSIO’s JSON API certification is more than a badge; it’s a clear signal of where Cemiar is headed and what we’re building toward.

This unlocks new possibilities for brokers, stronger real-time connectivity, and a foundation for the next generation of automation.

And honestly… it’s only the beginning.

Proud of our team, thankful to the CSIO - Centre for Study of Insurance Operations, and grateful for the trust from partners across the country. Let's keep pushing the industry forward!! | 24 | 9 | 0 | 1w | Post | Samuel Belanger Lamoureux | https://www.linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | https://linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | 2025-12-08T05:25:50.642Z |  | 2025-11-26T16:34:32.251Z | https://www.linkedin.com/feed/update/urn:li:activity:7399468452790366208/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7336406462732152832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGlXfXotdeNBw/feedshare-shrink_800/B4EZc9mHaJHcAg-/0/1749085095512?e=1766620800&v=beta&t=Vy2yTp-yTKMJcE0fQZrEEsB4bNRWzU8Oo0_ogtnvfTQ | I was in Toronto yesterday as a guest speaker at the Avantis Alliance annual meeting, what a great time I had!

For those unfamiliar, Avantis is a national alliance of independent insurance brokerages representing each Canadian province. Founded in 1986, their philosophy is “Strength Through Knowledge and Co-operation.” Brokerages in the group openly share best practices and business development ideas in a forum designed to enhance productivity and innovation.

Today, Avantis includes ten member brokerages with over $800 million in annual gross written premium, and meets formally once a year to discuss market issues and industry developments at both provincial and national levels.

It was a real pleasure to have the opportunity to present Cemiar’s AI, integration, and automation solutions, engage with everyone, and witness their positive reactions firsthand. The discussions and questions showed how relevant and exciting these technologies are for the future of brokerage operations.

Thank you to everyone who participated, and for the invitation, I feel lucky and honored to have been included among all of you!

Guild Insurance Group, BC ASSUR, HSM Insurance, Johnston Meier Insurance Agencies Group, Advantage, Miller Insurance Brokers Inc , Trigon Insurance Brokers Ltd., Steers Insurance Limited, Jones Insurance, Butler Byers Insurance Ltd

#Insurance #CemiarLink #Insurtech #AI #BrokerTech #Innovation #Cemiar #CanadianBrokerages #AvantisAlliance #Toronto | 29 | 1 | 1 | 6mo | Post | Samuel Belanger Lamoureux | https://www.linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | https://linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | 2025-12-08T05:25:55.703Z |  | 2025-06-05T15:00:04.556Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7322960389279797250 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFXpv3oZtgB-w/feedshare-shrink_800/B56ZZ_59EgGoAg-/0/1745902623393?e=1766620800&v=beta&t=eT6rRd9CE3XfNOeJW1tIASMFmOnZSQF9UKMmrcQmjkA | What an amazing experience last week at the 2025 Insurance Brokers Association of Manitoba (IBAM) convention in Winnipeg! 🙌

It was truly an honor to be invited as a panelist on the annual tech panel alongside two incredible industry leaders, Dwight Heppner and Nick Kidd. 

I'm still reflecting on how great it was to be part of it! 

A special shout-out to Susan Gilbert for moderating the panel so expertly, it was a pleasure getting to know her through this process, and she did a fantastic job keeping the discussion engaging and insightful.

It was fun to share our findings, realizations, and predictions on where the industry is heading and even more rewarding to receive such amazing feedback afterward from the attendees!

A big thank you to Alexa Loewen, Director of Operations & Marketing at IBAM, for the event organization, and to Grant Wainikka, M.A. (Econ.), MBA, Chief Executive Officer of IBAM, for his leadership in making it all happen.

And I have to mention how much of a pleasure it was to attend the event with Cemiar’s newest team member, Victor Jeanmougin, who did a fantastic job representing us at the tradeshow! 👏

It's hard not to smile when I think about how far we've come at Cemiar. 

Definitely an event we’ll remember for a long time.

Can’t wait to be back next year — and now, our eyes are set on the Insurance Brokers Association of Alberta convention next week in Banff, AB! | 40 | 3 | 6 | 7mo | Post | Samuel Belanger Lamoureux | https://www.linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | https://linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | 2025-12-08T05:25:55.704Z |  | 2025-04-29T12:30:10.829Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7320466685373689858 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHINyfurC5fCg/feedshare-shrink_800/B56ZZeEZQvHsAg-/0/1745334933691?e=1766620800&v=beta&t=gEV6VUaOwAP5sz_HOmu_YuoIiotJ1gpflIGeiAPuVuo | Come say hi at Booth 41 or join me Friday at 11:15 for the Tech Panel — lots of fun, great people, and sharp insights ahead. | 6 | 0 | 0 | 7mo | Post | Samuel Belanger Lamoureux | https://www.linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | https://linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | 2025-12-08T05:25:55.708Z |  | 2025-04-22T15:21:05.487Z | https://www.linkedin.com/feed/update/urn:li:activity:7320465300527710209/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7308880414822006785 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQE_wn4SWA48-g/image-shrink_800/B4EZW5APexHUAo-/0/1742565604275?e=1765778400&v=beta&t=eMM5ORY0Fz6zNa9Z0o4tRGWDa3nXmpCtei2eVcyGDIA | Excited to be representing Cemiar at IBAM’s annual convention this April in Winnipeg! I’ll be joining industry colleagues Nick Kidd from QUOTEY and Dwight Heppner from Guild Insurance Group on the Tech Panel to discuss what’s possible with today’s technology for brokerages, and what’s coming next. Looking forward to a great conversation! | 19 | 2 | 2 | 8mo | Post | Samuel Belanger Lamoureux | https://www.linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | https://linkedin.com/in/samuel-b%C3%A9langer-lamoureux-3a5518109 | 2025-12-08T05:25:55.708Z |  | 2025-03-21T16:01:23.325Z | https://www.linkedin.com/feed/update/urn:li:activity:7308849934768717825/ |  | 

---



---

# Samuel Belanger Lamoureux
*Cemiar*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Starting A Side Hustle In Quebec: 6 Young Entrepreneurs Who Made Their Dreams A Reality](https://www.mtlblog.com/quebec-side-hustle-stories)
*2024-01-26*
- Category: blog

### [Centre of Excellence for Digital Innovation](https://centresofexcellencenb.ca/digitalinnovation/?speaker_series=technology-and-entrepreneurship-with-sam-poirier-from-potential-motors)
*2022-11-01*
- Category: article

### [CIBL radio](https://kiima.co/en-us/blogs/blog/cibl-radio?srsltid=AfmBOop_pVH3Zk08ElsIj-xUG3Xb6L4R6qTaLaVmTpuZYpA63853BxW6)
*2023-09-07*
- Category: blog

### [N°6 - novembre 2023 - Commercial Real Estate Magazine - JBC Média](https://jbcmediakiosk.milibris.com/commercial-real-estate-magazine/commercial-real-estate-magazine/n6-2023)
*2025-01-01*
- Category: article

### [Sampler CEO on the peer-to-peer future of marketing](https://canadiangrocer.com/sampler-ceo-peer-peer-future-marketing)
*2025-01-07*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Season 8 - Episode 9: Samuel Belanger-Lamoureux](https://digitalinsurancepint.com/season-8-episode-9-samuel-belanger-lamoureux/)**
  - Source: digitalinsurancepint.com
  - *Apr 22, 2025 ... In this episode of the Digital Insurance Pint podcast ... Samuel Bélanger-Lamoureux, co-president of Cemiar, an insuretech firm dedic...*

- **[S8.9 Samuel Belanger-Lamoureux - YouTube](https://www.youtube.com/watch?v=AON4RR1hnPA)**
  - Source: youtube.com
  - *Apr 21, 2025 ... ... podcast, Tom, Adam, Jeff & Steve discuss the entrepreneurial journey of Samuel Bélanger-Lamoureux, co-president of Cemiar, an ins...*

- **[Panels - Insurance Brokers Association of Manitoba](https://ibam.mb.ca/panels-2025.html)**
  - Source: ibam.mb.ca
  - *Moderated by: Ren de Moissac. Samuel Belanger Lamoureux. Nick Kidd. Dwight Heppner. Samuel Belanger Lamoureux. Co-Founder, Co-President, CRO, Cemiar. ...*

---

*Generated by Founder Scraper*
