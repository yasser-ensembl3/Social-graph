# Sirio Berati

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Enhancor AI
**Durée dans le rôle** : 7 months in role
**Durée dans l'entreprise** : 7 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Marketing Services

## Description du rôle

I founded Enhancor AI because I was obsessed with one problem no one in the industry seemed to solve well: realistic human skin texture in AI-generated visuals.

Everything looked overly smooth, plastic, uncanny, or fakem and I knew that if AI was ever going to be taken seriously in photography, film, fashion, and advertising, realism had to be fixed at the texture level.

So I built Enhancor AI from the ground up with one mission:
bring true, camera-grade realism to AI images, starting with skin.

What began as a solo project with no funding and no coding background has grown into one of the fastest-scaling AI platforms in the creator ecosystem. 

Our models power some of the most realistic human images online, helping creators, photographers, brands, and production teams generate visuals with authentic pores, imperfections, micro-shadows, fine lines, and natural skin depth that traditional models simply could not achieve.

In 6 months, Enhancor has scaled from $0 to $350K+ MRR, fully bootstrapped and profitable, used by thousands of creators worldwide. 

Our tools , like Enhancor V3, Crisp Upscaler, Skin Detailer, KORA PRO, and more, have set a new standard for photorealism in AI.

## Résumé

Creator. Visionary.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAClIVRoBTsiHh90m21vTB8PTha7e0KcBC-I/
**Connexions partagées** : 4


---

# Sirio Berati

## Position actuelle

**Entreprise** : Enhancor AI

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Sirio Berati

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402013286352949249 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4D05AQE89qwUcNWRqg/mp4-720p-30fp-crf28/B4DZrk7xiGJMCI-/0/1764777483703?e=1765785600&v=beta&t=uSTqD-0sFpg3j682_7ShZPEHfmEpX644dIYupvTZ_pQ | https://media.licdn.com/dms/image/v2/D4D05AQE89qwUcNWRqg/videocover-high/B4DZrk7xiGJMBU-/0/1764777473072?e=1765785600&v=beta&t=_3Po4XjIrh754wp6k6HtqpMqaQNCqQU2vNB6rU84Pgk | Kling 2.6 Pro just dropped and it’s by far the best image to video model to date. 

You can check out my entire YouTube video to copy all my prompts. 🫡 | 30 | 4 | 1 | 4d | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:30.725Z |  | 2025-12-03T15:58:10.223Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401783322328158208 | Video (LinkedIn Source) | blob:https://www.linkedin.com/57937e7a-f265-41d7-8e4d-41c8d86e75c7 | https://media.licdn.com/dms/image/v2/D4D05AQExt9h-8y71mg/videocover-low/B4DZrhqrvNIkBQ-/0/1764722655854?e=1765785600&v=beta&t=j_Kx0qxl60wjzVVNCcMrShXv3klV20e7RF_wWoiwQTo | 100% AI Generated.

This is Kling 2.6 PRO.

I spent 12h generating this clip trying my best to get the most realistic and cinematic results. I probably spent over $60 to get here.

From script, to frames, to audio and video. All AI. 

What do you think? | 534 | 83 | 19 | 5d | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:30.726Z |  | 2025-12-03T00:44:22.527Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400208176593313792 | Video (LinkedIn Source) | blob:https://www.linkedin.com/be4abc21-8f53-40d1-a23e-426b3b84d200 | https://media.licdn.com/dms/image/v2/D4D05AQH9Mls7PB2DHg/videocover-high/B4DZrLSE9wIABU-/0/1764347107315?e=1765785600&v=beta&t=3T6ShOXqJxFgz93bRWSKQ7vESIEyTp5WfrFocB3ErLo | 100% AI generated. 

Testing out character emotion with celebrities using Nano Banana Pro, Enhancor V3, Seedance 1 and Kling 2.5 Pro. Trying to achieve a cinematic look here.

Where does it lack? | 253 | 59 | 14 | 1w | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:30.727Z |  | 2025-11-28T16:25:18.519Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398421366078840832 | Video (LinkedIn Source) | blob:https://www.linkedin.com/eeaa739f-99e2-4031-99fa-12a8f6ab5a85 | https://media.licdn.com/dms/image/v2/D4D05AQEKFfJrTTfKng/videocover-high/B4DZqx4.e.GQBU-/0/1763921099449?e=1765785600&v=beta&t=RTJW53NfZtc4kGnSlVN8PtAkgp_IvDh4ifQDidlvjI4 | I user Gemini 3 to build a holographic control center to help Santa deliver his gifs easier this year. Took me 30 minutes, one prompt and some back and forth.

Link to the app and prompt in the comments :) | 41 | 5 | 2 | 2w | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:30.728Z |  | 2025-11-23T18:05:09.695Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7397318597649440768 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFeIUs98eAKhQ/feedshare-shrink_1280/B4DZqiOELrJ4As-/0/1763658187941?e=1766620800&v=beta&t=Mgln71GnSo21jsZ3wwK-PoQCbOTXmN1WRxQg5sn8Awg | The scariest thing I have ever seen recently with AI models.

I uploaded my face and name inside Nano Banana 2 (Pro) and asked it to generate an ID. That’s it. Nothing else.

It guessed my nationality, age, color of my official Albanian government ID, without me specifying any of it.
It added the official watermark too.
Crazy.

I believe Nano Banana searches google to pull all this information. And I used it through API. 

So there was no way for it to know anything about me. | 91 | 25 | 7 | 2w | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:30.729Z |  | 2025-11-20T17:03:09.213Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7382078132780126209 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE-qH0I28AO2g/feedshare-shrink_800/B4EZnJo2ZQIIAg-/0/1760024575724?e=1766620800&v=beta&t=1tnl3g6Mhw7GQrBKBih4O0kq-_hLk4mAIEeEuPmF49w | When I opened my Forbes Under 30 speech, I said something that even I knew sounded bold:

By 2027, the next billionaires will be creators. And I will try to prove it.

Four months ago, the world told me I wasn’t worth investing in.
Today, I’m running one of the fastest-growing creative AI startups, bootstrapped, zero ads, just pure community and creativity.

I’m not here because I had the perfect plan. I actually do not have to do lists. My life is chaotic.

I’m here because I learned to combine everything I know: design, storytelling, tech, emotion, into something that actually works.
That’s what being a creator is.

We do not specialize. We synthesize.

I’ve always felt that creators are the original GPTs.
We don’t just learn, we remix, we adapt, we imagine.
And when you give that kind of person access to AI, that’s when the magic really happens.

None of this would exist without the people who believed, built, and experimented with me. YOU.

Thank you @forbes for giving me the opportunity to share my story. The event was phenomenal. 

I’m genuinely grateful for everyone who’s been part of this journey, every message, every test, every idea we tried together. Every “ai slop” comments. Every criticism on not offering free trial. All of them.

If there’s one piece of advice I can give you: use AI to build the most absurd idea you have ever had but never had the chance to bring it to life.

Because the real magic of AI is not what it can do for you, but how it empowers you to do what you’ve always wanted.

To create — without limits.

This is Sirio

📷 Jamel Toppin for Forbes | 63 | 7 | 0 | 1mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.075Z |  | 2025-10-09T15:42:59.234Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7381857655587487744 | Text |  |  | Google VEO 3.1 dropping soon! | 7 | 0 | 0 | 1mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.075Z |  | 2025-10-09T01:06:53.375Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7381745527903924224 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f0193ac1-1e4c-4352-afab-ef6bfc868d93 | https://media.licdn.com/dms/image/v2/D4D05AQGgDAastjSZIA/videocover-high/B4DZnE6PAyH4B4-/0/1759945264132?e=1765785600&v=beta&t=bI6m_8dtihAsrLpcfOwk_skAyPHqrdrxE1exbed4V2o | Create Consistent Videos with Sora 2 (timeline prompting) | 59 | 40 | 3 | 1mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.076Z |  | 2025-10-08T17:41:20.052Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7380770683494137856 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHCU2LV9CJjCQ/feedshare-shrink_800/B4DZm3D0j_GgAg-/0/1759712857586?e=1766620800&v=beta&t=3qxfGJ9iobcs0l6bp-SZ10xl5WdQnUilLEApzpyv8ks | Who is ready for some next level hyper realism?

I am.

Coming this week :) | 72 | 3 | 2 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.077Z |  | 2025-10-06T01:07:39.033Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7380652609835089920 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE0gv87pTyKDA/feedshare-shrink_800/B4DZm1YbEtIcAg-/0/1759684705246?e=1766620800&v=beta&t=mn3XndLQmDrOk1YG_qsk3kYdnggy3CpmXpkFxixJ8ag | Tomorrow, we are about to change image generation forever :)

Generated with KORA PRO! | 41 | 5 | 0 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.078Z |  | 2025-10-05T17:18:28.079Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7377395797761490944 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE0FQaGxfzy3Q/feedshare-shrink_800/B4DZmHGYNJJEAg-/0/1758908221360?e=1766620800&v=beta&t=pq5d9jFlND6duad7l_iwDy8_OJ0-MIE8ow2zmv8DXgw | WILD! E-com is about to change!!

You can now transfer/copy ANY pose and have your AI influencer create any campaign, with the new pose transfer feature inside Enhancor.

All you got to do: upload an image of your influencer + the pose you want to copy, hit generate and boom!!

Pro tip: use nano banana for more control.

(link below) | 37 | 3 | 0 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.078Z |  | 2025-09-26T17:37:03.572Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7377111557698322432 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQH9Pi0pZ2xuKg/feedshare-shrink_800/B4DZmDD2zuGQAg-/0/1758840453834?e=1766620800&v=beta&t=FwV9JUfGWFnTBLOdtLSXtu8mluBEU3RRRGY6fL-neh4 | I just built a workflow that allows you to transfer ANY pose and control your avatar's movement.

Open Sourcing this this week.

Extremely excited about it. | 27 | 2 | 0 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.079Z |  | 2025-09-25T22:47:35.460Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7376687965839810561 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5f280dd7-e6d5-499f-8f67-729d1eb8a064 | https://media.licdn.com/dms/image/v2/D4D05AQH8Prl5MgUh8w/videocover-low/B4DZl9A8kgJMB8-/0/1758739345295?e=1765785600&v=beta&t=wMNys5ET74hiKtUF7HXJQ53bP6C1vKqlqU-cDp1Iauw | AN Animate just broke the internet (Open-Source + Guide below) | 25 | 3 | 2 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.080Z |  | 2025-09-24T18:44:23.291Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7376233727598718977 | Video (LinkedIn Source) | blob:https://www.linkedin.com/685ce74b-329a-496d-a7ad-53bb08ba23fd | https://media.licdn.com/dms/image/v2/D4D05AQE1b4W5NmABaw/videocover-high/B4DZl2lbOmJgB8-/0/1758631155764?e=1765785600&v=beta&t=FfyMeaUXzBvF66vm6C47lTtkP740l7jqE_C-02RMNU8 | It is officially game OVER!

Wan Animate (fully open source) is definitely a SOTA model. 

The fidelity of the image is like nothing I have seen so far.

The relight LoRA does a phenomenal job as well with enhancing environmental lighting & integration.

What’s missing? | 54 | 7 | 11 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.081Z |  | 2025-09-23T12:39:24.455Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7376095728500285441 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a4ac1445-6f73-4963-a74c-378ed4abb113 | https://media.licdn.com/dms/image/v2/D4D05AQGX_RpbYHkkZg/videocover-high/B4DZl0n8R.JIB8-/0/1758598258072?e=1765785600&v=beta&t=YmkKA4nR68oUv8pbJ3u73yMwLi-S3GJpILnezOlj4-s | This is Hollywood level character replacement with AI (link below 👇🏼)

Wan Animate is absolutely mind-blowing! Achieve state of the art actor replacement entirely with AI, from one input image, in less than 10 minutes.

You can now access it inside Enhancor/Tools/Animate🫡

Yes, that’s me in the frame. And no, Taylor is not my innie. If you were asking | 51 | 4 | 3 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.082Z |  | 2025-09-23T03:31:02.906Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7375959356405714944 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e593e30f-e17b-4e0d-a3a5-80d574cf6110 | https://media.licdn.com/dms/image/v2/D4D05AQGkKfF7yi9nUQ/videocover-high/B4DZlyrpAgHsCA-/0/1758565734219?e=1765785600&v=beta&t=rUYlbQA6d2QE8RoEnSmU9maChHbtBlL5olQGxDPqVc4 | We’re about to witness the biggest revolution in traditional entrepreneurship: creators taking over and setting the rules.

Redefining what it even means to build. How money is made, why companies exist, and what fulfillment looks like as a founder.

I get asked ALL the time if I am selling Enhancor. And to be fair, it never crosses my mind. Because that’s not how I operate. I build for fun. For community. For self. And mosts creatives do.

We do not see it as a door to financial freedom (which for sure can be), but to something greater. Meaning. Identity. Individual fulfillment. | 16 | 0 | 0 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.084Z |  | 2025-09-22T18:29:09.265Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7375697029961777152 | Text |  |  | For people who think AI is just a click of a button, here’s my 12-step creative cycle to actually create with AI, and it applies to any niche.

1️⃣ Imagine – Every project starts with a vision. AI can’t dream for me.
2️⃣ Converse – I talk it out with AI like a cofounder. Voice. I usually use my MetaAI glasses when I go on a walk and I talk to GPT.
3️⃣ Co-Ideate – We riff back and forth until sparks turn into concepts.
4️⃣ Sketch Sensemaking – I map the chaos into frameworks and outlines because this step helps me to visualize better.
5️⃣ Moodboard at Scale – AI generates hundreds of visual directions. My job is to now to curate.
6️⃣ Rapid Mockups – Quick drafts, prototypes, posts. Test before investing more time.
7️⃣ Human Workshop – Real reactions from peers and communities. AI can’t replace this. I send stuff to friends and they nay or yay.
8️⃣ Decide – Every idea has trade-offs: speed vs. quality, reach vs. revenue. I choose the lane.
9️⃣ Research Deep Dive – Market context so I’m not just adding noise. The story needs to be good.
🔟 Research + AI Co-Thinking – AI helps me analyze patterns and synthesize insights.
1️⃣1️⃣ Build & Realize – This is the work: making the thing. AI accelerates, but I execute. I am the asset. AI is the tool.
1️⃣2️⃣ Evaluate & Share – Publish, gather feedback, and loop back to step one.

👉 That’s the cycle. Not one click. Twelve steps.

This framework works whether you’re building content, products, or entire businesses. Fitness, finance, fashion, film, AI as a collaborator makes the cycle sharper in any niche.

The creators and entrepreneurs who understand this will outpace the ones still chasing “magic prompts.”

Curious: which step of the cycle do you feel most stuck in right now? | 17 | 3 | 1 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:34.085Z |  | 2025-09-22T01:06:45.767Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7375406589794488320 | Video (LinkedIn Source) | blob:https://www.linkedin.com/52a4243b-855c-4b21-a1a2-9d66c768acd3 | https://media.licdn.com/dms/image/v2/D4D05AQG9ingUwrhKrw/videocover-high/B4DZlq1LijJEB8-/0/1758433954889?e=1765785600&v=beta&t=Q-4Oeu6MEz3uGJzj8SVE0ZYlWMfTBsG5sJONnvmra1s | Wan 2.2 Animate is actually Crazy!!

You can replace characters from a simple source image. No need to first frame anymore.

It handles facial expressions and body movements like no other model I have ever seen.

It is open source and free to use, that's the crazy part! | 91 | 7 | 7 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.630Z |  | 2025-09-21T05:52:39.435Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7375342971858120704 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ea2097a0-cc5e-4a8c-82e5-351585cb5e7a | https://media.licdn.com/dms/image/v2/D4D05AQHVmAjn9iZiiQ/videocover-high/B4DZlp7Ug2G8B8-/0/1758418787977?e=1765785600&v=beta&t=bIDN4iahyHQpT9HRcXkrZpK4pYScAGEKZQA4gglijKA | Wan 2.2 Animate Lip syncing Test.

Definitely way better than Runway Act2 in my opinion.

Takes about 8 minutes for a HD video to be processed at 720p vertical (reels style) | 190 | 15 | 11 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.631Z |  | 2025-09-21T01:39:51.737Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7375265889279086592 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3bc5a099-e820-438e-b478-64d82d66b6e0 | https://media.licdn.com/dms/image/v2/D4D05AQEtB22T7GdITA/videocover-high/B4DZlo1KITHYB8-/0/1758400408471?e=1765785600&v=beta&t=o22XLxtYCTrkjxhczEvTSLh9PCxDLrcwAe_KWDNnS28 | Alibaba just destroyed all the competitors with Wan-Animate with better lip syncing, better performance videos,  with accurate facial expressions and actor replacement and with better lighting and color tone for seamless environmental integration.

Free, open source and no content moderation.

China did it again. | 72 | 8 | 12 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.631Z |  | 2025-09-20T20:33:33.818Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7375015896488153088 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5be9a994-67e1-4c1c-9ada-ca5cf001b7a4 | https://media.licdn.com/dms/image/v2/D4D05AQGzp3UCn51vJg/videocover-high/B4DZllR1xFGgB8-/0/1758340805751?e=1765785600&v=beta&t=6JipTBcSB57QLKlpVuUFpGPHPZpdT-AmQgmhy-zPg7Q | Testing out Wan-Animate

What’s wild is it makes full HD videos and also it does not need that “first frame” trick like Runway Act2

Just drop in an image + prompt, and your character is replaced instantly. | 23 | 3 | 4 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.632Z |  | 2025-09-20T04:00:10.892Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7374840570344550401 | Video (LinkedIn Source) | blob:https://www.linkedin.com/664383d5-7310-476b-a202-9eb87968a604 | https://media.licdn.com/dms/image/v2/D4D05AQH7ySqqMF4A_Q/videocover-high/B4DZliyKMQJcB8-/0/1758299001722?e=1765785600&v=beta&t=urY38CD3Y7jpkKZtA2N79tyKxlJYWMaR7KcMsntLwSk | Alibaba COOKED!! Hollywood is in big trouble.

Wan-Animate is an opensource vision model. It can:

1. Animate any character using a performer’s video, captures facial expressions & body motion. 

2. Replace characters in videos with animated ones while keeping original lighting & color tones for environmental integration. 

3.Uses spatial skeleton signals for body/movement control, and implicit facial features for expression control. 

4. Includes a Relighting LoRA module to adapt lighting & color consistent with the scene.

5. can do pure character animation or character replacement in videos.

Currently stress testing and and will keep you updated with all the use cases and how you can use it for FREE 🫡 | 465 | 51 | 62 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.632Z |  | 2025-09-19T16:23:29.882Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7370848240981774336 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e802e01f-eccc-4abe-a987-20042e008bfc | https://media.licdn.com/dms/image/v2/D4D05AQEHMRFBi0A1Fg/videocover-high/B4DZkqDJTVGkCM-/0/1757347147896?e=1765785600&v=beta&t=8yfObGrOTlzs-ZoniTIQ7t70bT5dSN81NsPXBOkCd58 | YC Combinator refused me and this is what happened right after! | 21 | 0 | 0 | 2mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.633Z |  | 2025-09-08T15:59:24.388Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7369860176868163584 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ee4a7ca9-e0fb-4dd3-93ed-02649f552bcd | https://media.licdn.com/dms/image/v2/D4D05AQF-Lm9uf72Ukg/videocover-low/B4DZkb.vbLJACI-/0/1757111478509?e=1765785600&v=beta&t=DZeT7ch6cDw7UmE1AQz8v9nFMK47eMyzQH3xm8UYVek | Just shipped Draw-to-Edit inside Enhancor AI, and I’m open-sourcing the whole thing.

How it works (under the hood)

1. Annotations pipeline

Frontend uses Canvas API (freehand strokes, arrows, text, image overlays, undo/redo, auto-resize to source resolution)

When you click Edit, we burn in your annotations on a copy of the image and send one clear instruction to the model: “Apply the changes indicated by the annotations, then remove all annotations/text/overlays so the final result is clean and seamless.” Result comes back clean, without any markup.

2. Brush-masking pipeline (the clever bit)

We record your brush strokes as points + siz. Compute a tight bounding box (+padding) around them. Crop that region, remap coordinates, send the smaller tile to the model. Stitch the edited tile back into the full image with a python script.

I’m releasing the full Draw-to-Edit implementation (canvas tools, annotation burn-in, brush bounding-box workflow, stitching script, and reference prompts).
👉 Repo: (link in comments)
👉 Live demo: Enhancor.ai → Tools → Draw to Edit (link in comments) | 61 | 3 | 1 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.633Z |  | 2025-09-05T22:33:11.546Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7368675143461625858 | Video (LinkedIn Source) | blob:https://www.linkedin.com/83a8143b-82e3-4ec2-ae5d-3c425c96c437 | https://media.licdn.com/dms/image/v2/D4D05AQE25TIWvguK3g/videocover-high/B4DZkLIVuyHwCM-/0/1756829048327?e=1765785600&v=beta&t=sx0TpQU505WUQ6DkgaaqzXiLKKqkyd0d-Q6uOg48q9I | Enhancor just released Draw to Edit for Nano Banana.

You can annotate, add text and upload reference images inside the canvas.

Drop “draw” to try it out.

New features releasing this week 👀 | 25 | 4 | 1 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.634Z |  | 2025-09-02T16:04:17.565Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7368329147535765504 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a27a905c-013e-4d61-87b5-e8564ee1259a | https://media.licdn.com/dms/image/v2/D4D05AQFXMa5nIQX0BQ/videocover-high/B4DZkGQKPnIEDA-/0/1756746557196?e=1765785600&v=beta&t=HUOmxEF0rwANODxoNU9KrEulsMl3aCQXmFT7rkO1DGg | Your favorite AI tool? Is simply a wrapper (well, most of them). A very well productized model that is part of a bigger workflow. Which of course, serves a use case.

1. Realistic Images -> use Wan 2.1/2 to finetune a LoRA
2. Product holding -> Nano Banan
3. VFX -> smart prompting + foundational model
4. Image Upscale -> flux dev comfyui
5. Video Upscale -> RealESRGAN
6. Character Consistency-> Finetune LoRAa

Want more secrets like these? 👀 | 24 | 3 | 0 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.635Z |  | 2025-09-01T17:09:25.708Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7367252759181484033 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c99d82c8-1099-40d0-bf8a-fdac257229bc | https://media.licdn.com/dms/image/v2/D4D05AQEshhBqjaMk0Q/videocover-high/B4DZj28MCQGkCI-/0/1756489921663?e=1765785600&v=beta&t=YAzVV9h-Cae6Uav49JU38hkfrFk75652qnRQosl8_cU | The real hack is not the tech you use, but how well you productize it to solve problems.

In the next few weeks we will see AI saas built on top of Nano Banana that will:

1. Solve for Virtual Tryons
2. Tattoo Design
3. Hairstyle
4. Graphic design editing

and more creative use cases. No one cares that you are a wrapper or an API. Everyone cares how well you solve particular problems.

Nano Banana is such a big deal: it’s horizontal. It’s not tied to one vertical. You can branch into multiple tangents, and each one can be its own app.

I am cooking something as well 👀 | 20 | 2 | 0 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.636Z |  | 2025-08-29T17:52:14.726Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7366099523972009984 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE8ZIBZ4zfyZg/feedshare-shrink_800/B4DZjmkXY2H4As-/0/1756214955347?e=1766620800&v=beta&t=M3ED5UDAArKYgLmYXehYAfpEOT68fZNNGi3Wy_40XY8 | Just dropped Nano Banana inside Enhancor!! The BEST image editor model in the world.

Tools -> Image Editing.

(server is going through a lot of volume rn, be patient :) ) | 55 | 9 | 0 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.636Z |  | 2025-08-26T13:29:42.026Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7365470525671849986 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bd00945f-d7a7-44ca-8d9b-4d8d5121894a | https://media.licdn.com/dms/image/v2/D4D05AQHiFRJ8W_7Qlw/videocover-high/B4DZjdoK8nG8CI-/0/1756065001987?e=1765785600&v=beta&t=UXRqzVkIeSPnVdq302joJjVfKjZq9LJ13gGFNZZPkbc | These are the worst things you can do today when building an AI product, ranked from worst to least:

1. Free trial. Absolutely not needed. You’re bootstrapping, barely able to fund this yourself. Why pay for others? Say no to socialism, hehe.
2. Co-founder. There goes your 50%.
3. App store. Not necessary.
4. Ads. You can reach more people organically at a faster rate, or partner with those who already have an audience if you’re not willing to learn how to build one.

Enhancor was entirely built and scaled through the support of my community. If I can do it, you can too. | 15 | 4 | 0 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.637Z |  | 2025-08-24T19:50:17.145Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7365388523740315648 | Video (LinkedIn Source) | blob:https://www.linkedin.com/58c680f2-5ff1-47d0-be0a-9c147cbb5379 | https://media.licdn.com/dms/image/v2/D4D05AQG8FG6lN5HnyQ/videocover-high/B4DZjcdnotHwCM-/0/1756045456275?e=1765785600&v=beta&t=5Ef5vzuHrY3cW8HVzQCqY0fopLd7IzGoRIkcEWjor4k | Confirmed. Google will release nano banana in the coming weeks. This will disrupt the market, once again. | 284 | 11 | 9 | 3mo | Post | Sirio Berati | https://www.linkedin.com/in/sirioberati | https://linkedin.com/in/sirioberati | 2025-12-08T07:01:39.638Z |  | 2025-08-24T14:24:26.361Z |  |  | 

---



---

# Sirio Berati
*Enhancor AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Cracking the Code: Fixing AI’s Plastic Skin Problem](https://sirio.visionreimagine.com/p/cracking-the-code-fixing-ai-s-plastic-skin-problem)
*2025-02-16*
- Category: article

### [AI UGC for PROs by Sirio Berati course Archives - Econolearn](https://econolearn.com/tag/ai-ugc-for-pros-by-sirio-berati-course/)
*2025-01-18*
- Category: article

### [Sirio Berati - Hyper Realistic AI Selfies/Influencers full course updates Archives - Ecomkevin Course](https://coursesbykevin.com/product-tag/sirio-berati-hyper-realistic-ai-selfies-influencers-full-course-updates/)
*2025-01-01*
- Category: article

### [Sirio Berati – AI For Pros – MegaSkillz](https://megaskillz.com/product/sirio-berati-ai-for-pros/)
*2025-10-22*
- Category: article

### [AI For Pros Community by Sirio Berati (Group Buy) - Econolearn](https://econolearn.com/ai-for-pros-community-sirio-berati/)
*2025-08-11*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Find KORA Cinema here -> kora.enhancor.ai](https://www.threads.com/@heysirio/post/DM8DbXwucKJ/find-kora-cinema-here-koraenhancorai?hl=en)**
  - Source: threads.com
  - *Aug 4, 2025 ... Sirio Berati (@heysirio). 1.1K Views. Find KORA Cinema here -> kora.enhancor.ai ... Batteries Included Podcast (@batteriesincludedpodc...*

- **[Forbes' Flagship 2025 Under 30 Summit in Ohio | JobsOhio](https://www.jobsohio.com/newsroom/news-press/forbes-under-30-summit-in-columbus)**
  - Source: jobsohio.com
  - *Sep 8, 2025 ... Rowan Cheung, Founder & CEO, The Rundown; Sirio Berati, AI Creator and Founder & CEO, ENHANCOR AI; Jonathan Lord, Cofounder & CTO, Flu...*

- **[Top 10 UGC Tech Creators in 2025](https://influencers.feedspot.com/ugc_tech_instagram_influencers/)**
  - Source: influencers.feedspot.com
  - *Sirio Berati Bio I am @sirio. A visionary who uses AI to create without limits. ****@visionreimagine.com- Try Enhancor AI. ... Podcast Database · Maga...*

- **[Alex Warren, Suni Lee, Jake Shane and More to Join Forbes ...](https://finance.yahoo.com/news/alex-warren-suni-lee-jake-192900197.html)**
  - Source: finance.yahoo.com
  - *Sep 8, 2025 ... Sirio Berati, AI Creator and Founder & CEO, ENHANCOR AI. Jonathan Lord, Cofounder & CTO, Flux Marine. Soyoung Lee, Cofounder & Head of...*

- **[Alex Warren, Suni Lee, Jake Shane and More to Join Forbes ...](https://www.businesswire.com/news/home/20250908798714/en/Alex-Warren-Suni-Lee-Jake-Shane-and-More-to-Join-Forbes-Flagship-2025-Under-30-Summit-in-Columbus-OH)**
  - Source: businesswire.com
  - *Sep 8, 2025 ... Sirio Berati, AI Creator and Founder & CEO, ENHANCOR AI; Jonathan Lord, Cofounder & CTO, Flux Marine; Soyoung Lee, Cofounder & Head of...*

- **[2025 Forbes Under 30 Summit](https://www.forbes.com/connect/event/2025-forbes-under-30-summit/)**
  - Source: forbes.com
  - *Jake Shane. Comedian, Digital Entertainer and Podcast Host. Lucy Guo. Forbes ... Sirio Berati. AI Creator and Founder & CEO. ENHANCOR AI. Will ......*

- **[Sirio Berati (@heysirio) • Threads, Say more](https://www.threads.com/@heysirio)**
  - Source: threads.com
  - *Sirio Berati. heysirio. heysirio's profile picture. I am. @sirio . A ... I built Enhancor AI from $0 → $350K/month in 6 months. No investors. No ads ....*

- **[You can now transfer/copy ANY pose and have your AI influencer ...](https://www.threads.com/@heysirio/post/DPEnJN0iT9R/you-can-now-transfercopy-any-pose-and-have-your-ai-influencer-create-any-campaig)**
  - Source: threads.com
  - *Sep 27, 2025 ... Sirio Berati (@heysirio). 23 Replies. 4.4K Views. You can now ... Enhancor - AI-Powered Skin Texture Enhancement Tool. app.enhancor.a...*

- **[6 months ago I could barely pay rent. I had this idea but, I didn't ...](https://www.threads.com/@heysirio/post/DRKdcsMDhdo/video-months-ago-i-could-barely-pay-rent-i-had-this-idea-but-i-didnt-know-how-to-code)**
  - Source: threads.com
  - *Sirio Berati (@heysirio). 42 Replies. 20K Views. 6 months ago I could barely ... Enhancor AI from $0 → $350K/month in 6 months. No investors. No ads ....*

- **[Alex Warren, Suni Lee, Jake Shane And More To Join Forbes ...](https://www.forbes.com/sites/forbes-spotlights/2025/09/08/alex-warren-suni-lee-jake-shane-and-more-to-join-forbes-flagship-2025-under-30-summit-in-columbus-oh/)**
  - Source: forbes.com
  - *Sep 8, 2025 ... Sirio Berati, AI Creator and Founder & CEO, ENHANCOR AI and Trace Johnson, Cofounder, AI Owl, will discuss, debate and demo the future...*

---

*Generated by Founder Scraper*
