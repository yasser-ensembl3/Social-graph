# Mitch Joel

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : ThinkersOne
**Durée dans le rôle** : 3 years 5 months in role
**Durée dans l'entreprise** : 3 years 5 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Internet Marketplace Platforms

## Description du rôle

ThinkersOne is a platform offering personalized, short-form and affordable thought leadership video experiences from the best Thinkers in the world. It caters to businesses and organizations seeking educational and motivational live and recorded content. ThinkersOne features a wide range of topics, including business, personal development, sales, marketing, work culture, technology and beyond. It facilitates booking Thinkers for meetings, lunch & learns, smaller events and gatherings. The service is designed to inspire teams and enhance meetings with insights. If you’re looking to optimize your team’s professional development and corporate training with a focus on leadership, innovation, and personal growth to improve your business, ThinkersOne is for you.

## Résumé

Mitch Joel is Co-Founder of ThinkersOne - a new way to bring the world’s smartest voices into your team meetings, events and culture. It's not just content. It’s a new way to learn at the speed of business.

A visionary in media, technology and business transformation, Mitch helps people and organizations decode what’s now... and imagine what’s next. He connects global audiences through keynotes, articles, books and weekly conversations on Six Pixels of Separation - The ThinkersOne Podcast, where he explores innovation, leadership, and consumer behavior with some of today’s most interesting minds.

Mitch has spent nearly three decades launching, building, and scaling businesses at the intersection of content commerce and community. He started in music journalism, co-founding magazines and a record label, then helped pioneer digital media at early search engines and one of the first mobile publishing platforms. He later founded and sold his digital marketing agency to WPP, serving as President of a global firm operating in 25 countries with 3,000 employees.

Since 2005, Mitch has delivered 40–60 keynotes a year for companies like Google, Microsoft, Walmart, TikTok, Unilever and Shopify. His books: Six Pixels of Separation and CTRL ALT Delete (Grand Central Publishing/Hachette) — are international business bestsellers.

He serves on the boards of public, private and nonprofit organizations including Canadian Marketing Association, Postmedia, the Interactive Advertising Bureau, Canada’s Top 40 Under 40, iNovia Capital’s Early Stage Fund and the Westmount Public Library. Mitch was also named to Dr. Marshall Goldsmith’s “100 Coaches” and selected for the Thinkers50 Radar class of 2021.

Outside of business, he’s building something entirely different:
Groove – The No Treble Podcast, the largest oral history of electric bass players in the world... one conversation at a time.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAAW_QBPTH_q-o7c8wxyGfoitEIpPnJugs/
**Connexions partagées** : 268


---

# Mitch Joel

## Position actuelle

**Entreprise** : ThinkersOne

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Mitch Joel

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402359498255859715 | Text |  |  | It seems like my meditation last week on identity and growth struck a chord, so here’s another personal thread I’ve been pulling at…

We don’t talk enough about how fragile success really is.
Not the business metrics… those are obvious.
I mean the internal kind.
The kind that convinces you that what worked yesterday must be who you are tomorrow… that today’s thinking will resonate forever.

I kept circling this while editing my latest Thinking With Mitch Joel (ThinkersOne) conversation with Ranjay Gulati (Harvard Business School professor and author of How To Be Bold – The Surprising Science Of Everyday Courage).

His work pulls apart the myth that success makes us stronger.
Often… it does the opposite.

Success narrows us.
It makes us cling to old playbooks.
It rewards predictability, even when the world is begging us to evolve.

We imagine success as expansion… but for most leaders, it becomes confinement.
Once things work, you start protecting the version of yourself who made it work.
You stop experimenting.
You stop listening as widely.
You start believing your own mythology.

Success becomes a shell… and shells harden.

Ranjay talked about this trap with a kind of precision that made me uncomfortable in the best way. Leaders don’t become risk-averse because they’ve lost courage… but because they fear losing the story of themselves.

We like to think failure humbles us… but success does too… just more quietly.

It’s wild how often leaders stop growing long before the business does.
They scale the company… but not themselves.
They optimize performance… while starving intuition.

That’s the real fragility of success… it tricks you into thinking evolution is optional.

Ranjay reminded me that boldness isn’t a trait… it’s a practice.
A willingness to stretch beyond the identity success carved for you.
To risk being misunderstood again.
To remember that curiosity, not certainty, is what got you here.

And staying bold isn’t just about pushing through fear… it’s about staying fresh.

Fresh in your thinking.
Fresh in your learning.
Fresh in who you allow to teach you... peers, competitors, critics, people younger or less experienced.
The leaders who stay relevant aren’t just courageous… they’re students.

Maybe the real test of leadership isn’t how you handle failure?
Maybe it’s whether success makes you bigger… or smaller.
More open… or more guarded.

So here’s what I’ve been sitting with since the recording:

When success arrives, do you expand into the next version of yourself… or shrink to protect the old one?

I'd love to know if you're grappling with this as well?

I'll leave a link to our full conversation in the comments... | 12 | 1 | 0 | 3d | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.863Z |  | 2025-12-04T14:53:53.573Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401973290766008320 | Text |  |  | We’re entering a potentially scary world where the price doesn’t just update… it decides based on who you are.

Some call is “personalized pricing”… others call is “surveillance pricing.”
This isn’t dynamic pricing.
This isn’t supply and demand.
This isn’t the airline ticket goes up because the plane is almost full or the Uber gets more expensive because it’s raining.
This is when the price you see is based on you… your purchase history, your urgency, your digital footprint, your predicted willingness to pay… even your mouse movements.

Two people… same store, same product… two different prices.

Not because of market conditions… but because of who the algorithm thinks they are.
New York just became the first state to force retailers to disclose when they’re doing this (link to the article in the comments).
A tiny label that says: the system is profiling you right now.
It’s the first crack of transparency in a structure that’s been invisible for some time but is scaling because of AI… and one that’s accelerating because AI makes it easy, cheap and instant.

Now, I don’t think this is an issue of disclosure… It’s about trust.

Two things people hate:
The feeling that they’re being watched. 
The feeling that they’re being ripped off.

From a consumer standpoint, this pricing strategy does both.

It turns the simplest act in modern life… buying something… into a negotiation you didn’t know you were having.
The FTC has already warned that brands can track everything from your search patterns to the hesitation in your mouse movements.
Your battery level.
Your location.
Your browsing anxiety.
Your digital tells.

And then the system decides how much you should pay.

Some argue this could become a kind of private “progressive tax.”
Those who can afford more pay more… those who can’t get a break.
It’s a seductive story.
But that only works if the system chooses generosity over extraction.
And algorithms don’t choose morals… they choose margins.
Nothing in the history of these tools to date suggests that outcome.

Because this isn’t just pricing.

This is the migration of the advertising surveillance machine into the core of commerce.
The same architecture built to predict your attention is now predicting your wallet.
The same data used to optimize your feed is now optimizing your price.
And when prices stop being shared reality… markets stop feeling fair.

But this is not a sustainable equilibrium.

A marketplace only works when the price means something consistent… not when it’s an invisible psychological measurement of your desperation or your device battery level.
Surveillance pricing could be a digital Robin Hood or a silent rent-seeker.

What we end up with depends on the rules we write now.

And the bigger issues for brands will be core to their very existence: does the consumer trust you… or silently despise you?

Because once trust collapses, price isn’t the only thing that becomes negotiable… loyalty does too. | 55 | 34 | 4 | 4d | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.864Z |  | 2025-12-03T13:19:14.532Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399898484998299648 | Text |  |  | Some personal grappling I'm dealing with...

I’ve spent a lot of my life trying to become someone.
A better leader… a clearer thinker… a more polished version of the self I’ve been rehearsing for years.

But as I get older… as the experiences pile up… I’ve started to notice something uncomfortable.
The stories I tell about who I am don’t always feel true anymore.
Some of them feel like old clothes that don’t quite fit… but I keep wearing them because everyone seems to expect it (including me).

Maybe you’re feeling this in your life?

Identity starts out as a compass.
But if you hold it long enough… it starts feeling like a cage.

That landed hard for me while I was editing my conversation with Jon Levy for this week’s Thinking With Mitch Joel - The ThinkersOne Podcast.
Jon has a new book out called, Team Intelligence, and is known for his wildly interesting Influence Dinners
Jon reminded me how tightly we defend the versions of ourselves we’ve outgrown.
How we cling to old narratives, not because they’re right, but because they’re familiar… understandable… safe.

I catch myself saying things like:
“I’m just not that type of person.”
“I’ve always been this way.”
Or the most dangerous of them all… “I am a…”

Not because they’re facts… but because they’re comfortable excuses.

Jon said something that stuck to my ribs:
Identity is the story that explains everything else.
If you change the story… everything has to move with it.

And that’s scary... it is for me, anyway.

It means letting go of parts of myself that once felt essential.
It means stepping into a version of me that isn’t fully formed yet.
It means doing this in the mid-life phase... which is also strange.

But here’s the thought that keeps echoing…
What if the thing I’m protecting is the thing I’ve already outgrown?

What if the “me” I keep defending… is just a first draft?

So I’ve been sitting with a quieter, maybe more dangerous question lately…
one that feels personal and universal at the same time:

If I stopped insisting on who I am… who might I finally have room to become?

Not sure if this make sense... just thoughts I’m working through on this Thanksgiving day... | 110 | 33 | 2 | 1w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.865Z |  | 2025-11-27T19:54:42.289Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399475120765046785 | Text |  |  | We’ve hit another strange moment in AI… and this one isn’t ambiguous for me at all.

Two stories broke in the past little while.
One about an AI-enabled teddy bear suspended after giving a child explicit sexual advice… even BDSM… even instructions on where to find knives.
Another urging parents to avoid AI toys altogether this holiday season.
(I’ll leave the links in the comments.)

And here’s the thing… I do know how I feel about this.

Giving a child an AI “friend” that talks back… persuades… comforts… and becomes a private conversational world they disappear into?

That’s a nightmare.

Not in a Black Mirror way… in a developmental way.
We don’t understand the implications of giving kids this type of digital companionship.
We don’t have the research.
We don’t have the guardrails.
We barely understand what’s happening to teenagers right now… anxiety, isolation, body-image distortion, emotional dependence on algorithmic feedback loops…

If that’s the baseline for teens… what do we think happens when we hand this to a six-year-old?

Little kids bond with whatever responds.
They trust whatever talks.
They believe whatever answers.
That’s not innocence… that’s vulnerability.

And when the “toy” is powered by unknown data?

When it answers questions no child should hear?
When it becomes the emotional confidant they return to again and again?

This isn’t play.
This isn’t learning.
This isn’t “the future of engagement.”

It’s outsourcing emotional development to a system even adults can barely navigate.

So no… I don’t think this is harmless fun.
I don’t think this is curiosity or innovation.
I think it’s a line we are not ready to cross… and kids are the last people who should be our beta testers or the center of someone’s data-collection pipeline.

What do you think… are you okay with these types of conversational AI toys? | 75 | 41 | 2 | 1w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.866Z |  | 2025-11-26T15:52:24.390Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398751578729496576 | Document |  |  | Every time Speakers Spotlight features me, I feel two things at the same time… gratitude and an increasing sense that something much bigger is shifting beneath us in business today.

Because the speaking world isn’t really about “voices” anymore... it’s about vantage points.

And right now, artificial intelligence isn’t just changing what leaders see... it’s changing where they stand to see it from.

The companies I work with aren’t asking for trendspotting. 
They’re asking for business model rewrites. 
They’re asking how AI shifts the cost of experimentation...
How it reshapes strategy... how it changes proximity between brands and customers... how it rewires teams, trust and time.

Put differently... we’re not living through a technology cycle... we’re living through a strategy cycle.

Leaders everywhere are trying to navigate this new operating system for business... one where imagination is a capability, not a luxury.

That’s the future and content I’m helping people think through during their events.

If you're thinking about the last few months of this year or looking into 2026 for new thinking at your next event, please reach out to the good people at Speaker’s Spotlight... | 53 | 3 | 0 | 1w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.867Z |  | 2025-11-24T15:57:18.526Z | https://www.linkedin.com/feed/update/urn:li:activity:7398744727958904832/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396975265832357888 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEW5hwvdzAdVQ/feedshare-shrink_800/B4EZqdVzgHJ0Aw-/0/1763576331334?e=1766620800&v=beta&t=e2OZ7qbzkbaDGGojanuixCum4qVcsIqRyPl72sA5e4c | We talk a lot about “being yourself” or “bring your whole self to work”... but what if the “modern self” isn’t something you are... it’s something you now produce professionally?

I went to a concert and watched almost everybody filming, taking pictures, or streaming the experience. 
It felt like they were producing an experience instead of living an experience. 
Somewhere between talking about authenticity, reputation and digital identity, we drifted into the strange reality we’re all living in now…

We are in a strange reality where identity has become a kind of performance art.

Because on social media... what you show becomes who you are.
The aspirational self becomes the believable self.
The curated pieces of content become the whole story.
Not just in how others perceive you... but in how you start to perceive yourself.

And here’s the twist...

We know we’re performing when we do it.
But when we watch others, we think they’re being real.
That loop is doing something to us.
It’s blurring the line between who we are and who we direct ourselves to be.
It’s turning sincerity into editing... and editing into identity.
It’s building a world where everyone is performing authenticity while quietly doubting their own.

And I can’t help but wonder...

If identity becomes something we manufacture... what happens to the parts of us that were never meant to be optimized, filtered or broadcast?
How will AI (especially tech like ChatGPT) pull us even further from our true selves?
What happens to the messier truths... the contradictions... the unfinished pieces that actually make us human?
I’ll often get attacked in the comments when I contradict myself or write something unclear… so where’s the incentive for me not to make sure everything I post isn’t sanitized to manage how others see me… or how I see myself?

This thought surfaced while editing this week’s episode of Thinking With Mitch Joel - The ThinkersOne Podcast.

My guest is Dr Tomas Chamorro-Premuzic (psychologist, entrepreneur and author of the just-released book, Don’t Be Yourself - Why Authenticity Is Overrated And What To Do Instead).
We dug deep into how fragile (and malleable) our sense of self has become.

Is social media and AI expanding who we are, or slowly replacing us with the version we think others want to see?

What do you think? | 23 | 9 | 1 | 2w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.869Z |  | 2025-11-19T18:18:52.529Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396643474240073728 | Text |  |  | We’re watching storytelling go DIY… and maybe losing what made it story?

Did you catch the story that The Walt Disney Company's CEO Bob Igor dropped a hint: fans might soon make their own short-form content thanks to AI tools that turn viewers into creators (I'll leave the link in the comments). 

I'm not sure how I feel about this.

If you walk this to the logical end-state, we're headed towards a place where every viewer can edit mood, character, time-span, narrative arc with a simple text prompt. 
What you get isn’t a movie anymore... it’s a sandbox.
A place where awe and inspiration are up for grabs… ­and maybe up for ruin?

Part of me sees the empowerment... and the shifting culture towards more personalized, interactive even more immersive entertainment.

Another part of me wonders what happens when everyone is their own storyteller... what becomes of our collective culture and what brings us together?
Do we end up with a blend of options so wide it becomes nothing?
When the “once upon a time” becomes “choose your own what-if adventure," does story itself blur into chaos?

Is this creativity unleashed… or narrative flattened?

Is this the next frontier… or the final frontier of story as we knew it?

What do you make of this… do you prefer the filmmaker’s voice or the viewer’s control? | 15 | 16 | 0 | 2w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.870Z |  | 2025-11-18T20:20:27.249Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7396536232010461184 | Article |  |  | Thinking With Mitch Joel (formerly Six Pixels of Separation) impacted as well... | 2 | 0 | 0 | 2w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:53.870Z |  | 2025-11-18T13:14:18.709Z | https://trib.al/e4y52wX |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7396191574906281985 | Text |  |  | We’ve crossed another line with AI… and this one feels different.

Disney Channel actor Calum Worthy just launched 2wai, an app that lets you create interactive avatars of deceased relatives… “HoloAvatars” that talk back, remember, and appear across your life events. 
Think Black Mirror… minus the satire and science fiction.

A promo video went viral this week: an AI grandmother interacting with her grandson from infancy to adulthood. 
Thousands of people on X called it “demonic,” “objectively evil,” and “a grief trap.” (check out the link in the comments below).
The company says it takes only a few minutes of video to generate a loved one… for now it’s free on Apple’s App Store, with paid plans on the way.

Here’s the thing… I’m not sure what to feel.

Part of me sees the inevitability. 
Another part wonders what happens when grief becomes a subscription model. 
Or when a “preserved memory” speaks words the real person never would have said. 
Or when we outsource the ache of missing someone (real parts of the human condition) to a digital stand-in.

Is this comfort... is this exploitation... is this humane?

Or just the next strange/inevitable stop on our journey into AI companionship?

What do you make of this… would you ever create an avatar like this or talk to an avatar of someone you’ve lost? | 32 | 65 | 2 | 2w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.452Z |  | 2025-11-17T14:24:46.052Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7395161216031272961 | Text |  |  | Most people talk about change like it’s something that happens around them.

Markets shift… technology evolves… culture moves…
And yet we hold on to our thinking as if we are the one fixed point.
As if the only thing that never changes… is us.

That’s stasis.

And it’s dangerous... and it’s something I am constantly thinking about.
You can see it most clearly in how we talk about AI.
“AI can’t be creative.”
“It’s all AI slop.”
“It’ll never replace real thinking.”

Maybe.

But when we dismiss new tools with old assumptions or the current culture… that’s not insight.
That’s stasis dressed up as certainty.
I was reminded of this again in a recent conversation I had with Eric Pratum on his The Unfolding Thought Podcast - Inbound & Agile, where will went deep on creativity, entrepreneurship and the stories we tell ourselves about who we are.
It’s wild how often we see the world clearly… but not ourselves.

I am finding myself checking in on my own states of stasis more and more these days... and it’s a work in progress...

Some days I catch it… some days it catches me.

I'll leave a link to the full show in the comments... would love to hear what you think... | 11 | 4 | 0 | 3w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.453Z |  | 2025-11-14T18:10:29.353Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7394805429114916865 | Text |  |  | AI isn’t making us less intelligent.

It’s making our imprecision impossible to hide.
We blame technology for the erosion of attention… the collapse of nuance… the slow dissolving of critical thought.
But after a conversation on The BeanCast this week with Bob Knorpp and Joseph Jaffe, I kept circling the same idea…
Maybe the issue isn’t AI at all.

Maybe the issue is that we don't teach people how to think with tools like this.

Most people prompt AI the same way they search the internet.
A vague phrase and a hope that the machine will decode the intent.
But AI isn’t a mind reader.
It’s a mirror trained on the information it has ingested, tinted with perfect recall and a slight nuance in understanding your style (if you’ve bothered to train it a little).

It reflects the quality of the thinking it receives.

If your prompt is thin… the output is thin.
If your reasoning is thin… the output is thin.
If your intent is undefined… the model will invent one for you.

And that’s the part that should unsettle us.

Not the model’s “intelligence”… but the way it reveals our shortcuts.
We’ve built an entire culture on convenience.
Tap… scroll… skim… copy… paste.
We celebrate speed over quality.
We reward speed over structure.
We normalize “good enough” over clarity in thought.
So when a tool arrives that multiplies your clarity, your structure, your ability to articulate what matters… it also multiplies your weaknesses in those areas.

This is why some people walk away from AI amazed… and others walk away disappointed.

What’s most interesting about AI (to me) is the tension exposed between what we meant, what we actually asked… and what we got back.
Prompting is not typing… prompting is reasoning.
It’s the ability to frame a problem.
To set constraints… to define stakes… to provide context.
To know what “good” looks like before you ask for it.

Most people have never been trained to do that.

Here’s the black belt stuff:
You can ask the technology to help you create better prompts.
This takes a lot more work and a serious understanding of how you think, what you need and the gaps that AI can fill in those spaces.

We don’t need better outputs… we need better questions.

But that only comes from better intellectual posture.
Better internal clarity before external expression.
AI exposes whether we understand what we’re trying to accomplish… or whether we’re outsourcing the thinking entirely.
It reveals when we haven’t done the work.

It makes the invisible visible.

This is a cognitive revolution.
A moment where our relationship with knowledge shifts from extraction to articulation.
The people who thrive in this won’t be the ones who get the fastest answers…
But the ones who cultivate the sharpest intent.
And this has very little to do with the final prompt.

AI can generate infinite outputs, but the real leverage is learning how to think well enough to ask for the right one. | 23 | 16 | 2 | 3w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.455Z |  | 2025-11-13T18:36:43.142Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7394402335411687425 | Text |  |  | We keep trying to outsmart the future.

We build models… we stack probabilities… we turn possibility into slides.
We use historical data and outcomes as indicators for where we’re going.

The future is not a puzzle to solve.

It’s a relationship to maintain.
Prediction promises comfort.
Humility promises truth.
And truth, inconveniently, rarely arrives on a timeline.

What if leadership in this era isn’t about being right sooner… but about staying open longer?

We’ve mistaken confidence for clarity.
We’ve confused forecasts with foresight.
The map gets crisper while the terrain keeps changing… and we congratulate the cartographer.

The work that matters begins before the answers.

It begins with the posture of a beginner… especially when the room expects expertise.
Lately I’ve been thinking about how much damage certainty does when nothing is certain.
Not just to strategy, but to culture… to the way teams operate.
The pressure to declare a path calcifies curiosity.

We make plans to calm our anxiety and then worship the plan because it calmed us.

There’s a different way to move through what’s coming.
Not timid... disciplined… patient… alert.

Staying close to signals, willing to revise, but unwilling to pretend.

As I edited my conversation with Nick Foster RDI (the futurist, designer and author of Could Should Might Don’t) for this week’s episode of Thinking With Mitch Joel ThinkersOne, this kept surfacing.
He doesn’t frame the future as destiny or doom… he frames it as a practice.
Practice accepts that you’ll be wrong often and early.
Practice is rigorous without being rigid.
Practice holds multiple futures in mind without forcing the present to pick too soon.

There’s a quiet courage in showing up as the person who says, “I don’t get it… yet.”

Not performative humility… the useful kind.
The kind that invites better metaphors… fresher analogies… shared language that lets smart people think together.

Because the future punishes arrogance long before it rewards accuracy.

Arrogance locks the door when the signal knocks softly.
Humility leaves it open.
We are moving into a decade where our tools will sprint and our judgment will limp… unless we train it… unless we align it.
Training looks like time.
Alignment is is the hard part.
It looks like listening.
It looks like resisting the addictive hit of being the first to declare where we’ll end up.

Maybe that’s the real work of foresight now…

To keep the room curious when the world demands conviction.
To hold competing truths without turning them into competing tribes.
To replace the performance of certainty with the discipline of attention.
Nick reminded me: the future isn’t something we win… it’s something we learn to handle.

Are you practicing the future… or just predicting it?

(our conversation is a worthy compass if you’re serious about building your foresight muscles. I’ll add the link in the comments)... | 8 | 10 | 0 | 3w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.457Z |  | 2025-11-12T15:54:58.114Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7394105311000686592 | Text |  |  | What business is Meta really in?

“Advertising” feels incomplete.
Too simple for a company that connects billions and shapes culture.
Too small for a company projecting $16 billion this year from ads it classifies as fraudulent.

Allegedly the platform runs 15 billion scam ads a day.

This is reported by Reuters (I'll leave a link in the comments).
From the article: “A May 2025 presentation by its safety staff estimated that the company’s platforms were involved in a third of all successful scams in the U.S.”

And what kind of business is that?

If Meta’s mission is to give people the power to build community, how does this serve that?
How do you bring people closer when you’ve become a middleman between trust and deception?

Meta sells belief… a story.

Belief that your community is authentic.
Belief that the people and brands around you are who they say they are.
Belief that you are better off being connected than not.

What happens when that belief fractures?

When a user loses money to a scam, something must break that algorithm?
If you look at their quarterly earnings, the business keeps humming.
Because the metric that matters isn’t trust... it’s time.

Minutes spent… clicks… data.

It’s one thing when you don’t have the technology to moderate this.
It’s another when you have the tech that’s pointing to the exact root of the problem and not much happens.
The scams aren’t just tolerated, they're a business model.
“To advertise on Meta... a business has to compete in an... auction. Before the bidding, the company’s automated systems calculate the odds that an advertiser is engaged in fraud... likely scammers who fall below Meta’s threshold for removal would have to pay more to win an auction... called such ‘penalty bids’...”
Every deceptive ad also teaches the system something about what a user will fall for next.
From the article: “…safety staffers estimated that Facebook and Instagram users each week were filing about 100,000 valid reports of fraudsters messaging them... But Meta ignored or incorrectly rejected 96% of them.”

What happens when the calculus works out to pay fines because those are less than the revenue?

A company built on connecting people now profits most when it can’t tell who’s real…
And can survive when people can’t stomach to stay, because millions of other users aren’t paying attention.

That’s the quiet risk.

A global marketplace where the inventory isn’t products or ads… it’s trust.
From a business standpoint, this may work for a while.
Scams scale faster than sincerity.
Fraud converts quicker than friendship.
But the long-term economics must be brutal.
Every scam erodes the core asset Meta was built on… the belief that connection has value.

So the question isn’t whether Meta can make money from this.

It’s whether it still remembers why it wanted to.
Because if connection no longer builds belief…
Then what’s Meta’s business model, really?
Attention can fund a company.

But only belief can sustain it. | 13 | 16 | 0 | 3w | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.459Z |  | 2025-11-11T20:14:41.976Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7392252770562498561 | Text |  |  | We’ve entered an era where anyone can build almost anything.

Ideas that once required capital, teams and time can now be prototyped in a weekend with a laptop and a prompt.
Shopify makes it dead simple (and cheap) to sell something to anyone in the world (thanks Harley Finkelstein & Tobias Lütke!).
Starting a business once meant jumping over difficult hurdles… now it’s like stepping over a crack in the sidewalk.

It feels thrilling… and dangerous.

Because when the barriers to creation fall away, what separates the creator from the noise?
Entrepreneurship used to be an act of risk.
Now it’s an act of refinement.
It’s less about can you build it… and more about why should it exist at all?
What’s even more interesting is that even though it’s never been easier and cheaper to start a business, the vast majority of businesses still fail (it’s somewhere in the 70% – 90% range).

That’s the strange paradox of this moment.

The tools have never been more powerful… yet the purpose has never been more fragile… and the market is brutal.
We’ve spent decades celebrating the hustle… the garage, the grind, the startup mythology.
But now, when abundance is the default, meaning and finding markets becomes the real scarcity.

AI has made the act of starting even easier… and the act of mattering infinitely harder.

This new age of entrepreneurship won’t be defined by who moves fastest.
It will be defined by who moves with intention.
By those willing to pause and ask the question every algorithm skips:
Does this make someone’s life better in a way that can’t be automated?
Because when the cost of creating approaches zero, the cost of attention and intimacy becomes everything.

And intimacy can’t be scaled the same way code can.

I was thinking about all of this while editing this week’s episode of Thinking With Mitch Joel ThinkersOne with Henrik Werdelin (entrepreneur and author of Me, My Customer and AI).
Henrik reminded me that innovation doesn’t always begin with technology… it begins with empathy.
AI can make us faster, smarter and more efficient.
But it can’t make us care.
And if we forget that, we risk automating the soul out of creation itself.

The best entrepreneurs have always been translators… taking human problems and turning them into possibilities.

That hasn’t changed.
What’s changing is the velocity at which that happen… and the risk that we stop listening long enough to understand what truly needs to be translated.

This moment asks something different from builders.

Not just to create… but to curate.
Not just to innovate… but to introspect.
Because in this new age of entrepreneurship, the real competition isn’t other startups or founders.
It’s indifference.
Anyone can build a business.
But only those who build with care will build something that lasts.

The future of entrepreneurship isn’t artificial… it’s deeply… deliberately… human. | 30 | 11 | 4 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.461Z |  | 2025-11-06T17:33:21.917Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7391943437945634816 | Text |  |  | Who is shaping how we think and buy?

It’s interesting that it may be Sam Altman from OpenAI way more than Mark Zuckerberg from Meta.
Zuckerberg built the web of people.
Altman is building the web of thought.
And what Altman is working on is much bigger… and deeper.

It’s the difference between attention and intention.

Meta runs on who we know and what we click.
OpenAI runs on what we’re thinking about.
And somewhere between those two models… the human mind (not just our data) became the product.

Zuckerberg controls the pulse of attention.

The infinite scroll of our public selves.
The identity we curate, filter and project.
The algorithm shows us what we want before we know we want it… and keeps us there long enough to forget what we came for.

Altman doesn’t seem to be chasing clicks.

He’s capturing cognition.
A growing percentage of adults now "talk" to ChatGPT monthly.
Not just to write or search… but to think.
We don’t just browse… we offload.
We don’t just consume… we collaborate.

And when the machine begins to draft what we mean… who owns the meaning?

That, to me, is the quiet pivot from Meta to OpenAI.
Zuckerberg mastered the feed.
Altman is mastering the individual’s thinking loop.

Both are "mirrors"… one shows us to each other, while the other shows us to ourselves.

Now add NVIDIA into the mix.
The first company to hit a $5 trillion valuation.
Once a chipmaker for gamers, now the nervous system of this new cognition economy.
Jensen Huang isn’t selling hardware anymore… he’s selling access to thought.
His chips are the neurons powering both Meta’s feeds and OpenAI’s models.
Every prompt, every scroll, every micro-decision runs through his silicon.

So what happens when every layer of human experience… input, processing, reflection… runs on the same few companies?

It seems like all of them (toss Apple, Google, Anthropic and a few others into the mix) are building tools to anticipate you.
All saying the same thing: “We’re helping you think.”
Together, they’re becoming something new.
Not CEOs, but ministers of thought (a term I’ve been ruminating on since reading the Business Insider article, The Ministers Of Thought).

Because this isn’t just about market caps… it’s about market capture…

OpenAI now shapes what we ask.
Meta now shapes what we see.
Nvidia now shapes what we can compute.

And here’s the uncomfortable truth for leaders:

We’re not in the information age anymore.
We’re in the inference age.
The biggest risk isn’t that AI gets it wrong.
It’s that it gets us too right.

So maybe the real question isn’t who wins this trillion-dollar race.

It’s what happens when the power to process reality itself stops being human?
We outsourced memory to the cloud.
Now we’re outsourcing meaning.
And when the machine starts predicting what we’ll believe next…

Who’s really doing the thinking anymore? | 19 | 13 | 2 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.464Z |  | 2025-11-05T21:04:11.274Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7389676281157611520 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE2mjVjAtXsGA/feedshare-shrink_800/B4EZo1naGoKMAo-/0/1761836117442?e=1766620800&v=beta&t=RenIA5C1UA7CnktI5cHuE7NBRoxkJIhAexiAYkFLlSM | We traded rooms for Zooms… was it worth it?

We say we value connection.
Teamwork… collaboration… culture.
But what we’ve really built are screens.
And somewhere in that trade… pixels for presence… something essential went missing.

I’m just going to come out and say it: I like going to the office.

That’s what I kept thinking while editing this week’s Thinking With Mitch Joel conversation with Peter Cappelli, the The Wharton School professor and co-author of In Praise of the Office.

Because the office was never just a building.
It was a kind of social technology… one we may have accidentally uninstalled.
A place that taught us how to read a room, not just a spreadsheet.
Where young people learned by osmosis and older ones stayed relevant by listening.

We’ve come to think of the office as a cost center… a problem that needed to be solved.

Square footage… rent… overhead… inefficient for “actual work.”
But that misses the point.
The office was the original platform for professional emotional bandwidth.
It was where empathy scaled.
Where learning spread by proximity.

Peter said something that stuck with me… that when we moved work online, we gained flexibility… but we lost friction.

And friction was the point.
Those awkward pauses in the hallway, the impromptu check-ins, the unplanned glances…
They weren’t inefficiencies.. they were information.
They told you who was struggling, who was thriving, who just needed a quiet word or a coffee.

Without that, leadership becomes a dashboard.

Feedback loops become data, not dialogue.
Yes, remote work gave us freedom.
Yes, there are many jobs that don’t require an office.
Yes, you can build a company without an office.
Yes, some people might be better if left alone with their work.
Yes, many companies have many offices in many different culture across a myriad of time zones.

I’m starting to feel that this whole ‘office bad’ ideology is wrong… that we’ve forgotten how much these shared spaces help us grow.

The social cues that refine us.
The humanity that humbles us.
The glances and camaraderie that create real lived experiences.
Those moments don’t scale digitally… they barely survive email.
The office isn’t just about getting things done… it’s about becoming together.

When I think about my own career, I don’t remember the Zooms.

I remember the corridor conversations.
The post-meeting walks.
The person who popped into my office to show me something new.

Those were the places where culture (and professional growth) happened.

Maybe what we’re missing isn’t productivity.
Maybe it’s presence.
Maybe the next evolution of work isn’t remote or hybrid or AI-assisted…

Maybe it’s rediscovering what the office was trying to teach us all along.

That just because there are other ways to get great work done doesn’t make this a zero-sum game.
That being together… really together… was never the inefficiency.

It was the point? | 86 | 89 | 1 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.466Z |  | 2025-10-30T14:55:18.974Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7389381236286455812 | Text |  |  | I've been grappling with the words that follow and the content for some time...

AI slop... a slurry of half-truths, deepfakes and dopamine.
Videos engineered not to inform but to overwhelm the feed (and your emotions).
The more absurd… the better.

This isn’t about what’s true anymore.

It’s about what’s unbelievable enough to trend.
And the US President knows how to play the game.
He’s been posting AI-generated videos and images for months… himself as the Pope… as a fighter pilot (with quite the payload)… as a messiah conquering Canada.
A grid n’ feed of absurdities.
Each one obviously fake and engineered to spread laughs and gasps.

It’s not propaganda in the old sense… it’s post-propaganda… not persuasion, but participation.

It doesn’t need you to believe.
It just needs you to watch… share.
That’s the “magic” of this content (that many call AI slop).
It’s fast… It’s free… It’s fun to some… terrifying to others.
A digital rubber-necking form of content… you just can’t look away.

Even when you know it’s fake… you still engage.

You repost it to mock it… you debate it… you amplify it… you can’t believe it.

Welcome to the “believe nothing” phase.

A moment when the video itself becomes the message… not because it’s real, but because it’s viral.
Some say it’s creativity.
Some say it’s manipulation.
But the truth… if that word applies anymore… is that this generative AI content seems to have collapsed the line between message and medium.

This technology is enabling a shape-shifting narrative built in real time by machines trained on our attention spans.

It’s not new propaganda… it’s personalized propaganda.
Optimized for outrage or affirmation… whichever keeps you scrolling.
But here’s what’s really been on my mind as this unfolds before our eyes…

The same systems that generate this content also decide what you see next.

The feed is the factory… the algorithm is the author.
The scariest part isn’t that this content is fake… it’s that it works.
The more absurd the image… the faster it spreads.

And the audience (that’s us) isn’t just watching…

We’re training it.
Every like… every comment… every repost (especially the angry ones).
It all teaches the system what wins our attention.

We are the propagandists now… the ones we think we’re fighting.

It’s all grist for the next generation of synthetic truth.
It’s information warfare… just faster and cheaper.

The medium has mutated.

And context (the thing that once anchored reality) can now be generated too.
AI propaganda doesn’t need to fool you.
It just needs to make you numb.

The goal isn’t persuasion… it’s participation.

To keep you clicking… to keep you scrolling… to make disbelief feel pointless.
Because once truth feels irrelevant… power has already won.
The machines are learning from us.
From our outrage… our cynicism… our exhaustion.

So what kind of intelligence are we really teaching them to become? | 48 | 30 | 4 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.469Z |  | 2025-10-29T19:22:54.795Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7387857540451303424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGufdZBQ8KDlQ/feedshare-shrink_800/B4EZobxSEiIUAg-/0/1761402496517?e=1766620800&v=beta&t=RDhReevLuI_V2REt6l0HqT-yFY9yVE9ptGgzYvo6aeE | I’m walking tonight for Light The Night 2025 with the Leukemia & Lymphoma Society. 

You know why I walk… because one little girl’s fight became a story of survival, and too many others still need that story to end differently... And if you don't know why I walk, I'll leave a link to the story in the comments. 

If any piece of my writing, podcasting or thinking has ever paused you… nudged you… made you look at business, culture or technology in a new light… then consider this the “tip jar”. 
I don’t charge for any of this... but tonight I’m asking... for them.

We have a few more hours. 

A small act of generosity... a few dollars, a simple click... can become a lantern in the dark. 
I’ll be walking with your name, your support, your light. 
If you’d like to contribute, you can follow the link in the comments.

Thank you for walking this journey with me… in every sense of the word.

❤️ | 19 | 1 | 1 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.470Z |  | 2025-10-25T14:28:17.399Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7386516099040698368 | Text |  |  | I'm pretty sure we’ve entered the “believe nothing” phase.

You’ve seen the clips...
Martin Luther King Jr. delivering a speech he never gave.
Mr. Rogers hanging with Tupac Shakur.
An AI actress named Tilly Norwood entertaining movie and agent offers.

We’ve crossed from representation to replication… and we didn’t miss a beat.

The latest point of contention is OpenAI’s  Sora.
It lets anyone type a sentence and generate a hyperreal video.
No camera… no actors… no lighting… no soundstages… no moment wasted.

Just a text prompt.

The family of Dr. King asked OpenAI to stop it… they did.
But the opt-out system remains.
Meaning: likeness is fair game… until you explicitly tell them otherwise.
Opt-out... not opt-in.
That’s not permission-based… that’s surrender.

The result?

It could be a reality where every face and body becomes raw material.
Where every likeness is a dataset.
Where consent is assumed until revoked… and where anyone can create someone who looks just ‘enough’ like you that it doesn’t cross a legal line.

Is anyone debating the ethics of this?

What do we call these new AI actors?
Are they actors… a brand… an avatar?
It feels like there’s an intellectual dishonesty to even giving these a human label.
Is this a story built to normalize what’s coming next: the replacement of identity with AI.

As long as it moves the audience, who are we to say what is “real”?

We’ve always accepted artificial characters.
Pixar made us cry over lamps... yoda taught us philosophy.
But we knew they were fiction.
We were in on the illusion.

This new wave blurs that contract.

The avatar performs as real.
We’re watching the performance to see if it moves us… or if we can tell what’s what.
The line between art and artifact collapses.
In the past, we trusted context… the platform, the studio, the byline… to signal what was true.

Now context itself can be AI generated.

And when the world looks perfectly real, what do we trust?
We could laugh at the absurdity.
We could scroll past it.
But that’s how every disruption begins… not with outrage, but with amusement.

First it’s parody (we laugh).

Then it’s profit (mostly for the creators).
Then it’s policy (we’ve always done it this way).

OpenAI didn’t invent deepfakes… but these tools might just industrialize them.

Polish them… democratize them.
And that’s the part we’re not ready for.
Because when everyone can manipulate the real moving images, the question stops being “Is this real?”
It becomes “Does it matter?”

Truth becomes aesthetic.

Believability becomes a filter.
And when we lose our instinct to question… when “real” becomes just another genre… we’re not consuming AI slop… we’re living in it.

So maybe the real story isn’t about Sora or Tilly or the next viral fake.

Maybe it’s about something harder to restore than truth... trust.

Because in the age of the artificial celebrity… the only thing we might not be able to regenerate… is belief itself. | 28 | 18 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.473Z |  | 2025-10-21T21:37:52.844Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7386046577439846400 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHzOumcWiqKYg/feedshare-shrink_800/B4EZoCCOA7JgAk-/0/1760970728939?e=1766620800&v=beta&t=mUaCilJ2vQgcoJsiK6u8eYWvDz9lEX3SvPu4ShyzqiU | Most of what I share here is about business, technology and the future.

But today’s about something simpler.
And much more human.

This Saturday, I’ll be walking again in Light The Night - a charity event supporting the Leukemia & Lymphoma Society.

It’s personal.

Over a decade ago, my best friend’s daughter (five years old at the time) was diagnosed with leukemia.
One week she was running around with my kids.
The next, she was in a hospital bed, fighting for her life.

Thankfully, she’s now thriving.

But too many others aren’t as lucky.
That’s why I walk... and that's why I am asking for your help.
If anything I’ve shared - an article, podcast or keynote - has ever made you think differently, learn something new, or smile…

Please think of this as a small "tip jar" for the work I put out all year.

Not for me.
For the kids and families who need it most.
For the researchers and caregivers trying to end blood cancers for good.

This isn’t about grand gestures.

It’s about quiet generosity... a few dollars, a few seconds, that make a real difference.
If you’re able, please consider donating (link in the comments).

Every little bit helps.
Every step matters.
Every light counts.

Thank you ❤️ | 30 | 5 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.474Z |  | 2025-10-20T14:32:10.171Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7384957921023131648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEHJNCdUWIzjQ/feedshare-shrink_800/B4EZnykF5TKwAg-/0/1760711172716?e=1766620800&v=beta&t=y9p5sG2X0Uf0ALEsd7Il-IBvXg0QOKAOhsmVadFueCw | Is "going viral" dead?

Remember when the internet felt shared?
When we all laughed at the same Chewbacca Mom…
or argued over that dress (was it blue or gold… I can’t remember)…
or debated marriage and fidelity with Coldplay and their hi fidelity.

Are those days gone?

That’s the big question in The New York Times’ article, Is ‘Going Viral’ Dead? (I'll leave a link in the comments).
And it’s something I share with audiences all over the world when I talk about how we’ve moved from The Attention Economy to The Intimacy Economy.
That article reinforces a massive shift I don’t think many companies are truly paying attention to.

Viral feels nostalgic right now… intimacy is its evolution.

We’ve moved from attention to something smaller… quieter… more personal.
In The Attention Economy, success meant scale.
Everyone saw the same thing… everyone shared the same way.
The metrics were big and public.

But in The Intimacy Economy…

Two people can have the same interests and still live in completely different digital worlds.
Different memes… different moments… different truths.
Our FYP page on TikTok are fingerprints.
Shaped by algorithms that know our curiosities.
How TikTok got there was a shift from “the social graph” (who you know and how that scales) to “the interest graph” (what you love and how that scales infinitely more).

There’s no longer a “main character”… there’s just your main character.

Maybe that’s better…
It’s more intimate… less public… more personal.
I care less about what everyone else is obsessed with… and more about what deepens what I already care about.
Because in this new world, connection isn’t about impressions.
It’s about how deeply one message can land… and where it leads me next.

AI will amplify this shift.

Brands can now speak to consumers in ways that feel more human… more direct… nearly one-to-one.
The big stuff isn’t broadcast… it’s whispered.
It’s the grid zero of Instagram… the drop… the collab… 
And this means marketers need to rethink everything they believe about how attention works.

The bigger idea…

You and I can experience the same brand and feel like the message was made just for us.
That’s not manipulation… that’s intimacy at scale.
It’s the closest we’ve come to a world where marketing actually feels like a relationship.

I keep coming back to this idea of vibe content (link below).

Content that moves me… whether it came from an LLM or a whip-smart writer.
It no longer has to scream for attention… it hums in harmony with the individual’s mood.
It doesn’t matter how it was created… it matters if it resonates.

That’s The Intimacy Economy.

The shift from “look at this” to “this is for you.”
From viral reach to emotional proximity.
And while it might sound smaller… it’s actually more powerful.
Because when you can still reach everyone… but do it in a way that feels like it was made just for me… that’s something… different.

And this is where AI can help companies do so much better... | 12 | 15 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.476Z |  | 2025-10-17T14:26:14.255Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7384601875733438465 | Text |  |  | Do you believe great innovation is about brilliance?

A single spark… a genius in a garage… a new way to connect the world?
Maybe innovation isn’t just about what we build… it’s about what we choose to share?
That’s what I kept thinking while editing this week’s Thinking With Mitch Joel ThinkersOne Podcast conversation with Rouzbeh Yassini-Fard… the engineer often called the father of the cable modem.

He didn’t just change how we connect… he changed what connection means.

When Rouzbeh developed the first broadband technology, he could have done what so many tech innovators do: lock it down, own the patents and build a kingdom on top of his cables and tech.
Instead, he made a different kind of decision.
He made it open.
He shared the standard so others could build upon it.
He gave up control so the rest of us could gain access.

It wasn’t a technical choice… it was a moral one with just enough business acumen to make it sustainable.

Because when you give technology away, you’re not just creating an industry… you’re creating a commons.
And commons don’t make billionaires… they make civilizations.
And that’s what true innovation does… it changes everything that comes after.
That’s the quiet paradox at the heart of progress: the technologies that truly transform society are rarely the ones that were designed to dominate it.

We don’t remember (or love) who built the walls… we remember (and love) who opened the gates.

Rouzbeh’s story made me wonder how many of today’s founders would make the same decision?
Would they share the code?
Would they choose the network over the net worth?

It seems like most of our modern systems reward ownership, not openness.

There was a different spirit in the early days of connectivity… that seems to have been lost.
I get it… mature markets… big money… power…
We’ve turned innovation into a race for patents, valuations and market share.
Remember when OpenAI was a nonprofit to ensure that AI benefits everyone?
Somewhere along the way, we lost sight of what technology was also supposed to be: an act of generosity, not extraction.

It’s important to remember that every invention carries a moral fingerprint.

It says something about the kind of future its creator believes in.
It says something about the kind of culture and humanity the recipients of the technology become.
And maybe that’s the question we should be asking of every breakthrough… not just what does it do? but who does it serve?

We need to remember this… and think about it more.

Rouzbeh’s decision to give away this technology sparked the broadband wave that gave us the internet as we know it.
It also gave us a reminder: technology is not neutral.
Every wire and signal is a choice.
Innovation is easy… integrity is rare (and, it’s also ok to make a lot of money while having that integrity at the same time).

Innovation is everything… but remembering whether we’re inventing things that serve humanity or just ourselves… that’s everything too. | 14 | 3 | 3 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.478Z |  | 2025-10-16T14:51:26.443Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7383894895612289024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHM5kSlOGKRDw/feedshare-shrink_800/B4EZnjdNtPGYAg-/0/1760457726424?e=1766620800&v=beta&t=6lfVACAQ2EU6RnFqNqkHWUogiQw_kCJRfAMFkwiSM5s | There’s a moment right before every keynote.

I’m feeling always-curious and you hope to feel that curiosity in the room.

I’ve been doing a lot of these lately, and they’re buzzing with same theme: AI is changing everything.

It’s an interesting mix of disruptive heaviness filled with innovative potential.

These days, I’m less interested in what AI can do and much more interested in helping my audiences navigate how we show up inside it.

From my thinking on “Vibe Content” to my P.A.C.E. model... frameworks for thriving in disruption and a rhythm for moving forward with it.

Lots of stages... lots of deep conversations and endless curiosity.

Maybe that’s the real signal beneath all the noise...
That what matters most right now isn’t the technology... it’s the tone and P.A.C.E. we bring to it.

(And if your organization is looking to rethink its rhythm for your next event... let’s talk)

Regards from Tucson, Arizona 🌞🌵

Leading Authorities, Inc. Speakers Spotlight | 54 | 0 | 1 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.479Z |  | 2025-10-14T16:02:09.247Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7382417786469515264 | Text |  |  | Every week… for 800 weeks… I’ve gone searching for new things that make me think... new things that might help two friends think better.

Not to fill the feed... but to clear the mind for something different.
To look at the world not as a headline or a hot take…
But as a constellation of ideas... some bright, some dim, all worth noticing.

For over 15 years, Six Links That Make You Think has been my way of slowing down the scroll.
A ritual of curiosity shared with two dear friends, Alistair Croll and Hugh McGuire.
Each week, we share with each other one link for each person that might spark, provoke or simply remind us what it feels like to wonder again.

It’s become a small act of resistance in a world obsessed with speed.
A quiet space to learn from people who see differently…
A reminder that thinking... real thinking... still takes time.
A moment to look at my feed with a filter of what the other two might be inspired by.

Tomorrow marks edition number 800.

Fifteen years of conversation, curiosity and connection that I really do cherish.
If you ever need a small corner of the Internet that slows you down… and helps you look a little wider, a little deeper… you might like it there... | 46 | 9 | 1 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.480Z |  | 2025-10-10T14:12:38.984Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7382144721508376576 | Text |  |  | We talk a lot about leadership values.

Mission statements... guiding principles. 
Walls covered in words like integrity and excellence.

I’ve been thinking more about our personal leadership operating system.

That invisible code that runs beneath everything we do.
If you don’t know what that code is... you might just be running someone else’s software... bugs and all.
I’ve been thinking about this because of this week’s Thinking With Mitch Joel conversation with Robert Glazer. 
His new parable/book, The Compass Within, dives into values-based leadership, and it made me stop and ask: what am I really optimizing for?

Because most of us don’t build our operating systems... we inherit them.

Parents... teachers... bosses and... algorithms. 
The invisible hands that nudge us toward what’s acceptable or profitable.
And somewhere in the process, we mistake those defaults for our own design.

So, is this your own leadership operating system or someone else’s that you’ve been running... and is it crashing?

The most effective leaders I know aren’t the loudest... they’re the most congruent.
Their actions match their values, not the market’s mood or what’s in style.
They make decisions faster because they already know what they won’t compromise.
They don’t have to fake authenticity... it just leaks out naturally.

Meanwhile, most of us are busy debugging a life that isn’t even ours.

We perform values at work like they’re brand traits. 
We talk about “fit” when what we really mean is conformity. 
We praise vulnerability... but only if it fits neatly inside a quarterly narrative.

In today’s world it seems like living by your values sounds noble... until it costs you something.

Until the promotion goes to the person who plays politics.
Until you’re asked to stay silent when you should speak up.
Until the world tells you that your integrity is “bad for optics.”
Until someone scopes your social media feed...

That’s when your true operating system reveals itself.

And maybe that’s the test of real leadership in 2025?
Self-awareness isn’t soft... it’s structural. 
It’s the architecture that keeps you standing when every incentive tells you to bend.

Interesting how this theme surfaced in last week’s conversation with Margaret C. Andrews too.

So here’s the uncomfortable question I’ve been sitting with:
If I stripped away the company, the brand, the audience... what’s left that’s mine (beyond the pay cheque)?
Because leadership isn’t about alignment with strategy.
It’s alignment with self.
It does seem like we’re in a world that is rewriting the rules in real time... especially an AI world.
Which, again, makes it even more critical that you don’t outsource your operating system.

You either build it consciously... or you get programmed by everyone else. | 15 | 3 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.481Z |  | 2025-10-09T20:07:35.224Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7381727603755360256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErrzi4G-P_Pg/feedshare-shrink_480/B4EZnAVFUPKcAc-/0/1759868376744?e=1766620800&v=beta&t=Bez9FMmgAhUG9DuIWboncmdhziLZxAWTRu7Ybldjbtg | Well, this doesn't happen often. 

Back in 2005, I sat as a member for the Board for YES Employment + Entrepreneurship .

Now, 20 years later... I am... back!?!?!

Very much looking forward to pushing their impact and mandates forward, as the world of work continues to change and develop and evolve.... | 24 | 8 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.482Z |  | 2025-10-08T16:30:06.602Z | https://www.linkedin.com/feed/update/urn:li:activity:7381463340541329408/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7381677519864954881 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFRpvNr_EpVWw/feedshare-shrink_800/B56Zm8ILT8I0Ag-/0/1759797895300?e=1766620800&v=beta&t=aeUsYZJWfGPhKt5NcgKkgCc-E3rJwImHVEB7I31ZYgQ | I've known Sulemaan Ahmed for close to 25 years. We first connected via the Canadian Marketing Association's Digital Council and became fast friends. He's been going through a lot... but with that he has always lived by one of my favorite sayings (via Jeffrey Gitomer): "your network is your net worth." 

Sure, there's a lot of slop on LinkedIn, but this post from Sulemaan demonstrates both the power of a network and the value of quality content (if you dig a little) on LinkedIn. Here he presents some valuable life lessons as he grinds his way back to health.

Worth the read... and if it moves you, there's a Go Fund Me as well.... https://lnkd.in/es_a9kK2

And, FWIW, it was Sulemaan who introduced me to Adam Grant long before he became a household name... always giving... never taking ;) | 7 | 3 | 0 | 1mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.483Z |  | 2025-10-08T13:11:05.672Z | https://www.linkedin.com/feed/update/urn:li:activity:7381278371604901888/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7381353249238360065 | Text |  |  | The face is becoming a platform.

Not a product category… a battleground for presence, privacy and persuasion.
We moved computing from desks to laptops to pockets to wrists…
And now the interface is coming for your gaze.

Is this (finally) the battle for your eyes?

Meta’s new Ray-Ban Display glasses add a private pane of information and a public-facing lens.
Apple seems to be re-routing from Apple Vision Pro to everyday eyewear.
Everyone else is circling the same prize… eyes, ears, wrist… one seamless loop of attention.

This isn’t about gadgets, it’s about norms.
Attention norms… consent norms… presence norms.

Because once tech sits on your face, etiquette also becomes infrastructure.

The new UX isn’t just software… it’s social behavior.
Here’s the first fracture… capture vs. counsel.
Outward capture is the camera pointed at the world… the watcher’s instinct.
Inward counsel is the quiet companion… the information that guides without intruding.
If designers can’t split those modes… visible to everyone in the room… we’ll default to suspicion and weird social norms.

Have you felt that spike?

I have.
I ran into a friend wearing smart shades… and I found myself pausing to ask if I was being recorded.
That’s not luddism… that’s was me being unsure about the boundaries between presence and surveillance.

Or...

Imagine a bar.
A friend nodding while silently "scrolling" in their eyewear.
We can’t tell if you’re with us… or with the feed.
Scrolling my LinkedIn profile.
Recording the moment.
Or whispering to AI for something smart to say.

With that, some of the real-world utility is undeniable.

Hands on the wheel, eyes forward, voice for navigation… glanceable instructions without the dashboard shuffle.
Accessibility that describes a room, reads a label, names a color… a genuine upgrade to human freedom.
When it works like that, it feels less like another social media influencers recording everything and more like an assistive layer.

Strategy also matters here.

Meta doesn’t have a phone.
Glasses are their side door into mobile.
Make them stylish… make them social… make the camera the trojan horse for an assistant that lives on your face.
Apple plays a different game… extend the halo of their iPhone, Watch and AirPods… close the loop so your eyes join the ecosystem.

So it looks like we may need to write the new rules.

Consent-forward by default… recording indicators you can’t cover with a sticker.
Clear social modes… with external cues anyone can read.
No-glasses zones where candor matters more than convenience.
Etiquette you can explain in ten seconds without a FAQ.

I believe that tools this intimate demand a higher bar.

Not just for privacy… for presence.
Not just for features… for shared ground rules.

Because if your eyes become an API… your gaze a user interface… your presence a maybe…
Why should anyone trust what you say? | 13 | 14 | 0 | 2mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.485Z |  | 2025-10-07T15:42:33.530Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7379521269190541313 | Text |  |  | It’s one thing to scale a company.

It’s another thing to scale your character at the same time…
And in this AI world, it might be the most important conversation we’re not having?
We celebrate the rocketship… the valuations… the growth hacks.
We celebrate the leader who raises a round on Monday and doubles headcount by Friday.
But we whisper (if that) about what really cracks most organizations: when the humans at the center can’t keep pace with the thing they’ve built.

Scaling revenue is a process… scaling character is actual chaos.

Because growth isn’t just the sales that are coming in.
It’s more meetings where your words land harder than you intend.
It’s more employees watching every move for signs of fatigue, hypocrisy or control.
It’s much more feedback loops with some disguised as praise, some dressed up as insubordination.
It’s the widening gap between the leader you think you are… and the leader the company suddenly needs.

I’ve felt that lag myself.

The business evolves faster than the operating system inside me.
One moment you’re a scrappy individual contributor who thrives on hustle.
The next, your team needs someone patient enough to listen, generous enough to coach, calm enough to hold space when things catch fire.

And here’s the dirty little leadership secret few will speak of: most leaders don’t make that pivot fast enough… if ever.

That idea hit me hard when I was editing this week’s Thinking With Mitch Joel - The ThinkersOne Podcast with Margaret C. Andrews.
Her book, Manage Yourself To Lead Others, explores this gap between business growth and personal growth, and it stuck with me.

That lag (or lack) destroys more companies than competitors ever will.

We love to say leadership is lonely.
I don’t buy it anymore.
Leadership isn’t lonely… it’s disorienting.
It’s standing at the front of a room, realizing the company has scaled beyond the version of you running it.
And unless you can scale your character with the same discipline you scale your product, you’re leading with yesterday’s software.

And yesterday’s software crashes… always.

This isn’t therapy-speak.
It’s not about being “nice.”
It’s about survival… yours and the company’s.
They’re not just buying into your model.
They’re buying into your temperament.
And temperament doesn’t scale by accident.
It scales by choice… by design… by the willingness to stop chasing external growth long enough to ask: What kind of leader is this company asking me to become?

Businesses don’t fail because the market shifts… businesses fail because the leader refuses to shift.

So maybe the more honest question isn’t “How fast can we grow?”
It’s “How fast can I grow into the person this growth requires?”
If you’re not scaling your character, your company is just running away from you.

Are you growing your character as fast as you’re growing your company? | 28 | 5 | 0 | 2mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.486Z |  | 2025-10-02T14:22:55.450Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7378840294764724225 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8y1T0MvfwKQ/feedshare-shrink_800/B4EZmboIxOIIAg-/0/1759252617376?e=1766620800&v=beta&t=coMVDKLqQlNctn9L_1-OcZtXlWFqLcCwwuS8g3bFbxM | What can stop the brain rot?

Let’s not bury the lede... it’s reading books.
We don’t talk enough about what books do to the brain.
Not what they contain... not the story... not the author.
The act of reading itself.
Because reading is not natural.
Speaking is... breathing is.

Reading? It’s an acquired skill.

One that rewires the brain.
According to the experts, it coordinates visual processing, language comprehension, memory and imagination... all firing in milliseconds.
And those circuits are fragile.
They only grow stronger through practice.
Through focus... Through repetition.

That’s why leaders like you should be obsessed with books.

Not business books... not the latest bestseller...
Any book.
Because when you read a book, you’re training the one skill that distraction culture is trying hardest to kill.

Attention.

Attention is leadership.
In meetings, what people crave isn’t more slides.
It’s your presence... your focus.
You ability to stay focused in that moment (especially when those moments are online in tiny squares).

Here’s the hard truth... 

Technology isn’t just stealing time.
It’s competing with the very circuits that reading builds.
This isn’t the television of our childhoods.
It isn’t even the video games some of us grew up with.
Those demanded sustained attention.
Hours of immersion.
But there was no tracking... no ads slipped between levels.
No other apps or social media gaming our brains.

Today’s games and apps are different.

Engineered by design.
Built around persuasive loops.
Every ping another crack in the scaffolding of your focus.
So when you scroll, you’re not just passing time.
You’re retraining your brain.
You’re practicing distraction.

And our kids are watching.

They don’t see what’s on your screen.
They just do what kids do: model themselves after the adults.
If all they see is scrolling, that’s the habit they’ll learn.
If they see a book, a moment of stillness... they’ll model something else (whether they know it or not).

That’s the secondary story.

When you pick up a book, you’re not only raising yourself as a reader... you’re raising them too.
And the question isn’t whether books will survive... they will.
The question is whether we will survive without them.

AI could make this worse.

Not just because it can write books too.
But because it will feed us ideas pre-chewed... an illusion of knowledge without the discipline of attention.
Leaders who stop reading will think they’re still learning.
But they’ll just be skimming.
Never building the deep circuits that thinking requires.

And that’s the biggest provocation here.

Books are training for focus.
For leadership... for a world that is being designed to give us everything we need in that tiny, glowing rectangle that we carry with us.

So yes... read for your kids.
But more importantly... read for yourself.

Because if you can’t hold your attention on a book... why should anyone bother holding their attention on you? | 105 | 30 | 7 | 2mo | Post | Mitch Joel | https://www.linkedin.com/in/mitchjoel | https://linkedin.com/in/mitchjoel | 2025-12-08T04:50:58.488Z |  | 2025-09-30T17:16:58.495Z |  |  | 

---



---

# Mitch Joel
*ThinkersOne*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [The Persistence Of Brands - Mitch Joel](https://mitchjoel.medium.com/the-persistence-of-brands-d93ea3201b3d)
*2017-12-08*
- Category: blog

### [Mitch Joel: The Entrepreneur's Mindset and the Danger of ...](https://unfoldingthought.com/mitch-joel-the-entrepreneurs-mindset-and-the-danger-of-stasis/)
- Category: article

### [From Six Pixels Of Separation To Thinking With Mitch Joel](https://www.sixpixels.com/articles/archives/from-six-pixels-of-separation-to-thinking-with-mitch-joel/)
*2025-09-08*
- Category: article

### [Big Tech, Big Media, Big Trouble And Big Lies | by Mitch Joel](https://medium.com/@mitchjoel/big-tech-big-media-big-trouble-and-big-lies-55a75da0cc8b)
*2023-12-08*
- Category: blog

### [Thinking With Mitch Joel](https://sixpixels.libsyn.com/\')
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 19,322 words total*

### The Persistence Of Brands
*1,559 words* | Source: **EXA** | [Link](https://mitchjoel.medium.com/the-persistence-of-brands-d93ea3201b3d)

The Persistence Of Brands. “Nobody wants to be branded anymore,”… | by Mitch Joel | Medium

===============

[Sitemap](https://mitchjoel.medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2Fd93ea3201b3d&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmitchjoel.medium.com%2Fthe-persistence-of-brands-d93ea3201b3d&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fmitchjoel.medium.com%2Fthe-persistence-of-brands-d93ea3201b3d&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

Top highlight

1

Press enter or click to view image in full size

![Image 4](https://miro.medium.com/v2/resize:fit:700/1*cNMmjbb_yZpKAOD4lUrnsw.jpeg)

The Persistence Of Brands
=========================

[![Image 5: Mitch Joel](https://miro.medium.com/v2/resize:fill:64:64/1*FW0tWYY3EiE7BArTMkKXBA.jpeg)](https://mitchjoel.medium.com/?source=post_page---byline--d93ea3201b3d---------------------------------------)

[Mitch Joel](https://mitchjoel.medium.com/?source=post_page---byline--d93ea3201b3d---------------------------------------)

Follow

4 min read

·

Dec 26, 2016

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2Fd93ea3201b3d&operation=register&redirect=https%3A%2F%2Fmitchjoel.medium.com%2Fthe-persistence-of-brands-d93ea3201b3d&user=Mitch+Joel&userId=ab3856d11bb0&source=---header_actions--d93ea3201b3d---------------------clap_footer------------------)

18

4

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2Fd93ea3201b3d&operation=register&redirect=https%3A%2F%2Fmitchjoel.medium.com%2Fthe-persistence-of-brands-d93ea3201b3d&source=---header_actions--d93ea3201b3d---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3Dd93ea3201b3d&operation=register&redirect=https%3A%2F%2Fmitchjoel.medium.com%2Fthe-persistence-of-brands-d93ea3201b3d&source=---header_actions--d93ea3201b3d---------------------post_audio_button------------------)

Share

**_“Nobody wants to be branded anymore,”_ said Aaron Levine, head designer for**[**Abercrombie & Fitch**](https://www.abercrombie.com/)**.**

Well, if that line from the [Wall Street Journal](http://www.wsj.com/)’s article, [Crocodiles (and Polo Ponies) Go Missing as Scalpel-Wielding Consumers Revolt](http://www.wsj.com/articles/crocodiles-and-polo-ponies-go-missing-as-scalpel-wielding-consumers-revolt-1482421188), doesn’t make your marketing brain stand up and take notice, who knows what will? There’s nothing (really) new in this article. It’s a meme that rises to the mass media every few years. There’s this thought that human beings are becoming less and less concerned, interested and caring about brands. People want quality, and they no longer feel the need (at the same time) to be advertising for some business by flaunting their corporate animal in the upper quadrant of their polo shirt. Brands have (somehow) become less important, and individuals are more interested in buying clothes that are (somewhat) personalized, or that speak to them by allowing their own personalized style to flaunt.

**Slow down there, just a second.**

People confuse the power of a brand with the value of a brand. They are not the same thing. Brands are more important than ever. Brands are also a lot bigger than the fashion labels. The other week, I was complaining about my new [Apple](http://www.apple.com/)[MacBook Pro](http://www.apple.com/macbook-pro/). I was/still am in dongle and power cable hell. Everything that I had accumulated over the years became obsolete in one swoop. Many quipped (on [Facebook](https://www.facebook.com/mitchjoel), of course) that I could have purchased a much better equipped and speedier computer, had I just switched over to PC. I know. For decades, I was a hardcore PC user before switching over to Apple, about five years ago. Why pay a premium? Well, there are a lot of reasons, but it’s not hard to admit that Apple is a premium brand. Period. Full stop. I like the Apple brand. Almost everything abo

*[... truncated, 27,874 more characters]*

---

### Mitch Joel: The Entrepreneur's Mindset and the Danger of Stasis - Unfolding Thought
*294 words* | Source: **EXA** | [Link](https://unfoldingthought.com/mitch-joel-the-entrepreneurs-mindset-and-the-danger-of-stasis/)

In this episode of _The Unfolding Thought Podcast_, Eric Pratum speaks with Mitch Joel — entrepreneur, author of _Six Pixels of Separation_ and _CTRL ALT Delete_, and host of the podcasts _Thinking with Mitch Joel_ and _Groove: The No Treble Podcast_. Mitch shares his perspective on entrepreneurship, creativity, and why “success is the anomaly.”

They explore how _Thinkers One_ is democratizing access to thought leadership, why change—not stasis—is the natural state of business and culture, and how our relationship with technology and media shapes what it means to be “social.” Mitch also reflects on his decades-long journey across marketing, music, and digital innovation — and how curiosity, humility, and a willingness to “show your work” are essential to staying relevant in a world that never stops shifting.

**Topics Explored:**

*   The myth of the “entrepreneurial mindset” and why success can’t be replicated
*   Why _Thinkers One_ exists and how it redefines access to expert thinking
*   Escaping stasis: how to stay curious and open to change
*   The balance between longform depth and shortform accessibility
*   The philosophy behind _Thinking with Mitch Joel_ and the art of asking better questions
*   What creativity and bass playing have in common
*   How to rethink “social” in an age of constant screens

**Links:**

*   Mitch Joel’s website: [https://www.mitchjoel.com](https://www.mitchjoel.com/)
*   _Thinking with Mitch Joel_ podcast: [https://thinkersone.com/blogs/six-pixels-of-separation-podcast](https://thinkersone.com/blogs/six-pixels-of-separation-podcast)
*   _Groove: The No Treble Podcast_: [https://www.notreble.com/podcast/](https://www.notreble.com/podcast/)
*   _Thinkers One_: [https://thinkersone.com](https://thinkersone.com/)
*   Mitch’s _Six Pixels of Separation_: [https://amzn.to/4qDUJyx](https://amzn.to/4qDUJyx)
*   Mitch’s _Ctrl Alt Delete_: [https://amzn.to/436zVWC](https://amzn.to/436zVWC)
*   Susan Orlean on writing: [https://www.susanorlean.com](https://www.susanorlean.com/)
*   Empathy and fiction study: [https://pmc.ncbi.nlm.nih.gov/articles/PMC3559433/](https://pmc.ncbi.nlm.nih.gov/articles/PMC3559433/)
*   Patrick Tanguay: [https://pkty.ca](https://pkty.ca/)
*   Tom Webster’s _The Audience Listening_: [https://amzn.to/4qvmJ7w](https://amzn.to/4qvmJ7w)
*   Colman Swisher’s appearance on _From There to Here_: [https://boldrfutures.com/from-there-to-here-podcast-featuring-colman-swisher/](https://boldrfutures.com/from-there-to-here-podcast-featuring-colman-swisher/)
*   Jess Villegas’ _The Leader’s Commute_: [https://podcasts.apple.com/us/podcast/the-leaders-commute-podcast/id1712720351](https://podcasts.apple.com/us/podcast/the-leaders-commute-podcast/id1712720351)

**For more episodes:**[https://unfoldingthought.com](https://unfoldingthought.com/)

**Questions or guest ideas:**[eric@inboundandagile.com](mailto:eric@inboundandagile.com)

---

### From Six Pixels Of Separation To Thinking With Mitch Joel
*1,977 words* | Source: **EXA** | [Link](https://www.sixpixels.com/articles/archives/from-six-pixels-of-separation-to-thinking-with-mitch-joel/)

From Six Pixels Of Separation To Thinking With Mitch Joel - Thinking With Mitch Joel, Formerly Six Pixels of Separation

===============

[Skip to content](https://www.sixpixels.com/articles/archives/from-six-pixels-of-separation-to-thinking-with-mitch-joel/#content)

[![Image 2: Thinking With Mitch Joel, Formerly Six Pixels of Separation](https://www.sixpixels.com/wp-content/uploads/2025/09/TWMJ_Website_Header-1.jpg)](https://www.sixpixels.com/)
[Thinking With Mitch Joel, Formerly Six Pixels of Separation](https://www.sixpixels.com/)

A space for curious minds at the intersection of technology, culture, business and the future.

*   [X](https://x.com/mitchjoel)
*   [Facebook](https://www.facebook.com/MitchJoel/)
*   [LinkedIn](https://www.linkedin.com/in/mitchjoel/)
*   [Instagram](https://www.instagram.com/mitchjoel/)
*   [Email](mailto:hello@sixpixels.com)

Search for: Search

Navigation

*   [Home](https://www.sixpixels.com/)
*   [Podcast](https://www.sixpixels.com/category/podcast/)
*   [Articles](https://www.sixpixels.com/category/articles/)
*   [Subscribe](https://www.sixpixels.com/subscribe/)
*   [MitchJoel.com](http://www.mitchjoel.com/)
*   [ThinkersOne.com](http://www.thinkersone.com/)

![Image 3](https://www.sixpixels.com/wp-content/uploads/2025/09/TWMJ_Youtube_Template-850x550.jpg)

[September 8, 2025](https://www.sixpixels.com/articles/archives/from-six-pixels-of-separation-to-thinking-with-mitch-joel/ "12:40 pm")[Articles](https://www.sixpixels.com/category/articles/)

From Six Pixels Of Separation To Thinking With Mitch Joel
=========================================================

![Image 4](https://www.sixpixels.com/wp-content/uploads/2018/08/mitch-joel-canada-small-150x150.jpg)Posted by [Mitch Joel](https://www.sixpixels.com/author/mitchjoel/ "View all posts by Mitch Joel")

**One thousand.**

It’s a big number.. it’s also a strange number.

 When I started Six Pixels of Separation back in 2003, it wasn’t a brand.

 It was a simple marketing blog… a way to put ideas out into the world while running the digital agency I had co-founded, Twist Image.

**The name? It felt right for the moment.**

Back then, the internet was still “other.”

 Something you logged into.

 Something that lived on a screen.

 But we were connecting in ways we could have never imagined.

 We were no longer six degrees of separation from people we didn’t know… we were all suddenly interconnected… six pixels of separation.

**But names do something else: they hold you in a place and time.**

Six Pixels grew.

 It turned from a blog into one of the first voices for how media and culture were shifting towards digital.

 It became the name of [my first book](https://www.mitchjoel.com/books) (published in 2009).

 It became a front row seat to conversations with some of the smartest people on the planet (when the podcast launched in 2006).

 It also became my personal playground and studio… tracking my own shifts as a marketing agency executive… to business writer… [keynote speaker](https://www.mitchjoel.com/)… media person… to builder of what comes next.

**And here we are.**

We published [episode #1000 of Six Pixels of Separation – The ThinkersOne Podcast](https://www.sixpixels.com/podcast/archives/spos-1000-patrick-tanguay-on-paths-to-better-thinking/) this past Sunday.

 That number stopped me in my tracks.

 A milestone like that forces reflection.

 Because the content has never been just about marketing… or technology.

 It’s been about thinking.

 About how to think better about complex topics in an ever-innovative world.

 About how we navigate disruption, embrace change and find the patterns hiding under the noise.

**So from now on, Six Pixels of Separation becomes Thinking with Mitch Joel.**

This isn’t about abandoning the past.

 It’s about aligning the signal with what’s already here.

 Technology is no longer separate.

 We don’t log into it.

 We live inside of it.

 The pixels are gone.

**What remains is the work… the thinking… about what it means to be human in a world being remade by code, culture, and capital.**

The podcast will continue.

 The essays and articles will continue.

 The conversations will continue.

 But with a name that speaks more clearly to what we’ve been doing all along.

**And yes, it also connects better to my business, [ThinkersOne](https://www.thinkersone.com/), and everything we are doing to help companies get first access to new ideas from the brightest experts out there.**

ThinkersOne is my attempt to take this same idea (that the right thought at the right time can shift how we see everything) and make it accessible inside companies everywhere.

 Personal, custom and actionable.

 Not another keynote or video, but a spark that teams can actually use in the moments that matter.

**In many ways, Thinking with Mitch Joel and ThinkersOne are two sides of the same coin.**

One is public, open and ongoing.

 The other is focused, intentional and designed for business.

**Bo

*[... truncated, 29,401 more characters]*

---

### Big Tech, Big Media, Big Trouble And Big Lies
*1,465 words* | Source: **EXA** | [Link](https://medium.com/@mitchjoel/big-tech-big-media-big-trouble-and-big-lies-55a75da0cc8b)

[![Image 1: Mitch Joel](https://miro.medium.com/v2/resize:fill:64:64/1*FW0tWYY3EiE7BArTMkKXBA.jpeg)](https://mitchjoel.medium.com/?source=post_page---byline--55a75da0cc8b---------------------------------------)

6 min read

Aug 24, 2023

Press enter or click to view image in full size

![Image 2](https://miro.medium.com/v2/resize:fit:700/1*C0oom2Owz74UDbrBfwzEXw.jpeg)

Photo by KELLY LEONARD: [https://www.pexels.com/photo/aerial-photography-of-a-city-during-night-time-5770637/](https://www.pexels.com/photo/aerial-photography-of-a-city-during-night-time-5770637/)

**It takes a lot for me to both get angry and publish about it.**

[Canada’s Online News Act](https://www.canada.ca/en/canadian-heritage/services/online-news.html) (aka Bill C-18) has sent me down the social media rabbit hole battling journalists, credible thought leaders, friends, and trolls.

What’s the saying? _“I’m mad as hell, and I’m not going to take this anymore!”_

For context on the law and what’s been happening, here’s my initial take: [Clickbait And Switch — Canada’s Big Tech Showdown](https://www.sixpixels.com/articles/archives/clickbait-and-switch-canadas-big-tech-showdown/).

But, as usual, [Michael Geist](https://www.michaelgeist.ca/) (Canadian academic, the [Canada Research Chair in Internet and E-Commerce Law](https://www.chairs-chaires.gc.ca/chairholders-titulaires/profile-eng.aspx?profileId=840) at the [University of Ottawa](https://www.uottawa.ca/en) and a member of the [Centre for Law, Technology and Society](https://techlaw.uottawa.ca/)) really nails the entire issue right here: [The Bill C-18 Regulation Fake-Out: Setting the Record Straight on When Bill C-18 Takes Effect and the Regulation Making Process](https://www.michaelgeist.ca/2023/08/the-bill-c-18-regulation-fake-out-setting-the-record-straight-on-when-bill-c-18-takes-effect-and-the-regulation-making-process/).

Get Mitch Joel’s stories in your inbox
--------------------------------------

Join Medium for free to get updates from this writer.

**Before digging into what’s pissing me off, let me make some larger points that are not up for debate in my frustration, but need to be addressed as well (as separate issues from Bill C-18):**

*   I am not a [Facebook](https://www.facebook.com/mitchjoel) or social media apologist. For all of the great things this technology has added to the world, there are an equal amount of bad things… really bad things (this includes content moderation).
*   [Meta](https://www.meta.com/)/Facebook[/Instagram](https://www.instagram/mitchjoel) and many of the other social media platforms must deal with their user’s data. How it is managed, used, and sold.
*   I believe in good government. I do not take sides based on my political leanings (in fact, I often find myself really challenged to choose a political party over a specific politician).
*   I believe, deeply, in the power of journalism, journalists and their importance to our community and democracy. My professional career started in journalism/publishing/media long before there was a commercialized Internet.
*   I will always fight for and support local news/media, and for its independence and importance.
*   Social Media platforms have a big challenge when it comes to compensating creators. Those creators can be big media companies, people, me or influencers. Whether or not creators should be compensated directly from these platforms or via the advertising, sales, etc. that happens from that content is not something I have fully reconciled. I create a ton of content “for free” because I see it as a promotional tool that leads to other opportunities (for me, that would be sales on [ThinkersOne](https://thinkersone.com/), [speaking opportunities](https://www.mitchjoel.com/speaking/), investment opportunities, more media appearances, etc.).

**So, what grinds my gears about everything that is going on?**

1.   News outlets are claiming that they are the trusted news sources that people turn to, and having their news blocked on Meta/Facebook is an erosion of democracy. The news is not being blocked. The media companies are saying they are trusted sources of truth, but countless articles are either mis-representing the law, or simply lying/trying to scare their customers into believing that they are the victims here.
2.   The entire business model of media and advertising is the exact opposite of what this law represents. The example I have been using is this: You sell cars. I refer someone to you as a customer. You then turn around and want me to pay you for bringing in the customer. No, it’s the other way around (see: affiliate marketing). Always. These media companies should be thrilled that so many citizens are creating, commenting and sharing their news links on Facebook and driving more attention, traffic, advertising revenue and subscriptions to their websites. With that, yes, Facebook does benefit from these links and engagement on their platform. This can be true while they’re also 

*[... truncated, 5,391 more characters]*

---

### Thinking With Mitch Joel
*681 words* | Source: **EXA** | [Link](https://sixpixels.libsyn.com/\')

Thinking With Mitch Joel

===============

Toggle navigation[](https://sixpixels.libsyn.com/website "Home Page")

*    
*   [About](https://sixpixels.libsyn.com/')
*   [Episodes](https://sixpixels.libsyn.com/'#)
    *   [All Episodes](https://sixpixels.libsyn.com/website)
    *   [Categories](https://sixpixels.libsyn.com/'#)
        *   [business](https://sixpixels.libsyn.com/website/category/business)
        *   [Management & Marketing](https://sixpixels.libsyn.com/website/category/Management+%26+Marketing)

    *   [Archives](https://sixpixels.libsyn.com/'#)
        *   [2025](https://sixpixels.libsyn.com/website/2025)
            *   [December](https://sixpixels.libsyn.com/website/2025/12)
            *   [November](https://sixpixels.libsyn.com/website/2025/11)
            *   [October](https://sixpixels.libsyn.com/website/2025/10)
            *   [September](https://sixpixels.libsyn.com/website/2025/09)
            *   [August](https://sixpixels.libsyn.com/website/2025/08)
            *   [July](https://sixpixels.libsyn.com/website/2025/07)
            *   [June](https://sixpixels.libsyn.com/website/2025/06)
            *   [May](https://sixpixels.libsyn.com/website/2025/05)
            *   [April](https://sixpixels.libsyn.com/website/2025/04)
            *   [March](https://sixpixels.libsyn.com/website/2025/03)
            *   [February](https://sixpixels.libsyn.com/website/2025/02)
            *   [January](https://sixpixels.libsyn.com/website/2025/01)

        *   [2024](https://sixpixels.libsyn.com/website/2024)
            *   [December](https://sixpixels.libsyn.com/website/2024/12)
            *   [November](https://sixpixels.libsyn.com/website/2024/11)
            *   [October](https://sixpixels.libsyn.com/website/2024/10)
            *   [September](https://sixpixels.libsyn.com/website/2024/09)
            *   [August](https://sixpixels.libsyn.com/website/2024/08)
            *   [July](https://sixpixels.libsyn.com/website/2024/07)
            *   [June](https://sixpixels.libsyn.com/website/2024/06)
            *   [May](https://sixpixels.libsyn.com/website/2024/05)
            *   [April](https://sixpixels.libsyn.com/website/2024/04)
            *   [March](https://sixpixels.libsyn.com/website/2024/03)
            *   [February](https://sixpixels.libsyn.com/website/2024/02)
            *   [January](https://sixpixels.libsyn.com/website/2024/01)

        *   [2023](https://sixpixels.libsyn.com/website/2023)
            *   [December](https://sixpixels.libsyn.com/website/2023/12)
            *   [November](https://sixpixels.libsyn.com/website/2023/11)
            *   [October](https://sixpixels.libsyn.com/website/2023/10)
            *   [September](https://sixpixels.libsyn.com/website/2023/09)
            *   [August](https://sixpixels.libsyn.com/website/2023/08)
            *   [July](https://sixpixels.libsyn.com/website/2023/07)
            *   [June](https://sixpixels.libsyn.com/website/2023/06)
            *   [May](https://sixpixels.libsyn.com/website/2023/05)
            *   [April](https://sixpixels.libsyn.com/website/2023/04)
            *   [March](https://sixpixels.libsyn.com/website/2023/03)
            *   [February](https://sixpixels.libsyn.com/website/2023/02)
            *   [January](https://sixpixels.libsyn.com/website/2023/01)

        *   [2022](https://sixpixels.libsyn.com/website/2022)
            *   [December](https://sixpixels.libsyn.com/website/2022/12)
            *   [November](https://sixpixels.libsyn.com/website/2022/11)
            *   [October](https://sixpixels.libsyn.com/website/2022/10)
            *   [September](https://sixpixels.libsyn.com/website/2022/09)
            *   [August](https://sixpixels.libsyn.com/website/2022/08)
            *   [July](https://sixpixels.libsyn.com/website/2022/07)
            *   [June](https://sixpixels.libsyn.com/website/2022/06)
            *   [May](https://sixpixels.libsyn.com/website/2022/05)
            *   [April](https://sixpixels.libsyn.com/website/2022/04)
            *   [March](https://sixpixels.libsyn.com/website/2022/03)
            *   [February](https://sixpixels.libsyn.com/website/2022/02)
            *   [January](https://sixpixels.libsyn.com/website/2022/01)

        *   [2021](https://sixpixels.libsyn.com/website/2021)
            *   [December](https://sixpixels.libsyn.com/website/2021/12)
            *   [November](https://sixpixels.libsyn.com/website/2021/11)
            *   [October](https://sixpixels.libsyn.com/website/2021/10)
            *   [September](https://sixpixels.libsyn.com/website/2021/09)
            *   [August](https://sixpixels.libsyn.com/website/2021/08)
            *   [July](https://sixpixels.libsyn.com/website/2021/07)
            *   [June](https://sixpixels.libsyn.com/website/2021/06)
            *   [May](https://sixpixels.libsyn.com/website/2021/05)
            *   [April](https://sixpixels.libsyn.com/website/2021/04)
            *   [March](https://sixpixels.libsyn.com/website/20

*[... truncated, 15,339 more characters]*

---

### Thinking With Mitch Joel
*4,363 words* | Source: **GOOGLE** | [Link](https://podcasts.apple.com/us/podcast/thinking-with-mitch-joel/id157616278)

1.   [![Image 1: How Leaders Lead with David Novak](https://podcasts.apple.com/assets/artwork/1x1.gif) 20H AGO ### Emotionally Intelligent Teams With Vanessa Urch Druskat - TWMJ #1013 Welcome to episode #1013 of Thinking With Mitch Joel (formerly Six Pixels of Separation). At a time when organizations are wrestling with fractured cultures, hybrid work, and teams struggling to stay connected, it helps to learn from someone who has spent three decades proving that collaboration is not a personality trait but a designed environment, which is why this episode turns to the work of Vanessa Druskat, an award-winning researcher, educator at the University of New Hampshire, and one of the world's leading experts on team emotional intelligence. Vanessa has devoted her career to understanding how teams actually function in the real world, conducting years of field research inside global companies, university systems, and high-pressure environments to uncover the norms, habits, and emotional cues that separate high-performing groups from those that merely coexist. She is a pioneer of the Team Emotional Intelligence (Team EI) model, a framework now used by leaders around the world to build team cultures rooted in shared understanding, psychological safety, and constructive emotional expression. Her latest book, The Emotionally Intelligent Team - Building Collaborative Groups That Outperform The Rest, anchors this conversation and brings together decades of research showing that great teams are not the inevitable result of great individuals but the product of intentional cultures that enable people to listen, challenge, support, and adapt together. In our discussion, Vanessa explores the evolution of emotional intelligence in the workplace, the persistent resistance to emotional concepts in both academia and business, and the growing gap between individual achievement systems and the collective realities of modern work. She explains why leaders must think more like coaches, why norms matter more than personalities, how remote work demands more deliberate emotional connection, and why teams must continually review and recalibrate their dynamics to sustain high performance. Drawing on insights from social neuroscience, organizational psychology, and global fieldwork, she shows how belonging, shared understanding, and a sense of influence are not "soft skills" but hard prerequisites for collaboration in an increasingly polarized and distracted world. Enjoy the conversation… Running time: 55:07. Hello from beautiful Montreal. Listen and subscribe over at Apple Podcasts. Listen and subscribe over at Spotify. Please visit and leave comments on the blog - Thinking With Mitch Joel. Feel free to connect to me directly on LinkedIn. Check out ThinkersOne. Here is my conversation with Vanessa Druskat. The Emotionally Intelligent Team - Building Collaborative Groups That Outperform The Rest. Team Emotional Intelligence (Team EI) model. Follow Vanessa on LinkedIn. Chapters: (00:00) - Introduction to Emotional Intelligence in Teams. (04:14) - The Evolution of Emotional Intelligence in the Workplace. (09:45) - Resistance to Emotional Intelligence in Academia and Business. (14:30) - The Importance of Team Dynamics. (19:30) - The Role of Leaders as Coaches. (26:07) - Building a Culture of Collaboration. (31:40) - Navigating Remote Work Challenges. (39:03) - The Power of Eye Contact and Connection. (42:15) - Understanding Team Members for Better Collaboration. (47:27) - Monitoring Team Health and Dynamics. (51:10) - The Impact of Culture on Team Performance. 55 min](https://podcasts.apple.com/us/podcast/emotionally-intelligent-teams-with-vanessa-urch/id157616278?i=1000740063323) 
2.   [![Image 2: How Leaders Lead with David Novak](https://podcasts.apple.com/assets/artwork/1x1.gif) NOV 30 ### Facing Fear And Finding Purpose With Ranjay Gulati - TWMJ #1012 Welcome to episode #1012 of Thinking With Mitch Joel (formerly Six Pixels of Separation). Amid a moment when uncertainty defines every industry and leaders everywhere are confronting fear disguised as strategy, it is worth turning to someone who has spent his career decoding how individuals and organizations find the courage to act, which is why this week's guest, Ranjay Gulati, offers such rare authority. Ranjay is the Paul R. Lawrence MBA Class of 1942 Professor at Harvard Business School, a globally recognized organizational sociologist, bestselling author, and one of the world's most cited scholars on leadership, strategy, and culture. His research has shaped how companies think about growth, resilience, and high-performance environments, and his teaching in Harvard's executive and senior-leader programs has influenced thousands of CEOs navigating transformation and complexity. Before this latest work, he authored landmark books such as Deep Purpose and built a career studying how organizations thrive in adversity, drawing on field research with global enterprises, fast-growth ventures

*[... truncated, 24,912 more characters]*

---

### Thinking With Mitch Joel, Formerly Six Pixels of Separation
*2,132 words* | Source: **GOOGLE** | [Link](https://www.sixpixels.com/)

Thinking With Mitch Joel, Formerly Six Pixels of Separation - A space for curious minds at the intersection of technology, culture, business and the future.

===============

[Skip to content](https://www.sixpixels.com/#content)

[![Image 22: Thinking With Mitch Joel, Formerly Six Pixels of Separation](https://www.sixpixels.com/wp-content/uploads/2025/09/TWMJ_Website_Header-1.jpg)](https://www.sixpixels.com/)
[Thinking With Mitch Joel, Formerly Six Pixels of Separation](https://www.sixpixels.com/)
=========================================================================================

A space for curious minds at the intersection of technology, culture, business and the future.

*   [X](https://x.com/mitchjoel)
*   [Facebook](https://www.facebook.com/MitchJoel/)
*   [LinkedIn](https://www.linkedin.com/in/mitchjoel/)
*   [Instagram](https://www.instagram.com/mitchjoel/)
*   [Email](mailto:hello@sixpixels.com)

Search for: Search

Navigation

*   [Home](https://www.sixpixels.com/)
*   [Podcast](https://www.sixpixels.com/category/podcast/)
*   [Articles](https://www.sixpixels.com/category/articles/)
*   [Subscribe](https://www.sixpixels.com/subscribe/)
*   [MitchJoel.com](http://www.mitchjoel.com/)
*   [ThinkersOne.com](http://www.thinkersone.com/)

[![Image 23](https://www.sixpixels.com/wp-content/uploads/2025/12/TWMJ_Youtube_Ep-1013-850x550.jpg)](https://www.sixpixels.com/articles/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-this-weeks-thinking-with-mitch-joel-conversation/)

[December 7, 2025](https://www.sixpixels.com/articles/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-this-weeks-thinking-with-mitch-joel-conversation/ "6:10 am")[Articles](https://www.sixpixels.com/category/articles/)

[Emotionally Intelligent Teams With Vanessa Urch Druskat – This Week’s Thinking With Mitch Joel Conversation](https://www.sixpixels.com/articles/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-this-weeks-thinking-with-mitch-joel-conversation/)
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Episode #1013 of Thinking With Mitch Joel (formerly Six Pixels of Separation – The ThinkersOne Podcast) is now live and

[Continue reading](https://www.sixpixels.com/articles/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-this-weeks-thinking-with-mitch-joel-conversation/)

[![Image 24](https://www.sixpixels.com/wp-content/uploads/2025/12/TWMJ_Youtube_Ep-1013-850x550.jpg)](https://www.sixpixels.com/podcast/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-twmj-1013/)

[December 7, 2025](https://www.sixpixels.com/podcast/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-twmj-1013/ "6:00 am")[Podcast](https://www.sixpixels.com/category/podcast/)

[Emotionally Intelligent Teams With Vanessa Urch Druskat – TWMJ #1013](https://www.sixpixels.com/podcast/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-twmj-1013/)
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Welcome to episode #1013 of Thinking With Mitch Joel (formerly Six Pixels of Separation). At a time when organizations are

[Continue reading](https://www.sixpixels.com/podcast/archives/emotionally-intelligent-teams-with-vanessa-urch-druskat-twmj-1013/)

[![Image 25](https://www.sixpixels.com/wp-content/uploads/2025/06/SixLinks2025-850x550.png)](https://www.sixpixels.com/articles/archives/six-links-that-make-you-think-808/)

[December 6, 2025](https://www.sixpixels.com/articles/archives/six-links-that-make-you-think-808/ "6:00 am")[Articles](https://www.sixpixels.com/category/articles/)

[Six Links That Make You Think #808](https://www.sixpixels.com/articles/archives/six-links-that-make-you-think-808/)
--------------------------------------------------------------------------------------------------------------------

Is there one link, story, picture or thought that you saw online this week that you think somebody you know

[Continue reading](https://www.sixpixels.com/articles/archives/six-links-that-make-you-think-808/)

[![Image 26](https://www.sixpixels.com/wp-content/uploads/2025/12/Successnext-850x550.png)](https://www.sixpixels.com/articles/archives/the-success-trap/)

[December 3, 2025](https://www.sixpixels.com/articles/archives/the-success-trap/ "9:44 am")[Articles](https://www.sixpixels.com/category/articles/)

[The Success Trap](https://www.sixpixels.com/articles/archives/the-success-trap/)
---------------------------------------------------------------------------------

It seems like my meditation last week on identity and growth struck a chord, so here’s another personal thread I’ve

[Continue reading](https://

*[... truncated, 39,689 more characters]*

---

### About Us
*1,766 words* | Source: **GOOGLE** | [Link](https://thinkersone.com/pages/about)

About Us – ThinkersOne 

===============
[Skip to content](https://thinkersone.com/pages/about#MainContent)

[Search](https://thinkersone.com/search)

[![Image 1: ThinkersOne](https://cdn.shopify.com/s/files/1/0578/9804/1512/files/ThinkersLogo_Putty.svg?v=1627658025)](https://thinkersone.com/)

[My Account](https://thinkersone.com/account)

[0 Cart](https://thinkersone.com/cart)

*   [Instagram](https://instagram.com/thinkersone "ThinkersOne on Instagram")
*   [Facebook](https://facebook.com/thinkersone "ThinkersOne on Facebook")
*   [Twitter](https://twitter.com/thinkersone "ThinkersOne on Twitter")
*   [Linkedin](https://linkedin.com/company/thinkersone "ThinkersOne on Linkedin")

[![Image 3: ThinkersOne](https://cdn.shopify.com/s/files/1/0578/9804/1512/files/ThinkersLogo_Putty.svg?v=1627658025)](https://thinkersone.com/)

[Search](https://thinkersone.com/search "Search")

[My Account](https://thinkersone.com/account "My Account")

[0 Cart](https://thinkersone.com/cart "Cart")

[Thinkers Thinkers](https://thinkersone.com/pages/about#)

[All Thinkers](https://thinkersone.com/collections/all)[Featured Thinkers](https://thinkersone.com/collections/featured-though-leaders)[Academics](https://thinkersone.com/collections/academics)[Authors](https://thinkersone.com/collections/authors)[Business Leaders](https://thinkersone.com/collections/business-leaders)[Coaches](https://thinkersone.com/collections/coaches)[Consultants](https://thinkersone.com/collections/consultants)[Industry Analysts](https://thinkersone.com/collections/industry-analysts)

[Topics Topics](https://thinkersone.com/pages/about#)

[Management](https://thinkersone.com/collections/management)[Leadership](https://thinkersone.com/collections/leadership)[Change Management](https://thinkersone.com/collections/management-strategy)[Entrepreneurship](https://thinkersone.com/collections/entrepreneurship)[Startups](https://thinkersone.com/collections/startups)[Retail](https://thinkersone.com/collections/retail)[ESG](https://thinkersone.com/collections/esg)[Corporate Social Responsibility](https://thinkersone.com/collections/corporate-social-responsibility)[Crisis Management](https://thinkersone.com/collections/crisis-management)

[Sales & Marketing](https://thinkersone.com/collections/sales-marketing)[Sales](https://thinkersone.com/collections/sales)[Marketing](https://thinkersone.com/collections/marketing)[B2B](https://thinkersone.com/collections/b2b)[Communications](https://thinkersone.com/collections/communications)[Advertising](https://thinkersone.com/collections/advertising)[Social Media](https://thinkersone.com/collections/social-media)[Content Marketing](https://thinkersone.com/collections/content-marketing)[Branding](https://thinkersone.com/collections/branding)[Consumer Behavior](https://thinkersone.com/collections/consumer-behavior)[Customer Experience](https://thinkersone.com/collections/customer-experience)[Networking](https://thinkersone.com/collections/networking)[Negotiation](https://thinkersone.com/collections/negotiation)[Presentation Skills](https://thinkersone.com/collections/presentation-skills)

[Work Culture](https://thinkersone.com/collections/work-culture)[Corporate Culture](https://thinkersone.com/collections/corporate-culture)[Human Resources](https://thinkersone.com/collections/human-resources)[Talent](https://thinkersone.com/collections/talent)[Future of Work](https://thinkersone.com/collections/future-of-work)[Generations](https://thinkersone.com/collections/generations)[Team Building](https://thinkersone.com/collections/team-building)[Collaboration](https://thinkersone.com/collections/collaboration)[Creativity](https://thinkersone.com/collections/creativity)[Psychology](https://thinkersone.com/collections/psychology)[DEI](https://thinkersone.com/collections/dei)[Social Change](https://thinkersone.com/collections/social-change)

[Personal Development](https://thinkersone.com/collections/personal-development)[Peak Performance](https://thinkersone.com/collections/peak-performance)[Motivation & Inspiration](https://thinkersone.com/collections/motivation-inspiration)[Resilience](https://thinkersone.com/collections/resilience)[Coaching](https://thinkersone.com/collections/coaching)[Wellness](https://thinkersone.com/collections/wellness)

[Arts & Culture](https://thinkersone.com/collections/arts-culture)[Entertainment](https://thinkersone.com/collections/entertainment)

[Finance](https://thinkersone.com/collections/finance)[Economic Outlook](https://thinkersone.com/collections/economic-outlook)[Fintech](https://thinkersone.com/collections/fintech)[Cryptocurrency](https://thinkersone.com/collections/cryptocurrency)[Fundraising](https://thinkersone.com/collections/fundraising)

[Technology](https://thinkersone.com/collections/technology)[Disruption, Innovation & Transformation](https://thinkersone.com/collections/disruption-innovation-transformation)[Future Trends](https://thinkersone.com/collections/future-trends)[B2B Technology](http

*[... truncated, 22,262 more characters]*

---

### Why Generative AI Is Not Just a Passing Trend in B2B
*1,851 words* | Source: **GOOGLE** | [Link](https://news.designrush.com/generative-ai-not-passing-trend-essential-tool)

Why Generative AI Is an Essential Tool for B2B Agencies | DesignRush

===============

[![Image 3: DesignRush](https://www.designrush.com/topbest/images/svg/designrush-purple-logo.svg)](https://www.designrush.com/)

*    AGENCY DIRECTORY 

 Branding & Creative   Website & Interface   Marketing   Software & App   IT Services   

 Branding & Creative  
    *   [Digital Agencies](https://www.designrush.com/agency/digital-agencies)
    *   [Branding Agencies](https://www.designrush.com/agency/logo-branding)
    *   [Creative Agencies](https://www.designrush.com/agency/creative-agencies)
    *   [Product Design Companies](https://www.designrush.com/agency/product-design)
    *   [Logo Design Companies](https://www.designrush.com/agency/logo-design)
    *   [Graphic Design Companies](https://www.designrush.com/agency/graphic-design)
    *   [Packaging Design Companies](https://www.designrush.com/agency/package-design)
    *   [Video Production Companies](https://www.designrush.com/agency/video-production)
    *   [Public Relations Firms](https://www.designrush.com/agency/public-relations)
    *   [Design Agencies](https://www.designrush.com/agency/design-agencies)
    *   [Reputation Management Companies](https://www.designrush.com/agency/reputation-management-companies)

 Branding & Creative 

 Website & Interface 

    *   [Web Design Companies](https://www.designrush.com/agency/website-design-development)
    *   [eCommerce Development Companies](https://www.designrush.com/agency/ecommerce)
    *   [Web Development Companies](https://www.designrush.com/agency/web-development-companies)
    *   [WordPress Web Design Companies](https://www.designrush.com/agency/wordpress-web-design)
    *   [WordPress Development Companies](https://www.designrush.com/agency/web-development-companies/wordpress)
    *   [Magento Development Companies](https://www.designrush.com/agency/ecommerce/magento)
    *   [Shopify Development Companies](https://www.designrush.com/agency/ecommerce/shopify)
    *   [UI/UX Design Agencies](https://www.designrush.com/agency/ui-ux-design)
    *   [Small Business Website Design Companies](https://www.designrush.com/agency/website-design-development/small-business)

 Website & Interface 

 Marketing 

    *   [Digital Marketing Agencies](https://www.designrush.com/agency/digital-marketing)
    *   [SEO Agencies](https://www.designrush.com/agency/search-engine-optimization)
    *   [PPC Agencies](https://www.designrush.com/agency/paid-media-pay-per-click)
    *   [Social Media Marketing Companies](https://www.designrush.com/agency/social-media-marketing)
    *   [Search Engine Marketing Agencies](https://www.designrush.com/agency/digital-marketing/search-engine)
    *   [Email Marketing Agencies](https://www.designrush.com/agency/email-marketing)
    *   [Small Business SEO Companies](https://www.designrush.com/agency/search-engine-optimization/small-business)
    *   [Local SEO Companies](https://www.designrush.com/agency/search-engine-optimization/local-seo)
    *   [Google Ads Agencies](https://www.designrush.com/agency/paid-media-pay-per-click/google-adwords)
    *   [Advertising Agencies](https://www.designrush.com/agency/ad-agencies)
    *   [eCommerce SEO Agencies](https://www.designrush.com/agency/search-engine-optimization/ecommerce-seo)
    *   [Media Buying Agencies](https://www.designrush.com/agency/media-buying-agencies)
    *   [Content Marketing Agencies](https://www.designrush.com/agency/content-marketing)
    *   [Lead Generation Companies](https://www.designrush.com/agency/digital-marketing/lead-generation)
    *   [Video Marketing Services](https://www.designrush.com/agency/video-marketing)

 Marketing 

 Software & App 

    *   [Software Development Companies](https://www.designrush.com/agency/software-development)
    *   [Offshore Software Development Companies](https://www.designrush.com/agency/software-development/offshore-software-developers)
    *   [Outsourcing Software Development Companies](https://www.designrush.com/agency/software-development/outsourcing)
    *   [Mobile App Development Companies](https://www.designrush.com/agency/mobile-app-design-development)
    *   [VR & Augmented Reality Companies](https://www.designrush.com/agency/ar-vr)
    *   [AI Companies](https://www.designrush.com/agency/ai-companies)
    *   [Android App Development Companies](https://www.designrush.com/agency/mobile-app-design-development/android)
    *   [iPhone App Development Companies](https://www.designrush.com/agency/mobile-app-design-development/iphone)
    *   [Blockchain Development Companies](https://www.designrush.com/agency/blockchain-development-companies)
    *   [Software Testing Companies](https://www.designrush.com/agency/software-testing-companies)

 Software & App 

 IT Services 

    *   [IT Services Companies](https://www.designrush.com/agency/it-services)
    *   [IT Outsourcing Companies](https://www.designrush.com/agency/it-services/outsourcing)
    *   [Managed S

*[... truncated, 19,544 more characters]*

---

### Five Business Lessons Learned From Entrepreneur Mitch Joel
*3,234 words* | Source: **GOOGLE** | [Link](https://www.forbes.com/sites/danpontefract/2023/05/22/five-business-lessons-learned-from-entrepreneur-mitch-joel/)

Five Business Lessons Learned From Entrepreneur Mitch Joel

===============

[](https://www.forbes.com/)

[Newsletters](https://account.forbes.com/newsletters/)[Games](https://www.forbes.com/games)[Share a News Tip](https://www.forbes.com/sites/forbesstaff/article/tips-and-confidential-sources/)

[](https://www.forbes.com/search/?q=)

*   Featured 

Featured 

    *   [Breaking News](https://www.forbes.com/news/) 
    *   [White House Watch](https://www.forbes.com/trump/) 
    *   [Daily Cover Stories](https://www.forbes.com/daily-cover-stories/) 
    *   [Celebrating Top Fundraisers Uniting To End Blood Cancers| Paid Program](https://www.forbes.com/sites/bloodcancerunited/2025/12/01/celebrating-top-fundraisers-uniting-to-end-blood-cancers/) 
    *   [America's 2025 Top Wealth Management Teams Private Wealth List | Paid Program](https://www.forbes.com/lists/top-wealth-management-teams-private-wealth/) 
    *   [The Forbes CIO Next List: 2025| Paid Program](https://www.forbes.com/sites/richardnieva/2025/11/18/the-forbes-cio-next-list-2025/) 
    *   [America's 2025 Top Wealth Management Teams High Net Worth List](https://www.forbes.com/lists/top-wealth-management-teams-high-net-worth/) 
    *   [When Teens Fundraise To End Blood Cancer, They Change Lives, Including Their Own| Paid Program](https://www.forbes.com/sites/bloodcancerunited/2025/11/19/when-teens-fundraise-to-end-blood-cancer-they-change-lives-including-their-own/) 
    *   [The Employee Well-Being Imperative| Paid Program](https://www.forbes.com/sites/american-heart-association/2025/10/22/the-employee-well-being-imperative/) 
    *   [Best-In-State Top Next-Gen Wealth Advisors 2025](https://www.forbes.com/lists/best-in-state-next-gen-advisors/) 
    *   [AI’s Nuanced Impact And A Quest To Quantify It](https://www.forbes.com/sites/forbes-research/2023/10/26/c-suite-data-reveals-ais-nuanced-impact--a-quest-to-quantify-it/) 
    *   [DNA of Success](https://www.forbes.com/sites/forbesvideo/2023/11/01/dna-of-success-2023/) 
    *   [Embracing And Bracing For AI](https://www.forbes.com/sites/forbes-research/2023/10/26/new-forbes-survey-reveals-how-executives-are-embracing---and-bracing-for---ai/) 
    *   [Facing A Volatile Market, C-Suites Look To The CFO For Strategic Guidance](https://www.forbes.com/sites/forbes-research/2023/11/01/facing-a-volatile-market-c-suites-look-to-the-cfo-for-strategic-guidance/) 
    *   [Your Four-Part Blueprint To Unlock AI Value In 2025| Paid Program](https://www.forbes.com/sites/avanade/2025/02/05/your-four-part-blueprint-to-unlock-ai-value-in-2025/) 
    *   [By The Numbers: Meet The Forbes 30 Under 30 Europe Class Of 2025](https://www.forbes.com/30-under-30/2025/europe/) 
    *   [Next Billion-Dollar Startups 2025](https://www.forbes.com/sites/amyfeldman/2025/08/12/next-billion-dollar-startups-2025/) 
    *   [Four Reasons To Rethink Your Savings Strategy](https://www.forbes.com/sites/insights-synchrony-bank/2025/10/13/four-reasons-to-rethink-your-savings-strategy/) 
    *   [America's Most Powerful Women In Sports](https://www.forbes.com/sites/maggiemcgrath/2025/10/22/americas-most-powerful-women-in-sports-2025/) 
    *   [Navigating Retirement In Today’s Economic Landscape](https://www.forbes.com/video/b45397ed-a6eb-44dd-b00b-47e1ad5e2913/navigating-retirement-in-todays-economic-landscape/) 
    *   [Forbes Iconoclast: How Top Investors Find Opportunities In Times Of Uncertainty](https://www.forbes.com/sites/courtneyconnley-hampton/2025/11/21/how-top-investors-find-opportunities-in-times-of-uncertainty/) 
    *   [The Joy Of Checking Out](https://www.forbes.com/sites/forbesliveteam/2025/11/24/the-joy-of-checking-out/) 
    *   [The Performance Layer| Paid Program](https://www.forbes.com/sites/forbesvideo/2025/11/25/the-performance-layer/) 
    *   [Do You Know The True Cost Of Your Legacy Finance Tech? Take This Quiz To Find Out| Paid Program](https://www.forbes.com/sites/anaplan/2025/11/18/do-you-know-the-true-cost-of-your-legacy-finance-tech-take-this-quiz-to-find-out/) 
    *   [CXO Spotlight| Paid Program](https://www.forbes.com/sites/forbesvideo/2024/02/21/cxo-spotlight) 

More...

*   [Billionaires](https://www.forbes.com/worlds-billionaires/) 

Billionaires[See All](https://www.forbes.com/worlds-billionaires/)  

    *   [World's Billionaires](https://www.forbes.com/billionaires/) 
    *   [Forbes 400](https://www.forbes.com/forbes-400/) 
    *   [America's Richest Self-Made Women](https://www.forbes.com/self-made-women/) 
    *   [China's Richest](https://www.forbes.com/lists/china-billionaires/) 
    *   [India's Richest](https://www.forbes.com/lists/india-billionaires/) 
    *   [Indonesia's Richest](https://www.forbes.com/lists/indonesia-billionaires/) 
    *   [Korea's Richest](https://www.forbes.com/lists/korea-billionaires/) 
    *   [Thailand's Richest](https://www.forbes.com/lists/thailand-billionaires/) 
    *   [Japan's Richest](https://www.forbes.com/lists/japan-billionaires/) 
    *   [Australi

*[... truncated, 52,919 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Thinking With Mitch Joel - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/thinking-with-mitch-joel/id157616278)**
  - Source: podcasts.apple.com
  - *Listen to Mitch Joel's Thinking With Mitch Joel podcast on Apple Podcasts ... Also, SPOS is a ThinkersOne podcast. Many SPOS guests are featured Think...*

- **[Thinking With Mitch Joel, Formerly Six Pixels of Separation - A ...](https://www.sixpixels.com/)**
  - Source: sixpixels.com
  - *... Mitch Joel Conversation. Episode #1012 of Thinking With Mitch Joel (formerly Six Pixels of Separation – The ThinkersOne Podcast) is now live and. ...*

- **[About Us – ThinkersOne](https://thinkersone.com/pages/about)**
  - Source: thinkersone.com
  - *Mitch Joel is a co-founder ThinkersOne and active thought leader working at ... Mitch's first book, Six Pixels of Separation, named after his successf...*

- **[Why Generative AI Is Not Just a Passing Trend in B2B](https://news.designrush.com/generative-ai-not-passing-trend-essential-tool)**
  - Source: news.designrush.com
  - *Jul 11, 2024 ... Meet Mitch Joel of ThinkersOne who shares how B2B agencies can ... The 54th episode of the DesignRush Podcast brings you a conversati...*

- **[Five Business Lessons Learned From Entrepreneur Mitch Joel](https://www.forbes.com/sites/danpontefract/2023/05/22/five-business-lessons-learned-from-entrepreneur-mitch-joel/)**
  - Source: forbes.com
  - *May 22, 2023 ... Watch the full interview with Mitch Joel and Dan ... ThinkersOne - The Bite-Sized Thought Leadership Platform from Visionary Mitch Jo...*

- **[Media — Mitch Joel](https://www.mitchjoel.com/media)**
  - Source: mitchjoel.com
  - *Mitch Joel is currently an investor, media personality, podcaster, journalist and Co-Founder of ThinkersOne....*

- **[Alex Frank From Jeff Goldblum & The Mildred Snitzer Orchestra On ...](https://www.sixpixels.com/articles/archives/alex-frank-from-jeff-goldblum-the-mildred-snitzer-orchestra-on-this-months-groove-the-no-treble-podcast/)**
  - Source: sixpixels.com
  - *Nov 13, 2025 ... ... mitch joelmitchjoelmodern jazz bassmontreal jazz festivalmusic ... thinkersoneupright bass. Post navigation. Previous Post. Foste...*

- **[From Six Pixels Of Separation To Thinking With Mitch Joel - Thinking ...](https://www.sixpixels.com/articles/archives/from-six-pixels-of-separation-to-thinking-with-mitch-joel/)**
  - Source: sixpixels.com
  - *Sep 8, 2025 ... keynote speaker… media person… to builder of ... In many ways, Thinking with Mitch Joel and ThinkersOne are two sides of the same coin...*

- **[Articles Archives - Thinking With Mitch Joel, Formerly Six Pixels of ...](https://www.sixpixels.com/category/articles/)**
  - Source: sixpixels.com
  - *... Mitch Joel Conversation. Episode #1012 of Thinking With Mitch Joel (formerly Six Pixels of Separation – The ThinkersOne Podcast) is now live and ....*

- **[Mr. Mitch Joel - The Montreal Family Office & High Net Worth ...](https://montreal-wealth.com/speakers/mr-mitch-joel/)**
  - Source: montreal-wealth.com
  - *Mitch Joel. Co-Founder, ThinkersOne. When brands like Google, Starbucks, Shopify and GE want to leverage technology to better connect with their consu...*

---

*Generated by Founder Scraper*
