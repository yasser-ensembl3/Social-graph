# Mohammad Shirvan

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Ourbuddy Ai Inc
**Durée dans le rôle** : 2 years 2 months in role
**Durée dans l'entreprise** : 2 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Co-founded and led the backend architecture of OurBuddy.ai, a multi-tenant SaaS platform built for insurance brokerages.

Architected and delivered a scalable backend infrastructure with 99.9% uptime, supporting multiple brokerages and 100+ active users.

Designed and implemented AI-powered lead management and workflow automation systems, reducing manual setup time by 70%.

Built a multimodal RAG system integrating LLMs for intelligent document and video processing, training content generation, and real-time Q&A.

Developed microservices with Spring Boot, Kafka, Redis, AWS, and Docker, ensuring sub-100ms API latency.

Integrated Keycloak for enterprise-grade multi-tenant identity management and fine-grained access control.

Established automated CI/CD pipelines with GitHub Actions, Jenkins, and GitLab CI, minimizing production issues by 60%.

## Résumé

I build backend systems that scale reliably.

With 14+ years of experience, I specialize in Java / Spring Boot microservices, cloud architecture, and AI integration. I’m currently the Co-Founder & Backend Architect at OurBuddy.ai, a multi-tenant SaaS platform for insurance brokerages. I design and manage backend systems powering AI-driven automation, event-driven workflows, and 99.9% uptime infrastructure.

My technical sweet spot lies in event-driven architecture, integrating LLMs and RAG systems, and building rock-solid APIs that handle high-volume traffic without breaking.

Previously, I co-founded Softverse Technology and spent several years building:

Secure payment systems handling hundreds of thousands of daily transactions

Enterprise CRMs serving millions of users

Scalable APIs for web and mobile applications

Tech stack: Java, Spring Boot/Cloud, AWS, Azure, Docker, Kafka, PostgreSQL, Redis, Python (AI integrations), and modern CI/CD.

Based in Montreal 🇨🇦, currently learning French.
Always happy to connect with engineers, founders, and builders working on challenging and meaningful problems.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA8WkzYBNfaMmoLr2rji9ylsHXgKTFqEYYk/
**Connexions partagées** : 1


---

# Mohammad Shirvan

## Position actuelle

**Entreprise** : Ourbuddy Ai Inc

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mohammad Shirvan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389272425948999680 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8878f330-7965-4d03-a6a0-41f2305562c4 | https://media.licdn.com/dms/image/v2/D4E05AQH93A0A0aXC2Q/videocover-low/B4EZotLGX6KYBQ-/0/1761694481182?e=1765785600&v=beta&t=ZLHrWg4UoUpqkUGTOLHjhmme0U_CrMJ6nTPAiSFz4-Q | Reading this reminded me why we started Ourbuddy.AI in the first place. It’s not just about building AI — it’s about building for people who care deeply about their clients and their craft.

The passion and integrity I’ve seen from Canadian brokers inspire us every day to push harder and make AI that actually helps, not replaces.

Honoured to be building this alongside you, Anil. 🙌

#InsuranceBrokers #InsurTech #TheFutureIsYou #OurBuddyAI #Gratitude | 3 | 0 | 0 | 1mo | Post | Mohammad Shirvan | https://www.linkedin.com/in/mshirvan | https://linkedin.com/in/mshirvan | 2025-12-08T07:01:59.894Z |  | 2025-10-29T12:10:32.389Z | https://www.linkedin.com/feed/update/urn:li:activity:7389269794035748864/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7329171229225947136 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHdde0K99ZLgg/feedshare-shrink_2048_1536/B56ZbZwxl_HUAo-/0/1747410166521?e=1766620800&v=beta&t=9Li_6uTHJXv1zEjrlku3javZNisWtnShfZHY_lUxDeM | What if your team didn’t waste hours searching through folders, chats, and emails?

At OurBuddy, we’re building an AI that doesn’t just store your files—it understands them.

Proud of what we’re creating at Ourbuddy Ai Inc smarter, faster way to find what matters.

#AI #Productivity #Startup #OurBuddyAI | 4 | 0 | 0 | 6mo | Post | Mohammad Shirvan | https://www.linkedin.com/in/mshirvan | https://linkedin.com/in/mshirvan | 2025-12-08T07:02:02.021Z |  | 2025-05-16T15:49:50.464Z | https://www.linkedin.com/feed/update/urn:li:activity:7329169456679542786/ |  | 

---



---

# Mohammad Shirvan
*Ourbuddy Ai Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Buddy.AI’s Founder Turns His American Dream into a Movement Impacting 22 Million Lives](https://aimresearch.co/market-industry/buddy-ais-founder-turns-his-american-dream-into-a-movement-impacting-22-million-lives)
*2024-11-12*
- Category: article

### [Ivan Crewkov CEO & Co-Founder of Buddy AI – Interview Series](https://unite.ai/ivan-crewkov-ceo-co-founder-of-buddy-ai-interview-series)
*2024-02-16*
- Category: article

### [Episode 39 - Bryan Talebi - CEO and Co‐Founder of Ahura AI](https://podcasts.apple.com/sl/podcast/episode-39-bryan-talebi-ceo-and-co-founder-of-ahura-ai/id1629780011?i=1000676664812)
*2024-11-12*
- Category: podcast

### [$100B Founder Breaks Down The Biggest AI Business Opportunities For 2025](https://podcasts.apple.com/bh/podcast/%24100b-founder-breaks-down-the-biggest-ai-business/id1469759170?i=1000678301010)
*2024-11-26*
- Category: podcast

### [The Shobeir Show](https://podcasts.apple.com/us/podcast/the-shobeir-show/id1629780011)
*2024-11-26*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
