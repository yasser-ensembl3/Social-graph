# Boris Martínez Castillo

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396994761670201344 | Text |  |  | So what’s the deal with the Meta gig? Is it legit?? 

#meta #ai #vfx #nuke | 2 | 0 | 0 | 2w | Post | Boris Martínez Castillo | https://www.linkedin.com/in/boris-mc | https://linkedin.com/in/boris-mc | 2025-12-08T07:06:50.640Z |  | 2025-11-19T19:36:20.699Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7296646310873497602 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9ea45172-a414-4251-917f-9f71122f3592 | https://media.licdn.com/dms/image/v2/D5610AQGHJR_809We4Q/videocover-low/B56ZUJDP6GGoA8-/0/1739613605485?e=1765785600&v=beta&t=3nreqx7y4WHB7r-FFg_pM5NmqnulhrHuWq6x5dNJqZc | ✍🏼🤕 | 4 | 0 | 0 | 9mo | Post | Boris Martínez Castillo | https://www.linkedin.com/in/boris-mc | https://linkedin.com/in/boris-mc | 2025-12-08T07:06:50.640Z |  | 2025-02-15T21:47:25.645Z | https://www.linkedin.com/feed/update/urn:li:activity:7296468386677432321/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7292214344795185155 | Video (LinkedIn Source) | blob:https://www.linkedin.com/045990f5-5252-494a-8ca2-f0d6e9e67b37 | https://media.licdn.com/dms/image/v2/D4E05AQEIBtp2IvPNXg/videocover-low/B4EZTMi2E9GgCQ-/0/1738598502030?e=1765785600&v=beta&t=Pfhh0lw70Ej1N_U4K2Xhto_syEKQcasnlzxYs6GFsI4 | This one's got to be a good one! | 6 | 0 | 0 | 10mo | Post | Boris Martínez Castillo | https://www.linkedin.com/in/boris-mc | https://linkedin.com/in/boris-mc | 2025-12-08T07:06:50.641Z |  | 2025-02-03T16:16:22.590Z | https://www.linkedin.com/feed/update/urn:li:activity:7292211075628826624/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7285785054843142144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhkLrgLs-SNg/feedshare-shrink_2048_1536/B4EZRxO5s4HMAo-/0/1737066519738?e=1766620800&v=beta&t=CkC-u_09EhbfhYW3wwkMGrW1NhaqXqvv470t3iX5Hfs | One of the few true geniuses the world of the arts has ever seen and an obsession of mine ever since I first watched one of his masterpiece movies. RIP maestro. | 9 | 0 | 0 | 10mo | Post | Boris Martínez Castillo | https://www.linkedin.com/in/boris-mc | https://linkedin.com/in/boris-mc | 2025-12-08T07:06:50.641Z |  | 2025-01-16T22:28:40.415Z |  |  | 

---

