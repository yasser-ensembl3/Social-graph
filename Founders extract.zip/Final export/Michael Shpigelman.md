# Michael Shpigelman

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Activity Messenger
**Durée dans le rôle** : 3 years 3 months in role
**Durée dans l'entreprise** : 3 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAxykdkBPSiiE5MYVxEr2JXWmb6mrVG3Qec/
**Connexions partagées** : 42


---

# Michael Shpigelman

## Position actuelle

**Entreprise** : Activity Messenger

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Michael Shpigelman

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394907440770600960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHmyzYEEha9Hw/feedshare-shrink_800/B4EZp5QMawHMAk-/0/1762970881013?e=1766620800&v=beta&t=0lI26RSV3y3xx5WIVz4_obggmRrtqP-NhdHrUauIfdY | 💙❤️ | 15 | 0 | 0 | 3w | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:02.435Z |  | 2025-11-14T01:22:04.616Z | https://www.linkedin.com/feed/update/urn:li:activity:7394720783618547713/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7382677252074938368 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c826c423-e4ae-4f56-9867-a58d20f3aaf4 | https://media.licdn.com/dms/image/v2/D4E05AQHSW8tfJRu5aw/videocover-low/B4EZmWqi6qIQB4-/0/1759169361105?e=1765782000&v=beta&t=uOWp8kgcqPfgWbDFNssum4qkSzQf_r3vOLj7j8gt440 | 🤖 | 3 | 0 | 0 | 1mo | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:02.435Z |  | 2025-10-11T07:23:40.405Z | https://www.linkedin.com/feed/update/urn:li:activity:7378775735563603968/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7382067902247510016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF8awbIqMIb6A/feedshare-shrink_800/B4EZm5v1SvHgAk-/0/1759757948789?e=1766620800&v=beta&t=YZAgWkmlDfxfjMBKwhLoGqL2AtNpzpxSjkIisVKrFlI | 🤓 | 1 | 0 | 0 | 1mo | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:02.436Z |  | 2025-10-09T15:02:20.085Z | https://www.linkedin.com/feed/update/urn:li:activity:7381312365889331202/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7371308856682897408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEz630rfuuBwg/feedshare-shrink_800/B4EZkplq_UKYAg-/0/1757339365818?e=1766620800&v=beta&t=OJHkPfrT02ZYd10oHFcA7NPEYwntmNHPsEPYS0U0uSA | ❤️ | 9 | 0 | 0 | 2mo | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:02.438Z |  | 2025-09-09T22:29:43.729Z | https://www.linkedin.com/feed/update/urn:li:activity:7371165526640730112/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7298043688784416769 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF6HXZ4V-qjgg/feedshare-shrink_800/B4EZUZ0vaWHcAg-/0/1739895011669?e=1766620800&v=beta&t=qdd1X2cobe1BYVmk1M4CcCo4Y1V_t4_jmYoubmg_eQs | 🥇 | 6 | 0 | 0 | 9mo | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:08.080Z |  | 2025-02-19T18:20:06.501Z | https://www.linkedin.com/feed/update/urn:li:activity:7297648613059379201/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7293389816740630530 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEimFf0hiQ4Sw/feedshare-shrink_800/B4EZTXaRLAHMAk-/0/1738780776102?e=1766620800&v=beta&t=Dhn-4dqj8-F8zgkIY6gr17iap9QqOFhbL9PpBVPfsvc | ❤️ | 4 | 0 | 1 | 10mo | Post | Michael Shpigelman | https://www.linkedin.com/in/michael-shpigelman-735b3159 | https://linkedin.com/in/michael-shpigelman-735b3159 | 2025-12-08T06:18:08.081Z |  | 2025-02-06T22:07:16.941Z | https://www.linkedin.com/feed/update/urn:li:activity:7293252100359086082/ |  | 

---



---

# Michael Shpigelman
*Activity Messenger*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Shpigelman Facebook, Instagram & Twitter on PeekYou](https://www.peekyou.com/_shpigelman)
*2025-01-01*
- Category: article

### [[155] w/ Michael Shuman](https://open.spotify.com/episode/0aginY5X5e4nHLdeAHr337?si=iCQ2C276QhapoZyLzyIT5g&amp%3Butm_source=copy-link&nd=1&dlsi=aa91c5920cbd46a7)
*2023-02-08*
- Category: podcast

### [](https://activitymessenger.com/blog/how-mobilisaction-jeunesse-managed-to-sell-977-tickets-via-activitymessenger/)
- Category: blog

### [](https://podcasts.apple.com/il/podcast/dan-shipper-the-first-multimodal-media-company/id1709773028?i=1000699009475)
- Category: podcast

### [Eran Shpigelman](https://pmworldlibrary.net/authors/eran-shpigelman/)
*2012-09-29*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[SaaSpasse chez Activity Messenger](https://www.saaspasse.com/startups/activity-messenger)**
  - Source: saaspasse.com
  - *... Activity Messenger vous aide à en faire plus en moins de temps. Fondateurs. Olivier Rousseau. Co-fondateur, Growth. Michael Shpigelman. Co-fondate...*

- **[Ep.84 - Olivier Rousseau : 1M ARR, avantage injuste & co-fondateur ...](https://www.youtube.com/watch?v=lO_SeLHSwEg)**
  - Source: youtube.com
  - *May 1, 2024 ... ://www.linkedin.com/in/michael-shpigelman-735b3159/, co-fondateur chez Activity Messenger ... podcast & événements....*

- **[About us](https://activitymessenger.com/about/)**
  - Source: activitymessenger.com
  - *Activity Messenger is more than a communication and management tool — it's a ... Michael Shpigelman. Co-founder. Mike is a builder. An intermediary .....*

---

*Generated by Founder Scraper*
