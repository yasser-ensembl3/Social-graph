# Mathieu Tougas

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Mizo
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Helping MSPs reduce their costs and increase their productivity.

## Résumé

CEO & Co-founder at Mizo — Service Desk AI Agent that cuts MSP resolution time and increases service quality.  Operator-turned-founder focused on actionnable AI, service-desk automation, and peer-group partnerships. Let’s connect.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABIdY2EB3MV7AVlepKKD82wKVGQdgUVrYps/
**Connexions partagées** : 156


---

# Mathieu Tougas

## Position actuelle

**Entreprise** : Mizo

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Mathieu Tougas
*Mizo*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Mizo | LinkedIn](https://ca.linkedin.com/company/mizo-tech)
*2025-05-12*
- Category: article

### [GRTiQ Podcast: 211 Mathieu Baudet](https://grtiq.com/grtiq-podcast-211-mathieu-baudet/)
*2025-03-07*
- Category: podcast

### [Field Notes | Frédéric Tougas — SHOOT FILM MAGAZINE](https://www.shootfilmmagazine.com/features/blog-post-title-one-kz6xz-z63m9-jwg9c)
*2021-12-22*
- Category: blog

### [Boo! MCP is a Security Frightmare - by Rich Freeman](https://www.channelholic.news/p/boo-mcp-is-a-security-frightmare)
*2025-11-02*
- Category: article

### [News Archive - MSP Channel Transformation](https://channelmastered.com/news/)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Tate Talks - The MSP Podcast - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/tate-talks-the-msp-podcast/id1471418509)**
  - Source: podcasts.apple.com
  - *Listen to Chris Tate - MSP Strategist, JumpCloud's Tate Talks - The MSP Podcast podcast on Apple Podcasts ... S11E3: Tate Talks - With Mathieu Tougas,...*

- **[IT Nation Wise Up | IT Nation](https://itnationpodcast.podbean.com/)**
  - Source: itnationpodcast.podbean.com
  - *... Mathieu Tougas, CEO and Co-Founder of Mizo, and PitchIT 2025 finalist. Read ... Copyright 2024 All rights reserved. Podcast Powered By Podbean. Co...*

- **[Boo! MCP is a Security Frightmare - by Rich Freeman](https://www.channelholic.news/p/boo-mcp-is-a-security-frightmare)**
  - Source: channelholic.news
  - *Nov 2, 2025 ... I'll take it on faith that Mizo's implementation of MCP is safe, given that Mathieu Tougas ... What companies like Mizo disagree about...*

- **[News Archive - MSP Channel Transformation - Channel Mastered](https://channelmastered.com/news/)**
  - Source: channelmastered.com
  - *Mizo Wants Agents and Humans in Healthy Relationships. I'll take it on faith that Mizo's implementation of MCP is safe, given that Mathieu Tougas, its...*

- **[What are we listening to? Here's our MSP Podcast Roundup ...](https://www.scalepad.com/blog/top-msp-podcasts/)**
  - Source: scalepad.com
  - *May 2, 2025 ... Spotify // Apple Podcast · S11E3: Tate Talks - With Mathieu Tougas, Mizo. PreviewE. Dec 2·Tate Talks - The MSP Podcast. Save on Spotif...*

- **[Comparing AI-Powered Tools for MSPs: What to Look For](https://mizo.tech/blog/comparing-ai-powered-tools-msps/)**
  - Source: mizo.tech
  - *Mathieu Tougas profile photo - MSP technology expert and author at Mizo AI agent platform. Mathieu Tougas. • Sep 8, 2025. Featured image for "Comparin...*

- **[Future Outlook: How AI Agents Will Reshape MSP Services by 2026](https://mizo.tech/blog/future-outlook-ai-agents-reshape-msp-2026/)**
  - Source: mizo.tech
  - *Mathieu Tougas profile photo - MSP technology expert and author at Mizo AI agent platform. Mathieu Tougas. • Sep 26, 2025. Featured image for "Future ...*

- **[Complete MSP Ticket Management Guide: From Intake to Closure](https://mizo.tech/blog/msp-ticket-management-process/)**
  - Source: mizo.tech
  - *Mathieu Tougas profile photo - MSP technology expert and author at Mizo AI agent platform. Mathieu Tougas. • Jul 3, 2025. Featured image for "Complete...*

- **[The Ultimate Guide to Structuring Your Ticket Categories](https://mizo.tech/blog/the-ultimate-guide-to-structuring-your-ticket-categories/)**
  - Source: mizo.tech
  - *Mathieu Tougas profile photo - MSP technology expert and author at Mizo AI agent platform. Mathieu Tougas. • Apr 23, 2025. Featured image for "The Ult...*

- **[Mizo - ACET](https://acet.ca/en/portfolio/our-startups/mizo/)**
  - Source: acet.ca
  - *Mizo. Mizo is an integrated AI agent that optimizes support desk operations. Mathieu Tougas ... Blog and news (FR) · Contact us · Français. Present yo...*

---

*Generated by Founder Scraper*
