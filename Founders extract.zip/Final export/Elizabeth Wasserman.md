# Elizabeth Wasserman

## Position actuelle

**Titre** : Advisor, Investor
**Entreprise** : Felix Capital Corp
**Durée dans le rôle** : 7 years 2 months in role
**Durée dans l'entreprise** : 7 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Investment Management

## Description du rôle

I work with high-potential businesses to varying degrees, leveraging my expertise in digital business model development, go-to-market strategy, conversion optimization, and performance marketing.

## Résumé

Founder of Mate1.com, one of the world's top online dating sites, with 50+ million members. Angel investor and advisor to early stage startups. Building something new in 2025.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABaWnkBoFahZzuD6LdtZbGp9_HfWyIeim0/
**Connexions partagées** : 107


---

# Elizabeth Wasserman

## Position actuelle

**Entreprise** : Ask Elina

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Elizabeth Wasserman

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402844583551725569 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHe696UA-b3Ng/feedshare-shrink_800/B4EZrwjtz6HMAg-/0/1764972488983?e=1766620800&v=beta&t=E5uVP4_d82D04esCxVlGVoufYzNB0JqO6aDm4A_UfkU | Thanks Dawn Abankwah, Sinai Health Foundation and the BMO/Airmiles team for today's open, illluminating conversation. We appreciated the thoughtful questions from women of a wide range of ages. and by the men who joined as well. Their presence matters. | 6 | 1 | 1 | 2d | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:45.029Z |  | 2025-12-05T23:01:26.920Z | https://www.linkedin.com/feed/update/urn:li:activity:7402831177914470400/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7400245081443827713 | Text |  |  | I've been hearing about the wonders of peptides from all directions these days, and it's hard to resist the temptation to be a guinea pig when the promises are this big... | 1 | 0 | 0 | 1w | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:45.031Z |  | 2025-11-28T18:51:57.321Z | https://www.linkedin.com/feed/update/urn:li:activity:7400226044097560576/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399445654563086337 | Article |  |  | Crazy. You shouldn’t need a back channel hookup to get treatment for perimenopause symptoms… | 4 | 1 | 0 | 1w | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:45.031Z |  | 2025-11-26T13:55:19.100Z | https://www.nytimes.com/2025/10/28/style/the-perimenopause-whisper-network.html?unlocked_article_code=1.308.MBYO.7Z5fkWq7Zgmp&smid=url-share |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399195876658937856 | Article |  |  | Love this story | 1 | 0 | 0 | 1w | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:45.032Z |  | 2025-11-25T21:22:47.407Z | https://www.buildcanada.com/great-canadian-builders/george-cohon |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7394455569509535744 | Text |  |  | This is an announcement about Ask Elina being ready for the public. 
It's also a story about 2 founders gaining just enough knowledge to realize how little we know...

We started building Ask Elina with an idea of what was broken in women's health care, what the major challenges were for women entering perimenopause, and how AI could be part of the solution. It all seemed so clear.
And then we started testing it on a small group of women (and on ourselves). 

It's been an education, and we are just getting started. | 23 | 11 | 5 | 3w | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.984Z |  | 2025-11-12T19:26:30.112Z | https://www.linkedin.com/feed/update/urn:li:activity:7394426150611177472/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7384676598375108608 | Text |  |  | Come see us this weekend! | 8 | 1 | 1 | 1mo | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.984Z |  | 2025-10-16T19:48:21.709Z | https://www.linkedin.com/feed/update/urn:li:activity:7384664307625738240/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7332838753767456772 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH2oNdN3L5mzw/feedshare-shrink_800/B56Zb.sVoGHoAg-/0/1748029759562?e=1766620800&v=beta&t=ove-ZDV7ASCp4BJHR5oC4FzGi5LhOvYR5RF0HXJnt2U | A genuinely informative interview with my co-founder, Nathalie Belanger. If you want to understand our goals with Ask Elina, this is a great place to start. | 35 | 2 | 1 | 6mo | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.987Z |  | 2025-05-26T18:43:16.454Z | https://www.linkedin.com/feed/update/urn:li:activity:7331768219369697280/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7321350683822067712 | Text |  |  | A chance to work with great people, truly independent thinkers | 9 | 0 | 0 | 7mo | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.987Z |  | 2025-04-25T01:53:47.141Z | https://www.linkedin.com/feed/update/urn:li:activity:7315401699215466496/ | https://www.linkedin.com/jobs/view/4202862493/ | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7317725545763397632 | Article |  |  | The most diabolical thing about perimenopause is that most of us don’t know we’re in it until it has already wreaked havoc in our lives. 
One of my main goals in joining Nathalie Belanger in this project  is to use our marketing skills to reach women before they even know what’s hit them.
Awareness and self-compassion can spare you a lot of anguish. Thats the heart of Ask Elina. (She may also tell you to lift weights and stop drinking, but you’re welcome to ignore that stuff). 
If this is relevant to anyone you know, tell them to please join our waitlist at Askelina.com | 14 | 2 | 0 | 7mo | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.988Z |  | 2025-04-15T01:48:46.876Z | https://globalnews.ca/news/11127597/a-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7295573019492536320 | Text |  |  | You never pass up a chance to work with Nathalie Belanger - especially when she’s fired up about something. Her summary below is one of the clearest things I've read on this subject.
Perimenopause can feel like a descent into a dark and bottomless pit. We’re determined to build a product that gets to the heart of the problem, and to reach women before they even know what the problem is. | 10 | 1 | 0 | 9mo | Post | Elizabeth Wasserman | https://www.linkedin.com/in/lizwasserman | https://linkedin.com/in/lizwasserman | 2025-12-08T04:48:49.988Z |  | 2025-02-12T22:42:33.039Z | https://www.linkedin.com/feed/update/urn:li:activity:7295501471528210433/ |  | 

---



---

# Elizabeth Wasserman
*Ask Elina*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Belong.Life Expands into Women’s Health with Ask Elina](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina)
*2025-04-07*
- Category: article

### [Belong.Life's Advanced AI Technology Selected to Power New Menopause Support Solution](https://www.morningstar.com/news/pr-newswire/20250407io58785/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution)
*2025-04-07*
- Category: article

### [](https://www.prnewswire.com/il/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html)
- Category: article

### [Belong.Life's Advanced AI Technology Selected To Power New Menopause Support Solution](https://www.healthitoutcomes.com/doc/belong-life-s-advanced-ai-technology-selected-power-menopause-support-solution-0001)
*2025-04-07*
- Category: article

### [A Canadian tech company is using AI to help woman navigate menopause](https://globalnews.ca/news/11127597/a-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause/)
*2025-04-14*
- Category: article

---

## 📖 Full Content (Scraped)

*8 articles scraped, 13,517 words total*

### Belong.Life Expands into Women’s Health with Ask Elina
*1,359 words* | Source: **EXA** | [Link](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina)

Belong.Life Expands into Women’s Health with Ask Elina - Tomorrow's World Today®

===============

[Skip to content](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina#primary)

[![Image 3: Tomorrow's World Today](https://www.tomorrowsworldtoday.com/wp-content/uploads/2024/11/cropped-twt_h-logo-solid@2x-1.webp)](https://www.tomorrowsworldtoday.com/)Search this site ![Image 5](https://tomorrowsworldtoday.com/wp-content/themes/twt-custom-theme/assets/svg/icon_search.svg)

*   [Home](https://www.tomorrowsworldtoday.com/)
*   [Special Coverage](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina#!)
    *   [Agriculture and Food](https://www.tomorrowsworldtoday.com/category/agriculture-and-food/)
    *   [Animals](https://www.tomorrowsworldtoday.com/category/animals/)
    *   [Art](https://www.tomorrowsworldtoday.com/category/art/)
    *   [Artificial Intelligence](https://www.tomorrowsworldtoday.com/category/artificial-intelligence/)
    *   [CES](https://www.tomorrowsworldtoday.com/category/ces/)
    *   [Consumer Products](https://www.tomorrowsworldtoday.com/category/consumer-products/)
    *   [Energy](https://www.tomorrowsworldtoday.com/category/energy/)
    *   [Health and Wellness](https://www.tomorrowsworldtoday.com/category/health-and-wellness/)
    *   [Manufacturing](https://www.tomorrowsworldtoday.com/category/manufacturing/)
    *   [Nature](https://www.tomorrowsworldtoday.com/category/nature/)
    *   [Robotics](https://www.tomorrowsworldtoday.com/category/robotics/)
    *   [Space](https://www.tomorrowsworldtoday.com/category/space/)
    *   [Sports](https://www.tomorrowsworldtoday.com/category/sports/)
    *   [Sustainability](https://www.tomorrowsworldtoday.com/category/sustainability/)
    *   [Technology](https://www.tomorrowsworldtoday.com/category/technology/)
    *   [Transportation](https://www.tomorrowsworldtoday.com/category/transportation/)
    *   [Travel](https://www.tomorrowsworldtoday.com/category/travel/)
    *   [World’s First](https://www.tomorrowsworldtoday.com/category/worlds-first/)

*   [Our Worlds](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina#!)
    *   [Inspiration](https://www.tomorrowsworldtoday.com/inspiration/)
    *   [Creation](https://www.tomorrowsworldtoday.com/creation/)
    *   [Innovation](https://www.tomorrowsworldtoday.com/innovation/)
    *   [Production](https://www.tomorrowsworldtoday.com/production/)

*   [Original Programs](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina#!)
    *   [Tomorrow’s World Today](https://www.tomorrowsworldtoday.com/tomorrowsworldtoday/)
    *   [TWT Podcast](https://www.tomorrowsworldtoday.com/podcast/)
    *   [Become a Partner](https://www.tomorrowsworldtoday.com/become-a-partner/)

*   [About](https://www.tomorrowsworldtoday.com/about/)
*   [Contact](https://www.tomorrowsworldtoday.com/contact/)
*   [Be A Contributor](https://www.tomorrowsworldtoday.com/be-a-contributor/)

Navigation

![Image 8: Close navigation](https://tomorrowsworldtoday.com/wp-content/themes/twt-custom-theme/assets/svg/icon_x.svg)
**Where Inspiration and Creation Drive Innovation and Production**

[![Image 10: Tomorrow's World Today](https://tomorrowsworldtoday.com/wp-content/uploads/2024/11/twt_s-logo-solid@4x.png)![Image 12: Tomorrow's World Today](https://tomorrowsworldtoday.com/wp-content/uploads/2024/11/cropped-twt_h-logo-solid@2x-1.webp)](https://www.tomorrowsworldtoday.com/)
**Where Inspiration and Creation Drive Innovation and Production**

Search this site ![Image 14](https://tomorrowsworldtoday.com/wp-content/themes/twt-custom-theme/assets/svg/icon_search.svg)

*   [Home](https://www.tomorrowsworldtoday.com/)
*   [Special Coverage](https://tomorrowsworldtoday.com/applications/belong-life-expands-into-womens-health-with-ask-elina#!)
    *   [Agriculture and Food](https://www.tomorrowsworldtoday.com/category/agriculture-and-food/)
    *   [Animals](https://www.tomorrowsworldtoday.com/category/animals/)
    *   [Art](https://www.tomorrowsworldtoday.com/category/art/)
    *   [Artificial Intelligence](https://www.tomorrowsworldtoday.com/category/artificial-intelligence/)
    *   [CES](https://www.tomorrowsworldtoday.com/category/ces/)
    *   [Consumer Products](https://www.tomorrowsworldtoday.com/category/consumer-products/)
    *   [Energy](https://www.tomorrowsworldtoday.com/category/energy/)
    *   [Health and Wellness](https://www.tomorrowsworldtoday.com/category/health-and-wellness/)
    *   [Manufacturing](https://www.tomorrowsworldtoday.com/category/manufacturing/)
    *   [Nature](https://www.tomorrowsworldtoday.com/category/nature/)
    *   [Robotics](https://www.tomorrowsworldtoday.com/category/robotics/)
    *   [Space](https://www.tomorrowsworldtoday.com/category/space/)
    *   [Sports](https://www.tomorrowsworldtoday.com/category/sports/)

*[... truncated, 16,016 more characters]*

---

### Page Not Found | Morningstar
*70 words* | Source: **EXA** | [Link](https://www.morningstar.com/news/pr-newswire/20250407io58785/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution)

[![Image 1: Morningstar](https://www.morningstar.com/assets/img/morningstar.d826858.svg)](https://www.morningstar.com/)

[Get 7 Days Free](https://www.morningstar.com/mm/investor/learn?utm_source=mstar&utm_medium=header&utm_campaign=evergreen)

*   [Portfolio](https://www.morningstar.com/tools/portfolio)

*   [Funds](https://www.morningstar.com/funds)
*   [ETFs](https://www.morningstar.com/topics/etfs)
*   [Stocks](https://www.morningstar.com/stocks)
*   [Bonds](https://www.morningstar.com/bonds)

*   [Home](https://www.morningstar.com/)

*   
    *   [Portfolio](https://www.morningstar.com/tools/portfolio)
    *   [Watchlists](https://www.morningstar.com/tools/watchlists)
    *   [Screener](https://www.morningstar.com/tools/screener)
    *   [Chart](https://www.morningstar.com/tools/chart)
    *   [Rating Changes](https://www.morningstar.com/tools/rating-changes)

*   [Funds](https://www.morningstar.com/funds)
*   [ETFs](https://www.morningstar.com/topics/etfs)
*   [Stocks](https://www.morningstar.com/stocks)
*   [Bonds](https://www.morningstar.com/bonds)

*   [Help](https://www.morningstar.com/help-center)
*   [What’s New](https://www.morningstar.com/whats-new)
*   [Notifications](https://www.morningstar.com/notifications)

*   [All Products and Services](https://www.morningstar.com/business)

404 Error
---------

Like guarantees of future returns, this page doesn’t exist.

Try searching, or go to our [homepage](https://www.morningstar.com/).

---

### Belong.Life's Advanced AI Technology Selected to Power New Menopause Support Solution
*839 words* | Source: **EXA** | [Link](https://www.prnewswire.com/il/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html)

_'Ask Elina' Harnesses Belong's Data and Expertise in Conversational AI to Help Women_ _Navigate Menopause, Manage Symptoms and Explore Options_

, /PRNewswire/ -- [Belong.Life](https://belong.life/), a leader in AI-driven patient education and engagement solutions, today announced that its AI Health Mentor SaaS solution has been selected to power _[Ask Elina](https://www.askelina.com/)_, a new app designed to help women effectively navigate perimenopause and menopause.

[![Image 1: Powered by Belong.Life’s advanced AI technology, ‘Ask Elina’ is a new app offering personalized, evidence-based support and symptom management for women navigating perimenopause and menopause.](https://mma.prnewswire.com/media/2658921/BelongLife_Ask_Elina.jpg?w=500)](https://www.prnewswire.com/il/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html)

 Powered by Belong.Life’s advanced AI technology, ‘Ask Elina’ is a new app offering personalized, evidence-based support and symptom management for women navigating perimenopause and menopause. 

The menopause journey can be confusing, frustrating, and isolating. _Ask_ _Elina_ is designed to help women navigate these challenges with confidence. Powered by Belong's AI technology, _Elina_ is a highly trained health coach who helps users navigate the overwhelming influx of information about menopause._Elina_ gets to know users personally and provides evidence-based insights and guidance tailored to their needs while helping them manage symptoms and understand their options.

"We chose Belong.Life's AI mentor technology for its proven success in delivering an effective health support platform that excels in user experience and accuracy," said Nathalie Belanger, Co-Founder of _Ask Elina_. "Women deserve a trusted, personalized resource to help them navigate menopause, and with Belong's SaaS solution, we're making that a reality. Perimenopause lasts seven years on average and more than 25 million women around the world enter menopause annually. Empowering women with on-demand, easy-to-understand, evidence-based information tailored to their unique journey is essential for supporting their long-term well-being."

_Ask Elina_ was founded by seasoned executives Nathalie Belanger and Elizabeth Wasserman. Belanger, a former Vice President at both Reitmans retail company and Aeroplan, brings extensive expertise in omnichannel strategies and customer engagement, while Wasserman, the founder of dating platform Mate1.com, successfully built and scaled a global online community of over 50 million users. Their expertise, combined with Belong's AI technology, positions them to bring a best-in-class digital health solution to market.

"Perimenopause can be an incredibly lonely and frightening time for many women," said Elizabeth Wasserman, Co-Founder of _Ask Elina_. "Healthcare providers often dismiss these experiences, leaving women to navigate this transition alone. We're creating a companion that offers both knowledge and compassion when women need it most."

Belong's proprietary AI technology has already demonstrated success in patient communities across oncology and multiple sclerosis, with platforms such as _Dave the Cancer Mentor_ and _BelongMS_. This collaboration marks Belong's expansion into women's health, reinforcing its commitment to leveraging AI to address critical healthcare challenges.

"Women navigating menopause are often underserved, and _Ask Elina_ tackles this head-on with an accessible and easy to use AI-powered companion," said Eliran Malki, Co-Founder and CEO of Belong.Life. "Our AI SaaS platform will support women during this critical stage of their lives. This collaboration highlights how AI can bridge gaps in healthcare by offering scalable, always-available support for women managing complex health transitions."

"The opportunity to impact millions of women navigating menopause is immense, and we are proud to contribute to a solution that delivers accurate, compassionate, and individualized care at scale," said Irad Deutsch, Co-Founder and CTO of Belong.Life. "We are committed to maintaining the highest standards of safety and privacy, ensuring that all users can trust our platform to securely access the tools and insights they need during transformative stages of their lives."

_Ask Elina_ is expected to launch in May 2025. Women interested in early access can join the waitlist at [www.askelina.com](http://www.askelina.com/).

**About Belong.Life**

[Belong.Life](https://belong.life/)is a leader in digital health solutions transforming the patient experience and deliver value for patients, healthcare providers, pharmaceutical companies, and payers. Belong's key solutions include the world's largest social and professional networks for people living with cancer (_[Belong – Beating Cancer Together](https://urldefense.com/v3/\_\_https:/cancer.belong.life/\_\_;!!DlCMXiNAtWOc!1fLWpKoaR6hNoliwB8XLvzgxMI9Rfhhxdgq0\_IBro

*[... truncated, 3,615 more characters]*

---

### Belong.Life's Advanced AI Technology Selected To Power New Menopause Support Solution
*792 words* | Source: **EXA** | [Link](https://www.healthitoutcomes.com/doc/belong-life-s-advanced-ai-technology-selected-power-menopause-support-solution-0001)

_'Ask Elina' Harnesses Belong's Data and Expertise in Conversational AI to Help Women Navigate Menopause, Manage Symptoms and Explore Options_

New York, NY /PRNewswire/ - [Belong.Life](https://belong.life/), a leader in AI-driven patient education and engagement solutions, today announced that its AI Health Mentor SaaS solution has been selected to power [Ask Elina](https://www.askelina.com/), a new app designed to help women effectively navigate perimenopause and menopause.

The menopause journey can be confusing, frustrating, and isolating. Ask Elina is designed to help women navigate these challenges with confidence. Powered by Belong's AI technology, Elina is a highly trained health coach who helps users navigate the overwhelming influx of information about menopause. Elina gets to know users personally and provides evidence-based insights and guidance tailored to their needs while helping them manage symptoms and understand their options.

"We chose Belong.Life's AI mentor technology for its proven success in delivering an effective health support platform that excels in user experience and accuracy," said Nathalie Belanger, Co-Founder of Ask Elina. "Women deserve a trusted, personalized resource to help them navigate menopause, and with Belong's SaaS solution, we're making that a reality. Perimenopause lasts seven years on average and more than 25 million women around the world enter menopause annually. Empowering women with on-demand, easy-to-understand, evidence-based information tailored to their unique journey is essential for supporting their long-term well-being."

Ask Elina was founded by seasoned executives Nathalie Belanger and Elizabeth Wasserman. Belanger, a former Vice President at both Reitmans retail company and Aeroplan, brings extensive expertise in omnichannel strategies and customer engagement, while Wasserman, the founder of dating platform Mate1.com, successfully built and scaled a global online community of over 50 million users. Their expertise, combined with Belong's AI technology, positions them to bring a best-in-class digital health solution to market.

"Perimenopause can be an incredibly lonely and frightening time for many women," said Elizabeth Wasserman, Co-Founder of Ask Elina. "Healthcare providers often dismiss these experiences, leaving women to navigate this transition alone. We're creating a companion that offers both knowledge and compassion when women need it most."

Belong's proprietary AI technology has already demonstrated success in patient communities across oncology and multiple sclerosis, with platforms such as Dave the Cancer Mentor and BelongMS. This collaboration marks Belong's expansion into women's health, reinforcing its commitment to leveraging AI to address critical healthcare challenges.

"Women navigating menopause are often underserved, and Ask Elina tackles this head-on with an accessible and easy to use AI-powered companion," said Eliran Malki, Co-Founder and CEO of Belong.Life. "Our AI SaaS platform will support women during this critical stage of their lives. This collaboration highlights how AI can bridge gaps in healthcare by offering scalable, always-available support for women managing complex health transitions."

"The opportunity to impact millions of women navigating menopause is immense, and we are proud to contribute to a solution that delivers accurate, compassionate, and individualized care at scale," said Irad Deutsch, Co-Founder and CTO of Belong.Life. "We are committed to maintaining the highest standards of safety and privacy, ensuring that all users can trust our platform to securely access the tools and insights they need during transformative stages of their lives."

Ask Elina is expected to launch in May 2025. Women interested in early access can join the waitlist at [www.askelina.com](http://www.askelina.com/).

**About Belong.Life**

[Belong.Life](https://belong.life/) is a leader in digital health solutions transforming the patient experience and deliver value for patients, healthcare providers, pharmaceutical companies, and payers. Belong's key solutions include the world's largest social and professional networks for people living with cancer ([Belong – Beating Cancer Together](https://urldefense.com/v3/__https:/cancer.belong.life/__;!!DlCMXiNAtWOc!1fLWpKoaR6hNoliwB8XLvzgxMI9Rfhhxdgq0_IBroZ1IaPRkFErVzDg_vbTUgzCC5hk16_vvjUwTI43_tc8Ug1T5O-y-zw$)) and multiple sclerosis ([BelongMS](https://urldefense.com/v3/__https:/ms.belong.life/__;!!DlCMXiNAtWOc!1fLWpKoaR6hNoliwB8XLvzgxMI9Rfhhxdgq0_IBroZ1IaPRkFErVzDg_vbTUgzCC5hk16_vvjUwTI43_tc8Ug1QXjfy__w$)). Its AI-driven patient engagement platforms proactively support and empower patients throughout their healthcare journey. These include [Dave - AI Cancer Mentor](https://urldefense.com/v3/__https:/belong.life/belong-ai-health-mentor-app/__;!!DlCMXiNAtWOc!1fLWpKoaR6hNoliwB8XLvzgxMI9Rfhhxdgq0_IBroZ1IaPRkFErVzDg_vbTUgzCC5hk16_vvjUwTI43_tc8Ug1T9eZ4dQg$), validated by top oncologists a

*[... truncated, 2,518 more characters]*

---

### A Canadian tech company is using AI to help woman navigate menopause
*2,140 words* | Source: **EXA** | [Link](https://globalnews.ca/news/11127597/a-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause/)

A Canadian tech company is using AI to help woman navigate menopause - Montreal | Globalnews.ca

===============

[SKIP TO MAIN CONTENT](https://globalnews.ca/news/11127597/a-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause/#content)

In the news

*   [Newfoundland](https://globalnews.ca/news/11560868/child-disappeance-abductions/)
*   [Trump](https://globalnews.ca/news/11563380/carney-washington-trump-sheinbaum-fifa-draw/)
*   [FIFA Peace Prize](https://globalnews.ca/news/11563699/donald-trump-inaugural-fifa-peace-prize/)
*   [Army Vet](https://globalnews.ca/news/11563659/ed-bambas-army-vet-grocery-store-video/)

[Global News Home![Image 6](https://globalnews.ca/wp-content/themes/shaw-globalnews/assets/dist/images/logo-mobile.svg?v=2)](https://globalnews.ca/)

[Subscribe](https://globalnews.ca/pages/email-alerts/)

Site theme toggle. Switch between light or dark mode- [x] 

Light Dark

 

[Live](https://globalnews.ca/live/national/)

Search

Site theme toggle. Switch between light or dark mode- [x] 

Light Dark

 

[GlobalNews home![Image 7](https://globalnews.ca/wp-content/themes/shaw-globalnews/assets/dist/images/logo-morty.svg)](https://globalnews.ca/)

*   [Watch](https://globalnews.ca/videos/)
*   [World](https://globalnews.ca/world/)
*   [Canada](https://globalnews.ca/canada/)
*   Local 
*   [Politics](https://globalnews.ca/politics/)
*   [Money](https://globalnews.ca/money/)
*   [Health](https://globalnews.ca/health/)
*   [Entertainment](https://globalnews.ca/entertainment/)
*   [Lifestyle](https://globalnews.ca/lifestyle/)
*   [Perspectives](https://globalnews.ca/perspectives/)
*   [Sports](https://globalnews.ca/sports/)
*   [Shopping](https://globalnews.ca/the-curator/)
*   [Commentary](https://globalnews.ca/commentary/)
*   [Contests](https://globalnews.ca/contests/)
*   [Podcasts](https://curiouscast.ca/)
*   [U.S. News](https://globalnews.ca/us-news/)

 A Canadian tech company is using AI to help woman navigate menopause 

[Click to return to homepage![Image 8](https://globalnews.ca/wp-content/themes/shaw-globalnews/assets/dist/images/logo-morty.svg)](https://globalnews.ca/)

Leave a comment[Share this item on Facebook](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fglobalnews%2Eca%2Fnews%2F11127597%2Fa-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause%2F)[Share this item via WhatsApp](whatsapp://send?text=A%20Canadian%20tech%20company%20is%20using%20AI%20to%20help%20woman%20navigate%20menopause%20-%20Montreal%20%7C%20Globalnews.ca%20-%20https%3A%2F%2Fglobalnews%2Eca%2Fnews%2F11127597%2Fa-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause%2F)[Share this item on X](https://twitter.com/intent/tweet?text=A%20Canadian%20tech%20company%20is%20using%20AI%20to%20help%20woman%20navigate%20menopause%20-%20Montreal%20%7C%20Globalnews.ca%20https%3A%2F%2Fglobalnews%2Eca%2Fnews%2F11127597%2Fa-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause%2F)[Send this page to someone via email](mailto:?Subject=A%20Canadian%20tech%20company%20is%20using%20AI%20to%20help%20woman%20navigate%20menopause%20-%20Montreal%20%7C%20Globalnews.ca&body=%0D%0AA%20Canadian%20tech%20company%20is%20using%20AI%20to%20help%20woman%20navigate%20menopause%20-%20Montreal%20%7C%20Globalnews.ca%0D%0Ahttps%3A%2F%2Fglobalnews%2Eca%2Fnews%2F11127597%2Fa-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause%2F%0D%0A%0D%0A%0D%0A)See more sharing options

Full Menu

Search Menu

[Home](https://globalnews.ca/)

[Trending](https://globalnews.ca/top-trending)

[Watch](https://globalnews.ca/live/national/)

[Local](https://globalnews.ca/national/)

Menu

Menu Close
----------

Submit Search
### Topics

*   [Watch](https://globalnews.ca/videos/)
*   [World](https://globalnews.ca/world/)
*   [Canada](https://globalnews.ca/canada/)
*   [National](https://globalnews.ca/national/)Change location
*   [Politics](https://globalnews.ca/politics/)
*   [Money](https://globalnews.ca/money/)
*   [Health](https://globalnews.ca/health/)
*   [Entertainment](https://globalnews.ca/entertainment/)
*   [Lifestyle](https://globalnews.ca/lifestyle/)
*   [Perspectives](https://globalnews.ca/perspectives/)
*   [Sports](https://globalnews.ca/sports/)
*   [Shopping](https://globalnews.ca/the-curator/)
*   [Commentary](https://globalnews.ca/commentary/)
*   [Contests](https://globalnews.ca/contests/)
*   [Podcasts](https://curiouscast.ca/)
*   [U.S. News](https://globalnews.ca/us-news/)

### TV Programs

*   [Global National](https://globalnews.ca/national/program/global-national)
*   [West Block](https://globalnews.ca/national/program/the-west-block)
*   [The Morning Show](https://globalnews.ca/national/program/the-morning-show)
*   [Video Centre](https://globalnews.ca/national/videos/)
*   [More…](https://globalnews.ca/national/tv-news-programs)

### Connect

*   [Email alerts](https://globalnews.ca/pages/email-alerts/)
*   [Alexa](https://globalnews.ca/pages/alexa/)
*   [Breaking News

*[... truncated, 30,153 more characters]*

---

### Belong.Life's Advanced AI Technology Selected to Power New Menopause Support Solution
*3,010 words* | Source: **GOOGLE** | [Link](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html)

Belong.Life's Advanced AI Technology Selected to Power New Menopause Support Solution

===============

[Close menu](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-0)

*   [News](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-news)
*   [Products](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-products)
*   [Contact](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-contact)

[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-default)
*   [Send a Release](https://www.prnewswire.com/account/online-membership-form/)
*   [Client Login](https://www.prnewswire.com/account/online-membership-form/)
*   [Resources](https://www.prnewswire.com/resources/)
*   [Blog](https://www.prnewswire.com/resources/articles)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [RSS](https://www.prnewswire.com/rss/)
*   [](https://twitter.com/PRNewswire)[](https://www.facebook.com/pages/PR-Newswire/26247320522)[](https://www.linkedin.com/company/pr-newswire/)

[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-news)
*   _3_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-1)News in Focus
*   _5_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-2)Business & Money
*   _5_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-3)Science & Tech
*   _5_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-4)Lifestyle & Health
*   _0_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-5)Policy & Public Interest
*   _1_[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-6)People & Culture
*   [Send a Release](https://www.prnewswire.com/account/online-membership-form/)
*   [Client Login](https://www.prnewswire.com/account/online-membership-form/)
*   [Resources](https://www.prnewswire.com/resources/)
*   [Blog](https://www.prnewswire.com/resources/articles)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [RSS](https://www.prnewswire.com/rss/)
*   [](https://twitter.com/PRNewswire)[](https://www.facebook.com/pages/PR-Newswire/26247320522)[](https://www.linkedin.com/company/pr-newswire/)

[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-products)
*   [Explore Our Platform](https://www.prnewswire.com/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.prnewswire.com/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.prnewswire.com/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.prnewswire.com/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.prnewswire.com/multichannel-amplification/ "Amplify Content ")
*   [All Products](https://www.prnewswire.com/products/all-products/ "All Products")
*   [Send a Release](https://www.prnewswire.com/account/online-membership-form/)
*   [Client Login](https://www.prnewswire.com/account/online-membership-form/)
*   [Resources](https://www.prnewswire.com/resources/)
*   [Blog](https://www.prnewswire.com/resources/articles)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [RSS](https://www.prnewswire.com/rss/)
*   [](https://twitter.com/PRNewswire)[](https://www.facebook.com/pages/PR-Newswire/26247320522)[](https://www.linkedin.com/company/pr-newswire/)

[](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html#mm-panel-contact)
*   [General Inquiries](https://www.prnewswire.com/contact-us/general-inquiries "General Inquiries")
*   [Editorial Bureaus](https://www.prnewswire.com/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https://www.prnewswire.com/contact-us/partnerships "Partnerships")
*   [Media Inquiries](https://www.prnewswire.com/contact-us/media-inquiries "Media Inquiries")
*   [Worldwide Offices](https://www.prnew

*[... truncated, 73,728 more characters]*

---

### New app uses proven AI to fill gaps in menopause support
*2,586 words* | Source: **GOOGLE** | [Link](https://www.femtechworld.co.uk/news/new-app-uses-proven-ai-to-fill-gaps-in-menopause-support-mnp25/)

New app uses proven AI to fill gaps in menopause support

===============

[![Image 2: FemTech World](https://femtechworld.co.uk/wp-content/uploads/2021/11/femtech-white.svg)](https://www.femtechworld.co.uk/)

*   [Latest News](https://www.femtechworld.co.uk/latest-news/)
*   [Opinion](https://www.femtechworld.co.uk/category/opinion/)
*   [Insight](https://www.femtechworld.co.uk/category/insight/)
*   [Events](https://www.femtechworld.co.uk/femtech-events/)
*   [Newsletter sign up](https://7193aae6.sibforms.com/serve/MUIFAI-BmXqy8QifVOkqVrhN4D3vKWwTNBfWZnMjajz1RpV1QUAfJF4o3OCl9ITwOzlr5Txjvt7EJM8p9Ve8w_pYvK8DOJV0cM168xOYocnizbIkblbiTYii0CYFNGxKzSdfndBSig4vjjbisxYiR5cYVxmqUnoPgDiSy2hWpjzfzufGwJk43-RIzdGiVQHvRc0CnhI3aQzDEI2O)
*   [Awards entry](https://aspectpublishing.shorthandstories.com/femtechworldawards2026/)
*   [Contact us](https://aspectpublishing.shorthandstories.com/contact-us/index.html)
*   [Advertise](https://www.femtechworld.co.uk/advertise/)
*   [Podcast](https://open.spotify.com/show/6Cvms8srXKKEwiUo6q05d5?si=80920e33eeff456e)

Connect with us
*   [](https://twitter.com/FemTechWorld)
*   [](https://www.instagram.com/femtechworld/)
*   [](https://www.linkedin.com/company/femtech-world)

[](https://twitter.com/FemTechWorld)[](https://www.instagram.com/femtechworld/)[](https://www.linkedin.com/company/femtech-world)

[![Image 3: FemTech World](https://femtechworld.co.uk/wp-content/uploads/2021/11/femtech-white.svg)](https://www.femtechworld.co.uk/)[![Image 4: FemTech World](https://femtechworld.co.uk/wp-content/uploads/2021/11/femtech-white.svg)](https://www.femtechworld.co.uk/)
FemTech World
-------------

#### New app uses proven AI to fill gaps in menopause support

*   [Latest News](https://www.femtechworld.co.uk/latest-news/)
*   [Opinion](https://www.femtechworld.co.uk/category/opinion/)
*   [Insight](https://www.femtechworld.co.uk/category/insight/)
*   [Events](https://www.femtechworld.co.uk/femtech-events/)
*   [Newsletter sign up](https://7193aae6.sibforms.com/serve/MUIFAI-BmXqy8QifVOkqVrhN4D3vKWwTNBfWZnMjajz1RpV1QUAfJF4o3OCl9ITwOzlr5Txjvt7EJM8p9Ve8w_pYvK8DOJV0cM168xOYocnizbIkblbiTYii0CYFNGxKzSdfndBSig4vjjbisxYiR5cYVxmqUnoPgDiSy2hWpjzfzufGwJk43-RIzdGiVQHvRc0CnhI3aQzDEI2O)
*   [Awards entry](https://aspectpublishing.shorthandstories.com/femtechworldawards2026/)
*   [Contact us](https://aspectpublishing.shorthandstories.com/contact-us/index.html)
*   [Advertise](https://www.femtechworld.co.uk/advertise/)
*   [Podcast](https://open.spotify.com/show/6Cvms8srXKKEwiUo6q05d5?si=80920e33eeff456e)

*   [![Image 5](https://www.femtechworld.co.uk/wp-content/uploads/2024/11/92.8-FemTech-World-Banner-1.png)](https://kisacoresearch.com/events/whisusa?utm_source=femtech_world&utm_medium=affiliate&utm_campaign=92.8_femtechworld_banners) 
*   [![Image 6](https://www.femtechworld.co.uk/wp-content/uploads/2024/11/FemTech-World-x-WHW-USA-Website-Banner.png)](https://www.womenshealthweek.com/?utm_source=advocacy&utm_medium=ext_email&utm_campaign=whw-usa-26-femtech-world) 
*   [![Image 7](https://www.femtechworld.co.uk/wp-content/uploads/2024/11/92.8-FemTech-World-Banner-1.png)](https://kisacoresearch.com/events/whisusa?utm_source=femtech_world&utm_medium=affiliate&utm_campaign=92.8_femtechworld_banners) 
*   [![Image 8](https://www.femtechworld.co.uk/wp-content/uploads/2024/11/FemTech-World-x-WHW-USA-Website-Banner.png)](https://www.womenshealthweek.com/?utm_source=advocacy&utm_medium=ext_email&utm_campaign=whw-usa-26-femtech-world) 

[![Image 9](https://www.femtechworld.co.uk/wp-content/uploads/2025/11/Have-you-entered-yet.jpg)](https://aspectpublishing.shorthandstories.com/femtechworldawards2026/)

### [News](https://www.femtechworld.co.uk/category/news/)

New app uses proven AI to fill gaps in menopause support
========================================================

![Image 10](https://secure.gravatar.com/avatar/92c0856e5835dbbeee4ffb6447e8deefa04043d01c7c5769f3552f11777b49be?s=46&d=mm&r=g)

Published

8 months ago
on

April 8, 2025

By

[News Desk](https://www.femtechworld.co.uk/author/news-desk/ "Posts by News Desk")

![Image 11](https://www.femtechworld.co.uk/wp-content/uploads/2024/08/AdobeStock_585697535.jpeg)

### **Belong.Life, the developer of AI-driven patient education and engagement solutions, has announced that its AI Health Mentor SaaS solution has been selected to power _Ask Elina_, a new app designed to help women effectively navigate[perimenopause](http://www.femtechworld.co.uk/menopause/insight-perimenopause-menopause-and-your-mental-health-and-wellbeing/) and menopause.**

Powered by Belong’s AI technology, _Elina_ is a highly trained health coach who helps users navigate the overwhelming influx of information about menopause.

_Elina_ gets to know users personally and provides evidence-based insights and guidance tailored to their needs while helping them manage symptoms and understand their options.

[![Image 12](https://www.femtechworld.co.uk/wp-content/uploads/2025/03/menopause.gif

*[... truncated, 28,260 more characters]*

---

### Speakers - Women's Powership Symposium
*2,721 words* | Source: **GOOGLE** | [Link](https://womenspowership.com/speakers/)

![Image 1: BethMosk](https://womenspowership.com/wp-content/uploads/2025/08/BethMosk.jpg)

Beth Moskovic
-------------

Beth Moskovic is a Relationship Coach for women and couples and a Mikvah educator. A native Montrealer, Beth received her Master’s Degree in Educational Psychology from McGill University in 2003 and in 2019 her coaching certifications in Marriage and Intimacy and Mikvah education.

As a Marriage and Intimacy Coach, Beth guides women and couples to take on healthier habits in themselves and their relationship. Beth is also very passionate about health and wellness, particularly in nutrition, movement, and bringing less toxins into daily living. She is always learning, growing, and sharing best practice with her clients. Most of her training and experience comes from being a wife and mom of six beautiful children.

![Image 2: carly](https://womenspowership.com/wp-content/uploads/2025/08/carly.jpg)

Carly Flam
----------

Carly Flam is a partner at Robinson Shepard Shapiro’s Family Law Group. Her practice focuses on separation and divorce for married and unmarried spouses, custody, child and spousal support, asset partition, matrimonial regimes, unjust enrichment, and pre-marital planning. She has developed a particular expertise in navigating high net worth divorce cases involving hidden income, trusts and other complex financial structures, as well as cross-border issues and jurisdictional disputes.

Carly is a passionate advocate, a strategic thinker and a pragmatic problem- solver. While she is recognized for her litigation skills, Carly is also focused on providing clients with the support, empathy and guidance they need during challenging moments.

![Image 3: 4](https://womenspowership.com/wp-content/uploads/2025/08/4.jpg)

Dr. Manon Charlebois
--------------------

Dr. Charlebois obtained her medical degree in 2002 and completed her residency in obstetrics and gynecology at the University of Montreal. In clinical practice since 2008, she turned to integrative medicine in 2015 and became a licensed medical acupuncturist recognized by the Collège des médecins du Québec in 2021.

She trained in medical acupuncture at Harvard and in electro-acupuncture and neurofunctional approaches at McMaster University. She is pursuing certification in Japanese acupuncture in New York and training in chronic pain management at McGill University.

Dr. Charlebois combines her expertise in gynecology, obstetrics, medical acupuncture, and neuroscience to offer a holistic approach to health. She favors a collaborative approach with her patients, focusing on prevention, mind-body balance, and disease treatment. By taking into account the uniqueness of each woman, she aims to maintain overall well-being, addressing individual needs while fostering physical and emotional harmony.

![Image 4: Vicky-1](https://womenspowership.com/wp-content/uploads/2025/09/Vicky-1.jpg)

Dr. Vicky Tagalakis
-------------------

Dr. Vicky Tagalakis is Associate Chair of the Department of Medicine at McGill University and Physician-in-Chief of Medicine at the Jewish General Hospital in Montreal. She is a Research Scientist in the Centre of Epidemiology and Community of Studies, Lady Davis Institute for Medical Research, Jewish General Hospital. Her clinical interest is in the diagnosis and management of venous thrombotic disorders and her principal research interests focus primarily on the epidemiology of venous thrombosis primarily in cancer patients. She has held over $10 million in grants and authored more than 100 peer-reviewed publications. She co-leads the CanVECTOR Population and Health Services Research Platform, a national network that uses large scale administrative databases to conduct population-based studies on quality of care and effectiveness related to the management of venous thromboembolism. She was the Director of the General Internal Medicine residency program at McGill from 2003-2016. During her tenure, she led transformative changes in the training program with the establishment of a two-year residency program at McGill in 2003 and helped lead the establishment of the national standards of training for the specialty of General Internal Medicine in 2015. Between 2016 and June 2023, she led the academic mission of the McGill University Division of General Internal Medicine which includes over sixty highly accomplished faculty members from across three hospitals, comprising of national and international renowned researchers, teachers and educators, quality improvement leaders, and clinician innovators. She has been recognized for her teaching and mentorship having received the Jewish General Hospital Department of Medicine Teacher of the Year award and the McGill Department of Medicine Mentor of the Year award.

![Image 5: Elizabeth](https://womenspowership.com/wp-content/uploads/2025/08/Elizabeth.jpg)

Elizabeth Wasserman
-------------------

Elizabeth Wasserman is co-founder of Ask Elina, an AI mentor and commun

*[... truncated, 14,619 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Belong.Life's Advanced AI Technology Selected to Power New ...](https://www.prnewswire.com/news-releases/belonglifes-advanced-ai-technology-selected-to-power-new-menopause-support-solution-302421825.html)**
  - Source: prnewswire.com
  - *Apr 7, 2025 ... "Perimenopause can be an incredibly lonely and frightening time for many women," said Elizabeth Wasserman, Co-Founder of Ask Elina....*

- **[A Canadian tech company is using AI to help woman navigate ...](https://globalnews.ca/news/11127597/a-canadian-tech-company-is-using-ai-to-help-woman-navigate-menopause/)**
  - Source: globalnews.ca
  - *Apr 14, 2025 ... Co-founders Nathalie Belanger, 56 and Elizabeth Wasserman, 50, were inspired by their own experience with menopause to create Ask Eli...*

- **[New app uses proven AI to fill gaps in menopause support](https://www.femtechworld.co.uk/news/new-app-uses-proven-ai-to-fill-gaps-in-menopause-support-mnp25/)**
  - Source: femtechworld.co.uk
  - *Apr 8, 2025 ... Podcast. Connect with us. FemTech World. New app ... Elizabeth Wasserman is Co-Founder of Ask Elina. She said ......*

- **[Speakers - Women's Powership Symposium](https://womenspowership.com/speakers/)**
  - Source: womenspowership.com
  - *Elizabeth Wasserman is co-founder of Ask Elina, an AI mentor and community ... Podcast, Founder of Bliss Essential Oils (BlissEssential.co), Course .....*

---

*Generated by Founder Scraper*
