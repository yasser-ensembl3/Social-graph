# Anton Morrison

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Mogul
**Durée dans le rôle** : 3 years 5 months in role
**Durée dans l'entreprise** : 3 years 5 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Technology, Information and Media

## Résumé

Founder | Design Innovation Consultant | AI Enthusiast

I’m the founder of Mogul, a design innovation consultancy that helps organizations unlock their digital potential through cutting-edge solutions and transformative learning experiences. With broad expertise across industries like travel, pharmaceuticals, and higher education, I specialize in bridging the gap between strategy and execution, ensuring impactful and lasting outcomes.

I thrive on solving meaningful problems, whether it’s helping a travel agent training platform boost engagement, designing intuitive tools for a therapeutic company, or guiding businesses through the power of AI-driven innovation. My approach combines sophisticated UX/UI design, low-code technologies, and AI enhancements to deliver results quickly without compromising on quality.

What I Do Best
Explore: Uncover and validate exciting ideas by understanding user needs, creating product roadmaps, and crafting clear missions.
Create: Design elegant digital products tested with real users, delivering experiences that delight and exceed expectations.
Grow: Build dynamic design systems, toolkits, and training programs to empower teams and foster design maturity.

Speaking & Thought Leadership
I’m passionate about sharing insights on design, innovation, and AI. From addressing UX Theatre at events to leading workshops on integrating AI into workflows, I aim to inspire others to harness technology for impactful change.

Let’s Connect
If you’re looking for a collaborator to bring clarity to complexity, supercharge your team’s design capabilities, or explore the potential of AI in your organization, let’s chat! 🌟

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABaJvGIBW8cANXppY2-YDes8eUJ2-2HNoB8/
**Connexions partagées** : 14


---

# Anton Morrison

## Position actuelle

**Entreprise** : Mogul

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Anton Morrison

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394104495825121280 | Text |  |  | Job alert to work with the very talented Xania! | 0 | 0 | 0 | 3w | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.018Z |  | 2025-11-11T20:11:27.623Z | https://www.linkedin.com/feed/update/urn:li:activity:7393784475614228481/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387181793327620096 | Article |  |  | 🤔 A quick user testing hack using OpenAI Atlas Agent Mode

You can run small tests using Agent Mode in Atlas — and in a few minutes it surfaces subtle usability issues and accessibility quirks you might have missed.

It’s fast, simple, and gives you a some insight into usability improvements — like having a mini User Testing session assistant run a test for you. 

📽 Here’s it in action: 👉 https://lnkd.in/eZjT9xu9

If you’re building or managing a site, try running one through Agent Mode. You might be surprised what it finds.

#UX #UserTesting #AI #Atlas #DesignInnovation #openai 

ps. User Researchers please don't come at me i am not saying this will replace human research

pps. This was posted using Atlas Agent Mode as well...  😂 | 4 | 1 | 0 | 1mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.019Z |  | 2025-10-23T17:43:06.730Z | https://www.loom.com/share/2b632b7e7e3c4a979e05cccf4ddc4896?sid=43edcfe3-e231-4078-a562-e40f811195e5 |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386780735585546240 | Article |  |  | The Confusion of the Day

OpenAI just launched their shiny new browser, Atlas, with all the expected hype — “game changer,” “future of browsing,” you know the headlines.

But here’s the twist: when you use ChatGPT.com inside Atlas, it actually has fewer capabilities than when you use it in any other browser.
Specifically — no Sources tab.

Let that sink in: OpenAI’s own browser offers less functionality for their own product than Chrome does. 🤯

I get it — shipping fast is part of the game. You launch, learn, iterate... but this seems like a wild thing to do.

Obviously everyone’s fighting for where users interact with LLMs. But releasing half-baked experiences and hoping users stick around while you figure it out? 

P.S. — plus Atlas doesn’t even have split screen. Come on! 😅

#UX #AI #OpenAI #ProductDesign #HumanCenteredDesign #DontMakeMeThink | 9 | 0 | 0 | 1mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.019Z |  | 2025-10-22T15:09:27.113Z | http://chatgpt.com/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7385664781099384832 | Article |  |  | While everyone’s debating the AI bubble and drowning in AI-generated slop, Google DeepMind just reminded us why this technology actually matters.

Their Cell2Sentence-Scale 27B model didn’t just analyze existing cancer research—it predicted an entirely new therapy approach, then proved it works in the lab. 

They screened over 4,000 drugs and identified silmitasertib as a “conditional amplifier” that makes cold tumors visible to the immune system. The result? A 50% increase in antigen presentation.

Here’s what got me: 70-90% of the drug hits were completely new discoveries, never reported in scientific literature before.

This isn’t a one-off. Google’s been building toward this for a decade—from DeepVariant helping complete the human genome in 2015, to AlphaMissense predicting disease variants, to DeepSomatic catching cancer mutations other methods miss.

We’re seeing real breakthroughs in cancer research and fusion energy because of AI. These are the stories we need more of—not another AI chatbot or generated marketing copy. This is AI actually solving hard problems that matter.

Read more: https://lnkd.in/etfKvAr9 | 11 | 0 | 0 | 1mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.020Z |  | 2025-10-19T13:15:02.830Z | https://blog.google/technology/ai/google-gemma-ai-cancer-therapy-discovery/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7381385109054324736 | Article |  |  | Almost a fifth of young UK adults are using AI to design holidays — who else sees travel planning changing fast? ✈️🤖

Is it surprising? — people already lean on ChatGPT for inspiration, not really. 

Was also interested to read about Spains new campaign - I wonder how AI could help destinations like Spain promote slower, longer stays and nudge behaviour toward sustainable tourism. 

An exciting space to help people be better travelers.

👉 Read it here: https://lnkd.in/eUyNqJ4V

#AI #TravelTech #Tourism #Sustainability #TravelIndustry | 6 | 2 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.021Z |  | 2025-10-07T17:49:09.502Z | https://www.theguardian.com/travel/2025/oct/07/uk-adults-ai-design-holiday-package-holiday-travel-abta |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379895953153024000 | Text |  |  | 🧭 Perplexity made its AI browser free… will it be future of the web?

Perplexity’s Comet puts an assistant beside the page. It answers questions, summarizes, and helps you move through a site in real time. The free move makes it easy for more people to try that idea. 

The interesting part isn’t just “AI in a browser.” It’s the question behind it: how will we find and explore the web next?

🕸️ The web we have today
I love the web. I’ve worked on it for most of my career. But we did make it messy. Browser quirks. Heavy pages. Accessibility shipped last. On top of that, the business model pushes everything toward ads, SEO tricks, and engagement hacks. It’s still an amazing medium, but it can be a slog.

🧱 Websites as objects
There’s was an interesting idea posted by Tobias van Schneider that websites might turn into “objects.” Little units you can pick up, reuse, and personalize. We’ve tried versions of this before with components and atomised websites. It worked sometimes, and sometimes it didn’t. Personalization is hard, and context gets lost easily.

🧭 Findability vs discoverability
Findability: how easy it is to get to a specific thing when you already know what you’re after.
Discoverability: how easy it is to bump into valuable things you didn’t know you needed.

The current web is still pretty good at both. Search helps with findability. Links and browsing still drive discovery when we let them. Nice ascetics makes it enjoyable.

📡 Why feeds and pure chat aren’t enough
Feeds take control away. The algorithm drives. You follow.
Chat is great when you have a clear goal. “Find X, do Y.” But it’s not the best place to wander, poke around, and stumble on something surprising.

🔮 So what’s next?
Sidecar chat and “browser agents” feel promising, but something is still off. The old PDF‑viewer analogy comes to mind: it’s like placing a book in the middle of an old TV. The form hasn’t quite met the medium yet.

If not feeds and not pure chat, what shape supports both findability and discoverability while keeping us in control? 

Maybe it looks like:
- Clear source trails and live citations so we can verify as we go (Transparency)
- Page‑aware summaries that respect the structure a writer designed (Author Structural respect)
- Background workflows that reduce tab chaos without hiding what’s happening (Visible autonomy)
- Accessibility and device agnostic by default, not as an afterthought (Obvs)
- Actions should be undoable or safely previewable before they commit (Reversibility)

I don’t know the final answer Yet. But I know the questions we ask now will shape what we build next. Maybe it will be a time to fix some thing. | 6 | 1 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.021Z |  | 2025-10-03T15:11:47.068Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7379500930876010496 | Text |  |  | 🎬 From Vibes to Storyboards

If your AI keeps “improvising,” give it a storyboard of frames, not single vibes.
Storyboards beat sticky notes because they force the flow:

Frame 1 — Setup
- Who’s the user?
- Goal in one sentence
- Inputs and constraints

Frame 2 — Conflict
- Expected errors and edge cases
- Branches and guardrails
- What must never happen

Frame 3 — Resolution
- Output shape or schema
- Done criteria and quick tests
- Handoff or fallback path

Example (auth flow):
1. Setup: “User signs in with email + JWT. 3 attempts max.”
2. Conflict: “On fail → log, exponential backoff, show friendly message, suggest reset after 3.”
3. Resolution: “Return {token, role, expires_at}. Tests pass: jwt.verify, role check, rate limit.”

Why it works
- Removes guesswork
-  Keeps sequence and state visible
- Produces first‑attempt code instead of first‑draft chaos

Try this today ✅
- Take one vague prompt and sketch 3 frames
- Add 1 failure branch and a done check
- Paste the frames above your prompt and run

This isn’t the complete side of Context Engineering—just the mindset. Next, I’ll talk about the Four Pillars foundation.

#ContextEngineering101 #AIEngineering #DeveloperProductivity #CodingBestPractices | 5 | 0 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.022Z |  | 2025-10-02T13:02:06.418Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7378933343033126912 | Article |  |  | OpenAI launching Sora2 App ("social media AI?") seems strange when so much talk of AI not producing the ROI enterprise is looking for…

The reason I say that is just yesterday I watched a compelling take from Scott Galloway that today’s AI funding is getting circular, which could leave OpenAI vulnerable to bubble bursting. https://lnkd.in/e7GwBhrp

Then OpenAI drops Sora2 — a fun "social" platform — but it doesn’t obviously map to enterprise ROI. More of a distracting way to use power of AI that productive... I am sure apps like Sora2 can be useful labs for engagement and improve video capabilities, but this must also burn capital and leadership focus. 

So is Sora2 a smart strategic exploration, a new platform that will have 100 million users in a month, or a side project that is going to fuel the fire of AI bubble... 

#AIInvestment #Sora2 #OpenAI #TechBubble #AIStrategy #AIProductivity #FutureTech #AIEconomy | 1 | 1 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.022Z |  | 2025-09-30T23:26:42.931Z | https://www.youtube.com/watch?v=Oeepx2ZLrCA |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7378768677929709568 | Text |  |  | 🎯 Vibe Coding vs Context Engineering — Kicking off the series

If your last feature took 15 prompts to land, you’re gambling with your time. 🎰 
This post kicks off the Context Engineering 101 series.

Vibe Coding is great for exploring ideas, spiking approaches, and rapid experiments. Keep it in your toolkit. But when it’s time for production code, you need a Context Engineering mindset and process.

- Vibe Coding: “Implement auth.”
Result: 20 iterations. 3 hours. Still broken. 😵

- Context Engineering: “Auth flow, JWT rules, error states, tests, integration points, test cases.”
Result: Works the first time. Every time. ✨

Here is where it helps:
- 10x fewer iterations
- 100x less frustration
- Hours saved per feature
- Unified code style

Real-world note: We’ve been migrating a large production system using Context Engineering. The approach scaled, reduced random failures, and improved review velocity.

Stop hoping. Start engineering. 🚀

#ContextEngineering101 #ContextEngineering #AIEngineering #FutureOfCoding #DeveloperProductivity | 6 | 0 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:32.023Z |  | 2025-09-30T12:32:23.711Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7377304099312074752 | Article |  |  | 🧑‍💼 Which jobs are AI really getting good at?

OpenAI just released GDPval, their new benchmark that tests AI models against 1,320 real-world tasks across 44 occupations. Think of it as the SATs for AI, but instead of algebra, it’s legal briefs, nursing care plans, engineering designs, and sales forecasts.

What stood out to me was the sector-by-sector results:

⚙️ Manufacturing engineers: AI can design complex jigs in hours instead of days.

⚖️ Lawyers: Models draft briefs that follow arguments well, but still stumble on nuance.

🩺 Nurses: AI can generate detailed care plans, but reviewers preferred the human versions for bedside realism.

📈 Sales managers: Forecasts came fast and cheap, though sometimes with formatting quirks.

💻 Software developers: Strong performance in bug-fixing and building small features, though prone to overconfidence in tricky cases.

Across industries, the takeaway is similar: AI delivers drafts at 100x speed and cost efficiency, but humans still win on accuracy, judgment, and instruction-following.

The interesting part isn’t whether AI “takes jobs”—it’s how different professions will be reshaped. Experts reviewing and refining AI outputs often beat starting from scratch. In other words, the future of work looks less like replacement and more like hybrid workflows.

From my own work, AI now handles much of the early lift 🚀. I can spin up prototypes with UX Pilot and Vibe coding quickly ⚡, and even a larger content-engineering migration is running smoother than expected 🔧. I’ll share more concrete examples soon. ✨💡📊

For those curious, image of the report shows win rates by occupation—it’s interesting to see Claude nearly outperformed ChatGPT across the board.

📑 Full research: https://lnkd.in/eZVrzqMm

#AI #FutureOfWork #OpenAI #GDPval #Productivity #BuildInPublic | 5 | 0 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.450Z |  | 2025-09-26T11:32:40.958Z | https://cdn.openai.com/pdf/d5eb7428-c4e9-4a33-bd86-86dd4bcf12ce/GDPval.pdf?utm_source=www.theneurondaily.com&utm_medium=newsletter&utm_campaign=here-s-how-good-ai-is-at-your-job&_bhlid=fec774187cc962d469aa2471b2754eb0d42785bb |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7371274592067330048 | Video (LinkedIn Source) | blob:https://www.linkedin.com/76488df9-17d5-41c7-a8e1-bb2c893bf299 | https://media.licdn.com/dms/image/v2/D4E05AQE7dOMToUhU5Q/videocover-high/B4EZkuovOyKgCM-/0/1757424099584?e=1765782000&v=beta&t=6Din0sVikfZF5CPFufvXTgYjzumyxdn189pyI43n4Dk | If I was in london this weekend I would go to this! | 5 | 0 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.451Z |  | 2025-09-09T20:13:34.408Z | https://www.linkedin.com/feed/update/urn:li:activity:7371170973313839104/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7370807437588852736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHz7fNdnvw55Q/feedshare-shrink_800/B4EZkpeTr2GwAk-/0/1757337435391?e=1766620800&v=beta&t=N5wYgIgwYkxHsfUOsH3PlBu8ZAxpH9758oDfWij8Tgk | ⚡ Coding a Morning Briefing in a Café ☕📖💡

Yesterday morning I dropped my 6‑year‑old off at a birthday party—the first time I didn’t need to stay. That left me with an unexpected block of three free hours I hadn’t planned for. 🎂⏳🙌

So I found a great café, ordered a cappuccino, opened my laptop, and—with a little help from Claude Code—built a Python script that now gives me a morning briefing straight into my Notion inbox. ☕💻📝

Here’s what it does:

1. 📡 Pulls articles from a few RSS feeds I chose
2. 📊 Scores each article 1–100 against criteria I set per source
3. 🎯 Picks anything 80+
4. ✍️ Writes quick summaries in a tone I defined
5. 🔊 Generates audio for those summaries (so I can listen on the school run)
6. 📰 Creates a daily page with those items 
7. 📥 Sends it to Notion as my daily note
8. ⏰ Schedules it for 6am on weekdays via GitHub Actions

Normally I’d reach for Make.com or n8n, but I’ve been enjoying pure Python lately—and with an AI code assistant, the idea went from sketch to working in the time it took to finish a coffee. ☕️⚡🐍

For me, that’s the power of AI-assisted coding: taking a simple idea and making it real in a Sunday morning sprint. I am going take this to the next stage and share it more broadly 🚀🔧📲

#BuildInPublic #Python #Notion #Automation #GitHubActions #AI #AIAssistedCoding #Productivity | 14 | 1 | 0 | 2mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.452Z |  | 2025-09-08T13:17:16.101Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7364427119554088960 | Article |  |  | Is it just me or is there a new AI anouncement every week but no big picture vision… 🤔✨📡

In 1987, Apple released this Knowledge Navigator video.* It wasn’t about a product launch—it was about a possible longterm future. 

A vision. 👓🚀🌍

Fast forward to today and most AI “demos"—Apple Intelligence 🍏, Rabbit 🐇, Pin 🧷, OpenAI (🥱😉)—are presenting a "working" product. They often feel like smoke and mirrors, focused on the short-term product releases that are coming soon, not big-picture imagination. 

Worst of both worlds. 🎭⚡🔍

The power of visionary demos is that they give us something to aim for. A vision, a flag in the sand. As we get closer, the flag can move, but it’s something we can all aim towards and get excited about. 

Innovate towards. 🏁📱🔥

Where are the demos that spark imagination today? That show us how AI could transform education, improve healthcare, or change how society works? 🔮📚💉

Maybe the most important demo isn’t the next release—it’s the one that helps us see a better horizon… or maybe AI companies don’t really have a vision. 🌅🤖❓

👉 Watch the Knowledge Navigator here: 

https://lnkd.in/eGk6vBa7

 🎥📼👀

#AI #AIDemos #VisionNotFeatures #SmokeAndMirrors #FutureThinking #AIBubble #AISavesTheWorld #FourDayWeekDream #AIBobble #BetterHorizons #NotAnotherGadgetDrop #RobotNotRobot #LOLbots #NextBigThingMaybe #AIAllDay #PitchPerfectAI #FlagInTheSand #WhatEvenIsThisDemo #AIFutureFun #ArtificiallyHilarious

* I first learned about this video and the importance of a vision in a Jared Spool UX Session, he has them every Monday and well worth it! | 1 | 0 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.453Z |  | 2025-08-21T22:44:09.741Z | https://www.youtube.com/watch?v=umJsITGzXd0 |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7363938660028674050 | Article |  |  | Pitching with AI ✨💡🚀

This morning I created a flood of ideas for a pitch in hours—not days. I felt excited and empowered to get my thoughts onto the screen. Hats off to UX Pilot AI and Adam for creating the missing Figma AI plugin 🎨🤖👏

🌍⚖️🖌️ Preparing a pitch design has always been a balancing act. In the ad world, you’d never show up without something to wow. In UX, purists argue you shouldn’t design before research. 🔎📊🧐

📚💭🔥 For years I’ve sat somewhere in between: prove your process with case studies, but also share fresh ideas that get the client excited. ✨🙌💡

🕒⚡🔄 The challenge has always been time. Too often, rushed design work in pitches leads to weaker output. But AI is flipping this. I was able to take dozens of rough ideas and quickly turn them into mocks. They’re not final answers—but they help a prospect see the thinking, not just hear about it. 👀💻🎯

🌈💪🤝 In the end, I think a pitch is about sparking confidence and imagination. And maybe, just maybe, a mockup is worth more than a thousand slides 😉📊✨

#AI #UXDesign #DesignThinking #Innovation #Figma #PitchProcess #AIinDesign

https://lnkd.in/eNWKx3Sa | 13 | 1 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.454Z |  | 2025-08-20T14:23:11.915Z | https://www.loom.com/share/a77a7893351f47e6acaf1484b54d770d?sid=1d000767-c73d-4191-adfe-7fdcee514912 |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7363280904548405249 | Text |  |  | This looks like awesome opportunity! | 1 | 0 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.455Z |  | 2025-08-18T18:49:30.788Z | https://www.linkedin.com/feed/update/urn:li:activity:7363250042415001600/ | https://www.linkedin.com/jobs/view/4285967222/ | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7363162588714606593 | Article |  |  | I found this article super interesting calv.info as an insight for how OpenAI operates 👀.

Wild to think Codex was built in just 7 weeks. A small team (~8 engineers, ~4 researchers, 2 designers, 2 GTM and a PM) went from first line of code to a shipped prodcut.

I was initially underwhelmed by Codex but they are clearly approaching it with the long game in mind. More designed to work almost like a co-worker—you give it a task, it goes off and does the work, then comes back with results.

From my own experience, Codex shines most after the “creative coding” bit—things like adding Storybook, writing tests, refactoring code, removing technical debt more on the unglamorous side of coding.

BUT as the models get better, this feels like the direction things are heading: humans keep the creative spark, while AI takes care of the heavy lifting around it.

👉 Worth a read: https://calv.info/

#AI #OpenAI #Codex #DeveloperExperience | 0 | 0 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.456Z |  | 2025-08-18T10:59:22.095Z | https://calv.info/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7361835812906233856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGR4jQRDm1K3Q/feedshare-shrink_800/B4EZip.qVRGUAg-/0/1755198433342?e=1766620800&v=beta&t=Ok_OTPRFvXdRGN_o6GyiVYai_a4clQoPew0q9Swp0cs | 💡 AI in Design: Faster Starts, Trickier Finishes? 🤖 🎨

With AI, the messy, tangled part of design often shifts.

Without AI, the complexity is front-loaded 🌀 — research, exploration, ideation — before the path becomes clearer 🛤️.

With AI, that early stage feels smooth ✨. You get to “an answer” faster ⏩ and might think, “We’ve cracked it!” 💥

But the real twists can appear later 🔄, as you move from concept to reality 🚀 — uncovering what AI missed 🕵️‍♂️, where assumptions crept in 🧐, and where human context still matters ❤️.

I’m not saying don’t use AI 🙅‍♂️🤖 — just know its limitations ⚠️. Use it as part of a solid, traditional process 🛠️, not just as a shortcut to go faster 🏎️💨.

Have you experienced this “late-stage tangle” with AI in your process? 💭

#AI #DesignThinking #UXDesign #ProductDesign #ArtificialIntelligence #Innovation #DesignProcess #AIDesign #HumanCenteredDesign #TechTrends #CreativeProcess #DigitalInnovation #FutureOfWork #UXUI #DesignLeadership | 12 | 0 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.457Z |  | 2025-08-14T19:07:14.092Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7361370983225511936 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGAphVPHxrZxA/feedshare-shrink_2048_1536/B4EZijX5opGYAo-/0/1755087609336?e=1766620800&v=beta&t=SvJVfiReG6o3sLpNf_9xA3-EclR0yiiKPnXXy3Y9dmE | 🔥 ChatGPT Brings Back GPT-4o — The Crowd Has Spoken 📢

Sometimes, change is hard. We’ve seen it before — when Facebook redesigned its News Feed, when Instagram moved icons, or when Microsoft replaced the Start Menu. 

People push back. And OpenAI just learned this lesson again.

After GPT-4o disappeared from the model list, community demand quickly brought it back. 😆 Early reports suggest a broken “router” on day one of GPT‑5 caused much of the trouble — but either way, the crowd has spoken...

Sure, they could have handled the change better. But here’s the interesting update which for me makes a big improvement. 

A small tweak to how models are described in the dropdown could have saved a lot of confusion. 📝✨

💡 UX takeaway: Before you overhaul an experience, check if clarity alone can solve the problem. The simplest change might be the one your users notice (and appreciate) the most.

#AI #UXDesign #ChatGPT #ProductDesign #GPT4o #UserExperience #UXTips #ProductManagement | 4 | 0 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.457Z |  | 2025-08-13T12:20:10.060Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7360419460723134464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGUAiT4bC-Rog/feedshare-shrink_800/B4EZiV2flIGoAg-/0/1754860747791?e=1766620800&v=beta&t=77lmEkS8HLf0htR5vf6R3nzk1y9x5LBFVJXKxKCgMC8 | What a week! 🚀

Started it off giving my Vibe Coding talk and as you can see from the picture, the love I have back for making things is real. Surprised by how well the talk went down and how many people have reached out to learn more about my methods and tools... I should probably create a playbook 🤔

Huge shout out to all the other amazing speakers: 💪 Andrew Kumar Shannon Lal Chloé Crevier Jean-Luc SansCartier Gabriel Laliberte Houda Kaddioui Allison Saunders Suzanne Dergacheva Maria Parra Martin Anderson-Clutz Michele Ann Jenkins Fran Wyllie Pierre-Paul Lefebvre Simon Morvan Dust Leblanc John Doyle Shane Collier Joyce Peralta Maxime Dieuzaide

One thing that struck me from all the conversations - even though AI is touching everything these days, it still feels like we're actually in the early days. 

The potential for what's coming next is mind-blowing.

Big thanks to Evolving Web for putting together such a fantastic EvolveDigital + EvolveDrupal Summits event and bringing this community together! 🙏

#EvolveDigital #VibeCoding #AIAssistedDevelopment #Community #EvolvingWeb | 52 | 3 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.458Z |  | 2025-08-10T21:19:09.417Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7360066072701534208 | Text |  |  | ChatGPT 🏆 won the chat interface.
But Claude Code 💻 won the coding battle.

I use AI a lot—and I try to test things as thoroughly as I can—but sometimes you’ve got to pick a lane.

Until two months ago, I was a daily ChatGPT user. Then I switched to Claude, and honestly, it’s been… 😬 frustrating.

With ChatGPT 5 🚀 and my first few days of using it, I’m back. (Although—it’s too fast ⚡… my thoughts on that later.)

For coding, though? Claude Code is incredible. 💡

I’ve also been experimenting with turning Claude Code into my full AI assistant—taking my rambling Scottish accent 🎙️ and turning it into a clear weekly schedule 📅, answering emails 📧, organising my calendar 🗂️…

More on that soon. 👀

#AI #ArtificialIntelligence #Productivity #ChatGPT #Claude #ClaudeCode #AIAssistant #NoCode #TechTools #FutureOfWork | 8 | 3 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.459Z |  | 2025-08-09T21:54:55.147Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7359556740780072962 | Text |  |  | 🚀 GPT-5: Mostly Ending Model Choice Paralysis 🧠✨

If you’ve just opened ChatGPT-5, you’ve probably seen the model picker 🎛️ has vanished— the old list of names like o1, o3, o3-mini, 4o that sound more like stormtroopers 🤖 than helpful options. Picking one can feel a bit like choosing wine 🍷 when you kinda know what you want but can’t decode the menu.

With GPT-5’s Unified System + Adaptive Reasoning 🛠️⚡, the AI now adjusts its “thinking depth” on the fly—going deep 🏊‍♂️ for complex tasks, staying light 🏃‍♀️ for simple ones—without you having to constantly toggle models.

👉 It’s not 100% solved. The dropdown’s still there 📜, but it matters a lot less. 
This feels like moving from manual gears 🚗 to automatic: you can still switch, but you probably won’t need to.

💡 Does it matter? YES :

 ⏱️ Faster, smoother workflows—no stopping to “pick the right model”

 🎯 More focus on the work, less mental overhead

 🔮 A glimpse of AI orchestration becoming invisible

It’s early days—still to be tested in the wild 🌍—but this is the first step towards a future where model choice is something you never think about again.

#AI 🤖 #GPT5 🚀 #ChatGPT 💬 #AdaptiveReasoning 🧠 #Productivity ⚡ #UX 🎨 #AIworkflow 🔄 | 13 | 1 | 0 | 3mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.460Z |  | 2025-08-08T12:11:00.954Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7357884643615883264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgwdIL9aVWkQ/feedshare-shrink_800/B4EZhx1FuSHEAg-/0/1754256400038?e=1766620800&v=beta&t=pNmd5fkkG8BCsY0k4YpHfiocpUMqHsKRZjZGdEPAIw4 | Found this in an old sketchbook - a Santa Monica tourism map interface I probably pitched years ago! 📝✨

I love sketching ideas by hand first - there's something about pen and paper that helps you think differently. But being able to immediately bring those sketches to life? 

That's the magic of vibe coding.

That sketch sitting in my drawer for who knows how long? Now I can turn it into a working prototype in just 10 minutes. 

This is one of the workflows I'll be demonstrating in my Vibe Coding 101 talk - from sketch to screen in record time.

Still have discount codes available - DM me!

👉 https://lnkd.in/eqiGnBE4

#EvolveDigital #VibeCoding #SketchToCode #RapidPrototyping #AIAssistedDevelopment #UXDesign | 20 | 0 | 0 | 4mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.461Z |  | 2025-08-03T21:26:41.924Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7356958822118170625 | Text |  |  | Website development have gone full circle and I’m not sure we ended up in the right place 🔄

Twenty years ago: Messy inline styles and table layouts
Fifteen years ago: CSS Zen Garden showed us pure separation of concerns - it was **bliss** ✨
Today: Tailwind brings us back to inline-style-like utility classes

Don’t get me wrong - React and complex toolchains absolutely have their place. If you’re building Gmail, you need that power.

But somewhere in the rush toward complexity, I lost my love for coding. The abstractions made simple things complicated and the power of CCS wasted…

Then AI coding brought me back. 💡 

Here’s what surprised me - even with AI assistance, I keep gravitating toward that CSS Zen Garden era simplicity. 

So I am creating a AI coding starting kit  that creates beautiful, semantic websites with pure CSS styling. No frameworks, minimum build steps, just elegant separation of structure and presentation.

This is one of the things I’m talking about in my Vibe Coding 101 talk - using AI to rediscover the web’s most beautiful principles.

👉 https://lnkd.in/eqiGnBE4
DM for discount codes! 🎫

#EvolveDigital #VibeCoding #CSSZenGarden #WebStandards #Simplicity | 20 | 3 | 0 | 4mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.462Z |  | 2025-08-01T08:07:48.878Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7356224435252600832 | Article |  |  | The challenge of preparing a talk on AI? 

Things move so fast that your presentation can be outdated before you even hit "save" 😅

Just spent this morning exploring Sub Agents in Claude Code and it could be...

dramatic pause 🥁🎭…

…GAME CHANGER 🤯🚀✨💥

The way you can define specialized agents with specific roles and contexts reminds me of the simple and logical approach CrewAI uses for agent orchestration. But this feels even more seamless - like having a whole team in your terminal.

Watching agents collaborate on complex tasks while maintaining their individual expertise? It's exactly the kind of workflow evolution I've been hoping to see.

Guess what? I'm squeezing this into my Vibe Coding 101 talk because it's too exciting not to share fresh insights with everyone. 🎤

Tickets are still available and I've got discount codes - DM me if you want to dive deep into the future of AI-assisted development! 🎫💌

👉 https://lnkd.in/eqiGnBE4

#EvolveDigital #ClaudeCode #SubAgents #VibeCoding #AIAssistedDevelopment #CrewAI | 8 | 0 | 0 | 4mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.463Z |  | 2025-07-30T07:29:37.405Z | https://www.evolvedigital.com/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7355495356060581888 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGybCxyBVKnyg/feedshare-shrink_800/B4EZg972TaGwAo-/0/1753385766787?e=1766620800&v=beta&t=Dg_P1uxwTfa-RnOVQJzdce0W3BuNQAla1OgDlb-46KY | Excited to be part of this lineup! 🚀

Looking forward to all these talks and especially excited to share my own session on **Vibe Coding 101** - a practical guide to getting up and running fast with AI-assisted development.

I’ll be covering the tools I use depending on what I’m trying to achieve, from rapid prototyping to production-ready apps. Over the last 4 months, vibe coding has brought more excitement to my career than anything in years - getting ideas from concept to screen in hours rather than weeks.

We’ll dive into context engineering techniques that make the difference between frustrating AI interactions and seamless collaboration. Plus some real workflows you can use immediately.

Fair warning: there will be zero discussion about “AI taking jobs” or doom scenarios. Just a practical guide to getting the most out of this incredible productivity multiplier.

Can’t wait to see everyone there! 
…if you fancy attending DM me for discount code

#VibeCoding #AIAssistedDevelopment #DeveloperProductivity
#EvolveDigital | 8 | 0 | 0 | 4mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.464Z |  | 2025-07-28T07:12:31.380Z | https://www.linkedin.com/feed/update/urn:li:activity:7354232948667076608/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7338253133116059659 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHeXe_8jJgWvQ/feedshare-shrink_800/B4EZda2VezG4Ak-/0/1749575884402?e=1766620800&v=beta&t=2KqJH5TJe0EQpvNJI9ZOO191d2oREH8g-LMVWTwnDas | “Dad, your phone is broke—I can’t see anything.” 🎧📱😵



— My 6-year-old this morning, trying to pick a song on the way to school

Funny… but also a bit of a design reality check. 😬

Apple’s new Liquid Glass UI is undeniably sleek — floating layers, frosted panels, beautiful blur effects. ✨🍏
But is it usable? 🤔
Is it accessible to everyone? 👀
Can your gran read the Control Center in sunlight? ☀️👵
What about users with visual impairments? Or just tired eyes? 🥱

Immediate thoughts from using it for a morning... feels cool but also cluttered, hard to navigate but that might be beta-bugs. And while there's a “Reduce Transparency” toggle ⚙️, it feels more like a bandage than a thoughtful feature.

I’ll live with the new UI for a while before making a final call...

#Apple #LiquidGlass #UXDesign #Accessibility #Inclusion #iOS26 #DesignMatters #HumanCenteredDesign #WWDC2025 #TechForGood | 9 | 2 | 0 | 5mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.465Z |  | 2025-06-10T17:18:05.085Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7337191508703342592 | Article |  |  | Really enjoyed this article and precisely the way i think of people dismissing AI as coding agent. 

This in particular is one of the reasons i fell out of love of coding years ago… 

“I can feel my blood pressure rising thinking of all the bookkeeping and Googling and dependency drama of a new project. An LLM can be instructed to just figure all that shit out. Often, it will drop you precisely at that golden moment where shit almost works, and development means tweaking code and immediately seeing things work better. That dopamine hit is why I code.” | 3 | 1 | 0 | 6mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.466Z |  | 2025-06-07T18:59:34.101Z | https://fly.io/blog/youre-all-nuts/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7332826429753102336 | Text |  |  | What Is the Future of Education in the Age of AI?

As a parent of a six-year-old living in Quebec, I’ve been thinking a lot about education lately—especially how it intersects (or fails to intersect) with technology, smartphones, and AI.

Recently, Quebec made headlines by banning phones from classrooms. On the surface, it seems sensible to reduce distractions and help children focus. But the more I reflect on it, the more I worry: are we stepping back at the exact moment we need to step forward?

A thought-provoking post by Isabelle Faulkner really stuck with me. She questioned whether banning phones truly addresses the deeper issue of digital distraction—or whether it simply avoids the harder, more necessary conversation about how to integrate technology meaningfully into learning environments. 

Then this morning, I read an article about Estonia’s approach to education and technology (https://lnkd.in/eQnxXfqG). Not only is Estonia not banning phones in classrooms—they’re actively working to provide both students and teachers with access to tools like OpenAI.

What really struck me, though, was learning that Estonia ranks among the top 10 education systems globally, and is the highest-ranked country in Europe.

I don’t have all the answers, so I’m left asking:

How can we help our children thrive in a world increasingly shaped by technology, if we don’t teach them how to use it well—early and often?

#education #AI #edtech #futureoflearning #AIineducation #digitallearning #21stcenturyskills #Quebeceducation #Estonia #parenting #technologyineducation #schoolreform #OpenAI #educationpolicy | 9 | 1 | 0 | 6mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.467Z |  | 2025-05-26T17:54:18.180Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7331728305919856642 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHNLMzrM2RUTw/feedshare-shrink_800/B56ZbutlpkGsAg-/0/1747761651279?e=1766620800&v=beta&t=38O1J5KKEbaBNp0Xpiy_YT7e9yXC9GzVKCbEdx21a2s | This is an excellent report on AI & Design in the real world! Well worth a read... 

This insight resonated a lot, as I think AI gives you "things" so quickly that you can get fooled into thinking your job is done. However, when it comes to the nitty-gritty of final delivery, you still need the time to make the thing right. 

"Exploration is AI’s sweet spot.
Teams are turning to AI most in the early phases of their workflow: research, ideation, and strategy. 84% use it occasionally or regularly during Exploration, compared to 68% in the Creation phase and 39% during Delivery." | 2 | 0 | 1 | 6mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.467Z |  | 2025-05-23T17:10:45.056Z | https://www.linkedin.com/feed/update/urn:li:activity:7330643689565773824/ |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7327457525761536000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF29thyfBGU-w/feedshare-shrink_800/B4EZbBbwsyGQAg-/0/1747002010451?e=1766620800&v=beta&t=UMNNBDrUJxAA970BtUvttgXoD7MYdkVmrgmSYfAndag | Sunday afternoon vibe coding a game my six old designed… #vibecoding #gamedesign | 42 | 5 | 0 | 6mo | Post | Anton Morrison | https://www.linkedin.com/in/antonmorrison | https://linkedin.com/in/antonmorrison | 2025-12-08T06:13:36.468Z |  | 2025-05-11T22:20:11.719Z |  |  | 

---



---

# Anton Morrison
*Mogul*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [Anthony Morrison Blog – Anthony Morrison Students](https://anthonymorrisonstudentsblog.com/anthony-morrison-students)
*2025-01-01*
- Category: blog

### [Ep. 033: Anthony Morrison – “So Much Can be Done in One Life” by Foundational Steps: The SHOW](https://creators.spotify.com/pod/profile/foundationalsteps/episodes/Ep--033-Anthony-Morrison--So-Much-Can-be-Done-in-One-Life-e1ne47u)
*2023-10-24*
- Category: podcast

### [Unlock Success with Anthony Morrison](https://podcasts.apple.com/us/podcast/unlock-success-with-anthony-morrison/id1502316440)
*2022-06-09*
- Category: podcast

### [Anthony Morrison: Learn How To Build Your Own Facebook Fan Page Business | EOFire](https://www.eofire.com/podcast/anthonymorrison/)
*2024-10-29*
- Category: podcast

### [Anthony Morrison and His New Program on Morrison Publishing](https://www.powershow.com/view0/8e3eab-Yzk0N/Anthony_Morrison_and_His_New_Program_on_Morrison_Publishing?varnishcache=1)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Don't Just Add AI, Solve The Problem | Anton Morrison on ...](https://www.youtube.com/watch?v=PnjJcZ2isMw)**
  - Source: youtube.com
  - *Jul 15, 2025 ... In this episode of Beyond SaaS, Jason Niedle speaks with Anton Morrison, co-founder of Mogul AI, about the intersection of design inn...*

- **[Practical Insights for Digital Teams - EvolveDigital Summit](https://www.evolvedigital.com/evolve-digital-montreal-2025)**
  - Source: evolvedigital.com
  - *Aug 4, 2025 ... Anton Morrison. Co-Founder. Mogul. Description: AI-first “vibe coding ... He has also appeared on the Talking Drupal podcast as a gues...*

- **[About EvolveDigital](https://www.evolvedigital.com/about)**
  - Source: evolvedigital.com
  - *EvolveDigital is a one-day conference and training event organized by Evolving Web ... Anton Morrison, Co-Founder, Mogul Global. Design & Creative. 20...*

- **[About EvolveDrupal](https://www.evolvedrupal.com/about)**
  - Source: evolvedrupal.com
  - *EvolveDrupal is a one-day conference and training event organized by Evolving Web ... Anton Morrison, Co-Founder, Mogul. 20 minutes. AI driven design ...*

- **[Mogul Blog](https://www.mogul.global/blog)**
  - Source: mogul.global
  - *Aug 8, 2023 ... Something went wrong while submitting the form. Image of Anton Morrison ... © 2025 Mogul.global. Scroll down for more....*

- **[Anton Morrison - Founder, design innovation consultant, and AI ...](https://antonmorrison.online/)**
  - Source: antonmorrison.online
  - *I'm Anton Morrison, founder of Mogul, where we help organizations unlock their digital potential through AI-driven design and transformative learning ...*

---

*Generated by Founder Scraper*
