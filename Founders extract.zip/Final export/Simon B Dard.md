# Simon Bédard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399521929709395969 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEZDVK5lxbSOg/feedshare-shrink_800/B4EZrBh.qPKkAg-/0/1764183502937?e=1766620800&v=beta&t=0_ujnnwVpo6K6wfc0RmtG9szZfoTM4omSkBH-BKRKF8 | The founder-led motion got us here: Series A, team of +45, large enterprise deployments. Now it’s time to bring in a product leader with proven track record to help us move even faster. 

We’re hiring a VP of Product to own our product function: translating our vision into execution, ensuring on-time delivery and keep elevating our operating standards. This is a strategic and hands-on role. You’ll lead a team spanning product management, product design, and product marketing.

We’re building a liberated company where people have the autonomy to lead, the responsibility to deliver, and the support of a highly collaborative, self-managed team.

Here's a sneak peek at what we've been working on lately.

Link to apply → https://lnkd.in/eD66is9Y
Clinia | 86 | 3 | 10 | 1w | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:17.976Z |  | 2025-11-26T18:58:24.512Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399127294604357632 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGZs0SUFHRzcQ/feedshare-shrink_800/B4EZq70qPtKoAs-/0/1764087738728?e=1766620800&v=beta&t=cYokTD9FE2cX5cn-nUkLnahhC03NmhaKP_96rpqd4IA | I'm particularly proud of this one: Clinia BeActive Club, enabled via Strava. Team members receive hard cash, deposited in their account, for time spent moving. No matter the sport or the intensity. | 40 | 3 | 0 | 1w | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:17.976Z |  | 2025-11-25T16:50:16.171Z | https://www.linkedin.com/feed/update/urn:li:activity:7399120266775207959/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396983796148957184 | Article |  |  | Honored to join the C100 Fellows program—excited for what’s ahead in the Valley. Clinia | 62 | 7 | 4 | 2w | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:17.978Z |  | 2025-11-19T18:52:46.315Z | https://thec100.org/blog-posts/2026_fellows_announcement/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7358116418405441537 | Article |  |  | A benchmark-first approach is fundamental when developing AI solutions for healthcare. To have our team present their paper at a world-class event like KDD (Knowledge Discovery and Data Mining) is something that I'm very proud of since our AI team has been focusing heavily on applying this approach to the healthcare space over the past 4 years. 

Break a leg Daniel Buades Marcos and Nadia Sheikh
Thank you for your support Jimmy Lin | 26 | 1 | 1 | 4mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:17.979Z |  | 2025-08-04T12:47:41.340Z | https://arxiv.org/abs/2412.06954 |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7322332950455357440 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2ab3b27c-c2f7-4edd-9063-f0f819b1782d | https://media.licdn.com/dms/image/v2/D5605AQFD7GPaPYbGSQ/videocover-low/B56ZZy2.xrGUCE-/0/1745683739281?e=1765778400&v=beta&t=lY6qGWWp_hC5mqw9d3isyP8XJPh35_aFs5enzjJFLYk | Agreed Julie Yoo, and for these AI doctor superapps to offer truly integrated and contextualized experiences (supporting patients with the right content, apps, providers, and more), a health-grade retrieval stack will be crucial! Clinia | 20 | 1 | 1 | 7mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:23.170Z |  | 2025-04-27T18:56:57.756Z | https://www.linkedin.com/feed/update/urn:li:activity:7321928343463886850/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7308181846171807744 | Document |  |  | Surfacing the right health information or context, for use by clinicians, AI models or agents is mission critical for efficient care delivery. Thanks Michael Eggleton | 28 | 0 | 1 | 8mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:23.170Z |  | 2025-03-19T17:45:31.580Z | https://www.linkedin.com/feed/update/urn:li:activity:7308149968014315521/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7303539459373912064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE2ZZBzqdftew/feedshare-shrink_800/B4EZVtiZlYG0Ao-/0/1741299498893?e=1766620800&v=beta&t=rm6oUnSQw1BhwCIdp67-BciHbx0t0QTqELooYMbCZ3w | Yesterday, Clinia took the stage for the first time at HIMSS '25.

A big shoutout to our director of product strategy Michael Eggleton who gave a bit of perspective on how we see the #healtcare ecosystem evolve with #AI and the importance of #search on this journey for patients, providers and systems alike! | 163 | 7 | 3 | 9mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:23.171Z |  | 2025-03-06T22:18:20.316Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7299838530220949505 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFgjMbEmFXCZg/feedshare-shrink_800/B4EZU48dS3H0Ao-/0/1740417128844?e=1766620800&v=beta&t=2_P3-mMOI66gyJAcmXpIZgnoSsWgNOJUnZTlZS0EIrg | Tous les lundis matin, chaque membre de l’équipe Clinia reçoit une notification similaire à celles-ci dans Slack. Personnellement, ça me surprend à chaque fois! 

Il y a 4 ans, on a développé le programme BeActive qui rémunère le temps passé à bouger de façon hebdomadaire. Peu importe le sport, peu importe l’intensité, bouger pour rester en forme est important pour nous. Le montant est symbolique, mais ça part bien la semaine!

--
Every Monday morning, every Clinia team member receives a notification similar to this one in Slack. Personally, it surprises me every time!

4 years ago, we developed the BeActive program, which rewards time spent moving, on a weekly basis. No matter the sport or the intensity, moving to stay active is important to us. The dollar amount is symbolic, but it starts the week off right! | 149 | 9 | 2 | 9mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:23.172Z |  | 2025-02-24T17:12:10.046Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7288291511954243584 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGbQyU5X9aFJQ/feedshare-shrink_800/B4EZSUdPseHAAg-/0/1737657482787?e=1766620800&v=beta&t=FHvEhe38FtkdH83ljUamnvY7Cx_Uq5nuOqMMuN5XXlI | It’s incredible the extent to which fraudsters will go to scam people. We’ve recently been made aware of fraudulent activities where individuals received fake job offers claiming to be from our team, signed in my name, and requesting personal information as part of the hiring process.

I’m sharing this in case it may help other companies going through a similar situation, and to inform potential candidates about our rigorous hiring process. | 25 | 0 | 0 | 10mo | Post | Simon Bédard | https://www.linkedin.com/in/simonbedard1 | https://linkedin.com/in/simonbedard1 | 2025-12-08T05:10:23.172Z |  | 2025-01-23T20:28:26.358Z | https://www.linkedin.com/feed/update/urn:li:activity:7288263734165176320/ |  | 

---

