# Adelin Pierre

## Position actuelle

**Titre** : CVF Youth Fellow
**Entreprise** : Climate Vulnerable Forum and V20 Finance Ministers (CVF-V20)
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Government Relations

## Description du rôle

Climate Vulnerable Forum Youth Fellowship Program

## Résumé

Adelin Pierre is a young professional, peacebuilder, and ecological activist from a Small Island Developing State in the Caribbean, with over eight years of experience in climate change policy, youth leadership,Youth, Peace & Security and biodiversity protection.

He currently serves as a Project Officer at Nature-Action Québec and as the Regional Coordinator for Latin America and the Caribbean at the Youth UNESCO for Climate Action Network. Adelin is also a member of the Caribbean Development Bank’s Future Leaders Network.

Adelin has held several prominent international roles, including Disaster Risk Reduction Regional Focal Point for the Americas and Caribbean with the United Nations Major Group for Children and Youth, and Americas Focal Point at the World Youth Parliament for Water.

As Co-founder and Board Coordinator of the Parlement Haitien de la Jeunesse pour l’Eau et l’Assainissement (PHJEA), he has mobilized more than 2,700 young people and supported the implementation of 35 youth-led initiatives. His work includes innovative projects such as the Local Conference of Youth on Climate Change in Haiti (LCOY Haiti), Race for Oceans, the UNLEASH Innovation Lab, and UNLEASH Hack Haiti, all focused on driving progress toward the SDGs, with an emphasis on advancing climate adaptation and resilience.

Recognized for his leadership, Adelin was named Youth Climate Ambassador by Haiti’s Ministry of Environment in 2017 and received the Outstanding Person Award in the Environmental Field from Junior Chamber International in 2018. He continues to champion youth empowerment, climate action, and peacebuilding at both regional and global levels.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAu1E_cBGUSdi8feJJ40Ge-75SU2cwi475I/


---

# Adelin Pierre

## Position actuelle

**Entreprise** : United Nations

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Adelin Pierre
*United Nations*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Interview with Adidjé Kerala, Head of a Stabilization Committee in Chad](https://undpafrica.medium.com/interview-with-adidj%C3%A9-kerala-head-of-a-stabilization-committee-in-conflict-affected-chad-b5c6f43fd345)
*2021-05-06*
- Category: blog

### [Read about Adelina Sila | Office of Information and Communications Technology](https://unite.un.org/WomenInTech-UN/adelina-sila)
*2021-01-01*
- Category: article

### [Full text of "Combined annual report of the Columbia-Presbyterian Medical Center /"](https://archive.org/stream/combinedannualre00colu_1/combinedannualre00colu_1_djvu.txt)
*2016-10-23*
- Category: article

### [In Haiti, Forum Discusses Key Adventist Prophetic Interpretations in the 21st Century](https://adventist.news/news/in-haiti-forum-discusses-key-adventist-prophetic-interpretations-in-the-21st-century)
*2024-03-22*
- Category: article

### [Full text of "The book of St. Louisans; a biographical dictionary of leading living men of the city of St. Louis and vicinity"](https://archive.org/stream/bookofstlouisans00marq/bookofstlouisans00marq_djvu.txt)
*2016-10-23*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Meet the new Youth Power Panel - Restless Development](https://restlessdevelopment.org/2022/01/meet-the-new-youth-power-panel/)**
  - Source: restlessdevelopment.org
  - *Jan 31, 2022 ... Adelin Pierre, Youth Power Panelist from Haiti ... Together with the Youth Power Panel, we are gearing up to a major United Nations e...*

- **[Adelin Pierre : un artisan de la paix au service de l'environnement ...](https://haiticlimat.org/adelin-pierre-un-artisan-de-la-paix-au-service-de-lenvironnement/)**
  - Source: haiticlimat.org
  - *Nov 10, 2025 ... ... Adelin Pierre incarne ... Il a aussi occupé plusieurs postes de leadership au sein de réseaux internationaux tels que le United N...*

- **[Youth Power - Restless Development](https://restlessdevelopment.org/youth-power/)**
  - Source: restlessdevelopment.org
  - *Adelin Pierre is a young environmental activist from Haiti. He is currently serving as UNLEASH Ambassador and Disaster Risk Reduction Regional Focal f...*

- **[Learning at risk: the impact of climate displacement on the right to ...](https://unesdoc.unesco.org/ark:/48223/pf0000387895)**
  - Source: unesdoc.unesco.org
  - *... (United Nations 2018). When juxtaposing this fact with the reality that ... It was prepared with the support and review of Adelin Pierre, Andrea F...*

- **[École d'été 2023 - personnalités invitées - Institut du Nouveau Monde](https://inm.qc.ca/ee23-personnalites/)**
  - Source: inm.qc.ca
  - *Sep 18, 2023 ... Adelin Pierre. Membre de la démarche jeunesse sur la carboneutralité ... United Nations Major Group for Children & Youth où il souten...*

- **[Carta abierta al presidente Luis Abinader: ¡Alto a las deportaciones ...](https://mst-rd.org/2024/10/11/carta-abierta-al-presidente-luis-abinader-alto-a-las-deportaciones-ya/)**
  - Source: mst-rd.org
  - *Oct 11, 2024 ... Adelin Pierre; Aditi Rao, Princeton University, USA; Adom Getachew ... Gabriela Rodríguez Pizarro, Former United Nations Special Rapp...*

- **[Activistas, dirigentes políticos y sociales rechazan las deportaciones ...](https://acento.com.do/actualidad/activistas-dirigentes-politicos-y-sociales-rechazan-las-deportaciones-masivas-en-rd-9435650.html)**
  - Source: acento.com.do
  - *Dec 17, 2024 ... Adelin Pierre 7 ... Gabriela Rodríguez Pizarro, Former United Nations Special Rapporteur on the Human Rights of Migrants and Their Fa...*

- **[Nepal's Aishworya Shrestha named among global cohort of UN ...](https://www.myrepublica.nagariknetwork.com/news/nepals-aishworya-shrestha-named-among-global-cohort-of-un-youth-leaders-for-62-16.html)**
  - Source: myrepublica.nagariknetwork.com
  - *Oct 29, 2025 ... ... United Nations, marking her place on the global stage of youth changemakers. ... Among others, the 2025 cohort includes Adelin Pi...*

- **[Provisional list of participant](https://unfccc.int/sites/default/files/resource/PLOP_COP27.pdf)**
  - Source: unfccc.int
  - *Nov 18, 2022 ... ... United Nations. Ministry of Foreign Affairs. Government of Antigua and ... Adelin Pierre. Mr. Fritz Gerald Pierre-Louis. Membre C...*

- **[COP 27 and COY 17 Experience of Young Professional Adelin ...](https://www.gwp.org/en/GWP-Caribbean/WE-ACT/news-page/News-and-Activities/cop-27-and-coy-17-experience-of-young-professional-adelin-pierre-from-haiti/)**
  - Source: gwp.org
  - *Dec 6, 2022 ... ... Conference of the Parties (COP 27) of the United Nations Framework Convention on Climate Change (UNFCCC) in Sharm El-Sheikh, Egypt...*

---

*Generated by Founder Scraper*
