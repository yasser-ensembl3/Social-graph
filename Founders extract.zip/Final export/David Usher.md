# David Usher

## Position actuelle

**Titre** : Chief Executive Officer
**Entreprise** : SecondEcho
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

SecondEcho is a platform for creating a digital echo of yourself, capturing your voice, thoughts, feelings, and memories in a way that reflects who you are, not just what happened. Instead of journaling into a void, you speak with Chloe, an agentic AI guide who acts like a personal biographer, helping you surface meaningful stories and build a coherent record of your life. We used to lose memories because too little was recorded, now we lose them because everything is scattered and overwhelming. SecondEcho organizes your lived experience into something connected, personal, and lasting.

## Résumé

David Usher is the founder and CEO of Reimagine AI, an artificial intelligence venture studio launched in 2018 that builds AI-powered companies at the intersection of digital immortality, healthcare, and entertainment.

A multiplatinum-selling musician, David has sold more than 1.4 million albums, won four Juno Awards, and reached #1 on charts singing in English, French, and Thai.

He is also a best-selling author and an international keynote speaker, traveling worldwide to share insights on creativity, innovation, and the future of AI.

David holds a degree in political science from Simon Fraser University, and his book on creativity and the creative process, Let the Elephants Run: Unlock Your Creativity and Change Everything, is available now.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACGsNwBJerUmQgvx34ximjUvRpHnCCRRsY/
**Connexions partagées** : 124


---

# David Usher

## Position actuelle

**Entreprise** : REIMAGINE AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# David Usher

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403410475767537664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHaRM4kvJEz1Q/feedshare-shrink_800/B4EZrzsadLHMAg-/0/1765025097823?e=1766620800&v=beta&t=ANsyhJTDZbdBS_NOpFLrflpwomfSSO8gy3GqErF3-NM | I've been using ChatGPT since it dropped. Mac app, iPhone app, the whole setup. It has made me so much more capable as a CEO. I come from the arts but AI makes my business doc, my SOWs, LOIs, legal docs, pitches, and fundraising docs better, because it gives me great frameworks I can improve on, and an instant expert I can bounce ideas off. 

Now we get comfortable with our tools. Lazy, even. Then OpenAI called a code red when Google started breathing down their neck. That made me think—maybe I should look around again.

Then I listened to the Hard Fork boys—Kevin Roose and Casey Newton—absolutely raving about Anthropic and Claude 4.5.

I've used Claude a fair bit but wasn't impressed enough to switch.

So I gave it another try and damn. 

It's faster. It's better. And now it's my go to. Now I understand the code red.
OpenAI's market cap depends on everything going perfectly. They can't lose users. Code red. (not Google but Anthropic)
#ai | 117 | 51 | 3 | 16h | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:49.833Z |  | 2025-12-07T12:30:06.138Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402655293291077632 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2d31c9e1-bae3-4662-b5ed-df5484723112 | https://media.licdn.com/dms/image/v2/D4E05AQGRq2tScR50WQ/videocover-low/B4EZruDmz9HgBQ-/0/1764930524638?e=1765778400&v=beta&t=HoyS9FyxnPrId3q6C21dXJjeTDG5InzKVDLcwD95CpA | Listening to Sam Altman muse about the future and the unraveling of our cultural, social and economic fabric like it’s a round of theoretical Dungeons and Dragons is so nauseating.

The same tech oligarchs already ran this experiment once with social media. They unleashed it on our kids, and I think it’s been fu*king terrible for all of us.

Now trillion dollar companies want to talk about the coming “age of abundance” and we should trust them to deliver it and us. Meanwhile these are the same companies are firing their own employees to replace them with AI. If abundance is real, when does it start, and why does it never seem to include the people working inside their own buildings?

We keep getting grand theories about the future. But what about the present.
I’m not feeling very trusting.
#ai | 385 | 98 | 25 | 2d | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:49.833Z |  | 2025-12-05T10:29:16.605Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401983656677806080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHeEu75SlCwgA/feedshare-shrink_800/B4EZrkg6ROJ0Ak-/0/1764770424429?e=1766620800&v=beta&t=MFK_0NwZwPT8-hVTcchZgbyjabR8L6-2MOjsihDeUEo | I heart radio just launched Guaranteed Human, for DJs and vocalists.

As the AI fever dream grows, we are going to see the rise of human spaces.

Chess is the best example of this. Computers are better at people playing chess, but its no fun playing with a computer. And chess has never been bigger. Its a huge community online with humans playing humans. 

We are seeing the same thing in social media. As our feeds are starting to get cluttered with AI generated videos, and it gets harder to tell whats real, the whole thing means less, and we are starting to lose interest.

I find the same thing with music, i want to write music with my human friends, and play live to other humans.

AI is a powerful tool that has the power to make incredible things, but some of it is just slop.

The rise of human spaces!
#ai | 51 | 3 | 0 | 4d | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:49.834Z |  | 2025-12-03T14:00:25.958Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401262558537748480 | Video (LinkedIn Source) | blob:https://www.linkedin.com/63a30ce7-45c8-4853-add5-48d9af4bd3c9 | https://media.licdn.com/dms/image/v2/D4E05AQGRp6ed7ZLE4g/videocover-high/B4EZrFgvvYKcBU-/0/1764250288645?e=1765778400&v=beta&t=SnhzwS4a_oFwdU8C0t1-6U2RsKejSg0OwElym5ndH5A | Memory is everything.
The framework of consciousness.
It defines the past, shapes the present, and without it we lose all dreams about the future.
My mom was diagnosed with Alzeimers about 10 years ago. Watching all her memories fade and disappeared has been long and brutal. 
I feel lucky she still remember me.
All this time i have spend thinking and working on memory, how to save it, how to share it, but somehow I was to stupid to collect all her stories while I could. 
Life moves way too fast... | 15 | 4 | 0 | 6d | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:49.835Z |  | 2025-12-01T14:15:02.764Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400175402167685120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbCuKHFxg4vg/feedshare-shrink_800/B4EZrJ5fQKKkAg-/0/1764323884675?e=1766620800&v=beta&t=GFn5JjhUS6_KUREXejCtQ6AMD9K-W0cQFdSmMrT5W3o | I'm in the Globe and Mail today talking about AI and creativity.
#ai | 210 | 15 | 3 | 1w | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:49.835Z |  | 2025-11-28T14:15:04.487Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7398377750400770048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvR6JSWPBFUg/feedshare-shrink_800/B4EZqxRUnSGYAg-/0/1763910707641?e=1766620800&v=beta&t=tCLIawpSL8WCmepiSTSr3qSgzf03U0SzwKnSDGplNp0 | I’ve been thinking a lot about memory and how we remember

93 years old and the sweetest, it’s hard to imagine once she was a fiery asian dragon lady chasing me around the house with a wooden spoon

Happy birthday mom! | 441 | 26 | 1 | 2w | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.907Z |  | 2025-11-23T15:11:50.907Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396162803218145280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c99fa14b-14df-47d7-993d-453c2bef1542 | https://media.licdn.com/dms/image/v2/D4E05AQEmNxuIzxg-Ww/feedshare-thumbnail_720_1280/B4EZqNmVqeHUA4-/0/1763312231810?e=1765778400&v=beta&t=D9sri9wRWme6w9ogBx10AVnl3NuyoYP7sLLcCfL_c7U | Here’s how I’m using our new platform SecondEcho to record memories.

You talk to Chloe our agentic AI biographer, its like journaling but smarter and interactive. You can save and share your thoughts, feeling, stories and voice, and overtime, create your digital Echo.

If you’d like to come on as a beta tester and shape what this becomes, write “Memory” in the comments and I will reach out and add you to the list.
#ai | 56 | 40 | 6 | 2w | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.909Z |  | 2025-11-17T12:30:26.347Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7393992164017393664 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4f300994-c753-4b06-a72f-93832125f29c | https://media.licdn.com/dms/image/v2/D4E05AQF0hrGBMEQfVg/videocover-high/B4EZpwMOtKKsBU-/0/1762818846619?e=1765778400&v=beta&t=5yomSgF9KI_XuoafY_aYYYOKYOYt_RKhfc-MGBqqrjA | This really is so damn Westworld, amazing and terrifying! | 43 | 7 | 2 | 3w | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.910Z |  | 2025-11-11T12:45:05.633Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391451641511833600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH_Nq6xvGzbdg/feedshare-shrink_800/B4EZpO2GArGcAg-/0/1762259395578?e=1766620800&v=beta&t=ejd63BXAmyG-Af1tzTH1ApHBYpTaRi5-UY1AOK9Y1qE | I love giving keynotes, talking about AI and creativity, and I love connecting with the audiences. A huge thanks to the companies and organizations and all the people who made this year so much fun!

Catherine Day Speakers Spotlight Mélanie Roy Martin Perelmuter Farah Perelmuter ACFO-ACAF | 94 | 6 | 2 | 1mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.911Z |  | 2025-11-04T12:29:57.867Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389624689171771392 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHPdTxjkkUcbQ/feedshare-shrink_800/B4EZo0UGIcGUAg-/0/1761814275330?e=1766620800&v=beta&t=9N268hpx4iMCKUxg2xsPwye0c0hkyaowZtgU2NJeGBs | When AI Writes Everything, How Do We Still Learn to Think?

When I learned to write, I learned to think. 
The act of putting words into order was the act of putting thoughts into order.
Writing isn’t what you do after thinking; writing is thinking.

Right now, in high school and university, students are using AI to write their essays. Everyone knows this. But what’s talked about less is the loop we’ve created:
• Teachers use AI to write the lesson plans (of course, not all teachers).
• Students use AI to write the essays based on those plans.
• Then teachers use AI to check for AI plagiarism.
• And finally, use AI again to grade the papers (again, not all teachers, yet).

Both sides have quietly automated the core intellectual process.
The issue isn’t the existence of the tools; it’s that if you don’t learn how to write, you lose the ability to know whether the writing is any good. You lose the ability to see the structure of an argument, the shape of an idea, the seams where reasoning starts to break down. And without that, you also lose the ability to critique AI’s output. You’re left trusting what it spits out because you no longer know what’s good or bad, slop or false.

We’re not just outsourcing the work; we’re outsourcing our understanding of how to critique the work.

Will we still know how to think for ourselves once AI is doing all the thinking for us?
#ai | 138 | 35 | 14 | 1mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.911Z |  | 2025-10-30T11:30:18.486Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7388914956047646721 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPexIf_QgkIg/feedshare-shrink_800/B4EZoqy.QAJ0Ag-/0/1761654602054?e=1766620800&v=beta&t=mRwqt22eF6HI9eLBfXuoQwOWrl60hXGGlbh82WyImH4 | Another early flight to give a keynote on my favorite things, creativity and artificial intelligence

I’ve found my love of travel again. It took me awhile after the pandemic, I feel very lucky to be able to speak to audiences about the changes that are coming…

Mélanie Roy Speakers Spotlight Martin Perelmuter Farah Perelmuter | 146 | 6 | 0 | 1mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.912Z |  | 2025-10-28T12:30:04.923Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7386372426223362048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE6rSKSu4nMgw/feedshare-shrink_800/B4EZoGqkKjHgAo-/0/1761048417574?e=1766620800&v=beta&t=NLl_f5SrZO0ox4qDjP27LKLHrd8K3QfdFSlm0yX51iM | Another early morning flight off to give a keynote!!

Lucky for me I love talking to people about AI

Mélanie Roy Martin Perelmuter 

#AI | 157 | 5 | 0 | 1mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.913Z |  | 2025-10-21T12:06:58.575Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7384307324624019457 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEGb16Rt0tC2Q/feedshare-shrink_800/B4EZnpUYTHIwAg-/0/1760556058751?e=1766620800&v=beta&t=3syjx8_O3tfAWJ95dWA43KKkerMdZ3mUYhAy1XvbqQU | I guess to justify a 100 billion dollar valuation you have to open your platform up to sex bots and AI slop. 

So when Open AI started, they were supposed to be a non profit and their mission statement was...

“advancing digital intelligence in the way most likely to benefit humanity as a whole, unconstrained by a need to generate financial return.”

Today Sam (we are good friends so i call him Sam) decided that what the world really needs is AI sex bots. "Now that we have been able to mitigate the serious mental health issues and have new tools, we are going to be able to safely relax the restrictions in most cases."

The mission has changed...
#ai | 59 | 30 | 0 | 1mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.913Z |  | 2025-10-15T19:20:59.986Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7381291196830085120 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3545fac0-c295-4795-907f-9454fb620a29 | https://media.licdn.com/dms/image/v2/D4E05AQFGyV8QPpaIng/feedshare-thumbnail_720_1280/B4EZm.dDRnHIA4-/0/1759836913604?e=1765778400&v=beta&t=hUd83iD2nEU3PLOy14VVt4oHh-R9zfm-C-2WnWY7lg4 | Today I’m really excited to share something we’ve been quietly building.

Our new platform, SecondEcho.

Since I started Reimagine AI seven years ago, we have tried many iterations, but the technology just wasn’t there to bring it to life, until now.

SecondEcho is a way to preserve your thoughts, feelings, and memories, the story of your life as an interactive, immortal legacy. A digital echo of your mind.

This mission began when my mom was diagnosed with Alzheimer’s. Watching her memories, her story, and her legacy slowly fade over the past decade, without any real record for my kids and their kids to one day know, is what set this in motion.

Today, we’re opening the waiting list for early beta testers, for those who want to help us explore what memory could look like in the age of AI.

If you’d like to be part of it, just type “Memory” in the comments and I’ll send you a special link to get on the SecondEcho waiting list.

PS If you have any questions, just ask in the comments.

Jonathan Gallivan, Robert Takefman, Defne Gurcay, Anton Iancu, Sanders Lee, Carle Beauchamp, Mélanie Roy, Mitch Joel, Philippe Beaudoin, Innovobot, Annie Pinet, Claude G. Théoret

#AI | 290 | 255 | 14 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.914Z |  | 2025-10-07T11:35:59.083Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7379478946683449344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9i8Ctc2-ZTg/feedshare-shrink_800/B4EZmks_2EIMAk-/0/1759404883943?e=1766620800&v=beta&t=RSvOyxTrpFMvE7zBXhOpLPWJkQnHs5dXu2bpHTFq2yI | Pretty much the last thing on earth the world needs is an AI-generated social media platform...just sayin.
#ai | 34 | 8 | 0 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.915Z |  | 2025-10-02T11:34:44.978Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7374768746176864256 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b06ac981-a509-468e-8053-b43c566b6d1d | https://media.licdn.com/dms/image/v2/D4E05AQFRXQemmBj2CQ/videocover-low/B4EZlhw_dXGUB4-/0/1758281861209?e=1765778400&v=beta&t=nH7pc1l324GVkKVNg2DA3MwQgFGJl_lx3x44FvMtRiw | The hand is one of the most problematic and challenging problems in creating humanoid robots.

Sanctuary AI, Tesla, Figure, they are all racing to try and recreate the movement and dexterity of the human hand.

Enter a Chinese Startup with the Wuji Hand. 20 degrees of freedom. 600 grams. Million-cycle durability.

It’s pretty black mirror! | 75 | 16 | 5 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.915Z |  | 2025-09-19T11:38:05.666Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7374408129997856770 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFzWz_oSAXPEg/feedshare-shrink_800/B4EZlZiXXpKsAg-/0/1758143805758?e=1766620800&v=beta&t=MjGXyo-7UHwS-e1nnNKQi1edESBhIgyT34OIah-x2Kg | Who's going to ALL IN next week? 
#allin | 46 | 14 | 0 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.916Z |  | 2025-09-18T11:45:08.069Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7373313397335019520 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f85eef64-3085-464c-b21e-f9e7b1ecd16b | https://media.licdn.com/dms/image/v2/D4E05AQFPKzDEJf7EIQ/feedshare-thumbnail_720_1280/B4EZlIX7bjGwAw-/0/1757855858805?e=1765778400&v=beta&t=TXFKnukQwrwoR3YhnYQR_OU-7xVudS7OdXoadHZ2rC4 | "Dead Internet" theory in action. This video has over a million views on YouTube. 

When the sea of AI pollution drowns us, we will have to find new human spaces to live our digital lives. 
#ai | 68 | 18 | 6 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.917Z |  | 2025-09-15T11:15:03.463Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7370765787516600320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF9PmK-lIfR7A/feedshare-shrink_800/B4EZko4bK1KkAk-/0/1757327504814?e=1766620800&v=beta&t=wvGB03NfDdXN7lZthzQ8_uoiEQtwq-zkFFCGnhAc-ow | When AI Cuts Up Books

Anthropic, the company behind Claude, just settled with authors for $1.5 billion. The headlines are about copyright, but the story underneath is so ugly.

To feed their AI, Anthropic literally cut up books, buying millions of used copies, slicing off the bindings, scanning every page, then tossing the remains. A court called that fair use. At the same time, they pulled down millions of pirated ebooks, and that’s where the line was crossed.

To build machines that can speak in human voices, we killed the artifact that carried those voices for a hundred years. | 43 | 16 | 4 | 2mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.917Z |  | 2025-09-08T10:31:45.950Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7370049167467118592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFfxH24WmuCxQ/feedshare-shrink_800/B4EZkesqZSGUAg-/0/1757156649332?e=1766620800&v=beta&t=HL67QINX0wRQwaeT9mmBZKEGKNWjCTSsrTJ9zezO8u8 | Sam Altman is now worried about the “dead internet” he created

Dead internet theory-when all the videos and posts, and comments on the posts, and comments on the comments are all created by AI bots. The humans are really just watchers in an artificial matrix.

Very similar to what I'll call the "dead education" theory-when the teachers use AI to write their lesson plans, so the kids can use AI to write their papers, and the teachers can use AI to check for plagiarism, and then AI to grade the papers.

"Isn't it's ironic" that Sam is now worried about the dead internet he is actively creating, "dont you think?"
#ai | 397 | 88 | 23 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.918Z |  | 2025-09-06T11:04:10.416Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7366786701828038660 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF5esxWX9P5Ig/feedshare-shrink_800/B4EZjrI8DCIIAg-/0/1756291646904?e=1766620800&v=beta&t=tj8MVfSqxpvEkmPQb3_3GWncWn7aLF9jHlA_fvXq-PY | This is a great listen about AI cheating and education.

The main points:
• In universities right now, everyone is cheating. Students are writing essays with ChatGPT, while professors are using AI to make lesson plans and grade papers. 

• If you lose the ability to write, do you lose the ability to think? For me, they are tied together.

• And if AI is creating lessons, writing essays, grading them, and catching plagiarism, what does a university education mean? (other than fun times at the pub)

The real question: are we entering the post-literacy era?

What do you think — a post-literacy world?
#ai #artificialintelligence #education | 25 | 12 | 0 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.918Z |  | 2025-08-28T11:00:17.994Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7366462077411975168 | Article |  |  | CNN - When our exhibit Lucy AI was on display in New York City, Clare Duffy invited us onto her CNN podcast Terms of Service.

Big thanks to Clara and her team for the thoughtful conversation and for helping share Lucy’s story with a wider audience.
#cnn #termsofservice | 30 | 1 | 0 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.919Z |  | 2025-08-27T13:30:21.502Z | https://podcasts.apple.com/us/podcast/how-your-memories-can-live-on-after-you-die/id1777077679?i=1000723563538 |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7363974552957120512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4bf14042-5512-411d-9853-a1584020ed43 | https://media.licdn.com/dms/image/v2/D4E05AQE6W8DPNhyGew/videocover-high/B4EZjIXr07HgCM-/0/1755708342834?e=1765778400&v=beta&t=EjXd2yeVwOVNyB94fzssTytdog9BqHa9wB7pTfS3x5A | A lot of people ask me what it’s like to play music for lots of people. 
Heres what it looks like from my POV! | 87 | 8 | 1 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.919Z |  | 2025-08-20T16:45:49.456Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7363548216174211072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHNhVBgpR5ddg/feedshare-shrink_800/B4EZjCUCjqHgAk-/0/1755606702025?e=1766620800&v=beta&t=i7g23OGWztDKVO6shWI9peXuhgfiRWhAGedl9bcvrTc | Thanks Toronto! Now back to AI | 223 | 5 | 1 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.920Z |  | 2025-08-19T12:31:42.846Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7363309592333717505 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6f3cf25a-fa0b-417c-9191-6bb3baada483 | https://media.licdn.com/dms/image/v2/D4E05AQEFjQK9CWSVPQ/videocover-high/B4EZi.6vP1GcCU-/0/1755549802049?e=1765778400&v=beta&t=TI97kiZASF7F_nnlMo_aVzLQxioVm2G9Q20kstxEGmw | Show tonight downtown Toronto at the CNE, yes of course we have a gong!! | 149 | 8 | 0 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.920Z |  | 2025-08-18T20:43:30.489Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7362109427371364353 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFwrTn8CGZN9w/feedshare-shrink_800/B4EZit3gg0HgAg-/0/1755263667123?e=1766620800&v=beta&t=3C_xg5PEhpW503iZEfhyhyyBZkeNWaOoQQzTngJRTTE | If you are in Toronto. We will be playing an outdoor show, downtown at the CNE this Monday, August 18th, 2025 | 142 | 4 | 1 | 3mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.921Z |  | 2025-08-15T13:14:28.864Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7355598003799265282 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ee3500b5-bfdb-4bd0-9bb5-0c9a0ea2071e | https://media.licdn.com/dms/image/v2/D4E05AQFDtmLtFVeyAg/feedshare-thumbnail_720_1280/B4EZhQHH9vGwA4-/0/1753690704420?e=1765778400&v=beta&t=zrd9VwnkbL6DvQ7y4E6R3DJak9PW94krt3nuDfVzAMA | I’m excited to announce our new experimental project, Kids Care AI, in consultation with Dr. Dominic Venne, Chief of Surgery and Chief of Pediatric Neurosurgery at St. Justine Hospital.

We are seeking partners in healthcare, hospitals, or university research (possibly including autism research) that would be interested in experimenting with our AI-powered virtual beings platform for children.

Kids Care AI is a virtual companion platform featuring interactive, customizable characters designed to support children before and after surgery, especially during those times when parents can’t be by their side. The experience is playful and adaptable, with the ability to change characters, backgrounds, and more. Through “Story Mode,” kids can enjoy fun, engaging tales or explore custom narratives that gently explain hospital procedures, helping to reduce anxiety and create a calmer, more reassuring experience.

Our first test story focuses on The MRI Journey. Many young children need sedation before an MRI due to fear or anxiety, an approach that’s stressful for families, resource-intensive for hospitals, and a major cause of long wait times. By using storytelling and virtual companionship, we’re experimenting with ways to reduce anxiety and potentially avoid the need for sedation altogether.

The app is built with our custom content filters to ensure safe, positive interactions. 

And this is just the beginning. We’re especially curious about how Virtual Companions like Kids Care AI could support children with autism or other unique needs.

If you work in healthcare, hospitals, university research, or autism research and want to experiment with these tools, we’d love to connect.
Danina Kapetanović Clare Duffy Meetali Jain Dominic Venne, MD, MSc, FRCSC Sanders Lee Carla Marques Sonia Marques Alex Bethke Jonathan Gallivan Defne Gurcay Carle Beauchamp Robert Takefman 
#ai #autism | 179 | 27 | 12 | 4mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.922Z |  | 2025-07-28T14:00:24.508Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7355281420145020931 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1UiHnhW9j8g/feedshare-shrink_1280/B4EZhM1eaRHoAo-/0/1753635744055?e=1766620800&v=beta&t=BW30VNjt5s_vlnOJMYq3o0mb5FvsZNkPi8kcSF-4GkU | At 92, my mom is still so much more fashionable than me! | 531 | 23 | 1 | 4mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.922Z |  | 2025-07-27T17:02:25.083Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7351606634021851137 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQHePZlP6eK92w/videocover-high/B4EZgU.OZ3GwCM-/0/1752698579534?e=1765778400&v=beta&t=PlQ-7trABFeQ6gv2MGaqgjwtQJm3EYcDBFACuH63mFM | Love this! | 14 | 4 | 0 | 4mo | Post | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/davidusher | 2025-12-08T05:06:53.923Z |  | 2025-07-17T13:40:07.797Z | https://www.linkedin.com/feed/update/urn:li:activity:7351350721511915521/ |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7396175649444478977 | Video (LinkedIn Source) | blob:https://www.linkedin.com/08067224-6146-4f46-b6d0-27f98d2f17b3 | https://media.licdn.com/dms/image/v2/D4E05AQEmNxuIzxg-Ww/feedshare-thumbnail_720_1280/B4EZqNmVqeHUA4-/0/1763312231810?e=1765778400&v=beta&t=D9sri9wRWme6w9ogBx10AVnl3NuyoYP7sLLcCfL_c7U | Here’s how I’m using our new platform SecondEcho to record memories.

You talk to Chloe our agentic AI biographer, its like journaling but smarter and interactive. You can save and share your thoughts, feeling, stories and voice, and overtime, create your digital Echo.

If you’d like to come on as a beta tester and shape what this becomes, write “Memory” in the comments and I will reach out and add you to the list.
#ai | 56 | 40 | 6 | 2w | Hugh McGuire reposted this | David Usher | https://www.linkedin.com/in/davidusher | https://linkedin.com/in/hughmcguire | 2025-12-08T05:07:44.194Z |  | 2025-11-17T13:21:29.126Z |  |  | 

---



---

# David Usher
*REIMAGINE AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [Team — REIMAGINE AI](https://www.reimagine.ai/aboutus)
*2025-01-01*
- Category: article

### [David Usher, Canadian artist and entrepreneur, talks AI, its potential and touring again, ahead of Lethbridge talk](https://calgaryherald.com/news/local-news/david-usher-canadian-artist-entrepreneur-ai-potential-touring-lethbridge-talk)
*2025-03-11*
- Category: article

### [David Usher: Where Does Creativity Come From? - Laura Gassner Otting](https://lauragassnerotting.com/lgotv-interview/david-usher-bigtalk/)
*2024-09-14*
- Category: article

### [REIMAGINE AI | LinkedIn](https://ca.linkedin.com/company/reimagineai)
*2025-05-09*
- Category: article

### [Library — REIMAGINE AI](https://www.reimagine.ai/library)
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 9,971 words total*

### Team — REIMAGINE AI
*148 words* | Source: **EXA** | [Link](https://www.reimagine.ai/aboutus)

Team — REIMAGINE AI

===============

[0](https://www.reimagine.ai/cart)

[Skip to Content](https://www.reimagine.ai/aboutus#page)

[![Image 1: REIMAGINE AI](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/b9fe8fcf-9542-456a-b41e-7420293fa841/Reimagine+logo+white.png?format=1500w)](https://www.reimagine.ai/)

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

English

[Français](https://www.reimagine.ai/aboutus#)

[English](https://www.reimagine.ai/aboutus#)

Open Menu Close Menu

[![Image 2: REIMAGINE AI](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/b9fe8fcf-9542-456a-b41e-7420293fa841/Reimagine+logo+white.png?format=1500w)](https://www.reimagine.ai/)

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

English

Open Menu Close Menu

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

[English](https://www.reimagine.ai/aboutus#)

[Back](https://www.reimagine.ai/)

[Français](https://www.reimagine.ai/aboutus#)

[English](https://www.reimagine.ai/aboutus#)

![Image 3](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/da55dde8-0902-4a44-af2a-5ca5af488fca/Default_fill_the_frame_full_with_wild_colourful_orchids_and_e_0.jpg)

**About REIMAGINE AI**

Founded by [David Usher](https://www.davidusher.com/) in 2018, Reimagine AI is an artificial intelligence venture studio specializing in digital immortality, AI healthcare and AI-powered virtual beings in entertainment.

We are dedicated to building unique AI platforms and experiences to spark your imagination and make you dream about the future.

Connect with us to: 

Create • Collaborate

![Image 4](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/7101a0d4-277c-4c3e-8807-78e4caf8120e/National_Research_Council_of_Canada_%28logo%29.svg.png)

![Image 5](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/1627677926302-H9PBY4TKE9H8IFQ9MAB8/Transparent_google_logo_2015.png)

![Image 6](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/ac919520-722d-4850-9e4a-4123ea7eeefe/virginmobile_logo.png)

![Image 7](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/1627677890971-H663W4GBWYVQMHV6RYC9/mila+logo.png)

![Image 8](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/7b4a37c1-003e-4b53-99ee-2349ece39a4a/EY_logo_2019.svg.png)

![Image 9](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/963277e1-6c12-43c2-83d1-ea03cb6b6080/Behaviour_Interactive_logo.svg.png)

[](https://www.linkedin.com/company/reimagineai/)[](mailto:hello@reimagine.ai)

[Contact Us](https://reimagine.ai/contact)

Copyright © 2025 Reimagine AI Inc. All Rights Reserved.

­

­

---

### David Usher, Canadian artist and entrepreneur, talks AI, its potential and touring again, ahead of Lethbridge talk
*1,977 words* | Source: **EXA** | [Link](https://calgaryherald.com/news/local-news/david-usher-canadian-artist-entrepreneur-ai-potential-touring-lethbridge-talk)

[Skip to Content](https://calgaryherald.com/news/local-news/david-usher-canadian-artist-entrepreneur-ai-potential-touring-lethbridge-talk#main-content)

*   [Subscribe](https://calgaryherald.com/subscribe/)
    *   [FAQ](https://calgaryherald.com/faq/)
    *   [My Account](https://calgaryherald.com/my-account/)
    *   [Manage My Subscription](https://calgaryherald.com/my-account/#/subscriptions/)

*   [News](https://calgaryherald.com/category/news/)
    *   [Local News](https://calgaryherald.com/category/news/local-news/)
        *   [Crime](https://calgaryherald.com/category/news/crime/)

    *   [Politics](https://calgaryherald.com/category/news/politics/)
    *   [True Crime](https://calgaryherald.com/category/news/true-crime/)
    *   [National](https://calgaryherald.com/category/news/national/)
    *   [World](https://calgaryherald.com/category/news/world/)
    *   [Weather](https://calgaryherald.com/weather/)
    *   [Archives](https://www.tkqlhce.com/click-8833683-11570746?url=https://calgaryherald.newspapers.com/?xid=1841/ "Archives (Leaving Calgary Herald)")

*   [Business](https://calgaryherald.com/category/business/)
    *   [Energy](https://calgaryherald.com/category/business/energy/)
    *   [Local Business](https://calgaryherald.com/category/business/local-business/)
    *   [Real Estate](https://calgaryherald.com/category/business/real-estate/)
        *   [First-Time Homebuyers](https://calgaryherald.com/category/business/real-estate/first-time-homebuyers/)

    *   [Commercial Real Estate](https://calgaryherald.com/category/business/commercial-real-estate/)
    *   [FP Markets](https://business.financialpost.com/markets/ "FP Markets (Leaving Calgary Herald)")
    *   [FP Headlines](https://business.financialpost.com/category/news/ "FP Headlines (Leaving Calgary Herald)")
    *   [FP Money](https://business.financialpost.com/category/personal-finance/ "FP Money (Leaving Calgary Herald)")
    *   [Technology](https://calgaryherald.com/category/technology/)
        *   [Gaming](https://calgaryherald.com/category/technology/gaming/)
        *   [Science](https://calgaryherald.com/category/technology/science/)
        *   [Space](https://calgaryherald.com/category/technology/space/)

    *   [Small Business](https://calgaryherald.com/category/business/small-business/)
    *   [Alberta's Top Employers](https://calgaryherald.com/category/sponsored/top-employers-ch/)

*   [Sports](https://calgaryherald.com/category/sports/)
    *   [Calgary Flames](https://calgaryherald.com/category/sports/hockey/nhl/calgary-flames/)
        *   [NHL](https://calgaryherald.com/category/sports/hockey/nhl/)
        *   [PWHL](https://calgaryherald.com/category/sports/hockey/pwhl/)
        *   [More Hockey](https://calgaryherald.com/category/sports/hockey/)

    *   [Calgary Stampeders](https://calgaryherald.com/category/sports/football/cfl/calgary-stampeders/)
        *   [CFL](https://calgaryherald.com/category/sports/football/cfl/)
        *   [NFL](https://calgaryherald.com/category/sports/football/nfl/)

    *   [Calgary Cavalry](https://calgaryherald.com/category/sports/soccer/calgary-cavalry/)
    *   [Calgary Roughnecks](https://calgaryherald.com/category/sports/calgary-roughnecks/)
    *   [Spruce Meadows](https://calgaryherald.com/tag/spruce-meadows/)
    *   [Soccer](https://calgaryherald.com/category/sports/soccer/)
        *   [International Soccer](https://calgaryherald.com/category/sports/soccer/international-soccer/)
        *   [MLS](https://calgaryherald.com/category/sports/soccer/mls/)

    *   [Baseball](https://calgaryherald.com/category/sports/baseball/)
    *   [Basketball](https://calgaryherald.com/category/sports/basketball/)
    *   [Golf](https://calgaryherald.com/category/sports/golf/)
        *   [Golf Videos](https://calgaryherald.sportstonews.com/ "Golf Videos (Leaving Calgary Herald)")

    *   [Curling](https://calgaryherald.com/category/sports/curling/)
    *   [Rodeo-Chucks](https://calgaryherald.com/category/sports/rodeo-chucks/)
    *   [Tennis](https://calgaryherald.com/category/sports/tennis/)
    *   [Auto Racing](https://calgaryherald.com/category/sports/auto-racing/)

*   [Opinion](https://calgaryherald.com/category/opinion/)
    *   [Columnists](https://calgaryherald.com/category/opinion/columnists/)
    *   [Letters](https://calgaryherald.com/category/opinion/letters/)
    *   [Editorials](https://calgaryherald.com/category/opinion/editorials/)
    *   [Send us an Opinion Column or Letter](https://calgaryherald.com/opinion/columnists/how-to-submit-a-column-to-the-calgary-herald/)

*   [Arts](https://calgaryherald.com/category/entertainment/)
    *   [Local Arts](https://calgaryherald.com/category/entertainment/local-arts/)
    *   [Movies](https://calgaryherald.com/category/entertainment/movies/)
        *   [Movie Listings](http://movies.calgaryherald.com/ "Movie Listings (Leaving Calgary Herald)")

    *   [Television](https://calgaryherald.com/category/entertainment/tele

*[... truncated, 26,349 more characters]*

---

### David Usher: Where Does Creativity Come From? - Laura Gassner Otting
*441 words* | Source: **EXA** | [Link](https://lauragassnerotting.com/lgotv-interview/david-usher-bigtalk/)

David Usher shares where creativity comes from, and how it pushes you in unexpected directions. Join Laura Gassner Otting as she hosts this episode of LGOtv with special guest, David Usher – Lead Singer, Creativity Expert, AI Geek.

Timestamps:

[1:25](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=85s)​ – What did you want to be when you grew up?

[5:00](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=300s)​ – “You grow up white, you feel like you’re white, but the reality is [that] if you don’t look the same, your religion is not the same, you’re not really white.”

[7:35](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=455s)​ – Do you think the trauma of high school made you more comfortable?

[12:15](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=735s)​ – “Your job as a creator or a conductor is to do an analysis on your process and to understand…”

[13:48](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=828s)​ – “Creativity is a language. If you want to get better at the language, learn the language. Practice the language.”

[18:15](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=1095s)​ – “Leave no blank space for doubt.”

[22:50](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=1370s)​ – What fascinates you about artificial intelligence?

[27:23](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=1643s)​ – I worry that this is another way that artists will not get fully paid…they’re getting paid in monopoly money.

[31:51](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=1911s)​ – Who is going to build sustainable ecosystems?

[37:16](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=2236s)​ – “You can not talk about the future unless you understand AI.”

[45:51](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=2751s)​ – Was there pressure to “succeed” in tech within the AI world?

[49:08](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=2948s)​ – Taking your goals seriously.

[50:19](https://www.youtube.com/watch?v=_-Y50s5ObN0&t=3019s)​ – “You don’t want to tell people your idea too early.”

Links:

[https://www.reimagine.ai](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbjVVWk51cVh2U3dqYjlORl81dTJMT3RndUlGd3xBQ3Jtc0ttUFRTU2VDN24tcVM5RDB3Mk85MjJfSE55NTMwUHdoejNFY3podVh0aXZzcWUybWlXaXJodEhPN2pQeWs0X2dnbW5XQmlLRHdmaTMyaGtrZi1pVXpTMzlkbkY0U2lJR2NVRkloU2kxLXhvYm5FR3U3cw&q=https%3A%2F%2Fwww.reimagine.ai)​

[https://www.davidusher.com](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbWVySzBtRDZkSEdkU09fVkxjN3NFeEg1NU1xQXxBQ3Jtc0trNWp2UmxkT1RtRk1LVW9QeHFqdmR1bVRlVkNzb0FDaTc2ZkFrVkJYSEtINUtzM1lsMm5oRldJb2pCUXRPNU15MExzdUp0THhsMnhYdDM5dWhsdDYxWGFLMTZJYmZZQWdRODZfVW5MZ25GRGduUVhORQ&q=https%3A%2F%2Fwww.davidusher.com)​

[https://www.instagram.com/davidusher](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbWdtcVN2cVJtb0o4UUFTZEx2Q0pYeTA1SFN5Z3xBQ3Jtc0tuVlk1Q2ZmdkpkX3k2UlRTTUR3d0M3dUd3NHUwSU5iTm9JWnJwc3ZIYWhmT1o3VHJuSDI0N1pNYUFCd3lHOVRJV1daaVN1STV3UmRnckFYNTZZWWpFR1pSUXFVcDVEdVhzcGRLTnZra2NKRkdBYkpiTQ&q=https%3A%2F%2Fwww.instagram.com%2Fdavidusher)​

[https://www.facebook.com/DavidUsher](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbVVMbFdsNnhQazdLblUwOTc2cTBkQ1hNMXNiUXxBQ3Jtc0ttU0czWjR0UDdYZEhUYWxoNmx4U2VGRTlwSWgzLVdONzNxcTNKc0Y5WTVkVHpyUDFpWnlNLTFCWGtkUzNPYTJDYmVPVDh0Wk03bVJXbWlwUG81NWI2U3VFZWhDSjRrMFhwUFNGM3k0bHFWaTdndUhzQQ&q=https%3A%2F%2Fwww.facebook.com%2FDavidUsher)​

[https://www.linkedin.com/in/davidusher](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbUx4Z2xZdjBNNTdZRlVvOG5xY0p2Q1QwTFExQXxBQ3Jtc0trbHFubVFiODl6eThtZGxyaTV3d3pDb2ZBS183RUVvVjFjbVh3VGdzc0VxbEFLdk1WQmxmOVhlWEJUdDhWNXc0Y2RJa0h4a0FXNXNTcmRnOXBvOVkta29USzBvaUlHTlg0NTRnZEctSzNwek1IUjFlWQ&q=https%3A%2F%2Fwww.linkedin.com%2Fin%2Fdavidusher)​

[https://twitter.com/davidusher](https://www.youtube.com/redirect?event=video_description&redir_token=QUFFLUhqbjVhZVp4Q21iWVh2c09SWUZMRzNELVBmVUJMZ3xBQ3Jtc0ttWUhFUDhFRGdRNE9sRUZXTmJsRmtXb2xubmdLZFVvTVNza1RTeEZUa2Vzb2lJb2swclg0THhHVURfRVFRd2JJUTVYM084UUlIR2dGbWNabXo0ekVvdjhDb2RkenQwakllcU9hTlZ5blliVnJjU1hlTQ&q=http%3A%2F%2Ftwitter.com%2Fdavidusher)​

David Usher is an artist, best-selling author, entrepreneur, and keynote speaker. As a musician, he has sold more than 1.4 million albums, toured all over the world, and has had #1 singles singing in English, French, and Thai. When David is not making music, he is equally passionate about his other life, as the founder and creative director of Reimagine AI. Reimagine AI is an artificial intelligence creative studio that builds and deploys interactive virtual beings. David is an in-demand keynote speaker and travels the world speaking about creativity, innovation, and artificial intelligence. He is also the co-creator (with Dr. Damon Matthews) of the Climate Clock.

Washington Post Best Selling Author and Motivational Keynote Speaker, [Laura Gassner Otting](https://lgo2.kinsta.cloud/speaking/), inspires people to push past the doubt and indecis

*[... truncated, 551 more characters]*

---

### REIMAGINE AI | LinkedIn
*1,930 words* | Source: **EXA** | [Link](https://ca.linkedin.com/company/reimagineai)

REIMAGINE AI | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/company/reimagineai#main-content)[LinkedIn](https://ca.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Join now](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Freimagineai&trk=organization_guest_nav-header-join)[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Freimagineai&fromSignIn=true&trk=organization_guest_nav-header-signin)

![Image 1: REIMAGINE AI’s cover photo](https://media.licdn.com/dms/image/v2/D4E3DAQHhAvHUXT7WRQ/image-scale_191_1128/image-scale_191_1128/0/1704971222819/reimagineai_cover?e=2147483647&v=beta&t=tZaoCsHynViKlom_qhwl-yRP4qAb6Q16tpHNA3EkxDA)

![Image 2: REIMAGINE AI](https://ca.linkedin.com/company/reimagineai)

REIMAGINE AI
============

Entertainment Providers
-----------------------

### Montreal, Québec  1,280 followers

#### Artificial Intelligence Venture Studio

[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Freimagineai&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://ca.linkedin.com/company/reimagineai)![Image 4](https://ca.linkedin.com/company/reimagineai) View all 4 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B51635036%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Freimagineai&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

Reimagine AI is an artificial intelligence venture studio launched in 2018 that builds AI-powered companies at the intersection of digital immortality, healthcare, and entertainment.

 Website [https://www.reimagine.ai/](https://www.linkedin.com/redir/redirect?url=https%3A%2F%2Fwww%2Ereimagine%2Eai%2F&urlhash=F97l&trk=about_website)
External link for REIMAGINE AI

 Industry  Entertainment Providers 

 Company size  2-10 employees 

 Headquarters  Montreal, Québec 

 Type  Privately Held 

 Founded  2018 

 Specialties  virtual beings, artificial intelligence, creative studio, artificial intelligence, virtual influencer, Large language models, interactive experiences, healthcare, virtual healthcare, eldercare, and seniors care 

Locations
---------

*    Primary Montreal, Québec H2T 1A8, CA [Get directions](https://www.bing.com/maps?where=Montreal+H2T+1A8+Qu%C3%A9bec+CA&trk=org-locations_url)

Employees at REIMAGINE AI
-------------------------

*   [![Image 5: Click here to view David Usher’s profile](https://ca.linkedin.com/company/reimagineai)### David Usher](https://ca.linkedin.com/in/davidusher?trk=org-employees)
*   [![Image 6: Click here to view Mercedes Cabezas-Watson’s profile](https://ca.linkedin.com/company/reimagineai)### Mercedes Cabezas-Watson](https://ca.linkedin.com/in/mercedes-cabezas-watson-049b9721b?trk=org-employees)

[See all employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B51635036%255D&trk=public_biz_employees-join)

Updates
-------

*   
[](https://www.linkedin.com/posts/reimagineai_httpslnkdinefqewvnk-activity-7400555590135205889-EcsU)

[![Image 7: View organization page for REIMAGINE AI](https://ca.linkedin.com/company/reimagineai)](https://ca.linkedin.com/company/reimagineai?trk=organization_guest_main-feed-card_feed-actor-image)[REIMAGINE AI](https://ca.linkedin.com/company/reimagineai?trk=organization_guest_main-feed-card_feed-actor-name) 
1,280 followers

 1w    

    *   [Report this post](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Freimagineai&trk=organization_guest_main-feed-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=POST&_f=guest-reporting)

[https://lnkd.in/efQEWVnK](https://lnkd.in/efQEWVnK?trk=organization_guest_main-feed-card-text)

[![Image 8: View profile for David Usher](https://ca.linkedin.com/company/reimagineai)](https://ca.linkedin.com/in/davidusher?trk=organization_guest_main-feed-card_reshare_feed-actor-image)

[David Usher](https://ca.linkedin.com/in/davidusher?trk=organization_guest_main-

*[... truncated, 33,068 more characters]*

---

### Library — REIMAGINE AI
*801 words* | Source: **EXA** | [Link](https://www.reimagine.ai/library)

Library — REIMAGINE AI

===============

[0](https://www.reimagine.ai/cart)

[Skip to Content](https://www.reimagine.ai/library#page)

[![Image 1: REIMAGINE AI](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/b9fe8fcf-9542-456a-b41e-7420293fa841/Reimagine+logo+white.png?format=1500w)](https://www.reimagine.ai/)

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

English

Open Menu Close Menu

[![Image 2: REIMAGINE AI](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/b9fe8fcf-9542-456a-b41e-7420293fa841/Reimagine+logo+white.png?format=1500w)](https://www.reimagine.ai/)

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

English

Open Menu Close Menu

[OUR WORK](https://www.reimagine.ai/)

[SECONDECHO](https://www.reimagine.ai/secondecho)

[LUCY AI](https://www.reimagine.ai/lucyai)

[MEMORY CARE](https://www.reimagine.ai/memorycare)

[ABOUT US](https://www.reimagine.ai/aboutus)

[CONTACT](https://www.reimagine.ai/contact)

[English](https://www.reimagine.ai/library#)

[Back](https://www.reimagine.ai/)

![Image 3](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/da55dde8-0902-4a44-af2a-5ca5af488fca/Default_fill_the_frame_full_with_wild_colourful_orchids_and_e_0.jpg)

Let’s connect on LinkedIn:[**LINKEDIN**](https://www.linkedin.com/in/davidusher/)

Sign up to [**SECONDECHO**](https://www.secondecho.ai/)

**AI LIBRARY • REFERENCE LISTS**
--------------------------------

**Large Language Models**
-------------------------

(If you are just beginning using LLMs at work, this Hubspot Guide to Claude AI for Enterprise is a great place to start) [Download](https://www.reimagine.ai/s/The-Complete-Guide-To-Claude-AI.pdf)

[Openai Chatgpt](https://openai.com/chatgpt/overview/)

[Deepseek](https://chat.deepseek.com/)

[Anthropic Claude](https://www.anthropic.com/)

[Groq Inference Engine (Delivering Open-Source Models with extremely low latency)](https://groq.com/)

[Google Gemini](https://aistudio.google.com/prompts/new_chat?model=gemini-2.0-flash-exp)

[Grok](https://x.ai/)

**MY AI ART WORKFLOW**
----------------------

Here is the breakdown of the process of making my first full AI music video for Run to the Sea.

The song itself, I made it with my human friends.

The concept for the video was to use a couple of my solo album covers as inspiration (Little Songs, and Morning Orbit) and make a video featuring the “younger” version of me from that era.

The 2 new developments happened this month that I’ve been waiting for, before giving a full video a try: Runway’s Act One for lipsync, and Openart making it simple to fine-tune a Flux model to create consistent characters.

Obviously, the video is not perfect but the tech is so new, and as an experiment, I think it points to what will be possible.

So here is the workflow I used, a lot of trial and error, things I learned and would do differently next time.

First I used [OpenArt](https://openart.ai/home) to fine-tune a Flux model on myself. Openart is a platform that has a ton of different tools and a great place to experiment with different Gen AI. I uploaded about 20 images of me and trained the model.

For image generation I also used Openart, I loaded the trained Flux model of me and started the prompt with “Younger David Usher…” I didn’t use negative prompting, and I would start with 1 generation to test the prompt, and then when I got an image that was on the right track I moved to 4 at a time.

The images were good but low res, so I used an Openart upscaler. (if I were to do this again I would probably use [Magnific](https://magnific.ai/upgrade/) or [Topaz Upscale](https://www.topazlabs.com/topaz-video-ai) to upscale so I would have more resolution going into the video stage)

For image to video, I used either [Kling](https://klingai.com/) or [Runway](https://runwayml.com/). When I wanted just motion I would use Kling, great interface, and I like how you can extend the clips.

For lipsync, I used Runway, their new Act One feature very cool. With Act One you need to load an image as the source, but also a “driving video” that shows the AI the mouth and head placement for the lipsync. I went pretty lo-fi on this and shot myself against the hotel bathroom shower curtain with my iPhone. (I was on the road for some keynote gigs, so lots of hotels). I think if I actually spent more time on the driving videos, the lipsync would be better.

I edited it on my MacBook with iMovie.

The total cost was probably around $200 in generation credits. (For one of my vid

*[... truncated, 6,137 more characters]*

---

### Ubisoft launches Tech Makers, a podcast about some of the video game industry’s most innovative work
*655 words* | Source: **GOOGLE** | [Link](https://www.ubisoft.com/en-us/studio/laforge/news/6iskJr33y9JsMCloONyHJX/ubisoft-launches-tech-makers-a-podcast-about-some-of-the-video-game-industrys-most-innovative-work)

![Image 1: [La Forge] Ubisoft launches Tech Makers, a podcast about some of the video game industry’s most innovative work - Techmakers](https://staticctf.ubisoft.com/J3yJr34U2pZ2Ieem48Dwy9uqj5PNUQTn/1vKIhZXwe90cuSF3nwNdmI/b9d1ad151639f5fa1eed5430da769f02/-La_Forge-_Bandeau_TechMakers_EN-768x170.png)

 Welcome to Tech Makers, a Ubisoft podcast. In this first series, we’re celebrating 5 years of innovation at La Forge. In this exclusive sneak peek, you will meet the people working on some of the video game industry’s most promising innovations. Get ready to learn more about the project’s origins and discover various prototypes and breakthroughs whose impacts are felt far beyond the world of gaming.

Tech Makers was directed by Bruno Guglielminetti and produced by Stéphane Berthomet (Go-script média), about the origin and development of some of the most exciting innovations in the video game industry. Hosted by David Usher, founder, and creative director of Reimagine AI, this five-episode podcast will show you how researchers and industry professionals alike convert their hypotheses into prototypes that have tangible effects on games loved by millions of fans around the world:

[**Episode 1—LA FORGE**](https://open.spotify.com/episode/7drPqm8Nk0qRKclxFMwFrq?si=qr6YcAccRWSNDphh7idoxQ)

In this first episode, you will dive into the world of the founders of Ubisoft La Forge, research, and development lab, which is celebrating its 5th anniversary this year. Travel back in time to its creation and discover its many impacts, triumphs, and of course … its failures.

```
Guests: Yves Jacquier (Executive Director—Ubisoft La Forge), Olivier Pomarez (Director of Development—Ubisoft La Forge) and Cédric Decelle (VP Technology —Ubisoft Montréal)
```

[**Episode 2—CHARACTERS**](https://open.spotify.com/episode/3CK0J7P1Bs5nXxU9KBvTvq?si=3lxz2fTNSvG5Vc3PqkintA)

In this second episode, we explore how scientists at La Forge are revolutionizing video game characters and how text-to-speech technology is helping our artists improve and refine the gaming experience by making character voices more realistic. You will also learn about Choreograph—a prototype that anticipates the movements of playable characters and gives them a fluidity like those recorded in motion capture.

```
Guests: Marc-André Carbonneau (R&D Scientist and Director of a team of researchers on speech and sound machine learning—Ubisoft La Forge—TTS), Ylva Ferstl (R&D Scientist—Ubisoft La Forge, Toronto), David Coulombe (Production Manager — Services) and Raphaël Saint-Pierre (Engine Programmer—Far Cry)
```

[**Episode 3 — ENVIRONMENTS**](https://open.spotify.com/episode/37VkBUyP4Ie7U9yaMEKI75?si=3d95e2d9be824baf)

In this third episode, we discuss the Torch prototype, which combines physics and programming to improve on traditional methods of animating fluids such as water, air, and fire. We also dig into the differences between academic and corporate environments, and how La Forge manages to bring these two worlds together through research and development.

```
Guests: Shahin Rabbani (R&D Scientist and Lead of the Environment Team at Ubisoft—Ubisoft La Forge—Torch) and Claude Langlais (Director Pipeline Information)
```

[**Episode 4—ACTION**](https://open.spotify.com/episode/0AlOCENWkCtdIGYhEqfDXg?si=579c36ab6f184fbf)

In this fourth episode, we explain how the SmartNav prototype manages to create more realistic and responsive behaviours for non-playable characters and how their design enhances the immersive experience for players in various open-world games.

```
Guests: Joshua Romoff (Research Scientist at Ubisoft—Ubisoft La Forge—SmartNav), Gabriel Robert (Technical Lead—Ubisoft La Forge) and Julien Varnier (Technical Architect for AI & Gameplay—Far Cry 5, 4 & 3)
```

[**Episode 5— BEYOND TECH**](https://open.spotify.com/episode/26iQwJUH9dJWXb9Og4L0Hn?si=bdfb7f6509b44fa2)

In this final episode, our experts discuss innovations beyond gaming. For example, how the self-driving cars in Watch Dogs can teach kids the basics of machine learning, how AI can raise climate-change awareness by simulating its possible consequences, and how our research is helping counter dangerous online behaviours thanks to some unexpected allies…

```
Guests: Elisabeth Doyon (Student at Université de QUébec à Montréal(UQAM)— CSM AI for kids), Amanda Jarrell ([MURL], User Research Project Manager—Ubisoft—ToxBuster) and Andrea Feder (Production Manager — Ubisoft La Forge)
```

All the episodes are also available on all streaming platforms.

Series credits:

A podcast produced by Ubisoft La Forge.

 Production: Josée Laterreur, Marie-Line Paquet

 Executive production: Stéphane Berthomet – Go-Script media

 Director: Bruno Guglielminetti

 Animation: David Usher

 Editorial direction: Yves Jacquier, Olivier Pomarez, Andrea Feder, Josée Laterreur

 Production assistant: Sophie Thifault

 Public Relations: Antoine Leduc-Labelle

Enjoy your listening!

Want to know more about our research

*[... truncated, 156 more characters]*

---

### Broadcast Dialogue - The Podcast: David Usher & Catherine Warren on the future of AI in the Creative Industries - Broadcast Dialogue
*1,680 words* | Source: **GOOGLE** | [Link](https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries/)

Broadcast Dialogue - The Podcast: David Usher & Catherine Warren on the future of AI in the Creative Industries - Broadcast Dialogue

===============

[Facebook](https://www.facebook.com/broadcastdialogue/ "Facebook")[Instagram](https://www.instagram.com/broadcastdialogue/ "Instagram")[Linkedin](https://www.linkedin.com/company/broadcast-dialogue "Linkedin")[Mail](mailto:info@broadcastdialogue.com "Mail")[Spotify](https://open.spotify.com/show/4AIZVJ4RopqEAKgEhPu9gx "Spotify")[Twitter](https://twitter.com/BroadcastDialog "Twitter")

*   [Sign In](https://broadcastdialogue.com/my-account/)
*   [Subscribe Now – Free!](https://broadcastdialogue.com/subscribe)
*   [Job Listings](https://broadcastdialogue.com/careers-2/)
*   [Post Your Job Listing](https://broadcastdialogue.com/post-a-career/)
*   [Events](https://broadcastdialogue.com/events/)
*   [Advertise With Us](https://broadcastdialogue.com/advertising/)
*   [About](https://broadcastdialogue.com/about/)
*   [Contact](https://broadcastdialogue.com/contact/)

Search

[![Image 3: topLogo](https://broadcastdialogue.com/wp-content/uploads/2016/08/topLogo.png)Broadcast Dialogue Broadcast Dialogue](https://broadcastdialogue.com/)

*   [Sign In](https://broadcastdialogue.com/my-account/)
*   [Subscribe Now – Free!](https://broadcastdialogue.com/subscribe)
*   [Job Listings](https://broadcastdialogue.com/careers-2/)
*   [Post Your Job Listing](https://broadcastdialogue.com/post-a-career/)
*   [Events](https://broadcastdialogue.com/events/)
*   [Advertise With Us](https://broadcastdialogue.com/advertising/)
*   [About](https://broadcastdialogue.com/about/)
*   [Contact](https://broadcastdialogue.com/contact/)

[Twitter](https://twitter.com/BroadcastDialog "Twitter")

[Instagram](https://www.instagram.com/broadcastdialogue/ "Instagram")

[Linkedin](https://www.linkedin.com/company/broadcast-dialogue "Linkedin")

[Spotify](https://open.spotify.com/show/4AIZVJ4RopqEAKgEhPu9gx "Spotify")

[Mail-1](mailto:info@broadcastdialogue.com "Mail-1")

[![Image 4: topLogo](https://broadcastdialogue.com/wp-content/uploads/2016/08/topLogo.png)](https://broadcastdialogue.com/)

[![Image 5](https://broadcastdialogue.com/wp-content/uploads/2025/02/MusicMater728x90.jpg)](https://musicmaster.com/?webbd)![Image 6](blob:http://localhost/5b53771eeb35929db25773b2f8b22705)

*   [Radio + Podcast](https://broadcastdialogue.com/category/radio-audio/)
*   [TV + Film](https://broadcastdialogue.com/category/television-film/)
*   [Online](https://broadcastdialogue.com/category/online-digital/)
*   [Tech](https://broadcastdialogue.com/category/broadcast-tech/)
*   [General News](https://broadcastdialogue.com/category/general/)
*   [Revolving Door](https://broadcastdialogue.com/category/revolving-door/)
*   [Sign Offs](https://broadcastdialogue.com/category/sign-offs/)
*   [The Podcast](https://broadcastdialogue.com/category/broadcast-dialogue-podcast/)
*   [Jobs](https://broadcastdialogue.com/careers-2/)

Search

[](https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries/#)

[Home](https://broadcastdialogue.com/)[Broadcast Dialogue - The Podcast](https://broadcastdialogue.com/category/broadcast-dialogue-podcast/ "View all posts in Broadcast Dialogue - The Podcast")Broadcast Dialogue - The Podcast: David...

Broadcast Dialogue – The Podcast: David Usher & Catherine Warren on the future of AI in the Creative Industries
===============================================================================================================

[![Image 7: Connie Thiessen](https://broadcastdialogue.com/wp-content/uploads/2024/04/avatar_user_44_1712622561-96x96.jpg)](https://broadcastdialogue.com/author/connie/ "Connie Thiessen")

[Connie Thiessen](https://broadcastdialogue.com/author/connie/)

December 6, 2019

[Twitter](https://twitter.com/intent/tweet?text=Broadcast+Dialogue+%E2%80%93+The+Podcast%3A+David+Usher+%26+Catherine+Warren+on+the+future+of+AI+in+the+Creative+Industries&url=https%3A%2F%2Fbroadcastdialogue.com%2Fbroadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries%2F&via=BroadcastDialog+ "Twitter")[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries/&title=Broadcast+Dialogue+%E2%80%93+The+Podcast%3A+David+Usher+%26+Catherine+Warren+on+the+future+of+AI+in+the+Creative+Industries "Linkedin")[Email](mailto:?subject=Broadcast%20Dialogue%20%E2%80%93%20The%20Podcast:%20David%20Usher%20&%20Catherine%20Warren%20on%20the%20future%20of%20AI%20in%20the%20Creative%20Industries&body=https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries/ "Email")[Copy URL](https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-a

*[... truncated, 16,053 more characters]*

---

### Musician-turned-researcher David Usher is exploring the human side of artificial intelligence | CBC Radio
*1,338 words* | Source: **GOOGLE** | [Link](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)

Musician-turned-researcher David Usher is exploring the human side of artificial intelligence | CBC Radio

===============

[Content](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090#content)

[Skip to Main Content](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090#content)[Accessibility Help](https://www.cbc.ca/accessibility)

[Menu](https://www.cbc.ca/sitemap)

[](https://www.cbc.ca/)

When search suggestions are available use up and down arrows to review and enter to select.

Search

[Search](https://www.cbc.ca/search)

Sign In

##### Quick Links

*   [News](https://www.cbc.ca/news)
*   [Sports](https://www.cbc.ca/sports)
*   [Radio](https://www.cbc.ca/radio)
*   [Music](https://www.cbc.ca/music)
*   [Listen Live](https://www.cbc.ca/listen/live-radio)
*   [TV](https://www.cbc.ca/television)
*   [Watch](https://gem.cbc.ca/)

*   [radio](https://www.cbc.ca/radio) 
*   [Top Stories](https://www.cbc.ca/radio)
*   [Shows](https://www.cbc.ca/radio/shows)
*   [Podcasts](https://www.cbc.ca/radio/podcasts)
*   [Schedules](https://www.cbc.ca/programguide/daily/today/cbc_radio_one)
*   [Frequency](https://www.cbc.ca/radio/frequency)
*   [Listen Live](https://www.cbc.ca/listen/live-radio)
*   More 

Musician-turned-researcher David Usher is exploring the human side of artificial intelligence | CBC Radio Loaded

[Spark](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048)
Musician-turned-researcher David Usher is exploring the human side of artificial intelligence
=============================================================================================

An AI project from a Montreal-based creative studio is aiming to connect with humans beyond simple information retrieval.

AI projects aim to connect with humans beyond simple 'information retrieval,' Usher says
----------------------------------------------------------------------------------------

CBC Radio · Posted: Dec 27, 2019 2:01 PM EST | Last Updated: December 27, 2019

![Image 5](https://i.cbc.ca/ais/1.5155222,1559179258000/full/max/0/default.jpg?im=Crop%2Crect%3D%2864%2C0%2C1773%2C997%29%3B)

The AI agent named 'Ophelia' was part of the We Could Be Human: A Learning Machine exhibit at the Phi Centre in Montreal, Que. (Submitted by Phi Centre)

Social Sharing
--------------

*   [X 0](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)
*   [Pinterest 0](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)
*   [Reddit 0](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)
*   [LinkedIn 0](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)
*   [Email 0](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)

Instead of asking Siri to tell you the latest news or fetch the weather forecast, David Usher wants us to have meaningful conversations with artificial intelligence.

"What we're trying to do is force the user [to] have conversations about love and death, the meaning of life, what is AI, and what is humanity, what is climate change — those kinds of things," the musician-turned-AI researcher told _[Spark](http://cbc.ca/spark)_ host Nora Young.

This exploration of the more philosophical side of artificial intelligence is at the heart of[ReImagine AI](https://www.reimagine.ai/), the Montreal-based artificial intelligence creative studio that Usher founded. The studio collaborates with university research labs and science centres across Canada to integrate human interaction into AI.

"We're trying to build something that's a lot more conversational," Usher said.

One of the ways to do this, he explained, is to avoid the temptation of using AI only for information retrieval, by keeping it disconnected from the internet. One of the lab's current projects is an AI avatar called Ophelia, which only uses information gathered from its interaction with users to engage with them.

![Image 6](https://i.cbc.ca/ais/1.5155218,1717209327420/full/max/0/default.jpg?im=Crop%2Crect%3D%280%2C0%2C852%2C479%29%3BResi

*[... truncated, 12,519 more characters]*

---

### Reimagine AI
*676 words* | Source: **GOOGLE** | [Link](https://www.reimagine.ai/)

**_the_****AI VENTURE****STUDIO**
---------------------------------

Building the interface between AI and the Human Experience

![Image 1](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/e3b694a1-a6ee-43c3-88ac-5aee29226c04/Screenshot+2025-07-29+at+5.31.46%E2%80%AFAM.png)

**SECONDECHO**
--------------

The 21st-century way to save and share your story. Your thoughts, feelings and memories, forever. Sign up now to join the beta.

![Image 2](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/48121b2b-3448-4242-8f21-c5ec2fbc6689/Screenshot+2025-09-17+at+10.05.06%E2%80%AFAM.png)

**KIDS CARE****AI**
-------------------

Reimagine AI is working with Dr. Dominic Venne, Chief of Surgery and Pediatric Neurosurgery at St. Justine Hospital to develop AI companions to support children through their surgical journey. Kids Care AI will also begin trials with childern with Autism, fall 2025.

**LUCY****AI****(the EXHIBIT)**
-------------------------------

At the age of 49 Lucy Simic, artistic director of bluemouth inc was diagnosed with stage 4 lung cancer. LUCY AI is an immersive multimedia experience where we invite participants to talk to Lucy AI, and then see into her memories, into her mind.

![Image 3](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/39bcb77e-f01a-4f0d-9457-289616e726d5/CNN.svg.png)

![Image 4](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/8a734121-4956-4437-8801-4254172cb43e/undefined-high+%2827%29.gif)

**CNN podcast Terms of Service** Featuring Lucy Simic and David Usher discussing Lucy AI in NYC

**REIMAGINE****HEALTH**
-----------------------

AI Virtual Companions for the elderly, memory and Alzheimer's patients.

[![Image 5](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/fb865703-4d28-44d5-bfa3-82bf4d9df71a/tht.jpg)](https://vimeo.com/888300226?share=copy#t=0)

![Image 6](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/eb477855-4bb6-49fb-b6ed-6cd188f51d7b/Reimagine+Reception+Logo+2.png)

**REIMAGINE****RECEPTION**
--------------------------

Revolutionizing healthcare reception. Peak times. Overnight. Weekends. Our AI-powered Voice receptionists make sure your customers are never left hanging. Or hanging up. Call our reception now!

![Image 7](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/9bc41002-ed69-4a60-a80e-1118ba872689/IMG_0034-topaz33-face-upscale-4x+2.jpeg)

**ASK****LUCY****AI**
---------------------

**Real Conversations for Cancer Patients and Their Loved Ones**At the age of 49 Lucy Simic, artistic director of bluemouth inc was diagnosed with stage 4 lung cancer. **Ask Lucy AI** is an interactive virtual experience designed to provide recently diagnosed cancer patients and their loved ones with a space to speak openly with someone who has walked a similar path.

![Image 8](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/1a72a218-5a8a-4ebe-8125-8e80f514b4b9/tumblr_lqjmvhCBbd1qd84n8o1_500.gif)

**ONE TIMES SQUARE****NYC**
---------------------------

Premiering Fall 2025

Reimagine AI has been commissioned to create an AI-powered virtual being for a new permanent exhibit in Times Square. In collaboration with Behaviour Interactive.

[![Image 9](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/4560af6e-9cf7-40da-9154-0c3ce4c7efa7/Screenshot+2023-11-25+at+5.40.53%E2%80%AFPM.jpg)](https://vimeo.com/888213416?share=copy)

**_this_****ALIEN****HEART**
----------------------------

Premiered March 2023 at the MONOM, Berlin 

Reimagine AI, in collaboration with LedPulse presented the world’s first interactive AI in a 3D volumetric display: _this Alien Heart_

![Image 10](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/50d038cd-5b02-4f9a-9004-ddb02b877ae3/undefined-high+%2832%29.gif)

**MEMRY**
---------

**Watch the Trailer**

Discover the adventures of _MEMRY,_ a new animated series featuring AI-powered interactive characters. 

Winner of NUMIX 2024

Web and Application – Experience

![Image 11](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/ba7ccdb7-aa28-4891-b6eb-b87a3d4c2fde/Ernst-Young-Symbol.png)

**ERNST &****YOUNG**
--------------------

Ernst & Young 2023 World Conferences: 

New York City,London, Singapore, Palo Alto, and Munich.

Reimagine AI provided the conference series with five unique AI-powered virtual beings: attendees could interact with these beings to learn more about EY.

**Run to the Sea by David Usher**Human song • AI music video

[![Image 12](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/7cd6cd12-dcd9-4ed8-b5d0-ed2f60180e7d/Screenshot+2024-11-15+at+2.56.07%E2%80%AFAM.png)](https://vimeo.com/1026896746?share=copy#t=0)

![Image 13](https://images.squarespace-cdn.com/content/v1/5f1c94f0da02446a43383527/7fb8e585-550d-4e16-b03a-9a9c052289ec/undefined-high+%2816%29.gif)

**LOUVRE****MUSEUM PARI

*[... truncated, 2,893 more characters]*

---

### DAVID USHER
*325 words* | Source: **GOOGLE** | [Link](https://www.davidusher.com/)

![Image 1](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/1620440697141-425VM4YHY8U161BI0VGP/KG2_5833-2.jpeg)

David Usher is an artist, [best-selling author](https://www.davidusher.com/author), [keynote speaker](https://davidusher.com/speaking), and the founder of [Reimagine AI](https://www.reimagine.ai/), an artificial intelligence creative studio. As a musician, he has sold more than 1.4 million albums, toured all over the world, and has had #1 singles singing in English, French, and Thai. He is also the co-creator (with Dr. Damon Matthews) of the [Climate Clock](https://climateclock.net/), tracking global warming in real-time. David has a degree in political science from Simon Fraser University and his book on creativity and innovation,Let the Elephants Run•Unlock Your Creativity and Change Everything,is out now

**Connect with David on**[**Linkedin**](https://www.linkedin.com/in/davidusher/)

#### **Tour Summer 2025**

![Image 2: Slide 2](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/f10529f9-de48-4e96-bc08-48cf00449e14/IMG_8434+3.JPG)

![Image 3: Slide 3](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/315e5cd9-91e0-4e8a-b441-81d9c76cfac0/IMG_8438+2.JPG)

![Image 4: Slide 1 (current slide)](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/1754338331826-IH04MEL8VYG4C0UXSNNE/IMG_8437%2B3.png)

![Image 5](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/1620462185828-SB5BG8XMOOSVDHYPPLRM/DSC04687.jpg)

> “Go ahead, write in this book. I dare you. David’s writing will change you, possibly forever.”

— Seth Godin

> “We have been given a very short window of opportunity, that’s why the Climate Clock is so important. The clock is ticking and we need to be reminded of how little time we have left to act.”

— David Suzuki

> “David’s insightful take on how to both unleash and control one’s own creativity is particularly relevant in today’s world, where new ideas and innovation are becoming a key part of our everyday lives. ”

— Justin Trudeau

![Image 6: CTSymposium2025-Day2-206-WEB.jpg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/5ce19b35-4fed-499b-8490-11a1a33542e7/CTSymposium2025-Day2-206-WEB.jpg)

![Image 7: CTSymposium2025-Day2-208-WEB.jpg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/e68c8818-2f3b-419c-a1e0-1318178009b3/CTSymposium2025-Day2-208-WEB.jpg)

![Image 8: CTSymposium2025-Day2-216-WEB.jpg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/b8c77c4a-8575-4233-ba70-fc513b1ba8c9/CTSymposium2025-Day2-216-WEB.jpg)

### REIMAGINE AI

David is the founder and CEO of Reimagine AI:

Building the interface between artificial intelligence and the human experience.

![Image 9](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/f638e83e-42e1-461d-a6d6-3c0e51922d58/Screenshot+2025-10-07+at+11.23.55%E2%80%AFAM.png)

00:00

01:25

00:00

### SPEAKING

David speaks to companies all over the world about creativity, innovation and artificial intelligence.

CLIENTS INCLUDE:

![Image 10: 7F01E0BF-4060-464A-8169-697D599E0141_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/4b666b8c-139b-45d9-ab8a-4e142db3746e/7F01E0BF-4060-464A-8169-697D599E0141_1_105_c.jpeg)

![Image 11: A21E7661-AB76-4D18-8397-FCD32C030495_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/2e681422-718e-484e-846c-6d1da0dd74e0/A21E7661-AB76-4D18-8397-FCD32C030495_1_105_c.jpeg)

![Image 12: 042CF6B8-B837-4E4D-A29C-541ECE6614BE_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/83c8ad82-f7e4-41cb-bbbf-ea6c4df48ba8/042CF6B8-B837-4E4D-A29C-541ECE6614BE_1_105_c.jpeg)

![Image 13: 458CD9B5-CC81-42A6-9E8E-CE1F5F8F8BA4_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/cb9bb0f8-7f9c-4665-b36e-784331a2e3e1/458CD9B5-CC81-42A6-9E8E-CE1F5F8F8BA4_1_105_c.jpeg)

![Image 14: 50A4580F-B7B4-4FF4-B6ED-3EBB2B609199_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/409d55c4-6a83-4ac7-ad85-8d1cacb1de03/50A4580F-B7B4-4FF4-B6ED-3EBB2B609199_1_105_c.jpeg)

![Image 15: 6CA93BA1-DF8C-45C0-AF75-730AB1BA51AB_1_105_c.jpeg](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/a6cccb8e-40a2-4999-afcc-b2e8a258411d/6CA93BA1-DF8C-45C0-AF75-730AB1BA51AB_1_105_c.jpeg)

### Let the Elephants Run

David’s Best Selling book on creativity and the creative process. [Learn more…](https://davidusher.com/author)

![Image 16: IdeaForest_Facebook-1.png](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/1620466759695-QAV7QGVFQ9BS7XMMECS2/IdeaForest_Facebook-1.png)

![Image 17: DanceMarathon_Twitter.png](https://images.squarespace-cdn.com/content/v1/60957662d7cf687cf2fa6b1a/1620466785920-JC5OHBCTO6ZKD2RHVQZR/DanceMarathon_Twitter.png)

![Image 18: AluminumHat_Facebook-1.png](https:/

*[... truncated, 781 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[David Usher: Where Does Creativity Come From? - Laura Gassner ...](https://lauragassnerotting.com/lgotv-interview/david-usher-bigtalk/)**
  - Source: lauragassnerotting.com
  - *Apr 21, 2021 ... Reimagine AI is an artificial intelligence creative studio that builds and deploys interactive virtual beings. David is an in-demand ...*

- **[Ubisoft launches Tech Makers, a podcast about some of the video ...](https://www.ubisoft.com/en-us/studio/laforge/news/6iskJr33y9JsMCloONyHJX/ubisoft-launches-tech-makers-a-podcast-about-some-of-the-video-game-industrys-most-innovative-work)**
  - Source: ubisoft.com
  - *Apr 19, 2022 ... Hosted by David Usher, founder, and creative director of Reimagine AI, this five-episode podcast will show you how researchers and in...*

- **[The Podcast: David Usher & Catherine Warren ... - Broadcast Dialogue](https://broadcastdialogue.com/broadcast-dialogue-the-podcast-david-usher-catherine-warren-on-the-future-of-ai-in-the-creative-industries/)**
  - Source: broadcastdialogue.com
  - *Dec 6, 2019 ... David Usher, Moist frontman and founder of Reimagine.AI, a creative studio specializing in AI, interacting with 'Ophelia' at the Telef...*

- **[Musician-turned-researcher David Usher is exploring the human ...](https://www.cbc.ca/radio/spark/how-making-ai-do-goofy-things-exposes-its-limitations-1.5404048/musician-turned-researcher-david-usher-is-exploring-the-human-side-of-artificial-intelligence-1.5404090)**
  - Source: cbc.ca
  - *Dec 27, 2019 ... ... David Usher ... This exploration of the more philosophical side of artificial intelligence is at the heart of ReImagine AI, the M...*

- **[Reimagine AI](https://www.reimagine.ai/)**
  - Source: reimagine.ai
  - *CNN podcast Terms of Service Featuring Lucy Simic and David Usher discussing Lucy AI in NYC ... 2016 • David Usher (founder of Reimagine AI) worked wi...*

- **[DAVID USHER](https://www.davidusher.com/)**
  - Source: davidusher.com
  - *David Usher is an artist, best-selling author, keynote speaker, and the founder of Reimagine AI, an artificial intelligence creative studio....*

- **[How Your Memories Can Live On After You Die - Terms of Service ...](https://www.cnn.com/audio/podcasts/terms-of-service-with-clare-duffy/episodes/55ae436e-25e7-11f0-a31f-e3438bb5cfca)**
  - Source: cnn.com
  - *Aug 26, 2025 ... Well, David Usher, thank you for doing this. ... David's company, Reimagine AI, is also exploring other applications of AI virtual be...*

- **[What making music taught David Usher about running an AI startup ...](https://betakit.com/what-making-music-taught-david-usher-about-running-an-ai-startup/)**
  - Source: betakit.com
  - *Jun 27, 2025 ... Podcast · Newsletter · Quiz · Jobs. What making music ... Musician and Reimagine AI founder David Usher with one of the AI avatars hi...*

- **[David Usher - Wikipedia](https://en.wikipedia.org/wiki/David_Usher)**
  - Source: en.wikipedia.org
  - *He has also released a number of solo albums. He is the founder of Reimagine AI, an artificial intelligence creative studio. David Usher....*

- **[Artificial Intelligence and the Power of Creative Thinking with David ...](https://www.ualberta.ca/en/events/alumni/artificial-intelligence-and-the-power-of-creative-thinking-with-david-usher.html)**
  - Source: ualberta.ca
  - *May 15, 2025 ... David Usher Live Online: Music, AI, and the Future of Creativity ... Reimagine AI, to help organizations reboot their creativity in t...*

---

*Generated by Founder Scraper*
