# Robin Franciosa

## Position actuelle

**Titre** : Account Manager
**Entreprise** : GRAITEC GROUP
**Durée dans le rôle** : 1 year 4 months in role
**Durée dans l'entreprise** : 1 year 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

I support AEC industry stakeholders in their digital transformation.
- Managing a client portfolio in the field of architecture
- Offering BIM solutions based on Autodesk and Graitec to optimize productivity
- Providing strategic guidance to address competitiveness and remote collaboration challenges

## Résumé

As an experienced account manager, my passion for new technologies has driven me to contribute to businesses' digital transformation.

I work closely with AEC companies to identify and develop technical solutions tailored to meet their operational needs. It enhanced my understanding and interest in digital innovations, particularly digital twins, connected systems, cloud computing, and SaaS business models.

My areas of expertise include consultative sales and business management. I am accustomed to managing the entire sales lifecycle, building weekly pipelines, providing advice on technical solutions, closing deals, and elaborating partnerships.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABS5FpEBGTSkzfa3tjbSYL5a9YxfDqq3GOU/
**Connexions partagées** : 5


---

# Robin Franciosa

## Position actuelle

**Entreprise** : GRAITEC GROUP

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Robin Franciosa

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392421649804906497 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEjYhnmAPaklQ/feedshare-shrink_800/B4EZpcoRy6HcAk-/0/1762490661053?e=1766620800&v=beta&t=3QQGRIpyO_Cf7X3pOTjlcRhmtDYjYtQnuhg2yDvFADs | Ce midi, la communauté BIM montréalaise s’est réunie autour des outils Ideate Software, GRAITEC Group pour Revit.

Merci à Annie Tourville (Kelvin Emtech), Edgar Contreras (Stantec) et à Yoan FOURNY (GRAITEC CANADA) pour leurs démonstrations concrètes.

De belles discussions sur l’optimisation, la précision et l’automatisation dans nos workflows. | 28 | 1 | 0 | 1mo | Post | Robin Franciosa | https://www.linkedin.com/in/robin-franciosa | https://linkedin.com/in/robin-franciosa | 2025-12-08T07:20:46.346Z |  | 2025-11-07T04:44:25.866Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7387117056116097024 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e5a5ecad-3259-410e-bf3a-4fd847e47404 | https://media.licdn.com/dms/image/v2/D4E10AQEez2E0exEhUg/ads-video-thumbnail_720_1280/B4EZoHg2JsIMAY-/0/1761062642604?e=1765785600&v=beta&t=dV1SEivFivVtqggtF4etF0OrEfx6uhe-73gbshkdG00 | Rendez-vous le 6 novembre pour l'événement Ideate au centre ville de Montréal 

Venez découvrir comment les firmes de l'AEC optimisent leur flux de travail Revit avec les plug-ins Ideate.

📅 6 novembre 2025 entre 11h et 13h
 📍 WeWork, 1010 rue Sainte-Catherine Ouest (station Peel)
 🥗 Événement gratuit – lunch offert

Réservez votre billet dès maintenant, places limitées

#Revit #BIM #AEC #Ideate #Graitec #Architecture #Ingénierie #Formation #Montreal | 1 | 1 | 0 | 1mo | Post | Robin Franciosa | https://www.linkedin.com/in/robin-franciosa | https://linkedin.com/in/robin-franciosa | 2025-12-08T07:20:46.348Z |  | 2025-10-23T13:25:52.176Z | https://www.linkedin.com/feed/update/urn:li:activity:7386432591316484096/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7328469455712251904 | Text |  |  | 🏗️ Ingénieurs structure, et si vos modélisations et assemblages devenaient plus fiables et rapides ?

Ne manquez pas les dernières places pour le Lunch & Learn Advance Design / IDEA StatiCa de mercredi prochain à Montréal.

✅ Découvrez comment ces outils se complètent pour améliorer la précision et la rapidité de vos analyses
✅ Échangez avec nos experts et vos pairs du secteur
✅ Profitez d’une démonstration concrète et posez vos questions en direct

🔗 Inscrivez-vous dès maintenant, l'événement est gratuit ! | 2 | 0 | 0 | 6mo | Post | Robin Franciosa | https://www.linkedin.com/in/robin-franciosa | https://linkedin.com/in/robin-franciosa | 2025-12-08T07:20:52.210Z |  | 2025-05-14T17:21:14.620Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7297701409611763713 | Text |  |  | 🏗️ Ingénieurs en structure, optimisez votre workflow avec Advance Design et IDEA StatiCa ! 

Vous travaillez sur des projets complexes et cherchez à optimiser vos calculs et vérifications ? Ne manquez pas notre Lunch & Learn à Québec !

📅 Date : 26 février 2024 entre 12h et 14h
📍 Lieu : Ville de Québec
🔍 Thème : Intégration de Advance Design et IDEA StatiCa pour des analyses et conceptions structurelles plus efficaces.

✅ Découvrez comment ces outils se complètent pour améliorer la précision et la rapidité de vos analyses
✅ Échangez avec nos experts et vos pairs du secteur
✅ Profitez d’une démonstration concrète et posez vos questions en direct

🔗 Inscrivez-vous dès maintenant. Places limitées, ne tardez pas !
Au plaisir de vous y voir

#BIM #IngénierieStructure #AdvanceDesign #IDEAStatiCa | 3 | 0 | 1 | 9mo | Post | Robin Franciosa | https://www.linkedin.com/in/robin-franciosa | https://linkedin.com/in/robin-franciosa | 2025-12-08T07:20:52.212Z |  | 2025-02-18T19:40:00.787Z |  |  | 

---



---

# Robin Franciosa
*GRAITEC GROUP*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Our Story | GRAITEC Group](https://graitec-group.com/meet-the-team/our-story/)
*2024-11-04*
- Category: article

### [Innovate2BUILD](https://webinars.graitec.com/innovate2build/register)
*2024-03-21*
- Category: article

### [Executive Committee | GRAITEC Group](https://graitec-group.com/meet-the-team/)
*2025-04-29*
- Category: article

### [The Fabrice Grinda Story by Robin Capital (Venture With Robin)](https://podcasters.spotify.com/pod/show/venturewithrobin/episodes/The-Fabrice-Grinda-Story-e2c339h/a-aakhcdf)
*2023-11-17*
- Category: podcast

### [GRAITEC GROUP Company Overview, Contact Details & Competitors](https://leadiq.com/c/graitec-group/5a1d975e2300005e0085ec8e)
*2025-03-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
