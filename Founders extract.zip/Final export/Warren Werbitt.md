# Warren Werbitt

## Position actuelle

**Titre** : Founder
**Entreprise** : www.theprintwhisperer.shop
**Durée dans le rôle** : 2 months in role
**Durée dans l'entreprise** : 2 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Description du rôle

Major Duties & Responsibilities

Founder & Brand Leader – Oversee the creative direction, strategy, and operations of The Print Whisperer Shop, aligning all activities with the brand’s mission to inspire connection, laughter, and positivity.

Product & Design Development – Create and curate premium-quality apparel inspired by four core themes: mental health, fishing, print, and AI, ensuring each piece reflects authenticity and purpose.

Marketing & Community Engagement – Lead brand storytelling across digital platforms, fostering awareness and engagement through humor, conversation, and shared passion.

Strategic Partnerships – Build relationships with industry professionals, print companies, and tech innovators to expand reach and drive collaboration.

E-commerce Management – Manage Shopify operations, including product launches, fulfillment coordination, and customer experience optimization.

Social Impact Leadership – Direct 10% of profits to the Make-A-Wish Foundation, reinforcing the brand’s commitment to giving back and spreading joy.
Key Achievements

Founded a purpose-driven lifestyle brand that merges creativity, print culture, and modern expression.

Developed unique, conversation-starting apparel lines such as “Ink in My Veins” that resonate with diverse audiences.

Established The Print Whisperer Shop as a natural extension of The Print Whisperer brand, combining passion, humor, and philanthropy.

Built a growing online presence that promotes positivity and sparks connection within the global print and creative communities.

Launched a socially responsible business model that balances revenue growth with meaningful charitable contribution.

## Résumé

Print Industry Veteran & Strategic Advisor | The Print Whisperer – Hook, Line & Thinker

🎣 From casting lines to closing deals — I’ve spent my life chasing the big catch, whether it’s a monster musky or a million-dollar client. The thrill is the same: patience, skill, and knowing when to reel it in.

With 30+ years in print, I built a company from the ground up to $18M in revenue and 120 employees. Now, I help print businesses worldwide work smarter, sell more, and make more money, without drowning in complexity.

I also mentor young people entering the industry, because the future of print depends on sharing what we know and inspiring the next generation.

What I Bring to the Table:
• Operational efficiency that drives profit
• Sales team training that actually sticks
• Strategies to win and keep clients
• Workflow optimization that saves time & money
• Leadership that builds strong cultures

Seen & Heard In:
• Host, Printing’s Alive Podcast
• WhatTheyThink’s Printer to Printer Series
• HP/Dscoop Mentor (2021)

If you’re ready to grow, adapt, and thrive in print, let’s talk.

📧 warren@theprintwhisperer.com
📱 514-947-6662
🌐 www.ThePrintWhisperer.com

#PrintWhisperer #PrintIndustry #BusinessGrowth #PrintingIsAlive #HookLineThinker #ILovePrint

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABb5XgB2gYwSGlEnmNb_VSFhdvQ9vxMk-4/
**Connexions partagées** : 76


---

# Warren Werbitt

## Position actuelle

**Entreprise** : www.theprintwhisperer.shop

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 1st


---

# Warren Werbitt

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403421250443960320 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E10AQHQXzuBK6FQkw/mp4-720p-30fp-crf28/B4EZr48XwiIUB4-/0/1765113172917?e=1765774800&v=beta&t=S7vQrqD2niFp5i-3T5KneKY-3-sF0iX08U1Y5nHm0TE | https://media.licdn.com/dms/image/v2/D4E10AQHQXzuBK6FQkw/videocover-high/B4EZr48XwiIUAw-/0/1765113169286?e=1765774800&v=beta&t=xqzklC8XKv1DPtHbYHNGeetHgOwiJtx8pWsEQYpMBto | I asked Julie Watson from Ultimate Tech this question, and honestly, her answer kind of blew my mind.

Picture this: all those boring, brain-numbing, energy-sucking tasks you pretend you don’t hate? Gone. Poof. Handled by automation while you actually get to focus on growing your business instead of wrestling with spreadsheets at midnight.

Julie told me about a client who had this lightbulb moment....literally said, “I never thought about it that way.” And boom. Everything changed. Because really… why are we still doing things like it's 2004 when technology is basically waving its arms yelling, “Let me help you!”

So… ready to rethink how you work and let automation take a few things off your plate?

LISTEN TO EPISODE 47 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Technology | 6 | 1 | 0 | 15h | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:45.164Z |  | 2025-12-07T13:12:55.021Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7403100508216782848 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bec1a957-d171-4ef8-b0e0-e7e02277cb07 | https://media.licdn.com/dms/image/v2/D4E10AQETipb5cacKyQ/videocover-high/B4EZr0YnEOGUAw-/0/1765036686080?e=1765774800&v=beta&t=7l2GLR7gkDF52YtY5N5WMXgNSHf_3PQcVOFRVnkdtkE | I sat down with Doug Laxdal from The Gas Company to break down some of his award-winning projects, the kind of work that completely reshapes what we think print can do.

Each project is a reminder of how much untapped potential still exists in print when creativity leads the way.

What he’s doing goes far beyond ink on paper. He’s pushing boundaries, redefining expectations, and proving that print isn’t just a medium, it’s a playground for innovation.

This week's episode is one you CAN'T MISS! 👍

LISTEN TO EPISODE 46 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Graphics | 0 | 0 | 0 | 1d | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:45.165Z |  | 2025-12-06T15:58:24.115Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7403090686365028352 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQECSneJukSxkA/feedshare-shrink_800/B4EZr0Pv5yKMAk-/0/1765034360925?e=1766620800&v=beta&t=NusJHb6lITybuoEGv2OM3_AYqdch4KobdRkcGldSPvo | My T-Shirts Get More Attention Than I Do.   (True Story) 

Walked into the gym this morning wearing my “MY ANXIETY HAS ANXIETY” tee… and before I even reached the machines, a woman stopped me and asked me to take a picture.

That’s twice now. 

Two different days, 
Two different shirts I designed & Two women stopping me.

And every time, it’s the same pattern: great laugh, great moment… conversation over. 😅

But hey, these tees are incredible conversation starters. 

I’m just working on the conversation finishing part.

If you want your own conversation starter, you can find them at theprintwhisperer.shop.

And seriously… I’d love to hear your stories if someone stops you while wearing one.

And since I apparently can’t close anything that isn’t printed on a press, 

I’m tagging Bill Farquharson elite sales trainer, professional closer, and the only guy I know who could sell sand in a sandstorm.

Bill… my shirt reeled them in, hooked them, and handed me the net… and somehow I still dropped the fish.

Buddy, I might need your “How to Not Be Helpless After Hello” workshop. 😅🎣


Please remember that 10% our profits go to Make-A-Wish America where kids get live out a dreams. 


#MentalHealthAwareness #Anxiety #RealTalk #ConversationStarter #WearTheTruth #ThePrintWhisperer #MakeAWish #SalesHumor | 29 | 6 | 0 | 1d | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:45.167Z |  | 2025-12-06T15:19:22.403Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402709982753816576 | Video (LinkedIn Source) | blob:https://www.linkedin.com/02c97992-705e-4d38-91a7-f32c6fe526c7 | https://media.licdn.com/dms/image/v2/D4E10AQFuVg4-Zur5Bw/videocover-high/B4EZru1AI_GoAw-/0/1764943464824?e=1765774800&v=beta&t=k7l1FQ8NDd8IIBColuBcHCg_4kj20DUGNb4u77vEtEQ | Doug Laxdal from The Gas Company doesn’t settle for “good enough”and after speaking with him on the latest episode of Printing's Alive The Podcast, I can see why. 

In a world where “good enough” gets accepted far too often, Doug’s approach is refreshing. It made me rethink my own standards and consider how often we settle when we should be pushing further.

You can hear the full conversation in the episode, where Doug breaks down how a relentless drive for excellence can completely reshape what’s possible in print.

LISTEN TO EPISODE 46 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Graphics | 4 | 0 | 0 | 2d | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:45.168Z |  | 2025-12-05T14:06:35.589Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7402347732411097088 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5604ad33-f1c9-4eb7-8cba-974b0c18783d | https://media.licdn.com/dms/image/v2/D4E10AQHm6xZoSikqzA/videocover-high/B4EZrprelXIIAw-/0/1764857084292?e=1765774800&v=beta&t=2gOCiCxWXcnMX1tRz2buxS5kPybagR9NeNulrhSAE_g | Doug Laxdal from The Gas Company shared a project with me on Printing's Alive The Podcast that stopped me in my tracks, not just because it’s beautiful, but because of the sheer ingenuity behind it. He took a handwritten note from an ailing artist and transformed it into a piece that completely reimagines what a book can be.

For anyone claiming print is outdated, this project says otherwise. It shows that print is still evolving and still capable of telling stories in ways no digital format can replicate.

People love to say print is dying, but maybe it’s just waiting for the right creators to push it forward. Doug’s work is a clear example of how imagination and craft can make print feel as groundbreaking now as it was centuries ago.

LISTEN TO EPISODE 46 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Graphics | 4 | 0 | 0 | 3d | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:45.169Z |  | 2025-12-04T14:07:08.377Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7401260678390489089 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d7e62f35-ebdc-4e31-92fb-37c9c185dd60 | https://media.licdn.com/dms/image/v2/D4E10AQHZYV0uxQgB-A/videocover-high/B4EZraOyJRIIA0-/0/1764597906811?e=1765774800&v=beta&t=vgPW7Bjj4_BIQUoM6Fif6czlh3RFcTR9XuA0QjrpG-A | When was the last time you picked up a book and it made you pause, not because of what it said, but because of the experience itself? In my recent conversation on Printing's Alive The Podcast, Doug Laxdal from The Gas Company shared a project that completely reimagines what a book can be.

Doug was approached with a request that sounded almost unbelievable: create a book that smells like garlic for a campaign. And Doug didn’t take the simple route of tucking a scent strip into the pages. Instead, he formulated an ink blend made from garlic oil, pigment, and varnish to build the scent directly into the printed design.

It left me thinking:
What other boundaries in print are waiting to be challenged?

LISTEN TO EPISODE 46 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Apparel | 1 | 0 | 0 | 6d | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.785Z |  | 2025-12-01T14:07:34.502Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7400918618244423680 | Video (LinkedIn Source) | blob:https://www.linkedin.com/393367c7-6b9d-427b-8176-1028a6e97f86 | https://media.licdn.com/dms/image/v2/D4E05AQHaTIEuOPc4cA/videocover-high/B4EZrVYPWRHUBU-/0/1764516494240?e=1765774800&v=beta&t=nN4BjaTgpZmYQnH4W56lgjvNeEkj2NxlJc_hTS_6HgM | Sunday humor or not 🤣🤣

Just sitting here in the snow thinking about how my grandparents could’ve moved somewhere with palm trees, sunshine, and year-round fishing… but nope. 

They chose this. 🥶🌨️☃️💨

#sunday #grandparents #emotion #humor #mentalhealth | 6 | 1 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.786Z |  | 2025-11-30T15:28:21.008Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7400892932070744065 | Video (LinkedIn Source) | blob:https://www.linkedin.com/25df9569-5b15-4d6b-87dd-8f2ebf504e71 | https://media.licdn.com/dms/image/v2/D4E10AQFZ0kCTX1xWbg/videocover-high/B4EZrVA0vLKcA0-/0/1764510357149?e=1765774800&v=beta&t=JnN8EMMiur74cpFdPqAVWUWsoT5-RkbNujSc28Flqyo | I had the chance to sit down with Doug Laxdal from The Gas Company for Episode 46 of Printing's Alive The Podcast, and the story he brought with him is one I haven’t stopped thinking about.

Imagine a world where books can withstand attempts to destroy them. It sounds unreal, but that’s exactly what Doug and his team brought to life with a single, extraordinary edition of Margaret Atwood’s The Handmaid’s Tale.

Doug was approached by an agency whose project, creating an unburnable book, had already failed once. Instead of walking away, he saw an opportunity to explore the outer edge of what print can be. Using Sina Foil, a material typically found on film sets to protect actors from burns, he engineered a version of the book that challenges the limits of physical media.

WANT TO HEAR MORE?

LISTEN TO EPISODE 46 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Graphics #Print | 1 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.787Z |  | 2025-11-30T13:46:16.947Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400173592493305856 | Video (LinkedIn Source) | blob:https://www.linkedin.com/03034c2b-b0f1-44bf-a1c0-1f6df7db247a | https://media.licdn.com/dms/image/v2/D4E10AQGtUPuzZYZjiA/videocover-high/B4EZrKyFxkIUA0-/0/1764338725417?e=1765774800&v=beta&t=3DUWwk_BSt_1GZmmMHVazDV-ntlB8ZSVCNUOCEtKJrU | Imagine this: six local teams win their championships on a Friday, and by Tuesday, each fan is sporting a customized shirt celebrating the victory. 

While at a recent show, Davis Slagle and his team managed to pull off six entire online store pop-ups in just four days, from selling to printing to delivering. That's 800 unique shirts, each printed and packaged individually. And they didn't rely on the usual shipping routes either. They delivered by car to ensure fans got their shirts as quickly as possible.

In an age where everyone talks about innovation, BeeGraphix is living it. 

Catch the full conversation on Printing's Alive The Podcast.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 3 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.788Z |  | 2025-11-28T14:07:53.027Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7399886989766000641 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIEN2dtS9tbA/feedshare-shrink_800/B4EZrGt_1aKMAk-/0/1764270540450?e=1766620800&v=beta&t=AhhhEb1hhgO9IaZxXSDpykc7fZ1VkZQnoAB7ovIKemo | Thankful. Grateful. Actually laughing out loud. 😂😂

I went to pick up my buddy Bertrand Dagenais the other day to go fishing…

He comes out wearing his Cast Away, Worries Gone hoodie, love it already
and then points to my thank-you card proudly taped in his window.

That moment hit me. 😊

I’m beyond thankful for the people in my life… 🙏

friends who show up, who support, who don’t judge, who genuinely care.

The older I get, the more I realize how rare that is and how much it matters for your mental health.

This whole TPW journey has been fun, emotional, meaningful… and full of these little reminders that people are good, thoughtful, and willing to lift each other up.

And hey every hoodie, tee, or beanie from the shop helps Make-A-Wish America, which means we’re spreading good energy even further.

To everyone who’s been part of this ride so far thank you. 

Truly.

You’ve made my year.

👉 www.theprintwhisperer.shop

 #Thankful #Gratitude #MentalHealthMatters #ThePrintWhisperer #MakeAWish #GoodPeople #Community #FishingLife #PrintCommunity | 9 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.790Z |  | 2025-11-27T19:09:01.612Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7399812945603612673 | Video (LinkedIn Source) | blob:https://www.linkedin.com/568880c4-43be-43f0-a821-31a0af72261a | https://media.licdn.com/dms/image/v2/D4E10AQFD3LwmLw2cIA/videocover-high/B4EZrFpZbUKUA0-/0/1764252558080?e=1765774800&v=beta&t=k0rwnkID4m12TMa4Lq76phFeo8x1FCTs1Ru4emIcS7I | Davis Slagle of BeeGraphix had to make one of the toughest calls of his career when COVID hit. His Pittsburgh-based mom-and-pop shop known for screen printing and vinyl cutting was suddenly hanging by a thread. While so many businesses were forced to shut down, Davis chose to pivot instead of pause 🔄.

He led BeeGraphix’s leap into direct-to-film printing, and that shift completely transformed the business. Today, they run more than 2,000 web stores across the country, delivering everything from custom apparel to embroidered merch. It’s a bold move that pushes back against the idea that traditional print is fading away 🚀.

Catch the full conversation on Printing's Alive The Podcast.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU
#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 0 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.791Z |  | 2025-11-27T14:14:48.108Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7399449117724413953 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9bb6ebc1-9cec-4701-8d97-5dc38ad3758d | https://media.licdn.com/dms/image/v2/D4E10AQHUNQK8cLrIlw/videocover-high/B4EZrAfFCRKoA4-/0/1764165967040?e=1765774800&v=beta&t=19jUC7aZXmVOky7KoO-uBuZucOyHRqfIs2hz2tEVrdc | The apparel decorating world has been built on manual work and old-school methods for decades but we’re standing at the edge of a massive technological shift 🤖⚡. 

I had an eye-opening conversation with Davis Slagle from BeeGraphix on the latest episode of Printing’s Alive. He didn’t sugarcoat it, change isn’t coming, it’s already here. And it’s not the small, gradual kind. AI and robotics are gearing up to transform the entire sector.

Catch the full conversation on Printing's Alive The Podcast.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 4 | 0 | 1 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.792Z |  | 2025-11-26T14:09:04.782Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7399116640371494912 | Video (LinkedIn Source) | blob:https://www.linkedin.com/68155d10-289e-43d6-af38-440e28a75759 | https://media.licdn.com/dms/image/v2/D4D10AQEBkUXhpInn2g/videocover-high/B4DZq7wsfzGsBA-/0/1764086698230?e=1765774800&v=beta&t=hid0UPQObJcNBg-eajdx8EFsG8kQj6Xy1eMToyr8uks | In an industry where everything moves at lightning speed, staying afloat takes more than guesswork. I asked Davis Slagle of BeeGraphix how he manages it, and his perspective was refreshingly simple.

In this episode, we dig into the fast-shifting world of apparel printing — and the surprising parallels it shares with the AI boom. Just like AI, the apparel space is in the middle of a revolution, and jumping in without a strategy won’t cut it.

Davis and I talk about the rise (and fall) of early Direct-to-Film companies and how it mirrors today’s wave of AI startups. The strong adapt. The rest fade away.

Catch the full conversation on Printing's Alive The Podcast.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 1 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.793Z |  | 2025-11-25T16:07:56.004Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7399086496953311237 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEfSQxra-RpiA/image-shrink_800/B4EZq7VU_NGYAg-/0/1764079522601?e=1765774800&v=beta&t=eNyBiIrbr-GKxe5Kh8eNS0a2jYnMPBErbFyff7mvGjI | EP45 is officially out now🔥

I sit down with Davis Slagle from BeeGraphix to dig into how the company reinvented itself during COVID and made the move into direct-to-film printing. We talk growth, price competition in the apparel market, and what it really takes to diversify without spreading yourself too thin.

We get into BeeGraphix’s operations, equipment choices, and practical advice for anyone stepping into the industry. There’s real talk about planning and marketing before making equipment investments, when outsourcing actually helps your business, and what we learned from this year’s PRINTING United Expo.

The episode wraps with insights on handling high-volume work, quality control, evolving technology, and the pricing strategies that keep you profitable, not stressed.

Catch the full conversation on Printing's Alive The Podcast.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 15 | 0 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.795Z |  | 2025-11-25T14:08:09.253Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7398942050483589120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHPKeevoK-8fg/feedshare-shrink_800/B4EZq5Slp4HoAk-/0/1764045249878?e=1766620800&v=beta&t=yj6PHewy-4NYovecJRggQzOnyJcSByEDqZT9n9cDhis | Let’s be real, AI has been quietly helping you keep life together.

That resume?

That interview prep?

That “brilliant idea” you definitely didn’t Google at 1 a.m.?

Yep… we know.

So we made the gear that owns it. 😊

Check out the new drops in AI, Culture, and explore the rest of 
www.theprintwhisperer.shop 

 🧘‍♂️ Mindful Mode
 🧵 Ink & Thread
 🎣 The Fisherman’s Wardrobe

And because doing good matters, 10% of our profits goes Make-A-Wish America

Own the joke. 😂
Wear the truth. 😇
Support something big. 👧👦

ps. yes… this copy was done using AI. hehe

#AI #PrintIndustry #ThePrintWhisperer #Decorativeapparel #MakeAWish 
#fishing #mentalhealth | 8 | 4 | 0 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.797Z |  | 2025-11-25T04:34:10.531Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7398724068755120128 | Video (LinkedIn Source) | blob:https://www.linkedin.com/69922896-a44e-4414-9a19-01c3730cd07d | https://media.licdn.com/dms/image/v2/D4E10AQEjcw4haALd7A/videocover-high/B4EZq2Lu1iIwA4-/0/1763993122895?e=1765774800&v=beta&t=3pyLSDM7KV7_0td3y-_jU_u3wv_28h1UC0Ak1JCe_1s | I’ve had enough of the race-to-the-bottom mentality 🙅‍♂️. The constant discounting just to beat the competition? It’s time to stop that madness.

I believe we should be doubling down on value instead of slashing prices. If comfort, quality, and expertise speak for themselves, why should profitability take the hit? Why should the consumer always win at the expense of the business’s health?

Catch more of this conversation on Printing's Alive The Podcast .

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 4 | 0 | 1 | 1w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:47.798Z |  | 2025-11-24T14:07:59.637Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7398339829488394240 | Video (LinkedIn Source) | blob:https://www.linkedin.com/913a6329-1e31-4e1c-ba70-60df3e3e8a84 | https://media.licdn.com/dms/image/v2/D4E10AQHSvQN4kqpeow/videocover-high/B4EZqwu0RAKoA0-/0/1763901655802?e=1765774800&v=beta&t=tFvQ58pYSb_XPiYx9EC2qZ7ibD3aL44CyYXw06Nfs3w | I’m fired up 🔥 and ready to set the record straight about print. Too many misconceptions are floating around, and I’m here to push back. The world can’t function without print period. From marketing materials to packaging, print keeps businesses moving and helps entire industries grow.

Davis Slagle from BeeGraphix backs this up every printed piece plays a part in someone else’s success. So why does our industry still have to defend its worth? 🤷‍♂️

Catch the full conversation on Printing's Alive The Podcast and hear why this matters more than ever.

LISTEN TO EPISODE 45 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Marketing #Apparel | 7 | 2 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.256Z |  | 2025-11-23T12:41:09.857Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7397998394713210880 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9bmQIsY9oXQ/feedshare-shrink_800/B4EZqr4VDhKMAg-/0/1763820264331?e=1766620800&v=beta&t=Wy-FKsd-O89d2FaUQdiUy3ZahYWOTZcLEhCg3t17gmw | Saturday morning truth from the gym…

I walk in, haven’t even touched a machine yet, and a woman hits me with:

“I like your shirt.”

Let me tell you  when your T-shirt pulls more weight than you do, that’s a solid start to the day. 😂💪

Wearing the Fish More. Talk Less. tee from my shop…

Apparently it boosts confidence AND cardio. 

Who knew?

And if fishing’s not your thing, no worries.

There are tees and hoodies for every mood: print life, mental health, AI, good vibes, all of it.

If you want a shirt that works harder than your warm-up:

www.theprintwhisperer.shop

And yes  10% of profits go to @Make-A-Wish 
Good vibes all around.

#SaturdayMorning #GymLife #PrintCommunity #ThePrintWhispererShop #MakeAWish #WeekendVibes #ConversationTees #FishingLife #MentalHealthMatters #AICulture | 50 | 3 | 2 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.258Z |  | 2025-11-22T14:04:25.463Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7397634360457416704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEulhW25_hlDA/feedshare-shrink_800/B4EZqmtPqFGoAg-/0/1763733472277?e=1766620800&v=beta&t=xpqh5zdW0vPX535_UbdJw4iJyaJW30739KGtA2fvZ3M | Happy Friday ......Weekend mode is officially ON. 😁

There’s something about a great hoodie, good people, and a good laugh that just sets the tone. 

The cozy, mid-weight hoodies from The Print Whisperer Shop are built for real life, clean fit, great feel, and messages that spark conversations wherever you go.

And the best part?

10% of profits goes directly to Make-A-Wish America Make-A-Wish Canada Make-A-Wish® UK

Because looking good AND doing good is always a win.

Take a peek 👇

 www.theprintwhisperer.shop

We produce and ship globally  🌍

#PrintCommunity #FeelGoodFriday #ThePrintWhispererShop #MakeAWish #HoodieSeason #fishing #mentalhealth #ai #print Shopify Printful | 8 | 0 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.260Z |  | 2025-11-21T13:57:52.933Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7397274566462427137 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3abeb6a6-8fce-4766-ba9c-7b9e8f98e0dc | https://media.licdn.com/dms/image/v2/D4E10AQFdykcP1scH3A/videocover-high/B4EZqhlX8TKsA0-/0/1763647526142?e=1765774800&v=beta&t=oUHME0IdHDEb9Hilzksnyslm8XiwdV5S8d2OCkMZ9PY | I’m here to prove that print isn’t just alive, it’s thriving. In this week’s episode, I dive into my latest venture, www.theprintwhisperer.shop, where I’m blending print with the things I love: fishing, mental health, and even a touch of AI. People are responding in ways that remind me just how powerful print can be just last week, someone ordered six of my designs!

Aaron Montgomery 💡from Our Success Group chat this week about how print does more than just connects, it makes a difference. 

That is why I’m also donating 10% of profits to Make-A-Wish America. If you think print is past its prime, join me and see why the tangible, the colorful, the printed still has magic.

LISTEN TO EPISODE 44 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Print #PrintIndustry | 1 | 0 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.262Z |  | 2025-11-20T14:08:11.360Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7396912111911661569 | Video (LinkedIn Source) | blob:https://www.linkedin.com/16053f4f-747a-4daa-9de0-094193442036 | https://media.licdn.com/dms/image/v2/D4E10AQF6nEC1t90lig/videocover-high/B4EZqcbzx0IoA8-/0/1763561131847?e=1765774800&v=beta&t=ydNbQzoB3hffsqQTKRPaLbob3LSqTxWOJ_NopH1nLhc | I once turned a fishing magazine article into a business strategy by adding a personal twist to my card: “Founder and Fisherman.” In a meeting with a retail CEO, it sparked a chat about fishing and skiing, turning 15 minutes into an hour and he even brought in his VPs! Shows me that a little personality can open big doors. 

How do you incorporate personal passion into your professional life? I chat with Aaron Montgomery this week on Printing's Alive The Podcast.

LISTEN TO EPISODE 44 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Print #PrintIndustry | 3 | 0 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.263Z |  | 2025-11-19T14:07:55.461Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7396549527773691904 | Video (LinkedIn Source) | blob:https://www.linkedin.com/553c0064-256c-44a3-a59c-aba021aeac03 | https://media.licdn.com/dms/image/v2/D4E10AQGuPZD1L0ZR1g/videocover-high/B4EZqXSARyGoA4-/0/1763474674581?e=1765774800&v=beta&t=Xw2HiFQaFmPn5Q9aTI0Se1L8MNx1tWqhxdq_WRsjuXU | In a business so serious, could humor be the disruptive force we need to not just survive, but thrive? Something to ponder as we hustle through the daily grind. I chat about it on this week's Printing's Alive The Podcast with Aaron Montgomery 💡 

How do you see humor playing a role in your industry?

LISTEN TO EPISODE 43 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Print #PrintIndustry | 4 | 0 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:50.265Z |  | 2025-11-18T14:07:08.666Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7396187310784028672 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5775bb0a-6c11-461e-ba43-def3d33a38bc | https://media.licdn.com/dms/image/v2/D4E10AQFAfYsr1UEvXw/videocover-high/B4EZqSIjoMKcA0-/0/1763388312534?e=1765774800&v=beta&t=FfBN2yg77wY-rMsogdZ21rnFXYjiav2I7mKk3K0ZigA | In a digital-first world, people still ask me why print continues to resonate. Honestly? This week’s episode might hold the answer.

I just launched www.theprintwhisperer.shop ....my not-so-traditional t-shirt venture built around four pillars that shape my life: fishing, print, mental health, and AI. And a portion of every sale goes straight to Make-A-Wish.

The response blew me away. Within the first week, someone bought six shirts each one connecting with a message I created. That’s the magic of print: it sparks conversations.

LISTEN TO EPISODE 44 OF PRINTING'S ALIVE. OUT TOMORROW! CLICK HERE: https://loom.ly/m15yZkU

Aaron Montgomery 💡https://lnkd.in/eNAJvqbj podcast 

#TPW #PrintingsAlive #Podcast #Apparel #Print #PrintIndustry | 2 | 2 | 0 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.704Z |  | 2025-11-17T14:07:49.406Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7396181547831218178 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHph3KfKUX-ig/feedshare-shrink_800/B4EZqOWtt.HEAg-/0/1763324921812?e=1766620800&v=beta&t=X5rfpNg3wQxMhidvDmK_4bLrBEXlMt73MQ1GzSPW6y4 | Nothing better than waking up to the man himself, Kevin Abergell of Taktiful, rocking his Just Embellish It tee from The Print Whisperer Shop.

Appreciate you, brother, that shirt was basically made with you in mind. 
You are the king of embellishment.

And for everyone else out there…

If you or your company are promoting ANY kind of embellishment, foil, varnish, texture, raised, shiny, sparkly, you name it, you owe it to yourself to check out The Print Whisperer Shop. 

We’ve got a whole line of embellishment tees, with new ones dropping regularly.

Let’s show the world how good embellishment really looks. 👑✨

10% goes to Make-A-Wish because doing good should look good too 😊

#Embellishment #JustEmbellishIt #PrintEmbellishment #PrintIndustry #PrintLife #ThePrintWhisperer #PrintCommunity #PrintProud #Foil #Varnish #RaisedUV #DigitalFinishing #PackagingDesign #PrintDesign #PrintShopStyle #MakeAWish #PrintingIsAlive #PrintPeople | 17 | 1 | 1 | 2w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.705Z |  | 2025-11-17T13:44:55.411Z | https://www.linkedin.com/feed/update/urn:li:activity:7395920780053872642/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7395911078422929408 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f25cd45f-9ff7-4de0-b2fb-84d619f31b0d | https://media.licdn.com/dms/image/v2/D4E10AQGoA7nsh2gIwg/videocover-high/B4EZqON6I0KsA0-/0/1763322604446?e=1765774800&v=beta&t=5u12b-m9MDxc-Xh5eIVfSvDSCgKh_N2_NzuxvdE6H5w | The print industry is undergoing a significant transformation. But aren't we all a little resistant to change? Aaron Montgomery from Our Success Group thinks so, and he's not alone. There's a shift happening, especially in the t-shirt printing space, and it seems like the old guard is clinging on for dear life.

If you’re ready to look at print in a whole new dimension, this week's upcoming podcast is worth a listen.

LISTEN TO EPISODE 44 OF PRINTING'S ALIVE. OUT TUESDAY! CLICK HERE: https://loom.ly/m15yZkU

#TPW #PrintingsAlive #Podcast #Apparel #Print #PrintIndustry | 3 | 1 | 0 | 3w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.706Z |  | 2025-11-16T19:50:10.479Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7395168283907280897 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFADceihkXX_g/feedshare-shrink_800/B4EZqDqXIpHEAg-/0/1763145513050?e=1766620800&v=beta&t=QBQZzdFAwtQ1hed60EqK8lcVPlU9iJMnJco82okbaXA | It’s Friday… which means it’s officially “Reel Good Times” weekend.

And yes, these tees come in multiple colors so no matter what you’re up to, you’re wearing the right kind of energy. 😎

If you need a shirt that’s comfy as hell, guaranteed to make someone smile, and perfect for whatever fun you’ve got lined up… I’ve got you covered.

And the best part?

10% of every purchase goes to Make-A-Wish America Make-A-Wish Canada Make-A-Wish® UK.

Good vibes all around.

Check out the full lineup → www.theprintwhisperer.shop

 Feel free to share, the more smiles the better. 😊😁😄😃😋😉

#GoodFriday #ReelGoodTimes #ThePrintWhispererShop #WeekendReady #ConversationTees #MakeAWish #ApparelWithHeart #fishing | 8 | 0 | 0 | 3w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.707Z |  | 2025-11-14T18:38:34.466Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7395100194285187073 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e0d7a0da-c493-4ceb-91f2-99d419ca7f22 | https://media.licdn.com/dms/image/v2/D4E10AQELShHT7wCtCA/videocover-high/B4EZqCr1oFKcA0-/0/1763129123634?e=1765774800&v=beta&t=VuTx1hjC5dlZYnQZ3zwj69PDWzHEGSmOICSZQBGK8tk | In the latest episode of Printing's Alive The Podcast, we drop the hammer on an industry that's long overdue for a shake-up: print. I invited Katelin Shanks from Racami, LLC to chat and dive deep into why most companies fail at implementing new tech like AI and automation.

Spoiler alert: It's not the tech that's the problem, it's the people.

This episode is a wake-up call for those who still think the old ways will carry them through the next decade. 

Listen now to find out how you can future-proof your print business.

LISTEN TO EPISODE 43 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Print #PrintIndustry | 4 | 0 | 0 | 3w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.709Z |  | 2025-11-14T14:08:00.635Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7394902357714837504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGAOByIsZ0Nkw/feedshare-shrink_800/B4EZp_4gYLKcAg-/0/1763082111397?e=1766620800&v=beta&t=0LBXwZFNe7nd9It40NMdcXCVQxCmXvdKJdMiE0yMplM | The best advertising money can’t buy?   A happy customer.  😁😁

 And this guy… he’s basically a walking billboard for joy right now.

He grabbed a tee from The Print Whisperer Shop, threw it on, and instantly started smiling like someone just told him fishing season got extended.

If he’s this happy, odds are you could be too.

 👉 www.theprintwhisperer.shop

And hey 10% of every purchase goes to Make-A-Wish, helping bring hope and strength to kids who need it most.

#helpingchildren #printingindustry #appareldecoration #tshirt #conversationstarter #humanconnection
Make-A-Wish America Make-A-Wish® UK Make-A-Wish Canada | 9 | 0 | 0 | 3w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.710Z |  | 2025-11-14T01:01:52.721Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7394737771581485057 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6d5d5f71-8a15-47b3-bc86-f6584047efcc | https://media.licdn.com/dms/image/v2/D4E10AQF0Bj2phW51cQ/videocover-high/B4EZp9iOM9IQA0-/0/1763042720069?e=1765774800&v=beta&t=Vw469d2EekB0QMeRFpvIpPTmFFOaKDYfx4FH54VeuIk | Automation in print isn't just a buzzword, it's a necessity. Katelin Shanks from Racami, LLC lays it out clearly: businesses need to decide what they're trying to solve before diving headfirst into automation. 

I echo this sentiment, emphasizing the importance of answering critical questions before making any investment in new equipment. If you can't define your problem, how can you expect to find the right solution?

It's time to stop romanticizing automation as a cure-all and start treating it as a strategic tool to address specific business challenges.

LISTEN TO EPISODE 43 OF PRINTING'S ALIVE. OUT NOW! CLICK HERE: https://loom.ly/m15yZkU

 #TPW #PrintingsAlive #Podcast #Marketing #Print #PrintIndustry | 9 | 0 | 0 | 3w | Post | Warren Werbitt | https://www.linkedin.com/in/warrenwerbitt | https://linkedin.com/in/warrenwerbitt | 2025-12-08T04:38:52.711Z |  | 2025-11-13T14:07:52.329Z |  |  | 

---



---

# Warren Werbitt
*www.theprintwhisperer.shop*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 16 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Warren Werbitt is The Print Whisperer. Hook, Line, & Thinker](https://theprintwhisperer.com/)
*2024-08-29*
- Category: article

### [Warren Werbitt and PRINTING United Alliance Collaborate on New Podcast](https://www.printing.org/content/2025/01/17/warren-werbitt-and-printing-united-alliance-collaborate-on-new-podcast)
*2025-01-17*
- Category: podcast

### [Print Industry Expert Warren Werbitt Launches Innovative Podcast Exploring Print's Future](https://advos.io/en/print-industry-expert-warren-werbitt-launches-innovative-podcast/202510129)
*2025-01-16*
- Category: podcast

### [Breaking Pricing Myths: Modern Profit Strategies for Printers](https://www.piworld.com/podcast/printings-alive/breaking-pricing-myths-modern-profit-strategies-for-printers/)
*2025-06-17*
- Category: podcast

### [Transforming the Print Industry with AI | Warren Werbitt at Imagine AI Live 2024 in Las Vegas | E32 - Imagine AI Podcast](https://podcast.imagineai.live/episodes/5eRzSdErdMg)
*2024-05-10*
- Category: podcast

---

## 📖 Full Content (Scraped)

*5 articles scraped, 5,933 words total*

### Warren Werbitt is The Print Whisperer. Hook, Line, & Thinker
*777 words* | Source: **EXA** | [Link](https://theprintwhisperer.com/)

Print owners and managers
-------------------------

have a lot on their plates
--------------------------

A global shift in online engagement tactics have forced them to learn new ways to:
----------------------------------------------------------------------------------

### Operate their business profitably

### Help the sales team thrive

### Market and sell to the RIGHT client

### Exceed customer expectations

### Enjoy life - and print - again!

Hi. I'm Warren Werbitt.
-----------------------

I've lived the soaring highs and the killing lows of my four passions:
----------------------------------------------------------------------

Owning a print communications company - built from the ground up - for almost three decades. At its peak, my business was highly profitable - employing 120 people and generating $18 million in sales

Casting for fish - and print sales - in murky waters

Helping people, causes, and the print industry

Raising a beautiful family

![Image 1: Warren Werbitt with sunglasses exterior portrait](https://theprintwhisperer.com/wp-content/uploads/2024/08/Warren-Werbitt-scaled.jpg)

I've travelled the world - and fished in some of the best waters.
-----------------------------------------------------------------

I have forged relationships with some of the largest manufacturers and some of the smallest print providers.

Today, I'm ready to share all I've learned on my journey so far - the good, the bad, and the shivering ugly - so that other printers can learn from my successes and my missteps.

I can help because I've been there, and I know what you're going through each day.

![Image 2: warren werbitt printing industry celebrity](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-with-fishing-rod.jpg)

![Image 3: well known printing industry name](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-007.jpg)

![Image 4: "I LOVE PRINT"](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-008.jpg)

![Image 5: Print consultant](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-002.jpg)

![Image 6: printing consultant](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-004.jpg)

![Image 7: printing industry video](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-003.jpg)

![Image 8: print industry speaker](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-005.jpg)

![Image 9: Print industry speaker](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-006.jpg)

![Image 10: warren werbitt guest speaker](https://theprintwhisperer.com/wp-content/uploads/2021/10/warren-werbitt-speaker.jpg)

![Image 11: printing industry celebrity](https://theprintwhisperer.com/wp-content/uploads/2021/07/warren-werbitt-printing-industry-001.jpg)

I am The Print Whisperer.

 Hook, Line, and Thinker.
----------------------------------------------------

Who we help
-----------

Small to mid-sized business owners and managers across the global print industry including:
-------------------------------------------------------------------------------------------

Owners / operators

President / CEO

COO / Operations Managers

Sales Leaders

CMOs / Marketing Executives

Large|
------

![Image 12: quotation mark](https://theprintwhisperer.com/wp-content/uploads/2021/09/quote.png)

This guy is the real deal. He just makes you feel good and makes you proud of what we do. Not enough people do that these days. I'm not sure why. If you hook up with Warren you will always get the best this industry...any industry, can deliver. I've been doing this a long time and I'm not easily impressed...but I am with Warren.

[### Bill Gillespie](https://www.linkedin.com/in/bill-gillespie-60a26618/)

I have known Warren and done business in several capacities for over 10 years. Warren is truly a man of "Passion for Print". He will do what it takes to ensure success and does not compromise for quality. Some may call him a character, but I say Warren is a man of character. I’m proud to call him a friend.

[### Harold (Bubba) Williams](https://www.linkedin.com/in/bubbawilliams/)

Warren is a printing leader and champion. I have observed him manage his team, as well as all aspects of producing complex graphic communications projects. He is customer obsessed, is a charismatic leader and consistently leads his company to outstanding results.

[### Joe Rickard](https://www.linkedin.com/in/joerickard/)

When you look in the dictionary under the word "passion", there’s a picture of Warren. He’s not afraid to take chances and does what he thinks is the right thing for his clients. He’s tough but fair and a real pleasure to know. I recommend Warren to anyone who wants to get it right and be treated with respect.

[### Mike Philie](https://www.linkedin.com/in/mike

*[... truncated, 1,498 more characters]*

---

### Warren Werbitt and PRINTING United Alliance Collaborate on New Podcast
*1,471 words* | Source: **EXA** | [Link](https://www.printing.org/content/2025/01/17/warren-werbitt-and-printing-united-alliance-collaborate-on-new-podcast)

![Image 1](https://aorta.clickagy.com/pixel.gif?clkgypv=jstag&ws=1)![Image 2](https://aorta.clickagy.com/channel-sync/4?clkgypv=jstag&ws=1)![Image 3](https://aorta.clickagy.com/channel-sync/114?clkgypv=jstag&ws=1)![Image 4](https://aorta.clickagy.com/pixel.gif?ch=319&cm=8e2c46aff56868a196fc1765172466) Warren Werbitt and PRINTING United Alliance Collaborate on New Podcast 

===============

[![Image 6: Printing United Alliance Logo](https://www.printing.org/images/default-source/banners-logos/logo.png?sfvrsn=a896bdf7_0)](https://www.printing.org/)

[About Us](https://www.printing.org/about)

Welcome [My Profile](https://my.printing.org/)[Sign Out](https://www.printing.org/content/SignOut/)

[Login](https://www.printing.org/content/2025/01/17/warren-werbitt-and-printing-united-alliance-collaborate-on-new-podcast#)

*   [Membership](https://www.printing.org/membership)
    *   Membership
    *   [Membership Types](https://www.printing.org/membership-types)
    *   [Member Benefits](https://www.printing.org/membership/member-benefits)
    *   [Membership FAQs](https://www.printing.org/membership/membership-faqs)
    *   [Membership Minute Videos](https://www.printing.org/membership/membership-minute-videos)
    *   [Member Spotlights](https://www.printing.org/membership/member-spotlights)

*   [Library](https://www.printing.org/library)
    *   Library
    *   [Technical Excellence](https://www.printing.org/library/technical-excellence)
        *   [Certifications](https://www.printing.org/library/technical-excellence/certifications)
        *   [G7+ Certification](https://www.printing.org/library/technical-excellence/g7plus-certification)
        *   [System Certification](https://www.printing.org/library/technical-excellence/system-certification)
        *   [Color and Print Quality](https://www.printing.org/library/technical-excellence/color-and-print-quality)

    *   [iLEARNING+](https://www.printing.org/library/ilearning)
    *   [Business Excellence](https://www.printing.org/library/business-excellence)
        *   [Human Resources](https://www.printing.org/library/business-excellence/human-resources)
        *   [Legislation](https://www.printing.org/library/business-excellence/legislation)
        *   [Environmental, Health and Safety](https://www.printing.org/library/business-excellence/environmental-health-safety)
        *   [Sustainability](https://www.printing.org/library/business-excellence/sustainability)
        *   [Economics & Forecasting](https://www.printing.org/library/business-excellence/economics-forecasting)

    *   [Publications](https://www.printing.org/library/publications)
        *   [PRINTING United Journal](https://www.printing.org/library/publications/journal)
        *   [Media Brands](https://www.printing.org/library/publications/media-brands)
        *   [The Printing Press](https://www.printing.org/library/publications/the-printing-press)

    *   [eNewsletters](https://www.printing.org/library/enewsletters)
        *   [ColorPro](https://www.printing.org/library/enewsletters/colorpro)
        *   [Industry Advocate](https://www.printing.org/library/enewsletters/industry-advocate)
        *   [Industry Ink](https://www.printing.org/library/enewsletters/industry-ink)
        *   [Printing AI](https://www.printing.org/library/enewsletters/printing-ai)

    *   [Standards](https://www.printing.org/library/standards)
        *   [Specifications for Print Production](https://www.printing.org/library/standards/specifications-for-print-production)
        *   [Unified Printing Taxonomy](https://www.printing.org/library/standards/united-printing-taxonomy)

    *   [Glossary](https://www.printing.org/library/glossary)

*   [Events](https://www.printing.org/events)
    *   Events
    *   [PRINTING United Expo](https://www.printing.org/events/printing-united-expo)
    *   [Workshops](https://www.printing.org/events/workshops)
    *   [Conferences](https://www.printing.org/events/conferences)
    *   [Webinars](https://www.printing.org/events/webinars)
        *   [Past Webinars](https://www.printing.org/events/webinars/past-webinars)

    *   [Invite Only](https://www.printing.org/events/invite-only)
        *   [Apparel Decoration Summit](https://www.printing.org/events/invite-only/apparel-decoration-summit)
        *   [Digital Packaging Summit](https://www.printing.org/events/invite-only/digital-packaging-summit)
        *   [Inkjet Summit](https://www.printing.org/events/invite-only/inkjet-summit)
        *   [Leadership Summit](https://www.printing.org/events/invite-only/leadership-summit)
        *   [Legislative Fly-In](https://www.printing.org/events/invite-only/legislative-fly-in)
        *   [Wide-Format Summit](https://www.printing.org/events/invite-only/wide-format-summit)

*   [Communities](https://www.printing.org/communities)
    *   Communities
    *   [Online Communities](https://www.printing.org/communities/printerlink)
    *   [Market Segments](https://www.printing.

*[... truncated, 19,272 more characters]*

---

### Print Industry Expert Warren Werbitt Launches Innovative Podcast Exploring Print's Future
*305 words* | Source: **EXA** | [Link](https://advos.io/en/print-industry-expert-warren-werbitt-launches-innovative-podcast/202510129)

Bold and unfiltered, Warren Werbitt's "Printing’s Alive: The Podcast" explores the intersection of print, business, and innovation. Subscribe & watch episode 0 now.

### TL;DR

Stay ahead of the curve in the print industry with 'Printing’s Alive: The Podcast' hosted by Warren Werbitt.

Explore the intersection of print, business, and innovation through bold conversations and unfiltered discussions on 'Printing’s Alive: The Podcast'.

Empower the global print community with inspiring stories of innovation and leadership on 'Printing’s Alive: The Podcast'.

Tune in for raw, unfiltered discussions with print experts, business innovators, and unique personalities on 'Printing’s Alive: The Podcast'.

Warren Werbitt, a prominent consultant in the printing industry, is set to transform podcast content with his new series 'Printing's Alive: The Podcast', promising raw and engaging discussions about print technology and business innovation.

Developed in partnership with PRINTING United Alliance, the podcast aims to challenge perceptions about the print industry by featuring candid conversations with industry leaders and innovators. The inaugural episodes will showcase trailblazers from Israeli print technology companies and explore topics ranging from media evolution to marketing strategies.

The podcast's first episode, 'Innovation Nation: How Israeli Companies Are Shaping Print's Future', will feature executives from Kornit Digital, Scodix, and Highcon, highlighting technological advancements in the print sector. Subsequent episodes will include discussions with marketing expert Mitch Joel and print marketing specialist Joanne Gore.

PRINTING United Alliance President Dave Leskusky emphasized the podcast's alignment with the organization's mission to inspire and connect the global print community. The podcast represents an opportunity to showcase the dynamic and innovative nature of the print industry to a broader audience.

Launching on January 21st, 2025, the podcast will release weekly episodes every Tuesday, targeting print professionals, business leaders, and those interested in technological innovation. Werbitt's unfiltered approach promises to deliver entertaining and insightful content that challenges traditional industry narratives.

---

### Breaking Pricing Myths: Modern Profit Strategies for Printers
*1,388 words* | Source: **EXA** | [Link](https://www.piworld.com/podcast/printings-alive/breaking-pricing-myths-modern-profit-strategies-for-printers/)

Breaking Pricing Myths: Modern Profit Strategies for Printers

===============
![Image 1](https://aorta.clickagy.com/pixel.gif?clkgypv=jstag&ws=1)![Image 2](https://aorta.clickagy.com/channel-sync/4?clkgypv=jstag&ws=1)![Image 3](https://aorta.clickagy.com/channel-sync/114?clkgypv=jstag&ws=1)![Image 4](https://aorta.clickagy.com/pixel.gif?ch=319&cm=8943752a7a2e9616041d1765172480)![Image 5](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 6](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 7](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 8](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 9](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 10](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 11](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 12](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 13](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 14](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 15](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 16](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F%2Fwww.piworld.com%2Fpodcast%2Fprintings-alive%2Fbreaking-pricing-myths-modern-profit-strategies-for-printers%2F&cookie=&adroll_s_ref=&keyw=&name=lytics_all_printing_impressions&p0=4109)![Image 17](https://ipv4.d.adroll.com/px4/NYGJDST4FVE3VFSZREBNVK/ZU5F5VZ3LJHTXEYLSFHWSX?adroll_fpc=1a948562b6b0b066774e6b71e25ad64d-1765172479151&pv=40584160819.4327&arrfrr=https%3A%2F

*[... truncated, 79,090 more characters]*

---

### Transforming the Print Industry with AI | Warren Werbitt at Imagine AI Live 2024 in Las Vegas | E32 - Imagine AI Podcast
*1,992 words* | Source: **EXA** | [Link](https://podcast.imagineai.live/episodes/5eRzSdErdMg)

[](https://podcast.imagineai.live/episodes/5eRzSdErdMg) Warren the Printing OG

0:00

![Image 1](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

0:00

Alright. I'm very happy to have Warren Warbert with us today because I've been talking with you a lot during this conference, and we've been having some good discussions. Could you please talk to the audience about what you're working on?

Warren

0:11

So presently, I come from the packaging and printing space, and that's where I happen to know Steve from. Mhmm. Now I'm just kinda trying to think how can I maybe help people within the industry by bridging the gap between AI and everything that we do in in in print space manufacturing? People have problems with scheduling, estimating. Like, the those are the 2 basic ones that people keep asking.

Warren

0:34

And the other problem with the estimating is the industry's getting older. There's not a lot of young people who are coming into the trade wanting to know how to estimate. So there's a lot of, a lot of nervousness.

![Image 2](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

0:46

Yeah. So I think you found the right conference to come to. What have been some of your key takeaways so far? We're a day and a half in. We just have an afternoon left.

[](https://podcast.imagineai.live/episodes/5eRzSdErdMg) Key takeaways from ImagineAiLive: “It’s today, not tomorrow.”

0:49

Warren

0:53

So I'm I'm sitting here smiling because from the minute I sat down to the first session yesterday, my head has just been spinning. So for anyone who's listening, I would say it's today, not tomorrow, If you think you're too tired today and you're gonna look tomorrow, you're already behind.

![Image 3](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

1:12

Yeah.

Warren

1:12

Right? So I think the the real takeaway is that it's here. It's now, it's gonna improve our lives. I mean, there's a whole other side to it, but in general, it's gonna improve our lives. I think people should know not to be afraid of it, but rather to embrace it because a perfect example is I'm finishing up a book and I had hired somebody to do the book and question me and, you know, get all the stuff out of my head.

Warren

1:38

And a friend of mine said, why didn't you do it yourself? And I said, how do you do it yourself? And he said, well, I used chat GPTA and you prompted in the title and the chapters. And I said, that's great, but I still don't know what a good book Chris. So what I'm walking away from everything here is you still need the human element to to make it move and to be right.

Warren

1:58

So the AI will help a lot of the in between. Mhmm. But you need the person at the beginning and you still need the person at the end. For the completion of it all and to know it's the human aspect of the feeling and what good because the AI is not giving you feeling.

![Image 4](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

2:13

And for shipping the industry that you're in, how's AI gonna help the most?

[](https://podcast.imagineai.live/episodes/5eRzSdErdMg) How is AI going to help the printing business?

2:17

Warren

2:18

Well, it's gonna help in everything because, if you look at the printing industry before you print, you're you gotta design something. You gotta put some copy on something. It could be a brochure. Could be developing a logo business card to be printed later. So it's all the elements along the way that make things quicker.

![Image 5](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

2:36

Mhmm.

Warren

2:36

It'll make things move. The potential for creativity is off the charts now

![Image 6](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

2:41

Yeah.

Warren

2:42

Right? Not to take away from anybody and their expertise, but a lot of businesses don't have a lot of money to spend to get certain things or or to get the creativity, the creativity here, the depth Uh-huh. Of some projects. Mhmm. So that'll speed it up.

![Image 7](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

2:58

The AI and helping with the designs and what primarily are you printing? You're printing everything? Like

Warren

3:03

Right now, I'm not printing anything. I'm just working more as a consultant to help print owners for the longest time, I had my own facility, 120 people. We were packaging large format, direct mail. Actually, now that I say direct mail, as I'm here, the whole AI thing with direct mail lists follow-up the analytics of your campaigns, just should make it like that.

![Image 8](https://data-1.podcastai.com/hosts/uhLSaJDvJiD/display-1.jpg)

Chris Madden

3:28

Wow. So it's a little different. Is there any question that you wanna ask?

Warren

3:33

I'm just sitting and and just taking it all in. Yeah. And, like, you know, even even 

*[... truncated, 7,835 more characters]*

---

---

## 🎬 YouTube Videos

- **[Leadership Interview with Warren Werbitt - The Print Whisperer](https://www.youtube.com/watch?v=ohEUepl7r8g)**
  - Channel: Seaway Printing
  - Date: 2024-02-18

- **[Adding Value to Print with Embellishment · Warren Werbitt · The Print Whisperer](https://www.youtube.com/watch?v=nJjRg0jl3lY)**
  - Channel: INKISH
  - Date: 2022-10-22

- **[Warren Werbitt Interviews Mark DeBoer of Darwill](https://www.youtube.com/watch?v=3W0aRg5UFFw)**
  - Channel: Graphic Arts Alliance
  - Date: 2021-06-10

- **[On-Demand Print Market Explodes: Insights from Warren Werbitt](https://www.youtube.com/watch?v=zhLnczE7d7k)**
  - Channel: warren werbitt
  - Date: 2025-01-24

- **[Why a 500-Year-Old Industry is Going All-In on AI – Warren Werbitt at Imagine AI Live 2025 | E136](https://www.youtube.com/watch?v=60vQNvDlv54)**
  - Channel: Imagine AI Live
  - Date: 2025-07-23

- **[Printing&#39;s Alive: The Irony of Sustainability](https://www.youtube.com/watch?v=YQIc8VSlf_w)**
  - Channel: warren werbitt
  - Date: 2025-02-13

- **[The New Era of Entrepreneurship: From Print to Digital Sales](https://www.youtube.com/watch?v=hGr6bWrgQ4I)**
  - Channel: warren werbitt
  - Date: 2025-01-30

- **[Commit to print featuring Warren Werebitt at Printing United Conference](https://www.youtube.com/watch?v=wLjFyamAyA8)**
  - Channel: warren werbitt
  - Date: 2025-03-31

- **[Will AI Take Your Job? Warren Werbitt &amp; Mitch Joel Debate](https://www.youtube.com/watch?v=tyN-pkSag8s)**
  - Channel: warren werbitt
  - Date: 2025-02-04

- **[Warren Werbitt Unfiltered Episode 1 with Steven Roberts](https://www.youtube.com/watch?v=D0AL9e1L-Tw)**
  - Channel: Taktiful
  - Date: 2022-08-25

---

## 🔎 Press & Mentions

- **[When Print Worlds Collide: Breaking the Old Rules of Print with The ...](https://www.youtube.com/watch?v=mC8ahoMqoBY)**
  - Source: youtube.com
  - *7 days ago ... This week the 2 Regular Guys welcome back Warren Werbitt, The Print Whisperer himself, to explore the growing convergence between comme...*

---

*Generated by Founder Scraper*
