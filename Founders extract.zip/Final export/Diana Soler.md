# Diana Soler

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Somos Latinx in Tech
**Durée dans le rôle** : 11 months in role
**Durée dans l'entreprise** : 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

We are a community committed to helping Latinx professionals thrive in tech. We host events and create programs encouraging learning, networking, mentorship, and sponsorship—helping them grow their careers into leadership roles. We strive to elevate the visibility of Latinx professionals across all levels of the tech industry and inspire Latinx professionals to pursue tech, help them enter and grow within the industry, and develop the expertise and confidence to be successful.

## Résumé

With nearly a decade of experience in the tech industry, I am a senior leader and expert in Product Operations, driving operational excellence, cross-functional collaboration, and scalable processes that enable product and services organizations to thrive. I have a proven track record of building and leading high-performing teams, establishing and scaling Product Operations functions, and fostering alignment between Product, Engineering, Design, and Go-to-Market teams to accelerate innovation and business impact.

A recognized thought leader in Product Operations, I have spoken at industry conferences, built best-in-class frameworks for product feedback loops, release readiness, and data-informed decision-making, and successfully guided organizations through pivots to product-led growth. My expertise spans product management, product marketing, customer enablement, strategic planning, and organizational transformation, ensuring that teams are empowered with the right tools, processes, and insights to deliver exceptional customer experiences.

I am passionate about scaling operations, driving product maturity, and fostering a culture of collaboration and continuous improvement—all essential in shaping high-impact product teams and enabling business success.

🔗 https://linktr.ee/dcsoler 
✅ Ex-Airbnb
👩🏻‍💻 Cofounder Somos Latinx In Tech
✨ Mentor at Technovation Montreal
❤️ Techaide Ambassador
🇨🇴 Colombian 🇨🇦 Canadian
✈️ Passionate about all things travel
🍊 Orangetheory Fitness Enthusiast

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAFPXawB6Ai5myNayKI0Tes2dxNxjBCjHrM/
**Connexions partagées** : 97


---

# Diana Soler

## Position actuelle

**Entreprise** : Assent

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Diana Soler
*Assent*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Diana Soler | WTM Montreal 2025](https://wtmmontreal.com/en/speakers/diana-soler/)
*2025-09-02*
- Category: article

### [Diana Soler - Director Of Product Operations & Services Enablement at Assent | The Org](https://theorg.com/org/assent/org-chart/diana-soler)
*2024-11-06*
- Category: article

### [Diana Soler](https://www.productledalliance.com/author/diana/)
*2022-11-18*
- Category: article

### [Our Story & Leadership | Assent](https://www.assent.com/company/our-story/)
*2025-05-01*
- Category: article

### [Blog - Assent](https://www.assent.com/blog/?itm_channel=web&itm_content=blog&itm_source=mainsite-blog&itm_medium=text-link&itm_campaign=fabx-hts)
*2025-02-12*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Diana Soler - Product-Led Alliance | Product-Led Growth](https://www.productledalliance.com/author/diana/)**
  - Source: productledalliance.com
  - *Nov 18, 2022 ... Diana Soler. Director of Product Operations at Assent. Topics: Posts ... Podcasts · Reports. GENERAL. Events · Membership · Community...*

- **[WIP Montreal - Product Operations | Women In Product](https://community.womenpm.org/c/all-local-events/product-operations)**
  - Source: community.womenpm.org
  - *Diana Soler is the Director of Product Operations & Analytics at Assent, overseeing teams responsible for product operational rhythm, enablement, cont...*

- **[Product Weekend Speakers](https://www.theproductweekend.com/speakers)**
  - Source: theproductweekend.com
  - *... Podcast, and author of 2 of ... Diana Soler is a Product Operations leader driving excellence, scalable processes, and cross-functional alignment ...*

- **[Product Operations Certified: Core](https://learn.productledalliance.com/course/product-operations-certified-core)**
  - Source: learn.productledalliance.com
  - *[Fireside chat] Diana Soler, Director of Product Ops & Services Enablement at Assent. Scaling and quality [31 minutes]. Challenges of scaling product ...*

- **[Product Operations Festival | April 16, 2025](https://virtual.productopssummit.com/)**
  - Source: virtual.productopssummit.com
  - *Apr 16, 2025 ... Diana Soler, Director of Product Operations, Analytics & Enablement, Assent ... "The combination of keynote sessions and panel discus...*

- **[Product4Good 2024 Conference by Techaide](https://www.techaidemontreal.org/en/product4good/)**
  - Source: techaidemontreal.org
  - *Oct 1, 2024 ... Chief Product and Services Officer at Assent. See Event Agenda. Our ... Diana Soler. Assent. Laura Di Costanzo. Stay22. Carlos Pinto. ...*

- **[About us — Techaide](https://www.techaidemontreal.org/en/about-us/)**
  - Source: techaidemontreal.org
  - *May 14, 2024 ... Diana Soler. Assent. Farnel Fleurant. Workind. ” Happy to leverage my ... Blog · Contact Us. Help Out. Donate · Lead an Initiative · ...*

---

*Generated by Founder Scraper*
