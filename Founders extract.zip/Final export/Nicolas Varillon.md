# Nicolas Varillon

## Position actuelle

**Titre** : Filmmaker - Positive Social and Environnemental Impact
**Entreprise** : Self-employed
**Durée dans le rôle** : 2 years 11 months in role
**Durée dans l'entreprise** : 2 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Résumé

I produce and direct video content to highlight people and companies that have a positive social and environmental impact.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAv0YrUBmxC-njF3eqWs5CWlppaLzJHSJWg/
**Connexions partagées** : 6


---

# Nicolas Varillon

## Position actuelle

**Entreprise** : NVision Productions

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nicolas Varillon

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398768507410083840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHc1gAO1i-l9g/feedshare-shrink_800/B4EZq20v8dHcAg-/0/1764003873184?e=1766620800&v=beta&t=HHBcU5tBfnWSZswMnC0QxnvL-DM0fJ_5CvWX6l0un_o | Courir un marathon par mois pour supporter des familles qui se battent contre la maladie de leurs enfants.

C’est de là qu’est né “DEBOUT”, mon prochain film documentaire.

Depuis un an, Olivier court un marathon par mois pour lever des fonds, malgré une microfracture prête à céder à chaque foulée.

En parallèle, Carine, se bat pour sa fille Sarah-Lou dans un traitement contre la leucémie.

Deux combats.
Deux fatigues.
Une même question: comment rester Debout quand tout menace de s’effondrer?

🎬 DEBOUT, c’est:
- un film authentique, centré sur l’humain et le courage.
- une immersion dans la réalité des familles d’enfants malades.
- un moyen concret de sensibiliser le grand public aux maladies pédiatriques et à la solitude émotionnelle qui les accompagne.

👉 Aujourd’hui, je recherche des marques, fondations et organismes qui souhaitent:
- s’associer à un projet d’impact.
- donner de la visibilité à une cause bien réelle.
- contribuer au financement d’initiatives dédiées aux enfants malades.

Si vous travaillez en RSE, fondation, marketing d’impact, santé, ou sport et que cette thématique résonne avec vos valeurs, écrivez moi en message privé pour recevoir le dossier du film et discuter de possibilités de partenariat.

Nicolas | 22 | 2 | 1 | 1w | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:04.994Z |  | 2025-11-24T17:04:34.638Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7393987937690025984 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHD7sHuP5OsoQ/feedshare-shrink_800/B4EZpy42J2GYAg-/0/1762864096746?e=1766620800&v=beta&t=7e_3CcgDw0EprixRnuLt8pB7CZLGA-cwgaKop-gvszI | Produire des vidéos en équipe coûte une fortune. 💸 

C’est vrai.

Alors faute de budget, j’ai longtemps géré mes projets vidéo en solo.
C’est simple, direct… et suffisant pour la plupart des mandats sur lesquels je travaille.
Mes clients étaient satisfaits, et on passait au projet suivant.

Mais depuis quelque temps, j’ai commencé à m’entourer de nouveaux talents sur mes tournages. 
Et ça change tout.

Chaque personne apporte son expertise et élève le rendu final pour une image plus soignée, une image plus travaillée et un impact plus fort auprès des communautés ciblées.

En production corporative, la qualité visuelle n’est pas qu’une question d’esthétique.
Elle renforce votre crédibilité, votre image de marque et la portée de votre message.

Alors, comment intégrer davantage de personnes sans augmenter le budget de mes clients?
Simple:
Mon rôle n’est pas juste d’appuyer sur “enregistrer” et de livrer une vidéo.
Mon rôle est d’accompagner les organisations à impact positif en leur permettant d’atteindre leurs objectifs grâce à l’image, et ça passe forcement par une vision long terme.

🛠️ Parce qu’à la base, la vidéo n’est pas un produit…c’est un outil.
Un outil qui apporte une solution, qui ouvre des portes et qui génère des opportunités.

Des clients comme Fabli l’ont bien compris avec une collaboration qui grandit à chaque nouveau projet pour mon plus grand plaisir!

Vous avez un projet? Commençons par prendre un café! ☕ 

Photo: Dernier tournage publicitaire pour la campagne de noël de Fabli avec Ève Saint-Louis et Mélanie Heyberger. | 19 | 3 | 1 | 3w | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:04.995Z |  | 2025-11-11T12:28:17.998Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7380970558953484292 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG5C1l_uy7GtA/feedshare-shrink_800/B56Zm55nIYIAAg-/0/1759760512027?e=1766620800&v=beta&t=Y-X_FD3tsTYG7s67IFGmba30vozGYWdE_Y7MM222oP0 | 🎥 93 % des équipes marketing ne savent pas utiliser la vidéo!

💸 Alors pourquoi investir des milliers de dollars dans un format si puissant…
pour n’avoir aucun impact réel derrière?

J’ai récemment collaboré sur un projet documentaire.
👉 Résultat: le projet a cartonné.

Pas parce que les images étaient belle (en 2025, tout le monde peut faire ça).
Mais parce qu’il y avait une stratégie claire derrière chaque plan, derrière chaque image.

Le documentaire n’était pas une fin en soi. C’était la porte d’entrée vers une stratégie bien pensée avec une page de destination optimisée, une campagne diffusée via les réseaux sociaux et des ambassadeurs pour relayer le tout.

💡 Alors, comment intégrer la vidéo dans une stratégie qui fonctionne vraiment?
1️⃣ Définissez votre objectif.
2️⃣ Identifiez précisément votre audience.
3️⃣ Clarifiez le problème que votre service ou produit résout.

Ensuite, posez-vous cette question :
👉 Comment la vidéo peut-elle amplifier cette stratégie?

Quand elle est pensée comme un outil stratégique, la vidéo devient l’un des investissements les plus rentables de votre communication.

J’aide les marques engagées à devenir iconiques grâce à la réalisation de vidéos authentiques. Parlons de votre futur projet autour d’un café!

Source: Content Marketing Institute | 14 | 0 | 0 | 2mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:04.995Z |  | 2025-10-06T14:21:53.056Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7379147795527651328 | Document |  |  | 📣 Rendre un discours crédible ne tient parfois qu'à la composition visuelle d'une scène.

Quand on regarde une interview, on pense souvent au message de la personne qui parle.

Mais ce qu’on oublie, c’est tout le travail visuel qui vient renforcer ou affaiblir ce message.

👀 Quelle émotion voulons-nous que le spectateur ressente à ce moment-là?

Dans le cas de cette interview qui met en avant un chauffeur de bus et son quotidien, j'ai voulu créer une ambiance intime mais également sombre, rappelant les difficultés quotidiennes auxquelles ils font face.

Le fond d'arrière plan noir n'est pas la non plus par hasard. Il sert à projeter les lignes qui rappellent les trajets qu'empruntent chaque jour les chauffeurs de bus, en créant une sorte de pattern visuel.

Je voulais également qu'on connecte avec la personne interviewée et son discours sans prêter attention à l'environnement ou nous avons tourné.

Le chandail que porte notre chauffeur n'est pas non plus choisi par défaut. Il rappelle les couleurs de son employeur et vient contraster avec la couleur de sa peau. Vous avez sans doute peut-être vu ces couleurs complémentaires d'orange / bleu que l'on retrouve souvent en production cinématographique.

🎥  Au final, une interview c’est une rencontre entre une personne, une histoire et une intention visuelle. | 16 | 0 | 0 | 2mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:04.996Z |  | 2025-10-01T13:38:52.390Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7375883468112547840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG2Wy7aAQJhrQ/feedshare-shrink_800/B4EZlxm7XAGUAg-/0/1758547654676?e=1766620800&v=beta&t=1TxmVBMGAJMNxNTCtQahTb2GD7TP3blmb0OHu80ssHQ | 🤙 Sans doute l’un des projets les plus physiques que j’ai eu l’occasion de réaliser à ce jour.

🎥 La SCFP 1983 m’avait contacté pour réaliser un portrait documentaire sur les chauffeurs de bus à Montréal.

👀 Vous avez peut être d’ailleurs vu passé la vidéo avec plus de 70k vues, 800 likes, 480 partages et plus de 150 commentaires, tout ça en seulement 1 semaine!

Dans ce portrait, je voulais obtenir le rendu le plus immersif possible. 

Qu’on est une idée honnête de ce qu'est le travail de chauffeur de bus.

📋 Si je résume ce tournage, il aura fallu:
- 1 journée de repérage complète pour comprendre comment le rouage du transport public fonctionne ici.
- 1 journée avec une chauffeuse, Lissa, en heure du matin: départ de chez moi à 3h pour être prêt à tourner à 4h à Longueuil et finir à 16h (retour à la maison à 17h).
- 1 journée avec un chauffeur, Stéphane, en heure du soir: départ à 8h de chez moi pour être prêt à tourner à 10h du matin et finir à 1h du matin, le lendemain (retour à la maison vers 2h).
- On ajoute à ça, les courses entre les arrêts de bus en portant sa caméra de 10kg pour obtenir le plus d’immersion possible et des plans extérieurs.
- 1/2 journée d’interview dans les bureaux de la SCFP avec nos 2 chauffeurs.
- Les heures de montages pour obtenir le résultat final.

C’était intense, mais le résultat en valait la peine!

❓ Mais le plus important. Pourquoi ce projet cartonne autant? Ça intéresse qui le portrait documentaire, à l’heure où tout le monde fait des vidéos “dynamiques”?

Tout d’abord on peut expliquer le succès de la campagne par le fait que le transport public intéresse globalement tout le monde. Mais le succès se doit aussi à l’authenticité du moment capturé. 

On peut facilement s’identifier à Lissa et Stéphane parce qu’ils sonnent vrai.

Cette authenticité dont je parle tout le temps c’est ce qui fonctionne aujourd’hui et c’est elle qui reste dans les esprits du spectateur!

Les marques doivent repenser en profondeur leur modèle de communication et le véritable objectif derrière chaque projet.

Ce changement c’est maintenant qu’il doit se faire.

👉 Le portrait est disponible en lien dans la description! | 22 | 1 | 1 | 2mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:04.997Z |  | 2025-09-22T13:27:36.086Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7340362422983032834 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEHccMMoYjozg/feedshare-shrink_800/B4EZd40uaLG4Ak-/0/1750078777964?e=1766620800&v=beta&t=O79Ap3sU1E2aNe3Sv_JvD7p2FqgY6sKzFTsKhhYHGbs | Voici comment réaliser une publicité pour la NBA pour 2000$ et en seulement 2 jours de travail 👇

1. Rédigez un script (mais rapidement hein, on a pas le temps...).
2. Envoyez tout ça sur Geminin, ChatGpt et autre outil d'IA pour finaliser le script.
3. Commencez à générer des images vidéos avec VEO 3.
4. Soyez patient, parce que les rendus d'image bug...souvent (400 générations d'images pour obtenir 15 clips utilisables, le ratio est pas dingue...)
5. Et voilà...vous obtenez une belle vidéo, 100% dopamine, 100% impersonnelle, 100% déjà vue. (mais pas cher)

Pas convaincu? Pourtant les prédictions annoncent que cette tendance va définitivement devenir la norme pour les marques. 

C'est exactement ce qu'à fait le réalisateur PJ Ace pour la marque Kalshi durant le championnat de NBA....

Maintenant prenons du recul. Le résultat de cette vidéo est assez impressionnant lorsqu'on sait que toutes les images sont générées à partir d'IA. La marque a réussi à faire le buzz non pas grâce au message de sa vidéo, mais grâce à la prouesse technique pour la réaliser. Pari gagné?

Est-ce que ça m'inquiète pour l'avenir de mon métier? Pas vraiment. Je reste convaincu que nous rentrons dans une aire où l'hyper personnalisation et l'authenticité feront la différence plutôt que le matraquage de visuels sans saveur qu'on aura tous déjà vu 100 fois...

Bonne semaine à tous ;)

Lien de la vidéo en commentaire 🎥 | 9 | 1 | 1 | 5mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.420Z |  | 2025-06-16T12:59:38.978Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7321160187979972608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGAtv1TjWwQtg/feedshare-shrink_800/B4EZZn8ZQkHkAg-/0/1745500607915?e=1766620800&v=beta&t=VyZgnHYpAi6_CKNmqLL8nCW3d2nsDX3hIPhe_-BLHsk | 🎬 Appel à collaboration – Pépites recherchées 🌍

Je suis à la recherche de pépites créatives ici au Canada (je suis basé à Montréal), pour bâtir une équipe soudée autour de projets vidéos documentaires et commerciaux à impact sociaux ou environnementaux positifs.

J’ai beaucoup de projets que je veux mener à terme, mais seul c’est tout simplement impossible…alors je cherche des talents qui partagent les mêmes valeurs et la même vision pour créer des récits authentiques et engagés. Ces personnes doivent être autant à l’aise en anglais qu’en français.

✨ Les talents que je cherche :
- Un(e) monteuse / monteur capable de raconter une histoire en documentaire ou de dynamiser une vidéo en commercial
- Un(e) rédacteur(trice) / scénariste capable de structurer et de sublimer une histoire
- Un(e) productrice qui sait allier rigueur, humain et ambition

En résumé, je cherche à m'entourer de personnes bien meilleures que moi avec un fit, humainement parlant ;)

Voici une liste de projets en cours. Certains ont débuté, d’autres à commencer (certains sont rémunérés, d'autres autofinancés):
- Court documentaire sur une ancienne infirmière en santé mentale qui aide les premiers répondant atteint de trouble de stress post traumatique grâce à la pratique de la pêche
- Court documentaire sur le bienfait du sport à travers le parcours d’un ancien sportif de haut niveau atteint de maladie dégénérative
- Court documentaire sur l’impact des pesticides sur la santé de nos agriculteurs
- Spec Ad sur une marque: thème course à pied
- Spec Ad sur une marque: thème Basketball

👉 L’idée finale est de collaborer sur plusieurs projets pour enrichir mutuellement nos portfolios avec l’envie d’aller loin ensemble, dans la durée.

Si tu veux qu’on crée de la valeur, du sens et un impact – discutons!

Et si tu connais quelqu’un qui pourrait être cette pépite, n’hésite pas à partager ce post ou à le taguer 🙏

Mon travail est disponible sur mon site https://lnkd.in/e-hpEyPY
et vous pouvez m'envoyer un message avec votre portfolio à nicolas@nvision-productions.com | 47 | 5 | 4 | 7mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.421Z |  | 2025-04-24T13:16:49.393Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7316512131208630273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGYdR-OQuaIZA/feedshare-shrink_800/B4EZYl5AkvG0Ag-/0/1744392424893?e=1766620800&v=beta&t=mWUt5N4I1wMJr5OK0qUWBrIfR8e6DmJOYAY6FrgQEAM | 📣 Recherche une personne pour le tournage d'un mini documentaire 📣

Je remets le couvert en préparant à nouveau un court documentaire à impact positif, dont le tournage aura lieu en mai et sur une journée (je suis à Montréal et peux me déplacer au Québec si besoin).

💥 Pour cela je suis à la recherche d’une femme, ou d’un homme, au cœur d’un moment charnière de sa vie.

👉 Je cherche quelqu’un : 
– en train d’accomplir un objectif personnel,
ou
– en train de prendre une revanche sur la vie, sur sa santé, sur un passé difficile,
ou
– ou en train d’agir concrètement pour une cause sociale ou environnementale.

L’objectif est de mettre en avant cette personne derrière la caméra pour qu'elle puisse à son tour sensibiliser et inspirer le public, en me permettant de raconter une histoire authentique, sincère et humaine.

Si vous connaissez une personne qui répondrait à cela, envoyez-moi un message en privé ou taguez-la dans les commentaires.

Merci d’avance pour vos partages!! 🙏 🙏 | 14 | 7 | 2 | 7mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.422Z |  | 2025-04-11T17:27:06.302Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7313896632872284162 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhPazEBlcU3g/feedshare-shrink_800/B4EZYAuO38HgAg-/0/1743768842109?e=1766620800&v=beta&t=dOHS62SVUXd1kfIQDsNyPODN9qK3yH1R8w73swBuKQs | L’IA vous tire vers le bas! ❌ 

Si vous avez raté la grosse tendance actuelle, je vais vous la rappeler brièvement: comment transformez une image en dessin animé façon Ghibli…

Tout le monde est surexcité à l’idée de voler le travail d’un monument du dessin animé, Miyazaki, pour en faire des contenus “tendances”.

Outre le côté marrant à voir, pensez-vous vraiment que ça va apporter quelque chose à votre business?

💸 À moins d’avoir une stratégie bien précise qui viserait à utiliser ce type de contenu, ça ne vous apportera rien au même titre qu’utiliser des images libres de droits en 2025…Vous gaspillez votre argent…

Nous sommes rentrés dans l’ère de l’authenticité ou montrer son vrai visage et ses faiblesses sont la clé pour émerger et gagner en visibilité plutôt qu’une communication générique basée sur des tendances…

Dans un registre similaire, de nombreux vidéastes et réalisateurs ont peur que l’IA leur fasse perdre des contrats, en allant pitcher à leur place des idées tout droit sorti de Chatgpt.

🎉 Rassurez-vous, l’IA ne remplacera jamais une chose: vous-même.
L’IA ne remplacera jamais votre propre histoire.
L’IA ne remplacera jamais votre vision et ce en quoi vous croyez.

💥 L’IA est un outil qui peut vous aider, pas vous remplacer.

Photo:
Client: Fabli
Projet: Vidéo de lancement | 35 | 2 | 1 | 8mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.423Z |  | 2025-04-04T12:14:02.905Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7307406773873762305 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG0ZnQ2XBf_6w/feedshare-shrink_800/B4DZWkfvVBGkAo-/0/1742221538977?e=1766620800&v=beta&t=OKmOIjiWmM2dA8lTI6WL6Z2V22yAs64OwC_WhcCKjWk | 💥 Je suis honoré de vous annoncer que je débute un nouveau partenariat avec l’Association pour la santé publique du Québec | ASPQ).

🎥 Ce projet de réalisation vidéo aura pour but de mettre en lumière les initiatives du réseau de la santé et des services sociaux (RSSS) ayant un impact positif sur l’environnement et contribuant aux efforts de décarbonation du réseau!

🙏 Merci à Amélie Bonifacj et Jérôme Leclerc pour leur confiance!

Stay tuned :)

#Impactpositif #productionvidéo | 38 | 6 | 0 | 8mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.424Z |  | 2025-03-17T14:25:39.944Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7303541145261789184 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTZdl7Kg2BqA/feedshare-shrink_2048_1536/B4EZVtj.C8HUAo-/0/1741299900923?e=1766620800&v=beta&t=p9PeoLkTcVtWY_j2vMsLSStrJI6jB8E8DRqroSMe1m8 | 💥 Je suis extrêmement fier de vous annoncer un nouveau partenariat avec Fabli pour réaliser leur campagne vidéo de lancement produit.

🎉 La Fabli est un plus qu'un jouet pour enfant. Elle permet d’écouter des histoires et de jouer à des jeux, sans utiliser d’écran!

💛 Mais ce qui la démarque, c'est tout le contenu qui a été pensé et crée par des professionnels de la santé! 

Ça permet à ce compagnon de jeu d’être un réel soutien émotionnel et cognitif à chaque étape du développement de l’enfant.

🎥 J’ai bien hâte de capturer ce petit bijou de storytelling en image avec NVision Productions et de créer quelque chose de spécial!

Merci à Thibault Lerailler de m'avoir fait rencontrer l'équipe, et d'avoir pensé et créé le design de la Fabli avec Punctuate Design Studio. Ce compagnon est absolument canon!

En attendant, rendez-vous sur https://fabli.co/ si vous voulez plus d'infos! | 45 | 12 | 2 | 9mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.425Z |  | 2025-03-06T22:25:02.263Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7302682758231805953 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhYnVw6fhN-Q/feedshare-shrink_800/B4EZVhXPu6G0Ag-/0/1741095245955?e=1766620800&v=beta&t=SNeYayUsyBU4Q8Eoe51j5ogqV4KG69elF4YoZoUou5w | ‼️ Tout ne tourne pas autour des entreprises B Corp!

En mars on célèbre toutes les entreprises certifiées ou en cours de certification B Corp. Ces entreprises doivent répondre à des critères bien précis pour avoir le label et pouvoir démontrer qu’elles ont un impact positif sur les personnes, les communautés et la planète. 🌎 

Mais aujourd’hui je souhaite mettre en lumière toutes les organisations qui ne peuvent pas avoir cette certification (parce que non lucrative) et qui ont pourtant un impact considérable sur les prises de décisions sociales environnementales.

🎂 Par exemple, le GRAME a fêté ses 35 ans d’activités il y a quelques semaines.

35 ans ou cette belle organisation encourage l’écocitoyenneté.
35 ans que le GRAME expérimente dans la ville en favorisant la santé et le bien être.
35 ans que ses membres font des recommandations basées sur des preuves scientifiques.

👏  Chapeau !

👏 Mais chapeau aussi à Équiterre, Moisson Montréal, GoRecycle, MASSE CRITIQUE, et bien d’autres qui œuvrent dans la même direction à impact positif. 

Ces organismes ont autant besoin de lumière que les B Corp alors si vous en avez d'autres en tête, n'hésitez pas à les taguer en commentaire!


J’ai lancé de mon côté le processus de certification B Corp, parce qu’il est essentiel de démontrer l’impact positif qu’une entreprise de production vidéo peut avoir!

Photo: 35 ans du GRAME aux côtés de Louis-Philippe Tessier (mobilidée) et Maja Vodanovic (Mairesse de Lachine).

#BCorp #Impactpositif #BLab | 37 | 2 | 0 | 9mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.426Z |  | 2025-03-04T13:34:06.847Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7300911268041838594 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0D-ambDshXQ/feedshare-shrink_800/B4EZVIMHF3HcAo-/0/1740672889926?e=1766620800&v=beta&t=9TXTrCgYLifKX2vyFcuU8bup4yck95x-UFroXG5ORXU | 💲 Quel est le prix réel de ce que vous devez payer pour une vidéo?
500$, 5 000$, 50 000$?

Cette différence de prix vous parait absurde? 

Pourtant ce qui peut paraître absurde pour certains, se justifie amplement pour d’autres.

❓ Alors, je vous pose une question simple: qu’attendez vous d’un vidéaste?

- Avez vous besoin de quelqu’un qui appuie simplement sur le bouton d’enregistrement et capture ce qu’il se passe devant lui?

- Avez vous besoin d’un accompagnement avec quelqu’un qui comprenne votre business et les objectifs à atteindre derrière la réalisation vidéo en vous challengeant sur le rendu final?

- Avez vous besoin d’une équipe complète, qui puisse gérer l’écriture, la réalisation, la post production et la distribution et toute la stratégie de la vidéo?

Chaque service est bien différent et à un prix, mais c’est à vous de savoir ce dont vous avez besoin.

C’est à vous d’avoir conscience que pour 500$ vous n’aurez peut-être pas le service d’une agence de production vidéo.

C’est à vous d’avoir conscience que le pouvoir de la vidéo aujourd’hui n’est pas d’avoir une belle image. Le pouvoir de la vidéo c’est de planifier toute la stratégie qui va autour. La “belle image” doit faire partie de votre prestation si vous faites appel à un vidéaste professionnel :)

Faire de la vidéo parce que c’est dans l’air du temps, sans stratégie c’est gaspiller votre argent alors posez vous la question lors de votre prochain projet vidéo: De quoi avez-vous réellement besoin?

PS: si vous ne savez pas de quoi vous avez besoin, on peut toujours s’en parler de vive voix pour le définir ensemble ! ;)

Client: Alliance SaluTERRE & Équiterre
Projet: Chaque Terre Compte | 25 | 0 | 1 | 9mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.427Z |  | 2025-02-27T16:14:50.673Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7271935321494142977 | Video (LinkedIn Source) | blob:https://www.linkedin.com/068c8ee4-3b49-4e98-ab63-d373000e1de4 | https://media.licdn.com/dms/image/v2/D4E05AQEjwsf6mgZ7tQ/videocover-low/videocover-low/0/1733764456512?e=1765785600&v=beta&t=Q_E_gQQhF3_bUyqrgnCKxjYEnyoqDpRhIz5dZ0CM4Yg | 🎥 Tout quitter pour vivre de sa passion et devenir vidéaste documentaire et commercial à l’autre bout du monde.

Cela fait un peu plus de 2 ans que j’ai pris le risque de me lancer en affaires en investissant tout ce que j’avais. Énergie, argent et temps.

D’ailleurs quand on parle d’aventure entrepreneuriale je ne suis pas tout à fait d’accord. L’entreprenariat c’est plus qu’une aventure. C’est avant tout des rencontres, des risques, des expériences, des erreurs, de la fierté mais surtout du soutien!

💗 Ce soutien, indispensable pour réussir, je le dois à ma chère épouse, cachée dans l’ombre, mais qui m'encourage, me motive et me booste chaque fois que c’est nécessaire ! :)

Je souhaite à tout le monde d’avoir ce binôme pour continuer d’avancer sereinement dans vos projets.

👉  Voici donc à quoi ressemble 2 années de soutien résumé en 50 secondes ;)

🙏  Merci à tous mes clients, mes partenaires et toutes les personnes qui m’ont fait confiance jusqu’ici! | 75 | 19 | 2 | 11mo | Post | Nicolas Varillon | https://www.linkedin.com/in/nicolasvarillon | https://linkedin.com/in/nicolasvarillon | 2025-12-08T07:12:07.428Z |  | 2024-12-09T17:14:46.669Z |  |  | 

---



---

# Nicolas Varillon
*NVision Productions*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Video Editing in Montreal - Nicolas Varillon](https://nicolasvarillon.com/en/video-editing/)
*2024-05-09*
- Category: article

### [Resilience - Mini Documentary - Nicolas Varillon](https://nicolasvarillon.com/en/positive-impact-films/resilience-mini-documentary/)
*2025-04-19*
- Category: article

### [Video Color Grading in Montreal - Nicolas Varillon](https://nicolasvarillon.com/en/video-color-grading/)
*2024-05-09*
- Category: article

### [He needs you - Refuge Animex - Nicolas Varillon](https://nicolasvarillon.com/en/videos/he-needs-you-refuge-animex/)
*2024-05-09*
- Category: article

### [](https://elvtr.com/blog/interview-with-nicolas-darveau-garneau)
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Resilience - Mini Documentary - Nicolas Varillon](https://nicolasvarillon.com/en/positive-impact-films/resilience-mini-documentary/)**
  - Source: nicolasvarillon.com
  - *In one day, I planned to interview ... NVision Productions. +1 438 509 3727. 300-204 rue du Saint-Sacrement, Montréal, QC H2Y1W8 Canada. 2025 Nicolas ...*

- **[Dans le quotidien des chauffeurs de bus à Montréal - Nicolas Varillon](https://nicolasvarillon.com/dans-le-quotidien-des-chauffeurs-de-bus-a-montreal/)**
  - Source: nicolasvarillon.com
  - *... interview. Le matériel utilisé ... NVision Productions. +1 438 509 3727. 300-204 rue du Saint-Sacrement, Montréal, QC H2Y1W8 Canada. © 2025 Nicola...*

- **[Résilience - Mini Documentaire - Nicolas Varillon](https://nicolasvarillon.com/films-impact-positif/resilience-mini-documentaire/)**
  - Source: nicolasvarillon.com
  - *C'est la partie interview qui ... NVision Productions. +1 438 509 3727. 300-204 rue du Saint-Sacrement, Montréal, QC H2Y1W8 Canada. © 2025 Nicolas Var...*

- **[Video productions](https://nicolasvarillon.com/en/videos/)**
  - Source: nicolasvarillon.com
  - *CRSSS - Let's Talk Mental Health ... NVision Productions. +1 438 509 3727. 300-204 rue du Saint-Sacrement, Montréal, QC H2Y1W8 Canada. 2025 Nicolas Va...*

---

*Generated by Founder Scraper*
