# Saeed Sarfarazi

## Position actuelle

**Titre** : Founder - CEO
**Entreprise** : MoreConvert
**Durée dans le rôle** : 4 years 10 months in role
**Durée dans l'entreprise** : 4 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

MoreConvert is a subscription-based SaaS solution that combines wishlist, waitlist, email automation, and analytics tools to convert traffic into sales.

## Résumé

Now building infrastructure for deep-tech founders to influence Canada’s innovation landscape.

For the past 12+ years, I’ve built startups from scratch, sometimes winning big, sometimes failing forward, always learning. A few highlights:

Launched a research and education platform that reached 250,000+ paid users in a highly niche market (~40% market share).

Ran a software development agency that built subscription-based web apps with 13,000+ active users.

Led a 70+ person team for more than 8 years.

I’ve bootstrapped every venture without outside funding, which taught me to stay scrappy, resourceful, and relentlessly focused on growth. The failures have been as meaningful as the wins, they shaped how I lead, build, and strategize today.

I’m passionate about turning ideas into products, products into businesses, and businesses into long-term value.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADOyjKQBezQ9pxy6z40aHKxw7_jcawTgano/
**Connexions partagées** : 8


---

# Saeed Sarfarazi

## Position actuelle

**Entreprise** : Canadian Physical AI Institute (CPAI)

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Saeed Sarfarazi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402759382427549696 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQF1Ok-chRClzA/mp4-720p-30fp-crf28/B4EZrviYG2HgCM-/0/1764955363856?e=1765785600&v=beta&t=Qjl9px5UXmyIcu8huWcUvX5_RGBChBHnGeQwZER_SU4 | https://media.licdn.com/dms/image/v2/D4E05AQF1Ok-chRClzA/videocover-low/B4EZrviYG2HgBU-/0/1764955359393?e=1765785600&v=beta&t=twUgJeqvR7aGHEJsE3zfCYf5kjqocMCAePFDpv_-5Mo | Alexander with his great teammates in MIT built a system where you can simply speak to a robot, and it will design and build a physical object (like a stool or table) in minutes. 
It combines Large Language Models (LLMs) with robotic assembly, allowing users to "speak objects into existence."

Although today’s speech-to-reality systems are still constrained by slow robotic assembly, limited material strength, and the simplicity of modular components, they represent a profound shift in how we interact with the physical world.

We can imagine a future where anyone without CAD skills, without fabrication training can co-create with AI and robotics simply by expressing intent through speech, gesture, or thought.

These systems may be limited now, but their direction is unmistakable:
 a world where reality itself becomes editable that is really exciting.

Learn more: 
https://lnkd.in/eXc9MyYr

#PhysicalAI #Robotics #GenerativeAI #EmbodiedAI #MIT #Innovation | 8 | 0 | 0 | 2d | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.120Z |  | 2025-12-05T17:22:53.389Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401643873145401344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEMwThT8NN6pw/feedshare-shrink_800/B4EZrfpgJpKkAk-/0/1764688795986?e=1766620800&v=beta&t=jM6Uch8W7EoM_y2MgTfILL1AS6WUMSckOmaO9TiHU6g | Most people will watch the future arrive.
 A few will build it.
If you’ve been waiting for a place to start, this is it.
Applications are open for the first CPAI Canada Physical AI cohort.
👉 Don’t just follow progress, join it.

 Click the page and hit Apply to Collaborate | 3 | 0 | 0 | 5d | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.120Z |  | 2025-12-02T15:30:15.251Z | https://www.linkedin.com/feed/update/urn:li:activity:7401641282189676544/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396947891875110913 | Text |  |  | We’re not at the absolute limit of silicon, but we’re definitely past the time of huge, easy jumps in raw compute.
GPUs will still get better, but those insane “+200% every year” moments?
Yeah… that phase is basically over.
If you’re showing up now expecting the same ride, you’re late to that party.

The real choke-point for AI isn’t compute anymore, it’s energy.
Data centers are eating power like entire countries, and every new model needs even more juice.

That’s why the next big wave isn’t just “faster chips.”
It’s everything around them:

new ways to generate and store energy
stronger, smarter power grids
cooling and infrastructure
hardware built for efficiency, not just brute force
and later on: quantum stuff and physical/robotic AI

The GPU hype isn’t dead, but it’s mature.
The next real growth story is energy and the systems that can actually feed the AI world.
That’s where the future is opening up. | 3 | 1 | 0 | 2w | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.121Z |  | 2025-11-19T16:30:06.069Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7395166132997050368 | Video (LinkedIn Source) | blob:https://www.linkedin.com/12d0512d-0f34-4642-a852-c15fa0b50423 | https://media.licdn.com/dms/image/v2/D4E05AQFlXXocsDW2yw/videocover-low/B4EZpaZnzAIwBU-/0/1762453263328?e=1765785600&v=beta&t=pwcI7oShHoTK-O8JRunSujLq9PORaSHuNg9_Wm5CaOg | These days, more than ever, I’ve been studying failed Physical AI startups.
 What fascinates me most is that most of them don’t fail because of the product, they fail much earlier, at the level of strategy and roadmap.
One team promotes a feature-stuffed device but can’t manage the complexity of actually building it.
 Another skips proper market validation and launches something driven purely by conviction.
 And surprisingly, many still manage to raise significant funding, because investors are captivated by the creativity of the idea, not the strength of the problem it solves.
Take Jibo, for example.
 What ultimately doomed it was the sunk cost fallacy.
 When the company could have joined Alexa’s ecosystem or pivoted toward a more defensible niche, it instead doubled down on the original concept, an idea that was charming, but not essential.
 They kept building the same dream long after the market had moved on.
So here’s my question for you:
 👉 How can a company, after spending heavily, making promises, and even running pre-sales , change direction without destroying the trust it has built?
P.S. The voice in the video is from NotebookLM, and the footage is from their demo. | 5 | 0 | 0 | 3w | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.122Z |  | 2025-11-14T18:30:01.649Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7394366058897461249 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFcy6XCbkCPBQ/feedshare-shrink_800/B56Zp2MSGBHIAg-/0/1762919526567?e=1766620800&v=beta&t=AaVe10Xb17ubnYC3IMH9MHh2nqofH3TbESs2WKZ1YF4 | Today’s robots “suck” in unlearned situations,
 because they don’t have the world-model-based reasoning humans and animals use to navigate the unknown.
They are performers, not learners.
 Responders, not thinkers.

When something changes a cup tips over, lighting shifts, a tool is missing, or the table is in a new position most current robots fail or freeze.

Because they don’t yet have an internal world model, they can’t predict what will happen or plan a new sequence of actions on the fly.
 They rely on learned policies, not reasoning.

Yann LeCun calls this out directly:
“Any 10-year-old can clear a table or fill a dishwasher ‘zero-shot’.
 Our robots cannot.”
That’s the Moravec’s paradox:
 Things easy for humans (intuitive physical reasoning) are hardest for machines.
A robot with a learned world model doesn’t just replay memorized skills, it imagines and tests hypotheses internally.
 It can:
Predict what will happen before acting 
Adapt a plan when conditions change
Handle uncertainty and partial information
Learn new skills faster through observation, not millions of trials
That’s what LeCun calls Objective-Driven AI  machines that reason and plan via optimization, not token prediction or static policies.
Thanks Chris Yoo for sharing this great idea.

Main slides : https://lnkd.in/e3jVM9VM | 2 | 0 | 0 | 3w | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.122Z |  | 2025-11-12T13:30:49.119Z | https://www.linkedin.com/feed/update/urn:li:activity:7394220427369222144/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394110732801355776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGh9FoJRHNgsQ/feedshare-shrink_800/B4EZp0ohuBHgAg-/0/1762893373399?e=1766620800&v=beta&t=u-e_6Kw8qIuxVWZaT9YwsKlAZJ_6EeaQXYj4jO3h70U | Today I’m digging into trends happening around Physical AI and I’ve spotted three major waves shaping its evolution, from the past to the near future.

Wave 1: The Full-Stack Era (2015–2021)
This was the “do it all” age.
Startups built everything from scratch.
Companies like Attabotics, Starsky Robotics, and Argo AI burned through hundreds of millions trying to own the entire stack.
It was visionary…
…but unsustainable.
These companies weren’t just building robots, they were, unknowingly, building the infrastructure for robotics.

Wave 2: The Unbundling Era (2022–2025)
Investors and founders realized that the biggest opportunities weren’t in the robots themselves, they were in the “picks and shovels” that make robots possible.
This triggered the great unbundling, an explosion of tooling and middleware startups, each mastering one piece of the puzzle:
Formant: “Datadog for robots” (fleet observability)
Foxglove: “Visual Studio for robotics developers” (data visualization)
Polymath Robotics: “Stripe for autonomy” (API-driven control stacks)
PickNik Robotics: “Red Hat for manipulation” (open-core model)
This era transformed robotics from hardware-heavy R&D into something modular, API-driven, and capital-light.

Wave 3: The Networked Intelligence Era (2026–2030)
Now comes the next transformation, when robots stop learning alone and start learning together.
Physical AI systems will soon operate as connected intelligence networks: fleets, digital twins, and AI models sharing knowledge through the cloud.
Picture this:
A delivery robot in Toronto hits black ice and learns to recover that experience instantly updates the driving models of fleets in Stockholm.
A robotic arm in Japan learns a new grasp technique and uploads it to a global “robot skill store” that any factory in the world can download.
Fleets across industries share model updates securely through federated learning, improving global performance without exposing raw data.
This is the Internet moment for robotics.
Just as the Internet connected people, and cloud computing connected software,I think Wave 3 connects embodied intelligence: robots, vehicles, and environments that continuously improve each other through data loops.
The future of Physical AI isn’t another humanoid.
 It’s the network where all robots think, learn, and evolve together.
#PhysicalAI #Robotics #AIInfrastructure #Tooling #RobotOps #EdgeAI #FutureOfAI #DeepTech | 6 | 0 | 0 | 3w | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.123Z |  | 2025-11-11T20:36:14.634Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7392255707892359168 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7e8f88de-a911-48ed-8c92-b11ee7b99644 | https://media.licdn.com/dms/image/v2/D5605AQER0Sqs607tUw/videocover-low/B56Zo2C_3vIcBQ-/0/1761843348591?e=1765785600&v=beta&t=KN1bQmEPxdr73rAkQV_iAQEFjQ_K1Agf8J3J7uEdzP4 | 🏡 Why NEO Still Needs a Human Behind the Curtain!!!

You all have heard about Norway’s 1X Technologies home robot NEO but I think there is a part that most headlines skip
It’s not fully autonomous Yet.

In this first phase, NEO’s “AI” is actually a human-in-the-loop system.
You schedule a time, say, 9 AM to clean your living room and a remote operator connects, performing tasks through NEO while you watch through the app.
Faces are blurred for privacy, and “no-go zones” are enforced.

But make no mistake: this is telepresence, not true autonomy.
So why do this? Because every hour of remote work becomes training data for 1X.
It’s the bridge between today’s semi-manual control and tomorrow’s self-sufficient home AI.
Unstructured environments like your home is chaos, not a lab.
Actuator reliability like today’s motors and tendons can’t run 3,000 hours without service.
Privacy and trust like always-on cameras and remote access make many users uneasy.
This isn’t failure, it’s the honest stage between “robot vacuum” and “robot companion.”

 The next step
The real leap will come when robots like NEO:
combine shared autonomy (80% on-board AI + 20% human assist),
achieve quiet, safe actuation that lasts months without service, and operate offline-first, with privacy built into every sensor.
Until then, home robots will be part helper, part research platform learning from us before they can live with us.

Would you let a remote operator control a robot inside your home, if it meant teaching that robot to one day work fully on its own?

#PhysicalAI #HomeRobotics #Humanoids #1X #EmbodiedAI #AIinAction #SmartHome #HumanInTheLoop #FutureofWork | 8 | 4 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.124Z |  | 2025-11-06T17:45:02.231Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391496970869207040 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ffd3a5cf-0b26-40b2-98ee-28cfb6478716 | https://media.licdn.com/dms/image/v2/D5605AQE37U35jZCinQ/videocover-high/B56Zo16iY_J8BU-/0/1761841130106?e=1765785600&v=beta&t=CPQMFXZM3KmK7etu885NZuBRzL9AmwE9jsKALbAfdtQ | 🚁 Drone delivery, worth it, or just hype?
Everyone loves the clips of pizzas flying through the sky…
 But here’s what most people don’t say out loud: 👇
The cost is massive.
 Buying a drone is cheap.
 Certifications, insurance, and weather-proof ops are not.
 It works but only sometimes.
A drone can deliver 2–3 kg of food faster than a scooter if
the route is open air, and
the drop zone is simple (house or parking lot).
But it can’t deliver 4 pizzas to an apartment tower in the rain.
That’s why current drone routes focus on suburbs, campuses, or hospitals, not downtown cores.

The real story is Physical AI.
 Fleets that learn routes, weather, and maintenance patterns.
 That’s what scales not just delivery speed.
Even the biggest players struggle to beat human couriers on cost per delivery.
 To win, they need:
thousands of flights per day
multi-merchant networks
AI-driven scheduling + maintenance
Until then, drone delivery is more of a strategic experiment than a profit engine.

So is it worth it?
we can say: 
 ✅ For Marketing Cases, pilots and partnerships, yes.
 ❌ For full replacement of drivers, not yet.

What do you think ?
1. Cool frontier worth investing early
2. Sky hype that still needs to land

#DroneDelivery #PhysicalAI #AutonomousLogistics #SmartCities #Robotics #LastMile | 13 | 7 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:36.125Z |  | 2025-11-04T15:30:05.228Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7389689510076243968 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4b960be1-8629-4f05-b134-9fb2aa3500bb | https://media.licdn.com/dms/image/v2/D4E05AQFwuHPFrNapLA/videocover-high/B4EZo1zbXxGUBU-/0/1761839267164?e=1765785600&v=beta&t=yuY7-XLL7VWdCEbLFswRlmQWPjl4TSy_81vz3ueebKA | When robots start thinking in metal 👉 this happens:

Huayan Robotics’s Robot has combined AI-driven welding and 3D printing to create a system that can see, adjust, and build metal parts on its own.

Cameras and sensors watch the welding arc and the shape of each layer in real time.
An onboard AI model checks the bead quality and corrects speed, heat, and material flow automatically.
It “learns” the best settings from past welds  so every next part comes out more precise.

🏭 Where it’s used:
Repairing worn or broken industrial tools and molds
Building custom machine parts directly from CAD without casting
Strengthening thin metal sections in automotive and aerospace parts
Rapid prototyping of metal components in R&D labs
⚙️ In short, it’s Physical AI in metal form: a robot that doesn’t just follow instructions, it adapts to the material.

Do you think future factories will all mix welding + printing like this? 👇


#PhysicalAI #Robotics #AdditiveManufacturing #WeldingAutomation #SmartFactory #IndustrialAI #Cobot #Metalworking #AIinManufacturing | 36 | 3 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:38.251Z |  | 2025-10-30T15:47:52.994Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389015270041821185 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGYED1n-HDAgA/feedshare-shrink_800/B4EZosOOx3IoAg-/0/1761678519779?e=1766620800&v=beta&t=dSvGMlUnRALhm8CqEdyZWTBRuop_aHuiV8DLvR2HvFc | I’ve been reading about Samsung’s new Galaxy XR headset. It’s clearly an exciting moment for mixed-reality hardware.
these headsets are no longer just display devices. They’re becoming embodied sensors for AI. However, embodiment isn’t just about sensors.
To reach true Physical AI, three ingredients need to mature:

the system must feel like an extension of the body, not an object pressing against it.
latency and misalignment still break the feedback loop between human motion and AI response.
software must understand context (not just inputs), learning from the user’s space, rhythm, and attention.

The Galaxy XR points toward this direction but early problems already shows the gaps: comfort issues, limited battery life, and a yet-fragile ecosystem.

If we trace the current pace of sensor fusion, on-device AI, and spatial understanding, I’d say we’re 5 to 7 years away from Physical AI headset and eyeglasses being practically embodied, when devices feel as natural and invisible as glasses or earbuds, and AI can seamlessly inhabit our physical context.

Until then, each generation like the Galaxy XR is an evolutionary prototype and not yet a destination, but an essential stepping stone toward it.

Canadian Physical AI Institute (CPAI)

#PhysicalAI #XR #SpatialComputing #GalaxyXR #HumanComputerInteraction #AIEmbodiment #FutureOfAI | 3 | 0 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:38.251Z |  | 2025-10-28T19:08:41.643Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7388741211357925376 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e6eb415a-3d42-4dbd-beeb-f831817786dc | https://media.licdn.com/dms/image/v2/D4E05AQGnF5Smmuu_cQ/videocover-low/B4EZooU.EnHgBE-/0/1761613178309?e=1765785600&v=beta&t=KfdP6WQkRj4A07ggf5ce3YDG7OstEfI7bOeHXHNtbtY | Amazon’s Smart Glasses for Delivery Drivers or Surveillance in Disguise?

Amazon has launched a new pair of AI-powered smart glasses designed to support its delivery drivers but while the technology is impressive, it raises some important questions.

These glasses combine cameras, sensors, and AI to help drivers locate the right package, scan barcodes, navigate directly through the display, and capture delivery confirmation photos all without touching a phone. They’re paired with a smart vest that includes buttons and magnetic connectors, allowing the glasses to be attached independently and powered through hot-swappable batteries for long shifts.

At first glance, this seems like a breakthrough in hands-free efficiency. Drivers can stay focused on their routes, minimize distractions, and complete deliveries faster But the deeper you look, the more complex it becomes.

Are these glasses simply a tool for convenience, or are they also part of a massive data collection system? With built-in cameras and continuous AI processing, every movement, interaction, and environment could technically be recorded and analyzed. That’s a level of surveillance we’ve never seen in last-mile logistics before.

While the integration of navigation and AI support could make phones nearly obsolete during deliveries, it also means Amazon’s ecosystem gains even deeper control over the workflow. Efficiency, yes but at what cost to privacy and autonomy?

Amazon’s smart glasses might represent the next step in AI-driven logistics but they also remind us how thin the line is between innovation and surveillance.
What do you think about this physical AI tool?

#Amazon #AI #WearableTech #SmartGlasses #DeliveryTech #Innovation #Privacy #FutureOfWork #DataEthics #TechReview #physicalai #cpai | 5 | 0 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:38.252Z |  | 2025-10-28T00:59:40.961Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7386454534857957376 | Text |  |  | From ChatGPT 3.5 to ChatGPT 5, I didn’t see any drastic changes, but there’s a bit more accuracy and a big wave of marketing talk and stories about the “future of AI.”
Many AI startups, including ones like Cursor and even OpenAI’s flagship products, still aren’t profitable. For example, OpenAI posted revenue of about $4.3 billion in the first half of 2025, but its losses and cash burn are growing too. They mostly disclose operational costs while avoiding detailed discussion of infrastructure expenses, which are likely amortized over the long term signaling that profitability isn’t coming anytime soon.

More broadly, enterprise AI deployments haven’t delivered strong returns for most companies: a survey found combined losses of around $4.4 billion among large firms adopting AI, even though many remain optimistic.
Meanwhile, startup valuations are soaring into the stratosphere even as real profits remain elusive.

I hope they eventually find a way to create a truly new stage of AI,  something beyond small tricks and ever-bigger transformer models. If that doesn’t happen, I think the bubble surrounding all these fast-growing but still unprofitable companies could burst spectacularly. 😄

I believe the only AI company that manages to stay profitable will ultimately win even if its models, like Gemini, aren’t the strongest simply because it can survive the crash.

And also, physical AI will probably grow noticeably, thanks to lightweight, energy-efficient models and meaningful narrow applications being developed. Since it’s such a hard field to break into, the wild, unrealistic ideas don’t really have much space there which might actually be a good thing.

ps. But to be fair, it really does proofread and organize texts well, doesn’t it?😁
Of course, that alone isn’t enough to survive with this level of growing debt. | 7 | 0 | 0 | 1mo | Post | Saeed Sarfarazi | https://www.linkedin.com/in/saeedsarfarazi | https://linkedin.com/in/saeedsarfarazi | 2025-12-08T07:09:38.252Z |  | 2025-10-21T17:33:14.799Z |  |  | 

---



---

# Saeed Sarfarazi
*Canadian Physical AI Institute (CPAI)*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Mixing Oil and Water: Negative Aliens’ AI-Based Phantom Reality versus Divine Organic Consciousness Holographic Reality  Mohsen Paul Sarfarazi, Ph.D.](https://multidimensionalconsciousness.wordpress.com/2020/07/19/mixing-oil-and-water-negative-aliens-ai-based-phantom-reality-versus-divine-organic-consciousness-holographic-reality-mohsen-paul-sarfarazi-ph-d/)
*2020-07-19*
- Category: article

### [Fundamentals of Physical AI](https://arxiv.org/abs/2511.09497)
*2025-11-12*
- Category: article

### [Interviews with leading business and IT experts](https://stephenibaraki.com/cips/cips_interviewslist.html)
*2025-01-01*
- Category: article

### [Saeed Khan’s Articles, Talks & Interviews](https://swkhan.medium.com/saeed-khans-articles-talks-interviews-6e3e440156aa?source=rss-1b956809074b------2)
*2025-08-08*
- Category: blog

### [Speakers | Canadian AI 2025 Conference](https://www.caiac.ca/en/conferences/canadianai-2025/invited-speakers)
*2025-05-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
