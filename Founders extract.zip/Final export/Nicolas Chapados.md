# Nicolas Chapados

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Chapados Couture Capital
**Durée dans le rôle** : 12 years 11 months in role
**Durée dans l'entreprise** : 12 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Financial Services

## Résumé

Nicolas Chapados holds an engineering degree from McGill University and a PhD in Computer Science from University of Montreal, Canada. While still writing his thesis and jointly with his advisor Yoshua Bengio, he co-founded ApSTAT Technologies in 2001, a machine learning technology transfer firm, to apply cutting-edge academic research ideas to areas such as insurance risk evaluation, supply chain planning, business forecasting, national defence, and hedge fund management. From this work, he also co-founded spin-off companies: Imagia (www.imagia.com), to detect and quantify cancer early with AI analysis of medical images, Element AI (www.elementai.com), an applied research lab in artificial intelligence with a systematic process to connect fundamental innovations with commercial applications (sold in January 2021 to ServiceNow Inc.), and Chapados Couture Capital (www.chapados-couture.com), a quantitative asset manager. He holds the Chartered Financial Analyst (CFA) designation.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAA23l8BnSK-8MpXvMKaFp92b2QDbTYj4Ts/
**Connexions partagées** : 175


---

# Nicolas Chapados

## Position actuelle

**Entreprise** : Chapados Couture Capital

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nicolas Chapados

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396696604403003392 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a34e331b-0aa2-4f27-a7c6-c60fdf4009c8 | https://media.licdn.com/dms/image/v2/D4E05AQFIpN1wyxaRDg/videocover-high/B4EZqUXC2vHEBU-/0/1763425662375?e=1765778400&v=beta&t=jTw4gEO-7bfJBNO8xgKc5C0xUMhRYVEBqAZasn62XuE | Fier de prêter ma voix pour la santé mentale. | 62 | 3 | 0 | 2w | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:05.642Z |  | 2025-11-18T23:51:34.467Z | https://www.linkedin.com/feed/update/urn:li:activity:7396343331619872768/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7378884617279262720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZYIBQJqy6aA/feedshare-shrink_800/B4EZmbCBrQKQAk-/0/1759242625298?e=1766620800&v=beta&t=122Db8tedkFXknH8uCGsi_x_Df_Ru1F4Mug-ecGWGzI | 🚀 Awesome new SLM from ServiceNow! 
Apriel-1.5-15B-Thinker — Small model. Big reasoning 🔥 | 21 | 1 | 2 | 2mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.649Z |  | 2025-09-30T20:13:05.806Z | https://www.linkedin.com/feed/update/urn:li:activity:7378866231220527104/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7350640325884837890 | Text |  |  | Headed to ICML in Vancouver? Don't miss these contributions by the ServiceNow AI Research team!
PS — and if you want to catch up, I will be attending the workshops Friday and Saturday. | 13 | 1 | 0 | 4mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.659Z |  | 2025-07-14T21:40:21.984Z | https://www.linkedin.com/feed/update/urn:li:activity:7350552542809845760/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7321170743415758848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEqnjL3ycXqBA/feedshare-shrink_2048_1536/B4EZZn7j_UHcAw-/0/1745500389993?e=1766620800&v=beta&t=iPxXxqwH1V0vdeiPYq9UWVkTO6FXUDxIa6VFGkTANG8 | Ever wonder what security vulnerabilities lie in your AI agents? Our new DoomArena framework lets you find out! | 20 | 1 | 1 | 7mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.664Z |  | 2025-04-24T13:58:46.005Z | https://www.linkedin.com/feed/update/urn:li:activity:7321159272866746371/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7321109234312437760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0R2uNI8FIYg/feedshare-shrink_800/B4EZZjfoZPHMAg-/0/1745425960904?e=1766620800&v=beta&t=g3B0Nks1lJB-rqyhW-FAjA0u_oCh2kp-lPNaW5NPj88 | All good science starts with a good literature review, and AI can help with that :) LitLLM, brought to you by the awesome team at ServiceNow AI Research. | 28 | 1 | 2 | 7mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.665Z |  | 2025-04-24T09:54:21.092Z | https://www.linkedin.com/feed/update/urn:li:activity:7320847094917828608/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7317446997530087426 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHUgeQjSPHGzg/feedshare-shrink_800/B4EZYmWkMhHgAg-/0/1744400172379?e=1766620800&v=beta&t=mOp8G9OjnxCfoRZKYnkvp3uzpxVGqgVK5RGpIFXS1Fo | A new open LLM pushing the boundary of performance vs efficiency, from ServiceNow! 💪🏼✨
Congrats to Sathwik Tejaswi Madhusudan and Torsten Scholak for co-leading this effort 🚀 | 24 | 1 | 0 | 7mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.668Z |  | 2025-04-14T07:21:55.802Z | https://www.linkedin.com/feed/update/urn:li:activity:7316544625471598593/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7305342740563656704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH07R5cIboyGA/feedshare-shrink_800/B4EZWBUTrXHcAk-/0/1741631342244?e=1766620800&v=beta&t=7y-rV1dHyKVKm68LnGY-rlIbslcnZiAX2nEIyttBack | Can’t wait to join my colleagues Krishnamurthy Dvijotham and Jason Stanley on stage next week at GTC to talk about AI agent security! | 29 | 0 | 0 | 8mo | Post | Nicolas Chapados | https://www.linkedin.com/in/nicolaschapados | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:11.674Z |  | 2025-03-11T21:43:56.055Z | https://www.linkedin.com/feed/update/urn:li:activity:7304931310899265558/ |  | 

---



---

# Nicolas Chapados
*Chapados Couture Capital*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 9 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Nicolas Chapados - Montreal, Quebec, Canada | Professional Profile | LinkedIn](https://ca.linkedin.com/in/nicolaschapados)
*2025-04-24*
- Category: article

### [Nicolas Chapados - EXP | LinkedIn](https://ca.linkedin.com/in/nicolas-chapados-989358117)
*2025-01-01*
- Category: article

### [Nicolas Chapados, CFA | Chapados Couture Capital](https://www.chapados-couture.com/authors/chapados/)
*2022-01-01*
- Category: article

### [Startupfest | Nicolas Chapados](https://www.startupfest.com/speaker/nicolas-chapados/)
*2022-12-23*
- Category: article

### [Nicolas Chapados](https://portfolioparadigms.com/about-author/)
*2009-01-18*
- Category: article

---

## 🎬 YouTube Videos

- **[Sommet des dirigeants TI : Element AI et Thirdshelf clarifient l&#39;IA](https://www.youtube.com/watch?v=yt2cv3_0Wn8)**
  - Channel: Direction informatique
  - Date: 2017-10-18

- **[FINTalks Canada FULL EXCLUSIVE VIDEO hosted by Thinking Capital &amp; MaRS Discovery District -](https://www.youtube.com/watch?v=II2iZhHS3vo)**
  - Channel: Thinking Capital
  - Date: 2017-07-14

- **[Responsible AI](https://www.youtube.com/watch?v=RYVKT-e1OxA)**
  - Channel: Singapore FinTech Festival
  - Date: 2018-11-27

- **[La Création de Element AI - Startupfest Version Français 2017](https://www.youtube.com/watch?v=-qxAjhr3XkQ)**
  - Channel: Startupfest
  - Date: 2018-01-31

- **[Should AI in Financial Services Be Regulated | SFF 2020](https://www.youtube.com/watch?v=lfg3d3Vf1OU)**
  - Channel: Singapore FinTech Festival
  - Date: 2020-12-11

- **[AI and Healthcare](https://www.youtube.com/watch?v=vKNEEb8AjZs)**
  - Channel: Creative Destruction Lab
  - Date: 2016-11-30

- **[Explainable AI (XAI) - The Practitioners View](https://www.youtube.com/watch?v=1TTOzyhu_lQ)**
  - Channel: SGInnovate
  - Date: 2020-04-17

- **[LLM Agents MOOC | UC Berkeley Fall 2024 | AI Agents for Enterprise Workflows by Nicolas Chapados](https://www.youtube.com/watch?v=-yf-e-9FvOc)**
  - Channel: Berkeley RDI Center on Decentralization & AI
  - Date: 2024-10-22

- **[ApSTAT Technologies Inc.](https://www.youtube.com/watch?v=inHRMmIb9UI)**
  - Channel: Nicolas Chapados
  - Date: 2010-05-31

---

## 🔎 Press & Mentions

- **[Element AI | Scotiabank Digital Banking Lab](https://www.ivey.uwo.ca/scotiabank-digital-banking-lab/canada-fintech/infrastructure-services/element-ai/)**
  - Source: ivey.uwo.ca
  - *Dec 3, 2018 ... Previously: Co-Founder and CSO, Imagia Cybernetics (2015-Present); Co-Founder, Chapados Couture Capital (2013-Present); Consultant, JD...*

- **[Hedge Fund Quants Close In on Designing Ultimate Trader's Brain](https://www.wealthmanagement.com/alternative-investments/hedge-fund-quants-close-in-on-designing-ultimate-trader-s-brain)**
  - Source: wealthmanagement.com
  - *It's about five years away from becoming a mainstream tool at hedge funds, said Nicolas Chapados ... Chapados Couture Capital in Montreal and Element ...*

- **[Machine Learning Veterans Launch 'Element AI' - A Montreal Based ...](https://www.newswire.ca/news-releases/machine-learning-veterans-launch-element-ai---a-montreal-based-artificial-intelligence-startup-factory-598510761.html)**
  - Source: newswire.ca
  - *Oct 25, 2016 ... Nicolas Chapados – holds a PhD in Computer Science from the ... Chapados Couture Capital, a quantitative asset manager. Real Ventures...*

- **[ALL IN | 2024 Speakers – ALL IN Website](https://allinevent.ai/pages/2024-speakers)**
  - Source: allinevent.ai
  - *Nicolas Chapados. VP Research, ServiceNow. More information. VP Research ... Chapados Couture Capital, a quantitative asset manager. He holds the ......*

- **[Les leaders du Deep Learning lancent Element AI, une usine à ...](https://www.decideo.fr/Les-leaders-du-Deep-Learning-lancent-Element-AI-une-usine-a-startup-en-intelligence-artificielle-basee-a-Montreal_a8867.html)**
  - Source: decideo.fr
  - *Oct 26, 2016 ... - Nicolas Chapados - détient un doctorat en sciences informatiques ... Chapados Couture Capital, un gestionnaire d'actifs alternatifs...*

- **[Nicolas Chapados | ServiceNow AI Research](https://www.servicenow.com/research/author/nicolas-chapados.html)**
  - Source: servicenow.com
  - *Nicolas Chapados. VP of Research. AI Research Management. Leadership team. Nicolas ... Chapados Couture Capital, a quantitative asset manager. He hold...*

- **[Nicolas Chapados | Mila](https://mila.quebec/en/directory/nicolas-chapados)**
  - Source: mila.quebec
  - *Nicolas Chapados is VP of research at ServiceNow Inc. He holds an ... Chapados Couture Capital, a quantitative asset manager. Chapados' research ......*

- **[Nicolas Chapados - Machine Learning Conference](http://www.marketforintelligence.com/speakers/nicolas-chapados/)**
  - Source: marketforintelligence.com
  - *Nicolas Chapados. Chief Science Officer, Imagia / Co-Founder, ApSTAT ... Chapados Couture Capital, a Canadian alternative asset manager. He is also .....*

- **[Montréal Exchange - CADC 2016](https://cadc.m-x.ca/2016/index_en.php)**
  - Source: cadc.m-x.ca
  - *Dec 1, 2022 ... In his keynote, Andrew Coyne outlines the new energy and cross ... Nicolas Chapados, Chapados Couture Capital Inc. Denis Paquette ......*

- **[Nicolas Chapados - Co-Founder & CSO @ Element AI - Crunchbase ...](https://www.crunchbase.com/person/nicolas-chapados)**
  - Source: crunchbase.com
  - *Nicolas Chapados holds an engineering degree from McGill University and a PhD ... Chapados Couture Capital, a Quebec-registered quantitative asset man...*

---

*Generated by Founder Scraper*
