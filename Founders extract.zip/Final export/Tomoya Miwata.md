# Tomoya Miwata

## Position actuelle

**Titre** : Founder
**Entreprise** : miwa maroon studio
**Durée dans le rôle** : 5 years 6 months in role
**Durée dans l'entreprise** : 5 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Media

## Description du rôle

- Runs Unreal Engine and TouchDesigner tutorials
- Created audio-reactive procedural grass and 3D fluid sim
- Published GSX Shadow(Gaussian Splatting plugin) and SoftyDMX(LED Bar specialized DMX controller)

## Résumé

Show Reel (https://youtu.be/OvJWhYYbwjE)
miwa maroon tutorial(youtube.com/@miwa_maroon), Portfolio(miwa-maroon.crd.co)

Experienced in developing real-time visual effects and artist-friendly tools across video games, mobile apps, interactive installations, and audio-reactive visuals. Specialties include complex shaders, system design, and optimization. Proficient with Unreal Engine, TouchDesigner, EmberGen, Blender, HLSL, GLSL, C++, and Python.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADt9kt4BRo9FG-9lMsYqNW_4xZaFJoVGpS4/
**Connexions partagées** : 1


---

# Tomoya Miwata

## Position actuelle

**Entreprise** : miwa maroon studio

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Tomoya Miwata

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391488682949767168 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ed8ae8d1-5562-466a-be30-70089ada086b | https://media.licdn.com/dms/image/v2/D5605AQGn94uydcFxBg/videocover-high/B56ZpKvxdNI0BU-/0/1762190630490?e=1765789200&v=beta&t=Q7BhLpBtnRbagWTMHJb1tSAwbFOabVtyzRNDL1W8Ajs | That make the asset creation easy for the artists and I love these types of tools . | 3 | 0 | 0 | 1mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:34.672Z |  | 2025-11-04T14:57:09.234Z | https://www.linkedin.com/feed/update/urn:li:activity:7391163233325256704/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7374511002845089793 | Video (LinkedIn Source) | blob:https://www.linkedin.com/41022f80-1ae2-4888-ac44-2f17542453f9 | https://media.licdn.com/dms/image/v2/D4E05AQHigWajRr0QaA/feedshare-thumbnail_720_1280/B4EZleGjauKUA0-/0/1758220401417?e=1765789200&v=beta&t=aochiqeG1pgu1MXc-j8qjcHPXXuSTPYf13efjU8Ls_I | 🎵Render Perfect Synchronized Audio Visualizer in UE5 | Devlog 2 🎵

Last time I showed Auviz working in real-time. Now it’s time for the Sequencer — so you can create your own music videos directly in Unreal Engine!

- Bake audio bands directly into Sequencer
- Bind to any Blueprint function
- Render a perfectly synchronized audio-visual piece

This is the tool we’ve been waiting for. 

 👉 Download now and give it a try. I’d love to hear your feedback and feature requests!
🎥 Tutorial here: https://lnkd.in/e_fw4iXk

#UnrealEngine #Auviz #AudioReactive #Sequencer #GameDev #RealtimeVFX #CinematicTools | 1 | 0 | 0 | 2mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.594Z |  | 2025-09-18T18:33:54.867Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7370968260311408641 | Video (LinkedIn Source) | blob:https://www.linkedin.com/36fd710b-22c6-4794-bb0a-2d2c64fe60bb | https://media.licdn.com/dms/image/v2/D4E05AQFkFqM9quT5Ig/videocover-low/B4EZkrwifNIQCI-/0/1757375772969?e=1765789200&v=beta&t=8k4-x7oovkxcp271VbQNgSlhO8ix-UvjEEoVdbqsoeY | 🎵Auviz Development – Big Milestone! 🎵

This is huge: each audio band (Low, Mid, High) is now baked directly into the Sequencer when you drop in your audio.

For cinematic workflows, this is exactly what you’ve been waiting for — fully timeline-controlled, audio-driven visuals.

Next step: linking each frequency band to actor functions for even deeper creative control.

Let’s gooo! 🔥

#UnrealEngine #Auviz #AudioReactive #Sequencer #RealtimeVFX #CinematicTools #GameDev | 1 | 0 | 0 | 2mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.595Z |  | 2025-09-08T23:56:19.226Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7370146764924030976 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7a350142-4315-4528-9343-3624ad26fda8 | https://media.licdn.com/dms/image/v2/D4E05AQHdIiCJ5heeMg/videocover-low/B4EZkgFZ9PGcCE-/0/1757179914572?e=1765789200&v=beta&t=ExHx29fgyaj1ixUqxz_B1TlmfJuG4mTpwR2C1tOp5Xg | 🎬 Auviz Development Update – Sequencer Integration 🎵

I’ve started working on Sequencer support for rendering and cinematic workflows in Auviz.
The first big step:
- Added a new Auviz Track Type
- Created ActorsTrack (link any actor you want to be audio-reactive)
- Created FunctionTrack (trigger functions you want to call)

This also means… I finally discovered how to add custom tracks and sections in Unreal’s Sequencer — something I’ve wanted to figure out for a long time!

Super exciting to see Auviz getting closer to full cinematic audio-visual control. 🚀
#UnrealEngine #Auviz #AudioReactive #Sequencer #PluginDevelopment #RealtimeVFX #GameDev | 1 | 0 | 0 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.596Z |  | 2025-09-06T17:31:59.463Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7368479988586659840 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c996abb8-25bb-4ca7-8315-4a55690d4386 | https://media.licdn.com/dms/image/v2/D4E05AQGPsw2oB6ObAg/feedshare-thumbnail_720_1280/B4EZkIZNQeHgA4-/0/1756782450511?e=1765789200&v=beta&t=kvg2QPUOL-jN_x1b2twb6cM1SCKo-SzAV1gBmEBoY3w | 🎵 Unreal Engine + Audio Visual: Here’s What You Can Do! | Devlog #1 🎵

Auviz, a plugin for Unreal Engine made for everyone who loves audio-visual creation. It’s still experimental, but already has:

- Full audio analysis inside Unreal (no TouchDesigner needed for low/mid/high)
- Works without PIE (Play-In-Editor)
- Real-time + rendering support

This is just the beginning — I’d love to hear what features you would like to see in Auviz.

👉 Take a peek at the first devlog here:
https://lnkd.in/endKhf-Q

#UnrealEngine #Auviz #AudioReactive #RealtimeVFX #GameDev #PluginDevelopment 

Special Thanks to Jose Carlos Bringas | 7 | 0 | 1 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.597Z |  | 2025-09-02T03:08:49.017Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7364750254434308096 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c5f82d06-936f-490b-b9c3-140aba0a860c | https://media.licdn.com/dms/image/v2/D4E05AQHOPkP9EH-JIg/videocover-low/B4EZjTZShfHICI-/0/1755893283646?e=1765789200&v=beta&t=5JFu0-Dcy67K8h1aC5ndvf57AtShhTz9noTtxwoG0zo | 🎵 Auviz Development Update – Making the Invisible Visible 🎨

One of the core ideas behind Auviz is that you can see the audio-visual results both with the editor playing and without it — so it works in any situation.

Behind the scenes, the audio pipeline is completely different in those two cases, and I had to implement separate approaches. But the beauty is: the results look the same!

This update may feel subtle, but if you’ve ever built tools yourself, you know how I feel. 😄

Step by step, Auviz is becoming a solid foundation for creating beautiful, audio-reactive visuals in Unreal Engine.

#UnrealEngine #Auviz #AudioReactive #RealtimeVFX #GameDev #tool #PluginDevelopment #TechnicalArt | 3 | 0 | 0 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.598Z |  | 2025-08-22T20:08:11.100Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7363727008083628032 | Video (LinkedIn Source) | blob:https://www.linkedin.com/492b19ee-0dc1-4ddf-9e1a-381fcd74f751 | https://media.licdn.com/dms/image/v2/D4E05AQHp7lpTfmOjrA/feedshare-thumbnail_720_1280/B4EZjE2nE9HoA0-/0/1755649307768?e=1765789200&v=beta&t=LGL8q2g8J1Uqptca8j7vz-2_XV7NtafndqCylqbOWVM | 🎥 Auviz – First Demo in Progress 🎵

I’m excited to share that I’m working on the first demo of Auviz, my Audio Visual Plugin for Unreal Engine.
In this demo, I’m showing step by step how to achieve a cinematic look, and I plan to create a tutorial later to dive into the details.
The next milestone: synchronizing music with visuals in real time.
 Stay tuned — more to come soon!
#UnrealEngine #Auviz #AudioReactive #RealtimeVFX #TechnicalArt #GameDev | 3 | 0 | 0 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.598Z |  | 2025-08-20T00:22:10.159Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7362139108334321664 | Video (LinkedIn Source) | blob:https://www.linkedin.com/afde7b49-a962-4d59-b628-bfeb9c8ea120 | https://media.licdn.com/dms/image/v2/D5605AQEn6o8w7ryViQ/videocover-low/B56ZiuSbZhG4CE-/0/1755270736203?e=1765789200&v=beta&t=x-srQHVIee5mogWnKKk50LtDhJ7YmExJ55qXzAz6sRk | 🎵 Auviz – Evolving Audio Visuals in Unreal Engine 🎨

I’ve just added frequency separation to Auviz — now you can split your audio into low, mid, and high bands and drive parameters in real time. Even better, you can adjust the frequency ranges while it’s running for instant creative control. Thanks for helping Jose Carlos Bringas !

I’m building Auviz to be the go-to plugin for creating beautiful, real-time audio visuals in Unreal Engine — and I’d love your ideas and feature requests.

💡 Let’s shape this tool together and push the boundaries of audio-reactive art!
#UnrealEngine #Auviz #AudioReactive #VFXTools #RealtimeVFX #TechnicalArt | 4 | 1 | 0 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.599Z |  | 2025-08-15T15:12:25.357Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7359655744805187584 | Video (LinkedIn Source) | blob:https://www.linkedin.com/aa61f411-fd04-4205-9ad0-4439dd46183b | https://media.licdn.com/dms/image/v2/D4D05AQHVXDFtf35S4A/videocover-low/B4DZiK_2RrGsCE-/0/1754678660305?e=1765789200&v=beta&t=MSaiLyUpGaISbPTNG6utZTHLJS0UAUb5QnQ2UDeNsy4 | 🎵Introducing Auviz – My New Audio Visual Plugin for Unreal Engine 🎨

I’ve been developing Auviz, a plugin that lets you easily link audio to any actor’s parameters in Unreal Engine — whether your source is a music file (.wav) or a live device input like a microphone or instrument.
 It works without pressing Play in the editor 
— thanks to custom C++ code I built from scratch to make real-time audio visualization possible right in the editor viewport.
My goal is to make it simple for anyone to create beautiful, audio-reactive visuals in Unreal, whether for VFX, live shows, or interactive art.
🚀 Release coming soon — stay tuned!

#UnrealEngine #Auviz #AudioReactive #RealtimeVFX #GameDev #TechnicalArt | 12 | 3 | 0 | 3mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.600Z |  | 2025-08-08T18:44:25.353Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7353431131024678914 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1be7d072-3489-4403-913f-a78da278f649 | https://media.licdn.com/dms/image/v2/D4E05AQEbh0AsRlhhug/feedshare-thumbnail_720_1280/B4EZgyimJzGYA4-/0/1753194588113?e=1765789200&v=beta&t=MbsaW2kky1rBKe9aOZr94IdXyXx92G0SBcEPVTFK5nQ | Gaussian Splatting can’t cast dynamic shadows — until now.

With GSX Shadows, you can mix transparent splats with real-time lighting and 3D assets.
Create more realistic, cinematic scenes and level up your art.
 🎮 Download → http://bit.ly/3IeB1Yt

#UnrealEngine #GSXShadows #GaussianSplatting #RealtimeVFX #GameDev #TechnicalArt #3dart #VFXTools | 7 | 0 | 0 | 4mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.601Z |  | 2025-07-22T14:30:01.780Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7348718226807119873 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d112873d-6337-49bd-afce-77a5dc428876 | https://media.licdn.com/dms/image/v2/D4E05AQG_rCXeMNCQOQ/videocover-low/B4EZfvkPAMGwCE-/0/1752070954274?e=1765789200&v=beta&t=TUoMqKuGPpLdBPLVskZV7lydVDp2vFi9pBAGhQEqhtA | 📢 Excited to announce my first public release on Fab:
GSX Shadows – a custom-built Gaussian Splatting plugin for real-time VFX in Unreal Engine.
✅ Designed for artists: drag & drop your 3D scan
 ✅ Add cinematic lighting with included template effects
 ✅ Built-in support for dynamic shadows
 ✅ No prior splatting experience needed
Whether you're working on stylized visuals, experimental shaders, or cinematic FX, GSX makes splatting artist-friendly and production-ready.
And....... it’s listed next to Luma AI on Fab — truly honored.
🔗 Try it here: https://lnkd.in/e6eG7sY8
 Let me know what you build with it!
#UnrealEngine #VFX #GSXShadows #GaussianSplatting | 4 | 2 | 0 | 4mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.601Z |  | 2025-07-09T14:22:37.853Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7347352494903050240 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c3880e5c-3ec1-4de6-9661-9ba8b49ed0ac | https://media.licdn.com/dms/image/v2/D4E05AQHdRrKRSxUL1w/feedshare-thumbnail_720_1280/B4EZfcKHotHgA0-/0/1751745330572?e=1765789200&v=beta&t=PwmQ0Ca0DDt5ZcqKaBuEXYy80T8U753Qhs3-Zk3k6JA | “𝐇𝐨𝐰 𝐈 𝐁𝐮𝐢𝐥𝐭 𝐄𝐏𝐈𝐂 𝐁𝐏𝐌-𝐒𝐲𝐧𝐜𝐞𝐝 𝐋𝐢𝐠𝐡𝐭𝐢𝐧𝐠 𝐢𝐧 𝐔𝐄 5.6 — 𝐅𝐮𝐥𝐥 𝐒𝐨𝐟𝐭𝐲𝐃𝐌𝐗 𝐖𝐨𝐫𝐤𝐟𝐥𝐨𝐰”
This is a complete start-to-finish guide for creating real-time, BPM-synced lighting effects using my custom DMX system, SoftyDMX, inside Unreal Engine 5.6.
You’ll learn:
 • How to set up DMX Pixel Bars
 • What fixtures are and how to patch them
 • How to sync lighting to music BPM
 • How to use SoftyDMX with UE 5.6
 • Workflow tips for real-time events, live shows, and broadcast setups
🎥 Watch the tutorial: https://lnkd.in/e3hbvEM7
Whether you're a beginner or a lighting artist looking to level up, this guide is packed with everything you need to get started.
#UnrealEngine #TechnicalArt #SoftyDMX #DMXLighting #RealTimeVFX #LiveEventProduction #MusicVideoLighting | 1 | 0 | 1 | 5mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.603Z |  | 2025-07-05T19:55:41.993Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7347307382898585600 | Video (LinkedIn Source) | blob:https://www.linkedin.com/62cf2fa1-b2d9-4e9d-baa4-0f78856b8e19 | https://media.licdn.com/dms/image/v2/D4E05AQFoXwM_HH9ANA/feedshare-thumbnail_720_1280/B4EZfbhFfPHYA0-/0/1751734573909?e=1765789200&v=beta&t=x9lxmmY1Gd1ZXnffVWVQcXHq2ya3q2gBSGVVqucVpls | 🚀 Introducing GSX Shadows – Real-World Scans to Real-Time VFX
 Transform your 3D scans into stunning visual effects directly in Unreal Engine with GSX Shadows, a powerful Gaussian Splatting plugin I’ve developed to make this groundbreaking tech accessible to everyone.
🧠 No prior experience with Gaussian Splatting? No problem.
- Just drop your 3D scan into Unreal.
- No complex setup, no prior experience needed.
- Comes with ready-to-use effects to instantly enhance your scene.
Whether you're into games, VFX, or virtual production — this tool helps you create high-quality visuals, fast.
👉 Download GSX Shadows: http://bit.ly/3IeB1Yt
#UnrealEngine #GSXShadows #GaussianSplatting #RealtimeVFX #GameDev #TechnicalArt #VFXTools | 19 | 0 | 0 | 5mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.604Z |  | 2025-07-05T16:56:26.453Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7332907140556230657 | Video (LinkedIn Source) | blob:https://www.linkedin.com/742f61d5-8cc3-4180-b400-6a6e8a7a7b6e | https://media.licdn.com/dms/image/v2/D4E05AQHiq4SUxhx14g/feedshare-thumbnail_720_1280/B4EZcO3zN8HsAw-/0/1748301199916?e=1765789200&v=beta&t=lpQmDrwWKrjRTXyIh-22qVEB1SRiheATlStc5dSvjT4 | I’ve just released my latest Technical Art Showreel showcasing work built over the past 5+ years in real-time VFX and tools for games and interactive visuals.
Featured projects:
 • Procedural grass with multi-buffer shaders
 • Real-time fluid simulation
 • Flame wing asset
 • GSX Shadows – a custom Gaussian Splatting plugin for VFX
 • DMX LED controller built for responsive light design
Technologies used: Unreal Engine, TouchDesigner, EmberGen, Blender, C++, Python, HLSL, GLSL.
Watch the reel here: https://lnkd.in/eZzBGnc4 
 Open to collaborations and feedback!
#TechnicalArt #RealTimeVFX #GameDev #ShaderDevelopment #GaussianSplatting #UnrealEngine #DMX | 13 | 2 | 0 | 6mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.607Z |  | 2025-05-26T23:15:01.135Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7326659397101785089 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | It’s been a while since I started my role at shylabs as a VJ/Lighting Technologist, but I wanted to share this update with everyone. | 3 | 3 | 0 | 6mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.608Z |  | 2025-05-09T17:28:43.018Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7326657513553092609 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | It’s been a while since I started my role at Digital-Stick as a Technical Artist, but I wanted to share this update with everyone. | 6 | 0 | 0 | 6mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.608Z |  | 2025-05-09T17:21:13.945Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7326654838081994753 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | It’s been a while since I started my role at miwa maroon studio as a Founder, but I wanted to share this update with everyone. | 10 | 6 | 1 | 6mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.608Z |  | 2025-05-09T17:10:36.063Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7285686076902371328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/edb5525c-0db5-4c14-a54b-ad1c0e0e1b2d | https://media.licdn.com/dms/image/v2/D4E05AQFis4qli_tu4Q/videocover-low/B4EZRv00YPHACQ-/0/1737042914416?e=1765789200&v=beta&t=_G5YoklQ84qm-yoaJ_anv1df_LvYO9TNM3JschclMe8 | 🚀 New Tutorial: “GSX Shadows” Plugin for Gaussian Splatting!

This innovative plugin is designed with creators in mind:

 •	Specialized for VFX creation 🖌️
 •	Supports runtime shadows 💡
 •	Optimized workflow for usability 🛠️

🎉 Access it by subscribing to miwa maroon’s Patreon (Each Other tier or higher).

Perfect for developers and artists exploring cutting-edge VFX tools. Save this post for later inspiration!

🔗 https://shorturl.at/v5HH2 🔗 | 60 | 1 | 3 | 10mo | Post | Tomoya Miwata | https://www.linkedin.com/in/miwa-maroon | https://linkedin.com/in/miwa-maroon | 2025-12-08T08:01:39.609Z |  | 2025-01-16T15:55:22.235Z |  |  | 

---



---

# Tomoya Miwata
*miwa maroon studio*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [On Simple Logo Detection with TouchDesigner using OpenCV](https://miwa-maroon.medium.com/on-simple-logo-detection-with-touchdesigner-using-opencv-e4830d73bb91)
*2022-02-11*
- Category: blog

### [After looking around for a “mini projector” with good value for the cost](https://miwa-maroon.medium.com/after-looking-around-for-a-mini-projector-with-good-value-for-the-cost-9e1d9b43b0d4)
*2022-05-08*
- Category: blog

### [miwa tomoya](https://anime-sharing.com/tags/miwa-tomoya)
*2013-04-30*
- Category: article

### [miwa look.1 - Onitsuka Tiger MAGAZINE](https://www.onitsukatiger.com/jp/magazine/interview/miwa-look-1/?lang=en)
*2019-07-16*
- Category: article

### [MIWA – Packaging Of The World](https://packagingoftheworld.com/2024/12/miwa.html)
*2024-12-10*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
