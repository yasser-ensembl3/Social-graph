# Philip Taylor

## Position actuelle

**Titre** : Founder and CEO
**Entreprise** : Zea
**Durée dans le rôle** : 1 year 1 month in role
**Durée dans l'entreprise** : 8 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Web technology is rapidly evolving and Zea offers a new way for Design, Manufacturing, and AEC companies to transform their businesses. Zea delivers real-time collaboration, browser-based access across devices, cloud storage and compute, and a powerful rendering engine designed for large CAD and BIM data sets. Zea is ready to solve specialized problems and create custom solutions for your business too.
 
VR visualization and collaboration are easy with Zea. Transport into a space, immerse the team in a virtual environment, touch and manipulate objects, make changes in real time. Feel presence, a true spatial awareness and sense of scale embodied in all your projects.
 
Want to learn more? Reach out for a live demo.

https://www.zea.live
_____________________________________________________________________
Philip Taylor | ☎ +1 514 582 4325 | ✉ phil@zea.live | www.zea.live

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAHAjOABGnz55Wosnc98VtNFuIqaITK4H2o/
**Connexions partagées** : 13


---

# Philip Taylor

## Position actuelle

**Entreprise** : Zea

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Philip Taylor

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396645659094757376 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f4d42294-d138-4b2c-aec7-e12ffc50f690 | https://media.licdn.com/dms/image/v2/D4E05AQGXOJaS8rK54A/videocover-low/B4EZqYpD9hIoBQ-/0/1763497499927?e=1765782000&v=beta&t=1PJTHL1yqw3hzcNPesJQGUIcQH_6k6rxsMpwmHqyAvA | Big things are coming at Zea... | 14 | 0 | 1 | 2w | Post | Philip Taylor | https://www.linkedin.com/in/philip-taylor-828a179 | https://linkedin.com/in/philip-taylor-828a179 | 2025-12-08T06:03:44.903Z |  | 2025-11-18T20:29:08.159Z | https://www.linkedin.com/feed/update/urn:li:activity:7396644699576610816/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7375882429296951297 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFW3JvaEu2wvQ/feedshare-shrink_800/B4EZlxlh3LGcAg-/0/1758547287987?e=1766620800&v=beta&t=Ol7KRYZrRtS6JqqmUH0775tXSnDl6UZ3JTEHiFcmics | Damn I love this companies vehicles. A great team to work with as well.. | 6 | 0 | 0 | 2mo | Post | Philip Taylor | https://www.linkedin.com/in/philip-taylor-828a179 | https://linkedin.com/in/philip-taylor-828a179 | 2025-12-08T06:03:44.906Z |  | 2025-09-22T13:23:28.413Z | https://www.linkedin.com/feed/update/urn:li:activity:7375881933660241920/ |  | 

---



---

# Philip Taylor
*Zea*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Couple from the soap opera Passions will be working together again](https://www.dailymail.co.uk/tvshowbiz/article-14084123/Chicago-Med-cast-Natalie-Zea-real-life-husband.html)
*2024-11-21*
- Category: article

### [Street youth worker Philip Faresa: A new kind of role model](https://zeal.nz/blog/a-new-kind-of-role-model/)
*2017-05-31*
- Category: blog

### [- YouTube](https://www.youtube.com/watch?v=CizE7tjDcvc)
*2025-04-25*
- Category: video

### [SBA 445: The Evolution of Smart Buildings Academy with Phil Zito](https://podcast.smartbuildingsacademy.com/445)
*2023-12-11*
- Category: podcast

### [Interview with Zero Support Managing Partner Phil Young  by Financial Adviser Lives Podcast](https://creators.spotify.com/pod/profile/philip-calvert/episodes/Interview-with-Zero-Support-Managing-Partner-Phil-Young-e1b82bg)
*2024-11-12*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Full text of "Heads of families at the first census of the United States ...](https://archive.org/stream/headsoffamiliesa00nort/headsoffamiliesa00nort_djvu.txt)**
  - Source: archive.org
  - *... Philip Taylor, John Thompson. John Taylor, James, jum Taylor, James Thomas ... Windle, Phillip Yost, Jacob Zea, Phillip Feltner, Adam Fultz, Josep...*

- **[UMGC Winter 2024 Virtual Commencement Digital Program by ...](https://issuu.com/umucachiever/docs/24-comm-052_winter_2024_virtual_commencement_digit)**
  - Source: issuu.com
  - *Dec 4, 2024 ... Philip Taylor Reynolds II. Quincy Reynolds. Rebecca Reynolds. La'Darion ... Zea Garrido g. Manuel L. Zegarra l. Evelyn Zelaya. Mallory...*

- **[Honor Rolls for Bethlehem Area School District | The Valley Ledger ...](https://www.thevalleyledger.com/?p=84501)**
  - Source: thevalleyledger.com
  - *Dec 8, 2018 ... Zea Roman, Melanie Alexandra Zetino. Grade 7: Wisam Al Ezzi, Jomar W ... Philip Taylor Hunsinger, Khadeeja Hussain, John Jabbour ......*

- **[The University of Virginia Record](https://xtf.lib.virginia.edu/xtf/view?docId=2005_Q2_3/uvaBook/tei/z000000337.xml;query=;brand=default)**
  - Source: xtf.lib.virginia.edu
  - *Zea, Paul Howard, Jr. 1 Brooklyn, N. Y. Special Students Angell, Marian ... Philip Taylor c Moore, Pierre Albert c Moore, Robert Dandridge p 106 Moore...*

- **[Honor Rolls for Bethlehem Area School District – 2022 School Year ...](https://www.thevalleyledger.com/?p=111753)**
  - Source: thevalleyledger.com
  - *Apr 11, 2022 ... ... Philip Taylor Hunsinger, Khadeeja Hussain, Abieyuwa Grace Idehen ... Zea Roman, Stephanie Y Zheng, Winnie Zheng, Nicholas Michael...*

- **[Full text of "A history of the city of Dublin"](https://archive.org/stream/historyofcityofd02cilbuoft/historyofcityofd02cilbuoft_djvu.txt)**
  - Source: archive.org
  - *... zea- lous friend. He married the widow of a Mr. Lister, a man of fortune ... Philip Taylor, 1777; Rev. Jo- seph Hutton, 1788. The permanent funds ...*

- **[Full text of "Commencement"](https://archive.org/stream/commencement2016univ_1/commencement2016univ_1_djvu.txt)**
  - Source: archive.org
  - *... Zea Qiaozhi Zhang Scott Zhang* Jingyi Zhao* Deanna Zhong Jerome John Zinn ... Cannon Christopher David Caruso Fang Chen Hailin Chen Ryan Chin Phil...*

- **[Untitled](https://terauora.com/wp-content/uploads/2022/06/Ta%CC%84-Ta%CC%84tou-Mahere-Korowai-Guidelines.pdf)**
  - Source: terauora.com
  - *Mokomoko, Philip Taylor, Rahera Biddle, Richard Wallace, Shanara Wihongi ... Zea- land. Health services have an important role and rangatahi know what...*

- **[WebGL Meetup March 2021](https://www.khronos.org/events/webgl-meetup-2021)**
  - Source: khronos.org
  - *Philip Taylor, Founder, Zea. Ivan Popelyshev, Programmer, CrazyPanda. Register Today! Conference Code of Conduct: The Khronos ......*

- **[Covert and Overt Propaganda](https://thestacks.libaac.de/bitstreams/448350c9-fb23-455c-9b76-1c6b7fdfa51a/download)**
  - Source: thestacks.libaac.de
  - *Philip Taylor has traced the history of propaganda back to the ancient world ... 6 Canadians, Australians, South Africans, and New Zea landers became ...*

---

*Generated by Founder Scraper*
