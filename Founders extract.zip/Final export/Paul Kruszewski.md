# Paul Kruszewski

## Position actuelle

**Titre** : Founder/CEO
**Entreprise** : qarl AI
**Durée dans le rôle** : 1 year 5 months in role
**Durée dans l'entreprise** : 1 year 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Building the future of human-AI interactivity.

## Résumé

I  build high performance super nerd teams who in turn build the future of AI.*3RD PERSON BIO*Dr. Paul A. Kruszewski is a deep tech inventor and entrepreneur.   His passion is the application of AI to visual and interactive computing.  Over the last 25+ years, his ground-breaking, award-winning AI products have been used to create numerous broadcasts, films, video games, toys, robots, amusement park rides and health &amp; fitness applications.   As Founder/CEO, he is a serial entrepreneur with 3 successful exits of frontier AI start ups,  he specializes in developing and selling V1.0 AI Infrastructure for Enterprise.  Customers have included Disney, Electronic Arts, Intel, Lockheed Martin, L3, Nikon, NVIDIA &amp; Sony.  His 4th start-up QARL is developing the ultimate human AI interface.  ******************Helping to build the Metaverse one byte at a time since 1980 and with a focus on generative AI for 3D content creation since 1992.45+ years of hacking at the intersection of AI/3DI lead teams who build tech that blows minds.I assemble and lead teams of smart/driven/good people to build scalable businesses that rely on solving deep AI / visual computing / real-time problems.Proven track record of anticipating technological trends and building world class start ups to deliver award-winning innovative AI / visual computing technology.Top 5 Character Strengths*Industry, diligence, and perseverance. *Creativity, ingenuity, and originality.*Zest, enthusiasm, and energy.*Curiosity and interest in the world.*Love of learning.Specialties: artificial Intelligence, augmented reality, business development, computer graphics, computer vision, crowd simulation, deep learning, deep tech, game middleware and technology, metaverse, military simulation and training, motion capture, software development,  start-ups, venture capital, video games, visual computing, visual effects Influences:  Devroye, Dyson, Edison, Jobs, Kurzweil, Mozart, Musk, Patton, Prusinkiewicz, Rush, Turing Favourite Video Games (more or less in chronological order):  Battlezone, Lunar Lander, Gear of War Trilogy, BioShock, Uncharted, The Last of Us Parts 1 & 2 Erdős number = 3 Alignment = Chaotic good

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACgzCABW2cWdN-dLw04uvyY2JoXEFQzUZw/
**Connexions partagées** : 306


---

# Paul Kruszewski

## Position actuelle

**Entreprise** : QARL AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Paul Kruszewski

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401990334794211328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEDupuTZNTpg/feedshare-shrink_800/B4EZrkm93DHcAk-/0/1764772016548?e=1766620800&v=beta&t=jj2zSiDi2VSPy3Pck4uohebtiwvK7LaEa5H91ykP0eU | #iitsec was transformative for my first AI company AI.implant back in the early 2000s
Excited to explore new expertiential learning opportunities for QARL AI
#dualuse | 51 | 3 | 0 | 4d | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:35.187Z |  | 2025-12-03T14:26:58.145Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394793654390849536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXd-yAsL5cIA/feedshare-shrink_800/B4EZp.Vn8tIwAg-/0/1763056194412?e=1766620800&v=beta&t=czWwtPBc_2MV1juU3kosVCSlnmAmMSWztQutc_4NJbg | Excited for my first #devlearn | 41 | 2 | 0 | 3w | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:35.187Z |  | 2025-11-13T17:49:55.829Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393982512617758720 | Text |  |  | As I pack up for our first day at the first permanent office at QARL AI, I am unexpectedly excited like an elementary student on the first day of school.  Thank you Danielle King for setting up the new HQ 👻! | 89 | 10 | 0 | 3w | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:35.188Z |  | 2025-11-11T12:06:44.560Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7368293950152929281 | Article |  |  | I just finished Jakob Kerr novel https://lnkd.in/eEqWtXrP
As a fan of hard boiled noir and a survivor of almost 30 years in tech, I highly recommend it. | 18 | 4 | 0 | 3mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:35.188Z |  | 2025-09-01T14:49:33.998Z | https://www.penguinrandomhouse.com/books/746269/dead-money-by-jakob-kerr/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7341898528023101442 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGGqVjnIvQVAw/feedshare-shrink_800/B4EZeOpyZTHsAg-/0/1750445010208?e=1766620800&v=beta&t=mhVQ78BkZ1bONERjWOdThzjvwWbiG9fH6GmDcIQBinU | It was great to reconnect with old friends at the wrByeBye party last night!  Shout out to Danielle King who did a stellar job of organizing everything! | 79 | 9 | 0 | 5mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:35.189Z |  | 2025-06-20T18:43:34.959Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7308564399768698880 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVMVk_bs24CQ/feedshare-shrink_800/B4EZW05StZGwAo-/0/1742496676623?e=1766620800&v=beta&t=eX4AdkQifekz1O8HS5aTLGXK7FK6enagtdTfe5ZYshc | Super nerd week continues at #gdc2025 | 44 | 6 | 0 | 8mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.829Z |  | 2025-03-20T19:05:39.465Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7307541289464397824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEp4xaRX7zC8w/feedshare-shrink_800/B4EZWmaD9oGwAg-/0/1742253608647?e=1766620800&v=beta&t=CcdW8dWpXz49itEgdavlKFu1Vdl0TRYqTM2DAhvbVbA | Locked and loaded for a great #gtc25 | 81 | 2 | 0 | 8mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.829Z |  | 2025-03-17T23:20:10.960Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7307343028598296577 | Text |  |  | Flying off to #SFO for the best nerd week of the year #GTC2025 #GDC2025
#QARLWorldTour2025
Looking forward to reconnecting with old friends and making new ones.  So much cool tech / so little time! | 20 | 2 | 0 | 8mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.830Z |  | 2025-03-17T10:12:21.886Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7298393181388193793 | Article |  |  | Montrealers want to know if it can shovel snow! | 17 | 0 | 0 | 9mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.830Z |  | 2025-02-20T17:28:52.031Z | https://techcrunch.com/2025/02/20/figures-humanoid-robot-takes-voice-orders-to-help-around-the-house/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7296939037309784064 | Text |  |  | Just finished playing "The Last of Us Part II."  As a technologist who has helped to pioneer the development of navigation meshes, behaviour trees, and ambient NPCs, the game AI blew my mind!  As a gamer, I was often torn between wanting the game to end ASAP and never wanting it to end.  This is the first time in my 50 years of playing video games that a game made me feel sad.  What a masterpiece! | 30 | 7 | 0 | 9mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.830Z |  | 2025-02-16T17:10:37.066Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7289671081458585600 | Text |  |  | What are the cool kids doing for a format for a V1.0 product deck?
Any examples that you could recommend.
N.B.  AGENCIES DO NOT CONTACT ME.  I am asking for help only from people and I know and trust. | 7 | 6 | 0 | 10mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.831Z |  | 2025-01-27T15:50:21.359Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7287587102542708737 | Text |  |  | Awesome opportunity for an amazing scientist to help make a big breakthrough in AI at SCALE!  Plus the team is nice! | 20 | 0 | 1 | 10mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.831Z |  | 2025-01-21T21:49:22.067Z | https://www.linkedin.com/feed/update/urn:li:activity:7287583907972014080/ | https://www.linkedin.com/jobs/view/4100293908/ | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7285004822917857281 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH85YLFrz0l1g/feedshare-shrink_800/B4EZRmJRZuHAAo-/0/1736880498064?e=1766620800&v=beta&t=ahglv6Z09dmDZNrcDTae0viP_eSmT13ZKZ6FKZIInLI | Weekly QARL AI in person working lunch #SecretNerdCave #TheRoad2GTC2025 | 58 | 4 | 0 | 10mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.832Z |  | 2025-01-14T18:48:18.628Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7281776095933206529 | Text |  |  | So I just finished playing #TheLastOfUsPartI on the #playstation5.  I am not sure if it is because I am father of two daughters and/or an Alberta farm boy (where the corresponding excellent TV series was made) but this game seemed like the best video game of the last decade or more?  Probably the most engrossing / emotional experience I have had with a video game to date | 30 | 6 | 0 | 11mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.832Z |  | 2025-01-05T20:58:30.128Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7274679812760256512 | Text |  |  | Calling all #MTLSuperNerds!   Come help us build the next generation of #digitalhumans | 20 | 0 | 1 | 11mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.833Z |  | 2024-12-17T07:00:24.377Z | https://www.linkedin.com/feed/update/urn:li:activity:7274484694857965569/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7273647399871434752 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGcyVJiqntA0g/feedshare-shrink_800/B4EZPEvo_vH0Ag-/0/1734172670516?e=1766620800&v=beta&t=vfldz0f_Lfbw8AD17vJX2CbJDxcRk0TB23lDRiNv1-0 | If you are ever in Paris and want to go off piste on the museum front, I highly recommend the Musée des Arts et Métiers!  It was one of the best afternoons in Paris I have ever had.  Check out the Cray-2!  The glass box I am standing behind actually had water flowing through it as part of the liquid cooling.  I love how art and tech can come together like this.  Sadly Melanie Dirks won't let me have one in the house! | 64 | 5 | 0 | 11mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.833Z |  | 2024-12-14T10:37:57.963Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7273639020855803905 | Text |  |  | I am delighted to announce that Thomas Jan Mahamad has joined QARL AI as our Founding Developer.  I have had the pleasure of hacking great stuff with him at both wrnch and Hinge Health and look forward to building even cooler things with him at QARL AI 👻 | 59 | 3 | 0 | 11mo | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.833Z |  | 2024-12-14T10:04:40.250Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7270446246383783937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGCSjWKuXAMyA/feedshare-shrink_800/feedshare-shrink_800/0/1733409461757?e=1766620800&v=beta&t=nNEzc7BS-mFtChmFdZGEYJGaPwXk754DnWbcgCpxsWs | First annual QARL AI Holiday Dinner! | 87 | 4 | 0 | 1yr | Post | Paul Kruszewski | https://www.linkedin.com/in/paulkruszewski | https://linkedin.com/in/paulkruszewski | 2025-12-08T05:22:38.834Z |  | 2024-12-05T14:37:43.497Z |  |  | 

---



---

# Paul Kruszewski
*QARL AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [QARL](https://www.qarl.ai/)
*2025-01-01*
- Category: article

### [Introducing QARL: A Generative AI Tool to Remove the Risk from your LLM Applications | Bitstrapped Blog](https://www.bitstrapped.com/blog/introducing-qarl-a-generative-ai-tool)
*2024-04-28*
- Category: blog

### [Digitizing the real world with Paul Kruszewski, CEO & Founder @ Wrnch | Business growth consultant and strategic management firm | PNR](https://thepnr.com/what-we%E2%80%99re-learning/digitizing-the-real-world-with-paul-kruszewski-ceo-founder-wrnch/)
*2020-08-21*
- Category: article

### [10 questions for a founder : wrnch.ai](https://kaptur.co/10-questions-for-a-founder-wrnch-ai/)
*2020-10-06*
- Category: article

### [Paul Kruszewski - Facebook, LinkedIn, Twitter](https://clay.earth/profile/paul-kruszewski)
*2024-07-29*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Paul Kruszewski - Creative Destruction Lab](https://creativedestructionlab.com/mentors/paul-kruszewski/)**
  - Source: creativedestructionlab.com
  - *Blog · Community · EN · FR · Apply. Role: Associate. Sites: CDL-Montreal, CDL-Paris. Stream: Artificial Intelligence. Paul Kruszewski. Founder/CEO, QA...*

---

*Generated by Founder Scraper*
