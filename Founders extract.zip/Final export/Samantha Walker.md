# Samantha Walker

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Mia
**Durée dans le rôle** : 4 years 11 months in role
**Durée dans l'entreprise** : 4 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

We help companies automate manual workflows using genAI, saving them time and money. 

Techstars Montreal AI 2021
NextAI 2022
CDL Montréal AI 2022-2023

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABFmZ30B1dgNyMjsxPlC-iqQyFYKSAcprnw/
**Connexions partagées** : 79


---

# Samantha Walker

## Position actuelle

**Entreprise** : Mia

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Samantha Walker
*Mia*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 26 |

---

## 📚 Articles & Blog Posts

### [Meet Samantha Walker](https://voyageohio.com/interview/meet-samantha-walker-of-cleveland-shaker-heights/)
*2023-02-09*
- Category: article

### [How Samantha Plavins Started Walking the Walk](https://www.dreamersdoers.com/leading-visibly-how-samantha-plavins-started-walking-the-walk)
*2025-07-08*
- Category: article

### [Mia’s Thoughts and Reflections – SMAUK](https://smauk.org.uk/connect-with-the-community/community-voices/teenage-voices/reflections-experiences/mias-thoughts-and-reflections/)
*2023-06-01*
- Category: article

### [Horses in the Morning Archives - Horse Radio Network](https://www.horseradionetwork.com/category/horses-in-the-morning/)
*2025-09-01*
- Category: article

### [Sauce presents Collective Harmony – In Partnership with Mi Piaci — Sauce](https://www.saucemag.co.nz/interviews/mi-piaci-collective-harmony)
*2023-09-24*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Women's VIVAIA Shoes | Nordstrom](https://www.nordstrom.com/browse/women/shoes?filterByBrand=vivaia)**
  - Source: nordstrom.com
  - *MIA · MIA Limited Edition · Minnetonka · Miu Miu · Miz Mooz · Moncler · Moon Boot® · MUCK ... VIVAIA Water-Repellent Square-Toe Loafers (Samantha Walk...*

- **[Solving the mystery of why colds cause asthma attacks](https://www.medicalnewstoday.com/articles/283337)**
  - Source: medicalnewstoday.com
  - *Oct 2, 2014 ... Samantha Walker, director of research and policy at Asthma UK, says ... Medically reviewed by Mia Armstrong, MD · Asthma management .....*

- **[Honours Cohorts - Science](https://www.monash.edu/science/schools/biological-sciences/honours/honours-cohorts)**
  - Source: monash.edu
  - *Samantha Walker Sarah Adams Shaun Dabare Stefan Prodic Thomas Freire. 2022 ... Jonathan Levins; Joshua Johnstone; Lauren Kirn; Madison Rauber; Mel Ber...*

- **[Sin Reaper 3D (2012) - IMDb](https://www.imdb.com/title/tt2188885/)**
  - Source: imdb.com
  - *Samantha Walker · Lance Henriksen · Dr. Douglas Hoffman · Hazuki Kato · Jenny Kaylin · Patrick J. Thomas · Sasha Jones....*

- **[Your Complete List Of The Dancers For THON 2020 | Onward State](https://onwardstate.com/2020/02/08/your-complete-list-of-the-dancers-for-thon-2020/)**
  - Source: onwardstate.com
  - *Feb 8, 2020 ... Samantha Walker. 12c, Connor Guilfoil. 13a, Alexander Roker. 13b, Erin ... Mia Lancellotti. 207a, Madison Emanski. 207b, Nina Macelko....*

- **[A Place to Call Home (TV Series 2013–2018) - Full cast & crew - IMDb](https://www.imdb.com/title/tt2258904/fullcredits/)**
  - Source: imdb.com
  - *Mia Lethbridge · Clinic Nurse. /Zelda Banks. 3 episodes • 2015–2018. Tony Girdler ... Samantha Walker. key costumer / costume standby assistant / stan...*

- **[Indestructible: No Place to Hide (2020) - IMDb](https://www.imdb.com/title/tt8907348/)**
  - Source: imdb.com
  - *Mia Farrow in Rosemary's Baby (1968). Horror. Storyline. Edit. After transforming Stephanie and Rachel into indestructible beings just like himself an...*

- **[THE CREATIVE DESTRUCTION LAB (CDL)- IS A UNIQUE ...](https://innovationsoftheworld.com/the-creative-destruction-lab-cdl-is-a-unique-program-for-massively-scalable-science-based-technology-startups/)**
  - Source: innovationsoftheworld.com
  - *• August/September: interviews and selection ... Mentors Nicolas Chapados and Jean-François Connolly meet with Samantha Walker, CEO of mia in SGMs (Sm...*

- **[Efficacy and Safety of the mRNA-1273 SARS-CoV-2 Vaccine](https://pubmed.ncbi.nlm.nih.gov/33378609/)**
  - Source: pubmed.ncbi.nlm.nih.gov
  - *Feb 4, 2021 ... ... Samantha Walker, Neha Rampally, Madhu Balachandran, David Parenti ... Mia Crowley, Monique Williams, Katherine Fee, Elizabeth DeJe...*

- **[FCCLA State Winners List 2022](https://www.schools.utah.gov/cte/_cte/ctso/WinnersFCCLAState.pdf)**
  - Source: schools.utah.gov
  - *Mia Dallof. Kearns. Silver. Baking and Pastry. Career Investigation. 1. 1st ... Samantha Walker. Salem Hills. Gold. Interior Design. 2. 2nd. Caroline ...*

---

*Generated by Founder Scraper*
