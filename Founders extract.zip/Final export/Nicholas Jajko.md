# Nicholas Jajko

## Position actuelle

**Titre** : Co-Founder PBNJ Productions Inc.
**Entreprise** : PBNJ productions Inc.
**Durée dans le rôle** : 11 years 9 months in role
**Durée dans l'entreprise** : 11 years 9 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Media Production

## Description du rôle

As Co-founder of PBNJ, I am in charge of meeting and building meaningful relationships with potential clients. I overlook the hiring process for subcontractors for all projects.

My other duties include but are not limited to:

-Director
-Videographer
-Photographer
-Editor

I ensure that communication with clients is quick and clear as well as provide customer service to past and present clients. My position also consists of administrative work such as filing and invoicing.

## Résumé

Mon parcours de plus de dix ans témoigne de mon adaptabilité et de ma compréhension des différents secteurs, garantissant que votre contenu visuel s’harmonise parfaitement avec les besoins de votre industrie.

My decade-long journey is a testament to my adaptability and understanding of various sectors, ensuring your visual content aligns seamlessly with your industry's needs.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAjrKf0BCpDtzDLJonohAa9dcLPLGk9ofVo/
**Connexions partagées** : 5


---

# Nicholas Jajko

## Position actuelle

**Entreprise** : PBNJ productions Inc.

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Nicholas Jajko

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391230126975471616 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG61xzrVJEHgw/feedshare-shrink_800/B4EZpLsnI5HoAg-/0/1762206581288?e=1766620800&v=beta&t=FS-nOp24-bFx6KrRsckKy1nXbZWv7ktrdkDqQ3n183s | 500 000 pieds carrés de travail et de précision.
Chaque colonne, chaque détail peint et livré avec un souci du résultat impeccable.
Nous avons eu le privilège de capturer le avant et après de ce projet énorme, témoin du savoir-faire et de la minutie de l’équipe.
Bravo à l'équipe de CONIQ inc pour avoir transformé l’acier et le béton en un espace aussi net que spectaculaire.
Fiers d’avoir été derrière la caméra pour immortaliser cette évolution.
📸 PBNJ productions Inc.

#construction #photographie #chantier #architecture #avantetaprès #entrepreneurgénéral #équipe #montréal #coniq

500,000 square feet of hard work and precision.
Every column, every detail — painted and delivered with an impeccable level of care.
We had the privilege of capturing the before and after of this massive project, a true testament to the craftsmanship and attention to detail of the team on site.
Kudos to the team at CONIQ inc for transforming steel and concrete into a space that’s as clean as it is impressive.
Proud to have been behind the camera to capture this transformation.
📸 PBNJ productions Inc.

#construction #photography #sitework #architecture #beforeandafter #generalcontractor #teamwork #montreal #coniq | 11 | 0 | 0 | 1mo | Post | Nicholas Jajko | https://www.linkedin.com/in/nicholas-jajko-13913b42 | https://linkedin.com/in/nicholas-jajko-13913b42 | 2025-12-08T08:00:27.416Z |  | 2025-11-03T21:49:44.686Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7337998203419586562 | Video (LinkedIn Source) | blob:https://www.linkedin.com/81221376-3888-4d70-80e8-14b3c650c667 | https://media.licdn.com/dms/image/v2/D4E05AQE_8lufFmBjNg/videocover-low/B4EZdPSMCCHYBg-/0/1749381927059?e=1765789200&v=beta&t=0-aMVlpHQwOw0JveMVOdu7NuK_kWjJOXPyJwZDm-Urg | What an amazing opportunity we had, to travel to Punta Cana to capture the essence of this Wellness retreat. 

Good vibes all around! | 7 | 1 | 0 | 5mo | Post | Nicholas Jajko | https://www.linkedin.com/in/nicholas-jajko-13913b42 | https://linkedin.com/in/nicholas-jajko-13913b42 | 2025-12-08T08:00:27.416Z |  | 2025-06-10T00:25:05.109Z | https://www.linkedin.com/feed/update/urn:li:activity:7337439682282106880/ |  | 

---



---

# Nicholas Jajko
*PBNJ productions Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Nicholas Jajko | Kennedys | Firm Prospects](https://engage.firmprospects.com/public/attorneys/Vm2YyKqO/kennedys/nicholas-jajko)
*2025-12-06*
- Category: article

### [PBNJ productions Inc. Technology Stack | PBNJ productions Inc. Technology Profile](https://rocketreach.co/pbnj-productions-inc-technology-stack_b7c51ecdc18d8b1e)
*2025-01-01*
- Category: article

### [PBNJ Productions](https://www.weddingwire.ca/wedding-videography/pbnj-productions--e9223)
*2020-02-16*
- Category: article

### [Collect and share your podcast reviews, automatically.](https://blog.podrover.com/posts/meet-Brett-Gajda-and-Nick-Jaworski.html)
*2017-09-28*
- Category: blog

### [GitHub - pbnj/awesome-podcasts: 🎙 A collection of awesome engineering podcasts! ARCHIVED in favor of https://github.com/rShetty/awesome-podcasts](https://github.com/pbnj/awesome-podcasts)
*2016-11-12*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
