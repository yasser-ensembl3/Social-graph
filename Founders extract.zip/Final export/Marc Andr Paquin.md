# Marc-André Paquin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402800446408589314 | Article |  |  | Ravi d'avoir participé à mon tout premier podcast ! 

Merci à Bruno Guglielminetti pour l'invitation et l'occasion de parler de Plume IA ! | 10 | 0 | 1 | 2d | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:46.701Z |  | 2025-12-05T20:06:03.805Z | https://baladoquebec.ca/mon-carnet-le-podcast/mon-carnet-du-5-decembre-2025-edition-aws-reinvent-de-las-vegas |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402068212990844928 | Article |  |  | C'était un plaisir de discuter avec Alain McKenna de La Presse cette semaine ! | 6 | 0 | 0 | 4d | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:46.702Z |  | 2025-12-03T19:36:25.754Z | https://www.lapresse.ca/affaires/techno/2025-12-03/ia-en-sante/prendre-des-notes-a-la-place-des-medecins-ca-marche.php?sharing=true |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400255309396733952 | Text |  |  | Plume IA heading to AWS re:Invent !
I'll be in Las Vegas with Alexandre Picotte next week for one of the world's largest cloud computing events.
Beyond attending sessions and exploring the latest tech innovations, I'm thrilled to be participating in a panel on AI and doing several interviews with journalists to share about our journey at Plume IA
If you're attending re:Invent, let's connect! Would love to discuss over coffee.
#reInvent2025 #PlumeIA #HealthTech | 38 | 3 | 0 | 1w | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:46.703Z |  | 2025-11-28T19:32:35.855Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7371957332789989376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEv6Rfd3PAAMA/feedshare-shrink_800/B4EZk50IRAHEAg-/0/1757611591355?e=1766620800&v=beta&t=l9nPevqCogDhRySG-TUKIXSgz9rncVNLJO7Q2vrnaF8 | Super conférence SaaSpasse hier ! Présentations inspirantes, belles rencontres avec entre autres Le Chiffre, Unicorne et Rum&Code !  Merci aux organisateurs pour cet événement de qualité !

Prochain stop pour moi : ALL IN 🚀 | 38 | 2 | 1 | 2mo | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:48.951Z |  | 2025-09-11T17:26:32.481Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7370942320613019648 | Text |  |  | Notre équipe grandit ! 🚀 
Nous cherchons un développeur backend (intérmédiaire/sénior) pour transformer avec nous la pratique médicale au Québec ! 

Postulez ici : 
https://lnkd.in/e9mJx8fR | 27 | 0 | 2 | 2mo | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:48.952Z |  | 2025-09-08T22:13:14.720Z |  | https://www.linkedin.com/jobs/view/4297668436/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7346630614139240448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEN9R4xjFKszw/feedshare-shrink_800/B4EZfR0ZgyHwAg-/0/1751571869318?e=1766620800&v=beta&t=MlnxSTLyYTt6ZU_SMCFMu5UQ3SjmBnyEgrnco35kNeI | Je suis ravi de partager que nous avons officiellement obtenu la certification TGV de Santé Québec !

Pour ceux qui ne connaissent pas, la certification TGV de Santé Québec évalue plus de 250 critères rigoureux couvrant la sécurité, la gouvernance des données, la protection de la vie privée et la qualité de service, en plus d'inclure un test de pénétration complet. C'est un gage de qualité et de fiabilité reconnu dans l'écosystème de la santé numérique québécoise.

Cette certification témoigne de notre engagement envers l'excellence technologique et la conformité aux plus hauts standards de qualité dans le secteur de la santé au Québec.

Un grand merci à toute l'équipe qui a rendu cette réalisation possible. Cette étape importante nous permet de continuer à innover et à offrir des solutions de confiance pour le domaine de la santé.

#PlumeIA #CertificationTGV #SantéQuébec #InnovationSanté #TechnologieMédicale #IA | 19 | 1 | 0 | 5mo | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:48.952Z |  | 2025-07-03T20:07:12.207Z | https://www.linkedin.com/feed/update/urn:li:activity:7346624904127037440/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7274442546238353409 | Text |  |  | Je suis heureux d'annoncer que je rejoins Plume IA en tant que Co-Fondateur et Directeur de la Technologie.

Cette nouvelle étape représente une opportunité unique de contribuer à l'amélioration du système de santé québécois. Notre technologie de scribe IA vise à réduire significativement la charge administrative des professionnels de la santé, leur permettant ainsi de se concentrer sur l'essentiel : les soins aux patients.

Je me réjouis de collaborer avec une équipe talentueuse pour bâtir des solutions qui auront un impact tangible sur notre système de santé. Jasmin Landry, James Tu, MD CCFP (EM)

Suivez Plume IA pour rester informés de nos développements ! | 64 | 10 | 1 | 11mo | Post | Marc-André Paquin | https://www.linkedin.com/in/mapaquin1 | https://linkedin.com/in/mapaquin1 | 2025-12-08T07:02:51.072Z |  | 2024-12-16T15:17:35.630Z |  |  | 

---

