# Nancy Audet

## Position actuelle

**Titre** : journaliste
**Entreprise** : Groupe TVA Inc
**Durée dans le rôle** : 17 years 11 months in role
**Durée dans l'entreprise** : 17 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Broadcast Media Production and Distribution

## Description du rôle

Journaliste

## Résumé

Journaliste depuis plus de 20 ans, je mets ma curiosité et ma sensibilité au service des histoires qui façonnent notre société. Mon parcours m’a amenée à couvrir l’actualité, à réaliser des entrevues marquantes et à développer des projets télé qui donnent la parole à ceux qu’on entend trop peu. À la télévision, j’ai notamment animé la série Être famille d’accueil sur Moi et Cie, participé au développement du documentaire Qui a tué les Expos, maintenant disponible sur Netflix, et contribué à la création des séries L’Escroc, Priez pour nous et L’Envers de la médaille.

Marquée par mon propre passage à la DPJ, j’ai choisi d’utiliser ma voix pour créer du changement. Depuis trois ans, je présente une conférence inspirante où je raconte mon chemin, de la protection de la jeunesse jusqu’à la salle de nouvelles un récit ancré dans la résilience, la résistance et la solidarité. J’ai également publié Plus jamais la honte (Éditions de l’Homme, 2021) et Ils s’appellent tous Courage, deux ouvrages qui mettent en lumière la réalité trop souvent silencieuse des enfants vulnérables.

En 2025, j’ai cofondé Ékip Jeunesse, un organisme qui accompagne les jeunes qui quittent le système et se retrouvent souvent seuls, sans ressources. Après plusieurs années d’engagement sur le terrain, ce projet s’inscrit dans la continuité de ma mission : redonner espoir, dignité et visibilité aux jeunes en situation de précarité.

Quel que soit le médium à l’écran, sur scène ou dans l’écriture je cherche à faire émerger des histoires qui transforment, qui rassemblent et qui éveillent les consciences.

Pour toute demande professionnelle, visitez :
nancyaudet.ca/conférences

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAnF2ZMBaPmTNt9GPMABpcOABu2w5AWWdG0/
**Connexions partagées** : 17


---

# Nancy Audet

## Position actuelle

**Entreprise** : Organisme Ékip Jeunesse

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nancy Audet

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400909744145793024 | Text |  |  | Il n’y a que le mot COURAGE écrit en lettres majuscules quand je pense à toi Demetry. Parler c’est guérir. Partager c’est sensibiliser. 🙏 | 35 | 7 | 3 | 1w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:25.330Z |  | 2025-11-30T14:53:05.258Z | https://www.linkedin.com/feed/update/urn:li:activity:7399534066703732736/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399073352532901890 | Article |  |  | Un matin, mon téléphone sonne. C’est Louisa. Elle pleure.
« Tu dois venir me chercher… maintenant », réussit-elle à dire entre deux sanglots.

Je suis figée.
« Mais voyons… ils ne peuvent pas te mettre à la porte aujourd’hui. C’est TON anniversaire! Oui, tu as 18 ans, mais ils pourraient te garder un peu plus longtemps… non? »

« Non. Viens me chercher, s’il te plaît. »

J’explose intérieurement.
Seize ans dans le système… et on la met dehors le jour de ses 18 ans.

Je file au foyer de groupe. C’est là qu’elle devait être “préparée” à la vie adulte.
La vérité? Aucune préparation.
Pas d’emploi.
Pas de réseau.
Pas prête du tout.

Elle m’ouvre elle-même la porte.
On descend à son petit studio au sous-sol : minuscule, sombre, miteux.
Sur le lit, une boîte de sacs poubelles.
Pendant qu’elle pleure, je remplis tout ça en vitesse : trois sacs et on part.
Personne ne vient.
Personne ne dit rien.

Seize ans dans le système… et même pas un “bonne chance”.

J’ai pris cette photo avant de partir. Pour me rappeler et pour montrer que oui, ça se passe encore comme ça.
À ceux qui disent : « Tu exagères. »
Non. Je n’exagère pas. Je témoigne.

Et les chiffres parlent fort :
33 % des jeunes qui sortent du système tombent en situation d’itinérance.
Un sur trois.
C’est gigantesque.
C’est indéfendable.
C’est maintenant qu’il faut agir.

Aujourd’hui, Louisa est en sécurité. Une famille l’a accueillie.
Mais tous n’ont pas cette chance.
Beaucoup n’ont personne à appeler quand on les met dehors et qu’ils ne sont pas prêts.

Louisa est entrée à la DPJ à 2 ans.
Elle a connu 22 déplacements.
22 ruptures.
Elle ne méritait pas d’être mise à la rue comme ça.

Personne ne mérite ça.
C’est une question de dignité humaine.

Vous voulez aider?
Vous voulez faire partie du mouvement?
Rejoignez ÉKIP Jeunesse 
On va travailler ensemble. 🙏

J’aime Louisa et je lui ai promis de tout faire pour que cela n’arrive plus.

Je vous laisse écouter son témoignage hier soir à l’émission de Philippe Cantin. 👇 | 59 | 9 | 8 | 1w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:25.331Z |  | 2025-11-25T13:15:55.379Z | https://www.985fm.ca/audio/739662/33-des-jeunes-se-retrouvent-en-situation-d-itinerance |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7398733339500896256 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e64288cb-3a10-460e-b58a-a7f35ab58106 | https://media.licdn.com/dms/image/v2/D4E10AQHEpp65y3Ax1g/videocover-high/B4EZq2JgnbIoA0-/0/1763992540161?e=1765785600&v=beta&t=cDSIrg4Ym1FhDTWbeR1Bqf3S7BrTZ5LtNUKyYTLmVM8 | Nous sommes si fiers de nos ambassadeurs d’ÉKIP Jeunesse. Ils sont importants pour nous. Grâce à eux, nous restons connectés sur l’essentiel. 🙏 | 1 | 0 | 0 | 1w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:25.332Z |  | 2025-11-24T14:44:49.955Z | https://www.linkedin.com/feed/update/urn:li:activity:7398721045412716544/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398575538044370944 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0ca3b261-7163-4ab3-a777-507689f2c305 | https://media.licdn.com/dms/image/v2/D4E05AQEB0sdDolXmNg/videocover-high/B4EZq0FLcHKgBY-/0/1763957850618?e=1765785600&v=beta&t=6MPl0YiFygonsQTsiFX96IX6RGhp3HXzDd2ZOgvJY1s | Je nous invite tous et toutes à prendre un moment pour regarder ces images de tentes qui se multiplient dans nos villes. Ces hommes et ces femmes passeront l’hiver dehors. Personne n’est à l’abri. Cela pourrait être un membre de notre famille… ou même notre enfant.

Chacun de nous a la responsabilité de poser un geste pour aider ces êtres humains. Nous traversons une crise sociale sans précédent. Soyons solidaires. Soutenons et appuyons les organismes qui leur viennent en aide.

À ÉKIP Jeunesse, nous allons tenter d’aider les jeunes qui se retrouvent à la rue sans filet de sécurité. N’hésitez pas à nous écrire si vous avez des vêtements chauds à offrir. Nous effectuerons une grande distribution dans les campements, les refuges d’urgence et les maisons d’hébergement les 6 et 7 décembre prochain. 🙏 | 24 | 1 | 2 | 2w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:25.333Z |  | 2025-11-24T04:17:47.156Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396945738087276545 | Document |  |  | Vous pouvez appuyer la mission d’Ékip Jeunesse et vous gâter en même temps. Nous sommes très fiers de cette campagne et de nos partenaires de grande qualité. Je vous invite à y jeter un coup d’œil. Merci ☺️🙏 | 7 | 0 | 1 | 2w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:25.334Z |  | 2025-11-19T16:21:32.566Z | https://www.linkedin.com/feed/update/urn:li:activity:7396902780344643584/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7395841257077645312 | Text |  |  | Je veux prendre un moment pour remercier Fabrice.

L’an dernier, il m’a écrit spontanément pour m’offrir son soutien. On s’était promis de se reparler cette année… et il a tenu parole. Aujourd’hui, il est là, aux côtés d’Ékip Jeunesse, avec toute sa générosité et son histoire qui donne encore plus de sens à son engagement.

Sa présence et son appui me touchent profondément. Ce sont des gestes comme le sien qui nous donnent l’élan nécessaire pour continuer et pour accompagner encore plus de jeunes.

Merci du fond du cœur, Fabrice. 💛 | 8 | 1 | 0 | 3w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.245Z |  | 2025-11-16T15:12:43.773Z | https://www.linkedin.com/feed/update/urn:li:activity:7395556489588838402/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7395215778104422400 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7E7VIhQPSwg/feedshare-shrink_800/B4EZqDUwtGHoAk-/0/1763139850300?e=1766620800&v=beta&t=FOqyBQe07EhQnwz1HuAyXd001qlk61YHYf3jtEJD7I0 | Merci pour l’accueil chaleureux. Nous étions vraiment heureuses de rencontrer vos formidables équipes qui offrent un filet de sécurité à des centaines de jeunes du Québec. Votre rôle est essentiel. Nous allons vous soutenir du mieux que nous pouvons.

Ne lâchez pas. Vous rendez notre monde meilleur. Un jeune à la fois, un cœur à la fois. Vous portez bien votre nom. ❤️ | 7 | 0 | 0 | 3w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.246Z |  | 2025-11-14T21:47:17.965Z | https://www.linkedin.com/feed/update/urn:li:activity:7395144535883804672/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7393711442014773248 | Image |  | https://media.licdn.com/dms/image/v2/D4D10AQF3ivAieFGqww/image-shrink_800/B4DZpuubyxJEAc-/0/1762794257983?e=1765785600&v=beta&t=LkJJERQyqp7Lbvbhr2FR9SncFJtQLICkweVyQspC808 | Dans 7 dodos. Cette campagne sera belle et remplie d’espoir. J’espère que vous aurez envie d’y participer. ☺️ | 11 | 0 | 0 | 3w | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.247Z |  | 2025-11-10T18:09:36.292Z | https://www.linkedin.com/feed/update/urn:li:activity:7393695053254324224/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7392656348842438656 | Article |  |  | Je sens un vent de solidarité qui se lève pour les jeunes en situation de précarité. C’est touchant et motivant. Merci à tous nos précieux partenaires. Sans vous, cela ne serait pas possible. 

Cogeco Media 
VitroPlus 
Manmade 
La Vie En Rose 
Alexandra Oberson 
Atelier Tonic 
La Poche Bleue
Le5600.com
RACQ-Regroupement des Auberges du coeur du Québec
Groupe Entourage | 37 | 1 | 1 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.250Z |  | 2025-11-07T20:17:02.477Z | https://ici.radio-canada.ca/ohdio/premiere/emissions/le-15-18/segments/rattrapage/2218210/ekip-jeunesse-un-organisme-aide-directe-pour-jeunes-vulnerables |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391578191015866368 | Document |  |  | Vous êtes nombreux à me demander ce que fera Ékip Jeunesse pour aider concrètement les jeunes en situation de précarité. 

Cette publication répond à cette question. Merci à tous ceux qui nous offrent leur soutien. N’hésitez pas à suivre notre page. 🙏 | 20 | 3 | 0 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.254Z |  | 2025-11-04T20:52:49.620Z | https://www.linkedin.com/feed/update/urn:li:activity:7391571094710947841/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7390758962385666048 | Article |  |  | Leur voix est importante. À nous d’aller vers eux et de les écouter. 🙏 | 4 | 1 | 1 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.255Z |  | 2025-11-02T14:37:30.294Z | https://www.ledevoir.com/opinion/lettres/930078/voix-peuvent-si-on-ecoute-changer-quebec |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7389473618465861633 | Video (LinkedIn Source) | blob:https://www.linkedin.com/238c1c46-b7ec-412c-9d7d-db4fbadd70aa | https://media.licdn.com/dms/image/v2/D4E10AQGrBgSrWNGMwA/ads-video-thumbnail_720_1280/B4EZowEWWvKkAk-/0/1761743042680?e=1765785600&v=beta&t=kr__xQx21i5pnUhwENiHJSBgRZQbUQ_Wjy9gSC6sgOo | Une journée très spéciale pour moi.
Après des mois de travail, de rêves, de discussions et d’espoir, ÉKIP Jeunesse est officiellement lancé!

Avec ÉKIP, on veut tendre la main aux jeunes qui quittent la DPJ ou qui vivent une grande précarité. Ces jeunes qui, trop souvent, n’ont personne pour les rattraper quand le système se retire. On veut leur offrir un vrai départ dans la vie, avec dignité, soutien et bienveillance.

Ce projet, je le porte profondément dans mon cœur. Parce qu’aucun jeune ne devrait avoir à affronter seul cette étape.

Je vous invite à faire partie de notre ÉKIP.

Suivez notre page ÉKIP Jeunesse et aidez-nous à bâtir une communauté forte, humaine et solidaire.🙏

Parce que, sincèrement, nous sommes tellement plus forts ensemble. 💪 | 78 | 14 | 5 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.258Z |  | 2025-10-30T01:30:00.423Z | https://www.linkedin.com/feed/update/urn:li:activity:7389285960041050112/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7388370220136026112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHGqbafrooHVA/feedshare-shrink_800/B4EZojDjBlJ0Ag-/0/1761524728650?e=1766620800&v=beta&t=n1o4sV4sb_N3QytidCE25k70p0WfAz9pmjrvotmnXas | « Je ne savais pas ce que je faisais ici ce soir. Mais maintenant je sais. J’étais sur le point d’abandonner, mais après t’avoir entendue, j’ai changé d’avis. Merci de m’avoir redonné une grande dose de motivation. »

Ces mots, prononcés vendredi par une médecin après ma conférence, m’habitent encore. Ils me rappellent pourquoi je fais ce métier.

Chaque fois que je vais à la rencontre des gens qui travaillent auprès des enfants, éducatrices, intervenants, enseignants, médecins, travailleurs sociaux, je ressens une immense gratitude.

Ce sont eux qui portent, au quotidien, le poids des histoires, des blessures et des espoirs des enfants.

Pouvoir leur redonner, le temps d’une rencontre, une dose d’énergie, d’espoir et de reconnaissance… c’est un privilège immense.

Je repars chaque fois touchée, inspirée, et convaincue que la bienveillance, lorsqu’elle circule, transforme réellement des vies.

Merci au CPE l’Attrait mignon et au Centre de pédiatrie sociale de Longueuil pour votre accueil et votre confiance.

Merci à tous ceux et celles qui, chaque jour, choisissent de croire aux enfants. | 60 | 0 | 0 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.259Z |  | 2025-10-27T00:25:29.761Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7386145160025235456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7ldnOilQLww/feedshare-shrink_800/B4EZoDb36tHoAg-/0/1760994233050?e=1766620800&v=beta&t=LS0Jw1rh6lXn_6r5s5tIjnqdMcIqt1thtebieLUkvcI | DONNONS DU CHAUD, DONNONS ESPOIR 

Il y a trois ans, j’ai organisé une petite collecte d’hiver… sur le coin de ma table de cuisine. Je ne me doutais pas un instant que cet élan de solidarité prendrait une telle ampleur.

Aujourd’hui, La Grande Collecte d’hiver est devenue un véritable mouvement, et pour la première fois cette année, elle est pilotée par Ékip Jeunesse, l’organisme que j’ai cofondé pour soutenir les jeunes vulnérables de 16 à 25 ans.

Depuis nos débuts, nous avons déjà aidé plus de 10 000 jeunes à retrouver un peu de chaleur, de dignité et d’espoir.

Mais la crise sociale actuelle frappe fort et de plus en plus de jeunes se retrouvent sans logement, sans filet et à la rue.

👉 Le 5 décembre prochain, nous serons présents dans cinq points de collecte VitroPlus à travers le Québec pour amasser manteaux, tuques, mitaines, bottes, sacs à dos et cartes-cadeaux d’épicerie, de pharmacie ou de restaurants.

✨ Entreprises, vous pouvez faire une vraie différence :

Installez une boîte de dons dans vos bureaux dès novembre.

Venez vivre une journée de teambuilding solidaire le 5 décembre avec vos collègues en venant remettre vos dons et donner un coup de main!

Ensemble, faisons de cette campagne un mouvement positif et rassembleur. Parce que les jeunes ont besoin de nous et nous pouvons faire une différence. ❤️

Pour nous écrire: info@ekipjeunesse.ca | 48 | 3 | 18 | 1mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.261Z |  | 2025-10-20T21:03:54.091Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7380940051062349824 | Article |  |  | Je suis profondément inquiète à la lecture de ce texte.

Depuis des années, on promet aux enfants du Québec un système de protection plus humain, plus efficace, plus centré sur leurs besoins.

Pourtant, les réformes se succèdent et les droits fondamentaux des jeunes continuent d’être bafoués dans l’indifférence.

En retirant à la Chambre de la jeunesse le pouvoir d’intervenir en matière de lésions de droits, on prive les enfants d’un véritable recours. D’un espoir, surtout.

La Commission des droits de la personne et des droits de la jeunesse (CDPDJ), déjà débordée et souvent lente à agir, n’a pas les moyens ni le mandat pour répondre à l’urgence de chaque situation. Soyons honnêtes : la CDPDJ ne joue déjà pas son rôle adéquatement. Elle ne le jouera pas davantage.

Cette décision ne fera qu’affaiblir encore plus les enfants les plus vulnérables.

On déplace le problème au lieu de le régler.
Et pendant que les instances se renvoient la responsabilité, les enfants victimes de lésions de droits sont laissés pour compte. Encore une fois.

C’est une erreur grave. Un système qui prétend protéger les jeunes ne peut pas leur retirer le seul recours qui leur permettait d’être entendus. | 28 | 1 | 2 | 2mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.262Z |  | 2025-10-06T12:20:39.408Z | https://www.ledevoir.com/opinion/idees/922698/idees-quand-on-reduit-delais-prix-droits-jeunes-dpj-paient-note |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7379886944824164352 | Video (LinkedIn Source) | blob:https://www.linkedin.com/32cd370f-d7cc-4c76-ba19-d270db54f592 | https://media.licdn.com/dms/image/v2/D4D05AQEFOJt1fpcFZQ/videocover-low/B4DZmqf.ZiJcCA-/0/1759502153228?e=1765785600&v=beta&t=9gvVyf8oW_Cr5BwB1Nd9OsAzLojihJy9xmSr1Z45Ha8 | Le 18 avril 2024, en chambre, le ministre Lionel Carmant rejetait avec fermeté l’idée qu’on puisse comparer les centres jeunesse à des milieux carcéraux. Son ton moqueur et irrespectueux avait provoqué les ricanements de plusieurs élus de la CAQ.

Un an et demi plus tard, un rapport de la CDPDJ sur les centres jeunesse de Laval vient rappeler une réalité troublante : des enfants y vivent encore dans des conditions qui s’apparentent à l’isolement carcéral. Ces jeunes déjà fragilisés par leur parcours subissent ainsi de nouvelles blessures. Ce n’est pas une simple question de gestion de ressources, c’est une atteinte directe à leur dignité et à leurs droits.

Lorsqu’on enferme un enfant dans une cellule, on ne l’aide pas à guérir. On accentue ses traumatismes. On lui envoie le message que sa souffrance n’a pas d’importance. Et ces marques, elles ne disparaissent pas avec le temps : elles accompagnent ces jeunes tout au long de leur vie.

Il est urgent que le ministre Lionel Carmant prenne la pleine mesure de ses responsabilités. Les enfants pris en charge par l’État n’ont pas choisi leur destin. Ils dépendent de nous, de nos institutions, de nos décideurs. Leur offrir des conditions de vie dignes et respectueuses de leurs droits n’est pas une option : c’est un devoir.

Parce qu’un gouvernement qui ne protège pas ses enfants les plus vulnérables échoue dans sa mission. | 81 | 13 | 9 | 2mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.264Z |  | 2025-10-03T14:35:59.315Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7376997112493899776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHcXvJaUc1Ydw/feedshare-shrink_800/B4EZlDN6t2KwAg-/0/1757769348349?e=1766620800&v=beta&t=uoBeUZ79DPIvAq2UUuoAROuVhFpO59sIIalMVjmNh2A | Si on pouvait seulement se voir dans le regard des autres et s’aimer comme ils nous aiment. ❤️ | 7 | 0 | 0 | 2mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.271Z |  | 2025-09-25T15:12:49.597Z | https://www.linkedin.com/feed/update/urn:li:activity:7372619014428213248/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7373143546066907137 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEHftnGjhQyrA/image-shrink_800/B4EZlCAvEwGwAc-/0/1757749113775?e=1765785600&v=beta&t=mwfH7guuyBV-fbB8Zwub5EueTIay_6jh6nn6W45fssU | Cela est très inspirant. Dans l’espoir que les enfants Québécois puissent aussi être entendus. Ce qui arrive très rarement chez nous. 🙏 | 25 | 0 | 4 | 2mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.272Z |  | 2025-09-15T00:00:07.765Z | https://www.linkedin.com/feed/update/urn:li:activity:7372534141155700736/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7371601398154678273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGXtz7m3epKaw/feedshare-shrink_800/B4EZk0wZe5KsAg-/0/1757526730096?e=1766620800&v=beta&t=DYXtKeucRp6bp7-sLTXFO136bvSB6_5NyXkJyaCVqmI | À ne pas manquer le 21 octobre prochain. Produit à Montréal avec une équipe absolument formidable. Bravo Attraction | 2 | 0 | 0 | 2mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.273Z |  | 2025-09-10T17:52:11.051Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7363318574624428033 | Article |  |  | Lancement officiel de mon site web 🥳

Au fil des années, j’ai eu l’honneur de côtoyer des personnes d’une incroyable résilience. Leur courage m’a transformée, inspirée, et guidée dans ma mission.

Aujourd’hui, je suis heureuse de vous présenter un espace qui me ressemble :
⤵️⤵️⤵️

www.nancyaudet.ca

Vous y trouverez mon parcours, mes conférences, mes livres, et les projets qui m’animent.

Mon objectif est simple : mettre la parole au service de la transformation, humaine et sociale.

Si le cœur vous en dit, je vous invite à venir découvrir ce nouvel espace.

Vos retours, vos partages et vos impressions sont les bienvenus. | 97 | 16 | 0 | 3mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.274Z |  | 2025-08-18T21:19:12.034Z | http://www.nancyaudet.ca/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7361022848393502722 | Article |  |  | J’appuie chaque mot de ce vibrant cri du cœur. Notre jeunesse a besoin de nous. Alors que j’entends trop souvent qu’ils ne veulent pas travailler et qu’ils ont tout cuit dans le bec, je vois des jeunes essayer très fort de s’en sortir. Je les vois manquer de ressources et de soutien. Je vois aussi leur solitude.

Pourtant, ils ont beaucoup à offrir. Ils veulent avancer. Ils veulent contribuer. 

Prenons soin d’eux et écoutons ce qu’ils ont à dire. Leur voix compte. 🙏

Je vous recommande cet article de La Presse : Le Québec doit écouter sa jeunesse, maintenant https://lnkd.in/druGAjnS | 22 | 2 | 3 | 3mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.277Z |  | 2025-08-12T13:16:48.248Z | https://lp.ca/xhmlTe?sharing=true |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7359916755051266048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnFf31-Yxyrw/feedshare-shrink_800/B4EZh8HfP_GoAk-/0/1754428995203?e=1766620800&v=beta&t=oBsVKYpEn6x7YHEHrbdagf0FLFmEe_yGRoIWT8RoH3I | Il est important de ne pas stigmatiser les enfants et les jeunes victimes. Il est tout aussi important de bien s’informer avant de prendre la parole sur un sujet aussi délicat. | 11 | 1 | 0 | 3mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.278Z |  | 2025-08-09T12:01:35.045Z | https://www.linkedin.com/feed/update/urn:li:activity:7358608556650078208/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7351383476622761984 | Article |  |  | La mort de ces deux enfants aurait pu être évitée. Les signaux étaient au rouge comme c’est arrivé trop souvent. Comment un homme violent envers la mère de ses enfants peut-il être un bon père? On protège la mère, mais pas les enfants? Formons tous les intervenants à reconnaître les signes et les dangers liés au contrôle coercitif. Ça peut sauver des vies. 

https://lnkd.in/eKFJrtk9? | 37 | 5 | 2 | 4mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.279Z |  | 2025-07-16T22:53:22.927Z | https://www.ledevoir.com/societe/892870/coroner-denonce-absence-mecanismes-proteger-enfants-exposes-violence-conjugale? |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7350550683269455872 | Document |  |  | Encore une fois des unités hébergeant des enfants du Mont Saint-Antoine ont été inondées hier. Ces enfants sont sous la responsabilité de l’État et ils vivent dans des conditions difficiles. Où seront-ils logés? Qui va assurer les travaux d’assèchement pour éviter qu’il y ait encore des champignons et de la moisissure? Lesley Hill est-ce possible d’aller vérifier si les enfants vont bien et l’état des lieux svp? | 14 | 4 | 1 | 4mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.280Z |  | 2025-07-14T15:44:09.519Z | https://www.linkedin.com/feed/update/urn:li:activity:7341177587995430917/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7345567863279153152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7r9NeNE2Yng/feedshare-shrink_800/B4EZetfjJRHYAk-/0/1750962421112?e=1766620800&v=beta&t=-raFeCfwGktGj63JbKLtH-pl9WrjiWxEO6lUyRZm8dY | Merci de bien vouloir bâtir des ponts avec moi. Nous avons la même mission et le même amour des enfants. Pour prendre soin des enfants, il faut aussi tendre la main aux parents. 🙏❤️ | 16 | 1 | 0 | 5mo | Post | Nancy Audet | https://www.linkedin.com/in/nancy-audet-b83ab046 | https://linkedin.com/in/nancy-audet-b83ab046 | 2025-12-08T07:07:31.281Z |  | 2025-06-30T21:44:12.657Z | https://www.linkedin.com/feed/update/urn:li:activity:7344068701530300417/ |  | 

---



---

# Nancy Audet
*Organisme Ékip Jeunesse*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [](https://www.fondationjeunesdpj.ca/en/blog/nancy-audet-becomes-a-proud-supporter-of-the-fondation-du-centre-jeunesse-de-montreal/)
- Category: blog

### [Let's Imagine Podcast EPISODE 34: Young Women Are Reimagining Leadership in Canada’s Nonprofit Sector](https://imaginecanada.ca/en/360/lets-imagine-podcast-episode-34-young-women-are-reimagining-leadership-canadas-nonprofit-sector)
*2025-10-08*
- Category: podcast

### [An Interview with Michèle Audette: carrying the hearts of many](https://montrealserai.com/article/an-interview-with-michele-audette-carrying-the-hearts-of-many/)
*2021-01-16*
- Category: article

### [Celebrating Diversity: Executive Director Nancy Gagnier and Program Director Audrey Rowe of South Orange/Maplewood Community Coalition on Race On How To Build Inclusive Communities](https://medium.com/authority-magazine/celebrating-diversity-executive-director-nancy-gagnier-and-program-director-audrey-rowe-of-south-ad2fdd19e314)
*2024-05-17*
- Category: blog

### [Thrive Hive Podcast](https://podcasts.apple.com/us/podcast/thrive-hive-podcast/id1633529521?l=fr-FR)
*2025-06-06*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Signalements en forte hausse à la DPJ: «Il faut un vrai changement ...](https://www.24heures.ca/2025/10/22/signalements-en-forte-hausse-a-la-dpj-il-faut-un-vrai-changement-de-culture-souligne-deux-expertes)**
  - Source: 24heures.ca
  - *Oct 22, 2025 ... ... Nancy Audet, journaliste et cofondatrice de l'organisme Ékip Jeunesse. ... podcasts filméswww.pesesurstart.com. Publicité. En col...*

- **[Signalements en forte hausse à la DPJ: «Il faut un vrai changement ...](https://www.journaldequebec.com/2025/10/22/signalements-en-forte-hausse-a-la-dpj-il-faut-un-vrai-changement-de-culture-souligne-deux-expertes)**
  - Source: journaldequebec.com
  - *Oct 22, 2025 ... ... Nancy Audet, journaliste et cofondatrice de l'organisme Ékip Jeunesse. ... TikTok se lance à son tour dans les podcasts filmés. w...*

- **[Steven Guilbeault ému lors de son retour dans Tout le monde en ...](https://news.ssbcrack.com/steven-guilbeault-emu-lors-de-son-retour-dans-tout-le-monde-en-parle-apres-son-depart-du-cabinet/)**
  - Source: news.ssbcrack.com
  - *7 days ago ... Pour clore l'épisode, Nancy Audet a partagé des réflexions ... Avec la cofondatrice de l'organisme Ékip jeunesse, Alicia Monette, elles...*

- **[Tout le monde en parle - Épisodes | Qui Joue Qui ?](https://quijouequi.com/emissions/tout-le-monde-en-parle/episodes)**
  - Source: quijouequi.com
  - *... Nancy Audet, cofondatrice de l'organisme Ékip jeunesse, et Alicia Monette, ex-placée de la DPJ, pour La grande collecte d'hiver au profit des jeun...*

- **[«Mon cri du cœur a été entendu»: l'organisme Ékip amasse plus de ...](https://www.24heures.ca/2025/12/01/mon-cri-du-cur-a-ete-entendu-lorganisme-ekip-amasse-plus-de-175-000-apres-son-passage-a-tlmep)**
  - Source: 24heures.ca
  - *7 days ago ... L'organisme Ékip Jeunesse, qui vient en aide aux ... La journaliste et cofondatrice de l'organisme Nancy Audet était de passage au talk...*

- **[Nancy Audet](https://nancyaudet.ca/accueil)**
  - Source: nancyaudet.ca
  - *À propos de Nancy Audet ... C'est donc avec passion qu'elle a cofonfé l'organisme ÉKIP JEUNESSE et qu'elle soutient différents organismes et initiativ...*

- **[Épisode du dimanche 30 novembre 2025 | Tout le monde en parle](https://ici.radio-canada.ca/tele/tout-le-monde-en-parle/site/episodes/1130091/30-novembre-2025)**
  - Source: ici.radio-canada.ca
  - *Nov 30, 2025 ... ... Nancy Audet, cofondatrice de l'organisme Ékip jeunesse, et Alicia Monette, ex-placée de la DPJ, pour La grande collecte d'hiver a...*

- **[Tout le monde en parle – les personnes invitées du 30 novembre ...](https://ici.radio-canada.ca/tele/blogue/2210406/tlmep-steven-guilbeault-julie-snyder)**
  - Source: ici.radio-canada.ca
  - *Nov 28, 2025 ... ... Nancy Audet, cofondatrice de l'organisme Ékip jeunesse, et Alicia Monette, ex-placée de la DPJ, pour La grande collecte d'hiver a...*

- **[Ékip jeunesse | La Ruche](https://laruchequebec.com/en/projects/en-ekip-pour-les-jeunes-vulnerables)**
  - Source: laruchequebec.com
  - *... organisme ÉKIP JEUNESSE voit le jour. Nous serons là pour eux à l'année, en aide ... Conférence avec Nancy Audet. Select. help. $1,000 (Includes t...*

- **[Tout le monde en parle: Découvrez les invités du 30 novembre](https://www.noovomoi.ca/en-vedette/tout-le-monde-en-parle-invites-30-novembre-2025.html)**
  - Source: noovomoi.ca
  - *Nov 29, 2025 ... Nancy Audet, cofondatrice de l'organisme Ékip jeunesse, et Alicia Monette, ex-placée de la DPJ, pour La grande collecte d'hiver au pr...*

---

*Generated by Founder Scraper*
