# Gurasis Singh

## Position actuelle

**Titre** : Founder & Podcast Host
**Entreprise** : My Thick Accent
**Durée dans le rôle** : 3 years 3 months in role
**Durée dans l'entreprise** : 3 years 3 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Online Audio and Video Media

## Description du rôle

Breaking the stereotypical moulds the immigrants are asked to fit by bring forth stories of immigrants every Thursday. Unfolding their personal journeys of struggle, resilience and finding home away for home. 
Join in the mission to know each other “Beneath The Accent!”

Season 2 Live Now 🎧

New Episode | Every Thursday | On All Podcast Streaming Platforms | Just search “My Thick Accent”

## Résumé

🎯 Advertising Strategist by Trade. Podcast Creator by Passion.

With 6+ years in advertising — across FMCG, pharma, and purpose-driven brands — I thrive at the intersection of strategy, storytelling, and client delight.

🔹 Led multi-channel campaigns for GSK and AbbVie, managing timelines, approvals, and cross-functional teams in regulated industries.
🔹 Contributed to award-winning work, including a Silver and Bronze at the 2024 New York Festivals Health Awards.
🔹 Started in the creative world with Ogilvy India (that experience ignited something in me to excel in the Industry).

Outside of the 9–5, I’m the creator and host of My Thick Accent — a podcast with 100+ episodes and 10,000+ downloads, spotlighting immigrant voices and reshaping narratives. From guest outreach to audio/video editing, I’ve built the show end-to-end. It’s not just storytelling, it’s production, branding, and community-building in motion.

🧠 Whether it's:

☑️ Building B2B/B2C messaging strategies
☑️ Managing high-stakes accounts
☑️ Or crafting audio content that hits home

I bring precision, empathy, and momentum to everything I create.

📬 Open to advertising, content, and podcast-related roles — freelance or full-time. Let’s connect!

🎙 Podcast: @mythickaccent
☕ DM to Book a chat!

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACCRwDsBGL9d0xKIyWIeviZCvW7Wc9w7eVM/
**Connexions partagées** : 3


---

# Gurasis Singh

## Position actuelle

**Entreprise** : My Thick Accent

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Gurasis Singh
*My Thick Accent*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 16 |

---

## 📚 Articles & Blog Posts

### [What Happens When Birthdays Become Checkpoints? | Happy Birthday Gurasis Singh (Host) 🎂  - My Thick Accent | iHeart](https://www.iheart.com/podcast/269-my-thick-accent-104900295/episode/what-happens-when-birthdays-become-checkpoints-285106904/)
*2025-07-09*
- Category: podcast

### [](https://podcasts.apple.com/ca/podcast/my-thick-accent-with-gurasis-singh-ep-000/id1644146229?i=1000578842888)
- Category: podcast

### [My Thick Accent](https://www.mythickaccent.com/1835261/contributors)
*2025-01-01*
- Category: article

### [My Thick Accent – Podcast](https://podtail.com/podcast/my-thick-accent/)
*2025-06-23*
- Category: podcast

### [Breaking Barriers in Canadian Media: Story of Former Host ...](https://www.mythickaccent.com/1835261/episodes/13461418-breaking-barriers-in-canadian-media-story-of-former-host-of-badhai-ho-one-of-the-best-talk-shows-in-ethnic-media-in-ontario-ft-geetika-bhardwaj-ep-043)
*2023-08-24*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[My Thick Accent](https://www.mythickaccent.com/)**
  - Source: mythickaccent.com
  - *... My Thick Accent' podcast aims to break the stereotypical moulds the ... | Happy Birthday Gurasis Singh (Host). What happens when birthdays transfo...*

- **[What Happens When Birthdays Become Checkpoints? | Happy ...](https://www.mythickaccent.com/1835261/episodes/17480383-what-happens-when-birthdays-become-checkpoints-happy-birthday-gurasis-singh-host)**
  - Source: mythickaccent.com
  - *Jul 9, 2025 ... 'My Thick Accent' podcast aims to break the stereotypical moulds the ... | Happy Birthday Gurasis Singh (Host). July 09, 2025 ......*

- **[Meet Gurasis Singh - Bold Journey Magazine](https://boldjourney.com/meet-gurasis-singh/)**
  - Source: boldjourney.com
  - *Meet Gurasis Singh. July 2, 2024. We recently connected with Gurasis Singh and have shared our conversation below. ... I am the creator and host of th...*

- **[My Thick Accent is My Superpower with Gurasis Singh (NOF#14 ...](https://onfire.show/my-thick-accent-is-my-superpower-with-gurasis-singh-nof14/)**
  - Source: onfire.show
  - *... podcast “My Thick Accent” to showcase immigrant success stories ... My Thick Accent is My Superpower with Gurasis Singh (NOF#14). Watch Later ......*

- **[Dilipani – Equity, Diversity, Inclusion and Belonging Consultation ...](https://www.dilipani.com/)**
  - Source: dilipani.com
  - *Burst The Conventional Bubble | Ft. Dakshima Dilipani Ep. 023 - My Thick Accent with Gurasis Singh ... https://podcasts.apple.com/us/podcast/ekwomen ....*

- **[My Thick Accent](https://www.mythickaccent.com/1835261/episodes)**
  - Source: mythickaccent.com
  - *My Thick Accent Artwork · He Didn't Expect This Question | Know Your Host - Gurasis Singh [New Segment]. What happens when podcast roles reverse and t...*

- **[Episodes | Ready Set Do](https://www.readysetdopodcast.com/episodes/)**
  - Source: readysetdopodcast.com
  - *In this powerful and deeply personal episode, we sit down with Gurasis Singh, the host of My Thick Accent podcast, to explore the layered experience o...*

- **[Resilience, Success, and Mentorship with Jessica Camborda (NOF ...](https://creators.spotify.com/pod/profile/newcomers-on-fire9/episodes/Resilience--Success--and-Mentorship-with-Jessica-Camborda-NOF2-e33sb0m)**
  - Source: creators.spotify.com
  - *My Thick Accent is My Superpower with Gurasis Singh (NOF#14). Gurasis Singh ... Acing the Interview: We share step-by-step techniques to thoroughly .....*

- **[Whose Story Are You Living? - My Thick Accent](https://www.mythickaccent.com/1835261/episodes/17113910-whose-story-are-you-living-beneath-the-accent-with-rafael-rodrigues)**
  - Source: mythickaccent.com
  - *My Thick Accent. Whose Story Are You Living? | Beneath The Accent with Rafael Rodrigues. June 25, 2025 • Gurasis Singh • Season 2. Share. Share episod...*

- **[Boy in outer space: Author Omar El Akkad talks adjusting to Canada ...](https://thenewcomer.ca/success-stories/boy-in-outer-space-author-omar-el-akkad-talks-adjusting-to-canada-and-success-in-writing/)**
  - Source: thenewcomer.ca
  - *Feb 23, 2022 ... “That poor guy got six calls a day from me, because who else am I going to talk to? ... “My Thick Accent Is My Superpower”: How Guras...*

---

*Generated by Founder Scraper*
