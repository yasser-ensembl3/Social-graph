# Nylan Raufaste

## Position actuelle

**Titre** : CEO & Co-founder
**Entreprise** : Self-storage.ai
**Durée dans le rôle** : 5 years 6 months in role
**Durée dans l'entreprise** : 5 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Since 2021, Self-storage.ai has been partnering with self-storage operators to help them improve customer experience through SpaceStacker, an AI-powered 3D storage planner that boosts user engagement, increases conversion rates, and reduces reliance on customer service.

Plugged directly into a website, SpaceStacker lets users select their items or apartment size to receive tailored storage recommendations based on unit inventory. It suggests the ideal unit size and shows how to pack efficiently—all in 3D and 360° virtual views.

SpaceStacker offers a number of niche features that make it a unique tool, clearly differentiating our partners’ websites from their competitors.

By simplifying the biggest barrier to independent online reservations—finding the right unit size—SpaceStacker enhances website performance, delivers a seamless customer experience, and drives rental conversions.

Curious to see it in action? Let’s chat about bringing SpaceStacker to your website!

## Résumé

I’m passionate about how technology can be used to create a positive impact on people, businesses, and industries.

Currently working with self-storage facility chains to help them improve customer experience through SpaceStacker, an AI-powered 3D storage calculator that increases user engagement and conversion rates while reducing the need for customer service in the rental process.

Originally built to help users find the right storage unit size, SpaceStacker uses Tetris-like technology to maximize volume while respecting specific conditions. Its versatility enables us to solve space optimization challenges across logistics, supply chains, and other industries.

In 2024, Self-storage.ai was named “Best AI Startup in Canada” at the ALL IN event.

With a background in business and IT, I’ve co-created software like a peer-to-peer storage marketplace, a storage unit pricing comparison tool, and an AI hackathon evaluation platform. Along the way, I’ve participated in entrepreneurial programs like Creative Destruction Lab, NEXT AI, and KPMG Ventures.

Feel free to connect if you’d like to discuss technology, entrepreneurship, self-storage, or space optimization challenges.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACjlYdwBa4FyhZ_CTjxZSdf54a8dnV6oWmc/
**Connexions partagées** : 74


---

# Nylan Raufaste

## Position actuelle

**Entreprise** : Self-storage.ai

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nylan Raufaste

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399198262739566595 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFaRpMzyL4OZw/feedshare-shrink_800/B4EZq8YPOcKcAg-/0/1764097063123?e=1766620800&v=beta&t=OB9t1Ke6YmqNMHtKhNHDHeuXXjHznfeRBqEHNPnKYig | Appreciate being included in the winter edition of Self-Storage Canada with the article "How AI and 3D Help Customers Select Ideal Unit Sizes" | 29 | 2 | 0 | 1w | Post | Nylan Raufaste | https://www.linkedin.com/in/nylanraufaste | https://linkedin.com/in/nylanraufaste | 2025-12-08T06:08:19.780Z |  | 2025-11-25T21:32:16.293Z | https://www.linkedin.com/feed/update/urn:li:activity:7399159372339384320/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7340415762437709826 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHo0s5LAQ-oiw/feedshare-shrink_800/B4EZd5lD7dHgAg-/0/1750091451186?e=1766620800&v=beta&t=wIgoDCKunkC-nH6SlxV_149Kk7gxuSSHSZExxuS4rOo | We had an incredible time in France for VivaTech 2025 🇫🇷✨

As part of the official Canadian delegation, with Canada being this year’s Country of the Year at VivaTech, we had the opportunity to showcase how we use AI and 3D technology to optimize the layout of objects and goods within any type of container.

What makes our technology powerful is its ability to handle items of all shapes and sizes, identifying the most efficient way to arrange them based on constraints such as weight distribution, fragility, accessibility, and stacking rules.

Today, we provide white-labeled 3D storage planners to self-storage operators (called garde-meuble in France), helping their customers determine the right unit size directly on their website. The tool drives online reservations and also supports call center staff, especially new hires, in guiding users toward the right unit over the phone.

Looking ahead, we’re expanding the use of our "Tetris-like" optimization technology to support logistics and freight loading.

Maximizing loading space is critical for the logistics industry: it means transporting the same volume of goods with fewer trips, reducing costs, fuel usage, and environmental impact 🌍.

During VivaTech, we had insightful discussions with supply chain, logistics, and freight experts who shared valuable perspectives and feedback.

We’re excited about the impact our product, SpaceStacker, can have across these industries in the months to come.

Special thanks to the entire SCALE AI - Canada's AI Cluster team for organizing this mission and for selecting Self-storage.ai as one of the startups representing Canada as part of this delegation.

We were honored to attend a networking reception at the Official Residence of the Canadian Ambassador to France, and to hear inspiring remarks from The Honourable Stéphane Dion, Ambassador to France and Monaco, as well as Evan Solomon, Canada’s Minister of AI and Digital Innovation, on the future of AI and technology, both in Canada and around the world.

Stay tuned, and feel free to reach out if we haven’t had the chance to connect yet! 🚀 | 180 | 18 | 6 | 5mo | Post | Nylan Raufaste | https://www.linkedin.com/in/nylanraufaste | https://linkedin.com/in/nylanraufaste | 2025-12-08T06:08:19.781Z |  | 2025-06-16T16:31:36.095Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7336136603481911297 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFLzQHj2Xk_Pw/feedshare-shrink_800/B4EZc8xXXbGcAk-/0/1749071264302?e=1766620800&v=beta&t=UQP_JufQrDthkRP9zJ7M2uJjAx3WPyRbrneVb6GpKjc | Accompagné de Bernard Pitre de la Ville de Laval, j’ai eu le plaisir de rencontrer l’équipe de CargoM - Grappe métropolitaine de logistique et transport de Montréal hier au Port de Montréal, à l’occasion de leur Assemblée générale annuelle.

J’ai eu l'occasion de discuter avec Louis-Philippe Allard, Amy Lombard, Yves Murray et Karine Dudognon sur les façons dont l’intelligence artificielle peut être utilisée pour optimiser les espaces de chargement de marchandises. L’objectif : réduire le nombre de trajets nécessaires pour transporter un même volume, diminuer la consommation de carburant et contribuer à la réduction des émissions de GES.

Rassemblant les acteurs de la logistique et du transport de marchandises du Grand Montréal, CargoM joue un rôle clé en créant des ponts entre les parties prenantes autour d’objectifs communs et d’actions concertées visant à renforcer la cohésion, la compétitivité, la croissance et le rayonnement du secteur.

#TechForGood #AI #Logistique #TransportDeMarchandises #MobilitéDurable #IAQuébec #VilleDeLaval #StartupAI #GreenTech #SupplyChain #Optimisation | 139 | 6 | 1 | 6mo | Post | Nylan Raufaste | https://www.linkedin.com/in/nylanraufaste | https://linkedin.com/in/nylanraufaste | 2025-12-08T06:08:19.782Z |  | 2025-06-04T21:07:45.097Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7316119369330167808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEJRIuyAmXlkQ/feedshare-shrink_800/B4EZYgTY8tGYAo-/0/1744298676576?e=1766620800&v=beta&t=xQ3ssdmDiJ_EV0G7QxOrrFkGYinQNJmd-_hVb_PwQJ0 | Who will be there? | 17 | 2 | 0 | 7mo | Post | Nylan Raufaste | https://www.linkedin.com/in/nylanraufaste | https://linkedin.com/in/nylanraufaste | 2025-12-08T06:08:19.784Z |  | 2025-04-10T15:26:24.573Z | https://www.linkedin.com/feed/update/urn:li:activity:7316118919776251907/ |  | 

---



---

# Nylan Raufaste
*Self-storage.ai*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [What does it take to be a student entrepreneur? The answer with Ange Blécon and Nylan Raufaste, co-founders of Entrepotes](https://starduststartupfactory.org/student-entrepreneurship-entrepotes/)
*2020-12-16*
- Category: article

### [Michael Nylan interview](https://www.sonshi.com/nylan.html)
*2024-01-01*
- Category: article

### [AI-Powered 3D Storage Planner | Self-Storage.ai](https://www.self-storage.ai/en-ca)
*2025-01-01*
- Category: article

### [What is AI? Just another buzzword? by Self Storage Lab](https://creators.spotify.com/pod/profile/selfstoragelab/episodes/What-is-AI--Just-another-buzzword-e286mn3)
*2025-04-29*
- Category: podcast

### [The Rise of AI in Self Storage | Self Storage Explained Podcast](https://stora.co/ca/podcast/the-rise-of-ai-in-self-storage)
*2025-08-21*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Ventures - Next Canada](https://www.nextcanada.com/directory/ventures/)**
  - Source: nextcanada.com
  - *Self-storage.ai. Comparastore is Canada's first self-storage marketplace ... Nylan Raufaste. Ange Blecon. Toothpod. Toothpod is aiming to improve glob...*

- **[NEXT AI Montréal Open House · Luma](https://luma.com/jm19nzjk?locale=fr)**
  - Source: luma.com
  - *... Nylan Raufaste, CEO de Self-storage.ai, avec la participation de Zhen Chen ... ​​PITCH COMPETITION: WIN A CHANCE TO RECEIVE AN INVITATION TO THE F...*

- **[Nylan RAUFASTE CEO & Co-Founder at SELF-STORAGE.AI](https://vivatechnology.com/speakers/3fa5bc52-5d1f-f011-8b3d-6045bdf3ac94)**
  - Source: vivatechnology.com
  - *Nylan RAUFASTE. Photo Nylan RAUFASTE. Nylan RAUFASTE. CEO & Co-Founder. SELF-STORAGE.AI. #. Artificial Intelligence. Industry & Supply Chain. Mobility...*

---

*Generated by Founder Scraper*
