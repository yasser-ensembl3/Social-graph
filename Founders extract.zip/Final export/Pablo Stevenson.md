# Pablo Stevenson

## Position actuelle

**Titre** : Selected Startup
**Entreprise** : Google for Startups
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

Hello there! I'm Pablo, the co-founder of Tedy.app, a benefits platform reshaping the concept of well-being within organizations. Tedy is all about fostering meaningful connections and nurturing company cultures that thrive. Tedy is growing, and you should totally check it out especially if you're an SMB that's done with those old-school benefits from the 90s. Check it out at tedy.app 🚀

In my previous role as the CEO and founder of ressac, a recognized digital agency, I successfully exited with a strategic acquisition from Leger, Canada's top research firm. Over my 17-year journey at ressac, I fostered an atmosphere of sustainable growth, achieving three consecutive appearances on the prestigious Growth 500 list and clinching two awards  as one of Canada's Best Places to Work. 🏆

With a portfolio of over 250 keynotes delivered both nationally and internationally, I passionately discuss corporate culture, business growth, and the profound influence of technology on brands and individuals. Curious about me? You can catch me online or at Café Gamba on St-Viateur if you are nearby. Cheers!

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABF3-IBsA6GqG9lpYg6jzvgwoS-5vVXWqA/
**Connexions partagées** : 126


---

# Pablo Stevenson

## Position actuelle

**Entreprise** : Tedy

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pablo Stevenson

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392037332717162497 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGnI9YMLMYyxA/feedshare-shrink_800/B4EZpXKuwlJ0Ag-/0/1762399031736?e=1766620800&v=beta&t=n9ggqi6ZnSXue23UF5b1RtViHLZDGtKfOlCZyVTtPFk | Canada’s startup scene is alive and kicking. We’re at SAAS NORTH Conference with the Tedy team, and the energy here is unreal. So many founders and ecosystem builders are shaping the economy of tomorrow.If you’re in Ottawa, come find us and say hi. You’ll spot our big fat poster for sure. | 72 | 0 | 0 | 1mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:30.286Z |  | 2025-11-06T03:17:17.532Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391138966340653056 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEdWMkgpsAydw/feedshare-shrink_800/B4EZpKZtVPKkAk-/0/1762184848434?e=1766620800&v=beta&t=qnj-W-R7XKBqVmMl7wo4BR_VhO3Q12i1lfwsMp5xDUQ | Last Friday I had the chance to share Tedy’s 1 minute vision for a new era of AI-powered benefits at the Google for Startups Montreal AI Gathering.

It was a really special group, Googlers and founders who are genuinely pushing the limits of what LLMs and agentic systems can do. You could feel the energy in the room.

Our take on AI is a bit different though. Employee benefits live in this weird space I like to call “non-direct compensation.” It’s part of your pay, but it often gets lost behind layers of process and perception.

At Tedy, we’re using LLMs and machine learning not just to process thousands of claims automatically (which we already do with high accuracy), but to help companies build programs that truly match the needs of their people.

Because in a 2,000-person company, not everyone wants the same thing. And when the value of benefits feels different to everyone, it affects how people see their total compensation.

That’s the gap we’re working to close, and honestly, it’s what makes this space so exciting right now. | 73 | 10 | 0 | 1mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:30.286Z |  | 2025-11-03T15:47:30.297Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7377343705860435968 | Text |  |  | Today, Tedy is thrilled to join one of the most innovative HR, Talent, and Operations communities out there The People People Group.

It’s a natural move for us to stay close to people who truly understand other people and culture, one of the most important ingredients of the future of work. 
🚀 🚀 🚀 | 32 | 0 | 0 | 2mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:30.287Z |  | 2025-09-26T14:10:03.895Z | https://www.linkedin.com/feed/update/urn:li:activity:7377086077297373184/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7371240752603111425 | Video (LinkedIn Source) | blob:https://www.linkedin.com/952e2509-63d7-45d2-8362-344c1fc4d211 | https://media.licdn.com/dms/image/v2/D4E05AQGD8it2vElGKg/videocover-low/B4EZkvmXBZIMCE-/0/1757440212341?e=1765774800&v=beta&t=6eKbvc-fv2Haeaz2mC--WV2MgVryj320RUIzExQcnKk | We have officially launched Tedy Partners. Every day, we hear from Group Benefits Advisors, CPAs, and HR Partners eager to be part of the next wave of innovation in employee benefits. 💪 

After months of hard work, I’m proud to say we’ve built something solid that will make a real difference in personalized benefits.

If you’re a broker/advisor, HR consultant, or accountant, let’s talk! | 20 | 2 | 0 | 2mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:30.289Z |  | 2025-09-09T17:59:06.451Z | https://www.linkedin.com/feed/update/urn:li:activity:7371238539801292800/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7341850717193748480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGenWHOqxC1AQ/feedshare-shrink_800/B4EZeN8QasHIAk-/0/1750433076274?e=1766620800&v=beta&t=js0hdiB73SjWBj0dMI9STseKOqoxkyopRMACo4NqVh0 | Ça jase de rémunération mieux-être dans La Presse. Tu ne sais pas ce que c’est? Parfait! Jean-François Lessard, Paméla Bérubé, CRHA et Anna Potvin vont t'expliquer le tout.

https://lnkd.in/eWmbc_Ee | 16 | 1 | 0 | 5mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.459Z |  | 2025-06-20T15:33:35.969Z | https://www.linkedin.com/feed/update/urn:li:activity:7341848458296786944/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7338226706589143040 | Video (LinkedIn Source) | blob:https://www.linkedin.com/eb736900-b0a7-4db4-8951-765cfeac355e | https://media.licdn.com/dms/image/v2/D4E05AQEiQ_LXJ4gFAQ/videocover-high/B4EZdaWSMlHcBk-/0/1749567500753?e=1765774800&v=beta&t=3iafn9BjYzxKtW1AOWKfi7hoS883OTMxfRXprZ1vjCg | Sydney Wingender Toronto for Tech Week to present Tedy at Google Demo Day. Feel free to stop by, we’re happy to meet new partners, potential clients, and of course, investors. DM us! | 16 | 1 | 0 | 5mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.460Z |  | 2025-06-10T15:33:04.510Z | https://www.linkedin.com/feed/update/urn:li:activity:7338218005077639169/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7320440983802810368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEV1lTEZysolA/feedshare-shrink_800/B4EZZduRuCHYAo-/0/1745329136414?e=1766620800&v=beta&t=h-VNpBknbTaTFEPDI9w-adcu5RiDiYt6W3ZGcAuj_oI | 🔥 Super proud to share that Tedy is part of the 2025 Google for Startups Accelerator: Canada cohort! 🇨🇦

We’re already using AI to process thousands of claims every month—but this takes it to a whole new level:
 👉 Smarter benefits
 👉 Real-time personalization for teams
 👉 Redefining wellness at work, the 2025 way

Big thanks to the Google team for the vote of confidence. Can’t wait to show what we’re building. Let’s go. 💥 | 95 | 13 | 0 | 7mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.461Z |  | 2025-04-22T13:38:57.755Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7312856374244265986 | Video (LinkedIn Source) | blob:https://www.linkedin.com/acc13a50-9496-4fb2-892e-d4e0ea8d30c4 | https://media.licdn.com/dms/image/v2/D4E05AQFPtOYXVipbkA/videocover-high/B4EZXx72nCHgBw-/0/1743520787566?e=1765774800&v=beta&t=GMPhec2WoZcAZbujyeM8xLCKbhKUk3kUJCzQiBrB3OE | 💥 Donnée choc : chaque dollar investi dans un PAE (programme d’aide aux employés) génère 3 $ en retour. Oui oui, c’est mesuré et pas juste de la théorie !
Paméla Bérubé, CRHA chez Huni PAE (l’un de nos partenaires clés en mieux-être sur demande chez Tedy), s’est prêtée au jeu et a répondu en 100 secondes (ou presque!) aux questions que tout le monde se pose sur les PAE. 🎤 | 31 | 1 | 2 | 8mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.461Z |  | 2025-04-01T15:20:25.921Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7310724975630405633 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5c133789-8e43-4168-adb7-620c395e643d | https://media.licdn.com/dms/image/v2/D4E05AQE3ZCKl_GOqQA/videocover_350_624/B56ZYQYnx5GcAE-/0/1744031612154?e=1765774800&v=beta&t=mnPynyZd0o8iCSXZKd4K8moyuWiVck7Xps4XRxQColA | 🚨 Alerte Webinaire : Rémunération & mieux-être avec la gang de Go RH et Tedy. Vous êtes pro RH, en finance ou dirigeant? Ce webinaire va vraiment vous interpeller: du concret, des pistes d’action, et une nouvelle façon de penser la rémunération.

🎟️ Inscrivez-vous maintenant (places limitées) :
 👉 https://lnkd.in/eBpECGTM | 13 | 1 | 0 | 8mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.462Z |  | 2025-03-26T18:11:00.892Z | https://www.linkedin.com/feed/update/urn:li:activity:7310720323706847232/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7307432413859577856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFOmWFAGmNBuA/feedshare-shrink_800/B4EZWfr0eDH0Ag-/0/1742140821244?e=1766620800&v=beta&t=ib8Ytlh5piuunCvgZmdB-oFoan0WsFOLwrHA1Wf-Rsc | Je crois que vouloir à tout prix viser l’excellence est une utopie dans le monde des affaires d’aujourd’hui. Je préfère le"pace", la vitesse, mais enveloppés d’une solide couche de culture à échelle humaine et d’une éthique irréprochable. 🦚 Axel Øreste | 5 | 0 | 0 | 8mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.463Z |  | 2025-03-17T16:07:32.993Z | https://www.linkedin.com/feed/update/urn:li:activity:7307362567339864064/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7303126929904226306 | Article |  |  | «Il y a une certaine forme d’allergie à la manière que les choses sont faites aux États-Unis. [...] On a toujours dit qu’on était une société distincte, on peut l’être aussi dans la manière de faire des affaires». Mon 2 cents au JDM / TVA, j'y crois. 💪 | 8 | 0 | 0 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.463Z |  | 2025-03-05T18:59:05.626Z | https://www.journaldemontreal.com/2025/03/03/de-la-bienveillance-a-la-performance--des-entreprises-etablies-ici-influencees-par-le-modele-americain |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7303091499192233984 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0d74b652-7d2f-4e78-b538-2520984309e8 | https://media.licdn.com/dms/image/v2/D4E05AQFuz4yhMXXZXQ/videocover-high/B4EZVnK9KoGgBs-/0/1741192688763?e=1765774800&v=beta&t=XtmVCBtUZ6EX5ATSN-OuaHxL0Jd3ReT4ysjtYc5ute0 | Tu ne veux pas dormir la nuit? Parfait, mets-toi en mode entrepreneur et pense au coût de ton prochain payroll pendant que ta business scale 🚀.  Crois moi tu vas rester réveillé(e). J’en ai jasé avec 🦚 Axel Øreste Øreste de HackCell. 

C’est justement pour ça que Tedy existe : donner de l’oxygène aux employés et aussi au compte de banque de l’entreprise avec plus de certitude. 

🎧  Épisode complet ici : https://lnkd.in/e5vFzkDX | 16 | 2 | 1 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.464Z |  | 2025-03-05T16:38:18.286Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7302753040392966144 | Video (LinkedIn Source) | blob:https://www.linkedin.com/94c47742-2dd3-489f-8c2f-e545e1941734 | https://media.licdn.com/dms/image/v2/D4E05AQElhZeAGoGEPA/videocover-high/B4EZVhkKXNGgBw-/0/1741098640093?e=1765774800&v=beta&t=yVz389M9IMoyXO9rP-YfaKw6kdLX2J1qf9WaReqQBK0 | La qualité de la question dicte la qualité de la réponse. Shoutout à 🦚 Axel Øreste le culture "fixer". | 5 | 1 | 0 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.465Z |  | 2025-03-04T18:13:23.420Z | https://www.linkedin.com/feed/update/urn:li:activity:7302738361788579841/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7300987768661323776 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d70d0572-56e1-475e-85f1-9a66aa6d101c | https://media.licdn.com/dms/image/v2/D4E05AQFABwZfVJMIPQ/videocover-high/B4EZVH5_adGwB4-/0/1740668146686?e=1765774800&v=beta&t=plfaye_U_4Bu6pcNW__9ity5ff-MVpHEerARbU8E7nc | 😱 OMG! Quelles questions de fou de la part de 🦚 Axel Øreste, surtout la première qui est digne de Contra sans le Konami code (les OG vont comprendre la référence). Je suis allé dans ce podcast en mode cold turkey, real time, zéro BS et surtout vrai. Merci HackCell, William Carrier, pour ce moment. 🔥 

Bon! Allez checker ça et commenter mon hoodie léopard : https://lnkd.in/eDNYvx2j | 19 | 4 | 0 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.468Z |  | 2025-02-27T21:18:49.842Z | https://www.linkedin.com/feed/update/urn:li:activity:7300891424814714881/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7295907724272230401 | Text |  |  | Truth hurts… especially for SMB wallets. Here’s how Tedy is fixing HSAs in Canada, no commissions, no hassle, just smarter benefits. 🚀 | 7 | 1 | 0 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.469Z |  | 2025-02-13T20:52:32.877Z | https://www.linkedin.com/feed/update/urn:li:activity:7295844365015437312/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7295486328656318464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2bbe6934-4d29-481c-bdc3-ae4919cd5ece | https://media.licdn.com/dms/image/v2/D4E10AQFva_YsDs8NrQ/ads-video-thumbnail_720_1280/B4EZT6ajhCGwAc-/0/1739368053473?e=1765774800&v=beta&t=dRU736z9VBoJqlieUo0GEoA5nNW20EyNdygNkm9aUCw | Had a blast talking business, culture, and what truly drives people with a very inspiring Jeremiah Curvers on the #UpAtNightPodcast .

For me, Tedy—and everything my partners and I build—is the result of a very looooooooong and sometimes complex equation. One that’s constantly solving for what makes people happy, engaged, and inspired to carry the fire at the workplace. ❤️‍🔥 🔥 💪 

🎧 https://vist.ly/3mu65np | 15 | 2 | 0 | 9mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.470Z |  | 2025-02-12T16:58:04.333Z | https://www.linkedin.com/feed/update/urn:li:activity:7295438592997249025/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7292929695694610433 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7b6821f0-e9ac-495d-9191-2c86ac008e47 | https://media.licdn.com/dms/image/v2/D4E05AQFOorbcz2U9hw/videocover-low/B4EZTWw4oQGgCM-/0/1738769931060?e=1765774800&v=beta&t=ADFqUjwHalV8Pur_wsMCovyJCsqTZwOWkM0a1JSO3jo | 🔓 Unlock: The Workplace Benefits Disconnect – Full Report 🇨🇦

Most companies think their benefits are great. Employees? Not so much.

We surveyed 250 employees & 200 employers across Canada to uncover the truth about workplace benefits, what’s working, what’s wasted, and what employees really want.

🔍 What’s inside?
✅ Why a majority prefer flexible spending over a salary increase
✅ The top mistakes HR teams are making with benefits
✅ How modern benefits can improve retention & cut costs

Want access to the full report?
✔️ Like this post
✔️ Connect with me (so I can DM it to you)
✔️ Comment "BENEFITS STUDY" below

I’ll send it directly to your DMs today! 

Tedy #EmployeeBenefits #HR #FutureOfWork #ModernCompensation #WorkplaceWellness | 17 | 1 | 2 | 10mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.471Z |  | 2025-02-05T15:38:55.535Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7292581740953391105 | Poll |  |  | We’re exploring a smart wallet that helps employees prioritize Canadian products when using their benefits. Would you use a ‘Buy Canadian’ wallet at work? Tedy | 9 | 4 | 0 | 10mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.471Z |  | 2025-02-04T16:36:16.660Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7289722274004254720 | Text |  |  | Benefits have a cost, workplace culture is free.


One of the most important lessons I have learned as a CEO is to establish a strong culture before allowing finances to dictate it. It can be challenging for small businesses, but the benefits appear sooner than you might expect.

In my previous venture, I only introduced formal benefits after we reached 12 employees (traditional ones, at that). Surprisingly, no one was clamoring for them because they already felt appreciated through close management, meaningful projects, and genuine freedom. It turns out that creating a positive culture does not cost a cent; money simply amplifies what is already there.

My advice is to avoid waiting for large budgets or elaborate perks before building a genuine culture. Start now, and when you do implement benefits, ensure they enhance your core values rather than replace them. That's why we built Tedy and believe we can democratize benefits and recognition for all SMBs across the country. 💪 | 14 | 0 | 1 | 10mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.472Z |  | 2025-01-27T19:13:46.613Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7289652281640198145 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ecd2622e-81a7-4270-a2a7-6444f4fd31d8 | https://media.licdn.com/dms/image/v2/D4E05AQFogSYcgUQ7LQ/videocover-high/B4EZSoKvNqHgBw-/0/1737988181727?e=1765774800&v=beta&t=GNgDKXfe1hRsTIGuW6M-udR9LkxP7mSyBfRkfbjiMAQ | Sometimes, I feel like the more AI there is out there, the more it’s used for things with little to no real impact. My colleague, Sydney Wingender, shares his thoughts on AI and employee benefits. ⤵️ | 3 | 0 | 0 | 10mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.473Z |  | 2025-01-27T14:35:39.133Z | https://www.linkedin.com/feed/update/urn:li:activity:7289650824710897664/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7288228084309245952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0a688e99-d13b-46de-8a41-01d25f44e495 | https://media.licdn.com/dms/image/v2/D5605AQFiV4vgGHOYXg/videocover-high/B56ZST5uvVGoBs-/0/1737648182057?e=1765774800&v=beta&t=8s-btAzfPn_8cEpcjpSWURbwHExgrLAmQSXAUfCLZSU | Tellement vrai. La master twist des augmentations salariales 101 avec Jean-François Lessard. 🤘🤘🤘 | 9 | 0 | 1 | 10mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.473Z |  | 2025-01-23T16:16:24.029Z | https://www.linkedin.com/feed/update/urn:li:activity:7288224747597836288/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7275198314092888064 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d07e7207-716d-40a0-b405-20a1f577ba8a | https://media.licdn.com/dms/image/v2/D4E05AQHryi5IP89SgQ/videocover-high/B4EZPawM7cHABs-/0/1734541926867?e=1765774800&v=beta&t=aroGUmx1LRWPqDWNnq6Dc9F2g1BqWGoTHUHEWA3XkVI | Quel est le plus grand problème des avantages sociaux en 2024 et 2025 ? Une chose est sûre : avec Tedy, le problème est déjà réglé. 👇 | 93 | 10 | 2 | 11mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.474Z |  | 2024-12-18T17:20:44.728Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7273063239867936770 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c96e2416-e027-44db-8536-c4b41cb9726e | https://media.licdn.com/dms/image/v2/D4E05AQETyS4hTQOGUQ/videocover-high/B4EZO8cXRzHABw-/0/1734033384020?e=1765774800&v=beta&t=CW_ivtyUOldzrlE_O6129SaycoxT-mFI1SM2XLu-Bbo | Can you guess the most popular category, vendor, or travel destination on Tedy this year? 

Inspired by the annual Spotify Wrapped, we decided to create our own version for Tedy—and wow, what a year it’s been!

This journey with Tedy has been nothing short of extraordinary. Challenging, rewarding, and downright exhilarating. I’ve never felt so engaged and energized in my professional life. Stay tuned to see what made the top of the list. | 46 | 9 | 0 | 11mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.475Z |  | 2024-12-12T19:56:43.365Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7272698141760438273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEC8TxPk16-JA/feedshare-shrink_800/feedshare-shrink_800/0/1733945440626?e=1766620800&v=beta&t=BGiQ1-MdcCDMB4SPXiL2-GO9hmT18KuQlPzQIB1aUKs | Feeling incredibly proud to share that Tedy has been recognized as one of the recipients of the 2024 AQT Young Companies Program Grant! 🎉

Grateful to be part of a community driving innovation and redefining workplace wellness. Excited for what’s ahead! 🚀 | 37 | 5 | 0 | 11mo | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.475Z |  | 2024-12-11T19:45:57.193Z | https://www.linkedin.com/feed/update/urn:li:activity:7272694330274861056/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7270132488729964544 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGJsWsnLuSbyg/feedshare-shrink_2048_1536/feedshare-shrink_2048_1536/0/1733329542702?e=1766620800&v=beta&t=PmDwEApAj3Ph0ZueJ29semgFqBWqhB6WBpLu04sp_Mg | Critical times call for critical decisions. Let’s talk raises, shall we? Check out Work in Progress Magazine by Tedy. 👇👇👇 | 4 | 0 | 0 | 1yr | Post | Pablo Stevenson | https://www.linkedin.com/in/pablostevenson | https://linkedin.com/in/pablostevenson | 2025-12-08T04:56:35.476Z |  | 2024-12-04T17:50:57.843Z | https://www.linkedin.com/feed/update/urn:li:activity:7270111060332814338/ |  | 

---



---

# Pablo Stevenson
*Tedy*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Tedy - Our story](https://www.tedy.app/story)
*2025-01-01*
- Category: article

### [Pablo Stanley: A creative force of nature on the importance persistence and hustle](https://podcasts.apple.com/gm/podcast/pablo-stanley-a-creative-force-of-nature-on/id1266839739?i=1000655540870)
*2024-05-14*
- Category: podcast

### [Meet Tedy: The Canadian startup transforming employee benefits that cover everything from pet food to concert tickets](https://www.thestar.com/sponsored-sections/meet-tedy-the-canadian-startup-transforming-employee-benefits-that-cover-everything-from-pet-food-to/article_9ef33658-0ee4-11ef-8445-afaefcc80414.html)
*2024-05-14*
- Category: article

### [About - Pablo Stanley](https://pablostanley.substack.com/about)
*2024-12-26*
- Category: blog

### [Life As A Remote Designer: A conversation with Pablo Stanley](https://maze.co/blog/pablo-stanley-interview/)
*2024-05-23*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 11,477 words total*

### Tedy - Our story
*374 words* | Source: **EXA** | [Link](https://www.tedy.app/story)

[](https://www.tedy.app/?r=0)

en

We modernise the employee experience and make you a better employer
-------------------------------------------------------------------

Just like you, we are entrepreneurs and company culture geeks that love people and businesses that care. Wellness, benefits and recognition is not nice simply to have. Based on our very own employer journey at different companies we converged in the same goal of providing tools that will make employers better, and employers happier.

![Image 1: Three of Tedy's founders smilig](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692b_TEDY-2846%20(2).webp)

![Image 2: Pablo Stevenson smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692a_Pablo.webp)

Pablo Stevenson
---------------

As former CEO and founder of a well-known digital agency, Pablo led the acquisition of his company by one of Canada's research giants. During his 17-year tenure, he cultivated a culture of growth that earned him three consecutive appearances on the prestigious Growth 500 list and two rankings among the best places to work in Canada. Drawing on his extensive expertise in corporate culture and growth, Pablo is now propelling Tedy to the next level.

[Connect](https://www.linkedin.com/in/pablostevenson/)

![Image 3: Sydney Wingender smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb9006929_Sydney.webp)

Sydney Wingender
----------------

With a decade of experience in product design and user experience, Sydney boasts a track record of data-driven solutions for the political world and marketing agencies. Currently, he is leading Tedy's product and technology vision to create a fully automated, highly personalized platform. Sydney is a regular speaker and contributor to podcasts, covering topics ranging from technology to culture and growth.

[Connect](https://www.linkedin.com/in/sydneywingender/)

![Image 4: JF Lessard smiling
](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692c_JF.webp)

JF Lessard
----------

JF is a seasoned entrepreneur with 15 years' experience in sales and marketing. He is also co-founder of a major player in the Canadian media landscape. After a successful exit from the media world (a lifestyle news website), JF played a key role in the franchise expansion of fast food companies and is a strategic reference when it comes to SMEs and their needs.

[Connect](https://www.linkedin.com/in/jean-fran%C3%A7ois-lessard/)

Thank you! Your submission has been received!

Oops! Something went wrong while submitting the form.

Schedule a demo

How about a little virtual coffee? Discover how Tedy can boost your benefits and energize your corporate culture.

View the Tedy discovery demo

Add your information and receive a viewing link instantly.

Schedule a demo

How about a little virtual coffee? Discover how Tedy can boost your benefits and energize your corporate culture.

---

### Pablo Stanley: A creative force of nature on the importance persistence and hustle
*1,750 words* | Source: **EXA** | [Link](https://podcasts.apple.com/gm/podcast/pablo-stanley-a-creative-force-of-nature-on/id1266839739?i=1000655540870)

Pablo Stanley: A creative forc…–Design Better – Apple Podcasts

===============

[](https://podcasts.apple.com/gm/new)

*   [Home](https://podcasts.apple.com/gm/home)
*   [New](https://podcasts.apple.com/gm/new)
*   [Top Charts](https://podcasts.apple.com/gm/charts)
*   [Search](https://podcasts.apple.com/gm/search)

Open in Podcasts

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

![Image 1: Design Better](https://podcasts.apple.com/assets/artwork/1x1.gif)

*   14/05/2024
*   S10, E97
*   18 MIN

Pablo Stanley: A creative force of nature on the importance persistence and hustle
==================================================================================

[Design Better](https://podcasts.apple.com/gm/podcast/design-better/id1266839739)

 Play 

_Get access to the full episode, show notes, transcript and more on our Substack:_ _https://designbetterpodcast.com/p/pablo-stanley_

Pablo Stanley’s creativity seemingly knows no bounds. Constant doodling is a key to his creative process, and has spawned countless projects including web comics like The Design Team and Stanley and Rupert, an illustration generation platform called Blush, and most recently Bueno, a platform that lets people build virtual worlds. Pablo makes us all feel like slackers!

We spoke with Pablo about his childhood in Mexico and how it influences his creativity, the wide array of creative projects he’s working on, and the importance of persistence and hustle when you’re earning a creative living independently.

Bio

Pablo Stanley is a Co-founder at Musho—AI Designer,Blush, and Lummi—tools to unlock people's creativity. He’s also working on Bueno, and previously made Robotos, Humankind, Transhumans, Humaaans, Open Peeps, etc . Previously he was was a Lead at InVision, a Staff Designer at Lyft, and co-founder of Carbon Health. He gives design workshops and shares design tutorials on YouTube. He also writes a comic- _The Design Team._

Premium Episodes on Design Better

This is a premium episode on Design Better (learn more in the announcement here). We’ll be releasing two premium episodes per month, along with two free episodes for everyone. Premium subscribers also get access to our monthly AMAs with former guests, ad-free episodes, and our new enhanced newsletter _The Brief_ that compiles salient insights, quotes, readings, and creative processes uncovered in the show.

Upgraid to paid

Visiting the links below is one of the best ways to support our show:

**Methodical Coffee:** Roasted, blended, brewed, served and perfected by verified coffee nerds 🤓. We have our very own Design Better roast at Methodical, grab some here to fuel your creativity: https://methodicalcoffee.com/products/design-better-coffee

**Crashplan:**You may have heard horror stories of people being locked out of their Apple or Google accounts, and losing decades worth of precious files like family photos. That’s why we’ve been using Crashplan for a decade and a half now to back up all of our important files. Visit Crashplan.com/DESIGNBETTER for 50% off your first year of CrashPlan.

**Uplift Desks:**For people like us who spend countless hours at our desk, ergonomics are an essential consideration. A standing desk from Uplift Desk can help you avoid the negative effects of sitting all day by improving circulation and reducing strain. Design Better can get a special deal by visiting UPLIFTDesk.com. **Use the code DESIGNBETTER5 at checkout for 5% off your order.** Free shipping, free returns, and an industry-leading 15-year warranty. They’re a great company.

**Gusto:**We’re big fans of Gusto, who make it easy to run payroll, set up healthcare and other benefits for your business. They’ve made setting up the HR infrastructure for Design Better a breeze. Gusto is also one of the best designed SaaS tools out there.

Design Better listeners get 3 months free once they run their first payroll - Go to **gusto.com/designbetter**to sign up.

If you're interested in sponsoring the show, please contact us at: sponsors@thecuriositydepartment.com

If you'd like to submit a guest idea, please contact us at: contact@thecuriositydepartment.com

[Episode Webpage](https://designbetterpodcast.com/p/pablo-stanley)

Hosts & Guests
--------------

*   [### Aarron Walter Host](https://podcasts.apple.com/gm/browse)   
*   [### Eli Woolery Host](https://podcasts.apple.com/gm/browse)   

Information
-----------

*   Show [Design Better](https://podcasts.apple.com/gm/podcast/design-better/id1266839739) 
*   Frequency Updated weekly 
*   Published 14 May 2024 at 11:00 UTC 
*   Length 18 min 
*   Season 10 
*   Episode 97 
*   Rating Clean 

Gambia

Select a country or region

Africa, Middle East, and India
------------------------------

See All 

*   [Algeria](https://podcasts.apple.com/dz/new)
*   [Angola](https://podcasts.apple.com/ao/new)
*   [Armenia](http

*[... truncated, 21,156 more characters]*

---

### Meet Tedy: The Canadian startup transforming employee benefits that cover everything from pet food to concert tickets
*3,250 words* | Source: **EXA** | [Link](https://www.thestar.com/sponsored-sections/meet-tedy-the-canadian-startup-transforming-employee-benefits-that-cover-everything-from-pet-food-to/article_9ef33658-0ee4-11ef-8445-afaefcc80414.html)

Meet Tedy: The Canadian startup transforming employee benefits that cover everything from pet food to concert tickets

===============
[Skip to main content](https://www.thestar.com/sponsored-sections/meet-tedy-the-canadian-startup-transforming-employee-benefits-that-cover-everything-from-pet-food-to/article_9ef33658-0ee4-11ef-8445-afaefcc80414.html#main-page-container)

You have permission to edit this article.

[Edit](https://www.thestar.com/tncms/admin/editorial-asset/?edit=9ef33658-0ee4-11ef-8445-afaefcc80414)Close

Log In

[![Image 1: Proudly Canadian Owned Logo](https://bloximages.chicago2.vip.townnews.com/thestar.com/content/tncms/live/libraries/flex/components/media2/resources/images//proudly-canadian/proudly-canadian-owned.png?_dc=1764181962)](https://www.thestar.com/about/)

*   [-8°|Monday, Dec. 8](https://www.thestar.com/weather/?weather_zip=M7A1A2)
*   [**Play Now! $75M****+ $12MM**![Image 2: OLG Lottery](https://bloximages.chicago2.vip.townnews.com/thestar.com/content/tncms/assets/v3/editorial/9/62/962391b6-a783-4f5d-90fb-e2b416f33559/685808027fb7b.preview.png)](https://www.olg.ca/en/lottery/play-lotto-max-encore/about.html?utm_source=F26_National_LMAX_ONP_TorStar_NavBar&utm_medium=TorStar_NavBar)

Site search Search

[Newsletters](https://www.thestar.com/newsletters/?itm_source=newsletter-header-link)

[Today's paper](https://www.thestar.com/subscribe/epaper/)

[Home](https://www.thestar.com/)

*   [Ryan Wedding](https://www.thestar.com/news/crime/ryan-wedding/)
*   [Cookie week](https://www.thestar.com/life/cookies/)
*   [One Great Idea](https://www.thestar.com/one-great-idea/)
*   [Holiday](https://www.thestar.com/holiday/)

[GTA](https://www.thestar.com/news/gta/)

*   [Readers’ Choice Awards](https://best-businesses.thereaderschoice.ca/o/toronto/readers-choice-2025-nominations)
*   [Shopping and Services](https://www.thestar.com/shopping-and-services/)

[Canada](https://www.thestar.com/news/canada/)

*   [Ontario](https://www.thestar.com/news/ontario/)
*   [British Columbia](https://www.thestar.com/news/canada/british-columbia/)
*   [Alberta](https://www.thestar.com/news/canada/alberta/)
*   [Quebec](https://www.thestar.com/news/canada/quebec/)
*   [Nova Scotia](https://www.thestar.com/news/canada/nova-scotia/)

[Politics](https://www.thestar.com/politics/)

*   [Federal Politics](https://www.thestar.com/politics/federal/)
*   [Provincial Politics](https://www.thestar.com/politics/provincial/)
*   [Political Opinion](https://www.thestar.com/politics/political-opinion/)

[World](https://www.thestar.com/news/world/)

*   [United States](https://www.thestar.com/news/world/united-states/)
*   [Americas](https://www.thestar.com/news/world/americas/)
*   [Europe](https://www.thestar.com/news/world/europe/)
*   [Asia](https://www.thestar.com/news/world/asia/)
*   [Africa](https://www.thestar.com/news/world/africa/)
*   [Australia](https://www.thestar.com/news/world/australia/)
*   [Middle East](https://www.thestar.com/news/world/middle-east/)

[Opinion](https://www.thestar.com/opinion/)

*   [Star Columnists](https://www.thestar.com/opinion/star-columnists/)
*   [Editorials](https://www.thestar.com/opinion/editorials/)
*   [Contributors](https://www.thestar.com/opinion/contributors/)
*   [Letters To The Editor](https://www.thestar.com/opinion/letters-to-the-editor/)
*   [Editorial Cartoons](https://www.thestar.com/opinion/editorial-cartoons/)

[Life](https://www.thestar.com/life/)

*   [Relationships](https://www.thestar.com/life/relationships/)
*   [Food and Drink](https://www.thestar.com/life/food-and-drink/)
*   [Travel](https://www.thestar.com/life/travel/)
*   [Beauty and Fashion](https://www.thestar.com/life/beauty-and-fashion/)
*   [Royals](https://www.thestar.com/news/world/royals/)
*   [Health](https://www.thestar.com/life/health-wellness/)
*   [Home and Garden](https://www.thestar.com/life/home-and-garden/)
*   [Autos](https://www.thestar.com/life/autos/)
*   [Horoscopes](https://www.thestar.com/life/horoscopes/)
*   [Obituaries](https://obituaries.thestar.com/)

[Sports](https://www.thestar.com/sports/)

*   [NHL](https://www.thestar.com/sports/hockey/)
*   [PWHL](https://www.thestar.com/sports/hockey/pwhl/)
*   [NBA](https://www.thestar.com/sports/basketball/)
*   [MLB](https://www.thestar.com/sports/baseball/)
*   [NFL](https://www.thestar.com/sports/football/)
*   [CFL](https://www.thestar.com/sports/football/cfl/)
*   [Sports Betting](https://www.thestar.com/sports/sports-betting/)
*   [Golf](https://www.thestar.com/sports/golf/)
*   [Soccer](https://www.thestar.com/sports/soccer/)
*   [Tennis](https://www.thestar.com/sports/tennis/)
*   [Auto Racing](https://www.thestar.com/sports/auto-racing/)
*   [Cricket](https://www.thestar.com/sports/cricket/)
*   [Olympics and Paralympics](https://www.thestar.com/sports/olympics-and-paralympics/)

[Real Estate](https://www.thestar.com/real-estate/)

[Entertainment](https://www.thestar.com/entertainment/)

*   [Events](https://www.thestar.co

*[... truncated, 67,224 more characters]*

---

### About - Pablo Stanley
*92 words* | Source: **EXA** | [Link](https://pablostanley.substack.com/about)

Why subscribe?
--------------

Subscribe to get full access to the newsletter and [publication archives](https://pablostanley.substack.com/archive).

### Stay up-to-date

Never miss an update—every new post is sent directly to your email inbox. For a spam-free, ad-free reading experience, plus audio and community features, [get the Substack app](https://substack.com/app/app-store-redirect).

### Join the crew

Be part of a community of people who share your interests. Participate in the comments section, or support this work with a subscription.

_To learn more about the tech platform that powers this publication, visit [Substack.com](https://www.substack.com/)._

### People

[![Image 1: Pablo Stanley's avatar](https://substackcdn.com/image/fetch/$s_!Qzpx!,w_64,h_64,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F44048a05-76d3-48f5-9462-654fc420b826_1200x1200.png)](https://substack.com/@pablostanley?utm_source=about-page)

---

### In the Loop by Maze | Company Blog
*667 words* | Source: **EXA** | [Link](https://maze.co/blog/pablo-stanley-interview/)

In the Loop by Maze | Company Blog

===============

![Image 1: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Accept All

Customize Consent Preferences![Image 2: Close](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

For more information on how Google's third-party cookies operate and handle your data, see:[Google Privacy Policy](https://business.safety.google/privacy)

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

Performance

- [x] 

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

Advertisement

- [x] 

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

Uncategorized

- [x] 

Other uncategorized cookies are those that are being analyzed and have not been classified into a category as yet.

Save My Preferences Accept All

New Event: Fall 2025 Product Roundup—our latest features designed to help you find faster, build smarter, and scale with research-grade AI

[Register Now](https://maze.co/events/fall-2025-product-roundup/)

[](https://maze.co/)

Platform

[Maze Platform Connect everyone to users with our end-to-end research platform ![Image 3](blob:http://localhost/f4af5481f277fce0ef5777ccac4a720d) ![Image 4](blob:http://localhost/6a498e77b01900f2b770970a876bd42d)![Image 5](https://www.datocms-assets.com/38511/1762727273-promo-card-platform.jpg?auto=format&fit=max&w=320)](https://maze.co/platform/)

[Integrations](https://maze.co/integrations/)

[](https://maze.co/integrations/figma/)[](https://help.maze.co/hc/en-us/articles/6040216807315-Embedding-maze-reports-in-third-party-tools)[](https://maze.co/integrations/slack/)[](https://maze.co/integrations/zoom/)

Recruit participants

[Panel](https://maze.co/features/research-panel/)[In-Product Prompt](https://maze.co/features/in-product-prompts/)[Participant management](https://maze.co/platform/reach/)

Build & Research

[AI Moderator New](https://maze.co/features/ai-moderator/)[Prototype Testing](https://maze.co/features/prototype-testing/)[Moderated Interviews](https://maze.co/features/interview-studies/)[Surveys](https://maze.co/features/surveys/)[Live Website Testing](https://maze.co/features/live-website-testing/)[Mobile Testing](https://maze.co/features/mobile-testing/)

Analyze & Learn

[Automated Reports](https://maze.co/platform/ux-reporting/)[Maze AI](https://maze.co/ai/)[Video Clips](https://maze.co/features/clips-video-recordings/)

Solutions

[Templates Choose from our library of pre-built mazes to copy, customize, and share ![Image 7](blob:http://localhost/f4af5481f277fce0ef5777ccac4a720d) ![Image 8](blob:http://localhost/9c4350e224db51eff0304c21fbe82147)![Image 9](https://www.datocms-assets.com/38511/1762727280-promo-card-template.jpg?auto=format&fit=max&w=320)](https://maze.co/templates/)

Use Cases

[Concept Validation](https://maze.co/use-cases/concept-and-idea-validation/)[Usability Testing](https://maze.co/use-cases/wireframe-and-usability-testing/)[Copy Feedback](https://maze.co/use-cases/content-and-copy-testing/)[User Satisfaction](https://maze.co/use-cases/feedback-and-satisfaction/)

Industries

[Financial Services](https://maze.co/industry/financial-services/)[Tech & Software](https://maze.co/industry/tech/)[Insurance](https://maze.co/industry/insurance/)

Roles

[Researchers](https://maze.co/roles/user-researchers/)[Designers](https://maze.co/roles/product-designers/)[Product Managers](https://maze.co/roles/product-managers/)

Resources

[Content Hub Resources for product, research, and design teams ![Image 11](blob:http://localhost/f4af5481f277fce0ef5777ccac4a720d) ![Image 12](blob:http://localhost/661d284fbc00c58524acddee01d7ef3c)![Im

*[... truncated, 5,871 more characters]*

---

### Tedy - Our story
*374 words* | Source: **GOOGLE** | [Link](https://tedy.app/story)

[](https://www.tedy.app/?r=0)

en

We modernise the employee experience and make you a better employer
-------------------------------------------------------------------

Just like you, we are entrepreneurs and company culture geeks that love people and businesses that care. Wellness, benefits and recognition is not nice simply to have. Based on our very own employer journey at different companies we converged in the same goal of providing tools that will make employers better, and employers happier.

![Image 1: Three of Tedy's founders smilig](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692b_TEDY-2846%20(2).webp)

![Image 2: Pablo Stevenson smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692a_Pablo.webp)

Pablo Stevenson
---------------

As former CEO and founder of a well-known digital agency, Pablo led the acquisition of his company by one of Canada's research giants. During his 17-year tenure, he cultivated a culture of growth that earned him three consecutive appearances on the prestigious Growth 500 list and two rankings among the best places to work in Canada. Drawing on his extensive expertise in corporate culture and growth, Pablo is now propelling Tedy to the next level.

[Connect](https://www.linkedin.com/in/pablostevenson/)

![Image 3: Sydney Wingender smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb9006929_Sydney.webp)

Sydney Wingender
----------------

With a decade of experience in product design and user experience, Sydney boasts a track record of data-driven solutions for the political world and marketing agencies. Currently, he is leading Tedy's product and technology vision to create a fully automated, highly personalized platform. Sydney is a regular speaker and contributor to podcasts, covering topics ranging from technology to culture and growth.

[Connect](https://www.linkedin.com/in/sydneywingender/)

![Image 4: JF Lessard smiling
](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692c_JF.webp)

JF Lessard
----------

JF is a seasoned entrepreneur with 15 years' experience in sales and marketing. He is also co-founder of a major player in the Canadian media landscape. After a successful exit from the media world (a lifestyle news website), JF played a key role in the franchise expansion of fast food companies and is a strategic reference when it comes to SMEs and their needs.

[Connect](https://www.linkedin.com/in/jean-fran%C3%A7ois-lessard/)

Thank you! Your submission has been received!

Oops! Something went wrong while submitting the form.

Schedule a demo

How about a little virtual coffee? Discover how Tedy can boost your benefits and energize your corporate culture.

View the Tedy discovery demo

Add your information and receive a viewing link instantly.

Schedule a demo

How about a little virtual coffee? Discover how Tedy can boost your benefits and energize your corporate culture.

---

### Tedy - L'équipe qui propulse Tedy
*451 words* | Source: **GOOGLE** | [Link](https://tedy.app/fr/story)

[](https://www.tedy.app/fr)

fr

Nous modernisons l'expérience des vos employés et faisons de vous un meilleur employeur
---------------------------------------------------------------------------------------

Nous sommes des entrepreneurs et des passionnés (lire _geeks_) de culture d'entreprise. Les entreprises qui placent leurs employés au cœur de leurs préoccupations et qui font preuve de bienveillance représentent notre plus grande source d'inspiration. Forts de nos propres expériences en tant qu'employeurs et employés dans diverses organisations, on s'est ralliés sous un même objectif : offrir aux PME une plateforme qui rendra les employeurs meilleurs.

![Image 1: Three of Tedy's founders smilig](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692b_TEDY-2846%20(2).webp)

![Image 2: Pablo Stevenson smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692a_Pablo.webp)

Pablo Stevenson
---------------

En tant qu'ancien PDG et fondateur d'une agence numérique de premier plan, Pablo a mené l'acquisition de son entreprise par l'un des leaders de la recherche au Canada. Au long de ses 17 années à la barre, il a établi une culture de croissance distinguée, récompensée par trois apparitions consécutives sur la liste emblématique Growth 500 et deux nominations parmi les meilleurs lieux de travail au Canada. Passionné de culture organisationnelle, il a pour mission de faire de Tedy une plateforme incontournable pour les PME d'ici.

[Connecter](https://www.linkedin.com/in/pablostevenson/)

![Image 3: Sydney Wingender smiling](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb9006929_Sydney.webp)

Sydney Wingender
----------------

Fort de près de 10 ans d'expertise en développement de produits numériques et en expérience utilisateur, Sydney s'est distingué par la création de solutions innovantes axées sur les données pour des partis politiques et le secteur privé. Il chapeaute actuellement la vision produit et technologique de Tedy pour en faire une plateforme entièrement automatisée et hautement personnalisée. Sydney est un conférencier régulier et contribue fréquemment à des podcasts, couvrant des sujets qui allient technologie et culture d'entreprise.

[Connecter](https://www.linkedin.com/in/sydneywingender/)

![Image 4: JF Lessard smiling
](https://cdn.prod.website-files.com/65f88d817325f02fb900683c/65f88d817325f02fb900692c_JF.webp)

JF Lessard
----------

JF est un entrepreneur expérimenté avec une solide expertise de 15 ans en ventes et marketing. Co-fondateur d'une plateforme phare dans l'édition numérique, il a brillamment mené son acquisition par un acteur majeur du secteur médiatique. Par la suite, JF a joué un rôle déterminant dans l'expansion de franchises de restauration rapide, devenant ainsi une référence stratégique essentielle pour ces dernières. JF fait preuve de connaissances hors-pair pour bien comprendre les besoins et les realités des PME de chez nous.

[Connecter](https://www.linkedin.com/in/jean-fran%C3%A7ois-lessard/)

Thank you! Your submission has been received!

Oops! Something went wrong while submitting the form.

Pour toute demande de renseignements des médias, veuillez communiquer avec nous au [Courriel: media@tedy.app](mailto:media@tedy.app)

Planifier une démo

Que direz-vous d'un petit café virtuel? Découvrez comment Tedy peut augmenter vos avantages sociaux et dynamiser votre culture d'entreprise.

Voir la démo de la découverte de Tedy

Ajoutez vos informations et recevez un lien de visualisation instantanément.

Planifier une démo

Que direz-vous d'un petit café virtuel? Découvrez comment Tedy peut augmenter vos avantages sociaux et dynamiser votre culture d'entreprise.

---

### Access Denied
*13 words* | Source: **GOOGLE** | [Link](https://www.journaldemontreal.com/2025/03/03/de-la-bienveillance-a-la-performance--des-entreprises-etablies-ici-influencees-par-le-modele-americain)

You don't have permission to access "http://www.journaldemontreal.com/2025/03/03/de-la-bienveillance-a-la-performance--des-entreprises-etablies-ici-influencees-par-le-modele-americain" on this server.
Reference #18.30c1ce17.1765177573.26f47d3a

https://errors.edgesuite.net/18.30c1ce17.1765177573.26f47d3a

---

### Départ de Léger DGTL: de nouveaux défis chez Tedy pour Pablo Stevenson
*3,160 words* | Source: **GOOGLE** | [Link](https://www.grenier.qc.ca/actualites/36860/depart-de-leger-dgtl-de-nouveaux-defis-chez-tedy-pour-pablo-stevenson)

Départ de Léger DGTL: de nouveaux défis chez Tedy pour Pablo Stevenson | Grenier aux nouvelles

===============

![Image 1: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

Nous respectons votre vie privée.

Avec votre consentement, nous et nos partenaires utilisons les cookies ou des technologies similaires pour stocker, accéder à et traiter des données personnelles telles que vos visites à ce site Web, les adresses IP et les identifiants des cookies. Vous pouvez révoquer votre consentement ou vous opposer au traitement des données à tout moment en cliquant sur « Personnaliser » ou en accédant à notre Politique de confidentialité sur ce site Web.

Personnaliser Tout rejeter Accepter tout

Personnaliser les préférences en matière de consentement![Image 2: cky-close-icon](https://cdn-cookieyes.com/assets/images/close.svg)

Nos partenaires et nous déposons des cookies et utilisons des informations non sensibles de votre appareil pour améliorer nos produits et afficher des publicités et contenus personnalisés. Vous pouvez accepter ou refuser ces différentes opérations. Pour en savoir plus sur les cookies, les données que nous utilisons, les traitements que nous réalisons et les partenaires avec qui nous travaillons, vous pouvez consulter notre politique de confidentialité.

Nécessaire Toujours actif

Les cookies nécessaires sont cruciaux pour les fonctions de base du site Web et celui-ci ne fonctionnera pas comme prévu sans eux.

Ces cookies ne stockent aucune donnée personnellement identifiable.

*   Cookie __cflb 
*   durée 3 jour 12 heure 
*   la description This cookie is used by Cloudflare for load balancing. 

*   Cookie PHPSESSID 
*   durée session 
*   la description Ce témoin est natif des applications PHP. Le témoin stocke et identifie un identifiant de session unique d’un utilisateur afin de gérer les sessions d’utilisateurs sur le site Internet. Ce témoin est un témoin de session et sera supprimé lorsque toutes les fenêtres du navigateur seront fermées. 

*   Cookie _csrf 
*   durée session 
*   la description This cookie is essential for the security of the website and visitor. It ensures visitor browsing security by preventing cross-site request forgery. 

*   Cookie redirectUrl 
*   durée session 
*   la description No description available. 

*   Cookie JSESSIONID 
*   durée session 
*   la description New Relic utilise ce témoin pour stocker un identifiant de session afin que New Relic puisse surveiller le nombre de sessions pour une application. 

*   Cookie __cf_bm 
*   durée 1 heure 
*   la description Cloudflare a placé ce témoin pour prendre en charge la gestion des robots Cloudflare. 

*   Cookie _adstanding_local_id 
*   durée 1 an 
*   la description Description is currently not available. 

*   Cookie cookieyes-consent 
*   durée 1 an 
*   la description CookieYes place ce témoin pour mémoriser les préférences des utilisateurs en matière de consentement afin que leurs préférences soient respectées lors des visites ultérieures de ce site. Il ne collecte ni ne stocke aucune information personnelle sur les visiteurs du site. 

*   Cookie _cfuvid 
*   durée session 
*   la description Calendly sets this cookie to track users across sessions to optimize user experience by maintaining session consistency and providing personalized services 

*   Cookie __hssrc 
*   durée session 
*   la description Ce cookie est défini par Hubspot chaque fois qu'il modifie le cookie de session. Le cookie __hssrc défini à 1 indique que l'utilisateur a redémarré le navigateur, et si le cookie n'existe pas, on suppose qu'il s'agit d'une nouvelle session. 

*   Cookie __hssc 
*   durée 1 heure 
*   la description HubSpot définit ce cookie pour assurer le suivi des sessions et pour déterminer si HubSpot doit incrémenter le nombre de sessions et les horodatages dans le cookie __hstc. 

*   Cookie rc::a 
*   durée N'expire jamais 
*   la description This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks. 

*   Cookie rc::c 
*   durée session 
*   la description This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks. 

Fonctionnelle

- [x] 

Les cookies fonctionnels permettent d'exécuter certaines fonctionnalités telles que le partage du contenu du site Web sur des plateformes de médias sociaux, la collecte de commentaires et d'autres fonctionnalités tierces.

*   Cookie messagesUtk 
*   durée 6 mois 
*   la description HubSpot sets this cookie to recognize visitors who chat via the chatflows tool. 

*   Cookie ytidb::LAST_RESULT_ENTRY_KEY 
*   durée N'expire jamais 
*   la description The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future. 

*   Cookie yt-remote-session-app

*[... truncated, 28,767 more characters]*

---

### Employee benefits: Double the impact at half the price
*1,346 words* | Source: **GOOGLE** | [Link](https://nationalpost.com/sponsored/business-sponsored/employee-benefits-double-the-impact-at-half-the-price)

[Skip to Content](https://nationalpost.com/sponsored/business-sponsored/employee-benefits-double-the-impact-at-half-the-price#main-content)

*   [Subscribe](https://nationalpost.com/subscribe/)
    *   [Our Offers](https://nationalpost.com/subscribe/)
    *   [My Account](https://nationalpost.com/my-account/)
    *   [Manage My Subscriptions](https://nationalpost.com/my-account/#/subscriptions/)
    *   [FAQ](https://nationalpost.com/faq/)

*   [Newsletters](https://nationalpost.com/newsletters/)
*   [Canada](https://nationalpost.com/category/news/canada/)
    *   [Canadian True Crime](https://nationalpost.com/category/news/true-crime/)
    *   [Canadian Politics](https://nationalpost.com/category/news/politics/)
    *   [Health](https://nationalpost.com/category/health/)

*   [World](https://nationalpost.com/category/news/world/)
    *   [Israel & Middle East](https://nationalpost.com/category/news/world/israel-middle-east/)

*   [Financial Post](https://financialpost.com/ "Financial Post (Leaving National Post)")
*   [NP Comment](https://nationalpost.com/category/opinion/)
*   [Longreads](https://nationalpost.com/category/longreads/)
*   [Puzzmo](https://www.puzzmo.com/+/nationalpost/ "Puzzmo (Leaving National Post)")
*   [Diversions](https://nationalpost.com/puzzles/)
    *   [Comics](https://nationalpost.com/comics/)
    *   [NP News Quiz](https://nationalpost.com/tag/np-news-quiz/)
    *   [New York Times Crossword](https://nationalpost.com/nyt-puzzle/)
    *   [Horoscopes](https://nationalpost.com/category/life/horoscopes/)

*   [Life](https://nationalpost.com/category/life/)
    *   [Eating & Drinking](https://nationalpost.com/category/life/food/)
    *   [Style](https://nationalpost.com/category/shopping-essentials/style-beauty/)
    *   [Sponsored](https://nationalpost.com/category/sponsored/)
        *   [Play for Ontario](https://nationalpost.com/category/sponsored/olg/)

    *   [Travel](https://nationalpost.com/category/travel/)
        *   [Travel Canada](https://nationalpost.com/category/travel/travel-canada/)
        *   [Travel USA](https://nationalpost.com/category/travel/usa/)
        *   [Travel International](https://nationalpost.com/category/travel/international/)
        *   [Cruises](https://nationalpost.com/category/travel/cruises/)
        *   [Travel Essentials](https://nationalpost.com/category/shopping-essentials/travel-guide/)

    *   [Culture](https://nationalpost.com/category/entertainment/)
        *   [Books](https://nationalpost.com/category/entertainment/books/)
        *   [Celebrity](https://nationalpost.com/category/entertainment/celebrity/)
        *   [Movies](https://nationalpost.com/category/entertainment/movies/)
        *   [Music](https://nationalpost.com/category/entertainment/music/)
        *   [Theatre](https://nationalpost.com/category/entertainment/theatre/)
        *   [Television](https://nationalpost.com/category/entertainment/television/)

    *   [Business Essentials](https://nationalpost.com/category/business-essentials/)
    *   [Advice](https://nationalpost.com/advice/)

*   [Lives Told](https://livestold.com/ "Lives Told (Leaving National Post)")
*   [Tails Told](https://tailstold.com/ "Tails Told (Leaving National Post)")
*   [Shopping](https://nationalpost.com/category/shopping-essentials/)
    *   [Buy Canadian](https://nationalpost.com/category/shopping-essentials/buy-canadian/)
    *   [Home Living](https://nationalpost.com/category/shopping-essentials/home-living/)
    *   [Outdoor Living](https://nationalpost.com/category/shopping-essentials/outdoor-living/)
    *   [Tech](https://nationalpost.com/category/shopping-essentials/tech/)
    *   [Style & Beauty](https://nationalpost.com/category/shopping-essentials/style-beauty/)
    *   [Kitchen & Dining](https://nationalpost.com/category/shopping-essentials/kitchen-dining/)
    *   [Personal Care](https://nationalpost.com/category/shopping-essentials/personal-care/)
    *   [Entertainment & Hobbies](https://nationalpost.com/category/shopping-essentials/entertainment-hobbies/)
    *   [Gift Guide](https://nationalpost.com/category/shopping-essentials/gift-guide/)
    *   [Travel Guide](https://nationalpost.com/category/shopping-essentials/travel-guide/)
    *   [Deals](https://nationalpost.com/category/shopping-essentials/deals/)
    *   [Savings](https://canoe.com/category/deals/savings/ "Savings (Leaving National Post)")

*   [National Post Store](https://postmedia.store/collections/national-post/ "National Post Store (Leaving National Post)")
*   [More](https://nationalpost.com/)
    *   [Sports](https://nationalpost.com/category/sports/)
        *   [Hockey](https://nationalpost.com/category/sports/hockey/)
        *   [Baseball](https://nationalpost.com/category/sports/baseball/)
        *   [Basketball](https://nationalpost.com/category/sports/basketball/)
        *   [Football](https://nationalpost.com/category/sports/football/)
        *   [Soccer](https://nationalpost.com/category/spo

*[... truncated, 15,442 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Tedy - Our story](https://tedy.app/story)**
  - Source: tedy.app
  - *Three of Tedy's founders smilig. Pablo Stevenson smiling. Pablo Stevenson. As former CEO and founder of a well-known digital agency, Pablo led the acq...*

- **[Meet Tedy: The Canadian startup transforming employee benefits ...](https://www.thestar.com/sponsored-sections/meet-tedy-the-canadian-startup-transforming-employee-benefits-that-cover-everything-from-pet-food-to/article_9ef33658-0ee4-11ef-8445-afaefcc80414.html)**
  - Source: thestar.com
  - *May 14, 2024 ... Podcasts · This Matters · It's Political · The Billionaire Murders ... Pablo Stevenson, one of Tedy's three founders. “It's more abou...*

- **[Tedy - L'équipe qui propulse Tedy](https://tedy.app/fr/story)**
  - Source: tedy.app
  - *Pablo Stevenson. En tant qu'ancien PDG et fondateur d'une agence numérique de ... Passionné de culture organisationnelle, il a pour mission de faire d...*

- **[Ta F**king Culture d'Entreprise avec Axel Oreste - YouTube](https://www.youtube.com/playlist?list=PLRCoSyB15bYZTVEzxm4hnlq2vgytXy9bX)**
  - Source: youtube.com
  - *Sep 4, 2025 ... TFCE #4 : Pablo Stevenson, CEO @Tedy – Quand la désorganisation devient ton superpouvoir. Axel Oreste - HackCell · 49:59. TFCE #5 : Ph...*

- **[De la bienveillance à la performance: des entreprises établies ici ...](https://www.journaldemontreal.com/2025/03/03/de-la-bienveillance-a-la-performance--des-entreprises-etablies-ici-influencees-par-le-modele-americain)**
  - Source: journaldemontreal.com
  - *Mar 3, 2025 ... L'important est de continuer de faire les choses à notre façon, selon le président de Tedy, qui offre des avantages sociaux sur mesure...*

- **[Départ de Léger DGTL: de nouveaux défis chez Tedy pour Pablo ...](https://www.grenier.qc.ca/actualites/36860/depart-de-leger-dgtl-de-nouveaux-defis-chez-tedy-pour-pablo-stevenson)**
  - Source: grenier.qc.ca
  - *Sep 5, 2023 ... Pablo Stevenson : Je vais officiellement intégrer l'équipe de Tedy, une startup destinée aux PME qui s'est donnée pour mission de démo...*

- **[Employee benefits: Double the impact at half the price | National Post](https://nationalpost.com/sponsored/business-sponsored/employee-benefits-double-the-impact-at-half-the-price)**
  - Source: nationalpost.com
  - *Oct 15, 2024 ... ... Pablo Stevenson, co-founder of Tedy. “At the same time, employers ... This story was provided by Tedy for commercial purposes. Ar...*

- **[The affordable, zero-commission HSA loved by Canadian SMBs ...](https://financialpost.com/sponsored/business-sponsored/the-affordable-zero-commission-hsa-loved-by-canadian-smbs)**
  - Source: financialpost.com
  - *Apr 17, 2025 ... ... Pablo Stevenson, CEO of Tedy. “You're 30 minutes away from helping ... Article content. Tedy app. Article content. Complement or ...*

- **[Tedy | La plateforme de reconnaissance qui fera de vous un ...](https://www.lapresse.ca/xtra/2024-02-14/tedy/la-plateforme-de-reconnaissance-qui-fera-de-vous-un-meilleur-employeur.php)**
  - Source: lapresse.ca
  - *Feb 14, 2024 ... En travaillant avec plus de 400 entreprises, Pablo Stevenson, cofondateur de Tedy, le remarque plus que jamais : il est difficile d'i...*

- **[Devenez un meilleur employeur avec Tedy](https://www.lesoleil.com/la-vitrine/2024/03/19/devenez-un-meilleur-employeur-avec-tedy-TLW7KKX3EFFYZKWWIIMGKWTZZY/)**
  - Source: lesoleil.com
  - *Mar 19, 2024 ... Jean-François Lessard, Pablo Stevenson et Sydney Wingender, fondateurs de Tedy. Contenu commandité | Tedy. Quand les baby-boomers rec...*

---

*Generated by Founder Scraper*
