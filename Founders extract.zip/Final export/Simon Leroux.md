# Simon Leroux

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Optionality
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Optionality is a Generative AI co-pilot for Advisors in the M&A and financing space. Advisors use Optionality to provide an initial assessment of the business value and options, accelerate the M&A and financing process and win more deals.

## Résumé

I’m a serial entrepreneur in Artificial Intelligence, having sold my last startup, Gazelle.ai, to the private equity fund KKR before joining Inovia Capital as an Entrepreneur-in-Residence. It was during my time at Inovia that the idea for Optionality was born—a Generative AI co-pilot transforming the M&A and financing industry by redefining the role of trusted advisors.

Optionality empowers advisors with AI-driven tools to assess business value, accelerate the M&A and financing process, and win more deals. Backed by Inovia Capital, Optionality builds on my previous experience at Gazelle.ai, where we leveraged AI and big data to identify high-growth companies, leading to its acquisition by KKR and integration into Lightcast, a global leader in labor market analytics.

I began my career in the private sector at Bell Canada Enterprises (BCE) where I held senior management positions in business strategy, sales and marketing. As part of a special task force at McKinsey & Company, I developed a predictive, algorithm-based model that was used for advanced market segmentation and targeting strategies. For that work, I received BCE's Ovation Award, the company's highest honour. In 2009, I became an owner and partner at ROI Research on Investment, a management consulting firm specializing in business development and attracting foreign direct investment (FDI) where the idea of Gazelle originated

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAR0-cB61w4QLrScAi27a-aAByJbjsECLw/
**Connexions partagées** : 401


---

# Simon Leroux

## Position actuelle

**Entreprise** : Optionality

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Simon Leroux

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402377382252404736 | Video (LinkedIn Source) | blob:https://www.linkedin.com/50cca50e-e3f5-4637-8a11-9702169fa2e1 | https://media.licdn.com/dms/image/v2/D4E05AQHexyuD27paxQ/videocover-high/B4EZrpcGiQKYBU-/0/1764853051745?e=1765774800&v=beta&t=dgvgDXbrO5mV_LA-gKBQNMhlLdcJHdHBKhfrTXKZKHQ | Merci à l’équipe de SaaSpasse pour l’invitation.

On a eu l’occasion de revenir sur la genèse d’Optionality, les premières intuitions, les erreurs, les pivots… et surtout le moment où on a réalisé qu’on devait ouvrir la plateforme directement aux entrepreneurs, et pas seulement aux aviseurs.

Quand j’ai commencé à bâtir Optionality, mon réflexe était simple: construire un produit pour les aviseurs M&A.

Ce sont eux qui sont aux premières loges lors des transactions. Ils ont l’expertise, les modèles, les relations. En les outillant mieux, on créait automatiquement plus de valeur pour tout l’écosystème.

On a donc bâti les premières versions du produit pour eux: automatisation des pitchbooks, des comparables, des listes d’acquéreurs, des scénarios de financement… bref, tout ce qui accélère leur travail et renforce leur rôle de trusted advisor.

Et ça reste une partie importante de ce qu’on fait.

Mais en collaborant avec ces aviseurs, un point est devenu clair:
leur travail commence souvent quand l’entrepreneur est déjà dans le processus.

Alors que la vraie création de valeur: la préparation, la réflexion, la compréhension de ses options ... se fait bien avant.

C’est ce qui nous a poussés à ouvrir Optionality directement aux entrepreneurs.
Parce que c’est en amont que tout se joue:
– comprendre sa vraie valeur
– savoir quels acquéreurs pourraient être intéressés
– évaluer si on doit acheter, lever, ou optimiser avant de vendre
– identifier où investir pour augmenter sa valeur future

Aujourd’hui, un entrepreneur peut entrer simplement son site web et son nombre d’employés, et obtenir:
– une première évaluation (sans états financiers)
 – un benchmark sectoriel
 – une carte des acquéreurs potentiels
 – un plan d’optionnalité clair et actionnable

Ensuite, on suit sa progression dans le temps: valeur, leviers d’amélioration, décisions stratégiques.

Les aviseurs restent des partenaires clés — et plusieurs utilisent Optionality pour enrichir leurs mandats et mieux préparer leurs clients.

Mais notre mission demeure la même:
donner à chaque entrepreneur la clarté, la préparation et les options nécessaires pour décider du bon moment… et des bonnes décisions.

Toujours dispo pour les entrepreneurs qui veulent ''jaser"'.
A+ | 27 | 1 | 2 | 3d | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:41.102Z |  | 2025-12-04T16:04:57.450Z | https://www.linkedin.com/feed/update/urn:li:activity:7402334626490400768/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401964122264776704 | Video (LinkedIn Source) | blob:https://www.linkedin.com/34296f3f-2469-4c58-af72-cf2cf32081b2 | https://media.licdn.com/dms/image/v2/D4E05AQH82y0qI0-8qA/videocover-high/B4EZrkI0Q5IwBY-/0/1764764110040?e=1765774800&v=beta&t=qnGmlgM4srA4kKVzlzlheMy2_wjEaL09bERMdC_2yrw | Stay tuned ... ce Jeudi mon épisode sur le pod de SaaSpasse 

Merci pour l’invitation Francois Lanthier Nadeau et l’espace pour parler de ce qui nous drive chez Optionality : aider les entrepreneurs à être mieux outillés et vraiment prêts quand vient le temps de planifier un transfert, une vente, une acquisition ou même une levée de financement.

Hâte de partager mon parcours, les leçons apprises… et aussi quelques cicatrices. Let’s go! 🚀

Plusieurs ''shout out'' sur le pod! Steven Jast, Chris Arsenault , Claude G. Théoret , Étienne Mérineau , Vicky Boudreau ... et bien d'autres. | 51 | 4 | 1 | 4d | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:41.103Z |  | 2025-12-03T12:42:48.591Z | https://www.linkedin.com/feed/update/urn:li:activity:7401957196239949824/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401958151878627328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhajarEdBqYA/feedshare-shrink_800/B4EZrkJtrcKkAg-/0/1764764343375?e=1766620800&v=beta&t=Uk6WFgMLjgVfdnNEJGLh4DyMb4-xydeZmhytIqaJlrg | 7:00 pm last night, I had an entrepreneur update me on his deal, and it’s a reminder that selling a business is rarely a straight line.

He’d been negotiating with a buyer for a while. Good conversations, strong offer, everything moving in the right direction. Then, halfway through due diligence, the buyer came back asking to “reassess the valuation.”

Nothing major had changed.
No red flags.
Just the classic mid-process pressure test.
They pushed for a meaningful price reduction.

He told me he felt blindsided. Not because he thought the buyer was acting in bad faith, but because he had no clear way of knowing whether the revised price was fair or simply opportunistic. And that’s where most owners get stuck ... you only sell once, buyers do this constantly.

We looked at his situation together. He compared the revised offer against recent transactions in his space, and he realized the drop didn’t reflect market reality. Having that reference point gave him enough confidence to push back instead of accepting it out of fear the deal would collapse.

Just having the right context so he didn’t negotiate in the dark.
This is the part of M&A people don’t see on LinkedIn.

Offers move. Pressure ramps up. Terms get challenged.

And if you’re not prepared, you end up giving away value you didn’t need to.

That’s really the whole point: preparation doesn’t guarantee a smooth deal, but it stops you from being the only one at the table without a baseline.

Don’t be the owner who gets squeezed in a re-trade.

Be the one who walks in with the facts and keeps the value you’ve earned. | 10 | 0 | 0 | 4d | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:41.104Z |  | 2025-12-03T12:19:05.140Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401608695236698112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGAM6B86YVXqQ/feedshare-shrink_800/B4EZrfL4vnKMAg-/0/1764681026821?e=1766620800&v=beta&t=tCRHngqAL_JY8CMzsr3Uhku95psv8R8TcYGPiHxP-bo | Getting an Offer Isn’t the Finish Line. It’s the Trap Most Entrepreneurs Fall Into
One Offer Isn’t a Deal. And It’s Never the Full Story.

Last week I spoke with an entrepreneur who had just received an offer from a potential buyer. Good offer, good fit… and his first reaction was: “I’ll negotiate it myself. Why bring in an M&A advisor if I already have an offer on the table?”

I get the instinct.

But this is exactly the kind of situation we built Optionality for.

Because an offer is not a transaction.

More than 85% of deals fall apart, get retraded, or renegotiated.

Receiving an offer is just the start of the real journey. Without preparation, comparables, and a clear plan, you often end up accepting terms that don’t truly reflect the value of what you’ve built.

That’s where preparation changes everything.

With Optionality, entrepreneurs come into these discussions with a clear view of:
-what their company is actually worth
-the options available
-potential buyers
-what truly drives value in their industry

In short: they know where they’re heading.

But even with all of that, an M&A advisor is still essential.

They’re the ones who keep the deal on track, negotiate the right terms, avoid the traps, and often… bring other buyers to the table. When multiple acquirers show up, the dynamic changes completely.

Building a company is the work of a lifetime.

The day someone seriously wants to buy it doesn’t come around often. You need to be prepared, surrounded by the right people, and equipped to turn intent into a successful transaction at the right price and with the right terms.

That’s the spirit of Optionality:

Giving you the clarity, the options, and the preparation you need… so that when the offer comes, you’re in a strong position. And with the right M&A advisor, you can get the outcome you actually deserve. | 9 | 0 | 0 | 5d | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:41.105Z |  | 2025-12-02T13:10:28.184Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400159461513834497 | Text |  |  | Cette semaine j’ai eu un appel avec un entrepreneur. Il a reçu une offre d’un acquéreur potentiel. Bonne offre, bon fit… et sa première réaction a été : « Je vais la négocier moi-même. Pourquoi impliquer un conseiller M&A si j’ai déjà une offre sur la table? »

Je comprends le réflexe.

Mais c’est exactement pour ce genre de situation qu’on a créé Optionality.

Parce qu’une offre, ce n’est pas une transaction.

Plus de 85 % des deals avortent, se font retrader ou renégocier (re-trade). 

Recevoir une offre, c’est juste le début du vrai parcours. Sans préparation, sans comparables et sans plan, on se retrouve souvent à accepter des termes qui ne reflètent pas vraiment la valeur de ce qu’on a bâti.

Et c’est là que la préparation change tout.

Avec Optionality, les entrepreneurs arrivent dans ces discussions avec une vision claire de :
la vraie valeur de leur entreprise
les options possibles
les acheteurs potentiels
ce qui drive réellement la valeur dans leur secteur
Bref : ils savent où ils s’en vont.

Mais même avec tout ça, un aviseur M&A reste essentiel.

C’est lui qui garde le deal sur les rails, qui négocie les bons termes, qui évite les pièges, et souvent… qui fait émerger d’autres options. Quand plusieurs acquéreurs se manifestent, la dynamique change complètement.

Construire une entreprise, c’est l’effort d’une vie.

Le Jour J, celui où quelqu’un veut vraiment vous acheter, ne se répète pas souvent. Il faut être prêt, entouré, et outillé pour transformer une intention en transaction réussie, au bon prix et avec les bons termes.

C’est ça, l’esprit d’Optionality :Vous donner la compréhension, les options et la préparation nécessaires… pour que, quand l’offre arrive, vous soyez en position de force. Et pour que la suite, avec un bon aviseur M&A, mène au résultat que vous méritez.

Bon vendredi! | 32 | 0 | 0 | 1w | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:41.106Z |  | 2025-11-28T13:11:43.939Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7395083153968885760 | Text |  |  | Everyone but the founder is ready for retirement.

The team’s ready.
Their family’s ready.
Even their business might be ready.

But… often the founder is not.

I see it all the time.

Owners spend decades building something that becomes part of who they are.

So when the talk turns to “retirement,” it feels less like freedom and more like losing a piece of yourself.

BDC found that 40% of Canadian entrepreneurs plan to exit within 10 years.

But most haven’t started preparing, not because they don’t want to… but because they don’t know what life after the business looks like.

Here’s the truth…

Planning your next chapter isn’t about walking away, but building a business that can thrive without you so you have the freedom to choose when and how to step back.

The best time to start is while you still love what you do.

Because by the time you’re ready to leave… everyone else might already have.

At Optionality, we help business owners plan their next chapter on their terms.

If you’re not ready to retire yet, that’s okay.

But the best exits start long before you think you’ll take one. | 15 | 0 | 1 | 3w | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.034Z |  | 2025-11-14T13:00:17.907Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394373438540288000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3zvMnSYDSiQ/feedshare-shrink_800/B4EZpuSIr4IQAg-/0/1762786843217?e=1766620800&v=beta&t=R63XWR2MHoDe7Ik-ZtgOA-Nzg6XarykIc_nuALRFUwA | Thanks to EY for hosting me and ten other local founders and CEOs from Montréal’s AI scene around one table to tackle one big question: How can we win against Big Tech?

It was a night of sharp insights, laughter, and honest conversations about what it takes to build global companies from here.

Excited to see this turn into a quarterly tradition… bringing together the next generation of Québec’s tech builders.

Credit: EY, François Tellier, Antoine Riachi, Jérôme Lachance, and Patrick d’Astous. | 56 | 2 | 1 | 3w | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.036Z |  | 2025-11-12T14:00:08.563Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7393633535573790721 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6Iw3vhdO0MQ/feedshare-shrink_800/B4EZpa3n40KkAg-/0/1762461122713?e=1766620800&v=beta&t=VN9ZfT6qJ57lT4odp7pvBa87RQByrRaVlBq69e4FOwQ | I’m seeing a quiet trend is unfolding among Canadian business owners…

They’re not just surviving tariffs, they’re buying their way through them.

BDC reports that 30% of mid-sized manufacturers in Canada are considering U.S. acquisitions to offset tariff risk and protect supply chains.

In the last month alone, I’ve seen multiple owners exploring U.S. targets, not for growth’s sake, but resilience.

One manufacturing CEO told us: “We realized our best defence wasn’t lobbying, it was buying.”

That’s why some business owners are using Optionality to:

- Analyze their own business’ strengths
- Find compatible U.S. targets
- Estimate valuation ranges
- Evaluate deal feasibility in minutes

Cross-border acquisitions aren’t just a hedge.

They’re the new growth playbook for small and mid-market leaders who want to stay competitive globally.

What other quiet trends are you seeing? 🤔 | 46 | 6 | 1 | 3w | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.036Z |  | 2025-11-10T13:00:01.949Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7392531279180824576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEnC0p5rUyldQ/feedshare-shrink_800/B4EZpa1j2GHcAg-/0/1762460581759?e=1766620800&v=beta&t=U-jyd4Z_-pxfQocM0FZhhU3BHO3Wyo9zcucE5W1eHV4 | Merci à RBC Gestion de patrimoine – Groupe Constantineau  ( Simon Constantineau ) pour m'avoir inviter a partager mon expérience et celle de Optionality sur la création de valeur et la préparation à la vente d’entreprise.

 J’ai eu le plaisir d’échanger avec Mark Anthony Serri et plusieurs entrepreneurs sur un sujet que je trouve encore trop peu discuté :

 Comment créer de la valeur avant même d’avoir une intention de vendre.

C’est souvent là que tout se joue :

- Comprendre ce qui fait vraiment la valeur de son entreprise (et pas juste son EBITDA)
- Identifier les bons acheteurs potentiels, longtemps à l’avance
- Construire un plan de croissance crédible qui rend votre entreprise “désirable pour les acheteurs”

Chez Optionality, on aide les propriétaires à bâtir cette préparation et à transformer l’évaluation en stratégie.

 Parce qu’attendre la transaction, c’est déjà être en retard.

#Entrepreneuriat #ValeurDentreprise #MergersAndAcquisitions #OptionalityAI #RBC #VenteDEntreprise #Stratégie | 53 | 2 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.037Z |  | 2025-11-07T12:00:03.546Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391124443902746624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHwDMJL3vruvw/feedshare-shrink_800/B4EZpKMg8BIoAk-/0/1762181386492?e=1766620800&v=beta&t=v0mU6IvLoQPOQ3M9ktp5GypcC4l6WA35-s-bK8Aidgs | Most founders build with one goal in mind: growth.

Few build with the goal of survival without them.

And that’s the part no one likes to talk about.

Especially younger owners.

According to a BEI  survey, the biggest reason owners delay succession planning is simple: “It feels too early.”

But “too early” is how chaos begins.

When there’s no plan in place, one unexpected event (illness, accident, or worse) can unravel decades of work:

Direction disappears.
Key employees leave.
Clients lose confidence.
The business loses its heartbeat.

The truth?

If your company can’t run without you, it’s not a business, it’s a dependency.

Here’s what resilient owners do differently:

✅ Document their processes and decisions.
✅ Train managers to lead without them.
✅ Build systems that create value beyond themselves.
✅ Treat succession like a growth strategy, not a “someday” task.

Because the goal isn’t to plan for death…

It’s to build a business strong enough to outlive you. | 13 | 1 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.038Z |  | 2025-11-03T14:49:47.878Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7390084993206624257 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTDXUwF_oG2Q/feedshare-shrink_1280/B4EZo7bH.WKkAs-/0/1761933562351?e=1766620800&v=beta&t=lvX-_rozcWpJ3Vw2-zljmAYD64HO4b-B8FWJ7E9lnec | “It’s too early to plan my exit.”

That’s what most owners say, until it’s too late.

Between managing staff, customers, and cash flow, planning your eventual exit feels like a “later” problem.

But here’s the truth: later always comes faster than you think.

According to a BEI survey:

- 35% of owners believe they don’t need to plan yet
- 13% say they don’t have the time, money, or energy to start

Meanwhile, the average exit takes 5–10 years to structure properly.

That’s not “planning early.”

That’s giving your future the time it deserves.

Here’s why the best founders start early:

✅ The business is healthy, not in crisis.
✅ You have time to grow value and close gaps.
✅ You keep control while preparing for freedom later.
✅ You can evolve your plan as life changes.

Because exit planning isn’t about retirement.

It’s about options, and the freedom to decide when, how, and to whom you’ll sell. | 11 | 0 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.039Z |  | 2025-10-31T17:59:23.520Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7389396799465148416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGa-GHyiOPG_g/feedshare-shrink_800/B4EZoxpOxHGoAg-/0/1761769483742?e=1766620800&v=beta&t=0NI1xCwDgs2x0foYBjEjZ1mScg9KBCTUuT96uou6nl8 | Every deal starts with excitement…

Then slowly dies in silence.

In M&A, time doesn’t just pass… it kills.

According to Bain & Company, nearly 60% of failed mid-market deals stall due to poor preparation, not price, not fit, not negotiation.

I’m seeing it firsthand.

A business owner gets an offer from a single buyer.

They think: “I’ll handle this myself.”

Weeks turn into months.
Data rooms aren’t ready.
Financials get revised.
Advisors come in late.

By the time momentum fades, so does leverage.

It’s not a lack of opportunity…

It’s a lack of readiness.

That’s why at Optionality, we help business owners build deal readiness before they get the call — complete data rooms, updated valuations, clean financials.

Because leverage isn’t created during negotiation.

It’s been built for months.

If you’re getting approached by buyers (even casually), don’t wait.

Preparation turns time from a killer into your advantage. | 22 | 0 | 0 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.039Z |  | 2025-10-29T20:24:45.346Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7388529980303110144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG4POvc3G4o4w/feedshare-shrink_800/B4EZoQ8aW_KgAk-/0/1761220867206?e=1766620800&v=beta&t=VlCgLo1QKei4ImQdH6qsdlR87Jde5KAMZe7073rOwmo | I had the pleasure of speaking at TechExit.io last week about how founders can design better exits!

Here’s the main takeaway:

You don’t sell your company… you build an exit.

We talked about what actually drives strong outcomes: preparation, positioning, and process.

1. Preparation creates leverage.

The best exits start years before they happen. Founders who map potential buyers early—who they acquire, why, and at what stage—consistently see better outcomes. Optionality data shows those who start early can see up to 20–35% higher valuations at exit.

2. Process design drives control.

Leverage isn’t luck. The best founders run parallel workstreams, control information flow, and make buyers invest time before exclusivity.

3. Relationships close deals.

Data supports the story, but it’s people who close it. Building internal champions years in advance changes everything.

4. Founder energy decides the finish line.

The last few weeks test endurance more than strategy. Deals close when founders keep focus and optimism high.

Every great exit starts long before the LOI.

That’s exactly why we built Optionality.

To help founders prepare sooner, build leverage, and design their best possible exit.

Thanks to my co-panelists, Sarah Miller Wright, Mike Hollinger, Samara Starkman and event organizers, David Tyldesley and Amar Varma. | 52 | 2 | 2 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.040Z |  | 2025-10-27T11:00:19.553Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7387442755503042560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFxykOo3hGSWw/feedshare-shrink_800/B4EZn4jQftKgAk-/0/1760811616687?e=1766620800&v=beta&t=540OyhJwbw1DzKCiohxTkuK2bE2_-fZzVhd_m8gb988 | You don’t build optionality to sell.
 
You build it to control your destiny.

Most business owners think “exit planning” means listing their company next year.

It doesn’t.

It means understanding your position (financially and strategically) before anyone else tells you what you’re worth.

That means knowing:

- What would your business sell for today
- How strategic buyers value companies like yours
- Where your blind spots and gaps are
- And who could realistically acquire you down the road

You wouldn’t wait until you’re sick to start caring about your health.

So why wait until you need to sell to start caring about your valuation?

Optionality gives you clarity before you need it, not after.

Because in M&A, control doesn’t come from timing the market…

It comes from being ready when opportunity knocks. 👊 | 29 | 5 | 2 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.040Z |  | 2025-10-24T11:00:04.961Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7386717998004461568 | Document |  |  | Most business owners don’t lose deals because of the economy.

They lose them because of assumptions.

I recently read a 2024 Exit Planning Institute study that found 70–80% of businesses listed for sale never actually sell.

Not because they’re bad companies, but because owners unknowingly sabotage their own exits.

Here are the seven silent deal killers that show up again and again:

1. Overestimating your value.
2. Confusing your “retirement number” with market reality.
3. Chasing top-line instead of the quality of earnings.
4. Ignoring intangibles, people, culture, and brand.
5. Negotiating solo.
6. Bringing advisors in too late.
7. Skipping pre-sale diligence.

Selling a business isn’t about timing the market…

It’s about removing friction.

And that’s what we help founders do at Optionality.

Benchmark their business against 180,000+ private companies and build a clear path to an exit that actually happens.

👉 Send me a DM if you want to see how your company stacks up. | 40 | 11 | 3 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.041Z |  | 2025-10-22T11:00:09.308Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7385993192434839554 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHCW2p_aidywA/feedshare-shrink_800/B4EZn4iYe3KcAg-/0/1760811387921?e=1766620800&v=beta&t=gkA8L4cD0Prddh7H-7VC9vuwkQ2rlSwTXi1f5aA7E8M | “I’ll figure it out then”.

That’s what most founders say when thinking about exiting down the line.

But when the time comes…

Most of them aren’t ready.

In fact, BDC found that 40% of Canadian business owners plan to exit within 10 years, yet most haven’t started preparing.

And when they do, they realize:

- No one internally can buy them out
- They don’t know their fair market value
- Their only “option” is to list online

But that’s not an exit… that’s surrendering.

Here’s what I recommend instead:

- Map your buyer universe early.
- Even if you’re not for sale, start conversations.
- Talk to competitors, industry leaders, private equity, and searchers.
- Learn what they value and what gaps you can close.

The businesses that prepare before they need to sell consistently achieve 20–30% higher valuations (study by Bain & Company).

That’s the power of clarity…

And the whole idea behind why I started Optionality. | 15 | 0 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.042Z |  | 2025-10-20T11:00:02.194Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7384921225652826112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFrsaC93d5k2A/feedshare-shrink_800/B4EZnJX3qlJ0Ag-/0/1760020102296?e=1766620800&v=beta&t=ZiyrQmw0vnxiwuhqkzuMuAQy2YI7JMZc9j-LciXh8Ys | Everyone loves a successful exit story.

And you might think you’re next.

But here’s the truth: 8 out of 10 businesses never sell.

You rarely hear about stories where the deal falls apart.

The biggest reason why they don’t sell?

Not because the numbers were bad, but because the owner waited too long to prepare.

Buyers couldn’t get clarity.
Valuation expectations weren’t aligned.
And there was no prior relationship established.

Selling a business isn’t about finding “a buyer.”

It’s about building options long before you need them, mapping who your potential buyers could be, and starting conversations (even if you’re not ready to sell).

The worst time to prepare for an exit is when you have to sell.

The best time?

Yesterday.

That’s why I started Optionality.

To help owners benchmark their value, identify active buyers in their industry, and establish the relationships that matter before they are needed.

If you want to learn how top owners build optionality years before they sell…

👉 Send me a message, and we’ll show you how it works. | 20 | 0 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.043Z |  | 2025-10-17T12:00:25.397Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7384196353360334848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPTPZn-Peh6Q/feedshare-shrink_800/B4EZnJXq55HoAs-/0/1760020049993?e=1766620800&v=beta&t=-flmYhNjc_v-RDRQfagSceDz_nZzTsshdc_P8kZdUQY | Business owners often tell me the same thing…

“I’m getting emails from private equity groups, searchers, consultants… all saying they can buy or sell my business.”

There’s never been more noise in the M&A market, yet somehow, less clarity.

Who’s legitimate?
Who’s a fit?
Who’s just fishing?

That confusion leads to paralysis.

Owners don’t act, not because they’re not interested in selling, but because they don’t know where to start.

The truth is, you don’t need to be “for sale” to start building optionality.

It’s not about existing tomorrow, it’s about controlling your destiny.

Understanding your market value.

Knowing who might be interested in the future and why.

At Optionality, we’ve made the same data used by top PE firms and M&A advisors accessible to business owners.

So you can finally answer: “What’s my business really worth, and who would actually buy it?”

Curious to see how it works?

👉 Send me a message to see how we can help. | 13 | 0 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.044Z |  | 2025-10-15T12:00:02.375Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7383834039826198530 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF8TaYQN7OD6w/feedshare-shrink_800/B4EZnJWxyiHgAg-/0/1760019816002?e=1766620800&v=beta&t=_WFLcNEfao7p3JEl1bJ1TpZBdZE8A0oQTeJcJmcz-gQ | Most founders assume the best exits are the ones with the biggest cheques.

But in reality, 40% of owners who plan their exit properly sell to individuals within the business, rather than to those outside it.

After analyzing many exits of small and medium businesses (1-50M ARR), we found the most satisfied founders weren’t those who sold to PE or strategics.

They sold to partners, managers, or key employees.

They got less cash upfront… but something better:

✅ Continuity
✅ Control
✅ Legacy

Because sometimes, the right exit isn’t about maximizing price, but maximizing peace of mind.

When your buyer already shares your vision, knows your team, and understands what drives the business, the handoff is smoother, and the culture remains intact.

At Optionality, we see this pattern every week.

The best outcomes come from owners who plan early, prepare their team, and structure the deal around the next chapter, not just the closing date.

Curious what that could look like for your business?

👉 Start here: https://lnkd.in/eKqFsapY | 11 | 0 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.045Z |  | 2025-10-14T12:00:20.097Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7382410605321797633 | Image |  | https://media.licdn.com/dms/image/v2/D4E12AQGU2I1bewP_sQ/videocover-low/B4EZmWh6cmHIBU-/0/1759167172732?e=1766620800&v=beta&t=aaaL-Q-vMdMef3VIhBqOEFTEb0xNt6ZymUY_bx1b9Hw | Proud to be featured in Inovia Capital’s latest campaign Canadian Roots. Global Mindset. 

Building global companies from Canada is possible, and here’s why I believe in it! Magaly Charbonneau , Prem Kalevar , Chris Arsenault , Alexis Garneau thanks for the support!

https://lnkd.in/evWzxcta

#CanadianRoots #GlobalMindset #CompanyBuilders | 33 | 3 | 1 | 1mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.045Z |  | 2025-10-10T13:44:06.865Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7380926897074888704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE38GmPLaEl0Q/feedshare-shrink_800/B4EZm5R5v9IIAg-/0/1759750102527?e=1766620800&v=beta&t=GYL2NdJFqaJhCwMGrK6nf4fBVG-xGx1AVj1ej-dLCcQ | Entrepreneurs:

One of the most common mistakes in mergers and acquisitions (M&A) is assuming that a verbal price equates to a real deal. 

It's a scenario I encounter frequently: an entrepreneur becomes enthusiastic about an indicative offer and treats it as a done deal. However, through my experience with Optionality.ai and real-world exits, I've learned that price holds little significance until due diligence is finalized. 

The true power lies in how you manage the process, not just the initial number presented.

Here’s what I advise business owners planning an exit:

- Make multiple buyers invest time and resources before granting exclusivity.
- Strategically sequence diligence—begin with financials, market, and legal aspects; reveal your technology and intellectual property later to increase switching costs and safeguard your value.
- Create competition and urgency through clear timelines and by enforcing parallel workstreams.

When business owners utilize Optionality.ai, we assist them in:

- Conducting a pre-exit diagnostic to identify risk areas (financials, market, technology readiness).
- Building a network of potential buyers.
- Understanding their value and the value drivers for buyers.

The outcome? You reach the Letter of Intent (LOI) with clear calculations, no unexpected issues, and the credibility to negotiate better terms.

I will delve deeper into this topic at TechExit.io on October 21 during the session titled “Cringe-Worthy: Top 10 Ways to Not Blow a Deal.” If you plan to attend, I would welcome the opportunity to connect. I will be sharing insights gained from assisting companies like yours in exiting with confidence and how Optionality.ai is designed to provide leverage at every stage. 

#TechExit #MergersAndAcquisitions #SaaS #FounderExit #DealProcess #OptionalityAI | 20 | 0 | 1 | 2mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.046Z |  | 2025-10-06T11:28:23.253Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7379856796875767808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGvZCS1uO2nig/feedshare-shrink_800/B4EZmqEphpHIAg-/0/1759494969930?e=1766620800&v=beta&t=cSwa44SKOWUsTH-1P_cRWdSnTNNyFY-IVyCy05WJwDM | Every week, business owners tell me the same thing:
 “Simon, I just got another spray-and-pray email from a U.S. private equity fund… is this real?”

The short answer: yes.

There are now more private equity funds in the U.S. than McDonald’s restaurants. 🍔

Over 19,000 funds are competing for deals; a number that has ballooned over the past decade. And in the words of KKR’s Alisa Wood at Bloomberg’s Women, Money and Power summit:
“Paper gains are no substitute for real liquidity.”

With exits slowing, PE firms are under pressure. That means more outreach, more noise ... and more confusion for business owners.

That’s exactly why I built Optionality:
to help owners cut through the noise, understand if these approaches are real, and prepare for the right conversations ... on their terms, not someone else’s.

Curious what’s behind those emails in your inbox?
Check out 
Optionality

... or DM me.

#MergersAndAcquisitions #PrivateEquity #BusinessOwners #ExitPlanning | 37 | 1 | 3 | 2mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.047Z |  | 2025-10-03T12:36:11.484Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7379545114014277632 | Article |  |  | #thebestmomenttobuiltoptionalityisnow

Honored to be featured in this great article by our client EC2 Finance  on how AI is transforming mergers & acquisitions.

At Optionality, we’re proud to see our clients adopt innovative approaches to support entrepreneurs who are asking the big questions:
 - What is the true value of my business?
 - What are my best transfer options in the short or medium term?
 - How can I accelerate growth through acquisitions?

AI doesn’t replace human expertise; it amplifies it. It helps advisors and business owners:
 🔹 Save time on analysis and preparation
 🔹 Explore different strategic scenarios
 🔹 Identify the right buyers or targets faster

It’s exactly in this critical zone between preparation, valuation, and going to market that AI makes all the difference. | 7 | 0 | 0 | 2mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.048Z |  | 2025-10-02T15:57:40.499Z | https://www.ec2finance.com/comment-lia-transforme-les-fusions-et-acquisitions/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7379108499705765888 | Article |  |  | Merci à Nicolas Morin qui m’a partagé la lettre ouverte qu’il a publiée un peu plus tôt cette année avec Lucien Bouchard (ancien premier ministre du Québec) et Sébastien Roy sur le repreneuriat, une phrase m’a frappé : « le passage ne s’effectuera pas sans peine. »

Je suis d’accord … et j’ajouterais : le meilleur moment pour agir, c’est maintenant.

Parce qu’un transfert réussi, ça se prépare longtemps d’avance… et ça se prépare quand on ne pense pas nécessairement à vendre.

Chez Optionality, nous croyons que les meilleurs transferts sont centrés sur les propriétaires. 

Donnons aux entrepreneurs les bons outils, données et scénarios pour comprendre leur juste valeur, explorer leurs options stratégiques et bâtir une trajectoire de croissance ou de sortie qui maximise leur impact.

Que vous soyez un entrepreneur qui se pose des questions sur sa valeur réelle et ses options, que vous planifiiez un transfert dans quelques années ou que vous soyez un consolidateur à la recherche d’opportunités… parlons-nous.

J’ai développé Optionality pour vous.

https://lnkd.in/e4xE9NJy | 26 | 0 | 0 | 2mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.049Z |  | 2025-10-01T11:02:43.536Z | https://www.lapresse.ca/dialogue/opinions/2025-02-25/lettre-de-lucien-bouchard-et-de-ses-associes/le-repreneuriat-un-nouveau-souffle-pour-l-economie-d-ici.php |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7376211380317659136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8OQdrCvydDQ/feedshare-shrink_800/B4EZl2RKVgHcAg-/0/1758625835321?e=1766620800&v=beta&t=F8u6X7cn9hAdS-JCLEL9-7rwpCRV9JACTPxMP3g1HK4 | The best exits don’t happen when you’re “transaction ready.” They happen when you’ve prepared early.

Excited to join TechExit.io Toronto on October 21, alongside incredible dealmakers, founders, and advisors. Mike Hollinger , Samara Starkman , Sarah Miller Wright (MBA, ICD.D)

I’ll be speaking on the session:
 “Cringe Worthy – Top 10 Ways to Blow a Deal.”
We’ll dig into the most common (and painful) mistakes that can kill a tech M&A deal—things like messy cap tables, sketchy data practices, and missed prep work. Having sold and purchased several companies, I’ve seen firsthand how much of a difference early preparation makes.

This is also why I built Optionality.ai:
An AI platform that helps founders, advisors, and investors prepare years before the market ever sees a deal; by knowing your value, benchmarking it, and surfacing off-market opportunities. 

Use my promo code SLEROUX20 for 20% off: techexit.io/toronto
#TechExit #M&A #Optionality #Entrepreneurship | 54 | 2 | 1 | 2mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.050Z |  | 2025-09-23T11:10:36.448Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7364335006460092417 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGi7MZNO8owfA/feedshare-shrink_800/B4EZjNfqkDHgAg-/0/1755794287674?e=1766620800&v=beta&t=Ha-QIv7ErDqPqzPKInzYh3YlM0CoPXFNUzU8lqSHyz4 | Top 46 des entreprises québécoises vendues au cours des deux dernières années !

Derrière chaque vente, il y a une histoire.

Des années de victoires, de défaites, de doutes, puis de choix pas toujours faciles.

Les meilleurs aviseurs et les entrepreneurs le savent : ces histoires-là sont pleines de leçons, que ce soit pour préparer sa propre sortie ou identifier notre prochaine acquisition.

C’est dans cet esprit-là qu’on a bâti notre palmarès.

Vous allez y trouver :

✅ Qui a vendu
✅ Qui a acheté
✅ Le type d’acquéreur (Stratégique, Fonds PE, etc.)
✅ Quand c’est arrivé
✅ Des liens pour creuser plus loin

C’est pas juste une liste.

C’est un portrait du deal flow québécois … une intelligence de marché qui vous aide à voir les tendances avant tout le monde.

👉 Pour recevoir la liste complète, commentez « 46 ». | 212 | 1566 | 6 | 3mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.052Z |  | 2025-08-21T16:38:08.268Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7363951175311728640 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5c1745e1-5730-4ad6-a61c-bb6c68049712 | https://media.licdn.com/dms/image/v2/D4E05AQEJSpe39S467w/videocover-low/B4EZjH3LiVGwCE-/0/1755702387504?e=1765774800&v=beta&t=00DpSFHwl6U6LE3K18_p_FOX18F8D52ff4SBlxeJ2YY | Take a look at our past transactions feature with 90,000+ deals! 👇 | 20 | 2 | 0 | 3mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.053Z |  | 2025-08-20T15:12:55.791Z | https://www.linkedin.com/feed/update/urn:li:activity:7363949829489627141/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7358561575483371521 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEkiuw_17IJKg/feedshare-shrink_800/B4EZh7cwgEGYAk-/0/1754417793469?e=1766620800&v=beta&t=RQL-G1iPWmXvs2J_Ntew1Kroy_1MDoadZijh6akjYiw | My team and I are looking for a handful of business owners who are thinking about building, buying, or selling in the next 12–24 months.

If you’ve been feeling uneasy lately, here’s why:

You know your business could be worth more.
You didn’t build it just to coast.
And deep down, you’re starting to wonder… what’s next?

Here’s the truth:

Most founders wait too long to figure that out.

They stay heads-down, hoping growth (or a buyer) will just show up.

That’s not a strategy.

What you need is clarity — on your valuation, your market position, and the moves that could 2x that number before you ever go to market.

That’s exactly what we do.

With 2 exits under my belt and over 30 years of combined M&A experience from advisors like Eric Cardinal and Archit Kalani, we’re opening up 10–20 spots for a free M&A roadmap.

It includes:

✅ A breakdown of your current valuation
✅ Top buyers and acquisition targets in your industry
✅ Financial benchmarks & industry comps
✅ A roadmap to increase enterprise value over the next 1–3 years

No fluff. Just insight — from people who’ve done it.

If you want to see what your business is REALLY worth — and how to increase that number…

Simply LIKE this post and I’ll send you the details. | 91 | 5 | 15 | 4mo | Post | Simon Leroux | https://www.linkedin.com/in/lerouxs | https://linkedin.com/in/lerouxs | 2025-12-08T04:41:50.053Z |  | 2025-08-05T18:16:35.058Z |  |  | 

---



---

# Simon Leroux
*Optionality*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 24 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [E237: Simon Leroux Discusses AI in M&A and Founding Optionality](https://www.how2exit.com/e237-simon-leroux-discusses-ai-in-ma-and-founding-optionality/)
*2024-08-07*
- Category: article

### [AI-Powered Valuation: How AI is Revolutionizing the M&A Process …](https://www.how2exit.com/blog/ai-powered-valuation-how-ai-is-revolutionizing-the-ma-process-with-simon-leroux/)
*2024-08-12*
- Category: blog

### [From Financial Struggles to a Successful Acquisition (With Shawn Johal) | Optionality’s Exit Stories](https://ca.linkedin.com/in/lerouxs)
*2025-02-10*
- Category: article

### [Optionality – Inovia](https://www.inovia.vc/active-companies/optionality/)
*2025-03-01*
- Category: article

### [Time-As-Platform: Ether’s Phoenix & The Memorial Monument — simondlr.com](https://blog.simondlr.com/posts/time-as-platform)
*2022-05-05*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 40,750 words total*

### Podpage | Build a beautiful podcast website in 5 minutes
*232 words* | Source: **EXA** | [Link](https://www.how2exit.com/e237-simon-leroux-discusses-ai-in-ma-and-founding-optionality/)

Podpage | Build a beautiful podcast website in 5 minutes

===============

[![Image 2: Podpage](https://static.getpodpage.com/dashboard/images/wordmark@2x.7bad0bc531f2.png)](https://www.how2exit.com/)

*   [Why Podpage?](https://www.how2exit.com/why-choose-podpage/)
*   [Features](https://www.how2exit.com/features/)
*   [Reviews](https://www.how2exit.com/reviews/)
*   [Integrations](https://www.how2exit.com/integrations/)
*   [Pricing](https://www.how2exit.com/pricing/)
*   [Blog](https://www.how2exit.com/blog/)
*   [Login](https://www.how2exit.com/account/login/)
*   [Create a Podpage](https://www.how2exit.com/preview/)

[Create Your Website](https://www.how2exit.com/preview/)

[![Image 3](https://static.getpodpage.com/dashboard/images/wordmark@2x.7bad0bc531f2.png)](https://www.podpage.com/)
Page not found
--------------

There was no page found at this URL. Please try a different one or [go to the homepage](https://www.podpage.com/).

#### Company

*   [About Podpage](https://www.how2exit.com/about/ "About")
*   [Partners](https://www.how2exit.com/partners/ "Partners")
*   [Integrations](https://www.how2exit.com/integrations/ "Integrations")
*   [Pricing](https://www.how2exit.com/pricing/ "Pricing")
*   [Affiliate Program](http://support.podpage.com/en/articles/8597938 "Affiliate Program")
*   [Community](https://www.how2exit.com/community/ "Community")
*   [Blog](https://www.how2exit.com/blog/ "Blog")
*   [Product Updates](https://www.how2exit.com/updates/ "Product Updates")

#### Customers

*   [Customer Stories](https://www.how2exit.com/customers/stories/ "Customer Stories")
*   [Podpage for Podcasters](https://www.how2exit.com/why-choose-podpage/ "Podpage for Podcasters")
*   [Podpage for Podcast Networks](https://www.how2exit.com/network-websites/ "Podpage for Podcast Networks")
*   [Podpage for Enterprise](https://www.how2exit.com/network-websites/ "Podpage for Enterprise")

#### Compare

*   [Compare Podpage vs WordPress](https://www.how2exit.com/compare/podpage-vs-wordpress/ "Compare Podpage vs WordPress")
*   [Compare Podpage vs Squarespace](https://www.how2exit.com/compare/podpage-vs-squarespace/ "Compare Podpage vs WordPress")
*   [Compare Podpage vs Wix](https://www.how2exit.com/compare/podpage-vs-wix/ "Compare Podpage vs WordPress")

#### Resources

*   [Podcast Name Generator](https://www.podpage.com/podcast-name-generator/)
*   [Podcast Website Templates](https://www.how2exit.com/podcast-website-templates/)
*   [SEO for Podcasts](https://www.podpage.com/blog/seo-for-podcasts/)
*   [Comparing WordPress and Podpage](https://www.podpage.com/blog/comparing-wordpress-vs-podpage/)
*   [Monetizing your Podcast](https://www.podpage.com/blog/monetizing-your-podcast/)
*   [Apple Smart Banner for Podcasts](https://www.podpage.com/blog/apple-smart-podcasts-banner/)
*   [Podcast Player Badge Set](https://www.how2exit.com/badges/)

#### Guides

*   [Libsyn Podcast Websites](https://www.how2exit.com/libsyn-website/)
*   [Podbean Podcast Websites](https://www.how2exit.com/podbean-website/)
*   [Buzzsprout Podcast Websites](https://www.how2exit.com/buzzsprout-website/)
*   [Simplecast Podcast Websites](https://www.how2exit.com/simplecast-website/)
*   [Megaphone Podcast Websites](https://www.how2exit.com/megaphone-website/)
*   [Omny Podcast Websites](https://www.how2exit.com/omny-website/)

*    © 2025 Podpage™ 
*   [Sitemap](https://www.how2exit.com/sitemap.xml)
*   [Privacy Policy](https://www.how2exit.com/privacy/ "Privacy")
*   [Terms of Use](https://www.how2exit.com/terms/ "Terms")
*   [](https://www.twitter.com/podpagehq)
*   [](https://www.facebook.com/Podpage-108058407645613)

[](https://www.how2exit.com/e237-simon-leroux-discusses-ai-in-ma-and-founding-optionality/#)![Image 6](https://t.co/1/i/adsct?bci=4&dv=UTC%26en-US%26Google%20Inc.%26Linux%20x86_64%26255%26800%26600%264%2624%26800%26600%260%26na&eci=3&event=%7B%7D&event_id=339c52cd-5717-4e53-b405-26ca78a87845&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=245b7084-f768-4cba-9ac0-a212ab482784&pt=Podpage%20%7C%20Build%20a%20beautiful%20podcast%20website%20in%205%20minutes&tw_document_href=https%3A%2F%2Fwww.how2exit.com%2Fe237-simon-leroux-discusses-ai-in-ma-and-founding-optionality%2F&tw_iframe_status=0&txn_id=o4jow&type=javascript&version=2.3.35)![Image 7](https://analytics.twitter.com/1/i/adsct?bci=4&dv=UTC%26en-US%26Google%20Inc.%26Linux%20x86_64%26255%26800%26600%264%2624%26800%26600%260%26na&eci=3&event=%7B%7D&event_id=339c52cd-5717-4e53-b405-26ca78a87845&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=245b7084-f768-4cba-9ac0-a212ab482784&pt=Podpage%20%7C%20Build%20a%20beautiful%20podcast%20website%20in%205%20minutes&tw_document_href=https%3A%2F%2Fwww.how2exit.com%2Fe237-simon-leroux-discusses-ai-in-ma-and-founding-optionality%2F&tw_iframe_status=0&txn_id=o4jow&type=javascript&version=2.3.35)

---

### Podpage | Build a beautiful podcast website in 5 minutes
*232 words* | Source: **EXA** | [Link](https://www.how2exit.com/blog/ai-powered-valuation-how-ai-is-revolutionizing-the-ma-process-with-simon-leroux/)

Podpage | Build a beautiful podcast website in 5 minutes

===============

[![Image 2: Podpage](https://static.getpodpage.com/dashboard/images/wordmark@2x.7bad0bc531f2.png)](https://www.how2exit.com/)

*   [Why Podpage?](https://www.how2exit.com/why-choose-podpage/)
*   [Features](https://www.how2exit.com/features/)
*   [Reviews](https://www.how2exit.com/reviews/)
*   [Integrations](https://www.how2exit.com/integrations/)
*   [Pricing](https://www.how2exit.com/pricing/)
*   [Blog](https://www.how2exit.com/blog/)
*   [Login](https://www.how2exit.com/account/login/)
*   [Create a Podpage](https://www.how2exit.com/preview/)

[Create Your Website](https://www.how2exit.com/preview/)

[![Image 3](https://static.getpodpage.com/dashboard/images/wordmark@2x.7bad0bc531f2.png)](https://www.podpage.com/)
Page not found
--------------

There was no page found at this URL. Please try a different one or [go to the homepage](https://www.podpage.com/).

#### Company

*   [About Podpage](https://www.how2exit.com/about/ "About")
*   [Partners](https://www.how2exit.com/partners/ "Partners")
*   [Integrations](https://www.how2exit.com/integrations/ "Integrations")
*   [Pricing](https://www.how2exit.com/pricing/ "Pricing")
*   [Affiliate Program](http://support.podpage.com/en/articles/8597938 "Affiliate Program")
*   [Community](https://www.how2exit.com/community/ "Community")
*   [Blog](https://www.how2exit.com/blog/ "Blog")
*   [Product Updates](https://www.how2exit.com/updates/ "Product Updates")

#### Customers

*   [Customer Stories](https://www.how2exit.com/customers/stories/ "Customer Stories")
*   [Podpage for Podcasters](https://www.how2exit.com/why-choose-podpage/ "Podpage for Podcasters")
*   [Podpage for Podcast Networks](https://www.how2exit.com/network-websites/ "Podpage for Podcast Networks")
*   [Podpage for Enterprise](https://www.how2exit.com/network-websites/ "Podpage for Enterprise")

#### Compare

*   [Compare Podpage vs WordPress](https://www.how2exit.com/compare/podpage-vs-wordpress/ "Compare Podpage vs WordPress")
*   [Compare Podpage vs Squarespace](https://www.how2exit.com/compare/podpage-vs-squarespace/ "Compare Podpage vs WordPress")
*   [Compare Podpage vs Wix](https://www.how2exit.com/compare/podpage-vs-wix/ "Compare Podpage vs WordPress")

#### Resources

*   [Podcast Name Generator](https://www.podpage.com/podcast-name-generator/)
*   [Podcast Website Templates](https://www.how2exit.com/podcast-website-templates/)
*   [SEO for Podcasts](https://www.podpage.com/blog/seo-for-podcasts/)
*   [Comparing WordPress and Podpage](https://www.podpage.com/blog/comparing-wordpress-vs-podpage/)
*   [Monetizing your Podcast](https://www.podpage.com/blog/monetizing-your-podcast/)
*   [Apple Smart Banner for Podcasts](https://www.podpage.com/blog/apple-smart-podcasts-banner/)
*   [Podcast Player Badge Set](https://www.how2exit.com/badges/)

#### Guides

*   [Libsyn Podcast Websites](https://www.how2exit.com/libsyn-website/)
*   [Podbean Podcast Websites](https://www.how2exit.com/podbean-website/)
*   [Buzzsprout Podcast Websites](https://www.how2exit.com/buzzsprout-website/)
*   [Simplecast Podcast Websites](https://www.how2exit.com/simplecast-website/)
*   [Megaphone Podcast Websites](https://www.how2exit.com/megaphone-website/)
*   [Omny Podcast Websites](https://www.how2exit.com/omny-website/)

*    © 2025 Podpage™ 
*   [Sitemap](https://www.how2exit.com/sitemap.xml)
*   [Privacy Policy](https://www.how2exit.com/privacy/ "Privacy")
*   [Terms of Use](https://www.how2exit.com/terms/ "Terms")
*   [](https://www.twitter.com/podpagehq)
*   [](https://www.facebook.com/Podpage-108058407645613)

[](https://www.how2exit.com/blog/ai-powered-valuation-how-ai-is-revolutionizing-the-ma-process-with-simon-leroux/#)![Image 6](https://t.co/1/i/adsct?bci=4&dv=UTC%26en-US%26Google%20Inc.%26Linux%20x86_64%26255%26800%26600%264%2624%26800%26600%260%26na&eci=3&event=%7B%7D&event_id=9176538b-b91d-414e-94ed-9cfef425042c&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=7358d0f6-9c2d-4fd9-9fd6-0b65eb94567d&pt=Podpage%20%7C%20Build%20a%20beautiful%20podcast%20website%20in%205%20minutes&tw_document_href=https%3A%2F%2Fwww.how2exit.com%2Fblog%2Fai-powered-valuation-how-ai-is-revolutionizing-the-ma-process-with-simon-leroux%2F&tw_iframe_status=0&txn_id=o4jow&type=javascript&version=2.3.35)![Image 7](https://analytics.twitter.com/1/i/adsct?bci=4&dv=UTC%26en-US%26Google%20Inc.%26Linux%20x86_64%26255%26800%26600%264%2624%26800%26600%260%26na&eci=3&event=%7B%7D&event_id=9176538b-b91d-414e-94ed-9cfef425042c&integration=advertiser&p_id=Twitter&p_user_id=0&pl_id=7358d0f6-9c2d-4fd9-9fd6-0b65eb94567d&pt=Podpage%20%7C%20Build%20a%20beautiful%20podcast%20website%20in%205%20minutes&tw_document_href=https%3A%2F%2Fwww.how2exit.com%2Fblog%2Fai-powered-valuation-how-ai-is-revolutionizing-the-ma-process-with-simon-leroux%2F&tw_iframe_status=0&txn_id=o4jow&type=javascript&version=2.3.35)

---

### Simon Leroux - Optionality | LinkedIn
*7,558 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/lerouxs)

Simon Leroux - Optionality | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/lerouxs#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-jacksonville-fl?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Flerouxs&fromSignIn=true&trk=public_profile_nav-header-signin)[Create an account](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=lerouxs&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Flerouxs&trk=public_profile_nav-header-join)[![Image 1](https://ca.linkedin.com/in/lerouxs)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Flerouxs&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/D4E16AQEwRMGPCLvBWQ/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1715371474319?e=2147483647&v=beta&t=A5PklYarTELjHwTkr6LuUDSLqC2cSNRQ-e_FMAmN6oA)

![Image 3: Simon Leroux](https://ca.linkedin.com/in/lerouxs)

![Image 4](https://ca.linkedin.com/in/lerouxs)
Sign in to view Simon’s full profile
------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=lerouxs&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=lerouxs&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Simon Leroux
============

![Image 5](https://ca.linkedin.com/in/lerouxs)
Sign in to view Simon’s full profile
------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=lerouxs&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=lerouxs&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

### Montreal, Quebec, Canada Contact Info 

![Image 6

*[... truncated, 72,458 more characters]*

---

### Optionality – Inovia
*1,411 words* | Source: **EXA** | [Link](https://www.inovia.vc/active-companies/optionality/)

Optionality – Inovia

===============

Consent to cookies

This website uses cookies to help it work and to track how you interact with it, so that we can provide you with an enhanced and personalised user experience. We will only use cookies if you consent to them by clicking "Accept all". You can also manage your individual cookie preferences from the settings by clicking on "Customize".

Customize Necessary only Refuse all Accept all

Consent to cookies

Necessary- [x] REQUIRED 

Necessary cookies are crucial for the basic functions of the website and the website will not work in its intended way without them. These cookies do not store any personally identifiable data.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| cc_cookie_byscuit | .www.inovia.vc | 6 months | Byscuit sets this cookie to keep all the information related to consent. |

We are experiencing a brief cookie management interruption due to maintenance.

Rest assured that only necessary cookies are being tracked during this period. We appreciate your understanding as we promptly address this issue.

Functional- [x] Functional 

Functional cookies help to perform certain functionalities like sharing the content of the website on social media platforms, collect feedbacks, and other third-party features.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| HSID | .google.com | 1 year 10 days | To provide fraud prevention. |
| NID | .google.com | 1 year | This cookie is used to collect website statistics and track conversion rates and Google ad personalisation |
| SEARCH_SAMESITE | .google.com | 4 month | SameSite prevents the browser from sending this cookie along with cross-site requests. The main goal is mitigate the risk of cross-origin information leakage. It also provides some protection against cross-site request forgery attacks. |
| SIDCC | .google.com | 1 year | To provide the identification of trusted web traffic. |
| wp-wpml_current_language | www.inovia.vc | Session | Stores the current language. By default, this cookie is set only for logged-in users. If you enable the language cookie to support AJAX filtering, this cookie will also be set for users who are not logged in. |

Analytics- [x] Analytics 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics the number of visitors, bounce rate, traffic source, etc.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| _ga | .inovia.vc | 1 year 1 month 4 days | Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. |
| _ga_SF1F6Y3JM8 | .inovia.vc | 1 year 1 month 4 days | Google Analytics sets this cookie to store and count page views. |
| _gat_UA-99297379-1 | .inovia.vc | 1 minute | Google Analytics sets this cookie for user behaviour tracking. |
| _gid | .inovia.vc | 1 day | Google Analytics sets this cookie to store information on how visitors use a website while also creating an analytics report of the website's performance. Some of the collected data includes the number of visitors, their source, and the pages they visit |
| _hjAbsoluteSessionInProgress | .inovia.vc | Session | Detect the first pageview session of a user. |
| _hjFirstSeen | .inovia.vc | 30 minutes | Store first visit to the site. |
| _hjIncludedInSessionSample_2813421 | .inovia.vc | Session | This cookie is set to determine if a user is included in the data sampling defined by your site's daily session limit. |
| 1P_JAR | .google.com | 1 month | These cookies are set via embedded youtube-videos. They register anonymous statistical data on for example how many times the video is displayed and what settings are used for playback. |
| AEC | .google.com | 2 month 1 day |  |
| ajs_anonymous_id | .inovia.vc | 1 year | Store last visit. |
| ajs_group_id | .inovia.vc | 1 year |  |

Advertisement- [x] Advertisement 

Advertisement cookies are used to deliver visitors with customized advertisements based on the pages they visited before and analyze the effectiveness of the ad campaign.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| __Secure-* | .google.com | 1 year | Cookies whose names begin with __Secure- are secure cookies used primarily to enhance the security of sessions and user data on a website. This prefix is ??a naming convention that indicates that the cookie is set with certain mandatory security measures. |
| APISID | .google.com | 1 year 10 days |  |
| SAPISID | .google.com | 1 year 10 days | The**SAPISID**cookie is used to: * Personalize ads displayed on Google sites. * Track user interactions with Google services (such as YouTube videos). * Create a user profile based on recent searches and pr

*[... truncated, 8,515 more characters]*

---

### Time-As-Platform: Ether’s Phoenix & The Memorial Monument — simondlr.com
*1,616 words* | Source: **EXA** | [Link](https://blog.simondlr.com/posts/time-as-platform)

Due to the ever-growing immutable history of blockchains, the longer they exist, the more possible it becomes to interact (and transact) with the future and the past. It brings about strange, emergent outcomes that include: hyperstructures (free, yet valuable infrastructure), abundant retroactive funding (Ether’s Phoenix), and re-animating the dead. After just over a decade of existence, time-as-platform is slowly emerging and could redefine all manner of new social structures, art, and philosophical questions.

It’s a hard topic to talk about because causality is kind of warped by the nature that hypothetical events in the future are impacting people’s choices today. And past events are influencing decisions today. Let’s try.

**1 Interacting with the past: Retroactive Funding**

A trend that emphasises time-as-platform is the retroactive airdrop: it rewards users that have already interacted with a protocol or product. A big example of this was [Uniswap](https://uniswap.org/), a decentralized exchange protocol. Initially, people could use it as-is: exchange trades through an automated market maker. This meant that a collection of addresses showed commitment to the protocol. It was there, recorded in the immutable history of Ethereum.

Then, [a token, $UNI, was created to continue governing the protocol](https://uniswap.org/blog/uni). This token gives access over a community treasury. 15% of the supply was retroactively given to participants that interacted with the first and second version of Uniswap. It meant, at the time, that if you made at least one trade, you were given ~$400. This token is now valued >$3.6B.

This behaviour sparked a new tendency in users: a speculative incentive to just interact with stuff, in case there’s a future reward for doing so. It’s a unique bootstrapping mechanism, because even if the users aren’t eventually rewarded, they do the effort to engage with the technology.

This has interesting implications, especially when there’s compounding network effects: the more it happens, the more it will happen. The longer it goes, the more it will happen and the more opportunity there will be to reward past transactions. There’s a continuous reward system that incentivises more and more users to interact with protocols, not for a known speculative reward, but a hypothetical reward. It’s not akin to traditional speculation (buy something and hope it goes up), but rather a way to bet on any unknown futures. All becomes possible and to receive these future, hypothetical rewards, the sooner you interact, the better. The more traces you immutably record and leave behind, the more likely it could be that you could be rewarded.

There’s also another side to this coin (_screw it, pun intended_). What’s additionally valuable about this model: [it’s easier to agree what _was_ useful than _will_ be useful](https://medium.com/ethereum-optimism/retroactive-public-goods-funding-33c9b7d00f0c). Retroactive rewards are a lot more efficient form of resource allocation than pre-determining hypothetical rewards. A protocol should serve the user, not the user serving the protocol. The latter occurs when the rules are transparent (such as in blockchains) and gaming the protocol occurs with programs + bots. Retroactive rewards broadly disincentivizes abusers because when the rules are unknown, people only really act in individually beneficial ways with the protocol. It’s useful to interact more with the protocol, but not to spam or abuse the protocol because you don’t know if it’s costly to do so. It’s simply more beneficial to use the protocol for your own individual needs and hope that will be sufficient for a future, retroactive airdrop.

A variant of this framing focuses on the value of producing public goods, dubbed, the [Ether’s Phoenix](https://medium.com/ethereum-optimism/ethers-phoenix-18fb7d7304bb).

In short, it states that an abundant future of public goods will indefinitely and retroactively reward the contributors who helped create it. Its name is derived from the opposite conundrum: called the Roko’s Basilisk. A future AI will punish you forever if you don’t help to create it.

An example of the Ether’s Phoenix unfolding is with the Optimism network (a scaling solution to Ethereum): it is rewarding earlier contributors for helping to bring Optimism to fruition. 5% of the initial supply will be retroactively donated to the following categories: people already using Optimism, people repeatedly using Optimism, people that used a DAO (working together), used a multisig (working together), Gitcoin donors (donated to open source projects), and that have experimented with other scaling solutions (early adopters of new technology).

In the future, there will be more airdrops planned and as noted, it’s not shown yet what criteria will be rewarded. This is intentional.

**Where does the value come from?**

Ultimately, if actions today are to be rewarded by future protocols, where does the value **actua

*[... truncated, 5,626 more characters]*

---

### How AI is Transforming Mergers and Acquisitions
*2,414 words* | Source: **GOOGLE** | [Link](https://www.ec2finance.com/en/how-ai-is-transforming-mergers-and-acquisitions/)

How AI is Transforming Mergers and Acquisitions - EC2

===============

![Image 1: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://cdn-cookieyes.com/assets/images/close.svg)

**EC2** pays special attention to privacy and the protection of personal information. We use cookies to help you navigate our website efficiently and use certain features. You will find detailed information about all the cookies under each consent category below.

Cookies labelled as “necessary” are stored on your browser as they are essential for the website’s basic features. We also use third-party cookies which help us analyze how you use this website, record your preferences and provide content that are relevant to you. Your consent is required before these cookies can be stored on your browser....Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie PHPSESSID 
*   Duration session 
*   Description This cookie is native to PHP applications. The cookie stores and identifies a user's unique session ID to manage user sessions on the website. The cookie is a session cookie and will be deleted when all the browser windows are closed. 

*   Cookie cookieyes-consent 
*   Duration 1 year 
*   Description CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors. 

*   Cookie elementor 
*   Duration Never Expires 
*   Description The website's WordPress theme uses this cookie.It allows the website owner to implement or change the website's content in real-time. 

*   Cookie wpEmojiSettingsSupports 
*   Duration session 
*   Description WordPress sets this cookie when a user interacts with emojis on a WordPress site. It helps determine if the user's browser can display emojis properly. 

*   Cookie rc::a 
*   Duration Never Expires 
*   Description This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks. 

*   Cookie rc::c 
*   Duration session 
*   Description This cookie is set by the Google recaptcha service to identify bots to protect the website against malicious spam attacks. 

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie PugT 
*   Duration 1 month 
*   Description PubMatic sets this cookie to check when the cookies were updated on the browser in order to limit the number of calls to the server-side cookie store. 

*   Cookie ytidb::LAST_RESULT_ENTRY_KEY 
*   Duration Never Expires 
*   Description The cookie ytidb::LAST_RESULT_ENTRY_KEY is used by YouTube to store the last search result entry that was clicked by the user. This information is used to improve the user experience by providing more relevant search results in the future. 

*   Cookie yt-remote-session-app 
*   Duration session 
*   Description The yt-remote-session-app cookie is used by YouTube to store user preferences and information about the interface of the embedded YouTube video player. 

*   Cookie yt-remote-cast-installed 
*   Duration session 
*   Description The yt-remote-cast-installed cookie is used to store the user's video player preferences using embedded YouTube video. 

*   Cookie yt-remote-session-name 
*   Duration session 
*   Description The yt-remote-session-name cookie is used by YouTube to store the user's video player preferences using embedded YouTube video. 

*   Cookie yt-remote-fast-check-period 
*   Duration session 
*   Description The yt-remote-fast-check-period cookie is used by YouTube to store the user's video player preferences for embedded YouTube videos. 

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _gid 
*   Duration 1 day 
*   Description Google Analytics sets this cookie to store information on how visitors use a website while also creating an analytics report of the website's performance. Some of the collected data includes the number of visitors, their source, and the pages they visit anonymously. 

*   Cookie _gat_gtag_UA_* 
*   Duration 1 minute 
*   Description Google Analytics sets this cookie to store a unique user ID. 

*   Cookie _ga_* 
*   Duration 1 yea

*[... truncated, 15,948 more characters]*

---

### SaaSpasse | Podcast on Spotify
*1,849 words* | Source: **GOOGLE** | [Link](https://open.spotify.com/show/0KbsmBnjNy1DbPkhWGlYHG)

![Image 1](https://i.scdn.co/image/ab67656300005f1f623e012f64daf71e65443130)

Podcast François Lanthier Nadeau

About
-----

SaaSpasse — podcast franco bourré de conversations et d'idées sur lancer et scaler des produits numériques au Québec.

All Episodes
------------

*   Aujourd’hui, je jase avec Simon Leroux, président-fondateur @ Optionality, une plateforme d’AI qui aide les entrepreneurs et aviseurs avec les M&A & valorisation.Optionality c’est moins d’un an, 7 personnes, un pre-seed ainsi qu’une ronde seed qui vient de se closer.On retrace le parcours de Simon : ses 3 startups.CHAPITRES :(0:00) Intro + présentation de Simon & Optionality(4:38) Des métriques sur la compagnie(6:06) Création et vente de sa première business (Research on Investment)(15:17) La genèse de sa business Gazelle(25:53) Bâtir des relations avec des investisseurs/acquéreurs potentiels(28:26) La plus grosse leçon dans son exit avec KKR(40:17) C'est quoi un executive in residence?(45:38) La raison derrière la création d'Optionality(53:17) Leurs clients, leur mission et l'optionnalité(1:12:53) Leur produit vs le AI(1:22:20) À quoi ressemble leur GTM?(1:28:16) Le silver tsunami et le repreneuriat au Québec(1:34:05) Questions en mitraille(1:42:28) Conclusion—Simon sur LinkedInOptionalityResearch on investment (ROI)GazelleKKRInoviaCohereFTQÉcole d’entrepeneurship de Beauce[Success.co](http://Success.cohttps://www.success.co/)Cool SaaS peeps mentionnés :Steven Jast, délégué du gouvernement du Québec à HoustonClaude Théôret, senior AI advisor chez InnovobotChris Arsenault, partner chez Innovia CapitalSimon De Baene, co-founder & CEO chez WorkleapMaxime Martineau , CTO chez OptionalityDean Mendes, co-founder & head of product chez OptionalityVicky Boudreau, CEO & founder chez HeylistÉtienne Mérineau, general partner chez Telegraph Ventures—Abonnez-vous à l’infolettre (de feu) :https://saaspasse.beehiiv.com/subscribeSuivez-nous sur LinkedIn (no cringe zone) :https://www.linkedin.com/company/saaspasse/Suivez-nous sur Instagram (mémés inclus) :https://www.instagram.com/saaspasse/Faites affaire avec nos partenaires certifiés (des kingpins) :https://www.saaspasse.com/partenairesAffichez une offre d’emploi sur le job board (gratis) :https://www.saaspasse.com/emploisInscrivez votre SaaS au répertoire des SaaS au QC (>300) :https://www.saaspasse.com/ajout-saas—Crédits musiqueIntro/outro : Miro Chino — pas pireUtilisée sous licence valide non exclusive (publishing + master). © Bravo Musique / Fair Enough Publishing.Merci à⁠Fair Enough Publishing⁠pour la synchro!

Dec 4

1 hr 48 min  
*   Aujourd’hui, je jase avec Philippe Beaudoin, directeur sénior à la recherche chez LoiZéro, un laboratoire de recherche appliquée en machine learning.On retrace le parcours de Philippe : ses hackatons chez Google, son chapitre chez Element AI et son mandat chez LoiZéro.CHAPITRES :(0:00) Intro + présentation de Philippe & LoiZéro(6:16) Le parcours de Philippe : Google, Element AI, Waverly(8:02) Définir Philippe sans parler de carrière(11:24) Syndrome d'imposteur et confiance sur scène(15:29) Le Fellow Network chez Element AI(17:03) La joke qui n'a pas survécu à la traduction live chez Hyundai(21:04) Parlons des LLM et des risques catastrophiques(22:48) Comment parler des risques sans faire peur(26:17) Intelligence vs agency : la différence critique(30:03) Le problème d'alignement des agents(31:48) Anthropomorphiser les IA : est-ce correct de dire « rester en vie » ?(35:19) Est-ce que Philippe est un vibe-coder?(36:20) La nature probabiliste des modèles et le risque(40:44) Pourquoi les guardrails classiques ne suffisent pas(45:32) Le programme Scientist AI chez LoiZéro(46:50) L'agent qui menace un ingénieur pour ne pas être réentraîné(49:32) E-vals vs guardrails : deux approches de contrôle(52:32) Le langage comme surface d'attaque infinie(55:37) Ce qu'un SaaS devrait exposer à des agents(1:01:29) Construire des systèmes non-agentiques(1:06:21) Conseil pour comprendre l'IA : travailler sur un projet passion(1:08:05) Shameless plug : LoiZéro et dédramatiser le discours—Philippe sur LinkedInEYElement AI (ServiceNow AI research)BaselineMilaCopilotCool SaaS peeps mentionnés :Yoshua Benjio, president & scientific director @ LoiZéro—Abonnez-vous à l’infolettre (de feu) :https://saaspasse.beehiiv.com/subscribeSuivez-nous sur LinkedIn (no cringe zone) :https://www.linkedin.com/company/saaspasse/Suivez-nous sur Instagram (mémés inclus) :https://www.instagram.com/saaspasse/Faites affaire avec nos partenaires certifiés (des kingpins) :https://www.saaspasse.com/partenairesAffichez une offre d’emploi sur le job board (gratis) :https://www.saaspasse.com/emploisInscrivez votre SaaS au répertoire des SaaS au QC (>300) :https://www.saaspasse.com/ajout-saas—Crédits musiqueIntro/outro : Miro Chino — pas pireUtilisée sous licence valide non exclusive (publishing + master). © Bravo Musique / Fair Enough Publishing.Merci à⁠Fair Enough Publishing⁠pour la synchro!

Nov 27

1 hr 28 min  
*  

*[... truncated, 11,337 more characters]*

---

### Forum FinTech Canada - Conférenciers 2024 Canada Fintech Forum
*10,816 words* | Source: **GOOGLE** | [Link](https://www.forumfintechcanada.com/en/speakers)

![Image 1](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/Abramowitz.png)

### Talia Abramowitz

##### Managing Partner, Deloitte Ventures, Deloitte
*   Talia is the managing partner of Deloitte Ventures and the driving force behind the launch of the $150M venture fund in 2022. A first-of-its-kind capital initiative for Deloitte Canada designed to make minority investments in emerging technology companies. Talia’s entrepreneurial roots underpin her passion for helping founders successfully establish and grow their businesses. Talia established the fund strategy and developed the associated operating and governance models and put them in place. Two and a half years in, Talia has overseen the deployment of $30M of capital into 7 companies and the commitment of $25M of capital into 5 funds. Talia is an observer on select Boards and Limited Partner Advisory Committees and has strong ties within the Venture Capital ecosystem. ​

*   A committed business builder, Talia was also instrumental in the creation and growth of Omnia AI, Deloitte Canada’s artificial intelligence practice, where she served as chief operating officer, people and culture leader for Omnia AI from 2018 to 2021. Talia was part of the core team responsible for incubating and building the Omnia AI practice within Deloitte, which after a couple years was a ~100M business, with offshore capability, a standalone brand and a solid culture of innovation. ​

*   Prior to that Talia was the chief operating officer of the Financial Advisory practice in Canada where she developed and executed business strategies, and harnessed strategic investments to drive operational improvements, margin uplift and topline growth. ​

*   Talia was the Managing Partner of the Toronto Valuations practice from 2016 to 2018 which included managing a team of ~50, delivering over 300 engagements annually including valuations for financial reporting, dispute / litigation, M&A, tax, annually across all industries.​

*   Talia also has more than 15 years of experience providing valuation and M&A advisory services to companies in a variety of industries, particularly in the technology, insurance and retail sectors. During her tenure at Deloitte, Talia has developed and delivered complex financial models, analyses, reports, presentations and advisory services related to valuations for financial reporting, tax, acquisitions and divestitures ranging in value from $10 million to $12 billion.​

*   Talia graduated from the Ivey School of Business and is a Chartered Business Valuator.

![Image 2](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/%C2%BBAmend.png)

### Antoine Amend

##### Senior Technical Director, Financial Services,Databricks
Antoine Amend is a data practitioner passionate about distributed computing and advanced analytics. Graduated with a master's degree in astrophysics, author of “Mastering Spark for data science”, Antoine has been pushing both engineering and science disciplines side by side to extract commercial value from large datasets. Serving as director of data science at Barclays UK, Antoine led their AI practice and data and analytics transformation. With expertise in enterprise architecture and commercial experience delivering data science to production across regulated industries, he joined Databricks as the Sr. Technical Director for financial services, helping customers redefine the future of Banking, Insurance and Capital Markets.

![Image 3](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/Amyotte%20(1).png)

### Alexie Amyotte

##### Associate, Fasken
Alexie Amyotte is a partner in the Corporate, Commercial and Emerging Technologies Group in Montreal, where she frequently advises clients on venture capital financing, mergers and acquisitions, and corporate governance. A 2014 graduate of Université Laval and admitted to the bar in 2016, she also has experience in wealth protection. Prior to joining Fasken, she practised with a provincial firm specializing in business law.

![Image 4](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/images/Arbabi.png)

### Hamed H. Arbabi

##### Founder and CEO, VoPay
The CEO and Founder of VoPay, Hamed Arbabi, is recognized as an innovative Thought Leader in the Fintech

 Industry. Known for his drive to innovate and change how firms conduct business, Hamed has used his expertise to turn VoPay into a dominant force in the world of Financial Technology.

A serial entrepreneur, Hamed has successfully built and grown multiple startups and leveraged his knowledge

 of business expansion to develop them into successful, disruptive ventures. With over fifteen years of

 executive-level experience in spearheading comprehensive strategies and business developments, Hamed has a proven track record and an in-depth knowledge of the global financial industry.

 Hamed’s overall vision for VoPay revolves around innovation and digital transformation. Wh

*[... truncated, 73,772 more characters]*

---

### Conférenciers 2024 Forum Fintech Canada
*12,373 words* | Source: **GOOGLE** | [Link](https://www.forumfintechcanada.com/fr/conferenciers)

![Image 1](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/Abramowitz.png)

### Talia Abramowitz

##### Associée directrice, Deloitte Venture, Deloitte
*   Talia est l'associée directrice de Deloitte Ventures et la force motrice derrière le lancement du fonds de capital-risque de 150 millions de dollars en 2022. Une initiative de capital unique en son genre pour Deloitte Canada, conçue pour faire des investissements minoritaires dans des entreprises technologiques émergentes. Les racines entrepreneuriales de Talia sous-tendent sa passion pour aider les fondateurs à établir et à développer avec succès leurs entreprises. Talia a établi la stratégie du fonds et a développé les modèles de fonctionnement et de gouvernance associés et les a mis en place. Deux ans et demi plus longtemps, Talia a supervisé le déploiement de 30 millions de dollars de capital dans 7 entreprises et l'engagement de 25 millions de dollars de capital dans 5 fonds. Talia est observatrice au sein de certains conseils d'administration et comités consultatifs de commanditaires et entretient des liens étroits au sein de l'écosystème du capital de risque. ​

*   Bâtisseuse d'entreprise engagée, Talia a également joué un rôle déterminant dans la création et la croissance d'Omnia AI, la pratique d'intelligence artificielle de Deloitte Canada, où elle a été chef des opérations, leader des personnes et de la culture pour Omnia AI de 2018 à 2021. Talia faisait partie de l'équipe de base responsable de l'incubation et du développement de la pratique Omnia AI au sein de Deloitte, qui, après quelques années, était une entreprise d'environ 100 millions, avec une capacité offshore, une marque autonome et une solide culture d'innovation. ​

*   Avant cela, Talia était chef des opérations de la pratique des conseils financiers au Canada, où elle a développé et exécuté des stratégies commerciales et a exploité des investissements stratégiques pour stimuler les améliorations opérationnelles, l'augmentation des marges et la croissance du chiffre d'affaires. ​

*   Talia a été l'associée directrice de la pratique Toronto Valuations de 2016 à 2018, ce qui comprenait la gestion d'une équipe d'environ 50 personnes, la réalisation de plus de 300 engagements par an, y compris des évaluations pour les rapports financiers, les litiges / litige, les F&A, la fiscalité, chaque année dans tous les secteurs.​

*   Talia a également plus de 15 ans d'expérience dans la fourniture de services de conseil en évaluation et en F&A à des entreprises de divers secteurs, en particulier dans les secteurs de la technologie, de l'assurance et de la vente au détail. Au cours de son mandat chez Deloitte, Talia a développé et fourni des modèles financiers complexes, des analyses, des rapports, des présentations et des services de conseil liés aux évaluations pour l'information financière, la fiscalité, les acquisitions et les dessaisissements dont la valeur varie de 10 millions de dollars à 12 milliards de dollars.​

*   Talia est diplômée de l'Ivey School of Business et est une évaluatrice d'affaires agréée.​

![Image 2](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/%C2%BBAmend.png)

### Antoine Amend

##### Directeur technique principal, Services financiers,Databricks
Antoine Amend est un « data practitioner » passionné par l’informatique distribuée et les analyses avancées. Diplômé d’une maîtrise en astrophysique et auteur de « Mastering Spark for data science », Antoine a fait progresser les disciplines scientifiques et techniques pour extraire la valeur commerciale des grands ensembles de données. En tant que directeur de la science des données chez Barclays UK, Antoine a dirigé leur pratique de l’IA et la transformation des données et de l’analyse. Avec une expertise en architecture d’entreprise et une expérience commerciale dans la prestation de services de science des données à la production dans les industries réglementées, il a rejoint Databricks en tant que Sr. Directeur technique pour les services financiers, aidant les clients à redéfinir l’avenir de la banque, des assurances et des marchés de capitaux.

![Image 3](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/files/Amyotte%20(1).png)

### Alexie Amyotte

##### Associée, Fasken
Alexie Amyotte est associée au sein du groupe de droit des sociétés, droit commercial et des technologies émergentes à Montréal, où elle conseille fréquemment des clients sur le financement de capital de risque, les fusions et acquisitions, et la gouvernance d’entreprises. Diplômée de l’Université Laval en 2014 et admise au barreau en 2016, elle a également de l'expérience en protection de patrimoine. Avant de rejoindre Fasken, elle pratiquait dans un cabinet provincial spécialisé en droits des affaires.

![Image 4](https://cdn.ca.yapla.com/company/CPYrIasrSgml9Osscl6TbL5t/asset/images/Arbabi.png)

### Hamed H. Arbabi

##### Fondateur et chef de la direction, VoPay
Le PDG et fondateur de

*[... truncated, 82,902 more characters]*

---

### ‘Speed is an advantage’: M&A sector turns to AI for faster deal making
*2,249 words* | Source: **GOOGLE** | [Link](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/)

‘Speed is an advantage’: M&A sector turns to AI for faster deal making - The Logic

===============

[Skip to content](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#content)

Canada's Business and Tech Newsroom

*   [Professional Subscription](https://thelogic.co/group-subscriptions/)
*   [Partnerships & Advertising](https://thelogic.co/partnerships/)
*   [Licensing & Syndication](https://thelogic.co/group-subscriptions/)

[Log In](https://thelogic.co/login?redirect=https://thelogic.co/news/mergers-acquisitions-ai-deal-making)[Subscribe](https://thelogic.co/subscribe)

Welcome, 
*   [My Account](https://thelogic.co/my-account)
*   [Log Out](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#)

[](https://thelogic.co/)

*   [Business](https://thelogic.co/tag/business/)
*   [Tech](https://thelogic.co/tag/tech/)
*   [National](https://thelogic.co/tag/national/)
*   [The Big Read](https://thelogic.co/category/news/the-big-read/)
*   [Briefings](https://thelogic.co/briefings/)
*   [Commentary](https://thelogic.co/category/commentary/)

[Search](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#search)Search

[Log In](https://thelogic.co/login?redirect=https://thelogic.co/news/mergers-acquisitions-ai-deal-making)[Subscribe](https://thelogic.co/subscribe)

Welcome, 
*   [My Account](https://thelogic.co/my-account)
*   [Log Out](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#)

Close

#### Services

*   [Professional Subscription](https://thelogic.co/group-subscriptions/)
*   [Partnerships & Advertising](https://thelogic.co/partnerships/)
*   [Licensing & Syndication](https://thelogic.co/group-subscriptions/)

#### Content

*   [Business](https://thelogic.co/tag/business/)
*   [Tech](https://thelogic.co/tag/tech/)
*   [National](https://thelogic.co/tag/national/)
*   [The Big Read](https://thelogic.co/category/news/the-big-read/)
*   [Briefings](https://thelogic.co/briefings/)
*   [Commentary](https://thelogic.co/category/commentary/)

#### Masthead

*   CEO & Editor-in-Chief: David Skok
*   Chief Operating Officer: Jenna Zuschlag Misener
*   Managing Editor: Jordan Timm

100% Human-crafted journalism, trusted by leaders

###### News

‘Speed is an advantage’: M&A sector turns to AI for faster deal making
======================================================================

While Simon Leroux was selling his first business in 2022, he had already started thinking about his next company—and how it could make the deal-making process easier.

###### News

‘Speed is an advantage’: M&A sector turns to AI for faster deal making
======================================================================

‘The M&A industry is ready for disruption because it’s highly manual and repetitive’

 By [Aimée Look](https://thelogic.co/author/alook/ "Posts by Aimée Look")

![Image 1: Two men sit across from each other at a table with a computer screen displaying content. A sign nearby lists features like win more and generate lists.](https://thelogic.co/wp-content/uploads/2024/12/Simon_Leroux_Founder_CEO_Optionality-Montreal-November_2024-Handout-1920x1280-1.jpg)

 Optionality founder and CEO Simon Leroux at the Fintech Forum in Montreal in November 2024. **Photo:**Optionality/Handout 

Dec 9, 2024

[A A](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#)

[A Small](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/)[A Medium](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/)[A Large](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/)

[Share](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#)

[](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/#)
Gift

[](mailto:?subject=%E2%80%98Speed%20is%20an%20advantage%E2%80%99%3A%20M%26%23038%3BA%20sector%20turns%20to%20AI%20for%20faster%20deal%20making%20-%20The%20Logic&body=Check%20out%20this%20article%20from%20The%20Logic%3A%20https%3A%2F%2Fthelogic.co%2Fnews%2Fmergers-acquisitions-ai-deal-making%2F)[](https://twitter.com/intent/tweet?text=%E2%80%98Speed+is+an+advantage%E2%80%99%3A+M%26%23038%3BA+sector+turns+to+AI+for+faster+deal+making+-+The+Logic&url=https%3A%2F%2Fthelogic.co%2Fnews%2Fmergers-acquisitions-ai-deal-making%2F)[](https://www.facebook.com/sharer/sharer.php?quote=%E2%80%98Speed+is+an+advantage%E2%80%99%3A+M%26%23038%3BA+sector+turns+to+AI+for+faster+deal+making+-+The+Logic&u=https%3A%2F%2Fthelogic.co%2Fnews%2Fmergers-acquisitions-ai-deal-making%2F)[](https://www.linkedin.com/shareArticle?mini=true&summary=%E2%80%98Speed+is+an+advantage%E2%80%99%3A+M%26%23038%3BA+sector+turns+to+AI+for+faster+deal+making+-+The+Logic&url=https%3A%2F%2Fthelogic.co%2Fnews%2Fmergers-acquisitions-ai-deal-making%2F)
Share

While Simon Leroux was selling his first business in 2022, he had already started thinking about his next company—and how it could make the deal-making process easier.

After finding a buyer for his previous company, Gazelle, the Montreal-based entrepreneur 

*[... truncated, 24,377 more characters]*

---

---

## 🎬 YouTube Videos

- **[How Simon Leroux is Transforming the M&amp;A industry](https://www.youtube.com/watch?v=VUHWQYBmO9g)**
  - Channel: Omeed Tabiei
  - Date: 2024-08-23

- **[DEMO SIMON LEROUX 2016](https://www.youtube.com/watch?v=rrNVIiQdwPM)**
  - Channel: simon leroux
  - Date: 2016-06-24

- **[pp sourds Simon Leroux Connolly](https://www.youtube.com/watch?v=duRsNWcQ93M)**
  - Channel: 5imonQC
  - Date: 2018-04-11

- **[Gif Tonic : l&#39;animation au Ouest Park](https://www.youtube.com/watch?v=oCO8TyxYZkc)**
  - Channel: Ouest Track Radio
  - Date: 2025-02-13

- **[L&#39;interrupteur - version des Verts](https://www.youtube.com/watch?v=gVozCO_aRs4)**
  - Channel: Simon Leroux
  - Date: 2009-12-18

- **[Les élèves découvrent l’art numérique](https://www.youtube.com/watch?v=WVaO5a_D7KU)**
  - Channel: Ville Lillebonne
  - Date: 2016-07-15

- **[Our Top 10 Most Viewed Interviews Featuring Adam Coffey, Roland Frasier and Many More!](https://www.youtube.com/watch?v=_0_rjbOETr8)**
  - Channel: How2Exit
  - Date: 2024-12-25

- **[Murale Macadam Sud - Hell P](https://www.youtube.com/watch?v=TK0exBKIT3I)**
  - Channel: Simon Leroux
  - Date: 2013-12-06

- **[Montage Lyrique - ECTQ 2015-2016](https://www.youtube.com/watch?v=zMQS1v9dnU4)**
  - Channel: Zakary Nourcy
  - Date: 2016-01-16

- **[Des faits… d’hier à aujourd’hui [Épisode 2 • “Parcours de vie”]](https://www.youtube.com/watch?v=XLzDpJajfiU)**
  - Channel: Anne Gorny
  - Date: 2023-10-18

---

## 🔎 Press & Mentions

- **[How AI is Transforming Mergers and Acquisitions - EC2](https://www.ec2finance.com/en/how-ai-is-transforming-mergers-and-acquisitions/)**
  - Source: ec2finance.com
  - *Simon Leroux, serial entrepreneur and founder of Optionality, a startup ... podcast Au cœur de l'action, hosted by EC2 Finance. Optionality combines ....*

- **[SaaSpasse | Podcast on Spotify](https://open.spotify.com/show/0KbsmBnjNy1DbPkhWGlYHG)**
  - Source: open.spotify.com
  - *Aujourd'hui, je jase avec Simon Leroux, président-fondateur @ Optionality, une plateforme d'AI qui aide les entrepreneurs et aviseurs avec les M&A ......*

- **[E237: AI-Powered Valuation: How AI is Revolutionizing the M&A ...](https://www.youtube.com/watch?v=4JbdUbvj5JI)**
  - Source: youtube.com
  - *Aug 7, 2024 ... ... Simon Leroux shares his M&A expertise on the How to Exit Podcast. From bootstrapping Gazelle AI to its acquisition and founding Op...*

- **[Conférenciers 2024 Canada Fintech Forum - Forum FinTech Canada](https://www.forumfintechcanada.com/en/speakers)**
  - Source: forumfintechcanada.com
  - *Simon Leroux. Founder and CEO, Optionality; Stealth. Simon Leroux is a serial entrepreneur in the field of AI. His last start-up, Gazelle, was acquire...*

- **[Conférenciers 2024 Forum Fintech Canada](https://www.forumfintechcanada.com/fr/conferenciers)**
  - Source: forumfintechcanada.com
  - *... podcast qui archive les histoires des plus grands entrepreneurs juifs du siècle dernier. ... Simon Leroux. Fondateur et chef de la direction, Opti...*

- **['Speed is an advantage': M&A sector turns to AI for faster deal ...](https://thelogic.co/news/mergers-acquisitions-ai-deal-making/)**
  - Source: thelogic.co
  - *Dec 9, 2024 ... ... Optionality founder and CEO Simon Leroux at the Fintech Forum in ... interview. “Speed is an advantage when it comes to the compet...*

- **[Program 2024 Canada Fintech Forum](https://www.forumfintechcanada.com/en/program)**
  - Source: forumfintechcanada.com
  - *Simon Leroux, Founder, Optionality, Founder & CEO, Optionality. Rheia Khalaf ... INTERVIEWED BY. Talia Abramowitz, Managing Partner, Deloitte Ventures...*

- **[Speakers - techexit.io](https://techexit.io/toronto/speakers/)**
  - Source: techexit.io
  - *Simon Leroux. Founder & CEO. Optionality. Stephanie Fan. Principal. Pender Software Holdings. Talia Abramowitz. Managing Partner. Deloitte Ventures. T...*

- **[Blog | Optionality](https://optionality.ai/blog)**
  - Source: optionality.ai
  - *Mar 17, 2025 ... Optionality's Blog. Learn all the essentials to ... 3 Hidden Risks in M&A That Can Cost Founders Millions · Simon Leroux in Exit Stor...*

- **[AI in M&A: Benefits for Deal Sourcing Professionals | KUMO](https://www.withkumo.com/blog/ai-in-ma-benefits-for-deal-sourcing-professionals/)**
  - Source: withkumo.com
  - *Simon Leroux, founder of Optionality, highlights the role of AI in enhancing efficiency: ... Blog Posts. How to Streamline Deal Sourcing: A Step-by-St...*

---

*Generated by Founder Scraper*
