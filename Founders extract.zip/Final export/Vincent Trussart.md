# Vincent Trussart

## Position actuelle

**Titre** : Co-Chairman, MXL Technical Steering Commitee
**Entreprise** : DMF - Media Exchange Layer
**Durée dans le rôle** : 11 months in role
**Durée dans l'entreprise** : 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Media

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAG691gBX3072Hu6_bBA3TCrR5wlLfdpqbE/
**Connexions partagées** : 5


---

# Vincent Trussart

## Position actuelle

**Entreprise** : DMF - Media Exchange Layer

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Vincent Trussart

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393991288074964993 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFMNt_Hf_tBpA/image-shrink_800/B4EZpyyYrJIUAc-/0/1762862402541?e=1765785600&v=beta&t=oQ_MI5vKqxbVbguM7_IaTaERa7xAWX3sFPMPF01vIsg | I’m looking forward to presenting at InterBEE 2025 in Tokyo on November 19th about #European Broadcasting Union (EBU) DMF - Media Exchange Layer. Looking forward to meeting colleagues and having good conversations. If you’re attending, feel free to stop by! | 44 | 4 | 0 | 3w | Post | Vincent Trussart | https://www.linkedin.com/in/vincent-trussart-aa087b9 | https://linkedin.com/in/vincent-trussart-aa087b9 | 2025-12-08T07:00:37.713Z |  | 2025-11-11T12:41:36.792Z | https://www.linkedin.com/feed/update/urn:li:activity:7393980850498928640/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379131951007293440 | Article |  |  | I am pleased to announce that I will be presenting the #EBU #DMF #MXL project at InterBEE 2025 in Tokyo on November 19th. 

MXL FAQ: https://lnkd.in/enPuSztq | 76 | 2 | 1 | 2mo | Post | Vincent Trussart | https://www.linkedin.com/in/vincent-trussart-aa087b9 | https://linkedin.com/in/vincent-trussart-aa087b9 | 2025-12-08T07:00:37.714Z |  | 2025-10-01T12:35:54.762Z | https://github.com/dmf-mxl/mxl/wiki/Frequently-Asked-Questions |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7369693758575095808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSlHVGRmO5Gg/feedshare-shrink_1280/B4EZkZpayPIQAs-/0/1757071912858?e=1766620800&v=beta&t=F_bYpoj0eoQNPKYp6J7kvdhMS9JjKVjZf8PgoQ2Oyjw | IBC 2025 is just around the corner!  Don't miss my DMF - Media Exchange Layer presentations. #IBC2025 #GrassValley #MXL #MediaProduction #IP | 66 | 3 | 1 | 3mo | Post | Vincent Trussart | https://www.linkedin.com/in/vincent-trussart-aa087b9 | https://linkedin.com/in/vincent-trussart-aa087b9 | 2025-12-08T07:00:41.737Z |  | 2025-09-05T11:31:54.333Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7363558952397119490 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF8c7NFGs3EXg/feedshare-shrink_1280/B4EZjCd2STHEAk-/0/1755609261674?e=1766620800&v=beta&t=SCFq8UUivZUBKO-fh1CPjjROMUQb512_-U9FZNJaEgs | #IBC2025 #IBCShow #MediaProduction #GrassValley | 38 | 2 | 0 | 3mo | Post | Vincent Trussart | https://www.linkedin.com/in/vincent-trussart-aa087b9 | https://linkedin.com/in/vincent-trussart-aa087b9 | 2025-12-08T07:00:41.741Z |  | 2025-08-19T13:14:22.561Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7340763228357976064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFyCXHfjyj3uQ/feedshare-shrink_800/B4EZd.hNZlHcAk-/0/1750174336606?e=1766620800&v=beta&t=2exhW0VJNuGGWTn-aAIs_yOfFoRNuLLig8B0r8HWdlI | Exciting news! The #EBU #DMF #MXL SDK is now available as an open source project on GitHub : https://lnkd.in/e_bUyUKv
 
At the recent European Broadcasting Union (EBU) Network Technology Seminar in Geneva, I had the pleasure of joining Gareth Sylvester-Bradley from NVIDIA to share a status update on the SDK in our session, “Bootstrapping the MXL Library.”
 
Proud to say that Grass Valley continues to be a committed and active contributor to the DMF MXL project.
 
A huge thanks to everyone who’s been part of driving MXL forward. | 137 | 6 | 9 | 5mo | Post | Vincent Trussart | https://www.linkedin.com/in/vincent-trussart-aa087b9 | https://linkedin.com/in/vincent-trussart-aa087b9 | 2025-12-08T07:00:41.747Z |  | 2025-06-17T15:32:18.426Z |  |  | 

---



---

# Vincent Trussart
*DMF - Media Exchange Layer*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [The Weekly Briefing](https://broadcastdialogue.com/twb-rsa-062625/)
*2025-06-26*
- Category: article

### [COVID-19 – Design and Manufacturing Futures Lab](https://dmf-lab.co.uk/projects/covid-19/)
*2020-03-25*
- Category: article

### [](https://jointheconnector.buzzsprout.com/2040515/episodes/11457530-the-connector-podcast-dfs-2022-trensition)
- Category: podcast

### [- YouTube](https://www.youtube.com/watch?v=xyPIQWIdF3U)
*2025-04-28*
- Category: video

### [The Future of Wine Trading: dVIN’s Protocol-First Approach to Ecosystem Building](https://news.dvinlabs.com/the-future-of-wine-trading-dvins-protocol-first-approach-to-ecosystem-building-f26c69540557?gi=567ec0f3b46e)
*2025-06-08*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[IP Showcase On the Water, Amsterdam 2025 - IP Showcase](https://ipshowcase.org/ip-showcase-on-the-water-amsterdam-2025/)**
  - Source: ipshowcase.org
  - *Videos and Podcasts · CONTACT · HOME · NEWS · Press ... EBU DMF Media eXchange Layer (MXL): Streamlining Multi-Vendor Live Video. Vincent Trussart, Gr...*

- **[Conference Detail - CR-195 | Inter BEE 2025 The Comprehensive ...](https://www.inter-bee.com/en/forvisitors/conference/session/?conference_id=3215)**
  - Source: inter-bee.com
  - *MXL : EBU DMF Media eXchange Layer - Streamlining Multi-Vendor Live Video ... Vincent Trussart. VP, Software Architecture, Grass Valley. Vincent Truss...*

- **[INTER BEE CREATIVE | Inter BEE 2025 The Comprehensive Media ...](https://www.inter-bee.com/en/forvisitors/conference/creative/)**
  - Source: inter-bee.com
  - *CR-195 INTER BEE CONNECTED SESSION MXL : EBU DMF Media eXchange Layer - Streamlining Multi-Vendor Live Video ... Vincent Trussart. VP, Software Archit...*

---

*Generated by Founder Scraper*
