# Anis Laateur

## Position actuelle

**Titre** : Founder and CEO
**Entreprise** : CLINIKO DZ
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Health and Human Services

## Résumé

I’m Anis Laateur, an Algerian student at Laval University in Canada and the founder of Cliniko, a healthcare tech platform designed to simplify medical appointment booking in North Africa.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAEEhpjQBw2VmI2jT1N3Lbxld0jpMMdTon5w/


---

# Anis Laateur

## Position actuelle

**Entreprise** : CLINIKO DZ

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Anis Laateur

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389343823715307522 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG3m9vWA3erfw/feedshare-shrink_800/B4EZow49tUHcAg-/0/1761756852751?e=1766620800&v=beta&t=ZcZSXngc06sc1AzuitGJbcuedCtKHVwZO-5ckOT3HVw | Sharing a project I developed: an AI-powered Email Phishing Detector.
Phishing remains a persistent cybersecurity challenge. To explore AI-based detection methods, I built a web application that analyzes email content to predict whether it's safe or potentially phishing.
Functionality: Users can paste email text into the interface, and the application provides a classification (Safe/Phishing) along with a confidence score.
Technical Details: The core component is a TensorFlow/Keras neural network (specifically, a Bidirectional LSTM). It was trained on a combined dataset of over 43,000 emails, incorporating the Enron corpus and other phishing datasets to provide diverse examples.
Key techniques implemented:
GloVe pre-trained word embeddings were used as a foundation for word meanings.
Fine-tuning of these embeddings was performed on the email data to adapt them to the specific context of phishing detection.
Sequence processing using LSTM allowed the model to interpret word order and context.
Text preprocessing was handled using NLTK.
This application was developed as a student project to gain practical experience (it currently processes English emails). The model achieved high accuracy (~98-99%) on the test dataset and demonstrated an ability to identify various phishing attempts, including correctly classifying informal safe emails after the fine-tuning process.
The project provided valuable insights into NLP, neural network implementation, managing dataset bias, and the iterative nature of developing AI models.
For those interested in testing the app or exploring the code, the GitHub repository is available here: https://lnkd.in/e968nHgi | 8 | 0 | 0 | 1mo | Post | Anis Laateur | https://www.linkedin.com/in/anis-laateur-704b4b265 | https://linkedin.com/in/anis-laateur-704b4b265 | 2025-12-08T07:03:46.225Z |  | 2025-10-29T16:54:14.943Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7315755327939899396 | Video (LinkedIn Source) | blob:https://www.linkedin.com/13205f4c-993c-400c-ba7b-7cd7bcd72d00 | https://media.licdn.com/dms/image/v2/D4E05AQFj2u3JBvEbYw/videocover-low/B4EZYbHVX4HMCU-/0/1744211637805?e=1765785600&v=beta&t=LWyWR_ucq7BhMCzJ8tihd8VdrPc6KxR2w2om8PIqBT4 | We’re getting closer to launch — and I’m excited to share that doctor registration is now OPEN! 🩺
Grateful for the progress we’re making and the journey ahead. Let’s keep pushing forward! | 8 | 0 | 0 | 7mo | Post | Anis Laateur | https://www.linkedin.com/in/anis-laateur-704b4b265 | https://linkedin.com/in/anis-laateur-704b4b265 | 2025-12-08T07:03:46.226Z |  | 2025-04-09T15:19:50.342Z | https://www.linkedin.com/feed/update/urn:li:activity:7315753912999763970/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7313194585571155970 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEMl5X7MbW3Zw/feedshare-shrink_800/B4EZX2vLI1H0Ag-/0/1743601317865?e=1766620800&v=beta&t=mJ0q_nRyJMVqoCNj76c32Vtl5Yar-m3X1QGWDN_1W2g | I can’t wait for us to launch and start making a real impact on the healthcare system! | 7 | 0 | 0 | 8mo | Post | Anis Laateur | https://www.linkedin.com/in/anis-laateur-704b4b265 | https://linkedin.com/in/anis-laateur-704b4b265 | 2025-12-08T07:03:46.226Z |  | 2025-04-02T13:44:21.785Z | https://www.linkedin.com/feed/update/urn:li:activity:7313193985936642050/ |  | 

---



---

# Anis Laateur
*CLINIKO DZ*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Anis Bennaceur (Attention) - Raising $17M to reinvent B2B Sales with AI 🦄](https://podcasts.apple.com/fr/podcast/anis-bennaceur-attention-raising-%2417m-to-reinvent-b2b/id1578365506?i=1000716693896)
*2025-07-10*
- Category: podcast

### [Episode #25 The POWER of Customer Conversations 🗣️ ft. Anis Bennaceur - Bridge the Gap™ by Revenue Reimagined](https://revenuereimagined.buzzsprout.com/2214090/episodes/14236312-episode-25-the-power-of-customer-conversations-ft-anis-bennaceur)
*2024-01-03*
- Category: article

### [The story of Cliniko](https://www.cliniko.com/story/)
*2025-04-13*
- Category: article

### [Learn More About Cliniko with Joel Friedlaender | Clinic Mastery](https://www.clinicmastery.com/learn-more-about-cliniko-with-joel-friedlaender)
*2025-05-05*
- Category: article

### [INNOVATION – The Tech Booster Tunisia is launched during the 2nd intercluster meeting of THE NEXT SOCIETY | ANIMA Investment Network](https://anima.coop/en/2nd-techdays-the-next-society)
*2020-02-10*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
