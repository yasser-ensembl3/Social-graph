# Daniel Lavinskas

## Position actuelle

**Titre** : Founder & Chief Executive Officer
**Entreprise** : Citera
**Durée dans le rôle** : 2 years 6 months in role
**Durée dans l'entreprise** : 2 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

As Founder & CEO at Citera, I am dedicated to driving our vision of sustainability and empowering organizations to make a positive impact. With a focus on innovation and strategic leadership, I oversee the development and implementation of our cutting-edge solutions. Together with our talented team, we are revolutionizing the way businesses approach sustainability, making it accessible, actionable, and impactful. Join us on this exciting journey as we shape a more sustainable future for all.

## Résumé

Building dynamic analytics dream teams, I've cultivated innovation and a culture of excellence. Passionate about sustainability, my journey from St. Andrews to launching Citera fulfills a decade-long dream. Entrepreneurial by nature, let's create a greener future together! 🌿🚀

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAlCYvkBUX9ewtzCcfQqMRenyjrfTMq0YW8/
**Connexions partagées** : 52


---

# Daniel Lavinskas

## Position actuelle

**Entreprise** : Citera

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Daniel Lavinskas

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396223098557210624 | Document |  |  | Happy to share that I’ll be joining the AI Masterclass panel this Friday 6 PM at NYU!

This invite-only program, powered by NYU SPS and Intellibus, brings together C-suite leaders, board members, and innovators to explore how AI is shaping the future of enterprise and leadership.

Looking forward to an insightful conversation with fellow leaders and changemakers.

Learn More: www.aimasterclass.com

NYU Kimmel Center, NYC
November 21 | Panel at 6 PM
#AIMasterclass #Leadership #AI #NYUSPS #ExecutiveEducation | 42 | 4 | 0 | 2w | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:23.840Z |  | 2025-11-17T16:30:01.876Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7386478827063050240 | Video (LinkedIn Source) | blob:https://www.linkedin.com/34d691b7-3bc3-424c-bbb8-2444ad7ab866 | https://media.licdn.com/dms/image/v2/D5605AQGvDvBTHSxydg/feedshare-thumbnail_720_1280/B56ZoHzEZhKIA0-/0/1761067424628?e=1765778400&v=beta&t=RC6qok7W7Vb7PPTo5kD4Dr0h1D4VnUAAMR7Ip21TM6A | The speed at which OpenAI is transforming the web is scary. Is this a data grab or truly want to build a better browser? | 5 | 1 | 0 | 1mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:23.843Z |  | 2025-10-21T19:09:46.512Z | https://www.linkedin.com/feed/update/urn:li:activity:7386452311742693376/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7360648796650840065 | Article |  |  | We’re surrounded by headlines celebrating renewable energy adoption—yet emissions keep rising.
Why?

Because fossil fuel use still outpaces renewables, and global energy demand keeps climbing.

AI and other energy-intensive technologies are scaling faster than anything we’ve seen before. Even as we adopt solutions to reduce emissions, they often introduce new pressures elsewhere in the system.

It’s a reminder: technology alone won’t save us.
We need to start integrating sustainability metrics into ROI calculations, or risk chasing progress that cancels itself out.

https://lnkd.in/eR8Tqetm | 7 | 0 | 0 | 3mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.382Z |  | 2025-08-11T12:30:27.363Z | https://www.forbes.com/sites/rrapier/2025/08/01/the-renewable-illusion-why-fossil-fuels-keep-winning/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7359210241831444481 | Article |  |  | A decade ago, sustainability was seen as a trade-off.
Lower growth. Lower profit.

Today, it’s viewed as a driver of long-term value.
According to Morgan Stanley, 88% of companies globally see sustainability as essential for value creation.

Why the shift?
More than half have already felt the effects of climate change in the last 12 months.

It’s time to move beyond viewing ESG as a regulatory checkbox.
Sustainability is a business strategy, and it’s central to long-term viability.


https://lnkd.in/e6qUeQtm | 12 | 0 | 0 | 4mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.383Z |  | 2025-08-07T13:14:09.167Z | https://www.morganstanley.com/press-releases/morgan-stanley-sustainable-signals-survey-2025---morgan-stanley |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7307502829210861570 | Article |  |  | The good news we all need…


Kudos to the startups, property managers, building owners, utility companies, and everyone else working to build a greener, more sustainable environment. This is why we do what we do—making a real, positive impact and leaving our world better for future generations.

Let’s keep pushing forward on the road to net zero. | 7 | 0 | 0 | 8mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.386Z |  | 2025-03-17T20:47:21.321Z | https://www.unep.org/news-and-stories/press-release/emissions-building-sector-stopped-rising-first-time-2020-un-finds |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7300880534551887873 | Article |  |  | Trump's 65% cut of EPA workforce puts Canadian Cities' building decarbonization at risk.


Canada's building decarbonization policies - Ontario EWRB, Toronto EWRB, Montreal by-law 21-042, and Vancouvers' ECR - all have one thing in common... The usage of Energy Star Portfolio Manager for it's data collection, which is facilitated by the United States Environmental Protection Agency.

Not only does this not support local businesses that are more than capable of supporting Canadian governments in their efforts, but it hands the fate of our future decarbonization efforts solely in the hands of the US Government... And with the recent cuts, this puts our overall decarbonization efforts at risk.

Let's take back control. Let's work to build Canadian standards that promote Canada's interests, support Canadian businesses, and strengthen our country.

Read more about it in our recent blog here: 

https://lnkd.in/eVEAiJZc

#epa #energystar #buildingdecarbonization #canada | 10 | 0 | 0 | 9mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.387Z |  | 2025-02-27T14:12:43.238Z | https://www.reuters.com/world/us/epa-chief-eyes-65-workforce-reduction-trump-says-2025-02-26/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7295069253156655105 | Article |  |  | Widespread adoption of Gen AI set to drive energy prices higher for buildings.

The rapid rise of AI isn’t just reshaping our digital landscape—it’s also straining our energy grids. In my latest blog post, I break down how the exponential growth in AI-powered data centers is set to drive energy prices even higher.

Over the past decade, electricity prices have nearly doubled—with data center workloads growing 20–40% annually, data centers are projected to account for up to 12% of total U.S. energy consumption by 2030. This surge not only challenges our energy infrastructure but also puts increasing pressure on households and businesses to cut back on consumption.

Read the full analysis on how smarter energy management and efficiency innovations could help us navigate these challenges and build a more sustainable future. | 12 | 0 | 1 | 9mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.388Z |  | 2025-02-11T13:20:45.785Z | https://www.citera.ai/blog/the-hidden-cost-of-our-digital-future |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7293638103980781569 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFukAee3o7JMA/feedshare-shrink_800/B4EZTg1MV5HgAg-/0/1738938830784?e=1766620800&v=beta&t=Ly1ZXdCCqfU2Airxhyd43mOwzkqH4zB7PGVhnv1I-pA | Forget plowing the roads or shoveling sidewalks; if you want to glide effortlessly, apparently you just need two wheels (and nerves of steel for that wind chill). Meanwhile, I’m perfecting my snowbank hurdling skills every morning—who needs the gym when your street doubles as an arctic obstacle course?

On the bright side, if you’ve ever wanted to rebrand your driveway as a Winter Wonderland, now’s the time. Thanks, Montreal, for making me feel like a champion downhill skier every time I head out for groceries!

#SnowDaze #TwoWheelsFTW #CityWinterOlympics #SorryCars | 21 | 0 | 0 | 10mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.388Z |  | 2025-02-07T14:33:53.232Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7290056705437040640 | Article |  |  | Every time the temperature drops… I hold my breath!

In Montréal (NDG), we’re particularly vulnerable to power outages—whether due to inefficient buildings or aging infrastructure. Last year, we lost power for more than a week having to move out of our home into my in-laws basement. It’s a constant reminder of how fragile our energy grid really is, and how fortunate we are to have alternatives.

At Citera, we’re doing everything we can to make our community more sustainable, and days like today feel especially precarious. Yes, every homeowner has a responsibility to do their part, but businesses must do theirs too. It all starts with understanding energy usage.

When we launched Citera's EcoView, our goal was to help businesses take ownership of their energy consumption, reduce emissions, and make small, impactful changes. On days like these, those changes are more important than ever.

#EnergyEfficiency #Sustainability #PowerGrid #EcoView #Community #Montreal | 20 | 0 | 0 | 10mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.390Z |  | 2025-01-28T17:22:41.280Z | https://www.citera.ai/blog/the-arctic-blast-how-its-testing-the-limits-of-our-power-grid?utm_source=linkedin&utm_medium=post&utm_campaign=cold_snap_eng&utm_id=eng+cold+snap+blog+ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7287944429464600576 | Article |  |  | Clients and investors have been freaking out about the Paris Accord and the shifting political landscape in the US—but here’s why you shouldn’t worry!

While federal policies may shift, the real action is happening at the state and municipal levels where sustainability regulations are growing stronger. What were seeing is that cities and states are actually doubling down on climate action. 

At Citera we specialize in easing the environmental regulatory strain on businesses and buildings to make the shift easier towards a carbon neutral future...and we are here to stay! 

Florence Labrie and I love to debate and spitball about these topics so we started a blog to put ideas down on paper, hope you enjoy! | 14 | 2 | 0 | 10mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.391Z |  | 2025-01-22T21:29:15.444Z | https://www.citera.ai/blog/the-us-steps-back-but-carbon-neutrality-goals-push-forward?utm_source=linkedin&utm_medium=post&utm_campaign=trump_paris_agreement+ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7284549599300583424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHSIBaZ8yjoaQ/feedshare-shrink_800/B4EZRfrQN7HMAo-/0/1736771963836?e=1766620800&v=beta&t=QlKkdh9wWxRUyaoUXXxYRS8kT5zn56rEOaW5TFjxGk4 | Monday mood: Our Chief Cuddle Officer (CCO), Pippa, has declared today a duvet day. 🐾

She’s made a strong case for an extra day off—citing her impeccable snuggle game as grounds for negotiation. Can’t say I blame her; if I looked this cozy, I’d probably want to skip the Monday morning emails too.

Thought I would share something to put a smile on people's faces on a dreary January Monday morning! | 61 | 4 | 1 | 10mo | Post | Daniel Lavinskas | https://www.linkedin.com/in/dlavinskas | https://linkedin.com/in/dlavinskas | 2025-12-08T05:14:29.392Z |  | 2025-01-13T12:39:24.860Z |  |  | 

---



---

# Daniel Lavinskas
*Citera*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [Citera | LinkedIn](https://ca.linkedin.com/company/citera-ai)
*2025-04-22*
- Category: article

### [Citera - About Citera | Driving Smarter, Greener Buildings](https://www.citera.ai/about-us)
*2023-01-01*
- Category: article

### [Building Online Academy Websites with Professional Marketing and CRM Integration with Daniel Vargas](https://podcast.lifterlms.com/building-online-academy-websites-professional-marketing-crm-integration-daniel-vargas/)
*2022-02-04*
- Category: podcast

### [Gary Lavinskas Email & Phone Number | Remedy Energy Services Inc. Senior Corporate Controller Contact Information](https://rocketreach.co/gary-lavinskas-email_269382890)
*2025-01-01*
- Category: article

### [Podcast: The Complex Role of Leadership in Tech with Daniel Natic](https://www.it-labs.com/podcast-the-complex-role-of-leadership-in-tech-with-daniel-natic/)
*2025-02-14*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Meet 16 Founders Joining Morgan Stanley Inclusive & Sustainable ...](https://peopleofcolorintech.com/articles/meet-16-innovators-joining-morgan-stanley-inclusive-sustainable-ventures/)**
  - Source: peopleofcolorintech.com
  - *Sep 16, 2025 ... ... Daniel Lavinskas. A former ESG strategist and AI development leader, Lavinskas founded Citera after seeing how hard it was for ev...*

- **[AI Forum 2024 - ICCC](https://italchamber.qc.ca/events/ai-forum-2024/)**
  - Source: italchamber.qc.ca
  - *Daniel Lavinskas – Citera · David Buckeridge – McGill University. Professor ... Podcast. Mon Carnet de l'actualité numérique – Bruno Guglielminetti .....*

- **[Business Forum on AI 2020 - ICCC](https://italchamber.qc.ca/it/events/business-forum-on-ai-2020/)**
  - Source: italchamber.qc.ca
  - *Daniel Lavinskas – Citera · Daniel Silverman – Investissement Québec ... Opening web conference: Emerging Policies and Trends ......*

- **[AI Forum 2022 - ICCC](https://italchamber.qc.ca/it/events/ai-forum-2022/)**
  - Source: italchamber.qc.ca
  - *Daniel Lavinskas – Citera · Daniel Lavinskas – Citera · Daniel Silverman – Investissement Québec International. Vice-President, Foreign Direct Investm...*

- **[About Citera | Driving Smarter, Greener Buildings - Citera](https://www.citera.ai/about-us)**
  - Source: citera.ai
  - *At Citera, we simplify energy compliance and empower property owners ... Daniel Lavinskas. Founder & CEO. LinkedIn Icon Visit Citera's Twitter page to...*

- **[À propos de Citera | Vers des bâtiments plus intelligents et plus ...](https://www.citera.ai/fr/a-propos)**
  - Source: citera.ai
  - *Nous sommes fiers de notre équipe diversifiée et talentueuse, où chaque membre apporte une perspective unique à Citera. · Daniel Lavinskas · Florence ...*

---

*Generated by Founder Scraper*
