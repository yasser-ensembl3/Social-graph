# Stéphane Mark

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400177613845143552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGNq52eG83zVg/feedshare-shrink_800/B4EZrKdztNKkAo-/0/1764333404360?e=1766620800&v=beta&t=40zGTN7G8qKTGn8Ws02psf0tF7aVQw5auph1KW9pq5A | Merci beaucoup Centech Mtl. 🙏  Merci de croire en W Technologies et de nous accompagner pour atteindre de nouveaux sommets. Félicitations aux autres lauréats, bien hâte de continuer à nous entraider dans nos défis respectifs. | 11 | 2 | 0 | 1w | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:22:58.076Z |  | 2025-11-28T14:23:51.792Z | https://www.linkedin.com/feed/update/urn:li:activity:7400156557738668032/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7398734864373571584 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGvEBeR_PHIRQ/feedshare-shrink_800/B56ZqpgrcwJQAg-/0/1763780509181?e=1766620800&v=beta&t=CHN2FWTjtkL-NKbp8jdkYO76Hoa3uns-fW_VqtnIa_I | La semaine dernière a été assez intense!

Mercredi c'était Demo day du Centech Mtl à l'Ax-C. J'ai eu l'occasion de présenter W Technologies... oui oui pour la nième fois, et pas mon dernier. On peut connaître toutes les théories et entendre plusieurs pitch, mais le faire est un vrai art! 

Merci à la gang du Centech Mtl pour l'organisation et le support, c'est très apprécié 🙏 👏 ! 
Merci aux entrepreneurs, professionnels et investisseurs qui se sont déplacés. J'ai des références et des suivis à faire!!! Ça prend un grand village pour aider une entreprise comme la nôtre et chaque aide est appréciée. 🙏 🥰 
Merci à mes pairs fondateurs/fondatrices d'entreprises tech. Merci de vos encouragements et de former un si beau groupe qui se soutient.  👏 🙌 
Merci aux entrepreneurs en résidence du Centech, dont Stéphanie Bacquere, Franck Louesdon, Martin Enault pour votre franchise et vos bons mots 🙏 

Cette journée marquait la fin du programme accélération, j'y suis entrée à mi-parcours et quelle intensité! 

C'est l'fun les pitchs et le réseautage, mais des rencontres terrain c'est essentiel et motivant. Vendredi matin j'ai eu une belle rencontre avec 2 conseillers en sécurité financière où on a discuté de mon expérience dans le secteur financier, du métier de conseiller, et des solutions de W Technologies. À chaque rencontre j'en apprends tellement et ça me motive encore plus!

Et vendredi après-midi, j'ai eu une belle rencontre avec des entreprises en tech de l'Espagne. J'ai eu le plaisir de discuter avec Carlos Albo de Wenalyze. Nous avons parlé de nos solutions respectives, du marché financier et de l'assurance au Canada et en Espagne.

#Entrepreneuriat #insurtech #Demoday #networking | 37 | 0 | 0 | 1w | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:22:58.077Z |  | 2025-11-24T14:50:53.513Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7392584509491302400 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH1sIXk7dnfsg/feedshare-shrink_800/B56Zpe8ZidJwAk-/0/1762529492918?e=1766620800&v=beta&t=bN07R-HQi-EtMXl_CQmFDCmHV1PMlP9H5RXe5I3MJqU | Quelle journée intense hier à l'Expo Accélération du Centech Mtl à l'Ax-C. Les 35 entreprises de la cohorte de cette saison ont eu l'occasion de présenter nos solutions respectives. Merci à tous ceux et celles qui sont venus me voir au kiosque de W Technologies. Merci pour vos questions, votre curiosité, vos encouragements et pour les riches échanges. 

Mon p'tit plug 😉 : Chez W Technologies, nous avons développé un coéquipier numérique pour les conseiller(e)s en sécurité financière indépendant(e)s. Ça prend en charge vos suivis, formulaires et conformité, pour vous redonner du temps, du plaisir à conseiller et à développer votre entreprise.

À mon réseau : Si vous connaissez ou vous faites affaire avec des conseillers en sécurité financière indépendants et des cabinets de conseils financiers (au Québec et dans le reste du Canada), n'hésitez pas à me contacter. | 38 | 7 | 0 | 1mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:22:58.078Z |  | 2025-11-07T15:31:34.641Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7391102177118826496 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9d6e373e-c78b-4ba0-a9b5-ff4f5ad85b7b | https://media.licdn.com/dms/image/v2/D5605AQFOChkHYcsf8A/videocover-high/B56ZpJ4O9.G4CI-/0/1762176074873?e=1765778400&v=beta&t=EPfEl10vkV-2kgCYNqAC003AipuGfp5HvDoE0jLDV5c | Depuis quelques semaines je participe à la cohorte Accélération du Centech Mtl avec d’autres entrepreneurs allumés qui développent des solutions vraiment intéressantes. Comme à l’école, on approche de la fin… et les portes s’ouvrent ce jeudi 6 novembre : ma collègue et moi présenterons W Technologies aux côtés de 35 autres startups de la cohorte automne 2025.

🗓️ Expo Accélération – Rencontrez les startups Accélérées 
Quand : Jeudi 6 novembre, 14 h – 19 h 
Où : Centech – Espace Ax-C (800 rue Square-Victoria, 3e étage, Tour de la Bourse)
Accès : Libre, gratuit et ouvert à toutes et tous

Pourquoi venir?
* M'encourager et en apprendre davantage sur notre solution chez W Technologies!
* Découvrir des innovations de pointe en deeptech, medtech, edtech, IA…
* Échanger directement avec plus de 35 startups prêtes à transformer leur industrie.
* Réseauter avec des entrepreneur·e·s et des acteurs clés de l’écosystème techno montréalais.

Billet : https://luma.com/oefbqvrv

J'ai hâte de vous y croiser et d'échanger!

#MontrealTech #Centech #ExpoAccélération #StartupMTL #Innovation #Entrepreneuriat #Réseautage #Insurtech #AI #Fintech | 21 | 5 | 0 | 1mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:22:58.079Z |  | 2025-11-03T13:21:19.063Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7390486115830575104 | Text |  |  | Sales job opportunity in a cool tech company in Montreal

#salesjob #jobintech #montreal | 3 | 0 | 0 | 1mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:22:58.079Z |  | 2025-11-01T20:33:18.606Z | https://www.linkedin.com/feed/update/urn:li:activity:7390375721052839936/ | https://www.linkedin.com/jobs/view/4333616086/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7380940085355012097 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4f0463fc-eb4e-4fb4-a2a2-8fa4a588fea2 | https://media.licdn.com/dms/image/v2/D5605AQGctLdhwZemmQ/videocover-high/B56Zm5d07aKIB8-/0/1759753241622?e=1765778400&v=beta&t=9PK0I6n0FiFe4eFsn72YbkubSBXiT1tWb_rlHGPzHwg | Quelle première semaine en entrepreneuriat! 

Après des années d’expérience accumulées,  des sessions de réseautage, des conférences inspirantes, plusieurs occasions d’écouter et d’accompagner des entrepreneurs/entrepreneures, je pensais être bien préparé… j’ai des bons reflexes, mais j’ai quand ce vertige. J’ai le sentiment de déballer un mega jeu de puzzle, à observer tous les morceaux, il faut juste commencer quelques parts, une pièce à la fois! Let’s go! 

Cette première semaine, c’était :
- définir la vision, la mission, la proposition de valeur (en mvp et toujours à améliorer)
multiplier les cafés et les rencontres inspirantes
- passer du temps au Centech Mtl et à l’Ax-C et côtoyer d’autres startups (d’ailleurs j’y serais régulièrement)
- rebondir d’idées et construire avec ma partenaire

Quand je suis passionné, ça bouillonne dans ma tête. Et là, ça bouillonne fort. C’est à la fois excitant, stimulant… et un peu enivrant. Les priorités s’entrechoquent, mais je me rappelle qu’il faut avancer une bouchée à la fois, rester à l’écoute et se faire confiance.

Objectif semaine 2 : finaliser un MVP du pitch deck, amorcer le contenu marketing et ventes, et continuer à multiplier les rencontres.

P.S.1 — J’ai entendu dans un podcast qu’il ne faut jamais hésiter à reach out.
Alors je lance ça ici : si vous avez de l’expérience avec les investisseurs (préparation, approche, bonnes pratiques), j’aimerais beaucoup échanger avec vous et avoir vos conseils.

P.S.2 — Si vous êtes partenaires Microsoft, je suis curieux de connaître vos impressions, pros/cons.

Bonne semaine à toutes et à tous. | 29 | 0 | 1 | 2mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.320Z |  | 2025-10-06T12:20:47.584Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7377402056384548864 | Video (LinkedIn Source) | blob:https://www.linkedin.com/78586406-1c5a-4847-936e-05dec44da938 | https://media.licdn.com/dms/image/v2/D5605AQEUwhVt9GICOg/videocover-low/B56ZmHMCvqJwB4-/0/1758909710562?e=1765778400&v=beta&t=mhRpigz1m_IXH470qZwdMgLVE1_hzQpA4ux-dBfbv7w | Aujourd’hui marque ma dernière journée à l’AQT . 

Je pars avec le cœur rempli de gratitude! 
À mes collègues Nicole, Marc, Marie-Pier, Viviane, Guy, Mihaela et Carole, merci pour votre collaboration, votre bienveillance et les moments de complicité, de fous rires, de travail acharné qui ont rendu ces deux dernières années si riches. 

À la communauté techno et aux membres de l’AQT, grand merci pour votre ouverture et générosité. Merci pour les discussions franches, de m’avoir partagé vos défis, vos rêves et ambitions. Je suis fier de faire partie de cette communauté techno si dynamique, si riche, et qui contribue non seulement à bâtir notre société québécoise, mais aussi à rayonner un peu partout dans le monde. On a vraiment de beaux bijoux technos au Québec!

Merci aux jeunes entreprises que j’ai eu la chance de côtoyer. Vous m’avez appris la passion, la résilience et l’art de rêver grand malgré les obstacles. Je suis si heureux de vous voir croître, d’avoir célébré avec vous vos succès! Vous êtes une source d’inspiration inestimable.

Ces échanges, ces rencontres, ces amitiés m’ont fait grandir. Vous m’avez inspiré à me dépasser et à réfléchir à mon propre chemin.

🪂Alors aujourd’hui, j’ai décidé de faire le saut. Comme la première fois où j’ai sauté en parachute : un mélange de stress, d’excitation, de papillons dans le ventre… mais aussi la conviction profonde que c’est le bon moment.

Je me lance dans une nouvelle aventure. Je vais rejoindre une jeune entrepreneure pour bâtir une startup qui allie la technologie, l’IA et une bonne dose d’humains aux services des besoins du secteur des services financiers. Une opportunité où mes expériences passées et présentes s’alignent naturellement. J’en dis pas plus pour l’instant, mais stay tuned!

☕️Pour la suite, je veux continuer à apprendre de vous. J’aimerais multiplier les échanges avec d’autres entrepreneurs et bénéficier de vos conseils pour ce nouveau chapitre. Restons connectés, je suis toujours partant pour un coffee chat, une discussion franche, un partage d’expérience. 

Et si vous êtes investisseurs (ou connaissez quelqu’un qui l’est 😉), mon DM est grande ouverte.

Merci à toutes et à tous et je vous tiens au courant pour le prochain chapitre… | 105 | 58 | 0 | 2mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.321Z |  | 2025-09-26T18:01:55.744Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7371296767893688320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0Yp2lkbMO9w/feedshare-shrink_800/B4EZkuh6fsKQAg-/0/1757422266767?e=1766620800&v=beta&t=yn1rrVsxv9_fbp7Rx5baPFqgxGZXUm6pHfIv6UR_k48 | Opportunités d’emplois dans une belle entreprise en IA Videns, propulsée par Cofomo 

#IA #ITjobs #emploientechno #opportunitesemploi | 2 | 0 | 0 | 2mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.321Z |  | 2025-09-09T21:41:41.537Z | https://www.linkedin.com/feed/update/urn:li:activity:7371163248764616706/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7369523249807826945 | Text |  |  | Belles opportunités dans une entreprise tech en croissance et vous aurez la chance de travailler avec une gestionnaire hors pair et humaine!

#emploientech #techjob #techno #Montreal | 3 | 0 | 0 | 3mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.322Z |  | 2025-09-05T00:14:21.875Z | https://www.linkedin.com/feed/update/urn:li:activity:7369456294140878848/ | https://www.linkedin.com/jobs/view/4295930980/ | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7366494575714111490 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEuNXdHwYVHOw/feedshare-shrink_800/B4EZjsGF67IMAk-/0/1756307678346?e=1766620800&v=beta&t=wdBz7WyGVaLZD_eJOsqltR9SF5kGp9JVNqqVPO3XpYI | Vous êtes une jeune entreprise en techno ou vous en connaissez? La mise en candidature pour la prochaine cohorte du Programme Jeunes Entreprises AQT est lancée.  Un clin d'œil aux entrepreneurs qui font parti du programme de cette année : Maxime Lavoie LevelOps | Pablo Stevenson Tedy | Fred Gauthier Ralph François Reelcruit | Nicholas Morin Predicte.com | William Garneau NordAI | 12 | 8 | 0 | 3mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.323Z |  | 2025-08-27T15:39:29.701Z | https://www.linkedin.com/feed/update/urn:li:activity:7366488327945871360/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7364721815031615488 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQENZsICiqWjUw/feedshare-shrink_800/B56ZjS_biWHQAk-/0/1755886507875?e=1766620800&v=beta&t=6SN-11wtWjaeXGqg3imaIAKwAYbq5YRdVhhWBBYHntU | Rencontrer et échanger avec des jeunes entrepreneurs fait partie de ce qui me motive dans mon quotidien. Avec mon collègue Guy, on a eu le plaisir de rencontrer Olivier Brassard et Christopher St-Pierre, fondateurs d’Altevo à Brossard, une entreprise qui développe des logiciels et des solutions numériques sur mesure.

Parmi leurs nombreux projets innovants, j’ai trouvé très intéressant leur collaboration avec FlexyB Solutions: ils réinventent l’univers des cartes-cadeaux en le rendant 100% numérique, écologique, simple et donnant accès à un vaste catalogue incluant les marques locaux grâce à la géolocalisation des bornes. 

Quel bel exemple du dynamisme, du talent et de la créativité que les jeunes entreprises technos apportent à notre écosystème!

#technoduquebec #jeuneentreprisetechno #quebec #technologie AQT | 28 | 2 | 0 | 3mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.323Z |  | 2025-08-22T18:15:10.618Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7364309876799385604 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHs0naPN2tQDg/feedshare-shrink_800/B56ZjNItvZHQA0-/0/1755788273993?e=1766620800&v=beta&t=AnC5pUJc8BPI-Xn9Bc8Z5N-SRKKqens1tLeC2jF-7PM | Hier, avec mon collègue Guy Côté, on a eu le plaisir de visiter une nouvelle entreprise membre de l’AQT, Direct Impact Solutions à Laval.

Chef de file mondial en développement, intégration et optimisation d’applications personnalisées, l’entreprise accompagne la transformation numérique des organisations grâce aux technologies Web et aux plateformes OutSystems et FileMaker.

Avec une présence et des clients au Canada, en Europe et aux États-Unis, Direct Impact Solutions est un bel exemple d’entreprise technologique québécoise qui rayonne à l’international.

Un grand merci Philippe Lazzaroni et Patrick Daneau pour l'accueil et la belle discussion! | 14 | 0 | 3 | 3mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.324Z |  | 2025-08-21T14:58:16.890Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7355094852776157185 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEc8utMsasy0Q/image-shrink_800/B4EZhCBDVAGcAg-/0/1753454229455?e=1765778400&v=beta&t=dmqaS7IwQJtL8vjnkUcIlpOH-VzaI5lfz0MfwfzMkXA | Une belle opportunité en marketing dans une entreprise techno super dynamique!

#jobmarketing #jobtechno #opportuniteemploi #membreaqt #technoduquebec | 3 | 0 | 0 | 4mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.324Z |  | 2025-07-27T04:41:03.956Z | https://www.linkedin.com/feed/update/urn:li:activity:7354520091251671040/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7351678825174364160 | Video (LinkedIn Source) | blob:https://www.linkedin.com/31402a7a-1d7b-4141-a64f-e034f07f2e8c | https://media.licdn.com/dms/image/v2/D5605AQGuQUfD0yBFEQ/videocover-high/B56ZgZo4GRIACU-/0/1752776810748?e=1765778400&v=beta&t=fPW8e01u8AtlBHA3N45AQItYlbbKKv9C5PglOvw5tjI | Dernière journée du Technology Councils of North America (TECNA) Summer Conference à Montréal!

Après 2 journées riches en réseautage, en inspiration, en échanges d’idées et en partage de meilleures pratiques, nous avons clôturé l’événement en beauté avec une visite mémorable chez Moment Factory, fleuron québécois reconnu mondialement pour ses créations multimédias immersives.

Nous avons eu le privilège de découvrir leurs installations, prototypes, et même un accès exclusif « behind the scenes » qui a impressionné les représentants des associations technos nord-américaines présents.

Un immense merci à Vanessa Chartrand Jérôme GASSELIN Richard Hachem Catherine Deschâtelets pour votre accueil chaleureux et votre générosité.


Last day of the TECNA Summer Conference in Montreal!

After two days filled with inspiration, idea sharing, and best practices, we wrapped up the event in style with a memorable visit to Moment Factory, a world-renowned Quebec flagship known for its immersive multimedia creations.

We had the privilege of touring their installations and prototypes and even got exclusive behind-the-scenes access that truly impressed the leaders of North American tech councils in attendance.

A heartfelt thank you to Vanessa, Jérôme, Richard, and Catherine for your warm welcome and generosity. 

#TECNA2025 #TechnoduQuébec #MonRéseauDesPDGTechnos #LeadershipTechno #TechLeadership #Motnréal #MomentFactory #technologie #Innovation #CréativitéQuébécoise 
AQT Nicole Martel Marie-Pier Meunier | 25 | 2 | 5 | 4mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.325Z |  | 2025-07-17T18:26:59.509Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7326952356535771137 | Text |  |  | Belle opportunité de job en marketing chez Dracal Technologies Inc. 
#Marketingjob #emploienmarketing #techjob #emploientech #technoduquebec #quebec #opportuniteemploi | 2 | 0 | 0 | 6mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.326Z |  | 2025-05-10T12:52:49.990Z | https://www.linkedin.com/feed/update/urn:li:activity:7326672932951257088/ | https://www.linkedin.com/jobs/view/4227117474/ | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7326405148568604673 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQENyzaI0v2BQg/feedshare-shrink_800/B4EZawHtqlHMAo-/0/1746711534863?e=1766620800&v=beta&t=YuDIa2ILi6l6jv5qorpUlFF5Z4ZI5LiuhLZk2pDqAjw | Opportunité de travail en marketing dans une entreprise techno d’ici chez eZsign 

#emploitechno #itjobs #opportunitedetravail #technoduquebec #emploimarketing #Quebec | 2 | 1 | 0 | 6mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.327Z |  | 2025-05-09T00:38:25.444Z | https://www.linkedin.com/feed/update/urn:li:activity:7326259622145585153/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7326234542900477952 | Text |  |  | Belle opportunité de travail chez Solutions Kumojin pour un poste de Développeur Fullstack.
#ITJob #emploientech #technoduquebec #Quebec #developpeurfullstack | 2 | 0 | 1 | 6mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:00.327Z |  | 2025-05-08T13:20:29.883Z | https://www.linkedin.com/feed/update/urn:li:activity:7326210363249618944/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7323717364720504834 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHobOTUetx4dQ/feedshare-shrink_800/B4EZZ87GrMHYAg-/0/1745852591344?e=1766620800&v=beta&t=qCm3xPojcJb-TSxsCNBwh79NnR5rAaubogDLO8jHmJU | Belle opportunité de travail pour développeurs Full-Stack dans une belle entreprise en croissance Predicte.com 
#carriereentech #ITjob #opportunitecarriere #quebec #canada | 3 | 1 | 0 | 7mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:02.472Z |  | 2025-05-01T14:38:07.838Z | https://www.linkedin.com/feed/update/urn:li:activity:7322636512100061184/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7311755955065495552 | Video (LinkedIn Source) | blob:https://www.linkedin.com/085a8b2e-351f-4d18-8e0c-0fbe401aa811 | https://media.licdn.com/dms/image/v2/D5605AQFvKCRYpa_dyA/videocover-high/B56ZXiTONXHoBs-/0/1743258459865?e=1765778400&v=beta&t=z-TabPdPb3GqFZwnSO1guAvVhGvT39uhNgeDr9fJtnw | Vendredi de la semaine dernière et hier, pour la 2e année consécutive, j’ai eu le bonheur d’être juge aux finales régionales de l’Expo-Sciences en Montérégie et à Montréal. C’est toujours aussi inspirant de voir la passion, le travail et le génie de nos jeunes!  👏 

Bravo à Réseau Technoscience et Technoscience Région métropolitaine pour l’organisation. Si vous souhaitez encourager les jeunes et être jugé dans les prochaines éditions, suivez les pages LinkedIn pour les appels aux juges!

#exposciences #science #technologie #encouragerlarelevescientifique | 16 | 3 | 0 | 8mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:02.474Z |  | 2025-03-29T14:27:45.544Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7300990847179767808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9u0A8JfYPqg/feedshare-shrink_800/B4EZVI_YDZGwAg-/0/1740686333666?e=1766620800&v=beta&t=oNNf0T05SbaPRy7-ZA3gFcMRxW0aSGSfv_HTSJsNcBU | Hier, a eu lieu la 2e rencontre mensuelle des jeunes boursier AQT 2025 et nous avons eu un bel échange sur des pratiques de commercialisation. Bien content de voir les échanges et la synergie du groupe. Merci Véronique Morin-Morissette pour ta générosité. Bien hâte à la prochaine rencontre du mois de mars!

Allez découvrir les belles entreprises technos d'ici et qui font parti de la cohorte des boursiers de cette année :
Maxime Lavoie d'LevelOps
Pablo Stevenson de Tedy
Frederik Gauthier de Reelcruit
William Garneau de NordAI
Nicholas Morin de Predicte.com
Antonio Spiezia de trails | 21 | 2 | 1 | 9mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:02.480Z |  | 2025-02-27T21:31:03.818Z | https://www.linkedin.com/feed/update/urn:li:activity:7300967658865188865/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7272668766121930752 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH1TFYXsNNvUw/feedshare-shrink_800/feedshare-shrink_800/0/1733937351735?e=1766620800&v=beta&t=2-6d-2fTSEOkxn8kbjs0ZhjHefZfnxuCh7W4qTgCFJc | Fier de dévoiler et d’accompagner les nouveaux lauréats des Bourses Jeunes Entreprises AQT 👏 | 2 | 0 | 0 | 11mo | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:04.775Z |  | 2024-12-11T17:49:13.495Z | https://www.linkedin.com/feed/update/urn:li:activity:7272660374603157505/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7270993926960930816 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0ce13de1-d59e-41fd-9be7-dc8224568af7 | https://media.licdn.com/dms/image/v2/D4E05AQG5vCObsgr3hg/videocover-low/videocover-low/0/1733514760871?e=1765778400&v=beta&t=5Dmif7tOY-6guHQs5xMKuBXiU6XP1Hz_r6x1NeewcPs | Donnez un peu de votre temps pour être juge bénévole à l’expo-sciences! Encourageons nos jeunes. Une expérience enrichissante. | 33 | 1 | 0 | 1yr | Post | Stéphane Mark | https://www.linkedin.com/in/stephanemark | https://linkedin.com/in/stephanemark | 2025-12-08T05:23:04.776Z |  | 2024-12-07T02:54:00.722Z | https://www.linkedin.com/feed/update/urn:li:activity:7270887991001198594/ |  | 

---

