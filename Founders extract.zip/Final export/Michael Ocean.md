# Michael Ocean

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : SellMeThisPen
**Durée dans le rôle** : 3 years 10 months in role
**Durée dans l'entreprise** : 3 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

At SellMeThisPen, we help sales leaders transform team performance without adding headcount or management overhead ✨

Our AI roleplay and coaching platform enables your reps to practice with realistic scenarios tailored to your use case, then receive personalized feedback after every interaction - real client calls or AI simulations.

The result?

👉 Faster onboarding

👉 Consistent methodology adoption

👉 Continuous skill development that scales across your entire team.

Your reps get unlimited practice in a safe environment, real-time call assistance, and objective coaching that reinforces your sales framework. No more “hoping training sticks”, see measurable improvement in deal outcomes 📈

Ready to empower your team with continuous learning? Join 1,400+ companies @ sellmethispen.ai

## Résumé

I’ve been in sales since I was 9 (selling sneakers to my classmates), but my real journey has taken me from founding AE to help scaling sales at companies with hundreds of reps.

And no matter the size of the org, one thing’s always been broken: coaching!

It was always reactive. Training was one-size-fits-all. Role-plays? Rare. Real coaching? Only if your manager wasn’t buried in pipeline reviews. And meaningful, actionable feedback? Practically nonexistent.

That’s why we built SellMeThisPen AI - to help revenue leaders scale personalized coaching and practice without adding more meetings or headcount.

Here’s what it helps you with:

✨ On-demand AI role-plays to sharpen real skills

✨ Instant, AI-powered coaching after real calls or mock sessions

✨ Reinforcement learning that actually sticks

Bottom line: It helps your team ramp faster, close better, and grow revenue - without burning out your managers.

If you’re rethinking how you scale coaching, let’s talk. 🤝

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABRkVVcBVtmnkTzFjNWdXC9OAcBfTNVrKUY/
**Connexions partagées** : 49


---

# Michael Ocean

## Position actuelle

**Entreprise** : SellMeThisPen AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Michael Ocean

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402708329271042049 | Document |  |  | Most sales training fails for one simple reason:
We still treat adult sellers like classroom kids.
And then we’re shocked when nothing sticks!


On the latest SellMeThisPen AI Podcast, I sat down with Rosi Y., EMEA GTM Enablement Lead at Miro, ex-Gartner, ex-Highspot and one of the few people who’s actually applied real adult learning science to revenue teams. 

"Adults aren't blank slates, you need to work with their experience, not against it." 

Rosi described the familiar scene we’ve all seen:

She’d walk into sessions where seasoned reps sat in the back, half-listening, half-Slack-checking, waiting for the hour to end.
Not because they were difficult.
Because they’d lived through years of information dumps, rigid scripts, and “do it because I said so” training that treated them like beginners.

So she rebuilt her entire approach around something most teams never consider:

Adults learn differently. Dramatically differently.

She told a story about being responsible for enabling 400–500 reps globally with a tiny team and realizing the only way training would ever stick was if she stopped fighting the way adults naturally think and started designing for it. 

That’s where her 3 pillars of adult learning came from, the same pillars she now uses to make training actually change seller behavior:

1️⃣ Relevance
If reps can’t see how it impacts their deals today, they tune out. Tie everything to real pipeline, real blockers, and real quota pressure.

2️⃣ Autonomy
Adults reject scripts. But they embrace frameworks. Give them room to adapt the approach and you give them ownership which is when mastery happens.

3️⃣ Reflection
Learning sticks only when reps connect new ideas to past experiences. Build moments where they compare approaches, share stories, and spot their own gaps.


If you’re wondering why your trainings fade after 48 hours…
it’s probably because one (or all) of these pillars is missing.


And the second you layer them in?
Training stops feeling like school.
It starts feeling like leveling up.


Swipe through the carousel above for the full breakdown! 👉 | 18 | 3 | 3 | 2d | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:49.718Z |  | 2025-12-05T14:00:01.368Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401639645765341184 | Video (LinkedIn Source) | blob:https://www.linkedin.com/76849601-3f7f-43b9-ba06-c9f74d194042 | https://media.licdn.com/dms/image/v2/D4E05AQFkluUpBlwb8Q/feedshare-thumbnail_720_1280/B4EZrfoADlGoA4-/0/1764688399669?e=1765778400&v=beta&t=1v9mNOdDwN1FXStHpqp4o9VpiBdECf4F8k9yXiPSHd0 | Most “sales training” fails for one simple reason: we treat adults like kids.


So why are we still running enablement like a classroom when reps clearly don’t learn that way?


On the latest SellMeThisPen AI Podcast, I sat down with Rosi Y., EMEA Enablement Lead at Miro and a former secondary school teacher turned seller turned enabler.


Her career path gives her a unique lens: she’s taught actual teenagers and she’s taught sellers.


"Adults want autonomy. They don’t want information dumped on them." 


Rosi shared a story I’ve seen play out everywhere:

A team of experienced reps walks into training, sits in the back, thumbs on Slack, barely pretending to pay attention. They’re good at their jobs, respected, tenured and painfully uninterested.

But instead of forcing content on them, she flips the script. She pulls them in, asks what they want out of the session, even puts them on stage as guest speakers. Suddenly they wake up. They participate. They own the learning. 


That’s the core idea: adult learning only sticks when the learner feels ownership not obligation.


Here’s how Rosi breaks it down:

1️⃣ Autonomy matters.

Adults engage when they choose to level up, not when information is shoved at them. Give options, show impact, let them steer parts of the session. It turns compliance into commitment. 

2️⃣ Leverage experience, don’t fight it.

Tenured reps aren’t bored, they’re under-utilized. Bring them in as contributors. Ask for their stories, examples, failures. They love talking about their world, and the room trusts them instantly. 

3️⃣ Respect > instruction.

Adults don’t want a teacher. They want a partner. Treat them like peers who bring value, not pupils who need to “sit still and listen.” Even simple one-on-ones to learn who they are builds trust and opens them up to learning. 


In the full episode we cover:

 – Why adult brains reject “traditional training”
 – The psychology behind rep disengagement
 – How AI fits into training without replacing human coaches
 – Building trust with reps in high-pressure environments

What’s your go-to move for keeping reps engaged like adults, not students?


 P.S. Link to the full episode in the comments! 👇 | 28 | 14 | 3 | 5d | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:49.719Z |  | 2025-12-02T15:13:27.365Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399792378015948800 | Document |  |  | Natural talent is the worst predictor of sales success.


So why do so many teams still hire for “the vibe” instead of the mindset?


On the latest SellMeThisPen AI Podcast, I sat down with Thomas Waites of TW Sales, operator behind 3 successful acquisitions, and someone who’s built multiple high-performance sales orgs from scratch to unpack this exact mistake.


"I watched 'natural' salespeople plateau while awkward, determined ones surpassed them."


Thomas learned this early. He’d onboard 20–40 reps at a time and assume the charismatic ones would win.

They didn’t.

The “naturals” coasted…then stalled!


The “awkward but hungry” reps kept grinding then sprinted past everyone.
That observation shifted everything for him.
Because the real problem wasn’t skills.
It was the system those skills lived inside.


He told a story about inheriting a team where people complained about 9 a.m. meetings because it interfered with their morning golf routine.

That wasn’t a skills issue.

That was a mindset and behavior issue and no amount of training fixes that.

So he rebuilt the culture from the ground up.

Reps stopped blaming leads.
Ownership went up.
Performance followed.


Here’s the framework Thomas shared for building a winning environment instead of a “talent-dependent” one:

1️⃣ Hire and bet on mindset first
If someone owns their performance, you can develop everything else. If they blame the world, nothing you do will matter.

2️⃣ Create systems that lift the entire team
Peer-to-peer pairing, shared wins, and simple metrics make improvement unavoidable not optional.

3️⃣ Lead with belief, not fear
High performers don’t need pressure; they need support. If you treat them like losers, they’ll play like it. If you treat them like champions, they rise.

4️⃣ Reward behavior as much as outcomes
Crushing quota isn’t enough. If someone poisons culture, they’re a short-term win and a long-term loss.

If you want a team that keeps improving, you don’t build around the naturals.
You build around the mindsets that scale.


Swipe through the carousel above for the full breakdown! 👉 | 23 | 6 | 4 | 1w | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:49.720Z |  | 2025-11-27T12:53:04.413Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396174739787968513 | Video (LinkedIn Source) | blob:https://www.linkedin.com/44209a8d-fd88-4bd8-8b7c-b6bb1c35b351 | https://media.licdn.com/dms/image/v2/D4E05AQEnbLIGUSfSpg/feedshare-thumbnail_720_1280/B4EZqR9sY_KYA0-/0/1763385463298?e=1765778400&v=beta&t=uZAG1xtnu6CrW7JVZrMNWZ-c7Jb8ZKpUxF-2-Sx3VXU | AI didn’t make L&D easier, it exposed who’s been coasting!


So the real question is…are you actually using it to level up, or just hoping it replaces the work you don’t want to do?


The other day on the SellMeThisPen AI Podcast, I sat down with Jen Rutsky an L&D leader with a legal background who’s been hands-on with AI long before it went mainstream. She’s worked across tech, law, finance and she’s one of those  operators who actually experiments instead of theorizing.


Jen described a shift she’s seeing: most L&D orgs still cling to e-learning modules that nobody remembers 20 minutes later. Meanwhile, learners want interactive, kinesthetic, real-time practice. And AI finally makes that possible.


She told a story about managers preparing for tough conversations. Traditionally, they’d wait for Jen to role-play with them assuming her calendar wasn’t booked for the next two weeks. Now? They can fire up a tool, simulate the scenario, and get coaching instantly. No embarrassment. No bottleneck. No excuses.

That’s the shift:

We’re not building courses anymore. We’re building systems that adapt.

Here’s the core idea: L&D relevance now comes from teaching people how to use AI not from producing content.

1️⃣ AI is the new practice field.
Your learners shouldn’t wait for workshops. They should rehearse critical conversations, pitches, and decisions inside AI-driven role-plays, the reps are unlimited, judgment-free, and instant.

2️⃣ Your value is orchestration, not instruction.
Jen’s building workflows, coaching layers, feedback loops. AI handles the repetition; humans handle the nuance. L&D pros who cling to “content creation” lose. Those who build systems win.

3️⃣ Real-time relevance is now the standard.
If a document, process, or naming convention changes, AI can update onboarding flows instantly. No more outdated links, stale PDFs, or credibility-killing errors. L&D finally becomes current instead of catching up.


In the full episode we cover:

– Why e-learning as we know it is fading fast
 – How managers should approach hallucinations with “trust but verify”
 – Building AI champion programs inside companies
 – What modern onboarding looks like when every persona gets personalized learning from day one

L&D pros -> what’s one AI use case you’ve tried that actually moved the needle?

P.S. Link to the full episode in the comments! 👇 | 17 | 3 | 3 | 2w | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.187Z |  | 2025-11-17T13:17:52.247Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7394364189252743170 | Document |  |  | Everyone in the space is obsessed with efficiency BUT blind to what’s coming.


What happens when AI makes your whole sales org faster…but forgettable?

On the SellMeThisPen AI Podcast, I sat down with Kelly Wright, Founder & CEO of Culture Driven Sales, former President & COO at Gong, and the sales exec who took Tableau from $0 to $850M in revenue.


"People buy from people. Companies don't buy from companies."

That’s not fluff, it’s the hard truth about what separates top sellers from the rest.

Kelly built Culture Driven Sales after watching tech companies chase speed at all costs.

Every dashboard. Every pipeline review. Every tool, all aimed at efficiency. 
But as she puts it, AI is going to make everyone equally efficient.

Same data. 
Same speed. 
Same playbooks.

So what’s left?
Your people!


At Tableau, Kelly broadened reps’ development path with storytelling training. Every rep went through it, learning how to connect emotionally, not just close logically.

Within months, customers were calling her asking, “Why are your reps so different? They actually get me.”

That’s what happens when you lead with culture.


Here’s the 3-step playbook she shared to build that edge:

👉 Start with purpose.
If your team can’t tell you why your company exists, you’ve already lost. Anchor every deal in mission, vision, and values.

👉 Train for connection.
Teach reps to read the room, grab attention in 15 seconds, and tell stories that stick. That’s emotional enablement.

👉 Build unshakable trust.
Be the vendor who tells the truth even when it’s not convenient. 


That’s how you win loyalty AI can’t automate.
AI will level the field. Culture will tip it back in your favor.

Go check the full framework in the carousel above for more insights! 👉 | 34 | 6 | 4 | 3w | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.188Z |  | 2025-11-12T13:23:23.361Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7393634745282297858 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0bf27fd0-73d0-4c59-9a22-ba3021ba7257 | https://media.licdn.com/dms/image/v2/D4E05AQFpLG3aJvDQ9Q/feedshare-thumbnail_720_1280/B4EZpt3j0vGUA0-/0/1762779872929?e=1765778400&v=beta&t=lyjoJqZLL3uyyk7c4UPeMjZub3hWl3AdyNPJJkLOe-8 | When everyone’s powered by AI, culture becomes your advantage.

When every competitor has the same data, same tools, and same efficiency…what’s left to set you apart?


On the latest SellMeThisPen Podcast, I sat down with Kelly Wright former EVP of Sales at Tableau, ex-President & COO at Gong, and now founder of Culture Driven Sales. We talked about how AI is making sameness the norm and why your culture will be what breaks you out of it.


“If your people can inspire, motivate, and communicate in a way that makes others believe they’re part of something special, that’s the real differentiator.”


At Tableau, in addition to traditional sales training, they trained the entire sales org in storytelling. Every rep learned how to connect emotionally first, then sell. The results? 

Customers started saying “Your team feels different.” Prospects trusted them before the demo even started.That’s the power of culture, it shapes how your people show up long before the pitch begins.


👉 Start with your “why.” Before the product, sell your belief. People buy from conviction, not comparison.

👉 Enable connection, not just conversion. Emotional intelligence beats perfect talk tracks every time.

👉 Protect your mission internally. When your team believes, your buyers feel it.


In the full episode we cover:

– The shift from sales driven to culture driven organizations
– Storytelling as a competitive advantage
– How companies lose (and revive) their “why”
– Why AI will make culture your ultimate differentiator


What’s your take -> can belief still win in a data driven world?

P.S. Link to the full episode in the comments! 👇 | 29 | 12 | 4 | 3w | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.189Z |  | 2025-11-10T13:04:50.366Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7390003148033060864 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3e7408d4-55d6-4f23-a1b6-1510a185358e | https://media.licdn.com/dms/image/v2/D4E05AQHvghFlt5n4dQ/videocover-high/B4EZo6QnXzGoBU-/0/1761914030488?e=1765778400&v=beta&t=75557IPwkJCoiyThsEO2bh0S-L_lpEll3JxBF3XVgRM | Two of my favourite GTM pros had a killer exchange on the SellMeThisPen AI podcast 🎙️

Tim Work asked Gail Behun:

“Where do you see the focus shifting from pre-sales to post-sales and what are you going to be doing differently with your post-sales teams when it comes to enabling them for success in the next few years?”

Gail:

We can’t just enable sellers, we have to understand the buyer’s journey after the sale. 70% of customer value happens post-sale, and the biggest gap is the handoff.

AI can bridge it, pulling every note, promise, and signal into a clean, smart handoff so CS teams start with context, not chaos.


My question for our leaders 👇 

If most of the value comes after the deal closes...
Why aren’t we enabling the teams who own that part the same way we do our sales orgs? | 23 | 5 | 3 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.191Z |  | 2025-10-31T12:34:10.110Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7388926870148505600 | Document |  |  | Your CRO just spent $1M on a methodology no one asked for.

How do you turn a doomed rollout into a win when the decision’s already been made?


On the latest SellMeThisPen AI Podcast, I sat down with Gail Behun, a longtime enabler. We dug into how enablement leaders can save a rollout that’s already set up to fail and still make it stick.


"You can’t change the methodology choice, but you can control the implementation."


Here’s how Gail breaks it down:

When the CRO drops a “We’re rolling out MEDDIC next quarter” bomb without any discovery or alignment, it’s already chaos. The team’s unprepared, messaging’s fuzzy, and the pressure’s all on enablement to make it work.


She’s been in that exact spot before, a top-down rollout, big spent, zero context. Instead of pushing back, she reframed it: “We can’t stop it, but we can own how it lands.”


Her 4-stage playbook turned a messy rollout into a success story:

1️⃣ Do Discovery Anyway -> Even if the choice is made, go back and ask: How are sellers selling today? Why this? Why now? You can’t build relevance without understanding reality.

2️⃣ Define Your Control Points –> You can’t control the methodology, but you can control how it’s introduced, sequenced, and reinforced. Draw your “flexibility zone” early.

3️⃣ Contextualize to Your Business –> Translate every acronym, every stage, to your sellers’ actual world. “What does ‘Champion’ mean in our buyer org?”

4️⃣ Build It Into Your System –> Weekly deal reviews, monthly spotlights, daily coaching moments. The goal: make the methodology impossible not to use.


The takeaway:

Enablement doesn’t fail because of bad methodologies. It fails when we skip the groundwork. Discovery, context, and repetition turn a forced rollout into a business driver.

Swipe through the carousel above for the full framework! 👉 | 21 | 10 | 1 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.192Z |  | 2025-10-28T13:17:25.466Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7388552471440281601 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4d808bf6-1287-4f73-8b0a-b2c300e018f3 | https://media.licdn.com/dms/image/v2/D4E05AQFfqlRDcfZSZw/feedshare-thumbnail_720_1280/B4EZolpRrkHEAw-/0/1761568171463?e=1765778400&v=beta&t=km3i80sPBHvGYfgmwbu8OWZVUVWf2IHMmA50PqFRZfA | Enablement that can’t prove value doesn’t survive.

What’s the one thing every enablement leader needs to stop doing right now?
Waiting for revenue impact to validate their work!


I had Gail Behun, Head of Revenue Enablement at Headway, on the SellMeThisPen AI Podcast, and we talked about what’s really happening in enablement.

It’s not disappearing…it’s being redefined.

Most teams still chase lagging indicators, revenue, win rates, quota attainment. But those take months. And leadership can’t wait that long.

Gail flipped the script by tracking leading signals, proof of progress before the dollars hit the board.


Here’s her breakdown:

1️⃣ Confidence scores: If sellers don’t feel ready, they won’t sell it.
2️⃣ Call intelligence: Are they actually pitching it? Are buyers reacting?
3️⃣ Proposal frequency: If it’s not showing up in decks, it’s not real.
4️⃣ Revenue: The final proof, not the starting point.

That’s how you prove impact before the pipeline catches up.


In the full episode we cover:

 – How AI exposes weak enablement (and rewards the strong)
 – Why “data hygiene” is a losing battle and what to do instead
 – Turning enablement from training into a business driver
 – Building confidence as the new competitive advantage

How are you proving enablement’s value inside your org?

P.S. Link to the full episode in the comments! 👇 | 24 | 5 | 3 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.193Z |  | 2025-10-27T12:29:41.858Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7387458448801554432 | Document |  |  | Most “change” programs fail before they even start.


When people don’t actually change, every new tool, process, and “transformation” ends up collecting dust.


We skip the human part -> clarity and alignment, then wonder why nothing sticks!


On the latest SellMeThisPen AI Podcast, I sat down with Dina Berger, Ph.D. Sales Enablement Leader @ AWS, who’s led global transformation programs that actually last.


“It’s no different than selling to a customer, you need to make the case for why the shift matters.”


Dina broke down the 4 stages of effective change management and the one stage most companies skip that kills the whole thing.


Swipe through the carousel above to see where your team might be stuck and how to fix it 👉 | 18 | 4 | 2 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.194Z |  | 2025-10-24T12:02:26.535Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7387096908164538369 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3418beed-d4f7-4c95-bdfe-a8ee86c23d60 | https://media.licdn.com/dms/image/v2/D4E05AQHoqPndTod6Tg/feedshare-thumbnail_720_1280/B4EZoQ9ZRpHMA8-/0/1761221122358?e=1765778400&v=beta&t=xG4c0ZJYzTpCZD0dY-yFepvgUOyCCSOZPHdFc6ERx5k | Most change programs fail.

But what if the failure starts before the change even begins, at the top?


On the latest SellMeThisPen AI Podcast, I sat down with Dina Berger, Ph.D. Sales Learning and Development Leader, a senior enablement and change management leader at Amazon Web Services, to talk about the brutal truth behind failed transformation efforts and what actually drives adoption.


"One third of all change programs fail because decisions are made without the right information."


We've all seen it happen -> leadership announces a “must-do” initiative, tech stacks are bought, sales teams are told to “get on board”… and nothing sticks. Why? Because nobody asked the field if it made sense.


Dina explained how a simple reality check from enablement based on field feedback, not boardroom logic can prevent months of wasted time and money.


Here’s how she breaks it down:

1️⃣ Clarity first. Before anything else, define why the change matters. What problem are you actually solving?

2️⃣ Alignment next. Get leaders, managers, and key influencers to buy in. Without them, your “mandate” is just noise.

3️⃣ Training last. Enablement doesn’t start with slides, it starts with empathy. Teach through the lens of what’s in it for me.

4️⃣ Sustain the shift. Reinforce, measure, and iterate. Change isn’t an event; it’s a process of earning belief.


In the full episode we cover:

 – How to manage up and give leadership reality checks.
 – Building change coalitions that actually drive adoption.
 – Using data (not emotion) to prove enablement impact.
 – What to do when your change program doesn’t work the first time.


What’s your take -> does change really fail at the top, or in the trenches?

 P.S. Link to the full episode in the comments! 👇 | 18 | 5 | 3 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.196Z |  | 2025-10-23T12:05:48.530Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7384206089023660032 | Document |  |  | If your AMs still talk like support, you're bleeding revenue.

Why are we still coaching to checklists when strategy drives revenue today?


On the latest SellMeThisPen AI Podcast, I had a great conversation with Tim Work, Senior Director at Actabl, about what today’s account managers really need to succeed.


"The AM you hired five years ago isn’t the AM you need today."

Let that sink in.

Tim’s seen it firsthand: most companies still treat AMs like glorified renewal clerks. But the role has evolved and enablement needs to catch up.


He told a story about building a renewal strategy with his team. At first, it was all about timelines “when do we start talking about renewal?” But then the lightbulb went off...

Renewals don’t start 90 days out.
They start on Day 1.

So if you're not enabling AMs to drive value from the moment a deal closes, you're already playing catch-up.

Here’s what that enablement needs to look like:

1️⃣ Train AMs like sellers
Not support. Give them ROI storytelling skills, commercial acumen, and access to sales strategy sessions, not just product decks.

2️⃣ Coach to behaviors, not tasks
Tim said it best: "You can't manage to activity volume anymore." Instead, review call recordings, look at relationship depth, and use AI to track quality, not just quantity.

3️⃣ Normalize AI in the workflow
Top reps aren’t hiding their use of AI, they’re winning with it. Don’t make it taboo. Make it a core part of prep, follow-up, and planning.

4️⃣ Start renewal motions from implementation
Introduce AMs early. Map executive check-ins. Build trust before it’s time to “sell.”


Go check the full framework in the carousel above for more insights! 👉 | 23 | 2 | 1 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.198Z |  | 2025-10-15T12:38:43.538Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7383844732440956928 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7af64c47-2c22-4f78-9ff4-f3b16b3b711c | https://media.licdn.com/dms/image/v2/D4E05AQEoLcEot8aZRA/feedshare-thumbnail_720_1280/B4EZnivhw2KgA0-/0/1760445735170?e=1765778400&v=beta&t=ghZpv6ziaOqZqtOS6U0LhD83NBfPrJYO4OEodxja7PA | How many customers would renew today if you didn’t have to ask?


On SellMeThisPen AI Podcast, I sat down with Tim Work, Senior Director of Account Management at Actable, who shared how proactive engagement keeps customers confident and connected, long before renewal comes up.

“You win when you lead customers along the journey, not when you fix their problems.”


Most vendors wait until usage drops or emails go quiet.
By then, it’s already too late.


Tim’s team took a different approach:

1️⃣ At signing: Introduce yourself and outline a success plan, start the partnership right.

2️⃣ 3 months in: Check in with the exec sponsor “If renewal was today, would you say yes?”

3️⃣ 6 months in: Bring in Product or Leadership to show new value before issues ever surface.

That steady rhythm built trust and customers who wanted to stay.

Proactive engagement isn’t about fixing problems. It’s about never letting them pile up.


In the full episode we cover:

 – How proactive playbooks reduce churn
 – The right cadence for customer check-ins
 – Why renewal readiness starts with alignment, not discounts


What’s one proactive move that’s kept your customers around longer?

P.S. Link to the full episode in the comments! 👇 | 40 | 14 | 3 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.199Z |  | 2025-10-14T12:42:49.415Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7381655780598423553 | Document |  |  | Tech doesn’t fail. Adoption fails.


What if the tool you think “doesn’t work” is actually fine and it’s your rollout that’s broken?


On the SellMeThisPen AI Podcast, I sat down with Iulia Tesfai, MBA, Founder of RevTectonic and fractional RevOps leader who’s spent 15+ years helping GTM teams scale.

She’s seen it firsthand - amazing tools, terrible rollouts.

Most teams don’t have a tool problem, they have an adoption problem.

 Month one, leadership is fired up.
 Month two, everyone’s trained.
 Month three, usage drops.
 By month six, people say, “We need a new tool.”


Iulia learned this the hard way. Her team once rolled out a platform that could’ve saved reps hours a week. Instead, it collected dust, until she changed her approach.

She turned adoption into a game: pulled disqualified opps into ChatGPT, turned them into a trivia challenge (“Spot the compelling event”), and suddenly, reps were asking how to use the tool better.


Here’s her 5-rule framework for winning the adoption game 👇

1️⃣ Start with a champion. Get your top performer to pilot it—credibility spreads faster than memos.

 2️⃣ Move at your team’s pace. Crawl → walk → run. Adoption dies when you dump 47 features on day one.

 3️⃣ Make it relevant. Every role needs to see their win in it.

 4️⃣ Make training engaging. Gamify, compete, laugh - whatever keeps curiosity alive.

 5️⃣ Show value per role. Reps, managers, execs - they each care about different metrics. Meet them there.

People don’t resist change. They resist being changed.


Swipe through the carousel above for the full breakdown 👉 | 18 | 0 | 4 | 1mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.202Z |  | 2025-10-08T11:44:42.627Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7380964386498093056 | Video (LinkedIn Source) | blob:https://www.linkedin.com/164da533-73aa-4307-a37e-36f1a0dd483d | https://media.licdn.com/dms/image/v2/D4E05AQG0J24yiYT_Ig/feedshare-thumbnail_720_1280/B4EZm5z2riHgA0-/0/1759759005334?e=1765778400&v=beta&t=5GntAdY3adtujcHJQ1NoujOhg4MKkrI29w8ZICeOxws | Tech doesn’t fail. Adoption does.


Ever wonder why teams keep buying shiny new tools but never see results?

The other day on the SellMeThisPen AI Podcast, I sat down with Iulia Tesfai, MBA, Fractional Head of RevOps and founder of RevTectonic, to talk about the real reason so many tech rollouts collapse and what to do about it.


Iulia’s been on the front lines of revenue operations for over 15 years. From HP in Romania to scaling SaaS teams in the U.S., she’s seen one pattern repeat: 

companies don’t have a tech problem, they have a trust and adoption problem.


Here’s the story.

A client signs a two-year deal with a big-name platform. Six months later, it’s chaos - low usage, bloated stack, zero ROI. The execs want to rip it out and start over.

But Iulia digs deeper. Turns out the tool works fine. The rollout didn’t. No champions. No pacing. No clear value for the reps.

That’s when she started applying what she calls her “Three Adoption Rules.”

1️⃣ Find your champion. Every team has an overachiever willing to test something new. Get their buy-in early and make them the success story.
2️⃣ Move at your team’s pace. Crawl → walk → run. Don’t push shiny tech faster than your culture can absorb it.
3️⃣ Start with what you have. Most tools already do more than your team realizes. Explore features before buying the next miracle product.


When adoption fails, even the best tool becomes shelfware.

In the full episode we cover:

 – The identity crisis in RevOps today
 – How AI is reshaping revenue alignment
 – Why fractional RevOps is exploding
 – Iulia’s “gamified enablement” tactics that actually work


What’s your take, does your team have a tech problem or an adoption problem?


P.S. Link to the full episode in the comments! | 22 | 3 | 2 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.204Z |  | 2025-10-06T13:57:21.428Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7379863408508051456 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e0dbb297-a172-4bbc-9c8d-c483b51394b5 | https://media.licdn.com/dms/image/v2/D4E05AQFIlfDmiqwnnw/videocover-high/B4EZmqKfiVHMB8-/0/1759496530510?e=1765778400&v=beta&t=CY8Rcw2_DJncmJprBpUiPbk4J3b1MMY9cJQL2RCDbK8 | How has your career impacted your personal development?

Lisa Honaker told me that mindfulness and improv were the most transformative leadership lessons she’s ever had.

What’s been the most surprising way your career has shaped you? | 27 | 10 | 2 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.205Z |  | 2025-10-03T13:02:27.820Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7378775720661065728 | Document |  |  | Cutting headcount isn’t a strategy. 
It’s fear disguised as leadership.


What if the real path through downturns is doubling down on your people?


On the SellMeThisPen AI Podcast, I sat down with Lisa Honaker, VP of Account Management at Actabl and former leader at FedEx and Highspot. With 20+ years of revenue leadership, she’s lived through multiple downturns and her perspective was sharp.

"My argument is that you sell your way through it."


When markets tighten, too many execs pull the same lever: cuts. The problem? 

You trigger fear, kill trust, and actually weaken performance. Lisa’s take was different, she explained how she’s led teams through tough cycles by focusing on people and relationships.


At FedEx and later in SaaS, she saw how quickly customers and employees lose confidence when leaders hunker down. Instead, she shifted focus: equip teams to deeply understand customers, build authentic trust, and align roles to strengths. That’s how you grow while others retreat.


Here’s her 3-part breakdown:

1️⃣ Tailor enablement. Pre-sales acquisition skills aren’t the same as post-sales retention. Training should reflect that.

2️⃣ Train for real discovery. Teach reps to use AI and research tools to uncover customer + industry challenges and walk into calls already speaking the buyer’s language.

3️⃣ Put people in roles they love. Hunters hunt. Farmers farm. When people play to their strengths, performance rises, and cuts aren’t the answer.

Leaders talk about resilience, but Lisa showed how to build it: protect the people who’ll carry you through.


Swipe through the carousel above for the full framework! 👉 | 22 | 2 | 2 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.207Z |  | 2025-09-30T13:00:22.829Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7378405549819834368 | Video (LinkedIn Source) | blob:https://www.linkedin.com/af4ee595-5017-455b-a5a6-f21211c3dffe | https://media.licdn.com/dms/image/v2/D4E05AQFpiGIL8YHBaA/feedshare-thumbnail_720_1280/B4EZmVcqH7KQAw-/0/1759148943004?e=1765778400&v=beta&t=WmQ8jlyW5xn7y6KZTLDcsPTV7taGFxej9gQFPjt8nEk | Fragile economies don’t kill companies. Leadership choices do.


Two orgs can face the same downturn. One panics and slashes. The other leans into customers and comes out stronger. Which are you?


On the latest SellMeThisPen AI Podcast, I sat down with Lisa Honaker revenue leader at FedEx, Highspot, and now Head of Account Management at Actabl. She’s led teams through downturns and fragile cycles, and her advice is blunt.

"My argument is that you sell your way through it."


Lisa’s seen how fear-driven cuts ripple: customers lose trust, teams lose confidence, and the business loses momentum. Yes, trimming bloat matters. But shrinking back as your only move? That’s playing not to lose!


Her playbook for a fragile economy:

1️⃣ Know your customers deeper than ever. Don’t stop at surface “value.” Study their industry headwinds, their competition, even their personal stakes.

2️⃣ Be the problem-solver. Buyers today aren’t looking for pitches. They want advisors who reduce risk and make them look smart in front of their org.

3️⃣ Protect your people. Fear follows employees home. Fear kills performance. Support unlocks the discretionary effort that actually drives growth.


In the full episode we cover:

 – Why reflexive cuts backfire harder than most execs realize
 – How account managers may need sharper competitive intel than AEs
 – Lisa’s rebranding strategy from FedEx to SaaS
 – What makes sellers like Peter Schmitz unforgettable in tough times


What’s your take -> do you cut, or do you sell your way through?


P.S. Link to the full episode in the comments! 👇 | 30 | 23 | 3 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.208Z |  | 2025-09-29T12:29:27.223Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7376594758967791616 | Document |  |  | Most AI rollouts fail.
Why? Because leaders chase tools before building foundations. 
What if adoption started with literacy, not logins?


On the latest SellMeThisPen AI Podcast, I had a great conversation with seasoned enabler Kate Stringfield ✨. She’s led global teams and rolled out AI across sales, success, and partner orgs.


"You need foundational knowledge before you can have good conversations with customers."

Kate didn’t start with tools. She started with education. Sellers first learned what AI really is, how it differs from automation, what risks exist, and only then did tools enter the picture.


Here’s what she learned about making adoption stick:

1️⃣ AI Literacy first – Without a baseline, reps either resist change (“why fix what works”) or misuse tools. Literacy turns fear into curiosity.

2️⃣ Champion stories - Her team identifies top performers, documents how they’re winning with AI, and shares those stories broadly. Peer-driven FOMO works better than mandates.

3️⃣ Conversation over control - Instead of banning “shadow tools,” Kate’s team asks why reps picked them, learns the value, and finds safer ways to replicate it. This builds trust instead of secrecy.

4️⃣ Measure what matters - Forget vanity stats like course completions. Look at real behavior change: Are reps bringing AI into customer conversations? Is pipeline growing because of it?

Too many companies rush to buy licenses, throw out tool training, and then wonder why adoption collapses. Kate’s blueprint flips the script: foundation, champions, conversations, and behavior-based measurement.


Swipe through the carousel above for the full framework! 👉 | 23 | 4 | 3 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.210Z |  | 2025-09-24T12:34:01.041Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7375881092437798912 | Video (LinkedIn Source) | blob:https://www.linkedin.com/925835d8-b3ea-461b-aea6-0519c2b61fb3 | https://media.licdn.com/dms/image/v2/D4E05AQFQXOnt2o13pA/feedshare-thumbnail_720_1280/B4EZlxkqNlHgA8-/0/1758547060774?e=1765778400&v=beta&t=Y5JVSyX2swtCO_mrjiHhMtYfoSWSuuoaw03rO5j3EOQ | Most AI rollouts fail.


What if the real problem isn’t the tools but the missing "foundation"?


On the latest SellMeThisPen AI Podcast, I sat down with Kate Stringfield ✨ Stringfield, a former seller turned enablement leader managing a global team, and she’s knee-deep in helping sellers adopt agentic AI.


"First we have to teach people what AI actually is, before asking them to sell with it."


Kate’s story is an enablement done right. Instead of pushing shiny tools and praying for adoption, her team slowed down. They started by teaching every GTM function the basics: what AI is, what it isn’t, and how it differs from automation.

That foundation gave people the language and confidence to use AI in their workflow. Only after that did they layer in use cases, customer pain points, and solution positioning.


Here’s Kate’s 3-step playbook for driving adoption that actually lasts:

1️⃣ Start with education. Make sure every rep knows the difference between automation, generative AI, and agentic AI. Without this, you’re setting them up to fail.

2️⃣ Create desire. Show reps and managers how AI can reduce pain, fewer tools, less manual work, faster research so they actually want to change.

3️⃣ Reinforce and measure. Adoption isn’t a one and done. Track behavior change, share wins, and continuously refine programs to prove business outcomes.


In the full episode we cover:

 – How to handle pushback from skeptical or "stuck in their ways" sellers
 – The role of managers in sustaining adoption
 – Why clarity of vision and integration matter more than tool selection
 – Practical rollout examples using Gemini and ChatGPT


What’s your take -> Are companies moving too fast with AI in sales?


P.S. Link to the full episode in the comments! 👇 | 27 | 12 | 3 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.213Z |  | 2025-09-22T13:18:09.681Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7374430926648537088 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f8c3c522-ad0e-41c9-8b32-96dee04975ca | https://media.licdn.com/dms/image/v2/D4E05AQH0MPXUyFZ50w/videocover-high/B4EZlc9vIGHICA-/0/1758201334876?e=1765778400&v=beta&t=Qm4BB6FNSnVWDCBfCe7E2W1f_lYikoxPGp9nTtqK9_0 | When a seasoned sales leader asked a seasoned sales enablement professional:


Matt L Marshall on SellMeThisPen AI podcast: “What’s the best way to stay aligned with a sales leader to drive enablement through an organization?”


Shannon Izquierdo says:

➡️ Show up.

Enablement leaders should be in weekly sales meetings - not as silent observers, but as active contributors.

➡️ Bring data.
Don’t just talk about enablement initiatives - share metrics. For example:
“Only 30% of the team has engaged with the new playbook.”
“Here’s where leaders need to reinforce messaging.”

➡️ Be on the agenda.
Enablement shouldn’t be an afterthought - If sales teams review pipeline and wins every week, enablement deserves a slot too.


The takeaway -> Alignment isn’t a quarterly check-in! It’s a weekly habit. | 19 | 6 | 1 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.215Z |  | 2025-09-18T13:15:43.214Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7373710562922381312 | Document |  |  | Are you losing deals to competitors?
maybe your sellers don’t have the skills?
or your product’s not making an impact?


Win-loss analysis should answer all of that.
It’s a cross-functional GTM motion if you build it right.


On SellMeThisPen AI Podcast, I sat down with Shannon Izquierdo - ex-FedEx, now founder of The Prompt Insight Group—to unpack her 6-step win-loss framework.


Here’s what she shared:

 – Start with exec buy-in, or don’t start at all
 – Use multiple sources (CRM ≠ truth)
 – Tag feedback to the right team: Product, Enablement, Marketing, etc.
 – Kill the bloated content no one uses
 – Build monthly reviews to track insight → action


She turned off 1,500 pieces of content. Nobody noticed!
That’s the problem.


This isn’t about more data.
it’s about making the data matter.


Swipe the carousel for Shannon’s full breakdown 👉 | 25 | 2 | 5 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.216Z |  | 2025-09-16T13:33:15.118Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7373342540009283584 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3da147de-2f7a-43d2-ac78-0bf96fe2ff73 | https://media.licdn.com/dms/image/v2/D4E05AQG3Q88r2NyqUQ/feedshare-thumbnail_720_1280/B4EZlNf2fBKoAw-/0/1757941820493?e=1765778400&v=beta&t=Ur2CZKqJA-X42NccsbwQtC5PPUm1SLiIqN0SwhelJcs | “We turned off 1,500 pieces of content… and no one noticed.”


What if your sales team doesn’t need more content but less, with better context?


On the latest SellMeThisPen AI Podcast, I had a great conversation with Shannon Izquierdo, founder of the Prompt Insight Group and a veteran of sales enablement at companies like FedEx and Kinaxis.


"I'd rather have three good pieces of content and create sales plays all day long to help all the sellers."


Shannon's approach is rooted in one reality: most sellers don’t use most content. Not because they don’t care, but because they don’t know how to position it.


She shared a story where she archived 1,500+ assets and nobody asked about them. Nobody was using them. It was a wake-up call: volume ≠ value.


Instead, Shannon advises teams to go narrow and deep:

1️⃣ Segment your sellers. Inside sales ≠ enterprise ≠ field reps. Build plays specific to their role, funnel stage, and buyer type.

2️⃣ Reuse, reposition, repeat. One strong piece of content can power multiple sales plays—top, mid, and late funnel. Same asset, different angles.

3️⃣ Context is king. Tell your sellers why a battle card changed. Connect the dots back to win-loss insights. That’s how you build trust.

4️⃣ Get collaborative. When marketing, product, and enablement sync up, you stop flooding reps with fluff and start giving them what actually drives revenue.


In the full episode we cover:

 ✅ The right way to run win-loss analysis (without it becoming shelfware)
 ✅ Why “no decision” is your real competitor
 ✅ Using sales plays to scale insights across your org
 ✅ How early-stage startups can bake enablement into their culture


What’s your take on “less content, more context”?


P.S. Link to the full episode in the comments! 👇 | 24 | 1 | 6 | 2mo | Post | Michael Ocean | https://www.linkedin.com/in/michaelocean | https://linkedin.com/in/michaelocean | 2025-12-08T05:11:56.218Z |  | 2025-09-15T13:10:51.618Z |  |  | 

---



---

# Michael Ocean
*SellMeThisPen AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 15 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [GTM AI Podcast with Coach K and Jonathan Moss](https://creators.spotify.com/pod/profile/gtmaipodcast/episodes/AI-for-Business-Leaders-How-Causal-Analytics-Drives-8X-Growth-e2rhei7)
- Category: podcast

### [Michael Ocean - SellMeThisPen | LinkedIn](https://ca.linkedin.com/in/michaelocean)
*2025-05-14*
- Category: article

### [Blog | AI Sales Role-Play and Real-Time Assistant - SellMeThisPen](https://www.sellmethispen.ai/blog)
*2025-05-07*
- Category: blog

### [Interview with Michael Ocean on SMTP podcast - Venkat's Blog](https://www.nagaswamy.com/post/interview-with-michael-ocean-on-smtp-podcast/)
*2025-07-16*
- Category: podcast

### [Sales Team Building Activities to Boost Performance](https://www.outbackteambuilding.com/blog/sales-team-building-activities-to-boost-performance/)
*2025-03-27*
- Category: blog

---

## 🎬 YouTube Videos

- **[Gerry Stellenberg and Michael Ocean from Multimorphic - Episode 69](https://www.youtube.com/watch?v=txyhAXbICb4)**
  - Channel: The JBS Show with Jamie Burchell
  - Date: 2025-08-14

- **[How Freedom Fuels Resilience: Michael Ocean&#39;s Founder Journey | FBR S2E2](https://www.youtube.com/watch?v=6cEmiH69ymg)**
  - Channel: Wholegrain Wisdom
  - Date: 2025-04-10

- **[#12 GTM AI Podcast: Michael Ocean with Sellmethispen.ai, Rookie to Rockstar, AI Transforming Sales](https://www.youtube.com/watch?v=YUk2zA_MMt0)**
  - Channel: GTM AI Academy 
  - Date: 2024-04-29

- **[Linkedin Tear Down Podcast with James Ski &amp; Michael Ocean](https://www.youtube.com/watch?v=bmJhf5OcTzU)**
  - Channel: Sales Confidence
  - Date: 2024-11-21

- **[Episode 233″ – Weird Al Pinball Designers Stephen Silver &amp; Michael Ocean (Part 1)](https://www.youtube.com/watch?v=b0Ch2wBr5Qo)**
  - Channel: Dave & Ethan's 2000′′ Weird Al Podcast
  - Date: 2024-06-12

- **[AI Sales Roleplays with Michael Ocean](https://www.youtube.com/watch?v=125tZTvTQN4)**
  - Channel: Avenue9 AI Marketing
  - Date: 2025-09-08

- **[Ep 116: Final Resistance with Scott Danesi and Micheal Ocean](https://www.youtube.com/watch?v=Al1d4g7FnZQ)**
  - Channel: LoserKid Pinball
  - Date: 2023-08-29

- **[AI Sales Roleplays with Michael Ocean](https://www.youtube.com/watch?v=2RlaytN8OlQ)**
  - Channel: Avenue9 AI Marketing
  - Date: 2025-09-08

- **[Founders Feel Alone. But We Don’t Talk About It](https://www.youtube.com/watch?v=ef_a8FWeggE)**
  - Channel: Wholegrain Wisdom
  - Date: 2025-06-07

- **[Is A.I. In Sales The Work Of The Devil?](https://www.youtube.com/watch?v=4qZVfDToCG4)**
  - Channel: Pete Monfre
  - Date: 2025-05-15

---

## 🔎 Press & Mentions

- **[4 Reasons AI Won't Replace Enterprise Salespeople [But Help ...](https://www.sellmethispen.ai/blog/4-reasons-ai-wont-replace-enterprise-salespeople-but-help-them-perform-better)**
  - Source: sellmethispen.ai
  - *Sep 12, 2025 ... According to Michael Ocean, founder of SellMeThisPen AI, the answer ... In this episode of Human First AI Marketing Podcast, Mike ......*

- **[Is A.I. In Sales The Work Of The Devil? - The B2B Marketing Mindset](https://b2bmarketingmindset.com/is-a-i-in-sales-the-work-of-the-devil/)**
  - Source: b2bmarketingmindset.com
  - *Find out as I talk to Michael Ocean CEO of SellMeThisPen.ai – He is a fellow ... Podcast is brought to you by The Agency Founders Network- a private ....*

- **[#12 GTM AI Podcast: Michael Ocean with Sellmethispen.ai, Rookie ...](https://www.youtube.com/watch?v=YUk2zA_MMt0)**
  - Source: youtube.com
  - *Apr 29, 2024 ... with another awesome podcast recap for ya! Today I sat down with the one and only Michael Ocean, CEO of sellmethispen.ai ... #12 GTM ...*

- **[The B2B Marketing Mindset: Home](https://b2bmarketingmindset.com/)**
  - Source: b2bmarketingmindset.com
  - *About the podcast. In weekly episodes streamed live on LinkedIn ... Find out as I talk to Michael Ocean CEO of SellMeThisPen.ai – He is a fellow ......*

- **[AI in Sales: Transforming Sales Performance in 2025 - Ebsta](https://www.ebsta.com/blog/ai-sales-transforming-performance/)**
  - Source: ebsta.com
  - *May 1, 2025 ... Michael Ocean, CEO and Founder of SellMeThisPen, has been at the ... The solution: Implement SellMeThisPen's AI role-play and coaching...*

- **[B2B Sales Enablement: How To Do It Right? – Arrows](https://arrows.to/resources/b2b-sales-enablement)**
  - Source: arrows.to
  - *Michael Ocean from SellMeThisPen AI proposes an interesting approach to training new sales reps. ... Podcast · Partner Program. Company. About · Conta...*

- **[3 Tips Every Beginner in Sales Needs to Know - SellMeThisPen AI](https://www.sellmethispen.ai/blog/3-tips-every-beginner-in-sales-needs-to-know)**
  - Source: sellmethispen.ai
  - *Feb 4, 2024 ... Follow trainers and coaches (or other sales professionals like our CEO, Michael Ocean) ... SellMeThisPen AI is actively preparing for ...*

- **[QA Internships in US companies](https://mentorpiece.education/qa-internship/)**
  - Source: mentorpiece.education
  - *Michael Ocean, CEO of SellMeThisPen.AI decided to hire one of the interns for the company. ... What does a mock interview look like? The final exam is...*

- **[SellMeThisPen AI Reviews 2025: Details, Pricing, & Features | G2](https://www.g2.com/products/sellmethispen-ai/reviews)**
  - Source: g2.com
  - *Filter 73 reviews by the users' company size, role or industry to find out how SellMeThisPen AI works for a business like yours ... Michael Ocean. Sho...*

- **[SellMeThisPen AI - Nail sales calls w/ AI coaching | AppSumo](https://appsumo.com/products/sellmethispen/)**
  - Source: appsumo.com
  - *SellMeThisPen AI. Leverage AI sales coaching, realistic role-play, and real ... SellMeThisPen AI. Sellmethispen.ai. Founder. Michael Ocean. Founder .....*

---

*Generated by Founder Scraper*
