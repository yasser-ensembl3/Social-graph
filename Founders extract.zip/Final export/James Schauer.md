# James Schauer

## Position actuelle

**Titre** : Research | Development | Design | Consulting
**Entreprise** : Octave
**Durée dans le rôle** : 12 years 11 months in role
**Durée dans l'entreprise** : 12 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Made and sold 'Touch Writer' (ML Gesture Recognition) to Bay Area firm | Advisor to iToldYa! (Toronto) | Fleksy (SF, acquired by Pinterest) | Vidy (SF, Successful ICO) | XYZ Interactive (Toronto / Hardware) | Ubiquilux (Toronto) + others

## Résumé

Enjoy https://open.spotify.com/playlist/4PaDrfiAb4cLYuqJYKSZgh

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAABC7cBPrqIItV5HA8D89k9KBjri8gkdpg/
**Connexions partagées** : 45


---

# James Schauer

## Position actuelle

**Entreprise** : Private | AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# James Schauer

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402689456471748608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7z0SwNIYnvg/feedshare-shrink_800/B4EZrs4LIOKcAg-/0/1764910741518?e=1766620800&v=beta&t=J-tokhlai32ihe5vma0dsEgielLcDg_SvfLQrJNzKJg | Roleplay' 😁 🤣 🙊 🤠 🫣 

(see the incredible OpenRouter report: https://lnkd.in/eY8QnpET) | 1 | 0 | 0 | 2d | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:06.128Z |  | 2025-12-05T12:45:01.742Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402338551759253504 | Text |  |  | Imagine in 2002 people saying that Googlers should 'Sell their options and get out of this weird 'Internet' craze! It's a bubble!' | 0 | 1 | 0 | 3d | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:06.128Z |  | 2025-12-04T13:30:39.539Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401961190869868551 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFQ9XrV-vORmA/feedshare-shrink_800/B4EZrhHemMIUAg-/0/1764713425773?e=1766620800&v=beta&t=Zwjzjx-xwwCqaZdJFMFQe0Nh2OGiCaTkGMvgrKu7R8w | A whole revolution in a tiny image: 12 Million usable / rolling token context windows (🤠🙊🌟🔥!!) for long rolling projects (OpenAI Codex) will change a lot of things in the real world. | 4 | 0 | 0 | 4d | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:06.129Z |  | 2025-12-03T12:31:09.692Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401742473011818496 | Text |  |  | They trained AI ... so that we could make content train a simpler AI ... in order to make content to train an even less intelligent AI ... and I'm not even joking 🤠 | 0 | 0 | 0 | 5d | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:06.130Z |  | 2025-12-02T22:02:03.291Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400156543717122048 | Article |  |  | The big Benedict Evans report:

https://lnkd.in/ec8VWBXn | 0 | 0 | 0 | 1w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.644Z |  | 2025-11-28T13:00:08.282Z | https://www.ben-evans.com/presentations |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7399870331919749120 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d013ff83-3c4b-4d1b-9b09-280c35573e87 | https://media.licdn.com/dms/image/v2/D4E05AQGvRXSUxHAP-g/videocover-low/B4EZrFuWtEHoBQ-/0/1764253859558?e=1765778400&v=beta&t=F4IM_SOc8FS1sDEu6oBcrtQNANAQULvytdo8j6Ypk3Y | Adam on the BBC! Good job! | 1 | 0 | 0 | 1w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.645Z |  | 2025-11-27T18:02:50.072Z | https://www.linkedin.com/feed/update/urn:li:activity:7399817083095588864/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7399565912326156288 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF1yLLLIYFBbA/feedshare-shrink_800/B56Zqdr2zgJ8Ag-/0/1763582111889?e=1766620800&v=beta&t=_bzucVrh4hhfCqCZh703SYY9WUe3FBhoHLx3d436uDU | Cursor is the 'case study' that will define a giant new AI market vector for 2026: the widespread adoption of commodity AI, mostly often Chinese entities like Alibaba, across various verticals.

The market size maybe somewhat less than that of Frontier Models - but the 'impact' will be 10x greater across industry. The 'Age of the Agent' is being held up due to economic factors more than anything else - it's 'cost prohibitive' to use tokens for consumer retail and other applications. 

The 'Open Weight' movement, led almost entirely by Chinese innovators - will break that dam and enable AI in so many more verticals than we've seen thus far.

A caveat to all of this is that Frontier Foundries can 'compete' with this Open Weight movement very quickly by releasing smaller models with Open Weights. We've seen this with OAI release of GPT OSS 20G and 120G.

It's going to be fun. Follow the Allen Institute for great information. | 0 | 2 | 0 | 1w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.646Z |  | 2025-11-26T21:53:10.785Z | https://www.linkedin.com/feed/update/urn:li:activity:7396999510591246337/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7398815847676420096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFDRqzkPQWIkQ/feedshare-shrink_800/B4EZq3fzf3KUAg-/0/1764015160325?e=1766620800&v=beta&t=HWT05VMqeMClTe0_NzNj2OqYuu9m6zVPBYaqgoM8B0M | BOOM! | 4 | 1 | 0 | 1w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.646Z |  | 2025-11-24T20:12:41.437Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7398714704107343873 | Text |  |  | Future civilizations will wonder why we created 'Super Intelligence' to wade through all the noise we've created for ourselves, instead of organizing our information and using AI for better purpose. | 2 | 1 | 0 | 1w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.647Z |  | 2025-11-24T13:30:46.931Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7397638570615730177 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4-UCYt5D66w/feedshare-shrink_800/B4EZqhZV_2J0Ak-/0/1763644367766?e=1766620800&v=beta&t=yMxLgoxX4bnlQTW04jnYclKs0Df8hq2f0-UI9lMUJAQ | This one works on two levels: those who think it's a joke, and those who know it's not, which makes it much more funny. | 0 | 0 | 0 | 2w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.649Z |  | 2025-11-21T14:14:36.713Z | https://www.linkedin.com/feed/update/urn:li:activity:7397260633056071681/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7397404696467951616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/306a43f1-bfe4-41e9-a36d-44ad5313cd16 | https://media.licdn.com/dms/image/v2/D5610AQHXOSjnt9x9EA/videocover-high/B56Zqe1X7EH8A0-/0/1763601385626?e=1765778400&v=beta&t=7Rq9ayMODE3ix0f9BVaYegXx127XFmz2k23BvuIj4no | "Alibaba is what is enabling AI Research" - Nathan Lambert, Senior Researcher, Allen Institute. Let that sink in. | 0 | 1 | 0 | 2w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.651Z |  | 2025-11-20T22:45:16.771Z | https://www.linkedin.com/feed/update/urn:li:activity:7397080423123701761/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396912532697026560 | Text |  |  | big win for Loyal & co. and validation for diversified portcos | 0 | 0 | 0 | 2w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.651Z |  | 2025-11-19T14:09:35.784Z | https://www.linkedin.com/feed/update/urn:li:activity:7396904942919352320/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7396549921136463875 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvXswTxYKoTQ/feedshare-shrink_800/B4EZqXS61NIUAk-/0/1763474921568?e=1766620800&v=beta&t=RRLsXUwF4kbHQHRuyyY5z3utwCLzmfUZWyd_59No8j0 | Most people don't realize that we're not seeing a lot of AI in many of places due to cost and performance (speed), not due to limitations on capability or 'apparent intelligence'.

Just with the AI that we have today, were it 10x faster and 10x cheaper, we'd see it deployed in 10x more use cases.

This dynamic is well underway - inference costs continue to come down, models continue to process tokens more quickly (in addition to a strong path of 'qualitative' improvement in apparent intelligence).

GPT 5.1 which performs similarly to o3 on this benchmark, is 200x less expensive, and that's over about 10 months.

Those that have an intuition for this dynamic probably underpin a key part of the continued bull case for AI. | 3 | 0 | 0 | 2w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.652Z |  | 2025-11-18T14:08:42.451Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7396124138307801088 | Article |  |  | This guy gets it, bigly. This is how Engineering is going to be (must be) at least for a while. | 3 | 2 | 0 | 2w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.653Z |  | 2025-11-17T09:56:47.914Z | https://github.com/jordanhubbard/nanolang |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7395797106596139008 | Text |  |  | Tuning an LLM is like training a bright young staffer who has spent their entire life watching TV - they 'know a lot of stuff' - yet have zero initiative or abilities. But they 'they have it in them' ... so ... you have to find the right 'tricks' to motivate them to WRITE THE CORRECT DATE FORMAT 🤦‍♂️ ! 

(😀 Ok, That last part is just some passive aggressive inside-AI humour, if you know, you know) | 4 | 1 | 0 | 3w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.654Z |  | 2025-11-16T12:17:17.478Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7395413578687873025 | Text |  |  | Tier 1 | 1 | 0 | 0 | 3w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.655Z |  | 2025-11-15T10:53:17.299Z | https://www.linkedin.com/feed/update/urn:li:activity:7395206426966798338/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7394856309466234880 | Text |  |  | The rise of AI will not spontaneously induce UBI; the former is kind of empowerment, the latter is a function of our social power structures.

Putting the aside the overstated impact AI ...

The onset of the Industrial Revolution actually increased the number of hours worked per person, as social structures were re-oriented around industrial capacity and away from the 'farm / homestead / village' which upset the previous, more feudal social order.

Much of the surplus from AI will go into the hands of individuals in terms of increased standard of living (appliances, medicine etc.) but most of the rest will accumulate as 'capital' in the hands of a very small number of people.

'UBI' and other social considerations are a measure of how 'power' is distributed in society, irrespective of the amount of wealth generated by industry.

While it's is true that the more 'technical empowerment' that is available to society, the greater the opportunity there is for some kind of distribution, the fact is, if we wanted to have '20 hour-work weeks' with '20 weeks off' - we could have had that any time in the last 150 years.

Our social structures are a result of the choices we make and we live in the making of those outcomes. 

Obviously 'less work' implies 'less surplus' (though certainly not always, which is the point of 'tech'), and there will always be legitimate issues around 'tragedy of the commons' etc.

But if we want to make effective use of this 'new tech empowerment', we'll have to be just as creative on the social and governance front, in terms of how we value labour, risk, and how we decide to regulate, tax etc.. as we are in the lab making fancy algorithms. | 0 | 0 | 0 | 3w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.656Z |  | 2025-11-13T21:58:53.963Z | https://www.linkedin.com/feed/update/urn:li:activity:7394769800234766336/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7394427855259983872 | Text |  |  | "There’s too much content ... more people are writing about things than there are things to write about" 

- 'Jason Knight' ? (courtesy 'Alex Klement') | 3 | 0 | 0 | 3w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.657Z |  | 2025-11-12T17:36:22.520Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7393693198411444224 | Text |  |  | Document understanding and characterization' is likely soon going to be a 'Feature' - not something inherently Agentic. 

It will likely involve LLM/AI in a way that might resemble Agentic architecture, but ultimately it's a sub-function and will eventually not be done within the Agentic context itself.

The Agents trying to do these things right now are likely going to collapse back onto 'General Agents' while using that functionality provided by another entity - like 'ElastiCloud' -> 'ElastiDoc' etc.. | 3 | 3 | 0 | 3w | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.657Z |  | 2025-11-10T16:57:06.678Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7392554154017054720 | Text |  |  | AI Tooling right now is much more « throw the spaghetti at the wall » then people would like to admit.

That's totally fine, nobody can predict the future, and experiments are good - but - there should be more self awareness about that fact.

Some of this tech is being passed off as 'architecture', when I think they're just experiments.

'RAG' is definitely something that has found a use, but which will be displaced by other things in the future.

'Chain-State' architectures (you know the one) I think was useful in the Chat GPT 3.5 era but which has considerably less value now. 

'Multi Agent' architecture ... Good Lord ... I would recommend staying away from that other than having fun. The fundamental problem with MAA's (my acronym) is that in most cases, there's just no need for it and the deliniations have yet to be well defined. Eventually, MAA's will take root, but when the interfaces between them become much more 'contractual' and well defined. We need them to have 'strong encapsulation' before they become really useful.  That said, there are definitely some situations where 'sub agents' (for narrow-context tasks) are going to be useful.

It's like 1999, when the 'back-end' for the Cloud was still in discovery, in fact, the word 'Cloud' was not even in use.

I think there's a big PhD thesis waiting for someone to understand the 'meme waves' of solutions that come and go, with all those 'GitHub Stars' as measures of ostensible credibility ... | 3 | 0 | 0 | 1mo | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.658Z |  | 2025-11-07T13:30:57.332Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7391462984415600640 | Text |  |  | OpenAI Codex and Claude Code, two of the most powerful and in demand solutions in existence ... do not do 'Cut & Paste'. 

Le that sink in.

That $100B company ... on the path to AGI ... can't allow you to just select and delete some text.

Nope. 

That's too hard.

You have to delete 1 character at a time, like it's 1974.

In 2025 and there's no simple tooling around basic UI. None of Google, Microsoft, or all these fancy AI companies can make 'Cut & Paste' available for a simple command line app. | 9 | 5 | 1 | 1mo | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.659Z |  | 2025-11-04T13:15:02.226Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7390189835249934336 | Text |  |  | "Incoming PhDs will drop by ~75% in the sciences starting next year as public funding for labs dries up, with engineering down 50%. Similar trends at other universities with post-doc programs." ... 🫣 🙊 🙉 😱  ... this is 'Cultural Revolution' ... a shocking level of self harm. | 1 | 0 | 0 | 1mo | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.660Z |  | 2025-11-01T00:55:59.811Z | https://www.linkedin.com/feed/update/urn:li:activity:7390150341826342912/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7389971992701161472 | Article |  |  | Definitely try this out if you have not yet. | 0 | 0 | 0 | 1mo | Post | James Schauer | https://www.linkedin.com/in/jamesaschauer | https://linkedin.com/in/jamesaschauer | 2025-12-08T05:02:10.661Z |  | 2025-10-31T10:30:22.100Z | https://claude.com/offers/oct-2025-free-month |  | 

---



---

# James Schauer
*Private | AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 16 |

---

## 📚 Articles & Blog Posts

### [Schauer Thoughts](https://podcasts.apple.com/zm/podcast/schauer-thoughts/id1659964384)
*2025-10-22*
- Category: podcast

### [Private Markets Group Ltd](https://privatemarkets-group.com/ai-technology-directory)
*2025-01-01*
- Category: article

### [Private Eye: Data and AI in Private Investment Markets](https://www.spencerstuart.com/research-and-insight/private-eye-data-and-ai-in-private-investment-markets)
*2025-01-01*
- Category: article

### [In re the Children of: Jessica Lee Schauer and James Lee Schauer.](https://law.justia.com/cases/minnesota/court-of-appeals/2003/opa030402-1104.html)
*2025-01-01*
- Category: article

### [Download Practical marketing research : measuring customer satisfaction in the government environment PDF by Schauer, James A](https://pdfdrive.to/download/practical-marketing-research-measuring-customer-satisfaction-in-the-government-environment)
*2023-01-16*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 22,628 words total*

### Schauer Thoughts
*2,336 words* | Source: **EXA** | [Link](https://podcasts.apple.com/zm/podcast/schauer-thoughts/id1659964384)

1.   [4 DAYS AGO ### How to Be More Creative: Abstraction and Improvisation (Part 3)! Here we are, the third and final installment on how to be more creative! What a wild and winding journey it’s been, hopefully everyone is forever changed. Just a reminder: the essence (aka timbre - a unique quality of a sound that distinguishes it from other sounds) of a shower thought is a rambling (divergent) musing while in the shower - an environment where sound and heat are taking ego (fixedness) offline and allowing you to make more fluid connections. Water is also a fluid, which is a substance that can flow and take the shape of it’s container aka your body, your brain - which btw are constantly changing so best to keep a lot of things fluid, moving, lest some solids clog flow. Anywho, I hope you enjoy the neuroscience, the lateral movements, the abstractions, the improv, but most of all… I hope you dance. To the beat of your own drum. Don’t fall in line, or do, it’s up to you! Talk again soon, toodles! Edit: I meant to say “IAF does RC circuits, not currents” - I was speaking so fast that I flubbed that. Also, second edit:for an electrical fire, always disconnect the power source first. Third edit at the end:Delight is surprise + happiness, not happiness + sadness - I was speaking too fast. For more information on book club, visit my Patreon:https://www.patreon.com/posts/new-book-for-143088045 Resources: This Is What It Sounds Like - Susan Rogers and Ogi Ogas Scent: A Natural History of Fragrance - Elise Vernon Pearlstine Plant Lore and Legend - Ruth Binney The Botany of Desire - Michael Pollan Most Delicious Poison - Noah Whiteman The Catalyst: RNA and the Quest to Unlock Life’s Deepest Secrets - Thomas R. Cech The Mind-Gut Connection - Emeran Mayer, MD On Muscle: The Stuff That Moves Us and Why It Matters - Bonnie Tsui The Beauty Molecule - Nicholas Perricone, MD A neurocomputational model of creative processes https://www.sciencedirect.com/science/article/pii/S0149763422001452#bbib49 Lateral Thinking: A Textbook of Creativity https://d1wqtxts1xzle7.cloudfront.net/34623410/Lateral_thinking-libre.pdf?1409804461=&response-content-disposition=inline%3B+filename%3DL_AT_ERAL_T_HINKING.pdf&Expires=1764634187&Signature=gNaugtGh5fV5tq9C76US8IlQFXrqcrkaQ8UfxyvUsb~UM2YhbJJB-9PQOD4gjmHvFVaHfBNuIWsr9a~eVOHZuveFrUdxx-zZJdmh3DDxosekQ2OoHM2trx2ixYlWitsqpWY5CfobdDM0aQVICGCb00--EUfzJJq0-gIrySw388J4EI8MvqHtWJaGEIXWJx7gwpYvhfF3xTJ12GFhUK4pvrmz8qoLYTmLLjs3AwFZ-EWPRRfcCh8M6-eELduwJaTfi05edifhH6duN9qzmVUe7Nc-egIYIxcYWzIbFvwbDqseOpBDa2vD42DEZrU9eL4vW3XiYOobx6RD31QGEEvnpQ__&Key-Pair-Id=APKAJLOHF5GGSLRBV4ZA Play It As It Lies | What Does This Mean? https://cattailcrossing.ca/blog/play-it-as-it-lies-what-does-this-mean/ Improv Games for Collaboration https://www.theatrefolk.com/blog/improv-games-for-collaboration Learn more about your ad choices. Visit podcastchoices.com/adchoices 1h 39m](https://podcasts.apple.com/zm/podcast/how-to-be-more-creative-abstraction-and-improvisation/id1659964384?i=1000739466009) 
2.   [26 NOV ### How To Be Creative: Divergent Thinking (Pt. 2)! Prepare to get meta, I’m going to walk you through my creative, divergent thinking process while explaining the neuroscience of creativity and divergent thinking! We do need our brains and bodies to be in sync for this to be meaningful, illuminating, give you (and I) an “aha!” moment. Please note, divergent thinking means you think in a way that is not typical or standard, so I apologize if I’m hard to follow, however it is necessary to illustrate the point I’m making. I want you to know that you don’t have to understand every single detail, however you should focus on the actual “route” my mind is taking - the “figure 8.” Thank you so much to The Allen Institute for inviting me to Neuroscience 2025 in San Diego, I am beyond grateful and appreciative for the experience. I encourage everyone to check out their website, as well as their mission, because science (and creativity) truly are for everyone. The Allen Institute:https://alleninstitute.org/ New Book Club Information: https://www.patreon.com/posts/new-book-for-143088045 Resources: This Is What It Sounds Like - Susan Rogers and Ogi Ogas Your Brain on Art: How the Arts Transform Us - Susan Magsamen & Ivy Ross Horror in Architecture: The Reanimated Edition - Joshua Comaroff + One Ker-Shing Future Tense: Why Anxiety Is Good for You (Even Though It Feels Bad) - Tracy Dennis-Tiwary, PhD This is the book I recommended on arousal state splitting off into excitement or anxiety. A neurocomputational model of creative process https://www.sciencedirect.com/science/article/pii/S0149763422001452 Functional Fixedness: When We Stick to What We Know https://nesslabs.com/functional-fixedness This is not the Time Magazine article but it also covers functional fixedness and how it impacts creativity Sensorimotor experience and verb-category mapping in human sensory, motor and parietal neurons https://www.sciencedirect.com/science/arti

*[... truncated, 14,799 more characters]*

---

### Private Markets Group Ltd
*3,709 words* | Source: **EXA** | [Link](https://privatemarkets-group.com/ai-technology-directory)

AI Private Markets Technology Directory | UK Investment Platform

===============

[UK Family Office Summit Oxford 2026 - Secure Your Ticket Now](https://privatemarkets-group.com/oxford-summit-tickets)

[](https://privatemarkets-group.com/ai-technology-directory#)

[![Image 1: Private Markets Group Ltd](https://img1.wsimg.com/isteam/ip/a3d7b13e-796f-4fe6-a62b-b34885e1e325/LinkedinLogo.png/:/rs=h:86,cg:true,m/qt=q:95)](https://privatemarkets-group.com/home "Private Markets Group Ltd")

[Home](https://privatemarkets-group.com/home)

[Executive Education](https://privatemarkets-group.com/executive-education)

[Events](https://privatemarkets-group.com/ai-technology-directory#)

*   [Digital Forum 2026](https://privatemarkets-group.com/digital-forum-2026)
*   [In-Person Summit 2026](https://privatemarkets-group.com/in-person-summit-2026)
*   [Webinars](https://privatemarkets-group.com/webinars)

[Tickets](https://privatemarkets-group.com/ai-technology-directory#)

*   [Digital Forum Tickets](https://privatemarkets-group.com/digital-forum-tickets)
*   [Oxford Summit Tickets](https://privatemarkets-group.com/oxford-summit-tickets)
*   [Oxford Summit LP Pass](https://privatemarkets-group.com/oxford-summit-lp-pass)
*   [Accommodation In Oxford](https://privatemarkets-group.com/accommodation-in-oxford)

[Partnership](https://privatemarkets-group.com/ai-technology-directory#)

*   [Family Office Forum](https://privatemarkets-group.com/family-office-forum-1)
*   [UK Family Office Summit](https://privatemarkets-group.com/uk-family-office-summit)
*   [Digital Media Partnership](https://privatemarkets-group.com/digital-media-partnership)
*   [PMG Platform Partnership](https://privatemarkets-group.com/pmg-platform-partnership)
*   [Research Partnership](https://privatemarkets-group.com/research-partnership)
*   [Bespoke Partnerships](https://privatemarkets-group.com/bespoke-partnerships)

[Speaker Application](https://privatemarkets-group.com/ai-technology-directory#)

*   [Apply To Speak: In-Person](https://privatemarkets-group.com/apply-to-speak%3A-in-person)
*   [Apply To Speak: Online](https://privatemarkets-group.com/apply-to-speak%3A-online)
*   [Keynote Speakers](https://privatemarkets-group.com/keynote-speakers-1)

[Resources](https://privatemarkets-group.com/ai-technology-directory#)

*   [Newswire](https://privatemarkets-group.com/newswire)
*   [Real Estate Magazine](https://privatemarkets-group.com/real-estate-magazine)
*   [Editorial Calendar](https://privatemarkets-group.com/editorial-calendar)
*   [Fundraising Data](https://privatemarkets-group.com/fundraising-data)
*   [Private Wealth Voices](https://privatemarkets-group.com/private-wealth-voices)
*   [Webinar Library](https://privatemarkets-group.com/webinar-library)
*   [Private Fund Database](https://privatemarkets-group.com/private-fund-database)
*   [AI Technology Directory](https://privatemarkets-group.com/ai-technology-directory)
*   [UK Family Offices List](https://privatemarkets-group.com/uk-family-offices-list)
*   [Global Directory](https://privatemarkets-group.com/global-directory)

[About](https://privatemarkets-group.com/ai-technology-directory#)

*   [About Us](https://privatemarkets-group.com/about-us)
*   [Our 50 30 20 Standard](https://privatemarkets-group.com/our-50-30-20-standard)
*   [Attendees](https://privatemarkets-group.com/attendees)
*   [Our Partners & Sponsors](https://privatemarkets-group.com/our-partners-%26-sponsors)
*   [Testimonials](https://privatemarkets-group.com/testimonials)

[Contact Us](https://privatemarkets-group.com/contact-us)

[![Image 2: Private Markets Group Ltd](https://img1.wsimg.com/isteam/ip/a3d7b13e-796f-4fe6-a62b-b34885e1e325/LinkedinLogo.png/:/rs=h:86,cg:true,m/qt=q:95)](https://privatemarkets-group.com/home "Private Markets Group Ltd")

[Home](https://privatemarkets-group.com/home)

[Executive Education](https://privatemarkets-group.com/executive-education)

[Events](https://privatemarkets-group.com/ai-technology-directory#)

*   [Digital Forum 2026](https://privatemarkets-group.com/digital-forum-2026)
*   [In-Person Summit 2026](https://privatemarkets-group.com/in-person-summit-2026)
*   [Webinars](https://privatemarkets-group.com/webinars)

[Tickets](https://privatemarkets-group.com/ai-technology-directory#)

*   [Digital Forum Tickets](https://privatemarkets-group.com/digital-forum-tickets)
*   [Oxford Summit Tickets](https://privatemarkets-group.com/oxford-summit-tickets)
*   [Oxford Summit LP Pass](https://privatemarkets-group.com/oxford-summit-lp-pass)
*   [Accommodation In Oxford](https://privatemarkets-group.com/accommodation-in-oxford)

[Partnership](https://privatemarkets-group.com/ai-technology-directory#)

*   [Family Office Forum](https://privatemarkets-group.com/family-office-forum-1)
*   [UK Family Office Summit](https://privatemarkets-group.com/uk-family-office-summit)
*   [Digital Media Partnership](https://privatemarkets-group.com/digital-media-partnership)
*   [PMG Platform Partnership

*[... truncated, 31,583 more characters]*

---

### Private Eye: Data and AI in Private Investment Markets
*2,005 words* | Source: **EXA** | [Link](https://www.spencerstuart.com/research-and-insight/private-eye-data-and-ai-in-private-investment-markets)

*   [![Image 1](https://www.spencerstuart.com/-/media/consultant-photos-new/new-york/hodkinson_peter-web-1e-2024.jpg) Peter Hodkinson New York](https://www.spencerstuart.com/our-consultants/peter-h-hodkinson)
*   [![Image 2](https://www.spencerstuart.com/-/media/consultant-photos-new/new-york/ogle_tim-web-2c-2024.jpg) Tim Ogle New York](https://www.spencerstuart.com/our-consultants/tim-ogle)
*   [![Image 3](https://www.spencerstuart.com/-/media/consultant-photos-new/new-york/stack_charlie-web-4d-2024.jpg) Charlie Stack New York](https://www.spencerstuart.com/our-consultants/charlie-h-stack)

A year ago, [our first “Private Eye”](https://www.spencerstuart.com/research-and-insight/private-eye-insights-on-technology-and-leadership-in-the-private-markets)article investigated how the private capital industry — private equity firms, hedge funds, “growth equity” firms, real-asset investors and credit alternatives to traditional bank lending — were addressing key technology questions. All but a handful of elite investment firms are still playing catch-up when it comes to developing technology-enabled business models. The explosive growth of private capital markets in the past two decades — and in particular the past few years — has exposed the general need for more modern technology basics such as CRM, data storage, reporting and information security.

For our next Private Eye article, we look at the next step in these technology investments: how some leading firms are harnessing their rich data assets to power sustainable value and competitive advantage in a data-driven, AI-enabled future. We spoke with several top leaders whose firms are in the vanguard of this shift, driving significant value creation as they navigate forward. These firms are building a “flywheel” of capabilities, deploying data science and AI to improve performance across the investment life cycle, from deal sourcing to portfolio optimization. They are fully committed to building new capabilities, learning new skills and adopting new ways of working that will be more difficult to deploy at scale. The result is that they are unlocking value, both for investors and the companies they own, from the advantages inherent to the private portfolio business model.

Upgrading data foundations
--------------------------

The extremely lean structures common in private markets and the resulting paucity of data assets have for many years provided a significant barrier to effectively adopting data-driven approaches. In the early days of big data, armies of people were needed to organize data and build models. Even when that was possible, monetizing the efforts was difficult, as private firms often lacked the volumes of standardized information that publicly traded firms regularly generate through public filings and real-time market data. The overarching result is a general underinvestment in data-driven capabilities by the private capital industry, which more commonly has run investment and reporting processes on the backs of spreadsheets, spinning cycles on manual data munging and manipulation.

However, advances in cloud technology and greater access to open-source models have enabled some private investors to test and deploy AI and data solutions more easily. Further improvements in data science and machine learning have also allowed them to work with private equity data sets, from sourcing to due diligence to ownership and operation.

Outsourcing partners and cloud providers are helping lay some of these foundations, while some firms are using small internal teams to develop proprietary approaches. Either way, long-term effectiveness comes from a financial and organizational commitment. But where does that commitment come from? The next sections look at some answers to this question.

Common challenges to navigate
-----------------------------

*   **Cost.**While low-budget progress is possible, meaningful returns typically require meaningful investment. 
*   **Talent.**Experienced practitioners, especially those with investing experience, remain thin on the ground and highly sought-after. 
*   **Cultural resistance and change.**Successfully capturing the value of data and AI requires real behavioral change from practitioners who have largely succeeded without them until recently. 
*   **Scalability.**Designing and deploying a new capability or platform across a diverse business and portfolio is challenging. Few companies have so far managed it. 

Embracing AI for operational efficiency
---------------------------------------

At the GP level, artificial intelligence can automate routine tasks and optimize complex operations, allowing firms to focus precious human capital on more strategic, higher-value activities. Predictive analytics can also ensure regular, reliable and accessible risk assessment and tracking.

Integrating AI into operations is perhaps the easiest for firms to tackle, yet also generally does not lead to the type of behavior change tha

*[... truncated, 9,251 more characters]*

---

### In re the Children of: Jessica Lee Schauer and James Lee Schauer.
*3,169 words* | Source: **EXA** | [Link](https://law.justia.com/cases/minnesota/court-of-appeals/2003/opa030402-1104.html)

This opinion will be unpublished and

may not be cited except as provided by

Minn. Stat. § 480 A. 08, subd. 3 (2002).

**STATE OF MINNESOTA**

**IN COURT OF APPEALS**

**A03-402**

In re the Children of: Jessica Lee Schauer and James Lee Schauer.

**Filed November 4, 2003**

**Affirmed**

**Anderson, Judge**

Anoka County District Court

File No. J3-02-53747

Sherri D. Hawley, 1398 Myrtle Street North, St. Paul, MN 55119 (for appellant)

Nellie G. Spexet, 3401 131st Avenue Northeast, Blaine, MN 55449 (guardian ad litem)

Robert M. A. Johnson, Anoka County Attorney, Robert D. Goodell, Assistant County Attorney, M. Katherine Doty, Assistant County Attorney, 2100 Third Avenue, 7th Floor, Anoka, MN 55303 (for respondent)

Considered and decided by Wright, Presiding Judge; Harten, Judge; and Anderson, Judge.

U N P U B L I S H E D O P I N I O N

**G. BARRY ANDERSON,**Judge

Appellants challenge the termination of their parental rights. Appellants contend that they are not palpably unfit parents, that their children are not neglected and in foster care, that the conditions leading to the removal of the children from the home have been corrected, and that the termination is not in the best interests of the children. Because the district court did not err in finding appellants palpably unfit to be parents, we affirm.

FACTS

Background of the Schauer Family

James Lee Schauer and Jessica Lee Schauer are husband and wife. The Schauers have three children: J.L.S., I,[1] born October 2, 1996, J.L.S., II, born December 9, 2000, and A.R.S., born April 29, 2002.

On August 1, 2001, the Schauers contacted Anoka County Social Services ("Social Services") and requested voluntary placement of their two sons, J.L.S., I, and J.L.S., II, in foster care. The family was homeless and neither parent was employed.

On August 16, 2001, the Schauers contacted Social Services and told the agency that they had found an apartment and would be moving in on August 24. On August 28, Social Services inspected the new apartment and found it adequate; on August 29 the two children were returned from foster care to their parents.

In the time between when the Schauers voluntarily placed their children in foster care in early August, and when the two boys returned home to their parent's new apartment, Social Services worked with the Schauers to help get them back on their feet. Social Servicesprovided money and also referred the couple to the Therapeutic Service Agency ("TSA") for relationship counselingthe Schauers had revealed to Social Services that there had been domestic violence in their relationship.

In September 2001, Mrs. Schauer began meeting with Lisa Schroeder ("Schroeder"), a TSA therapist. In therapy sessions with Schroeder, which continued through mid-November 2001, Mrs. Schauer revealed that Mr. Schauer: (1) received residential treatment as a child; (2) was involved in gang activity; (3) had been diagnosed as suffering from both a bipolar disorder and ADHD; (4) had been medicated for these conditions as a child, but as an adult refused either medication or treatment for his conditions; (5) was physically, emotionally, and verbally abusive in the relationship; (6) suffered from a gambling problem; (7) was addicted to methamphetamine; (8) was involved in distributing methamphetamine; and, (9) was possibly manufacturing methamphetamine in the couple's apartment.

At more than one counseling session, Mrs. Schauer maintained that she had no contact with Mr. Schauer and did not know his whereabouts. Social Services advised Mrs. Schauer that if Mr. Schauer tried to contact her she should contact the agency immediately; Mrs. Schauer assured Social Services that she would not allow Mr. Schauer to return to the apartment.

At Mrs. Schauer's October 18, 2001 appointment with Schroeder, Mrs. Schauer revealed she had lied about Mr. Schauer's whereabouts and that he had been living in their apartment the entire time. Mrs. Schauer also disclosed that the police had arrested Mr. Schauer that day while he was in possession of methamphetamine. In addition, Mrs. Schauer revealed that she had used methamphetamine for a short time after the birth of her second child.

At Mrs. Schauer's November 2, 2001 appointment, she told Schroeder that she was not currently in contact with Mr. Schauer. Mr. Schauer entered the room during the session and admitted that he had listened to the entire conversation, and that he had never stopped living in the Schauer apartment. Both parents told Schroeder that their drug abuse did not negatively impact their children.

Removing the Children From the Home

On November 6, 2001, the Drug Task Force placed a 72-hour hold on the Schauer children after receiving information about the Schauers from Social Services and TSA. The Drug Task Force found crank paraphernalia at the Schauer home. Mrs. Schauer told members of the task force that Mr. Schauer was using drugs, that her husband was controlling, and that he was both verb

*[... truncated, 15,898 more characters]*

---

### Download Practical marketing research : measuring customer satisfaction in the government environment PDF by Schauer, James A
*2,233 words* | Source: **EXA** | [Link](https://pdfdrive.to/download/practical-marketing-research-measuring-customer-satisfaction-in-the-government-environment)

**Table Of Content**

The Ontario Ministry of Revenue Practical Marketing Research: Measuring Customer Satisfaction in the Government Environment By James A. Schauer, M.C.Inst.Mktg. Manager, Marketing Services Ministry of Revenue Ontario Marketing Services Taxpayer Services Branch Tune 12, 1992 HF 5415 . 5 . S3 2 1992 c. l i tor mai a The Ontario Ministry of Revenue Practical Marketing Research: Measuring Customer Satisfactiion in the Government Environment By James A. Schauer, M.C.Inst.Mktg. Manager, Marketing Services Ministry of Revenue Ontario Marketing Services Taxpayer Services Branch June 12, 1992 Digitized by the Internet Archive in 2018 with funding from Ontario Council of University Libraries https://archive.org/details/practicalmarketiOOscha Customer Service: Practical Marketing Research and Customer Satisfaction Measurement Contents Table of Contents .... i 1. Management by Facts: The Need for Information. 1 2. The Five C’s of Customer Satisfaction . 2 3. The Measurement of Customer Satisfaction . 3 4. The traditional Role Of Marketing Research . 4 a. Customers’ Needs and Expectations . 4 b. Identifying Changes and Trends .. 4 c. The Competition, Impact on Service Quality . 4 d. Target Markets, Segments with specific Needs . 4 e. Preferred Distribution Channels, Media. 5 f. Customer Service Delivery .. 5 g. Customer Satisfaction Levels and Trends . 5 5. The Application of Feedback in Government. 7 a. The Traditional Program Model . 7 b. Importance of Two-Way Communications .. 8 c. Marketing Communications applied to Program Delivery . 10 d. Customer Service and Revenue . 11 6. Why Marketing, when there is Nothing to Sell? . 12 a. The Risks of "Not knowing" . 12 b. Marketing begins and ends with the Customer . 12 c. The Importance of Research - Why measure at all? . 12 7. Customer Service: "The Moment of Truth" .. 13 a. The "Moment of Truth". 13 b. Managing and exceeding Customers’ Expectations . 14 c. Establishing Customer Satisfaction . 15 d. The measurable "Gaps" . 15 8. Customer Service Quality and Gaps in Service Delivery . 16 9. Trial and Error versus Marketing Research . 18 l Contents, continued: 10. The Tools, Methods & Benefits of Marketing Research. 19 a. Situation Analysis . 19 b. Customer Satisfaction Measurement . 20 c. Review of Existing Data .. 21 d. Methods for obtaining new Data .. 22 e. Focus Groups versus Quantitative Research . 22 f. Quantitative Research vs. Focus Groups: The Costs .. 23 g. Questionnaire Construction (1) Asking the Right People . 24 (2) Asking the Right Questions. 24 (3) Objective versus subjective Questions .......'. 25 (4) Cost Factors . 25 (5) Keep Questions Simple - Use Cross Tabulation .. 26 (6) Major Question Categories: Customer Satisfaction Measurement 26 h. Survey Sampling: "How much is "Enough"? .. 27 (1) Major Types of Survey . 27 (2) Accuracy of Random Sampling .. 27 (3) Survey Response Rates . 27 (4) Survey Accuracy and Sample Size .•. 28 (5) The Impact of Response Rates on Sample Size . 29 (6) Practical Measures for Raising Response Rates. 29 i. Performance Measurement and Service Quality Improvements . 29 (1) Data Analysis for Trends and Changes . 30 (2) Need for Consistency, Continuity. 30 j. Cross-tabulation of Data - Practical Benefits . 30 k. Customer Service and the "Number-One Syndrome" . 31 11. Practical Business Data Analysis. 33 a. Practical Application Areas in Government . 33 b. Analysis of Trends, Time Factors . 33 12. How to avoid the Most Common Market Research Mistakes . 34 13. Cabinet Office Approvals and F.O.I. . 35 14. The Benefits and Limitations of Marketing Research . 35 15. And Last: Look beyond the Obvious. 35 16. Useful References . 35 Appendix "A": Guidelines for obtaining Cabinet Office approval. 37 Appendix "B": Bibliography and Useful References... 40 n Customer Service: Practical Marketing Research: Measurement of Customer Satisfaction and Change 1. Management bv Facts: The Need for Information The purpose of this paper is twofold. First, it is to outline the growing need for market research and customer satisfaction measurements, including cost considerations in general, to provide senior management with a basis for understanding the processes involved. Second, it is to fill the current dearth in the literature of discussions on customer satisfaction questionnaire development and use. Many experts have written articles and books about the importance of customer service for competing in business today. Most of these authors generally concur that customer satisfaction is an important factor for the successful business and that customer perceptions and attitudes should be assessed and monitored. In the early Eighties, business learned important new skills for identifying and satisfying its customers. Inevitably, this experience led to the recognition that the needs of internal work processes and internal customers were critical to external service delivery. Faced with growing spending constraints, a similar awareness 

*[... truncated, 9,640 more characters]*

---

### Just a moment...
*22 words* | Source: **GOOGLE** | [Link](https://www.legacy.com/us/obituaries/greenbaypressgazette/name/james-schauer-obituary?id=8261611)

www.legacy.com
--------------

Verify you are human by completing the action below.

www.legacy.com needs to review the security of your connection before proceeding.

---

### US State Department Names New Science Envoys
*1,561 words* | Source: **GOOGLE** | [Link](https://www.the-scientist.com/us-state-department-names-new-science-envoys-64316)

US State Department Names New Science Envoys | The Scientist

===============

[![Image 3: the-scientist Logo](https://www.the-scientist.com/assets/logos/main-logo.svg)](https://www.the-scientist.com/)

[Login](https://www.the-scientist.com/api/auth/login?screenHint=login&returnTo=/us-state-department-names-new-science-envoys-64316)

[Subscribe](https://www.the-scientist.com/page/subscribe)

*   [News](https://www.the-scientist.com/type-group/news)
*   [Magazines](https://www.the-scientist.com/magazine)
    *   [![Image 4](https://cdn.the-scientist.com/assets/image/51770/ts-12-25-cover-digest-8-5-x-10-5-s.webp)](https://www.the-scientist.com/series-entry/wooden-neurons-an-artistic-vision-of-the-brain)![Image 5: TS Digest](https://www.the-scientist.com/assets/logos/ts-digest.svg)
An Interactive Experience Current Issue

[December 2025](https://www.the-scientist.com/series-entry/wooden-neurons-an-artistic-vision-of-the-brain) [View this Issue](https://www.the-scientist.com/series-entry/wooden-neurons-an-artistic-vision-of-the-brain)[Archive](https://www.the-scientist.com/series/ts-digest)    
    *   [![Image 6: From Soundwaves to Brainwaves: The Transformative Power of Music](https://cdn.the-scientist.com/assets/image/50731/09-25-q3-cover-thumb-s.webp)](https://www.the-scientist.com/magazine/issue/from-soundwaves-to-brainwaves-the-transformative-power-of-music-39-3)![Image 7: the-scientist Logo](https://www.the-scientist.com/assets/logos/main-logo.svg)
Quarterly Magazine Current Issue

[September 2025](https://www.the-scientist.com/magazine/issue/from-soundwaves-to-brainwaves-the-transformative-power-of-music-39-3) [View this Issue](https://www.the-scientist.com/magazine/issue/from-soundwaves-to-brainwaves-the-transformative-power-of-music-39-3)[Archive](https://www.the-scientist.com/magazine)[Features](https://www.the-scientist.com/type/feature)    

*   [Topics](https://www.the-scientist.com/categories)

    *   [Life Sciences](https://www.the-scientist.com/category-group/science/life-sciences)

    *   [Biochemistry](https://www.the-scientist.com/category/science/biochemistry)
    *   [Cancer](https://www.the-scientist.com/category/science/cancer)
    *   [Cell & Molecular Biology](https://www.the-scientist.com/category/science/cell-and-molecular-biology)
    *   [Developmental Biology](https://www.the-scientist.com/category/science/developmental-biology)
    *   [Evolutionary Biology](https://www.the-scientist.com/category/science/evolutionary-biology)
    *   [Genetics](https://www.the-scientist.com/category/science/genetics)
    *   [Genome Editing](https://www.the-scientist.com/category/science/genome-editing)
    *   [Immunology](https://www.the-scientist.com/category/science/immunology)
    *   [Microbiology](https://www.the-scientist.com/category/science/microbiology)
    *   [Neuroscience](https://www.the-scientist.com/category/science/neuroscience)
    *   [Omics](https://www.the-scientist.com/category/science/omics)
    *   [Physiology](https://www.the-scientist.com/category/science/physiology)

    *   [Health & Medicine](https://www.the-scientist.com/category-group/health/health-and-medicine)

    *   [Cell & Gene Therapy](https://www.the-scientist.com/category/health/cell-and-gene-therapy)
    *   [Diagnostics](https://www.the-scientist.com/category/health/diagnostics)
    *   [Drug Discovery & Development](https://www.the-scientist.com/category/health/drug-discovery-and-development)
    *   [Public Health](https://www.the-scientist.com/category/health/public-health)

    *   [Science & Society](https://www.the-scientist.com/category-group/society/science-and-society)

    *   [Community](https://www.the-scientist.com/category/society/community)
    *   [Careers](https://www.the-scientist.com/category/society/careers)
    *   [Research Ethics](https://www.the-scientist.com/category/society/research-ethics)
    *   [Science Communication](https://www.the-scientist.com/category/society/science-communication)

    *   [Biotechnology](https://www.the-scientist.com/category-group/technology/biotechnology)

    *   [Artificial Intelligence](https://www.the-scientist.com/category/technology/artificial-intelligence)
    *   [Business](https://www.the-scientist.com/category/technology/business)
    *   [Laboratory Technology](https://www.the-scientist.com/category/technology/laboratory-technology)
    *   [Synthetic Biology](https://www.the-scientist.com/category/technology/synthetic-biology)

*   [Resources](https://www.the-scientist.com/multimedia)
    *   [Crossword Puzzles](https://www.the-scientist.com/type/crossword-puzzle)
    *   [eBooks](https://www.the-scientist.com/type/ebook)
    *   [Infographics](https://www.the-scientist.com/type/infographic)
    *   [Innovation Spotlight](https://www.the-scientist.com/type/innovation-spotlight)
    *   [Podcasts](https://www.the-scientist.com/type-group/audio)
    *   [Product Coverage](https://www.the-scientist.com/product-coverage)
    *   [Research 

*[... truncated, 22,880 more characters]*

---

### An outspoken epidemiologist becomes U.S. science envoy
*2,515 words* | Source: **GOOGLE** | [Link](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy)

An outspoken epidemiologist becomes U.S. science envoy | Science | AAAS

===============

Opens in a new window Opens an external website Opens an external website in a new window

This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. To learn more, view the following link: [Privacy Policy](https://www.science.org/content/page/privacy-policy)

Manage Preferences 

[Skip to main content](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#main-content-focus)

Advertisement

*   [news](https://www.science.org/news)
*   [careers](https://www.science.org/careers)
*   [commentary](https://www.science.org/commentary)
*   [Journals](https://www.science.org/journals)

[![Image 1](https://www.science.org/pb-assets/images/styleguide/logo-dark-1672180581427.svg)![Image 2: AAAS Science Logo](https://www.science.org/pb-assets/images/styleguide/logo-1672180580750.svg)](https://www.science.org/)

*   [](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#header-quick-search-wrapper "Search")
*   [Log in](https://www.science.org/action/ssostart?redirectUri=%2Fcontent%2Farticle%2Foutspoken-epidemiologist-becomes-us-science-envoy) 
*   [Become A Member](https://promo.aaas.org/science/join/?CTC=SMHPJN)  

[![Image 3: journal-menu-img](https://www.science.org/cms/asset/b98c8129-af9a-4add-82c1-bf1d04f3f1a2/science.2025.390.issue-6777.cover.gif) science](https://www.science.org/journal/science "Science")

[![Image 4: journal-menu-img](https://www.science.org/cms/asset/26a41dd8-d06c-450f-b99b-e1222f0ddfa9/sciadv.2025.11.issue-49.cover.gif) science advances](https://www.science.org/journal/sciadv "Science")

[![Image 5: journal-menu-img](https://www.science.org/cms/asset/189796d9-64c1-4265-b7dd-02f9cac4f58c/sciimmunol.2025.10.issue-114.cover.gif) science immunology](https://www.science.org/journal/sciimmunol "Science")

[![Image 6: journal-menu-img](https://www.science.org/cms/asset/618309a7-2ead-4dbd-9649-463dcc67c3de/scirobotics.2025.10.issue-108.cover.gif) science robotics](https://www.science.org/journal/scirobotics "Science")

[![Image 7: journal-menu-img](https://www.science.org/cms/asset/6aefa2ee-6bd9-47ce-8e73-a9b2a202f339/signaling.2025.18.issue-915.cover.gif) science signaling](https://www.science.org/journal/signaling "Science")

[![Image 8: journal-menu-img](https://www.science.org/cms/asset/94a0b73e-03e2-49c7-9ccd-43cb506c6f06/stm.2025.17.issue-827.cover.gif) science translational medicine](https://www.science.org/journal/stm "Science")

[![Image 9: journal-menu-img](https://www.science.org/pb-assets/images/styleguide/spj-cover-1695403298717.png) science partner journals](https://spj.science.org/ "Science Partner Journals")

[](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#journal-menu)

Quick Search anywhere

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Quick Search in Journals

Enter Search Term 

Searching: 

Anywhere

[Anywhere](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-0)[Science](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-1)[Science Advances](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-2)[Science Immunology](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-3)[Science Robotics](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-4)[Science Signaling](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-5)[Science Translational Medicine](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy#quick-search-form-9ea9b667-c3ce-40d1-870b-f7e001bbac01-6)

[Advanced Search](https://www.science.org/search/advanced)Search

###### Trending Terms:

*   [cancer](https://www.science.org/action/doSearch?AllField=cancer)
*   [climate](https://www.science.org/action/doSearch?AllField=climate)
*   [artificial intelligence](https://www.science.org/action/doSearch?AllField=artificial%20intelligence)
*   [postdoc](https://www.science.org/action/doSearch?AllField=postdoc)
*   [aging](https://www.science.org/action/doSearch?AllField=aging)

[](https://www.science.org/content/article/outspoken-epidemiolo

*[... truncated, 30,814 more characters]*

---

### 1998 Thomas Jefferson Award Winners Announced
*2,120 words* | Source: **GOOGLE** | [Link](https://www.dvidshub.net/news/529132/1998-thomas-jefferson-award-winners-announced)

Beth Reece of the 221st Base Support Battalion Public Affairs Office in Wiesbaden, Germany, and Army Staff Sgt. Jennifer L. Braden of Soldiers Radio and Television, Alexandria, Va., are the Defense Department's print and broadcast journalists of the year for 1998.

The two were announced May 5 as top individual winners of the 1998 Thomas Jefferson Awards Program, sponsored by the American Forces Information Service. The annual contest rewards excellence and professionalism in military print and broadcast media.

Journalist of the Year runners up are Marine Cpl. David J. Annarino of the Navy/Marine Corps News in Washington, D.C., print; and Navy Petty Officer 1st Class Scott A. Thornbloom of the Pacific Fleet Public Affairs Office, Pearl Harbor, Hawaii, broadcast.

Panels of three print and broadcast judges each scored the entries. Print panelists were Barbara Hines, chair of the Department of Journalism, Howard University; Warren S. Lacy, director for print and electronic publications, The Retired Officers Association; and Robert Robinson, deputy managing editor for sports, USA Today. Broadcast panelists were John R. Turner, associate professor, Department of Mass Communication and Communication Studies, Towson State University; Kenneth L. Blaylock, sound man, ABC News; and Naomi Spinrad, producer, NBC News Radio.

Winners in the print categories are:

Category A (Military-Funded Newspapers, Large)

First Place: Naval Reservist News, Naval Reserve Force Public Affairs Office, New Orleans Primary Contributor: Patricia Antenucci Significant Contributors: Chief Petty Officer Keith Boydston; Jennifer Fleming; Petty Officer 1st Class Matthew Kendall; Petty Officer 1st Class James Schauer; Chief Petty Officer Patricia Hoar

Second Place: Okinawa Marine, Marine Corps Base Camp Smedley D. Butler Public Affairs Office, Okinawa, Japan Primary Contributor: Cpl. Steven Davis Significant Contributors: Cpl. Scott Dunn; Cpl. Matt Weir; Cpl. Aaron Prater; Sgt. Jennifer Wolf

Category B (Military-Funded Newspapers, Small)

First Place: Associate Press, 446th Airlift Wing Public Affairs Office, Air Force Reserve, McChord Air Force Base, Wash. Primary Contributor: Tech. Sgt. Norman McKay Significant Contributors: Capt. Joy Caranfa; 1st Lt. Tamara Lewis; Tech. Sgt. Cheryl Kelleigh; Staff Sgt. Stephanie Crudup; Staff Sgt. Collen Roundtree

Second Place: Transatlantic News, Army Corps of Engineers Transatlantic Programs Center Public Affairs Office, Winchester, Va. Primary Contributor: Denise Tatu Significant Contributor: Joan Kibler

Category C (Military-Funded Newspaper, Newsletter)

First Place: The Maryland Musket, 29th Mobile Public Affairs Detachment, Maryland Army National Guard, Baltimore, Md. Primary Contributor: Sgt. Cesar Soriano Significant Contributors: Sgt. Ed Rollins; Spc. Christopher Lew; Spc. George Roache; Spc. Rob Bishop

Second Place: Air Scoop, Naval Air Engineering Station Public Affairs Office, Lakehurst, N.J. Primary Contributor: Kathleen Bozan Significant Contributors: Darlene Nye; Larry Lyford; Sandy Miller

Category D (Civilian Enterprise Newspapers (Metro))

First Place: The Flagship, Public Affairs Office, Naval Base Norfolk, Va. Primary Contributor: Petty Officer 1st Class Sandra Ramirez Significant Contributors: Scott Vanier; Skip Groce; Jim Ferrell; Petty Officer 2nd Class Cynthia Sykes

Second Place: Inside the Turret, Public Affairs Office, Fort Knox, Ky. Primary Contributor: Larry Barnes Significant Contributors: Sgt. Stacy Wamble; Sgt. William Wilczewski; Spc. Adriane Foss; Pfc. Tina Sosack

Category E (Civilian Enterprise Newspapers (Tabloid))

First Place: Rotovue, Joint Public Affairs Office, Marine Corps Air Station New River, Jacksonville, N.C. Primary Contributor: Cpl. Laura Chambers Significant Contributors: Sgt. Jeremy Heltsley; Cpl. Brandon Rizzo; Cpl. John Watts; Cpl. Christopher Lowe; Cpl. Ivrol Hines

Second Place: Jet Observer, Public Affairs Office, Naval Air Station Oceana, Virginia Beach, Va. Primary Contributor: Annette Hall Significant Contributor: Cathy Heimer

Category F (Newspapers (Magazine Format))

First Place: The Checkerboard, 99th Regional Support Command Public Affairs Office, U.S. Army Reserve, Oakdale, Pa. Primary Contributor: Jack Gordon Significant Contributors: Maj. Greg Yesko; Master Sgt. Steve Opet; Staff Sgt. Kelly Luster; Spc. Chris Coleman

Second Place: Leading Edge, Public Affairs Office, Headquarters Air Force Materiel Command, Wright-Patterson Air Force Base, Ohio Primary Contributor: Capt. Stephanie Holcombe Significant Contributors: Lt. Col. Dorothy Baker; Chris McGee; Rudy Purificato; Rob Ely; Tech. Sgt. Darrell Lewis

Category G (News/Article)

First Place: 2nd Lt. Erin Bradley, 1st Fighter Wing Public Affairs Office, Langley Air Force Base, Va., "Hero's Quick Reaction Saves Man's Life"

Second Place: Spc. Aaron Reed, 100th Mobile Public Affairs Detachment, Texas National Guard, Austin, Texas, "Texas Citizen- Soldiers Continue Search For Flood Vict

*[... truncated, 10,555 more characters]*

---

### Morons and Oxymorons: Undermining Women in Leadership
*2,958 words* | Source: **GOOGLE** | [Link](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership)

Morons and Oxymorons: Undermining Women in Leadership | INSEAD Knowledge

===============
[Skip to main content](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership#main-content)

[![Image 1: Logo](https://knowledge.insead.edu/sites/knowledge/themes/knowledge_theme/images/logo.png)](https://www.insead.edu/)[![Image 2: Knowledge](https://knowledge.insead.edu/sites/knowledge/themes/knowledge_theme/images/knowledge.png)](https://knowledge.insead.edu/)

*   Search
*   [Sign In](https://knowledge.insead.edu/user/login)

Main navigation
---------------

*   [Home](https://knowledge.insead.edu/)
*   Topics

    *   [![Image 3: career](https://knowledge.insead.edu/sites/knowledge/files/2022-07/career_0.svg) Career](https://knowledge.insead.edu/career)
    *   [![Image 4: economics-finance](https://knowledge.insead.edu/sites/knowledge/files/2022-07/economics-finance.svg) Economics & Finance](https://knowledge.insead.edu/economics-finance)
    *   [![Image 5: entrepreneurship](https://knowledge.insead.edu/sites/knowledge/files/2022-07/entrepreneurship.svg) Entrepreneurship](https://knowledge.insead.edu/entrepreneurship)
    *   [![Image 6: family-business](https://knowledge.insead.edu/sites/knowledge/files/2022-07/family-business.svg) Family Business](https://knowledge.insead.edu/family-business)
    *   [![Image 7: leadership-organisation](https://knowledge.insead.edu/sites/knowledge/files/2022-07/leadership-organisation.svg) Leadership & Organisations](https://knowledge.insead.edu/leadership-organisations)
    *   [![Image 8: marketing](https://knowledge.insead.edu/sites/knowledge/files/2022-07/marketing.svg) Marketing](https://knowledge.insead.edu/marketing)
    *   [![Image 9: operations](https://knowledge.insead.edu/sites/knowledge/files/2022-07/operations.svg) Operations](https://knowledge.insead.edu/operations)
    *   [![Image 10: responsibility](https://knowledge.insead.edu/sites/knowledge/files/2022-07/responsibility.svg) Responsibility](https://knowledge.insead.edu/responsibility)
    *   [![Image 11: strategy](https://knowledge.insead.edu/sites/knowledge/files/2022-07/strategy.svg) Strategy](https://knowledge.insead.edu/strategy)

*   [Videos](https://knowledge.insead.edu/videos)
*   [Podcasts](https://knowledge.insead.edu/podcasts)
*   [Series](https://knowledge.insead.edu/series-overview)
*   [Newsletter](https://knowledge.insead.edu/newsletter)
*   divider
*   [INSEAD Publishing](https://publishing.insead.edu/)
*   [Research](https://www.insead.edu/faculty-research)
*   Search
*   Menu

    *   [Videos](https://knowledge.insead.edu/videos)
    *   [Podcasts](https://knowledge.insead.edu/podcasts)
    *   [INSEAD Publishing](https://publishing.insead.edu/)
    *   [Research](https://www.insead.edu/faculty-research/research)

[](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership#main-content)

![Image 12: Senior businesswoman](https://knowledge.insead.edu/sites/knowledge/files/styles/1280x500/public/images/senior_businesswoman.jpg?itok=hR9IwAEl)

[Leadership & Organisations](https://knowledge.insead.edu/leadership-organisations)

Morons and Oxymorons: Undermining Women in Leadership
=====================================================

Nicholas Bray, European Correspondent

07 Feb 2013 4 

Morons and Oxymorons: Undermining Women in Leadership
=====================================================

*   [Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership&title=Morons%20and%20Oxymorons%3A%20Undermining%20Women%20in%20Leadership&source=https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership& "Share on LinkedIn")
*   [Share on Facebook](http://www.facebook.com/share.php?u=https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership&title=Morons%20and%20Oxymorons%3A%20Undermining%20Women%20in%20Leadership& "Share on Facebook")
*   [Share on Twitter](https://twitter.com/intent/tweet?url=https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership&text=Morons%20and%20Oxymorons%3A%20Undermining%20Women%20in%20Leadership&via=INSEADKnowledge& "Share on Twitter")
*   [Share via Email](mailto:?subject=Morons%20and%20Oxymorons%3A%20Undermining%20Women%20in%20Leadership&body=https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership& "Share via Email")
*   [Download PDF](https://knowledge.insead.edu/print/pdf/node/28631 "Download PDF")

*   [](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership#0)
*   [](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership#0)

**Fifty years after legal changes in many countries ended d

*[... truncated, 25,019 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[James Schauer Obituary (1931 - 2020) - Green Bay, WI - Green Bay ...](https://www.legacy.com/us/obituaries/greenbaypressgazette/name/james-schauer-obituary?id=8261611)**
  - Source: legacy.com
  - *Dec 8, 2020 ... James Schauer Obituary. James J. Schauer Green Bay - On December 8 ... Private graveside services are being held at Allouez Catholic C...*

- **[US State Department Names New Science Envoys | The Scientist](https://www.the-scientist.com/us-state-department-names-new-science-envoys-64316)**
  - Source: the-scientist.com
  - *Jun 13, 2018 ... The new appointees, Charles Bolden Jr., Robert Langer, Michael Osterholm, Rebecca Richards-Kortum, and James Schauer, join continuing...*

- **[An outspoken epidemiologist becomes U.S. science envoy | Science ...](https://www.science.org/content/article/outspoken-epidemiologist-becomes-us-science-envoy)**
  - Source: science.org
  - *Jun 12, 2018 ... ... James Schauer of the University of Wisconsin in Madison; and retired ... I'm just another private in the infectious disease army,...*

- **[News - 1998 Thomas Jefferson Award Winners Announced - DVIDS](https://www.dvidshub.net/news/529132/1998-thomas-jefferson-award-winners-announced)**
  - Source: dvidshub.net
  - *Jul 4, 2025 ... ... James Schauer; Chief Petty Officer Patricia Hoar. Second Place ... Private Ryan' Causes Tough Questions". Category J (Sports Artic...*

- **[Morons and Oxymorons: Undermining Women in Leadership ...](https://knowledge.insead.edu/leadership-organisations/morons-and-oxymorons-undermining-women-leadership)**
  - Source: knowledge.insead.edu
  - *Feb 7, 2013 ... - James Schauer. 863. Log in or register to post comments; Reply · 0. 0 ... AI: Disruption and Adaptation · Blue Ocean Strategy · Busi...*

- **[Prosperity For Every Generation](https://www.prosperityforeverygeneration.ca/)**
  - Source: prosperityforeverygeneration.ca
  - *James Schauer, CEO, Appnova Software Corporation, Montréal. Mary Smith ... Mike Morley, Founder/director AI/Ml, Menome Technologies Inc., Calgary. Sam...*

- **[Best Lawyers in South Milwaukee, WI | Justia Lawyer Directory](https://www.justia.com/lawyers/wisconsin/south-milwaukee)**
  - Source: justia.com
  - *... interview in their home country). Marc E ... Daniel James Schauer. SOUTH MILWAUKEE, WI Lawyer with 14 years of experience....*

- **[Celebrating one place, two traditions](https://www.uaf.edu/aurora/files/UAF_Aurora_fall2015_forWEB.pdf)**
  - Source: uaf.edu
  - *An environmental center representative said the company was trying to turn a stream into “their own unregulated private waste dump. ... James Schauer ...*

- **[Margarete Schauer-Elbert](https://scikon.uni-konstanz.de/personen/profile/maggie.schauer)**
  - Source: scikon.uni-konstanz.de
  - *Elbert, Thomas; Moran, James; Schauer, Maggie (2017): Lust an Gewalt ... The identified cases were interviewed based on a structured interview and com...*

- **[October 2009 – International Division – UW–Madison](https://international.wisc.edu/2009/10/)**
  - Source: international.wisc.edu
  - *Oct 27, 2009 ... UW-Madison News Release CONTACT: James Schauer, 608-262-4495 ... private voluntary codes of conduct monitored by professional auditor...*

---

*Generated by Founder Scraper*
