# Grégoire L.

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401650307610554368 | Celebration |  | https://media.licdn.com/media/AAYABAQSAAgAAQAAAAAAANJLzxZspMXOR2qc6yZIDOjDfQ.gif | 2025 Wrapped in fashion! 💻 📚 🏹 
I’m happy to share that I am now a Certified Associate Game Developer at Unity!
It's a long way... 🤘 💙

Thank you Alistair Mountain Niall Talbot Browne for the great preparation and support 🤘 | 27 | 3 | 0 | 5d | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:37.136Z |  | 2025-12-02T15:55:49.347Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388965673642852352 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d79eca30-9919-40d3-b633-cbce7c939a30 | https://media.licdn.com/dms/image/v2/D4E05AQE90_0oBfXTQQ/videocover-high/B4EZorg_rCIoB8-/0/1761666684870?e=1765774800&v=beta&t=m6mAHY2vXlpV3oHrxAUPa_pbXGBzNDRQ04RyALSxLP4 | Offre-toi une pause musique dans ton doom-scrolling professionnel! 💙 🪰 ...

Et si, pendant une minute, vous pouviez mettre de côté votre business plan, vos KPI et les réunions pour un moment de simple évasion artistique ?

Mon premier single solo, "Moucherons", est cette pause et voici un extrait de son passage chez les talentueux créateurs des Sessions Véranda.

C'est une ballade acoustique et sensible qui explore ces petites choses qu'on met de côté, ces pensées persistantes – nos "Moucherons" – qui nous tournent autour jusqu'à ce qu'on prenne le temps de les adresser. Une mélodie tout en contraste, qui passe de la mélancolie à la lumière, portée par une progression unique.

C'est un immense honneur de voir ce morceau immédiatement ajouté par Spotify à la playlist "Québécois Contemporain", reconnaissant ainsi ce premier pas dans ma triple vie de commercial/artiste/couteau-suisse technique.

Pourquoi ce partage sur LinkedIn ?

L'Équilibre Créatif : En tant qu'artiste franco-canadien basé à Montréal, je jongle entre la composition pour le théâtre et les courts-métrages, mon projet solo, les projets AV collectifs, l'écriture et mon travail "de la vraie vie" dans le monde de la 3D qui soutient tout cela (On pourrait d'ailleurs parler longtemps de notre représentation de ce qu'est la notion de "travail").
Ce single représente l'importance d'intégrer le sensible dans le quotidien, une nécessité même dans votre monde professionnel.

Encourager la Relève : Chaque écoute est un soutien direct à un nouvel auteur-compositeur qui démarre. Si la musique peut vous offrir une bulle de sérénité aujourd'hui, j'ai rempli mon objectif.

Oubliez les notifications pour un instant et laissez la musique faire le ménage dans votre tête. 😉 ✌ 

🎶 Écoutez "Moucherons" sur votre plateforme préférée : https://lnkd.in/eU_JQV26

#Musique #PauseCréative #GrégoireLemån #QuébécoisContemporain #ArtisteMontréal #BienÊtreAuTravail #Moucherons #ÉvasionAcoustique #AuteurCompositeur | 39 | 7 | 1 | 1mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:37.138Z |  | 2025-10-28T15:51:36.940Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7358899151713026048 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABwEEXEeLoHISM2cU9LdzliLaQ.gif | Adding another string to my bow with this certification: Unity Junior Programmer from Unity! 🤗 🏹 🎛️ | 34 | 2 | 0 | 4mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.104Z |  | 2025-08-06T16:37:59.503Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7344378498645467138 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ce6b22b5-26f5-4b14-886f-1d248b82f126 | https://media.licdn.com/dms/image/v2/D5610AQF8JwMzzMZ_nQ/videocover-low/B56ZeueHK4GoBU-/0/1750978851311?e=1765774800&v=beta&t=KZuLbPBwbdb2s94z5gHhabXLApZ8BNF82nvLEJZB5Cc | Our "Intro to Unity Industry" course is now FREE for a 30-day trial period! 🎊 
A great resource to kick off your RT3D journey 🤙 
➡️ https://lnkd.in/gmxJBfuR | 2 | 0 | 0 | 5mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.111Z |  | 2025-06-27T14:58:06.031Z | https://www.linkedin.com/feed/update/urn:li:activity:7344137634153209857/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7341170381111664643 | Video (LinkedIn Source) | blob:https://www.linkedin.com/31534d6c-f9f8-40b6-ac18-f78cab0fb06e | https://media.licdn.com/dms/image/v2/D5605AQFLScLY5niu9w/videocover-low/B56ZeETaiqH8CA-/0/1750271381566?e=1765774800&v=beta&t=PFm_b_yViSXVC7tMO3LWWJLzGVd30xvns79dhA-HF-0 | This is pretty sick! 🤩 👏 United Visual Researchers | 10 | 2 | 0 | 5mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.111Z |  | 2025-06-18T18:30:11.207Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7329118169392914433 | Video (LinkedIn Source) | blob:https://www.linkedin.com/91e00ad0-f3b3-411c-8f22-9770459d4c22 | https://media.licdn.com/dms/image/v2/D5605AQFrG8DprkbNgA/videocover-high/B56ZaSyfGhHUAc-/0/1746219451320?e=1765774800&v=beta&t=zhFOJ0b4_4IdFIE1EDtKso1sXpej6x_M562XrXVDI1o | 3D-Visualization can change the way we represent sound for more compelling and engaging audio productions. 
It's inspiring to see people break out of X/Y axes thinking patterns. 🤔 | 1 | 0 | 0 | 6mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.117Z |  | 2025-05-16T12:19:00.014Z | https://www.linkedin.com/feed/update/urn:li:activity:7324175290878828546/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7318313048409026560 | Article |  |  | 💻 🔥 📆  Join us on May 1st in MTL for a day-long event tailored for Unity Industry Users, where you'll explore techniques and gain insights to create high-fidelity, production-ready results. Learn from experts, enhance your skills, and take your 3D creations to the next level! | 4 | 0 | 0 | 7mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.125Z |  | 2025-04-16T16:43:18.422Z | https://unity.com/events-hub#upcoming-events |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7290061541452759040 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABgBrZ2daanMQJ-egBdqUfzcNg.gif | I’m happy to share that I’m starting a new position as Partner Relations Manager, Industry / Developers at Unity and realizing a life-long dream to evolve in the 3D-creation world!

A special thank you to Maria Garcia Corby for your recommandation and support; to Daniel Bradshaw, MBA, PHR for your efforts during the process and thank you Laura Sanabria Galvis, Samantha Rodrigues, Lolo Princewill, Emaleigh Shriver and Jose Miguel Mendez for your vote of confidence. 

Looking forward to embarking on this new journey! | 89 | 35 | 0 | 10mo | Post | Grégoire L. | https://www.linkedin.com/in/gregoireleman | https://linkedin.com/in/gregoireleman | 2025-12-08T04:46:42.127Z |  | 2025-01-28T17:41:54.276Z |  |  | 

---

