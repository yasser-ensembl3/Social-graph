# Suzanne Dergacheva

## Position actuelle

**Titre** : Co-founder, Strategist, Drupal Practice Lead
**Entreprise** : Evolving Web
**Durée dans le rôle** : 18 years 7 months in role
**Durée dans l'entreprise** : 18 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Description du rôle

I work with organizations across North America to help them improve how they leverage digital technology and design. I bring a strategic mindset, the perspective of the end-user, and my technical background to these conversations. I get to work with clients across from the education, government, non-profit, and public sectors including Princeton University, the Art Gallery of Ontario, and the Government of Canada.

I also contribute thought leadership and lead workshops on topics from content strategy and governance to user experience and design patterns. I care deeply about accessibility, open source, and making it easier for people to use and adopt new technology.

## Résumé

Hi, I’m Suzanne — co-founder of Evolving Web, a full-service digital agency built on collaboration and a deep commitment to our clients’ goals.

Over the past 17+ years, I’ve worn just about every hat while growing Evolving Web—from designer and developer to strategist, trainer, and team lead. What started as a small web shop is now a 90+ person agency trusted by universities, governments, and nonprofits across North America to lead large-scale digital projects that are thoughtful, accessible, and built to last.

Our team specializes in designing and building complex websites, often on Drupal and WordPress, with a focus on content strategy, UX, accessibility, and sustainable digital ecosystems. I lead our Drupal practice and digital strategy work, helping institutions like McGill, Princeton, Planned Parenthood Direct, and the Ontario Securities Commission turn their goals and challenges into solutions that meet real user needs.

What drives me is not just building great websites, but having real conversations. I like to start by listening—understanding where you’re coming from, what’s working, what’s not, and where you want to go. From there, I share insights and a vision that makes sense for your team, your users, and your long-term digital strategy.

If you’re exploring a redesign, trying to make your content easier to manage, or just curious how to move your digital strategy forward, I’d love to connect. No sales pitch—just a conversation.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAESB9QBrNdwR9IaieoejPedMePMEHHdEdw/
**Connexions partagées** : 52


---

# Suzanne Dergacheva

## Position actuelle

**Entreprise** : Evolving Web

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Suzanne Dergacheva

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399162104953593856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhtFa4dH-Mmw/feedshare-shrink_800/B4EZq8RF9nHgAk-/0/1764095191768?e=1766620800&v=beta&t=O6wXh93eALRIYOF_knAhy1gWPdFB8rxQaR7ewuy6asc | Organizing a 2-day summit is a lot more work than a 1-day summit (it's not less than twice as much work!) But the nice thing is that as an organizer, you might actually have a chance to go to some talks and have some in-depth conversations. Thanks Alex for sharing your highlights from last week's EvolveDigital NYC! | 4 | 0 | 0 | 1w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.373Z |  | 2025-11-25T19:08:35.605Z | https://www.linkedin.com/feed/update/urn:li:activity:7399151538264281088/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399110961674203136 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGdFpD4t6Szrw/feedshare-shrink_800/B4DZq7pFtdIEAg-/0/1764084702333?e=1766620800&v=beta&t=gX3WmIyFrQvnRtaZul7Vc9SdLEkUIiQ1IMbA1-U0Owg | Drupal meetup at Montreal CoWork tonight! 

I’m looking forward to hearing what Diego Castro has to say about integrating Figma with Drupal. If you’ve been meaning to try out Drupal Canvas (aka Experience Builder), but haven’t had time, Romain N. is going to do the work for you. And Albert Albala is coming to talk about PHPMetrics, which is totally new to me. Something for everyone! | 7 | 0 | 0 | 1w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.374Z |  | 2025-11-25T15:45:22.097Z | https://www.linkedin.com/feed/update/urn:li:activity:7399107531119267843/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7398810520553832448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGiKEWnVecpAw/feedshare-shrink_800/B4EZq3a8M3KcAg-/0/1764013887286?e=1766620800&v=beta&t=yHqbhDds3mtfELUL2bfAim1c_Yiu4U4hWsIK3zkFUoI | I just got home from EvolveDigital NYC, and as I’ve been following up with the people I met there, I keep thinking about how this event attracts so many thoughtful people and ideas.

This particular summit brought together web designers, technologists, communicators, and digital craftspeople from all kinds of backgrounds and platforms. Even with all the talk about “the age of AI,” what really stood out were the constants: relationships, human needs, collaboration, governance, and education.

Those themes surfaced again and again throughout the event.
What I appreciated most was how open people were, sharing challenges, comparing notes, admitting what’s hard, and talking about what’s actually working. Drupal folks, WordPress folks, strategists and marketers, and people building on completely different systems found plenty of common ground.

Some moments that stuck with me:
⭐️ Deanna Lorianni's talk about plain language and why it matters now more than ever
⭐️ Balanced, practical conversations about AI, not overly optimistic or gloomy
⭐️ My landing page content session, which sparked great discussions (thanks to my team at Evolving Web for supplying many of the case studies I showcased)
⭐️ Reconnecting with friends from the Drupal and Digital Collegium communities, and meeting so many new faces
⭐️ And of course…the surprise rapper who turned our closing remarks into something none of us will forget 🎤

A big thank-you to my teammates at Evolving Web, to Pantheon for co-organizing, to our other sponsors Digital Polygon and Automattic, to all the speakers for bringing valuable content, to Maya Schaeffer, Erin Callihan, J.D., Tammy Hung, Robert M. Kadar, Josh Koenig, James Rutherford who put so much personal energy into promoting the event, and to the volunteers who gave a contributed so much energy the during the 2-days.

I’m already looking forward to catching the sessions I missed when the videos are live (should be soon!) and to continuing these conversations long after the conference. Follow EvolveDigital + EvolveDrupal Summits for updates on the next event! | 85 | 6 | 4 | 1w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.375Z |  | 2025-11-24T19:51:31.352Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396565836544782336 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6a819394-f47d-45f8-be02-292b4889ce6b | https://media.licdn.com/dms/image/v2/D4E05AQEGgVz5RgbLjw/feedshare-thumbnail_720_1280/B4EZqXhahiIUA0-/0/1763478711757?e=1765778400&v=beta&t=qQ4kOlEssx9saIM2zP-UC-lpafss7IJDAzgllsRNcU4 | I’m excited about the design conversations that we have lined up for EvolveDigital + EvolveDrupal Summits NYC this Thursday and Friday (Nov 20-21). The design track features a nice array of topics from rebrand stories to design systems for small teams and big orgs, and hands-on ways to bring accessibility into your day-to-day work.

Here are a few of the highlighted design talks that I'm particularly looking forward to:
⭐️ Rebrand, for real with Dust Leblanc (Locomotive) about a 700-day journey to launching a new brand.
⭐️ NYT Brand Studio: behind the scenes with Hannah Ahn (The New York Times) about turning brand stories into immersive editorial experiences.
⭐️ Plan for growth, not just launch day with Jessica Monaco (Princeton) about visual systems that survive organizational changes and loads of new content.
⭐️ Design systems on a shoestring with Jeff Deutsch (Oxfam America) about lightweight governance that works for small teams.
⭐️ Strategy happens in low-fi with Pavel Samsonov (Justworks) about making better decisions early in the design process.
⭐️ Accessibility in practice with Emma Mansell (NYPL) about screen-reader-friendly engineering and how it impacts their design system

The nice thing about doing an event that mixes tech, design, and strategy is that it's not just designers who can benefit from these presentations, but also the developers, strategists, and managers who collaborate with them.

👉 Register: http://evolvedigital.com

#DesignSystems #UXDesign #Brand #Accessibility #ContentDesign #EvolveDigital | 20 | 0 | 1 | 2w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.377Z |  | 2025-11-18T15:11:56.980Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7395146208966504448 | Document |  |  | Can't wait for the event! One week left to go. | 2 | 0 | 0 | 3w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.378Z |  | 2025-11-14T17:10:51.390Z | https://www.linkedin.com/feed/update/urn:li:activity:7395142599579369472/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394071752068317184 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF5zfZgtitrIg/feedshare-shrink_800/B4EZp0FEf3IoAk-/0/1762884078728?e=1766620800&v=beta&t=Ey3bRqo6uKem9TTHmdN1Dwgq8zLutcpKHku-Cxvm6cg | WordPress is on the program at EvolveDigital + EvolveDrupal Summits in NYC November 20 to 21 (evolvedigital.com). I'm especially excited about the talk about WordPress training from a low vision perspective. Often we think of accessibility as "designing for screen readers," so this is going to bring some fresh ideas!

Why should WordPress folks attend? To get into a digital state of mind, and take home specific insights into making your WordPress website secure, AI-ready, and editor friendly. Learn from other WordPress users and network with designers and technologists in the wider digital sphere.

Highlights for the WordPress crowd:
⭐️ Teaching WP through a new lens with Bud Kraus (Joy of WP) accessibility and career reinvention from a low-vision creator’s point-of-view.
⭐️ Security as a mindset with Jonathan Desrosiers (Bluehost & WP Core) that features practical ways to harden your platform and evaluate new tools, from a core contributor.
⭐️ Design for content editors with Jesse Dyck (Evolving Web) — shaping block/Site Editor experiences that are fast, brand-safe, and accessible.
⭐️ AI that empowers creators with Ronnie Burt (Automattic) about building the web we actually want: open, configurable, human-centered.
⭐️ Creator authenticity on TikTok with Darian Lusk (Automattic) lessons from launching the official WordPress account.
⭐️ Lots of other content about digital strategy, design, and technology to broaden your horizons.

 👉 Register: evolvedigital.com
 #WordPress #WPDev #BlockEditor #SiteEditor #WebSecurity #EvolveDigital | 19 | 2 | 2 | 3w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.381Z |  | 2025-11-11T18:01:20.903Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7393672818174873600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHAO724mIxhTA/feedshare-shrink_800/B4EZpuaPioKcAg-/0/1762788966065?e=1766620800&v=beta&t=W-R1vCrtFnVIOeH37oofG17AOsMWTXCGetkn15y-v74 | Join your Drupal friends in NYC at EvolveDigital Nov 20-21 evolvedigital.com

We have two days of case studies, developer insights, governance wins, and AI-in-the-workflow, plus lots of hallway wisdom. We’re bringing together the Drupal community, in the context of a bigger digital strategy, design, and tech conference.

Some of the highlights:
⭐️ Responsible AI for devs with Michael Miles (MIT Sloan). Learn about how Copilot, not going on autopilot, can help keep code quality high.
⭐️ Conference platforms at scale with Tammy Hung & Abhimanyu Gupta (IEEE ComSoc). About designing a multi-conference system powered by Drupal Groups.
⭐️ Accessibility that isn’t “another task” with John Jameson (Princeton University). Building editing experiences with the Editoria11y module helps make accessibility compliance of your content the default.
⭐️ Working with 3rd-party data with Aaron Pinero (Columbia Health Sciences Library). Learn a way to build better Drupal integrations, with Queue API.
⭐️  Enterprise migrations at speed with Katie Manzi (CFA Institute). Find out how they moved 3 major sites to Drupal in 6 months.
⭐️  Stay up-to-date on Drupal Canvas with Matt Glaman and Evolving Web's Rich Lawson 

Plus lots of talks on digital strategy, design, and content that will get you outside the Drupal bubble!

📍 NYC • 2 days of sessions, panels, UX feedback, and hands-on training
 👉 Register: evolvedigital.com
 #Drupal #DrupalCMS #HigherEdWeb #Accessibility #OpenSource #EvolveDigital | 29 | 2 | 3 | 3w | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.382Z |  | 2025-11-10T15:36:07.651Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391128256806293505 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHU8StBoQnBSg/feedshare-shrink_800/B4EZpKP.ijKkAg-/0/1762182294821?e=1766620800&v=beta&t=Qs1Z_b7xgv6tjgG0umky-7967b01NOzB4JMQQBHomMs | Big news — EvolveDigital NYC is coming up November 20–21! 🎉evolvedigital.com

I’m thrilled to be helping organize this next edition of EvolveDigital, our event for anyone passionate about digital strategy, design, and technology. 

This summit, the lineup is bigger than ever, with fresh topics and incredible speakers, including:
 💡 Matt Glaman joining Evolving Web’s Rich Lawson to talk about Drupal Canvas — a game-changing new way to approach content creation.
 🧩 Jessica Monaco (Princeton University) sharing how to build sustainable design systems through the lens of content governance and long-term strategy.
 ♿️ Rachel Weitzner and Samantha B. (Verizon) introducing companion studies, an inclusive research approach that brings accessibility and product researchers together to include diverse participants and assistive tech users.

We’ve got something for everyone: from higher education (MIT, Princeton University, Columbia University, Georgia Tech, 
University of Rochester) and nonprofits (like the NY Public Library, Guttmacher Institute, Oxfam America) to startups, enterprise, and digital agencies.

🔗 Explore the full schedule: http://evolvedigital.com
EvolveDigital is all about learning from real-world examples, connecting across disciplines, and getting inspired by new ideas: whether you’re a marketer, designer, developer, or digital strategist.

Can’t wait to connect with everyone in NYC!

Tagging some first-time collaborators like Lara Harrison from the National Audubon Society, Ronnie Burt from WordPress.com, Cedric Clyburn from Red Hat, and Erin Callihan, J.D. from New York University. Super excited to have you on board! | 52 | 6 | 9 | 1mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.383Z |  | 2025-11-03T15:04:56.945Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7384254934244036608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErkcw0tP6QFA/feedshare-shrink_800/B4EZnokuXwIIAg-/0/1760543567092?e=1766620800&v=beta&t=gwbpbTjK6hYJxTUv4daXYoVIst__81-u9ukLHtSwfPw | Last month, I got to attend the Digital Collegium annual conference in Grand Rapids. Our Evolving Web team spent three energizing days connecting, learning, and sharing ideas with the higher ed digital community.

This conference is something special. The organizers, attendees, sponsors, and vendors cultivate a warm and welcoming event culture that helps connect the higher ed ecosystem. People  generously share knowledge, collaborate, and strive for inclusivity. As I walked through the vendor hall, I reconnected with so many friends and made some new connections too. 

Some highlights from the event:
 ✨ My colleagues Jesse Dyck and Celia McAlpine gave a fantastic session on auditing and designing components
 🧩 Jesse also teamed up with volunteers from the WordPress community to staff the #WordPressHappinessBar, helping folks troubleshoot plugin issues, explore AI integrations, and trade best practices
 💬 I had the chance to present about Drupal CMS, and how it can better support content teams and even form a starting point for your campus-specific CMS
 🌐 We spread the word about our EvolveDigital + EvolveDrupal Summits happening in NYC this November (20–21)
 🤝 And, of course, we met so many amazing people and especially meeting our clients who are local to Grand Rapids: Calvin University and Grand Rapids Community College

A few trends that I found came up in many conversations:
 💡 AI is everywhere, but teams are still figuring out how to integrate it meaningfully into workflows
 🔗 Multisite is thriving in higher ed — so many institutions are making it work at scale for large-scale ecosystems
 💙 Everyone is talking about governance and looking for ways to align user experiences and brand, whether you're at a 2,000 person college or a massive university network

Huge thanks to the Digital Collegium organizers and everyone who makes this event what it is! | 36 | 3 | 0 | 1mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.385Z |  | 2025-10-15T15:52:49.146Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7382427766484385792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEfyNkXgJNGOQ/feedshare-shrink_800/B4EZnOm6WtHMAg-/0/1760107936665?e=1766620800&v=beta&t=ZBpEOef3rFnFrvye1QHO7ADgGaliRYgByQ9f587SEhU | At every conference I go to, governance is an underlying theme. You need your websites and platforms to be accessible and brand-compliant. And you need to keep those content editors on track, without making them upset! 

If you see me getting animated in the hallway track, it's probably because we're talking about how to solve a governance problem.

As digital teams grow and roles get more specialized, we need ways to stay aligned. So people invest in design systems, style guides, and brand portals. But these only help if your team wants to use them. So what are the right tools? And what role should developers, designers, and content or marketing folks play in building governance?

Evolving Web is hosting a webinar on this topic next Friday, October 17 at noon ET, and I’m thrilled to be joined by our panelists:
Jeff Deutsch of Oxfam— bringing the design perspective
Chaz Chumley of UCLA Health — representing the developer’s view

If governance is one of those “problems to solve” on your list, you should join us!

 👉 Sign up at: https://lnkd.in/eQrFajgQ | 23 | 1 | 3 | 1mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.386Z |  | 2025-10-10T14:52:18.405Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7374489865369075713 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEM-otdWr8u0A/image-shrink_800/B4EZlSqkAxHgAc-/0/1758028514692?e=1765778400&v=beta&t=8NtpaKn41_aT8ikt1SbG0XK4mrBvaq8Y2BwyA_VRbO8 | Check out this talk I'm giving with A11yTalks next week! With some insights from how we flag and handle accessibility challenges at Evolving Web. | 20 | 1 | 1 | 2mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.387Z |  | 2025-09-18T17:09:55.300Z | https://www.linkedin.com/feed/update/urn:li:activity:7373706120382685184/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7373367446201851904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFkzD4bULRPUA/feedshare-shrink_800/B4EZlN2nyuKcAg-/0/1757947788887?e=1766620800&v=beta&t=grYku9hUxoVOx5X_ukFeJw2pW5gJTbYgzMCU7NDrV9U | Rejoignez Evolving Web ce vendredi 19 septembre à midi pour un webinaire en direct avec mon amie Amandine Michaud, MBA
 
IA, surinformation, budgets compressés… et si l’authenticité était le meilleur antidote? Dans un monde saturé par l’IA et la pression de « faire plus avec moins », comment vraiment se démarquer?

Amandine, fondatrice d’Aria Conseils et ex-directrice des communications et cheffe de cabinet du PDG d’Otéra Capital (CDPQ), partagera son expérience unique.

Vous y découvrirez :
* Comment simplifier vos messages pour capter l’attention malgré la surinformation
* Comment transformer l’authenticité en avantage concurrentiel
* Des exemples concrets tirés des coulisses de la gestion de crise et du redressement de réputation
* Des outils pratiques pour renforcer durablement la crédibilité de votre marque

Ce webinaire fait suite à la présentation du EvolveDigital + EvolveDrupal Summits à Montréal, avec du contenu revisité et enrichi pour répondre à vos réalités actuelles.

👉 Inscrivez-vous et venez échanger avec nous: https://lnkd.in/eZhWfEpu | 7 | 1 | 1 | 2mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.388Z |  | 2025-09-15T14:49:49.717Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7369377136895303680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHliSfRpECzew/feedshare-shrink_800/B4EZkVJcwoIQAk-/0/1756996424385?e=1766620800&v=beta&t=0j5L_0kuAilqYOP9_6GYsGo-ncyeeZGq0CNB3Uofq74 | I’m a minimalist: a clear desk and no extraneous kitchen gadgets or conference t-shirts. In 2010, I decided I was sitting on too many domain names that were gathering dust and cancelled a few of them. 

Fast-forward 15 years and I hear this podcast from Planet Money about what a domain name can be worth and I’m full of regrethttps://lnkd.in/eMerscJW. Now I am seeing the 1-word domain names everywhere and I see how easily they influence my brand perception.

Evolving Web recently bought evolvedigital.com for our EvolveDigital + EvolveDrupal Summits. We’ve been evolving the brand of these events over the last 2 years to create an inclusive summit that brings together tech and design with digital marketing and strategy. The vibe feels more like an open source community event than a sales-driven corporate event.

The next one is coming up in NYC on November 21st. If you have a story to tell, now is the time to submit a session. Find out more on our website: http://evolvedigital.com. | 40 | 5 | 2 | 3mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.388Z |  | 2025-09-04T14:33:45.842Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7369066831787085825 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGICZ9433nNfQ/feedshare-shrink_800/B4EZkQvO5nIkAw-/0/1756922441742?e=1766620800&v=beta&t=cI7DTxHgcpScZKKKF2_-FCi1qS3aUEmrTT2LVzfMK7o | My colleagues are in NYC this week, hosting an EvolveDigital + EvolveDrupal Summits happy hour at the Lookup on Broadway and West 35th. Thursday at 5:30pm. Meet up with Maya Schaeffer, Alex Dergachev and the digital thinkers they're hanging out with this week. Wish I could be there! RSVP at https://lnkd.in/eJAyeRfa | 15 | 1 | 1 | 3mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.389Z |  | 2025-09-03T18:00:43.339Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7355609478748127233 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH-wnxHgak1jg/feedshare-shrink_800/B56ZhRf15BHcAg-/0/1753713958996?e=1766620800&v=beta&t=RqK8YmbNl8Vk2zB7fgIGmVN8N-YTde4ukICI2GtZO_k | The next EvolveDigital + EvolveDrupal Summits is happening in Montreal on Monday, August 4th. Come hang out with us for a day of learning and networking. This is a down-to-earth conference where people share what they're working on in digital. Join other designers, strategists, developers, product managers, and content creators. There will also be students and career-shifters, newcomers are very welcome!

We have a fantastic lineup of talks from organizations like CBC/Radio-Canada and the University of Toronto, case studies about design transformations, and insights from enterprise CMS projects. If you’re a digital communicator wanting to pick up more technical know-how or a web developer looking to expand your design skill set, this conference overlaps disciplines on purpose so you can out of your bubble. 

Here’s a link with all the details: https://lnkd.in/g6e5u7m7.

Message me if you have questions about what you'll get out of the conference, or have questions about our events. The location is Montréal CoWork-B Corp™, right next to the Plateau Mont Royal metro station. 

#Accessibility #Design #WebDevelopment #Drupal #WordPress #CMS | 28 | 3 | 3 | 4mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.390Z |  | 2025-07-28T14:46:00.349Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7348755000568823811 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHlPNRYx4HKBQ/feedshare-shrink_800/B4EZfwFubLHEAg-/0/1752079723418?e=1766620800&v=beta&t=8_8P5rP4tgTV5AT9zPRJfoISwwgGZ9iRm45lBWPbBWY | Evolving Web turns 18 today 🥳 And as one of the co-founders, that means I've technically had the same job for 18 years...

But in no real sense is my job the same as it was in 2007 when Alex Dergachev and I started the company. We literally started it out of our student apartment when we were graduating from McGill University. We were swept up in enthusiasm about tech startups and open source, which became a big part of our identity and culture.

Some things I’ve learned as a woman in tech, an open source contributor, and a founder:

1️⃣ Talk about what’s hard.
Whether it’s growing pains or project failures, talking about your challenges and what doesn't work is part of the learning process.

2️⃣ Stay curious.
The technology and tools look completely different from 18 years ago. A willingness to keep learning and being open to change is essential.

3️⃣ There an abundance of digital work.
The need for thoughtful digital strategy is huge. We don’t need to hoard knowledge.

4️⃣ Impact happens at every level.
We’ve worked with institutions that are changing lives—through healthcare, education, and public service. But the impact is also personal. Clients who get energized by our training sessions. People who’ve built entire careers with Evolving Web. Teammates who light up when they learn something new.

5️⃣ Open source = striving to do it right.
When you're building in an open source environment,  what you create is designed to be used by a big community. This means, you pay more attention to the details, and helps you scale up. Whether creating a slide-deck template,  picking a CSS class or machine name, or building a design system, there's value in doing it right.

6️⃣ Some of the best lessons come from teaching.
Our training program has brought me into dozens of higher ed, government, and enterprise organizations and other agencies across North America, and I've learnt so much about different work cultures from this experience.

7️⃣ Partnerships matter.
We’ve built long-term relationships with organizations we admire. We’ve learned from fellow agencies. And we’ve had the joy of contributing to the Drupal and WordPress communities alongside some brilliant people.

8️⃣ Never stop learning.
Mentorship, open source contribution, community events, investing in people—all of it keeps me growing. Shoutout to our EvolveDigital + EvolveDrupal Summits that give me a chance to teach and learn.

#EvolvingWeb #Drupal #OpenSource #DigitalStrategy #EvolveDigital | 121 | 2 | 2 | 4mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:10.391Z |  | 2025-07-09T16:48:45.401Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7346185861568364544 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFqjZQolM12g/feedshare-shrink_800/B4EZfLlGqNGcAk-/0/1751467191667?e=1766620800&v=beta&t=Sp7EyuxzrNHsT8RvSOzipexCVMmCfDpDAce-T46cF_M | Yesterday was Canada Day and I was thinking of how much Canada benefits from its diversity. And just the face that Canada means many different things to the people who live here. There’s something dynamic about living in a place that doesn’t define itself in just one way. Most of my colleagues at Evolving Web were born somewhere else, and the pride that I feel on Canada Day is the pride that they've decided to come here to make it their home.

In Quebec, Canada Day is also moving day. In Montreal, we see more moving trucks that Canadian flags, because the majority of leases are dated July 1st. This year, Evolving Web moved to a brand new office, that’s located in my neighbourhood, Plateau Mont Royal. Our offices are inside Montréal CoWork-B Corp™, meaning we get to be part of a bigger community, with many other technologists and designers as office-mates. And I'm excited about this new piece of Evolving Web's identity. | 60 | 4 | 0 | 5mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.759Z |  | 2025-07-02T14:39:54.931Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7340747599907348480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEURDjMKCrLvw/feedshare-shrink_800/B4EZd54.STHsAg-/0/1750096670021?e=1766620800&v=beta&t=cKff7A_-s6H5ojo1zTKBE3-E460X6qzgcJbWnTKF7VE | At EvolveDigital + EvolveDrupal Summits Boston, my team put so much work into creating a great program of talks. From building brand trust, to deep-dives into Drupal's Experience Builder, to the impact of AI, it was a jam-packed 1-day conference.

That said, I missed most of the presentations in favour of the hallway track. Partly because I had so many people to catch up with, and partly because I had a 2-year-old conference buddy.

So... I've been watching ALL the videos to catch up on what I missed. At first, I had a list of highlights to watch, but now I'm just putting them on 1.5x speed so I don't have to skip any.

Here’s a link to the playlist: https://lnkd.in/eG3TpdCq. Thanks to the team effort from my colleagues at Evolving Web for getting these online so quickly!

What you won't find in these recordings is the pre-conference karaoke, the closing remarks featuring a professional comedian, or all the useful side-conversations in the hallway. Catch the next event to get the full experience: http://evolvedrupal.com. | 35 | 0 | 0 | 5mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.760Z |  | 2025-06-17T14:30:12.313Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7340420805266161664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEEP-6gOUizUw/feedshare-shrink_800/B4EZd5p0lqGwAg-/0/1750092696402?e=1766620800&v=beta&t=svbsHxU8_5vvRHJPon8ylk5Ec9tf2XMf-EMUHQarlGc | Drupal has millions of users and a huge contributor community, but not as many members as you would expect. Drupal Association members support the work of running Drupal.org, DrupalCon, and an increasing role in marketing Drupal as a product. 

I encourage everyone who uses Drupal to sign up as a member TODAY (June 16) by 8pm ET, which will give you a vote in the association board elections that start tomorrow night.

My colleague Maya Schaeffer is running to become a community-elected board member. As a former board member, I know she’ll do a great job of bringing fresh ideas and energy to this role. She's already contributed a lot through her event-organizing and promotion efforts 💙

📣 To be able to vote, you must create a drupal.org account and become an Individual Member by donating $1. Make sure to use the same email for your account and your donation.

1. Create your drupal.org account: https://lnkd.in/eWnKNx4Z
2. Donate $1 or more https://lnkd.in/eeGmuQui
3. Election info https://lnkd.in/eMjE3pBy including the information on all the candidates and their platforms.Detailed signup instructions : https://lnkd.in/eq3QPM8G

#Drupal #OpenSource #Community | 39 | 1 | 2 | 5mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.761Z |  | 2025-06-16T16:51:38.399Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7335711448066613249 | Video (LinkedIn Source) | blob:https://www.linkedin.com/488308c3-b50f-4c41-a16f-beada5fe81fc | https://media.licdn.com/dms/image/v2/D4E05AQGnFckFfyDcxg/feedshare-thumbnail_720_1280/B4EZc2ufKjH0A0-/0/1748969846145?e=1765778400&v=beta&t=lTbySGHFIXhDiqUZyHsCjM2Z1uP-cl3fqiqZHtOSNfk | I presented with Emily Kulms last week at a higher ed conference in Toronto about the redesign of the Loyalist College website. 

Loyalist has a really bold, exciting brand. And while they're proud of the fact that they offer a small college experience, their brand is big on impact and user experience.

We're doing the presentation tomorrow as a webinar, so if you are interested in how to make a bold brand work well online, or how to build out a WordPress site that's got the right balance of flexibility and governance, come join us!

June 4 @ 12 PM EST
Creating a Vibrant Digital Space: Bold Branding Meets Web Design
RSVP: https://lnkd.in/eJyj6nzy (you'll get the link to the recording in case you can't make it)

#WebDesign #HigherEd #DigitalStrategy #BrandImplementation #WordPress | 22 | 2 | 0 | 6mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.762Z |  | 2025-06-03T16:58:20.147Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7335687910244950016 | Video (LinkedIn Source) | blob:https://www.linkedin.com/59c91284-fb9b-4ea5-90b5-034fffaf0125 | https://media.licdn.com/dms/image/v2/D4E05AQHyEvgtsWz7pg/feedshare-thumbnail_720_1280/B4EZc2ZJojHcAw-/0/1748964255163?e=1765778400&v=beta&t=j7jp_BbxwobrJwluIogKyJL5RMZA4iHouoXA_VX3Rj4 | Today is the last day to sign up for the EvolveDigital + EvolveDrupal Summits in Boston this Friday: http://evolvedrupal.com. We'll be hanging out at the Microsoft NERD Center in Cambridge.

Here's a little preview video to get you excited 😆 | 10 | 1 | 3 | 6mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.762Z |  | 2025-06-03T15:24:48.293Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7335387229424386048 | Article |  |  | EvolveDrupal Boston is this Friday, June 6th. We have over 150 sign-ups, and it's not too late to register: http://evolvedrupal.com

I've had this issue at conferences recently where talks don't have the right level of detail. I'm longer an active developer, so learning the details of a technical approach or implementation seems too zoomed-in and detailed. And marketing or design sessions are often too zoomed-out and high-level to be useful, often lacking real-world examples.

Our goal is that the content at this EvolveDigital + EvolveDrupal Summits hits the sweet spot, with content that is both relatable and practical. We have speakers from a whole range of organizations, presenting topics at the intersection of digital strategy, design and technology. And we strive for a high concentration of case studies, so that you get to hear about the application of an idea, not just the sales pitch for why an idea is a good one.

The line-up of speakers include folks from all these organizations:

🎓 Higher-Ed - Harvard, MIT, RISD, Princeton, Yale
🌎 Brands - Honda, Purple.com, Chewy.com
💻 Tech - Acquia, Google, Pantheon, Mimecast, Contenful, DubBot 
🩺 Healthcare - WebMD, Boston Children's Hospital, UCLA Health
❤️ Nonprofit - Drupal Association, Oxfam America, Planned Parenthood
🏢 Agencies - Material+, JSI, Kanopi, OHO, SimpsonScarborough, EPAM, Bluefly, Lone Rock Point, Digital Polygon

We're also running three half-day pre-summit trainings on Thursday June 5. It's your chance to get in-person training about #Drupal and #UX, a unique opportunity to set aside time for learning new skills in a hands-on environment.

Hope you can join us! | 7 | 0 | 0 | 6mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.763Z |  | 2025-06-02T19:30:00.399Z | http://evolvedrupal.com/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7333192215713742848 | Document |  |  | The best part about organizing your own conference is getting to set the program. Here's the Agenda for EvolveDrupal Boston (coming up on June 6th). It's curated by humans that care deeply that you'll learn useful things and meet interesting people!

Long-term forecast says it will be sunny, that you'll get to hang out by the river and that the food will be delicious. Get the details and register at http://evolvedrupal.com.

Even if you're not attending, I encourage you to check out the topics, which show what Evolving Web and our co-organizer Pantheon are passionate about. And that shows the eagerness of people in our community to contribute and share what they know. 

EvolveDrupal = Collisions of ideas from people who have vastly different contexts and roles, but whose work touches digital. We combine marketing, design, and tech into one conference and break down the fake silos between these disciplines. 

Some highlights that I'm particularly looking forward to: 
⭐️ Alixandra Nozzolillo, MS from Harvard University Communications about the Rise of the Refresh - an approach that I've been advocating for recently as some higher ed budgets are shrinking
⭐️ Lynne Capozzi (who I work with as part of my Drupal Marketing contribution) in conversation with Steve Tisa and Roddy Young about marketing strategies and the future.
⭐️ Michael Tullo of Yale University talking about the Yale design system and YaleSites (I admit, I heard this talk at DrupalCon, that's why I know you'll find it interesting!)
⭐️ Andy Waldrop from WebMD talking about using AI in a regulated space (health). A case study about AI and the governance that goes hand-and-hand with it.
⭐️ My colleague Dharizza Espinach Barahona showing Drupal's up-and-coming Experience Builder tool, giving us a glimpse at the future of content editing.

And so much more about #Design #ContentStrategy #Marketing #FutureOfWeb #CMS #Drupal | 27 | 6 | 1 | 6mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.764Z |  | 2025-05-27T18:07:48.349Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7325896481830232065 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHU1NWk9_UTMg/feedshare-shrink_800/B4EZarQBmiHcAg-/0/1746629827961?e=1766620800&v=beta&t=SZXDJyqx9KUS1RQRhXj31PEks1QZ2pH2ZHjkTMyE4F4 | I’ve been to a lot of tech events over the years, but EvolveDigital + EvolveDrupal Summits really stands out. And the next one is coming up on June 6 in Boston.

Yes, I'm biased because my colleagues at Evolving Web are organizing the event. But it does combine what I love about small community feel of open source events with off-the-island thinking and a curated program of talks that goes way beyond the typical technical sessions. 

The event is small enough that you can actually talk to people, share ideas over coffee, and not feel lost in the crowd. And it brings together a mix of digital professionals from higher education, healthcare, non-profit, and government, and agency that you really want to connect with. 

Everyone is there to share practical ideas about brand, design and  strategy, the future of digital, CMS (Drupal and beyond), and adjacent technologies. And maybe a couple AI sessions thrown in for good measure ;) There’s a full day of sessions, lightning talks, networking, delicious food, and coffee.

We're holding it at the Microsoft NERD Center in Cambridge, which promises to give us a friendly, upbeat atmosphere, has lots of windows, and is next to the river. If that sounds like your kind of vibe you can get all the details at http://evolvedrupal.com.

Hope to see you there!

#TechEvents #Design #UX #CMS #Drupal #Boston | 27 | 2 | 2 | 7mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.765Z |  | 2025-05-07T14:57:09.843Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7323064214368014339 | Document |  |  | Got Opinions About Websites? We Want to Hear Them! 

EvolveDrupal Summit Boston is coming up on June 6th

The call for speakers is open until May 7th and we'd love to get your submissions. If you have thoughts about CMS-based websites, digital design, UX, or strategy — and you’re not afraid to share them — come join us in Boston!

For this event, we’re teaming up with our friends at Pantheon to make it our best yet. Expect sessions about:
✨ Design systems
✨ Branding in the age of AI
✨ Web accessibility + usability testing
✨ CMSs like Drupal, WordPress, Contentful, Webflow
✨ Front-end tech like Storybook and NextJS
✨ AI prompt engineering and more

Whether you want to present a big idea, a case study, or a lightening talk, we want to hear about it. 

Submit your talk idea to http://evolvedrupal.com. 

#EvolveDrupal #Drupal #WordPress #Contentful #Webflow #NextJS #DesignSystems #UX #Accessibility #AI | 12 | 0 | 0 | 7mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.766Z |  | 2025-04-29T19:22:44.659Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7320840844331139073 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdo_zYQ_5G9w/feedshare-shrink_800/B4EZZjZ9DNHMAk-/0/1745424471255?e=1766620800&v=beta&t=LweOMZglPapCUgY9-JezJtPudCXmO_N-ePpSTOnF8Mg | I’ll be speaking at a higher ed marketing and communications conference in Toronto, May 26–27. I’m joining the lineup at the 9th Annual Marketing and Communications for Post-Secondary Conference, and I’ll be giving two talks about building better higher ed space.

The sessions are based on work I’ve done with teams at colleges and universities who are navigating a lot of competing priorities: managing content across departments, making design decisions, keeping up with technology, and trying to create a digital space that actually connects with their audiences.

Here’s what I’ll be sharing:
🔹 4 Big Ideas to Drive Your Website Strategy
 This talk is about stepping back and looking at the big decisions that shape a higher ed website—navigation, search, content design, storytelling. I’ll go over what I’ve seen work (and not work) across projects, and offer a few ways to approach these decisions more strategically.

🔹 Creating a Vibrant Digital Space: Bold Branding Meets Web Design (with Emily Kulms from Loyalist College)
We’ll walk through the process behind Loyalist’s new website—from branding to technical implementation—and talk about how we tackled some of the common challenges in a collaborative, practical way.

Thanks Renee Summers for organizing the event! It's always a great learning environment, and it's not too late to register if you want to participate:
https://lnkd.in/e52N9Psm.

And if you're in Toronto, I’d love to connect in person. I’ll be around after the conference, just drop me a message!

#HigherEd #Toronto #DigitalStrategy #CMS #Design | 21 | 2 | 1 | 7mo | Post | Suzanne Dergacheva | https://www.linkedin.com/in/suzannedergacheva | https://linkedin.com/in/suzannedergacheva | 2025-12-08T05:20:14.767Z |  | 2025-04-23T16:07:51.934Z |  |  | 

---



---

# Suzanne Dergacheva
*Evolving Web*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 29 |

---

## 📚 Articles & Blog Posts

### [Suzanne Dergacheva - Co-founder | Evolving Web](https://evolvingweb.com/about/suzanne-dergacheva)
*2025-03-27*
- Category: article

### [Suzanne Dergacheva, Co-founder at Evolving web](https://www.slideshare.net/evolvingweb)
*2025-01-01*
- Category: article

### [Suzanne Dergacheva](https://acquia.com/about-us/team/suzanne-dergacheva)
*2025-07-01*
- Category: article

### [Practical Insights for Digital Teams - EvolveDigital Summit](https://www.evolvedigital.com/evolve-digital-montreal-2025)
*2025-08-04*
- Category: article

### [9th Annual Marketing & Communications for Post Secondary ...](https://summersdirect.com/conferences/9th-annual-marketing-communications-for-post-secondary-conference/)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Suzanne Dergacheva (pixelite)](https://www.drupal.org/u/pixelite)**
  - Source: drupal.org
  - *Suzanne Dergacheva (pixelite). pixelite's picture · git.drupalcode.org ... At Evolving Web, I get to manage Drupal projects, and provide strategic and...*

- **[Company Profile: Evolving Web](https://www.thedroptimes.com/219/company-profile-evolving-web)**
  - Source: thedroptimes.com
  - *Jan 4, 2022 ... Evolving Web was co-founded in 2007 by two university graduates Alex Dergachev and Suzanne Dergacheva. The company provides clients wi...*

- **[Weekly Reading List September 1 2025 - TPGi — a Vispero company](https://www.tpgi.com/weekly-reading-list-september-1-2025/)**
  - Source: tpgi.com
  - *Sep 1, 2025 ... Podcast: The State of Accessibility – Episode 13. Mark Miller ... Suzanne Dergacheva, Co-Founder of Evolving Web, is joined by Janell ...*

- **[Evolving Web | TheDropTimes](https://www.thedroptimes.com/organization/254/evolving-web)**
  - Source: thedroptimes.com
  - *Evolving Web was co-founded in 2007 by two university graduates Alex Dergachev and Suzanne Dergacheva. The company provides clients with collaborative...*

- **[Attendees - Félix Marzell](https://creativemornings.com/talks/felix-marzell/attendees)**
  - Source: creativemornings.com
  - *Podcast · About; About. About · Contact · Patrons · Corporate partners · Press ... Suzanne Dergacheva. Co-founder at Evolving Web. View profile. Profi...*

- **[9th Annual Marketing & Communications for Post Secondary ...](https://summersdirect.com/conferences/9th-annual-marketing-communications-for-post-secondary-conference/)**
  - Source: summersdirect.com
  - *Suzanne Dergacheva, Cofounder and Drupal Lead, Evolving Web Launching a new ... podcast and developing social media videos for the main channels. Lisa...*

- **[Practical Insights for Digital Teams - EvolveDigital Summit](https://www.evolvedigital.com/evolve-digital-montreal-2025)**
  - Source: evolvedigital.com
  - *Aug 4, 2025 ... He has also appeared on the Talking Drupal podcast as a guest and ... Suzanne Dergacheva, Evolving Web‍. Suzanne is the co-founder of ...*

- **[DrupalCon Atlanta 2025](https://drupalcon-atlanta-2025.sessionize.com/speakers)**
  - Source: drupalcon-atlanta-2025.sessionize.com
  - *Drupal Trainer & Senior Backend Developer at Evolving Web · Dipak Yadav. Drupal ... Suzanne Dergacheva. Co-founder at Evolving Web · Ted Bowman. Princ...*

- **[What Marketers Really Want: Understanding the Needs of Drupal CMS](https://evolvingweb.com/blog/what-marketers-really-want-understanding-needs-drupal-cms)**
  - Source: evolvingweb.com
  - *Nov 29, 2024 ... ... interviews to dig ... About the author, Suzanne Dergacheva. Suzanne oversees Evolving Web's design, user experience, and developm...*

- **[Suzanne Dergacheva Seeks Volunteer Support for New Drupal Brand](https://www.thedroptimes.com/40153/suzanne-dergacheva-seeks-volunteer-support-new-drupal-brand)**
  - Source: thedroptimes.com
  - *May 16, 2024 ... Suzanne Dergacheva, Co-founder of Evolving Web, calls for volunteer support to promote the new Drupal brand presented at DrupalCon Po...*

---

*Generated by Founder Scraper*
