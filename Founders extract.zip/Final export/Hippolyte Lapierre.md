# Hippolyte Lapierre

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : BoundaryAI
**Durée dans le rôle** : 2 years 7 months in role
**Durée dans l'entreprise** : 2 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Transforming complex feedback into actionable insights.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACyR9bwBtWjlgnYh87EuSTVxSLzb5sctBu4/
**Connexions partagées** : 25


---

# Hippolyte Lapierre

## Position actuelle

**Entreprise** : BoundaryAI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Hippolyte Lapierre

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393988542122844161 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQHIHRTUxGLgFQ/mp4-720p-30fp-crf28/B4EZpyA2mFHMBw-/0/1762849447567?e=1765778400&v=beta&t=a7zHDyUmQROHmaQXTmNSB3kmoEZjmNcDLUGfwfeezaY | https://media.licdn.com/dms/image/v2/D4E05AQHIHRTUxGLgFQ/videocover-low/B4EZpyA2mFHMCE-/0/1762849432776?e=1765778400&v=beta&t=pjNuRBoIIc0muRIFqlkNEx905jIXLN1qwkLLEXroC98 | Happy to share the public release of BoundaryAI. The platform automatically ingests feedback from all sources, analyzes thousands of complex comments, and delivers insights enriched with demographics, profiles, and behaviors. | 93 | 18 | 8 | 3w | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:15.166Z |  | 2025-11-11T12:30:42.106Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7378340876818817024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFy-B5KwzIsFQ/feedshare-shrink_800/B4EZmUh403HcAg-/0/1759133546208?e=1766620800&v=beta&t=jaLRNqfh50WFU26mdBb9MOYpRo5e4S50fwcUfkinmys | Last week, BoundaryAI deployed our platform at ALL IN 2025, Canada’s largest AI conference.

With over 6,000 leaders, experts, researchers and innovators from nearly 40 countries in attendance, ALL IN was a massive success and a true showcase of Canada’s leadership in AI. Congratulations to the entire ALL IN team on this achievement.

At events this size, it’s not enough to collect a few scores or multiple-choice surveys. Organizers need to know what people actually said, across thousands of voices, and how different groups experienced the event. That’s what BoundaryAI delivered.

We are proud to see BoundaryAI supporting world-class events.

Thank you Guillaume Lavoie, M. Sc. and Isabelle Turcotte for the collaboration. | 62 | 3 | 4 | 2mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:15.169Z |  | 2025-09-29T08:12:27.978Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7351695218099773441 | Text |  |  | We are currently interviewing for backend and frontend devs (Python / React) - paid ofc.

The role is in person in downtown Montreal, part-time or full-time (preferred). Current students accepted. 

We're happy to start ASAP, but the first week of September is the latest start date. Just fill in this link through our beautiful in-house platform: https://lnkd.in/ezfMWiGj

DM/e-mail me if you have recommendations. More info about BoundaryAI: www.boundary-ai.com | 40 | 4 | 2 | 4mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:17.917Z |  | 2025-07-17T19:32:07.887Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7339173439578034176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHFBIvUC_1qvQ/feedshare-shrink_800/B4EZdmlpuVGcA0-/0/1749772839454?e=1766620800&v=beta&t=VqtgvSdf84Hny-xaPBHC40SsOD3l6jnfgwGQeqbbxlA | Over the last few days, BoundaryAI was in London for the London Tech Week as part of the McGill Dobson Centre for Entrepreneurship International Fundraising Tour. 

We had the chance to pitch at King's College London, showcase our solution at the Québec Government Office in London and engage with key players at the London AI Hub with London & Partners

We now arrived in Paris for VivaTech - if you are around, DM me to come meet us at the Canadian booth / Québec Tech !

Eric Saikali Gustave Lapierre

Huge thanks Kika (Karolina) Armata Marianne Khalil Line Rivard Jean de Fougerolles Rémy Rouillard, PhD Isabelle Botfield McGill University - Desautels Faculty of Management Investissement Québec High Commission of Canada in the United Kingdom | Haut–commissariat du Canada au Royaume–Uni | 72 | 9 | 4 | 5mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:17.923Z |  | 2025-06-13T06:15:03.244Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7335708669453496321 | Document |  |  | BoundaryAI will be at London Tech Week and VivaTech next week. My DM’s are open if you are around London / Paris and down to meet | 28 | 2 | 2 | 6mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:17.931Z |  | 2025-06-03T16:47:17.674Z | https://www.linkedin.com/feed/update/urn:li:activity:7335693002763374594/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7332680657262858240 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvrTAPnJngcQ/feedshare-shrink_1280/B4EZcKXsTCH0Ak-/0/1748225672878?e=1766620800&v=beta&t=DWHC5vhn_taDoweEJP1dVR5lvBcChXzA8tzVIS6g0GY | This post is way overdue, so here’s a full brain dump of what we’ve been up to, what’s real now, and what’s coming next.

We launched the BoundaryAI platform in January and we’ve been relentlessly improving it ever since. We help organizations deeply understand the experiences they deliver, at scale. From collecting feedback, to analyzing it, to turning insights into action.

People are using it, paying for it, and guiding us. Customers include RBC GranFondo, EPFL, HEC Montréal, École nationale de théâtre du Canada / National Theatre School of Canada, consulting firms, hockey teams...

What they have in common: their core value is creating high-quality human experiences. It’s very much not a KPI, it’s their point. And what we’re building is a massive accelerator for that mission.

The support from the ecosystem has been incredible:
- We just wrapped the McGill Dobson Centre for Entrepreneurship Bootcamp and are joining the McGill X-1 Accelerator this summer as we reach a new stage
- La base entrepreneuriale HEC Montréal has been with us from the start, the support has been real and personal
- We’ve signed a research partnership with a major Swiss institution (more on that soon)
and much much more...

And ofc our big(est) news - Kyle Devin Martel just joined us full-time in Montreal. He’s already impacting sales + marketing

We’ll be at Web Summit in Vancouver, VivaTech Paris, London Tech Week, Startupfest at home. If you’re around, let’s drink some coffee :) | 58 | 3 | 3 | 6mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:22.620Z |  | 2025-05-26T08:15:03.310Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7331375105396137985 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF6QVQGm_ig6w/feedshare-shrink_800/B4EZb4oXpxHIAg-/0/1747928055001?e=1766620800&v=beta&t=K4ML2DnyXwMDIYSAbW2fOySBMGiFeFbOWPtSOD0y6iQ | BoundaryAI will be at Web Summit in Vancouver with La base entrepreneuriale HEC Montréal next week 👀 If you’re around and up for a chat, let’s grab a coffee! | 20 | 2 | 1 | 6mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:22.621Z |  | 2025-05-22T17:47:15.489Z | https://www.linkedin.com/feed/update/urn:li:activity:7331348148361052160/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7318278467274354688 | Article |  |  | Gustave Lapierre, open www.epfl.ch I think you are on the front page with BoundaryAI 😎 | 34 | 0 | 2 | 7mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:22.621Z |  | 2025-04-16T14:25:53.637Z | https://go.epfl.ch/Zxy-en |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7273464194530758657 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGT_3F5F8TNjQ/feedshare-shrink_800/B56ZPCIlXeGsAg-/0/1734128851185?e=1766620800&v=beta&t=p1EFH16PdRkwcNdJeD2qEvjB8EbO1roNlrTUAJrhZb8 | Proud to see BoundaryAI represented at EPFL Investor Day! | 20 | 0 | 0 | 11mo | Post | Hippolyte Lapierre | https://www.linkedin.com/in/hippolytelapierre | https://linkedin.com/in/hippolytelapierre | 2025-12-08T05:03:22.625Z |  | 2024-12-13T22:29:58.406Z | https://www.linkedin.com/feed/update/urn:li:activity:7273463580740481024/ |  | 

---



---

# Hippolyte Lapierre
*BoundaryAI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [BoundaryAi | The Org](https://theorg.com/org/boundaryai)
*2025-01-01*
- Category: article

### [Podcast - Boundaryless](https://www.boundaryless.io/resources/podcast/)
*2025-05-13*
- Category: podcast

### [The lessons every founder can learn from Stephany Lapierre’s journey to building a multi-million dollar supply chain company - Communitech](https://www.communitech.ca/technews/the-lessons-every-founder-can-learn-from-stephany-lapierres-journey-to-building-a-multi-million-dollar-supply-chain-company.html)
*2025-03-25*
- Category: article

### [Boundary (YC W23) is leveling up your prompt management 💡](https://cerebralvalley.ai/blog/boundary-yc-w23-is-leveling-up-your-prompt-management-4CvhPHF4LAvlKq3t3XIZHH)
*2024-06-17*
- Category: blog

### [Building Foundational Models to Generate Actions: Our Partnership with the H company](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company)
*2024-05-21*
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 19,052 words total*

### BoundaryAi | The Org
*338 words* | Source: **EXA** | [Link](https://theorg.com/org/boundaryai)

BoundaryAi | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

This is an unverified company page

![Image 1: BoundaryAi logo](https://cdn.theorg.com/7375afaf-7dfd-4ea0-b9da-79414746e424_thumb.jpg)

BoundaryAi
==========

[3 people](https://theorg.com/people/search)·[0 jobs](https://theorg.com/jobs)

Follow

Wholistic feedback analysis for data-driven growth. We are developing an all-in-one solution for collecting, analyzing and tracking qualitative feedback. Focused on human feedback within organizations, our solution targets academic and HR sectors. Concretely, we provide: - User-friendly platform... Read more

Industries

[Data,](https://theorg.com/explore/industries/data)[Education](https://theorg.com/explore/industries/education)+2

Headquarters

[Montréal, Canada](https://theorg.com/explore/countries/canada)

Employees

[1-10](https://theorg.com/explore/employee-ranges/1-10)

Links

[](https://linkedin.com/company/boundary-ai "View on linkedIn")[](https://www.boundary-ai.com/ "View the website")

Org chart

Teams

Offices

* * *

Org chart
---------

Full screen

[![Image 2: Hippolyte Lapierre's profile picture](https://cdn.theorg.com/69a2ce37-f344-4d1a-892d-65b665d996db_thumb.jpg)](https://theorg.com/org/boundaryai/org-chart/hippolyte-lapierre "View Hippolyte Lapierre on The Org")

[Hippolyte Lapierre](https://theorg.com/org/boundaryai/org-chart/hippolyte-lapierre "View Hippolyte Lapierre on The Org")

Co-founder & CEO

0

![Image 3: Hippolyte Lapierre's profile picture](https://cdn.theorg.com/69a2ce37-f344-4d1a-892d-65b665d996db_thumb.jpg)

Hippolyte Lapierre

Collapse

No reports!

* * *

Teams
-----

View all (0)

This company has no teams yet

* * *

Offices
-------

View all (1)

*   [HQ 2 people · 0 jobs ![Image 4: Hippolyte Lapierre's profile picture](https://cdn.theorg.com/69a2ce37-f344-4d1a-892d-65b665d996db_thumb.jpg) ![Image 5: Victor Keroulle's profile picture](https://cdn.theorg.com/4940af44-da61-4bf1-9a6d-95d84fe4b2bc_thumb.jpg) Use ⌘ + scroll to zoom the map Use two fingers to move the map HQ](https://theorg.com/org/boundaryai/offices/hq)

Similar companies
-----------------

[![Image 6: Liberty University logo](https://cdn.theorg.com/84bbc1b9-101f-4c7a-be6a-3722847188ee_thumb.jpg) Liberty University 7 followers](https://theorg.com/org/liberty-university)[![Image 7: TroopHR logo](https://cdn.theorg.com/28e6a315-8fb6-47de-a0cf-3bec82f8e413_thumb.jpg) TroopHR 2 followers](https://theorg.com/org/troophr)[![Image 8: TriNet logo](https://cdn.theorg.com/9778816f-2c95-4c68-b5eb-e19dd40fa7e7_thumb.jpg) TriNet 39 followers](https://theorg.com/org/trinet)[![Image 9: QuellTX logo](https://cdn.theorg.com/2125a69b-5c55-4b62-a8c0-99f3989518a1_thumb.jpg) QuellTX 5 followers](https://theorg.com/org/quell-tx)[ADP 180 followers](https://theorg.com/org/adp)[Sequoia 46 followers](https://theorg.com/org/sequoia-com)[Apollo Global Management 54 followers](https://theorg.com/org/apollo)[The American University in Cairo 52 followers](https://theorg.com/org/the-american-university-in-cairo)[University of Melbourne 29 followers](https://theorg.com/org/university-of-melbourne)[Springside Chestnut Hill Academy 35 followers](https://theorg.com/org/springside-chestnut-hill-academy)[2U 22 followers](https://theorg.com/org/2u)[Explore companies](https://theorg.com/explore)

Transparency starts here

Join the world's biggest network of public org charts

[Sign up](https://theorg.com/signup)[Log in](https://theorg.com/login)

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

![Image 10: Cookiebot session tracker icon loaded](https://imgsct.cookiebot.com/1.gif?dgi=46b327ce-c3bf-4c3a-94d7-32411fa4e7b8)

---

### Podcast - Boundaryless
*1,158 words* | Source: **EXA** | [Link](https://www.boundaryless.io/resources/podcast/)

Podcast - Boundaryless

===============

[](https://www.boundaryless.io/)

[About Us](https://www.boundaryless.io/about-us/)

[Our Story](https://www.boundaryless.io/about-us/our-story/)[Team](https://www.boundaryless.io/about-us/team/)

[Our Approach](https://www.boundaryless.io/our-approach/)

[Platform Design](https://www.boundaryless.io/pdt-framework/)[Platform Organizations with the 3EO](https://www.boundaryless.io/3eo-framework/)

[Services](https://www.boundaryless.io/services/)

[Trainings](https://www.boundaryless.io/trainings/)[Consulting](https://www.boundaryless.io/consulting/)

[Trainings](https://www.boundaryless.io/trainings/)

[Toolkits](https://www.boundaryless.io/toolkits/)

[Platform Design Toolkit](https://www.boundaryless.io/pdt-toolkit)[Portfolio Map Canvas](https://www.boundaryless.io/portfolio-map-canvas/)[3EO Toolkit](https://www.boundaryless.io/3eo-toolkit/)

[Resources](https://www.boundaryless.io/resources/)

[Blog](https://www.boundaryless.io/resources/blog/)[Podcast](https://www.boundaryless.io/resources/podcast/)[Newsletter](https://www.boundaryless.io/newsletter_subscription_page/)[Curation on Telegram](https://t.me/BLSS_IO)[Videos](https://www.boundaryless.io/resources/videos/)[Whitepapers](https://www.boundaryless.io/resources/whitepapers/)[Events](https://www.boundaryless.io/events/)

[Contacts](https://www.boundaryless.io/contacts/)

☰

[![Image 1: title](https://app.boundaryless.io/app/uploads/2021/07/Boundaryless-Icon.svg)](https://www.boundaryless.io/)

[About Us](https://www.boundaryless.io/about-us/)

[Our Story](https://www.boundaryless.io/about-us/our-story/)[Team](https://www.boundaryless.io/about-us/team/)

[Our Approach](https://www.boundaryless.io/our-approach/)

[Platform Design](https://www.boundaryless.io/pdt-framework/)[Platform Organizations with the 3EO](https://www.boundaryless.io/3eo-framework/)

[Services](https://www.boundaryless.io/services/)

[Trainings](https://www.boundaryless.io/trainings/)[Consulting](https://www.boundaryless.io/consulting/)

[Trainings](https://www.boundaryless.io/trainings/)

[Toolkits](https://www.boundaryless.io/toolkits/)

[Platform Design Toolkit](https://www.boundaryless.io/pdt-toolkit)[Portfolio Map Canvas](https://www.boundaryless.io/portfolio-map-canvas/)[3EO Toolkit](https://www.boundaryless.io/3eo-toolkit/)

[Resources](https://www.boundaryless.io/resources/)

[Blog](https://www.boundaryless.io/resources/blog/)[Podcast](https://www.boundaryless.io/resources/podcast/)[Newsletter](https://www.boundaryless.io/newsletter_subscription_page/)[Curation on Telegram](https://t.me/BLSS_IO)[Videos](https://www.boundaryless.io/resources/videos/)[Whitepapers](https://www.boundaryless.io/resources/whitepapers/)[Events](https://www.boundaryless.io/events/)

[Contacts](https://www.boundaryless.io/contacts/)

*   [](https://www.boundaryless.io/resources/podcast/#Section_n_2)Latest Episode 
*   [](https://www.boundaryless.io/resources/podcast/#Section_n_4)Recent 
*   [](https://www.boundaryless.io/resources/podcast/#Section_n_6)All Episodes 

The Boundaryless Conversations Podcast
======================================

#### An ongoing exploration of the future of Platforms & Ecosystems

[![Image 2](https://app.boundaryless.io/app/uploads/2021/08/spotify-podcast-badge-blk-grn-165x40-1.png)](https://open.spotify.com/show/5TFF8qgtS1IKMxCEhh3yGU)[![Image 3](https://app.boundaryless.io/app/uploads/2021/10/EN_Google_Podcasts_Badge.png)](https://podcasts.google.com/feed/aHR0cHM6Ly9mZWVkLnBvZGJlYW4uY29tL2JvdW5kYXJ5bGVzcy9mZWVkLnhtbA)[![Image 4](https://app.boundaryless.io/app/uploads/2021/08/US_UK_Apple_Podcasts_Listen_Badge_RGB.png)](https://podcasts.apple.com/gb/podcast/boundaryless-conversations-podcast/id1505530552)[![Image 5](https://app.boundaryless.io/app/uploads/2023/10/youtube-button-1024x288.png)](https://www.youtube.com/playlist?list=PLirNL8YC77R94jbDHpt9K6yfNqLEq8_em)

![Image 6: title](https://app.boundaryless.io/app/uploads/2021/11/Bless-Sqaure-Soundcloud-Avatar-300x300.png)

Listen to The Latest Episode
============================

[![Image 7: title](https://app.boundaryless.io/app/uploads/2025/11/Lisa-Cover-1024x576.png) #129 – Why I Don’t Call it “Self-Management” Anymore – with Lisa Gill ===================================================================== Lisa Gill – a coach, facilitator, and host of the acclaimed Leadermorphosis podcast – joins us to explore the evolving world of self-managing organisations. Drawing on over a decade of experience and examples from companies like Buurtzorg... ![Image 8](https://app.boundaryless.io/app/uploads/2021/07/Profilo-centrato-150x150.png) Boundaryless Team ================= November 25, 2025](https://www.boundaryless.io/podcast/gill-lisa/)

[#129 – Why I Don’t Call it “Self-Management” Anymore – with Lisa Gill ===================================================================== Lisa Gill – a coach, facilitator, and host of the acclaimed Leadermorphosis podcast – joins us to explo

*[... truncated, 12,595 more characters]*

---

### The lessons every founder can learn from Stephany Lapierre’s journey to building a multi-million dollar supply chain company - Communitech
*1,029 words* | Source: **EXA** | [Link](https://www.communitech.ca/technews/the-lessons-every-founder-can-learn-from-stephany-lapierres-journey-to-building-a-multi-million-dollar-supply-chain-company.html)

The local tech community gathered Tuesday morning at [Catalyst Commons](https://catalyst-commons.com/private-offices/?gad_source=1&gclid=Cj0KCQjwqIm_BhDnARIsAKBYcmsW3f4-HsIAUmhCj7lsPG7CZh1nmF_vmHF-fg9EuyAvpLR29p2dIzsaAmrlEALw_wcB) in Kitchener for the latest Communitech Breakfast, held in celebration of International Women’s Month.

The event featured [Stephany Lapierre](https://www.linkedin.com/in/tealbook/), CEO of [TealBook](https://www.tealbook.com/), who shared her inspiring and often challenging journey.

“I’m definitely a born entrepreneur,” she said.

Lapierre comes from a long line of business owners. Her grandfather started a Pepsi franchise in Quebec and delivered bottles door-to-door. After he passed away, her grandmother took over the business while raising three children and staying active in the community.

“My dad took over the business and my mom has been an entrepreneur,” said Lapierre. “All my friends from high school, weirdly, are all entrepreneurs.”

Looking to earn her own living and take control of her career, Lapierre started her first company at 18. Later, inspired by working in the pharmaceutical industry, she noticed that suppliers often pitched “innovative” ideas, but most of them didn’t live up to the hype.

“I would say 98 per cent of the time, they were not that innovative,” she said.

She also saw firsthand that many companies didn’t have reliable data on their suppliers. That insight led her to launch [Matchbook](https://www.matchbookinc.com/) in 2006, a matchmaking service for companies looking to connect with suppliers.

“I started seeing these companies had no way of purchasing what was really efficient, so I pivoted to building procurement functions for these scaling companies, and that gave me a lens into information about suppliers,” she said. “It became so apparent how big this opportunity was.”

That opportunity eventually led her to launch and lead supply chain software startup TealBook Inc., which helps companies get better, more accurate information about the suppliers from which they buy products and services. Its platform uses artificial intelligence (AI) and machine learning to collect data from different sources and keep details about suppliers up-to-date.

Because of this, big companies have started using TealBook to track and report on their goals around things like sustainability and social responsibility, especially when it comes to how they choose and work with suppliers.

However, Lapierre said funding the company was a challenge from day one.

“My first investment, my husband gave me $50 thousand from his business to get started,” she said.

Later, a fellow mom she met at her daughter’s soccer game offered to invest $1 million after hearing about what she was building.

“She was a true angel. She’s one of my best friends now,” Lapierre said. “She made lots of money, so she’s very happy.”

But raising money from institutional investors wasn’t as easy.

“I had no idea how to raise capital,” she said.

Lapierre said she reached out to hundreds of people on LinkedIn and ended up meeting with about 200 investors. Most of them told her she was too early, too late, or didn’t have enough data.

“One investor was a tough guy,” she said. “He looked at me and said, who are you? You’re a woman, no offence, you’re French Canadian, you have this funny accent, you have three kids, you didn’t go to Stanford and you’re building a company?”

She said the investor went on to tell her that no one would give her money because she was “foreign” and “high-risk,” and asked her, “What happens if one of your kids gets sick? How are you going to give me confidence that if I give you five million, you’re going to give me 10 times that?”

“He actually put a mirror to my face on how investors were perceiving me,” said Lapierre. “I was asking for money because my company needed to grow. Investors don’t care about that. They want to give you money because the opportunity is so amazing.”

That conversation changed everything for Lapierre.

“The gift was that I needed to find what worked for me, and that was in confidence and changing the narrative,” she said. “It’s less about gender, and more about the risk profile.”

TealBook eventually completed six funding rounds and has secured a total of about [$73 million](https://www.tealbook.com/company/) to date, which included [a Series B round](https://www.tealbook.com/news/tealbook-raises-50-million-series-b-funding/) on Dec. 14, 2021 that raised $50 million. Lapierre has been named one of the Top 100 Most Influential Women in Supply Chain.

Even with all the success, Lapierre said the journey has been stressful, and that’s why she’s made wellness a priority.

“Mental health is really important for founders,” she said. “I workout every day. You’ve got to find time for yourself. You have to train yourself to be healthy.”

She also makes it a point to take two weeks off with her family every summer when she tries to disconnect.

“Not eating w

*[... truncated, 1,650 more characters]*

---

### Boundary (YC W23) is leveling up your prompt management 💡
*2,381 words* | Source: **EXA** | [Link](https://cerebralvalley.ai/blog/boundary-yc-w23-is-leveling-up-your-prompt-management-4CvhPHF4LAvlKq3t3XIZHH)

1.   [Cerebral Valley](https://cerebralvalley.ai/)

Plus: CEO Vaibhav on BAML, Boundary's programming language, and YC W23...
-------------------------------------------------------------------------

Published 18 Jun 2024

CV Deep Dive
------------

**Today, we’re talking with**[**Vaibhav Gupta**](https://www.linkedin.com/in/vaigup/)**, CEO and Co-Founder of**[**Boundary**](https://www.boundaryml.com/)**.**

**Boundary builds developer tooling for structured generation with LLMs. Their flagship product is**[BAML](https://www.github.com/boundaryml/baml)**, an open-source domain-specific language to build, test, and manage prompts.** Co-founded by Vaibhav and his co-founder[Aaron Villalpando](https://www.linkedin.com/in/aaron-villalpando-99284576/) during YC’s W23 batch, Boundary’s mission originated from a desire to reduce hallucinations and provide guarantees on the outputs generated by AI models. **BAML currently has compatibility with all major providers like OpenAI, Anthropic, Cohere, Gemini, and even local models**.

**Today, BAML is used by a range of AI-focused customers, from YC startups to mid-market enterprises and nonprofits, like MuckRock**, for example, which uses BAML for processing FOIA requests. Developers love BAML for its fast iteration speed, VSCode LLM playground, and native Python/Typescript/Ruby integrations, making it a valuable tool for those aiming to achieve high levels of assurance and efficiency in their AI workflows.

**In this conversation, Vaibhav takes us through the founding story of Boundary, the decision to make a new programming language, and their roadmap for the next 12 months**.

**Let’s dive in ⚡️**

**Read time: 8 mins**

* * *

Our Chat with Vaibhav 💬
------------------------

**_Vaibhav - welcome to Cerebral Valley! First off, give us a bit about your background and what led you to co-found Boundary?_**

**I came from working in industry for about the last ten years, focusing on computer vision and other AI problems.**Some notable projects I worked on include Face ID at Google, AR teams at Microsoft, and optimization work at D. E. Shaw. The most common challenge I saw with AI systems is that they are probabilistic in nature—they sometimes fail and sometimes succeed. Most people are used to software that responds in a very specific, expected, and consistent manner.

**With Boundary, our goal is to help developers have guarantees so probabilistic systems like LLMs behave like deterministic, reliable systems like banking or database software.**

**_Give us a top-level overview of BAML - how would you describe it to the uninitiated AI/ML developer or enterprise team?_**

**BAML helps you write your prompts as functions in BAML files, with expected input types that produce expected output types.**The main innovation is the idea of prompt engineering with data types, not just English.

![Image 1: BO10](https://images.ctfassets.net/6p5bhasaj8xa/6qMYaH437zuYk0Qy1xCofe/1f1cb58ab7a7286d910c6157131879fb/1.png)

BAML then provides you a type-safe function in the language of your choice (with autocomplete).

![Image 2: BO20](https://images.ctfassets.net/6p5bhasaj8xa/3OjMf9eRSE4xUHhiellQaF/5101ee1f1d570e67d283a65764ddf8f6/2.png)

BAML handles everything like parsing, error handling, streaming, and tracing for you. When you call an LLM, you not only get a response, but you can be sure that the response will be exactly what you want. For instance, if you're a company categorizing customer issues into one of 15 categories, BAML ensures the response will come in as a list of categories, **just like an API call to traditional software systems**.

**_Who are your users today? Who’s finding the most value in what you’re building with BAML?_**

**BAML is best for users building agents that need to talk to existing software, like your UIs and databases.** We have users in many domains, from companies working in healthcare, or analyzing SEC compliance of hedge funds, and some consumer AI chatbots.

**BAML changed the way all of our customers think about prompt engineering.** They no longer needs long paragraphs trying to explain to the LLM what they want. They define their types, BAML inserts a small type-snippet to the prompt, and parses the response. It just works.

**Take one of our customers Vetrec, for example, which does veterinarian transcript analysis.** Vets can be very picky about their notes, and not all of them use the same terminology for everything. On top of that, some vets want bullet point lists, while some want formatted lists in sentence format. Others prefer paragraph form. This leads to writing a multi-step LLM agent. The issue is each step depends on others – and if each step fails just 5% of the time, **a 10 step-pipeline fails 40% of the time**!

After switching to BAML, Vetrec simplified their pipeline to fewer steps, and delivered each vets’ customized requirements faster. Now, they offload the prompting to the vets, and use BAML to guarantee the structure 100% o

*[... truncated, 11,085 more characters]*

---

### Accel - News
*10,772 words* | Source: **EXA** | [Link](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company)

Accel - News

===============

[![Image 1](https://cdn.prod.website-files.com/6643a08d305ab77f8c7566b6/670819c9dc53f9c02fe60190_logo-accel.png)](https://accel.com/)

*   [Companies](https://accel.com/companies)
*   [Team](https://accel.com/team)
*   [News &Insights](https://accel.com/news)

[Explore](https://accel.com/explore)

- [x]  

*   [Companies](https://accel.com/companies)
*   [Team](https://accel.com/team)
*   [News &Insights](https://accel.com/news)
*   [Explore](https://accel.com/explore)

All

[All](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company#)[Portfolio News](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company#)[Insights](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company#)[Podcasts](https://accel.com/noteworthies/building-foundational-models-to-generate-actions-our-partnership-with-the-h-company#)

[Accel News Portfolio News Reports Insights PORTFOLIO NEWS ### Our Investment in n8n: The AI Platform for Automation Oct 09, 2025](https://accel.com/noteworthies/our-investment-in-n8n-the-ai-platform-for-automation)

[### Accel 2025 Globalscape: Race for compute Nov 12, 2025 ![Image 2](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/69140f952e0e6d375724d894_Homepage%20module.png)](https://www.accel.com/globalscape)

[Podcast ![Image 3](https://cdn.prod.website-files.com/6643a08d305ab77f8c7566b6/67ac69dc2f05489daf76745e_Accel_Spotlight_On_thumb_Dots_05_V01%20(1).jpg) ### A podcast about how companies are built, from the people doing the building. ### A podcast about how companies are built, from the people doing the building. Spotlight On](https://accel.com/spotlight-on)

[Accel News Portfolio News Reports Insights PORTFOLIO NEWS ### Supabase’s Series E: An Era-Defining Database Oct 03, 2025](https://accel.com/noteworthies/supabases-series-e-an-era-defining-database)

[Accel News Portfolio News Reports Insights PORTFOLIO NEWS ### ServiceNow + Veza: Identity Security’s Next Chapter Dec 2, 2025](https://accel.com/noteworthies/servicenow-veza-identity-securitys-next-chapter)

[### Accel 2025 Globalscape: Race for compute Nov 2025 ![Image 4](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/69140f952e0e6d375724d894_Homepage%20module.png)![Image 5](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/6913b3b5b136fe2a215cdaa9_Accel%20blog%20image%20(1).png)](https://accel.com/noteworthies/accel-2025-globalscape-race-for-compute)

[Podcast ![Image 6](https://cdn.prod.website-files.com/6643a08d305ab77f8c7566b6/67ac69dc2f05489daf76745e_Accel_Spotlight_On_thumb_Dots_05_V01%20(1).jpg) ### A podcast about how companies are built, from the people doing the building. ### A podcast about how companies are built, from the people doing the building. Spotlight On](https://accel.com/spotlight-on)

[Accel News Portfolio News Reports Insights PORTFOLIO NEWS ### Our Series D in Cursor: Pushing the Frontier of AI Forward Nov 13, 2025](https://accel.com/noteworthies/our-series-d-in-cursor-pushing-the-frontier-of-ai-forward)

[![Image 7](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/692f7a6d4e508b48557e4bd9_Final%20(10).png) Accel News Portfolio News Reports Insights Podcasts ### ServiceNow + Veza: Identity Security’s Next Chapter December 2, 2025](https://accel.com/noteworthies/servicenow-veza-identity-securitys-next-chapter)

[![Image 8](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/692f4a2baea7cc5869fbb0b2_PermitFlow.png) Accel News Portfolio News Reports Insights Podcasts ### Our Series B in PermitFlow: Breaking the Construction Bottleneck with AI December 2, 2025](https://accel.com/noteworthies/our-series-b-in-permitflow-breaking-the-construction-bottleneck-with-ai)

[![Image 9](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/692de727f4195b4e28cc4208_BLOG%20COVER.png) Accel News Portfolio News Reports Insights Podcasts ### Google Joins Accel to Turbocharge AI Founders with Atoms AI Cohort 2026 November 24, 2025](https://accel.com/noteworthies/google-joins-accel-to-turbocharge-ai-founders-with-atoms-ai-cohort-2026)

[![Image 10](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/691e3c32e63030e8b19cd6df_AJ%20Tennant%20Blogpost.jpg) Accel News Portfolio News Reports Insights Podcasts ### Welcome, AJ Tennant! November 20, 2025](https://accel.com/noteworthies/welcome-aj-tennant)

[![Image 11](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/6915f7170696fea6f22d1e07_Cursor%20Series%20D%20Blog%20Post.png) Accel News Portfolio News Reports Insights Podcasts ### Our Series D in Cursor: Pushing the Frontier of AI Forward November 13, 2025](https://accel.com/noteworthies/our-series-d-in-cursor-pushing-the-frontier-of-ai-forward)

[![Image 12](https://cdn.prod.website-files.com/6661f5618fe795fa8894d04f/6914e251ce95b2059f8b050b_Code%20Metal%20Final.p

*[... truncated, 173,563 more characters]*

---

### Lauréats - Québecor
*3,001 words* | Source: **GOOGLE** | [Link](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats)

*   Glissez
*   [2024](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2024)
*   [2023](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laur%C3%A9ats2023)
*   [2022](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#ancre2022)
*   [2021](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#ancre2021)
*   [2020](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#ancre2020)
*   [2019](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2019)
*   [2018](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2018)
*   [2017](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2017)
*   [2016](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2016)
*   [2015](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2015)
*   [2014](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats#laureats2014)

2024, #laureats2024

Les récipiendaires des Bourses Pierre-Péladeau
----------------------------------------------

2024
----

#### 1 er Prix – 75 000$

*   **Lauréats**
Simon-Pierre Deschênes, Dominic Baril et Pierre-Hugo Vigneux | Université Laval

*   **Projet**

_Tessellate Robotics_ allie brillamment robotique et technologie de navigation autonome afin d’accroître la productivité au sein de divers créneaux d’activité, telles les industries de l’agriculture, de la défense et des mines. Notamment, l’entreprise a développé une solution d’inspection automatisée des champs permettant aux agriculteurs de mieux cerner les besoins de leurs champs, d’en accroître le rendement et de progresser ainsi vers une agriculture plus durable et responsable.

#### 2 e Prix – 50 000 $

*   **Lauréats**

 Alexandre Savard et Nicolas Jourdan-Gassin | Université du Québec à Trois-Rivières

*   **Projet**

_Encore! Biomatériaux_ développe et commercialise des emballages 100 % compostables fabriqués à partir de rebuts agroalimentaires surcyclés. Ses solutions permettent aux entreprises de s’affranchir des pièces de plastique à usage unique et d’opter pour des emballages ayant un temps de décomposition adapté à leur durée de vie utile.

#### 3 e Prix – 35 000 $

*   **Lauréats**

 Fiona Milano et Maxime Dimidschstein | Polytechnique Montréal

*   **Projet**

_Phoenix Impact_ a pour mission de réduire les déchets plastiques découlant des activités de l’industrie des sciences de la vie de plus de 80 %. L’entreprise a ainsi conçu une laveuse industrielle innovante permettant de reconditionner les consommables de laboratoire en vue de les réutiliser plutôt que de les incinérer.

#### 4 e Prix – 25 000 $

*   **Lauréats**

 Julia Kolta et Dhandre Weekes | HEC Montréal

*   **Projet**

_Armonía_ commercialise une solution innovante pour l'industrie de la beauté et de la coiffure. Sa plateforme numérique, accessible aux clients, offre une manière simple et pratique d’identifier et de réserver des services personnalisés. En parallèle, son logiciel de gestion destiné aux entreprises permet à ces dernières d’atteindre une audience plus large tout en optimisant leurs activités. Une belle valeur ajoutée autant pour les PME que pour les consommateurs de ce secteur.

#### 5 e Prix – 15 000 $

*   **Lauréats**

 Hippolyte Lapierre, Madeleine Philardeau, Eric Saikali et Victor Keroulle | Université McGill

*   **Projet**

_BoundaryAi_ développe une plateforme mettant à profit l’intelligence artificielle pour accroître l'engagement et le bien-être des employés au sein d’une organisation et améliorer l'expérience éducative dans les milieux universitaires. La solution de l’entreprise vise à transformer la donnée provenant de rétroactions qualitatives en information décisionnelle, grâce à une gestion optimisée ainsi qu’une analyse de précision.

[Pour voir tous les lauréats](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats)

![Image 1](https://www.quebecor.com/documents/20143/50067/4A8A6037.jpg/afa8db85-0f75-efce-19de-a8d3b2d05d6e?t=1718296350023&thumb=img_16_9_672%202x)

2023, #lauréats2023

Les récipiendaires des Bourses Pierre-Péladeau
----------------------------------------------

2023
----

#### 1 er Prix – 75 000$

*   **Lauréats**
Félix Lapointe, Jonathan Audet et Étienne Boucher | Université Laval

*   **Projet**

**Ferreol Technologies** développe et commercialise de nouveaux matériaux ainsi que de nouvelles technologies plus performantes et plus écoresponsables pour le secteur manufacturier au Québec et à l'international. La première innovation de l’entreprise est un alliage d'aluminium qui, selon certains joueurs du secteur minier, serait actuellement le plus résistant au monde.

#### 2 e Prix – 50 000 $

*   **Lauréats**

 Kashif Khan et Karina Gasbarrino | Université McGill


*[... truncated, 17,539 more characters]*

---

### Hippolyte Lapierre - Co-founder & CEO at BoundaryAi | The Org
*373 words* | Source: **GOOGLE** | [Link](https://theorg.com/org/boundaryai/org-chart/hippolyte-lapierre)

Hippolyte Lapierre - Co-founder & CEO at BoundaryAi | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

*   [![Image 4: BoundaryAi logo](https://cdn.theorg.com/7375afaf-7dfd-4ea0-b9da-79414746e424_thumb.jpg) BoundaryAi](https://theorg.com/org/boundaryai)
*   Hippolyte Lapierre

Unverified

![Image 5: Hippolyte Lapierre's profile picture](https://cdn.theorg.com/69a2ce37-f344-4d1a-892d-65b665d996db_thumb.jpg)

Hippolyte Lapierre
==================

### Co-founder & CEO

Contact

Hippolyte Lapierre is the Co-Founder & CEO of BoundaryAi, a company that creates AI-driven solutions for businesses. Hippolyte has a background in entrepreneurship and innovation, with experience at various organizations such as McGill Entrepreneurship Society, Wirkn, and the European Space Agency. They have a Bachelor of Commerce degree in IT Management and a minor in Computer Science from McGill University, and have also participated in programs such as the EPFL Startup Launchpad and the Warwick Business School. Additionally, Hippolyte has a passion for technology and gaming, having founded and managed the TechScape YouTube channel.

Location

Montréal, Canada

Links

[](https://www.linkedin.com/in/hippolytelapierre "View on linkedIn")

Previous companies

[![Image 6: ManoMano logo](https://cdn.theorg.com/a2bd850e-ee67-4768-817a-ebff5a3212f5_thumb.jpg)](https://theorg.com/org/manomano "ManoMano")[![Image 7: Wirkn logo](https://cdn.theorg.com/30a6ffba-7144-4a70-9630-cf9efe9cf4a0_thumb.jpg)](https://theorg.com/org/wirkn "Wirkn")

* * *

Org chart
---------

![Image 8: Hippolyte Lapierre's profile picture](https://cdn.theorg.com/69a2ce37-f344-4d1a-892d-65b665d996db_thumb.jpg)

Hippolyte Lapierre

Co-founder & CEO

No direct reports

* * *

Teams
-----

This person is not in any teams

* * *

Offices
-------

Use ⌘ + scroll to zoom the map

Use two fingers to move the map

HQ

* * *

Related people
--------------

*   [![Image 9: David Connors' profile picture](https://cdn.theorg.com/44cdcc69-7d5b-4699-92c0-bfa95e32154d_thumb.jpg) ![Image 10: Company logo](https://cdn.theorg.com/1129c42d-dd0c-4a40-8814-0ff48b80bce4_thumb.jpg) ### David Connors The Swarm](https://theorg.com/org/the-swarm/org-chart/david-connors) 
*   [![Image 11: Michael Brizendine's profile picture](https://cdn.theorg.com/cb60a7c2-9de4-40cf-a6ad-322ebd81b46f_thumb.jpg) ![Image 12: Company logo](https://cdn.theorg.com/442b29e5-2e3e-4728-9e47-39cf1db3e2ec_thumb.jpg) ### Michael Brizendine Scoop](https://theorg.com/org/scoop-chat/org-chart/michael-brizendine) 
*   [![Image 13: Janusz Dutkowski's profile picture](https://cdn.theorg.com/ba350fd4-1394-4ea5-9fe2-afeafb2a0148_thumb.jpg) ![Image 14: Company logo](https://cdn.theorg.com/e2d0b375-00f1-40ee-9b5d-4fd5689fa639_thumb.jpg) ### Janusz Dutkowski Data4Cure](https://theorg.com/org/data4cure/org-chart/janusz-dutkowski) 
*   [![Image 15: Kota Kubo's profile picture](https://cdn.theorg.com/ef4c8682-57ae-493e-aeaa-a23c708f77ec_thumb.jpg) ![Image 16: Company logo](https://cdn.theorg.com/a76e9624-5eaf-4dae-9a8d-970e3b2ea517_thumb.jpg) ### Kota Kubo Ubie](https://theorg.com/org/ubie/org-chart/kota-kubo) 
*   [![Image 17: Tavo Zambrano's profile picture](https://cdn.theorg.com/1ca6c21f-2ab7-4b40-af84-73297a011468_thumb.jpg) ![Image 18: Company logo](https://cdn.theorg.com/5f80c19a-e561-49e6-b2b0-110e37f15ee9_thumb.jpg) ### Tavo Zambrano Skydropx](https://theorg.com/org/skydropx/org-chart/tavo-zambrano) 

View more

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

![Image 19: Cookiebot session tracker icon loaded](https://imgsct.cookiebot.com/1.gif?dgi=46b327ce-c3bf-4c3a-94d7-32411fa4e7b8)

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Lauréats - Québecor](https://www.quebecor.com/fr/engagement-social/bourses-pierre-peladeau/laureats)**
  - Source: quebecor.com
  - *5e Prix – 15 000 $. Lauréats Hippolyte Lapierre, Madeleine Philardeau, Eric Saikali et Victor Keroulle | Université McGill. Projet BoundaryAi développ...*

- **[Hippolyte Lapierre - Co-founder & CEO at BoundaryAi | The Org](https://theorg.com/org/boundaryai/org-chart/hippolyte-lapierre)**
  - Source: theorg.com
  - *Hippolyte Lapierre is the Co-Founder & CEO of BoundaryAi, a company that creates AI-driven solutions for businesses....*

---

*Generated by Founder Scraper*
