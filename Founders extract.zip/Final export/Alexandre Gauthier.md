# Alexandre Gauthier

## Position actuelle

**Titre** : Co-Founder & CRO
**Entreprise** : ClearEstate
**Durée dans le rôle** : 3 years 9 months in role
**Durée dans l'entreprise** : 5 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Financial Services

## Résumé

Co-Founder & Chief Revenue Officer at ClearEstate, a category-defining estate technology platform that transforms how people plan for and settle estates. Daytime passions include SaaS growth, technology, and solving entrepreneurial challenges. After-work passions include martial arts, good wine, and chasing my two toddlers around the house.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAIbS_gB3wYvOmYCsW1kYcpP7UJ6B49Io6k/
**Connexions partagées** : 140


---

# Alexandre Gauthier

## Position actuelle

**Entreprise** : ClearEstate

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Alexandre Gauthier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389008075879448577 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQE-n0NJGpbk_w/image-shrink_800/B4EZosHqx4HMAc-/0/1761676801147?e=1765774800&v=beta&t=YOIEyD8jexLuWuIAGPgrrvmtPWGd0KJKZbFXFzZgCKk | On the very day when ClearEstate was celebrating its 5th anniversary, I took the opportunity to go on a meditative hike near Chamonix-Mont Blanc, in France, and it reminded me of something powerful.

Standing on that summit at 2,439m (8,000 feet) altitude, you realize how every step—every decision—matters. The mountain doesn’t care how busy you are. It just asks: Are you prepared? Do you know where you’re going? Are you ready to weather the storm? Do you have a clear path?

At ClearEstate, we help families navigate one of the most challenging climbs in life—preparing your legacy and ensuring that settling your estate is not an impossible mountain to climb. Without a guide, it’s easy to lose your way.

Whether it’s helping a loved one’s legacy live on or building your own, we believe in being prepared—and in walking beside you every step of the way.

Let’s make legacy planning feel a little more human. And a little less daunting.

Let’s book some time if you’re a wealth advisor and you want to chat about estate planning: https://hubs.la/Q03QBHrf0

🧭 #EstatePlanning #LegacyMatters #MontBlancMoments #Wealth #Wealthadvisor #Canadianwealth #Planning #Wills #Clearestate | 65 | 2 | 1 | 1mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:41.954Z |  | 2025-10-28T18:40:06.421Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388945141920735232 | Article |  |  | As we reach our fifth anniversary, I was asked if I knew what I was getting into when I began filling out the spreadsheet that later became ClearEstate.

The answer was definitely yes, I knew what I was getting into. This service was absolutely necessary and needed to be scaled. 

For better or worse, I’m an optimist and I try to function as though there are no obstacles until proven otherwise. I’m not sure I can offer advice on how to turn a painful time in life, a parent’s estate settlement in my case, into a VC-backed financial institution, but for a certain type of entrepreneur who is comfortable taking big risks, the most transformative businesses solve consumer problems as well as market problems. I’ve spent much of my career in the VC world and so I see many complex market problems in the process of being solved by #fintech and inefficient systems being disrupted.

Being in a position to create this positive transformation from home in Montréal is even more rewarding. 

My full reflection on our milestone:
https://hubs.la/Q03QjLvy0 | 65 | 8 | 2 | 1mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:41.955Z |  | 2025-10-28T14:30:01.796Z | https://hubs.la/Q03QjLvy0 |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7371199332416638977 | Article |  |  | Dark statement warning: You survive your own death. 
Retirement planning is a given. Everyone does it.

But estate planning? That’s where most people stop short. And the decisions that you make, or omit to make, have a tremendous impact that is felt years, sometimes decades, after you pass.

Your financial plan shouldn’t end with your final paycheck. It should extend beyond your lifetime.
📌 Who receives what & when, and even why
📌 How taxes and debts are covered
📌 Who takes control if you no longer can

ClearEstate helps Canadians extend their financial strategy beyond their lifetime—efficiently, clearly, and powerfully.
In times of uncertainty, that’s not just smart.
It’s essential.

Visit our website to know the Complete Guide to Planning Your Estate in Ontario.

#RetirementAndBeyond #ClearEstate #EstateIntegration #LongGamePlanning #Wills | 9 | 0 | 0 | 2mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:41.955Z |  | 2025-09-09T15:14:31.109Z | https://hubs.la/Q03Hz1Ms0 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7345469945402601474 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHeYqmNCBg7EQ/image-shrink_800/B4EZfBZ.RtHwAc-/0/1751296501430?e=1765774800&v=beta&t=1FfgwvoDjXHUUEvatu3ZlHJwC67gO11nQBelAmkwYO0 | We've reached a proud moment in ClearEstate’s journey: we’ve entered a strategic agreement with Canada Life, one of Canada’s most trusted names in financial services.

This partnership allows Canada Life to refer clients and employees to ClearEstate, helping more families access digital-first, expert-supported estate planning and settlement services.

Estate planning is evolving—and through this collaboration, we’re embedding it directly into the wealth and benefits ecosystems that Canadians already rely on. Grateful to our partners at Canada Life for sharing our vision.

We’re just getting started.

Read the press release from Canada Life here: https://hubs.la/Q03vc7dv0
---------------------
Nous avons atteint un moment dont nous pouvons être fiers dans le parcours de ClearEstate : nous avons conclu une entente stratégique avec la Canada Vie, l’un des noms les plus respectés dans les services financiers au pays.

Ce partenariat permettra à la Canada Vie de référer ses clients et employés à ClearEstate, afin de leur offrir un accès simplifié à des services successoraux numériques, appuyés par des experts.

La planification successorale évolue — et grâce à cette collaboration, nous l’intégrons directement aux écosystèmes de patrimoine et d’avantages sociaux sur lesquels les Canadiens s’appuient déjà. Merci à nos partenaires de la Canada Vie pour leur confiance et leur vision partagée.

Et ce n’est que le début.

Lisez le communiqué de presse de la Canada Vie ici : https://hubs.la/Q03vccjG0

#Growth #EstatePlanning #Fintech #CanadaLife #ClearEstate
#Croissance #PlanificationSuccessorale #CanadaVie | 67 | 4 | 0 | 5mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:41.956Z |  | 2025-06-30T15:15:07.216Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7339348270755831808 | Article |  |  | We make business plans. Financial plans. Backup plans. Disaster Recovery plans. Event plans.
But most Canadians don’t have an estate plan.
That’s a very dangerous blind spot to have in times like these.

My Dad hadn’t planned for cancer to take him from us. 
Uncertainty doesn’t wait.
It doesn’t check your calendar.
And it certainly doesn’t give you time to react.

That’s why ClearEstate exists—to help you prepare before life forces your hand.
📌 Create a will that will make your wishes crystal clear.
📌 Assign power of attorney in case of incapacity.
📌 Set up asset transfer instructions that bypass probate, if aligned with your plan.
📌 Consolidate everything in one secure, accessible place for your loved ones and executor.
This isn’t about fear—it’s about responsibility.

 Your family deserves protection. Your estate deserves structure. Your legacy deserves clarity.
In a world full of unknowns, estate planning is the one thing you can control.

We’ll help you start. 
#WealthProtection #PlanForward #ClearEstate #NoMoreGuesswork #CrisisReady
#Clearestate #EstatePlanning #Family #Trust #WealthManagement #FinancialPlanning | 17 | 0 | 4 | 5mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:41.956Z |  | 2025-06-13T17:49:46.245Z | https://hubs.la/Q03s48x60 |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7324157415225008129 | Article |  |  | My Economy teacher in university asked this question on the first day of class:

“Two men jump out of a plane. One with a parachute, the other one without. Which one of them took the greatest risk?”
“The one with the parachute.” he’d say. “Without a parachute, death is guaranteed. There is no risk. But with the parachute, a million things can happen.”
This paradoxical question resonates with me more than ever. Tariffs. Recession threats. Bank failures. Global unrest.
We live in a time where the cost of inaction has never been higher. There is no inherent risk to leaving an unplanned estate. It’s GUARANTEED to be a nightmare! 

Far too many Canadians assume estate planning is something they’ll “get to eventually.”
Until one day, “eventually” is too late.
Here’s what happens without a plan:
 🚫 Loved ones are stuck in probate for months (or years)
 🚫 Estate taxes and fees eat away at your hard-earned wealth
 🚫 Family conflict arises over unclear wishes
 🚫 Assets are frozen, inaccessible, or misallocated

Here’s what happens with ClearEstate:
 ✅ A legally valid will that reflects your wishes
 ✅ A plan that protects your assets
 ✅ Expert guidance without legalese or hidden fees
 ✅ A clear, compassionate roadmap for your family

Wealth is earned over decades. It can disappear in weeks.
Don’t let the legacy you’ve built get caught in the chaos of global uncertainty, or inaction! 🤦🏻‍♂️

Let ClearEstate help you protect what matters most.

#WealthProtection #PlanForward #ClearEstate #NoMoreGuesswork #CrisisReady
#Clearestate #EstatePlanning #Family #Trust #WealthManagement #FinancialPlanning | 14 | 0 | 0 | 7mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:48.271Z |  | 2025-05-02T19:46:44.054Z | https://hubs.la/Q03kWJP-0 |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7315093509684817921 | Article |  |  | As a co-founder of ClearEstate, I’ve seen firsthand how the lack of estate planning can leave families vulnerable when financial markets shift. When businesses prepare for trade disruptions, they don’t wait for a crisis—they plan ahead. Canadians should do the same when it comes to their personal finances.

🔹 Do you know how economic shifts affect your estate?
🔹 Is your family prepared for financial instability?
🔹 Are you confident your wealth will stay in Canada for future generations?

At ClearEstate, we help Canadians take control of their estate planning—because financial preparedness isn’t just smart, it’s a responsibility. When Canadian families secure their wealth, they contribute to a stronger economy, protect local businesses, and preserve a legacy that stays in Canada.

💡 The best time to plan is before uncertainty strikes. Let’s work together to protect our families and our country’s financial future.
📩 Let’s talk about your estate plan.

#EstatePlanning #CanadianWealth #ClearEstate #EconomicResilience" | 26 | 0 | 3 | 8mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:48.272Z |  | 2025-04-07T19:30:00.574Z | https://hubs.la/Q03gggKt0 |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7311032862231674881 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQHWcOjbFJcd2g/image-shrink_800/B56ZVDNKQCGsAc-/0/1740589279288?e=1765774800&v=beta&t=3zgfp6n-e7WQFuf_uBO9ghmA26X7iqVfa4uxKtnyZis | Some of the best minds 🧠 in Estate Planning at ClearEstate are joining me at 1PM to discuss 7 typical cases/mistakes we see in estate planning and how to avoid it. Whether your will is recent, a few years old or (hem...😅) not done yet, I'm sure you'll learn a thing or two around Death & Taxes. 😇

There's still time to signup: https://ow.ly/jVYe50V5CzZ

In collaboration with our friends at IG Wealth Management. 🤝 | 14 | 0 | 1 | 8mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:48.273Z |  | 2025-03-27T14:34:26.778Z | https://www.linkedin.com/feed/update/urn:li:activity:7300560581332217856/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7292938158613155840 | Text |  |  | What do Frogs and Wills have in common?

As a startup co-founder and a father of two young children, I’m no stranger to packed schedules and the temptation to put off the less glamorous tasks. But an old mentor of mine once shared a piece of advice that has stuck with me: “Eat a live frog first.” 🐸
What he meant was simple—start your day (or year!) by tackling the hard, unpalatable tasks first. Once you’ve done that, everything else feels easier.

For many families, estate planning is the “live frog” on their to-do list. It’s not exactly the kind of thing we eagerly discuss over morning coffee, and it often gets pushed aside for “later.” But here’s the thing: later can be unpredictable.

As the saying goes: “the best time to make your will was yesterday. And the second-best time is right now.” February is now upon us and conveniently, it’s the third-best time to prioritize what really matters—your family, your peace of mind, and your legacy. Here’s why estate planning deserves to be one of your top resolutions this year:
1️⃣ Protect Your Loved Ones: No one plans for the unexpected, but having a solid estate plan ensures your family is cared for, no matter what.
2️⃣ Save Time and Stress: Estate planning today means avoiding confusion, legal battles, and heartache tomorrow.
3️⃣ Pass on More Than Wealth: It’s not just about money—it’s about leaving a legacy of values, memories, and clarity for those you care about.

As Co-founder at ClearEstate I’ve seen how a well-thought-out estate plan transforms families’ experiences during challenging times. And as a parent, I know the relief that comes with knowing my own family is protected.

So, as you set your goals for 2025, consider eating the frog first. Tackle estate planning head-on—and once it’s done, you’ll have the satisfaction of knowing you’ve set the stage for a brighter, more secure future.

What’s your “frog” for 2025? Let me know in the comments—I'd love to hear how you’re prioritizing this year!

#NewYearNewGoals #FebruaryGoals #EstatePlanning #FamilyFirst #Fintech #Leadership | 37 | 0 | 3 | 10mo | Post | Alexandre Gauthier | https://www.linkedin.com/in/alexigauthier | https://linkedin.com/in/alexigauthier | 2025-12-08T04:54:48.274Z |  | 2025-02-05T16:12:33.252Z |  |  | 

---



---

# Alexandre Gauthier
*ClearEstate*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Alexandre Gauthier is on a mission](https://www.clearestate.com/media/alex-gauthier)
*2021-06-16*
- Category: article

### [Gauthier: How My Obsession Sparked ClearEstate](https://www.clearestate.com/blog/gauthier-how-my-obsession-sparked-clearestate)
*2022-02-09*
- Category: blog

### [Alex Gauthier & expert panel on 11:FS Fintech Insider podcast](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast)
*2023-08-18*
- Category: podcast

### [Alexandre Gauthier - ClearEstate | LinkedIn](https://ca.linkedin.com/in/alexigauthier)
*2017-02-06*
- Category: article

### [Our Press Coverage | ClearEstate Technologies Inc.](https://www.clearestate.com/en-us/media)
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 13,907 words total*

### Alexandre Gauthier is on a mission
*852 words* | Source: **EXA** | [Link](https://www.clearestate.com/media/alex-gauthier)

Co-Founder Profile: CPO Alex Gauthier
-------------------------------------

The ClearEstate co-founder is a young but experienced Montréal-based technology product and marketing leader who, in 2019, decided that he would put the brakes on a promising career to help solve...
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Posted on June 16, 2021

![Image 1: Alex 1 b w 1200x630](https://www.clearestate.com/assets/s3/press/visual/_1200x630_crop_center-center_90_none/Alex-1-b_w-1200x630.webp)

Alexandre Gauthier is on a mission.

The ClearEstate co-founder is a young but experienced Montréal-based technology product and marketing leader who, in 2019, decided that he would put the brakes on a promising career to help solve an especially difficult problem. Parts of the estate settlement process, he learned first-hand, were not only obsolete but breeding injustice.

It was the excruciating process of settling his late mother’s estate that inspired Alexandre to outline the ClearEstate concept. He recalls the complexity of the process, and the amount of work involved in settling all North American estates, as being a total shock.

“It was more antiquated than I could ever have imagined,” recalled Gauthier, who noted he had to send faxes for the first time in his life. “I hadn't owned a cheque book since I was 20 but had to get one for managing the estate. We’d ask ourselves, ‘is this for real?’”

On average, an estate can take 16 months to settle. It is also a significant financial burden for the estate, in addition to the burden of managing anxiety while grieving a loss.

### PURPOSE-DRIVEN PLATFORMS

Gauthier comes to the table with deep experience at prominent Canadian tech firms like Acquisio and Amilia. As to the latter, the popular and sophisticated online membership hub was his final stop before ClearEstate and a formative experience that helped prepare him for the demands of building a useful Software as a Service (SaaS) platform from the ground-up.

“My days are a little crazy,” he mused, as the co-founder wears many hats, including Head of Product and Marketing. “We’re all committed to the same goal: a next-generation service for estate execution, so that we can stop inflicting frustrating paperwork on families in mourning.”

Gauthier joined Amilia as VP of Marketing in 2014 and was soon promoted to CMO and eventually COO. Over six years, he helped increase revenue tenfold with $10M in recurring revenue by the end of his tenure.

“I’m proud to have helped the effort to grow the business from 17 to 110 employees, and raised over $12M in private capital through that period.”

Amilia, and the challenge of building a platform for community-driven businesses (groups like soccer leagues and summer camps that manage activities requiring multi-level scheduling), brought out the manager in Gauthier, a skilled entrepreneur and marketer in his own right.

“I think my superpower, so to speak, has always been my ability to kind of speak everyone's language,” he said. As a student, Alexandre was a successful franchise owner in Quebec’s well-known Qualité Étudiants network, the province’s leading student-owned residential painting operation. He believes in marketing from the ground-up, and prides himself on being comfortable “speaking with developers, the CEO, clients, and the marketing team... If two people are not understanding each other, it’s often because there is no cohesive vision. I’ve enjoyed working with CEOs who think big and always look to the future.”

Gauthier truly loved his time with Amilia and even felt a sense of ownership, but only after losing his mother did he understand his true purpose.

“There is a product that needs to be built. And it needs to be built because it doesn't exist yet. It became the driving force. My mother's real final gift was providing me this vision and this path forward to creating something that was meaningful.”

LIGHTING THE WAY
----------------

He describes the “craziness” of ClearEstate’s rapid development and trying to keep up with the needs of a company that is rapidly scaling each week. He jokingly refers to himself as the “Chief Executive of Everything”.

“If it's successful, and clients are happy with the services that we deliver, then I’m happy. And it's humbling, because we kind of figured it out very early on: what are the pain points? And we know them. I’ve been there, and when I see a family struggling, it's easy for me to relate.”

While estate planning in advance can mitigate cost, conflict and confusion in times of crisis, the probate process is far and away the most complex problem in the process to solve. Reforming the centuries-old system calls for concrete leadership, and Alexandre is confident ClearEstate will help spur these reforms in government and financial institutions across North America.

“We're a

*[... truncated, 591 more characters]*

---

### Gauthier: How My Obsession Sparked ClearEstate
*1,106 words* | Source: **EXA** | [Link](https://www.clearestate.com/blog/gauthier-how-my-obsession-sparked-clearestate)

*   [Search](https://www.clearestate.com/en-us/search)
*   [Contact Us](https://www.clearestate.com/en-us/contact-us)
*    U.S. (English) 

    *   [U.S. (English)](https://www.clearestate.com/en-us/blog/gauthier-how-my-obsession-sparked-clearestate?__geom=%E2%9C%AA)
    *   [Canada (English)](https://www.clearestate.com/blog/gauthier-how-my-obsession-sparked-clearestate?__geom=%E2%9C%AA)
    *   [Canada (Français)](https://www.clearestate.com/fr-ca/?__geom=%E2%9C%AA)
    *   [Quebec (English)](https://www.clearestate.com/en-qc/?__geom=%E2%9C%AA)
    *   [Québec (Français)](https://www.clearestate.com/fr-qc/?__geom=%E2%9C%AA)

*   [Login](https://app.clearestate.com/login)

Co-founder Alexandre Gauthier explains the roots of his original ClearEstate mind map

![Image 1: Co founder Alexandre Gauthier explains the roots of his original Clear Estate mind map](https://www.clearestate.com/assets/s3/blog/_24xAUTO_fit_center-center_none/Co-founder-Alexandre-Gauthier-explains-the-roots-of-his-original-ClearEstate-mind-map.webp)

We are shaped by our experiences, for better or worse. When I lost my mother in 2019, it was a very difficult time made exponentially more frustrating by [the red tape](https://www.clearestate.com/blog/the-surprising-red-tape-at-the-end-of-life) of estate settlement.

But it also inspired me to find a better way. No one should have to deal with an administrative process that complex, especially in times of grief. The mourning is difficult enough on its own. How has this process not been automated at all, I asked myself.

Then, an epiphany. It was one of those lightbulb moments, a flash of inspiration that broke through during what was a very dark time: what’s missing is a clear estate settlement solution.

All over internet message boards, I found people asking questions like, “where can I find clear probate instructions,” because there is a strong sense among those who’ve experienced an estate settlement that the system is profoundly unfair and outdated.

Our new polling research from Maru Public Affairs confirms much of what I learned in those first few days mapping out ClearEstate: the vast majority of people who have been named estate executor (74%) describe the experience as among the most difficult tasks of their entire lives, and one that results in significant disruptions for work and home life.

On a Mission
------------

The first step was to make sense of the maelstrom of information. In the hours after that initial shock of losing a parent, I was given a 66-page manual provided by the Quebec government (in retrospect, I am somewhat thankful for that since many executors in North America aren’t even provided a guide book by some governments).

I quickly realized that this wasn’t a checklist — which is what it should have been. It was a seemingly endless list of tasks with little direction.

For instance, for the first time in over a decade, I had to send faxes.

I had to get a checkbook (can you remember the last time you had to write a check?). I hadn’t kept one since my early 20s but now I needed one for managing the estate. I thought to myself at the time, “is this for real?”

I’ve often said it felt like an IRS audit that lasted for 18 months. This was only made worse by the feeling of mistrust at every step of the process. You’re constantly dealing with government or bank employees who are not specialized in these tasks and unaware of the process.

It’s the small indignities that felt painful at the time. I remember going to the bank and asking to open an estate account. The teller looked at me like I was an alien. This lack of competency leads to mistakes, which eats up more time. It’s frustrating, emotionally exhausting and, frankly, [unacceptable in the age of fintech and e-signatures](https://www.clearestate.com/blog/why-e-signatures-are-safer-and-legal-almost-everywhere), which as we’ve written recently have been widely accepted for over one decade now!

There had to be a better way. So I got to work on a visual representation of my “decision tree”; a sort of optimized checklist of sets of tasks, or a mind map, that would become ClearEstate.

Time is Precious
----------------

For fans of the sitcom It's Always Sunny in Philadelphia or any admirer of the .gif format, my first draft felt like a digital version of Charlie’s conspiracy board. There was a lot to uncover.

> Just saw the episode of It’s Always Sunny where Charlie uncovers the company conspiracy and this gif is so much better now that I know the context [pic.twitter.com/QpDrJX1f6y](https://t.co/QpDrJX1f6y)
> 
> — Claire Meyer (@clairemeyer_) [January 18, 2022](https://twitter.com/clairemeyer_/status/1483271472059723779?ref_src=twsrc%5Etfw)

The main cause of all the unnecessary red tape: redundancy, and having to send, resend and send some more documents and forms to various government agencies that should be in communication with each other. It is a huge inefficiency that is made even more complicated the mo

*[... truncated, 2,858 more characters]*

---

### Alex Gauthier & expert panel on 11:FS Fintech Insider podcast
*418 words* | Source: **EXA** | [Link](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast)

Alex Gauthier & expert panel on 11:FS Fintech Insider podcast

===============

Access our free probate checklist. [Instantly access now](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast#)

Settle an estate, without the guesswork.

Join the 100,000+ executors that have settled an estate **sooner** - using our step-by-step probate checklist

*   [Search](https://www.clearestate.com/en-us/search)
*   [Contact Us](https://www.clearestate.com/en-us/contact-us)
*    U.S. (English) 

    *   [U.S. (English)](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast?__geom=%E2%9C%AA)
    *   [Canada (English)](https://www.clearestate.com/media/alex-gauthier-11-fs-fintech-insider-podcast?__geom=%E2%9C%AA)
    *   [Canada (Français)](https://www.clearestate.com/fr-ca/?__geom=%E2%9C%AA)
    *   [Quebec (English)](https://www.clearestate.com/en-qc/?__geom=%E2%9C%AA)
    *   [Québec (Français)](https://www.clearestate.com/fr-qc/?__geom=%E2%9C%AA)

*   [Login](https://app.clearestate.com/login)

[](https://www.clearestate.com/en-us/)

[Talk to a specialist now](https://info.clearestate.com/en-us/book-a-free-us-main)

*    Settle an estate

    *   [Estate Settlement Services](https://www.clearestate.com/en-us/estate-settlement-solutions)
    *   [Professional Estate Representative](https://www.clearestate.com/en-us/estate-representative)

*   [Pricing](https://www.clearestate.com/en-us/pricing)
*    Learn

    *   [Blog](https://www.clearestate.com/en-us/blog)
    *   [Resources](https://www.clearestate.com/en-us/resources)
    *   [Calculators](https://www.clearestate.com/en-us/resources/calculators)

*    Company

    *   [About us](https://www.clearestate.com/en-us/about-clear-estate)
    *   [Careers](https://www.clearestate.com/en-us/careers)
    *   [Investors](https://www.clearestate.com/investors)
    *   [Media](https://www.clearestate.com/en-us/media)

*   [Contact Us](https://www.clearestate.com/en-us/contact-us)
*   [Search](https://www.clearestate.com/en-us/search)
*    U.S. (English) 

    *   [U.S. (English)](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast?__geom=%E2%9C%AA)
    *   [Canada (English)](https://www.clearestate.com/media/alex-gauthier-11-fs-fintech-insider-podcast?__geom=%E2%9C%AA)
    *   [Canada (Français)](https://www.clearestate.com/fr-ca/?__geom=%E2%9C%AA)
    *   [Quebec (English)](https://www.clearestate.com/en-qc/?__geom=%E2%9C%AA)
    *   [Québec (Français)](https://www.clearestate.com/fr-qc/?__geom=%E2%9C%AA)

*   [Login](https://app.clearestate.com/login)
*   [Talk to a specialist now](https://info.clearestate.com/en-us/book-a-free-us-main)

Access our free probate checklist. [Instantly access now](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast#)

Settle an estate, without the guesswork.

Join the 100,000+ executors that have settled an estate **sooner** - using our step-by-step probate checklist

[Our Press Coverage](https://www.clearestate.com/en-us/media)

CRO Alex Gauthier joins expert panel on 11:FS Fintech Insider podcast
=====================================================================

ClearEstate's Alex Gauthier joins a panel of experts to discuss current challenges and what the future looks like for fintech services catering to older generations on 11:FS Fintech Insider podcast.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 Posted on August 18, 2023

![Image 2: Adobe Stock 131421740 c 1](https://www.clearestate.com/assets/s3/press/visual/_1200x630_crop_center-center_90_none/AdobeStock_131421740-c-_1.webp)

In the recent fintech revolution, while millennials and Gen Z have seen expansive banking options, are those over 60 being adequately catered to? Or has the fintech revolution ignored them? Co-founder and CRO Alex Gauthier joins a panel of experts on the 11:FS Fintech Insider podcast to explore the current market options for seniors, challenges they face, and the future of finance for this age group.

Listen [here](https://content.11fs.com/podcasts/772-insights-has-the-fintech-revolution-ignored-older-customers).

Media inquiries: media@clearestate.com

*   [![Image 3: Share this article on facebook](https://www.clearestate.com/assets/img/icons/share/facebook.svg)](https://www.facebook.com/sharer/sharer.php?u=https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast)
*   [![Image 4: Share this article on twitter](https://www.clearestate.com/assets/img/icons/share/twitter.svg)](https://twitter.com/share?url=https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast)
*   [![Image 5: Share this article by email](https://www.clearestate.com/assets/img/icons/share/email.svg)](mailto:?subject=Read%20this%20article%20and%20tell%20me%20what

*[... truncated, 2,002 more characters]*

---

### Alexandre Gauthier - ClearEstate | LinkedIn
*8,062 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/alexigauthier)

Alexandre Gauthier - ClearEstate | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/alexigauthier#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-jackson-tn?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Falexigauthier&fromSignIn=true&trk=public_profile_nav-header-signin)[Join for free](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=alexigauthier&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Falexigauthier&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Falexigauthier&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/C4D16AQEgm248uzGnBQ/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1611524467893?e=2147483647&v=beta&t=ax3xCYtPa-DOScINfpJf3SLBmCPTFc92BPPmko2O8x0)

![Image 3: Alexandre Gauthier](https://media.licdn.com/dms/image/v2/C4E03AQHXYo4Dd0gYbg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1607450632291?e=2147483647&v=beta&t=qLPN9Hx1p-zVKQ_zfxkwzkwzKSl-h8ITdIzvdpKnGvU)

![Image 4](https://media.licdn.com/dms/image/v2/C4E03AQHXYo4Dd0gYbg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1607450632291?e=2147483647&v=beta&t=qLPN9Hx1p-zVKQ_zfxkwzkwzKSl-h8ITdIzvdpKnGvU)
Sign in to view Alexandre’s full profile
----------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=alexigauthier&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=alexigauthier&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Alexandre Gauthier
==================

![Image 5](https://media.licdn.com/dms/image/v2/C4E03AQHXYo4Dd0gYbg/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1607450632291?e=2147483647&v=beta&t=qLPN9Hx1p-zVKQ_zfxkwzkwzKSl-h8ITdIzvdpKnGvU)
Sign in to view Alexandre’s full profile
----------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=alexigauthier&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_joi

*[... truncated, 78,484 more characters]*

---

### Our Press Coverage | ClearEstate Technologies Inc.
*451 words* | Source: **EXA** | [Link](https://www.clearestate.com/en-us/media)

Access our free probate checklist. [Instantly access now](https://www.clearestate.com/en-us/media#)

*   [Search](https://www.clearestate.com/en-us/search)
*   [Contact Us](https://www.clearestate.com/en-us/contact-us)
*    U.S. (English) 

    *   [U.S. (English)](https://www.clearestate.com/en-us/media?__geom=%E2%9C%AA)
    *   [Canada (English)](https://www.clearestate.com/media?__geom=%E2%9C%AA)
    *   [Canada (Français)](https://www.clearestate.com/fr-ca/media?__geom=%E2%9C%AA)
    *   [Quebec (English)](https://www.clearestate.com/en-qc/?__geom=%E2%9C%AA)
    *   [Québec (Français)](https://www.clearestate.com/fr-qc/?__geom=%E2%9C%AA)

*   [Login](https://app.clearestate.com/login)

[Talk to a specialist now](https://info.clearestate.com/en-us/book-a-free-us-main)

*    Settle an estate

    *   [Estate Settlement Services](https://www.clearestate.com/en-us/estate-settlement-solutions)
    *   [Professional Estate Representative](https://www.clearestate.com/en-us/estate-representative)

*   [Pricing](https://www.clearestate.com/en-us/pricing)
*    Learn

    *   [Blog](https://www.clearestate.com/en-us/blog)
    *   [Resources](https://www.clearestate.com/en-us/resources)
    *   [Calculators](https://www.clearestate.com/en-us/resources/calculators)

*    Company

    *   [About us](https://www.clearestate.com/en-us/about-clear-estate)
    *   [Careers](https://www.clearestate.com/en-us/careers)
    *   [Investors](https://www.clearestate.com/investors)
    *   [Media](https://www.clearestate.com/en-us/media)

*   [Contact Us](https://www.clearestate.com/en-us/contact-us)
*   [Search](https://www.clearestate.com/en-us/search)
*    U.S. (English) 

    *   [U.S. (English)](https://www.clearestate.com/en-us/media?__geom=%E2%9C%AA)
    *   [Canada (English)](https://www.clearestate.com/media?__geom=%E2%9C%AA)
    *   [Canada (Français)](https://www.clearestate.com/fr-ca/media?__geom=%E2%9C%AA)
    *   [Quebec (English)](https://www.clearestate.com/en-qc/?__geom=%E2%9C%AA)
    *   [Québec (Français)](https://www.clearestate.com/fr-qc/?__geom=%E2%9C%AA)

*   [Login](https://app.clearestate.com/login)
*   [Talk to a specialist now](https://info.clearestate.com/en-us/book-a-free-us-main)

Access our free probate checklist. [Instantly access now](https://www.clearestate.com/en-us/media#)

The latest from ClearEstate

In the Media
------------

[![Image 1: Adobe Stock 131421740 c 1 width=](https://www.clearestate.com/assets/s3/press/visual/_800x420_crop_center-center_85_none/AdobeStock_131421740-c-_1.webp) CRO Alex Gauthier joins expert panel on 11:FS Fintech Insider podcast --------------------------------------------------------------------- ClearEstate's Alex Gauthier joins a panel of experts to discuss current challenges and what the future looks like for fintech services catering to older generations on 11:FS Fintech Insider podcast. Aug 18, 2023](https://www.clearestate.com/en-us/media/alex-gauthier-11-fs-fintech-insider-podcast)

[![Image 2: FP media post long 2 width=](https://www.clearestate.com/assets/s3/press/visual/_800x420_crop_center-center_85_none/FP-media-post-long-2.jpg) ClearEstate Featured in the Financial Post ------------------------------------------ FP reports on how the industry of writing and executing wills is primed for a shakeup amid Canada's increasingly aging population. Jun 23, 2022](https://www.clearestate.com/en-us/media/clearestate-featured-in-the-financial-post)

[![Image 3: Ny post logo width=](https://www.clearestate.com/assets/s3/press/visual/_24xAUTO_fit_center-center_none/ny-post-logo.jpeg) ![Image 4: A news/press articles from New York Post logo logotype 3367x](https://www.clearestate.com/assets/s3/press/logos/_24xAUTO_fit_center-center_none/New_York_Post_logo_logotype_3367x.webp) ClearEstate Featured in the New York Post ----------------------------------------- The New York Post's special print edition of Senior Living, highlights ClearEstate's ability to facilitate and simplify the entirety of the estate settlement process for any given executor of a will. Jun 9, 2022](https://www.clearestate.com/en-us/media/clearestate-featured-in-the-new-york-post)

[![Image 5: D Magazine Logo min width=](https://www.clearestate.com/assets/s3/press/visual/_24xAUTO_fit_center-center_none/D-Magazine-Logo-min.jpeg) ClearEstate Featured in D Magazine ---------------------------------- D Magazine reports on ClearEstate's expansion to Texas, its fourth U.S. Market alongside California, Arizona, and Nevada. May 10, 2022](https://www.clearestate.com/en-us/media/clearestate-featured-in-d-magazine)

[![Image 6: LG ce monogram colour rgb 4x width=](https://www.clearestate.com/assets/s3/press/visual/_24xAUTO_fit_center-center_none/LG_ce_monogram_colour_rgb@4x.png) ClearEstate Broadens Its Estate Settlement Services By Launching In New York ---------------------------------------------------------------------------- Spearheading its presence across the most populated U.S. states which currentl

*[... truncated, 1,648 more characters]*

---

### Montreal's ClearEstate Technologies aims to disrupt an antiquated business that has resisted change
*722 words* | Source: **GOOGLE** | [Link](https://financialpost.com/technology/montreals-clearestate-technologies-aims-to-disrupt-an-antiquated-business-that-has-resisted-change)

[Skip to Content](https://financialpost.com/technology/montreals-clearestate-technologies-aims-to-disrupt-an-antiquated-business-that-has-resisted-change#main-content)

*   [News](https://financialpost.com/category/news/)
    *   [Archives](https://www.tkqlhce.com/click-8833686-11570746?url=https://financialpost.newspapers.com/?xid=3369/ "Archives (Leaving Financial Post)")

*   [Economy](https://financialpost.com/category/news/economy/)
*   [Energy](https://financialpost.com/category/commodities/energy/)
    *   [Oil & Gas](https://financialpost.com/category/commodities/energy/oil-gas/)
    *   [Renewables](https://financialpost.com/category/commodities/energy/renewables/)
    *   [Electric Vehicles](https://financialpost.com/category/commodities/energy/electric-vehicles/)

*   [Mining](https://financialpost.com/category/commodities/mining/)
    *   [Commodities](https://financialpost.com/category/commodities/)
        *   [Agriculture](https://financialpost.com/category/commodities/agriculture/)

*   [Real Estate](https://financialpost.com/category/real-estate/)
    *   [Mortgages](https://financialpost.com/category/real-estate/mortgages/)
    *   [Mortgage Rates](https://financialpost.com/category/real-estate/mortgages/mortgage-rates/)

*   [Finance](https://financialpost.com/category/fp-finance/)
    *   [Banking](https://financialpost.com/category/fp-finance/banking/)
    *   [Insurance](https://financialpost.com/category/fp-finance/insurance/)
    *   [Fintech](https://financialpost.com/category/fp-finance/fintech/)
    *   [Cryptocurrency](https://financialpost.com/category/fp-finance/cryptocurrency/)

*   [Work](https://financialpost.com/category/fp-work/)
*   [Wealth](https://financialpost.com/category/wealth/)
    *   [Smart Money](https://financialpost.com/category/wealth/smart-money/)
    *   [Wealth Management](https://financialpost.com/category/wealth/wealth-management/)

*   [Investor](https://financialpost.com/category/investing/)
    *   [Personal Finance](https://financialpost.com/category/personal-finance/)
        *   [Family Finance](https://financialpost.com/category/personal-finance/family-finance/)
        *   [Retirement](https://financialpost.com/category/personal-finance/retirement/)
        *   [Taxes](https://financialpost.com/category/personal-finance/taxes/)
        *   [High Net Worth](https://financialpost.com/category/personal-finance/high-net-worth/)

*   [FP Comment](https://financialpost.com/category/opinion/)
*   [Executive Women](https://financialpost.com/category/executive/executive-women/)
*   [Puzzmo](https://www.puzzmo.com/+/financialpost/ "Puzzmo (Leaving Financial Post)")
*   [Newsletters](https://financialpost.com/newsletters/)
*   [Financial Times](https://financialpost.com/category/financial-times/)
*   [Business Essentials](https://financialpost.com/category/personal-finance/business-essentials/)
*   [More](https://financialpost.com/technology/montreals-clearestate-technologies-aims-to-disrupt-an-antiquated-business-that-has-resisted-change)
    *   [Innovation](https://financialpost.com/category/technology/)
        *   [Information Technology](https://financialpost.com/category/technology/tech-news/)

    *   [FP500](https://financialpost.com/category/financial-post-magazine/fp500/)
    *   [Podcasts](https://financialpost.com/podcasts/)
    *   [Small Business](https://financialpost.com/category/entrepreneur/small-business/)
    *   [Lives Told](https://livestold.com/ "Lives Told (Leaving Financial Post)")
    *   [Tails Told](https://tailstold.com/ "Tails Told (Leaving Financial Post)")
    *   [Shopping](https://canoe.com/ "Shopping (Leaving Financial Post)")
    *   [Travel Deals](https://yourtraveldeals.ca/financialpost?utm_source=referral&utm_media=display&utm_content=nav_menu&utm_placement=header/ "Travel Deals (Leaving Financial Post)")
    *   [Obituaries](http://nationalpost.remembering.ca/ "Obituaries (Leaving Financial Post)")
        *   [Place a Notice](https://nationalpost.remembering.ca/select-notice-type/ "Place a Notice (Leaving Financial Post)")

    *   [Advertising](https://financialpost.com/)
        *   [Advertising With Us](https://www.postmediasolutions.com/contact-us/ "Advertising With Us (Leaving Financial Post)")
        *   [Advertising Solutions](https://www.postmediasolutions.com/ "Advertising Solutions (Leaving Financial Post)")
        *   [Postmedia Ad Manager](https://admanager.postmediasolutions.com/ "Postmedia Ad Manager (Leaving Financial Post)")
        *   [Sponsorship Requests](https://www.postmediasolutions.com/partnerships/ "Sponsorship Requests (Leaving Financial Post)")

    *   [Classifieds](https://classifieds.nationalpost.com/ "Classifieds (Leaving Financial Post)")
        *   [Place a Classifieds ad](https://nationalpost.adperfect.com/ "Place a Classifieds ad (Leaving Financial Post)")
        *   [Working](https://working.nationalpost.com/ "Working (Leaving Financial Post)")

*   [Profile](https://financial

*[... truncated, 11,232 more characters]*

---

### ClearEstate raises $16.8 million CAD to help the grieving deal with estates
*1,587 words* | Source: **GOOGLE** | [Link](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/)

ClearEstate raises $16.8 million CAD to help the grieving deal with estates

===============

Read [BetaKit Most Ambitious](https://bit.ly/4k6pCHn): Telling the story of what’s possible.

✕

[![Image 1: BetaKit - Canadian Startup News & Tech Innovation](https://betakit.com/wp-content/uploads/2024/01/BetaKit_Logo_White_250px.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [About](https://betakit.com/about-us/)
*   [Advertise](https://betakit.com/advertise/)
*   [Members](https://betakit.com/innovation-leaders/)
*   [Contact](https://betakit.com/about-us/#contact)

*   [](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/#)
    *   [](https://www.linkedin.com/company/BetaKit)
    *   [](https://twitter.com/BetaKit)
    *   [](https://www.youtube.com/user/Betakit)
    *   [](https://www.facebook.com/BetaKit)

[![Image 2: BetaKit - Canadian Tech & Startup News](https://betakitdev.trypl.com/wp-content/uploads/2025/04/betakit-logo-OG.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [News](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/#)

    *   [Latest News](https://betakit.com/#Latest)
    *   [By Topics](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/#)

        *   [Funding](https://betakit.com/tag/funding)
        *   [Acquisitions](https://betakit.com/tag/acquisitions)
        *   [Layoffs](https://betakit.com/tag/layoffs/)
        *   [VC](https://betakit.com/tag/vc/)
        *   [Events](https://betakit.com/tag/events)
        *   [Markets](https://betakit.com/tag/markets/)
        *   [Reports](https://betakit.com/tag/reports)
        *   [Impact](https://betakit.com/tag/impact)

    *   [By Verticals](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/#)

        *   [AI](https://betakit.com/tag/ai)
        *   [FinTech](https://betakit.com/tag/fintech)
        *   [SaaS](https://betakit.com/tag/saas)
        *   [Retail](https://betakit.com/tag/retail)
        *   [Healthtech](https://betakit.com/tag/healthtech)
        *   [Cleantech](https://betakit.com/tag/cleantech)
        *   [Deep Tech](https://betakit.com/tag/deep-tech/)
        *   [Defence Tech](https://betakit.com/tag/defence-tech/)

    *   [By Regions](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/#)

        *   [Toronto](https://betakit.com/tag/toronto)
        *   [Montréal](https://betakit.com/tag/montreal)
        *   [Vancouver](https://betakit.com/tag/vancouver)
        *   [Waterloo Region](https://betakit.com/tag/kitchener-waterloo)
        *   [Ottawa](https://betakit.com/tag/ottawa)
        *   [Calgary](https://betakit.com/tag/calgary)
        *   [Prairies](https://betakit.com/tag/prairies)
        *   [Atlantic Canada](https://betakit.com/tag/atlantic-canada/)

*   [Podcast](https://betakit.com/category/podcasts)
*   [Newsletter](https://betakit.com/category/newsletters)
*   [Quiz](https://betakit.com/category/quiz/)
*   [Jobs](https://betakit.com/tag/jobs/)

ClearEstate raises $16.8 million CAD to help the grieving deal with estates
===========================================================================

 By [Charles Mandel](https://betakit.com/author/charles-mandel/ "Posts by Charles Mandel")February 3, 2022

[Email](mailto:?subject=ClearEstate%20raises%20$16.8%20million%20CAD%20to%20help%20the%20grieving%20deal%20with%20estates&body=https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/)[Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/&title=ClearEstate+raises+%2416.8+million+CAD+to+help+the+grieving+deal+with+estates&source=BetaKit)[Share on X](https://twitter.com/intent/tweet?original_referer=https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/&text=ClearEstate+raises+%2416.8+million+CAD+to+help+the+grieving+deal+with+estates&tw_p=tweetbutton&url=https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/&via=BetaKit)[Share on Reddit](http://www.reddit.com/submit?url=https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/&title=ClearEstate+raises+%2416.8+million+CAD+to+help+the+grieving+deal+with+estates)[Share on BlueSky](https://bsky.app/intent/compose?text=ClearEstate+raises+%2416.8+million+CAD+to+help+the+grieving+deal+with+estates%20https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/)

![Image 3: ClearEstate | BetaKit](https://cdn.betakit.com/wp-content/uploads/2021/06/ClearEstate-770x513.jpg)

Lead investor OMERS Ventures says “end-of-life products” deserve more thoughtful solutions.

Estate settlement startup ClearEstate has secured a $

*[... truncated, 17,435 more characters]*

---

### Checking your browser
*64 words* | Source: **GOOGLE** | [Link](https://www.f6s.com/companies/canada/montreal/lo)

Checking your browser

===============

![Image 1](https://www.f6s.com/content-resource/static/f6s-logo-square.svg?v=FVXHfEQcGR)

We think you might be a bot 

 To regain access, please make sure that cookies and JavaScript are enabled before reloading the page.

 Please email [support@f6s.com](mailto:support@f6s.com) with the info below if you think this is an error: 

IP: 34.34.225.193

 Request ID: mDlcG6C0Bd4C0eXC6GJMrWZzV2tT2SnUpAZg4icOBSmOOUUwxM-Wew==

[Terms](https://www.f6s.com/terms)[Privacy](https://www.f6s.com/privacy-policy)[Data Security](https://www.f6s.com/data-security)[Cookie Policy](https://www.f6s.com/cookie-policy)[Cookie Table](https://www.f6s.com/cookie-table)© 2025 F6S Network Limited. All rights reserved. F6S is a registered trademark.

---

### ClearEstate Secures $13.25M Series A led by OMERS Ventures
*619 words* | Source: **GOOGLE** | [Link](https://www.clearestate.com/media/clearestate-secures-13-25m-series-a-led-by-omers-ventures)

Backed by institutional investors and expanding in the four largest US markets, the SaaS platform for executors is democratizing estate settlement and planning.
----------------------------------------------------------------------------------------------------------------------------------------------------------------

Posted on February 3, 2022

![Image 1: Clear Estate Founders test](https://www.clearestate.com/assets/s3/press/visual/_1200x630_crop_center-center_90_none/ClearEstate-Founders-test.jpg)

MONTRÉAL, CANADA – January 31, 2022 (TNKR Media): ClearEstate, a platform that supports executors and planners by streamlining tasks and professional services related to estate planning and settlement, has secured a US$13.25 million Series A funding round, led by a prominent Canadian institutional investor, OMERS Ventures.

Created in 2020 following co-founder and CPO [Alexandre Gauthier](https://www.clearestate.com/media/alex-gauthier)’s challenges settling his own late mother’s estate, the Montréal-based startup with offices in Ontario, California and Texas is now supported by some of Canada’s most credible investors, including Diagram Ventures, Torstar, Triangle Capital and NAVentures, the venture capital arm of the National Bank of Canada.

ClearEstate is a family finance hub that can save executors approximately 120 hours of their time and $8,500 in fees. An average North American estate settlement will cost families about $10,000. Adding to the burden is the probate process upon the death of a family member, which is most complex for the executor. They are responsible for completing a series of mandatory administrative tasks that [Gauthier has described](https://www.clearestate.com/blog/clearestate-a-simple-solution-for-difficult-times) as “being audited by the IRS every month for 18 months,” the typical length of the process.

Despite the daunting tasks, new polling data from Maru Public Opinion for ClearEstate suggests about nine in ten North American adults appoint a person close to the family as estate executor. Nearly two-thirds of Americans polled (63%) described the loss of an immediate family member as one of life’s most difficult challenges, disrupting their personal and professional lives; among those appointed executors, nearly three-quarters (74%) agreed. This is where ClearEstate steps in.

With robust expansion plans throughout Canada and in the four most populous US states (California, New York, Texas and Florida), ClearEstate is growing its all-in-one estate asset management suite. The company also offers estate planning in advance, professional executorship services and bereavement benefits packages; an [emerging trend among employers](https://www.benefitscanada.com/human-resources/hr-law/employers-offering-wills-estate-planning-tools-amid-coronavirus-crisis/) to further the financial security of employees amid a competitive recruiting environment.

Following this latest fundraise, ClearEstate’s growth trajectory will focus on extensive recruitment in both the US and Canada, as the company seeks empathetic, diligent and forward-thinking software engineers, full-stack web developers, estate professionals, and web sales and marketing specialists. All roles are expected to be remote.

“We are humbled to have the confidence of OMERS, an organization that values multi-stage growth for those preaching institutional change,” said ClearEstate CEO and co-founder [Davide Pisanu](https://www.clearestate.com/media/founder-profile-ceo-davide-pisanu), previously a senior vice president with Cirque du Soleil. “OMERS is an important addition to the team as ClearEstate builds a network of support for executors across North America. We are not just addressing a little-known consumer pain point with solid tech, we’re tackling an unjust system that saddles ordinary families with extraordinary amounts of paperwork at a time when they should be healing.”

“Because we exist to serve the half a million members of the OMERS pension plan, the emerging needs of an ageing population are always top of mind for us,” said Shawn Chance, Partner, OMERS Ventures. “We feel confident that ClearEstate’s team and technology are addressing a significant gap in the market by adding much needed transparency and ease to the estate planning and settlement process for the average person.”

As [the largest wealth transfer in human history](https://www.forbes.com/sites/markhall/2019/11/11/the-greatest-wealth-transfer-in-history-whats-happening-and-what-are-the-implications/?sh=185599e14090) is expected in the coming years, ClearEstate will be calling on institutional partners across North America — governments, financial institutions, the courts, etc. — to once and for all optimize the estate settlement process, eliminating waste and offering families a more dignified, restful mourning period.

For further information or interview opportunities: media@clearestate.com

---

### Just a moment...
*26 words* | Source: **GOOGLE** | [Link](https://rocketreach.co/alexandre-gauthier-email_22574681)

![Image 1: Icon for rocketreach.co](https://rocketreach.co/favicon.ico)rocketreach.co
-------------------------------------------------------------------------------------

Verify you are human by completing the action below.

rocketreach.co needs to review the security of your connection before proceeding.

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[ClearEstate Technologies aims to disrupt antiquated estate ...](https://financialpost.com/technology/montreals-clearestate-technologies-aims-to-disrupt-an-antiquated-business-that-has-resisted-change)**
  - Source: financialpost.com
  - *Mar 11, 2022 ... Alexandre Gauthier and Davide Pisanu, two of the three co-founders of Montreal-based ClearEstate Technologies Inc., raised US$13.5 mi...*

- **[ClearEstate raises $16.8 million CAD to help the grieving deal with ...](https://betakit.com/clearestate-raises-16-8-million-cad-to-help-the-grieving-deal-with-estates/)**
  - Source: betakit.com
  - *Feb 3, 2022 ... Pisanu co-founded ClearEstate in 2020 with CPO Alexandre Gauthier following Gauthier's challenges settling his late mother's estate. T...*

- **[100 Top Companies in Montreal · December 2025 | F6S](https://www.f6s.com/companies/canada/montreal/lo)**
  - Source: f6s.com
  - *7 days ago ... ClearEstate strives to change the way estates are settled. Settling ... Alexandre Gauthier | F6S - Images. Meet Martin, Francois and .....*

- **[ClearEstate Secures $13.25M Series A led by OMERS Ventures](https://www.clearestate.com/media/clearestate-secures-13-25m-series-a-led-by-omers-ventures)**
  - Source: clearestate.com
  - *Feb 3, 2022 ... Created in 2020 following co-founder and CPO Alexandre Gauthier's ... For further information or interview opportunities: media@cleare...*

- **[Alexandre Gauthier Email & Phone Number | ClearEstate Co ...](https://rocketreach.co/alexandre-gauthier-email_22574681)**
  - Source: rocketreach.co
  - *Alexandre Gauthier, based in Montreal, QC, CA, is currently a Co-Founder and CRO at ClearEstate. Alexandre Gauthier brings experience from previous ro...*

- **[Alexandre Gauthier is on a mission](https://www.clearestate.com/media/alex-gauthier)**
  - Source: clearestate.com
  - *Jun 16, 2021 ... Talk to a specialist now. Settle an ... We know where this team needs to go.” You can reach Alexandre Gauthier at alex@clearestate.co...*

- **[Programme](https://conferencenationale2025.ca/fr/agenda)**
  - Source: conferencenationale2025.ca
  - *Alexandre Gauthier. Co-fondateur et CRO, ClearEstate. Courville et Montmorency ... Sa conférence vous plongera dans les secrets de la performance ment...*

- **[Thought Leadership | ClearEstate Technologies Inc.](https://www.clearestate.com/en-us/blog/thought-leadership)**
  - Source: clearestate.com
  - *Jean-Philippe Thought Leadership Blog. How I Learned that Estate ... Co-founder Alexandre Gauthier explains the roots of his original ClearEstate mind...*

- **[ClearEstate secures USD13.25m in Series A led by OMERS ...](https://www.privateequitywire.co.uk/clearestate-secures-usd1325m-series-led-omers-ventures/)**
  - Source: privateequitywire.co.uk
  - *ClearEstate, a platform that supports executors and planners by ... Created in 2020 following co-founder and CPO Alexandre Gauthier's challenges ......*

- **[ClearEstate Secures $13.25M Series A Led by OMERS Ventures](https://www.newswire.ca/news-releases/clearestate-secures-13-25m-series-a-led-by-omers-ventures-898478659.html)**
  - Source: newswire.ca
  - *Feb 3, 2022 ... MONTREAL · Created in 2020 following co-founder and CPO Alexandre Gauthier's challenges settling his own late mother's estate, the · C...*

---

*Generated by Founder Scraper*
