# Eric Angelillo

## Position actuelle

**Titre** : Co-Founder & Creative Director
**Entreprise** : Double Stallion Games
**Durée dans le rôle** : 5 years in role
**Durée dans l'entreprise** : 12 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAMbtusBwQ5w18XlZomYeoBz_CqRYPLp9b8/
**Connexions partagées** : 3


---

# Eric Angelillo

## Position actuelle

**Entreprise** : Double Stallion Games

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Eric Angelillo
*Double Stallion Games*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [Double Stallion Games | LinkedIn](https://ca.linkedin.com/company/double-stallion-games)
*2025-03-19*
- Category: article

### [Double Stallion-Creating Unique Player Experiences – Innovations of the World](https://innovationsoftheworld.com/double-stallion/)
*2025-03-01*
- Category: article

### [Double Stallion Games | The Org](https://theorg.com/org/double-stallion-games)
*2023-03-30*
- Category: article

### [Double Stallion is disrupting the gaming industry with 2D animation](https://toonboom.com/double-stallion-is-disrupting-the-gaming-industry-with-2d-animation)
*2018-07-25*
- Category: article

### [Exclusive: Interview With Eric From Horrible Unicorn Game Studios - Canadian Game Devs](https://canadiangamedevs.com/blog/2016/1/5/exclusive-interview-with-eric-from-horrible-unicorn-game-studios)
*2016-01-05*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Big Action Mega Fight in the making : Interview with Double Stallion ...](https://www.audiokinetic.com/en/big-action-mega-fight-in-the-making-interview-with-double-stallion-and-vibe-avenue/)**
  - Source: audiokinetic.com
  - *May 15, 2016 ... Double Stallion (DS): Double Stallion Games was one of the first ... Eric Angelillo, Art Director & Animator; Nicolas Barriere, Game ...*

- **[Rowan Parker – Creative Director at Riot Forge – on exploring and ...](https://www.brandsuntapped.com/rowan-parker-creative-director-at-riot-forge-on-exploring-and-expanding-the-world-of-league-of-legends/)**
  - Source: brandsuntapped.com
  - *Jul 25, 2023 ... ... Double Stallion Games and The Mageseeker with Digital Sun. What kick ... Eric Angelillo is the Creative Director there and we spo...*

- **[PANEL DISCUSSION: 2D Animation & Video Game Development ...](https://www.youtube.com/watch?v=AyfW-gaKW9w)**
  - Source: youtube.com
  - *Nov 5, 2021 ... ... Eric Angelillo Creative Director and Co-Founder at Double Stallion Games https://dblstallion.com/ If you enjoyed this episode, don...*

- **[2D Combat Racer Speed Brawl Hits PS4 Tomorrow – PlayStation.Blog](https://blog.playstation.com/2018/09/17/2d-combat-racer-speed-brawl-hits-ps4-tomorrow/)**
  - Source: blog.playstation.com
  - *Sep 17, 2018 ... The creative leads from Double Stallion Games share their ... Today, we get to hear from the game's Art Director, Eric Angelillo, and...*

- **[Convergence: A League of Legends Story reimagining Zaun ...](https://blog.playstation.com/2023/05/02/convergence-a-league-of-legends-story-reimagining-zaun/)**
  - Source: blog.playstation.com
  - *May 2, 2023 ... Eric Angelillo Creative Director, Double Stallion Games. My name is ... PS Blog Game of the Year Awards 2025: polls are now live ......*

- **[Double Stallion is disrupting the gaming industry with 2D animation ...](https://www.toonboom.com/double-stallion-is-disrupting-the-gaming-industry-with-2d-animation)**
  - Source: toonboom.com
  - *Jul 25, 2018 ... The Montreal-based indie studio has established itself as a leader in the growing movement of 2D animated video games. Double Stallio...*

- **[Speed Brawl is first video game animated in a Harmony-Unity ...](https://www.toonboom.com/speed-brawl-is-first-video-game-animated-in-a-harmony-unity-pipeline)**
  - Source: toonboom.com
  - *Feb 20, 2019 ... ... Eric Angelillo, art director and co-founder of Double Stallion Games. ... Blog · Shoparrow_outward · Contact usarrow_outward · Ab...*

- **[Convergence: A League of Legends Story y la reinvención de Zaun ...](https://blog.latam.playstation.com/2023/05/02/convergence-a-league-of-legends-story-y-la-reinvencion-de-zaun/)**
  - Source: blog.latam.playstation.com
  - *May 2, 2023 ... Eric Angelillo Creative Director, Double Stallion Games. Me llamo ... Premios al juego del año 2025 de PS Blog: las encuestas ya están...*

- **[Convergence: A League of Legends Story – Rediseñando Zaun ...](https://blog.es.playstation.com/2023/05/02/convergence-a-league-of-legends-story-redisenando-zaun/)**
  - Source: blog.es.playstation.com
  - *May 2, 2023 ... Eric Angelillo Director creativo, Double Stallion Games. Soy Eric ... Últimas noticias. Premios al Juego del año de PS Blog de 2025: v...*

- **[Convergence: A League of Legends Story e a reimaginação de ...](https://blog.br.playstation.com/2023/05/02/convergence-a-league-of-legends-story-e-a-reimaginacao-de-zaun/)**
  - Source: blog.br.playstation.com
  - *May 2, 2023 ... Eric Angelillo Creative Director, Double Stallion Games. Meu nome é ... Últimas notícias. Premiação Jogo do Ano de 2025 do PS Blog: vo...*

---

*Generated by Founder Scraper*
