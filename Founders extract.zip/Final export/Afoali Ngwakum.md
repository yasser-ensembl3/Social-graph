# Afoali Ngwakum

## Position actuelle

**Titre** : Producer & Founder
**Entreprise** : 9:16 STORIES
**Durée dans le rôle** : 3 years 4 months in role
**Durée dans l'entreprise** : 3 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

9:16 is the ratio of the screen of any smart phone. 
Our goal is to help brands create impactful video content made for their audiences to connect on social media. 

We specialize in: 
- Video Production 
- Vertical Content Production & Distribution Strategy
- Motion Graphic animations

## Résumé

Eternally curious. Fiercely intentional. Rooted in storytelling.  

I help brands, creatives, and entrepreneurs use video to go from invisible to influential—without burning out.  

My sweet spot?  
→ Turning ideas into scroll-stopping short-form content  
→ Building repeatable video systems for personal brands  
→ Teaching creators how to use tech (like AI) to tell better stories  
→ Bringing African stories to the global stage  

What I share here:  
🎥 Video strategy, storytelling, and editing workflows  
📲 Social media content that builds trust + traffic  
🌍 Africa-centered narratives, community building, and tech for creatives  

Over the years, I've:  
- Helped 50+ businesses and 1400+ students tell bold, compelling stories  
- Produced video for Grammy-nominated artists (Burna Boy, Wizkid)  
- Built a production company from the ground up: (https://www.916stories.com)  
- Created content with over 400M+ minutes viewed across platforms  
- Burned out and learned how to build a fulfilling life centred around my wellness. 

👀 See the work:  
→ Video production company https://www.916stories.com

Want to connect or collaborate?  
DMs are open or find me anywhere online @_afoali.  

P.S. I’m just here to share the things I learn. All views are my own.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABebq2cBpRzGbnLZZDWmHrKQW1uL_cC7muc/
**Connexions partagées** : 9


---

# Afoali Ngwakum

## Position actuelle

**Entreprise** : 9:16 STORIES

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Afoali Ngwakum
*9:16 STORIES*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [Motion Spotlight with Afoali Ngwakum Akisa](https://www.youtube.com/watch?v=FLltlvdEkdA)
*2024-08-21*
- Category: video

### [Inside Look: Afoali's Experience on the Hit TV Show LA VOIX with Deferlante Production](https://www.916stories.com/blogs/inside-look-afoalis-experience-on-the-hit-tv-show-la-voix-with-deferlante-production)
*2023-05-10*
- Category: blog

### [The Power of Short Form Vertical Video](https://www.916stories.com/blogs/the-power-of-short-form-vertical-video)
*2023-05-08*
- Category: blog

### [How AI is Changing Video Editing for Businesses - Top Easy-to-Use Apps](https://www.916stories.com/blogs/how-ai-is-changing-video-editing-for-businesses-top-easy-to-use-apps)
*2023-04-13*
- Category: blog

### [Strive Chat](https://podcasts.apple.com/au/podcast/strive-chat/id1669788288)
*2025-03-31*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[An Immigrant's Life | RedCircle](https://redcircle.com/shows/an-immigrants-life)**
  - Source: redcircle.com
  - *Afoali Ngwakum a video content creator from Montreal who is originally from ... 9:16 Stories and the fun and stress of video productions. ALL LINKS .....*

- **[Sayalab - Sayaspora](https://sayaspora.com/en/special-project/sayalab-en-2/)**
  - Source: sayaspora.com
  - *Afoali Ngwakum. Afoali is a creative producer and founder of 9:16 Stories Inc. ... Podcast · Events · Collections · Contact Us · FR. Montreal. info@sa...*

- **[Sayalab - Sayaspora Le projet Sayalab | Sayaspora](https://sayaspora.com/projet-special/sayalab/)**
  - Source: sayaspora.com
  - *Afoali Ngwakum. Afoali est productrice créative et fondatrice de 9:16 Stories Inc. ... Podcast · Événements · Collections · Contact · EN. Montréal. in...*

- **[Afoali Ngwakum Akisa](https://en.sommetdynastie.com/intervenants/afoali-ngwakum-akisa)**
  - Source: en.sommetdynastie.com
  - *Afoali Ngwakum Akisa. Afoali Ngwakum Akisa is a Montreal-based creative mind, storyteller, and founder of 9:16 Stories ... interviews with influential...*

- **[Afoali Ngwakum](https://www.skool.com/@nine-sixteen-academy-3601)**
  - Source: skool.com
  - *Afoali Ngwakum. @nine-sixteen-academy-3601. Afoali, founder of 9:16 Stories, helps creators craft impactful videos. Learn to connect, inspire ......*

- **[Intervenants](https://www.sommetdynastie.com/intervenants)**
  - Source: sommetdynastie.com
  - *... Talk, a dirigé la ... Afoali Ngwakum Akisa. Afoali Ngwakum Akisa est une créatrice basée à Montréal, une conteuse passionnée et la fondatrice de 9...*

---

*Generated by Founder Scraper*
