# Brigitte Hubmann

## Position actuelle

**Titre** : Founder / Principal
**Entreprise** : Film Associates International
**Durée dans le rôle** : 4 years 7 months in role
**Durée dans l'entreprise** : 4 years 7 months in company

## Localisation & Industrie

**Localisation** : Canada

## Description du rôle

Film Associates International is a boutique consulting agency focused on film promotion & marketing strategies and services.

## Résumé

Fluently tri-lingual, Brigitte Hubmann has 30 years of experience in film marketing, business development initiatives and cultural diplomacy at the national and international level. 

She works in close collaboration with film and cultural agencies, filmmakers, festivals, distributors and exhibitors.  

She leverages her experience for clients at Film Associates International, a boutique consulting agency that she founded in 2021 focusing on festivals, film sales, marketing strategies and services for the industry. 

Serving both individual clients and agencies, her strengths range from managing curated business meetings and networking events to hosting trade missions and pitch sessions. 

As a veteran cultural initiatives manager, she is known for balancing strategic planning and creative programming. She has produced public events as well as industry programming and PR campaigns at international film festivals and markets at Toronto, Cannes, Berlin, Sundance, Karlovy Vary and Shanghai.

She joined Telefilm Canada in 2001 as a core contributor shaping and delivering the agency’s international promotional strategies. The scope included festivals and markets as well as discoverability campaigns, spearheading CANADA NOW, the agency's promotion and export initiative in the U.S, UK, China, Germany and Mexico.

Brigitte began her career at the Goethe-Institutes in Montréal and New York as a film program manager, curating and promoting film series and retrospectives, for over 10 years. She then moved on to Germany`s national film PR agency (then known as Export-Union des Deutschen Films) as their Representative for Canada and USA (East Coast) from 1998 to 2001, as well as Executive Director of the Fassbinder Foundation in New York.

Fluent in English, French and German.

B.A. with a Specialization in Communication Studies from Concordia University.

MORE INFO @ https://cinando.com/en/Company/film_associates_international_249499/Detail or www.film-associates.com

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAFlGD4BghyepQaBHgsuzEFl-Rgx93v-kyw/


---

# Brigitte Hubmann

## Position actuelle

**Entreprise** : Film Associates International

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 3rd


---

# Brigitte Hubmann

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397389806957170688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFqsvYINdWxSA/feedshare-shrink_800/B4EZqjO1FwKUAg-/0/1763675165869?e=1766620800&v=beta&t=whxx9mjTC3rY42LYRnJV_FdqsO2z9Ph-NsoH65AeRAY | The film NIKA & MADISON and its team continue garnering accolades since world premiering at Toronto International Film Festival! Congratulations to Eva Thomas and her team on their ten nominations and five wins -- including Best Picture, Best Director, Best Original Screenplay, Outstanding Lead Performance, and Outstanding Supporting Performance -- at the Red Nation International Film Festival's award ceremony this past weekend in Los Angeles! | 18 | 0 | 0 | 2w | Post | Brigitte Hubmann | https://www.linkedin.com/in/brigitte-hubmann-192a077 | https://linkedin.com/in/brigitte-hubmann-192a077 | 2025-12-08T08:01:26.081Z |  | 2025-11-20T21:46:06.835Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384015945993826305 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH8ckrxW5tHqw/feedshare-shrink_800/B4EZnlLX6UGoAg-/0/1760486588682?e=1766620800&v=beta&t=KTXmc17YhJhPm0ovqgoGoVCSEoWRSme9tZDkq4fozbg | Keep an eye out for this film, this team!  Thrilled to share that “Eva Thomas and her team” have been nominated for the DGC Award for Outstanding Directorial Achievement in Feature Film for NIKA & MADISON - alongside such extraordinary and inspiring Canadian filmmakers as:
Guy Maddin, Evan Johnson & Galen Johnson - Rumours
Chloé Robichaud - Deux femmes en or
R.T. Thorne - 40 Acres 
Adam B. Stein & Zach Lipovsky - Final Destination: Bloodlines
Congratulations to all the Directors Guild of Canada - National nominees Eva Thomas | 7 | 0 | 0 | 1mo | Post | Brigitte Hubmann | https://www.linkedin.com/in/brigitte-hubmann-192a077 | https://linkedin.com/in/brigitte-hubmann-192a077 | 2025-12-08T08:01:26.082Z |  | 2025-10-15T00:03:09.907Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7308511773341478913 | Article |  |  | To my friends south of the 49th Parallel! The Hollywood Reporter just published a list of the 51 Greatest Canadian Films of All Time . Celebrate the best of Canadian independent spirit — no tariffs required. Check out the Telescope Film platform in the U.S. to see where you can screen them — and their sections dedicated to films from Canada and from Quebec! Telefilm Canada SODEC - Société de développement des entreprises culturelles Catherine Scheinman Justine Barda | 16 | 2 | 0 | 8mo | Post | Brigitte Hubmann | https://www.linkedin.com/in/brigitte-hubmann-192a077 | https://linkedin.com/in/brigitte-hubmann-192a077 | 2025-12-08T08:01:26.083Z |  | 2025-03-20T15:36:32.347Z | https://www.hollywoodreporter.com/lists/best-canadian-films/?fbclid=IwY2xjawJJFKFleHRuA2FlbQIxMQABHY8P5xpQ5P05PkzXfDc1EfdaAmbJTrF6qiBqYqFuZqgXYAMZliQjir0wjw_aem_dUNrb3YJ_ccsvohwVZYLOg |  | 

---



---

# Brigitte Hubmann
*Film Associates International*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [Film Associates International](https://film-associates.com/associates)
*2025-01-01*
- Category: article

### [Rachel Nichols Horror Gets North America Deal; Telefilm ...](https://www.yahoo.com/entertainment/rachel-nichols-horror-gets-north-133032983.html)
*2021-06-16*
- Category: article

### [Rachel Nichols - News](https://www.imdb.com/name/nm0629697/news/)
- Category: article

### [The future of the film and entertainment industry with Alan d'Escragnolle, CEO and Co Founder of Filmhub - The Bridge](https://www.buzzsprout.com/1976572/episodes/11761069-the-future-of-the-film-and-entertainment-industry-with-alan-d-escragnolle-ceo-and-co-founder-of-filmhub)
*2022-11-25*
- Category: article

### [Curating Personalised Learning Paths with  Online Platforms — TESOL Pop](https://tesolpop.com/listen-tesolpop-podcast/s10e1-curating-personalised-learnin-paths-with-online-platforms-roger-hubmann-happy-students)
*2024-09-17*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Rachel Nichols Horror 'Demigod' Gets North America Deal](https://deadline.com/2021/06/rachel-nichols-horror-gets-north-america-deal-telefilm-canada-exec-launches-consultancy-utopia-boards-we-intend-to-cause-havoc-global-briefs-1234776132/)**
  - Source: deadline.com
  - *Jun 16, 2021 ... EXCLUSIVE: Montreal-based film executive Brigitte Hubmann and LA-based vet Jennifer Price are launching Film Associates International...*

- **[Gravitas Ventures acquires Sean Garrity's The Burning Season ...](https://playbackonline.ca/2024/10/16/gravitas-ventures-acquires-sean-garritys-the-burning-season/)**
  - Source: playbackonline.ca
  - *Oct 16, 2024 ... The deal was negotiated by Gravitas' Bill Guentzler as well as Film Associates International's Brigitte Hubmann and Jennifer Price on...*

- **[Kino Lober Acquires Trio Of Restored Works By Canada's Patricia ...](https://deadline.com/2022/08/patricia-rozema-when-night-is-falling-kino-lorber-mubi-1235098071/)**
  - Source: deadline.com
  - *Aug 23, 2022 ... In addition to partnering with Kino Lorber for North America, Film Associates International co-founder and partner Brigitte Hubmann h...*

- **[Rachel Nichols Horror Gets North America Deal; Telefilm Canada ...](https://www.yahoo.com/entertainment/rachel-nichols-horror-gets-north-133032983.html)**
  - Source: yahoo.com
  - *Jun 16, 2021 ... EXCLUSIVE: Montreal-based film executive Brigitte Hubmann and LA-based vet Jennifer Price are launching Film Associates International...*

- **[Rachel Nichols - News - IMDb](https://www.imdb.com/name/nm0629697/news/)**
  - Source: imdb.com
  - *... Podcasts. Awards & events. OscarsBest Of 2025Holiday Watch ... Film Associates International Launch Exclusive: Montreal-based film executive Brigi...*

- **[Unabhängiges Forum für die Film-und Medienszene in ...](https://filmbuero-nds.de/files/rb151_web.pdf)**
  - Source: filmbuero-nds.de
  - *Oct 3, 2025 ... Eine der größten Privilegien war die Unterstützung durch Brigitte Hubmann von Film Associates International, die maßgeschneidert auf j...*

---

*Generated by Founder Scraper*
