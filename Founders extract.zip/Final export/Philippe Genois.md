# Philippe Genois

## Position actuelle

**Titre** : Coach
**Entreprise** : District 3 Innovation
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Professional Training and Coaching

## Résumé

Passionate about tech and entrepreneurship.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABhcUTUBh6qQxMtXd1ZZj9sD--K-pZgg4pw/
**Connexions partagées** : 94


---

# Philippe Genois

## Position actuelle

**Entreprise** : InputKit

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Philippe Genois

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401652123337248769 | Text |  |  | J’ai toujours détesté les événements de réseautage.

Le small talk forcé, les cartes d’affaires qui vont direct au vidange, les moments awkward quand t’as personne à qui parler.

Pendant des années, j’ai juste refusé toutes les invitations à des événements. Pi j’etais bein correct avec ça.

Jusqu’au jour où je me suis lancé le défi d’essayer pour vrai.

Non seulement j’ai appris à vraiment aimer ça, mais c’est tellement important pour bâtir son réseau.

J’irais pas jusqu'à dire que c’est un MUST, mais ça accélère la croissance de ta business for sure. Tu sais pas sur qui tu vas tomber, ça peut être une rencontre game-changer. | 79 | 15 | 1 | 5d | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:00:55.370Z |  | 2025-12-02T16:03:02.250Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397321309807976448 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2ca65d26-4531-4ed7-b48c-8a21c31cdc8b | https://media.licdn.com/dms/image/v2/D4E05AQEoAZadVxPPDQ/feedshare-thumbnail_720_1280/B4EZouwafMJ0A4-/0/1761721035903?e=1765778400&v=beta&t=1aZzP5GA1GvDOvDV4DD6OAiQRtBAFhZkfBmcjIFcmUY | Merci Rejean Gauthier pour l’invitation sur ton podcast!! Très content de t'avoir rencontré, ton histoire est touchante et inspirante!

Pour écouter l'épisode : https://lnkd.in/edK8nPZ3 | 10 | 0 | 1 | 2w | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:00:55.371Z |  | 2025-11-20T17:13:55.842Z | https://www.linkedin.com/feed/update/urn:li:activity:7389235816528625664/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394042351511379970 | Text |  |  | Tout le monde que je rencontre me pose la même question:
« Pi, c’était comment les Dragons ? »

J’imagine qu’il y a d’autres curieux ici qui se demandent si ça vaut la peine d’y aller.

Ce qu’on voit à la télé, c’est 7 minutes, mais derrière, c’est des mois de retombées.

Honnêtement, c’était une de mes plus belles expériences professionnelles.
Et les retombées sont 1000x meilleures que j’aurais imaginé.

Aujourd’hui, 1 démo sur 2, nos leads ont déjà vu la vidéo de notre passage (on met le lien sur notre site web et dans nos signatures de courriel)

Ça nous donne tellement de crédibilité au Québec, c’est insane.

Si j’avais à quantifier le retour, c’est facilement dans les 6 chiffres, et ça va continuer encore des mois / années !

Si tu te demandes si ça vaut toute l’énergie que tu vas investir dans le processus, ma réponse est un gros OUI !!

Fun fact, j’ai jamais voulu y aller à l'émission, je trouvais ça bein trop stressant et je pensais que ça allait rien donner. Merci à mon ami Vincent Martel, P. Eng., MBA qui m’a lancé le défi.

Voici la vidéo de notre passage: https://lnkd.in/eKnRStxK | 83 | 7 | 0 | 3w | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:00:55.372Z |  | 2025-11-11T16:04:31.264Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7391505356117684224 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFfQMVaZWycqw/image-shrink_1280/B4EZpPm34SHcAQ-/0/1762272183736?e=1765778400&v=beta&t=kSU1sKe9dJ8-IqA6Uz9Xra5E2zf0xstEd1p_wUauLhQ | Je sais pas pour toi, mais je trouve ça tellement important d’aller à des events comme #RevStar

T’entends le Président de LightSpeed et le co-founder de Hubspot parler de leurs équipes de 700 représentants et de leur croissance de 0 à $1B ARR…

Non seulement c’est inspirant, mais je trouve que ça m’oblige a prendre du recule et à réfléchir différemment.

Je reviens toujours de ce genre de conférences avec des trucs concrets qui finissent par faire toute la différence.

Merci à l’équipe RevStar pour l’organisation, ça fait du bien d’avoir ce genre de conférence au Québec !! | 36 | 3 | 0 | 1mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:00:55.373Z |  | 2025-11-04T16:03:24.427Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7388964791614349312 | Text |  |  | Depuis la COVID, on n’avait pu de bureau. 
I guess que c'était par paresse (on aimait mieux full-remote) et par peur que ca soit pas worth it.

Cet été, on a décidé de ramener 3 jours au bureau. On a investi dans un vrai beau bureau.

Pour vrai, turns out que c’était un esti de bon move.

Ça fait 4 mois maintenant et je me demande comment on faisait avant loll

Je réalise qu'à distance, on prenait beaucoup moins l'initiative de se parler pour les petites choses.
Mais c’est souvent ces petites choses-là qui font toute la différence. 

Sans compter juste l’énergie que ça donne de travailler avec du monde, d’entendre du monde closer des deals, etc.

Je ne reviendrais pas en arrière ! | 124 | 16 | 0 | 1mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:00:55.374Z |  | 2025-10-28T15:48:06.648Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379596840654045184 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHn6M-AZkAzQA/feedshare-shrink_800/B4EZmbbKhMIQAk-/0/1759249214461?e=1766620800&v=beta&t=_RIaWOc56_Evxa1KvZpGp4OC4Ay7nuEyK-n78CAYw9g | « Pas de magie : si tu veux des avis, faut que tu demandes. Voici 8 idées toutes faites pour t’aider à le faire comme du monde. » | 5 | 0 | 0 | 2mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.015Z |  | 2025-10-02T19:23:13.091Z | https://www.linkedin.com/feed/update/urn:li:activity:7379530722333696000/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7378794564460912641 | Text |  |  | Julien Smith (Co-founder de Breather) a dit à la conf SaaSpasse :
« La seule différence que je vois entre les entrepreneurs qui ont beaucoup de succès et les autres, c’est qu’ils travaillent plus fort et plus vite que tout le monde. »

For sure ma conférence préférée de la journée.

Je trouve ça tellement nice le monde qui disent les vraies choses, au lieu d'idéaliser l’entrepreneuriat. | 54 | 6 | 0 | 2mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.015Z |  | 2025-09-30T14:15:15.541Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7376257968461488128 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHy8rg7DP4Tgg/image-shrink_800/B4EZl27dCmKoAg-/0/1758636923204?e=1765778400&v=beta&t=tlB6zZHqsKdDFk2faeSvKxLq7G_1tZyxR2AdzxQdmnk | Je rencontre souvent des new SaaS founders qui veulent bootstrap et qui pensent que ça va aller vite! 

Moi, après 2 ans de grind, InputKit faisait à peine 5k MRR.
Je me payais 12k$/an (ça donnait un taux horaire en bas de 3$ / heure loll) et j’avais une autre job la fin de semaine.

Mon co-founder Jean-Philippe Fong était encore full-time chez Desjardins et m’aidait les soirs et fins de semaine, sans salaire.

Aujourd’hui, on approche du 2M$ ARR, en route vers le 10M.
Et je suis fucking content d’avoir choisi de bootstrap. Ça me donne la liberté que j’ai toujours voulu.

Mais je pense que très souvent, c’est plus long qu’on pense. | 190 | 16 | 1 | 2mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.016Z |  | 2025-09-23T14:15:43.927Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7373733424626294784 | Text |  |  | Notre problème avec InputKit , c'est que même si nos clients nous adorent, ils préfèrent ne pas trop en parler… pour garder leur edge compétitif (plusieurs sont devenu #1 sur Google maps grace à leurs reviews)

Mais je comprends pas comment en 2025, il y a encore des business de services qui négligent leurs avis Google !!

Si t’as une business de service, fais-moi confiance, tu dois :
- Avoir au moins 4.7/5 sur Google
- Avoir plus d’avis que tes compétiteurs locaux (et un minimum de 200-300 avis)

Une clinique médicale privée a augmenté son chiffre d’affaires de 800 000 $ juste en passant de 2.6 à 4.9/5 sur Google. 
Et j’ai des centaines d’exemples comme ça, dans pas mal tous les secteurs B2C.

Bref, arrête de mettre des milliers de dollars en pub si tes avis Google sont pourris. | 67 | 3 | 0 | 2mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.017Z |  | 2025-09-16T15:04:05.773Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7371181931243208704 | Text |  |  | Au début d’InputKit, je détestais vendre.

J’avais choisi l’informatique justement pour éviter de parler et de faire des présentations orales.
Pis là pour faire survivre InputKit, j’étais obligé de :
- parler à des inconnus
- me faire dire non
- me prouver chaque jour

C’était ma torture quotidienne, pendant des années.
Mais avec le temps, j'ai appris à bien vendre et à vraiment aimer ça.

Avec le recul, c’est la meilleure chose qui me soit arrivée.

Avec l’IA, développer un software va devenir de plus en plus facile.
Vendre, c’est LE skill le plus important selon moi. | 94 | 16 | 1 | 2mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.018Z |  | 2025-09-09T14:05:22.346Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7368647673421242368 | Text |  |  | Quand j'entends un entrepreneur dire que plus la business grossit, plus ça devient difficile… je suis tellement pas d’accord.

Au début d’InputKit, je faisais à peine 2k$/mois.
Je me payais à peine assez pour manger du Kraft Dinner.

Je portais tous les chapeaux : vendeur, développeur, support.
Je faisais 3h de route pour closer un deal à 50$/mois.
Aucun call entrant. Zéro lead. Personne voulait me parler.

Je détestais chaque journée.

Aujourd’hui, oui les problèmes sont plus gros, mais je travaille sur mon X entouré d'une équipe sa coche.

C’est 1000x plus facile qu'au début. | 130 | 15 | 0 | 3mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.019Z |  | 2025-09-02T14:15:08.197Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7366854692405932033 | Article |  |  | 👉 Fier de voir l’impact concret d’InputKit dans une industrie aussi compétitive que l’automobile. Bravo à Mario Gilbert et son équipe — vos clients satisfaits sont maintenant vos meilleurs ambassadeurs! 🚀 | 22 | 0 | 0 | 3mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.019Z |  | 2025-08-28T15:30:28.211Z | https://www.inputkit.io/fr/etude-de-cas/honda-lallier-ste-foy-collecte-12x-plus-davis-google-par-mois/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7340725221450022912 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7wDITbaZhhA/feedshare-shrink_800/B4EZd5Ul_8H0Ao-/0/1750087132898?e=1766620800&v=beta&t=mcrO0g26803Xumv3D49zsXi8F1-dL-g_CNGdth-6TA4 | Un gros merci à Samuel Beaudry pour l’invitation sur son podcast Le Podcast Pas Ordinaire 🎙️

J’ai vraiment eu du fun — on a eu des super belles discussions sur la business, la croissance, les échecs… et tout ce qui vient avec quand tu bâtis quelque chose de pas ordinaire.

Si ça te tente d'écouter ça, c’est par ici 👇
🎥 YouTube : https://lnkd.in/eX2d2Dph
 🎧 Spotify : https://lnkd.in/e8CBPinh | 8 | 1 | 0 | 5mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.020Z |  | 2025-06-17T13:01:16.873Z | https://www.linkedin.com/feed/update/urn:li:activity:7340408750039572480/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7307785371604377601 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHP0LUXp8jAEg/feedshare-shrink_800/B4EZWj17gVHgAk-/0/1742210584056?e=1766620800&v=beta&t=mU9pB4VMn3DqN5XPpnhy33obawZAvuWYyoeZJ1cyXuE | Merci à Jonathan Parent pour cette invitation sur son podcast 1001 couleurs du LEANdership! 🎤

J’ai eu le plaisir de parler de mon parcours, entre échecs et apprentissages, qui m’a mené là où je suis aujourd’hui.

À écouter ici 👉
Spotify : https://lnkd.in/eEdxxUbS
Apple Podcast : https://lnkd.in/e-scfbtG | 20 | 1 | 0 | 8mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.021Z |  | 2025-03-18T15:30:04.677Z | https://www.linkedin.com/feed/update/urn:li:activity:7307360827190243329/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7300552699291332611 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF-kpwm680cgA/feedshare-shrink_800/B4EZVC2DkpG0Ag-/0/1740583225131?e=1766620800&v=beta&t=BANEdzOMfHBZ1rfG9a4QAO66EWXP7o_fPCGNd-0ifvk | La semaine dernière, j'ai eu le plaisir d’être conférencier au Sommet Expérience (CX, UX, UI) 2025! 🎤

J'ai eu l’opportunité de partager ma vision sur l'écoute de la satisfaction client en CX de demain : hyper-personnalisation des sondages, fermer la boucle de rétroaction et diversifier ses méthodes d'écoute client. 

Un immense merci à l’équipe Formations Infopresse, aux autres conférenciers et aux participants pour cette superbe expérience! 🙌

#CX #UX #UI #ExpérienceClient #Conférence #Innovation #CustomerSuccess | 82 | 5 | 0 | 9mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.022Z |  | 2025-02-26T16:30:01.221Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7285008247332208640 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGXESDOvZb4dQ/feedshare-shrink_800/B4EZRmMXtwHAAg-/0/1736881314389?e=1766620800&v=beta&t=H7uUs3vNOvQ6ny0wwsLScuP8GdZqF2KSiOyy4XfSBKk | Je suis très excité d'annoncer que je serai conférencier au Sommet Expérience (CX, UX, UI) 2025 organisé par Formations Infopresse

C’est un rendez-vous incontournable pour tous ceux qui s’intéressent de près ou de loin à l’expérience client et à l’expérience utilisateur. Au programme : des tendances pour 2025, des insights et des discussions inspirantes! 🙌

👉 Toutes les infos ici : https://lnkd.in/e-3Xf5pA

#CX #UX #UI #Conférence #SommetExperience #Infopresse | 137 | 8 | 3 | 10mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.023Z |  | 2025-01-14T19:01:55.072Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7275534054463004672 | Article |  |  | Je ne sais pas pour toi, mais moi je regarde toujours les reviews avant d’acheter. 

Et honnêtement, y’a rien de plus frustrant que de choisir une entreprise avec de bons avis et de réaliser qu’elle se fou complètement de ton expérience. Ça arrive encore bien trop souvent !

Chez InputKit, on veut changer ça. C’est pourquoi on a décidé de lancer le Prix Excellence Client. 

L'idée est de mettre en avant les entreprises qui, non seulement offrent une une expérience client bien au delà de la moyenne, mais qui savent aussi réagir rapidement et efficacement lorsqu’un client vit une expérience moins satisfaisante. | 30 | 2 | 0 | 11mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.024Z |  | 2024-12-19T15:34:51.470Z | https://www.inputkit.io/fr/blogue/prix-excellence-client/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7275530229832417280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a1757f87-8ffa-4fd1-b18f-d9600da0902c | https://media.licdn.com/dms/image/v2/D4E05AQGcQw-KavfDfw/videocover-high/B4EZPbMEmnHkBs-/0/1734549201697?e=1765778400&v=beta&t=Wz_BNJyN3QwaKzK0sOsQT7lhfPV3qWNYN36bYj-wSIw | Merci pour l'invite sur ton pod Francois Lanthier Nadeau, j'ai vraiment eu du fun! | 31 | 2 | 0 | 11mo | Post | Philippe Genois | https://www.linkedin.com/in/philippegenois | https://linkedin.com/in/philippegenois | 2025-12-08T05:01:00.024Z |  | 2024-12-19T15:19:39.607Z | https://www.linkedin.com/feed/update/urn:li:activity:7275498865720492032/ |  | 

---



---

# Philippe Genois
*InputKit*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 22 |

---

## 📚 Articles & Blog Posts

### [InputKit on Indie Hackers](https://www.indiehackers.com/product/inputkit/traffic)
*2024-06-17*
- Category: article

### [About InputKit - Inputkit](https://www.inputkit.io/en/about-inputkit/)
*2024-05-23*
- Category: article

### [Posts Archive - Inputkit](https://www.inputkit.io/en/blog/)
*2024-12-13*
- Category: blog

### [Customer dissatisfaction: How to properly manage a dissatisfied customer?](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/)
*2022-11-16*
- Category: blog

### [Improving the Customer Experience : 11 Reasons to Choose InputKit](https://www.inputkit.io/en/blog/improving-customer-experience-11-reasons-choose-inputkit/)
*2022-11-22*
- Category: blog

---

## 📖 Full Content (Scraped)

*10 articles scraped, 24,753 words total*

### InputKit on Indie Hackers
*797 words* | Source: **EXA** | [Link](https://www.indiehackers.com/product/inputkit/traffic)

InputKit - Indie Hackers

===============

Privacy Preference Center
-------------------------

When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer.

Accept All
### Manage Consent Preferences

#### Functionality

Always Active

Functionality cookies are used to keep our Site and Services working correctly, like showing you the right information for your selected location.

Cookies Details‎

#### Preferences

- [x] Preferences 

Preference cookies let us save your preferences and recognise you when you return to our Services.

Cookies Details‎

#### Advertising

- [x] Advertising 

Advertising cookies and similar technologies allow us to place targeted Stripe advertisements on other sites you visit and measure your engagement with those ads.

Cookies Details‎

#### Analytics

- [x] Analytics 

Analytics cookies help us understand how visitors interact with our Services, allowing us to analyse and improve our Services (also through third party analytics).

Cookies Details‎

### Performance Cookies

Clear

- [x] checkbox label label

Apply Cancel

Consent Leg.Interest

- [x] checkbox label label

- [x] checkbox label label

- [x] checkbox label label

*   View Cookies  

    *   Name cookie name  

Confirm My Choices

[![Image 6: Powered by Onetrust](https://cdn.cookielaw.org/logos/static/poweredBy_ot_logo.svg)](https://www.onetrust.com/products/cookie-consent/)

[Home](https://www.indiehackers.com/)[Starting Up](https://www.indiehackers.com/starting-up)[Tech](https://www.indiehackers.com/tech)[Creators](https://www.indiehackers.com/creators)[A.I.](https://www.indiehackers.com/tags/artificial-intelligence)[Lifestyle](https://www.indiehackers.com/lifestyle)[Money](https://www.indiehackers.com/money)

[Idea Board](https://www.indiehackers.com/idea-board)

[Vibe Coding Tools](https://www.indiehackers.com/vibe-coding-tools)

[Products](https://www.indiehackers.com/products)[Ideas DB](https://www.indiehackers.com/ideas)[Case Studies DB](https://www.indiehackers.com/stories)[Subscribe to IH+](https://www.indiehackers.com/plus)

[](https://www.indiehackers.com/plus)

[Starting Up](https://www.indiehackers.com/starting-up)[Tech](https://www.indiehackers.com/tech)[A.I.](https://www.indiehackers.com/tags/artificial-intelligence)[](https://www.indiehackers.com/)[Creators](https://www.indiehackers.com/creators)[Lifestyle](https://www.indiehackers.com/lifestyle)[Money](https://www.indiehackers.com/money)

[Join](https://www.indiehackers.com/sign-up)

![Image 7: Icon for InputKit](https://www.indiehackers.com/images/avatars/product-6.png)

[InputKit](https://inputkit.io/)
================================

Customer Feedback Software

[Visit Website](https://inputkit.io/)
We're working on InputKit to help business owners deal with an important but overlooked opportunity: after-sales follow-ups. It lets them easily follow up with their clients to get feedback, reviews, referrals and more.

[![Image 8: Avatar for user @jpfong](https://www.indiehackers.com/nonexistent-image.png) Philippe Genois Founder](https://www.indiehackers.com/PhilGenois?id=4rDqvGwjrJbtlvwD39i0f6eSKu62)

[![Image 9: Avatar for user @jpfong](https://www.indiehackers.com/nonexistent-image.png) jpfong Co-founder](https://www.indiehackers.com/jpfong?id=a41fyXB9IWS5QKoXU6XMUZauhF02)

[![Image 10: Icon for InputKit](https://www.indiehackers.com/images/avatars/product-6.png) InputKit Customer Feedback Software](https://www.indiehackers.com/product/inputkit)[Posts 5](https://www.indiehackers.com/product/inputkit)[Revenue $60K /mo](https://www.indiehackers.com/product/inputkit/revenue)[Website](https://inputkit.io/)[Facebook](https://www.facebook.com/inputkit/)

[![Image 11](https://storage.googleapis.com/indie-hackers.appspot.com/product-update-icons/stacked-books.svg)](https://www.indiehackers.com/product/inputkit/indie-hackers-interview-5cc84ec097)

[April 27, 2018](https://www.indiehackers.com/product/inputkit/indie-hackers-interview-5cc84ec097)[Indie Hackers interview](https://www.indiehackers.com/product/inputkit/indie-hackers-interview-5cc84ec097)

[![Image 12](https://580157013239-us-east-1-chromeless.s3.amazonaws.com/interview-shareables/f07b1b6edd.png) Quitting and Going Full Time to Grow My SaaS Company - Indie Hackers My name is Philippe Genois. I'm 23 years old and studying software engineering part-time while living in Montreal, Canada. For the past year and 

*[... truncated, 6,684 more characters]*

---

### About InputKit - Inputkit
*690 words* | Source: **EXA** | [Link](https://www.inputkit.io/en/about-inputkit/)

Who we are

InputKit is a SaaS solution used by more than 1500 companies around the world. The solution helps service companies improve their customer experience, employee experience and online reputation.

By using InputKit, these companies give themselves a way to stand out from the competition by creating a wow effect with their customers and employees.

![Image 1](https://www.inputkit.io/wp-content/uploads/2025/05/img-9053-aspect-ratio-1205-775-1.jpg)

### Our mission: Make the world a better place by helping companies deliver a better customer and employee experience.

![Image 2: InputKit](https://www.inputkit.io/wp-content/themes/reptile/static/img/img_stats_1.svg)![Image 3: InputKit](https://www.inputkit.io/wp-content/themes/reptile/static/img/img_stats_2.svg)

The values that guide InputKit on a daily basis
-----------------------------------------------

![Image 4](https://www.inputkit.io/wp-content/uploads/2022/09/nos_valeurs.webp)

![Image 5](https://www.inputkit.io/wp-content/uploads/2022/10/team-succes-client.png)

### Embodying leadership

Building relationships based on trust, respect, tolerance and assertiveness to embody leadership on a daily basis.

![Image 6](https://www.inputkit.io/wp-content/uploads/2022/10/support-client.png)

### Being transparent

Communicating openly and honestly by promoting dialogue and sharing, is not just a nice slogan, we make sure that transparency covers each of our interactions with our employees, customers or all other stakeholders.

![Image 7](https://www.inputkit.io/wp-content/uploads/2022/10/evaluer-bien-etre-employes.png)

### Being accountable

Taking ownership, focusing on performance, delivering quality, aiming for efficiency and excellence is of paramount importance to us!

![Image 8](https://www.inputkit.io/wp-content/uploads/2022/10/flexibilite-travail-famille.png)

### Incorporating Humility

Humility is of essence, humility to accept others (accept our differences of opinion, status, our cultural and social differences) and accept oneself (recognize one’s errors, wrongs, areas for improvement, ignorance seeking to constantly improve).

![Image 9](https://www.inputkit.io/wp-content/uploads/2022/10/team-building.png)

### Working as a Team

Demonstrate altruism and solidarity to favor collaboration in an environment where mutual aid, motivation and success are essential!

![Image 10: InputKit](https://www.inputkit.io/wp-content/themes/reptile/static/img/separator_2.svg)

The story behind our company

InputKit, a growing company InputKit is a web-based customer experience solution that was founded in 2017 by Philippe Genois and co-founded by Jean-Philippe Fong. Today, InputKit is used by more than 1500 customers around the world. The whole team is very proud of this dazzling success which is the result of great collaboration between our different teams!

![Image 11](https://www.inputkit.io/wp-content/uploads/2025/05/InputKit_visuelCTA-blogue-2-1-aspect-ratio-1205-775-1.webp)

![Image 12: InputKit](https://www.inputkit.io/wp-content/themes/reptile/static/img/separator_1.svg)

![Image 13](https://www.inputkit.io/wp-content/uploads/2024/05/1329-inputkit-pitch-4.jpg)

As seen on "Dans l'oeil du dragon"
----------------------------------

Featured on the acclaimed show “Dans l’oeil du dragon”, InputKit made a notable appearance that left a lasting impact. Our pitch captured the attention of both the dragons and the audience, showcasing our innovative solutions and the passionate team behind them.

This exposure significantly boosted our visibility and credibility, accelerating our journey towards becoming a key player in our industry. Watch our memorable moment on the show below :

Discover our team of experts
----------------------------

![Image 14](https://www.inputkit.io/wp-content/uploads/2023/02/Philippe-2-site-web-1-aspect-ratio-755-420-1.webp)

### Philippe Genois

CEO and co-founder

![Image 15](https://www.inputkit.io/wp-content/uploads/2022/09/JPhong.webp)

### Jean-Philippe Fong

Chief Technology Officer and co-founder

![Image 16](https://www.inputkit.io/wp-content/uploads/2022/09/Arthur.webp)

### Arthur Delbecque

Sales and Business Development Specialist

![Image 17](https://www.inputkit.io/wp-content/uploads/2022/09/Mouna.webp)

### Mouna Hilal

Commercial director and integrator

![Image 18](https://www.inputkit.io/wp-content/uploads/2024/05/aminata-sene-aspect-ratio-755-420-2.jpg)

### Aminata Sene

Outbound Sales Development Representative

![Image 19](https://www.inputkit.io/wp-content/uploads/2024/05/annema5-aspect-ratio-755-420-1.jpg)

### Anne-Marie Roy

Human resources and operations support coordinator

What benefits can InputKit bring to you?
----------------------------------------

![Image 20](https://www.inputkit.io/wp-content/uploads/2022/09/a_propos_benefices_inputkit.webp)

![Image 21](https://www.inputkit.io/wp-content/uploads/2022/09/fidelisez-client.png)

### Improve your customer experience based on relevant feedback

*[... truncated, 2,108 more characters]*

---

### Posts Archive - Inputkit
*244 words* | Source: **EXA** | [Link](https://www.inputkit.io/en/blog/)

![Image 1: InputKit](https://www.inputkit.io/wp-content/themes/reptile/static/img/bg_blog.svg)

Our Customer Experience articles
--------------------------------

[![Image 2](https://www.inputkit.io/wp-content/uploads/2023/02/Sadapter-aux-besoins-des-clients-une-formule-gagnante.webp)](https://www.inputkit.io/en/blog/adapting-customers-needs/)

[![Image 3](https://www.inputkit.io/wp-content/uploads/2023/02/10_benefices_sondages_satisfaction.webp)](https://www.inputkit.io/en/blog/10-benefits-related-best-customer-satisfaction-survey/)

![Image 4](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 5](https://www.inputkit.io/wp-content/uploads/2023/02/demander-avis-client-via-email.webp)](https://www.inputkit.io/en/blog/how-get-feedback-customers-email/)

![Image 6](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 7](https://www.inputkit.io/wp-content/uploads/2023/01/6-manieres-dont-lexperience-employe-impacte-lexperience-client.webp)](https://www.inputkit.io/en/blog/improve-customer-experience-with-employee-experience/)

![Image 8](https://secure.gravatar.com/avatar/cabb6aa63b31c523a46d922291e01812?s=96&d=mm&r=g)

[![Image 9](https://www.inputkit.io/wp-content/uploads/2023/01/image_article_mythes.webp)](https://www.inputkit.io/en/blog/customer-experience-optimization-7-myths-deconstruct/)

![Image 10](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 11](https://www.inputkit.io/wp-content/uploads/2022/12/parcours_client_image_article.webp)](https://www.inputkit.io/en/blog/all-about-customer-journey-steps-examples/)

![Image 12](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 13](https://www.inputkit.io/wp-content/uploads/2022/11/Comment-sexcuser-aupres-dun-client-6-conseils-exemples.webp)](https://www.inputkit.io/en/blog/how-apologize-client-6-key-tips/)

![Image 14](https://secure.gravatar.com/avatar/cabb6aa63b31c523a46d922291e01812?s=96&d=mm&r=g)

[![Image 15](https://www.inputkit.io/wp-content/uploads/2022/11/image-article-remercier-client.jpg)](https://www.inputkit.io/en/blog/9-examples-thank-you-notes-clients/)

![Image 16](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

Our articles related to the employee experience
-----------------------------------------------

[![Image 17](https://www.inputkit.io/wp-content/uploads/2023/02/grande_resignation.webp)](https://www.inputkit.io/en/blog/how-deal-great-resignation-become-better-employer/)

![Image 18](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 19](https://www.inputkit.io/wp-content/uploads/2023/02/Comprendre-le-calcul-du-taux-de-roulement.webp)](https://www.inputkit.io/en/blog/understanding-employee-turnover-rate-formula/)

![Image 20](https://secure.gravatar.com/avatar/cabb6aa63b31c523a46d922291e01812?s=96&d=mm&r=g)

[![Image 21](https://www.inputkit.io/wp-content/uploads/2023/02/image_article_culture_organisationnelle_innovation.webp)](https://www.inputkit.io/en/blog/exploring-link-between-organizational-culture-innovation/)

![Image 22](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 23](https://www.inputkit.io/wp-content/uploads/2023/02/Onboarding-dun-nouvel-employe-7-incontournables.webp)](https://www.inputkit.io/en/blog/how-to-onboard-new-employee-7-essentials/)

![Image 24](https://secure.gravatar.com/avatar/cabb6aa63b31c523a46d922291e01812?s=96&d=mm&r=g)

[![Image 25](https://www.inputkit.io/wp-content/uploads/2023/01/image-article-acitivites-employes.webp)](https://www.inputkit.io/en/blog/7-fun-engaging-ideas-workplace-social-activities/)

![Image 26](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 27](https://www.inputkit.io/wp-content/uploads/2023/01/tendacances_experience_employe_2023_image_article.webp)](https://www.inputkit.io/en/blog/employee-experience-trends-follow-2023/)

![Image 28](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 29](https://www.inputkit.io/wp-content/uploads/2023/01/rencontres_individuelles_employes_image_article-1.webp)](https://www.inputkit.io/en/blog/importance-1-on-1-meetings-with-employees/)

![Image 30](https://secure.gravatar.com/avatar/dbae14cd50ad8821ecdab7c56c8a2f08?s=96&d=mm&r=g)

[![Image 31](https://www.inputkit.io/wp-content/uploads/2022/12/remerciement_employes_image_article.webp)](https://www.inputkit.io/en/blog/employee-thank-you-messages-good-pratices-7-examples/)

![Image 32](https://secure.gravatar.com/avatar/cabb6aa63b31c523a46d922291e01812?s=96&d=mm&r=g)

Our articles related to online reputation
-----------------------------------------

[![Image 33](https://www.inputkit.io/wp-content/uploads/2022/09/Comment-obtenir-mon-lien-pour-laisser-un-avis-Google.webp)](https://www.inputkit.io/en/blog/how-to-get-link-to-

*[... truncated, 6,308 more characters]*

---

### Customer dissatisfaction: How to properly manage a dissatisfied customer?
*1,883 words* | Source: **EXA** | [Link](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/)

Customer dissatisfaction: How to properly manage a dissatisfied customer? - Inputkit

===============

Manage cookie consent

To provide the best experiences, we use technologies such as cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Failure to consent or withdrawing consent may negatively impact certain features and functions.

Functional- [x] Functional  Always active 

The storage or technical access is strictly necessary for the purpose of legitimate interest of allowing the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of communication on an electronic communications network.

Préférences- [x] Préférences 

Le stockage ou l’accès technique est nécessaire dans la finalité d’intérêt légitime de stocker des préférences qui ne sont pas demandées par l’abonné ou l’utilisateur.

Statistiques- [x] Statistiques 

Technical storage or access that is used exclusively for statistical purposes.Le stockage ou l’accès technique qui est utilisé exclusivement dans des finalités statistiques anonymes. En l’absence d’une assignation à comparaître, d’une conformité volontaire de la part de votre fournisseur d’accès à internet ou d’enregistrements supplémentaires provenant d’une tierce partie, les informations stockées ou extraites à cette seule fin ne peuvent généralement pas être utilisées pour vous identifier.

Marketing- [x] Marketing 

Storage or technical access is necessary to create user profiles in order to send advertisements, or to track the user across a website or across multiple websites with similar marketing purposes.

[Manage options](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)[Manage services](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)[Manage {vendor_count} vendors](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

Accept Refuse Preferences Save preferences[Preferences](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)

[{title}](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)[{title}](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)[{title}](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#)

Manage cookie consent

To provide the best experiences, we use technologies such as cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Failure to consent or withdrawing consent may negatively impact certain features and functions.

Functional- [x] Functional  Always active 

The storage or technical access is strictly necessary for the purpose of legitimate interest of allowing the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of communication on an electronic communications network.

Préférences- [x] Préférences 

Le stockage ou l’accès technique est nécessaire dans la finalité d’intérêt légitime de stocker des préférences qui ne sont pas demandées par l’abonné ou l’utilisateur.

Statistiques- [x] Statistiques 

Technical storage or access that is used exclusively for statistical purposes.Le stockage ou l’accès technique qui est utilisé exclusivement dans des finalités statistiques anonymes. En l’absence d’une assignation à comparaître, d’une conformité volontaire de la part de votre fournisseur d’accès à internet ou d’enregistrements supplémentaires provenant d’une tierce partie, les informations stockées ou extraites à cette seule fin ne peuvent généralement pas être utilisées pour vous identifier.

Marketing- [x] Marketing 

Storage or technical access is necessary to create user profiles in order to send advertisements, or to track the user across a website or across multiple websites with similar marketing purposes.

[Manage options](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#cmplz-manage-consent-container)[Manage services](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#cmplz-cookies-overview)[Manage {vendor_count} vendors](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#cmplz-tcf-wrapper)[Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

Accept Refuse Preferences Save preferences[Preferences](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/#cmplz-manage-consent-container)

[](https://www.inputkit.io/en/blog/how-to-manage-customer-dissatisfaction-properly/)[Privacy Statement](https://www.inputkit.io/en/privacy/)[{title}](https://www.in

*[... truncated, 20,539 more characters]*

---

### Improving the Customer Experience : 11 Reasons to Choose InputKit
*2,563 words* | Source: **EXA** | [Link](https://www.inputkit.io/en/blog/improving-customer-experience-11-reasons-choose-inputkit/)

Improving the customer experience is a hot topic for years to come. Businesses are becoming increasingly aware of the importance of**customer satisfaction**, as it greatly contributes to customer loyalty and is an excellent long-term investment. However, with the growth of web platforms usage, customers are now much more critical of the customer experience. They are used to a**personalized**and**instant**service that can be difficult to replicate within your company.

### [Download now : -> FREE FRENCH EBOOK All About Customer Satisfaction and Net Promoter Score](https://www.inputkit.io/en/inputkit-ebook/why-how-monitor-nps/)

How can InputKit’s solution enable you to meet new customer standards so you can keep improving the customer experience? Here are**eleven ways**our solution can meet your customer experience needs to provide your customers with the service they deserve.

1. InputKit allows you to save time by automating your customer satisfaction follow-ups
---------------------------------------------------------------------------------------

There is no denying that in this labor shortage, it is a challenge to provide a flawless customer experience if there are not enough employees. We want to avoid the lack of employees having a**negative impact**on improving the customer experience and the customer service in your business. How can you keep improving the customer experience if you don’t have the resources to optimize your follow-up and task management at the heart of your business? Make sure you have the right tools like[**InputKit’s customer experience assessment and improvement solution**](https://www.inputkit.io/en/produits/customer-experience-management-software/)to help you maximize customer satisfaction!

With our solution, you will be able to send a fully personalized automated survey to your customer at the right time after a service is rendered. With a response rate of**45% by email**and**57% by text**, our**personalized**and**easy-to-use**surveys will give you a true picture of the satisfaction of your customers in-store. This way, you will be able to adapt your services to the needs of your customers while**avoiding several hours of management**to concentrate on more important tasks, like improving the customer experience of your business!

Take for example the testimony of Alain Gauthier, Communications and Customer Service Manager at Point S – Pneus Carignan. As part of[our case study](https://www.inputkit.io/en/portfolio/point-s-pneus-carignan-meilleure-experience-client-inputkit/), Mr.Gauthier said: “_Before InputKit, I had to spend several hours on the phone to get feedback from clients. Now I can analyze customer needs with automated questionnaires in minutes. It saves me about two hours of monitoring and management per day._”

Improving the customer experience with InputKit’s automation technologies saves**40 hours of management**and follow-up time per month! It’s impressive, isn’t it? In addition, sending out automated surveys also allowed her to adapt her services to the needs of her clients, which**increased his client satisfaction rate to 96%**. This shows how the automation of customer satisfaction tracking via our solution can help you, so you can keep improving the customer experience!

![Image 1: How InputKit Can Help You](https://www.inputkit.io/wp-content/uploads/2021/12/How-InputKit-can-help-you.webp)

2. InputKit allows you to detect dissatisfied customers before it is too late
-----------------------------------------------------------------------------

Of course, having good dissatisfaction management is a major issue in improving the customer experience of your business. However, there are**several myths about customer dissatisfaction**. Some companies believe that dissatisfied customers will necessarily communicate their dissatisfaction on their own. Others believe that it is impossible to recover an unsatisfied customer, and that as a result, it is not worth contacting them again.

However, according to[Solutions & Co.](https://solutionsandco.com/blogue/le-cout-d-un-client-perdu),**96% of dissatisfied customers will never tell you about their disappointment**: they will turn to one of your competitors and leave your company without telling you the source of their dissatisfaction. In addition, their**negative word-of-mouth**may harm your brand image and make it difficult to get new customers. In that vein, it is important to target the reason for your customers’ dissatisfaction as quickly as possible. However, how do you do this when your clients expect[a response**in less than 24 hours?**](https://blog.hubspot.com/service/social-media-response-time)

Before it’s too late, InputKit can help you optimize the**retention**of your dissatisfied customers while improving the customer experience. Through**automated satisfaction surveys**, you will be able to ask your customers about their satisfaction with the customer experience they have to ensure the**quality**of th

*[... truncated, 15,182 more characters]*

---

### Le podcast qui marche
*1,896 words* | Source: **GOOGLE** | [Link](https://podcasts.apple.com/fr/podcast/le-podcast-qui-marche/id1554914047)

Le podcast qui marche - Émission - Apple Podcasts

===============

[](https://podcasts.apple.com/fr/new)

*   [Accueil](https://podcasts.apple.com/fr/home)
*   [Nouveautés](https://podcasts.apple.com/fr/new)
*   [Classements](https://podcasts.apple.com/fr/charts)
*   [Rechercher](https://podcasts.apple.com/fr/search)

Ouvrir dans Podcasts

![Image 2: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif)

Le podcast qui marche
=====================

Mathieu Chevalier

*    0,0 (0) 
*   ENTREPRENARIAT

Le podcast qui marche est un balado audio pour entrepreneur·e·s dans lequel l'animateur et photographe Mathieu Chevalier prend une marche avec des entrepreneur·e·s et professionnel.le.s qui viennent partager leçons de vie, trucs, astuces et conseils, afin de t'aider à tirer ton épingle du jeu dans le monde merveilleux qu'est l'entrepreneuriat!

PLUS

Le podcast qui marche
=====================

Le podcast qui marche est un balado audio pour entrepreneur·e·s dans lequel l'animateur et photographe Mathieu Chevalier prend une marche avec des entrepreneur·e·s et professionnel.le.s qui viennent partager leçons de vie, trucs, astuces et conseils, afin de t'aider à tirer ton épingle du jeu dans le monde merveilleux qu'est l'entrepreneuriat!

 Dernier épisode 

Suivre

Épisodes
--------

1.   [![Image 3: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 22/08/2023 ### Philippe Genois - L'importance d'obtenir du feedback de ta clientèle Le feedback de ta clientèle. Ressource précieuse pour t'aider à améliorer tes produits et services! L'entrepreneur en série Philippe Genois partage plusieurs perles de sagesse lors de cette belle marche. Bonne écoute! Pour en savoir plus: https://www.inputkit.io/fr/ 23 min](https://podcasts.apple.com/fr/podcast/philippe-genois-limportance-dobtenir-du-feedback-de/id1554914047?i=1000625267171) 
2.   [![Image 4: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 21/07/2023 ### Francesca Bourgault - Écrire pour mieux faire entendre sa voix Écrire pour vendre, écrire pour montrer au monde son authenticité, sa voix unique, sa raison d'être entrepreneuriale. C'est dont la grande copywriter, stratège marketing et formatrice Francesca Bourgault et moi avons discuté lors de cette marche. Bonne écoute! Pour en savoir plus: https://agilomedia.com/ 15 min](https://podcasts.apple.com/fr/podcast/francesca-bourgault-%C3%A9crire-pour-mieux-faire-entendre/id1554914047?i=1000621911259) 
3.   [![Image 5: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 13/07/2023 ### Alain Roy - La relation: élément crucial du récit de de ton entreprise En tant qu'entrepreneur.e, connais-tu ta mission, vision, valeur? J'ai été prendre une marche avec Alain Roy, stratège – identité d’entreprise, et il nous explique comment bâtir son récit et prendre soin de la relation avec sa clientèle. Bonne écoute! Pour en savoir plus: https://www.royidentite.com/ 35 min](https://podcasts.apple.com/fr/podcast/alain-roy-la-relation-%C3%A9l%C3%A9ment-crucial-du-r%C3%A9cit-de/id1554914047?i=1000621060662) 
4.   [![Image 6: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 06/06/2023 ### Jorj Helou - Comment donner et recevoir du feedback Le feedback c’est le «retour nourrissant» et il est d’une importance capitale pour l’évolution de la collaboration professionnelle. J'ai été prendre une marche avec Jorj Hélou, formateur et coach en leadership, et il nous explique comment bien développer ce précieux outil qu'est le feedback. Bonne écoute! Pour en savoir plus: https://leaderzone.ca/ 25 min](https://podcasts.apple.com/fr/podcast/jorj-helou-comment-donner-et-recevoir-du-feedback/id1554914047?i=1000615893247) 
5.   [![Image 7: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 30/05/2023 ### Karine Cloutier - Créer sa vie de rêve par le mouvement Le mouvement, ce bel outil qui permet de grandir en sortant de sa zone de confort! J'ai été prendre une marche avec Karine Cloutier, coach de joie, prof de yoga, maître de l'art de mouvement et co-créARTiste de sortie dde zone. Bonne écoute! Pour en savoir plus: https://www.karinecloutier.com/ 29 min](https://podcasts.apple.com/fr/podcast/karine-cloutier-cr%C3%A9er-sa-vie-de-r%C3%AAve-par-le-mouvement/id1554914047?i=1000614925347) 
6.   [![Image 8: Claudia Baillargeon - Nomade dans l'âme](https://podcasts.apple.com/assets/artwork/1x1.gif) 23/05/2023 ### Patrick Salomon - La vision d'un Ninja Warrior Qu'est-ce que ça prend sur le plan mental pour faire aboutir un projet entrepreneurial après plusieurs années et un parcours jonché d'obstacles? J'ai été prendre une marche avec Patrick Salomon, qui a ouvert le premier centre de parkour et Ninja Warrior à Montréal, actn3. Il nous parle de sa vision et de l'aboutissement de ce grand projet. Bonne écoute! Pour en sav

*[... truncated, 23,572 more characters]*

---

### Le podcast qui marche | Philippe Genois - L'importance d'obtenir du feedback de ta clientèle | BaladoQuebec.CA
*623 words* | Source: **GOOGLE** | [Link](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele)

BaladoQuebec | BaladoQuebec.CA | Philippe Genois - L'importance d'obtenir du feedback de ta clientèle 

===============

[![Image 3: Logo](https://static.baladoquebec.ca/img/logosquare_20.png)](https://baladoquebec.ca/)

[Inscrire votre Podcast](https://baladoquebec.ca/repertoire/ajout)

[Hébergement Podcast](https://baladoquebec.ca/hebergement)

[](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele#)

[Light](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele#)

[Dark](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele#)

[System](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele#)

[Connexion](https://baladoquebec.ca/login)

[![Image 4: BaladoQuebec](https://static.baladoquebec.ca/img/logo_baladoquebec.png)![Image 5: Logo](https://static.baladoquebec.ca/img/logosquare_20.png)](https://baladoquebec.ca/)

[Accueil](https://baladoquebec.ca/)

[Podcast du Québec](https://baladoquebec.ca/repertoire)

[Tous les Podcasts (4048)](https://baladoquebec.ca/repertoire)

[Varmédia (17)](https://baladoquebec.ca/repertoire/varmedia)

[Podcasse.com (35)](https://baladoquebec.ca/repertoire/podcasse)

[Podcasteur (4)](https://baladoquebec.ca/repertoire/podcasteur)

[CISM 89,3 FM (12)](https://baladoquebec.ca/repertoire/cism)

[CHOQ.CA (40)](https://baladoquebec.ca/repertoire/choq)

[Yoink! Media (5)](https://baladoquebec.ca/repertoire/yoinkmedia)

[Puissance Maximale (6)](https://baladoquebec.ca/repertoire/puissance-maximale)

[Première Plus (29)](https://baladoquebec.ca/repertoire/premiereplus)

[Magnéto (5)](https://baladoquebec.ca/repertoire/magneto)

[QUB Radio (17)](https://baladoquebec.ca/repertoire/qub)

[CJMD 96,9 FM (30)](https://baladoquebec.ca/repertoire/cjmd)

[Romeo Podcasts (6)](https://baladoquebec.ca/repertoire/romeo-podcast)

[A la trois Média (8)](https://baladoquebec.ca/repertoire/alatroismedia)

Catégories

[Arts (199)](https://baladoquebec.ca/repertoire/arts)

[Tous dans Arts (199)](https://baladoquebec.ca/repertoire/arts)

[Alimentation (39)](https://baladoquebec.ca/repertoire/alimentation)

[Arts du spectacle (55)](https://baladoquebec.ca/repertoire/arts-spectacle)

[Arts visuels (28)](https://baladoquebec.ca/repertoire/arts-visuel)

[Conception (13)](https://baladoquebec.ca/repertoire/conception)

[Livres (40)](https://baladoquebec.ca/repertoire/livres)

[Mode et beauté (12)](https://baladoquebec.ca/repertoire/mode-beaute)

[Comédie (229)](https://baladoquebec.ca/repertoire/comedie)

[Tous dans Comédie (229)](https://baladoquebec.ca/repertoire/comedie)

[Improvisation (26)](https://baladoquebec.ca/repertoire/improvisations)

[Interviews de comédiens (22)](https://baladoquebec.ca/repertoire/interviews-comediens)

[Stand-Up (18)](https://baladoquebec.ca/repertoire/stand-up)

[Culture et société (633)](https://baladoquebec.ca/repertoire/culture-societe)

[Tous dans Culture et société (633)](https://baladoquebec.ca/repertoire/culture-societe)

[Documentaire (90)](https://baladoquebec.ca/repertoire/documentaire)

[Journaux personnels (31)](https://baladoquebec.ca/repertoire/journaux-personnels)

[Lieux et voyages (34)](https://baladoquebec.ca/repertoire/lieux-voyages)

[Philosophie (21)](https://baladoquebec.ca/repertoire/philosophie)

[Relations (56)](https://baladoquebec.ca/repertoire/relations)

[Éducation (284)](https://baladoquebec.ca/repertoire/education)

[Tous dans Éducation (284)](https://baladoquebec.ca/repertoire/education)

[Amélioration personnelle (64)](https://baladoquebec.ca/repertoire/amelioration-personnelle)

[Apprentissage des langues (11)](https://baladoquebec.ca/repertoire/apprentissage-langues)

[Comment (14)](https://baladoquebec.ca/repertoire/comment)

[Cours (14)](https://baladoquebec.ca/repertoire/cours)

[Enfants et Famille (60)](https://baladoquebec.ca/repertoire/famille)

[Tous dans Enfants et Famille (60)](https://baladoquebec.ca/repertoire/famille)

[Animaux de compagnie et animaux (5)](https://baladoquebec.ca/repertoire/animaux-compagnie)

[Histoires pour les enfants (3)](https://baladoquebec.ca/repertoire/histoire-pour-enfants)

[L'éducation des enfants (20)](https://baladoquebec.ca/repertoire/education-enfants)

[Parentalité (34)](https://baladoquebec.ca/repertoire/parentalite)

[Entreprises (222)](https://baladoquebec.ca/repertoire/entreprises)

[Tous dans Entreprises (222)](https://baladoquebec.ca/repertoire/entreprises)

[Carrières (38)](https://baladoquebec.ca/repertoire/carrieres)

[Gestion (36)](https://baladoquebec.ca/repertoire/gestion)

[Investissements (21)](https://baladoquebec.ca/repertoire/investissements)

[L'esprit d'entreprise (37)](https://baladoquebec.ca/repertoire/esprit-entreprise)

[Marketing (29)](https://baladoquebec.ca/repertoire/marketing)

[Fiction (18)](https://baladoquebec.ca/repertoire/fiction)

[Tous dans Fiction (1

*[... truncated, 9,167 more characters]*

---

### Dans la jungle des affaires
*1,970 words* | Source: **GOOGLE** | [Link](https://open.spotify.com/show/2kacq25PB8xC34eNfjYGLk)

![Image 1](https://i.scdn.co/image/ab67656300005f1f2f10a1eeb70f9f24125e2f51)

Podcast Réjean Gauthier

All Episodes
------------

*   Issu de notre série enregistrée à Lavaltrie, l’épisode #809 met en avant → 𝐉𝐚𝐜𝐪𝐮𝐞𝐬 𝐀𝐮𝐛𝐢𝐧, conférencier, auteur et 𝗮𝗰𝗰𝗼𝗺𝗽𝗮𝗴𝗻𝗮𝘁𝗲𝘂𝗿 𝗲𝗻 𝗱𝗲́𝘃𝗲𝗹𝗼𝗽𝗽𝗲𝗺𝗲𝗻𝘁 𝗵𝘂𝗺𝗮𝗶𝗻..​Jacques accompagne des dirigeants, gestionnaires et professionnels qui veulent mieux comprendre leurs comportements, ajuster leurs habitudes et retrouver une cohérence durable entre leur rôle, leurs décisions et leur réalité personnelle.​Son expertise repose sur un parcours où il a littéralement payé le prix de chaque enseignement qu’il partage.​🏃🏻‍♂️ Entre 2009 et 2011, il est passé de 415 livres à 190 livres sans chirurgie, un changement qu’il maintient depuis plus de 16 ans. En 2013, il a vécu une paralysie liée au CIDP et, en 2025, il a survécu à trois arrêts cardiaques.​Ces événements lui permettent d’expliquer avec précision comment la pression, les excès, les mécanismes de protection et le désalignement personnel fragilisent un individu, même performant et influencent directement la stabilité de son leadership.​📄 𝗖𝗼𝗻𝘀𝘂𝗹𝘁𝗲𝗿 𝘀𝗼𝗻 𝗽𝗿𝗼𝗳𝗶𝗹 𝘀𝘂𝗿 𝗻𝗼𝘁𝗿𝗲 𝘀𝗶𝘁𝗲 𝘄𝗲𝗯 :​Aujourd’hui, Jacques aide les leaders à :⦿ repérer les comportements qui nuisent à leur crédibilité ;⦿ modifier les habitudes qui affectent leur santé, leur énergie et leur jugement ;⦿ développer une constance durable ;⦿ réaligner leurs intentions et leurs actions.​🎤 Ses 𝗰𝗼𝗻𝗳𝗲́𝗿𝗲𝗻𝗰𝗲𝘀 𝗲𝘁 𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻𝘀, axées sur l’action, la responsabilisation et la conscience, créent des déclics et entraînent des changements mesurables.​📕 𝗔𝘂𝘁𝗲𝘂𝗿 de Pour une fois, va jusqu’au bout ! Il accompagne les organisations et les individus à reprendre le pouvoir sur leur énergie, leur santé et leur mission de vie.​𝐂𝐨𝐨𝐫𝐝𝐨𝐧𝐧𝐞́𝐞𝐬 𝐝𝐞 𝐉𝐚𝐜𝐪𝐮𝐞𝐬 𝐀𝐮𝐛𝐢𝐧 :​📞 514 924 8001📧 jacques@jacquesaubin.com🌐 jacquesaubin.com💼 Profil LinkedIn ​📕 Acheter son livre "Pour une fois, va jusqu’au bout !" ​Merci à 𝗗𝗲𝘃𝗼𝗹𝘂𝘁𝗶𝗼𝗻𝘀, qui nous a accueillis pour ces deux journées de tournage. ​Un gros merci aussi à notre partenaire 𝗔𝗻𝗶𝗺𝗮𝗹𝗲𝗿𝗶𝗲 𝗟𝗲 𝗧𝗼𝘂𝗰𝗮𝗻 pour leur précieuse commandite. ​​⭐ Coanimatrice — 𝗟𝗮𝘂𝗿𝗶𝗲 𝗖𝗿𝗼𝘁𝗲𝗮𝘂, 𝗖𝗥𝗜𝗔▸ Relations humaines du travail • Consultante | Enquêtrice | Médiatrice: https://www.lauriecroteau.ca/​🎙️ Animateur — Réjean Gauthier↳ Pour participer à l’émission Hébergé par Acast. Visitez acast.com/privacy pour plus d'informations.

Today

51 min 21 sec  
*   Le mois dernier, l’équipe du podcast Dans la jungle des affaires s’est déplacée à Lavaltrie pour enregistrer huit épisodes avec des entrepreneurs passionnés de la région.Voici à qui vous allez être présenté dans le 810e épisode : 𝐌𝐚𝐫𝐢𝐞-𝐂𝐚𝐫𝐨𝐥𝐢𝐧𝐞 𝐀𝐮𝐝𝐞𝐭, co-propriétaire de l’𝐀𝐧𝐢𝐦𝐚𝐥𝐞𝐫𝐢𝐞 𝐋𝐞 𝐓𝐨𝐮𝐜𝐚𝐧 à Lavaltrie.Un commerce familial ouvert avec son père en 2011.► 𝗣𝗼𝘂𝗿 𝘃𝗶𝘀𝗶𝗼𝗻𝗻𝗲𝗿 𝗹’𝗲́𝗽𝗶𝘀𝗼𝗱𝗲 𝗰𝗼𝗺𝗽𝗹𝗲𝘁Ancienne travailleuse de rue, Marie-Caroline a gardé ce réflexe d’écouter, d’accompagner et de répondre aux vraies questions, sans jugement. Ce même esprit se retrouve maintenant dans son animalerie. Dans cet épisode, elle raconte son quotidien sur le plancher, sa façon d’aider les gens avec leurs animaux, ses conseils pour la nourriture,les allergies et les comportements.Elle parle aussi des rescapés, des chats errants qu’elle réhabilite, de la dynamique familiale derrière le magasin et de ce qu’elle veut préserver dans le commerce de proximité. C’est une propriétaire qui connaît ses clients autant que leurs animaux.Au Toucan, chaque animal est suivi : dossiers, réactions, ajustements. Rien n’est laissé au hasard.📎 Consulter son profil sur notre site web :𝐂𝐨𝐨𝐫𝐝𝐨𝐧𝐧𝐞́𝐞𝐬 𝐝𝐞 𝐥’𝐀𝐧𝐢𝐦𝐚𝐥𝐞𝐫𝐢𝐞 𝐋𝐞 𝐓𝐨𝐮𝐜𝐚𝐧 :📞 450 586 0654📧 animalerie.letoucan@videotron.ca📍89-d Chem. de Lavaltrie, Lavaltrie, QC J5T 3E2🙏🏼 Merci à 𝗗𝗲𝘃𝗼𝗹𝘂𝘁𝗶𝗼𝗻𝘀, qui nous a accueillis pour ces deux journées de tournage. Un gros merci aussi à notre partenaire 𝐀𝐧𝐢𝐦𝐚𝐥𝐞𝐫𝐢𝐞 𝐋𝐞 𝐓𝐨𝐮𝐜𝐚𝐧 pour leur précieuse commandite. ⭐ Coanimatrice — 𝗟𝗮𝘂𝗿𝗶𝗲 𝗖𝗿𝗼𝘁𝗲𝗮𝘂, CRIA▸ Relations humaines du travail • Consultante | Enquêtrice | Médiatrice🎙️ Animateur – Réjean Gauthier ↳ Pour participer à l’émission Hébergé par Acast. Visitez acast.com/privacy pour plus d'informations.

Nov 25

55 min 19 sec  
*   🦁 Bienvenue Dans la Jungle des affaires — un accès direct à l’expérience, aux stratégies et aux parcours des entrepreneurs du Québec.🎧 Notre invité du jour :𝐃𝐚𝐧𝐢𝐞𝐥 𝐋𝐚𝐧𝐠𝐥𝐨𝐢𝐬| 𝐏𝐫𝐞́𝐬𝐢𝐝𝐞𝐧𝐭 - 𝐀𝐬𝐬𝐨𝐜𝐢𝐞́ 𝐟𝐨𝐧𝐝𝐚𝐭𝐞𝐮𝐫 –𝐆𝐫𝐨𝐮𝐩𝐞 𝐋𝐆𝐗(Stratégies PME | Sommet TECH RH | Sommet Formation | AKWI | Boomrank | TOP Experts PME)Depuis plus de 30 ans, Daniel Langlois œuvre à créer des espaces où les dirigeants de PME peuvent apprendre, échanger et grandir.Son parcours en affaires l’a mené à fonder le 𝐆𝐫𝐨𝐮𝐩𝐞 𝐋𝐆𝐗, une organisation qui regroupe plusieurs projets conçus pour soutenir la performance des entreprises québécoises.Au cœur de cet écosystème, on retrouve 𝐒𝐭𝐫𝐚𝐭𝐞́𝐠𝐢𝐞𝐬 𝐏𝐌𝐄, un événement d’envergure qui réunit chaque année plus de 5 500 dirigeants et 500 experts.L’objectif est simple : permettre aux entrepreneurs de découvrir des solutions concrètes, d’assister à des conférences

*[... truncated, 9,836 more characters]*

---

### Alexandra Lepage, Fondatrice de ALDI
*13,440 words* | Source: **GOOGLE** | [Link](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs/alexandra-lepage-fondatrice-de-aldi)

Alexandra Lepage, Fondatrice de ALDI

===============

![Image 1](https://www.danslajungledesaffaires.ca/public/media/1d367e28-5edf-11ee-9bd8-06df6d61f0da.png)

[](https://www.google.com/maps/place/+++++)

[](tel: "Téléphone")

Le réseau
*   [Secteurs d'activité](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs "Secteurs d'activité")

[Partenaires](https://www.danslajungledesaffaires.ca/fr/partenaires "Partenaires")[Ambassadeurs](https://www.danslajungledesaffaires.ca/fr/ambassadeurs-dans-la-jungle-des-affaires "Ambassadeurs")

[![Image 2](https://www.danslajungledesaffaires.ca/public/media/1d367e28-5edf-11ee-9bd8-06df6d61f0da.png)](https://www.danslajungledesaffaires.ca/fr "DJLDA - Version officielle")

[Trousse Média](https://www.danslajungledesaffaires.ca/public/media/7a5e4284-bbe4-11f0-9f61-027c568f0fb7.pdf "Trousse Média")

[Participer à l'émission](https://www.danslajungledesaffaires.ca/fr/nous-joindre "Participer à l'émission")

[Nouvelle version DLJDA 4.0](https://www.danslajungledesaffaires.ca/fr/dans-la-jungle-des-affaires-4-0 "Nouvelle version DLJDA 4.0")

*   [Entrevues par ordre alphabétique](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires "Entrevues par ordre alphabétique")
*   [Entrevues par secteurs d'activité](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs "Entrevues par secteurs d'activité")
*   [Ambassadeurs](https://www.danslajungledesaffaires.ca/fr/ambassadeurs-dans-la-jungle-des-affaires "Ambassadeurs")
*   [Nova Global](https://www.danslajungledesaffaires.ca/fr/nova-global "Nova Global")
*   [Animateur de l'émission](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs/rejean-gauthier "Animateur de l'émission")
*   [Témoignages de nos invités](https://www.danslajungledesaffaires.ca/fr/temoignages "Témoignages de nos invités")

*   [Entrevues par secteurs d'activité](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs "Entrevues par secteurs d'activité")
*   [Entrevues par ordre alphabétique](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires "Entrevues par ordre alphabétique")
*   [Ambassadeurs](https://www.danslajungledesaffaires.ca/fr/ambassadeurs-dans-la-jungle-des-affaires "Ambassadeurs")
*   [Nova Global](https://www.danslajungledesaffaires.ca/fr/nova-global "Nova Global")
*   [Animateur de l'émission](https://www.danslajungledesaffaires.ca/fr/animateur-rejean-gauthier "Animateur de l'émission")
*   [Témoignages de nos invités](https://www.danslajungledesaffaires.ca/fr/temoignages "Témoignages de nos invités")
*   [Trousse Média](https://www.danslajungledesaffaires.ca/public/media/98b52e14-bbe4-11f0-a2f9-027c568f0fb7.pdf "Trousse Média")

*   [](https://www.facebook.com/jungledesaffaires "Facebook")
*   [](https://www.linkedin.com/company/dans-la-jungle-des-affaires/ "LinkedIn")
*   [](https://www.youtube.com/@danslajungledesaffaires "Youtube")
*   [](https://www.tiktok.com/@lajungledesaffaires "TikTok")
*   [](https://linktr.ee/rejeangauthier "Linktree")

[](https://www.google.com/maps/place/)

[Participer à l'émission](https://www.danslajungledesaffaires.ca/fr/nous-joindre "Participer à l'émission")[Nouvelle Version DLJDA 4.0](https://www.danslajungledesaffaires.ca/fr/dans-la-jungle-des-affaires-4-0 "Nouvelle Version DLJDA 4.0")

[Retour](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs "Retour")

1.   [Accueil](https://www.danslajungledesaffaires.ca/fr "Accueil")
2.   [Le réseau](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires "Le réseau")
3.   [Entrepreneurs](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs "Entrepreneurs")
4.   Alexandra Lepage, Fondatrice de ALDI

Entrevue #504

Alexandra Lepage

Titre : Entrevue #504 -Alexandra Lepage, Fondatrice de ALDI Conception d'Espace

##### Alexandra Lepage

Fondatrice | ALDI Conception d'Espace

 Alexandra Lepage est une entrepreneure passionnée qui a fondé [**ALDI Conception d'Espace**](https://www.facebook.com/AlexandraLepageDesignerDinterieur/?locale=fr_CA "ALDI Conception d'Espace - Facebook") il y a plus de 14 ans.

Après une pause de 2017 à 2022 pour se consacrer à sa famille et à l'enseignement du design, Alexandra a ressenti le besoin de nourrir son côté créatif et entrepreneur. Elle a donc décidé de (re)sauter dans cette belle aventure.

Avec une solide expérience en design et une passion pour l'enseignement, Alexandra a toujours été à l'écoute de ses clients pour leur offrir des espaces qui leur ressemblent. Elle croit fermement que l'important est de créer un environnement de vie sain et inspirant. Chez ALDI, l'accent est mis sur l'harmonie, le confort, la fonctionnalité et le style.

Alexandra est également une enseignante dévouée, ayant accompagné de nombreux étudiant

*[... truncated, 257,472 more characters]*

---

### InputKit Careers and Employment | Indeed.com
*647 words* | Source: **GOOGLE** | [Link](https://ca.indeed.com/cmp/Inputkit)

About the company
-----------------

*   Founded

2017

*   Company size

11 to 50

*   Revenue

$1,3 m to $6,4m (CAD)

*   Industry

Computer Hardware Development

*   Headquarters

370 Bd Nobert #145, Longu...
*   Link

[InputKit website](https://www.inputkit.io/)

InputKit est une solution web d'expérience client qui a été fondée en 2017 par Philippe Genois et co-fondée par Jean-Philippe Fong. Notre solution aide les organisations à améliorer leur expérience client via des questionnaires courriels et SMS performants, à améliorer leur réputation sur le web et à reconnaître le bon travail de leurs employés. Aujourd'hui, la solution InputKit est utilisée par plus de 1500 clients dans plus de 20 pays. La qualité de notre service client est un facteur déterm...

Salaries
--------

Salary estimated from 62 employees, users, and past and present job advertisements on Indeed.

### Sales

*   [Représentant(e) des Ventes $57,841 per year 5 salaries reported](https://ca.indeed.com/cmp/Inputkit/salaries/Repr%C3%A9sentant(e)-des-Ventes?from=acme-salaries-v2)
*   [Account Executive $132,147 per year 6 salaries reported](https://ca.indeed.com/cmp/Inputkit/salaries/Account-Executive?from=acme-salaries-v2)
*   [Outbound Sales Representative $72,000 per year 3 salaries reported](https://ca.indeed.com/cmp/Inputkit/salaries/Outbound-Sales-Representative?from=acme-salaries-v2)

### Marketing

*   [Marketer $50,924 per year 5 salaries reported](https://ca.indeed.com/cmp/Inputkit/salaries/Marketer?from=acme-salaries-v2)
*   [Marketing Specialist $52,441 per year 3 salaries reported](https://ca.indeed.com/cmp/Inputkit/salaries/Marketing-Specialist?from=acme-salaries-v2)

[Explore more salaries](https://ca.indeed.com/cmp/Inputkit/salaries)

Reviews
-------

### Coordonnatrice marketing in Longueuil, QC

on 18 July 2022

#### Un environnement agréable, un horaire flexible et une belle équipe

Vous cherchez un horaire flexible, des conditions de travail compétitives, une équipe motivante et à l'écoute de vos besoins? Si c'est le cas, InputKit a tout pour vous plaire.Les gestionnaires donnent des rétroactions claires et précises, déterminent des objectifs réalisables, prennent le temps de s'enquérir des employés. Je suis très reconnue pour le travail accompli, et c'est très motivant....

### Technicien comptable in Longueuil, QC

on 18 July 2022

#### Environnement dynamique et convivial

- Équipe de jeunes professionnelles- Gestion inclusive et très bonne communication- Bel esprit d'équipe- Collègues de travail qualifiés- Environnement de travail flexible- Culture d'entreprise basé sur la confiance - Occasion de contribuer au futur de l'entreprise

### Stagiaire in Longueuil, QC

on 18 July 2022

#### Environnement de travaille très agréable

Équipe très chaleureuse et agreable et environnement de travail ideal pour croitre.

### Product Owner in Longueuil, QC

on 18 July 2022

#### Belle équipe!

C'est un environnement de travail dynamique et rempli de défis. Étant une petite entreprise, tout le monde a un impact direct sur le succès et l'avancement de l'entreprise, c'est super!

### Gestionnaire de comptes in Longueuil, QC

on 3 November 2021

#### Environnement dynamique et stimulant!

InputKit est une entreprise en pleine croissance avec laquelle c'est plaisant de grandir!On ne manque jamais de tâches pour bien remplir les journées et la direction nous encourage à exploiter nos talents dans des tâches complémentaires à nos rôles. Cela nous sort de la routine et nous permet de nous challenger, c'est très motivant!Le climat de travail est très agréable et l'équipe est très dy...

[See all reviews](https://ca.indeed.com/cmp/Inputkit/reviews)

What would you say about your employer?
---------------------------------------

Help fellow job seekers by sharing your unique experience.

Questions and answers
---------------------

People have asked 9 questions about working at InputKit. See the answers, explore popular topics, and discover unique insights from InputKit employees.

### Popular questions

Does InputKit offer a dental plan? What does it cover?

What is covered by the life insurance at InputKit?

How long do you have to work at InputKit before you can go on maternity leave?

[See all Q&A](https://ca.indeed.com/cmp/Inputkit/faq)

Interview insights
------------------

Insights from 11 Indeed users who have interviewed with InputKit within the last 5 years.

Favourable experience

Interview is average

Process takes about two weeks

[Explore interviews](https://ca.indeed.com/cmp/Inputkit/interviews)

Working at InputKit
-------------------

*   [Représentant des Ventes (H/F) 5.0 out of 5 stars.](https://ca.indeed.com/cmp/Inputkit/job-titles/Repr%C3%A9sentant-des-Ventes-(H%2FF))

[Show all job titles](https://ca.indeed.com/cmp/Inputkit/job-titles)

InputKit locations
------------------

*   [Longueuil, QC 5.0 out of 5 stars.](https://ca.indeed.com/cmp/Inputkit/locations/QC/Longueuil)

[Show all locations](https://ca.indeed.co

*[... truncated, 219 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Le podcast qui marche - Émission - Apple Podcasts](https://podcasts.apple.com/fr/podcast/le-podcast-qui-marche/id1554914047)**
  - Source: podcasts.apple.com
  - *L'entrepreneur en série Philippe Genois partage plusieurs perles de sagesse lors de cette belle marche. Bonne écoute! Pour en savoir plus: https://www...*

- **[BaladoQuebec.CA | Philippe Genois - L'importance ... - BaladoQuebec](https://baladoquebec.ca/partir-en-affaires/philippe-genois-limportance-dobtenir-du-feedback-de-ta-clientele)**
  - Source: baladoquebec.ca
  - *Aug 22, 2023 ... Le podcast qui marche - Philippe Genois - L'importance d'obtenir du ... Bonne écoute! Pour en savoir plus: https://www.inputkit.io/fr...*

- **[Dans la jungle des affaires | Podcast on Spotify](https://open.spotify.com/show/2kacq25PB8xC34eNfjYGLk)**
  - Source: open.spotify.com
  - *Notre invité du jour : Philippe Genois | Président fondateur chez InputKit.Entrepreneur autodidacte et passionné de technologie depuis l'adolescence, ...*

- **[De Gamer Sans Ambition à Boss d'une Entreprise Tech Lucrative ...](https://www.youtube.com/watch?v=MO00UjTniDE)**
  - Source: youtube.com
  - *Jun 16, 2025 ... Cette semaine, au Podcast Pas Ordinaire, j'ai reçu Philippe Genois, propriétaire d'InputKit. Philippe n'a jamais fitté dans le moule ...*

- **[Dans la Jungle des Affaires - YouTube](https://www.youtube.com/@danslajungledesaffaires/videos)**
  - Source: youtube.com
  - *Podcasts. Playlists. Posts. Search. Latest. Popular. Oldest. 55:20 ... #805 - Philippe Genois | Président fondateur chez InputKit. 39 views. 1 month ....*

- **[#805 - Philippe Genois | Président fondateur chez InputKit. - YouTube](https://www.youtube.com/watch?v=WrZvkzq7zLE)**
  - Source: youtube.com
  - *Oct 29, 2025 ... du jour : Philippe Genois | Président fondateur chez InputKit. Entrepreneur autodidacte et passionné de technologie ......*

- **[Alexandra Lepage, Fondatrice de ALDI](https://www.danslajungledesaffaires.ca/fr/le-reseau-dans-la-jungle-des-affaires/entrepreneurs/alexandra-lepage-fondatrice-de-aldi)**
  - Source: danslajungledesaffaires.ca
  - *Créatrice du podcast ''Cultive Ton Potentiel'' et du magazine ''Graine d'inspiration'' ... Philippe Genois. Président fondateur chez InputKit. Philipp...*

- **[InputKit Careers and Employment | Indeed.com](https://ca.indeed.com/cmp/Inputkit)**
  - Source: ca.indeed.com
  - *InputKit est une solution web d'expérience client qui a été fondée en 2017 par Philippe Genois et co-fondée par Jean-Philippe Fong....*

- **[InputKit | sideidea.com](https://www.sideidea.com/article/37)**
  - Source: sideidea.com
  - *译者写的简短总结. 这次采访的是Philippe Genois，23岁做的产品叫InputKit 是个 ... com/interview/fd8cc9deed) 翻译：[@糖醋陈皮](https://weibo.com/u ......*

- **[How to Come Up with Profitable Online Business Ideas](https://www.indiehackers.com/round-table/how-to-come-up-with-profitable-online-business-ideas)**
  - Source: indiehackers.com
  - *Philippe Genois. , Founder of Icon for InputKit InputKit ($60K/mo). I love ... Once I started using it to interview candidates at Everlane, it seemed ...*

---

*Generated by Founder Scraper*
