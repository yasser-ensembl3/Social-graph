# Martin Gendron

## Position actuelle

**Titre** : Advisory Committee Member
**Entreprise** : Nordic Réfrigération C.T. sec.
**Durée dans le rôle** : 1 year 2 months in role
**Durée dans l'entreprise** : 1 year 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Truck Transportation

## Description du rôle

Advisory committee member

## Résumé

- - - Coach - - - Leader - - - Career Builder - - - Administrator - - - SMB to Large corporation - - - Talent finder  - - -

 
With a little over 30 years in sales and marketing - 25+ year as an administrator and managing teams. With participatory management the teams has every time achieve their goals. 

Master at automate process in measuring task to be cost effective.

Known to be an amazing leader, coach and great administrator (especially if measurable...)

My specialties are : build long and lasting business relationships, great team leader, human skills, team player, negotiation, see integration when others don't, do a lot of mileage with marketing dollar, very flexible with client needs, deliver results. I have a major talent in unifying people skills. Entrepreneur...

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAUP9UB_9nPP7UBE_SM20ucXhC1VOKIkP8/
**Connexions partagées** : 149


---

# Martin Gendron

## Position actuelle

**Entreprise** : Nordic Refrigeration C.T.

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Martin Gendron

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397859332719284225 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFP8cETyC7odg/feedshare-shrink_800/B4EZqogAwdHoAg-/0/1763763556275?e=1766620800&v=beta&t=YXfhYEvTpzrvA7Phf2LCADbPiLg4qHGrGgjN9MAYqDo | Very pround of this accomplishement! | 16 | 2 | 0 | 2w | Post | Martin Gendron | https://www.linkedin.com/in/martingendron | https://linkedin.com/in/martingendron | 2025-12-08T05:24:59.058Z |  | 2025-11-22T04:51:50.500Z | https://www.linkedin.com/feed/update/urn:li:activity:7397760545883320320/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7353082147982692352 | Article |  |  | Partagez / let's share

Nous embauchons / we are hiring

https://lnkd.in/eSbP8PtK | 6 | 0 | 2 | 4mo | Post | Martin Gendron | https://www.linkedin.com/in/martingendron | https://linkedin.com/in/martingendron | 2025-12-08T05:24:59.059Z |  | 2025-07-21T15:23:17.739Z | https://ca.indeed.com/job/repr%C3%A9sentante-des-ventes-56a07af474274d3a |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7311912511845326849 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEMLzEU2J3ozg/image-shrink_800/B4EZWvauboGgA0-/0/1742404774524?e=1765778400&v=beta&t=2YjGWEKGfHAWlviXw4Gq4pafId0zJGLtQjtYzAdhQwk | Félicitations!!! | 10 | 0 | 0 | 8mo | Post | Martin Gendron | https://www.linkedin.com/in/martingendron | https://linkedin.com/in/martingendron | 2025-12-08T05:24:59.059Z |  | 2025-03-30T00:49:51.589Z | https://www.linkedin.com/feed/update/urn:li:activity:7308175316898701315/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7311912318764806146 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEtnldimVgLaA/image-shrink_800/B4EZWvbLvHH0Ak-/0/1742404894599?e=1765778400&v=beta&t=rx9Lf9mmu27vko8LLdM6ylxvKX1CdByEKnW_XwlCJGs | Good job guys | 7 | 0 | 0 | 8mo | Post | Martin Gendron | https://www.linkedin.com/in/martingendron | https://linkedin.com/in/martingendron | 2025-12-08T05:24:59.060Z |  | 2025-03-30T00:49:05.555Z | https://www.linkedin.com/feed/update/urn:li:activity:7308175820634636291/ |  | 

---



---

# Martin Gendron
*Nordic Refrigeration C.T.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Gendron HVAC-R](https://www.youtube.com/@gendronhvac-r1269)
*2024-01-01*
- Category: video

### [Refrigeration Mentor Podcast Conversations with Industry Players](https://refrigerationmentor.com/podcast/)
*2024-03-22*
- Category: podcast

### [Réfrigération Nordic | LinkedIn](https://ca.linkedin.com/company/r%C3%A9frig%C3%A9ration-nordic)
*2025-01-01*
- Category: article

### [Quebec’s Nordic Refrigeration wins Carrier Transicold award](https://www.trucknews.com/transportation/quebecs-nordic-refrigeration-wins-carrier-transicolds-award/1003184556/)
*2024-04-20*
- Category: article

### [The NEWSMakers Podcast: Commercial Refrigeration Trends](https://www.achrnews.com/articles/155301-the-newsmakers-podcast-commercial-refrigeration-trends)
*2024-10-08*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Martin Gendron Email & Phone Number | Blackcircles.ca President ...](https://rocketreach.co/martin-gendron-email_6972613)**
  - Source: rocketreach.co
  - *Martin Gendron brings experience from previous roles at Nordic Réfrigération C.T. ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
