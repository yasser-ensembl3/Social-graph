# Sarah Taibi El Kettani

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Sanovia.ai
**Durée dans le rôle** : 6 months in role
**Durée dans l'entreprise** : 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Hospitals and Health Care

## Résumé

🚀 Founder of Sanovia.ai | 24/7 AI Receptionist for Healthcare Clinics

I am developing an artificial intelligence solution that automates appointment scheduling, patient reminders, and call management for dental, physiotherapy, psychology, chiropractic clinics, and more.

🎯 Proven Results:
✓ 60% fewer missed appointments
✓ 30 hours saved per month on administrative tasks
✓ 3× more positive patient reviews

🎁 Special Offer: First month free to validate the impact — risk-free.

📍 Based in Montreal, available for on-site demonstrations.

Let’s connect to see how Sanovia.ai can transform your clinic.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADeBKUEBO2JBQ_8hN0Q2wIuAyQRV8Ki1h9U/
**Connexions partagées** : 15


---

# Sarah Taibi El Kettani

## Position actuelle

**Entreprise** : Sanovia.ai

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Sarah Taibi El Kettani

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394371592870572040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFkUb2l7vXj_Q/feedshare-shrink_800/B4EZp4VxylIoAg-/0/1762955567209?e=1766620800&v=beta&t=5DA62fC2OJrxQ1B4A9ginpdAQcqBybS4Yz9bYO7IKvQ | 🎯 Appel à mon réseau : Sanovia.ai recherche 2 à 3 cliniques partenaires au Québec !
Nous lançons Sanovia.ai, une réceptionniste virtuelle intelligente qui aide les cliniques dentaires et médicales à automatiser la gestion de leurs rendez-vous et suivis — sans changer leurs outils actuels.

💬 Le constat :
 Les équipes de réception passent jusqu’à 15 h/semaine à gérer appels, confirmations et annulations.
 Résultat : stress, retards et expérience patient compromise.

🚀 La solution :
 Un agent IA bilingue (voix + SMS) qui :
 ✅ répond 24/7,
 ✅ confirme ou modifie les rendez-vous automatiquement,
 ✅ envoie des rappels intelligents,
 ✅ et s’intègre à vos systèmes (Progident, Dentitek, etc.)
🎁 Nous cherchons 2 à 3 cliniques pilotes (dentaire, physio ou multidisciplinaires) pour tester Sanovia.ai gratuitement pendant 30 jours et co-créer la version finale du produit.

En échange, vous obtenez :
 💎 un accès gratuit complet,
 🚀 un rabais à vie sur l’abonnement,
 🧠 une voix directe dans l’évolution du produit,
 📣 et une visibilité publique comme clinique fondatrice Sanovia.ai.

Si vous dirigez une clinique ou connaissez quelqu’un d’ouvert à l’innovation en santé, écrivez-moi — même un court échange de 15 minutes peut faire une vraie différence.

🙏 Un simple partage de ce post pourrait nous connecter aux bonnes personnes.

#Santé #CliniqueDentaire #Innovation #IA #Québec #Startup #SantéNumérique #SanoviaAI #Automatisation #PatientExperience | 16 | 0 | 3 | 3w | Post | Sarah Taibi El Kettani | https://www.linkedin.com/in/sarah-taibi-el-kettani | https://linkedin.com/in/sarah-taibi-el-kettani | 2025-12-08T06:09:36.120Z |  | 2025-11-12T13:52:48.521Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7377366251913887744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETLpmyZwI_WQ/feedshare-shrink_800/B4EZmGrdMWIoAg-/0/1758901170501?e=1766620800&v=beta&t=A10REz44J83UgFX_YaGdtLx9jO8nm0dd_ATx8Uvtl5I | Français (English will follow you)

J’ai eu la chance de participer à ALL IN , le plus grand événement sur l’intelligence artificielle au Canada. Une journée riche en conférences, découvertes et surtout en rencontres inspirantes.

Un plaisir d’avoir échangé avec :

Louise Bergeron , avec qui nous avons discuté des défis et opportunités liés à l’IA dans le secteur de la santé.

Eric Chocron, MBA, avec qui j’ai discuté sur la manière dont Axeo pourrait soutenir mon projet Sanovia.ai.

Camile C., avec qui nous avons parlé du monde du travail en génie informatique et des conseils pour bien s’y préparer. 

Ces conversations ont renforcé ma conviction que bâtir un écosystème solide autour de l’IA est essentiel pour faire rayonner l’innovation au Québec et au Canada.

Un grand merci à toutes celles et ceux qui contribuent chaque jour à ce mouvement collectif.


English

I had the chance to attend ALL IN , Canada’s largest artificial intelligence event. A day full of insightful conferences, new discoveries, and above all, inspiring connections.

It was a pleasure exchanging with:

Louise Bergeron , with whom I discussed the challenges and opportunities of AI in the healthcare sector.

Eric Chocron, MBA , with whom I explored how Axeo could support my project Sanovia.ai. 

Camile C. , with whom I talked about the engineering job market and valuable advice on preparing for it.

These conversations strengthened my conviction that building a strong ecosystem around AI is essential to advancing innovation in Québec and across Canada.

A big thank you to everyone who contributes each day to this collective movement. | 47 | 5 | 0 | 2mo | Post | Sarah Taibi El Kettani | https://www.linkedin.com/in/sarah-taibi-el-kettani | https://linkedin.com/in/sarah-taibi-el-kettani | 2025-12-08T06:09:36.122Z |  | 2025-09-26T15:39:39.293Z |  |  | 

---



---

# Sarah Taibi El Kettani
*Sanovia.ai*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [10 women-led startups in MENA join our newest AI program](https://blog.google/outreach-initiatives/entrepreneurs/10-women-led-startups-in-mena-join-our-newest-ai-program)
*2024-04-30*
- Category: blog

### [How AI is opening up new markets and impacting the startup status quo with Sarah Guo and Elad Gil](https://www.podcast24.fi/episodes/no-priors-artificial-intelligence-machine-learning-technology-startups/how-ai-is-opening-up-new-markets-and-impacting-the-startup-status-quo-with-sarah-guo-and-elad-gil-VvxDZCjDpEY)
*2024-07-18*
- Category: podcast

### [Nidal Taibi](https://journa.com/nidal-taibi)
*2025-09-27*
- Category: article

### [SANOFI, AWS, IKTOS, ELAIA and MIND GROUP at AI for Health - The generative AI revolution for drug discovery - Artefact](https://www.artefact.com/blog/sanofi-aws-iktos-elaia-and-mind-group-at-ai-for-health-the-generative-ai-revolution-for-drug-discovery/)
*2024-12-18*
- Category: blog

### [Career Centre Blog Stream](https://telfer.uottawa.ca/telfer-knowledge-hub/career-centre-blog)
*2025-01-30*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
