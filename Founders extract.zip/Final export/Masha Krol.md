# Masha Krol

## Position actuelle

**Titre** : Founder, CPO
**Entreprise** : Stealth AI Startup
**Durée dans le rôle** : 9 months in role
**Durée dans l'entreprise** : 9 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

✅ step 1: get logo t-shirts made
⏳ step 2: loading...

## Résumé

product + gtm for humans + ai

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAJHGyEBCSbL5uzzm-CHXEmKO-kOFn1k5iA/
**Connexions partagées** : 94


---

# Masha Krol

## Position actuelle

**Entreprise** : Stealth AI Startup

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Masha Krol

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394844100446961664 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8mNF0yZ9ymw/feedshare-shrink_800/B4EZp9V5KWJgAg-/0/1763039484289?e=1766620800&v=beta&t=wG5X-6eLAHXbYJfvq06VnqhPf3zIwdLgJJtS4FMHptI | WHY WE'RE HIRING A PRODUCT DESIGNER IN MTL: this team can ship front-end wayyyyy faster than we can thoughtfully design it 😮‍💨


What we've been finding is that AI meaningfully accelerates the doing, especially on the UI side -- but we're only starting to figure out how to compress the messy bit that comes before the doing, and whether we even should.

The answer certainly doesn't _seem_ to be YOLO prompting till we die.

But honestly, figuring out how to support that divergent, convergent, extremely human process is the interesting part.

To that end, we’re hiring an experienced Product Designer in Montreal to help us shape how humans and AI build software together.

At Nera, we’re figuring out a new way to build software. It’s complex, ambiguous, and full of first-principles problems.

Design isn’t lipstick here -- design is thinking.

If you’ve done 0-1 work in B2B startups, love discovery, and enjoy turning messy intent into clarity, DM me and I’ll send the JD.

If you know someone you'd recommend, tag a friend!

No remote, agencies or PT please, this is a FTE role based in Montreal 🇨🇦

PS: yes we've added a couple of key folks since the selfie 🤳 | 183 | 30 | 18 | 3w | Nicolas Chapados reposted this | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:05.643Z |  | 2025-11-13T21:10:23.106Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392549068838760448 | Text |  |  | friends I'm hiring an experienced product designer in Montreal... are you that somebody? *humming Aaliyah for the rest of the day*


I'm looking for someone who’s done 0-1 work in complex B2B products, can take hand-waved ideas to real pixels, and loves the ambiguity and ownership of super-early stage startups. 

bonus points if you're into helping us stand up the habit of continuous discovery / interviewing!

DM if curious, I'll share a JD

sorry, no agencies / recruiters | 45 | 12 | 12 | 1mo | Nicolas Chapados reposted this | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/nicolaschapados | 2025-12-08T05:11:05.644Z |  | 2025-11-07T13:10:44.931Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7398355672792248320 | Text |  |  | forget pics, send me your custom instructions 🥵 | 1 | 0 | 0 | 2w | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:27.642Z |  | 2025-11-23T13:44:07.195Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397653894018949120 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE-Zpp95tZCow/feedshare-shrink_800/B56Zqm_A7mG0Ag-/0/1763738129015?e=1766620800&v=beta&t=QgwlKBVP3K3T-bZTZxFmHF243jm09M9doFd2mdk-5k4 | been thinking a lot about fluctuating thresholds in AI output... who else?



Working on Nera, I've been finding that there is a "usefulness threshold" to AI-generated output (be it code, writing, images...), above which getting _something_ is better than nothing.

There is another threshold, let's call it "good enough threshold", hitting which lets me accept the suggestion as is.

Vibe coders are hoping to aim for "yolo accept" all the time, particularly on first shot, and break down as problems get different across a variety of dimensions (I didn't say just "larger" or "more complex" because I think there's more to it).

Example: I tried to one-shot a bug into GitHub yesterday. The first shot was better than what I would have written from scratch, but not quite right, so I felt it was worth some work on my part to refine it. If the first shot was truly terrible, it would not have been worth refining, and I would want to shoot it and start over (maybe by my damn analog self, or with a better model). If the first shot is "good enough" (a threshold which also depends on many factors!), then I might be good to pass it through.

What I'm **really** curious about is the interaction in the messy middle. Is there a threshold between broad brush vs detail that has always existed, but is maybe more dynamic now? Is there in fact a distinction, or actually not? 

Or, radically, is there even an opportunity for me to discover something better than how I had originally been thinking about it?

Some adjacent work I've seen is what the NNg refers to this as the "articulation barrier" and the idea of UX as a way to "discover solutions in latent space" vs "creation" -- this feels interesting, but I'm not as black and white on it. I actually think it's much more a mix.

What have you seen? | 11 | 6 | 0 | 2w | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:27.642Z |  | 2025-11-21T15:15:30.097Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7395501538229571584 | Text |  |  | shots fired, feeling seen AND attacked at the same time | 3 | 1 | 0 | 3w | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:27.643Z |  | 2025-11-15T16:42:48.488Z | https://www.linkedin.com/feed/update/urn:li:activity:7393652422960885760/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394723564525993984 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE8mNF0yZ9ymw/feedshare-shrink_800/B4EZp9V5KWJgAg-/0/1763039484289?e=1766620800&v=beta&t=wG5X-6eLAHXbYJfvq06VnqhPf3zIwdLgJJtS4FMHptI | WHY WE'RE HIRING A PRODUCT DESIGNER IN MTL: this team can ship front-end wayyyyy faster than we can thoughtfully design it 😮‍💨


What we've been finding is that AI meaningfully accelerates the doing, especially on the UI side -- but we're only starting to figure out how to compress the messy bit that comes before the doing, and whether we even should.

The answer certainly doesn't _seem_ to be YOLO prompting till we die.

But honestly, figuring out how to support that divergent, convergent, extremely human process is the interesting part.

To that end, we’re hiring an experienced Product Designer in Montreal to help us shape how humans and AI build software together.

At Nera, we’re figuring out a new way to build software. It’s complex, ambiguous, and full of first-principles problems.

Design isn’t lipstick here -- design is thinking.

If you’ve done 0-1 work in B2B startups, love discovery, and enjoy turning messy intent into clarity, DM me and I’ll send the JD.

If you know someone you'd recommend, tag a friend!

No remote, agencies or PT please, this is a FTE role based in Montreal 🇨🇦

PS: yes we've added a couple of key folks since the selfie 🤳 | 183 | 30 | 18 | 3w | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:27.643Z |  | 2025-11-13T13:11:25.103Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7363941371700731905 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHHmT97ABsgNQ/feedshare-shrink_800/B4EZjH5ptwGUAo-/0/1755700437493?e=1766620800&v=beta&t=NQzHKG1SdU_mnZX5Va_I8rw6clQBmQwa-xhC6aqFtqw | safety first when working on ai, friends | 33 | 2 | 0 | 3mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.181Z |  | 2025-08-20T14:33:58.428Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7362855509562990592 | Article |  |  | if you’re not vibing from first principles you’re ngmi #AI #agentic #hardcorevibes

https://lnkd.in/eJPnU66z | 5 | 1 | 2 | 3mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.182Z |  | 2025-08-17T14:39:08.720Z | https://github.com/GatienBoquet/vibe-uppercase |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7362103976139399168 | Text |  |  | vibe coders are out here treating enterprise software like a single-player sport and it shows | 6 | 0 | 0 | 3mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.183Z |  | 2025-08-15T12:52:49.189Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7359935398409605120 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF10nfGcwSa5A/feedshare-shrink_800/B56ZiKiBlEH0Ag-/0/1754670832684?e=1766620800&v=beta&t=dZNULn2ZxXYoyCBKNqpZgS2MUKvwOisOcuOlb3leUJs | feeling cute, might start a ✨women hiring women✨ movement, @ me | 15 | 6 | 0 | 3mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.183Z |  | 2025-08-09T13:15:39.968Z | https://www.linkedin.com/feed/update/urn:li:activity:7359622898724036608/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7358539945025630209 | Text |  |  | all i want for my birthday is to meet senior technical women in MTL 🥺👉👈 | 37 | 6 | 0 | 4mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.184Z |  | 2025-08-05T16:50:37.955Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7353407722978959361 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHHw5pFHCkRzQ/feedshare-shrink_800/B4EZgyNWcQHgAk-/0/1753189019643?e=1766620800&v=beta&t=LwU-PIBHqaFiLHFZiWcsnsz5WfGz1HR_iFY6_FNMCv8 | So Robin and I were working on a spec for [redacted] when Chat went full drunk uncle on me (bad LLM, drunk-uncling is MY job!).

It up and lost an entire portion of the spec we'd already worked out, then asked a helpfully clarifying question, but took my answer and obfuscated important detail I explicitly provided.

Bref, NOT a vibe. Something’s rotten in the state of LLMs, eh? 🎭

Turns out my experience isn't a one-off -- the fine folks over at Chroma call it "context rot"; the whole post is worth checking out, but the findings really resonate:

1️⃣ Finding 1: models struggle with reasoning over long conversations. In their LongMemEval setup (~113k token chat histories vs ~300-token focused slices) every model dropped performance; in longer conversations, reasoning and accuracy falls off.

2️⃣ Finding 2: ambiguity compounds the challenge of long inputs. When the question doesn’t closely resemble the answer text (lower Needle-Question similarity), models that do fine at short length degrade faster as you add irrelevant tokens -- the model has to find and interpret the right bit, and gets lost. 

3️⃣ Finding 3: models struggle with distractors at long inputs. Even a single similar-but-wrong snippet drags accuracy down; add a few and it tanks. Failure mode differs by model family (hallucinate vs abstain) but nobody’s immune as length scales. 

4️⃣ Finding 4 (the kicker): models cannot be treated as reliable computing systems. On a trivial “repeat these words” task -- just literally copy/paste text! -- performance still decays with length; models refuse, truncate, or mutate output. We _cannot_ assume deterministic behavior just because the window is big.

The only thing I've reliably found to help?

As you notice quality start to dip, dump the conversation and start a fresh thread with only the bits that matter. Not to anthropomorphize the experience, but this reminds me of being a micromanager -- sometimes, more detail isn't actually better, no matter how much nuance we wish we could impart.

The authors recommend Context Engineering as a remedy -- curate, order, compress what lands in the window. I agree we need that layer. But frankly a lot of “context engineering” in practice is just more systematic prompting + retrieval plumbing + better PR. Will it help? Yeah. Actually guarantee reliable outputs? Absolutely not.

We still need a reliability layer above / across any one prompt -- that's where I'm exploring these days.

What else helps?

#AI #LLM #ContextEngineering | 21 | 11 | 1 | 4mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.185Z |  | 2025-07-22T12:57:00.867Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7340917849680490497 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0897cc96-9f37-495b-8389-089063484357 | https://media.licdn.com/dms/image/v2/D4E05AQHMduH_WOHZgw/videocover-low/B4EZd5K4ZiHcCE-/0/1750084590751?e=1765778400&v=beta&t=f5nH5MXgC7-IxpIHeWwnA5d5-lovXCssJA3v5UR3YLc | a mind for the bicycle | 2 | 0 | 0 | 5mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.186Z |  | 2025-06-18T01:46:43.022Z | https://www.linkedin.com/feed/update/urn:li:activity:7340386826504876033/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7335285230913687552 | Text |  |  | who do I know that has done an Oracle --> Postgres migration and survived? friend about to embark on this hero's journey for work, would love to prevent his pain if you're up for sharing ghost stories | 8 | 11 | 1 | 6mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.188Z |  | 2025-06-02T12:44:42.059Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7334561123574190083 | Document |  |  | Founder-led sales gold. Don't hold that Rob's at Harvard against him, he's actually done the 0-$1M+ in ARR. | 3 | 0 | 0 | 6mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.189Z |  | 2025-05-31T12:47:21.416Z | https://www.linkedin.com/feed/update/urn:li:activity:7328043758455844865/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7332413339110678529 | Article |  |  | for all my wonderful crusty developers out there — I see you, I hear you, I’m with you | 3 | 0 | 0 | 6mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.189Z |  | 2025-05-25T14:32:49.696Z | https://deplet.ing/the-copilot-delusion/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7303400092550463488 | Text |  |  | We need a Canadian ChatGPT / Claude. Who’s building this? | 12 | 2 | 0 | 9mo | Post | Masha Krol | https://www.linkedin.com/in/mashakrol | https://linkedin.com/in/mashakrol | 2025-12-08T05:11:32.191Z |  | 2025-03-06T13:04:32.676Z |  |  | 

---



---

# Masha Krol
*Stealth AI Startup*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 12 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Masha Krol](https://www.mashakrol.com/)
*2007-01-01*
- Category: article

### [MEGABRAIN — Blog — Masha Krol](https://www.mashakrol.com/blog/category/MEGABRAIN)
*2016-12-31*
- Category: blog

### [Blog — Masha Krol](https://www.mashakrol.com/blog)
*2020-07-05*
- Category: blog

### [EXTERNAL.FYI — Blog — Masha Krol](https://www.mashakrol.com/blog/category/EXTERNAL.FYI)
*2020-05-24*
- Category: blog

### [Stealth mode: The case for product first, marketing second](https://mashable.com/archive/product-first)
*2022-03-11*
- Category: article

---

## 🎬 YouTube Videos

- **[Masha Krol, Experience Designer at Element AI + Carl Schmidt - CTO &amp; Co-founder of Unbounce](https://www.youtube.com/watch?v=gfWlvD75uxQ)**
  - Channel: DynamicMTL
  - Date: 2018-08-29

- **[AI Tooling to Drive Growth &amp; Break Down Silos with Masha Kroll of Glowstick | Episode 064](https://www.youtube.com/watch?v=pEFv_dhGOT4)**
  - Channel: The Digital CX Podcast
  - Date: 2024-08-06

- **[There&#39;s no glass ceiling when trying to found your own startup: Entrepreneur](https://www.youtube.com/watch?v=rpGFt7cfnYM)**
  - Channel: BNN Bloomberg
  - Date: 2020-11-26

- **[AIFest 2017 - Masha Krol (Element AI)](https://www.youtube.com/watch?v=_67nOWi6l9k)**
  - Channel: Startupfest
  - Date: 2019-05-17

- **[2018 AI 100 Startup: Element AI](https://www.youtube.com/watch?v=qpIRj9y-ha4)**
  - Channel: CB Insights
  - Date: 2018-01-17

- **[Task #segmentation is a better way to target digital motions to the right users.](https://www.youtube.com/watch?v=EgXAO4eoNdU)**
  - Channel: The Digital CX Podcast
  - Date: 2024-08-11

- **[Element Raises $102 Million | Crunch Report](https://www.youtube.com/watch?v=pvcnwadXjJI)**
  - Channel: TechCrunch
  - Date: 2017-06-14

- **[Tech Lightning Rounds : Podcast: Ep 4: AI](https://www.youtube.com/watch?v=PKtrlEaK2yE)**
  - Channel: Intertrust Technologies
  - Date: 2019-04-24

- **[UX/ Intelligence artificielle - 23 février 2017 (Conférence 1)](https://www.youtube.com/watch?v=F46jcv_5mtI)**
  - Channel: Tout le monde UX
  - Date: 2017-03-31

- **[Мария Кроль - визитка](https://www.youtube.com/watch?v=6edMKeIwZAQ)**
  - Channel: Masha Krol
  - Date: 2021-09-08

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
