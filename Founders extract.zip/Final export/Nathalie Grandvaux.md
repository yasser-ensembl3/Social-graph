# Nathalie Grandvaux

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Réseau Québécois COVID-Pandémie (RQCP)
**Durée dans le rôle** : 5 years 8 months in role
**Durée dans l'entreprise** : 5 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Research Services

## Résumé

Associate Scientific Director - Students and Postdoctoral Affairs at the CHUM Research Center (CRCHUM), Professor in the Department of Biochemistry and Molecular Medicine, with accreditation in Microbiology, Infectiology, and Immunology, at Faculty of Medicine, Université de Montréal and director of a research group focused on host-virus interactions/Interferon response in virus infection and autoimmunity. Our preclinical investigations aim to identify host-targeted broad-spectrum antivirals & drugs relevant to the treatment of autoimmune diseases involving interferon signature.

Passionate about problem-solving, I am engaged in addressing challenges within the institutions/organizations. 

Committed to advancing organization of research in Canada and federating forces, I co-founded and was the inaugural president of the Canadian Society for Virology, a registered Not-for-profit Organization, which counted more than 300 members from across Canada when I finished my mandate. When the COVID-19 crisis started, I co-founded and co-directed the Quebec COVID - Pandemic Network, spearheading transdisciplinary research initiatives to effectively respond to the pandemic's impact in Quebec. Eager to contribute to strategic development of research in Canada, I am currently a member of the CIHR Institute of Infection and Immunity Advisory Board.

Being involved in public outreach efforts, I am a fervent advocate for disseminating evidence-based scientific information. I actively participate in various media appearances and science communication event to ensuring that scientific knowledge reaches a broader audience.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAkZBEBTGTlJOJfGYohsuSl4S_UsOqBv1M/
**Connexions partagées** : 10


---

# Nathalie Grandvaux

## Position actuelle

**Entreprise** : N. Grandvaux

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nathalie Grandvaux

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402141718697095168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6zzum29j6wg/feedshare-shrink_800/B4EZrltkmEIIAg-/0/1764790522419?e=1766620800&v=beta&t=79MUYs_qWambb0Uoc6Qe_m0T2CuNWCU1OIFe2fNwDOU | La rue des Femmes une cause importante. Une organisation extraordinaire qui fait la différence pour de nombreuses femmes à Montréal. | 4 | 0 | 0 | 4d | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:44.636Z |  | 2025-12-04T00:28:30.880Z | https://www.linkedin.com/feed/update/urn:li:activity:7402067955418677249/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397423690595975168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFSBAskx27Z3A/feedshare-shrink_800/B4EZqjG7luKgAg-/0/1763673098252?e=1766620800&v=beta&t=IULhGHTUqhWdpzzAZugpiH1d2m_Der2U64t5pxtf8z0 | Very honored to have been invited to speak at NOXROS 2025 – Oxidative Stress & Redox Regulation in Living Organisms in Marrakech.
The francophone and Moroccan redox communities are incredibly dynamic, and I had many thoughtful discussions on redox processes.
It was wonderful to reconnect with old friends, meet new researchers in the field, and engage with such vibrant communities. I’m leaving with lots of new ideas and, without a doubt, exciting collaborations to come. | 17 | 0 | 0 | 2w | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:46.921Z |  | 2025-11-21T00:00:45.324Z | https://www.linkedin.com/feed/update/urn:li:activity:7397381138668756994/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391443556004941825 | Article |  |  | A well deserved prize for Lidia Morawska for her leadership into awareness of aerosol transmission of SARS-CoV-2. Such leadership at very trouble times and in a period where people, authorities and media where reluctant to recognize this fact was essential and needed to be recognized.

https://lnkd.in/ey4kCiFx | 5 | 0 | 0 | 1mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:46.923Z |  | 2025-11-04T11:57:50.132Z | https://www.abc.net.au/news/science/2025-11-03/lidia-morawska-prime-ministers-science-prize-air-quality/105959260 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387596999384268800 | Article |  |  | La semaine dernière nous avons comme chaque année mis à l'honneur les étudiant(e)s, stagiaires postdoctoraux, stagiaires de 1er cycle et résident(e)s impliqués dans les projets de recherche du Centre de recherche du CHUM (CRCHUM). 

La recherche présentée dans les 135 affiches et 16 présentations orales était de calibre internationale. Grâce aux soutien de nos institutions et des départements cliniques nous avons remis 8950$ en prix d'excellence. Une reconnaissance bien méritée pour les acteurs essentiels de la recherche.

Peu de gens s'en rendent compte - et même nos dirigeants - mais dans le modèle canadien, une très grande partie de la recherche repose sur les étudiants gradués et stagiaires postdoctoraux. Loin d'être uniquement des personnes en formation, ils et elles sont le coeur de la recherche. Il sera certainement nécessaire de se poser la question si ce modèle dont le succès repose sur des personnes en formation doit perdurer (j'y reviendrai sous une forme ou une autre ultérieurement), mais pour le moment je veux souligner l'excellence de la communauté étudiante, postdoctorale et des résident(e) du CRCHUM. Bravo à tous! Une journée d'esprits créatifs, plein d'audace et d'idées innovantes.

Un grand bravo à mon équipe Hana Maalaoui et Joanne Auclair pour l'organisation de cette belle journée. Comme à chaque année, vous déplacez des montagnes! 

Centre de recherche du CHUM (CRCHUM) CHUM - Centre hospitalier de l'Université de Montréal Fonds de recherche du Québec Faculté de médecine de l'Université de Montréal Université de Montréal École de technologie supérieure Polytechnique Montréal International Comité Étudiant Du CRCHUM | 14 | 1 | 0 | 1mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:46.926Z |  | 2025-10-24T21:12:59.568Z | https://www.chumontreal.qc.ca/actualites/idees-audacieuses-esprits-effervescence-au-congres-etudiant-crchum |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7385779852592857089 | Article |  |  | Avec un peu de délai, on discute de l'utilité de la vaccination COVID-19 pour cette saison Noovo Info
https://lnkd.in/evFrMh-e | 3 | 0 | 0 | 1mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:48.981Z |  | 2025-10-19T20:52:18.012Z | https://youtu.be/AszI4o2Vmok?si=l0cDCYRunqs0fctO |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7384934398401335297 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFw-Ped6bAAFg/feedshare-shrink_800/B4EZnyOsIzK0Ag-/0/1760705563145?e=1766620800&v=beta&t=FPlWP43xbn14wmBsbRcf3LHbH8jE6GNt6Lb9UT0GGHI | Tout est prêt pour le 26ème congrès des étudiants, stagiaires et résidents du CHUM - Centre hospitalier de l'Université de Montréal au Centre de recherche du CHUM (CRCHUM). Une communauté très active : 135 affiches et 16 présentations orales des travaux de recherche réalisés sous la direction de chercheurs et chercheures du CRCHUM. Des avancées en Science fondamentale, clinique et en santé des populations. Un continuum de recherche unique. Des discussions interdisciplinaires innovantes en perspective.

Fonds de recherche du Québec CHUM - Centre hospitalier de l'Université de Montréal Centre de recherche du CHUM (CRCHUM) Université de Montréal Faculté de médecine de l'Université de Montréal École Polytechnique École de technologie supérieure École de santé publique de l'Université de Montréal Comité Étudiant Du CRCHUM | 98 | 2 | 3 | 1mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:48.982Z |  | 2025-10-17T12:52:46.025Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7378900027928256512 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGLSo5M4QVBwQ/feedshare-shrink_800/B56ZmbAUyiI0Ak-/0/1759242179851?e=1766620800&v=beta&t=XLDAMgQpRs8wNfzv-OFki2-C0lCbT6E2p0XhM5CsuEc | It was a pleasure to be back in Saskatoon for the #PIIN2025 symposium. I am always impressed by the quality of the research and the enthusiasm of students and postdocs. Very inspiring! Thank you Kerry J. Lavender and Thomas Murooka for the invitation. It was a fantastic meeting. | 43 | 2 | 0 | 2mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:51.361Z |  | 2025-09-30T21:14:19.991Z | https://www.linkedin.com/feed/update/urn:li:activity:7378796516146270208/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7370966639300845568 | Article |  |  | A ne pas manquer! Conférence grand public sur les bioaérosols par la formidable Caroline Duchaine! | 7 | 0 | 1 | 2mo | Post | Nathalie Grandvaux | https://www.linkedin.com/in/nathalie-grandvaux-1a9970 | https://linkedin.com/in/nathalie-grandvaux-1a9970 | 2025-12-08T07:16:51.363Z |  | 2025-09-08T23:49:52.747Z | https://www.brioeducation.ca/cours-activites/conference-quand-lair-devient-vecteur-comprendre-les-bioaerosols-cjdmtsp157/detail/ |  | 

---



---

# Nathalie Grandvaux
*N. Grandvaux*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Nathalie Grandvaux Lab](https://nathaliegrandvauxlab.com/)
*2023-12-01*
- Category: article

### [Our team – Nathalie Grandvaux Lab](https://nathaliegrandvauxlab.com/our-team/)
*2023-12-01*
- Category: article

### [Nathalie Grandvaux - Département de microbiologie, infectiologie et immunologie - Université de Montréal](https://microbiologie.umontreal.ca/en/professeurs-chercheurs/nathalie-grandvaux/)
*2018-07-16*
- Category: article

### [nathalie grandvaux](https://scholar.google.ca/citations?user=z24rOS8AAAAJ&hl=en)
*2016-10-20*
- Category: article

### [Nathalie GRANDVAUX | Professor (Full) | PhD](https://www.researchgate.net/profile/Nathalie-Grandvaux)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Pinpointing cysteine oxidation sites by high-resolution proteomics ...](https://www.science.org/doi/10.1126/scisignal.aaw4673)**
  - Source: science.org
  - *... Nathalie Grandvaux https://orcid.org/0000-0003-0567-0284+2 authors ... N. Grandvaux, M. Mariani, K. Fink, Lung epithelial NOX/DUOX and respiratory...*

- **[Structural basis of STAT2 recognition by IRF9 reveals molecular ...](https://www.pnas.org/doi/10.1073/pnas.1718426115)**
  - Source: pnas.org
  - *Jan 9, 2018 ... ... Nathalie Grandvaux, and Daniel Panne https://orcid.org/0000-0001 ... N Grandvaux, et al., Transcriptional profiling of interferon ...*

- **[Résumés des Communications Scientifiques](http://www.biefp.org/images/RMR/RMRA_HS2_pdf%20final.pdf)**
  - Source: biefp.org
  - *Oct 6, 2017 ... Podcast. Cas clinique. Vidéo/Animation ... n. grandvaux*. Université de Montréal, Canada. * Auteur correspondant. Courriel : nathalie....*

- **[STAT2 and IRF9: Beyond ISGF3 - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC3906322/)**
  - Source: pmc.ncbi.nlm.nih.gov
  - *Dec 18, 2013 ... Correspondence to: Nathalie Grandvaux, Email: nathalie.grandvaux@umontreal.ca ... N Grandvaux. K Fink was recipient of studentships f...*

- **[Redox-modulating agents target NOX2-dependent IKKε oncogenic ...](https://www.sciencedirect.com/science/article/pii/S2213231715000610)**
  - Source: sciencedirect.com
  - *, Nathalie Grandvaux. Show more. Add to Mendeley. Share. Cite ... , N. Grandvaux. IFNβ/TNFα synergism induces a non-canonical STAT2/IRF9 ......*

- **[Respiratory Syncytial Virus and Cellular Stress Responses: Impact ...](https://www.mdpi.com/1999-4915/8/5/124)**
  - Source: mdpi.com
  - *Cervantes-Ortiz SL, Zamorano Cuervo N, Grandvaux N. Respiratory ... Nathalie Grandvaux. 2016. "Respiratory Syncytial Virus and Cellular Stress ......*

- **[Activation of TBK1 and IKKε Kinases by Vesicular Stomatitis Virus ...](https://journals.asm.org/doi/pdf/10.1128/jvi.78.19.10636-10649.2004)**
  - Source: journals.asm.org
  - *... Nathalie Grandvaux,1,2. Ilkka Julkunen,4 Hiroaki Hemmi,5 M. Yamamoto,5 Shizuo ... Servant, M. J., N. Grandvaux, and J. Hiscott. 2002. Multiple sig...*

- **[‪nathalie grandvaux‬ - ‪Google Scholar‬](https://scholar.google.com/citations?user=z24rOS8AAAAJ&hl=en)**
  - Source: scholar.google.com
  - *nathalie grandvaux. Université de Montréal - CRCHUM. Verified email at ... N Grandvaux, MJ Servant, B TenOever, GC Sen, S Balachandran, ... Journal of...*

- **[Identification of the Minimal Phosphoacceptor Site Required for in ...](https://www.sciencedirect.com/science/article/pii/S0021925819713246)**
  - Source: sciencedirect.com
  - *Nathalie Grandvaux ‡ § ¶ ** , Benjamin R. tenOever ‡ § ‡ , Delphine ... N. Grandvaux, M.J. Servant, B.R. tenOever, G.C. Sen, S. Balachandran, G.N. ......*

- **[Respiratory Syncytial Virus-Mediated NF-κB p65 Phosphorylation at ...](https://pmc.ncbi.nlm.nih.gov/articles/PMC2898247/)**
  - Source: pmc.ncbi.nlm.nih.gov
  - *Sharma, S., B. R. tenOever, N. Grandvaux, G. P. Zhou, R. Lin, and J. Hiscott. 2003. Triggering the interferon antiviral response through an IKK-relate...*

---

*Generated by Founder Scraper*
