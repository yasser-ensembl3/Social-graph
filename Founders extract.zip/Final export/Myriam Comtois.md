# Myriam Comtois

## Position actuelle

**Titre** : Présidente fondatrice / relationniste
**Entreprise** : Myriam Communications
**Durée dans le rôle** : 10 years 6 months in role
**Durée dans l'entreprise** : 10 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Stratégie de communication
Relations de presse
Gestion de crise
Gestion d'événements

Principaux clients:
Éditeurs (littérature et essai)
Compagnies de théâtre 
Festivals 
Organismes culturelles 
Organismes communautaires

## Résumé

Grâce à mes années d’expérience dans le milieu culturel, notamment dans l’industrie du livre, du théâtre et de l’événementiel, j’ai œuvré à toutes les échelles : des structures émergentes aux institutions établies, en passant par des médias, des événements d’envergure jusqu’aux de plus petites productions.
Cette diversité de contextes m’a permis de comprendre les réalités multiples de la création, de la diffusion et de la réception médiatique, et d’affiner une approche à la fois stratégique, humaine et ancrée dans la réalité du terrain.

Dotée d’une solide expertise en relations de presse, j’offre aussi des services de communication et de consultation. Je donne également des ateliers et des formations sur les bonnes pratiques de communications pour des organismes culturels et sociaux. Je conserve une partie de pratique à créer des liens et faire du mentorat. 

Curieuse, investie et allumée par les projets et les équipes, j’aime m’impliquer pleinement dans les univers que j’accompagne. Mon plaisir réside dans la collaboration, le dialogue et la mise en lumière de la culture sous toutes ses

Fondatrice de Myriam Communications, j’accompagne artistes, maisons d’édition, festivals et tout autres organismes dans leur vie médiatique, avec la conviction qu’une communication réussie repose sur la clarté, la sincérité et le respect du rythme de chacun·e.

Co-fondatrice de Pavillons, j’ai exploré également les nouvelles façons de relier les auteur·rices et les lecteur·rices, en cocréant un site dont l’abonnement constitue une manière alternative de soutenir les arts, d’encourager le développement des idées et de donner vie à l’expérimentation.

Je souhaite contribuer à une vie culturelle forte, consciente et durable, où la communication devient un véritable prolongement de la création : un espace où les idées circulent, se transforment et trouvent leur public avec justesse, sensibilité et générosité.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAQGIgIBoJHCLfhGLZbjK9UgU5LewHcQ7tA/
**Connexions partagées** : 5


---

# Myriam Comtois

## Position actuelle

**Entreprise** : L'actualité

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Myriam Comtois
*L'actualité*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [Comment on fabrique L’actualité](https://lactualite.com/videos/comment-on-fabrique-l-actualite/)
*2011-09-14*
- Category: article

### [Interview with Myriam Achard – Centre PHI](https://news.unframed-collection.com/en/interview-with-myriam-achard-centre-phi/)
*2025-02-18*
- Category: article

### [The PHI Phenomenon: in conversation with Myriam Achard](https://nichemtl.com/2024/12/08/the-phi-phenomenon-in-conversation-with-myriam-achard/)
*2024-12-08*
- Category: article

### [MYRIAM ACHARD Director of PR & Communication, Phi Centre (CA) - Power To The Pixel](https://www.powertothepixel.com/people/myriam-archard-director-of-pr-communication-phi-centre-ca/)
*2014-06-20*
- Category: article

### [The New Atlas of Digital Art | Myriam achard Head  Partnerships Centre  PHI Montreal (ENG)](https://www.youtube.com/watch?v=IL4Vvhgxb9c)
*2022-07-08*
- Category: video

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Il faut qu'on parle de Québecor – Pivot](https://pivot.quebec/2025/05/15/il-faut-quon-parle-de-quebecor/)**
  - Source: pivot.quebec
  - *May 15, 2025 ... Myriam Comtois, relationniste, Montréal ... Abonnez-vous à notre infolettre pour recevoir chaque semaine toute l'actualité des luttes...*

- **[2 AU 5 MAI 2019](https://bluemetropolis.org/wp-content/uploads/2019/03/Brochure_2019_LR.pdf)**
  - Source: bluemetropolis.org
  - *MYRIAM COMTOIS Relationniste médias francophones. SHELLEY POMERANCE ... Dans les zones de conflits, l'actualité politique occupe le devant de la scène...*

- **[Le festival s'envole du 25 mai au 8 juin 2017 11e édition Montréal ...](https://theatre-contemporain.net/images/upload/pdf/f-96c-592c8bb0c7ed0.pdf)**
  - Source: theatre-contemporain.net
  - *Jun 8, 2017 ... soubresauts de l'actualité. Dans quel climat politique ... Myriam Comtois. Julie Delorme. Alexandrine Doré Pilote. Monteur vidéo. Sand...*

- **[Les libraires - Numéro 132 by leslibraires - Issuu](https://issuu.com/leslibraires/docs/les-libraires-132)**
  - Source: issuu.com
  - *Aug 26, 2022 ... ... l'actualité universelle. Elle bricole les mots pour toucher aux ... Myriam Comtois, Marie Lamarre et Annabelle Moreau. 1 POUR ......*

- **[Nous joindre | L'actualité](https://lactualite.com/nous-joindre/)**
  - Source: lactualite.com
  - *Autres ressources. RÉDACTION DE L'ACTUALITÉ (MAGAZINE) 514 848-0805, poste 301. Écrivez à la rédaction. RELATIONS DE PRESSE Myriam Comtois 514 462-138...*

- **[Travailler le plan isométrique en classe - École branchée](https://ecolebranchee.com/travailler-plan-isometrique-classe/)**
  - Source: ecolebranchee.com
  - *Apr 24, 2023 ... Toute l'ACTUALITÉ · CALENDRIER des événements; RESSOURCES par public ... Myriam Comtois à l'école Mont-de-La Salle, au CSS de Laval, ...*

- **[L'effet Guy A. - Châtelaine](https://fr.chatelaine.com/societe/entrevues/leffet-guy-a/)**
  - Source: fr.chatelaine.com
  - *Nov 20, 2012 ... Chantal Hébert, observatrice de la scène politique fédérale depuis des lustres, chroniqueuse au Toronto Star et à L'actualité, trouve...*

- **[R APPOR T](https://www.protegez-vous.ca/content/download/350832/file/rapport-activites-2021-2022.pdf)**
  - Source: protegez-vous.ca
  - *Mar 31, 2022 ... PROtégez-Vous, une infolettre qui résume l'actualité de nos activités de développement ... Myriam Comtois. LES PARTENAIRES. DU MARKET...*

---

*Generated by Founder Scraper*
