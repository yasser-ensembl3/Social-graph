# Christophe Roy

## Position actuelle

**Titre** : CEO & Co-Founder
**Entreprise** : Trame
**Durée dans le rôle** : 2 months in role
**Durée dans l'entreprise** : 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

A former national-level athlete, Christophe studied at three universities and conducted neuroscience research before turning to entrepreneurship. As a software designer and developer, he is now the CEO of Fizl, an app ranked among the top business applications on the App Store and Google Play, and backed by world-class accelerators, including one of Uber’s first investors. Today, he leads the development of an AI agent that helps non-technical teams automate enterprise processes.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACkuh9QBZ-MByGdJnYOc_VFLzSs1qEH2HjY/
**Connexions partagées** : 43


---

# Christophe Roy

## Position actuelle

**Entreprise** : Trame

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Christophe Roy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393659820064677888 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2eadf893-4e4e-46aa-83b1-2c0ee7a0344d | https://media.licdn.com/dms/image/v2/D4E05AQGJ4bxmyuhXlQ/videocover-low/B4EZpUy.fXGoCE-/0/1762359255066?e=1765778400&v=beta&t=9bdgtJD_JrpjceOw1R3AyWa0Fjzdu4Sa67AjGVODZxA | Du 11 au 12 novembre, je représenterai Trame à STRATÉGIES PME, un événement qui a réuni plus de 6000 dirigeants de PME lors de sa dernière édition !

J’ai hâte d’échanger, d’apprendre et de partager comment Trame aide les entreprises à optimiser leurs opérations en orchestrant leurs processus grâce à une approche déclarative de l’automatisation.

Un grand merci à Maxime Lavoie de LevelOps pour l’invitation, leur équipe aura un kiosque sur place alors passez les voir pendant l’événement ! | 12 | 0 | 0 | 3w | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:39.177Z |  | 2025-11-10T14:44:28.660Z | https://www.linkedin.com/feed/update/urn:li:activity:7391870566292639744/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392187776105910272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGR40jktFNOAw/feedshare-shrink_800/B4EZpLqHk_HEAk-/0/1762205925342?e=1766620800&v=beta&t=-_D_tzIM0vYqlu0ae26TV8w-dM9KUYt-acS4MRd6O6o | Le Club Entrepreneurs Desjardins – Montréal est en feu avec une 3e activité sur l’IA au service des PME 🔥

Un grand merci à Kiet Cuong et Martin Berube pour leurs présentations et à Jean-Paul Pham, SAMI BEN NASR, Aurelien Degoute et comme toujours, l'incroyable Marie-France Desy pour faire rayonner cette communauté d’entrepreneurs.

📷 Crédit photo : Catrine Daoust | 13 | 1 | 0 | 1mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:39.177Z |  | 2025-11-06T13:15:06.031Z | https://www.linkedin.com/feed/update/urn:li:activity:7391459286045839364/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391852511206453248 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6a54272f-a4b5-494c-b700-c83452dd663a | https://media.licdn.com/dms/image/v2/D4E05AQFKyocgEcoCnQ/videocover-low/B4EZpUikoRHECE-/0/1762354964791?e=1765778400&v=beta&t=AiHztxo0_H9D4kPrI8PpnJa4EtmvXZo4eI-jrMoxbXI | What is Trame in 38 seconds?

Trame bring automation to every department without engineers.

Instead of trying to handle the entire company context at once, Trame breaks down your intent into scoped workflows for better results.

If you're a fast-moving company, we would love to show you the future of business automation. | 33 | 4 | 3 | 1mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:39.178Z |  | 2025-11-05T15:02:52.650Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7390019493080563712 | Article |  |  | « Pour moi, l’attitude est aussi importante que les aptitudes. » 

- Robert Dutton 

Article très inspirant dans La Presse avec un homme qui nous a grandement aidé lors de notre passage à La base entrepreneuriale HEC Montréal.

Lien : https://lnkd.in/e6vBwQPV | 5 | 0 | 0 | 1mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:39.179Z |  | 2025-10-31T13:39:07.073Z | https://lp.ca/5FTHaL?sharing=true |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7382108247454797824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErMnkhRUqmxg/feedshare-shrink_800/B4EZnKEVEdHgAg-/0/1760031757185?e=1766620800&v=beta&t=gZ6XJCDv7HNOHBCUpHWGRq1prXIbPC53g3M6GVVlxoQ | J’ai peur de parler en public. 
Peur au point d'avoir des crises d’anxiété.

Ça commence par un manque d’air. 
Mon cœur se met à battre trop vite. 
Les sons deviennent lointains. 
Ma vision se brouille.

En quelques secondes, je perds contact avec ce qui m’entoure. 
L'auditoire, compatissant, voit l’entrepreneur geler devant lui.

La dernière fois était lors d'une présentation pour joindre l’accélérateur de District 3 Innovation, devant Jean-David Begin, notre mentor.

Aujourd’hui, après 10 mois de travail et grâce à la collaboration entre Le Parachute et La base entrepreneuriale HEC Montréal, ainsi qu’à la belle opportunité offerte par Marie-France Desy de Desjardins Business, j’ai eu la chance de prendre la parole lors d’un panel devant plus d’une centaine d’acteurs financiers de plusieurs pays.

Le thème ? 
Mieux soutenir les MPME pour propulser une croissance et un développement durables. Et cette fois...

Ça l'a commencé avec une blague.
Puis un auditoire qui rit.
Rapidement, une vraie discussion s’installe.
Et au final, on apprend, on échange et on en ressort grandi.

C’était une expérience incroyable.

Merci à tous ceux qui ont rendu cette expérience possible, et aux belles rencontres faites lors du panel.

France Michaud Marie-France Desy Charlene Zietsma Steve Tipman José Luis Chinchilla

Merci également à tous ceux qui m’ont aidé, de près ou de loin, durant mon cheminement personnel et professionnel.

Robert Dutton Théo Corboliou Charles Couture-Lebrun, Msc Charles Blais-Fortin Jason Elate Enric Soldevila Dominic H. Justine Labourot, erg. Gabrielle Huppé Maddie Naumann Jean-Philippe Duchesneau et tous ceux à qui je ne pense pas.

Et maintenant, avec Trame, je vois déjà les prochaines occasions de grandir et de soutenir les MPME dans leur croissance ❤️ | 88 | 28 | 0 | 1mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.622Z |  | 2025-10-09T17:42:39.132Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7381697436622168064 | Text |  |  | If you were evaluating your own product, would you buy from you? 

If your product does not yet exist, would you be a user of your product?

They’re simple questions that can help put things into perspective. | 10 | 2 | 0 | 1mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.623Z |  | 2025-10-08T14:30:14.197Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7380980211066236928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFfUzNgLOtlaQ/feedshare-shrink_800/B4EZmqiaBEIIAk-/0/1759502771854?e=1766620800&v=beta&t=lJC1FNA-IopAe2z_pb0Ew9EocoVyCyEFD-9siw947Uo | Before you integrate AI into your business ✋

Not every AI product is the same and the difference matters.

There are three main ways to approach AI today:

1. AI Forward is evolution (e.g., HubSpot)
2. AI First is intentional design (e.g., Grammarly)
3. AI Native is a new species of product (e.g., Trame)

Most companies claiming to be AI Native are really just AI Forward or AI First.

AI Native means the product would not exist without AI. 
Its entire architecture, experience and value depend on it.

An AI agent that creates and runs AI workflows to automate company processes like Trame would not exist without AI.

That is what defines a truly AI Native product. | 6 | 0 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.625Z |  | 2025-10-06T15:00:14.299Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7380965265167052800 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9a4fd37e-242a-44e6-9ae3-9c22f03c318a | https://media.licdn.com/dms/image/v2/D4E05AQHj8geozKvP2A/videocover-high/B4EZm50xbdKUB8-/0/1759759246323?e=1765778400&v=beta&t=OH7Nw-6JGN5qzh_OiNFmBRfYUXMDYMgZ2EpFsauGMts | “Keep your table cap clean”, he said 🤥

Follow Trame | 2 | 0 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.625Z |  | 2025-10-06T14:00:50.919Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7379944510614708224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJscq6X3xtFA/feedshare-shrink_800/B4EZmrUaxJHMAk-/0/1759515882506?e=1766620800&v=beta&t=dk-w8iKkImr_Y095aE8MKU94suHxs0Vc7fGQreDTUHw | « Génère une image d’un développeur logiciel qui commence à réseauter. »

Merci Marie-France Desy pour cette première soirée du Relais Affaires Desjardins !

📸 Martin Duchaîne | 30 | 4 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.626Z |  | 2025-10-03T18:24:44.069Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7379875167927164928 | Text |  |  | While people are still debating whether to write their LinkedIn posts with AI, we already have

• Fusion power on the horizon alongside safer nuclear fission
• The quest to sequence 1.8 million species with the Earth BioGenome Project
• Reusable rockets and conversations about terraforming Mars
• And now… an AI agent that builds AI workflows at Trame (saving the most impressive for last)

We don’t really care if you use AI in your posts as long as you provide value and follow Trame 👍 | 12 | 4 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.627Z |  | 2025-10-03T13:49:11.484Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7379529628018958337 | Text |  |  | You know you’re building something truly new when your CTO says the tech we need to build Trame has existed for less than 48 hours 🤯 | 9 | 0 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.627Z |  | 2025-10-02T14:56:08.350Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7379219242153566208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG4GsjXDf2SJQ/feedshare-shrink_800/B4EZmhAw24GUAk-/0/1759342965721?e=1766620800&v=beta&t=b3PfMACXRxJhH4-9MGqqiUi3Q_8Dscl4hdKznQw2PZQ | Portes ouvertes à La base entrepreneuriale HEC Montréal aujourd’hui ! Venez poser vos questions 🧐 | 43 | 2 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.628Z |  | 2025-10-01T18:22:46.593Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7378470650568544256 | Text |  |  | AI Agents vs. AI Workflows

95%+ of what people call “AI agents” are really just AI workflows.

This distinction matters: using an AI agent when you really need an AI workflow can skyrocket your costs.

AI Agent
✅ Complex tasks
❌ Less predictable
❌ Expensive

You give the problem and the AI figures out the solution.

AI Workflow
✅ Predictable
✅ Cost-effective
❌ Complex tasks

You give both the problem and the solution and the AI simply executes it.

A simple example:

Acme Inc. wants to automate daily information sharing between software A and B. The data must be cleaned, reformatted, and validated before it’s sent.

They ask an AI agent like Trame:
“I need to share product information between software A and B every day.”

The agent figures out the messy parts (format, validation) and builds an AI workflow that does it reliably every day.

👉 The agent is a one-time, expensive step to solve the complex problem.
👉 The resulting workflow is predictable and cost-effective to run every day.

In short:

AI workflow: you define the what and the how.
AI agent: you define the what, and the AI figures out the how.

Discover Trame 👉 https://www.tramehq.com/ | 11 | 0 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.629Z |  | 2025-09-29T16:48:08.451Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7375910505011453953 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEImaC-_ahJKQ/feedshare-shrink_1280/B4EZlxhH5eGcAs-/0/1758546133001?e=1766620800&v=beta&t=8X3C2clyJZ3ttJxZxDiIYWvHXaa4Ipol0Y6yuw_g_7o | We’re testing a new product and looking for a few teams to try it early.

Our goal: cut 90% of the admin work in invoice validation.

Let’s talk 👉 https://lnkd.in/euySPJwv | 19 | 2 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.630Z |  | 2025-09-22T15:15:02.185Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7373728909294604288 | Video (LinkedIn Source) | blob:https://www.linkedin.com/74986fdf-631e-46ec-bc9b-c83134eafcfb |  | Qu’est-ce qui se passe vraiment à l’intérieur d’une entreprise?
Je veux dire la vraie version, en cours, sans filtre.

C’est exactement ça, Business Audit :
45 minutes où l’on s’assoit avec un·e entrepreneur·e pour passer son entreprise en revue, Live sur Linkedin.

Le genre de conversation à laquelle j’aurais rêvé d’avoir accès quand je construisais seule : remettre en question chaque décision, me demander si mes problèmes étaient normaux, si j’étais en retard… ou juste pas faite pour ça.

Ensemble, on décortique :

Ce qu’ils vendent (et pourquoi c’est important)
À qui ils s’adressent (et s’ils les connaissent vraiment)
Ce qui fonctionne, ce qui coince et ce qui doit évoluer
Quel type d’entreprise (et de vie) ils essaient réellement de bâtir

Parce que parfois, juste entendre quelqu’un d’autre mettre ses blocages en mots, ça aide à nommer les nôtres.

L’invité de cette semaine : Christophe Roy,
Cofondateur et PDG de Fizl, une application qui aide les travailleurs autonomes à gérer leur entreprise.

Fizl est né d’une histoire personnelle : voir sa mère, femme de ménage, perdre trop de temps avec la facturation et la planification. Alors il a construit l’outil dont elle avait besoin — et l’a rendu accessible à des milliers de personnes comme elle.

Mais ce n’est pas seulement un regard dans les coulisses de l’entreprise de Christophe, c’est une vraie session de travail.

L’objectif : l’aider à affiner son focus et à propulser Fizl vers l’avant.
Et si vous nous rejoignez en direct, vous ferez aussi partie de la conversation. Votre perspective pourrait bien être ce qui l’aide à voir plus clair pour la suite.

📅 Mardi 16 Septembre à 11h (EST) — en direct sur LinkedIn. | 12 | 0 | 0 | 2mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.632Z |  | 2025-09-16T14:46:09.234Z | https://www.linkedin.com/feed/update/urn:li:activity:7363607217322762240/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7350921135565283328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGo4bDogBPCSw/feedshare-shrink_800/B4EZfmO27tGcAk-/0/1751914345376?e=1766620800&v=beta&t=e19UF8Rkb5XegNhSlTIh60NwH4PC5XMeviXewgQtrFw | Tous les moyens sont bons pour aider les entrepreneurs d’ici à se lancer !

J’ai eu la chance d’accompagner des centaines de travailleurs autonomes grâce à Fizl, et ce mercredi à 12h00, je serai aux côtés de Desjardins Business pour vous partager des solutions concrètes, en collaboration avec l’École des entrepreneurs du Québec et La Ruche (financement participatif).

Au menu : financement, accompagnement et ressources.

Inscription gratuite juste ici 👇 | 9 | 0 | 0 | 4mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.636Z |  | 2025-07-15T16:16:12.229Z | https://www.linkedin.com/feed/update/urn:li:activity:7348061352885731328/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7341861667363864576 | Video (LinkedIn Source) | blob:https://www.linkedin.com/66195f71-65fe-4d53-a7e4-f6d64fec98e3 | https://media.licdn.com/dms/image/v2/D5605AQGQg8l7A85Hmg/videocover-high/B56ZeNtB9dGQB4-/0/1750429102869?e=1765778400&v=beta&t=o6dJ5cDyh3NRuw2bUyBk3BTh3QN44n-zcpXLmuAPdy8 | What an incredible surprise at Web Summit Vancouver to hear Nishant Raina from Mastercard in conversation with Jillian Harris, Sheba Zaidi, and Geneviève S. about how small business owners are driving the Canadian economy.

As Jillian put it so well: If you're not a small business, buy from one. And if you have nothing to buy, follow one 💥 | 8 | 2 | 0 | 5mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.640Z |  | 2025-06-20T16:17:06.693Z | https://www.linkedin.com/feed/update/urn:li:activity:7341831824945422337/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7338584562744115200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHoLO8ptYEi3A/feedshare-shrink_800/B4EZdUvFCZHYAg-/0/1749473317694?e=1766620800&v=beta&t=aWNBrD0cTeyhId0Vi9dKbs1ZkVPlCsP98EHOHvmCvo8 | 🚨 $1,000,000 MILESTONE REACHED 🚨

Self-employed professionals in Quebec have invoiced over $1M using Fizl! 🎉

To celebrate, we’re launching something new:

Fizl Accounting, a new tool for CPA and bookkeepers, offers a centralized multi-client dashboard that connects directly to their clients’ app for real-time collaboration.

Think of it as the future of small business accounting, and we're looking for 20 accounting professionals to help us shape it!

👀 Discover what we're building: https://lnkd.in/e5tTpFGU
💬 Have someone in mind? Mention them in the comments!
🚀 Know a community this fits? Share it with your network!

_

🚨 JALON DE 1 000 000 $ ATTEINT 🚨

Les travailleurs autonomes du Québec ont facturé plus de 1M$ avec Fizl! 🎉

Pour célébrer, on dévoile une nouveauté :

Fizl Accounting, pour les CPA et les techniciens comptables, offre un tableau de bord multi-clients directement connecté à l’app de leurs clients.

C’est clairement l’avenir de la comptabilité pour les petites entreprises, et on cherche 20 professionnels en comptabilité pour tester !

👀 Découvre ce qu'on construit: https://lnkd.in/ejrQ3-T3
💬 Tague un professionnel en comptabilité!
🚀 Fais passer le mot dans ton réseau! | 67 | 26 | 1 | 5mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.641Z |  | 2025-06-11T15:15:04.066Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7337852228663144449 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnxia0hbru0A/feedshare-shrink_800/B4EZcgLL2FHsAk-/0/1748591500425?e=1766620800&v=beta&t=kPuijP_551u6PEe24WVKMzX8YHeYbDGlAXHx4mbOa54 | Something we haven’t talked much about, but that matters to us: the story of our name.

Ludditech Inc., the company behind Fizl, was named in honor of the 19th-century Luddites, who resisted the use of machines out of fear of being replaced.

We believe technology shouldn’t replace workers, but help them realize their potential. Businesses shouldn’t take shortcuts when it comes to people.

Thanks to Myriam Baril-Tessier for capturing our passion and to La base entrepreneuriale HEC Montréal for making this moment possible 📸 | 44 | 0 | 0 | 5mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.642Z |  | 2025-06-09T14:45:02.015Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7335344956900880385 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFLr0Z9rh8Ryw/feedshare-shrink_2048_1536/B4EZcxhXlBHsAo-/0/1748882520767?e=1766620800&v=beta&t=FxawcGLFLLk7pHJ8zmJaTVvUB2XcwRak3548qnojQM8 | Notre modèle d’affaires chez Fizl est d’offrir plus de valeur à nos clients que ce que ça leur coûte. Être là quand ça compte, c’est une belle façon d’y arriver ❤️ | 19 | 2 | 1 | 6mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.643Z |  | 2025-06-02T16:42:01.844Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7334238664186630145 | Text |  |  | AI should be used to enhance efficiency rather than productivity, but increasing speed may lead to compromises in quality. | 19 | 4 | 0 | 6mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.643Z |  | 2025-05-30T15:26:01.107Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7330603789743190017 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4D10AQG6uNMa5piZlA/ads-video-thumbnail_720_1280/B4DZbFmaGXHAAY-/0/1747071906002?e=1765778400&v=beta&t=LmzD3DC3-F7i8ueSA_RiWZpuJlkhy9syJRQl3GJw4yw | Excited to represent Fizl at Web Summit Vancouver!

Can’t wait to connect, learn, and share how we help self-employed professionals schedule, invoice, and get paid instantly.

Huge thanks to Nathalie Marcoux, Robert Dutton, Luis Cisneros Martinez, Théo Corboliou, and the entire team at La base entrepreneuriale HEC Montréal for backing ambitious founders.

#WebSummit2025 #Fizl | 19 | 2 | 0 | 6mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.647Z |  | 2025-05-20T14:42:19.507Z | https://www.linkedin.com/feed/update/urn:li:activity:7327750749029859328/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7327702015961186304 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGCmmW7h-cWHQ/feedshare-shrink_800/B4EZbE6JYEGcAk-/0/1747060301290?e=1766620800&v=beta&t=kUPW5i0Ug2xa2mw-786JhjfGQGQ4bjdp28hszgASxaw | Fizl just joined the 10th Cohort of Founder University by LAUNCH, led by Jason Calacanis! 🚀

After just a few weeks in this small pod, surrounded by incredible entrepreneurs from around the world, we’re already seeing how it's shaping our entrepreneurial journey.

Special shoutout to Maddie Naumann for welcoming us aboard. We instantly connected over the importance of keeping product quality at the heart of everything we do.

Excited to see where this journey takes us!

#Fizl #Startups #LAUNCH | 52 | 11 | 3 | 6mo | Post | Christophe Roy | https://www.linkedin.com/in/christophe-roy1 | https://linkedin.com/in/christophe-roy1 | 2025-12-08T05:03:45.648Z |  | 2025-05-12T14:31:42.725Z |  |  | 

---



---

# Christophe Roy
*Trame*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 25 |

---

## 📚 Articles & Blog Posts

### [Big News!](https://trameparis.beehiiv.com/p/big-news)
*2023-11-21*
- Category: article

### [When craft meets code: With Trame Paris CEO Ismail Tazi, ArtBlocks' Erick Calderon, and Ledger's Ian Rogers | The Ledger Podcast](https://shows.acast.com/on-the-ledger/episodes/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-artbl)
*2024-12-04*
- Category: article

### [When Craft Meets Code, with Trame Paris CEO Ismail Tazi, Art Block’s Erick Calderon, and Ledger’s Ian Rogers | Ledger](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers)
*2024-12-16*
- Category: podcast

### [Driving Disruption: Christophe Vanackere Of Trace One On The Innovative Approaches They Are Taking To Disrupt Their Industries](https://medium.com/authority-magazine/driving-disruption-christophe-vanackere-of-trace-one-on-the-innovative-approaches-they-are-taking-7b010238b63c)
*2023-12-21*
- Category: blog

### [The guy who invented VPN is now working on a unified API](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api)
*2023-12-18*
- Category: podcast

---

## 📖 Full Content (Scraped)

*10 articles scraped, 27,785 words total*

### Big News!
*357 words* | Source: **EXA** | [Link](https://trameparis.beehiiv.com/p/big-news)

![Image 1](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/a3d6221e-03dd-43ad-8281-f6993fbd1546/Trame_x_CPG.png?t=1700568472)

CPG and TRAME are officially coming together with a fresh funding round, new leadership, advisors, and slate of global events for 2024.

CPG is joining the [**TRAME**](https://trameparis.com/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) family, and together we are embarking on a journey to trailblaze the intersection of generative art and craft. In this new chapter, TRAME is also being supported by new investors 1kx, Seed Club Ventures, Flamingo DAO, and NxGen.

Soon, we will host community events and exhibitions featuring top designers and generative artists in global locales including Miami, Paris, Marrakech, and New York.

Post-acquisition by TRAME, [**Chris Cantino**](https://www.linkedin.com/in/chriscantino/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) and [**Jaime Schmidt**](https://www.linkedin.com/in/jaime-schmidt/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) will be joining as advisors to TRAME x CPG alongside others including Ian Rogers, Tony Chambers, and Yoko Choy.

Bringing an ambitious new vision to the plate, the one and only [**Ismail Tazi S**](https://www.linkedin.com/in/ismailts/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news)[](https://www.linkedin.com/in/ismailts/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news)will be taking the helm as CEO, and he will be joined by [**Jaime Derringer**](https://www.linkedin.com/in/jaimederringer/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) who is joining as Head of Brand and Editor-in-Chief!

CPG’s history with TRAME goes back to 2022 when Ismail and [**Adnane Tazi**](https://www.linkedin.com/in/adnane-tazi-9a160116/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news)(founders of TRAME) began collaborating with us on [**Craft Nouveau**](https://collectibles.trameparis.com/?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news)—a first-of-a-kind project with artist [**Alexis André**](https://twitter.com/MacTuitui?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) fusing generative art and craft, hosting events in Paris, Milan, and Lisbon.

![Image 2](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/9597159d-2dd8-4b36-b866-cd18d4a2d30f/cpg_craft-nouveau_1080x1350_Milano_03.png?t=1680628246)

![Image 3](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/32b1f308-5b31-4568-aa52-997757d5f437/DSC03479.jpg?t=1677493527)

As we collaborated, it was clear the value chain unlock was very complimentary, with each of us bringing numerous connections and skills to the table that made us stronger together.

Now with the team in place, we’re excited to double-down on our contributions to this chapter of art history by bridging digital art to our physical world. We believe that innovators at the intersection of generative art and craftsmanship will be celebrated by generations to come.

### Will anything change for existing CPG members?

While CPG programming will continue as usual, we do plan to experiment with new things! This is a great time to break out of the box and explore new member benefits, drops, and event formats.

Join us today at 11am PT where we’ll be chatting on [**CPG X**](https://twitter.com/CPGCLUB?utm_source=trameparis.beehiiv.com&utm_medium=referral&utm_campaign=big-news) about all the exciting new happenings.

Thank you to everyone for your support as always and we look forward to taking a big shot together!

---

### When craft meets code: With Trame Paris CEO Ismail Tazi, ArtBlocks' Erick Calderon, and Ledger's Ian Rogers | The Ledger Podcast
*907 words* | Source: **EXA** | [Link](https://shows.acast.com/on-the-ledger/episodes/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-artbl)

![Image 1: cover art for When craft meets code: With Trame Paris CEO Ismail Tazi, ArtBlocks' Erick Calderon, and Ledger's Ian Rogers](https://open-images.acast.com/shows/60c0ee98820ad600132f136c/1733325644556-ef447ab9-4a13-47f8-afad-f203ae8e652b.jpeg?height=750)

When craft meets code: With Trame Paris CEO Ismail Tazi, ArtBlocks' Erick Calderon, and Ledger's Ian Rogers
-----------------------------------------------------------------------------------------------------------

•

Wednesday, December 4, 2024

Welcome to the Ledger Podcast! On today's episode, we welcome Isma Tazi and Erick Calderon to the studio.

Isma is the founder of Trame, a curated gallery that offers exclusive limited-edition design pieces and artworks, all with digital provenance. It's an amazing fusion of craft and generative art.

Erick (aka Snowfro) is the man behind Art Blocks, the platform that's redefined the art world with its unique generative art drops.

Ledger worked with Trame to create the Cryptopunks Gallery at Art Block's Marfa event this year, showcasing how our latest device, Ledger Flex, can transform your device into a personal canvas while safeguarding your assets with Ledger's top-notch security.

So, sit back, relax, and join us as we chat about the intersection of craft and generative art, the importance of digital provenance, and the exciting collaborations between Trame and Ledger. Let's dive in!

Buy: shop.ledger.com

#### More episodes

[#### View all episodes](https://shows.acast.com/on-the-ledger/episodes)

*   [![Image 2](https://open-images.acast.com/shows/60c0ee98820ad600132f136c/1730122142572-4a3a283e-c37f-4085-8355-f5608e8df0ae.jpeg?height=250)](https://shows.acast.com/on-the-ledger/episodes/cryptos-privacy-problem-why-you-dont-have-privacy)[Crypto's Privacy Problem: Why you don't have privacy! -----------------------------------------------------](https://shows.acast.com/on-the-ledger/episodes/cryptos-privacy-problem-why-you-dont-have-privacy)
54:13|Friday, December 5, 2025

What happens to crypto when everything on-chain becomes encrypted by default?In this episode of the Ledger Podcast, host Kyle O’Brien (COS @ Zama) sits down with Rand Hindi (Founder & CEO @ Zama) and Charles Guillemet (CTO @ Ledger) to dive deep into privacy, fully homomorphic encryption (FHE), hardware security, and why institutional adoption is making onchain confidentiality a must-have, not a nice-to-have. 
*   [![Image 3](https://open-images.acast.com/shows/60c0ee98820ad600132f136c/1730122142572-4a3a283e-c37f-4085-8355-f5608e8df0ae.jpeg?height=250)](https://shows.acast.com/on-the-ledger/episodes/securing-value-an-enterprise-perspective-on-the-ownership-ec)[Securing Value: An Enterprise Perspective on the Ownership Economy ------------------------------------------------------------------](https://shows.acast.com/on-the-ledger/episodes/securing-value-an-enterprise-perspective-on-the-ownership-ec)
35:42|Friday, November 21, 2025

In this episode of The Ledger Podcast, we dive deep into the emerging frontier of the ownership economy, where consumers become stakeholders, loyalty becomes liquid, and brands are rebuilt from the bottom up.Our EVP of Ledger Enterprise, Sebastian Badault sat down with Ovie Faruq ,co-founder and CEO of REKT Brands, live from Ledger Op3n at 106 in Paris. From crypto-native companies to the shifting power dynamics of brand building, Ovie unpacks why traditional loyalty is broken, how brand coins reshape the value exchange, and why the next generation of global brands will be built with their communities, not above them.They discuss:Why crypto-native builders create differentlyHow brand coins reward early supportersWhy legacy giants like Pepsi & P&G can’t simply “copy” crypto-native brandsThe emotional and financial value of community-owned brandsWhat happens when consumers become co-creatorsEnjoy the episode! 
*   [![Image 4](https://open-images.acast.com/shows/60c0ee98820ad600132f136c/1763116925020-44203934-24b3-4ca3-a4e6-709141d7a46d.jpeg?height=250)](https://shows.acast.com/on-the-ledger/episodes/defense-wins-championships-with-matt-giteau-and-drew-mitchel)[Defense Wins Championships, with Matt Giteau and Drew Mitchell --------------------------------------------------------------](https://shows.acast.com/on-the-ledger/episodes/defense-wins-championships-with-matt-giteau-and-drew-mitchel)
40:57|Friday, November 14, 2025

On this special episode of the Ledger Podcast, recorded live at Ledger Op3n in Paris, Head of Brand Development Mo EL-SAYED sits down with two Australian Rugby legends, Matt Giteau and Drew Mitchell (co-hosts of Kick Offs and Kick Ons and our new Australian Ambassadors).This episode is all about value, risk, and rewriting the rules. Matt and Drew share the story of their game-changing move to France in 2011—a move that fundamentally altered the landscape of Australian rugby and led to the creation of the famous Giteau Law. They discuss how that spirit of taking control, betting on yours

*[... truncated, 4,519 more characters]*

---

### When Craft Meets Code, with Trame Paris CEO Ismail Tazi, Art Block’s Erick Calderon, and Ledger’s Ian Rogers | Ledger
*2,258 words* | Source: **EXA** | [Link](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers)

When Craft Meets Code, with Trame Paris CEO Ismail Tazi, Art Block’s Erick Calderon, and Ledger’s Ian Rogers | Ledger

===============
![Image 1](https://t.teads.tv/track?action=pageView&env=js-gtm&tag_version=8.3.1_f31e814&provider=tag&buyer_pixel_id=6887&referer=https%3A%2F%2Fwww.ledger.com%2Fthe-ledger-podcast%2Fwhen-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers&user_session_id=83606b9e-f84a-48aa-bdcf-891703b214c8&hasConsent=true&cht=timeout)[HOLIDAY SEASON: Save up to 50% and get up to $90 BTC on the best deals of the year Shop now](https://shop.ledger.com/pages/holiday-season)

[![Image 2: Ledger Academy](https://www.ledger.com/wp-content/themes/ledger-v2/public/images/ledger-academy-logo-long.svg)](https://www.ledger.com/academy "Ledger Academy")
*   [Shop Ledger](https://shop.ledger.com/)
*   [Ledger Quest](https://quest.ledger.com/)
*   [Search](https://www.ledger.com/academy/library)
*   [Crypto Glossary](https://www.ledger.com/academy/glossary)
*   [Topics](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers#)
    *   [Blockchain](https://www.ledger.com/academy/library/topic/blockchain)
    *   [Country Guides](https://www.ledger.com/academy/library/topic/country-guides)
    *   [Crypto](https://www.ledger.com/academy/library/topic/crypto)
    *   [DAOs](https://www.ledger.com/academy/library/topic/daos)
    *   [DeFi](https://www.ledger.com/academy/library/topic/defi)
    *   [Economics and Regulation](https://www.ledger.com/academy/library/topic/economics-and-regulation)
    *   [Ledger solutions](https://www.ledger.com/academy/library/topic/ledgersolutions)
    *   [Metaverse](https://www.ledger.com/academy/library/topic/metaverse)
    *   [Scams](https://www.ledger.com/academy/library/topic/scams)
    *   [Security](https://www.ledger.com/academy/library/topic/security)
    *   [Tutorials](https://www.ledger.com/academy/library/topic/tutorials)

*   [Series](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers#)
    *   [Enter The Donjon](https://www.ledger.com/academy/series/enter-the-donjon)
    *   [How I Got Hacked](https://www.ledger.com/academy/series/how-i-got-hacked)
    *   [Keep Your Crypto Safe](https://www.ledger.com/academy/series/get-your-crypto-safe)
    *   [Ledger How To's](https://www.ledger.com/academy/series/ledger-how-tos)
    *   [Reading Room](https://www.ledger.com/academy/series/reading-room)
    *   [School of Block](https://www.ledger.com/academy/series/school-of-block)
    *   [The Ledger Podcast](https://www.ledger.com/academy/series/on-the-ledger)

*   [Start learning](https://www.ledger.com/academy/what-is-web-30-everything-you-need-to-know)
*   [en English](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers#)
    *   This page is available in English only

*   [The Classroom](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers)
    *   [A) Welcome to Web3](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers)
        *   [What is Web 3.0?](https://www.ledger.com/academy/what-is-web-30-everything-you-need-to-know "What is Web 3.0?")
        *   [What Is Blockchain?](https://www.ledger.com/academy/what-is-blockchain "What Is Blockchain?")
        *   [Blockchain: Where It Started, Where It’s Going](https://www.ledger.com/academy/blockchain-generations-explained "Blockchain: Where It Started, Where It’s Going")
        *   [What Is Cryptocurrency?](https://www.ledger.com/academy/what-is-cryptocurrency "What Is Cryptocurrency?")
        *   [How Many Cryptocurrencies Are There?](https://www.ledger.com/academy/how-many-cryptos-are-there "How Many Cryptocurrencies Are There?")

    *   [B) How to secure your crypto](https://ledger.com/the-ledger-podcast/when-craft-meets-code-with-trame-paris-ceo-ismail-tazi-art-blocks-erick-calderon-and-ledgers-ian-rogers)
        *   [What Is a Private Key?](https://www.ledger.com/academy/whats-a-private-key "What Is a Private Key?")
        *   [What Is A Crypto Wallet?](https://www.ledger.com/academy/basic-basics/2-how-to-own-crypto/what-is-a-crypto-wallet "What Is A Crypto Wallet?")
        *   [What is a Seed Phrase (Secret Recovery Phrase)?](https://www.ledger.com/academy/basic-basics/2-how-to-own-crypto/whats-a-secret-recovery-phrase "What is a Seed Phrase (Secret Recovery Phrase)?")
        *   [Crypto Threats: How Crypto Gets Stolen](https://www.ledger.com/academy/basic-basics/2-how-to-own-crypto/how-crypto-gets-stolen-risks-to-beware-of "Crypto Threats: How Crypto Gets Stolen")

    *   [C) What is Ledger?](https://ledger.com/the-le

*[... truncated, 28,183 more characters]*

---

### Driving Disruption: Christophe Vanackere Of Trace One On The Innovative Approaches They Are Taking…
*2,531 words* | Source: **EXA** | [Link](https://medium.com/authority-magazine/driving-disruption-christophe-vanackere-of-trace-one-on-the-innovative-approaches-they-are-taking-7b010238b63c)

An Interview With Cynthia Corsetti
----------------------------------

[![Image 1: Cynthia Corsetti](https://miro.medium.com/v2/resize:fill:64:64/1*OuAsyJGktj-p7KXRi8iK6g.jpeg)](https://medium.com/@cynthiacorsetti?source=post_page---byline--7b010238b63c---------------------------------------)

10 min read

Dec 21, 2023

Press enter or click to view image in full size

![Image 2](https://miro.medium.com/v2/resize:fit:1000/1*WdmxqGkezivQu8gJXOI2nw.jpeg)

> **A new, data “GPS”:**Our analytics solution enables our customers to do more with their data. It’s like having a GPS for your choices, guiding you based on real insights rather than guesswork. Then there’s efficiency. Instead of wandering in the dark, you’re on a well-lit path, saving time, resources, and energy.

In _an age where industries evolve at lightning speed, there exists a special breed of C-suite executives who are not just navigating the changes but driving them. These are the pioneers who think outside the box, championing novel strategies that shatter the status quo and set new industry standards. Their approach fosters innovation, spurs growth, and leads to disruptive change that redefines their sectors. In this interview series, we are talking to disruptive C-suite executives to share their experiences, insights, and the secrets behind the innovative approaches they are taking to disrupt their industries._

_Christophe Vanackère is a strategic visionary handpicked to steer Trace One into a transformative new phase in consumer-packaged goods (CPG) and Retail innovation. As CEO of the legacy Trace One, Christophe’s priority was to modernize operations and transform it into a successful and scalable SaaS vendor. This foundational work set the stage for Trace One’s strategic acquisition of process manufacturing leader, Selerant. This pivotal move was the first significant step in fulfilling Trace One’s vision to emerge as a global leader in product lifecycle management (PLM) and Compliance solutions._

_With expertise in Software as a Service (SaaS) cloud technology and customer service, Christophe understands the nuanced demands of the evolving CPG and Retail industries. His skill in aligning business objectives with technological innovation is a cornerstone of Trace One’s strategic global expansion, now spanning 28 countries. Christophe’s leadership philosophy emphasizes profitability, people, and performance, values that are embedded in the company’s DNA._

_Under his guidance, the new Trace One is committed to empowering brands with a comprehensive approach to CPG and Retail product development. This enables companies to innovate and bring remarkable products to market faster, easier, and more profitably than ever before._

**Thank you so much for joining us in this interview series. Before we dive into our discussion about disruption, our readers would love to “get to know you” a bit better. Can you share with us the backstory about what brought you to your specific career path?**

I am a golfer, a runner, and a cyclist. If you know anything about those sports, you know that means I’m always trying to beat a personal best! My career has followed that trajectory as well, with each role building on the next and culminating here at Trace One, where I have been grateful to use my talents and skills to their full capacity.

**What do you think makes your company stand out? Can you share a story?**

More than half of us previously worked in the roles our customers work in today. We are often able to use this unique depth of knowledge and to join our prospective and current customers in overcoming the most pressing challenges in our industry. I have personally been in meetings where we spent the first ten minutes unraveling the common relationships we all have — even in this global, ever-expanding environment.

Speaking of global reach, over 26 languages are represented within Trace One. We value and nurture our diversity for its own sake but also because it helps us understand how to best serve local markets.

Our company culture also has open communication as a primary value. We follow an open-door policy to enable ideas and creativity to flow. Everyone can express their opinions about the way we do things, and we actively seek employee feedback, listen to concerns and implement changes based on input from all levels of the organization.

Employees feeling a sense of ownership and motivation are important to me because I have received invaluable mentorship from the beginning of my career. I was nurtured in cultures with open communication, and I felt heard. I could take chances that led to great outcomes. As we lead bravely and embrace disruption, agility and change at the pace that our customers need us to, we must encourage the free exchange of ideas to remain innovative at our core.

Finally, we stand out because the customer is at the center of everything we do.Our applications enhance and simplify their daily lives. We continually reassess

*[... truncated, 11,203 more characters]*

---

### The guy who invented VPN is now working on a unified API
*12,158 words* | Source: **EXA** | [Link](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api)

December 18, 2023

Roy Pereira's history in tech started in the 1990s - he saw the first boom-bust cycle and has since founded and exited a few startups.

For this, the 59th episode of the StartWell Podcast, Roy shares his experiences and perspectives as a startup founder, tech innovator, investor and Torontonian.

His current occupation is as a cofounder of [Unified](https://unified.to/) - a simple way for companies to unify data between multiple SaaS applications.

Read through the full video podcast transcript
----------------------------------------------

Table of Contents

1.   [The COVID-19 pandemic's impact on entrepreneurs and their mental health.](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-1)
2.   [Toronto's cultural diversity and tech industry growth](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-2)
3.   [Toronto's growth and infrastructure challenges](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-3)
4.   [Entrepreneurship, technology, and career development](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-4)
5.   [Entrepreneurship, innovation, and funding in the tech industry](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-5)
6.   [Tech adoption during COVID and the challenges of creating a sustainable financial model](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-6)
7.   [Entrepreneurship, marketing, and product development](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-7)
8.   [API integration and its importance in software development](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-8)
9.   [API design and translation](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-9)
10.   [Automating data integration for SaaS companies](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-10)
11.   [Entrepreneurship, funding, and business growth in 2023](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-11)
12.   [Tech growth in Toronto and remote work](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-12)
13.   [Work-life balance and urban living in Toronto](https://startwell.co/blogs/the-startwell-podcast/the-guy-who-invented-vpn-is-now-working-on-a-unified-api#ruffruff-table-of-contents-item-13)

![Image 1: RuffRuff Apps](https://ruffruff.app/assets/ruffruff-app.svg)[RuffRuff Apps](https://ruffruff.app/ "RuffRuff Apps")by[Tsun](https://tsun.ec/ "Tsun")

### The COVID-19 pandemic's impact on entrepreneurs and their mental health.

Roy Pereira 0:00 

So that was my first time in network security. I spent whatever, three, three years at the startup, doing their security, came up with a lot of internet standards, like virtual private networking. If you're doing VPN from your laptop, to your office, I came up with that in Ottawa in 1998. And we patented and then we gave it out what we gave it,

Qasim Virjee 0:20 

creating VPNs Oh, yeah, yeah.

Roy Pereira 0:22 

What entrepreneurs are forced to do right now is to go out and make revenue, right? You cannot assume that you're going to get this magical funding. Unlike during COVID. Obviously, with 0% interest, we saw this this, I call a dot COVID. eventbrite.com. Yeah. But really, it was like a co confused valuation party. Yeah, it just kept getting higher and higher and higher, until it broke.

Qasim Virjee 0:49 

Founded in 2017, start well, is Toronto's independent hub for innovators to collaborate, our podcasts relate perspectives from the world's most diverse urban population to reflect unique insights into global business, media, and culture?

Qasim Virjee 1:10 

For me, I challenged myself with the pandemic and I said, You know what, you got to have fun because as an entrepreneur, it's such a curious challenge to have to create value when there's not even a market.

Roy Pereira 1:27 

Yeah, I think there's so many directions we can go with talking about the pandemic, right. It's a black swan event. You and I've never seen it. Nobody's who's been alive? And so what do you do? And I think as

*[... truncated, 64,573 more characters]*

---

### 2020-11-01_Cote_Paris
*4,542 words* | Source: **GOOGLE** | [Link](https://fr.scribd.com/document/498618634/2020-11-01-Cote-Paris)

2020-11-01 Cote Paris | PDF | Conception | Peintures

===============

Opens in a new window Opens an external website Opens an external website in a new window

 This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. To learn more, view the following link: [Privacy Policy](https://support.scribd.com/hc/articles/210129366-Privacy-policy)

[Open navigation menu](https://fr.scribd.com/document/498618634/2020-11-01-Cote-Paris#sidebar)[![Image 1: Scribd](blob:http://localhost/d0cf58e0c96bd48797ae3249dd19d8af)](https://fr.scribd.com/)

Close suggestions Search Search

en Change Language

[Upload](https://fr.scribd.com/upload-document)

Sign in

Sign in

Download free for 30 days

0 ratings 0% found this document useful (0 votes)

2K views 240 pages

2020-11-01 Cote Paris
=====================

Ceci est un document promotionnel pour les trains à grande vitesse TGV Inoui en France. Il présente les nombreuses destinations européennes accessibles directement en train TGV, soulignant l…

Full description

Uploaded by
-----------

[Trinidad Contreras](https://www.scribd.com/user/469980965/Trinidad-Contreras)

AI-enhanced title and description

Go to previous items Go to next items
*   Download 
*   Save Save 2020-11-01_Cote_Paris For Later 
*   Share 
*   0%0% found this document useful, undefined 
*   0%, undefined 
*   Print 
*   Embed 
*   Ask AI 
*   Report 

Download

Save 2020-11-01_Cote_Paris For Later

You are on page 1/ 240

Search

Fullscreen

You are on page 1

240

![Image 2](https://html.scribdassets.com/73oabfwgw08i523x/images/1-1179494575.jpg)

ad[Download to read ad-free](https://www.scribd.com/oauth/signup?behavior_tag=download&doc_id=498618634)

Sbrvicbs c`osbih kéc`rjti`o bt c`ocbpti`o 3K bo djfjsio

Cifjhb. 

[jghb kb rbpjs, kbsifo Jokrbj Cjsjti.

H. 711 x E. 62 x Q. :11 cd. [jghb kb rbpjs jvbc 7 jhh`ofbs iotéfrébs kb ;1 cd. Qhjtbju bo c`dp`sitb vbrrb/cérjdiqub (phusiburs nioiti`os) sur uob trjvbrsb bo jhudioiud hjqué. Qiétbdbot bo phjts k’jcibr hjqué (phusiburs c`h`ris). 

* Qrix [[C 

djxidud c`osbihhé 

vjhjghb lusqu’ju 3:/:7/7171 

bo Nrjocb détr`p`hitjiob, e`rs hivrjis`o (tjrins jnniceés bo djfjsio). Bxistb bo vbrsi`o nixb. 

Gunnbt Scjhj

, kbsifo Gioj Gjitbh. 

Cejisbs H`ofitukb

, kbsifo Stuki` W`ceb G`g`is. 

Hjdpjkjirbs Nrjocis

, kbsifo Njgricb Gbrrux. 

Njgricjti`o bur`péboob. 

Nrboce

< nrjoæjis

![Image 3](https://fr.scribd.com/document/498618634/2020-11-01-Cote-Paris)

ad[Download to read ad-free](https://www.scribd.com/oauth/signup?behavior_tag=download&doc_id=498618634)

Q e`t`D i c e b h F i g b r t,o`o c`o t r j c t u b h h b.J r c e i t b c t b<w w w.j r k k b v r i b s.o h/S c u h p t u r b s D`d c i h`D i h`v j o`v i c,p`t b o t b r r b c u i t b b t t j g h b j u/F j h b r i b H b s b o t i d b o t k b s c e`s b s.

Nrboce Jrt kb ^ivrb

7 921 ₨

*

ju hibu kb 3 ;91 ₨ (k`ot :9,21 ₨ k’éc`-pjrticipjti`o)

![Image 4](https://fr.scribd.com/document/498618634/2020-11-01-Cote-Paris)

ad[Download to read ad-free](https://www.scribd.com/oauth/signup?behavior_tag=download&doc_id=498618634)

pibrrbnrby.c`d

[issus, Qjpibrs pbiots, [jpis, D`gihibr & Jccbss`irbs

NWJOCB

1: - HBS IOBWIBRWS SBQEJOB GBWFBW 1::61 Cbssy 1;21;:>3>;1: - JBHIBW QIJ 1:6:1 [`iry 1;217155:1 1> - SJWH L QJ KBC@WJI@O 1>261 Sjiot Qjuh Kb ^bocb 1>1953;197:7 - DJR^BWBU O.G.D. SJWH:7111 W`kbz 12>2>6;155:3 - SJWH C@B DJIS@O :37:1 Sjiot Wbdy Kb Qr`vbocb 1;37>719:::; - @QI@O JDBRGHBDBO:;111 Cjbo 173:526262:; - ^RBS K’IOBWIBRWS :;211 ^irb 173:29:12::> - ^BO K’BS:>111 Jof`uhbdb 12;235;51;:6 - IO KBSIFO & HINBSYHB :6>;1 ^jux Sur Dbr 12;>122 6:;71 - H’ JKWBSSB KBC@WJI@O 71111 Jljcci` 1;9277971:77 - CJSSI@QBB KBC@WS SJWH 77211 Qjidp`h 179>7122:9 7; - BS HJSC@OLJWIJS SJWH 7;261 Hb Hjrkio St Hjzjrb 12232:3317 76 - DJWIB KB GIJSI@76;11 Jcquifoy 1737;13797 79 - IKBBS 79931 Q`ot Jvbo 17951>1365 31 - QWISD KBSIFO 311:2 Oidbs Cbkbx : 1;>>>;5331 3: - NHJOBHHB KBC@WJI@O 3:111 `uh`usb 12>:7:3771 3: - KBSIFO & DJIBWBS SJWH 3:::1 `uh`usb 1>7;5>:7:6 3: - W@FBW KBHJI 3:511 Sjiot Fjukbos 12>:92733>33 - N@WOIJRU 33111 G`rkbjux 122>5:;:27 33 - JBHIBW DICEBH NBIHHB 33111 G`rkbjux 122>9>9;9;33 - JBHIBW KR NJRBRIH - ISSREBZRB 33111 G`rkbjux 122>957777 33 - NWBKBWIZRB N@RWOIBW 33111 G`rkbjux 122>;;9;1;33 - CEWIS@QEB W@Y KBC@WJI@O 33:71 Jrcjce`o 122>772;;;32 - N@RFBWJY CEWISIJO 32;11 Sjiot Djh` 17995:5>26 32 - HJ DJIS@O FBOBWJHB 32;11 Sjiot Djh` 1799;15:36 32 - ^.G.J KBC@WJI@O 326>1 D`otfbrd`ot 179973:6;:36 - JBHIBW KR KBC@W SJWH 36761 D`oth`uis / H`irb 17;6215767 35 - DHD 35971 Cr`hhbs 1;6>119::3;: - G@RWF@IO HBS JBHIBWS;:111 Gh`is 172;21>21>;: - @HI^IBW SID@OIO / SCJWHB KBC@WJI@O;::11 ^bok`db 172;63:>;>;: - BWIC D@WJOK;:7:1 D`otribux Bo S`h`fob 172;95729>;; - JK.7S;;::2 Ejutb F`uhjiob 17;11>76;5;; - D@O JWISJO JQISSIBW;;7:1 Q`roic 17;15791:;;; - H’ JBHIBW KB CBCIHB;;211 Hj Gjuhb 17;17;:751;; - DICEBH KBOIS KBC

*[... truncated, 79,214 more characters]*

---

### Voici les 30 émissions les plus attendues à la télé québécoise cet automne
*2,941 words* | Source: **GOOGLE** | [Link](https://www.journaldemontreal.com/2023/09/02/la-rentree-tele-en-30emissions-sur-les-chaines-generalistes)

**Septembre débarque avec des nouveautés plein nos écrans. Cette rentrée télévisuelle sur les quatre chaînes généralistes témoigne de la vitalité de nos productions. Les fictions occupent la majorité des heures de grande écoute. De nouveaux titres piquent la curiosité. On remarque aussi une tendance à offrir du sang neuf à des séries en misant sur des intrigues portées complètement par une nouvelle distribution.**

Plusieurs séries vues sur des plateformes font le saut sur les chaînes généralistes. Profitez-en si ce n’est déjà fait. Un investissement en variétés est aussi à souligner. Musique, grandes entrevues et têtes d’affiche reconnues pour leur humour s’installent pour égayer nos soirées. Coup d’œil sur 30 émissions pour reprendre ou développer nos habitudes télé.

**• À lire aussi -**[**Rentrée télé 2023: du nouveau, des changements et des retours**](https://www.journaldemontreal.com/2023/09/02/rentree-tele-2023-du-nouveau-des-changements-et-des-retours)**• À lire aussi -**[**Sorcières, nouvelle série de TVA: une œuvre forte et mystérieuse portée par trois actrices au sommet de leur art**](https://www.journaldemontreal.com/2023/09/06/nouvelle-serie-sorcieres-de-tva-une-oeuvre-forte-et-mysterieuse)**• À lire aussi -**[**La réponse lundi à TVA: Maxime est-il mort dans «Indéfendable»?**](https://www.journaldemontreal.com/2023/09/07/la-reponse-lundi-a-tva-maxime-est-il-mort-dans-indefendable)

### _Sorcières_

**Lundi 20 h à TVA**

**dès le 11 septembre**

La prémisse et le titre mystifient. Un bébé est trouvé abandonné dans la forêt d’un petit village. Trois sœurs – l’une journaliste, l’autre femme au foyer et la troisième coach de vie – s’y retrouvent 30 ans plus tard. Ce village les a vues grandir dans une commune fondée par leur père. De lourds secrets sont enfouis et leur présence ravive les machinations. Céline Bonnier, Marie-Joanne Boucher et Noémie O’Farrell sont à l’origine de ce drame familial et incarnent les rôles principaux.

**• À lire aussi:**[**Céline Bonnier joue une journaliste «cowboy» au lourd passé**](https://www.journaldemontreal.com/2023/09/02/sorcieres-celine-bonnier-joue-une-journaliste-cowboy-au-lourd-passe)

### _Martin Matte_ _en direct_

**Jeudi 21 h à TVA**

**dès le 28 septembre**

[![Image 1](https://m1.quebecormedia.com/emp/emp/76701_000086f6d7f614-e660-4708-a967-7d8e6d4d773c_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=3500&h=2333&width=400)](https://m1.quebecormedia.com/emp/emp/76701_000086f6d7f614-e660-4708-a967-7d8e6d4d773c_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=3500&h=2333&width=1400)

Photo Agence QMI / Mario Beauregard

L’humoriste chouchou est à la tête d’un nouveau talk-show. Il aura à ses côtés des collaborateurs réguliers et un _band_ pour assurer l’ambiance et le volet musical. Des sketches et des invités compléteront le contenu de ce rendez-vous hebdomadaire. Le direct risque d’ajouter une touche de frénésie supplémentaire.

**• À VOIR:**[**Premières images du plateau de****_Martin Matte en direct_**](https://www.journaldemontreal.com/2023/08/31/premieres-images-du-plateau-de-martin-matte-en-direct)

### _Après le déluge_

**Jeudi 21 h sur Noovo**

**dès le 14 septembre**

[![Image 2](https://m1.quebecormedia.com/emp/emp/2_9_23_A_APRESLEDELUGE_2_noovo_028630e3c07867-025e-4d89-a600-70fc26b3ab2d_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=1918&h=816&width=400)](https://m1.quebecormedia.com/emp/emp/2_9_23_A_APRESLEDELUGE_2_noovo_028630e3c07867-025e-4d89-a600-70fc26b3ab2d_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=1918&h=816&width=1400)

Photo fournie par Noovo

Cette série de Mara Joly (_La maison des folles_) suit Maxime Salomon (Penande Estime), une policière rebelle qui a pris sous son aile quatre jeunes au passé difficile afin de leur éviter un casier judiciaire. Elle les initie aux arts martiaux mixtes, ce qui risque d’avoir un impact sur sa carrière. Une série actuelle qui révèle de nouveaux visages et s’annonce percutante.

[![Image 3](https://m1.quebecormedia.com/emp/emp/2_9_23_A_APRESLEDELUGE_noovo_028629782043f5-4a0a-4ea8-8699-d16536357639_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=2048&h=865&width=400)](https://m1.quebecormedia.com/emp/emp/2_9_23_A_APRESLEDELUGE_noovo_028629782043f5-4a0a-4ea8-8699-d16536357639_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=2048&h=865&width=1400)

Photo fournie par Noovo

### _Pour une fois_

**Samedi 20 h à Télé-Québec**

**dès le 9 septembre**

[![Image 4](https://m1.quebecormedia.com/emp/emp/2_9_23_A_Pour_une_fois_2_bertrand_exertier_028659245dbe2b-a52d-4fa7-9794-02d9fcd204aa_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=8539&h=4891&width=400)](https://m1.quebecormedia.com/emp/emp/2_9_23_A_Pour_une_fois_2_bertrand_exertier_028659245dbe2b-a52d-4fa7-9794-02d9fcd204aa_ORIGINAL.jpg?impolicy=crop-resize&x=0&y=0&w=8539&h=4891&width=1400)

Photo fournie par Bertrand Exertier

Après avoir testé le concept une fois seulement l’hiver dernier, on nous revient avec ce talk-show rassembleur qui vise à briser les codes de l’entre

*[... truncated, 24,876 more characters]*

---

### Histoire-Géographie-EMC Tle
*640 words* | Source: **GOOGLE** | [Link](https://www.calameo.com/books/00059672902ad45ea9eb0)

Calaméo - Histoire-Géographie-EMC Tle

===============

[](https://www.calameo.com/)
*   [Features](javascript:void(0);)

    *   [##### Personalization Transform your documents into captivating experiences](https://www.calameo.com/personalization)
    *   [##### Integrations Connect Calaméo to your favorite applications](https://www.calameo.com/integrations)
    *   [##### Studio Make publications that look like you](https://www.calameo.com/studio)
    *   [##### Conversion Generate valuable leads from your publications](https://www.calameo.com/conversion)
    *   [##### Multi-Accounts Manage multiple accounts with the Multi-Accounts option](https://www.calameo.com/multi-account)
    *   [##### Share Disseminate your content everywhere, instantly](https://www.calameo.com/share)
    *   [##### Statistics Analyze your audience's behavior](https://www.calameo.com/analyse)
    *   [##### Subscribers Share exclusive content with your subscribers](https://www.calameo.com/subscribers)
    *   [##### Accessibility Publish accessible content](https://www.calameo.com/accessibility)

[All features](https://www.calameo.com/features)

##### Get more, right now!

Increase your account capabilities and boost your growth.

[Compare our plans](https://www.calameo.com/upgrade)

*   [Pricing](https://www.calameo.com/upgrade)
*   [Explorer](https://www.calameo.com/explorer)
*   [Resources](javascript:void(0);)

    *   [##### Blog Follow the latest news from Calaméo](https://blog.calameo.com/en/home/)
    *   [##### Guided tour Pick up this document to master Calaméo](https://www.calameo.com/guided-tour)
    *   [##### Help Center Find answers to your questions quickly](https://support.calameo.com/hc/)
    *   [##### Calaméo Mag Explore our articles and refine your ideas](https://www.calameo.com/mag)
    *   [##### Case studies Discover how to achieve your goals](https://www.calameo.com/case-studies)
    *   [##### Developers Integrate Calameo into your workflow](https://developer.calameo.com/)

##### From the blog

[Sign in](https://www.calameo.com/books/00059672902ad45ea9eb0#login)[Free sign up](https://www.calameo.com/books/00059672902ad45ea9eb0#register)

[![Image 1: Histoire-Géographie-EMC Tle](https://i.calameoassets.com/240729103605-85a95d981e9cdbf9d0a24ce6ca4ebe2e/large.jpg)](https://www.calameo.com/read/00059672902ad45ea9eb0)

**Read**

Histoire-Géographie-EMC Tle
===========================

 By [Lelivrescolaire.fr Éditions](https://www.calameo.com/accounts/596729)

Histoire-Géographie-EMC Tle - Éditions Lelivrescolaire.fr

Histoire-Géographie-EMC Tle - Éditions Lelivrescolaire.fr [Less](https://www.calameo.com/books/00059672902ad45ea9eb0#)

[Read the publication](https://www.calameo.com/read/00059672902ad45ea9eb0)

*   [More by this publisher](https://www.calameo.com/books/00059672902ad45ea9eb0#related)
*   [Share](https://www.calameo.com/books/00059672902ad45ea9eb0#share)
*   [Embed](https://www.calameo.com/books/00059672902ad45ea9eb0#embed)
*   [Add to favorites](https://www.calameo.com/books/00059672902ad45ea9eb0#favorite)
*   [Comments](https://www.calameo.com/books/00059672902ad45ea9eb0#comments)
*   [](https://www.calameo.com/books/00059672902ad45ea9eb0#flag)

[![Image 2: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/000596729c9fe18324eef)

[New Fireworks 2de](https://www.calameo.com/books/000596729c9fe18324eef)

8 months ago

[![Image 3: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/00059672991220ad000ad)

[Nuevo Hispamundo 2de](https://www.calameo.com/books/00059672991220ad000ad)

8 months ago

[![Image 4: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/000596729b43bc662dc26)

[FRANÇAIS TLE BAC PRO - TEMPS CAHIER](https://www.calameo.com/books/000596729b43bc662dc26)

a year ago

[![Image 5: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/000596729375f142795c3)

[Enseignement Scientifique Terminale - Ed...](https://www.calameo.com/books/000596729375f142795c3 "Enseignement Scientifique Terminale - Edition 2024")

2 years ago

[![Image 6: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/000596729c59e54022478)

[Enseignement Scientifique 1re - Edition ...](https://www.calameo.com/books/000596729c59e54022478 "Enseignement Scientifique 1re - Edition 2023")

2 years ago

[![Image 7: Histoire-Géographie-1re Technologique](https://s.calameoassets.com/pinwheel/platform/img/blank_book.gif)](https://www.calameo.com/books/000596729e1c72f25d870)

[HISTOIRE-GÉOGRAPHIE-EMC 2DE BAC PRO - CA...](https://www.calameo.com/books/000596729e1c72f25d870 "HISTOIRE-GÉOGRAPHIE-EMC 2DE BAC PRO - CAHIE

*[... truncated, 7,644 more characters]*

---

### Histoire - Tle
*689 words* | Source: **GOOGLE** | [Link](https://www.calameo.com/books/00059672922b79d9275cf)

Calaméo - Histoire - Tle

===============

[](https://www.calameo.com/)
*   [Features](javascript:void(0);)

    *   [##### Personalization Transform your documents into captivating experiences](https://www.calameo.com/personalization)
    *   [##### Integrations Connect Calaméo to your favorite applications](https://www.calameo.com/integrations)
    *   [##### Studio Make publications that look like you](https://www.calameo.com/studio)
    *   [##### Conversion Generate valuable leads from your publications](https://www.calameo.com/conversion)
    *   [##### Multi-Accounts Manage multiple accounts with the Multi-Accounts option](https://www.calameo.com/multi-account)
    *   [##### Share Disseminate your content everywhere, instantly](https://www.calameo.com/share)
    *   [##### Statistics Analyze your audience's behavior](https://www.calameo.com/analyse)
    *   [##### Subscribers Share exclusive content with your subscribers](https://www.calameo.com/subscribers)
    *   [##### Accessibility Publish accessible content](https://www.calameo.com/accessibility)

[All features](https://www.calameo.com/features)

##### Get more, right now!

Increase your account capabilities and boost your growth.

[Compare our plans](https://www.calameo.com/upgrade)

*   [Pricing](https://www.calameo.com/upgrade)
*   [Explorer](https://www.calameo.com/explorer)
*   [Resources](javascript:void(0);)

    *   [##### Blog Follow the latest news from Calaméo](https://blog.calameo.com/en/home/)
    *   [##### Guided tour Pick up this document to master Calaméo](https://www.calameo.com/guided-tour)
    *   [##### Help Center Find answers to your questions quickly](https://support.calameo.com/hc/)
    *   [##### Calaméo Mag Explore our articles and refine your ideas](https://www.calameo.com/mag)
    *   [##### Case studies Discover how to achieve your goals](https://www.calameo.com/case-studies)
    *   [##### Developers Integrate Calameo into your workflow](https://developer.calameo.com/)

##### From the blog

[Sign in](https://www.calameo.com/books/00059672922b79d9275cf#login)[Free sign up](https://www.calameo.com/books/00059672922b79d9275cf#register)

[![Image 1: Histoire - Tle](https://i.calameoassets.com/240729114625-b214e35c5385b05ffd3e50825c25fea6/large.jpg)](https://www.calameo.com/read/00059672922b79d9275cf)

**Read**

Histoire - Tle
==============

 By [Lelivrescolaire.fr Éditions](https://www.calameo.com/accounts/596729)

Histoire Tle - Éditions Lelivrescolaire.fr

Histoire Tle - Éditions Lelivrescolaire.fr [Less](https://www.calameo.com/books/00059672922b79d9275cf#)

[Read the publication](https://www.calameo.com/read/00059672922b79d9275cf)

*   [More by this publisher](https://www.calameo.com/books/00059672922b79d9275cf#related)
*   [Share](https://www.calameo.com/books/00059672922b79d9275cf#share)
*   [Embed](https://www.calameo.com/books/00059672922b79d9275cf#embed)
*   [Add to favorites](https://www.calameo.com/books/00059672922b79d9275cf#favorite)
*   [Comments](https://www.calameo.com/books/00059672922b79d9275cf#comments)
*   [](https://www.calameo.com/books/00059672922b79d9275cf#flag)

[![Image 2: New Fireworks 2de](https://i.calameoassets.com/250521094156-e1a6965c816415b82b65691143922c72/large.jpg)](https://www.calameo.com/books/000596729c9fe18324eef)

[New Fireworks 2de](https://www.calameo.com/books/000596729c9fe18324eef)

8 months ago

[![Image 3: Nuevo Hispamundo 2de](https://i.calameoassets.com/250422173353-52a3f5f112105c4ef05cfeb1ddffc6ed/large.jpg)](https://www.calameo.com/books/00059672991220ad000ad)

[Nuevo Hispamundo 2de](https://www.calameo.com/books/00059672991220ad000ad)

8 months ago

[![Image 4: FRANÇAIS TLE BAC PRO - TEMPS CAHIER](https://i.calameoassets.com/240716105327-2dac7165fd0026a4aa5ac3810f9219ac/large.jpg)](https://www.calameo.com/books/000596729b43bc662dc26)

[FRANÇAIS TLE BAC PRO - TEMPS CAHIER](https://www.calameo.com/books/000596729b43bc662dc26)

a year ago

[![Image 5: Enseignement Scientifique Terminale - Edition 2024](https://i.calameoassets.com/240827101342-db39b2ee9020623963a52278412c7841/large.jpg)](https://www.calameo.com/books/000596729375f142795c3)

[Enseignement Scientifique Terminale - Ed...](https://www.calameo.com/books/000596729375f142795c3 "Enseignement Scientifique Terminale - Edition 2024")

2 years ago

[![Image 6: Enseignement Scientifique 1re - Edition 2023](https://i.calameoassets.com/250605170305-b90b1b0897396408bd451cc2968c4a49/large.jpg)](https://www.calameo.com/books/000596729c59e54022478)

[Enseignement Scientifique 1re - Edition ...](https://www.calameo.com/books/000596729c59e54022478 "Enseignement Scientifique 1re - Edition 2023")

2 years ago

[![Image 7: HISTOIRE-GÉOGRAPHIE-EMC 2DE BAC PRO - CAHIER D'EXERCICE](https://i.calameoassets.com/230424092318-692d74d05c774eed52710b25da5b7a22/large.jpg)](https://www.calameo.com/books/000596729e1c72f25d870)

[HISTOIRE-GÉOGRAPHIE-EMC 2DE BAC PRO - CA...](https://www.calameo.com/books/000596729e1c72f25d870 "HISTOIRE-GÉO

*[... truncated, 7,771 more characters]*

---

### Histoire-Géographie-1re Technologique
*762 words* | Source: **GOOGLE** | [Link](https://www.calameo.com/books/0005967298c1d956eed08)

Calaméo - Histoire-Géographie-1re Technologique

===============

[](https://www.calameo.com/)
*   [Features](javascript:void(0);)

    *   [##### Personalization Transform your documents into captivating experiences](https://www.calameo.com/personalization)
    *   [##### Integrations Connect Calaméo to your favorite applications](https://www.calameo.com/integrations)
    *   [##### Studio Make publications that look like you](https://www.calameo.com/studio)
    *   [##### Conversion Generate valuable leads from your publications](https://www.calameo.com/conversion)
    *   [##### Multi-Accounts Manage multiple accounts with the Multi-Accounts option](https://www.calameo.com/multi-account)
    *   [##### Share Disseminate your content everywhere, instantly](https://www.calameo.com/share)
    *   [##### Statistics Analyze your audience's behavior](https://www.calameo.com/analyse)
    *   [##### Subscribers Share exclusive content with your subscribers](https://www.calameo.com/subscribers)
    *   [##### Accessibility Publish accessible content](https://www.calameo.com/accessibility)

[All features](https://www.calameo.com/features)

##### Get more, right now!

Increase your account capabilities and boost your growth.

[Compare our plans](https://www.calameo.com/upgrade)

*   [Pricing](https://www.calameo.com/upgrade)
*   [Explorer](https://www.calameo.com/explorer)
*   [Resources](javascript:void(0);)

    *   [##### Blog Follow the latest news from Calaméo](https://blog.calameo.com/en/home/)
    *   [##### Guided tour Pick up this document to master Calaméo](https://www.calameo.com/guided-tour)
    *   [##### Help Center Find answers to your questions quickly](https://support.calameo.com/hc/)
    *   [##### Calaméo Mag Explore our articles and refine your ideas](https://www.calameo.com/mag)
    *   [##### Case studies Discover how to achieve your goals](https://www.calameo.com/case-studies)
    *   [##### Developers Integrate Calameo into your workflow](https://developer.calameo.com/)

##### From the blog

[Sign in](https://www.calameo.com/books/0005967298c1d956eed08#login)[Free sign up](https://www.calameo.com/books/0005967298c1d956eed08#register)

[![Image 1: Histoire-Géographie-1re Technologique](https://i.calameoassets.com/210621121817-c96cea0057eb80d14703755eb63cfec9/large.jpg)](https://www.calameo.com/read/0005967298c1d956eed08)

**Read**

Histoire-Géographie-1re Technologique
=====================================

 By [Lelivrescolaire.fr Éditions](https://www.calameo.com/accounts/596729)

1 re Cartes et frises en Tous les cours version résumés interactive en vidéo LLS.fr/HG1Tcartes LLS.fr/HGT1cours VOIE TECHNOLOGIQUE MANUEL COLLABORATIF Histoire Géographie Nouveau Enseignement moral et civique Plus de 40 pages pour préparer les évaluations... [More](https://www.calameo.com/books/0005967298c1d956eed08#)

1 re Cartes et frises en Tous les cours version résumés interactive en vidéo LLS.fr/HG1Tcartes LLS.fr/HGT1cours VOIE TECHNOLOGIQUE MANUEL COLLABORATIF Histoire Géographie Nouveau Enseignement moral et civique Plus de 40 pages pour préparer les évaluations communes IMPRIMÉ EN FRANCE manuel numérique consultable gratuitement [Less](https://www.calameo.com/books/0005967298c1d956eed08#)

[Read the publication](https://www.calameo.com/read/0005967298c1d956eed08)

*   [More by this publisher](https://www.calameo.com/books/0005967298c1d956eed08#related)
*   [Share](https://www.calameo.com/books/0005967298c1d956eed08#share)
*   [Embed](https://www.calameo.com/books/0005967298c1d956eed08#embed)
*   [Add to favorites](https://www.calameo.com/books/0005967298c1d956eed08#favorite)
*   [Comments](https://www.calameo.com/books/0005967298c1d956eed08#comments)
*   [](https://www.calameo.com/books/0005967298c1d956eed08#flag)

[![Image 2: New Fireworks 2de](https://i.calameoassets.com/250521094156-e1a6965c816415b82b65691143922c72/large.jpg)](https://www.calameo.com/books/000596729c9fe18324eef)

[New Fireworks 2de](https://www.calameo.com/books/000596729c9fe18324eef)

8 months ago

[![Image 3: Nuevo Hispamundo 2de](https://i.calameoassets.com/250422173353-52a3f5f112105c4ef05cfeb1ddffc6ed/large.jpg)](https://www.calameo.com/books/00059672991220ad000ad)

[Nuevo Hispamundo 2de](https://www.calameo.com/books/00059672991220ad000ad)

8 months ago

[![Image 4: FRANÇAIS TLE BAC PRO - TEMPS CAHIER](https://i.calameoassets.com/240716105327-2dac7165fd0026a4aa5ac3810f9219ac/large.jpg)](https://www.calameo.com/books/000596729b43bc662dc26)

[FRANÇAIS TLE BAC PRO - TEMPS CAHIER](https://www.calameo.com/books/000596729b43bc662dc26)

a year ago

[![Image 5: Enseignement Scientifique Terminale - Edition 2024](https://i.calameoassets.com/240827101342-db39b2ee9020623963a52278412c7841/large.jpg)](https://www.calameo.com/books/000596729375f142795c3)

[Enseignement Scientifique Terminale - Ed...](https://www.calameo.com/books/000596729375f142795c3 "Enseignement Scientifique Terminale - Edition 2024")

2 years ago

[![Image 6: Enseignement Sc

*[... truncated, 8,324 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[2020-11-01 Cote Paris | PDF | Conception | Peintures](https://fr.scribd.com/document/498618634/2020-11-01-Cote-Paris)**
  - Source: fr.scribd.com
  - *Nov 1, 2020 ... 33 - CHRISTOPHE ROY DECORATION 33120 Arcachon 0556225444 BOJOLI by Josephine de Wild 2900 Schoten 0496234568 ... trame élégante rappel...*

- **[Voici les 30 émissions les plus attendues à la télé québécoise cet ...](https://www.journaldemontreal.com/2023/09/02/la-rentree-tele-en-30emissions-sur-les-chaines-generalistes)**
  - Source: journaldemontreal.com
  - *Sep 1, 2023 ... Christophe (Roy Dupuis) et Gabrielle (Eve Landry) partagent une ... Dolan a mis tout son talent pour nourrir cinq épisodes denses et u...*

- **[Histoire-Géographie-EMC Tle - Calaméo](https://www.calameo.com/books/00059672902ad45ea9eb0)**
  - Source: calameo.com
  - *... Christophe Roy, professeur Vincent Ortiz, professeur agrégé certifié à ... trame des pages jusqu'au paysage institutionnel de la France. La puis- ...*

- **[Histoire - Tle - Calaméo](https://www.calameo.com/books/00059672922b79d9275cf)**
  - Source: calameo.com
  - *... Christophe Roy, professeur certifiée au Collège Georges Alexandra Topart ... trame au plus profond des êtres. [...] La société agit sur la sphère ...*

- **[Histoire-Géographie-1re Technologique - Calaméo](https://www.calameo.com/books/0005967298c1d956eed08)**
  - Source: calameo.com
  - *... Christophe Roy, professeur certifié à l'Établissement (Belgique) français d ... trame ressenties : on sursaute avec lui, on suffoque, on n'en au r...*

- **[[LE_MONDE - 1] LE_MONDE/PAGES<UNE> ... 26/02/01](https://scholar.lib.vt.edu/InterNews/LeMonde/issues/2001/monde.20010225.pdf)**
  - Source: scholar.lib.vt.edu
  - *Feb 25, 2001 ... ... trame romanesque. La jeune Barbara, orpheline, vit chez sa tante ... Christophe Roy, violoncelle,. Rula Safar et Françoise Atlan ...*

- **[Untitled](https://festivalmusica.fr/telecharger/40)**
  - Source: festivalmusica.fr
  - *même temps construit une trame qui évolue lentement, sous l'effet de l'injection ... Avec le violoncelliste Christophe ROY et l'accordéoniste Pascal C...*

- **[Université d'Évry-val-d'Essonne Master 2 – Ingénierie artistique ...](https://www.biblio.univ-evry.fr/memoires/2016/2016_MM2_IngenierieMusicale_Boissiere.pdf)**
  - Source: biblio.univ-evry.fr
  - *de la trame théâtrale s'y déroule. Je pense que je ne l'aurais jamais fait ... 264 Christophe Roy était professeur de violoncelle moderne au CRC d'Évr...*

- **[m u s i c a](https://festivalmusica.fr/telecharger/38/programme-2001.pdf)**
  - Source: festivalmusica.fr
  - *de la trame sur lequel il suffirait de tirer… La pièce porte le titre ... et le violoncelliste Christophe Roy. Il forme un duo avec la contrebassiste ...*

- **[Ecrits de Christian Dachez - Christian Dachez, compositeur](https://www.dachez-compositeur.com/fr/ecrits-de-christian-dachez.html)**
  - Source: dachez-compositeur.com
  - *La complémentarité des deux instruments, toujours en décalage, assure le contrepoint au-dessus d'une trame harmonique basée sur des éléments répétitif...*

---

*Generated by Founder Scraper*
