# Michael Hazari

## Position actuelle

**Titre** : Founder
**Entreprise** : PharmaBase Remplacement
**Durée dans le rôle** : 2 years 10 months in role
**Durée dans l'entreprise** : 2 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Retail Pharmacies

## Résumé

Pharmacien diplômé du PharmD de l’Université de Montréal en 2021, j'ai acquis une solide expérience en tant que pharmacien salarié au sein d'un Pharmaprix à Laval pendant un an. Par la suite, j'ai exploré divers environnements de travail à travers le Québec en tant que remplaçant communautaire, y compris au Conseil Cri de la Baie-James pendant près de deux ans. 

Constatant les défis fréquents rencontrés dans le domaine du remplacement, j'ai lancé PharmaBase, une plateforme innovante destinée à améliorer la connexion entre propriétaires de pharmacies et remplaçants. PharmaBase permet aux propriétaires de publier des mandats et de communiquer directement avec les remplaçants, réduisant ainsi les frais des intermédiaires et favorisant la réinvestissement dans leurs pharmacies. Notre mission est de valoriser la profession de pharmacien et d'augmenter la rémunération des pharmaciens et ATP, tant salariés que remplaçants.

Pour en savoir plus, visitez les liens suivants: 

Notre page LinkedIn : [PharmaBase](https://www.linkedin.com/company/pharmabase-remplacement/) 

Notre site web : [PharmaBase](https://www.pharma-base.com) 

Téléchargez notre application sur l’Apple Store : [PharmaBase](https://apps.apple.com/ca/app/pharmabase/id6477830395).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAE2WHsABM_tztLAJXtk1h3lDc69uW3BF2Hg/
**Connexions partagées** : 2


---

# Michael Hazari

## Position actuelle

**Entreprise** : PharmaBase Remplacement

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Michael Hazari

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403463304188231681 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQHNu4MU12vrdw/mp4-720p-30fp-crf28/B4EZrqC5RuGYCI-/0/1764863226390?e=1765785600&v=beta&t=o27COGykpT2iO-df-sfNLxHQGgqbdpIS2icroQL7a3A | https://media.licdn.com/dms/image/v2/D4E05AQHNu4MU12vrdw/videocover-high/B4EZrqC5RuGYBU-/0/1764863222318?e=1765785600&v=beta&t=YWxpu0jThFgrXqpuUZoL7hcQtVncU6TwPdv-GJ93lD0 | 💬 Saviez-vous que le taux de postes vacants en pharmacie communautaire serait de 12 % comparativement à 3 % pour le Québec, tous secteurs confondus. Une réalité qui pousse plusieurs propriétaires à vouloir embaucher les bons remplaçants.
 
Chez Pharmabase, la liberté est au cœur de notre vision.
Contrairement aux agences traditionnelles, on ne met aucun frein à l’embauche :
👉 Pas de clause de non-sollicitation.
Si un match fonctionne, tant mieux — embauchez-le.
 
Plusieurs postes permanents ont déjà été comblés grâce à Pharmabase.
Et c’est exactement comme ça qu’on souhaite contribuer à la profession!
 
1) Pour télécharger dans le App Store:
 https://lnkd.in/d-aH5D2V
2) Pour télécharger dans Google Play:
 https://lnkd.in/epRxPB3j | 7 | 1 | 1 | 15h | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:16.614Z |  | 2025-12-07T16:00:01.415Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392206691309715460 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8baed06c-4f4d-47d3-ae04-736b9d958155 | https://media.licdn.com/dms/image/v2/D4D05AQHG4KkRwXOluw/videocover-high/B4DZpUdGQCIABY-/0/1762353512209?e=1765785600&v=beta&t=RCwszHftr8QjY5a9J1rp1z_DBCeUJP-_4EeBf87z0jU | Des frais exorbitants quittent l’industrie de la pharmacie.
Et vont directement… dans les poches des agences de remplacement.
Ça n’a aucun sens — surtout quand notre réseau est en crise.
 
📉 On manque de personnel. On manque de ressources.
Et pourtant, on continue à nourrir des intermédiaires?
 
Pharmabase, c’est une solution simple et pas chère.
Créée par un pharmacien, pour les pharmaciens.
✅ Pas de commission à l’heure.
✅ Un abonnement fixe pour les propriétaires.
Pour que l’argent reste là où il doit rester : dans notre industrie.
 
Pour télécharger l'app, le lien est dans les commentaires!
Propriétaires, écrivez-nous un courriel à info@pharma-base.com pour obtenir un code promo!
#pharmacie #remplacement #pharmacien #remplacant #app | 31 | 3 | 2 | 1mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:16.615Z |  | 2025-11-06T14:30:15.767Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7388260362242113536 | Text |  |  | Plusieurs m’ont demandé mon avis sur le PL2. Après avoir échangé avec des pharmaciens salariés, remplaçants et propriétaires, je partage ici une réflexion que beaucoup d’entre nous ont en commun.

 Association québécoise des pharmaciens propriétaires (AQPP)
Marie-Pascale Beaulieu | 38 | 5 | 0 | 1mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:16.615Z |  | 2025-10-26T17:08:57.598Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7388227932273463297 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a46214ef-56e0-4e47-8008-ce52faec2d95 | https://media.licdn.com/dms/image/v2/D5605AQG1oZsToi_PMg/videocover-high/B56ZnjFWndKICA-/0/1760451463029?e=1765785600&v=beta&t=o0RC7jmJosQSxg-m3cf-A7BxsZ3MiBZYoOwnUCqR3UY | 🎄 Le temps des Fêtes approche (déjà) — et avec lui, des besoins de vacances bien méritées.
Mais qui va couvrir ? 👀
Chaque année, on voit des offres publiées à la dernière minute, dans l’urgence… et parfois, sans succès.
🗓️ Notre conseil : planifiez d’avance vos contrats de remplacement.
Publiez-les dès maintenant sur Pharmabase, pour avoir le temps de choisir les bons candidats et éviter le stress de décembre.
Pour télécharger l'app, le lien est dans les commentaires!
#pharmacie #remplacement #pharmacien #remplacant #app | 6 | 2 | 0 | 1mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:16.616Z |  | 2025-10-26T15:00:05.691Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7373709770601558016 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e79c4a6b-971b-4db9-87a0-cc07cde5de56 | https://media.licdn.com/dms/image/v2/D4D05AQEIIBlqadIbhw/videocover-high/B4DZlOwMP2IECA-/0/1757962885430?e=1765785600&v=beta&t=Ftyld5kfU939HzFvhtQUlgEiVkNJJscl5yTjHHjjFt0 | Pendant longtemps, j’ai fait mes factures comme bien des remplaçants :
📄 sur Excel, 
✍️ à la main,
Et chaque fois, c’était pareil : ça me prenait trop de temps.
Je devais revérifier les calculs, reformater, convertir en PDF, envoyer à la bonne personne…
Bref, ce n’était jamais simple.
C’est exactement ce genre de petits irritants — qu’on finit par accepter — que je voulais éliminer avec Pharmabase. C’est pourquoi on a intégré un générateur de factures directement dans l’application.
🧾 Tu peux créer une facture claire et complète en quelques clics,
📤 l’envoyer directement au comptable ou à la pharmacie,
✅ et garder une trace bien classée de toutes tes factures, au même endroit.
C’est une vraie amélioration dans notre quotidien de pharmacien remplaçant!
Et ce genre de petits gains, mis bout à bout… ça fait une différence.
📲 Téléchargez l’app Pharmabase et essayez-le par vous-mêmes.
(Lien dans les commentaires) | 13 | 2 | 1 | 2mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.523Z |  | 2025-09-16T13:30:06.214Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7371911201859162112 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1cc0fd3a-97d0-47b6-946b-24c79830404c | https://media.licdn.com/dms/image/v2/D5605AQFj4gVRjjZTkA/videocover-high/B56Zk5KDQgJ8CI-/0/1757600575230?e=1765785600&v=beta&t=stzgTPh143OFZW2PuBIiCvp2qKB64mFJmIO_tHYLP2w | Selon l’AQPP, il manque aujourd’hui jusqu'à 1 100 pharmaciens au Québec.
C’est énorme.

Comme plusieurs, on pointe souvent le remplacement comme cause du problème.

Mais pour moi, la vraie question, c’est : qu’est-ce qui empêche ces pharmaciens-là de rester à long terme dans une pharmacie qui les conviendrait?

Et une partie de la réponse, ce sont les clauses de non-sollicitation imposées par certaines agences.

Elles empêchent un pharmacien remplaçant d’être embauché par une pharmacie… même si les deux parties le souhaitent.

C’est un des freins importants à l’embauche — et donc, à la stabilité.

C’est pour ça que chez Pharmabase, on a fait un choix clair :

✅ Aucune clause.

✅ Juste un contact direct entre pharmaciens propriétaires et remplaçants.

Parce que redonner de la liberté, c’est aussi une façon de faire avancer notre industrie. | 27 | 0 | 0 | 2mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.524Z |  | 2025-09-11T14:23:14.010Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7371173045270392832 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e2c5dbf9-cef8-4a9e-9f29-283c1397f179 | https://media.licdn.com/dms/image/v2/D4D05AQGu5igMyU3dUg/videocover-low/B4DZkuoP4UIYCE-/0/1757423935070?e=1765785600&v=beta&t=8sPPRo6uuEM7SV0Gn5wiSP6vKqlmVrD7fpp32dnfHMs | Ça fait un an que j’ai commencé à faire du contenu sur les réseaux sociaux pour promouvoir Pharmabase. 🎥

Et laissez-moi vous dire : c’est tout un défi.
 
Au début, c’était gênant… parfois, dire une simple phrase pouvait me prendre 5 prises, parce que je voulais que chaque petit détail soit parfait.
 
Avec le temps, j’ai appris à être plus à l’aise et même à m’amuser devant la caméra. Et au final, c’est ça le plus important pour moi : montrer le côté humain de Pharmabase. Donner une personnalité à cette plateforme et vous rappeler qu’il y a un pharmacien, un remplaçant, un humain comme vous, derrière cette application. 👨‍⚕️
 
Restez à l’affût, car du nouveau contenu avec des sujets chauds s’en vient prochainement! 🔥 | 31 | 0 | 1 | 2mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.525Z |  | 2025-09-09T13:30:03.765Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7361750996726755328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7f668024-3162-4da8-a797-eaff79af7175 | https://media.licdn.com/dms/image/v2/D4D05AQHs8bI91yZ9kw/videocover-high/B4DZiLpAEyGQCI-/0/1754689450201?e=1765785600&v=beta&t=CEbH6XLT7w88H-HoAJV4QIP227epyusE1HWY2loMc_k | Une des choses les plus importantes pour moi, quand j’ai eu l’idée de créer Pharmabase, c’était que tout le monde se sente à l’aise avec l’utilisation de l’application.
 
Je le sais : la technologie, ça peut parfois être un frein.
 
Et dans un milieu aussi exigeant que la pharmacie, on n’a pas toujours le temps ou l’énergie pour « comprendre une nouvelle plateforme ».
 
C’est pourquoi on a mis en place un support humain, simple et accessible :
💬 Vous pouvez nous écrire par chat
📞 Ou on peut vous appeler pour tout vous expliquer, étape par étape.
 
Publier un contrat, postuler à un shift, naviguer dans l’app… Peu importe le niveau de familiarité avec la techno, on est là pour accompagner chaque utilisateur.
 
Parce que chaque utilisateur mérite un accompagnement personnalisé, peu importe son niveau de confort avec la techno.
 
Téléchargez l'application dès maintenant!
Disponible sur le App Store et Google Play | 13 | 0 | 0 | 3mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.525Z |  | 2025-08-14T13:30:12.339Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7360663869872074752 | Video (LinkedIn Source) | blob:https://www.linkedin.com/cb02d228-9ef0-4b26-b843-cf38b2a83e99 | https://media.licdn.com/dms/image/v2/D4D05AQFN5muPQWJazQ/videocover-high/B4DZiLn0KtGkCI-/0/1754689147591?e=1765785600&v=beta&t=ykxSeM3oIy5-MmP4Qj8BoQrO-4faAei8cTxxM8pTH2M | 💡 En tant que pharmacien remplaçant, j’ai souvent senti qu’on pouvait faire mieux pour faciliter nos démarches au quotidien.
 
Pharmabase est donc née de ce genre de réflexions.
 
Pas une agence, mais une plateforme qui facilite les échanges entre remplaçants et propriétaires.
 
Elle permet notamment de :
✅ Créer des liens avec les pharmacies
✅ Discuter directement du taux horaire
✅ Générer des factures en quelques clics — et les envoyer au comptable si besoin
 
📲 Disponible sur l’App Store et Google Play.
 
🙏 Merci à Paola Frengul, pharmacienne remplaçante et utilisatrice engagée, pour son témoignage et sa participation. | 7 | 0 | 0 | 3mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.526Z |  | 2025-08-11T13:30:21.099Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7355590397026353154 | Video (LinkedIn Source) | blob:https://www.linkedin.com/74331d5e-d849-4bbb-bb5f-208ace5f0af3 | https://media.licdn.com/dms/image/v2/D4D05AQEE9HzqiwfHpQ/videocover-high/B4DZfNzTIaHACI-/0/1751504483955?e=1765785600&v=beta&t=BNBF7uDBBqUGH7JCwYz4rSEbVf3Zpj6o1kujgazd7EE | 💡 Chez Pharmabase, l’argent des remplacements n’est pas détourné.

Il reste entre les mains des pharmaciens propriétaires, sans commissions prélevées à l’externe.

Cette approche permet aux propriétaires de réinvestir directement dans ce qui compte vraiment :
✅ La rémunération de leurs équipes.
✅ Le développement et l’aménagement des aires cliniques.
✅ L’innovation et l’amélioration continue des services offerts.

C’est un modèle qui soutient l’évolution de la profession et qui contribue à la pérennité de notre industrie. 

Nous croyons fermement que chaque remplacement doit profiter avant tout à ceux qui font vivre la pharmacie au quotidien.

Paola Frengul

** 📌 Notre plateforme est financée par un abonnement annuel assumé uniquement par les propriétaires. | 10 | 0 | 0 | 4mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.527Z |  | 2025-07-28T13:30:10.912Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7353053673536548865 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e33bfd52-d0cb-4395-a063-373e06495bf3 | https://media.licdn.com/dms/image/v2/D4D05AQEa_ey2XnBz4g/videocover-high/B4DZgVG6lIGQCM-/0/1752700801463?e=1765785600&v=beta&t=5oIaFWJyfMu9pWcvuH0o01yCu5eehg8O9yP65jJEIIs | Travailler comme pharmacien remplaçant, c’est aussi apprendre à s’adapter — parfois loin de chez soi, dans des milieux qu’on ne connaît pas encore, avec des équipes qu’on découvre sur le moment.

Ce jour-là, la pharmacie était à une heure de route.
 
Heureusement, en tant que remplaçant qui utilise Pharmabase, je peux me concentrer sur l’essentiel :
• Négocier mon taux directement avec la propriétaire
• Envoyer mes factures au comptable via l’outil intégré
• Lancer le GPS vers la pharmacie sans quitter l’app
 
Le remplacement, ce n’est pas juste combler un besoin temporaire.
C’est une façon de sortir de sa zone de confort et d’apprendre à s’ajuster.
 
Et bonne nouvelle : Pharmabase est maintenant disponible sur Google Play ! 🎉
 
📲 Téléchargez l’app dès maintenant — lien dans les commentaires ! | 36 | 1 | 1 | 4mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.528Z |  | 2025-07-21T13:30:08.902Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7350516957005189122 | Video (LinkedIn Source) | blob:https://www.linkedin.com/08166a29-c214-4eb4-997d-31e9ad216ea8 | https://media.licdn.com/dms/image/v2/D4D05AQErwUWU-4mg2A/videocover-high/B4DZfNx7geGsCI-/0/1751504128821?e=1765785600&v=beta&t=19hUZ4jfmySkf0NQR0NT80yI-AQI9MTo6SjUlGpNK18 | 💡 Remplacement en pharmacie : équilibre idéal ou instabilité difficile à gérer ?

Le travail en remplacement offre souvent une grande flexibilité, permettant aux pharmaciens de concilier vie professionnelle, passions et équilibre personnel. 

Mais pour d’autres, l’absence de stabilité et la nécessité de s’adapter en permanence représentent de vrais défis.

Ce choix de carrière est-il vraiment adapté à tous ?

Chez Pharmabase, nous croyons qu’il est essentiel de partager les réalités et les points de vue de celles et ceux qui vivent cette expérience au quotidien.

Un grand merci Paola Frengul pour ta participation au podcast, et pour nous avoir partagé ton vécu en tant que pharmacienne remplaçante.

👉 Partagez vos expériences et vos réflexions en commentaires – Comment vivez-vous le remplacement ? Est-ce un atout pour votre équilibre ou un frein à votre stabilité ? | 16 | 0 | 0 | 4mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.528Z |  | 2025-07-14T13:30:08.551Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7349078953325703168 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHRRdtCPP6bAQ/feedshare-shrink_800/B4DZf0sXXcHMAg-/0/1752156960804?e=1766620800&v=beta&t=Vdufqk9U9FORqczYBNjSjMZmtFKxpigCOonibJX_qzA | Après plusieurs mois de travail, d’ajustements et d’imprévus, je suis très heureux (et soulagé 😅) de vous annoncer que Pharmabase est enfin disponible sur Google Play.
 
Je dirais que ça a été l’une des plus grandes épreuves jusqu’à maintenant.
 
Parfois, on a vraiment envie de faire avancer un projet, on a la vision… mais on ne mesure pas toujours toutes les péripéties qu’on va rencontrer pour le rendre réalisable.
 
Il y a un an, jour pour jour, on lançait Pharmabase sur l’App Store. On pensait que la version Android suivrait dans les mois qui allaient venir.
 
Nous voilà un an plus tard…
 
Bref — tout ça pour dire : merci à toutes celles et ceux qui ont été patients, encourageants, ou simplement présents tout au long de ce processus.
 
IMPORTANT: Cette première version embarque les fonctionnalités principales de Pharmabase, mais plusieurs mises à jour arrivent prochainement pour améliorer votre expérience, corriger quelques derniers bugs et affiner l’ensemble avec vos retours.

📲 Lien pour la version Android est disponible dans les commentaires! | 50 | 5 | 3 | 4mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.529Z |  | 2025-07-10T14:16:01.757Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7338558160984576000 | Video (LinkedIn Source) | blob:https://www.linkedin.com/301b8a61-982d-4470-a838-73d17ce89111 | https://media.licdn.com/dms/image/v2/D4D05AQFpliF-ijKAFg/videocover-high/B4DZc41vJJGYBo-/0/1749005322153?e=1765785600&v=beta&t=pL8u9oezeW0N4Lm3HwlQqXWrgTSZW67sMonCL0oSyFc | L’été approche. Et pour plusieurs pharmaciens propriétaires, ça rime avec gestion des vacances, réorganisation d’horaire, et recherche de remplaçants fiables.
 
Comme chaque année, ce moment peut vite devenir un casse-tête si on ne s’y prend pas assez tôt.
 
👉 Chez Pharmabase, on propose une solution simple, flexible et pensée pour vous :
 
Grâce à l’abonnement annuel, vous avez la liberté de publier autant de contrats que vous le souhaitez, quand vous le souhaitez. Et ce, sans frais d’intermédiaire.
 
Planifiez dès maintenant pour un été plus serein — pour vous, et pour votre équipe. | 23 | 0 | 0 | 5mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.530Z |  | 2025-06-11T13:30:09.396Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7336021438035824640 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a2bdee6e-0cfc-4cff-b479-9f2352de79fc | https://media.licdn.com/dms/image/v2/D4D05AQGUe5YvqoQnRQ/videocover-high/B4DZc41go4HwBk-/0/1749005327296?e=1765785600&v=beta&t=rd51qQnMqQ-GwR7AjGNUqqazOEpZdmWZa9E9PffuvEA | Les étudiant·e·s de 4e année présent·e·s à l’événement ont partagé un message clair : parler de finances et de rentabilité en pharmacie, c’est quelque chose qui leur manquait.

Pour plusieurs, ça a été l’occasion de mieux comprendre les options qui s’offrent à eux après leurs études — que ce soit comme salarié·e, remplaçant·e ou proprio — et de commencer à réfléchir à comment mieux gérer leur argent et planifier l’avenir.

Merci pour vos mots honnêtes, vos réflexions et votre curiosité 🙏

C’est pour vous qu’on organise ce genre de rencontres 💛

Saad Mrini | 15 | 0 | 0 | 6mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.530Z |  | 2025-06-04T13:30:07.515Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7333839559509622786 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e51c81a4-e535-4311-b479-1d1c65bfedc7 | https://media.licdn.com/dms/image/v2/D4E05AQHsa_gFWwCgsw/videocover-high/B4EZcXxzM1HkBo-/0/1748450665610?e=1765785600&v=beta&t=Sx12rs18_sY2YMGO2M-oQ0LcbE6ifVOAPL0dtNf5I98 | Une première fois qui ne sera pas la dernière.

Moses Boachie, Pharm.D., fondateur de DIN Marketing, nous partage son expérience en tant que partenaire derrière l’organisation de notre tout premier événement.

Des imprévus, des défis, de la pression — mais surtout un beau succès qui montre tout ce que la communauté de l'industrie de la pharmacie peut accomplir quand on se rassemble autour des bons sujets. 💼

Merci à toutes les personnes qui ont cru au projet et qui ont contribué à faire de cette journée un moment fort. 💙 | 10 | 2 | 1 | 6mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.531Z |  | 2025-05-29T13:00:07.137Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7330940482241359872 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE_0imlEIvEDA/feedshare-shrink_800/B4DZbw7pLtHQAg-/0/1747798895609?e=1766620800&v=beta&t=8E5QyEe4HSkJE-dbV9MNQmlgQyxYCBqbgYPFbtlw3Fg | ✨ Retour sur le tout premier événement signé PharmaBase : Finances et rentabilité en pharmacie.

Le 17 mai dernier, plus de 80 pharmaciens – propriétaires, remplaçants, salariés, ATP et finissants – se sont réunis à Boucherville pour une matinée d’échanges, d’apprentissage et de rencontres enrichissantes.

Organisé pour répondre à un besoin réel et souvent ignoré, cet événement avait pour mission d’outiller les professionnels de la pharmacie sur deux enjeux clés : la rentabilité en pharmacie et la gestion financière personnelle — avec du contenu pertinent, applicable au quotidien.

Au programme :
 🎤 Une conférence sur la rentabilité et la pérennité des pharmacies (1 UFC)
 💼 Une conférence sur les finances personnelles
 🤝 Un moment fort de réseautage entre propriétaires, remplaçants, finissants et partenaires

Un immense merci à nos partenaires officiels :
 🔹 iA Financial Group (Industrial Alliance) 
 🔹 Chloé Especa, courtière immobilière
 ainsi qu’à nos conférenciers, Yvon Picard et Jean-Pierre Abou, pour leur présence, leur engagement et la qualité des contenus partagés.

Et bien sûr, merci à l’équipe de DIN Marketing pour l’organisation de cet événement.

 Un moment fort qu’on espère revivre avec vous dans d’autres formats à venir.

📸 Voici quelques images de cette belle journée ! | 80 | 4 | 0 | 6mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.532Z |  | 2025-05-21T13:00:13.254Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7322605563144560642 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1ff6944e-56c2-4849-865f-34e09149dc21 | https://media.licdn.com/dms/image/v2/D4D05AQFL8DZr0hHP5g/videocover-high/B4DZZed4ocG8B0-/0/1745341634956?e=1765785600&v=beta&t=VXvq9wnAAf3-iOvK55zFgUCGxTbhJecKIc1uN6gtTp4 | 📣 Tu es pharmacien.ne ou ATP remplaçant.e ?

Inscris-toi sur Pharmabase avant le 1er mai et reçois un code promo exclusif pour notre événement du 17 mai : Finances et rentabilité en pharmacie.

Une occasion parfaite de :
💸 Comprendre les bases financières du métier
🤝 Élargir ton réseau
📍Et pourquoi pas, croiser la route de ton prochain contrat

Voici comment l’obtenir 👇
1️⃣ Télécharge l’app Pharmabase sur l’App Store
2️⃣ Complète toutes les étapes d’inscription
3️⃣ Attends notre message 💬 : le support technique t’enverra ton code promo directement

On t’attend! 
🎟️ Infos & billets juste ici: https://lnkd.in/dXPR4KW3 | 14 | 0 | 1 | 7mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.533Z |  | 2025-04-28T13:00:13.686Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7321156044590575617 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d2e540d1-e73f-4986-abef-db1080e709be | https://media.licdn.com/dms/image/v2/D4D05AQECw5ecgLzOPA/videocover-high/B4DZZeb6DkG0Bk-/0/1745341111914?e=1765785600&v=beta&t=iKz-RQ3805NFXboR69wITrqBY8dOkduKm_t-u-oRWog | 👉 Pharmaciens propriétaires, remplaçants, étudiants finissants, experts en finance... Tous seront réunis dans la même salle pour échanger, connecter, bâtir des ponts.

Que vous cherchiez un remplaçant fiable, une opportunité de contrat, un mentor ou même un contact du milieu financier : c’est l’occasion de créer des liens solides.

Ne manquez pas notre événement Finances & rentabilité en pharmacie le 17 mai prochain.

Pour plus de détails consultez le lien juste ici: https://lnkd.in/dXPR4KW3 | 20 | 0 | 1 | 7mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.534Z |  | 2025-04-24T13:00:21.532Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7320489198887575554 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7d0d1485-775d-4eff-bb20-6fe02612eb86 | https://media.licdn.com/dms/image/v2/D4D05AQHTRPV_yb2D9w/videocover-high/B4DZZKF5cTGgBk-/0/1744999800744?e=1765785600&v=beta&t=4vw_UePwxEEpSP_oHlNDZja8wNj3jSoP3RUDNkbxnFc | Depuis que PharmaBase Remplacement a vu le jour, j’ai toujours eu cette ambition en tête : apporter une vraie valeur ajoutée à l’industrie de la pharmacie.

L’idée de créer un événement, c’était audacieux. Trop gros, peut-être. Mais prometteur!

Et c’est grâce à une équipe créative, impliquée et passionnée, autant chez DIN Marketing que chez PharmaBase, qu’on a pu rendre ce projet bien réel.

🎯 L’événement « Finances & rentabilité en pharmacie », c’est bien plus qu’un simple rendez-vous :

C’est une réponse concrète à des besoins qu’on entend trop souvent sur le terrain — et trop rarement adressés de front.

Merci à tous ceux qui rendent cette aventure possible. 🙏

On vous attend en grand nombre le 17 mai à Boucherville!

🎟️ Infos & billets : https://lnkd.in/dXPR4KW3 | 13 | 0 | 1 | 7mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.535Z |  | 2025-04-22T16:50:33.127Z | https://www.linkedin.com/feed/update/urn:li:activity:7320438759248863233/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7313183554635538432 | Video (LinkedIn Source) | blob:https://www.linkedin.com/52b9ccec-35d8-4182-818a-bf131df173f8 | https://media.licdn.com/dms/image/v2/D5605AQEioBNs9u4iYw/videocover-high/B56ZXyGUAFHEB0-/0/1743523575564?e=1765785600&v=beta&t=gIRTBB0J_Gu68CPw4K64lWqMHHrUVBwaNYyoFBdDbos | https://lnkd.in/dXPR4KW3 

Depuis le tout début, Pharmabase existe pour transformer le remplacement en pharmacie.

Notre mission est simple, mais essentielle : aider les pharmaciens à mieux utiliser leurs ressources et à investir dans leur pratique, tout en créant un système plus juste et transparent pour tous.

On croit profondément que l’avenir de notre industrie passe par plus de collaboration, par des échanges ouverts sur nos réalités et par des outils qui nous redonnent le contrôle sur notre carrière.

Trop souvent, des enjeux importants comme la gestion financière sont mis de côté, perçus comme complexes ou même tabous. Pourtant, ce sont eux qui permettent aux pharmaciens, ATP et propriétaires de bâtir des pratiques solides, durables et rentables.

C’est pourquoi, j’ai décidé d’organiser un événement exclusif pour les pharmaciens propriétaires et les remplaçants (pharmaciens et ATP/TP) pour :
✅ Ouvrir le dialogue sur les finances en pharmacie.
✅ Partager des stratégies concrètes et adaptées à notre réalité.
✅ Rassembler notre communauté autour de solutions durables et accessibles.

📌 Les détails à retenir :
📅 Samedi 17 mai
📍 Hôtel Mortagne, Boucherville
⏰ 9h30 - 13h00

👥 Au programme :
🎤 Conférence 1 : Comment assurer une bonne rentabilité de vos pharmacies ? 📈
🎤 Conférence 2 : Comment gérer vos finances en tant que travailleur autonome ? 🧾

Avec la participation de deux experts invités qui viendront partager leurs meilleures stratégies.

Et pour poursuivre la discussion dans un cadre convivial :
🍸🥂 Un moment de réseautage pour échanger, collaborer et développer votre réseau.

Cet événement, c’est plus qu’un simple partage de connaissances :
C’est l’occasion de bâtir ensemble un avenir plus transparent, plus équitable et plus autonome pour notre industrie.

📩 Les places sont limitées. Inscrivez-vous dès maintenant ! 
Pour acheter votre billet: https://lnkd.in/dXPR4KW3 | 34 | 1 | 1 | 8mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.539Z |  | 2025-04-02T13:00:31.805Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7309921937206513666 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1c8dfb02-f7ae-4b0b-8bdd-4c28114e3e17 | https://media.licdn.com/dms/image/v2/D4D05AQFrs6uzZ5tjcg/videocover-high/B4DZVjg4KLHAB0-/0/1741131319396?e=1765785600&v=beta&t=xB4YUNC9-0BHu1d_Yk2XTrttlXjS0zr46MHvAoH463M | En tant que remplaçants, nous sommes bien conscients que plusieurs agences imposent des clauses de non-concurrence. 

Ce qui veut dire que, même si vous avez adoré travailler dans une pharmacie, que l’équipe était accueillante et que le milieu vous convenait parfaitement… il vous est impossible d’y retourner pour un poste permanent.

C’est justement pour éviter ce genre de limites qu’on a créé Pharmabase.

Puisque nous ne sommes pas une agence, mais bien une plateforme d’affichage de contrats, il n’y a aucune restriction. 

Les pharmaciens et ATP/ TP gèrent directement leurs opportunités avec les propriétaires, en toute simplicité et transparence. Vous pouvez donc travailler où vous voulez, quand vous voulez ! 

Et même si c’est votre troisième pharmacie de la semaine, on réalise vite que ce qui fait vraiment la différence, c’est la liberté de choisir ses opportunités et de bâtir son réseau — que ce soit pour du remplacement ou, pourquoi pas, un poste permanent.

Découvrez par vous-même comment Pharmabase peut vous simplifier la vie!
https://lnkd.in/d8Va6qSD | 33 | 1 | 0 | 8mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.539Z |  | 2025-03-24T13:00:01.612Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7308472383789531137 | Video (LinkedIn Source) | blob:https://www.linkedin.com/14c13b60-2b65-4670-a82c-eff990a1185c | https://media.licdn.com/dms/image/v2/D4D05AQHcm_-on8A1IA/videocover-high/B4DZVjgaa3G4Bs-/0/1741131200515?e=1765785600&v=beta&t=0w4sy37lZsBF_n3SElm-N9Y5CPpXnAqwpqTFFbg2vA0 | En ce mois de la reconnaissance, je tiens à exprimer toute ma gratitude envers ceux qui, chaque jour, rendent la pharmacie ce qu'elle est : les pharmaciens, ATP, TP, et tous ceux qui, par leur travail et leur engagement, contribuent à créer un environnement plus humain et plus fort. 🙌💊 

Chaque jour, vos efforts et votre dévouement font une réelle différence.

Je suis fier de faire partie de cette belle communauté et d'avoir l'opportunité de la soutenir avec des idées novatrices ayant pour but d’amener plus d’autonomie, collaboration, équité et transparence dans notre profession.
 
Ensemble, continuons à bâtir un avenir meilleur pour notre profession. | 24 | 1 | 0 | 8mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.540Z |  | 2025-03-20T13:00:01.146Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7305577063141314562 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e8562b4f-dff4-4a6f-9410-d70cacacd933 | https://media.licdn.com/dms/image/v2/D4D05AQHQ7munQ5FGnw/videocover-high/B4DZVjgNMLHIBw-/0/1741131152837?e=1765785600&v=beta&t=RqzM9vxxDFbXqpgzwLwc2EtBHJfZu6AYLE6rdl_dEVw | Je me rappelle du temps que je passais à faire mes factures après mes remplacements. Des heures à jongler avec des tableaux Excel, à vérifier (et revérifier) les montants… tout ça pour finalement me demander si j’avais bien fait ça. 😵‍💫

C’est exactement pour ça qu’on a voulu intégrer un système de facturation simple et efficace dans Pharmabase.

Maintenant, en quelques clics, ta facture est prête et envoyée directement au comptable de la pharmacie. Pas de casse-tête. Pas d’erreurs. Pas de perte de temps.

Et surtout :
🔹 Moins de stress administratif.
🔹 Plus de temps pour ce qui compte vraiment.
🔹 Et surtout, un paiement sans friction. 

Parce qu’au final, ce qu’on fait de mieux, c’est notre travail en pharmacie… pas de la comptabilité. 💊

📲 Si toi aussi t’es prêt à simplifier ta gestion, découvre Pharmabase!
https://lnkd.in/d8Va6qSD | 19 | 3 | 2 | 8mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.541Z |  | 2025-03-12T13:15:02.911Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7303776473654452225 | Video (LinkedIn Source) | blob:https://www.linkedin.com/672f1b7e-c7f0-40c9-9fb7-c3f7fff6f0a3 | https://media.licdn.com/dms/image/v2/D4D05AQGHNp7Bk7BXDw/videocover-high/B4DZVjfvNXG4Bs-/0/1741131039016?e=1765785600&v=beta&t=Dp5-zjyWFWztCWIRjYncqw6eyh1MOVgWKpBTWkJWXt8 | 🚀 Pour être honnête, c’est exactement pour ça qu’on a créé Pharmabase.
Je me rappelle quand je devais passer des heures à chercher des shifts, à négocier mes taux à l’aveugle, puis à me battre avec mes factures à la fin du mois... c’était devenu un sport ! 🏋️‍♂️

Mais à un moment, je me suis dit :
Pourquoi ça devrait être si compliqué pour les remplaçants? 

C’est là qu’on a décidé de faire les choses autrement.

Avec Pharmabase, tu peux :
✅ Trouver des shifts rapidement
✅ Négocier tes tarifs directement avec les proprios
✅ Envoyer ta facture en quelques clics

Pas de casse-tête. Pas d’intermédiaire. Juste toi, ton expertise et une plateforme qui te simplifie la vie.

📲 Envie de voir comment Pharmabase peut vous faire gagner du temps et de l’efficacité ? Le lien est juste ici: https://lnkd.in/d8Va6qSD | 18 | 5 | 0 | 9mo | Post | Michael Hazari | https://www.linkedin.com/in/michael-hazari-368b21303 | https://linkedin.com/in/michael-hazari-368b21303 | 2025-12-08T07:14:21.541Z |  | 2025-03-07T14:00:08.924Z |  |  | 

---



---

# Michael Hazari
*PharmaBase Remplacement*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Dr Moses Boachie, Pharm.D. (@lepharmacoach)’s videos with ...](https://www.tiktok.com/@lepharmacoach/video/7381516967070616838)
*2024-12-08*
- Category: article

### [PharmaBase](https://www.pharma-base.com/)
*2025-02-03*
- Category: article

### [Pharmabase Marketing](https://www.pharmabase.co.uk/)
*2025-05-06*
- Category: article

### [Expanding Pharmacy for Consumers and Strategic Partners | Areo Nazari, PharmD, CEO Matthew Hawkins, BSC, CTO CaryHealth - The Business of Pharmacy Podcast™](https://poddtoppen.se/podcast/1471128576/the-business-of-pharmacy-podcast/expanding-pharmacy-for-consumers-and-strategic-partners-areo-nazari-pharmd-ceo-matthew-hawkins-bsc-cto-caryhealth)
*2025-05-12*
- Category: podcast

### [The Business of Pharmacy Podcast™](https://podcasts.apple.com/fi/podcast/the-business-of-pharmacy-podcast/id1471128576)
*2025-05-12*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Pharmabase Remplacement](https://pharma-base.com/en)**
  - Source: pharma-base.com
  - *About Michael Hazari. App Founder. A vision forged by experience: Pharmacist and entrepreneur, Michael found his true calling in driving innovation to...*

- **[Pharmabase Remplacement](https://pharma-base.com/)**
  - Source: pharma-base.com
  - *Michael Hazari - Fondateur de l'app. Un parcours qui forge une vision. Pharmacien et entrepreneur, Michael a découvert sa véritable vocation en se tou...*

---

*Generated by Founder Scraper*
