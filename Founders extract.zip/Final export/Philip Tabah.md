# Philip Tabah

## Position actuelle

**Titre** : Co-Founder, Head of Creative
**Entreprise** : Field Office
**Durée dans le rôle** : 5 years 11 months in role
**Durée dans l'entreprise** : 5 years 11 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Design

## Description du rôle

Design + Digital

## Résumé

I am a creative thinker with a passion for quality content. 
Say hi: phil@field-office.ca

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAALH1noB0u3G5SHfROlFJh7VgjH3gg1gzgk/
**Connexions partagées** : 32


---

# Philip Tabah

## Position actuelle

**Entreprise** : Field Office®

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Philip Tabah

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402681269148618752 | Text |  |  | Do I know anyone at Google Montreal that can help us deal with the bill C-18 stuff? The Main still blocked on Google and Meta because they think we're a news publication, but we do no reporting. | 3 | 2 | 0 | 2d | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:51.900Z |  | 2025-12-05T12:12:29.732Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397298439761592320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGoddBWm-r4DA/feedshare-shrink_800/B4EZqh7uKxIwAo-/0/1763653381764?e=1766620800&v=beta&t=Yz7APE-eOUF68sNYmNFJIlzgi4kG2-azOQ9mt2S9_wA | We launched a really cool feature on The Main this week: Your Library. 

Your Library is a collection of articles and places you recommend or bookmarked. 

One of my favourite parts of what we're building are the City Guides and our Directory, a curated list of Montreal's best spots.  But there was something missing. It lacked interaction. You couldn't save a place, or show others that you endorse a spot. 

Well, now you can. 

Thumbs up if you recommend a spot, and bookmark it to save to a list or add it your favourites. 

You can do the same with articles. 

Try it out! Log in to get access to the feature. 

There's much more to come on this front, but feedback and feature requests are welcome. | 37 | 3 | 2 | 2w | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:51.901Z |  | 2025-11-20T15:43:03.198Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397296148111101954 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGF9mhJWItnkw/feedshare-shrink_800/B4EZqhwJwtKMAg-/0/1763650346573?e=1766620800&v=beta&t=zBATbftkmpt78gYtG0jfJ6pfPPeN4CsnAkVyHm_FOSc | Proud moment. Working with Lightspeed Commerce to bring The Main's First Annual Holiday Market to life.  We got some of the city's greatest brands together for a weekend of #shoppinglocal. Thanks for the support Dax Dasilva and the whole Lightspeed team. 

#montreal | 28 | 7 | 0 | 2w | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:51.902Z |  | 2025-11-20T15:33:56.826Z | https://www.linkedin.com/feed/update/urn:li:activity:7397285709532987393/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396560911542464513 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF6xlAY8nOSsw/feedshare-shrink_800/B4EZqXL0SJHMAk-/0/1763473049832?e=1766620800&v=beta&t=P1lj-T8nLm4u1WSQg3of5wa6srpFhKOkPG2l38VLZyo | Add Developer to my resume. 

I've been pushing code to production for The Main (with Jean-Philippe Lauzon's oversight and guidance) for the past couple of months. 

I can literally think of an improvement, vibe code my way through it, and push to github. Wild times. Lots of improvements coming your way. | 28 | 6 | 0 | 2w | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:51.902Z |  | 2025-11-18T14:52:22.768Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7392218182499028992 | Text |  |  | We're looking for a graphic designer at The Main so we put a call out to find someone to join the team. 

I can't tell you how much incredible talent has reached out. It's so inspiring. Montreal is an insanely talented city. 

This is going to be hard. | 54 | 5 | 2 | 1mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.561Z |  | 2025-11-06T15:15:55.480Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7389793610172420096 | Article |  |  | The History Lesson column has been around since 2012. It's one of my favourite things we do at The Main. Teaching people about their city is pretty fun.

You know what's even cooler? We get to teach millions of people every month with the history minutes we produce for the Tourisme Montréal instagram page. 

Did you know about the 22 gas street lamps in Old Montreal? Now you do: https://lnkd.in/e8T6G5sq

How about the history of Canada's Wall Street? https://lnkd.in/eqGAKMQR

Or how the Hat Trick got its name? https://lnkd.in/ePDkbkrs

There's a whole other agency side to what we do. | 21 | 2 | 0 | 1mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.562Z |  | 2025-10-30T22:41:32.391Z | https://www.instagram.com/reel/DI1kuBtKQoK/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7388967012951273472 | Text |  |  | We needed help. We’ve been swamped with partnership requests at The Main over the past few months. Brands are taking notice of the content we’re creating and looking to partner. 

It’s exciting to see companies looking for creative ways to reach a Montreal audience and to trust us to help them do it.

Good news, though. We found a solution. I'm proud to welcome Samuel Vadnais to the team – our first Head of Partnerships. He's already running at full speed. 

Can't wait for 2026. | 89 | 3 | 2 | 1mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.562Z |  | 2025-10-28T15:56:56.256Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7388627840700887041 | Article |  |  | As a local, do you go to Old Montreal? As one commenter put it, "It's shocking how Montreal is fumbling the ball on Old Montreal. It should be our Marais. Instead, it's now one of Montreal's tackiest neighborhoods." 

As we ramp up our content production, I'm proud that we're becoming a platform for Montreal's business community to share their perspectives. The Main really is the voice of Montreal. | 8 | 0 | 0 | 1mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.563Z |  | 2025-10-27T17:29:11.290Z | https://www.themain.com/articles/old-montreal-tourism-hospitality-independent-business-rent |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7388625905578991616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2ccec685-41ff-40e5-8677-fb29ec177c94 | https://media.licdn.com/dms/image/v2/D5605AQG45zOl-Kz0Gg/videocover-high/B56ZomnQvAJ4B8-/0/1761584449808?e=1765774800&v=beta&t=vVqd_ouIs47UnXtrrpxlQi9kouVzL-ZkfrZMyWzmocs | This project was massive. The team at Complexes funéraires Yves Légaré trusted us completely and collaborated at every step—resulting in world-class digital experience.

It's a sensitive industry to work in, but we approached it with care and practicality. We wanted to honour the emotional weight of what families are going through while making everything genuinely easier: finding service details, sending flowers, leaving condolences, navigating and finding information between locations. The coolest part? It's all built on Shopify.

A lot of UX research and Development went in to making this project come to life. Very proud of this one. 

https://yveslegare.com/ | 19 | 0 | 0 | 1mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.564Z |  | 2025-10-27T17:21:29.921Z | https://www.linkedin.com/feed/update/urn:li:activity:7388620790826504192/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7372019341178937345 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6EezASVxnbw/feedshare-shrink_2048_1536/B4EZk6shd3IQA0-/0/1757626374761?e=1766620800&v=beta&t=qIvvueS2B_WJvg7Vf-_gNKL-Nw5sRy8SnRrdo8kLyNs | Field Office™ → Field Office®

🤝 Jean-Philippe Lauzon | 22 | 1 | 0 | 2mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.565Z |  | 2025-09-11T21:32:56.433Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7371201989772464128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3QdUVb3VdSw/feedshare-shrink_800/B4EZkui_3UIIAg-/0/1757422554948?e=1766620800&v=beta&t=BwicEO4mDZ6XjTR9-9RItbnypsW7vkVaDaKqYJ3Sc1k | The photoshoot was the best part. Actually the brand was pretty sweet, too. Here’s another project from a while back! | 6 | 1 | 0 | 2mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.565Z |  | 2025-09-09T15:25:04.672Z | https://www.linkedin.com/feed/update/urn:li:activity:7371164461660872704/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7361166073427021824 | Article |  |  | I'd love to get more opinion / beat columnists writing for The Main. Have opinions about Montreal? Story ideas? Business, Real Estate, Local Politics and more. Reach out. | 11 | 0 | 1 | 3mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.566Z |  | 2025-08-12T22:45:55.757Z | https://www.themain.com/pitch-us |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7360719534783111168 | Article |  |  | It's tough to get press as "press" in Montreal, but we did it! So glad our first block party was covered in The Concordian. 

We're setting out to do big things for Montreal at The Main.

"I think Montreal needs a New Yorker or New York Magazine, and that’s what we’re trying to do. We want to look back at our content archive and be proud of the content we produced and the impact we’ve had on the community"

Big shout out to Ginane Deslauriers for the piece. Thank you.

https://lnkd.in/eBx6ZCac | 47 | 6 | 2 | 3mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.566Z |  | 2025-08-11T17:11:32.648Z | https://theconcordian.com/2025/08/the-mains-first-ever-block-party-unites-montreals-community/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7358513767057428482 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHfBqrkM2LNrg/feedshare-shrink_800/B56Zh6wykGG4As-/0/1754406269027?e=1766620800&v=beta&t=5PMmzNFuEIFEZHCUfKHH04-lwBwFOWCzqFtBvb_F_r8 | A simple but great site + brand we launched a while back for Le Mont, a new development in Downtown Montreal.

https://www.le-mont.ca/ | 12 | 1 | 0 | 4mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.567Z |  | 2025-08-05T15:06:36.641Z | https://www.linkedin.com/feed/update/urn:li:activity:7358513257176813569/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7358238056589500416 | Article |  |  | We've published our first book! It's our first foray into printed content. 

The Main is all online, and we often feel that our content would best be consumed in print so this was a fun little test. 

Inside: An article on what drives Steve St. Pierre (aka Mr. Beau Type) and how he roams the city photographing Montreal’s greatest signs and type. You’ll also find a selection of his favourites.

https://lnkd.in/e8-cxFcV | 48 | 5 | 1 | 4mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.567Z |  | 2025-08-04T20:51:02.143Z | https://depanneur.shop/products/beau-type-vol-1?variant=47850673766640 |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7350597472769007616 | Article |  |  | Looking for great local storytellers and journalists. | 9 | 0 | 1 | 4mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.568Z |  | 2025-07-14T18:50:05.005Z | https://www.themain.com/pitch-us |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7349481830594560001 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b2dac992-459b-4163-be94-ec81a7472a5f | https://media.licdn.com/dms/image/v2/D4E05AQHURAPfVO9dnQ/videocover-high/B4EZf6Z90gH4CI-/0/1752252806949?e=1765774800&v=beta&t=DOrYYaDHjXXSHn-rV1AM0-PfKGgphxH4vr1V8neqVyE | Another luxury furniture store launched ✅

CCollections was a special project. Fully custom from the ground up. We really spent the time thinking about the User Experience and built in some great storytelling features. 

Learn about your favourite designers while you shop!

More: https://lnkd.in/eaHf5ViC | 18 | 0 | 0 | 4mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.568Z |  | 2025-07-11T16:56:55.183Z | https://www.linkedin.com/feed/update/urn:li:activity:7349480984796454913/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7340819720318709761 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIygUiGuGTZg/feedshare-shrink_800/B4EZd_T66LG4Ao-/0/1750187619820?e=1766620800&v=beta&t=7CmRhX_L0nmaqoZJIXgMvsNN9YTLBEeJCdjkn9_gOVs | We launched this a few years ago, but it's still one of the projects I'm most proud of. Great mission, great storytelling... and we got to bring it to life. | 23 | 1 | 0 | 5mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.569Z |  | 2025-06-17T19:16:47.159Z | https://www.linkedin.com/feed/update/urn:li:activity:7340818942514417667/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7338580118853885954 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGi7ey4Z1gSFw/feedshare-shrink_800/B56ZdffucSHoAg-/0/1749653844006?e=1766620800&v=beta&t=I0CsX_1oLptaKPOBoek7dRD5VysRxEP7PO8BEKTnTqI | Quebec. | 26 | 12 | 0 | 5mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.569Z |  | 2025-06-11T14:57:24.560Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7336814327192088577 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4d5a7341-0bf1-4ab6-b127-9f9f5ee46f91 | https://media.licdn.com/dms/image/v2/D5605AQGqo0xewpaeFA/videocover-high/B56ZdGYlNzHUBo-/0/1749232547356?e=1765774800&v=beta&t=mn7g5e-Uk1LIlRIQayRZzJ2duw3EsFYO8IhAT9e9u10 | Little teaser. Starting to post our projects from the last 5 years. Jean-Philippe Lauzon and I have counted over 100 clients across Shopify builds, websites and content production. Wild! | 26 | 0 | 1 | 6mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.570Z |  | 2025-06-06T18:00:47.021Z | https://www.linkedin.com/feed/update/urn:li:activity:7336813092279939072/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7333549179367034881 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4e515614-bb80-43f4-a918-0b00959b1d31 | https://media.licdn.com/dms/image/v2/D4E05AQE49C76dKF8hg/videocover-high/B4EZcX9ay4HYBk-/0/1748453839496?e=1765774800&v=beta&t=luxIXf1evFunPlrBv80kPP5jcE5Gru5hqXK6U_UR9pk | Another one for the books. We released our first collaborative short film with Lightspeed Commerce featuring a very special local family-run business: Maison Lipari (one of the best shops for a nice gift or home decor in Montreal). 

Huge thanks to Lightspeed for being such incredible partners and for recognizing the value of our storytelling.

Also big shout to Joshua Rosenbaum, Alexe Laroche, Daniel Bromberg and everyone who contributed to this campaign. More to come! | 38 | 2 | 2 | 6mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.570Z |  | 2025-05-28T17:46:15.116Z | https://www.linkedin.com/feed/update/urn:li:activity:7333547090964344833/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7332858130030104576 | Article |  |  | We earned a badge of honour this weekend.

URBANIA is a brand I've looked up to since the early days of The Main. They've consistently pushed the boundaries of what local media should be. From their old print magazines to their mind-blowing current video output, they've been an inspiration and a north star for so much of what we do.

When I met their founder, Philippe Lamarre, we were both a little surprised by how similar our paths had been. Our visions were aligned. We're both extremely passionate about the people and stories that make Montreal one of the greatest cities on earth. And he had an idea.

URBANIA had the French market covered, and since we're a growing destination for Anglo Montrealers, he sensed an opportunity to collaborate. We wanted to work on something special together that could appeal to both sides of the city. 

So we worked with their incredible team and launched our collaborative Micromag this weekend: An offbeat guide to Montreal. It's bilingual. It's special. It features the incredible J.P. Karwacki (who did an amazing job on screen).

Check it out and share your thoughts!

https://lnkd.in/eJ5mCPNM

Here's to more collaborations. Thanks for believing in us!

Big big big shouts to Daniel Bromberg, Jean-Philippe Lauzon, Amber Spector and JP Karwacki. Killer team. And also Jean Bourbeau, Jean-Pierre Bastien, Alexandre Lamarche, Cloé Giroux and the whole URBANIA team. | 66 | 9 | 4 | 6mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.571Z |  | 2025-05-26T20:00:16.115Z | https://microm.ag/offbeat-guide-montreal-the-main/5d9fdd10-f4d6-11ed-b2a8-2b8423063157 |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7326078266211983360 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7d4045ed-c048-439e-8587-853085163edf | https://media.licdn.com/dms/image/v2/D5605AQF3pVgVRZoWSg/feedshare-thumbnail_720_1280/B56Zar1.lFGkA0-/0/1746639778047?e=1765774800&v=beta&t=0TFmI37XnA-f0tfCRrobQXf3MdKpcecDWliw69zGwqI | Design and development is getting as streamlined as it gets with this Figma update.

Agencies, designers and developers will be able to build faster than ever… but so will clients with small internal teams. 

I can’t imagine how large agencies will stay competitive. Small agencies like Field Office® can do work that the largest Shopify agencies could do a few years ago. And now individual freelancers can do what we used to do all on their own. | 6 | 0 | 0 | 7mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.572Z |  | 2025-05-08T02:59:30.617Z | https://www.linkedin.com/feed/update/urn:li:activity:7325938409338818560/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7322705888174108673 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHyd691ICwS2Q/feedshare-shrink_800/B4EZZ96M_dHkAg-/0/1745869132168?e=1766620800&v=beta&t=6XVFCJw5pSpMPcobszrjRevbBTY_VsmSUWHAb44h63E | Field Office® turned 5 at the beginning of 2025. We were due for a bit of a refresh. We've grown up a little. More to come. | 75 | 0 | 1 | 7mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.572Z |  | 2025-04-28T19:38:53.037Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7322699995952934912 | Text |  |  | I can't imagine humans are built to context-switch 785 times a day. | 6 | 0 | 0 | 7mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.573Z |  | 2025-04-28T19:15:28.222Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7321525252696530945 | Text |  |  | Small, senior teams are as powerful and competitive as large agencies. | 15 | 0 | 0 | 7mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.573Z |  | 2025-04-25T13:27:27.604Z | https://www.linkedin.com/feed/update/urn:li:activity:7321507853700128769/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7304967856276860928 | Text |  |  | Join the team! | 21 | 0 | 1 | 8mo | Post | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philiptabah | 2025-12-08T04:55:56.574Z |  | 2025-03-10T20:54:16.676Z |  | https://www.linkedin.com/jobs/view/4181438627/ | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7332866068530552833 | Article |  |  | We earned a badge of honour this weekend.

URBANIA is a brand I've looked up to since the early days of The Main. They've consistently pushed the boundaries of what local media should be. From their old print magazines to their mind-blowing current video output, they've been an inspiration and a north star for so much of what we do.

When I met their founder, Philippe Lamarre, we were both a little surprised by how similar our paths had been. Our visions were aligned. We're both extremely passionate about the people and stories that make Montreal one of the greatest cities on earth. And he had an idea.

URBANIA had the French market covered, and since we're a growing destination for Anglo Montrealers, he sensed an opportunity to collaborate. We wanted to work on something special together that could appeal to both sides of the city. 

So we worked with their incredible team and launched our collaborative Micromag this weekend: An offbeat guide to Montreal. It's bilingual. It's special. It features the incredible J.P. Karwacki (who did an amazing job on screen).

Check it out and share your thoughts!

https://lnkd.in/eJ5mCPNM

Here's to more collaborations. Thanks for believing in us!

Big big big shouts to Daniel Bromberg, Jean-Philippe Lauzon, Amber Spector and JP Karwacki. Killer team. And also Jean Bourbeau, Jean-Pierre Bastien, Alexandre Lamarche, Cloé Giroux and the whole URBANIA team. | 66 | 9 | 4 | 6mo | Philippe Lamarre reposted this | Philip Tabah | https://www.linkedin.com/in/philiptabah | https://linkedin.com/in/philippelamarre | 2025-12-08T05:07:14.981Z |  | 2025-05-26T20:31:48.801Z | https://microm.ag/offbeat-guide-montreal-the-main/5d9fdd10-f4d6-11ed-b2a8-2b8423063157 |  | 

---



---

# Philip Tabah
*Field Office®*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Philip Tabah on about.me](https://about.me/tabah)
*2023-02-06*
- Category: article

### [Field / About](https://field.inc/about/)
*2025-01-01*
- Category: article

### [Blog – Field: Digital Headquarters for Product Leaders](https://field.so/en/blog)
*2023-04-13*
- Category: blog

### [Field / Home](https://field.inc/)
*2025-01-01*
- Category: article

### [Field news / Field is Africa’s fastest-growing healthtech company – The Financial Times](https://field.inc/news/africas-fastest-growing-healthtech/)
*2022-05-09*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 10,193 words total*

### Philip Tabah on about.me
*116 words* | Source: **EXA** | [Link](https://about.me/tabah)

Philip Tabah - Montreal, QC, The Main, McGill University | about.me

===============

*   [](https://about.me/)

*   [**Get started for free Get your page**](https://about.me/welcome)
*   [Features](https://about.me/features)
*   [Pricing](https://about.me/pricing)
*   [Log In](https://about.me/login)

*   [Home](https://about.me/)
*   [Features](https://about.me/features)
*   [Pricing](https://about.me/pricing)

Philip Tabah
============

Montreal, QC
------------

Founder @themain + Tabah Media Inc.

Editor-in-Chief + Content Marketing and Branding Consultant

*   Work 
    *   The Main

*   Education 
    *   McGill University

*   [](https://www.twitter.com/Phlop "Visit me on Twitter")
*   [](http://www.linkedin.com/in/philiptabah "Visit me on LinkedIn")
*   [](http://www.facebook.com/phlop "Visit me on Facebook")
*   [](http://instagram.com/phlop "Visit me on Instagram")
*   [](http://www.foursquare.com/user/29332 "Visit me on Foursquare")

To ensure the best experience on our website, we recommend that you allow cookies, as described in our [Cookie Policy](https://about.me/legal/cookies).

Got it

---

### Field / About
*712 words* | Source: **EXA** | [Link](https://field.inc/about/)

Where immunizations, contraception, anti-infectives, essential devices and diagnostics, or chronic care at the local clinic or pharmacy are expired, too expensive, or simply unavailable, providers, patients, and whole communities pay the price.

Equitable, sustainable development, and with it the promise of emerging and frontier markets, starts with the ability of health systems to deliver access. The challenge, opportunity, and imperative in that drive us.

We are helping digitize, modernise, strengthen, and sustain the supply chains that enable this access, becoming long-term partners with the communities we serve, and helping make good on the promise of healthcare for millions.

We create products and services that are easy to use, effective, and scalable. [Find out why](https://field.inc/about/values)

2015

**OCTOBER**: Building on years working together across Africa, Michael and Justin form Field to transform the role of technology, business, and supply chain in sustainable, equitable development.

2016

**JANUARY**: Begins development of _Field Supply_, an offline-first SaaS solution simplifying the process of digitizing and optimizing large-scale supply chains, and _Forth_, a fourth-party logistics service leveraging Field Supply with the mission to upskill Africa’s underutilized informal transport labor to extend last-mile delivery at scale.
**AUGUST**: Maiden deployment of _Field Supply_, as the Supply Chain Control Tower for Nigeria’s national immunization program, integrating a legacy commercial ERP and retiring parallel spreadsheet reporting into an offline-first, web-based dashboard for supply chain managers at each of the country’s 820 immunization warehouses.

Signs an exclusive collaboration to become the official platform for the largest association of information transport workers in Africa, Nigeria’s National Union of Road Transport Workers (NURTW).

**NOVEMBER**: Responding to the worst Nigerian recession in a generation, launches a field-based research initiative to identify opportunities to help independent pharmacies stabilize affordable supply of pharmaceuticals without sacrificing quality.

2017

**MARCH**: Begins work with the International Federation of the Red Cross & Red Crescent (IFRC) to digitize supply chain operations and visualize performance for HIV, TB, Malaria, and immunization the Central African Republic.
**MAY**: With support from UNICEF, WHO, and the Bill & Melinda Gates Foundation, begins development of major new Field Supply features, including planning, batch-tracking, offline-first shipments, integrations with major health information systems, and performance management analytics - landmark advances in making next-generation digital tools accessible to users end to end.

**JUNE**: Commercial launch of Shelf Life in Abuja, Nigeria - pioneering vendor-managed inventory as a service and Pay-As-You-Sell subscriptions for retail pharmacies.

**AUGUST**: Responding to an invitation from the Rockefeller Foundation’s Yieldwise initiative, begins research in Kano and Lagos, Nigeria, resulting in _Acre_, a Forth-enabled service concept helping smallholders access markets and reduce postharvest loss in positive-sum, sustainable transformation of Nigeria’s tomato value chain.

**OCTOBER**: Nigeria’s National Supply Chain Integration Project (NSCIP) adopts Field Supply as the country’s health logistics management information system, beginning a sprint to add HIV, Malaria, and Family Planning programs to the platform - entrusting Field Supply with management of planning, reporting, and analytics on hundreds of new SKUs serving twenty-nine unique services across tens of thousands of new clinics, hospitals, and labs across the country.

2018

**JANUARY**: With two years of learning and iterating, amid a step change in mandate for _Field Supply_ and phenomenal demand for _Shelf Life_, Field decides to focus entirely on healthcare, suspending work on _Acre_, and consolidating _Forth_ into _Shelf Life_ to bring the absolute focus needed to deliver these services at scale.
**FEBRUARY**: New _Field Supply_ immunization program features go live. Government, UNICEF, and lead national rollout, alongside government and UNICEF - digitizing and strengthening Africa’s largest immunization supply chain.

**MARCH**: Berlin, Germany office officially opens.

**APRIL**: Nigeria’s HIV, Malaria, and Family Planning programs go live on Field Supply with the first phase of features. Nationwide onboarding of State Logistics Management Coordination Units and Federal Government staff begins.

**AUGUST**: Shelf Life launches in Nairobi, Kenya.

**OCTOBER**: Shelf Life raises money from the Bill & Melinda Gates Foundation to test its business and impact cases in new markets: Lagos, Nigeria and Nairobi, Kenya. Shelf Life ends 2018 having grown over 300% in revenue while advancing over 80,000 units of medicine over 1,000 deliveries at better than 95% on-shelf availability.

**NOVEMBER**: Embarks on an a

*[... truncated, 193 more characters]*

---

### Blog – Field: Digital Headquarters for Product Leaders
*1,499 words* | Source: **EXA** | [Link](https://field.so/en/blog)

[![Image 1](https://field.so/media/pages/blog/core-context-fit-product-reality-fit/0e88a465a8-1681202874/product-reality-fit-title-300x.png%20300w) April 13, 2023 ### Check Your Core/Context Fit (Also Known As Product/Reality Fit) This is a translated and revised version of a post we guest-authored back in 2015 for the 'produktbezogen' blog. It's about why the Core/Context Fit is the foundation for product success. And how the Product Field helps you find it. Continue Reading](https://field.so/en/blog/core-context-fit-product-reality-fit)[![Image 2](https://field.so/media/pages/blog/the-field-guide-for-visual-product-thinkers/6907ff9536-1680688193/img-9085-300x.jpg%20300w) April 05, 2023 ### The _Field Guide_ for Visual Product Thinkers The product innovation space is filled with useful methods, popular strategy frameworks and canvases asking meaningful questions, and well-known shapes of innovation that have emerged over time. But the immense variety of tools and approaches often proves challenging. Continue Reading](https://field.so/en/blog/the-field-guide-for-visual-product-thinkers)[![Image 3](https://field.so/media/pages/blog/what-if/3689a2f736-1679745816/whatif-300x.png%20300w) March 31, 2023 ### What if? Hi there 👋 — Chances are you are currently reading The Field Guide for Visual Product Thinkers and want to check out what's behind our "What if?" quotes, right? Well, here we go ... Continue Reading](https://field.so/en/blog/what-if)[![Image 4](https://field.so/media/pages/blog/virtual-reality-is-just-made-for-strategy-work/d7927e7764-1672754216/rwm6h5-v-300x.png%20300w) January 05, 2023 ### Virtual Reality Is Made for Strategy Work Yes, that was my very first thought when I put on an Oculus for the first time: VR is just made for strategy work! Continue Reading](https://field.so/en/blog/virtual-reality-is-just-made-for-strategy-work)[![Image 5](https://field.so/media/pages/blog/understanding-using-innovation-methods/75bd9aca71-1655723409/hero-intro-300x.jpg%20300w) June 20, 2022 ### Understanding & Using Innovation Methods According to Wikipedia, Method literally means “a pursuit of knowledge, investigation, mode of prosecuting such inquiry, or system.” Indeed, this is exactly how we understand and use methods — as tools to help us gain information and make sense of it, to become more confident when we make product decisions. Continue Reading](https://field.so/en/blog/understanding-using-innovation-methods)[![Image 6](https://field.so/media/pages/blog/the-kano-model-how-the-product-field-tells-you-when-to-use-it/f4ce8c6809-1655722638/hero-kano-300x.jpg%20300w) June 19, 2022 ### The Kano Model — How the Product Field Tells You When To Use It At Field, we are currently working on Method Advice, a new feature that provides contextual method advice based on the results from the Product Field sense-making process. Continue Reading](https://field.so/en/blog/the-kano-model-how-the-product-field-tells-you-when-to-use-it)[![Image 7](https://field.so/media/pages/blog/the-stakeholder-map-how-the-product-field-tells-you-when-to-use-it/da888e224d-1655722610/hero-stakeholder-300x.jpg%20300w) June 19, 2022 ### The Stakeholder Map — How the Product Field Tells You When To Use It At Field, we are currently working on Method Advice, a new feature that provides contextual method advice based on the results from the Product Field sense-making process. Continue Reading](https://field.so/en/blog/the-stakeholder-map-how-the-product-field-tells-you-when-to-use-it)[![Image 8](https://field.so/media/pages/blog/why-how-laddering-how-the-product-field-tells-you-when-to-use-it/723068efb0-1655722632/hero-whyhow-300x.jpg%20300w) June 19, 2022 ### Why/How Laddering — How the Product Field Tells You When To Use It At Field, we are currently working on Method Advice, a new feature that provides contextual method advice based on the results from the Product Field sense-making process. Continue Reading](https://field.so/en/blog/why-how-laddering-how-the-product-field-tells-you-when-to-use-it)[![Image 9](https://field.so/media/pages/blog/the-product-chasm-learning-vs-knowing/f3ed69ffcc-1655558734/chasm-9-300x.jpg%20300w) June 18, 2022 ### The Product Chasm — Learning vs. Knowing Why do so many top executives don’t seem to get “product”? This is the 9th and last post of the The Product Chasm series that introduces 9 different mental models that separate “modern product management” from “the business”. I found these models when reading through the responses to my question on product twitter. Continue Reading](https://field.so/en/blog/the-product-chasm-learning-vs-knowing)[![Image 10](https://field.so/media/pages/blog/the-product-chasm-philosophy-vs-solutions/b174dc11ad-1655557953/chasm-8-300x.jpg%20300w) June 10, 2022 ### The Product Chasm — Philosophy vs. Solutions Why do so many top executives don’t seem to get “product”? This is the 8th post of the The Product Chasm series that introduces 9 different mental models that separate “moder

*[... truncated, 9,675 more characters]*

---

### Field / Home
*246 words* | Source: **EXA** | [Link](https://field.inc/)

![Image 1: starts with access](https://images.ctfassets.net/xaa3pv9h17w3/7EE8JlrmrYeZBEtngea6QJ/5ad92c59f5312a7a10ac4a571aefff65/home-hero2.jpg?w=2800&q=80&fit=fill)

Growth

starts with access
--------------------------

Our impact

More than

38,000

points of care

More than

4,000

medical products managed

More than

$3.4B

product ordered through platform

More than

700M

pharmaceutical interventions enabled

We are helping governments and businesses make good on the promise of healthcare in the fastest growing parts of the world. And it starts with access.

We make pharmaceutical supply chain radically simple, affordable, and effective, helping providers, from the largest health systems to the smallest drug shops, ensure a new generation can access the care it needs to flourish.

Supply service ensuring availability, reducing costs, and empowering pharmacies to grow by improving access

[Go to site](https://shelflife.co/)

Powerful, intuitive, offline-capable supply chain management software and analytics

[Go to site](https://field.supply/)

Field is a technology company driven by the idea that equality and progress, growth and sustainability all start with access to healthcare.

We work on some of the hardest, most important problems of our age to build products and services that deliver that access in frontier and emerging markets, where it’s hardest fought and highest impact. [Find out more about us.](https://field.inc/about)

Our partners

[![Image 2: Federal Government of Nigeria](https://images.ctfassets.net/xaa3pv9h17w3/7yCZNHLJmMoy4IwomuoiQa/eb67d517bf98f6a8f5eb7bf94083cb50/1024px-Coat_of_arms_of_Nigeria-compressor__1_.png)](http://www.nigeria.gov.ng/)[![Image 3: National Primary Healthcare Development Agency Nigeria](https://images.ctfassets.net/xaa3pv9h17w3/XOkKnqnAkguy4o0ayyGq6/37a651b370dc7b91bf23c44927561da8/nphcda-logo-compressor.png)](http://nphcda.gov.ng/)[![Image 4: Bill and Melinda Gates Foundation](https://images.ctfassets.net/xaa3pv9h17w3/5SmFz3uuHcvsGHsfUH6PK1/6acb178e75d1a4ac780468a0277eeaa6/Global-Health-Program-GHP-Fellowship-compressor.png)](https://www.gatesfoundation.org/)[![Image 5: McKinsey and Company](https://images.ctfassets.net/xaa3pv9h17w3/3fFyG2Aw2PjmUhjs2Masfp/82df7373c42ffdd54df31c855b0cd19d/mckinsey-logo-compressor.png)](https://www.mckinsey.com/)[![Image 6: Chemonics](https://images.ctfassets.net/xaa3pv9h17w3/6VfMWJbHSazHK1C2EMpSIj/d46d44fa9a1e76909645e071e9ed7db0/chemonics-cropped-compressor.png)](https://www.chemonics.com/)[![Image 7: UNICEF](https://images.ctfassets.net/xaa3pv9h17w3/35fp75bgnM5sLWn19xryfR/40499f09c23fdd4897ab9b6ec20e0d3c/Unicef-logo-cropped-compressor.png)](https://www.unicef.org/)[![Image 8: Pharmacy Council of Nigeria – Reg#: FCT2021619E39](https://images.ctfassets.net/xaa3pv9h17w3/4nOFH8uwBvNcJwdv9waMGk/cadf23c721c82794d0420c8c8cc7a338/PCN_w_reg_2021_2x.png)](http://www.pcn.gov.ng/)[![Image 9: Clinton Health Access Initiative ](https://images.ctfassets.net/xaa3pv9h17w3/XVMPEF2pTPgGUwCPrbfDc/37b131d57740803299c51086a2804e0e/chai-logo-compressor.png)](https://clintonhealthaccess.org/)[![Image 10: International Federation of Red Cross and Red Crescent Societies](https://images.ctfassets.net/xaa3pv9h17w3/3n74t8Tc5zkfh4JSBjg0aC/ce5d612178daf0229713713b9f80b233/IFRC_logo-compressor.png)](https://www.ifrc.org/)[![Image 11: Nigerian Supply Chain Integration Project](https://images.ctfassets.net/xaa3pv9h17w3/18yaGOgn7JxnYjlxgHKk4Y/a9134bc050dcdd05ea81ab54f5b21aed/NSCIP-logo-compressor.png)](https://nscip.gov.ng/)

---

### Field news / Field is Africa’s fastest-growing healthtech company – The Financial Times
*294 words* | Source: **EXA** | [Link](https://field.inc/news/africas-fastest-growing-healthtech/)

We are excited to be the fastest growing healthtech in Africa, having ranked 24th out of 75 on the Financial Times’ inaugural list of Africa’s fastest growing companies in 2022. As a healthtech that started operations in 2015 with just 7 people and a passion to transform and improve access to affordable, quality healthcare across Africa, this comes as a great endorsement and acknowledgement of the progress we have made over this period.

The Financial Times’ ranking of the fastest growing African companies was based on accelerated business trends, innovations, adaptability and resilience post-Covid-19 pandemic. It was a multisectoral research effort that looked into startups within the informal trade, fintech, mining, agritech, healthtech, and real estate sectors, amongst others. Financial Times collaborated with research company Statista to compile this list by reviewing companies’ compound annual growth (CAGR) in revenues between 2017 and 2020.

Field recorded an Absolute Growth Rate (AGR) of 178.7%, Compound Annual Growth Rate (CAGR) of 40.7% and a total revenue of $2.3M between 2017 to 2020. In this period we also increased our employee numbers from 7 to 44, and expanded into new markets. Beyond these metrics used by the FT and Statista, our impact is being felt across the continent’s pharmaceutical supply chains. Shelf Life, our digitalized pharmacy subscription service, has empowered over 1,000 pharmacies across Nigeria and Kenya to gain access to varied medical supplies, reducing cost and ensuring availability, and expanding their distribution networks.

With 1.5 million patients served and an 85% increase in pharmacy numbers last year, we are poised to maintain our momentum in making pharmaceutical products readily accessible to pharmacies and drug stores, and committed to collaborating with African governments to provide interventions that help win the fight against diseases and inefficiencies on the continent.

---

### How the metaverse could change how we live, work and interact
*2,362 words* | Source: **GOOGLE** | [Link](https://globalnews.ca/news/8812707/metaverse-digital-future-interact-live-work/)

![Image 1](https://d21y75miwcfqoq.cloudfront.net/70c8fc80)

David Minicucci has a sentimental connection to [The Famous Cosmo’s](https://thefamouscosmos.com/) in Montreal.

As a teenager, Minicucci would hang out at the diner after school with friends. To this day, it’s still a place for locals to gather around the small counter to check in or even debate issues.

The diner, which Minicucci became the owner of in August 2020, has been a staple in Montreal’s NDG community since it was opened in 1967 by the original owner, Tony Koulakis.

 The new owner of The Famous Cosmo’s and longtime customer David Minicucci.  Ben Moran/ Global News 

“Tony was the king of the neighbourhood. Everybody loved him. He was (a) very warm person (who) would bring anybody in and serve them a meal, even if they couldn’t afford it. He would always make sure that everyone was fed,” Minicucci said.

 A framed photo of the late Cosmo’s owner, Tony Koulakis, hangs in the back of the diner.  Ben Moran/Global News 

Now the proud owner, Minicucci wants to grow the Cosmo’s brand but not with another brick-and-mortar location. Instead, Minicucci decided to expand Cosmo’s into the [metaverse](https://globalnews.ca/tag/metaverse/).

What is the metaverse?
----------------------

The metaverse is one of the biggest ideas in tech right now. As the next evolution of the internet, the metaverse is the concept of a more immersive, digital future where users can use avatars to explore different online, 3D worlds, with the help of virtual reality.

 Avatar in the metaverse, Horizon Worlds. 

Arun Maini, also known as [Mrwhosetheboss](https://www.youtube.com/user/Mrwhosetheboss) with a following of more than 10 million subscribers, is a tech YouTuber based in the U.K.

 Tech YouTuber Arun Maini, aka Mrwhosetheboss.  Ian Snape/Global News 

Maini told Global’s _The New Reality_ the metaverse isn’t an internet you look at through a screen, but an internet you’re inside of.

“One of the coolest things in the metaverse is this idea of being able to feel close to people who are further away. So imagine a world where we’re perfectly connected. You can almost snap your fingers and feel like you’re in the same room as someone who’s on a different continent, and you’ll be able to kind of see everything from their facial expressions to their emotions through their virtual avatar,” said Maini.

There are several platforms that offer metaverse experiences, including Decentraland, Sandbox, Horizon Worlds and Spatial. Some are owned by companies, while others are community-driven.

The idea of the metaverse is to enhance our social connections and make our online experiences so immersive that it’s mimicking reality.

Currently in the metaverse, even though it’s still in its infancy, you can do almost anything – work, shop, attend events or just explore.

1/3

*   ![Image 2](https://globalnews.ca/wp-content/uploads/2022/05/DECENTRALAND.jpg?quality=65&strip=all&w=12&h=12&crop=1)

![Image 3](https://globalnews.ca/wp-content/uploads/2022/05/DECENTRALAND.jpg?quality=65&strip=all&w=1600&h=0&crop=1) 

Memorial for the late soccer player Diego Maradona in Decentraland.

“The way I like to think about the metaverse now is kind of how people thought about the internet in the 1980s where no one had any idea what it was going to become,” Maini told Global News.

“No one knew there was going to be Google Maps or Instagram or all the crazy apps that we use in our lives today. It was very, very basic. And so that’s kind of where our understanding of the metaverse is: We know it’s the next stage. We know we’re moving towards it very slowly, very gradually. But we don’t know what it’s going to become.”

In March, Decentraland hosted its [first fashion show](https://decentraland.org/blog/announcements/metaverse-fashion-week-is-here/) with designers like Dolce & Gabbana, Philipp Plein and Tommy Hilfiger.

 Avatar walking in the Metaverse Fashion Show in Decentraland.  Vittorio Zunino Celotto/Getty Images 

“There is a lot of money washing around,” tech writer Mark Fielding told Global News, “and you have to move quickly and people are moving very quickly, investing in these new platforms, investing in these new technologies because time is of the essence.”

 Tech writer Mark Fielding.  Remi Tempereau/Global News 

It’s the potential of what the metaverse may become that is generating all the buzz.

In October 2021, [Facebook’s CEO Mark Zuckerburg announced](https://youtu.be/Uvufun6xer8) the company was changing from a social media company to a metaverse company, including a name change to Meta, signalling Facebook’s shift to a metaverse-first company, investing $10 billion into its platform. Facebook isn’t alone.

In addition to Facebook, Microsoft, Apple and Google are all investing in the metaverse, including Microsoft’s proposed acquisition of gaming company Activision Blizzard, worth close to US$69 billion. Also, well-known brands and institutions including Walmart, KFC, Barbi

*[... truncated, 10,532 more characters]*

---

### @canada.gov.ca’s accidental archivist John Batt is reshaping Canadian culture
*1,101 words* | Source: **GOOGLE** | [Link](https://www.themain.com/articles/canada-gov-ca-instagram-admin-john-batt-canada-culture-history-memes)

@canada.gov.ca’s accidental archivist John Batt is reshaping Canadian culture - The Main

===============

-12°C|Monday, December 8, 2025|

Become a [free member](http://themain.com/subscribe) today for articles access

[![Image 4: Instagram](https://www.themain.com/icons/icon-instagram.svg)](https://www.instagram.com/themain)[![Image 5: Twitter](https://www.themain.com/icons/icon-twitter.svg)](https://twitter.com/TheMain)[![Image 6: Tiktok](https://www.themain.com/icons/icon-tiktok.svg)](https://www.tiktok.com/@themainmtl)[![Image 7: Linkedin](https://www.themain.com/icons/icon-linkedin.svg)](https://www.linkedin.com/company/the-main/)

|

[Advertise](https://media.themain.com/?ref=themain.com)

[![Image 8: The Main Logo](https://www.themain.com/logo-box.svg)](https://www.themain.com/)

[Magazine](https://www.themain.com/articles)

Categories

*   [Arts & Culture Creativity, heritage, and expression.](https://www.themain.com/articles/arts-culture)
*   [Beyond Montreal Travel, adventure, and global perspectives.](https://www.themain.com/articles/beyond-montreal)
*   [Design The best of Montreal design.](https://www.themain.com/articles/design)
*   [Food & Drink La bonne bouffe.](https://www.themain.com/articles/food-drink)
*   [History Stories, lessons, and context.](https://www.themain.com/articles/history-lesson)
*   [Bulletin Our weekly newsletter.](https://www.themain.com/articles/bulletin)
*   [See all original stories](https://www.themain.com/articles)

[Holiday](https://www.themain.com/articles/holidays-2025)

[City Guides](https://www.themain.com/guides)

Popular Guides

*   [The Best Restaurants in Montreal](https://www.themain.com/guide/the-best-restaurants-in-montreal)
*   [Best NEW Restaurants](https://www.themain.com/articles/best-new-restaurants-in-montreal)
*   [Best Cafés](https://www.themain.com/guide/best-cafes-coffee-shops-montreal)
*   [Unique Boutiques](https://www.themain.com/guide/unique-boutiques-holiday-shopping-montreal)
*   [Romantic Restaurants](https://www.themain.com/guide/most-romantic-restaurants-montreal)
*   [Best Bookstores](https://www.themain.com/guide/best-bookstores-montreal)
*   [See all Guides](https://www.themain.com/guides)

[Directory](https://www.themain.com/directory/montreal)

Neighbourhood

*   [Downtown](https://www.themain.com/directory/montreal/downtown)
*   [Le Plateau-Mont-Royal](https://www.themain.com/directory/montreal/le-plateau-mont-royal)
*   [Mile End](https://www.themain.com/directory/montreal/mile-end)
*   [Mile-Ex](https://www.themain.com/directory/montreal/mile-ex)
*   [Saint-Henri](https://www.themain.com/directory/montreal/saint-henri)
*   [See All](https://www.themain.com/directory/montreal)

Business Type

*   [Restaurant](https://www.themain.com/directory/montreal/restaurant)
*   [Café](https://www.themain.com/directory/montreal/cafe)
*   [Shop](https://www.themain.com/directory/montreal/shop)
*   [Bar](https://www.themain.com/directory/montreal/bar)
*   [Bakery](https://www.themain.com/directory/montreal/bakery)
*   [See All](https://www.themain.com/directory/montreal)

Near the Metro

*   [Peel](https://www.themain.com/directory/montreal/peel)
*   [Mont-Royal](https://www.themain.com/directory/montreal/mont-royal)
*   [Place-Saint-Henri](https://www.themain.com/directory/montreal/place-saint-henri)
*   [Place-d'Armes](https://www.themain.com/directory/montreal/place-darmes)
*   [Jarry](https://www.themain.com/directory/montreal/jarry)
*   [View all](https://www.themain.com/directory/montreal)

[Shop](https://depanneur.shop/)

Search...⌘K

[](https://www.themain.com/account/sign-in)

[Subscribe](https://www.themain.com/subscribe-promo)

[Arts & Culture](https://www.themain.com/articles/arts-culture)

@canada.gov.ca’s accidental archivist John Batt is reshaping Canadian culture
=============================================================================

Discussing what’s mundane, regional, overlooked, and authentically Canadian with one of the country’s best digital curators—plus his ties to Montreal.

[![Image 9: The Main](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2023%2F06%2FSymbol-2.png&w=64&q=75)](https://www.themain.com/articles/canada-gov-ca-instagram-admin-john-batt-canada-culture-history-memes)

[The Main](https://www.themain.com/author/themain)

April 11, 2025- Read time: 7 min

![Image 10: @canada.gov.ca’s accidental archivist John Batt is reshaping Canadian culture](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2025%2F04%2FDSCF5553.jpg&w=3840&q=75)Meet John Batt, the admin of @canada.gov.ca and accidental Canadiana archivist. | Photography by Philip Tabah / [@phlop](https://www.instagram.com/phlop/)

### Places featured in this article

[Le Système](https://www.themain.com/place/le-systeme)

There's something charmingly subversive about a guy who quit his job to post about forgotten corners of Canadian culture on Instagram.

Working

*[... truncated, 11,140 more characters]*

---

### Mr. Beau Type and the art of noticing
*1,109 words* | Source: **GOOGLE** | [Link](https://www.themain.com/articles/mr-beau-type-typography-montreal)

Mr. Beau Type: Montreal’s Vernacular Signage and Typography - The Main

===============

-12°C|Monday, December 8, 2025|

Become a [free member](http://themain.com/subscribe) today for articles access

[![Image 3: Instagram](https://www.themain.com/icons/icon-instagram.svg)](https://www.instagram.com/themain)[![Image 4: Twitter](https://www.themain.com/icons/icon-twitter.svg)](https://twitter.com/TheMain)[![Image 5: Tiktok](https://www.themain.com/icons/icon-tiktok.svg)](https://www.tiktok.com/@themainmtl)[![Image 6: Linkedin](https://www.themain.com/icons/icon-linkedin.svg)](https://www.linkedin.com/company/the-main/)

|

[Advertise](https://media.themain.com/?ref=themain.com)

[![Image 7: The Main Logo](https://www.themain.com/logo-box.svg)](https://www.themain.com/)

[Magazine](https://www.themain.com/articles)

Categories

*   [Arts & Culture Creativity, heritage, and expression.](https://www.themain.com/articles/arts-culture)
*   [Beyond Montreal Travel, adventure, and global perspectives.](https://www.themain.com/articles/beyond-montreal)
*   [Design The best of Montreal design.](https://www.themain.com/articles/design)
*   [Food & Drink La bonne bouffe.](https://www.themain.com/articles/food-drink)
*   [History Stories, lessons, and context.](https://www.themain.com/articles/history-lesson)
*   [Bulletin Our weekly newsletter.](https://www.themain.com/articles/bulletin)
*   [See all original stories](https://www.themain.com/articles)

[Holiday](https://www.themain.com/articles/holidays-2025)

[City Guides](https://www.themain.com/guides)

Popular Guides

*   [The Best Restaurants in Montreal](https://www.themain.com/guide/the-best-restaurants-in-montreal)
*   [Best NEW Restaurants](https://www.themain.com/articles/best-new-restaurants-in-montreal)
*   [Best Cafés](https://www.themain.com/guide/best-cafes-coffee-shops-montreal)
*   [Unique Boutiques](https://www.themain.com/guide/unique-boutiques-holiday-shopping-montreal)
*   [Romantic Restaurants](https://www.themain.com/guide/most-romantic-restaurants-montreal)
*   [Best Bookstores](https://www.themain.com/guide/best-bookstores-montreal)
*   [See all Guides](https://www.themain.com/guides)

[Directory](https://www.themain.com/directory/montreal)

Neighbourhood

*   [Downtown](https://www.themain.com/directory/montreal/downtown)
*   [Le Plateau-Mont-Royal](https://www.themain.com/directory/montreal/le-plateau-mont-royal)
*   [Mile End](https://www.themain.com/directory/montreal/mile-end)
*   [Mile-Ex](https://www.themain.com/directory/montreal/mile-ex)
*   [Saint-Henri](https://www.themain.com/directory/montreal/saint-henri)
*   [See All](https://www.themain.com/directory/montreal)

Business Type

*   [Restaurant](https://www.themain.com/directory/montreal/restaurant)
*   [Café](https://www.themain.com/directory/montreal/cafe)
*   [Shop](https://www.themain.com/directory/montreal/shop)
*   [Bar](https://www.themain.com/directory/montreal/bar)
*   [Bakery](https://www.themain.com/directory/montreal/bakery)
*   [See All](https://www.themain.com/directory/montreal)

Near the Metro

*   [Peel](https://www.themain.com/directory/montreal/peel)
*   [Mont-Royal](https://www.themain.com/directory/montreal/mont-royal)
*   [Place-Saint-Henri](https://www.themain.com/directory/montreal/place-saint-henri)
*   [Place-d'Armes](https://www.themain.com/directory/montreal/place-darmes)
*   [Jarry](https://www.themain.com/directory/montreal/jarry)
*   [View all](https://www.themain.com/directory/montreal)

[Shop](https://depanneur.shop/)

Search...⌘K

[](https://www.themain.com/account/sign-in)

[Subscribe](https://www.themain.com/subscribe-promo)

[Arts & Culture](https://www.themain.com/articles/arts-culture)

Mr. Beau Type and the art of noticing
=====================================

What began as a personal archive has become one of Montreal’s most quietly compelling design diaries.

[![Image 8: J.P. Karwacki](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2023%2F09%2F267709292_10159406750378830_2102619651803061692_n.jpg&w=64&q=75)](https://www.themain.com/articles/mr-beau-type-typography-montreal)

[J.P. Karwacki](https://www.themain.com/author/jp-karwacki)

July 25, 2025- Read time: 8 min

![Image 9: Mr. Beau Type and the art of noticing](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2025%2F07%2FDSCF5819.jpg&w=3840&q=75)Steve St. Pierre (aka Mr. Beau Type) in front of Depanneur Pif on Beaubien, showing off a sign's typography that he particularly enjoys. | Photography by Philip Tabah / [@phlop](https://www.instagram.com/phlop/?hl=en)& Mr. Beau Type / [@mrbeautype](https://www.instagram.com/mrbeautype/)

By the time Steve St. Pierre noticed the sticker, he was already halfway across the Van Horne overpass. Tunnel vision, no sleep, heading back to Ottawa to say goodbye to his father. His partner pointed it out, letters on a railing: “Alain.” His dad’s name. It was a musicia

*[... truncated, 10,685 more characters]*

---

### Our patron saints of diners: Montreal’s next generation of casse-croûte owners
*1,103 words* | Source: **GOOGLE** | [Link](https://www.themain.com/articles/montreal-next-generation-of-casse-croute-diner-owners)

Our patron saints of diners: Montreal’s next generation of casse-croûte owners - The Main

===============

-12°C|Monday, December 8, 2025|

Become a [free member](http://themain.com/subscribe) today for articles access

[![Image 2: Instagram](https://www.themain.com/icons/icon-instagram.svg)](https://www.instagram.com/themain)[![Image 3: Twitter](https://www.themain.com/icons/icon-twitter.svg)](https://twitter.com/TheMain)[![Image 4: Tiktok](https://www.themain.com/icons/icon-tiktok.svg)](https://www.tiktok.com/@themainmtl)[![Image 5: Linkedin](https://www.themain.com/icons/icon-linkedin.svg)](https://www.linkedin.com/company/the-main/)

|

[Advertise](https://media.themain.com/?ref=themain.com)

[![Image 6: The Main Logo](https://www.themain.com/logo-box.svg)](https://www.themain.com/)

[Magazine](https://www.themain.com/articles)

Categories

*   [Arts & Culture Creativity, heritage, and expression.](https://www.themain.com/articles/arts-culture)
*   [Beyond Montreal Travel, adventure, and global perspectives.](https://www.themain.com/articles/beyond-montreal)
*   [Design The best of Montreal design.](https://www.themain.com/articles/design)
*   [Food & Drink La bonne bouffe.](https://www.themain.com/articles/food-drink)
*   [History Stories, lessons, and context.](https://www.themain.com/articles/history-lesson)
*   [Bulletin Our weekly newsletter.](https://www.themain.com/articles/bulletin)
*   [See all original stories](https://www.themain.com/articles)

[Holiday](https://www.themain.com/articles/holidays-2025)

[City Guides](https://www.themain.com/guides)

Popular Guides

*   [The Best Restaurants in Montreal](https://www.themain.com/guide/the-best-restaurants-in-montreal)
*   [Best NEW Restaurants](https://www.themain.com/articles/best-new-restaurants-in-montreal)
*   [Best Cafés](https://www.themain.com/guide/best-cafes-coffee-shops-montreal)
*   [Unique Boutiques](https://www.themain.com/guide/unique-boutiques-holiday-shopping-montreal)
*   [Romantic Restaurants](https://www.themain.com/guide/most-romantic-restaurants-montreal)
*   [Best Bookstores](https://www.themain.com/guide/best-bookstores-montreal)
*   [See all Guides](https://www.themain.com/guides)

[Directory](https://www.themain.com/directory/montreal)

Neighbourhood

*   [Downtown](https://www.themain.com/directory/montreal/downtown)
*   [Le Plateau-Mont-Royal](https://www.themain.com/directory/montreal/le-plateau-mont-royal)
*   [Mile End](https://www.themain.com/directory/montreal/mile-end)
*   [Mile-Ex](https://www.themain.com/directory/montreal/mile-ex)
*   [Saint-Henri](https://www.themain.com/directory/montreal/saint-henri)
*   [See All](https://www.themain.com/directory/montreal)

Business Type

*   [Restaurant](https://www.themain.com/directory/montreal/restaurant)
*   [Café](https://www.themain.com/directory/montreal/cafe)
*   [Shop](https://www.themain.com/directory/montreal/shop)
*   [Bar](https://www.themain.com/directory/montreal/bar)
*   [Bakery](https://www.themain.com/directory/montreal/bakery)
*   [See All](https://www.themain.com/directory/montreal)

Near the Metro

*   [Peel](https://www.themain.com/directory/montreal/peel)
*   [Mont-Royal](https://www.themain.com/directory/montreal/mont-royal)
*   [Place-Saint-Henri](https://www.themain.com/directory/montreal/place-saint-henri)
*   [Place-d'Armes](https://www.themain.com/directory/montreal/place-darmes)
*   [Jarry](https://www.themain.com/directory/montreal/jarry)
*   [View all](https://www.themain.com/directory/montreal)

[Shop](https://depanneur.shop/)

Search...⌘K

[](https://www.themain.com/account/sign-in)

[Subscribe](https://www.themain.com/subscribe-promo)

[Food & Drink](https://www.themain.com/articles/food-drink)

Our patron saints of diners: Montreal’s next generation of casse-croûte owners
==============================================================================

Greenspot. AA. Chez Ma Tante. Chez Nick. Beautys. Café Joe. Wilensky's. Nouveau Système. Paul Patates. Bagel Etc. Saying their names is like casting a spell that’d conjure two steamés all-dressed combo with fries and a fountain liqueur on the side.

[![Image 7: J.P. Karwacki](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2023%2F09%2F267709292_10159406750378830_2102619651803061692_n.jpg&w=64&q=75)](https://www.themain.com/articles/montreal-next-generation-of-casse-croute-diner-owners)

[J.P. Karwacki](https://www.themain.com/author/jp-karwacki)

September 11, 2023- Read time: 13 min

![Image 8: Our patron saints of diners: Montreal’s next generation of casse-croûte owners](https://www.themain.com/_next/image?url=https%3A%2F%2Fthemain.ghost.io%2Fcontent%2Fimages%2F2023%2F09%2FIMG_2892-1.jpg&w=3840&q=75)David Minicucci stands outside Cosmos in the west-end borough of NDG. (Photo: Philip Tabah)

I don’t need to tell you how Montreal’s got a legendary reputation for casse-croûtes and cantines, local diners and snack bars that have historically fed t

*[... truncated, 11,304 more characters]*

---

### The Bulletin: Going all-in for the holidays [Issue #156]
*1,651 words* | Source: **GOOGLE** | [Link](https://www.themain.com/articles/montreal-bulletin-issue-156)

If you were fighting it this past month, you can't deny it any further: the holidays are here and everyone's fully committed from here on out. That includes us: holiday market season is here, and our own first-ever market is setting up shop in Griffintown, then there's the Santa Claus Parade, and more enough artisanal pop-ups with festive spirit.

We hope we'll see you this weekend, as the whole team from The Main will be there to say hi, talk shop, hear your anecdotes and jokes about the city, and toast the end of an amazing year together.

[The Main’s First Annual Holiday Market](https://www.themain.com/articles/the-main-holiday-market-montreal-november-2025) is happening this weekend, November 22–23, in Griffintown. Entry is free all weekend, and if you RSVP before 11:59 p.m. today, you’ll be entered to win a $250 gift card for a shopping spree at the event.

Also: There's still time to [support The Main with a paid membership](https://www.themain.com/subscribe) and get an invite to our a VIP night on Nov 21!

* * *

![Image 1](https://themain.ghost.io/content/images/2025/06/image-4.png)
_Activities, parties, points of interest, art exhibitions, you name it: These are the weekend events you don't want to miss._

### Thursday

🎭 Premiering at the Segal Centre for Performing Arts is[_our place_](https://www.instagram.com/p/DP4doH-D3w1/?hl=en), a powerful comedy, by Canadian playwright Kanika Ambroise.

🎬 Montreal’s Image+nation Festival returns with [over 125 films from 38 countries](https://image-nation.org/fr), showcasing a sweeping mix of queer comedies, gripping dramas, intimate family stories, and bold new voices in LGBTQ+ cinema.

🍾 Dive into [a night of Korean literature and culture](https://www.instagram.com/p/DQrqfMOEaBf/) at Librairie Saint-Henri Books, where author Jinwoo Park (Oxford Soju Club) leads a cozy session of soju tastings, book pairings, and snacks—complete with a take-home tasting glass.

🎤 Be a part of the [Laugh for A Cause fundraiser](https://www.instagram.com/p/DQzSiPWjNMB/) at Hurleys, an uplifting night dedicated to supporting the Montreal Centre for Learning Disabilities bringing together some of Montreal's sharpest comedians.

📚 [The Montreal Book Fair](https://www.instagram.com/p/DQ6lo0lDwcd/) returns to the Palais des congrès, transforming the venue into a lively literary hub packed with local and international publishers, workshops, and author talks.

📸 Explore [the Plateau’s past and present](https://www.instagram.com/p/DRAMVTGkQ-3/) through the photography of Alain Chagnon at a free discussion with local historians at the House of Culture.

### Friday

❄️ [The Main’s first annual Holiday Market](https://www.instagram.com/p/DQsJRESkbNx/) kicks off this weekend– RSVP for a chance to win a 250$ gift card to spend at the market!

🎥 [Montreal’s RIDM festival](https://ridm.ca/fr) returns for another year showcasing over 100 films from over 40 countries in various venues throughout the city.

🎸 More than 500 local and international music industry professionals gather to discover emerging artists through showcases, conferences, and networking at [M for Montreal](https://mpourmontreal.com/en/).

🗣 [The Night Summit](https://www.zeffy.com/fr-CA/ticketing/mtl-au-sommet-de-la-nuit--2025) unites researchers, artists, industry leaders, and the public for panels and discussions at the SAT to confront the rising challenges facing Montréal’s nightlife.

🎨 Pause and reflect on the subtle moments that make up everyday life through texture and colours at Philip Viens' solo exhibition, [Bouchée de Vie](https://www.instagram.com/p/DQ2hxkwjVOD/).

### Saturday

🎅 Montreal's gathering on René-Lévesque Boulevard to experience Quebec's most popular Christmas event, [the Santa Claus Parade downtown](https://montrealcentreville.ca/en/defile-du-pere-noel/).

🏺 No Clue Collective hosts [a festive artisanal pop-up](https://www.instagram.com/p/DP_ic23jWvd/) with more than 30 local Montreal vendors selling unique ceramics, prints, candles, home goods, baked goods, jewelry, and more.

🖌️ Participate in [a ceramic painting workshop](https://www.instagram.com/p/DQFHyU0kc5e/) and create a personalized matcha bowl and chasen holder, or tumbler and small plate for either yourself or a loved one.

👘 Find unique presents and celebrate Japanese culture at the returning [Japanese Holiday Market](https://www.instagram.com/p/DOtgGDukcwC/), featuring artisanal goods, handcrafted gifts, and seasonal treats.

🧶 Milo and Dexter host [a weekend pop-up](https://www.instagram.com/p/DQ8GS8zjWeG/) with pieces on display and an exhibition featuring wool based works.

### Sunday

📚 It's the last day to peruse literature from Quebec and around the world at the [Salon du livre de Montréal](https://www.salondulivredemontreal.com/), the largest collection of French-language books in North America.

🏃‍♀️ Finish [a 7km race](https://www.instagram.com/p/DRIl6KyAMZI/) starting in Villeray and then reward yourself with a bean-to-bar c

*[... truncated, 8,653 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[How the metaverse could change how we live, work and interact ...](https://globalnews.ca/news/8812707/metaverse-digital-future-interact-live-work/)**
  - Source: globalnews.ca
  - *May 7, 2022 ... Podcasts · U.S. News. TV Programs. Global National · West Block · The ... Philip Tabah and Jean Philippe Lauzon of Field Office. David...*

- **[@canada.gov.ca's accidental archivist John Batt is reshaping ...](https://www.themain.com/articles/canada-gov-ca-instagram-admin-john-batt-canada-culture-history-memes)**
  - Source: themain.com
  - *Apr 11, 2025 ... ... Philip Tabah / @phlop. Places featured in this article. Le Système ... Field Office. 50% off your first 5 rides. logo. 50% off yo...*

- **[Mr. Beau Type: Montreal's Vernacular Signage and Typography ...](https://www.themain.com/articles/mr-beau-type-typography-montreal)**
  - Source: themain.com
  - *Jul 25, 2025 ... ... Philip Tabah / @phlop & Mr. Beau Type / @mrbeautype. By the time ... Field Office. 50% off your first 5 rides. logo. 50% off your...*

- **[Our patron saints of diners: Montreal's next generation of casse ...](https://www.themain.com/articles/montreal-next-generation-of-casse-croute-diner-owners)**
  - Source: themain.com
  - *Sep 11, 2023 ... ... Philip Tabah). I don't need to tell you how Montreal's got a ... Field Office. 50% off your first 5 rides. logo. 50% off your fir...*

- **[The Bulletin: Going all-in for the holidays [Issue #156] - The Main](https://www.themain.com/articles/montreal-bulletin-issue-156)**
  - Source: themain.com
  - *Nov 20, 2025 ... If ever you catch something we should know, don't hesitate to reach out to us on Instagram. Masthead: Philip Tabah ... Field Office. ...*

- **[The Bulletin: The incoming weather's hot, but this lineup's hotter ...](https://www.themain.com/articles/montreal-bulletin-issue-149)**
  - Source: themain.com
  - *Oct 2, 2025 ... ... Philip Tabah, Founder & Head of ... Legal. Terms of service · Membership Terms · Privacy Policy. The Main Media Inc. 2025. ✦ Built...*

- **[The Bulletin: Legacy, leftovers, and the future of everything [Issue ...](https://www.themain.com/articles/montreal-bulletin-issue-145)**
  - Source: themain.com
  - *Sep 4, 2025 ... If ever you catch something we should know, don't hesitate to reach out to us on Instagram. Masthead: Philip Tabah ... Field Office. 5...*

- **[Montreal's best new pizza is being baked above a paint shop in ...](https://www.themain.com/articles/frankies-pizza-forno-montreal-lachine)**
  - Source: themain.com
  - *Aug 30, 2023 ... Photos by Philip Tabah. Want to know what's happening in Montreal ... Field Office. 50% off your first 5 rides. logo. 50% off your fi...*

- **[Field Office™️ | A Full-Service eCommerce Shopify Website ...](https://www.field-office.ca/)**
  - Source: field-office.ca
  - *Portrait of Philip Tabah. Phil Tabah Partner / Head of Creative. phil@field-office.ca. Portrait of Jean-Philippe Lauzon. Jean-Philippe Lauzon Partner ...*

- **[Blog | Field Office™️ | A Full-Service eCommerce Shopify Website ...](https://www.field-office.ca/blog)**
  - Source: field-office.ca
  - *Stay in touch with the latest market updates. Field Office, your partner for DTC eCommerce Shopify Websites ... Portrait of Philip Tabah. Phil Tabah P...*

---

*Generated by Founder Scraper*
