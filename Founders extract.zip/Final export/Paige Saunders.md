# Paige Saunders

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : FediHost
**Durée dans le rôle** : 2 years in role
**Durée dans l'entreprise** : 2 years in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Description du rôle

We make getting on the fediverse easy for businesses, governments and individuals. More than just hosting services like Mastodon, PeerTube, GoToSocial and Pixelfed we have built tools to make it easy to manage multiple services in one convenient interface.
My part in the business is making videos and resources to help people get started and grow their presense on this refreshing new part of the internet.

## Résumé

I’m an optimistic social entrepreneur who found my calling in making advocacy video

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAFYfqYBEwGLqcB4mwzS-ujXSKzYbtABP2o/
**Connexions partagées** : 1


---

# Paige Saunders

## Position actuelle

**Entreprise** : FediHost

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Paige Saunders
*FediHost*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [Managing Mastodon Storage - FediHost](https://fedihost.co/blog/slug/managing-mastodon-storage)
*2025-03-12*
- Category: blog

### [Project Fitness with Chris Fudge: Ep 97 Paige Feddersohn - Healthy Body Image, Self Esteem And How it Helps People Reach Their Fitness Goals](https://projectfitness.libsyn.com/ep-97-paige-feddersohn-healthy-body-image-self-esteem-and-how-it-helps-people-reach-their-fitness-goals)
*2022-03-24*
- Category: article

### [PodRocket - A web development podcast from LogRocket - Paige Niedringhaus](https://podrocket.logrocket.com/hosts/paige-niedringhaus?page=2)
*2024-03-14*
- Category: article

### [Escaping the Application Blackhole with Paige Niedringhaus - She's in Tech 24 - She's in Tech -](https://topenddevs.com/podcasts/she-s-in-tech/episodes/escaping-the-application-blackhole-with-paige-niedringhaus-she-s-in-tech-24)
*2021-12-21*
- Category: podcast

### [Fedi](https://www.fedi.xyz/aboutus)
*2025-05-07*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Paige Saunders and Sean Speer: The contrarian case for why ...](https://thehub.ca/2025/05/30/paige-saunders-and-sean-speer-the-contrarian-case-for-why-conservatives-should-embrace-electoral-reform/)**
  - Source: thehub.ca
  - *May 30, 2025 ... Paige Saunders and Sean Speer: The contrarian case for ... He also co-founded FediHost, a Canadian PeerTube and Mastodon hosting prov...*

- **[Day 2 – Reclaim Open](https://reclaimopen.com/category/day2/)**
  - Source: reclaimopen.com
  - *Nov 5, 2025 ... Escaping Life Under An Algorithm – video from Paige Saunders (Fedihost) ... podcast episodes. The feed reader that so many have tossed...*

- **[J.J. McCullough's Long Road To Success (Canadian Civil Preview ...](https://www.youtube.com/watch?v=OJbXyjjjLd0)**
  - Source: youtube.com
  - *May 13, 2022 ... https://fedihost.co/. J.J. McCullough's Long Road To Success (Canadian Civil Preview). 10K views · 3 years ago ...more. Paige Saunder...*

- **[PeerTube | Fedi.Directory – Interesting accounts on Mastodon & the ...](https://fedi.directory/tag/peertube/)**
  - Source: fedi.directory
  - *Paige Saunders. Videos by an urbanist activist based in Montreal, Canada, but ... FediHost. Managed hosting service that lets anyone run their own ......*

- **[Some Graffiti Is Legal - YouTube](https://www.youtube.com/watch?v=0uje_ogUNEE)**
  - Source: youtube.com
  - *Sep 25, 2020 ... ... fedihost.co/. References & Sources https ... Some Graffiti Is Legal. 5.1K views · 5 years ago MONTREAL ...more. Paige Saunders....*

- **[PeerTube: the Fediverse's decentralized video platform (part 2 ...](https://blog.elenarossini.com/peertube-the-fediverses-decentralized-video-platform-part-2-creator-edition/)**
  - Source: blog.elenarossini.com
  - *Mar 28, 2025 ... Creator Paige Saunders (of Canadian Civil and FediHost) generously answered my PeerTube questions in a long, illuminating interview. ...*

- **[What VIA Should Have Done - YouTube](https://www.youtube.com/watch?v=OvcHSKud1Z0)**
  - Source: youtube.com
  - *Dec 8, 2023 ... The Fediverse! https://fedihost.co/. References & Sources. Draft Route: https ... Paige Saunders....*

- **[Graffiti: Handling The Vandalism - YouTube](https://www.youtube.com/watch?v=ip0H1WiYPPg)**
  - Source: youtube.com
  - *Sep 4, 2020 ... ... fedihost.co/. References & Sources [1] https ... Paige Saunders•5.6K views · 8:38. Go to channel · How The Internet ......*

- **[15 Montreal YouTube Channels You Should Follow - YouTube](https://www.youtube.com/watch?v=KU_A6tGqzMo)**
  - Source: youtube.com
  - *Aug 14, 2025 ... ... Paige Saunders (retired) 04:20 - Fedihost 04:45 - Fads 05 ... Why don't Canadian YouTubers ever talk about Canada? J.J. McCulloug...*

- **[How FediHost Media Storage Works - FediHost](https://fedihost.co/blog/slug/how-shared-storage-works)**
  - Source: fedihost.co
  - *Jan 15, 2025 ... By Paige Saunders. How FediHost Media Storage Works. One of the unique things about FediHost is our media storage system. It can be e...*

---

*Generated by Founder Scraper*
