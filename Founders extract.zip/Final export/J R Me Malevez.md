# Jérôme Malevez

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396316673697546241 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGGYTq5AGAK2Q/feedshare-shrink_800/B4EZqT.0f_IQAg-/0/1763419310596?e=1766620800&v=beta&t=i52K50IWZPm4B9vVGAPYTXo5FZ-jXeKrVJZCnBPoInE | We had weeks of power-line UAV footage and only a few defect examples. That’s the reality of grid inspection: the camera sees a lot; the model sees too little because defects are rare. 

So we tried a simple idea. We keep the exact same model (DINOv3) and only improve the data. 

First, we trained on real images only. Result: 52% accuracy on power-line defect detection (insulators/connectors). Not field-ready. 

Then we expanded the dataset by applying realistic defect patterns onto the real images with Silera, generating specific variants (angles, lighting, backgrounds, partial occlusions, look-alikes) so the model generalizes across sites, seasons, and cameras. 

Same model, new training set. 

Outcome: 93% accuracy. The difference wasn’t a bigger network or a fancy trick, it was having the right examples to learn from. 

Utilities can move faster with fewer re-flights, and more targeted maintenance, because the model finally sees what the drone sees. 

If you’re running inspections and short on defect images, DM me for a demo and a free sample set. | 14 | 2 | 1 | 2w | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:37.610Z |  | 2025-11-17T22:41:51.928Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391096918493274112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2Ur1YjoInvg/feedshare-shrink_800/B4EZpJHRX4KYAg-/0/1762163234826?e=1766620800&v=beta&t=RhJdOQMt3e1kENSbjZu227SscS5E9bBcXpOinRT-_Ik | Silera made HackSummit’s "75 Top North American Startups to Watch." 
A new generation of builders is rewriting the industrial playbook. 🤖 | 37 | 5 | 2 | 1mo | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:37.611Z |  | 2025-11-03T13:00:25.309Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7383536707444572160 | Document |  |  | What if your line caught the defects that matter, on the first pass?

We created an algorithm that learns the real defect patterns from your line and generates synthetic variants.
It improves any vision model by adding better data.

In this carousel, we walk you through the impact from a recent project.

Swipe to see it for yourself! | 20 | 0 | 1 | 1mo | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:37.611Z |  | 2025-10-13T16:18:50.533Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7378783268067815425 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGo6-NFfaJKKA/feedshare-shrink_2048_1536/B4EZmX6wDoKgAw-/0/1759190385477?e=1766620800&v=beta&t=_7PuZWTGyWLD8j1JUYGH93eufDNet6NbGMEyYW1Ne-c | What a moment at NYC Climate Week!

We showed how Silera helps factories deploy smarter vision models, increasing efficiency while cutting environmental impact. 

Grateful for the time and curiosity in the room, and proud to share our progress alongside great founders. 
Appreciate everyone who came over to chat after, those conversations were the best part. 

Thanks again to Streetlife Ventures, Amazon Web Services (AWS), and Collaborative Fund for pulling it off. 

If you're in this space, let's keep the dialogue going. | 49 | 0 | 0 | 2mo | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:37.612Z |  | 2025-09-30T13:30:22.271Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7371999953839353856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4Z4qG5EgY7Q/feedshare-shrink_1280/B4EZk6a5NOHIAs-/0/1757621753030?e=1766620800&v=beta&t=5YocM8dVtZwHAUr2jOqjlK4EmOgI2Jb0ss3lCTsKAVw | Proud to see Silera featured in this ClimateHack article on startups reshaping industries alongside Public Grid and Eztia Materials. 
Grateful to Laura Fox for highlighting our work, it's always good to know it resonates outside our own walls.

Article link in the comments below. | 12 | 2 | 0 | 2mo | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:37.612Z |  | 2025-09-11T20:15:54.131Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7305185832531906560 | Text |  |  | Let's talk about synthetic data! 
Our first question was: Can we train a vision model for waste sorting without a single real photo? 
We've been exploring robotic vision for a while with Andrei Muresanu and Aayush Bajaj, and launched our new venture Silera.

In this first pilot, we physically collected some used Starbucks cups, to serve as our real-world ‘nasty’ test set. Then we made 3D models to match these shapes, and wanted to see if our purely synthetic-trained model could handle the actual cups without extra real-data training. 

We achieved a near-perfect detection of 0.995 mAP (mean Average Precision) across our real test set of a couple hundred cups.

Check out the article for details: | 21 | 1 | 1 | 8mo | Post | Jérôme Malevez | https://www.linkedin.com/in/jmalevez | https://linkedin.com/in/jmalevez | 2025-12-08T04:42:42.723Z |  | 2025-03-11T11:20:26.265Z |  |  | 

---

