# Angela Hanna Goulene

## Position actuelle

**Titre** : Founder
**Entreprise** : Hannagie Productions Inc.
**Durée dans le rôle** : 2 years 9 months in role
**Durée dans l'entreprise** : 2 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Media Production

## Description du rôle

Hannagie Productions is a transmedia studio that specializes in Video Games, Animation and Film.

## Résumé

Angela Hanna Goulene is a French writer,  producer, and artist based in Montreal, Quebec. She's also the founder of Hannagie Productions, a transmedia company specialized in Cinema, Animation and Video Games. Angela has worked on the short films See You Soon and Not Another Serial Killer, which she's acted in, written and co-directed. 

Not Another Serial Killer was produced by the Kino Kabaret filmmaking program of 2021. The short then premiered at the Fantasia International Film Festival. It has since screened in multiple festivals abroad. 

Angela’s also been selected to the following programs in both film and games: Kino Kabaret, BIPOC Showrunner Bootcamp, Banff Netflix Diversity of Voices, April 2023 WGC Script of the Month, Pixelles Game Incubator Cohort of 2023, Amazon’s Women in Games 2023, QEPC (Quebec English Production Coalition) Mentorship Program 2024 and finally, Amazon's Women in Games Get In The Game program, which is sponsored her trip to Gamescom 2024.

Her game, the Sock Dating Simulator, has been sponsored and/or selected by the following events, programs and/or groups: Comiccon, Otakuthon, MIGS, Loto-Québec, La Zone de Jeux Indie, La Guilde du Jeu Vidéo, Amazon's Women in Games, The Academy of Interactive Arts (GDC Program), Toronto XP Game Summit, Demo Night, Ubisoft Caravane.

Angela is currently working as a screenwriter on various kids' shows and seeking to develop her own projects.

Follow her on social media:

Website: https://www.hannagie.com/
Instagram: @CompletelyGie
FB: @Angela Hanna Goulene

Sock Dating Simulator:

Website: https://www.sockdatingsim.com/
IG: https://www.instagram.com/sockdatingsim/

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAXTLPQBqTUdsEScpv67Ck2m1bNsU34IEec/
**Connexions partagées** : 20


---

# Angela Hanna Goulene

## Position actuelle

**Entreprise** : Rezolution Pictures

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Angela Hanna Goulene
*Rezolution Pictures*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Reel Injun](https://en.wikipedia.org/wiki/Reel_Injun)
*2025-03-25*
- Category: article

### [Hannagie Productions | LinkedIn](https://ca.linkedin.com/company/hannagie-productions-inc)
*2025-04-29*
- Category: article

### [Gaelle Hanna: Dubai's Makeup Maestro from Lebanon](https://uaestories.com/gaelle-hanna-dubais-makeup-maestro/)
*2025-04-02*
- Category: article

### [inTRAlinea. online translation journal > Special Issues > Volumes > Translating English as a Lingua Franca:News > Summer School Authenticity, Adaptability and AI News > Giving Voice, Gaining Voice, Seeing Voices. Insights from Linguistics, Literature, Education and TranslationSpecial Issue: Media Accessibility for Deaf and Blind Audiences > Accessibility Services through Intersemiotic Translation.Special Issue: Media Accessibility for Deaf and Blind Audiences > Old Accessibility for a New Television: Accessibility to VOD, TVOD and streaming platforms NowSpecial Issue: Media Accessibility for Deaf and Blind Audiences > Improving Subtitles: the Relevance of translating Idioms for the deaf and hard-of-hearingSpecial Issue: Media Accessibility for Deaf and Blind Audiences > L’italiano parlato nei sottotitoli per sordi e ipoudenti su RaiPlay:Special Issue: Media Accessibility for Deaf and Blind Audiences > Subtitling for the deaf and hard-of hearing:Special Issue: Media Accessibility for Deaf and Blind Audiences > “En vivo y subtitulado”:Special Issue: Media Accessibility for Deaf and Blind Audiences > Testing quality of different live subtitling methods: a Spanish into Italian case studySpecial Issue: Media Accessibility for Deaf and Blind Audiences > Il contributo dell’accessibilità per sordi alla resocontazioneSpecial Issue: Media Accessibility for Deaf and Blind Audiences > Reflexiones sobre la audiodescripción aplicada al cómicSpecial Issue: Media Accessibility for Deaf and Blind Audiences > La audiodescripción como modalidad de traducción intersemiótica: novedades y retosSpecial Issue: Media Accessibility for Deaf and Blind Audiences > Alternative Audiodeskription Rolle der Programmmusik in der intersemiotischen Übersetzung Schlüsselwörter:Special Issue: Media Accessibility for Deaf and Blind Audiences > Audio description of theatre and cinema production in Lithuania: experiences and needs of usersVolumes > Subtitling <i>The Handmaid’s Tale</i> for an Italian AudienceNews > 8th IATIS  International Conference: Sustainable Translation in the Age of Knowledge Extraction, Generation, and (Re)CreationSpecial Issue: Translating Threat > Introduction:Special Issue: Translating Threat > Manipulating Threat in Medical AdvertisingSpecial Issue: Translating Threat > Representing Disability in English and Greek Legal DiscourseSpecial Issue: Translating Threat > Translating Academia:Special Issue: Translating Threat > Shaping Political Ideologies in the UK BBC and the Russian BBC News ServiceSpecial Issue: Translating Threat > Translating Threat and Power Distance in Pushkin’s ‘The Fisherman and the Goldfish’Special Issue: Translating Threat > Carmilla into Greek:Special Issue: Translating Threat > Portraying Intellectual Disability through Translating FictionSpecial Issue: Translating Threat > Translating Threat in Greek Versions of OthelloSpecial Issue: Translating Threat > Rendering Patriarchy through Gendered Translator Gaze in Romeo and JulietSpecial Issue: Translating Threat > Explicitness as Threat in Love Poetry TranslationSpecial Issue: Translating Threat > Subtitling and Dubbing Intimacy and Threat:Reviews > Cultural Adaptation in Chinese Mental Health TranslationReviews > A new contribution to the development of Slovak-Italian literary relationsVolumes > Motivation of professional interpreters:Volumes > Interpretación simultánea en las ruedas de prensa de la EURO 2020:Volumes > Tradurre nel pubblico e nel privato: la voce dei traduttori non professionisti tra Alto Adige e MarcheVolumes > Les Profs débarquent en ItalieVolumes > Opposé·e·s par les connecteurs d’opposition :Volumes > The Cyrus Cylinder: A Journey through TranslationNews > Winter School in Translation StudiesVolumes > Translating the cultural Other during Covid:News > Legal Translation & Interpreting on the move. Research and Professional OpportunitiesSpecial Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Presentazione della raccoltaSpecial Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Vulgariser e(s)t traduire :Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Terminologie discursive et traduction :Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Kognitive Aspekte juristischer Terminologie und ihre Auswirkungen auf die Konzeptualisierung des ÜbersetzensSpecial Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Approcci metodologici per lo studio della terminologia giuridica multilingue nell’era dell’Intelligenza artificiale:Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Übersetzung in Leichte Sprache.Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Necessità terminologiche di ambito medico nella Lingua dei Segni Francese della Svizzera romanda:Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > Plain language at the Swiss Federal Statistical Office:Special Issue: Terminologia e traduzione: interlinguistica, intralinguistica e intersemiotica > L’analyse conceptuelle des éléments taxSpecial Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Re-Imagining Comics TranslationSpecial Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Tintin Re-imagined and Re-purposed:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Changes in the Visual Qualities of Translated Sound Effects Outside Speech Balloons:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Translating without the Full Picture:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > The Translation and Transcreation of Adventure ComicsSpecial Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Authorial Re-imagination in Comics and Picturebooks:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Reimagining Manga:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Shakespeare Refracted in Manga:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > From a Nineteenth-Century Classic to a Modern Graphic Novel:Special Issue: Reimagining Comics - The Translation and Localization of Visual Narratives > Do Special Powers Come with a Special Language?Volumes > How Do I Say <em>Realia</em> in English?Volumes > A Sociological and Paratextual Analysis of Translators’ Agency:Volumes > The Role of Translation Officials in the Qing DynastyVolumes > La terminologie du désarmement :Special Issue: Tradurre per l’infanzia e l’adolescenza > Tradurre per l’infanzia e l’adolescenzaSpecial Issue: Tradurre per l’infanzia e l’adolescenza > Epitesto e traduzione per l’infanzia e l’adolescenzaSpecial Issue: Tradurre per l’infanzia e l’adolescenza > La traduzione della letteratura francese per giovani lettrici e lettori a tematica LGBTQ+Special Issue: Tradurre per l’infanzia e l’adolescenza > Educazione emozionale e all’uguaglianza di genere:Special Issue: Tradurre per l’infanzia e l’adolescenza > La traduzione della poesia per bambiniSpecial Issue: Tradurre per l’infanzia e l’adolescenza > Tradurre “germi, virus, batteri e altri microscopici mostri” per ragazze e ragazziSpecial Issue: Tradurre per l’infanzia e l’adolescenza > Tradurre è (anche) giocare, sì o no?Special Issue: Tradurre per l’infanzia e l’adolescenza > Letteratura digitale per l’infanzia e traduzione:Special Issue: Tradurre per l’infanzia e l’adolescenza > “Per illimitata fantasia”:Special Issue: Tradurre per l’infanzia e l’adolescenza > Tradurre per l’infanzia e l’adolescenza:Special Issue: Tradurre per l’infanzia e l’adolescenza > “Editoria per l’infanzia, traduzione e genere per una letteratura senza stereotipi”:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Inclusive theatre-making:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Inclusive theatre-making:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > A new organizational challenge for inclusive theaters:Translations > La terra desolata 2022News > 3rd International Conference on Community TranslationSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > Embodiment in Translation Studies: Different PerspectivesSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > Embodiment und Enaktion: Ein neuer Ansatz in den empirischen HumanwissenschaftenSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > The metamorphoses of the body in the space/time of literary translationSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > Psychic rhymes and rhythms in translation:  Walt Whitman and Mark StrandSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > Mit | Gefühl bei der ÜbersetzungSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > Die Person sichtbar machen – Übersetzer:innen in SelbstauskünftenSpecial Issue: Embodied Translating – Mit dem Körper übersetzen > The gravitational law of levitySpecial Issue: Embodied Translating – Mit dem Körper übersetzen > A bodily and co-creative approach to teaching literary translationSpecial Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Users’ expectations of <i>zarzuela</i> audio description:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Audio describing visual intertextuality and cultural references as a challenge towards inclusionSpecial Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Innovation vs Practicality vs Entertainment:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Addressing content, technical and collaboration concerns in providing access to the D/deaf and hard of hearing audience:Special Issue: Inclusive Theatre: Translation, Accessibility and Beyond > Inclusive theatre-making on the stage:Volumes > The Fall and Rise of the Iranian Translator Communities at the Birth and Growth of the Arab EmpireVolumes > Taxis and logico-semantic relations in English-Arabic translationVolumes > Tradurre i classici da poetaVolumes > On the Translation of Books under the Francoist Regime: Methodological ApproachesNews > TRANSLATIONFEST IIVolumes > La formazione in traduzione fra competenze, professione e civismoVolumes > Translation as a WeaponVolumes](https://intralinea.org/specials/article/teaching_-)
*2022-06-28*
- Category: article

### [The Trailblazers: Rewriting the Narrative - Voyage LA Magazine | LA City Guide](https://voyagela.com/2024/10/07/trailblazers-rewriting-narrative/)
*2024-10-07*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
