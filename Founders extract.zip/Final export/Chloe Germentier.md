# Chloe Germentier

## Position actuelle

**Titre** : Fondatrice
**Entreprise** : Chloé Germentier Communications
**Durée dans le rôle** : 21 years 11 months in role
**Durée dans l'entreprise** : 21 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Résumé

Avec un Baccalauréat en Sciences économiques, sociales et politiques et une Maîtrise en Communications, j'ai travaillé dans le milieu de l'édition en Belgique puis suis arrivée à Montréal en 2004. Pendant 15 ans, j'ai accompagné les entreprises de la Région de Bruxelles-Capitale dans leurs démarches d'exportation au Québec. 
En parallèle, j'étais chroniqueuse pour des émissions de télé et radio communautaires. 
Il y a 5 ans, je me suis réinventée en tant qu'artiste à temps complet: narration de documentaires, doublage, enregistrement de livres audio, tournage dans des longs-métrages et séries télé. 
J'ai suivi il y a un an le microprogramme de réalisation à L'INIS car j'aime écouter et raconter des histoires et des cheminements de vie. J'ai donc eu la chance de réaliser mon premier court-métrage documentaire. 
Aujourd'hui, je travaille à temps partiel pour la Chambre de Commerce Belgique Canada, un retour à mes premiers amours vu que j'occupais un poste similaire en arrivant en 2004 au Québec. Je vais coordonner la première édition du Gala d'Excellence en Affaires CCBC qui se tiendra le 28 mai prochain, à Montréal. J'ai également dans les prochains mois, un projet d'enregistrement de livre audio, une première participation dans une pièce de théâtre au Centre du Théâtre d'Aujourd'hui, un premier rôle dans un long métrage et une exposition de peinture. 
Toutes ces expériences sont complémentaires et nourrissent ma curiosité. 
Au plaisir de vous rencontrer et d'échanger avec vous!
Chloé

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABBPSYBNp0ljz8yi1Z-KF-jjcdlFWgHR1Q/
**Connexions partagées** : 15


---

# Chloe Germentier

## Position actuelle

**Entreprise** : Belgian Canadian Business Chamber (BCBC/CCBC)

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Chloe Germentier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402452911827361792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG5SD2MIdDBoQ/feedshare-shrink_800/B4EZrq4RzoGYAg-/0/1764877213327?e=1766620800&v=beta&t=oMjkHolrUGsz_hLfbr-HumCcytMC3-1fhz8LwNzti1A | Ça a été très inspirant et instructif d’animer ce panel sur la transformation numérique! Merci pour l’opportunité! | 6 | 0 | 1 | 3d | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:33.092Z |  | 2025-12-04T21:05:05.104Z | https://www.linkedin.com/feed/update/urn:li:activity:7402431565311516672/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399146685244874753 | Article |  |  | 4 décembre 2025 - Dentons, 1 Place Ville-Marie. 
11h-14h.

PANEL ÉCONOMIQUE / DIALOGUES TRANSATLANTIQUES : BÂTIR LA CROISSANCE AVEC L'EUROPE. 


Vous êtes une entreprise québécoise/canadienne et vous avez envie de bâtir de nouvelles collaborations avec l'Europe?

Je vais animer le premier panel (d'une longue série) organisé par la CCI française au Canada - CCIFC (j'en profite pour remercier Claire de Bailliencourt pour l'invitation) en collaboration avec Italian Chamber of Commerce in Canada et Belgian Canadian Business Chamber. Nous serons accueillis par Me Xavier Van Overmeire (Partner,  International Trade and Business) chez Dentons.

Le but est d'offrir un échange concret, orienté résultats, entre trois entreprises européennes actives sur des segments technologiques complémentaires:

- l'infonuagique avec OVHcloud - Estelle Azemard (VP Canada)
- l'ingénierie et la cybersécurité pour les secteurs spatial, militaire et gouvernemental avec RHEA Group - Roberto Mazzolin (Chief Defence, Security and Technology strategist)
- et le développement web et mobile connecté aux programmes européens avec CBTW - David Dzialowski (Founder / CEO)

Ce panel s'adresse tant aux personnes qui oeuvrent dans ce milieu qu'aux personnes qui sont désireuses de comprendre les enjeux de la transformation numérique.  Le tout sera expliqué en langage simple et accessible. 

Nous allons aborder trois enjeux précis. 

1) Nous allons poser les bases du cadrage stratégique. Qu'est-ce que la souveraineté numérique? Où sont stockées les données, qui peut y accéder et selon quelles lois? Qu'est-ce que l'autonomie stratégique, c'est-à-dire, la capacité à continuer à fonctionner même si un fournisseur ou un pays change les règles. 

2) Nous allons ensuite, concrètement, parler avec ces entreprises de leurs retours expériences. C'est-à-dire, quels sont les défis que ces entreprises connaissent tant à l'interne, dans le développement de leurs services qu'à l'externe, avec leurs clients. Comment s'organisent les équipes, quels sont les obstacles qu'elles rencontrent et qu'est-ce qui rassure les clients?

3) Enfin, nous allons parler de la situation en Europe et de la capacité de celle-ci à être une véritable aide (et alternative). Malgré une énergie plus chère et des règlementations strictes , comment l'Europe peut-elle être un atout pour les entreprises québécoises / canadiennes. Nous aborderons le type de partenariats cloud qui sont faciles à mettre en oeuvre, le type de partenariats qui réduit les risques et accélère la mise en oeuvre ainsi que les portes d'entrées conseillées. 

Il reste quelques places. Tarif unique de 95$ (+taxes). Panel ouvert aux membres et non membres. 

Le panel sera suivi, de 12h30 à 14h, d'un cocktail/réseautage (dégustation de produits franco-belgo-italiens).

Au plaisir de vous y croiser!

Chloé

Pour vous inscrire: https://shorturl.at/144eA | 15 | 4 | 1 | 1w | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:33.093Z |  | 2025-11-25T18:07:19.260Z | https://www.ccifcmtl.ca/evenements/a-venir/e/event/panel-economique-dialogues-transatlantiques-batir-la-croissance-avec-leurope.html |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399132713787486208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEmEk8zAVWomA/feedshare-shrink_800/B4EZq7__SfKgAk-/0/1764090706187?e=1766620800&v=beta&t=YM7gjpupLZiRVzYRcwPfnSiTlPLukCqNbfMfxGJol7Y | 🔥 Pour la 2e année consécutive, un livre audio que j’ai enregistré pour Audible, se classe parmi les 20 livres les plus écoutés! Je remercie l’équipe d’Audible, la merveilleuse équipe avec laquelle j’ai un plaisir fou à enregistrer, Serge, Johan, Annick, Mathieu, Erick, Rémy, Stevo, Reda de chez Audio Z ;  un énorme merci également à l’autrice Lily Chu pour ses comédies romantiques rafraîchissantes qui sont très agréables à interpréter! Aussi pour cette 3e collaboration avec Audio Z, j’avais un super partenaire de narration: Matthias Lefèvre. 
Et enfin, merci à mes précieuses agentes Eugénie Gaillard et Aurélie Bolduc. 
Vive les 📕 🎧 🔥 | 7 | 1 | 0 | 1w | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:33.094Z |  | 2025-11-25T17:11:48.205Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7331505522845638657 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2f16acd2-ab91-4d0b-971d-5fbdc70a2d93 | https://media.licdn.com/dms/image/v2/D4E05AQHZJfZ_BPK4JA/videocover-high/B4EZb69RMAHIBs-/0/1747967122202?e=1765785600&v=beta&t=KBFCpW-6ridFVMVSgmdoOavtE-P1ymwVIGSuf5uIzTg | Après « Le grand retour », voici le 2e livre de Lily Chu enregistré avec la formidable équipe du studio Audio Z. Une production Audible originals! « À deux mantras du bonheur ». | 9 | 1 | 0 | 6mo | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:33.094Z |  | 2025-05-23T02:25:29.432Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7331503816250449920 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGE-7Ogz74aOg/feedshare-shrink_2048_1536/B4EZb673A3GUAo-/0/1747966720826?e=1766620800&v=beta&t=S4Hl1oc9Ykllv9Tj0dKvJasBH79S4UGGkYLTxhVLqjk | Le 11 mars dernier, j’ai eu l’immense privilège  de lire en français les extraits choisis par les deux incroyables auteurs islandais Jon Kalman Stefánsson et Sigridur Hagalin Bjornsdottir dans le cadre du Festival Fikas fondé par Christel Durand 🇮🇸 | Librairie Un livre à soi (Montréal) | 10 | 1 | 0 | 6mo | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:33.095Z |  | 2025-05-23T02:18:42.548Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7281283182807642112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFmT6dw00CSIw/feedshare-shrink_800/B4EZQxQd0WGwAg-/0/1735993189895?e=1766620800&v=beta&t=JHr8wtnLNjhZ6LC5rs00ZZp3RvWF2HXcWPrGkvdmzQM | Tout bientôt….☀️ | 6 | 0 | 0 | 11mo | Post | Chloe Germentier | https://www.linkedin.com/in/chloegermentier | https://linkedin.com/in/chloegermentier | 2025-12-08T07:11:36.156Z |  | 2025-01-04T12:19:50.481Z |  |  | 

---



---

# Chloe Germentier
*Belgian Canadian Business Chamber (BCBC/CCBC)*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Belgian Canadian Business Chamber | Toronto and Montreal](https://www.bcbc-ccbc.org/)
*2024-01-18*
- Category: article

### [Founder Friday with Chloe Smith of Mercator AI — The51](https://the51.com/51blog/fund-i-mercator-ai)
*2024-11-29*
- Category: blog

### [ABOUT US | Cancham BeLux](https://canchambelux.org/about-us-2/)
*2025-04-01*
- Category: article

### [Cancham BeLux |](https://canchambelux.org/)
*2025-06-25*
- Category: article

### [Belgian Canadian Business Chamber | LinkedIn](https://ca.linkedin.com/company/bcbc-ccbc)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
