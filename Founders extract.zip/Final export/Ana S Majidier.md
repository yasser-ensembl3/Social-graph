# Anaïs Majidier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402089261761568768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFw7W9EJM-Ww/feedshare-shrink_800/B4EZrl.nxtIUAk-/0/1764794994941?e=1766620800&v=beta&t=BPzlTVywXxdAz9fsg0QEQoIKedgKBVJLyJvcfBZpeWU | I must admit, when I first entered the startup world, I had to learn a whole new language: “Seed round”, “VC”, “Bootstrap”, and many more!

I’ve come a long way, but I’m still learning every single day and I know the path ahead is full of new lessons.

I also didn’t know BetaKit back then.
But I quickly realized it was the reference for Canada’s tech and startup ecosystem. It's now the media I read to understand what’s shaping the future, who’s building what, and why it matters.

So being featured in BetaKit today, as a woman co-founder of an impact-driven startup, means a lot.

It’s a milestone of recognition.
It’s credibility for what we’re building.
It’s proof that impact and performance belong together.

We’re betting on community and the community is betting back.

Don’t wait, read the full article to discover what we’re building and how this seed will allow us to scale globally. 🌍

To every person, partner, investor, and teammate who has bet on us: thank you. 💚 

Link to the article : https://lnkd.in/eqYhCayT

#WomenInTech #StartupJourney #CircularEconomy #TechForGood 
#ImpactTech #SharingEconomy #MontrealTech #CanadianStartups 
#BetaKit | 93 | 13 | 0 | 4d | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:24.287Z |  | 2025-12-03T21:00:04.172Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7398775147761025024 | Text |  |  | 🚀 On recrute !

Je suis à la recherche de notre futur·e Client Success Manager (bilingue FR/EN) pour rejoindre l’équipe.

Si tu as envie de travailler au cœur d’une startup à impact, d’être en contact direct avec nos villes et organisations partenaires, et de contribuer à bâtir une expérience client remarquable : viens travailler avec moi. 

👉 Au quotidien, tu vas :
• assurer l’accompagnement de nos clients lors du lancement et tout au long de la relation
• optimiser l’engagement et la réussite de leurs communautés
• structurer des processus et contribuer à bâtir une équipe appelée à grandir
• collaborer avec notre équipe produit
• et participer à la construction d’un modèle de partage moderne, social et durable

Tu vas travailler dans un environnement humain, agile, en constante évolution
et directement avec moi 👋.

📍 Poste basé à Montréal (mode hybride)
 📅 Début janvier
 🗣️ FR/EN

📩 Intéressé·e ou quelqu’un en tête ?
 Écris-moi directement ou envoie ton CV à : anais.majidier@partage.club | 29 | 0 | 2 | 1w | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:24.289Z |  | 2025-11-24T17:30:57.821Z |  | https://www.linkedin.com/jobs/view/4338793735/ | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386378262148595712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFfAHOvHH7NAQ/feedshare-shrink_800/B4EZoEc5DvHEAg-/0/1761011276449?e=1766620800&v=beta&t=-LXPeQpAnCVsW5kOXceF5lxqWsDzK1u6EauemLLnKgc | I’ll be in Tampa, Florida, from October 25–29 for #ICMA2025, where Partage Club will showcase how we help local governments turn social innovation into climate action. 

📍You’ll find us at Booth #748. Come see how our ready-to-deploy sharing platform helps cities reduce waste, strengthen communities, and make a real impact.

🤝 I’d love to connect with mayors, sustainability officers, and innovation leaders attending the event. If you know someone who’ll be there or who works with North American cities, feel free to connect us!

Looking forward to some inspiring conversations and new partnerships across the border. 🇨🇦➡️🇺🇸

#ICMA2025 #SmartCities #CircularEconomy #ClimateAction | 59 | 5 | 0 | 1mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.499Z |  | 2025-10-21T12:30:09.968Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384562510831460354 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHq82m3K1AEXg/feedshare-shrink_800/B4EZnqz5z0KkAg-/0/1760581107923?e=1766620800&v=beta&t=lTZHCOwd0l6i_LrXj6B5-Tdea1fhspSmHGsgBtb1jHw | Do you recognize who’s in this picture? 

Yesterday, I somehow ended up front row for a chat between Harley Finkelstein (President, Shopify) and Chris Arsenault (Partner, Inovia Capital).

Let’s just say… it wasn’t your average wednesday.
These moments are pure fuel. Fuel to recharge the ambition. Fuel to sharpen the vision. Fuel to remind me why I’m doing all this crazy stuff in the first place.

🎃 With Halloween around the corner, Harley shared a spooky-good piece of wisdom: “One of the keys to my success? Avoiding energy vampires.”

You know exactly who he means. Those people who drain your energy, question your ideas, or make your dreams feel too big. 

As founders (and humans, really), our energy is everything.
So if you needed the reminder too: protect it, feed it, and keep people around who make your fire burn brighter.

Here’s to chasing vampires, and surrounding ourselves with good humans, good vibes, and good company. ⚡️🥂 

#Entrepreneurship #Leadership #StartupLife #Founders #Shopify #Inovia #HalloweenWisdom | 113 | 2 | 1 | 1mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.500Z |  | 2025-10-16T12:15:01.119Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7370848509211615232 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGa5IB38MiqLQ/feedshare-shrink_800/B4EZkptE56KUAg-/0/1757341307529?e=1766620800&v=beta&t=zc5t4YppmiJGHIYZPS6ZhEDGjRoHeQMM3nZZp890DQk | 📰 Voir Partage Club dans La Presse ce matin, c’est bien plus qu’une fierté.

Quand on construit une entreprise, chaque étape compte : les premières lignes de code, les premiers membres, les premiers partenaires… et aussi ces moments de reconnaissance externe qui viennent valider que le projet a du sens.

Un article dans un grand média, ce n’est pas seulement de la visibilité.
 ✨ C’est un signal de crédibilité.
 ✨ C’est un boost de motivation pour l’équipe.
 ✨ Et c’est une preuve que l’économie du partage prend sa place dans la société.

Je suis convaincue que si l’on veut transformer nos habitudes de consommation, il faut à la fois des solutions concrètes (comme Partage Club) et des récits inspirants qui donnent envie aux gens de changer leurs réflexes.

🙏 Merci à Ariane Krol et La Presse pour ce bel article qui met en lumière notre mission. Ce n'est que le début !

👉 Bonne lecture : https://lnkd.in/e5PFk_6x | 137 | 8 | 2 | 2mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.501Z |  | 2025-09-08T16:00:28.339Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7361373489498341376 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG7cWR9IhGmWQ/feedshare-shrink_800/B4EZifC7H9HIAs-/0/1755015001597?e=1766620800&v=beta&t=5hBSoLyMsUT72e1tL4c7wcQ2UqUFgNt3HyWyN-3jF8s | 🚨 Je suis sûre que tu connais quelqu’un… qui connaît quelqu’un ! 😉

Deux nouveaux rôles clés sont toujours à combler au Partage Club.
On cherche deux pépites :

🎥 𝐂𝐫𝐞́𝐚𝐭𝐞𝐮𝐫·𝐭𝐫𝐢𝐜𝐞 𝐝𝐞 𝐜𝐨𝐧𝐭𝐞𝐧𝐮
Tu sais capter l’attention même dans un scroll frénétique ? Tu maîtrises les Reels, les formats courts, et tu aimes raconter de vraies histoires humaines ? 
Viens créer du contenu qui fait sourire, réfléchir… et incite à partager.

🤝 𝐂𝐨𝐨𝐫𝐝𝐨𝐧𝐧𝐚𝐭𝐞𝐮𝐫·𝐭𝐫𝐢𝐜𝐞 𝐬𝐮𝐜𝐜𝐞̀𝐬 𝐜𝐥𝐢𝐞𝐧𝐭 & 𝐬𝐞𝐫𝐯𝐢𝐜𝐞 𝐚𝐮𝐱 𝐦𝐞𝐦𝐛𝐫𝐞𝐬
Tu es organisé·e, débrouillard·e et tu aimes autant répondre aux besoins des utilisateurs que soutenir une équipe terrain ou marketing ? Ce poste est pour toi.

🔗 Lien vers les offres : https://lnkd.in/eisRnRsz
📩 Pour postuler, envoie ton CV à : anais.majidier@partage.club
🕘 Date limite : fin août 2025

✨ Partage ce post ou tague la personne parfaite pour ces rôles. 🔥 | 46 | 3 | 5 | 3mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.502Z |  | 2025-08-13T12:30:07.602Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7351589311311421442 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGlBB-ixu0-SA/feedshare-shrink_800/B4EZgWvBvwHgAk-/0/1752728085180?e=1766620800&v=beta&t=RuLqPPe3790iuTRd0mxFsao3vPAVYkumTPbyF69Gmgw | 📸 Deux photos, deux ans d’écart.

Il y a des journées qu’on n’oublie pas.
Sur celle de gauche : le jour où nous avons signé pour devenir officiellement cofondatrices du Partage Club.
C’était il y a deux ans, jour pour jour.

(Partage Club existait déjà, mais Fauve Doucet m’a offert un siège à ses côtés ou comme dirait Marie-Chantal Chassé, Eng., ICD.D : elle m’a permis d’adopter son bébé.)

Je me souviens parfaitement de ce moment.
Le mélange d’excitation, de lucidité, de détermination… et de peur aussi.
Je savais que je disais oui à plus qu’un projet. Je disais oui à une vision, à une autre façon de faire les choses. Et à une aventure humaine forte, avec Fauve.

Sur la photo de droite, nous voilà deux ans plus tard :
Toujours là, ensemble et animées par la même passion.

Être associée, c’est un peu comme être en couple mais au travail.
C’est construire une relation de confiance.
Savoir se parler franchement. Se soutenir. Se challenger.
C’est être fières de notre “bébé” qu’on voit grandir jour après jour.

On construit, brique par brique, cette entreprise qu’on a imaginée.
Et j’en suis tellement fière.

Mais surtout : on n’est plus deux.
On a maintenant une équipe formidable autour de nous.
Des personnes brillantes, drôles, investies, qui partagent nos valeurs et notre vision. Et ça, c’est peut-être ce qui me rend le plus fière. 

Merci à vous tous·tes qui croyez au partage, à l’audace douce, à l’intelligence collective.

Et merci à toi, Fauve Doucet. 💛

#PartageClub #DeuxAnsDéjà #Cofondatrices #Fierté #StartupLife #EntreprendreAutrement #ConstruireEnsemble | 182 | 36 | 1 | 4mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.503Z |  | 2025-07-17T12:31:17.741Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7348365920064479232 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGnT8Xgm1Wb0w/feedshare-shrink_800/B4EZfnvoiXG4BA-/0/1751939716942?e=1766620800&v=beta&t=Cm4l8mt0IuWt5sLJ1Fea2XmhlR4cyahXp2yzEPFiNl0 | Aujourd’hui, c’est mon anniversaire ! 🎂
Et si tu veux vraiment me faire plaisir… j’ai une petite faveur à te demander.

👉 Partage ce post pour m’aider à trouver les perles rares qui viendront renforcer notre équipe chez Partage Club.

Un simple clic pour toi, un grand coup de pouce pour nous 🙏

Merciiiii

#recrutement #emploi #startup #économiecirculaire #impact #anniversaire #PartageClub | 37 | 10 | 14 | 4mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.504Z |  | 2025-07-08T15:02:41.380Z | https://www.linkedin.com/feed/update/urn:li:activity:7348323759713378304/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7341491227973849093 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHUNNf1BHAJBg/feedshare-shrink_800/B56ZeI3XVNGQAk-/0/1750347905252?e=1766620800&v=beta&t=NiHBIGu2KiHGvdTKABqfu7BOxVDhL6P8uUtn_wf4xwI | « Ils ont partagé le monde, plus rien ne m’étonne. » 🎶

C’est la chanson qui m’a le plus émue hier soir, au concert de Tiken Jah Fakoly.
Écrite il y a des années… et pourtant tristement toujours d’actualité...

Pour ceux qui ne le savent pas, je suis d’origine iranienne. Et ce qui se passe en ce moment entre l’Iran et Israël me bouleverse profondément. Plus largement, la violence et les conflits qui secouent le monde en continu m’horrifient. 💔

Je suis une idéaliste. Une rêveuse. Une pacifiste. ✨
Et j’essaie, chaque jour, notamment à travers mon travail, de cultiver cet espoir.  Avec Partage Club, on rêve (très concrètement) d’un monde où l’humanité prédomine.
Un monde où l’on s’entraide, où l’on partage, où l’on se reconnecte. 🤝🌍

Alors merci, Tiken Jah Fakoly, d’être cet artiste engagé et bienveillant. 🙏
De faire danser les consciences, de pointer ce qui ne va pas, et de rassembler des milliers de personnes pour chanter à l’unisson des paroles de paix et d’espoir.

On en a cruellement besoin et hier soir m’a fait le plus grand bien. 

#musictherapy #partage #paix | 84 | 5 | 0 | 5mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.505Z |  | 2025-06-19T15:45:07.060Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7338180688371744768 | Video (LinkedIn Source) | blob:https://www.linkedin.com/89721db1-b89e-498a-8187-f8e1272249e1 | https://media.licdn.com/dms/image/v2/D4E05AQFxZ8n_MEuglg/feedshare-thumbnail_720_1280/B4EZdX41rEHIAs-/0/1749526208376?e=1765778400&v=beta&t=OvvJid53CTRMXKJsrCLfLePYyDbbALj1sVtdsTgXhpE | 🎬 Clap de fin sur le SIIViM 2025
On m’a demandé si je n’étais pas trop fatiguée après cette mission en France.
Au contraire.
Je me sens énergisée. Inspirée. Et un peu nostalgique.
Comme après un voyage où on sent qu’on était exactement au bon endroit, au bon moment.

Le SIIVIM, c’est quoi ?
C'est le Sommet international de l’innovation des villes médianes. Un événement incontournable réunissant acteurs publics et privés autour d’un thème central : l’innovation au service de la transition énergétique et environnementale. 💡🌱

🎉 Cette année, Partage Club a eu l’immense honneur d’être sélectionné parmi les 5 startups coup de cœur du jury français. Katrina Besner et moi avons eu la chance de présenter notre solution à des élus et des décideurs, tous curieux et emballés par l'idée de partager. 

🧑‍🤝‍🧑 Nous faisions partie d’une délégation québécoise de 80 personnes, pilotée de main de maître par IVÉO : élu·es, maires, entreprises. On arrive en ne connaissant presque personne, et on repart avec des idées plein la tête, beaucoup de cartes d'affaires et des liens tissés avec des personnes inspirantes.

Ce que je retiens :
✨ Les villes françaises sont prêtes pour des solutions de partage concrètes.
✨ Il existe une vraie volonté de collaboration transatlantique.
✨ Et surtout : Partage Club a toute sa place dans ces conversations et suscite des envies d’agir.

 👉 Rendez-vous en 2026 dans les Laurentides pour la prochaine édition ! On a déjà hâte.

---

 🙏 Merci à Dunkerque, Patrice VERGRIETE, Stéphane Baeteman pour votre accueil sincère. J'ai été ravie d'en apprendre plus sur votre ville. 

🤝 Merci à l’équipe d’IVÉO : Marie-Christine Foucault, Benoit Balmana, Simon Lajoie, Jean-Sébastien Bouchard, Galaad Lefay pour l’organisation de cette belle délégation, et pour votre soutien tout au long du parcours. 

#SIIVIM2025 #PartageClub #InnovationSociale #TransitionÉcologique #ImpactCollectif #Québec #France #ÉconomieCirculaire | 37 | 1 | 0 | 5mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.506Z |  | 2025-06-10T12:30:12.912Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7330578075887300609 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHsHNivJ5_0ag/feedshare-shrink_800/B4EZbrtpAqGUAk-/0/1747711332926?e=1766620800&v=beta&t=ntkObLCjopecpGcsXK6F-cmAVaQO1WYUsT8s2MfQQYc | Il y a quelques semaines, un journaliste de L'actualité m’a contactée : il voulait écrire un article sur Partage Club. J'adore quand les journalistes s’intéressent à ce qu’on construit.

Mais samedi, en découvrant le titre « Partage Club : l’abonnement vaut-il la peine ? », je ne vous cacherai pas que j’ai eu une petite montée d’adrénaline.

Avec l’équipe, tout ce qu’on veut, c’est offrir une expérience incroyable à nos membres. On met tout notre cœur dans le produit et l’expérience. On travaille l’UX, on teste, et on s’assure que tout soit fluide, beau, rapide.

Mais il y a des choses qu’on ne contrôle pas :
➡️ Est-ce qu’il habite dans un quartier bien desservi ?
➡️ Est-ce qu’il tombe sur des voisins sympas ?
➡️ Est-ce que l’objet qu’il cherche est disponible ?

💥 Spoiler : l’expérience a été positive. Fiou 😌
Comme 94 % de nos partageurs, qui disent avoir eu un échange positif… et vouloir recommencer.

Merci Karl Rettino-Parazelli d’avoir joué le jeu pour de vrai : téléchargé l’app, publié un besoin, fait un emprunt, et pris le temps de raconter tout ça avec nuance.

👉 L’article complet est à lire ici : https://lnkd.in/ePamtBnR | 113 | 9 | 1 | 6mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.507Z |  | 2025-05-20T13:00:08.846Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7328751057067532289 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGiBatIExoR0Q/feedshare-shrink_800/B4EZbQA2rkHcAg-/0/1747246608369?e=1766620800&v=beta&t=FKgs8B73wXFN6UZT8ycEaPuLOqK0W_2f6qWZTHgHq0U | 💬 Hier, je n’étais pas à la maison. Et c’est ma fille qui a accueilli notre voisine venue rapporter un simple moule à gâteau.

📩 Quelques heures plus tard, je reçois ce message :
« En une semaine d’inscription, j’ai emprunté et prêté des objets. Ça m’a aidée à m’acclimater à mon nouveau quartier. Bravo encore ! »

Ce genre de message, c’est tout ce qu’on espérait quand on a lancé Partage Club. Un acte qui crée du lien, rend service, et transforme un quartier en communauté.

L’impact social du Partage Club, il est là.

Et vous, quel est le dernier objet que vous avez partagé ? | 128 | 8 | 0 | 6mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.507Z |  | 2025-05-15T12:00:13.615Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7328406615940820994 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEV6LYOWakJ3Q/feedshare-shrink_800/B4EZaodlBTHcAg-/0/1746583049503?e=1766620800&v=beta&t=kBNMM0-pWMavVGcqOQ-kWVVqatgJtjRrfmxyuArpb6k | ⏰ C’est aujourd’hui à midi !
Tu veux savoir combien de bouteilles de plastique peuvent être détournées… grâce à une perceuse partagée ? 🛠️♻️

Tu veux comprendre pourquoi le partage, c’est révolutionnaire pour l’environnement, l’économie et notre lien social ?

Alors ne rate pas ça  👉
📍En ligne et ouvert à tous
🔗 Lien ici : https://lnkd.in/eq7-mF2P

J’espère vous voir nombreux ! 🙌 | 7 | 0 | 0 | 6mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.508Z |  | 2025-05-14T13:11:32.451Z | https://www.linkedin.com/feed/update/urn:li:activity:7325863242411483136/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7323692696538152960 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQFeXQjXFaPl8Q/feedshare-thumbnail_720_1280/B56ZaJl5y6HgAs-/0/1746065137879?e=1765778400&v=beta&t=9WaJBuJz2jIhwOYz8kjk8aCqLk5UpfzLLzPlrKVNAA0 | Le partage de services débarque sur l’app, nouveauté exclusive à Beaconsfield ! 

Derrière chaque objet partagé, il y a souvent bien plus qu’un simple prêt.
Il y a un échange. Une rencontre. Parfois même, un petit transfert de savoir.

👉 Tiens, je te prête mon chariot, voici comment l’ouvrir et le refermer.
👉 Je te prête ma poussette, fais juste attention, elle a le virage un peu sportif.
👉 Tu peux prendre mon nettoyeur à tissu, ajoute un peu de bicarbonate, tu verras, ça nettoie mieux.
👉 Voici ma perceuse. C’est pour un mur en plâtre ou en placo ? Si c’est du placo, tu auras peut-être besoin de chevilles Molly. J’en ai chez moi, je t’en apporte.

Ces échanges, on les a entendus. Encore et encore. 💬

🎉 Et aujourd’hui, c’est officiel : grâce à City of Beaconsfield, le partage de services devient réalité sur l’appli ! 

Un tout premier projet pilote, exclusif à la ville pour le moment, qui ouvre la porte à encore plus d’entraide… et de belles rencontres.

Quelle fierté. Un nouveau chapitre s’écrit, la suite logique du partage d’objets.💛 | 44 | 1 | 1 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.510Z |  | 2025-05-01T13:00:06.485Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7320604828441735169 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSuiRJCRejbg/feedshare-shrink_800/B4EZZbJ83PHYAk-/0/1745286058595?e=1766620800&v=beta&t=zXb8iXHYFzzyoYM3MLvzcDgTeilpSa0LZzHY1fLFfxE | Plus de 50 % des Québécois font déjà confiance à Desjardins. Et aujourd’hui, Desjardins choisit de faire confiance à Partage Club. 🙌 

Hé oui, nous avons signé un partenariat avec l’une des institutions les plus respectées du Québec. Pour faire avancer, ensemble, un modèle de société basé sur le partage plutôt que la surconsommation.
 
Une preuve que les grands acteurs peuvent s’engager vraiment dans la transition écologique.

💬 Walk the talk, comme on dit. Aujourd’hui, Desjardins le fait.

Une immense fierté pour moi, et pour toute l’équipe, en ce jour symbolique du Jour de la Terre. 🌍 | 57 | 5 | 1 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.511Z |  | 2025-04-23T00:30:01.361Z | https://www.linkedin.com/feed/update/urn:li:activity:7320431246923231232/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7318430555551719425 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGoOivV-xr8QA/feedshare-shrink_800/B4EZZBJyT3HEAg-/0/1744849812348?e=1766620800&v=beta&t=dMVX9cvNHAmcPU2PcIydndh3cvkXw8QpCwShe4jgUIM | And it’s a wrap sur deux jours intenses au Sommet canadien de l’économie circulaire, avec des participants venus des quatre coins du monde 🌍

Quelques fun facts & food for thought récoltés au passage :

🎤 Katrina Besner et moi avons eu la chance de présenter Partage Club devant plus d’une vingtaine de villes internationales (San Francisco, Dublin, Rome, etc. ). Merci encore Natacha Beauchesne.

🏙️ Atlanta : longtemps surnommée “the city of the poorest”,  est aujourd’hui un des piliers de la justice environnementale. Un mouvement pour que les communautés vulnérables ne soient plus les seules à vivre à côté des décharges ou à manquer d’infrastructures vertes.

💧 Murcie (Espagne) : championne mondiale de la réutilisation des eaux usées — 98 % recyclées (!), contre 5 % en moyenne en Europe. 

🐟 Squamish : ville à la croissance la plus rapide au Canada. Cette expansion exerce une pression croissante sur l'environnement local, notamment sur l'estuaire de Squamish, un écosystème vital pour de nombreuses espèces.

📚 Je suis sortie de là un peu plus intelligente, avec du nouveau vocabulaire : local bio-based materials & anaerobic digestion.

📉 Et cette question toujours aussi pertinente : pourquoi le PIB ignore-t-il encore des indicateurs aussi essentiels que les GES évités, la circularité ou le bien-être collectif ? 🤔

📣 À Montréal, le ton est donné :
“L’économie circulaire n’est plus une option. C’est l’avenir de notre économie.”
 Merci Daniel Normandin pour ce rappel percutant.

Bref, dans une époque où l’éco-anxiété s’est invitée dans nos quotidiens, ça fait du bien de se retrouver entourée de gens brillants, concrets, engagés. Qui ne se contentent pas de réfléchir, mais agissent.

Ravie des rencontres, des discussions et de repartir avec un peu plus d’élan !

#ÉconomieCirculaire #JusticeEnvironnementale #Impact #Innovation #PartageClub #Montréal #CCES | 72 | 9 | 1 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.512Z |  | 2025-04-17T00:30:14.308Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7317886946251337728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHo_RlSU5_ZiA/feedshare-shrink_2048_1536/B4EZY2xRmXHMAs-/0/1744675609654?e=1766620800&v=beta&t=mQ27DrvViw2v_riOPjavwO2wbaJ4S4lmj5sVefjxSVc | 💥 Les marchés fluctuent. Et si le partage devenait votre meilleur investissement ? 

On parle souvent de l’impact environnemental du partage. Mais savez-vous qu’il y a aussi un véritable bénéfice économique ?

Sur Partage Club, nous avons intégré un outil d’IA qui calcule, en temps réel, les économies réalisées grâce aux emprunts. 

💸 De mon côté ? 3 675 $ économisés. J'ai emprunté de nombreux objets : 
🎿 Des skis de fond.
🎮 Une Nintendo Switch pour mon fils.
🎸 Une guitare électrique pour ses premiers cours de musique, etc.

Pas des objets de luxe.
Des objets qui ouvrent des portes : à des passions, à des plaisirs simples, à des expériences qui comptent.

🎨 Le partage, c’est aussi ça. C’est rendre le quotidien plus accessible, sans compromis, sans achat.

Et si on arrêtait de tout posséder pour simplement mieux partager ?

👉 Vous seriez surpris de voir tout ce que vous pouvez emprunter autour de chez vous. Et vous, combien avez-vous économisé ? | 48 | 2 | 0 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.513Z |  | 2025-04-15T12:30:07.751Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7316441144832196608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE5yCzr6Bg6NA/feedshare-shrink_2048_1536/B4EZYi7uuFHkAo-/0/1744342806001?e=1766620800&v=beta&t=aZskmjyTnp-gcdRzYYmIxRohmTbwHh-q8oCy4BToKGs | Partage story 🏸

Je me suis inscrite au badminton.
J’achète une raquette ou… j’emprunte ?
J’emprunte, évidemment.
Je cherche sur Partage Club, et en 5 minutes, j’en trouve une à deux coins de rue. 
Simple, rapide, gratuit.

J’en ai ai fait des emprunts.
Et pourtant, à chaque partage, il se passe un truc.
Un petit moment de magie.
Un “wow, les gens sont vraiment généreux.”
Quelqu’un que je ne connais pas me répond… et me fait confiance !

C’est ça, le vrai pouvoir du partage.
Des gens qui ouvrent leur porte.
Qui tendent la main.
Sans rien attendre en retour.

Et ça, c’est fort. 

Et vous, vous avez déjà emprunté un objet à un voisin ? | 57 | 2 | 0 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.514Z |  | 2025-04-11T12:45:01.831Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7316135397938376705 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHfIgbdCSREGw/feedshare-shrink_800/B4EZYgfvtGHYAk-/0/1744301916064?e=1766620800&v=beta&t=PlnQJ_ik19A55NyaCP4-mKme4N6jbfe4DgyyoY9Y-pM | Waouh. Quelle énergie. Quel lancement. 💥

Une salle comble pour dévoiler notre tout premier 𝐫𝐚𝐩𝐩𝐨𝐫𝐭 𝐝’𝐢𝐦𝐩𝐚𝐜𝐭, réalisé avec l’équipe brillante de McGill University.

Parce qu'au Partage Club, on ne veut pas juste parler d’impact.
On veut le 𝐦𝐞𝐬𝐮𝐫𝐞𝐫, 𝐥𝐞 𝐩𝐫𝐨𝐮𝐯𝐞𝐫, et surtout… 𝐥’𝐚𝐦𝐩𝐥𝐢𝐟𝐢𝐞𝐫.

🌍 Notre mission est simple (et essentielle) : Changer notre rapport à la propriété. 𝐏𝐨𝐬𝐬𝐞́𝐝𝐞𝐫 𝐦𝐨𝐢𝐧𝐬. 𝐏𝐚𝐫𝐭𝐚𝐠𝐞𝐫 𝐩𝐥𝐮𝐬. ✨

Notre boussole, c’est l’impact. Chaque décision est guidée par notre volonté de maximiser notre impact 𝐞𝐧𝐯𝐢𝐫𝐨𝐧𝐧𝐞𝐦𝐞𝐧𝐭𝐚𝐥, 𝐞́𝐜𝐨𝐧𝐨𝐦𝐢𝐪𝐮𝐞 𝐞𝐭 𝐬𝐨𝐜𝐢𝐚𝐥.

Un immense merci à toutes celles et ceux qui étaient là pour célébrer ce moment avec nous. Vous nous donnez de l’élan. Et vous prouvez que le changement est déjà en marche. 🙌

📄 Le rapport est maintenant disponible sur notre site 👉 https://lnkd.in/eB5xfGy9

 📺 Et pour celles et ceux qui n’ont pas pu être présents, un 𝐰𝐞𝐛𝐢𝐧𝐚𝐢𝐫𝐞
 suivra très bientôt. Restez à l'affût !

Faisons ensemble du partage une nouvelle norme : Partaging is the new buying.💚 | 94 | 3 | 1 | 7mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.515Z |  | 2025-04-10T16:30:06.091Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7313587357142646784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFaKdtHMTp1KA/feedshare-shrink_800/B4EZX723FlGgAo-/0/1743687220379?e=1766620800&v=beta&t=P8039LUltXDdNirmVyOEoYW70Z1ScI4uiC9qA4ywQPs | 🚨 Et si je vous disais qu’un seul partage d’objet détourne l’équivalent de 11 bouteilles de plastique de 1,5 L des poubelles ?

Une nouvelle étape clé dans l’histoire du Partage Club : notre impact est désormais chiffré, concret, prouvé.

On le savait : partager des objets plutôt que les acheter, ça a un impact environnemental, économique et social… mais quel est l’impact réel, chiffré, concret ?

➡️ Quel effet sur les émissions de GES ?
➡️ Combien de déchets évités ?
➡️ Quel impact social mesurable ?

Ces questions, vous nous les avez posées encore et encore ces deux dernières années. Et aujourd’hui, on peut enfin y répondre. 🙌

Grâce à une collaboration rigoureuse avec McGill University, et deux chercheurs passionnés – Maëlle Morin et Sanjith Gopalakrishnan – on a enfin les chiffres.

🎉 Un vrai jalon dans l’histoire du Partage Club. On est fiers.

👀 Curieux de découvrir les résultats ?

📍 Maison du développement durable – Montréal
🕣 Le 8 avril, de 8h30 à 11h00
🎟️ Événement gratuit – et tu peux venir avec un +1 !
👉 Réserve ta place ici : https://lnkd.in/eh9MVUU4

À bientôt !

#PartageClub #Impact #Données #Recherche #McGill #ÉconomieCollaborative #GES #RéductionDesDéchets | 51 | 1 | 3 | 8mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.517Z |  | 2025-04-03T15:45:05.825Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7302773385363705856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEaniKB00hR1w/feedshare-shrink_800/B4EZVipsYyGYAk-/0/1741116852469?e=1766620800&v=beta&t=ShT3povl0rHxkJobQoanzfYe5LKvoRKcjq7b0kwiE7A | 𝐄𝐬𝐭-𝐜𝐞 𝐪𝐮𝐞 𝐭𝐮 𝐜𝐨𝐧𝐧𝐚𝐢𝐬 𝐪𝐮𝐞𝐥𝐪𝐮’𝐮𝐧 𝐪𝐮𝐢 𝐜𝐨𝐧𝐧𝐚𝐢̂𝐭 𝐪𝐮𝐞𝐥𝐪𝐮’𝐮𝐧 ? 

Nous ouvrons un rôle à la fois stratégique et terrain : un.e 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐚𝐛𝐥𝐞 𝐌𝐨𝐛𝐢𝐥𝐢𝐬𝐚𝐭𝐢𝐨𝐧 𝐞𝐭 𝐂𝐨𝐦𝐦𝐮𝐧𝐚𝐮𝐭𝐞́.
 
🚀 Découvre notre offre en détail ici : https://lnkd.in/eisRnRsz

👉 Si tu es cette personne, écris moi !
 
📢 Et si ce n’est pas toi, tu peux nous aider :
✅ Partage ce post avec ton réseau
✅ Tague une personne qui pourrait être intéressée | 33 | 1 | 6 | 9mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.517Z |  | 2025-03-04T19:34:14.039Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7301292591109537792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFvIBVFrcC-kg/feedshare-shrink_800/B4EZVNkGRTG0Ag-/0/1740763065111?e=1766620800&v=beta&t=KueN6imXt_UZlKmvtA6TVuuhedCapdloIbwnOJmGDr0 | Le 19 janvier 2025, tout a basculé.

Il avait plu la veille, il faisait très froid, et tout était glacé. Une seconde d’inattention, une chute brutale sur la tête, un choc.

Ma première pensée ? M***, je vais avoir le dos bloqué demain.

Si seulement…

Les trois jours suivants, les maux de tête étaient violents, les vertiges omniprésents, les nausées intenses. Mon esprit était dans le brouillard. Je n’étais plus moi-même, incapable de travailler.

Quelques jours de repos et je n'allais pas mieux. Une semaine plus tard, direction l’Institut des commotions cérébrales de Montréal. Le verdict tombe : traumatisme crânien. Un arrêt de travail m’est prescrit. Coup de massue.

𝐑𝐞𝐩𝐨𝐬 𝐭𝐨𝐭𝐚𝐥 𝐞𝐱𝐢𝐠𝐞́.
❌ Zéro écran.
❌ Zéro activité cérébrale.
❌ Zéro sport.
❌ Zéro lecture.

Quel choc. Je suis passée par toutes les phases : tristesse, déni, colère… et, honnêtement, je crois que je ne l’ai toujours pas totalement accepté. 

Le pire ? Ne pas savoir quand j’allais aller mieux. Il n’y a pas de règle : certains se remettent en 2-3 semaines, d’autres en 3 mois, 6 mois, voire une année complète. Impossible à prédire.

Pendant 5 semaines, j'ai respecté le protocole :
✔️ J’ai peu – voire pas – travaillé.
✔️ Je n’ai presque pas regardé les écrans.
✔️ Je n’ai presque pas fait de sport.
✔️ J'ai apprivoisé le silence et le calme.
✔️ J’ai dormi – beaucoup dormi.

Et pendant ce temps, une équipe incroyable a pris le relais.
Fauve Doucet, Katrina Besner, Audrée Morin Berthiaume, Guillaume Boudreau, Benoit Massé, Grégory Bouzonville, MBA, Catherine Robert.

🔹 Vous avez mis des projets sur pause.
🔹 Repris mes discussions avec les clients.
🔹 Assumé certains dossiers - alors que vous en avez déjà tous beaucoup.
🔹 Trouvé des solutions.
🔹 Fait en sorte que je puisse récupérer, sans stress, pour mieux revenir.

Un merci spécial à Fauve Doucet, qui, au-delà de tout, a été un véritable pilier. J’ai une chance incroyable de t’avoir à mes côtés. 

Aujourd’hui, je fais un retour progressif, avec quelques matinées de travail.
Que ça fait du bien ! J’étais comme une droguée en manque… Détox digitale et détox professionnelle.

Ça a été très difficile, mais je commence à aller mieux. Les maux de tête ont diminué. Je vais pouvoir reprendre de plus en plus.

Pourquoi ce post ?
✨ Parce que la santé, c’est tout, et on ne doit pas l'oublier. 
✨ Parce qu’avoir la chance de pouvoir compter sur des humains exceptionnels, ça mérite d’être dit. 💚💚💚 
✨ Et parce qu’en tant qu’entrepreneure, je sais que c’est un luxe que tout le monde ne peut pas se permettre. Pouvoir prendre un vrai temps de repos sans que tout s’écroule, c’est rare. J’en suis profondément reconnaissante. 🙏 

Faites attention à vous ! | 153 | 29 | 1 | 9mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.519Z |  | 2025-02-28T17:30:05.177Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7282787890449772549 | Text |  |  | Le Partage Club recrute ! 🚀 

🎥📱Créer des Reels, des stories ou des posts sur Insta et TikTok, c’est ton deuxième langage ?
✍️✨ Rédiger du contenu clair et percutant, c’est ton super pouvoir ? 
🎨🎯 Designer du matériel promotionnel pour des événements et des campagnes médias, c’est ta zone de confort ? 

👉 Si tu as répondu oui à tout ça, alors c’est toi qu’il nous faut !

Mais attention, voici les critères pour être éligible :
✅ Tu as moins de 30 ans.
✅ Tu habites au Canada.
✅ Tu es à la recherche de ton premier emploi dans le domaine.

Prêt·e à rejoindre une startup d’impact qui révolutionne le partage d’objets entre voisins ? 🌱 Contacte-nous dès maintenant !
📧 anais.majidier@partage.club | 23 | 0 | 2 | 10mo | Post | Anaïs Majidier | https://www.linkedin.com/in/anaismajidier | https://linkedin.com/in/anaismajidier | 2025-12-08T05:21:30.519Z |  | 2025-01-08T15:59:00.739Z |  | https://www.linkedin.com/jobs/view/4119795967/ | 

---

