# Jonathan Punski

## Position actuelle

**Titre** : CEO & Founder
**Entreprise** : DogPack
**Durée dans le rôle** : 4 years 2 months in role
**Durée dans l'entreprise** : 4 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Pet Services

## Résumé

As the CEO and Founder of DogPack, an innovative online platform created alongside my three brothers, I am passionate about uniting dogs and their owners through technology, community, and meaningful connections. DogPack was born out of a shared love for dogs and a vision to build a comprehensive ecosystem where dog lovers can discover dog-friendly parks, services, events, and businesses while connecting with a global community of like-minded individuals.

With DogPack, we’ve created a platform that empowers dog owners to explore, share, shop, travel, plan meetups, and promote their dog-related businesses. By blending user-friendly technology with a vibrant community, DogPack isn’t just an app; it’s a lifestyle for dog enthusiasts everywhere.

Our mission is simple but impactful: to improve the lives of dogs and their owners by making the world a more connected, dog-friendly place. I’m excited about the journey ahead as we continue to innovate and expand the DogPack community.

Feel free to reach out to me at jonathan@dogpackapp.com. I’m always happy to connect with fellow dog enthusiasts, business owners, and anyone interested in making the world more dog-friendly.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACSb2uAB8Wwoz1KpcQvZ3m3Y4sw5nk-jSPs/
**Connexions partagées** : 14


---

# Jonathan Punski

## Position actuelle

**Entreprise** : DogPack

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jonathan Punski

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399500189297975296 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7oFAff7lPFw/feedshare-shrink_800/B4EZrBOKxeIQAg-/0/1764178317096?e=1766620800&v=beta&t=r0OrjmWEzT-EM3LdQQOQ_TCoEg18qovRnLs6WtNdJK0 | We’re pleased to welcome the newest member of the DogPack team! 

Although he doesn’t have a name yet, he brings an impressive 5 days of experience of being an incredible people pleaser and making everyone around him smile instantly ✨

Welcome to the team! 🐾 | 146 | 20 | 1 | 1w | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:29.807Z |  | 2025-11-26T17:32:01.194Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391911706551279617 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3ZwvY0IzNYg/feedshare-shrink_800/B4EZpVYhe4HoAg-/0/1762369084452?e=1766620800&v=beta&t=zkBaG5PKD9qWbKN6gTP8A69AIc4h4Etaw9d5wrsHT1M | Every store that joins our Marketplace in this early stage is truly appreciated.

The DogPack Marketplace is live on our website, and is going through the last testing phases to be released on our app to be seen by over 550k unique Monthly Active Users.

A special shout out to Darren Silverman at Chuckit! for being an early adoptor and providing us with his valuable, awesome feedback. His amazing contributions have been helpful not only for us, but for other leaders as they work to build their space on DogPack's new Marketplace!

Getting that trust and support is truly encouraging for our whole team, and reminds me how important it is to try and pay it forward. | 33 | 4 | 1 | 1mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:29.807Z |  | 2025-11-05T18:58:05.920Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386821946107207680 | Article |  |  | We built our own Marketplace! Sellers are signing up everyday, and we're just about ready to launch it to buyers through our newsletters, in-app notifications, and social media channels. Buyers will also be rewarded with in-app Points when they purchase, incentivizing them to shop on the DogPack Marketplace. | 44 | 2 | 0 | 1mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:29.808Z |  | 2025-10-22T17:53:12.467Z | https://www.dogpackapp.com/blog/dogpack-marketplace-shop-dog-products/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7373821800004227072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEqJM2PMcVdOw/feedshare-shrink_800/B4EZlUT2kpIQAg-/0/1758056114997?e=1766620800&v=beta&t=srMFWIfA7AEKpo4BfL-ZXg5UtEMz9usN949TqP1oJg4 | Big milestone this week - DogPack was featured in Bloomberg Businessweek in a piece by none other than the Editor Brad Stone. Definitely one for the bucket list.

He may have roasted us for some dad-joke level humor (😅), but a lot has changed since that interview. Today we’re creating heartfelt, purpose-driven videos, collaborating with famous dogs, and the dogs of famous owners, reaching millions of people around the world.

Next up: the launch of our Marketplace to buyers next week, and a couple other very exciting things we're keeping under wraps until the day they're released!
On top of that, our social channels just hit record highs, now with 1.2M+ followers across Facebook, Instagram, and TikTok.
Grateful for the momentum and even more excited for what’s ahead.

https://lnkd.in/eEK3UXKn | 77 | 5 | 2 | 2mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.599Z |  | 2025-09-16T20:55:16.105Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7371245004259741696 | Text |  |  | Any Unity developers in my network looking for some consultancy work? | 12 | 2 | 0 | 2mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.599Z |  | 2025-09-09T18:16:00.125Z | https://www.linkedin.com/feed/update/urn:li:activity:7371243462328754176/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7369132427434299393 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGCSB3Zby4Rjw/feedshare-shrink_1280/B4DZkMqzFqGgAs-/0/1756854170372?e=1766620800&v=beta&t=tf6FXanOBFiEOFqSkE7-fqaAmflvNNnbdUsg1e6jAVY | So incredibly proud of my wife on this amazing accomplishment. 
To many more 🥂 | 31 | 3 | 0 | 3mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.600Z |  | 2025-09-03T22:21:22.560Z | https://www.linkedin.com/feed/update/urn:li:activity:7368780484161474560/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7366495950564933633 | Article |  |  | This was such an insightful piece by The Woof that I learned things about our content strategy that I didn’t even consciously realize we were doing. Great breakdown, and highly recommend this newsletter to anyone interested in the pet space. | 17 | 3 | 0 | 3mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.600Z |  | 2025-08-27T15:44:57.491Z | https://www.woofnews.co/p/how-dogpack-added-600k-followers-in-just-10-days |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7365755641770024962 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFfBU1jmo97Qw/feedshare-shrink_2048_1536/B4EZjhrubOGYA0-/0/1756132993378?e=1766620800&v=beta&t=2sA4LiRMHoaGUCQQ9tmh6WS4D-K4pGEKlmEgAyv_gxw | When our videos on social media started going viral we were excited, the followers were pouring in, organic users on the DogPack app started to grow quickly, and the positive comments made us smile.

Then we started to think, how can we leverage this large, loyal and engaged audience to move forward our mission statement of: 
"Making the world a better place for dog's and their humans."

So we reached out to Niall Harbison, the CEO of Happy Doggo, and next thing you know we collaborated on this video featuring Hank, the rescue dog, a true story of a dog that Niall rescued from deaths door.

https://lnkd.in/eHQc5hNK

In just 2 hours since the video has been published we've seen an overwhelming amount of positive comments including 
'This is the best use of AI I've seen so far.'

Hats off to Dov Punski for making this one a reality. Making people laugh and smile is great, but seeing the reactions on this video with such a powerful message is truly breathtaking! | 40 | 1 | 1 | 3mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.601Z |  | 2025-08-25T14:43:14.120Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7361454036325134336 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYwuKVM9s0LQ/feedshare-shrink_800/B4EZikjUJGGYAw-/0/1755107405811?e=1766620800&v=beta&t=wn1WtENU3fsZXfjT7Dkj_qahaROTrRw9BGwZXCSEY2k | At the event of the year for pet products, at SUPERZOO. Over 1,200 booths of innovative and incredible products.

Zaiaad Khan Aryeh Punski Dov Punski and myself are spreading the good word about DogPack’s new Marketplace where pet brands can reach their target audience easily. 

Just list or sync your existing store and we make sure your products get seen by the right people, at the right time!
The show is off to a great start. | 73 | 1 | 0 | 3mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.601Z |  | 2025-08-13T17:50:11.462Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7359303567637135362 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFGutsVRLgExg/feedshare-shrink_800/B4EZiF_hJLGYAo-/0/1754594691289?e=1766620800&v=beta&t=ReLIZLTXtIUQjhs_Nx6hCrGnDtlAfjY-VJBEB9CqySM | Thanks adjoe for inviting Dov Punski and myself to Boston for AppCamp.

Great initiative to get top minds in the User Acquisition space together to share tips and tricks on Ad Creatives, User Retention and Engagement and Reducing Churn.

It’s interesting to hear all the different strategies that are used in all kinds of apps, from Finance, to Gaming, to Social.

Dov was on a panel and shared some tips and tricks about how DogPack tripled their Instagram Follower count, and doubled our TikTok Followers in the last 7 days, leading to way more Organic Sign Ups on our app! | 68 | 4 | 1 | 4mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.603Z |  | 2025-08-07T19:24:59.773Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7355967118837747714 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHuxydvp7AK3A/feedshare-shrink_800/B4EZhWlHDEHEAw-/0/1753799227021?e=1766620800&v=beta&t=GAW_IFD-P-J-XsHMNvgEOw7tnOWjWdKwAIVrFX27Amw | Great food, drinks, and vibes at Noam restaurant in Montreal last night with DogPack’s Canada team.

The only one missing from this pic is Zaiaad Khan who’s cooking up something big in Toronto 🧑‍🍳.

We had a lot to celebrate, birthdays, milestones, new record highs, and being lucky enough to work together building something that we’re all passionate about.

To stay up to date with the most exciting things going on at DogPack be sure to subscribe to our newsletter which goes out the first Sunday each month.
Email aryeh@dogpackapp.com to follow along on our journey of making the world a better place for dogs and their owners. | 162 | 4 | 3 | 4mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.605Z |  | 2025-07-29T14:27:08.391Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7354121322500616193 | Text |  |  | It feels like I’m working 24.7.

Happy July 24th everyone 🙃 | 34 | 2 | 0 | 4mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.605Z |  | 2025-07-24T12:12:36.251Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7348796064956616705 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGM7v8hpP-DOw/feedshare-shrink_800/B4EZfwrEX9HgAw-/0/1752089513870?e=1766620800&v=beta&t=qUBTN6onrpZZymdW_9hW2Ou9o8lUGNXbHvgPN9_mGSE | All that Jackson Pollock did was splatter some paint on canvas. Rothko? He painted squares. Anyone could do that, yet a single work fetches tens of millions of dollars at auction. Crazy right?

If you believe anything about the above statement then you might also believe that all Software as a Service is on the path to extinction, because well, anyone could just Vibe Code up a whole app, website and offering in minutes! 🤡

(This is in no way bashing Vibe Coding, only those who fail to understand what those 2 words put together mean)

Problem is, the naysayers don’t build, or paint, and they can’t and won’t ever get started and most importantly, do it consistently.

AI is a great tool and like every tech org we’re using it to ASSIST our skilled SWE’s, not replace them. 

A great tech product can be built faster today, as has been true every year for the last 50 years, but like a painting it still needs to resonate significantly with the end viewer to be adopted widely and earn its place in history.

Creating a masterpiece takes a team of people that obsess over details, and ‘burn’ anything that doesn’t meet their exacting standards. The second and third rate art sells at garage sales for $10, or is left free on the curb.

All my love to the artists today that are showing up everyday to create beautiful products, that too many people are taking for granted. At DogPack®️ we’re keeping our heads down, ignoring all the noise and leading the Pack with the vision to be THE central Hub that will connect the growing $200B+ annual dog market in ways that no other platform can. | 32 | 1 | 1 | 4mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.607Z |  | 2025-07-09T19:31:55.914Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7347699583130517505 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH751lAlvDiOQ/feedshare-shrink_800/B4EZfhF0_LG4Ag-/0/1751828092284?e=1766620800&v=beta&t=x8a8z0S4xIJoXKlcugtsogsWwrX6Zp25Fd70MlgagfM | Everyone is talking about how their webpage traffic is getting fewer clicks from Google, but somehow, DogPack's organic traffic from Google is at an all-time high.

Our webmaster and blog writer Laurent noticed there was a gap in the market for high-quality breed images, started to load up our 700+ breed pages with beautiful imagery, and Google is rewarding us for it.

Search any of these breeds, and many more, and you'll see DogPack own the #1 spot, which gives us the largest picture, and shows our website as the Source. Great for our brand recognition, page and domain authority. We're doing a deep dive now to uncover more opportunities in the market for low competition and high traffic search terms. Classic SEO strategy.

With many companies throwing in the towel, abandoning their blogs, and complaining about AI taking all their traffic, we're doubling down on our SEO efforts. We believe that hard work is always rewarded - when paired with the correct strategy. | 76 | 8 | 3 | 5mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.608Z |  | 2025-07-06T18:54:54.275Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7346669831212920832 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABgBrZ2daanMQJ-egBdqUfzcNg.gif | A very warm welcome to Joel who joins us at this inflection point in our journey, and who will help bring DogPack to the next level and beyond.

Joel brings a wealth of experience with him from the tech space, and emphasizes the "People, Process, Product" framework for success. He also taught me that "Stand-Up" meetings actually need to be held, you guessed it, standing up. We're all very excited about what we'll accomplish together.

A special shoutout to someone I consider a friend, and mentor, wilson, who didn't let up, and guided me on the correct path, drawing on his vast experience in this space. | 35 | 2 | 0 | 5mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.608Z |  | 2025-07-03T22:43:02.286Z | https://www.linkedin.com/feed/update/urn:li:activity:7346573900467625986/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7342933854321537025 | Text |  |  | Tomorrow is a national holiday that you may have never heard of. 
St. Jean Baptiste. 

Right around the time when days are longest and temperatures are hottest, Quebec gets a well-deserved day of rest to celebrate our national heritage, and our special culture as the French speaking hub of North America.

Whether you were born here in ‘La Belle Province’, or decided to call this vast Province your home, tomorrow is an opportunity to express appreciation for our unique language, food, and joie de vivre, in this beautiful multicultural mosaic of people.

As is written on the back of every license plate on every pot-hole ridden road in this winter wonderland: ‘Je me Souviens’.

I remember. We collectively remember our past, and it helps us walk confidently into the future, as a united and proud people. I'm excited about the opportunities and growth that exist here in the place I proudly call home. | 32 | 1 | 0 | 5mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.609Z |  | 2025-06-23T15:17:35.984Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7338617216365473794 | Text |  |  | People often ask me what it’s like working with family every day - isn’t it tough? Actually, no! It’s the opposite. It’s our greatest advantage.

This may sound cliche, but everyone we work with and hire is like family to us. 

They must be fully trustworthy, unafraid to present their ideas or to challenge the status quo, and share our vision. (Quick tip for anyone applying anywhere: if you do land an interview, take 20–30 minutes to explore the app, website, or public company values. It shows, and it makes a big difference).

Working with family has been such a rewarding experience that I've done it again. Together with my wife, Janne, we opened up the Montreal Center for Logotherapy. She has the credentials and does all the work, and I support her vision and journey in any way that only someone close to you can.

While not everyone can work with family every day, we do have the power to stay close, stay connected. Reach out to someone you haven't spoken to in a while - even if you're the one who always makes the first move, it's worth it. | 48 | 1 | 0 | 5mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.610Z |  | 2025-06-11T17:24:49.296Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7336516606887424000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFW9nxR_wy0-w/feedshare-shrink_800/B4EZdCK.agGcAo-/0/1749161863690?e=1766620800&v=beta&t=Ucy2Jcu0lfjzByBmS5ct9x4wGVEUOLdSUWeCiMNTkqM | The DogPack team is looking forward to attend Superzoo, hosted by the World Pet Association (WPA) this August in Vegas!

With the new DogPack Marketplace expected to go live later this month, it should be perfect timing for our team to onboard the best pet products and brands that want an easy and risk-free avenue to sell D2C. With state of the art 2-way Product, Inventory, and Order sync happening between the Marketplace and the Shopify admin panel, a few clicks is all it will take for most sellers to be placed directly in front of their target audience.

If you're attending and want to chat with us before then and get a demo of our Marketplace, send me an email to jonathan@dogpackapp.com. | 42 | 2 | 1 | 6mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.611Z |  | 2025-06-05T22:17:44.969Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7333607219210412032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTi4_L0OnLyw/feedshare-shrink_800/B4EZcY05jLHcAg-/0/1748468210802?e=1766620800&v=beta&t=RedjPzrdBIvabhYsYAst0uP-nxLdgv6bPvzjHhXpAII | For whoever's been following, the last 5 years have seen a surge in available pet-related products, care, services, and foods, as pet adoption continue to climb (and for good reason!).

This new environment of easy accessibility to excellent pet products and services in almost every city worldwide has made becoming a pet-owner so much easier and more tempting to those that have never before owned a pet.

Luckily for those with a keen sense of fashion and a pile of extra cash, style concerns are no longer a roadblock to getting a pet as LV releases their new 2025 dog collection, which reaches it's peak with the gorgeous yet pricey 'Malle Chien ($40k USD)'.

What's the max limit that you would spend on your dog? Is it a percentage of your annual income, or are there some things you would never consider buying for your dog (a $1,500 Hermes leash for example) no matter how much of a budget you had?

Personally, I would max out on wellness spending, like insurance, food, vitamins, and vet visits, but forego the ultra-luxury products as I feel that's more something that people buy for their selves, and not their dogs.

Nevertheless, I would expect this ultra-luxury segment of the market to continue to grow for many years, as the humanization of pets continues to reach new heights. | 35 | 4 | 1 | 6mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.613Z |  | 2025-05-28T21:36:52.893Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7331704529400250368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0C6nJXeDEow/feedshare-shrink_800/B4EZb9yVJBHYAg-/0/1748014555693?e=1766620800&v=beta&t=RL7dS29gM5__gyzL1JtrrzSXaEtP3A_lSbhw2UQhY2o | The best part about Vegas? It wasn’t the parties, the food, or the perfect pool weather. It was the people. 
Ok, the parties were pretty epic too, thanks to many generous sponsors we were all able to go to see Martin Garrix, Hugel, Loud Luxury, Cirque du Soleil, for free. With open roof-top bars and too many overlapping happy hours to attend, the vibes were ✨immaculate✨

Being together with other founders, marketers, partners, suppliers, all in the same place for 3 days is just incredibly inspiring.

From those that just released their app yesterday with a pre-seed round of funding, to established companies that don’t need to raise anymore and are still growing fast, everyone I spoke with had something interesting to say and something that I learnt from. We look forward to being back in-office next week and implementing many of our new skills, tips and tricks which were also spilled at the plethora of 20-minute panels led by industry experts. Dov Punski Serach Smith Hitesh Dhingra. 

Fun fact: did you know that the CEO OF Snap Inc. is the biggest supporter of in-office work and works alongside his employees every day Monday to Friday? 

Lucky as we are at DogPack to be a team of 4 brothers and ultra dedicated teammates in Montreal, India, and Toronto, we were able to be here and not miss a beat. 

No matter what industry you’re in, I would highly recommend that you look up the biggest conferences in your sphere and start to attend them. If you think that there’s no need because you already know everything about your space, then go to share your knowledge, and you’ll be surprised at what you get back.

Thanks again to MAU Vegas and all the incredible sponsors for making this happen! Til next year friends 🫶 | 67 | 4 | 1 | 6mo | Post | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/jonathanpunski | 2025-12-08T06:06:34.613Z |  | 2025-05-23T15:36:16.292Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7347700081887703041 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH751lAlvDiOQ/feedshare-shrink_800/B4EZfhF0_LG4Ag-/0/1751828092284?e=1766620800&v=beta&t=x8a8z0S4xIJoXKlcugtsogsWwrX6Zp25Fd70MlgagfM | Everyone is talking about how their webpage traffic is getting fewer clicks from Google, but somehow, DogPack's organic traffic from Google is at an all-time high.

Our webmaster and blog writer Laurent noticed there was a gap in the market for high-quality breed images, started to load up our 700+ breed pages with beautiful imagery, and Google is rewarding us for it.

Search any of these breeds, and many more, and you'll see DogPack own the #1 spot, which gives us the largest picture, and shows our website as the Source. Great for our brand recognition, page and domain authority. We're doing a deep dive now to uncover more opportunities in the market for low competition and high traffic search terms. Classic SEO strategy.

With many companies throwing in the towel, abandoning their blogs, and complaining about AI taking all their traffic, we're doubling down on our SEO efforts. We believe that hard work is always rewarded - when paired with the correct strategy. | 76 | 8 | 3 | 5mo | Dov Punski reposted this | Jonathan Punski | https://www.linkedin.com/in/jonathanpunski | https://linkedin.com/in/dov-punski | 2025-12-08T06:14:03.595Z |  | 2025-07-06T18:56:53.188Z |  |  | 

---



---

# Jonathan Punski
*DogPack*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [How DogPack's Talking Dog Podcast Took Over the Internet](https://www.dogpackapp.com/blog/dogpack-talking-dog-podcast/)
*2025-10-30*
- Category: podcast

### [A Q&A with DogPack App’s Dov Punski: Minding your business](https://www.thesuburban.com/business/a-q-a-with-dogpack-app-s-dov-punski-minding-your-business/article_f8be30fa-d795-11ef-be7e-1358736b784b.html)
*2025-01-22*
- Category: article

### [AI dog podcasters are making a splash in Hollywood](https://www.businessinsider.com/ai-dog-podcasters-dogpack-sign-with-talent-giant-wme-2025-10)
*2025-10-30*
- Category: podcast

### [How DogPack added 600K followers in just 10 days](https://www.woofnews.co/p/how-dogpack-added-600k-followers-in-just-10-days)
*2025-08-27*
- Category: article

### [DogPack | LinkedIn](https://ca.linkedin.com/company/dogpackapp)
*2025-04-18*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[How DogPack added 600K followers in just 10 days](https://www.woofnews.co/p/how-dogpack-added-600k-followers-in-just-10-days)**
  - Source: woofnews.co
  - *Aug 27, 2025 ... As for how many of those have converted to app downloads, we're unsure but the CEO of DogPack, Jonathan Punski, has mentioned seeing ...*

- **[How DogPack's Talking Dog Podcast Took Over the Internet](https://www.dogpackapp.com/blog/dogpack-talking-dog-podcast/)**
  - Source: dogpackapp.com
  - *Oct 30, 2025 ... DogPack's talking dog podcast, starring Goldie and Frenchie, went ... As Jonathan Punski, DogPack's CEO, put it: “Today we're creatin...*

- **[DogPack Marketplace: Shop Dog and Pet Products in One Place](https://www.dogpackapp.com/blog/dogpack-marketplace-shop-dog-products/)**
  - Source: dogpackapp.com
  - *Sep 18, 2025 ... Jonathan Punski is the CEO and Founder of DogPack, the platform he ... DogPack's Talking Dog Podcast Goes Global: From Viral Laughs t...*

- **[Social media for dogs? The DogPack app is uniting furry, four ...](https://region.com.au/social-media-for-dogs-the-dogpack-app-is-uniting-furry-four-legged-friends-in-canberra/607957/)**
  - Source: region.com.au
  - *Nov 5, 2022 ... Jonathan Punski and Jazz. Photo: Jonatahan Punski. The owner of Bear, a four-and-a-half-year-old Belgian Shepherd, Dov said the DogPac...*

- **[As AI Takes Over Social Media, Are Dog Podcasters the Future ...](https://www.bloomberg.com/news/articles/2025-09-15/as-ai-takes-over-social-media-are-dog-podcasters-the-future)**
  - Source: bloomberg.com
  - *Sep 15, 2025 ... Jonathan Punski is the oldest of four brothers in Montreal who run a social networking company for pet owners called DogPack. This pa...*

- **[How these 4 brothers built a thriving company! - YouTube](https://www.youtube.com/watch?v=g4Dla97Yh38)**
  - Source: youtube.com
  - *Oct 23, 2025 ... Jonathan Punski is the Co-Founder & CEO of DogPack Dov Punski is the ... Jon Gray - President of Blackstone | Podcast | In Good Compa...*

- **[DogPack: Dog Parks & Services - Crunchbase Company Profile ...](https://www.crunchbase.com/organization/dogpack)**
  - Source: crunchbase.com
  - *Founders Aryeh Punski, Dov Punski, Eric Punski, Jonathan Punski ... January 11, 2022: Global News Interview: https://globalnews.ca/video/8502695/dogpa...*

- **[DogPack App - Overview, News & Similar companies | ZoomInfo.com](https://www.zoominfo.com/c/dogpack-app-inc/1316835332)**
  - Source: zoominfo.com
  - *DogPack App's CEO is Jonathan Punski Who is the CFO of DogPack App? DogPack ... Engineering Blog · Privacy Center. Free Trial. Log In · 866.904.9666. ...*

---

*Generated by Founder Scraper*
