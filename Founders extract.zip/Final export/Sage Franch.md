# Sage Franch

## Position actuelle

**Titre** : Founder & Executive Director
**Entreprise** : Compliance Leaders for AI Responsibility (CLAIR)
**Durée dans le rôle** : 4 months in role
**Durée dans l'entreprise** : 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Non-profit Organizations

## Description du rôle

Founded CLAIR to bring together senior compliance, risk, and legal leaders to solve the urgent challenges of AI governance. CLAIR is a private space for sharing peer-tested insights and developing the practical frameworks needed to navigate the intersection of AI and compliance. 

Interested in joining our next off-the-record roundtable on AI governance? Request an invite at joinclair.com

## Résumé

TL;DR - I partner with compliance leaders to give them superpowers with AI that works for them, and help them navigate AI governance.

I've always been fascinated by the intersection of technology and human behavior. That fascination took me to Microsoft, where I spent years on the front lines of emerging tech, building 3D spatial applications for Kinect and HoloLens and, later, leading the development of an AI app for athletes with disabilities to find the resources and support to help them thrive in their sport.

Today, my focus has a new urgency. As the Co-founder & CEO of Rulebook.ai, I'm tackling one of the biggest challenges for modern businesses: navigating a chaotic, fast-changing regulatory landscape. We provide teams with the intelligence they need to act with confidence and use compliance to accelerate growth.

But a new crisis is emerging, one I heard about countless times in hundreds of conversations with leaders over the last year. Compliance teams are being asked to govern AI, a technology evolving faster than anyone can keep up. They're building the plane while flying it, and there are gaps popping up everywhere.

That’s why I started CLAIR (Compliance Leaders for AI Responsibility). We are a private, not-for-profit group where leaders share what's working, build best practices, and create the AI governance playbook together. If you're passionate about advancing AI governance, apply to join us at joinclair.com.

My background at a glance:

10+ Years in Enterprise Tech: Building software that blends behavioral science, artificial intelligence, and human-centric design.

Microsoft Alum: Specialized in AI and emerging technologies.
--🤖 Pioneered mixed reality applications for Kinect and HoloLens.
--🏆 Led development of an AI app to connect athletes with the right facilities and resources.

Published Researcher: Co-authored a paper with the University of Waterloo on using Mixed Reality headsets as teaching aids (2017).

When I’m not focused on AI, I serve as a board member for non-profits, with a focus on ESG in education and the environment.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABHxpaIBfkFnZ1Sz7Ktkutu_uqJFgJmYHyw/
**Connexions partagées** : 64


---

# Sage Franch

## Position actuelle

**Entreprise** : Rulebook

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Sage Franch

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402737285001076737 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQH5Gxt3brahXA/feedshare-shrink_800/B56ZrvOVDcLAAg-/0/1764950103263?e=1766620800&v=beta&t=uzdmmRhMqZUfNBu8fXNgU0TPOP4rHKJt1IBpIAt9P5g | "It's no longer about what machines can do, but what we should let them do."

Machine intelligence is now evolving faster than we can keep pace with, and someone needs to put guardrails in place - but how can we govern what we don't understand?

This was the core theme of yesterday's AI Governance Summit. At Compliance Leaders for AI Responsibility (CLAIR) we brought the community together to bring clarity to AI and discuss practical ways to uncover, understand, and mitigate risk in the age of AI. 

We heard from:
Ray Eitel-Porter, on how to frame AI governance and get executive buy-in to lead this conversation at the top level
Thomas Fox, on the importance of community and knowledge sharing -- now is the time to break down the silos!
Pat Poitevin, on the emerging cyber threats that AI is amplifying and how being a better user of AI can lead to better results
Dr. Camille Howard, on the specific frameworks we can use to govern AI use and recognize the moments where further change is needed
Kirsten Liston and Jamie McKillop on the best practices for developing AI policies and training plans that keep up with change and inspire critical thinking. 

Thank you to everyone who joined us for this important conversation. As I shared in my closing remarks, AI is here to stay and the pace of change is only going to increase. The best way to stay on top of all of this is to share with each other. I'm thrilled that the Compliance Leaders for AI Responsibility (CLAIR) community has grown to over a thousand in just a few short months - safe to say this summit won't be our last. Be sure to follow our LinkedIn page and subscribe to our newsletter for upcoming announcements about our next events.

Finally, thank you again to our great partners who made this event possible. Rethink Compliance, Humanistic Power Group, Active Compliance and Ethics Group, GAN Integrity, and Rulebook. | 25 | 8 | 4 | 2d | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:33.759Z |  | 2025-12-05T15:55:04.952Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401674748046299136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEH4n6S1NMY4Q/feedshare-shrink_2048_1536/B4EZrgCUMKKYAw-/0/1764695295447?e=1766620800&v=beta&t=IiqbURaBXf3heXLtq3HBdGecPJMkmjx9-MVc6AiG8gg | When I met Kate Rood and got to talking about AI, her journey as a student, and her aspirations in tech entrepreneurship, I knew she was someone special. I'm beyond excited to partner with her on our new project, SprintApply, an AI platform to bring the fun back to job applications.

The job search has changed and it's not enough to "be yourself". You also have to pass the ATS and jump through hoops to get the interview. That's what SprintApply is for - we make it easy to customize your materials for each job you apply to, while staying true to yourself! 

This is AI that works for you, and helps you put your best foot forward. We'd love for you to give it a try and follow our page at SprintApply - we'll be posting new content and highlighting some of our top candidates too!

#jobseekers #jobsearch #opentowork #hiring | 8 | 2 | 2 | 5d | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:33.761Z |  | 2025-12-02T17:32:56.401Z | https://www.linkedin.com/feed/update/urn:li:activity:7401668541340606465/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401297078766706688 | Article |  |  | T-minus 4 days till our AI summit! And timing couldn't be better with the recent AI updates and the year end approaching. 

We'll be talking about AI risk and predictions for 2026 and helping you set up your organization to navigate AI effectively in the new year and beyond. Our speakers come equipped with real-world examples and tangible resources that you can put into action before the holidays to get a head start on the new year. 

I've seen a lot of our community register already - can't wait to see you there! If you're still wanting to join, you can register at joinclair.com/summit or send me a note. 

Shoutout to our fantastic lineup Ray Eitel-Porter Dr. Camille Howard, CCEP-US, CCEP-I, CIPP/US Thomas Fox Pat Poitevin, CACM, TASA Kirsten Liston Jamie McKillop and our partners GAN Integrity Rethink Compliance Rulebook Humanistic Power Group and ACEG! #AI #AIGovernance #ResponsibleAI | 17 | 0 | 0 | 6d | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:33.761Z |  | 2025-12-01T16:32:13.028Z | http://joinclair.com/summit |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394417321542356994 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHIKjRr0Ack1g/feedshare-shrink_2048_1536/B4EZp34QsxHcAw-/0/1762947828995?e=1766620800&v=beta&t=kGlw4n4M3OE0HgiOBH9j6mSe61x2zqMSkALBE2y7V1s | Last night, I had the honor of delivering a guest lecture at Compliance & Ethics at Fordham Law, on the topic of AI in compliance and how it impacts training.

Together we explored 3 questions: 

1/ What opportunities does AI present for compliance?
2/ How can we use AI to do more with less?
3/ How can we future-proof ourselves and our organizations?

KEY TAKEAWAYS:

A) When done right, AI presents an opportunity compliance has never had before: to move fast without compromising accuracy. I showed the students a few different ways to use AI in their work, including a demo of Rulebook's own AI agents for compliance. 

B) AI presents certain risks, but the biggest issue is not the tech - it's how we use it. We discussed the different and sometimes unexpected sources of vulnerability in the age where everyone (your employees, vendors, leadership, heck even the dog) all use AI. 

C) Not all AI is created equal. We talked about foundation models, free vs paid versions, and how to pick the best tool for the job, including how to tell the difference between the AI-native solutions and the legacy platforms that bolt on AI to remain relevant.

D) The key to future-proofing our organizations is AI Fluency. We have to move beyond AI literacy (understanding risks and opportunities) to AI fluency (using that knowledge to target desired outcomes and being able to recognize when tools deviate from expected behavior). 

If you're not already pushing AI literacy at your organization, you need to start that today. This is a new and rapidly evolving frontier. Whether we as individuals are using AI or not, we can't sit in stasis while the tech races ahead and other business functions adopt it at lightning pace. 

Thank you Barbara-Ann Boehler at Fordham University School of Law for inviting me to speak to your students and thank you to everyone who attended for the lively discussion! 

#AIGovernance #Compliance #RiskManagement #AI #Leadership #ResponsibleAI #AILiteracy | 22 | 0 | 0 | 3w | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.939Z |  | 2025-11-12T16:54:31.086Z | https://www.linkedin.com/feed/update/urn:li:activity:7394339134573580288/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7393672882696081408 | Document |  |  | "I have a lot to say, but we have an AI committee and I'm not on it."

I've heard this from countless compliance leaders this year. Some even trying to find creative ways to get a seat at the AI meetings because they weren't invited. Seems wrong, doesn't it? 

In my view, this is symptomatic of a few things:

1) Compliance is viewed as the "police"
When compliance is viewed as "the office of no", the rest of the business may avoid inviting them to AI governance discussions for fear of them shutting it down. 

2) Too many cooks in the kitchen, and no head chef
When everyone feels they should have a say but no one is the designated leader, they may rush to create a committee without considering all the stakeholders who should be consulted.

3) A lack of AI literacy / understanding of AI risk
It's easy to get caught up in the opportunities AI presents, without fully understanding the risks. A good AI literacy initiative should dive deep into both - you can't get the maximum benefit from AI unless you know what to do and what to avoid.

Today I came across this graph from Stanford Institute for Human-Centered Artificial Intelligence (HAI)'s 2025 AI Index Report, showing which business function is assigned responsibility for AI governance. Thought it was interesting and thought-provoking.

How do you think this will change in the coming year? | 22 | 8 | 1 | 3w | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.940Z |  | 2025-11-10T15:36:23.034Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7392188605089079297 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHrIPR4incgrA/image-shrink_800/B4EZpZUSNBKMAg-/0/1762435083284?e=1765782000&v=beta&t=7DqGwxMJr7qzGgKUxDBVx8UqCjW7DW1IJoSfATlV1Gw | Tomorrow I'm convening a private compliance leaders roundtable to talk about a pressing challenge: 

Uncovering and mitigating the risks of shadow AI.

What does shadow AI look like? It's everything from bringing your own unapproved AI tools to using ChatGPT on your phone because it's blocked on your work computer. 

Whether you know about it or not, people in your organization are using AI.  It could be It's not necessarily a bad thing - when used right, AI can help us accomplish things faster and make more informed decisions. But when used wrong, things can go really wrong. AI presents many new risks, and compliance teams are on the hook for protecting our organizations as the technology advances quicker day by day.

That's why I bring together compliance leaders on the first Friday of every month to talk about AI governance. 

What started as informal conversations has quickly snowballed into a community of compliance leaders 800-strong. This roundtable will be our third official one, and it's beyond oversubscribed. 

Compliance Leaders for AI Responsibility (CLAIR) is a non-profit organization dedicated to helping compliance professionals navigate AI. Our private forum and roundtables are free to join for anyone working in governance, risk, and compliance roles. | 22 | 6 | 0 | 1mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.940Z |  | 2025-11-06T13:18:23.676Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7391558055169044480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGLq29iGLcR3A/feedshare-shrink_800/B4EZpKDLZ8KcAo-/0/1762178940926?e=1766620800&v=beta&t=4aP7ttoGwdcGplxs38UDUSkmkDiSM5drGLDOwAFRHZQ | I've had the pleasure of getting to know Dr. Camille Howard, CCEP-US, CCEP-I, CIPP/US over the last few months as we've collaborated on AI governance projects.

Dr. Howard's unique combination of deep HR and compliance expertise with her technology acumen is exactly what compliance leaders need - it's not enough to be aware of AI, you have to know how these ideas apply to the compliance context. 

Excited for this session at our summit, one month from today! 

#AI #AIcompliance #AIgovernance #CLAIRSummit | 17 | 2 | 2 | 1mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.941Z |  | 2025-11-04T19:32:48.860Z | https://www.linkedin.com/feed/update/urn:li:activity:7391114184853229568/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7389628406692323328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGf2Vu-rNufFQ/feedshare-shrink_800/B4EZo03taJKcAg-/0/1761823619983?e=1766620800&v=beta&t=vxpv0iGzOV4JMxvl1vKtBLuH_XXo5LVIxwZbl2ZCTwc | Every time I talk to a compliance leader, the conversation turns to AI. 🧠 

There are more questions than answers. "What do all these terms mean?" "How do we enforce our AI use policy?" "People are using generative AI to do *what*?  It's hard to put guardrails on something that is changing faster than we can learn about it.

I'm very excited to announce that we at Compliance Leaders for AI Responsibility (CLAIR) are hosting our AI Governance Summit on December 4th - a half-day virtual event focused on *action*. 

We're bringing together an amazing group of AI and compliance experts who are at the forefront of AI governance, and they will be leading hands-on workshops to help you develop the policies, training plans, and frameworks to govern AI in your organization. You will leave with real assets you can use to implement your governance strategy immediately. 

I'm so grateful to our speakers Dr. Camille Howard, CCEP-US, CCEP-I, CIPP/US, Pat Poitevin, CACM, TASA, Kirsten Liston, Andrea Falcione, JD, CCEP, and Ray Eitel-Porter for their expertise, and to our partners Rethink Compliance, Rulebook, Humanistic Power Group, ACEG, and GAN Integrity for supporting this important mission. 

The time for simply talking about AI is over. It's time to put idea into action. 

Join us December 4th and make a real step forward in your AI governance plan.

Link to register: joinclair .com / summit 

#CLAIRSummit #AIGovernance #ResponsibleAI #Compliance #RiskManagement | 48 | 9 | 9 | 1mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.942Z |  | 2025-10-30T11:45:04.812Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7386515106618322944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9Lmv9FVoHiA/feedshare-shrink_800/B4EZoIrbRTIwAg-/0/1761082193577?e=1766620800&v=beta&t=9ohOPGy9TNkZniCyaUJSSJllqWVJSKXasHdr81NE4uk | Didn't get a seat at the last CLAIR AI governance roundtable? We've opened up spots for our November 7th session, where we'll be digging deeper into real AI governance strategies. Send me a message if you're interested. | 13 | 0 | 1 | 1mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.943Z |  | 2025-10-21T21:33:56.232Z | https://www.linkedin.com/feed/update/urn:li:activity:7386514093987430400/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7381490017183121408 | Text |  |  | In our AI Literacy roundtable last week, we got deep into the idea of AI literacy as a new core competency. If you're still thinking of machine intelligence as a sci-fi trope, you're missing out on the biggest paradigm shift since dot com. It's already happening, and not learning how to use AI will soon be equivalent to not knowing how to email.

As compliance leaders scramble to keep up with AI use in their organizations, they must aim for AI literacy at a minimum and, ideally, AI fluency.

🧠 AI Literacy is about knowing what AI does, and the risks and implications of different implementations
🧠 AI Fluency is about knowing how to use that knowledge to your advantage

At Compliance Leaders for AI Responsibility (CLAIR) we've developed a framework that compliance and governance leaders can use to develop AI literacy and AI fluency, both on an individual level and as an organization. It takes into account the unique needs of different stakeholder groups and uses a multi-layered approach to ensuring you develop the right skills in the right places to set your organization up for AI adoption. We will be publishing the framework soon - follow our LinkedIn page and send me a note, and I'll send you the link.

#CLAIRcommunity #Compliance #AIgovernance #AIliteracy #AIfluency | 28 | 2 | 1 | 2mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.943Z |  | 2025-10-08T00:46:01.549Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7379868302388535296 | Video (LinkedIn Source) | blob:https://www.linkedin.com/eddc461e-6ead-4c44-a44e-ad57b47f7eb3 | https://media.licdn.com/dms/image/v2/D4D05AQGBTie4hR7RYQ/videocover-high/B4DZmlvQXVJcCA-/0/1759422274192?e=1765782000&v=beta&t=hYtGrApI9U9HF0RDYz29n72AUZpIvWvxjlYjeaAU-bg | Compliance protects vulnerable populations: when promoting financial products such as credit cards, savings accounts, and crypto, marketers have a responsibility to clearly and honestly present the offerings. But too often, people are unaware of the rules. The recent rise of finfluencers has led to even less responsible promotion of financial products - but it doesn't have to be this way. 

Earlier this year, I sat down with James Erskine of ROCKET, an award-winning youth marketing agency, to discuss the rise of finfluencers, the financial promotions compliance regime in the UK, and how we are helping businesses automate finprom compliance with PromoComply AI, leading to better outcomes for both businesses and consumers - including faster time to market for new campaigns and more responsible marketing. Give it a listen at the link below and share your thoughts. | 14 | 0 | 3 | 2mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.944Z |  | 2025-10-03T13:21:54.612Z | https://www.linkedin.com/feed/update/urn:li:activity:7379825097295097856/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7377402535021817856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEcjSMzOGQTmw/feedshare-shrink_800/B4EZmHMgveHIAg-/0/1758909828596?e=1766620800&v=beta&t=OcAsqXJFMX332LdgQd5g78mXlLMoIzJPy6fgF4Mw8x8 | Next Friday, October 3rd, we're convening a closed-door session at Compliance Leaders for AI Responsibility (CLAIR) for an action-oriented conversation on AI Literacy.

The gap between how fast our teams are adopting AI and how well they understand its risks is the biggest blind spot in most organizations today. An AI Acceptable Use Policy is meaningless without a culture of literacy to support it.

Like all CLAIR roundtables, this won't be a webinar and it won't be recorded. It's an off-the-record, peer-to-peer roundtable where we will workshop practical strategies for building literacy at every level of an organization, from the front line to the boardroom.

Participation is for CLAIR members, but I'm holding a few spots for senior leaders in compliance, risk, or legal who are serious about solving this challenge. If you'd like to request an invite, send me a direct message.

#AIGovernance #AILiteracy #Compliance #RiskManagement #Leadership #Roundtable | 24 | 0 | 4 | 2mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.945Z |  | 2025-09-26T18:03:49.860Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7368625011072331777 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGXo1IYQ55rug/feedshare-shrink_800/B4EZkIwpZQIMAo-/0/1756788595955?e=1766620800&v=beta&t=Cqv-DD_RK_WGsCekO2wKQ2LED3wZosy8FkANgjy49bo | Talking about AI governance is easy. Practicing it? Not so much.

Today we are officially opening the doors of the Compliance Leaders for AI Responsibility (CLAIR) private forum! My team and I have built a toolkit of four practical, defensible resources designed to give you a head start on AI governance and take you from theory to action. 

I'm incredibly proud to share the CLAIR Founding Member Toolkit:
📝 An AUP Starter Kit to build your internal AI policy.
📈 An AI Risk Assessment Framework to identify and prioritize threats.
✅ An AI Vendor Due Diligence Questionnaire to vet new tools.
📊 An AI Governance Maturity Model to benchmark your program.

CLAIR members have access to these resources and more now in our private forum. 

If you're a leader who is done talking and ready to build, apply to join the conversation at joinclair.com.

#AIGovernance #Compliance #RiskManagement #Leadership #CLAIRcommunity | 22 | 0 | 4 | 3mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.946Z |  | 2025-09-02T12:45:05.072Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7363222080881860608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEHe7mqTYQbqQ/feedshare-shrink_800/B4EZi4vFgwGoAg-/0/1755446009975?e=1766620800&v=beta&t=makbVM0BS7oi0qOC0LQ5yHmdFci7Xj-FEpKEzDGxEVw | 📣 Over the last few months, I've had countless off-the-record conversations with compliance and risk leaders on the subject of AI governance.

The consensus is clear, the speed of AI evolution is creating a MASSIVE gap, and every leader is facing the same urgent challenge: how do we build the playbook for an AI-first world while we're already playing the game?

It's a problem too big and too fast to solve in a silo. That's why I'm incredibly excited to announce that we are taking these discussions further with a new community, Compliance Leaders for AI Responsibility (CLAIR).

I soft-launched CLAIR 4 days ago and have already had more than 60 people request access. In the coming weeks, we'll be opening the doors to our private forum and a series of limited capacity members-only roundtables.

We're here to cut through the AI fear-mongering and create a non-partisan, vendor-neutral forum for leaders to ask questions, swap notes, and share what's actually working in their organizations. This is about demystifying the technology and building defensible, practical strategies, together. To request access, visit our website at the link below.

So thrilled by the immediate response and excited to build this with all of you.

#AIgovernance #compliance #AI #CLAIRCommunity | 14 | 4 | 2 | 3mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.948Z |  | 2025-08-18T14:55:46.133Z | https://www.linkedin.com/feed/update/urn:li:activity:7362874227361808384/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7361745782061867008 | Text |  |  | Ready to break into AI sales?  I'm looking for two ambitious students to join my team at Rulebook.ai and be part of growing our global footprint.

At Rulebook.ai, we support some of the world's largest organizations in navigating regulatory compliance and powering ethics and compliance programs that really work. This is an opportunity to get directly involved in work that matters, while:
🧠  Learning the ins-and-outs of B2B SaaS sales
🤝  Working directly with compliance leaders in North America and beyond
💡  Gaining hands-on experience working with AI

I'm looking for individuals who are sharp, driven, and resilient. This role is remote-first, but will involve onsite team days, so we are looking for candidates based in the Greater Montreal Area. That said, this is a sales role - if you can convince us "why you", you may not need to meet every qualification.

If you are a student ready to do meaningful work and accelerate your career, I want to hear from you! To my network: If you know an exceptional student who would thrive in this environment, please share this opportunity with them. | 18 | 0 | 6 | 3mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.948Z |  | 2025-08-14T13:09:29.066Z |  | https://www.linkedin.com/jobs/view/4285644308/ | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7308168238389972992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE0S1-muqzndg/feedshare-shrink_800/B4EZWrQfjCHMAg-/0/1742334983444?e=1766620800&v=beta&t=0vC83fyOT08jtIVFkUMAQ-fJ8Sexxq485UIhRdosYxo | The regulators are using AI for finprom compliance, why aren't you? 🤔 

I had an energizing chat with George Aliferis, CAIA from Investology: re-think investment management at Finovate in London to discuss the future of finprom compliance, the current regulatory landscape, and the right way to advertise with finfluencers. The FCA is serious about financial promotions - just look at those numbers below! 😱 

✅ PromoComply's regulatory intelligence AI automates finprom compliance so you can build trust and reach your audience faster. 

Watch the full conversation below! 👀 

#finprom #financialpromotions #compliance #regtech #artificialintelligence #finfluencer | 25 | 4 | 2 | 8mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.949Z |  | 2025-03-19T16:51:27.232Z | https://www.linkedin.com/feed/update/urn:li:activity:7308042075906723841/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7305180708346474497 | Article |  |  | Proud to be highlighted in this list of five #WomeninFintech in honor of this Women's History Month. 🌐 I love seeing the transformative innovations that women are bringing forward in AI and finance - shoutout to Catherine Kurt, Jackie (Jac) Dunne, Tatiana Botskina, and Moyi Dang, whose work is also featured here, and thank you Finovate for bringing us together.

I'm also proud to have represented Québec on the global stage in London at Finovate Europe 2025 - and grateful to live and work in a province which supports entrepreneurship and fosters global growth for Canadian businesses.

Thank you to all the folks who came together to make this happen, including Heather Stowell, Greg Palmer, David Penn, Madeline Clines, Christian Hissibini, Latham French, Isabelle Botfield, Rémy Rouillard, PhD, Québec Government Office in London

https://lnkd.in/e72f-ZaX | 54 | 17 | 1 | 8mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.951Z |  | 2025-03-11T11:00:04.564Z | https://finovate.com/ladies-first-celebrating-the-women-of-finovateeurope-2025/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7300886167296565249 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEfYEoEdJi9ww/feedshare-shrink_800/B4EZVH1RpRGYAg-/0/1740666904456?e=1766620800&v=beta&t=UxhrOnuvPPPZ1QiK6pNx3IQvpUWFP-gtW08lRqFnT70 | What a beautiful week opening our new office in London! 🇬🇧 ✨

Christian and I are excited to expand our operations to London, UK. This week we introduced PromoComply to the UK market, celebrating our launch here at Finovate, and marking another milestone on our mission to power innovation in compliance.

Thank you to all the wonderful #fintech and #finance folks who came out to talk with us about financial promotions compliance - a matter that is of top priority for every organization advertising financial products in the UK. | 95 | 32 | 3 | 9mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.952Z |  | 2025-02-27T14:35:06.189Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7272357086942969856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHLxPjpQjIsWw/feedshare-shrink_800/feedshare-shrink_800/0/1733505876132?e=1766620800&v=beta&t=I4cSgcOUCfijm6MrekK8uDqNnZvEyf1tIJM9DfHXpGY | 🗓️ 💡 This Thursday, join me and Kirsten Liston for a deep dive into how AI is transforming compliance programs. We'll be showing some exciting demos of how Rulebook and Rethink Compliance are using AI to power innovation in compliance - join us at 11am ET to see it in action and participate in the discussion!

🎒 Oh, and did I mention you can earn up to 1.2 Live CCB CEUs? Don't miss it! Register here: https://lnkd.in/e9z7Uxj5 | 14 | 0 | 1 | 11mo | Post | Sage Franch | https://www.linkedin.com/in/sagefranch | https://linkedin.com/in/sagefranch | 2025-12-08T06:02:37.953Z |  | 2024-12-10T21:10:43.388Z | https://www.linkedin.com/feed/update/urn:li:activity:7270850633216229379/ |  | 

---



---

# Sage Franch
*Rulebook*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Compliance and AI: Navigating Compliance with AI – Sage Franch and Scott McCleskey on RuleBook AI](https://compliancepodcastnetwork.net/compliance-and-ai-navigating-compliance-with-ai-sage-franch-and-scott-mccleskey-on-rulebook-ai/)
*2024-10-11*
- Category: podcast

### [Work Minus Unconscious Bias with Sage Franch | The Digital Workplace](https://thedigitalworkplace.com/podcasts/sage-franch/)
*2021-05-19*
- Category: podcast

### [Interviews with leading business and IT experts](https://stephenibaraki.com/cips/v0315/sage_franch.html)
*2015-02-01*
- Category: article

### [Featured Speaker Interview: Sage Franch](https://fitc.ca/article/featured-speaker-interview-sage-franch/)
*2018-04-05*
- Category: article

### [Sage Franch (she/her) – Medium](https://medium.com/@thetrendytechie?source=post_page-----5d378fba933f--------------------------------)
*2024-06-18*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Newsroom | Rulebook AI](https://www.rulebook.ai/newsroom)**
  - Source: rulebook.ai
  - *Podcast: Rulebook's Sage Franch and Scott McCleskey discuss AI in Compliance with Tom Fox. Rulebook's Sage Franch and Scott McCleskey sit down with To...*

- **[Compliance and AI: Navigating Compliance with AI – Sage Franch ...](https://www.youtube.com/watch?v=DjSF8kNOCyk)**
  - Source: youtube.com
  - *Oct 11, 2024 ... ... Podcast Network at: LinkedIn: https ... Compliance and AI: Navigating Compliance with AI – Sage Franch and Scott McCleskey on Rul...*

- **[AI Governance Summit 2025 | CLAIR](https://www.joinclair.com/ai-governance-summit-2025)**
  - Source: joinclair.com
  - *Sage Franch, Executive Director of CLAIR AI Governance Association, CEO of Rulebook AI ... Founder of Compliance Podcast Network. ABOUT CLAIR. Your Pr...*

---

*Generated by Founder Scraper*
