# Arthur Ouaknine

## Position actuelle

**Titre** : Co-founder and CTO
**Entreprise** : Rubisco AI
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Data Infrastructure and Analytics

## Description du rôle

Our mission is to develop a transparent, robust and scalable tool for impactful forest monitoring—bringing new insights to forest conservation and management through advanced AI.

## Résumé

I am a postdoctoral researcher fellow at McGill University and Mila (Quebec Artificial Intelligence Institute), supervised by David Rolnick. My research projects are focused on multimodal and multitask deep learning applied to forest monitoring. I’m also a core team member of Climate Change AI leading the webinars team.

I completed my Ph.D. in March 2022 in collaboration between Institut Polytechnique de Paris (Telecom Paris; Image, Data and Signal department) and Valeo.ai (international research center in artificial intelligence applied to autonomous driving). The aim of my work was to use and adapt deep neural network architectures for scene understanding using automotive radar data and multi-sensor fusion.

For more information, please visit my personal webpage: https://arthurouaknine.github.io/

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABZNItEB3EM1gYDlFdFLZKKvaa6xYiotyTk/
**Connexions partagées** : 6


---

# Arthur Ouaknine

## Position actuelle

**Entreprise** : Rubisco AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Arthur Ouaknine

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391444179681329152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFflIQH2DKGhA/feedshare-shrink_800/B4EZpLS0ZBKkAg-/0/1762199817211?e=1766620800&v=beta&t=w0e4w_EJXbaYtZgvKh_jrpUwoBLY1zy4pVx_1Of1oGA | 🎉 Proud to announce that our team got 2 papers accepted at #NeurIPS2025, on individual tree crown segmentation and vegetation trait prediction.

Huge thanks to all our collaborators who worked hard on these topics, to bring cutting-edge computer vision and machine learning methods for better analysis and understanding of forests and vegetation cover worldwide.

🌲 Bringing SAM to new heights: Leveraging elevation data for tree crown segmentation from drone imagery. (Main Track)
🌎 Led by Mélisande Teng, with myself, Etienne Laliberté, Yoshua Bengio, David Rolnick and Hugo Larochelle. 
📖 https://lnkd.in/eggBFW6A 
🔍 TL;DR: We compared the Segment Anything Model (SAM) for automatically detecting individual tree crowns in drone imagery across different forest types, finding that our novel BalSAM approach—which integrates elevation data—shows promise especially for plantations, though modular fine-tuning SAM is necessary to outperform traditional methods.
📍San Diego, Wed 3 Dec 4:30 p.m. PST — 7:30 p.m. PST.
---

🛰️ GreenHyperSpectra: A multi-source hyperspectral dataset for global vegetation trait prediction. (Datasets & Benchmarks Track)
🌎 Led by Eya Cherif, with myself, Luke A. Brown, Phuong D. Dao, Kyle R. Kovach, Bing Lu, Daniel Mederer, Hannes Feilhauer, Teja Kattenborn and David Rolnick. 
📖 https://lnkd.in/eDuiT3py 
🔍 TL;DR: We introduced GreenHyperSpectra, a pretraining dataset for hyperspectral remote sensing that enables label-efficient machine learning models to predict vegetation traits like leaf carbon content across different sensors and ecosystems, outperforming traditional supervised methods.
📍San Diego, Thu 4 Dec 4:30 p.m. PST — 7:30 p.m. PST.
---

Feel free to reach us out and let's meet at NeurIPS in San Diego to discuss machine learning and computer vision applications for biodiversity monitoring.

#NeurIPS2025 #RemoteSensing #ComputerVision #MachineLearning #ForestMonitoring #BiodiversityMonitoring | 274 | 8 | 11 | 1mo | Post | Arthur Ouaknine | https://www.linkedin.com/in/arthur-ouaknine | https://linkedin.com/in/arthur-ouaknine | 2025-12-08T07:10:47.410Z |  | 2025-11-04T12:00:18.828Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7328373529098280961 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPY-2Dc9pxLA/feedshare-shrink_800/B4EZbMgIF3HkAg-/0/1747187699760?e=1766620800&v=beta&t=BEgbqWC7a50k8EPMeE5ffF2rbK5NOkIViVwMbdF-ZUQ | 🌎  We have an internship opportunity Mila - Quebec Artificial Intelligence Institute (Montréal)
🌲 Multi-modal learning for forest monitoring
👨‍🏫 Supervised by Arthur Ouaknine, in collaboration with David Rolnick & Etienne Laliberté

We’re looking for a full-time research intern (6 months) to work on cutting-edge ML for remote sensing 🌍
Keywords:
📸 drone imagery | 🌐 3D point clouds | 🌲 tree crown segmentation | 🧠 PyTorch | 🔀 multi-modal fusion | 📊 benchmarking | 🛰️ remote sensing

🗓️ Start: June 2025 (flexible)
📌 Location: Mila, Montréal (remote start possible)
⏳ Deadline to apply: June 7, 2025 – 11:59pm AoE
🔗 Apply here: https://lnkd.in/ebkxBr94

📬 Questions? Reach out: arthur.ouaknine [at] mila.quebec with [intern!] in the subject

🧠 Looking for ML Master’s/PhD level profiles with experience in PyTorch, vision, and remote sensing.
🌳 Bonus: Background in 3D modeling, instance segmentation, or multi-modal/multi-task learning.

#MachineLearning #ComputerVision #RemoteSensing #ForestMonitoring #PyTorch #GeospatialAI #Internship #Research | 278 | 12 | 21 | 6mo | Post | Arthur Ouaknine | https://www.linkedin.com/in/arthur-ouaknine | https://linkedin.com/in/arthur-ouaknine | 2025-12-08T07:10:47.413Z |  | 2025-05-14T11:00:03.933Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7303425882038124545 | Text |  |  | 🎉 Happy to share that our work OpenForest has been published in Environmental Data Science.

🌲We discussed many research ideas at the intersection of machine learning and forest monitoring as well as listing significant amount of open access datasets.
If you dataset is not here yet, feel free to add it in the catalog in our github repo!

Paper: https://bit.ly/41IK23B
Github: https://lnkd.in/emeR6yUm | 81 | 7 | 1 | 9mo | Post | Arthur Ouaknine | https://www.linkedin.com/in/arthur-ouaknine | https://linkedin.com/in/arthur-ouaknine | 2025-12-08T07:10:47.414Z |  | 2025-03-06T14:47:01.369Z | https://www.linkedin.com/feed/update/urn:li:activity:7303368842536259585/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7273937430884356097 | Article |  |  | 🌍 The Climate Change AI workshop at NeurIPS 24 will be livestream and available for free to everyone!

🕗 It will be held tomorrow (Dec 15) between 8.15am and 5.30pm PT.

👉 Link for the livestream and full schedule available here: https://lnkd.in/eniAf4gh | 30 | 1 | 0 | 11mo | Post | Arthur Ouaknine | https://www.linkedin.com/in/arthur-ouaknine | https://linkedin.com/in/arthur-ouaknine | 2025-12-08T07:10:47.414Z |  | 2024-12-15T05:50:26.745Z | https://www.climatechange.ai/events/neurips2024 |  | 

---



---

# Arthur Ouaknine
*Rubisco AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Arthur Ouaknine | Mila](https://mila.quebec/en/directory/arthur-ouaknine)
*2025-01-01*
- Category: article

### [Arthur Ouaknine – Medium](https://medium.com/@arthur_ouaknine)
*2018-12-11*
- Category: blog

### [Rubisco: The Future of Humanity’s Protein Supply](https://www.capecrystalbrands.com/blogs/cape-crystal-brands/rubisco-the-future-of-humanity-s-protein-supply)
*2025-03-17*
- Category: blog

### [‘World’s Most Abundant Protein’ Cheap Enough to Replace Soy: Upcycled Rubisco Protein Startup Day 8 Nabs $750K Pre-Seed](https://www.greenqueen.com.hk/day-8-rubisco-protein-israel-the-kitchen-foodtech-hub/)
*2024-02-21*
- Category: article

### [Mila Entrepreneurship Lab | Mila](https://mila.quebec/en/industry/mila-entrepreneurship-lab)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Arthur Ouaknine's Personal Page](https://arthurouaknine.github.io/)**
  - Source: arthurouaknine.github.io
  - *I am co-founder and chief technical officer (CTO) of Rubisco AI, a Mila startup that aims to monitor forest restoration projects. ... © 2025 Arthur Ou...*

- **[Assessing SAM for tree crown instance segmentation from drone ...](https://arxiv.org/html/2503.20199v1)**
  - Source: arxiv.org
  - *Mar 26, 2025 ... \AndArthur Ouaknine Mila, McGill University, Rubisco AI \AndEtienne ... In Proceedings of the AAAI Conference on Artificial Intellige...*

- **[(PDF) Assessing SAM for Tree Crown Instance Segmentation from ...](https://www.researchgate.net/publication/390213660_Assessing_SAM_for_Tree_Crown_Instance_Segmentation_from_Drone_Imagery)**
  - Source: researchgate.net
  - *Mar 26, 2025 ... ... Rubisco AI. Etienne Lalibert´. e. Universit´. e ... Arthur Ouaknine · Etienne Laliberté; [...] Hugo Larochelle....*

- **[Mila Entrepreneurship Lab | Mila](https://mila.quebec/en/industry/mila-entrepreneurship-lab)**
  - Source: mila.quebec
  - *Rubisco AI. Arthur Ouaknine, Etienne Laliberté. Rubisco AI's mission is to allow anyone to easily map all trees in their forests, determine their spec...*

- **[Impact Report 2024-2025 | Mila](https://mila.quebec/en/about/impact-reports/impact-report-2024-2025)**
  - Source: mila.quebec
  - *... Conference on Learning Representations (ICLR) Test of Time Awards ... Arthur Ouaknine, Rubisco AI leverages advanced AI and computer vision to ......*

- **[Demo Day 2023 | Mila](https://mila.quebec/en/news/demo-day-2023)**
  - Source: mila.quebec
  - *Nov 29, 2023 ... ... Arthur Ouaknine (Rubisco AI), Jorgelindo da Veiga Moreira (Spheroid ... Blog · Speed Science Contest · Publications · Open Source...*

- **[Arthur Ouaknine](https://arthurouaknine.github.io/files/cv_ouaknine.pdf)**
  - Source: arthurouaknine.github.io
  - *Oct 6, 2025 ... (+1) 438 525 2835 | arthur.ouaknine@gmail.com ... First proof of concept if available at https://rubisco.ai/demo/....*

---

*Generated by Founder Scraper*
