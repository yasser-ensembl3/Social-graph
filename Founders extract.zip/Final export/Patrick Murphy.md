# Patrick Murphy

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Maket Technologies
**Durée dans le rôle** : 5 years 9 months in role
**Durée dans l'entreprise** : 5 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Architecture - For Everyone

## Résumé

Building the future of home design, planning & construction

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAApl9TABU6SqBkuBS-zbFTBMOcP_tKV9j3o/
**Connexions partagées** : 224


---

# Patrick Murphy

## Position actuelle

**Entreprise** : Maket

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Patrick Murphy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7373339592151683072 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0028422c-9fcf-4204-95a4-e8a0d192c178 | https://media.licdn.com/dms/image/v2/D4E10AQFkuf6a6K3oMA/videocover-high/B4EZlNaDpwHEBY-/0/1757940303046?e=1765778400&v=beta&t=Rx5aRPKxL9hkzTcxWhs_pPHaQPsngv1yNlDkNDlKZWQ | In Quebec we say ‘Tu te sacre dans le traffic’, which translates to: 

Just do it 

Just ship it 

Just talk about it 

Even if it isn’t perfect, just start. 

The results will compound. 

So far they have compounded into 950,000 people registering to Maket 

And we are just getting started. | 29 | 4 | 1 | 2mo | Stephane Turbide reposted this | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.834Z |  | 2025-09-15T12:59:08.794Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402403336118824960 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHELyDNIGdjOw/image-shrink_800/B4EZrqemN6IoAc-/0/1764870482805?e=1765778400&v=beta&t=V662WfCEmOYVde-80YxhNzb0Gz7G9_OiqNVzFkSut_I | Good design doesn’t always need more square footage. 

Walk through Tokyo or Kyoto and you’ll notice how different it feels. Homes aren’t huge, but they’re perfectly thought out. Every corner has a purpose. Every inch feels considered.

In North America, we’ve built around size. Big houses, big lots, big costs. But we rarely stop to ask if all that space actually makes life better.

Japan figured out something we forgot:

That design isn’t about excess, but more about intention.

That’s where I think AI can make a real difference. Not by making homes bigger or flashier, but by helping us design smarter, layouts that flow better, light that moves naturally through rooms, space that adapts to how people really live.

We don’t need more square footage.

We need more thought in how we build. | 9 | 2 | 0 | 3d | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:29.689Z |  | 2025-12-04T17:48:05.334Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401617647395643392 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d376025d-2be5-46ef-8935-9bef3dfd7bbc | https://media.licdn.com/dms/image/v2/D4E10AQEoFwUhq59KCg/videocover-high/B4EZrfTzWlKgA4-/0/1764683103950?e=1765778400&v=beta&t=Y5sH6Ms3JdAwTeclsUbraHAneEzuMCDj9gttPoGE96E | Frederic Bastien hit the nail on the head 🔨 

Will AI take my place? It’s a question that a lot of people are asking these days. 

AI won’t replace architects. 

Instead, it will speed up the slow parts, keep projects compliant, and help teams design more homes, faster. 

For the full listen: https://zurl.co/NqucD | 2 | 0 | 0 | 5d | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:29.690Z |  | 2025-12-02T13:46:02.545Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401288993893613571 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFlr_mTN86KXg/image-shrink_800/B4EZrapHVTHoAk-/0/1764604803325?e=1765778400&v=beta&t=eTvRKpWif4oLuT04Mb8erHcXofaumPXKuS7qYsPThro | I’ll be speaking on the South by London stage at SXSW London 2026, June 1 to 6!

If you’ll be there, let’s connect. 

#SXSWLondon | 65 | 5 | 0 | 6d | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:29.690Z |  | 2025-12-01T16:00:05.444Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400186736837865473 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGGXpIz4sU1lg/image-shrink_800/B4EZrK.nyuJ0Ac-/0/1764342006391?e=1765778400&v=beta&t=vMQAscKsHX31dkJkyouUJwU6TcSGWA3cAVN8fsAJemY | As someone who started in graphic design, this one hit differently.

Affinity going free forever feels like a shift back toward what really matters: 

taste 
design
creativity.

When tools become democratized, what sets people apart isn’t access anymore, it’s taste. Anyone can create now, but not everyone can create something beautiful 😅

I was looking through a book of different logos the other day. The craft, the intention, the restraint. That level of thinking only comes from people who care deeply about design.

AI can replicate the output, but not the emotion behind it. Only humans can do that and that’s what makes design timeless.

Good taste still wins in the end. | 14 | 0 | 0 | 1w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:29.691Z |  | 2025-11-28T15:00:06.883Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7399461964080377858 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQET_26uvARy3Q/image-shrink_800/B4EZrArcknHcAg-/0/1764169207314?e=1765778400&v=beta&t=8vpAW_YXQ9mJqS-NCH5mrwSKA6dhozh4_kleR48sc6w | Most builders still manage plans through PDFs, email threads, or software only a few people on the team can open.

That’s a massive problem.

When plans are static, decisions get delayed, communication breaks down, and people end up building the wrong thing.

And it costs everyone time, money, and trust.

That’s why we built the ability to upload and digitize plans directly into Maket.

Since launching it, over 2,500 people have uploaded their own plans to be digitized.

Because once a plan becomes dynamic, everything changes.

You can edit, share, visualize, and collaborate instantly all in one place. 

A single source of truth, accessible to everyone.

It might sound mundane, but it starts with the floorplan.

That’s where clarity begins & where better buildings start. | 6 | 0 | 0 | 1w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:29.691Z |  | 2025-11-26T15:00:07.592Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396200495742144512 | Text |  |  | ChatGPT has changed how we work. It’s smart, fast, and knows a little bit about everything.

But that’s also its limitation. It knows a little bit about everything.

Ask it to design a home and it will do what it always does: make something that sounds right, not something that actually works. It doesn’t understand how spaces flow, how natural light hits a room, or what makes a layout functional for a real family.

That’s where Maket is different.

It’s been built with a very specific purpose, to understand the logic behind architecture. The spacing, the materials, the layout, the rules that dictate what can and can’t be built.

Where ChatGPT starts from general knowledge, Maket starts from context.

In the near future, it will know your lot size, the local zoning rules, your setbacks, and how that connects to what you’re trying to build.

It can reason about orientation, space efficiency, circulation, and real constraints.

ChatGPT gives you text.

Maket gives you plans.

It’s a different way of thinking about what AI can do.

Not as something abstract, but as a tool that helps people bring real ideas to life in a faster and smarter way. 

This is what we’ve been working towards at Maket.

AI that understands the world we actually live in & helps us design it better. 

https://lnkd.in/e5rfg3ih | 13 | 2 | 0 | 2w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.975Z |  | 2025-11-17T15:00:12.945Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394759822556020736 | Text |  |  | À quoi ressemblera l’avenir de l’IA et de l’architecture? Quels défis avons-nous rencontrés Maket?

Tout cela et plus encore dans ma récente conversation avec David Proulx. | 8 | 0 | 0 | 3w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.976Z |  | 2025-11-13T15:35:29.691Z | https://www.linkedin.com/feed/update/urn:li:activity:7393646453715324928/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7394393542946672640 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQF-N2kaofKvAw/image-shrink_800/B4EZp4pvvsKkAg-/0/1762960801355?e=1765778400&v=beta&t=kghH-VZwmZj4W7M77KdCQJ-zMze5W8pEBsseQdBKWfY | I like to compare what we’re building at Maket to the early days of Canva.

Canva used browser-based design to completely change how people could create. 

It gave anyone the ability to make something beautiful without needing a graphic designer.

We’re bringing that same transformation to architectural design.

Over a Million registered users have come to Maket with the same story:
They don’t want to hire an architect for early design exploration and they just want to do it themselves.

That was Canva’s early use case too. Designers didn’t disappear.

They shifted their focus to higher-value work, bigger mandates, and creative direction.

The same thing will happen in architecture.

AI will handle the groundwork:

- plan generation
- visualization
- iteration

and architects will focus on what truly requires human creativity:
solving complex design challenges and shaping spaces that move people.

We’re not removing the architect from the process. We’re bringing everyone else into it. | 33 | 3 | 0 | 3w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.977Z |  | 2025-11-12T15:20:01.827Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7393675060819099649 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQF1mI9I7Z94ZQ/image-shrink_800/B4EZpucSdjHoAg-/0/1762789502086?e=1765778400&v=beta&t=TnmHD3v0SH3w6MPsemkis_CggbT7I6OxEi9NsoCmZlM | One of the things I’m really bullish on is the combination of AI + land maximization.

Picture this: hundreds of thousands of houses sitting on lots that are way too big to maintain. 

Home owners end up spending weekends mowing grass (or buying a fancy mower) just to keep up.

What if I told you there’s a better way?

These same homeowners are sitting on unlocked value and don’t even know it. Many could subdivide their land into multiple lots.

The benefits?

- Unlock hundreds of thousands in value to reinvest. Whether in home improvements, a rental property, or even just high-interest savings
- Create more space to build affordable housing
- And yes, no need for that fancy mower

AI can make this process clear, simple, and accessible. The value is already there, we just need to help people see it. | 11 | 0 | 0 | 3w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.977Z |  | 2025-11-10T15:45:02.339Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7393653130732654592 | Text |  |  | Montreal gave us an early preview of Slush this week, and I'm not talking about the conference 🌨️ 😅 

The Helsinki version sounds much better. 

 If you’re attending, connect with Stephane Turbide. | 12 | 0 | 0 | 3w | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.978Z |  | 2025-11-10T14:17:53.799Z | https://www.linkedin.com/feed/update/urn:li:activity:7393649711049768960/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7392213157265494016 | Article |  |  | Huge thanks to FoundersPress for this feature exploring how our team is reimagining the architectural process through agentic workflows. 

Proud of what we’ve built so far, and even more excited for what’s next! 

https://lnkd.in/ejric8bd | 18 | 1 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.978Z |  | 2025-11-06T14:55:57.371Z | https://thefounderspress.com/how-maket-is-rebuilding-design-from-the-ground-up/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7391469472202629120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGJfAXUSyGjJw/feedshare-shrink_800/B4EZpPGTdMIQAg-/0/1762263647017?e=1766620800&v=beta&t=n2WFsts89yxsO_h6KfNaQJxQbk9tLq5r47PCMblA50g | What a whirlwind week it's been. 🌪️

I visited SF and experienced the power of the Llama Lounge hosted by Jeremiah Owyang, bringing together hundreds of AI builders, investors & corporate partners in the stunning Capgemini offices.

I also got to share the stage with Alyx van der Vorm & Thomas Foley at TC Disrupt chatting about AI Agents.

And of course, the Waymo rides and coffee walks in between meetings with Simon Vallee made it even better.

The energy is unmatched in SF right now.

Until next time 👋 | 72 | 5 | 1 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.981Z |  | 2025-11-04T13:40:49.035Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7391123216578285569 | Article |  |  | Maket was featured in BetaKit as part of our fundraising announcement.

Many thanks to the BetaKit team for highlighting our mission to make architectural design accessible for everyone.

The support from the Canadian tech community means a lot as we continue building here and expanding globally 🇨🇦 

https://lnkd.in/e96NfGYu | 59 | 8 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.981Z |  | 2025-11-03T14:44:55.261Z | https://betakit.com/maket-secures-3-4-million-to-make-floor-planning-quicker-with-ai/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7389327534414303232 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ba3c909e-c17f-4c89-a429-2e996c570f99 | https://media.licdn.com/dms/image/v2/D4E05AQGrhOGhqh6PrA/videocover-low/B4EZowqEI1KkCI-/0/1761752947694?e=1765778400&v=beta&t=T9hyPP_T2yPeW9hlNuNYZ_qI21IFHn4DKO6cRteKYkE | We've raised a $3.4 Million seed round led by Amiral Ventures with participation from Blitzscaling Ventures, BY Venture Partners, Spatial Capital & Hidden Layers. 

When Stephane Turbide and I started Maket, generative AI wasn't a word people used, but we already knew the architectural design world needed a massive shift.

By the time we launched in 2023, we realized this wasn't just our belief.

People everywhere wanted a simpler way to bring their ideas to life and be at the center of the architectural design process.

It’s proof that change is happening fast, and tools like Lovable, Replit, and Bolt are showing the same pattern. People want to go from idea to finished product faster than ever before.

In just two years, over 1 million users have generated millions of floorplans on Maket.

After welcoming Simon Vallee Valle as Co-founder & CPO in April of this year, we’ve been hard at work on Maket 2.0, a fully agentic version of our platform that’s going to change how people design their homes forever.

A huge thank you to everyone who believed in us from day one.

We wouldn’t be here without you.

Frederic Bastien Nectarios Economakis Dominic Becotte Julie Lacasse Jeremiah Owyang Jeffrey D. Abbott Abdallah Yafi Ghaith YAFI Sohrab Jahanbani Doug Griffin Therence Bois Isaac Souweine Bruno Morency Elizabeth Wasserman Marc G. Bellemare Jean-Philippe Taillon, CFA Amélie Chagnon Claude G. Théoret Nicholas Nadeau, Ph.D., P.Eng. Sylvain Carle Kevin Strike George Korkejian Ken Dobell Justine Marchand David Dufresne Emmanuelle Coppinger Brian Bell Louis Lachapelle Mike McAra Lynette Keyowski Taylor Gendron Tim Kersten 

#generativeAI #fundingannouncement #seedround | 265 | 100 | 20 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.983Z |  | 2025-10-29T15:49:31.271Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7388937861682851841 | Video (LinkedIn Source) | blob:https://www.linkedin.com/79d440e3-e6c6-46eb-a94a-e78f1a22d690 | https://media.licdn.com/dms/image/v2/D4E10AQEQ3EkzUqPj-Q/videocover-low/B4EZorHmmaKgAk-/0/1761660006064?e=1765778400&v=beta&t=YddcHxEM3qzum9InCCulXRIpgFLcQT0AoP-GNIJhtz8 | I’m a passionate person.

When I get into something, I go all in. It’s a cycle I’ve repeated with hobbies, sports, and pretty much everything else I’ve ever cared about.

Call it curiosity, call it hyperfocus, probably a bit of both.

I’ve always loved good design. Since starting Maket, that’s evolved into a passion for great architectural design.

In the age of AI, automation, and new materials, there’s no reason for ugly design anymore.

So why do we still see it?
Because data is siloed.
Because information is gatekept.
Because approval processes are outdated.
Because tools are stuck in the past.
Because people resist change.

The fix?

AI and UI working together, understanding all that complexity and making it simple.

The result: beautiful, accessible architecture, at scale. | 11 | 1 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.984Z |  | 2025-10-28T14:01:06.052Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7387121879876124672 | Article |  |  | I was having lunch with a long-time friend and mentor of mine.

Ken Dobell has worked at the highest levels in agencies and companies as President and VP. We always end up talking about the state of marketing, and this time he said something that stuck.

Companies live in three categories:

- Product companies
- Product companies → Marketing companies
- Marketing companies → Brand companies

Very few ever make the leap from marketing-led to brand-led.

That leap is what separates the ones that last from the ones that fade.

Invest in brand.

For example  👉 https://zurl.co/m34tb | 12 | 5 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.985Z |  | 2025-10-23T13:45:02.250Z | https://www.youtube.com/watch?v=FDNkDBNR7AM |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7386042516883529728 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGNBvloYAzkJQ/image-shrink_800/B4EZoB.h89JgAc-/0/1760969761629?e=1765778400&v=beta&t=bdN88Pb2Otcs0oIqKT2rptm2JEHVkM6-0wKT7fYS5ZY | Image models are incredible for visual inspiration but they don’t know building codes, zoning laws, or how to translate a beautiful render into an actual livable design. That’s the missing layer.

Because at the end of the day, you don’t just need an image. You need something that can turn imagination into floorplans, structures, and approvals.

That’s exactly what we’re building at Maket. | 11 | 3 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.985Z |  | 2025-10-20T14:16:02.059Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7384986565078384641 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFbjyCb0aAq_Q/image-shrink_800/B4EZny.JIrHgAg-/0/1760718002611?e=1765778400&v=beta&t=f29a_gKVB84iAO3oOmFj8r3WOeIMwn5v6clIGJcEQF4 | I was shocked to see a similar house as mine listed for $125,000 more — just two years after I bought.

I think real estate is being downplayed as an investment opportunity right now. Public sentiment is shifting toward “renting is better.”

Here’s what I think.

Real estate will keep on gaining value.

But we need to start treating real estate and home ownership as a generational asset, something handed down from one generation to the next.

Real estate agents have a huge role to play in this. For the longest time they’ve been seen as ‘transaction-oriented’, always thinking about the next sale.

I propose a new model: Imagine if the real estate agent was your asset manager. 

They would have access to AI tools around property value, reno estimation, and visualization.

Acting as the adviser for how you can maximize your property value. | 22 | 1 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.986Z |  | 2025-10-17T16:20:03.530Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7384237424056483840 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEIpmbNITYJhA/image-shrink_1280/B4EZnoUzsJIUAU-/0/1760539393858?e=1765778400&v=beta&t=PigcgEatAy2Y0Ixy7vnmeyPxEtllFm9Vuqw4VqTlubY | Everyone says “running a startup is a marathon”.

But it’s definitely not a clean 26 miles 😅

It’s sprinting one week, crawling the next.

Or going from “this is falling apart” to “we’re unstoppable” in the span of a day.

Entrepreneurs can get fooled by headlines and LinkedIn posts. They make it seem like success comes from one big moment:

- the funding round
- the product launch
- the big customer win

But the reality is much slower. The endless repetition of showing up, putting in the work, and solving the next problem.

Over time, those small, ordinary days stack up. And then one day, it looks like momentum.

That’s the real compounding. | 32 | 3 | 1 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.987Z |  | 2025-10-15T14:43:14.392Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7383510333514219520 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHSllqIJq3L7Q/image-shrink_800/B4EZnd_hY2IoAc-/0/1760366041689?e=1765778400&v=beta&t=FjkJ1rdXKWDqv4u8nfTQIteJeYBrKOz46VrE__WtHC8 | I love supporting local businesses.

One of my favourites is Luminaire Authentik.

If you’ve stepped into a trendy bar, restaurant, or home in Montreal, you’ve probably seen their work. Their lighting is instantly recognizable.

You pick the model. You pick the colour. And it’s handmade in Cowansville, just an hour outside the city.

It’s the perfect example of how local craft and modern technology don’t compete, but rather collaborate. | 16 | 2 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.987Z |  | 2025-10-13T14:34:02.498Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7382426695661678592 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGrwa2QnACMBg/image-shrink_800/B4EZnOl9PRHIAk-/0/1760107682731?e=1765778400&v=beta&t=qCuv8_DDyX0k8VceLEATJ8uffEmg6cxVU4_lfFypTM4 | Since the start of this year, we’ve approached hiring differently.

We’re keeping the team intentionally small — inspired by companies like Gamma and Loveable.

Not “hire fast, scale headcount.”
But “hire the right people, give them AI agents, and let them do more.”

And before we make an offer, every candidate meets every single person on the team.

It slows us down.
But that’s the point.

Hiring is the only thing we do slowly because it shapes everything else we can do quickly. | 28 | 4 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.988Z |  | 2025-10-10T14:48:03.101Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7381699398612779008 | Article |  |  | People have stopped even trying to live in the city.

Montreal should be accessible. It isn’t. Houses that should feel within reach are now sitting at a million dollars.

And this isn’t just a Montreal problem. It’s everywhere.

So people leave. They move further out. Suburbs stretch. Commutes get longer. Infrastructure falls behind.

If we want housing to work, we need more density in the core and real investment in infrastructure so other regions can actually stand on their own.

Right now, we’re failing at both.

https://zurl.co/rIOBq | 5 | 2 | 0 | 1mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.988Z |  | 2025-10-08T14:38:01.972Z | https://www.lapresse.ca/actualites/chroniques/2025-09-30/exode-vers-les-banlieues/l-inaccessible-maison-a-1-million.php |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7380972612216315904 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEF7Ek54kk_hA/image-shrink_800/B4EZm57euuKYAc-/0/1759761001959?e=1765778400&v=beta&t=jbPn9RwwBQDaoloRiupnUNfGYp9wPYA6BjBa-XJRt4w | This was the slide we presented at our booth at ALL IN 2025. 

It was clear, direct, straight to the point. And people were drawn to it.

It reminded me how much simplicity matters. In events. In design. In product.

People don’t want to fight through clutter. They want clarity. They want products that get to the point.

That’s been a huge learning for us at Maket and it’s shaped the new version we’re about to release. | 20 | 2 | 0 | 2mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.989Z |  | 2025-10-06T14:30:02.592Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7379629011876093952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9e81324a-88b5-4965-8385-91eb1f8d2f33 | https://media.licdn.com/dms/image/v2/D4E10AQH1_8nU3gbx_Q/videocover-high/B4EZmm1QSdIoAo-/0/1759440603269?e=1765778400&v=beta&t=6QE3a6XhLe6mXgH_xYupk0BowHgLfKSDXFFnUE02LH0 | I tried Sora 2 👀

I used it to generate old-time style ads for Maket and the results were mind blowing.

But I’m also a little concerned about the direction this is heading.

The line between real and synthetic keeps getting thinner. Using Sora felt so natural that when I switched back to Reddit, I had to do a mental reset and remind myself:

“this is real, that was not.”

The technology is incredible. But it’s also a reminder that what’s real and what’s generated will soon be almost impossible to tell apart.

How do you feel about Sora 2? | 17 | 4 | 0 | 2mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.990Z |  | 2025-10-02T21:31:03.308Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7379228070886543360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH0yWbVvcWvNA/feedshare-shrink_800/B4EZmhI0nvIQAg-/0/1759345070775?e=1766620800&v=beta&t=A9NyVYF8flLmVS2K1Qrn9UGCykhCtE5V-HwPCJhzF8Q | Last week I shared some updates about what is coming up next with Maket. 

Huge shoutout to Nicholas Nadeau, Ph.D., P.Eng. Claude G. Théoret and Sylvain Carle for putting together another edition of AI Salon with over 300+ people in attendance

Many thanks Richard Chenier and the entire Québec Tech team for hosting at Ax-C. 

Stay tuned 👀 | 39 | 4 | 0 | 2mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.991Z |  | 2025-10-01T18:57:51.527Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7379160674754777088 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQG3ahela4ybcw/image-shrink_800/B4EZmgLiB9KcAc-/0/1759329002839?e=1765778400&v=beta&t=3Uhq0WBP6UOlGDzervxy9NtZeX8Q7Ia6lMsHPtVncJM | What is becoming more and more clear in the era of AI is that brand matters.

Look at the best companies right now

- Gamma
- Anthropic

They all take brand seriously. They invest in it.

Gamma is instantly recognizable through its visuals and the thought leadership Grant Lee drives online.

Anthropic just launched an ad that is a masterpiece.

Yes, they have incredible products, communities, and distribution. But all of it is amplified by the strength of their brand.

As AI becomes the baseline for software and startups, the differentiator will be the companies that understand brand is not an afterthought. It’s an advantage. | 6 | 0 | 0 | 2mo | Post | Patrick Murphy | https://www.linkedin.com/in/patrick-murphy-2685114a | https://linkedin.com/in/patrick-murphy-2685114a | 2025-12-08T05:19:33.992Z |  | 2025-10-01T14:30:03.037Z |  |  | 

---



---

# Patrick Murphy
*Maket*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 20 |

---

## 📚 Articles & Blog Posts

### [Building Dreams with AI: Inside Patrick Murphy's Maket Mission](https://insights.teamignite.ventures/p/building-dreams-with-ai-inside-patrick)
*2023-12-07*
- Category: article

### [Building Dreams with AI: Inside Patrick Murphy's Maket Vision | Ep18 - Ignite Podcast](https://theignitepodcast.com/episodes/DteuHRa3j5D)
*2023-12-07*
- Category: podcast

### [Maket vs. Traditional Residential Planning: A Professional's Perspective | Maket](https://www.maket.ai/post/maket-vs-traditional-residential-planning-a-professionals-perspective)
*2000-01-01*
- Category: article

### [How To Be Unemployed by Patrick Murphy](https://thephiladelphiacitizen.org/unemployment-patrick-murphy/)
*2025-08-11*
- Category: article

### [The Source Podcast: Delivering Investment Insights with AI](https://www.nasdaq.com/articles/evestment/asset-manager-insights/the-source-podcast-delivering-investment-insights-with-innovative-artificial-intelligence)
*2023-10-24*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[AI Integration in BIM Workflows - IAAC BLOG](https://blog.iaac.net/ai-integration-in-bim-workflows/)**
  - Source: blog.iaac.net
  - *Mar 16, 2024 ... Experts for the Podcast : Patrick Murphy, CEO of MAKET AI : Patrick Murphy, CEO of MAKET, a company leveraging generative AI to trans...*

- **[From Floorplans to Full Renovations: How Maket's AI Owns the ...](https://www.tsp.show/from-floorplans-to-full-renovations-how-makets-ai-owns-the-architectural-stack-spotlight/)**
  - Source: tsp.show
  - *May 19, 2025 ... Apple Podcasts podcast player icon Apple Podcasts · Spotify ... In this Spotlight episode, Maket founder Patrick Murphy delivers a .....*

- **[Maket secures $3.4 million to make floor planning quicker with AI ...](https://betakit.com/maket-secures-3-4-million-to-make-floor-planning-quicker-with-ai/)**
  - Source: betakit.com
  - *Oct 29, 2025 ... Podcast · Newsletter · Quiz · Jobs. Maket secures $3.4 million to make ... Maket co-founders, COO Stéphane Turbide and CEO Patrick Mu...*

- **[We invested in Maket, AI for Residential Architecture](https://www.blitzscalingvc.com/post/we-invested-in-maket-ai-for-residential-architecture)**
  - Source: blitzscalingvc.com
  - *Jun 9, 2025 ... Patrick Murphy and Stéphane Turbide in Montreal, Maket reimagining architectural design with AI at its core. Maket has built a proprie...*

- **[Building Dreams with AI: Inside Patrick Murphy's Maket Mission ...](https://www.youtube.com/watch?v=qW5Eb4Fcw54)**
  - Source: youtube.com
  - *Dec 7, 2023 ... In this Ignite Podcast episode, host Brian Bell interviews Patrick Murphy, CEO of Maket, a company leveraging generative AI to transfo...*

- **[Patrick Murphy, Author at TechCrunch](https://techcrunch.com/author/patrick-murphy/)**
  - Source: techcrunch.com
  - *Nov 15, 2023 ... Patrick Murphy is Co-Founder & CEO at Maket, a generative architecture platform for homeowners and builders. Maket's AI tools empower...*

- **[Maket, dubbed the “ChatGPT for architecture,” scoops $3.4M CAD to ...](https://techfundingnews.com/montreal-maket-chatgpt-architecture-raises-3-7m-cad/)**
  - Source: techfundingnews.com
  - *Oct 29, 2025 ... Podcast · Popular now · Premium · Robotics News · SaaS News · Social Media ... Maket was founded in 2020 by Patrick Murphy, Stéphane ...*

- **[FoundersPress - Startup News, Tech & Reviews](https://thefounderspress.com/)**
  - Source: thefounderspress.com
  - *When Patrick Murphy describes Maket, he talks about democratization and a mission to make the architectural process as accessible as designing a socia...*

- **[How to Enhance Client Satisfaction Through Custom Designs | Maket](https://www.maket.ai/post/how-to-enhance-client-satisfaction-through-custom-designs)**
  - Source: maket.ai
  - *Businesses should conduct thorough research, including surveys, interviews ... Patrick Murphy. Co-Founder & CEO @ Maket. Recent blogs. Maket. A New Ma...*

- **[Book resources](https://nowork.ai/resources/)**
  - Source: nowork.ai
  - *May 31, 2024 ... Linkedin profile of Maket.ai CEO, Patrick Murphy: https://www ... David Sheff, “Interview with Steve Jobs”, 1985: https ......*

---

*Generated by Founder Scraper*
