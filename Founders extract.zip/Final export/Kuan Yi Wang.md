# Kuan Yi Wang

## Position actuelle

**Titre** : Piñata Pitch Co-Founder
**Entreprise** : Pinata Pitch
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

• Co-founded Piñata Pitch, Montreal's largest tech student pitch competition
• Montreal Startup Awards '25 | First-time Community Initiative Finalist
• Open House MTL ‘25 Champion Partner
• Shopify AI Build Day (Builder Sunday special edition) partner

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAFDAcDMBHth8yEa6ZDmhxxlnmRCMAb20ZE0/
**Connexions partagées** : 8


---

# Kuan Yi Wang

## Position actuelle

**Entreprise** : Pinata Pitch

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Kuan Yi Wang

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7395140295899639808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF5ZukiO9U-DQ/feedshare-shrink_800/B4EZqDQ5zDKsAg-/0/1763138839853?e=1766620800&v=beta&t=YobQ7nOBF8-27jdwd7BXb6qg2HMwEJlUB_tzRthadyg | don't expand... ok i'll let you click expand only if you do me a small favour



deal

We need students, builders, founders - Montrealers to believe in the younger generation like we do. If you fit in any of these categories, consider lending a hand. 

Piñata Pitch got nominated for the Founder's First Initiative of the Year at Montreal's 2025 Startup Awards and we need YOUR vote to win. 

Last year, in three months, Pinata Pitch raised $17k to organize the most sought-after student tech pitch comp in Montreal. 

Our school counselor told us ~50 people would show up, so might as well use the gymnasium as the venue. 

Their very words motivated us to 10x that number. 

We did even better. 

The past year, we've partnered with Shopify and Open House Montreal | Portes Ouvertes Montreal - #OHMTL to bring three local events to life, bridging over 4000+ of the younger generation in Montreal. 

Next year, Piñata Pitch is returning bigger. 
Game-ified event. 
Bigger venue. 
More prizes. 

But before that, help us get that trophy here:
https://lnkd.in/eCSs-WgJ 

(PP is only participating in the First Initiative Award; have a look at the other categories and cast your vote for them too! | 31 | 3 | 1 | 3w | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:44.705Z |  | 2025-11-14T16:47:21.605Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384619602447851520 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH2DqpaQ0a6nQ/feedshare-shrink_800/B4EZntwZclGUAg-/0/1760630511843?e=1766620800&v=beta&t=IA92khZxe5JlCDU7XzLKuTmnhTm_r_zs7l05MgAG0-I | Setting up my phone wallpaper as my LinkedIn QR code was massive

Anyway, I got my weekend laid out for you. literally
imo my favorite event is CR4KD (only for cracked people)

take a ss, go home sunday with a cofounder | 14 | 0 | 1 | 1mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.051Z |  | 2025-10-16T16:01:52.821Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7382976561727033345 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHBgOMtqH7U5Q/feedshare-shrink_800/B4EZnWYJhGGcAg-/0/1760238279059?e=1766620800&v=beta&t=EwZP-UCRIaunWxh28WN_MnpinKIXL9-ONoea9cDWtws | Thank you ilias Benjelloun and Nicholas Nadeau, Ph.D., P.Eng. for guiding both of us throughout this past year - it's cumulated to this point where even without a startup myself (yet) i'm bathing in the ecosystem. 
appreciation post coming soon btw | 8 | 1 | 0 | 1mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.052Z |  | 2025-10-12T03:13:01.387Z | https://www.linkedin.com/feed/update/urn:li:activity:7382974461240852480/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7375698794325381120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHqfmCnrB8M1g/feedshare-shrink_800/B4EZlpndBVIkAg-/0/1758413574920?e=1766620800&v=beta&t=7RvNeGtnzot0143sMxtwgP-CarGdYlmHf3KMggbRKMI | locked in | 7 | 0 | 0 | 2mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.053Z |  | 2025-09-22T01:13:46.424Z | https://www.linkedin.com/feed/update/urn:li:activity:7375687788719153152/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7371326868395810816 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5e098931-59b0-4a19-80ae-5f009f8f2406 | https://media.licdn.com/dms/image/v2/D5605AQGeYpk8coi8NQ/videocover-low/B56ZkwtWrSI8CI-/0/1757458859558?e=1765785600&v=beta&t=XGR5bifA6cY6O9mMe0g7Hytf_VShmGBUBjODSmPgkAo | fomo - you? | 4 | 0 | 0 | 2mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.055Z |  | 2025-09-09T23:41:18.056Z | https://www.linkedin.com/feed/update/urn:li:activity:7371316763747082241/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7370571461591310336 | Article |  |  | Thanks so much Sheng! Wishing you success in your ventures too... | 7 | 0 | 0 | 3mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.056Z |  | 2025-09-07T21:39:35.039Z | https://www.unfounders.com/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7356146451317415937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFCo1i_pE0yww/feedshare-shrink_800/B4EZhXsR2oGwAg-/0/1753817882539?e=1766620800&v=beta&t=0MQVyyLiQ-jd_Lr0Yp_9tpYYncjjbQ0qVvIEum8h4Xc | if you're a builder, or are building, you just can't skip this. | 2 | 0 | 0 | 4mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.058Z |  | 2025-07-30T02:19:44.586Z | https://www.linkedin.com/feed/update/urn:li:activity:7356045365545955328/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7354616688530575360 | Text |  |  | Screw your midterms - do them on your flight to SF. We're paying.


𝚞̲𝚗̲𝚏̲𝚘̲𝚞̲𝚗̲𝚍̲𝚎̲𝚛̲𝚜̲ ̲is building the most ambitious network in the world of untraditional founders - creator-founders to be exact. 

You have 2 months to build, market, record and grow. 

Present your journey in a reel; surprise us and you fly into an Airbnb in SF on October 7.

Then, it's PVP for investors. You'll get free mentorship, pitches left and right, panels of investors like sitting ducks. Except, they're rich ducks.

join immediately: https://tally.so/r/w77AOZ | 28 | 3 | 2 | 4mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.060Z |  | 2025-07-25T21:01:00.716Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7350886876733440001 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE6Xyx0wf9dDg/feedshare-shrink_2048_1536/B4DZgL0hdFGQAs-/0/1752544976810?e=1766620800&v=beta&t=A9avKcvKh0TlQb_VWWvR2F5Nwp37YD-zqDhqrsrgPVg | 𝘐 𝘨𝘰𝘵 𝘱𝘶𝘵 𝘪𝘯 𝘵𝘩𝘦 𝘵𝘪𝘮𝘦𝘰𝘶𝘵 𝘤𝘰𝘳𝘯𝘦𝘳 𝘰𝘯 𝘢 𝘳𝘰𝘰𝘧𝘵𝘰𝘱 𝘪𝘯 𝘊𝘩𝘪𝘯𝘢𝘵𝘰𝘸𝘯 𝘢𝘵 𝘵𝘩𝘦 𝘳𝘪𝘱𝘦 𝘢𝘨𝘦 𝘰𝘧 18.

Pinata Pitch v.0 connected 450 students from 15 countries around the world - we gave $10 000 CAD to the winning team. I thought we did great, but StartupFest reminded me I’m still just a pawn on the starting rank.

In this game, the queens and the rooks don't notice you until you’re a move away from promotion – until then, you’re expected to wait, prove, and earn your place on the board. Until then, I'm out of rooftop afterparties. 

Of course, don't get me wrong: StartupFest's warmth reminded me the importance of a team and the magic of the butterfly effect; Theodore Grether-Murray, Bill Xu, Lily An and Allen Yang, the Pinata Pitch squad behind sleepless nights of Figma designs and miserable marketing campaigns involving Squid Game, know that you guys made it into the highlights of my past year. It's always about the community, the friends and even the Linkedin ding-dings.

Back to today - without Pinata Pitch, at StartupFest, 
 • I never would've volunteered for Mishel Wong under Bopaq
 • I never would've ran into my previous boss Shiron L. and chit-chatted like old friends over pizza
 • I never would've visited Acrylic' and Chloë Ryan's office thanks to Nicholas Nadeau, Ph.D., P.Eng., a true tech inspiration
 • I never would've imagined meeting the chillest Googler Sheel Patel (office tour when??🤣 )
 • I never would've interviewed my goat Xin.
 • I never would've dreamed of losing count of the amount of Linkedin ding-dings.

All this, in the last three days. 

Special thanks to ilias Benjelloun for that pat on the shoulder during elantech's Grassroot Builder's potluck a few months back - it still resonates within me.

Before clocking out, thank you to everyone here and all those who helped shape my love for the startup world this past year. A pawn moves forward, one square at a time — see you next year, closer to promotion. | 47 | 2 | 0 | 4mo | Post | Kuan Yi Wang | https://www.linkedin.com/in/kuan-yi-wang-443871319 | https://linkedin.com/in/kuan-yi-wang-443871319 | 2025-12-08T07:15:51.061Z |  | 2025-07-15T14:00:04.287Z |  |  | 

---



---

# Kuan Yi Wang
*Pinata Pitch*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Piñata Pitch | Premier Tech Pitch Competition](https://www.pinatapitch.tech/team)
*2025-04-30*
- Category: article

### [How Two Founders Grew AI Tool For E-commerce Soloprenuers to 100K Users in Under 2 Years](https://www.starterstory.com/kua-ai-breakdown)
*2024-10-25*
- Category: article

### [Getting Creative at Scale](https://greylock.com/greymatter/pinata-getting-web3-creative-at-scale/)
*2022-12-02*
- Category: article

### [How to Build a Fullstack Mobile App with Expo](https://pinata.cloud/blog/how-to-build-a-fullstack-mobile-app-with-expo/)
*2024-12-11*
- Category: blog

### [Book Clubs and Book Suggestions: New Yorker magazine](https://libguides.freeportlibrary.info/BookClubsandBookSuggestions/NewYorker)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
