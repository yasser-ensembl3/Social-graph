# Yanis Nassi

## Position actuelle

**Titre** : Founder & Co-organizer
**Entreprise** : Selva de Concreto
**Durée dans le rôle** : 4 years 5 months in role
**Durée dans l'entreprise** : 4 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

FR : 

Programmation événementielle complète : sélection des artistes, prise de contact, négociation des cachets et planification des prestations.

Supervision logistique : gestion de la location de matériel, scénographie, coordination sur site lors des événements.

Marketing et communication : développement de l’identité visuelle, création de contenus graphiques, gestion des réseaux sociaux et animation de la communauté.

Promotion terrain : conception et diffusion de supports imprimés (flyers, affiches), campagnes d’affichage urbain.

Gestion d’équipe : encadrement de bénévoles et de personnel temporaire.

Opérations : gestion des stocks (bar et restauration), relations partenaires et sponsors, coordination des démarches administratives (permis et autorisations).

ENG 

Full event programming: artist selection, booking, and fee negotiation.

Logistical oversight: equipment rental, scenography, on-site coordination.

Marketing and communication: branding, visual content creation, social media management, public engagement.

Field promotion: flyer design and distribution, urban poster campaigns.

Team management: coordination of volunteers and temporary staff.

Operations: inventory management (bar, food), sponsor relations, permit acquisition.

## Résumé

Français : 

Développeur web et analyste de données avec une formation en économie quantitative (Université de Montréal), je me spécialise en modélisation prédictive, analyse comportementale et intégration de données multi-sources.

Après plusieurs années chez Desjardins, j’ai choisi de prendre le temps de completer sérieusement  ma formation pour répondre aux standards actuels du marché. Depuis un an, je me consacre pleinement à l’apprentissage d’outils modernes : Python, machine learning, pipelines ETL, visualisation avancée applications d’IA, développement full stack React/TS/ReactNative/JS/Node.

Mes projets personnels m’ont permis de consolider des compétences en statistiques appliquées, modélisation, et interprétation rigoureuse des données, avec une attention particulière à la clarté des insights et leur mise en valeur via des dashboards interactifs. 

Curieux, rigoureux et orienté impact, je cherche aujourd’hui une opportunité en science des données où je pourrai continuer à progresser et générer de la valeur.


English : 

Full stack Developper & Data analyst with a background in quantitative economics (Université de Montréal), I specialize in predictive modeling, behavioural analysis, and the integration of multi-source datasets.

After several years at Desjardins, I made the decision to fully commit to upskilling in data science to meet current industry standards. Over the past year, I’ve focused intensively on mastering modern tools: Python, machine learning, ETL pipelines, advanced data visualization, and AI-driven applications. Fullstack Webdev React/TS/ReactNative/JS/Node.

My personal projects have strengthened my expertise in applied statistics, modeling, and rigorous data interpretation, with a strong emphasis on delivering clear insights and showcasing them through interactive dashboards.

Curious, detail-oriented, and impact-driven, I’m now seeking a data science opportunity where I can continue to grow while generating real value.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABoDb5cBwpeCwmE2ykSRIy7EWrS2KFuOGvs/
**Connexions partagées** : 1


---

# Yanis Nassi

## Position actuelle

**Entreprise** : BAHY - Solutions écoles & formateurs

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Yanis Nassi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400259696504238080 | Article |  |  | Ces dernières semaines ont été très intenses. J’ai eu le privilège de travailler sur le nouveau storefront de Bahy, un projet qui m’a beaucoup appris et qui m’a permis d’élargir encore plus mon champ de compétences.

Travailler avec Bahy, c’est vraiment se retrouver dans une entreprise où la culture interne est saine, positive et collaborative. On s’y sent bien, on partage, on échange, et ça accélère énormément la montée en compétences. C’est un plaisir de faire mes armes dans un environnement comme celui-là.

Sur ce projet, j’ai sorti ma casquette front-end plus que jamais. Ayant souvent été orienté backend/architecture sur mes projets précédents, plonger autant dans l’interface m’a rappelé à quel point une maquette solide (Figma ou autre) est essentielle : c’est la première passerelle entre l’idée du client et la concrétisation de son identité visuelle. Comprendre, interpréter, puis traduire cette vision dans un produit cohérent fait partie des responsabilités qui me tiennent le plus à cœur.

J’ai adoré travailler sur ce storefront et apprendre tout au long du processus. Et même si j’apprécie la finesse du design system et du pixel-perfect, ce projet m’a confirmé une chose : mon esprit est naturellement attiré par les défis plus logiques (penser l’architecture, comprendre les bugs,remonter à la source, trouver la cause profonde, simplifier le code en uniformisant au maximum les requetes etc).

Quoi qu’il en soit, ce projet m’a permis d’évoluer, d’apprendre, et surtout de contribuer à une solution qui reflète vraiment l’image de marque et la vision de Bahy. Fier du résultat, et prêt pour la suite. 

Et vous, vous préférez quoi : le design ou l’architecture ? Et pourquoi ?

Pensez vous que Bahy devrait aussi s’implanter au Quebec pour faciliter ici aussi le lien entre les écoles et formateurs ? 

www.bahy.fr | 9 | 0 | 0 | 1w | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:47.433Z |  | 2025-11-28T19:50:01.823Z | http://www.bahy.fr/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7390213490692497408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHm8OufRlxw3A/feedshare-shrink_800/B4EZo9QAcnHUAg-/0/1761964198962?e=1766620800&v=beta&t=ZkuV-wXLlwSiuvfuOxqKOU_SgyWTFLTXh90TA4P1g8A | 🎃 Vendredi soir d’Halloween, 22h.

Je m’étais promis de décrocher un peu.
Mais une review GitLab sur mon projet Bahy m’a fait rouvrir VS Code.
Rien d’urgent, juste une petite remarque sur une merge request.
Et pourtant, impossible de ne pas y jeter un œil.

Je pourrais dire que je travaille tard parce qu’il le faut.
Mais non.
Je le fais parce que j’aime ça.
Parce qu’il y a quelque chose d’addictif à améliorer un composant, à traquer un détail de logique, à faire “mieux” que la veille.

J’ai passé plusieurs années dans le monde de l’art, et c’est dans le code que j’ai retrouvé cette sensation de construire quelque chose qui me dépasse un peu. Mais avec une dimension nouvelle : celle de la construction, de la structure, du raisonnement.

Le développement web m’a donné ce que je cherchais sans le savoir : une façon de créer utile.

Cette semaine encore, les refus se sont enchaînés.
C’est frustrant, bien sûr.
Mais chaque ligne que j’écris me rappelle pourquoi je continue.
Parce que c’est devenu plus qu’un métier, c'est devenu ma passion.

Alors oui, c’est Halloween.
Et pendant que d’autres chassent les bonbons, moi je chasse les bugs.
Pas par obligation.
Mais par passion.

Et si dans votre équipe, il manque quelqu’un qui code encore entre deux citrouilles… je suis peut-être celui qu’il vous faut. 🎃💻 | 12 | 0 | 0 | 1mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:47.434Z |  | 2025-11-01T02:29:59.708Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386340104258166784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGXGm1dZvJ2cw/feedshare-shrink_800/B4EZoGNJ8LJgAg-/0/1761040706229?e=1766620800&v=beta&t=6GJ3jaZfHYzIEAmSkum7F7y050MR0lJvvmS2CFN5Ti0 | Aujourd’hui, j’aimerais vous parler d’un projet qui me tiens particulièrement à cœur : La Selva De Concreto.

De 2020 à 2025, j’ai fondé et organisé la Selva de Concreto, un événement artistique multidisciplinaire qui réunissait le monde du hip-hop, de la peinture, du jazz, du tattoo et du street art.

🎤 +50 artistes, 🖼️ plusieurs disciplines, et plus de 300 personnes à chaque édition.
Un vrai défi, mais aussi une aventure humaine incroyable.

Dans les posts de cette semaine, nous explorerons les défis, apprentissages et différents enjeux rencontrés lors de l’organisation de tels événements et à quel point cette expérience peut être pertinente dans la gestion de projet en développement web. 

Pendant 5 ans, nous avons tout géré de A à Z (avec l’aide indispensable d’une équipe solide qui a évolué et s’est agrandie au fil des années):

 •	Programmation artistique (sélection, cachets, planification)
 •	Logistique et scénographie
 •	Communication & identité visuelle
 •	Gestion d’équipe et coordination terrain
 •	Relations partenaires et sponsors

Ce projet m’a appris autant sur la psychologie humaine, la communication, que sur la gestion de projet à 360°.
C’était un mélange d’art, de stratégie et de débrouillardise, un vrai laboratoire de créativité appliquée.

Aujourd’hui, je mets cette énergie et cette rigueur au service de ma reconversion dans le développement web et l’IA, sans jamais oublier d’où vient ma créativité. 🎨💻 | 5 | 4 | 0 | 1mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:47.435Z |  | 2025-10-21T09:58:32.418Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384158620843782144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHdxt4-MASUzg/feedshare-shrink_800/B4EZnibODnKgAg-/0/1760440414872?e=1766620800&v=beta&t=2VVzbQmMtUDvuTBO558mwqJKGbNjkpi58u4Dzc7seLw | On continue avec les postes portant sur l’IA.
Aujourd’hui, on parle de l’expérience exigée par certaines compagnies en intelligence artificielle.

🤖 “3 ans d’expérience en IA exigés.”

Les premières API d’OpenAI ont à peine trois ans.
Certaines technologies qu’on utilise tous les jours… n’existaient même pas en 2022.

Alors comment juger quelqu’un sur le nombre d’années passées à utiliser un outil
qui évolue plus vite que n’importe quel cursus académique ?

La vérité, c’est que dans ce domaine, l’ancienneté ou les diplômes n’ont jamais été un indicateur de compétence.

Ce qui compte aujourd’hui, ce n’est pas depuis combien de temps tu utilises l’IA,
mais comment tu l’utilises.

💡 Savoir comprendre ses limites.
💡 Savoir la guider pour amplifier ta logique, pas la remplacer.
💡 Savoir relier les bons outils entre eux pour produire plus vite, et surtout mieux.

Les meilleurs profils ne sont pas ceux qui “ont de l’expérience en IA”.
Ce sont ceux qui apprennent plus vite que l’IA n’évolue.

Parce qu’à la vitesse où la technologie avance,
chaque jour devient une nouvelle “année d’expérience”. | 9 | 0 | 0 | 1mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.543Z |  | 2025-10-15T09:30:06.242Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7383818722421161984 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFobyRo5r6Tgg/feedshare-shrink_800/B4EZnToBvoK0Ao-/0/1760192110958?e=1766620800&v=beta&t=Lc0mphfkZ9WuLvIsYS3tdN_I2F8Nvxsge8ajC5q093I | 🤖Toujours dans le cadre de ma recherche d’emploi, j’ai décidé de vous parler cette semaine de la place de l’AI dans le développement web. 

Ces derniers mois, on a vu passer beaucoup de titres alarmistes :

“L’IA va remplacer les développeurs d’ici 2025.”

“Le CEO d’Anthropic affirme que 90 % du code sera généré par l’IA.”

Mais au fond, est-ce vraiment la fin du métier… ou juste le début d’une nouvelle ère ? Ce n’est pas la première fois qu’une nouvelle technologie viens rebattre les cartes dans le domaine (frameworks nouveaux languages etc)

Quand le code devient automatique, la vraie valeur se déplace ailleurs.
L’IA sait déjà produire des lignes de code.
Ce qu’elle ne sait pas encore faire, c’est comprendre le “pourquoi” derrière le code.

Les profils qui mélangent vision produit, compréhension métier et créativité technique seront ceux qui tireront leur épingle du jeu.
Ceux qui savent penser un projet avant de le coder, relier les besoins réels à la solution, et donner du sens à la technologie.

C’est souvent le cas des profils venus d’autres univers, qui ont appris à coder avec l’IA, pas contre elle.
Ils ne voient pas le code comme une fin, mais comme un levier pour construire quelque chose de plus grand.

Quand l’IA automatise la production, la valeur humaine migre vers la conception :
🔹 la vision,
🔹 l’intuition,
🔹 la stratégie produit.

💭 Le futur du développement ne sera pas sans les développeurs.
Il sera sans ceux qui refusent d’évoluer. | 9 | 1 | 0 | 1mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.543Z |  | 2025-10-14T10:59:28.143Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7382369357458489345 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpGiKcVS8aZg/feedshare-shrink_800/B4EZnK3KGqHoAg-/0/1760045084781?e=1766620800&v=beta&t=MRWJxQqiYnBfFcVl3mHFE0oxYPEtPFKSRcXmIs0acbA | Dans le cadre de ma recherche d’emploi, je vous parle cette semaine de mon statut « junior » en développement web 💻

C’est un statut que j’avais du mal à assumer au départ,
mais je suis maintenant fier de m’affirmer en tant que junior dans le domaine ✨

On entend souvent qu’il faut des années d’expérience pour être vraiment efficace en tech.

Pourtant, il y a quelque chose que j’ai remarqué au fil de mes projets 👇

👉 L’enthousiasme et la fraîcheur d’un junior peuvent parfois apporter des solutions inattendues.

Par exemple, j’ai récemment travaillé sur un projet où l’on voulait utiliser du computer vision complexe.

En tant que junior, formé avec les outils les plus récents, j’ai proposé d’intégrer simplement un service existant (comme Document AI) ce qui a permis de gagner du temps et de l’efficacité ⚡

Bien sûr, l’expérience des seniors est précieuse, mais il y a un vrai avantage à avoir dans une équipe des juniors curieux, qui apportent un regard neuf et des solutions modernes 🤝

En fin de compte, mixer les approches, c’est ce qui fait la force d’une équipe 💡
Et je serais curieux d’avoir vos avis :

Avez-vous connu déjà vécu ce genre de situation ? | 10 | 0 | 1 | 1mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.544Z |  | 2025-10-10T11:00:12.608Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7381359544712740865 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF9NZMeiP93cQ/feedshare-shrink_800/B4EZm_bYyOIIAk-/0/1759853253428?e=1766620800&v=beta&t=7A1SY1QQ1Dpyg1Kr3hfkDXPLWZGhdMQpskZBZ8vtT3c | Ces derniers mois, j’ai beaucoup réfléchi à mon parcours.

Je me forme, je code, je construis, et pourtant, je reste à la recherche de ma première vraie opportunité en tech.
Alors aujourd’hui, j’avais envie de montrer ce qu’il y a derrière l’étiquette “junior”.

Mon parcours n’est pas classique, mais il est cohérent :

📘 2011 : Baccalauréat en France
🧮 2011–2013 : Classe préparatoire éco (maths, éco, logique)
🎓 2013–2017 : Baccalauréat canadien en économie à l’Université de Montréal (finance, commerce international, comptabilité)
🏦 2021-2023 : Conseiller financier chez Desjardins.
📊2023-2024: Data analyst en comptabilité chez Desjardins.
💼 2020–2025 : fondateur et producteur d’un événement artistique annuel (gestion complète : programmation, logistique, communication, partenariats, équipe, opérations)

En parallèle, j’ai suivi plusieurs formations continues :
 •	Chartered Financial Analyst (modules analytiques et financiers)
 •	Google Data Analyst Professional Certificate
 •	IBM Generative AI Professional Certification

Et surtout, j’ai appris à coder.
Aujourd’hui, je développe mes propres applications full-stack (React, TypeScript, Node.js, Strapi, Firebase), avec une vraie approche produit et design.

Mais ce que je veux surtout mettre en avant, ce sont mes compétences transférables : 

💡 Gestion de projet 360° → Rigueur et sens du delivery
Planifier, prioriser, livrer (que ce soit un événement ou une feature).

⚙️ Logistique & opérations → Fiabilité et anticipation
Savoir tout préparer en amont, identifier les risques, garder le cap sous pression.

🎨 Communication & marketing → UX/UI cohérente et claire
L’expérience utilisateur commence par la compréhension du public.

💬 Négociation & partenariats → Esprit d’équipe et clarté des objectifs
Créer du lien, aligner les attentes, faire avancer un projet collectif.

📊 Finance & data → Décision basée sur l’analyse
Comprendre les chiffres, les causes, les effets (pas juste les lignes de code).

Aujourd’hui, je suis un développeur junior, oui.
Mais aussi quelqu’un de travailleur, curieux, polyvalent, avec une vision produit globale.

Je crois sincèrement que la tech a besoin de profils qui savent connecter la technique, le business et l’humain.

Si vous cherchez quelqu’un d’autonome, impliqué et prêt à apprendre vite, je serais heureux d’en discuter | 20 | 3 | 0 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.544Z |  | 2025-10-07T16:07:34.488Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7379508024450793472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH59we_yX5X3g/feedshare-shrink_800/B4EZmc1hlIHgAg-/0/1759272902156?e=1766620800&v=beta&t=JtJ-6gCO6n9md2z4cqoJYTef-8r9xdW1zADNeNQSdYE | ✨ Nouveau CV ✨

Je viens de refaire mon CV pour mieux refléter mon parcours en développement full-stack (React, Node, Python) et intégration IA.
 Entre mes missions freelance (Bahy, Idéeal), mes projets SaaS persos (Wescott & Capdacier, NASTRAD) et mes expériences passées (finance & data), j’ai eu du mal à tout faire rentrer… Résultat : mon CV fait 2 pages.

👉 Du coup, j’aimerais avoir votre avis :

 1️⃣ Est-ce que 2 pages, c’est trop pour un profil comme le mien ?
 2️⃣ Trouvez-vous qu’il y a “trop d’infos”, ou au contraire que ça montre bien la diversité d’expérience ?

Votre retour m’aiderait beaucoup | 10 | 3 | 0 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.545Z |  | 2025-10-02T13:30:17.658Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7379138027245182976 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQES76rRSz32tw/feedshare-shrink_800/B4EZmS.2pFGYAg-/0/1759107579445?e=1766620800&v=beta&t=xUtnUcW6KDZnatEBjJAkT7rpuIkuSL9molF_wj9XBbc | On continue dans la présentation de mes derniers projets jusqu'a ce que je trouve un poste temps plein en développement. 
Aujourd'hui, j'ai décidé de vous parler d'un feature que j 'ai réalisé pour Bahy :

Lecture de screenshots automatisée par AI.

Le contexte & le problème

Les écoles envoient leurs besoins en professeurs sous forme de captures variées (photos d’écran, vrais screenshots, PDF, formats hétérogènes). Impossible d’industrialiser la saisie : c’est lent, source d’erreurs, et chaque maquette change. Il fallait un outil robuste capable de digérer tous ces formats, puis comprendre intelligemment où se trouvent les dates, créneaux et volumes d’heures demandés.


Le choix technologique (et les itérations)

Premier réflexe : Gemini Flash pour tout faire (OCR + compréhension). Résultat : rapide, mais insuffisant en OCR sur des images “réelles” (angles, qualité variable). 
J’ai donc combiné le meilleur des deux mondes :
Google Document AI pour un OCR fiable multi-formats,
Gemini pour la structuration sémantique (extraire dates, heures, classes, modules).

 Ce choix d’API a demandé des tests, comparaisons et compromis pour trouver une voie scalable qui tient sur tous les types de screenshots — un vrai travail de résilience produit/tech.


La solution livrée

 Un pipeline serverless : upload → Document AI (OCR) → Gemini (JSON structuré) → Excel (colonnes propres, dédoublonnage, formats normalisés). Côté admin, un drop & click clair, avec téléchargement XLSX immédiat.


L’impact

 Des heures de saisie économisées, une qualité homogène des données, et une équipe Bahy ravie du résultat. Au-delà du cas d’usage, c’est une démonstration de ce que l’automation peut apporter quand on marie les bons services cloud à la bonne logique métier.

Stack courte

 React + TypeScript + Tailwind • Firebase Functions • Google Document AI + Gemini • ExcelJS | 9 | 0 | 0 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.545Z |  | 2025-10-01T13:00:03.450Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7378783194298388480 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fa9aa420-764f-46a1-8e5e-ec62bbe8cd9c | https://media.licdn.com/dms/image/v2/D4E05AQElau_OUC8dOg/videocover-high/B4EZmXFrFiIUB8-/0/1759176479819?e=1765789200&v=beta&t=Eol6lZpirXphl6hZLW77xb8Gp4XekoBfkPY2-vDUF00 | APPLICATION WESCOTT ET CAPDACIER : PRESENTATION VIDEO

Dans cette vidéo (8 min), je vous montre un parcours complet au cœur de l’application :

 1️⃣ Inscription d’une compagnie et configuration de son profil.
 2️⃣ Connexion & publication d’une gig (quart de travail).
 3️⃣ Un technicien postule à l’offre.
 4️⃣ L’employeur accepte la candidature.
 5️⃣ Une fois accepté, le technicien peut “punch in” grâce à un QR code sécurisé au début de son quart.
 6️⃣ À la fin du quart, le technicien peut facturer directement la compagnie.

✨ Deux points importants mis en avant dans la vidéo :
La compagnie doit configurer les taux horaires des techniciens → base de la facturation.

Lors de la création de la gig, l’option “Call4” (4 heures minimum payées) a été choisie : le technicien facture donc 4h, même s’il a travaillé quelques minutes.

7️⃣ Enfin, on voit la validation et l’échange sur la facture, avec génération automatique d’un fichier Excel (via ExcelJS) pour ajustements si nécessaire.

🔑 L’objectif : simplifier et sécuriser tout le processus, de la planification des gigs à la facturation, en passant par la gestion des candidatures et le suivi des heures terrain.

👉 N’hésitez pas à me partager vos retours, que vous soyez dans l’événementiel, la tech ou simplement curieux de voir comment une telle solution peut transformer la gestion des équipes techniques. | 5 | 0 | 0 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.546Z |  | 2025-09-30T13:30:04.683Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7378443513312624641 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1Fl8qbuGI_w/feedshare-shrink_800/B4EZmNuxUhIIAk-/0/1759019474595?e=1766620800&v=beta&t=dDo5CRgXdplM2lCbDCr3AIhd8buOyJunCNcR0uXnGSk | Dans le contexte de ma recherche d'emploi en développement web, j'ai pensé qu'il serait bon de partager certains de mes projets récents :

Développeur Full-Stack — Projet Wescott & Capdacier
(Plateforme SaaS de booking pour techniciens de scène // Repo GitLab privé)

Dans le cadre de ce projet, j’ai conçu et développé une application complète permettant de connecter entreprises de l’événementiel et techniciens de scène.

 Les principales missions réalisées :

Analyse & structuration : compréhension des besoins métiers, découpage en tâches techniques, organisation du backlog.

Développement front-end : Next.js, React, TypeScript, intégration d’animations (Lottie), design responsive et UX mobile-first.

Développement back-end : Strapi (Node.js), création de collections (gig, gigrole, requests, timelogs, invoices…), endpoints custom (auth, punch in/out, facturation).

Gestion de données & workflows :
Création de gigs avec rôles techniques (slots, calltimes, couplage IN/OUT),
Système de candidatures avec validation/rejet,
Punch in/out avec timelogs,
Génération de factures et exports Excel.

DevOps & déploiement : conteneurisation avec Docker, hébergement cloud (Render, Vercel), configuration Postgres.

Design & branding : choix UI/UX, palette couleurs, icônes personnalisées, mise en place d’une identité visuelle cohérente.

Stack utilisée : Next.js, React, TypeScript, Strapi, Node.js, PostgreSQL, Docker, TailwindCSS, Framer Motion.

L'application est actuellement en phase de test

N'hésitez pas à m'écrire pour une visite guidée de l'application ou toute autre information. Il me fera aussi plaisir de lire vos commentaires et réactions.
Je reste à votre disposition pour des projets similaires.

PS : Je partagerais bientôt des captures d'écran video pour présenter l'interface plus concrètement | 12 | 0 | 0 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.547Z |  | 2025-09-29T15:00:18.425Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7375977761133187072 | Celebration |  | https://media.licdn.com/dms/image/v2/D4E2DAQGYmx_dieayow/profile-treasury-image-shrink_800_800/B4EZly7PSkGoAc-/0/1758569756697?e=1765789200&v=beta&t=IU30J48WqjSqmgK4KqTTROVa5_Qnwj2iBzDIBk48Hdg | J’ai le plaisir de partager avec vous ce projet, NASTRAD : Application d'analyse financière journalière, sur lequel j’ai travaillé. Découvrez-le ici : https://lnkd.in/ejt9RdnA | 12 | 3 | 1 | 2mo | Post | Yanis Nassi | https://www.linkedin.com/in/yanis-nassi-3331b1102 | https://linkedin.com/in/yanis-nassi-3331b1102 | 2025-12-08T08:01:51.547Z |  | 2025-09-22T19:42:17.294Z |  |  | 

---



---

# Yanis Nassi
*BAHY - Solutions écoles & formateurs*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [YB Digital](https://ybierling.com/en/podcast-yonumerique-yaniss-comment-apprehender-un-parcours-de-fondation-dentreprise)
*2026-09-10*
- Category: podcast

### [Cryptr | Authentication infrastructure for B2B](https://cryptr.co/blog/meet-our-customers-merciyanis)
*2022-12-20*
- Category: blog

### [Edtech: YaSchools uses technology to connect stakeholders](https://gulfbusiness.com/yaschools-using-technology-to-connect-stakeholder/)
*2023-09-16*
- Category: article

### [Re-establishing the School Radio: A Conversation with John Nahas - Educators](https://educators.learnquebec.ca/resources-edu/re-establishing-the-school-radio-a-conversation-with-john-nahas/)
*2023-07-26*
- Category: article

### [Interview with enorm magazin | Kabakoo Academies](https://www.kabakoo.africa/news/interview-with-enorm-magazin)
*2024-12-13*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
