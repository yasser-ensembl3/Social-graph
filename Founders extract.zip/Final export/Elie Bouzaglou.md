# Elie Bouzaglou

## Position actuelle

**Titre** : Founder
**Entreprise** : FishTank App INC
**Durée dans le rôle** : 9 months in role
**Durée dans l'entreprise** : 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

Elie Bouzaglo is the Founder, Designer, and Lead developer of Fishtank App Inc.



He began building the platform in April 2025 and launched a functional private beta on web, and is targeting Public Beta on both App Store and Play Store.

A self-taught developer since childhood, he has been building and rebuilding systems from the age of seven.

His early exposure to crypto, watching his father build a Bitcoin based business in 2018 shaped his belief that access drives innovation.

Fishtank is rooted in this principle, aiming to make early stage startups Discoverable, Buildable, and Fundable through an open, Collaborative ecosystem.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAFWCK7EBlwtqKumOfuSzZoigGK-_yJ_2UB4/
**Connexions partagées** : 4


---

# Elie Bouzaglou

## Position actuelle

**Entreprise** : FishTank

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Elie Bouzaglou

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403632388771270656 | Text |  |  | CONNECTIONS SHOULD MEAN MORE THAN
 + 500.
If you disagree, seep scrolling. 

🔜 https://fishtank.vc/apply | 0 | 0 | 0 | 3h | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.677Z |  | 2025-12-08T03:11:54.321Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7403469662316818432 | Text |  |  | Entrepreneurs don’t fail because they’re wrong.
They fail because they’re alone.

I’ve always believed every founder has two lists:
1.	The problems they talk about publicly
2.	And the problems they fight at 2:00 AM, alone, 
 Googling answers that don’t exist.

That’s why we built FishTank — think Stack Overflow for entrepreneurs, but designed for founders, freelancers, and investors who actually understand what you’re battling.

A place where:

• Founders get real answers from people who’ve 
 been in the same place
• Freelancers showcase expertise and land clients 
 by solving real problems
• Investors spot talent and strong operators long 
 before a pitch deck
• And the entire community levels up together

No pitching. No gatekeepers.
Just raw, practical knowledge from people building in real time.

If you’ve ever wished entrepreneurship had a “show me how” button…
This is it.
-> https://fishtank.vc/apply | 4 | 1 | 0 | 14h | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.677Z |  | 2025-12-07T16:25:17.311Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7403225262567628800 | Text |  |  | A friend told me he turned down a $12K project last week.
Client asked if his team could handle the full build.
He said "I don't have a team."
They hired an agency instead.
This is the fourth time this year.
But here's the thing:
He COULD form a team with other freelancers.
He knows people.
He just don't trust them not to flake.
Or make the money thing weird.
Or disappear after one project.
So he stayed solo.
FishTank Agencies (coming in V2) is fixing that.
Not by helping you FIND people.
By making it safe to actually BUILD with them.
How? I'll show you when we launch.
But if you've stayed solo because teaming up feels risky...
You'll get it.
https://fishtank.vc/apply | 1 | 0 | 0 | 1d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.678Z |  | 2025-12-07T00:14:07.870Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402068510157225985 | Text |  |  | Building FishTank because I got tired of the same conversation:

"Want to build this with me?"

"Sounds cool. What's it pay?"

"Equity and…."

"Oh. Yeah I can't do that right now."

Multiply that by 50 conversations and you get why this platform exists.

There's gotta be people out there who see equity as the upside, not the problem.

Designers who want to own what they create.
Developers who want a piece of something.
Founders who need believers, not employees.

That's who FishTank is for.

If that's you, we launch soon.

If not, cool. This probably isn't for you anyway.

https://fishtank.vc/apply | 2 | 0 | 0 | 4d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.678Z |  | 2025-12-03T19:37:36.604Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401757070980476928 | Article |  |  | FishTank is me being selfish honestly. I'm building the thing I wish existed when I started.

A place where you can say "here's what I'm building, who's in?" and actually find people to build with you.

Somewhere you can say “here's what I'm building" and actually find investors to back you.

Not people waiting for a salary.
Not people who need convincing.
Not investors who say “let’s circle back next quarter”
We launch soon. If you've felt this, you'll get why this matters.
https://fishtank.vc/apply | 0 | 0 | 0 | 5d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.679Z |  | 2025-12-02T23:00:03.718Z | https://fishtank.vc/apply |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7401729925789057024 | Text |  |  | I'm so tired of pitching.

Not pitching the idea. That part's easy.

I'm tired of pitching people to just WORK with me.

"Hey, want to build this together?"
"What's the pay?"

"I can offer equity and"
"Yeah let me know when you have funding."

Cool. So I'll just... build it alone then?

That's what most founders do. Build alone until they can afford not to.

FishTank is me being selfish honestly. I'm building the thing I wish existed when I started.

A place where you can say "here's what I'm building, who's in?" and actually find people who care.

Not people waiting for a salary.
Not people who need convincing.

Just people who see it and go "yeah, I'm in."

We launch soon. If you've felt this, you'll get why this matters. | 2 | 0 | 0 | 5d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.679Z |  | 2025-12-02T21:12:11.800Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7401339842376372225 | Text |  |  | Most platforms connect you with people who'll work FOR you.

FishTank connects you with people who'll build WITH you.

There's a massive difference.

When someone works FOR you:
- They clock hours
- They follow your brief
- They deliver and move on

When someone builds WITH you:
- They own a piece
- They challenge your ideas
- They care about the outcome

We're not building another Upwork.

We're building the place where founders find their co-founders.

Where “Freelancers” become equity partners.

Where investors see teams form in real time.

FishTank launches in a few weeks.

If you're tired of building alone, you're in the right place.

Waitlist in comments 👇 | 3 | 1 | 0 | 6d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.680Z |  | 2025-12-01T19:22:08.667Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7401220940216307712 | Article |  |  | Imagine if every time you got stuck building your startup…
there was a place to go where other founders actually answered. Honestly. Fast. No ego.

For years, I’ve felt like entrepreneurship has been this weird solo game.
You’re expected to figure out legal, product, fundraising, hiring, branding — all by yourself — while pretending you know what you’re doing.

Truth is, most of us don’t.

And that’s why I’m building something I wish existed on Day 1:

FishTank — think StackOverflow for entrepreneurs.
Ask anything. Share your wins. Share your mistakes.
Founders helping founders, minus the judgment.

But it’s not just that.

Because we all know advice is great… but funding decides everything.

So we added something I’ve never seen before:

Think TikTok for crowdfunding.
Instead of cold emails, pitch decks no one opens, or praying for replies —
you drop a short pitch, people scroll, and instantly signal interest.

A community where ideas get built and get backed.

If you’re a founder, a builder, a dreamer, or someone tired of doing this alone —
FishTank is for you.

We’re still early.
But if this sounds like something you actually need,
Enlist in the beta via the link below, or drop a comment. I’ll send you early access.

Let’s build the place we all wish we had when we started.
https://fishtank.vc/apply | 0 | 0 | 0 | 6d | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.680Z |  | 2025-12-01T11:29:40.183Z | https://fishtank.vc/apply |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400742957257097216 | Text |  |  | The hardest thing about startups isn’t failure.
It’s not knowing if you’re right… and having no one to ask.

FishTank exists for founders who are tired of second-guessing in silence.

Get unfiltered feedback.
See how other innovators think.
Pressure-test ideas before reality does it for you.

If you’re building anything right now — you belong here.
Join the public beta 
https://fishtank.vc/apply | 0 | 0 | 0 | 1w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.681Z |  | 2025-11-30T03:50:20.165Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7399474715410567169 | Text |  |  | Imagine if every time you got stuck building your startup…
there was a place to go where other founders actually answered. Honestly. Fast. No ego.

For years, I’ve felt like entrepreneurship has been this weird solo game.
You’re expected to figure out legal, product, fundraising, hiring, branding — all by yourself — while pretending you know what you’re doing.

Truth is, most of us don’t.

And that’s why I’m building something I wish existed on Day 1:

FishTank — think StackOverflow for entrepreneurs.
Ask anything. Share your wins. Share your mistakes.
Founders helping founders, minus the judgment.

But it’s not just that.

Because we all know advice is great… but funding decides everything.

So we added something I’ve never seen before:

Think TikTok for crowdfunding.
Instead of cold emails, pitch decks no one opens, or praying for replies —
you drop a short pitch, people scroll, and instantly signal interest.

A community where ideas get built and get backed.

If you’re a founder, a builder, a dreamer, or someone tired of doing this alone —
FishTank is for you.

We’re still early.
But if this sounds like something you actually need,
Enlist in the beta via the link below, or drop a comment. I’ll send you early access.

Let’s build the place we all wish we had when we started.
https://fishtank.vc/apply | 0 | 0 | 0 | 1w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.682Z |  | 2025-11-26T15:50:47.746Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7398546939417554944 | Text |  |  | Imagine TikTok for investing in startups.
Introducing Fishtank — an innovative platform destroying every boundary of how founders, creators, and investors meet, build, and fund new ideas.

For decades, startup discovery has been trapped inside pitch decks, cold emails, and “warm intros.”
Meanwhile, the world moved on.

So we rebuilt the experience from zero.

On Fishtank:

• Founders pitch their ideas through rapid-fire, swipeable videos
• Investors discover opportunities in seconds — not in six-week email chains
• Freelancers & interns can join early teams, not months after product-market fit
• Everyone participates in the same living ecosystem instead of scattered tools and broken workflows

No gatekeeping.
No outdated processes.
Just raw, unfiltered innovation — visible in real time.

Startups shouldn’t need to beg for discovery.
Investors shouldn’t drown in PDFs.
Talented creators shouldn’t have to guess where opportunity lives.

We’re building the bridge where all three finally meet.

This is the future of early-stage: fast, global, transparent, and built for 2025 — not 2010.

Fishtank.
Where ideas get seen.
Where founders get backed.
Where innovation stops waiting for permission.

If you’re a founder, creator, or investor… it’s time to jump in.

Join us today… or don’t 
Beta coming soon…
 https://fishtank.vc/apply | 1 | 0 | 0 | 2w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:08:56.683Z |  | 2025-11-24T02:24:08.712Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396993823341527040 | Article |  |  | Most people think founders are “risk-takers.”
Nah — We’re just delusional enough to think we can fix problems billion-dollar companies haven’t solved yet.

We’re the psychos who:
• Quit jobs and drop out of Ivy League schools 
 for ideas we sketched at 3am
• Hire interns before we hire ourselves
• Tell investors “we’re raising soon” (we’re not)
• Launch MVPs held together by duct tape, 
 StackOverflow, and a whole lot of prayer 
• Spend 3 hours choosing a logo and 30 seconds choosing a cofounder

And somehow… we’re still expected to build alone, hire alone, fundraise alone, and magically “make it work.”

Reality check:
You can be a great founder and still get destroyed by isolation.

That’s why I built FishTank.

Not for the wannapreneurs.
Not for the motivational-quote LinkedIn gurus.
 For the real ones surviving through chaos — founders, builders, freelancers, interns, investors — all in one place so you don’t waste 6 months searching for the people who actually move your startup forward.

If you’re done building in a vacuum, join the beta:

https://fishtank.vc/apply

Let’s be delusional together —  at least then it’s a  “strategy”. | 1 | 2 | 0 | 2w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.334Z |  | 2025-11-19T19:32:36.984Z | http://fishtank.vc/apply |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7396985374616514561 | Article |  |  | Being a founder is weird.
You’re building a startup…
but most days it feels like you’re building yourself.

You’re hunting for cofounders while trying not to lose confidence.
You’re pitching investors who want traction you can’t afford to build yet.
You’re trying to find talent who believes in your vision before the world does.
And you’re doing it all while pretending you “have a plan.”

Here’s the truth:
Founders don’t need more advice.
We need stronger networks — the kind you can actually tap into when things get hard.

That’s why I’m building FishTank.

Not another “social app.”
Not another “freelancer marketplace.”
Not another “startup community.”

FishTank is where early-stage founders, builders, interns, and investors actually meet, collaborate, and help each other move faster.
Real people. Real intros. Real work being done.

If you’re a founder building something ambitious — or someone who wants to help those who are — join the early beta.

https://fishtank.vc/apply

Let’s build the future with people who get it. | 0 | 0 | 0 | 2w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.335Z |  | 2025-11-19T18:59:02.651Z | http://fishtank.vc/apply |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7396576645240913920 | Text |  |  | This is exactly the contradiction that pushed me to build Fishtank.

Founders aren’t struggling because they’re “too early.”
They’re struggling because the market keeps moving the definition of “early.”

We keep calling it seed, but the expectations look more like a light Series A — revenue, traction, CAC/LTV clarity, even retention curves. Meanwhile, most real seed-stage founders are still in the trenches validating the concept, building the MVP, and trying to get that first 50 users to even care.

What founders need at that stage isn’t another “circle back when you have traction.”
They need:
• a community that actually understands early product building
• creators who can help them get attention before they can afford a team
• investors who evaluate potential, not polished dashboards
• and a place where early-stage work is visible, discoverable, and backed by reality — not legacy definitions of “seed”

That’s the gap we’re trying to fill with Fishtank:
a platform where founders, creators, and investors can collaborate before the metrics exist, because that’s when the real work begins.

If we want more innovation, we need to fund the phase where innovation actually happens.
Join the beta: https://fishtank.vc | 2 | 0 | 0 | 2w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.337Z |  | 2025-11-18T15:54:53.974Z | https://www.linkedin.com/feed/update/urn:li:activity:7395379907767320576/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7396574010685333504 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFJtfHVcLtMCg/feedshare-shrink_800/B56ZqVENDiJYAg-/0/1763437501989?e=1766620800&v=beta&t=TGLCLIOXTvwqWjZqEvBiuQC_MiIfCEubh_3jzZnPXZg | Matt Shoss 
 Absolutely.
Startups don’t live in boardrooms anymore — they live in feeds, group chats, niche communities, and creator ecosystems.

What you’re describing is exactly why were building Fishtank.

A lot of founders, creators, and even early-stage investors feel the shift… but they don’t have an actual place to operate in this new world.

So we made one.

A platform built for 2025 founders —
where distribution, collaboration, and capital actually happen in real time, not after “circling back next quarter.”

• Creators (freelancers and interns)  meet founders.
• Founders meet investors.
• Everyone operates at the speed culture moves.

It’s not about chasing trends — it’s about building where the new generation of startups already are.

The ecosystem evolved.
Founders evolved.
Distribution evolved.

Now it’s time for the infrastructure to evolve too — and that’s the gap we’re filling at Fishtank. | 0 | 0 | 0 | 2w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.339Z |  | 2025-11-18T15:44:25.847Z | https://www.linkedin.com/feed/update/urn:li:activity:7396532651052101633/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7395120226482176000 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFtyJbw1hHPng/feedshare-shrink_800/B4DZp0DaVnIkAk-/0/1762883644363?e=1766620800&v=beta&t=4xGmls-mI6megwaGnBaQpa9wefDkPK8pRO5lIpBYD-Y | Founders don’t struggle because of the idea.
They struggle because they’re expected to do 20 roles at once with zero support.

Execution is a team sport.
And the founders who win aren’t the ones with grit — they’re the ones who build the right team.

That’s why we built FishTank
See more https://fishtank.vc | 3 | 1 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.341Z |  | 2025-11-14T15:27:36.683Z | https://www.linkedin.com/feed/update/urn:li:activity:7394086525866606592/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7395086851180670977 | Text |  |  | Mira Maralova We’re past the point where founders need to slave over pitch decks that never get opened.

Your 20–30 second pitch is the real anchor. The rest should be optional.

That’s literally why FishTank exists. | 1 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.342Z |  | 2025-11-14T13:14:59.391Z | https://www.linkedin.com/feed/update/urn:li:activity:7393897827883720704/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7395083283937538048 | Text |  |  | Bitcoin dropped 7% today — and let’s be honest, nobody saw that coming.
Not you, not me, not the “experts.” And that’s the point: predicting markets is nearly impossible. It’s not your fault. It’s just the reality.

When you invest, you deserve to invest confidently — knowing what you’re investing in and who you’re backing.

That’s where FishTank comes in.

We’re opening access to early-stage startup investing in a way that feels natural, transparent, and intuitive.
You discover startups through a TikTok-style feed of 20–30 second pitches. You scroll, you watch, something catches your attention, you swipe to see more — full pitch deck, innovation profile, team, everything.

Simple. Human. Transparent.
You’re no longer guessing — you’re choosing.

Startup investing for everyone.
Join the upcoming public beta
https://fishtank.vc/apply | 0 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.343Z |  | 2025-11-14T13:00:48.894Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7394596858641166336 | Text |  |  | The reason you’re not getting funded?
Because traditional VCs have convinced you they’re the only option.
They box you in. They make you believe that if a VC doesn’t write the check, no one will.
But that’s simply not true.

There are millions of people with capital who are actively looking for ventures to back — artists, athletes, actors, creators, operators, even other founders.
They just haven’t had a platform to discover you… until now.

At FishTank, anyone can invest in your startup — as long as you, the founder, approve the terms. It’s that simple.

Upload your 30-second pitch + your full innovation profile.
Investors scroll through a TikTok-style feed, see your pitch, and if they like it, they swipe right to view your full Innovation profile.

You don’t need to wait for a VC to validate you.
Escape the VC trap.
Go where the investors actually are.
Join the upcoming public beta today at fishtank.vc/apply | 1 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.345Z |  | 2025-11-13T04:47:56.066Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7394431238184443904 | Text |  |  | Shaun Gold It’s not just that most startups fail — it’s that most never get a real chance to succeed.
Access to capital is still locked behind a system built for exclusivity, not creativity.

At FishTank, we’re opening that up — letting Founders, Investors, and Creators collaborate directly, and providing anyone with Capital the ability to fund the future.
Because maybe the problem isn’t that startups are too risky — it’s that very few founders get a chance. | 0 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.347Z |  | 2025-11-12T17:49:49.072Z | https://www.linkedin.com/feed/update/urn:li:activity:7394365069603676160/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7394252639712043008 | Text |  |  | David Y. VC isn’t broken because it bets on risk — it’s broken because it bets on exclusivity.
The power law exists because access is gated.

At Fishtank, we’re reimagining that.
Anyone with skill, time, or capital can help build — and share in the upside.
No gatekeepers. No “1 in 10,000” odds.
Just builders creating what’s next, together. | 0 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.349Z |  | 2025-11-12T06:00:07.878Z | https://www.linkedin.com/feed/update/urn:li:activity:7313269561271730177/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7394221776064573441 | Text |  |  | Berel Solomon I believe the real shift isn’t that employment is hard to find — it’s that people don’t want it anymore.
They want to build, not just work.
The days of trading time for a wage are ending — people want to create, own, and grow something that’s their apart of, 

That’s exactly why we’re building Fishtank —
a platform where Founders, Creators, and Investors connect to build startups together.
Not as employers and employees, but as collaborators building what’s next. 

What is an creator… On FishTank, a Creator is anyone who has a service they can offer to a Founder or a StartUp. 
This can be anything from development and marketing, to mentoring and market intelligence. As long as you aid startups, you belong on FishTank.
Find out more -> https://fishtank.vc | 1 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.350Z |  | 2025-11-12T03:57:29.411Z | https://www.linkedin.com/feed/update/urn:li:activity:7394196297857187840/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7394215179204464640 | Text |  |  | Completely agree — warm intros are a legacy feature of a system built for exclusivity.

At Fishtank, we’re building the opposite:
a platform where access is open, investors can be anyone with capital to deploy, and founders can connect directly without the middle layer.

Innovation shouldn’t depend on who you know — only on what you’re building. | 3 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.351Z |  | 2025-11-12T03:31:16.597Z | https://www.linkedin.com/feed/update/urn:li:activity:7393882683094925312/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7394213798192152576 | Text |  |  | For the past few months, we’ve been quietly building something new —
a platform designed to make startup building faster, more transparent, and more collaborative.

It’s called Fishtank — and it’s entering public beta soon.

Here’s what you’ll be able to do:

• Founders can create their startup profile, define what they need — funding, marketing, tech, design — and attract the right collaborators or backers.

• Creators can join startups directly, contribute their skills, and earn equity, commission, or fixed pay.

• Investors aren’t just venture funds.
They’re anyone with capital to deploy — whether you’re an entrepreneur, a professional, or someone who believes in backing innovation early.

Fishtank brings them all together — founders, creators, and investors —
in one ecosystem where collaboration replaces gatekeeping.

We’re currently in private beta, and opening up to new users soon.
If you want early access, join the waitlist — the next wave is coming
Apply —> https://fishtank.vc/apply | 4 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.352Z |  | 2025-11-12T03:25:47.338Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7393851577003847680 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF_YbIHOKtD2A/feedshare-shrink_800/B4DZpuyXoXG8Ag-/0/1762795293504?e=1766620800&v=beta&t=B2w4em1ls94x6HUMCh1aObsDwJYUeWw31nsXeuiAff8 | It’s interesting — we keep trying to fix venture through new fund structures, but maybe the real change needs to happen in access.
 If innovation can come from anywhere, capital formation should too.
That’s the thinking behind Fishtank — a platform where founders, creators, and investors collaborate directly to build and fund startups without the traditional bottlenecks of VC.
 The goal isn’t to replace venture — it’s to make it faster, more transparent, and more inclusive. | 4 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.353Z |  | 2025-11-11T03:26:27.077Z | https://www.linkedin.com/feed/update/urn:li:activity:7393699358090735617/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7393842536374517760 | Text |  |  | I didn’t grow up around venture capital — I grew up around crypto.
My dad was involved early on, and through him I saw what happens when access opens up:
anyone can participate, build, and own a piece of something bigger.

Crypto proved something powerful —
when access opens, innovation accelerates.
Not because of ideology,
but because opportunity drives performance.

That belief stuck with me.
If the future of money can be decentralized,
why can’t the future of innovation?

That’s why we're building 𝐅𝐢𝐬𝐡𝐭𝐚𝐧𝐤 —
a platform built on the belief that startups should be discoverable, buildable, and fundable
by anyone who the founder deems fit.

Here, founders, creators, and investors collaborate.
Each brings a different kind of capital — time, skill, or money —
and together, they build what’s next.

I’ve always believed investing should be open —
not limited to insiders,
but expanded to those who genuinely add value:
Funders, Creators, Investors.

We’re not replacing the system — we’re upgrading it.
Making startup building faster, more transparent, and more connected than ever. | 3 | 0 | 0 | 3w | Post | Elie Bouzaglou | https://www.linkedin.com/in/elie-bouzaglo | https://linkedin.com/in/elie-bouzaglo | 2025-12-08T07:09:00.355Z |  | 2025-11-11T02:50:31.623Z |  |  | 

---



---

# Elie Bouzaglou
*FishTank*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Fishtank Agency | B Corp™ | LinkedIn](https://uk.linkedin.com/company/fishtank-agency)
*2025-05-07*
- Category: article

### [AI Roundtable with Philippe Bouzaglou · Zoom · Luma](https://lu.ma/v0g85829)
*2025-07-31*
- Category: article

### [Elie Bou Faysal | Berytech](https://berytech.org/team/elie-bou-faysal/)
*2024-05-20*
- Category: article

### [Good News Business Round-Up featuring Fishtank Agency, EarthThings, Holden Smith and Accept Cards](https://huddersfieldhub.co.uk/good-news-business-round-up-featuring-fishtank-agency-earththings-holden-smith-and-accept-cards/)
*2024-02-05*
- Category: article

### [011: How a Navy Seal went from Garage to SHARK TANK to Millions in Revenue - Eli Crane of Bottle Breacher ⭐](https://podcast24.fr/episodes/entrepreneur-stories-4-inspiration-millionaire-interviews/-011-how-a-navy-seal-went-from-garage-to-shark-tank-to-millions-in-revenue-eli-crane-viMoc85VrW)
*2021-01-01*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
