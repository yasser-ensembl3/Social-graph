# Phil Siarri

## Position actuelle

**Titre** : Founder & Editor-in-Chief
**Entreprise** : Nuadox
**Durée dans le rôle** : 9 years in role
**Durée dans l'entreprise** : 9 years in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Nuadox is a media property producing, curating and aggregating insightful, uncommon innovation news and analysis.

## Résumé

Innovation strategist. Industry analyst. Publisher. Writer.

Based in Montreal, Canada, with multicultural and multilingual roots, I believe in a global, collaborative, and inclusive approach to innovation.

I’m the Founder and Editor-in-Chief of Nuadox, a media platform delivering global innovation news and analysis. I'm also the creator of The PhilaVerse, a Substack newsletter offering weekly, bite-sized tech content.

Over the years, I’ve worn many hats:

• Tech and business writer, with contributions on digital transformation, AI, and cloud computing.
• Former tech influencer with Foundry (IDG Communications), where I shared insights on enterprise technology trends.
• Published commentator on the global Fintech scene, with work featured in BankNXT, Financial IT, and more.
• Recognized thought leader, including:
 – Top 18 AI Media Influencers by Onalytica (2019).
 – 25 Healthtech Influencers to Follow by AI Time Journal (2020).
 – Top Writer in AI, Business, Technology, and Futurism on Medium (2019).
 – Top 40 Canadian Social Influencers in Finance and Innovation by Thomson Reuters/Refinitiv (2017, #11).
 – Top 50 Fintech Influencers in Montreal by FinFusion (2017).
 – Money Influencers in Canada by Hardbacon (2018–2024).
 – Invited participant, Canada 2020 Open Banking Policy Lab.

I bring a strong foundation in content strategy and digital marketing, including my time as Content Manager for most of Deloitte Canada’s industry and service lines (2012–2014), where I led data collection and localization for one of the largest web content migrations in Canadian history.

Other past projects include:
• KarTLad, a now-inactive world news aggregator recognized among Top 100 AI Websites by Feedspot.
• Strategic advisory roles in various tech ecosystems.
• A combined social media reach of 17,000+ followers.

📚 MBA, Cum Laude – Suffolk University (Boston)
📜 Certifications: ECMp, IGp, HubSpot Inbound
🎓 Also hold MBC and BBA degrees

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAC_OusBy0L8kFcPBzR4BtEUFN1VqXKLgr8/
**Connexions partagées** : 54


---

# Phil Siarri

## Position actuelle

**Entreprise** : Nuadox

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Phil Siarri
*Nuadox*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Is AI and journalism a good mix? - Phil Siarri - Medium](https://philsiarri.medium.com/is-ai-and-journalism-a-good-mix-83aaa1c3b14d)
*2019-06-24*
- Category: blog

### [Phil Siarri @philsiarri - Twitter Profile](https://twstalker.com/philsiarri)
- Category: article

### [phil siarri](https://nuadox.com/tagged/phil%20siarri)
*2024-04-03*
- Category: article

### [Phil Siarri, Editor in Chief](https://nuadox.com/philsiarri)
*2016-01-01*
- Category: article

### [Phil Siarri – Medium](https://philsiarri.medium.com/)
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Phil Siarri — Portfolio](https://psiarri.xyz/projects)**
  - Source: psiarri.xyz
  - *Phil Siarri. Innovation Research and Advisory - Recherche et Conseils en ... NUADOX: Croesus announces the launch of their innovation lab · DATA DRIVE...*

- **[25 Healthtech Influencers to Follow by 2020 - AI Time Journal ...](https://www.aitimejournal.com/25-healthtech-influencers-to-follow-by-2020/27517/)**
  - Source: aitimejournal.com
  - *... podcasts. Phil Siarri. Phil Siarri is the founder of Nuadox, a media property producing global innovation news and analysis. He is an IDG tech inf...*

- **[VR screen door effect? - Nuadox](https://medium.com/nuadox/vr-screen-door-effect-21614df8f90e)**
  - Source: medium.com
  - *May 28, 2017 ... Nuadox. In. Nuadox. by. Phil Siarri · Afrofuturism: When Art Meets Politics. Below is a presentation on Afrofuturism within the liter...*

- **[Digitizing the museum: A new kind of interaction | by Nuadox Crew ...](https://medium.com/nuadox/digitizing-the-museum-a-new-kind-of-interaction-dbcbf81b7cda)**
  - Source: medium.com
  - *Apr 9, 2018 ... Nuadox. In. Nuadox. by. Phil Siarri · Afrofuturism: When Art Meets Politics. Below is a presentation on Afrofuturism within the litera...*

- **[How to plan your trips e.g., how do you decide where to go and for ...](https://www.quora.com/How-do-you-plan-your-trips-e-g-how-do-you-decide-where-to-go-and-for-how-long)**
  - Source: quora.com
  - *Mar 15, 2016 ... Have s long playlist of music and audio books/podcasts. ... Phil Siarri. Founder of Nuadox | Tech Commentator | Digital Strategist. ·...*

- **[What are the best tools for Twitter chat transcripts and why? - Quora](https://www.quora.com/What-are-the-best-tools-for-Twitter-chat-transcripts-and-why)**
  - Source: quora.com
  - *Jan 31, 2011 ... More here: Dabney Porte on #SMManners [Podcast] ... Phil Siarri. Founder of Nuadox | Tech Commentator | Digital Strategist. · 8y. Rel...*

- **[Top 65 Money Influencers in Canada - Hardbacon](https://hardbacon.ca/en/financial-independence/top-money-influencers-in-canada/)**
  - Source: hardbacon.ca
  - *Feb 23, 2024 ... ... Podcast, available on most ... Phil Siarri is the founder and Editor in Chief of Nuadox, one of Canada's best financial technolog...*

- **[Which time is best for uploading content on Twitter? - Quora](https://www.quora.com/Which-time-is-best-for-uploading-content-on-Twitter)**
  - Source: quora.com
  - *Sep 13, 2022 ... Phil Siarri. Founder of Nuadox | Tech Commentator | Digital Strategist. · 8y. Related ... Another example, I know someone with a live...*

- **[Phil Siarri - Nuadox - State of Digital Publishing](https://www.stateofdigitalpublishing.com/digital-publishing/phil-siarri-nuadox/)**
  - Source: stateofdigitalpublishing.com
  - *Sep 28, 2017 ... The State of Digital Publishing interview series continues with Phil Siarri, the founder, and Editor-In-Chief of Nuadox.com, currentl...*

- **[Phil Siarri's Profile | Nuadox Journalist | Muck Rack](https://muckrack.com/philsiarri)**
  - Source: muckrack.com
  - *Find Phil Siarri of Nuadox's articles, email address, contact information, Twitter and more. ... Interview. See all 6 answers →. Have you ever used a ...*

---

*Generated by Founder Scraper*
