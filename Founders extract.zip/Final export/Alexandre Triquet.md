# Alexandre Triquet

## Position actuelle

**Titre** : Co-Founder  -  Executive Chairman
**Entreprise** : Reveal
**Durée dans le rôle** : 1 year 9 months in role
**Durée dans l'entreprise** : 1 year 9 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Medical Device

## Description du rôle

At Reveal Group, I lead the global vision, corporate strategy, and multi-sector expansion of our real-time molecular diagnostics platform. As Co-Founder and Chairman, my role is to align the long-term roadmap, secure strategic partners, and guide the evolution of Reveal Life Science across clinical, industrial, defense, and aerospace applications.

I work in close collaboration with our CEO, who leads day-to-day execution, clinical operations, and medical deployment, while I focus on mission alignment, strategic positioning, capital partnerships, and high-level market development.

I oversee:

Strategic direction and platform expansion

Key government, institutional, and industry relationships

Scaling Reveal’s presence across global health, defense, and remote diagnostic environments

My responsibility is to ensure that Reveal advances as the reference platform for real-time molecular intelligence worldwide.

## Résumé

At the helm of Tridan and its companies for over 15 years, I have dedicated myself to the development and strategic impact investments, primarily in Artificial Intelligence, high technology, biotech, photonic, diagnostic & therapeutic.


Some people see what is and ask why.
I dream of what could be—and work to make it real."

Founder and Chairman of Reveal, I lead the vision to make the invisible visible—and use the power of light and AI to transform life sciences, healthcare, security, and industry.


Reveal’s mission is simple and profound: save lives through earlier, faster, smarter intervention.
We are pioneering the future of molecular detection, real-time diagnostics, and intelligent health monitoring.  
Bringing A.I into science fact.

As Founder, I focus on strategy, innovation leadership, partnerships, and building a future where technology and humanity are not at odds, but in harmony.

If you share this vision or wish to collaborate to change the future, let's connect. The future of life depends on what we build today.

#LifeSciences #HealthInnovation #Photonics #ArtificialIntelligence

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAPXEh4BN_bnw5xdQ6q_e9Qqgsj00gn00ZQ/
**Connexions partagées** : 137


---

# Alexandre Triquet

## Position actuelle

**Entreprise** : Reveal

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Alexandre Triquet

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402483316903477248 | Video (LinkedIn Source) | blob:https://www.linkedin.com/393afd0e-beec-419f-91e5-cfbc4b2fe35a | https://media.licdn.com/dms/image/v2/D4E05AQEIpcHFzk7F3Q/videocover-low/B4EZrq9fNlHMBQ-/0/1764878587759?e=1765778400&v=beta&t=uzzzfMYOOlAUo2-twJnp7gik9_Kp8s-o86YWyPw46fU | Seeing Canada put purpose and responsibility at the heart of AI matters.
At Reveal, our researchers build tools that don’t just analyze data — they help doctors save lives in real time. Advancing science, with care for people. 🇨🇦🧬

Thanks @ Evan Solomon | 1 | 1 | 0 | 3d | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.143Z |  | 2025-12-04T23:05:54.239Z | https://www.linkedin.com/feed/update/urn:li:activity:7402437341056901120/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402335876107677698 | Article |  |  | Great to see leaders like @Evan Solomon recognize what’s happening in Montréal.
At Reveal Sentry our  light tech, our mission is straightforward: bring real-time molecular insight into the operating room so hospitals can deliver safer surgeries, faster decisions and better outcomes without increasing costs.
This isn’t just R&D anymore  it’s a market-ready platform built here, in Canada, and now scaling to surgeons, hospitals, and health systems looking for practical, high-impact innovation. When technology directly improves patient care and economic efficiency, it stops being a concept and becomes infrastructure.
Proud to build a solution that helps care teams do more, waste less, and deliver better results for patients and to do it from Canada, for global markets.
Anson Duran 

🔬🇨🇦 Smart care. Real impact. Made in Montréal.
#AI #HealthTech #SurgicalInnovation #Canada #Montreal #HospitalSystems #MedTech #RevealSurgical #SmartHealthcare #EfficiencyInCare


https://lnkd.in/e85qgURu | 7 | 0 | 0 | 3d | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.144Z |  | 2025-12-04T13:20:01.614Z | https://www.instagram.com/reel/DRccq7IDcBS/?utm_source=ig_web_copy_link&igsh=MzRlODBiNWFlZA== |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397694018245107713 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOCo1t5Ujm7w/feedshare-shrink_800/B4EZqnjagvKUAk-/0/1763747694861?e=1766620800&v=beta&t=ArlO5MyHO6hPNl5xqVCBbY-okCatKKwzh4F_xIa2s68 | Hier soir, j’ai eu l’occasion d’échanger avec
l’honorable Mélanie Joly , ministre de l’Industrie et du développement  économique du Canada pour le Quebec. Lors d’un souper où la conversation est rapidement allée au-delà des apparences.

On a parlé du rôle du Canada dans une économie mondiale en transformation,
et des défis très concrets que vivent nos innovateurs :
protéger notre propriété intellectuelle, fabriquer ici nos technologies notamment chez Reveal et Tridan Innovation 
et réussir à faire grandir nos idées sans devoir les exporter trop tôt.
À travers l’échange, j’ai senti une vision claire, une équipe solide…
et un réel intérêt pour comprendre ce qui se passe sur le terrain pour nous aider.

Rencontrer un leader à ce niveau, dans un cadre humain, change la perspective :

le leadership ne se résume pas à des décisions-il demande écoute, conviction et résilience.
Je repars inspiré.
Et très fier d’être Canadien.

#canada #innovation #canadainnovation #cancer
avec Sebastien Beauchamp | 53 | 2 | 0 | 2w | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.145Z |  | 2025-11-21T17:54:56.458Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397651359824777216 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHziyI1-9tXog/feedshare-shrink_800/B56Zqm0FGnHYAg-/0/1763735272998?e=1766620800&v=beta&t=6qjJjSPSuhybMppErIC3TUnK30rwC0MrHilJ9MfDnyI | L’année dernière, Exclaro / Reveal a eu l’honneur de recevoir le Grand Prix Acfas ainsi que le Prix du Jury.

Ce moment a été un véritable point d’inflexion : la science pouvait sortir du laboratoire pour entrer… en salle d’opération, en clinique, et même bientôt en pharmacie.
Depuis ce soir-là, nous avons poursuivi l’élan.

Nous avons transformé ce prix en plateforme technologique concrète — québécoise, francophone — qui permet de détecter l’invisible en temps réel grâce à la lumière et à l’IA.
💡 Voir ce que l’œil humain ne peut pas voir.
Pour mieux diagnostiquer. Pour prévenir. Pour sauver des vies.
Ce n’était pas une fin — c’était un mandat. Celui d’accélérer.

Voir aujourd’hui la communauté scientifique, les recteurs, les ministres et la relève réunis avec la même passion rappelle une chose essentielle :
le Québec peut éclairer le monde — en français — et en science.

Bravo aux lauréates et lauréats de cette année.
Et merci à l’Acfas de maintenir cette flamme vivante. | 3 | 0 | 0 | 2w | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.147Z |  | 2025-11-21T15:05:25.898Z | https://www.linkedin.com/feed/update/urn:li:activity:7397641920858144768/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7395162894897729536 | Text |  |  | We are deeply proud to welcome Costas Hadjipanayis to the Reveal Sentry™ ecosystem.
His arrival marks another defining moment for our mission.
Dr. Hadjipanayis is not only ONE OF THE WORLD leaders in neurosurgical oncology innovation  he is also Canadian-born, and his expertise strengthens the scientific backbone of what we are building.

At UPMC and the University of Pittsburgh School of Medicine, he holds major leadership roles across neurosurgery, brain tumor care, image-guided surgery, and nanotechnology. His impact on the field is recognized globally.
His guidance will be central as Sentry™ advances toward its pivotal trials, U.S. regulatory alignment, and international deployment. The support of leaders of his calibre confirms what we have always believed:

Sentry™ is not just a surgical tool — it is a global platform in surgical intelligence, shaped collaboratively with the world’s top neurosurgeons.

Welcome, Costas.
Your leadership and vision reinforce our commitment to bringing real-time molecular surgery to every operating room that needs it.
Christian Sauvageau Frederic Leblond Jean-François Lorrain François Daoust, Ph.D. Tridan Innovation
 #neurosurgery #oncology #Canada #MTC25 | 8 | 0 | 0 | 3w | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.148Z |  | 2025-11-14T18:17:09.626Z | https://www.linkedin.com/feed/update/urn:li:activity:7395091835532009472/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7390399690195902466 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEKtuODXqaODA/image-shrink_800/B4EZoDB06rKwAc-/0/1760987402963?e=1765778400&v=beta&t=3izKTvtRiwTxLdG8ze8hJ6Ye1soTUdhmD_9sZCehzBA | So proud to be here with our amazing team.... world breakthrough in Quebec Canada | 13 | 0 | 0 | 1mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.149Z |  | 2025-11-01T14:49:53.129Z | https://www.linkedin.com/feed/update/urn:li:activity:7386116595770728448/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7390355006203371520 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGLZA0KaafQZA/feedshare-shrink_800/B4EZo7RTJvJ0Ag-/0/1761930983991?e=1766620800&v=beta&t=5Gip__ASqsoxIXjC8s861tsAfGZYfUW9DmbWBxaf0tw | Proud moment seeing Québec innovation represented on the                      🌍 world stage!.... AGAIN in PALO ALTO California

At the Highlights from the @Silicon Valley Advantage Biotech Summit in Palo Alto, Reveal presented how our AI-powered molecular platform is transforming real-time cancer detection and tissue characterization.

It’s inspiring to see how AI from Canada  Québec is accelerating medical breakthroughs that are reshaping the future of diagnostics and surgery ,  bridging science, technology, and humanity.

Thank you to Carmen A. Zanfirescu, Charline Kempter, Mathieu Cormier and the entire Alexandre Triquet SVA Biotech community for highlighting this movement.
Christian Sauvageau, Frederic Leblond François Daoust, Ph.D. Michael S. Phillips Steve Moisan, Kevin Petrecca, Lanie Dufour
#AI #QuebecInnovation #MedTech #LifeSciences #Reveal
Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE)
Ministère de la santé et des services sociaux | 13 | 0 | 0 | 1mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.150Z |  | 2025-11-01T11:52:19.635Z | https://www.linkedin.com/feed/update/urn:li:activity:7390074181633323008/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7383939494955253763 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEi5AvZBC-Hmg/feedshare-shrink_800/B4EZnkF1gjGoAk-/0/1760468361105?e=1766620800&v=beta&t=qK1cUP9-9uSk_g3shb4D942sQOhpZ8wLZindaW42Tuo | Momentum in Surgery Innovation! 

Over the past two weeks after ALL IN, Reveal Sentry™ has been featured on three of the world’s most influential stages:

 🔹 The AANS/CNS Joint Section on Tumors Section Symposium (Los Angeles)
 🔹 Innovation in International Symposium of Neurology & Neurosurgery  (Los Angeles)
 🔹 The MedTech Conference Conference – The MedTech Conference powered by AdvaMed(San Diego)

The response has been nothing short of remarkable. Surgeons and leaders from North America, Europe, and Asia consistently shared the same message:

 ✅ The technology is ready for the OR
 ✅ The workflow fits seamlessly into surgery
 ✅ Real-time molecular guidance will transform cancer treatment

From Dr. Kevin Petrecca’s powerful clinical insights to Pr. Frederic Leblond pioneering science, supported all the team Christian Sauvageau our CEO by François Daoust, Ph.D. engineering leadership, we’ve seen unprecedented enthusiasm for Sentry’s pivotal trial and adoption worldwide.

Few technologies on Earth give surgeons molecular vision in real time during tumor surgery.
Momentum is accelerating, interest is global, and the demand is real.

This is Canadian innovation at the world stage — where cutting-edge science, AI, and clinical excellence converge.

For our governments, investors and strategic partners, this is a once-in-a-generation opportunity:

A proven breakthrough, global validation, and a market that is ready.
The future of AI-driven precision surgery is no longer a vision.
 It’s here. And Reveal is leading it.

#Neurosurgery #Innovation #AIForHealth #MedTech #SurgicalOncology #PrecisionMedicine #CanadianInnovation #HealthcareInvesting #VentureCapital #RevealSentry Nassim Ksantini, Michael S. Phillips, Jean-François Lorrain, Steve Moisan,Eric Dandurand, Juliette Selb, | 27 | 5 | 1 | 1mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.152Z |  | 2025-10-14T18:59:22.559Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7382647420687667200 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E10AQFAUD4WzwOMgQ/videocover-low/B4EZnN_j.AHgAk-/0/1760097617933?e=1765778400&v=beta&t=64NKZjw3pIKlRUezp9nGK_s1CvFa-dTIQtoB29IuAyw | Merci Mr Christian Dubé d'avoir pris le temps de venir assiter à cette première. | 13 | 0 | 0 | 1mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.153Z |  | 2025-10-11T05:25:08.048Z | https://www.linkedin.com/feed/update/urn:li:activity:7382384579468304384/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7381733747441741824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGramNcZvOu9w/feedshare-shrink_800/B4EZnEuVACGYAo-/0/1759942103688?e=1766620800&v=beta&t=0jVFFvmbyoyXhvXiGYqqFOSp4A0tAmH4ZCByaMNmzXQ | ✨ San Diego – The MedTech Conference powered by AdvaMed #MTC25
Proud moment for me as founder and Chairman to see our leadership — CEO Christian Sauvageau and CTO François Daoust, Ph.D. representing Reveal at The MedTech Conference on THE STAGE.

With Sentry™, we are giving surgeons the power to see cancer in real time, to guide surgery with light and AI, and to improve outcomes for patients worldwide.

We started in Paris at VivaTech then ALL IN Montréal, with a world-first live surgery is now being shared on the global stage. This is the essence of our mission:
transforming surgery from intuition to precision, from blind to visible.

I want to thank our extraordinary team,   visionaries, scientists, clinicians, and builders   who make this possible every day. Together, we are not just building a company, we are building the future of medicine.
✨ From light to insigh,  redefining surgical oncology with Reveal.

Frederic Leblond Michael S. Phillips Eric Dandurand Kevin Petrecca Steve Moisan 
#AdvaMed #MTC25 #MedTechInnovation #AIinSurgery #Reveal #CanadianInnovation | 22 | 1 | 1 | 1mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.155Z |  | 2025-10-08T16:54:31.371Z | https://www.linkedin.com/feed/update/urn:li:activity:7381732211668045824/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7380969805165748224 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGpGS3DqATxpQ/feedshare-shrink_800/B56Zm5451gHkAk-/0/1759760330219?e=1766620800&v=beta&t=JaPy9ljhebjNAed1WRbfpy43Wa50fQT_9mzM23_rLqM | 🌐 ALL IN 2025 – A historic week for AI & Health in Canada
What a week.    ''I’m late on this post, but for a good reason — things have been moving fast…”
At ALL IN 2025, Montréal, Canada and Reveal proved it can host an AI event of world-class calibre.
Thanks to SCALE AI - Canada's AI Cluster, Canada showed that AI innovation here is not just about theory — it’s about impact.
And just days later, with our partners at Le Neuro (Institut-Hôpital neurologique de Montréal)  (Centre universitaire de santé McGill | McGill University Health Centree,Polytechnique Montréall,CHUM - Centre hospitalier de l'Université de Montréall,Centre de recherche du CHUM (CRCHUM)), history was written:

The world’s first live surgery assisted by light and A.I  in real time  — using our Reveal Sentry™ platform.
This wasn’t a demo in a lab.!!
It was real.
It happened in Montréal.

And it showed the world that Canadian AI can serve people, directly, by saving lives.

We are proud that Reveal is one of the clearest examples that Canadian AI is not just competitive — it’s leading globally.
We’re not following.
We are among the first in the world to prove this technology works in real patients, in real surgeries.

🙏 SPECIAL thank you Minister Evan Solomonn (and your team, including Anson Duran &Peter Wall ) for supporting us, even coming to meet with us at ALL IN despite being called back to Ottawa.

🙏 Thank you to Christian Dubé, Minister of Health, who had the courage to attend our live brain surgery.
Not everyone can witness such a moment — and his presence showed real leadership and the importance of connecting innovation directly with public health.

🙏 Thank you INOVAIT Canada Clara MacKinnon-Cabral, Raphael Ronen, MSc, CFA) for backing our Pilot Fund.
🙏 Thank you to the leadership at SCALE AI - Canada's AI Cluster Isabelle Turcotte,Charlotte BA, Eric Aach, Patrick Ménard ) for making ALL IN a showcase at the level of the best international events.

And a special thank you to Peter Ross, our patient, who shared his story with courage — reminding everyone what this fight is about.
Canada has a unique opportunity: to prove that AI can and must serve people.

Reveal is proud to be one of the first to show it to the world.                       👉 Do you think Canadian AI should already be in the hands of surgeons?

Huge thank for our team at the show: Frederic Leblond, Christian Sauvageau, Kevin Petrecca,Michael S. Phillips,François Daoust, Ph.D..,  Then behind the scene:Reveal Explorer,Juliette Selb,Jean-François Lorrain,Eric Dandurand,Pierre Blanchard,Steve Moisan, US partners, : Christopher Cleary, Jonathan Martin

#ALLIN2025 #ScaleAI #EvanSolomon #INOVAIT #AIForHealth #MadeInCanada #RevealLifeScience #TechForChange | 54 | 5 | 2 | 2mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.156Z |  | 2025-10-06T14:18:53.339Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7378471306817708032 | Article |  |  | INNOVAIT Recipient Announce with The Minister EVAN SOLOMON ,
✨ Un moment de grande fierté pour nous chez Reveal.
Cette courte présentation, donnée en marge de l’annonce du INOVAIT Pilot Fund à ALL IN Montréal, mérite d’être visionnée.

L’hon. Evan Solomon, Ministre canadien de l’Intelligence artificielle et de l’Innovation numérique, a parlé avec clarté et conviction de l’importance de soutenir l’innovation canadienne — et de notre travail. Merci Monsieur le Ministre 🙏, vos mots et votre soutient comptent énormément.

En seulement quelques minutes, notre CEO Christian Sauvageau présente aussi un aperçu clair de notre technologie Sentry™ — qui combine IA et PHOTONIQUE pour permettre aux chirurgiens de détecter les marges tumorales en quelques secondes lors des chirurgies du cerveau et du sein.
👉 Je vous invite à regarder cette vidéo — un excellent résumé de qui nous sommes, ce que nous faisons et pourquoi cela compte.
 https://lnkd.in/ewks26N6

__________________________________________________________________
✨ A proud moment for us at Reveal Surgical.
 This short presentation, delivered on the sidelines of the INOVAIT Canada Pilot Fund announcement at ALL IN Montréal, is truly worth watching.

The Hon. Evan Solomon, Canada’s Minister of Artificial Intelligence and Digital Innovation, spoke with clarity and conviction about the importance of supporting Canadian innovation — and about our work. Thank you Minister     🙏🙏🙏🙏, your words mean a lot.🙏🙏🙏🙏

In just a few minutes, our CEO Christian Sauvageau also provides a concise overview of our Sentry™ technology — combining AI and Raman spectroscopy to help surgeons detect tumor margins in seconds during brain and breast cancer surgery.
👉 I invite you all to take a few minutes to watch this — it’s a powerful snapshot of who we are, what we do, and why it matters.
https://lnkd.in/ewks26N6

#INOVAIT #EvanSolomon #ALLIN2025 #AIForHealth #MadeInCanada #RevealLifeScience | 18 | 1 | 1 | 2mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.158Z |  | 2025-09-29T16:50:44.913Z | https://www.youtube.com/watch?v=t4wSBcAbbSk |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7377321027137196032 | Article |  |  | A World First, Live in ARTIFICIAL INTELLIGENCE I  and surgery at ALL IN and Le Neuro (Institut-Hôpital neurologique de Montréal)  🎥

Here is the official video of our historic live demonstration, held on the sidelines of ALL IN. 
For the very first time, an A.I. - and photonics-powered surgical tool was used live in the operating room.

🔬 Reveal SENTRY™ by Reveal gives surgeons real-time molecular vision, enabling them to immediately distinguish cancerous from healthy tissue.
 A concrete step forward for patients.
🙏 We were honored by the presence of Christian Dubé, Québec’s Minister of Health, and grateful to our researchers, hospitals, and partners who made this moment possible. Ministère de la Santé et des Services sociaux du Québec (MSSS)
✨ And this is only the beginning: many more announcements are coming at ALL IN. Stay tuned. 🚀
🔗 https://lnkd.in/e4wYrxQy


🇫🇷 Une première mondiale en direct du ALL IN et Le Neuro (Institut-Hôpital neurologique de Montréal)   🎥

Voici la vidéo officielle de notre démonstration historique réalisée en marge de ALL IN.
Pour la toute première fois, un outil chirurgical guidé par l’intelligence artificielle et la photonique a été utilisé en direct au bloc opératoire.
🔬 SENTRY™ de Reveal offre aux chirurgiens une vision moléculaire en temps réel, leur permettant de distinguer immédiatement les tissus cancéreux des tissus sains.
 Un espoir concret pour les patients.
🙏 Nous avons eu l’honneur de recevoir Christian Dubé, ministre de la Santé du Québec, et nous remercions nos chercheurs, nos hôpitaux et nos partenaires qui ont rendu ce moment possible.
✨ Et ce n’est qu’un début : 
Centre universitaire de santé Centre universitaire de santé McGill | McGill University Health Centre Centre, CHUM - Centre hospitalier de l'Université de Montréal Centre de recherche du CHUM (CRCHUM) Polytechnique Montréal,
La conférence de presse suivra sous peu  Restez à l’écoute. 🚀

🔗 https://lnkd.in/e4wYrxQy | 33 | 3 | 9 | 2mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.159Z |  | 2025-09-26T12:39:56.866Z | https://www.youtube.com/watch?v=LJmhO-0xTLw |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7377138565618561024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGRpJSfW4V6IQ/feedshare-shrink_800/B4EZmCbisTHgAg-/0/1758829883534?e=1766620800&v=beta&t=swDbt1DJ8zptN_OpBWx7ll5U9X0nLVSXufnf4yxQxWU | ✨ Un moment marquant pour Reveal et pour moi personnellement.
Ce matin, nous avons eu l’honneur de vivre une première mondiale en chirurgie guidée par l’intelligence artificielle et la photonique, au Neuro 
🙏 Je tiens à remercier chaleureusement M. Christian Dubé Dubé, ministre de la Santé du Québec, pour sa présence, son écoute et sa bienveillance. Vous avez été d’un soutien incroyable, et je suis fier de pouvoir compter sur un ministre aussi humain et engagé.
C’est grâce à des leaders comme vous, ainsi qu’à nos chercheurs, nos hôpitaux et nos partenaires @mme Lucie Opatrny, PDG de Centre universitaire de santé McGill | McGill University Health Centre, Mme @marie-eve Desrosiers PDG du CHUM - Centre hospitalier de l'Université de Montréal, Polytechnique Montréal, que nous pouvons bâtir ici, au Québec et au Canada, une technologie souveraine qui sauvera des vies.
Je suis tellement fier de ce que nous construisons ensemble, et j’ai déjà hâte de poursuivre ces échanges lors de notre prochaine rencontre. 🚀
Frederic Leblond Christian Sauvageau François Daoust, Ph.D. Michael S. Phillips Lanie Dufour 
#Innovation #Santé #IA #Québec #MadeInCanada #TechForChange | 32 | 8 | 1 | 2mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.160Z |  | 2025-09-26T00:34:54.650Z | https://www.linkedin.com/feed/update/urn:li:activity:7377067228677951488/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7374823650048507905 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSEJcafsdpsA/feedshare-shrink_800/B4EZlijBxxKsAk-/0/1758294974989?e=1766620800&v=beta&t=YZ3qk5uh9di6ClmVnHPS5kKxOUEU8UPEgWCSVT2yRsI | Rencontrons-nous à ALL IN 2025 🎟️ 

Je serai à ALL IN 2025, les 24 et 25 septembre à Montréal!

Joignez-vous à moi pour : 
✅ Découvrir les avancées concrètes de l’IA
✅ Échanger avec les leaders du secteur
✅ Vous inspirer et faire évoluer vos pratiques

Avec plus de 6 000 participants attendus, c’est le moment de bâtir des connexions fortes au cœur de l’écosystème IA.

On s’y retrouve? 👋

www.allinevent.ai 

#ALLIN2025 #Participant #Montréal #CommunautéIA
–
Let’s meet at ALL IN 2025 🎟️

I’ll be attending ALL IN 2025, taking place on September 24–25 in Montréal!

Join me to:
 ✅ Discover real-world AI breakthroughs
 ✅ Connect with leaders across the field
 ✅ Get inspired and advance your practices

With over 6,000 participants expected, this is the perfect opportunity to build meaningful connections at the heart of Canada’s AI ecosystem. 

See you there? 👋

www.allinevent.ai 

#ALLIN2025 #Participant #Montreal #AIEcosystem | 15 | 2 | 0 | 2mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.162Z |  | 2025-09-19T15:16:15.769Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7370504664393625600 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEteaEvAe_oAw/image-shrink_800/B4EZklK7glGYAc-/0/1757265247602?e=1765778400&v=beta&t=i6KZp8poDdb-R6KX7h5KkR4MlQZDOIeSmreZ-1VK0D0 | Riyadh. 15-17 September. This is where it starts.

I’m heading to Money20/20 Middle East this September - Where Money Does Business. It’s where partnerships form, strategies shift and the region’s fintech agenda gets real.

If you’re building, investing or shaping what’s next, let’s connect.

Who’s in? Discover your pass here: https://lnkd.in/eHrs9Fq3 

#Money2020MiddleEast #Fintech #Networking | 17 | 0 | 0 | 3mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.162Z |  | 2025-09-07T17:14:09.346Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7366067189721767937 | Article |  |  | Thank you to Evan Solomon for this inspiring feature in Mccleans.  Thanks to be our Canada’s first Minister of Artificial Intelligence and Digital Innovation, for his vision and leadership!. 🙏
In this interview, he describes AI as our “Gutenberg moment” and proudly highlights Reveal as a concrete Canadian innovation saving lives:
Reveal, a Canadian company, developed an AI-powered detection system that can help surgeons identify cancerous tissue in real time for the first time in the world”

At Reveal, we believe Canadian AI is not just theoretical but real, practical, and measurable — driving breakthroughs in surgery, diagnostics, health monitoring, and creating a global Google Map of Molecules powered by data.

🚀 And this is only the beginning: major announcements are coming, both in Canada and internationally. Get ready for September: a Canadian first with Reveal Explorer will be making headlines.
Thank you, Minister Evan Solomon — our true AI Champion — Anson Duran, and your entire team. Reveal is the concrete, measurable, and undeniable proof that Canadian AI can save lives — directly, nothing less. Thanks to visionary leaders like Minister Solomon and his team, these technologies will have a real and lasting impact on the health of our citizens. ✨
#AI #Innovation #HealthTech #Canada #Reveal #TechForChange Viva #Macleans #AIInnovation #HealthTech #CancerResearch #Oncology #IntelligenceArtificielle #LifeSciencesQuebec #InnovationCanada #CanadianTech #MadeInCanada

https://lnkd.in/ePRWw5Up | 19 | 4 | 1 | 3mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:42.163Z |  | 2025-08-26T11:21:12.940Z | https://macleans.ca/culture/evan-solomon-ai-digital-innovation-minister/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7357768164555776000 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | I’m pleased to announce that I have joined the Board of Directors of Nio Strategic Metals (TSX). This role will allow me to contribute to the strategic oversight of one of the world’s largest niobium resources located in Canada -  a critical mineral for defense, energy, and advanced technologies. | 37 | 7 | 0 | 4mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.468Z |  | 2025-08-03T13:43:51.152Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7355970388213788674 | Article |  |  | Quand l’IA Canadienne redéfinit la médecine
Merci au journal Le Soleil pour cet article qui souligne une avancée née ici, au Québec.
Ce qui avait commencé dans les salles d’opération comme un outil de guidage chirurgical devient aujourd’hui une plateforme capable de détecter le cancer a des niveaux moléculaires dans les tissus et les biofluides  en temps réel.
Les usages dépassent nos premières ambitions : dépistage préventif, chirurgie de précision, réponse aux pandémies, sécurité alimentaire et même applications industrielles.
C’est une révolution qui prouve que le Canada peut non seulement innover, mais inspirer le monde entier.

👉 Lisez l’article complet ici : https://lnkd.in/e2aFuz3B



When Quebec AI Redefines Medicine
Thank you to Le Soleil for highlighting this breakthrough born right here in Quebec.
What began in the operating room as a surgical guidance tool is now becoming a platform that detects cancer at the molecular level — in tissues and biofluids — in real time.
Its potential goes far beyond what we first imagined: preventive screening, precision surgery, pandemic response, food safety, and even industrial applications.
This is a revolution proving that Quebec can not only innovate, but inspire the world.
#Québec #Innovation #IA #MedTech #HealthTech #DeepTech #Cancer #Diagnostic #Santé #TechForChange #AIHealth #LifeSciences
Alexandre Bouchard @ | 35 | 1 | 2 | 4mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.469Z |  | 2025-07-29T14:40:07.871Z | https://www.lesoleil.com/affaires/2025/07/28/plus-dusages-que-prevu-pour-un-outil-quebecois-de-detection-de-cancers-5A6KIO2KIVAGXMTK77XSFFAIMM/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7349426318066782209 | Article |  |  | Un retour sur  REVEAL dans le Top 5  global à VivaTech 2025  Entrevue exclusive avec Richard Turcotte Salut Bonjour

Dans cette entrevue exclusive tournée à VivaTech Paris 2025, Alexandre Triquet, fondateur de Reveal Life Science, échange avec Richard Turcotte sur la percée technologique de son entreprise dans le domaine du diagnostic médical et de la chirurgie assistée par intelligence artificielle.

Reveal a été sélectionnée parmi les Top 5 finalistes mondiaux du concours "Tech for Change", se positionnant comme la seule entreprise canadienne à atteindre ce rang prestigieux parmi plus de 800 startups internationales. 🌍

Au programme de cette entrevue :

L’histoire derrière REVEAL et sa mission de révolutionner la détection du cancer, en salle d’opération et via les biofluides.

Les défis rencontrés et les prochaines étapes vers la mise en marché mondiale.

Une discussion franche sur l’importance de l’innovation canadienne sur la scène internationale.

Le rôle clé du Innovation, Science and Economic Development Canada particulierement notre nouveau Ministre de L'IA Evan Solomon ainsi que VivaTech et SCALE AI - Canada's AI Cluster dans la mise en lumière des technologies à impact.

🎯 Une technologie québécoise, une vision mondiale.

📌 Abonnez-vous pour suivre l’évolution de REVEAL et découvrir nos prochaines percées en santé, en environnement et en technologies de défense.

#VivaTech2025 #REVEAL #TechForChange #InnovationCanadienne #AI #DétectionDuCancer #Diagnostic #Startup #RichardTurcotte #Paris2025

https://lnkd.in/e5ErnEvK | 21 | 1 | 0 | 4mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.470Z |  | 2025-07-11T13:16:19.965Z | https://youtu.be/B8CmN3N4HqI |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7346305553930829824 | Article |  |  | Il y a déjà deux semaines, notre technologie a été mise en lumière par SCALE AI - Canada's AI Cluster , et par VivaTech dans le cadre du prestigieux concours "Tech for Change "
Félicitations  aux 8 entreprises  Canadiennes qui se sont illustrées parmi les 300 candidats retenus par Vivatech.

Et bien sur Reveal qui a été Awarded TOP 5 Global !!🇨🇦🙏💥


Grâce à ces formidables équipes canadiennes et françaises,

🙏🙏 Des annonces majeures s’en viennent.

Mais ce n’est pas pour nous que cette reconnaissance aura le plus grand impact 
C’est pour tous ceux qui se battent contre le cancer.
C’est pour eux que nous innovons. C’est pour eux que nous avançons.

Two weeks ago, our technology was spotlighted by SCALE AI | Canada’s Global AI Innovation Cluster, and by Viva Technology as part of the prestigious Tech for Change competition.
Thanks to the incredible Canadian and French teams behind these initiatives, 

Major announcements are on the horizon.

But this recognition isn’t about us 
 it’s about everyone fighting cancer.
They are the reason we innovate.
They are the reason we move forward. | 21 | 0 | 0 | 5mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.472Z |  | 2025-07-02T22:35:31.814Z | https://www.scaleai.ca/fr/delegation-canadienne-vivatech-2025/organisations/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7341497221156171776 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1ec9f19b-51d1-4640-9f72-67fb9e7bef97 | https://media.licdn.com/dms/image/v2/D5605AQHfBov1wfxDVw/videocover-low/B56ZeI8o4THoB0-/0/1750349311104?e=1765778400&v=beta&t=mdCg-fXHTPh2YkJthYDx7MDEiKqdJUfBqVXRDjLdHuw | Des émotions à VivaTech la semaine dernière? Une panoplie!

🙌 De notre nomination dans le TOP 5 Tech for Change du salon.
⏰ De l’arrivée tardive de notre appareil Sentry (jour férié le lundi).
‼️ De la perte de nos sondes par notre transporteur aérien… ‼️
👓 De lunettes “téléprompteur” finalement remisées après nos tests.
🎤 De mes trois pitchs sur les scènes de VivaTech.
💡 De la mise en lumière par l’équipe de SCALE AI - Canada's AI Cluster et l'aide logistique de #VivaTech.

De rencontres marquantes, qui sont, ou seront, des "game changers" pour notre technologie et son ambition : guider et sauver des vies.

...Et j’en passe!

Les émotions étaient à leur comble : Stress,  joie, enthousiasme, fierté, et toute la gamme…
Bref, au final, c’était magique! 🧙‍♂️

Un grand merci à Stéphane Lareau et Alexandre Bouchard pour leur participation et leurs efforts!
On a réussi, malgré les embûches, les tempêtes et les célébrations!

Voici une vidéo qui montre (une petite portion) de notre semaine intense et tout aussi gratifiante!

Merci de votre intérêt envers Reveal.
À très vite, Paris! 🛬

#vivatech2025 #top5techforchange #scaleai #reveal #emotions #helloworld | 34 | 2 | 2 | 5mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.473Z |  | 2025-06-19T16:08:55.946Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7341010147105787906 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGCTqQYlKdINg/feedshare-shrink_800/B56ZeCBzQBGQAg-/0/1750233202462?e=1766620800&v=beta&t=4sSGjxXsrfiVSEDWJeQxK3Cx0pD-69xPPcl-RoJOyko | 🚀 BREAKING:

It’s hard to capture what we lived at VivaTech 2025 in a single post 

Reveal and Reveal Explorer selected among the Top 5 GLOBAL “Tech for Change” companies at VivaTech 2025 🇨🇦🇫🇷

💥 Out of 600+ applications, only 5 were selected by VivaTech's prestigious jury (Bertrand Piccard, Marie Ekeland, etc.) for their global impact.

👉 We are proud to be ONE of them - with our technology Reveal Sentry, which gives surgeons for the FIRST TIME a vision to detect and remove cancer in real time.


📊 Some context:
🟣 180,000 attendees
🟣 14,000+ startups
🟣 171 nationalities
🟣 640,000+ business connections
🟣 326 startups certified “Tech for Change”
🟣 5 global finalists: 

🎤 We pitched 3 times, including on the Discovery Stage.
🤝 We met ministers, investors, global partners.
🧬 And we showed the world that Canadian innovation can save lives.

✅ Reveal Sentry: in-surgery devices, tissue diagnostics, cancer margins, surgical precision
✅ Reveal Biofluids: non-invasive analysis of saliva, urine, blood for early-stage disease detection
✅ Reveal Explorer: portable diagnostics for remote clinics, veterinary, food, and water safety
✅ Reveal Insight AI: our AI engine to interpret millions of spectral data points per second
✅ Reveal Atlas /Data Cloud: a global health data repository that can power research, pharma, and public health monitoring

Together, these tools are redefining how we detect, prevent, and treat disease at the molecular level.

🔬 But Sentry is only one piece of what Reveal is building.

We are creating a full platform of real-time diagnostics, powered by AI and Raman:

🗞️ We’ve now been contacted by multiple international institutions.

🌍 after France, I'm heading next to Brussels and Spain to accelerate 

💸 We’re raising — and looking for investors, and government partners to bring Sentry worldwide

To the entire VivaTech & SCALE AI - Canada's AI Cluster team and Canada: 🙏 thank you for your support.
This is just the beginning.


VivaTech SCALE AI - Canada's AI Cluster 
Costanza Liconti Hugues Foltz Isabelle Turcotte Charlotte BA Bertrand Piccard Marie Ekeland 
A special thank you for their interest in our work
MaRS Discovery District Health Canada | Santé Canada Mistral AI Eurazeo Google DeepMind GV (Google Ventures) Business France Ministère de la Défense 
Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE) Evan Solomon Mélanie Joly
Embassy of Canada in France | Ambassade du Canada en France 

📩 To press & media: happy to share more about our work at Reveal.

#Reveal #VivaTech2025 #TechForChange #Top5Global #AIForHealth #SurgicalTech #CancerDetection #HealthTech #CanadianInnovation #MedTech #LifeSciences #DeepTech #GlobalImpact #ScaleAI #InnovationForGood | 64 | 7 | 0 | 5mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.476Z |  | 2025-06-18T07:53:28.443Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7338687089326120971 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZdGs_DjbkPA/feedshare-shrink_800/B4EZdhBAK_HIAg-/0/1749679347199?e=1766620800&v=beta&t=z9wbLRNb5Uf7Vgj5IT7-CkZ5UwgR81tJ_uW4UK-HccA | Today, in Paris, I had the privilege and immense pleasure of representing Reveal's breakthrough technology at Europe's biggest Tech event: #VivaTech2025. 

Indeed, Reveal was selected as a Top 5 "Tech for Change" company, recognizing the tremendous impact and many potential applications our technology has.

On a personal note, I am truly honoured to represent #canada with SCALE AI - Canada's AI Cluster and the rest of the delegation.

Exciting breakthroughs were on display at VivaTech 2025 with AI to help humanity and Reveal, our advanced imaging and decoding of light signals was at the center. 

We had the privilege of showcasing our own evolution from real-time guidance during brain and breast cancer surgery to now enabling ultra-fast, precise diagnostics across health, environment and agri-food sectors. 

Our platform emphasizes sovereignty and speed in imaging-powered analysis. 

Truly demonstrating the transformative power of AI for critical sectors.

Meanwhile, Raman spectroscopy powered by AI gained the spotlight for its capabilities in rapid diagnostics, from drug development to pathogen detection. 

The synergy of light and AI is lighting the way for the future of medical imaging and beyond!

What innovations in AI-powered solutions are you most excited to see reshape your industry?

#vivatech #techforchange #scaleai #canada #reveal | 45 | 6 | 2 | 5mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.477Z |  | 2025-06-11T22:02:28.308Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7333839229711491073 | Document |  |  | 🎉
Reveal Life science – WORLD GLOBAL Top 6  FINALIST | Tech For Change Awards 2025 at VivaTech 🌍
It is with immense pride and deep emotion that I share this news: Reveal Reveal Explorer has been selected for the final  WORLD global finalists for the Tech For Change Awards at VivaTech 2025, Europe’s largest technology and innovation event.

Out of more than 300 purpose-driven startups, our Canadian technology  combining artificial intelligence and Raman spectroscopy   was recognized for its game-changing potential in healthcare, but also for its impact across multiple vital sectors: the environment, aerospace, defense, global  economy, and scientific research.  Our innovation brings to light what was once invisible, and redefines what technology can contribute to humanity  from saving lives to protecting our planet and advancing knowledge.

🙏 It is a profound honour for me and the entire team to represent  our country, to its researchers, institutions, and bold entrepreneurs who support meaningful and visionary innovation.
📍 Join us in Paris on June 11 for our final pitch in front of a world-class jury  and again on June 12 on the main stage for the awards ceremony.
Thank you to VivaTech, Axionable, Marie Ekeland, Charlie Perreau (Les Echos), Gwendal Bihan (Axionable) & Andrei Xydas (Lightrock) SCALE AI - Canada's AI Cluster, and all of our partners who make this journey possible.

This is more than recognition 
It’s a call to act, to innovate, and to save lives.

Alexandre Triquet
Founder , chairman, Reveal Life Science Reveal Explorer

 #statcan #cancer 
#VivaTech #TechForChange #RevealHealth #Canada #ProudlyCanadian #AIForHealth #HealthTech #DeepTech #CleanTech #SpaceTech #LifeSciences #InnovationThatMatters #TechForGood #FutureOfHealthcare #Spectroscopy #RamanAI #MedTechInnovation #HealthRevolution #SaveLivesWithTech #ScienceForGood #ImpactTech #GlobalInnovation
#CancerCanada #CancerQuébec #RechercheContreLeCancer #SoutienCancer #CancerAwareness #CancerResearch #CancerSupport #CancerSurvivor #Cancersucks #FuckCancer #BreastCancerAwareness #ColorectalCancerCanada #CanCertainty #FaceTheFight #FundTheFight #LightTheNight #LLSUSA #MothersDayWalk #ResearchMatters #NCSD2025 #InnovationQuébec #InnovationCanada #TechQuébec #StartupQuébec #StartupCanada #DeepTech #HealthTech #MedTech #LifeSciences #AIForHealth #CleanTech #SpaceTech #ScienceForGood #ImpactInnovation #FutureOfHealthcare #Spectroscopy #RamanAI #MedTechInnovation #HealthRevolution #SaveLivesWithTech #ProudlyCanadian #CIW24 | 38 | 11 | 4 | 6mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.480Z |  | 2025-05-29T12:58:48.507Z | https://www.linkedin.com/feed/update/urn:li:activity:7333793491325538304/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7333131110438129664 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5285190f-f160-4fbc-9965-9d1ab8682be0 | https://media.licdn.com/dms/image/v2/D4E05AQFkAmxdGHk4Lw/videocover-high/B4EZb.CAnOHYB0-/0/1748018663399?e=1765778400&v=beta&t=oscbK92ls50d9giQUGMLFkQOSbwnff6YHNVtOU4XaX4 | Reveal LIFE SCIENCE  at VivaTech 2025 |AI-Powered Innovation for Health and Wellbeing
As a Official Canadian Delegate, We are incredibly proud to announce that REVEAL has been recognized as one of the 10 most impactful Canadian companies by SCALE AI - Canada's AI Cluster and the Government of Canada,  at VivaTech 2025 in Paris

Even more exciting: I will have the incredible honor of taking the stage at "TECH for Change" to present our AI-powered optical technology, which helps surgeons detect tumor tissue more accurately and in real-time, among other applications. Only 2 companies from Canada out of 175+ worldwide have this unique opportunity.

This marks a significant milestone for our team, our mission, and our vision of creating a more precise, humane, and accessible healthcare system.

This is a significant moment for our team, our mission, and our vision of a more precise, humane, and accessible healthcare system.
Thank you to everyone who has supported us along the way. Let’s keep moving forward, together.
🔗 Discover more about the Canadian companies at VivaTech: https://lnkd.in/daEhbKch
#Reveal #VivaTech2025 #TechForChange #HealthTech #AIForGood #CanadaAtVivaTech #ScaleAI #AIMadeInCanada #FutureOfSurgery | 23 | 5 | 5 | 6mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.482Z |  | 2025-05-27T14:04:59.716Z | https://www.linkedin.com/feed/update/urn:li:activity:7332733512757768194/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7328110740337291264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE2x6PewFfIZA/feedshare-shrink_800/B4EZbKt4sfGQAg-/0/1747157748887?e=1766620800&v=beta&t=NSfEp0xymCyG_MutMmLcbzhPUDobvAWzE1fuV3HDHCU | 🚀Wow. NEWS!!!   What an honour.
I've just been selected to present Reveal Reveal Explorer on the Discovery Stage at VivaTech 2025  in front of the world.

I’ll have the privilege of sharing a keynote alongside only two other groundbreaking startups, as part of the prestigious Tech For Change recognition.

 📅 Friday, June 13th — 12:30 PM to 1:00 PM
We’ll be exploring one powerful theme:

 "Revolutionizing Healthcare: The Future of MedTech with AI and Advanced Technologies."

This is an incredible opportunity to showcase our revolutionary technology  developed with passion, science, and purpose, right here in Canada.
🙏 A heartfelt thank you to VivaTech and Axionable, ScaleAI and the Government of Canada of Canada for officially supporting our presence at VivaTech. Your trust gives us wings.
Let’s shine together. 🚀 | 11 | 0 | 1 | 6mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.482Z |  | 2025-05-13T17:35:50.210Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7325861780956528640 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQERimyEOEw9hw/feedshare-shrink_800/B4EZaqwd.oHoAk-/0/1746621555066?e=1766620800&v=beta&t=v_1amtmN-U9PbIUsUj6Ri5_AZw9RppY7PeqFucUwF-g | 🚀 NEW!🚀

It’s official Reveal (formerly Reveal Explorer) has been awarded the Tech For Change recognition by #VivaTech 2025, VivaTech, Europe’s largest tech event.
By receiving this recognition, we are now in the running to be selected as one of the six finalists.

We are honoured to represent ScaleAI and the Canadian Innovation in artificial intelligence and technology in Paris from June 11 to 14, 2025, alongside other visionary companies. SCALE AI - Canada's AI Cluster d’innovation mondiale du Canada en IA.

+450 speakers  2,800 exhibitors  + 165,000 visitors 13,500 startups 
174 countries 



Last call to join the movement 🌍

The Tech For Change Award at hashtag
#VivaTech 2025 celebrates startups using tech to tackle the world’s biggest challenges—climate, equality, inclusion, and beyond.

If you’re an exhibiting startup making real impact, this is your moment.
✨ Major visibility at VivaTech
🎤 Pitch live on stage
🏅 Winner announced on the main stage
📅 Apply by May 11 via the Tech For Change questionnaire, created with our partner Axionable.

Don’t miss your chance to be recognized👇 https://lnkd.in/eBNpNUix

hashtag

#VivaTech4Change hashtag
#Impact hashtag
#InnovationForGood
#VivaTech #VivaTech2025 #ScaleAI #Innovation #TechMadeInCanada hashtag #CanadaAtVivaTech 
#IA #IntelligenceArtificielle #CanadaInnovation #CanadianTech 
#MadeInCanada #AIforGood #DeepTechCanada #MontrealTech 
#LifeSciencesCanada #EUInnovation #FutureOfHealth #GlobalTech 
#HealthTechEurope #ParisTech #DeepTechEU #TechForHumanity #InnovationForImpact#FutureIsNow #HealthTech #MedTech 
#AIHealthcare

#Biotech 
#RealTimeDiagnostics 
#CancerDetection
#BrainTech 
#WomenInTech 
#DigitalHealth | 26 | 2 | 4 | 7mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.485Z |  | 2025-05-07T12:39:16.510Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7325491904886812673 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHNnzyhGr_wkg/feedshare-shrink_800/B4EZalgEM0HoAk-/0/1746533369596?e=1766620800&v=beta&t=rvGiKBTcQxybRtTb6CDZqKGi0xpdL-ZgX8hXsJfX4DM | 🚀 Big centralized labs are the past. The future of diagnostics is mobile, intelligent, and real-time.

The future of diagnostics isn’t about bigger labs — it’s about faster, smarter, distributed decision-making.
The CAP Today article highlights the urgent shift laboratories must embrace to thrive in value-based healthcare.
 At Reveal Life Science and Exclaro, we are actively building this future:
Real-time molecular detection,
Reagent-free technology,
Portable, point-of-care solutions,
Applied in surgery, oncology, early diagnostics, industrial health, and even space missions.
We enable earlier intervention, lower costs, and better clinical outcomes — delivering exactly what the future of healthcare demands.
See the unseen. Act in real time.

https://lnkd.in/e7EuNAsG
CAP TODAY Recommends >> The future of clinical laboratories in value-based care—Is this our tomorrow to lose?

The future of clinical laboratories in value-based care—Is this our tomorrow to lose?

College of American Pathologists (CAP)(CAP) 
American Cancer Society Society for Clinical Pathology (ASCP) 
American Society of Clinical Oncology (ASCO) Society for Clinical Laboratory Science 
@Commission on Laboratory Accreditation (COLA) 
American Association for Cancer Research for Diagnostics & Laboratory Medicine
Association Of Computer and Data Science | NSBM for Diagnostics & Laboratory Medicine
Association for Diagnostics & Laboratory Medicine | 15 | 1 | 0 | 7mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.486Z |  | 2025-05-06T12:09:31.183Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7318322988171288577 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEMLfwymtHnMQ/feedshare-shrink_800/B4EZY_n.cXHcAk-/0/1744824166653?e=1766620800&v=beta&t=-kbv32Hq6Ck4D6ZsUfnnBCw3doKC27gOEENj31r8ULQ | Honored to be invited to the private luncheon with the Utah Governer Spencer Cox and the State of Utah delegation in Montreal last week.
It was a great honor to sit at the table with @UtahSenator, Robert P. Sanders. Consul General , U.S. Department of State, also to have a pleasure to discuss with Senator Kirk Cullimore, Franz Kolb the Director of international Trade and Diplomacy of the Utah Governor's Also Connie Irrera at the US department and commerce Office and inspiring leaders to discuss tariffs, regulation, and — more importantly — the tremendous opportunities between Quebec, Utah, and the U.S.
At Reveal Our AI technology is purpose-built to save lives — from cancer to food fraud, avian flu, and threats to livestock. But it needs strong infrastructure and strategic partners, from hospitals to defense and space exploration. We see in State of Utah not only a powerful tech ecosystem, but a genuine human and environmental commitment that resonates with us deeply.
The Governer Spencer Cox and the State of Utah delegation showed a true affection for @Quebec and belief in our shared values. We must never lose faith in our American family — storms pass, but people of heart remain.
Thanks to the Mathieu Cormier and Invest Quebec | Investissement Québec International American Chamber of Commerce in Canada American Chamber of Commerce in Canada (AmCham Canada)),  and all those building bridges between our regions. The best is ahead. | 11 | 0 | 0 | 7mo | Post | Alexandre Triquet | https://www.linkedin.com/in/alexandre-triquet-a526ab19 | https://linkedin.com/in/alexandre-triquet-a526ab19 | 2025-12-08T05:12:47.486Z |  | 2025-04-16T17:22:48.246Z |  |  | 

---



---

# Alexandre Triquet
*Reveal*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 7 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [Alexandre Triquet Email & Phone Number | Founder | CEO Chairman Reveal & Tridan | Leading Optical & AI-Powered early Cancers & deseases biofluids Detection & Surgical guidance  | Scaling Innovation to Save Lives. - ContactOut](https://contactout.com/Alexandre-Triquet-32963770)
*2025-06-05*
- Category: article

### [Alexandre Triquet - TRIDAN INNOVATION - CEMDI](https://cemdi.inrs.ca/member/alexandre-triquet/)
*2025-04-01*
- Category: article

### [Reveal | LinkedIn](https://fr.linkedin.com/company/reveal-surgical?trk=public_profile_experience-item_profile-section-card_subtitle-click)
*2025-04-15*
- Category: article

### [ReEcho 2024](https://www.reecho.com/post/alex)
*2024-07-19*
- Category: article

### [Introducing Reveal - Reveal - Medium](https://reveal-platform.medium.com/introducing-reveal-7b47e0897178?source=user_profile---------5-------------------------------)
*2021-08-25*
- Category: blog

---

## 🎬 YouTube Videos

- **[Entrevue Salut Bonjour Alexandre Triquet VIVATECH](https://www.youtube.com/watch?v=B8CmN3N4HqI)**
  - Channel: Reveal Channel
  - Date: 2025-07-11

- **[Mon Carnet du 26 septembre 2025](https://www.youtube.com/watch?v=qfQqkzys6oc)**
  - Channel: Mon Carnet - Le Podcast
  - Date: 2025-09-28

- **[Historic World-First: Live Cancer Surgery with A.I  with REVEAL Sentry™](https://www.youtube.com/watch?v=j3SVljF76rA)**
  - Channel: Reveal Channel
  - Date: 2025-10-02

- **[Reveal Neuro 25 sept PRESS CONFERENCE complete](https://www.youtube.com/watch?v=DTa9g4M-41k)**
  - Channel: Reveal Channel
  - Date: 2025-10-02

- **[World-First A.I &amp; Surgical Revolution | REVEAL Sentry™ Live in Montréal](https://www.youtube.com/watch?v=yrgDFVn_jqM)**
  - Channel: Reveal Channel
  - Date: 2025-10-02

- **[🎥 Première mondiale historique : chirurgie du cancer en direct avec REVEAL Sentry™](https://www.youtube.com/watch?v=F5FlKQNmUM0)**
  - Channel: Reveal Channel
  - Date: 2025-10-02

- **[Traitement du cancer: l’intelligence artificielle à la rescousse !](https://www.youtube.com/watch?v=ugdYq_ISYsI)**
  - Channel: QUB - radio / télé / balado / vidéo
  - Date: 2024-07-09

---

## 🔎 Press & Mentions

- **[Reveal : Quand l'IA devient un allié vital contre le cancer – Mon Carnet](https://moncarnet.com/2025/10/02/reveal-quand-lia-devient-un-allie-vital-contre-le-cancer/)**
  - Source: moncarnet.com
  - *Oct 2, 2025 ... Mon Carnet, le podcast · {ENTREVUE} - Reveal : Quand l'IA devient un ... Alexandre Triquet, fondateur et président de Reveal, une jeun...*

- **[Traitement du cancer: l'intelligence artificielle à la rescousse ...](https://www.youtube.com/watch?v=ugdYq_ISYsI)**
  - Source: youtube.com
  - *Jul 9, 2024 ... ... Alexandre Triquet, PDG du groupe Reveal Surgical et Exclaro....*

- **[Mon Carnet du 26 sept 2025 – Mon Carnet](https://moncarnet.com/2025/09/26/mon-carnet-du-26-sept-2025/)**
  - Source: moncarnet.com
  - *Sep 26, 2025 ... Mon Carnet, le podcast · Mon Carnet - 26 septembre 2025 Mon Carnet, le podcast ... Alexandre Triquet (Reveal) : Une technologie québé...*

- **[News — Tridan](https://tridan.org/news)**
  - Source: tridan.org
  - *Interview Emmanuelle Lévesque 2024-07-11 Interview Emmanuelle Lévesque 2024 ... Entrevue avec Alexandre Triquet, PDG du groupe Reveal Surgical et Excl...*

- **[2025 Sessions | Vivatechnology](https://vivatechnology.com/sessions/partners/2025-06-14)**
  - Source: vivatechnology.com
  - *Jun 14, 2025 ... [REC] Interview VivaTech 2025 – Yann LeCun, VP & Chief AI Scientist chez Meta ... Alexandre Triquet. REVEAL. Tesla. June 14. 3:00 PM ...*

- **[Alexandre Triquet Chairman founder at REVEAL](https://vivatechnology.com/speakers/ffa4bc52-5d1f-f011-8b3d-6045bdf3ac94)**
  - Source: vivatechnology.com
  - *Alexandre Triquet. Photo Alexandre Triquet. Alexandre Triquet. Chairman founder. REVEAL. #. Artificial Intelligence. Deep Tech & Quantum Computing. Fo...*

- **[A transformation in neurosurgery | The Neuro - McGill University](https://www.mcgill.ca/neuro/channels/news/transformation-neurosurgery-368012)**
  - Source: mcgill.ca
  - *Sep 25, 2025 ... ... conference in Paris. However, demonstrating right here in ... Alexandre Triquet, Co-Founder and Executive Chairman, Reveal Quebec...*

- **[Reveal A.I. : quand l'IA apprend à lire la lumière pour comprendre la ...](https://vivatechnology.com/sessions/session/01121f30-dc3f-f011-a5f1-6045bda07d25)**
  - Source: vivatechnology.com
  - *... et des environnements complexes. Speakers. Photo Alexandre Triquet. Alexandre Triquet. Chairman founder. REVEAL. Partners. Canada Pavilion | Pavil...*

- **[Plus d'usages que prévu pour un outil québécois de détection de ...](https://www.lesoleil.com/affaires/2025/07/28/plus-dusages-que-prevu-pour-un-outil-quebecois-de-detection-de-cancers-5A6KIO2KIVAGXMTK77XSFFAIMM/)**
  - Source: lesoleil.com
  - *Jul 28, 2025 ... Cofondateur et principal actionnaire de Reveal Surgical, Alexandre Triquet ne cachait pas son enthousiasme à la suite des développeme...*

- **[Une technologie conçue au Québec pour détecter les tissus ...](https://www.journaldemontreal.com/2024/07/11/une-technologie-concue-au-quebec-pour-detecter-les-tissus-cancereux-pourrait-bientot-se-retrouver-dans-les-blocs-operatoires-du-monde-entier)**
  - Source: journaldemontreal.com
  - *Jul 11, 2024 ... ... Alexandre Triquet, PDG du groupe Reveal Surgical et Exclaro. Mais ... article publié dans la prestigieuse revue scientifique Natu...*

---

*Generated by Founder Scraper*
