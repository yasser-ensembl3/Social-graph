# Arnaud Montpetit

## Position actuelle

**Titre** : Conseiller d’affaires principal
**Entreprise** : Inno-centre
**Durée dans le rôle** : 8 months in role
**Durée dans l'entreprise** : 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Consulting and Services

## Résumé

Qu’il soit question de transformation numérique, d’efficacité opérationnelle ou d'innovation; les enjeux hors-normes auxquels font face nos organisations auront besoin de solutions hors normes. Pourtant, le coffre à outils de nombreuses organisations est incomplet lorsque vient le temps de développer des stratégies, d’innover et de voir à l’extérieur de la logique de leur industrie. 

Pour pallier cette situation, je vulgarise les concepts de design organisationnel, je crée des outils simples à implanter, et j’accompagne mes partenaires dans leur réflexion stratégique. Ce même sens du devoir me pousse à continuer mes études au 3e cycle et à enseigner au baccalauréat et au MBA pour cadres de l’Université de Sherbrooke.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAOEYKkB3-PEZudriigREqieP75WqyIH4Rw/
**Connexions partagées** : 120


---

# Arnaud Montpetit

## Position actuelle

**Entreprise** : IC Canada | Inno-centre

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Arnaud Montpetit

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399853921860747264 | Text |  |  | Une des raisons pour lesquelles j’ai démarré pivotal : je m’ennuyais de travailler avec les PME.

Quand on dit que le Canada doit augmenter sa productivité, et quand on sait qu’environ 65% des travailleurs du secteur privé œuvrent au sein d’une PME, le lien n’est pas difficile à faire : des PME plus efficaces égalent un Canada plus prospère.

Avec chaque nouvelle organisation que j’accompagne, je suis toujours fasciné par la complexité du rôle de gestion dans une PME. Pour bien faire son travail, une personne gestionnaire doit continuellement naviguer entre le stratégique, le tactique et l’opérationnel. C’est une prouesse qui génère une charge mentale considérable.

Le matin, elle prend une décision qui influence l’avenir de l’organisation, à l’heure du lunch, elle cherche une pièce de rechange pour une machine défectueuse, et l’après-midi, elle offre son opinion sur une embauche.

Dans les grandes entreprises, les responsabilités sont souvent réparties entre différents niveaux de gestion, ce qui permet à l’équipe exécutive de se concentrer exclusivement sur la stratégie. Ce n’est généralement pas le cas dans une PME.

Mon constat jusqu’à présent : il est très difficile pour une seule personne d’être à l’aise sur les trois paliers à la fois. Certaines excellent dans la stratégie, d’autres dans l’opérationnel, et d’autres encore dans la capacité de faire le pont. Mais ce n’est pas toujours explicité au sein d’une équipe, ce qui peut créer un déséquilibre.

Une personne orientée vers l’opérationnel aura naturellement tendance à s’entourer de profils similaires, ce qui peut mener à une vision stratégique plus floue et à du court-termisme. Une personne portée vers la stratégie privilégiera plutôt les profils de stratèges, au risque de s’éloigner de la réalité du terrain.

Si vous occupez un rôle de gestion, posez-vous la question : sur quel palier êtes-vous le plus à l’aise? Et comment votre organisation maintient-elle l’équilibre entre ces trois paliers pour être capable d’imaginer le futur sans perdre de vue le présent? | 51 | 2 | 0 | 1w | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:45.098Z |  | 2025-11-27T16:57:37.609Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396574902130065408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFjdZh7FFOVEA/feedshare-shrink_1280/B4EZqXpriWKsAs-/0/1763480877629?e=1766620800&v=beta&t=FPl90b3hbjRnz0jiHgjKY3HM_1bWF4mwNdSA-8YLupM | Il y a quelques années, je n’entendais pratiquement jamais le terme « modèle d’affaires ».

Oui, c’est un concept qui existe depuis toujours, mais il n’était pas réellement discuté de façon stratégique : c’était une manière d’opérer. Si vous connaissiez sommairement vos clients et vos sources de revenus, vous connaissiez votre modèle d’affaires. Sujet clos.

Quand j’essayais d’amener (souvent maladroitement) les avancées issues de la littérature sur le sujet, je me faisais regarder avec scepticisme. Certains percevaient même comme une insulte le simple fait de suggérer qu’il pouvait y avoir un enjeu stratégique lié à leur modèle d’affaires.

Aujourd’hui, plus de vingt ans après la publication du premier article sur le Business Model Canvas par Pigneur et Osterwalder, je sens un réel intérêt autour de moi. De plus en plus de gestionnaires y reconnaissent une véritable valeur stratégique et abordent le sujet avec curiosité et ouverture.

Si vous faites partie de ces curieux, mon ouvrage préféré sur le sujet, The Business Model Navigator, a été mis à jour plus tôt cette année et il est plus pertinent que jamais. C’est une excellente introduction : il présente 66 modèles d’affaires et explique comment envisager son organisation à travers un portefeuille simplifié de modèles plutôt qu’un seul modèle complexe.

https://lnkd.in/er_Zuw_r | 30 | 1 | 0 | 2w | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:45.099Z |  | 2025-11-18T15:47:58.384Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395113351065833472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFZCl-MY5Bf5w/feedshare-shrink_800/B4EZqC4ZP2GoAg-/0/1763132416022?e=1766620800&v=beta&t=CNj81JwSSj2bdcpCvaLmdI5qMd-jE3Eb3an-pz6T8cM | Avec GPT-5.1, OpenAI promettait un modèle à la fois plus intelligent, plus conversationnel et plus rapide. Après quelques heures d’utilisation, et à la lecture de nombreux commentaires, il semble que le modèle, tel que configuré de base, est moins logique et cohérent pour des prompts plus complexes que son prédécesseur.
 
L’ironie, c’est que le véritable stimuli économique d’OpenAI n’est pas d’offrir un un GPT toujours plus puissant, mais un GPT moins coûteux à faire tourner.
 
Depuis 15 ans, deux modèles d’affaires dominent le numérique : l’abonnement et le freemium. Netflix, Amazon Prime, Spotify, Adobe… tous reposent sur l’idée que le volume réduit les coûts marginaux. Offrir une version gratuite et un faible tarif mensuel pour attirer des millions d’utilisateurs est donc très rationnel et viable.
 
En démarrant, OpenAI a adopté cette logique. Par conséquent, l’entreprise perd maintenant environ deux dollars pour chaque dollar généré. Ce n’est pas un « coût d’acquisition », c’est structurel. Plus il y a d’utilisateurs, plus les pertes augmentent.
 
Pour Spotify, diffuser une chanson à 1 000 ou 100 000 personnes coûte presque rien de plus. Pour OpenAI, chaque requête implique un coût marginal significatif (énergie, GPU et infrastructure) qui croît avec l’usage.
 
Ainsi, contrairement à Netflix qui a comme stimuli de produire la meilleure série possible pour conserver notre abonnement mensuel, OpenAI a comme stimuli de rendre son modèle moins dispendieux à opérer, tout en espérant que l’utilisateur moyen ne s’en rende pas compte.
 
Les modèles d’abonnement ou de freemium ne fonctionneront jamais pour un LLM, ils vont simplement limiter l'innovation. La seule voie viable est de revenir à une logique de pay per use, à la tarification au token. | 56 | 10 | 1 | 3w | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:45.099Z |  | 2025-11-14T15:00:17.456Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7388575923136200704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHmU-NFpB5kqw/feedshare-shrink_800/B4EZol.nF5KoBM-/0/1761573771123?e=1766620800&v=beta&t=720O54_fTAei-3MUfKLkG4D2djVU3rDqHEzH6v_FDHg | J’ai été peu présent ici ces derniers mois, mais je n’ai pas chômé.

Maintenant que je peux l’annoncer officiellement, j’ai le plaisir de présenter pivotal, la nouvelle entreprise que j’ai cofondée plus tôt cette année avec mes amies et collègues de longue date, Veronique, Keline et Elizabeth.

Depuis près de 15 ans, j’aide des organisations dans leur transformation organisationnelle et numérique, parfois comme stratège, parfois comme intégrateur. J’ai participé à des projets qui se sont très bien déroulés… et à d’autres qui ont terminé en queue de poisson.

Il y a plusieurs facteurs qui influencent la réussite d’un projet. Mais le dénominateur commun, c’est la capacité de l’entreprise et de ses fournisseurs à traduire la vision stratégique et les besoins d’affaires en requis fonctionnels clairs pour les équipes qui vont opérer le changement.

C’est exactement là où pivotal intervient. Que vous cherchiez à revoir vos modèles d’affaires, à intégrer de nouvelles technologies, à vous doter d’une vision et d’une feuille de route cohérentes et réalistes, ou à trouver le bon partenaire et à encadrer l’implantation de vos projets, notre équipe peut aider.

Nous ne faisons aucune intégration : nous ne sommes attachés à aucune solution ni technologie. Nous sommes simplement attachés à la réussite des projets de nos clients.

Notre page LinkedIn : https://lnkd.in/eMURqY_B
Notre site Web : https://www.pvtl.ca

N’hésitez pas à m’écrire si vous souhaitez aller prendre un café ou discuter de vos projets! :) | 449 | 83 | 4 | 1mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:45.100Z |  | 2025-10-27T14:02:53.178Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7303109114295996416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPY7yKH0KTLw/feedshare-shrink_800/B4EZVnbCnGG0Ag-/0/1741196897096?e=1766620800&v=beta&t=dLOYoIvLDug03tJYvV2qLg2vfcUQS0O37HPdFSbY8Ic | Le tweet de Sam Altman, PDG d’OpenAI, l’organisation derrière ChatGPT, publié hier, peut sembler anodin, mais il est lourd de sens.

Il devient de plus en plus évident que les modèles d’affaires de « freemium » et d'abonnement, adoptés par tous les grands fournisseurs de LLMs et de modèles d’IA, ne sont pas viables. OpenAI perd de l’argent à chaque requête effectuée sur ChatGPT.

C’est un problème pour ces entreprises, mais cela pourrait rapidement devenir un problème de société.

Plusieurs centaines de milliards ont été investis dans ces jeunes pousses (OpenAI, Perplexity, Anthropic, etc.), qui se livrent une intense compétition à la « winner takes all ». Cela entraîne deux conséquences importantes :
 1.	Leurs produits deviennent des commodités plus rapidement qu’elles ne parviennent à rentabiliser leurs investissements.
 2.	Leur volonté de démocratiser la technologie les pousse à sous-évaluer leurs frais de licence.

Aucun de ces acteurs ne pourra rentabiliser ses investissements avec un abonnement fixe à 20 $/mois (et même 200 $/mois) tout en développant des modèles toujours plus puissants et énergivores. C’est pourtant la stratégie actuelle.

Pour l’instant, ce constat est noyé dans le « hype », l’euphorie des nouveaux modèles et la course à l’AGI. Mais tôt ou tard, la réalité rattrapera ces entreprises, leurs investisseurs, leurs fournisseurs d’infrastructure ainsi que le marché. Et nous savons tous comment naissent les crises économiques…

En tant qu’utilisateur de ces outils, ça ne me fait pas plaisir de le dire, mais la transition vers un modèle d’affaires en Pay Per Use est inévitable. Il est également critique que les entreprises, de la multinationale à la PME, adoptent ces technologies beaucoup plus rapidement et commencent à payer à l’usage, notamment via les APIs qui fonctionnent déjà ainsi. | 54 | 19 | 1 | 9mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:50.028Z |  | 2025-03-05T17:48:18.054Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7302773408700743680 | Article |  |  | La Presse publiait vendredi dernier un article sur l’intégration de l’IA au sein des PME québécoises, dans lequel Olivier Blais de Moov AI était interviewé. C’est un sujet important, car il touche directement le gain de productivité dont nous avons tant besoin.

J’ai beaucoup de respect et d’admiration pour Olivier – un ancien collègue de classe à l’UdS – ainsi que pour l’approche avant-gardiste de Moov. Nous sommes vraiment chanceux de les avoir au Québec.

Cela dit, je vais me permettre d’ouvrir un petit débat. Si le journaliste m’avait demandé l’inverse de ce qu’il a demandé à Olivier, c’est-à-dire ce qui ralentit l’intégration de l’IA dans les PME, j’aurais donné sensiblement les mêmes réponses.

« La première étape consiste à identifier le type d’intelligence artificielle (IA) le mieux adapté à son entreprise. »

Je suis persuadé que la majorité des gestionnaires de PME ont peu ou pas d’intérêt à savoir quel type d’IA sera utilisé, tant que celle-ci répond à leurs besoins. La première étape consiste plutôt à documenter des cas d’usage spécifiques et à évaluer le retour sur investissement. Et, si le ROI n'est pas évident, la PME ne l'adoptera pas.

« Avant d’adopter l’IA, il est essentiel de former tous les membres de l’entreprise, des employés aux dirigeants. »

Si l’on attend de former toute l’entreprise avant d’adopter l’IA, aucune PME ne l’adoptera, jamais. Les employés sont déjà submergés par leurs tâches quotidiennes et diverses formations obligatoires (RH, cybersécurité, etc.). Sans compter le taux de roulement. Plutôt que d’essayer d’expliquer l’IA, je crois que les meilleurs outils, pour une première phase d’adoption, seront ceux qui fonctionnent en arrière-plan. The best interface is no interface.

« L’intégration de l’IA doit également être encadrée par une gouvernance claire […]. Désigner un responsable de l’IA au sein du conseil d’administration permet de choisir les bons outils, de définir les meilleures pratiques et d’éviter des usages inappropriés. »

Or, beaucoup de PME n’ont pas de CA formellement structuré ou ne disposent pas d’une personne ayant les compétences requises pour jouer ce rôle. L’idée est bonne, mais la gouvernance ne peut pas commencer à ce niveau.

Bref, je comprends pourquoi ces réponses ont été formulées ainsi dans le contexte d’une entrevue. Cela dit, je persiste à croire qu’elles s’appliquent davantage aux grandes entreprises qu’aux PME. | 42 | 5 | 2 | 9mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:50.029Z |  | 2025-03-04T19:34:19.603Z | https://www.lapresse.ca/affaires/portfolio/2025-02-28/intelligence-artificielle/par-ou-les-pme-peuvent-elles-commencer.php |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7299796199388110848 | Text |  |  | Vendredi dernier marquait ma dernière journée en tant que VP Stratégie chez Logient x Wepoint.

Par la même occasion, cela marque la fin d’un premier grand chapitre de ma carrière : celui d’avoir cofondé Poudre Noire en sortant de l’université, fait grandir la firme, surmonté la faillite de certains clients, traversé la pandémie, rejoint Logient et découvert les rouages d’une entreprise de plusieurs centaines de personnes.

Une douzaine d’années ponctuées de réussites et de petites victoires, d’embûches et d’apprentissages, de rencontres marquantes avec des personnes brillantes et dévouées. Mais surtout, une multitude de souvenirs qui me suivront tout au long de ma carrière.

Mon premier merci va à mon ami et associé de longue date, Samuel Fontaine. D’une idée naïve dans une salle de classe de l’UdS à aujourd’hui, merci d’avoir pris ce chemin atypique avec moi. It was a hell of a ride! Je suis très fier du chemin parcouru et du gestionnaire que tu es devenu.

Je tiens aussi à remercier Vincent L. Godcharles, CPA, et toute l’équipe d’Oliva Capital d’avoir cru en nous et d’avoir fait de nous leurs associés chez Logient.

Et bien sûr, rien de tout cela n’aurait été possible sans les collègues, partenaires et clients avec qui j’ai eu le plaisir de collaborer.

Ceux qui me connaissent s’en doutent : je ne resterai pas immobile bien longtemps. Je suis enthousiaste face à ce nouveau chapitre qui s’ouvre. 

D’ici là, si vous voulez prendre un café dans les prochaines semaines, faites-moi signe! ;) | 366 | 110 | 0 | 9mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:50.030Z |  | 2025-02-24T14:23:57.589Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7292602854630977539 | Article |  |  | “He acts like a king because he’s too weak to govern as a president.”

Cette citation est tirée du balado publié hier par Ezra Klein du NYT. J’ai toujours été mitigé quant à cet éditorialiste, mais ce monologue de 13 minutes est éloquent.

Vu à travers le prisme d’un stratège, il est vrai que les premières semaines du second mandat du président américain sont intrigantes. Son équipe et lui ont orchestré avec brio une série de stratagèmes, directement tirés de la théorie, pour tester les limites du pouvoir du plus haut poste de la Maison-Blanche.

“Flood the zone”, “Muzzle Velocity”, “Divide and Conquer”, “Projection”, “Whataboutism”, “Gaslighting”… On dirait que Nicolas Machiavel, Edward Bernays et Robert Greene se sont réunis pour écrire un roman.

Et, de toute évidence, ça fonctionne : les journalistes ne savent plus où donner de la tête, le Sénat approuve une série de nominations déplorables à des postes clés par peur de représailles, la Chambre des représentants entière est devenue docile et accessoire, les employés de l’État sont déboussolés, les alliés prennent chaque menace au pied de la lettre et les activistes peinent à organiser leurs efforts (et mon réseau LinkedIn est en feu).

Là où je rejoins Klein : à force de créer de la confusion, de signer des décrets et de tenter de noyer tous ses ennemis en même temps (“flood the zone”), il va noyer sa propre équipe.

Il paraît puissant comme un roi, car ses stratagèmes fonctionnent particulièrement bien. Il s'offre le potentiel de changer profondément son pays et le monde. Mais lorsque chaque décret aux allures inconstitutionnelles, chaque décision douteuse, sera attaqué par un ennemi différent et mis en pause par un juge, comme c’est déjà le cas, saura-t-il maintenir la cadence, rallier le Congrès et gouverner comme un président pour mener ses promesses à terme? 

Un marathon de quatre ans, c’est long quand on le démarre par un sprint. Un stratège avec un plan aurait pris son temps. | 47 | 2 | 2 | 10mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:50.030Z |  | 2025-02-04T18:00:10.553Z | https://www.nytimes.com/2025/02/02/opinion/ezra-klein-podcast-trump-column-read.html |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7285034369239404545 | Text |  |  | De retour de vacances cette semaine, j'en profite pour vous souhaiter santé et bonheur en 2025, comme le veut la tradition. 

Je me permets d'aller plus loin en vous souhaitant également de rester curieux, rigoureux, intègre et empathique en 2025.

Avec les récents changements réglementaires de certaines plateformes, l’abolition des agences de contrôle au sud de la frontière, l’appauvrissement des médias traditionnels, l’expansion du contenu généré par l’IA et les discours incendiaires de certains politiciens et influenceurs, il est évident, dès ce début d’année, que la désinformation et la polarisation continueront à progresser en 2025.

Vous serez exposés à davantage de vérités alternatives, de récits fictifs, de pseudo-sciences, de propos haineux et de chambres d’écho. Et cela, quel que soit votre camp, vos valeurs ou vos convictions.

Faites confiance à votre intuition: si quelque chose semble suspect, c’est probablement le cas. Vérifiez vos sources, posez des questions, restez ouverts d’esprit et engagez-vous dans des débats constructifs.

Et surtout, ne vous laissez pas intimider ou emporter par l’intolérance et la haine. Il y a toujours une façon de s’exprimer et d’échanger dans le respect de l’un et de l’autre.

Bonne année 2025, chers amis et collègues. | 93 | 4 | 0 | 10mo | Post | Arnaud Montpetit | https://www.linkedin.com/in/arnaud-montpetit | https://linkedin.com/in/arnaud-montpetit | 2025-12-08T06:08:50.031Z |  | 2025-01-14T20:45:43.020Z |  |  | 

---



---

# Arnaud Montpetit
*IC Canada | Inno-centre*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Inno-Centre | Arnaud Montpetit](https://www.inno-centre.com/en/expert/arnaud-montpetit)
*2024-03-19*
- Category: article

### [Arnaud Montpetit – Medium](https://medium.com/@arnaud.montpetit?source=post_internal_links---------7----------------------------)
*2018-11-15*
- Category: blog

### [Suivez toutes nos actualités](https://www.inno-centre.com/en/actualites)
*2024-10-15*
- Category: article

### [IC | Inno-centre | High-level business support services to ensure the growth of SMEs in the agri-food processing sector](https://www.inno-centre.com/en/actualites/des-services-daccompagnement-daffaires-de-haut-niveau-pour-assurer-la-croissance-des-pme-du-secteur-de-la-transformation-agroalimentaire)
*2020-09-16*
- Category: article

### [InnoCity MTL, the Montréal accelerator of smart city starups, merges with Centech, University incubator | Innovation Development MTL | ID MTL](https://ville.montreal.qc.ca/idmtl/en/innocity-mtl-the-montreal-accelerator-of-smart-city-starups-merges-with-centech-university-incubator/)
*2018-03-06*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
