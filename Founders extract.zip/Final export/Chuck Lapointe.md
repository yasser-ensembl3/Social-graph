# Chuck Lapointe

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Narcity Media Group
**Durée dans le rôle** : 12 years 7 months in role
**Durée dans l'entreprise** : 12 years 7 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Online Audio and Video Media

## Résumé

Chuck Lapointe is the co-founder and CEO of Narcity Media, a leading online media company and publisher that focuses on local news and travel content for millennials. With over 12 years of experience in the media industry, Chuck has a passion for creating and delivering engaging and relevant content that connects people to their cities and communities.

Chuck is a pioneer and expert in sponsored content, having launched the first sponsored content platform in Canada in 2013. He has successfully grown Narcity Media into a trusted and influential source of lifestyle, local restaurants, and activity recommendations for over 8 million Canadians and 3 million Americans every month. He leads a team of talented and creative professionals who share his vision and mission to empower people to explore and enjoy their cities.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAIJ5I4BaplZpuEITOe9cQojceciOxf5Wo8/
**Connexions partagées** : 219


---

# Chuck Lapointe

## Position actuelle

**Entreprise** : Narcity Media Group

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Chuck Lapointe

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402832215329615872 | Article |  |  | Big releases this week on Locals.tv 🚀

We’ve shipped a slate of creator-first and business updates to help you grow faster, collaborate better, and earn more.

- Invite friends and track invites
- Invite collaborators to your Lists 
- Activate "Creator Agency" in your business settings to allow other creators to add you as their Creator Agency
- Businesses can now purchase Managed Services on Locals.tv which are billed hourly.
- Creators can now become "Mentors" to other creators

Read more in detail here:
https://lnkd.in/ehtwV5jA | 10 | 1 | 1 | 2d | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.938Z |  | 2025-12-05T22:12:18.106Z | https://www.locals.tv/blog/managed-services-roster-mode-creator-agencies-and-more |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401733786524229636 | Article |  |  | we just surpassed 100K in revenue on Locals.tv in less than 12 months 🙏🏻 💪🏻

with our strongest month being in November at 25K+.

this is a testament to our core focus of building a platform where local creators (no matter how small) can strive, and build actual real & sustainable local creator businesses  if they are willing to put in the effort.

and we're just getting started: we're aiming to 5x that in 2026

Locals.tv | 43 | 1 | 0 | 5d | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.939Z |  | 2025-12-02T21:27:32.271Z | http://locals.tv/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399573749240324096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHUtpBy_v6pfg/feedshare-shrink_800/B4EZrCRFfwIwAg-/0/1764195858312?e=1766620800&v=beta&t=M-8kqP4R2FfAqhuLKHNd13zjbkj-urvcWDYhMkJCH24 | I can’t stop smiling 😃

Heading into crunch time and Holidays, we’ve never been in a better place.

We’re on track to deliver our most profitable year since the beginning of Narcity Media Group 

Our team is a lean and mean machine that is ultra focused in every way.

The last 3 years have been a grind but I’ve learned so much about building intentionally and humbly.

Not stressing about external factors as much but doubling down on our core systems and quietly building a much better position for ourselves.

No fluff, just action.

In December, I’ll share full revenue numbers and profit by division for those that are curious.

I’ll say it again: we are truly building the future of local media.

The fight is not vs. other publishers.

We’re fighting to bring back ad dollars here, in our local markets.

Let’s fucking go!!! | 183 | 11 | 2 | 1w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.939Z |  | 2025-11-26T22:24:19.251Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398741321923960833 | Text |  |  | We're closing the year off strong with an extremely important hire to kick off the new year.

I am looking for an absolute rockstar individual contributor that can lead design and creative direction at Narcity Media Group.

You will be working directly with me to execute on everything from media decks, brand strategy, social content assets, event signage, and more. 

You need to have excellent taste, good understanding of content / brand trends and need to be on the gun.

If you or someone you know is interested, you / they can apply right here 🤠 

https://lnkd.in/eduTqf9T | 40 | 6 | 6 | 1w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.940Z |  | 2025-11-24T15:16:33.113Z |  | https://www.linkedin.com/jobs/view/4338903021/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396670692949176320 | Text |  |  | to be honest, a lot of brands  really suck at creator marketing. 

I'm not sure if it's because they're trying to adapt their TV commercials or if the teams doing this internally don’t know what they are doing..

it often feels like they try too hard and it just doesn't land 

 I see a huge missed opportunity for brands that just go for the very stock, very in-your-face, promotion.

This content sticks out like a sore thumb in your feed and performs poorly.

brands should embrace creator marketing as what makes it unique.

 leverage multiple creator ideas and stories to see what sticks with your brand.

let them come up with a creative strategy,  how they would integrate your product 

then use the top performing posts behind your paid media strategy 

rather than force through a narrative that makes your brand look like « you don’t get it »

we at Narcity Media Group understand effective local creator marketing through Rally™ , our talent agency, and Locals.tv our creator marketplace platform. 

we've done well over 300 local creator campaigns in the last 24 months, and we're just getting started 

DM me if you want some solid creator marketing tactics , we got you 😎 | 28 | 9 | 1 | 2w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.941Z |  | 2025-11-18T22:08:36.695Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7395126512196374529 | Text |  |  | We're building something truly magical at Locals.tv and we want to build as large of a community as possible around this with like-minded business owners that are serious about the local creator economy.

Comment "Link" here and I'll send you an invite | 12 | 6 | 0 | 3w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.942Z |  | 2025-11-14T15:52:35.314Z | https://www.linkedin.com/feed/update/urn:li:activity:7395125200599760896/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394439414975733760 | Text |  |  | There are normal PR people.

And there there are the PR type of people that 

have "Unsubscribe" links that open up a new email.

Ihysm | 13 | 4 | 0 | 3w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.942Z |  | 2025-11-12T18:22:18.571Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394099075601629184 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQHS5jTi4tVVVA/feedshare-thumbnail_720_1280/B4EZp0DJVOJgA4-/0/1762883574498?e=1765778400&v=beta&t=8caqGxnK5H0nZltbZNUGfVZb2MJSZwA6sQxDiE0kYAI | Effort = value. 

I've had a similar theory as Roberto now for the last two years as Gen-AI becomes unanimous with content creation. 

I think over time humans will attribute more effort with more value when it comes to content creation & creativity. 

We may not see that yet, but I think it will happen | 5 | 2 | 0 | 3w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:04:59.943Z |  | 2025-11-11T19:49:55.341Z | https://www.linkedin.com/feed/update/urn:li:activity:7394069799628140544/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7393667829750968321 | Text |  |  | I’m on the hunt for a small but mighty growth agency in Montreal or Toronto 🕵🏻‍♂️ 

that can audit and optimize our inbound lead engine.

From forms and landing pages to "always on" LinkedIn, Google, and Meta campaigns.

We’ve got a good volume, now I want to make sure every step of the funnel is performing at its best.

We use HubSpot as our CRM and CMS for Narcity Media Group so making sure it all connects and works in there is a must.

Any agencies or consultants you’ve worked with who you'd recommend??

Open to intros or DMs! | 39 | 33 | 4 | 3w | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.875Z |  | 2025-11-10T15:16:18.318Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7392581872415043584 | Poll |  |  | I'm curious what agency and marketing folks do here.

It seems that when I speak to media planning agencies, content is always handled by a separate creative agency or department.

Which seems like a very old-school way of doing things, especially when you look at how much creative impacts reach on social media.

If you did vote No, have you ever taken the time to blend in your content production costs and media spend and see what type of return you get on a CPV basis when you factor both of those in? | 4 | 0 | 0 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.876Z |  | 2025-11-07T15:21:05.913Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7392282114173333504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHnkjyivdaiNw/feedshare-shrink_800/B4EZpapaS7J0Ag-/0/1762457397396?e=1766620800&v=beta&t=YBYhWhhGXyr5l-D6Zu2waTleVoTC8kPjSkXgKSVJzjo | This is honestly so cool 

We launched a new thing called Lists on Locals.tv

And our teams are having incredible fun "curating" public creator lists of all types.

Here's a few:

Smaller Following, Huge Impact: Inside Montreal’s Micro-Creator Movement
https://lnkd.in/equ4wvmq

Top 10 Up-and-Coming Creators Putting Toronto on the Map
https://lnkd.in/ecMai2s8

10 Montreal Food Creators Making The City Look Tasty
https://lnkd.in/e9RqsfUZ

Looking forward to seeing what our users, creators, and brands are curating!

Most awesome part is the social proof that appears on Creator profiles as they are added to lists.

Let's fucking goooo! | 24 | 6 | 3 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.876Z |  | 2025-11-06T19:29:57.979Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7391930054416429057 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQGH8ekSdk8yQQ/feedshare-thumbnail_720_1280/B4EZpVpB3LGYA4-/0/1762373411159?e=1765778400&v=beta&t=a7MgE4gRSfei-0U_zftZ7hxtxeEz0nrdYa5AUxuVtP8 | We are sooooo close to unlocking the secret to effective local creator marketing at scale at Locals.tv

With our new content insights launched last week, we're now able to see cross-platform aggregated and average performance on key metrics such as:

- Cost per view
- Cost per engagement
- Average turnaround times

And the results are pretty insane...

We are seeing on average a LESS than $0.01 per view across 84 local collaborations completed on Locals.tv so far 🤯🤯🤯

Keep in mind this also factors in content production costs.

Honestly I'm not sure where you can get a better bang for your buck if you're wanting to reach local audiences.

I've been working on some content series in the next few months to highlight this huge opportunity for brands.

Thoughts?? Do we have something solid here?? | 45 | 6 | 2 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.877Z |  | 2025-11-05T20:11:00.392Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7391476374248583168 | Text |  |  | No harm done, Meta ads are a better option for you.

The amount of times I say this to brands and small businesses is actually quite high.

And I don’t see it as a bad thing.

I see it as an opportunity to educate businesses, brands and agencies on what they are willing to sacrifice.

We know Meta ads are shortsighted but necessary.

We know some clients just want short-term sales and need direct sale attribution on everything.

This is OK to a certain extent.

but when it takes your ENTIRE marketing budget or the bulk of it, it will come at a cost to your brand relevancy.

It will come at the cost of losing your ability to create good storytelling and market yourself.

Meta and Big Tech are not your friends. 

They want to create technical and creative dependency on their products where your brand becomes a commodity, only as good as it’s last dollar spent.

But some brands get it.

Some partners understand that betting on content is well worth it almost every time because at least: it puts you in the driver’s seat.

It flexes your creative muscles, and gives you massive upside and cost efficiency if you deliver properly.

The question is:
Will you realize before it’s too late? | 21 | 2 | 0 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.877Z |  | 2025-11-04T14:08:14.611Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7389725448437460992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHYPrfxEiieJQ/feedshare-shrink_800/B4EZo2UIZRKcAg-/0/1761847839553?e=1766620800&v=beta&t=4Rdo7c5HzTHuAxvDUO2N0_2XMavMrUISRPuyHVw0WFs | This year’s annual Narcity Media Group summit in Montreal was absolute 🔥

Everyone in the team showed up in a strong way and good vibes were infectious.

We had an incredible year and it only felt right to celebrate in a big way with the team IRL and connect individually & share stories with the people that make this company great.

2026 will be a monster year for us, I can’t wait!!

Onwards 🚢

Ps. Big shout out to our People Ops Director Max Alejandro Sanchez Luckert for delivering an impeccable experience and Rim Bouatlaoui for being the unofficial photographer 👏 | 98 | 6 | 4 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.878Z |  | 2025-10-30T18:10:41.367Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7386868651024470016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFOVKctksn3UA/feedshare-shrink_800/B4EZoNt2_AKoAg-/0/1761166722064?e=1766620800&v=beta&t=C-WSqXGCtlopAdfqIog-JGGa9jaMdRFAjNHfLUvYeT8 | Great networking day with Canada’s best in media & digital at Digital Day Camp 

Digital Day Camp brings together media, agencies, brands and ad tech for a full day of exchange and conversation in Toronto.

These events don’t happen enough in Canada and it’s one of those rare moments you get to challenge each other and connect with the people behind the screen running Canadian media.

Keep these going David U.K. and Rob Wheeler 🙏🏻 | 87 | 5 | 1 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.878Z |  | 2025-10-22T20:58:47.787Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7384323985544540160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHzzMyuFwhwGg/feedshare-shrink_800/B4EZnpjiA2HcAg-/0/1760560031129?e=1766620800&v=beta&t=IrYh3XAIPlvwqh6SjxiR3E2sbE_XRmumHysO9DiIWF4 | Olé... olé, olé, olé... ! 🤠

Another year, another partnership!

We're happy to announce we just renewed our partnership 🤝 with the Canadiens de Montréal for a SIXTH season!

I've said it before, but this partnership is a no-brainer for our company and for me personally.

To be associated with one of the world's most iconic hockey brands — and to be part of their journey — makes me extremely proud to be a fellow Canadian and Montrealer.

Montréal has been our home base since we launched in 2013, and we owe our character and boldness to this incredible city.

We're honored to continue investing in the cultural foundations that make this city great.

And of course, a big thank you to Laura Canter and team for your support in making this partnership happen so organically and run smoothly, year after year!

Go Habs Go!!! 🏆 🏒 | 84 | 4 | 0 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.879Z |  | 2025-10-15T20:27:12.259Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7383239378229174273 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4484KnB544w/feedshare-shrink_800/B4EZnaJDjaIIAg-/0/1760301438659?e=1766620800&v=beta&t=2CTpB9qxfxIkDI0qv4NVb-wdDFsxzaTuipnf1bwXvFY | Phoenix is a wrap!

I spent the weekend with creative thinkers, journalists and media entrepeneurs for Newsgeist 2025 in Phoenix, Arizona for News

Under Chatham house rules, truth and transparency were the foundations that made for a unique weekend full of insights and tangible solutions 

Although the tensions are running high between the US and Canada, it felt good to connect with like minded individuals to battle together the challenges facing our industry,  no matter where you’re from.

Thanks for welcoming me with open arms Richard Gingras and the team at Center for News, Technology & Innovation - CNTI 🫶 | 54 | 5 | 1 | 1mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.879Z |  | 2025-10-12T20:37:21.724Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7380978951138992128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEBoIKeFZP76w/feedshare-shrink_800/B4EZm6BPWNIMAg-/0/1759762512555?e=1766620800&v=beta&t=zg9jkjT6taPR1u32BlDP-bcZRTUz6kHnQ8tCyAG3iAA | We just launched Profile Insights in beta on Locals.tv
And it’s free.

For a limited time.

With a free account (and at least one business or creator account added), you now have access to follower growth rates, audience location data and as well as brand affinity from 1,000+ local creators across Canada.

It’s honestly pretty cool.

Discover all our Creators here:
https://lnkd.in/e9dSzryC

We’re going to use it to work with high velocity and high growth creators at Narcity and Rally.

Try it out and give me your feedback! | 14 | 0 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.880Z |  | 2025-10-06T14:55:13.909Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7378850055023194112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSyOxwxifyYQ/feedshare-shrink_800/B4EZmbxBfGKYAg-/0/1759254944036?e=1766620800&v=beta&t=M_3fl9FREYRGYuBC-o_vXTnRMlQMHUHw62U95HeNZhk | We just passed the 1,000 creator mark on Locals.tv 🤠

We're starting to see serious traction as we keep launching creator-first features that build towards increased transparency in the Local Creator Economy.

One by one, we're helping creators value themselves and stop working for free. 

Onwards to 10,000 🫡 | 33 | 2 | 2 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.880Z |  | 2025-09-30T17:55:45.522Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7376712890936098817 | Text |  |  | The hardest thing about running a media company isn’t competing for attention — it’s earning trust at scale.

Algorithms can push content, but they can’t create genuine connection.

That’s why I believe the future of media has to be founder-led, creator-led, human-led. 

Because trust is built through people, not impressions or logos.

That’s the kind of company we’re building at Narcity Media Group | 59 | 0 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:03.881Z |  | 2025-09-24T20:23:25.897Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7373707220019994624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEpFlkGy6Kztw/feedshare-shrink_800/B4EZlO3lRYHEAk-/0/1757964818584?e=1766620800&v=beta&t=f4JHjvXp_SHyTLZxGKKQoIcGH06_3N2b6HObR5mOiHY | This change is similar to what we're seeing as well in Canada. 

As audiences decline, your pitch to brands and advertisers will need to shift along with it. 

Small, independent journalists and subscriber-revenue-oriented publishers will fare well in this new reality ss they are not dependent on advertising. 

And publishers relying on audiences and scale to sell large-scale campaigns  will have to reinvent themselves. | 13 | 0 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.079Z |  | 2025-09-16T13:19:58.108Z | https://www.linkedin.com/feed/update/urn:li:activity:7373438873433182208/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7371933427052253184 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEv1uLa3sTkYg/feedshare-shrink_800/B4EZk5eYkMKoAg-/0/1757605891477?e=1766620800&v=beta&t=0WXhI5YngE1MY5Oz7TDAX11n0rXWoKSSQko-7SEML-s | This metric should scare the sh*t out of every publisher.

When Google says: “we are NOT noticing a significant drop in what we send to publishers with our new AI Overviews / Mode ”…

What they really mean is they’re papering over Search losses by juicing Discover.

Here’s our reality:

- 90%+ of our Google traffic is now Discover
- Google = ~60% of our overall traffic
- Which means 55% of all our traffic comes from one source

And we’re not the only one.

This is now true for most medium-to-large publishers across Canada and the U.S.

My recommendation: Drink from the hose while it’s still on..

But prepare now for the blackout.

When Discover shuts off, and when Google Zero arrives.

Build new distribution. Rethink your business. Stock the bunker.

Because this isn’t a slow fade — it’s a cliff. 

In two years, if you stand still, your audience could be a shadow of what it is today. | 26 | 10 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.080Z |  | 2025-09-11T15:51:32.909Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7371173789155426304 | Text |  |  | We need to talk about ARR posts.

Is it just me, or is ARR often thrown around in a half-pompous, half-misleading way?

Most SaaS plans aren’t even annual, yet founders post ARR numbers every month to make their traction look bigger on LinkedIn.

Here’s the truth:

$1M ARR just means you hit $80K MRR last month.

And $80K MRR is nothing to be ashamed of. 

That’s solid progress.

But leading with ARR as your gospel can hide problems:

- If you have 10% monthly churn, that $80K can shrink to ~$65K in 3 months.

- If margins are thin (say 20%), $80K MRR is really just $16K in profit.

ARR tells one story, just most often not the one that defines success.

If that’s their headline, it risks being more smoke than fire.

I’m not even in SaaS, and I can’t help but think the obsession with ARR is distracting from the real story: consistent, growing, quality revenue that actually sticks.

Stick to what you actually achieved and show your monthly progress instead, it will make you look more serious. | 10 | 0 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.082Z |  | 2025-09-09T13:33:01.121Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7370849623332061184 | Text |  |  | This is the number one thing I tell all starting creators looking to make money.

“You do not need PR invites to build your portfolio”

Every free event invite you accept and create content for thinking this will boost your portfolio and give you access to brand deals. 

You're wrong. 

The only thing you are doing is undermining your future self. 

Focus on your own narrative, what makes you unique. 

Focus on hidden gems and things you are the one to discover first.

These are not the things that you will get invited to or offered free shit for. 

These are things you'll probably most likely have to pay for and work your ass off to find. 

Brands, businesses, and PR agencies are going to work with you (pay you) when you build the leverage that is needed to get them to pay for your content. 

And you build that leverage by being you, not by being like everyone else. | 16 | 3 | 0 | 2mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.083Z |  | 2025-09-08T16:04:53.966Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7369755498641793024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGQrgD8BAEvxQ/feedshare-shrink_800/B4EZkahkGmIwAg-/0/1757086633092?e=1766620800&v=beta&t=NfXjv3_HFHkAZ7bk_TkGF0ws6z4-rIyFXkDphKAAkoc | Local creators deserve more credit than they are given. 

The industry needs to wake up.

We talked about this and other things at our first Locals.tv creator meet-up in Toronto on Wednesday.

20+ creators showed up.

We talked brand deals.

We talked content & audience growth.

We talked vulnerability.

We talked about where the platform is headed and what feedback they had using it so far.

It was incredibly insightful.

This is why we built Locals.tv — to connect creators with opportunities and with each other.

To build a real community from and for creators.

 If you’re a creator in Montreal or Toronto, I want to meet you.

Let’s grab coffee, hang out, and talk about how you can grow your brand, land deals, and turn your side hustle into a sustainable business.

Shout out to Harshil & Rim for organizing and to all the creators that could make it out to our first event ✌️ | 21 | 1 | 0 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.084Z |  | 2025-09-05T15:37:14.312Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7369537045922291712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH1tEJQnSqe-w/feedshare-shrink_800/B4EZkXa4QKGcAg-/0/1757034549911?e=1766620800&v=beta&t=-DzRWD67986yNzF9yBx5lzHNNi1PsoyeBjFm_BZ2Ylk | Toronto x TIFF 😎

One of the most hype times of the year to be in Toronto | 42 | 1 | 0 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.085Z |  | 2025-09-05T01:09:11.125Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7366897170685382657 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGxc7Ean0yLGQ/feedshare-shrink_2048_1536/B4EZjx57hpGUA0-/0/1756405154332?e=1766620800&v=beta&t=QVtmtDPhYYNFX0h_B8MER2abRLymRASAgwfyeurxbMs | This was last summer
 my text message list. 

Following up with potential investors, anyone really who was willing to put in $5,000 or more in the business. 

I feel it pinching my heart to think about the energy it took me to reach out constantly during that time and just get ghosted. 

I hold no grudge against these investors at all. At that point in time, we were a bad investment. 

But these were not cold messages or emails. 

These were people that showcased an interest in our business. 

And then to just disconnect like that, When I'm putting myself and our business out there, I won't lie, it hurt as hell. 

But looking back at this a year and a few months later in a much better situation, you can't help but feel thankful that these investments never panned out

On the flip side,  there were investors that had a transparent process and always replied to me, and were just honest about their approach and just said no 

The ones that treated me with respect will be the first ones I call back when we're ready to look for investment again.

The other ones tough luck. 

Treat people exactly how you would want to be treated in a position with less leverage and you will always win. | 51 | 8 | 0 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.086Z |  | 2025-08-28T18:19:15.822Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7366581733363720194 | Text |  |  | today we just had one of those « aha » moments for locals.tv

A real game changer for the network effects we were looking for

It’s going to be wild

Stay fucking tuned 🤠 | 10 | 0 | 0 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.087Z |  | 2025-08-27T21:25:49.704Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7365862909203124224 | Text |  |  | there is a massive supply and demand gap in Creator Marketing.

especially at the local level

The creator as a career option is in full throttle 

But the revenue opportunities are way too limited outside of direct collaborations :

- Instagram doesn’t give any revshare
- TikTok’s creator fund isn’t available in Canada and isn’t significant for most creators
- Facebook gives revshare but less than 10 cents CPM NET for most videos
- YouTube is decent but requires significant time to build authority on, and it’ll be a struggle if you have a local focus

Platforms have all the leverage and all the profits

Which means the only way to really make it as a local creator is to sell brand deals. 

But money at the brand level is extremely scarce (we know, we live it every day)

You will have hundreds of creators fighting for $100 deals…

That’s unsustainable 

Most creators lose money if they factor in their time

But there are signals that are pointing to businesses and brands starting to value organic paid content opportunities over just spending on Meta or Google

It will take a colossal effort from everyone working together at the local economy to make that shift:

- small businesses
- PR companies
- Media companies
- And creators

There is so much advantages to re-investing those ad dollars in your local markets.

It should be a no-brainer.

But one step a time, we’ll get there!

What do y’all think is needed to accelerate that shift globally? | 10 | 2 | 0 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.089Z |  | 2025-08-25T21:49:28.669Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7365781014641614848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFBSTNM8Mw6bg/feedshare-shrink_800/B4EZjiCykmGUAk-/0/1756139041684?e=1766620800&v=beta&t=LBHjx4zgfl_41PFXRtC_8tCZrIeniU_v_V7viVVoT1g | Messages like these from local Canadian creators recently joining the Locals.tv community gives us so much inspiration and 🔥 every day to keep building

We built this platform for creators first. 

And the energy we put into the community is being given back to us tenfold. 

With the over 750 creators now on the platform, it's remarkable to see momentum building up and we're here for it | 15 | 2 | 1 | 3mo | Post | Chuck Lapointe | https://www.linkedin.com/in/charleslapointe | https://linkedin.com/in/charleslapointe | 2025-12-08T05:05:06.090Z |  | 2025-08-25T16:24:03.484Z |  |  | 

---



---

# Chuck Lapointe
*Narcity Media Group*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [Beyond The Byline: Narcity Media’s Strategy For Empowering Local Creators In A Post-Publisher World](https://www.netinfluencer.com/chuck-lapointe-narcity-media-strategy-for-empowering-local-creators/)
*2025-03-13*
- Category: article

### [Narcity brings UGC to Locals.tv](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/)
*2025-03-10*
- Category: article

### [Narcity Media Group » Media in Canada](https://mediaincanada.com/tag/narcity-media-group/)
*2025-03-10*
- Category: article

### [Narcity Media - Company Profile & Staff Directory | ContactOut](https://contactout.com/company/Narcity-Media-Group-9281)
*2025-03-26*
- Category: article

### [Press | Narcity Media Group](https://www.narcitymedia.com/press)
*2025-05-12*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 44,592 words total*

### Beyond The Byline: Narcity Media’s Strategy For Empowering Local Creators In A Post-Publisher World
*1,936 words* | Source: **EXA** | [Link](https://www.netinfluencer.com/chuck-lapointe-narcity-media-strategy-for-empowering-local-creators/)

Beyond The Byline: Narcity Media’s Strategy For Empowering Local Creators In A Post-Publisher World

===============

[![Image 6: Net Influencer](https://netinfluencer.com/wp-content/uploads/2020/05/NetInfluencerPlan250px.png)](https://www.netinfluencer.com/)

*   [Brands](https://www.netinfluencer.com/brand/)
*   [Influencer](https://www.netinfluencer.com/influencer/)
    *   [Talent Collectives](https://www.netinfluencer.com/talent-collectives/)

*   [Agency](https://www.netinfluencer.com/agency/)
*   [Technology](https://www.netinfluencer.com/technology/)
*   [Platform](https://www.netinfluencer.com/platform/)
*   [More](https://www.netinfluencer.com/uncategorized/)
    *   [Web Stories](https://netinfluencer.com/web-stories/)
    *   [Strategy](https://www.netinfluencer.com/strategy/)
    *   [Commentary](https://www.netinfluencer.com/commentary/)
    *   [Subscribe to Influence Weekly](https://www.netinfluencer.com/old-subscribe-to-influence-weekly/)

Connect with us

[![Image 8: Net Influencer](https://netinfluencer.com/wp-content/uploads/2020/05/NetInfluencerPlan600px.png)](https://www.netinfluencer.com/)
Net Influencer
--------------

[![Image 9: Beyond The Byline: Narcity Media’s Strategy For Empowering Local Creators In A Post-Publisher World](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)](https://www.netinfluencer.com/)
Net Influencer
--------------

*   [Brands](https://www.netinfluencer.com/brand/)
*   [Influencer](https://www.netinfluencer.com/influencer/)

    *   [![Image 11: MrBeast Announces Creator Marketplace For Major Advertisers](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) MrBeast Announces Creator Marketplace For Major Advertisers](https://www.netinfluencer.com/mrbeast-announces-creator-marketplace-for-major-advertisers/)
    *   [![Image 13](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) YouTuber’s DIY Plant Cloning Community Disrupts Collector Market](https://www.netinfluencer.com/youtuber-diy-plant-cloning-community-disrupts-collector-market/)
    *   [![Image 15](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) How Rourke Sefton-Minns Built GenHQ Into A Creative Learning Hub](https://www.netinfluencer.com/how-rourke-sefton-minns-built-genhq-into-a-creative-learning-hub/)
    *   [![Image 17](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) Jake & Logan Paul Announce $30M Venture Fund Backing AI, Robotics Startups](https://www.netinfluencer.com/jake-and-logan-paul-announce-30m-venture-fund-backing-ai-robotics-startups/)
    *   [![Image 19](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) YouTuber Doug DeMuro Says He’ll Never Start Another Business After Cars & Bids](https://www.netinfluencer.com/youtuber-doug-demuro-says-hell-never-start-another-business-after-cars-and-bids/)

    *   [Talent Collectives](https://www.netinfluencer.com/talent-collectives/)

*   [Agency](https://www.netinfluencer.com/agency/)
*   [Technology](https://www.netinfluencer.com/technology/)
*   [Platform](https://www.netinfluencer.com/platform/)

    *   [![Image 21](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) TikTok Sued By Hawaii Over ‘Coercive’ Design Tactics Aimed At Minors](https://www.netinfluencer.com/tiktok-sued-by-hawaii-over-coercive-design-tactics-aimed-at-minors/)
    *   [![Image 23](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) TikTok Launches Location-Based Nearby Feed In Four European Markets](https://www.netinfluencer.com/tiktok-launches-location-based-nearby-feed-in-four-european-markets/)
    *   [![Image 25](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) EU Fines X €120 Million For Violating Digital Services Act Transparency Rules](https://www.netinfluencer.com/eu-fines-x-120-million-euros-for-violating-digital-services-act-transparency-rules/)
    *   [![Image 27: YouTube Global Culture & Trends 2025 Platform Highlights Creator Innovation And Regional Content Shifts](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) YouTube Global Culture & Trends 2025: Platform Highlights Creator Innovation And Regional Content Shifts](https://www.netinfluencer.com/youtube-global-culture-and-trends-2025-platform-highlights-creator-innovation-and-regional-content-shifts/)
    *   [![Image 29](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) Spotify Launches 2025 Wrapped With New Features Including Listening Age, Top Albums, And AI-Powered Archive](https://www.netinfluencer.com/spotify-launches-2025-wrapped-with-new-features-including-listening-age-top-albums-and-ai-powered-archive/)

*   [More](https://www.netinfluencer.com/uncategorized/)
    *   [Web Stories](https://netinfluencer.com/web-stories/)
    *   [Strategy](https://www.netinfluencer.com/strategy/)

        *   [![Image 31](blob:http://localhost/9a3e9fe203f6dbbb05101ffd8c89a938) RACER’s Creator Awards: Putting Automotive Influencers In The Driver’s Seat](https://www.netinfluencer.com/racer-creator-awards-putting-automotive-influencers-in-the-driv

*[... truncated, 23,377 more characters]*

---

### Narcity brings UGC to Locals.tv
*901 words* | Source: **EXA** | [Link](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/)

Narcity brings UGC to Locals.tv » Media in Canada

===============

[![Image 2: Media In Canada](https://cdn.mediaincanada.com/wp/wp-content/themes/pb/images/header-logo.png)Media In Canada - keeping media and marketing execs up to speed on the Canadian media scene](https://mediaincanada.com/ "Media In Canada - keeping media and marketing execs up to speed on the Canadian media scene")

*   [Media By Category](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/#)
    *   [Digital](https://mediaincanada.com/category/digital/)
    *   [Experiential](https://mediaincanada.com/category/experiential/)
    *   [Interactive](https://mediaincanada.com/category/interactive/)
    *   [Mobile](https://mediaincanada.com/category/mobile/)
    *   [Out Of Home](https://mediaincanada.com/category/ooh/)
    *   [Print](https://mediaincanada.com/category/print/)
    *   [Radio](https://mediaincanada.com/category/radio/)
    *   [Research](https://mediaincanada.com/category/research/)
    *   [Social](https://mediaincanada.com/category/social/)
    *   [Television](https://mediaincanada.com/category/television/)

*   [Home](http://mediaincanada.com/)
*   [Events](https://mediaincanada.com/events/)
*   [Careers](https://mediaincanada.com/careers/)
*   [Screening Room](https://mediaincanada.com/category/screening-room/)
*   [Resources](https://mediaincanada.com/resources/)
*   [Got a Tip?](https://mediaincanada.com/submit-news-tips/)
*   [Subscribe](https://mediaincanada.com/subscribe/)
*   [SIGN IN](https://mediaincanada.com/account/logon/)
*   [My Account](https://mediaincanada.com/myaccount/)
*   [Sign Out](https://mediaincanada.com/account/logoff/)

[](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/#)[](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/#)

[Home](https://mediaincanada.com/) » [News](https://mediaincanada.com/category/news/) » 

Narcity brings UGC to Locals.tv
-------------------------------

##### CEO Chuck Lapointe answers our questions about the new video app and platform.

[By Greg Hudson](https://mediaincanada.com/author/ghudson/)

 March 10, 2025 

![Image 3](https://cdn.mediaincanada.com/wp/wp-content/uploads/2025/03/Screenshot-2025-03-10-110416-623x350.png)

Last week, Narcity Media Group officially launched Locals.tv, a video app that is meant to empower local creators to build sustainable business models with the power of Narcity Media Group’s distribution. Verified users upload their video content to Instagram, then tag Narcity to be syndicated on Locals.tv platform. Creators can also create and send “Collab” proposals to small businesses and businesses can accept and pay for these pitches directly in the platform.

It sounds relatively simple, but we spoke to Narcity CEO Chuck Lapointe to gain additional insights into the platform.

**What was the genesis of Locals.tv?**

We wanted to get back into video by doubling down on local creators. Instead of competing with giants like Instagram or TikTok, we saw an opportunity to create a platform that genuinely supports local creators in building sustainable revenue streams through their content on top of what they mostly already do.

**You mention that creators can begin monetizing right away: how?**

Creators simply tag our Narcity accounts when posting videos on Instagram (TikTok coming soon). We then syndicate their videos on Locals.tv, allowing immediate monetization through ads. Our new “Collabs” feature further helps creators easily collaborate and sell paid collaborations with small businesses.

Ads come directly from Narcity’s ad network and partners. Advertisers have the option to participate (but are included by default as part of our rest of network purchase).

**Is there any content moderation? How do you ensure brand safety?**

Every creator undergoes editorial review and approval by our team before appearing on Locals.tv. This ensures brand safety, appropriate content, and consistent quality. Once the creator is approved, we passively monitor brand safety but less than at the creator approval stage.

**What kind of impressions do videos on Locals.tv provide, and how are you planning on growing the service?**

This platform is very new and we are still in roll out phase, so impressions per video are still quite low (in the low hundreds). Right now we are focused on the collaboration tools for our creators and giving them more options to monetize.

**Tell us a little about the timing of the launch?**

The timing aligns perfectly with a broader movement to support local creators and businesses, that as you know, we’ve been fully onboard with for years now. There’s heightened consumer interest in Canadian-made content, and we’re hoping to capitalize on that with Locals.tv and the local creators who decide to get onboard.

###### Tags:

[Chuck Lapointe](https://mediaincanada.com/tag/chuck-lapointe/), [Locals.tv](https://mediaincanada.com/tag/locals-tv/), [Narcity](https

*[... truncated, 6,799 more characters]*

---

### Narcity Media Group » Media in Canada
*576 words* | Source: **EXA** | [Link](https://mediaincanada.com/tag/narcity-media-group/)

Narcity Media Group » Media in Canada

===============

[![Image 1: Media In Canada](https://cdn.mediaincanada.com/wp/wp-content/themes/pb/images/header-logo.png)Media In Canada - keeping media and marketing execs up to speed on the Canadian media scene](https://mediaincanada.com/ "Media In Canada - keeping media and marketing execs up to speed on the Canadian media scene")

*   [Media By Category](https://mediaincanada.com/tag/narcity-media-group/#)
    *   [Digital](https://mediaincanada.com/category/digital/)
    *   [Experiential](https://mediaincanada.com/category/experiential/)
    *   [Interactive](https://mediaincanada.com/category/interactive/)
    *   [Mobile](https://mediaincanada.com/category/mobile/)
    *   [Out Of Home](https://mediaincanada.com/category/ooh/)
    *   [Print](https://mediaincanada.com/category/print/)
    *   [Radio](https://mediaincanada.com/category/radio/)
    *   [Research](https://mediaincanada.com/category/research/)
    *   [Social](https://mediaincanada.com/category/social/)
    *   [Television](https://mediaincanada.com/category/television/)

*   [Home](http://mediaincanada.com/)
*   [Events](https://mediaincanada.com/events/)
*   [Careers](https://mediaincanada.com/careers/)
*   [Screening Room](https://mediaincanada.com/category/screening-room/)
*   [Resources](https://mediaincanada.com/resources/)
*   [Got a Tip?](https://mediaincanada.com/submit-news-tips/)
*   [Subscribe](https://mediaincanada.com/subscribe/)
*   [SIGN IN](https://mediaincanada.com/account/logon/)
*   [My Account](https://mediaincanada.com/myaccount/)
*   [Sign Out](https://mediaincanada.com/account/logoff/)

[](https://mediaincanada.com/tag/narcity-media-group/#)[](https://mediaincanada.com/tag/narcity-media-group/#)

[Home](https://mediaincanada.com/) » Archive »

Articles Tagged ‘Narcity Media Group’
-------------------------------------

[![Image 2](https://cdn.mediaincanada.com/wp/wp-content/uploads/2025/03/Screenshot-2025-03-10-110416-300x172.png) Narcity brings UGC to Locals.tv -------------------------------](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/)

CEO Chuck Lapointe answers our questions about the new video app and platform.

By [Greg Hudson](https://mediaincanada.com/author/ghudson/ "Posts by Greg Hudson")

 March 10, 2025 

[![Image 3](https://cdn.mediaincanada.com/wp/wp-content/uploads/2024/05/narcity-300x172.jpg) Narcity cancels crowdfunding campaign -------------------------------------](https://mediaincanada.com/2024/07/30/narcity-cancels-crowdfunding-campaign/)

NMG will relaunch its search for investors again, once its new models and brands have been established.

By [Patti Summerfield](https://mediaincanada.com/author/psummerfield/ "Posts by Patti Summerfield")

 July 30, 2024 

[![Image 4](https://cdn.mediaincanada.com/wp/wp-content/uploads/2024/05/narcity-300x172.jpg) Narcity signs as ad sales representative for Wildin Media ---------------------------------------------------------](https://mediaincanada.com/2024/05/13/narcity-signs-as-ad-sales-representative-for-wildin-media/)

The deal aims to expand brands’ reach in Western Canada and enhance their engagement with Gen Z.

By [Andrea Hernandez](https://mediaincanada.com/author/ahernandez/ "Posts by Andrea Hernandez")

 May 13, 2024 

[![Image 5](https://cdn.mediaincanada.com/wp/wp-content/uploads/2021/05/blog-banner-300x172.jpg) Narcity outlines new, more long-form approach to content --------------------------------------------------------](https://mediaincanada.com/2023/06/16/narcity-outlines-new-more-long-form-approach-to-content/)

As the economics for free media continue to change, the company is moving away from the high-output approach associated with digital news sites.

By [Patti Summerfield](https://mediaincanada.com/author/psummerfield/ "Posts by Patti Summerfield")

 June 16, 2023 

[![Image 6](https://cdn.mediaincanada.com/wp/wp-content/uploads/2021/05/blog-banner-300x172.jpg) Narcity rolls out a subscription model for advertisers ------------------------------------------------------](https://mediaincanada.com/2023/02/02/narcity-rolls-out-a-subscription-model-for-advertisers/)

Some Drive Thru plans also allow agencies to transfer impressions between different clients.

By [Patti Summerfield](https://mediaincanada.com/author/psummerfield/ "Posts by Patti Summerfield")

 February 2, 2023 

[Careers »](https://mediaincanada.com/careers/)

Popular

[* ![Image 7](https://cdn.mediaincanada.com/wp/wp-content/uploads/2025/12/shelley-smit-100x57.jpg) Omnicom Media Canada names Shelley Smit CEO, Noah Vardon as GM](https://mediaincanada.com/2025/12/02/shelley-smit-noah-vardon-omnicom-media-canada/)[* ![Image 8](https://cdn.mediaincanada.com/wp/wp-content/uploads/2025/06/omnicom-interpublic-100x57.jpeg) Omnicom to cut 4,000 jobs and consolidate agencies: Financial Times](https://mediaincanada.com/2025/12/01/omnicom-restructuring/)[* ![Image 9: (Image: Unsplash)](https://cdn.mediaincan

*[... truncated, 4,760 more characters]*

---

### Narcity Media - Company Profile & Staff Directory | ContactOut
*1,397 words* | Source: **EXA** | [Link](https://contactout.com/company/Narcity-Media-Group-9281)

Narcity Media - Company Profile & Staff Directory | ContactOut

===============

![Image 9](https://d.adroll.com/cm/b/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 10](https://d.adroll.com/cm/bombora/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 11](https://d.adroll.com/cm/experian/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 12](https://d.adroll.com/cm/g/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 13](https://d.adroll.com/cm/index/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 14](https://d.adroll.com/cm/l/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 15](https://d.adroll.com/cm/n/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 16](https://d.adroll.com/cm/o/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 17](https://d.adroll.com/cm/outbrain/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 18](https://d.adroll.com/cm/pubmatic/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 19](https://d.adroll.com/cm/taboola/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 20](https://d.adroll.com/cm/triplelift/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)![Image 21](https://d.adroll.com/cm/x/out?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&advertisable=T4NUFKPNRBEKHNCA3O5CFJ)

![Image 22](https://ipv4.d.adroll.com/seg4/T4NUFKPNRBEKHNCA3O5CFJ/DUX3GKZKWVD5TGTRQEZPQV?adroll_fpc=02ec4e7e3f629e489fed1a88a99fddd9-1765180199713&pv=14394098273.541891&arrfrr=https%3A%2F%2Fcontactout.com%2Fcompany%2FNarcity-Media-Group-9281&cookie=&adroll_s_ref=&keyw=&p0=1789&adroll_external_data=&adroll_version=2.0)

[](https://contactout.com/)

*   [Product](https://contactout.com/company/Narcity-Media-Group-9281)Overview [![Image 23: our data logo](https://contactout.com/images/database-01.svg) Our Data](https://contactout.com/our-data)[![Image 24: clients logo](https://contactout.com/images/face-smile.svg) Clients](https://contactout.com/clients)Use Cases [![Image 25: sales logo](https://contactout.com/images/people-double.svg) Sales](https://contactout.com/sales-users)[![Image 26: recruiters logo](https://contactout.com/images/rocket.svg) Recruiters](https://contactout.com/recruiters)Features [![Image 27: Search Portal Logo](https://contactout.com/images/feature-search.svg) Search Portal](https://contactout.com/search-portal)[![Image 28: Chrome Logo](https://contactout.com/images/feature-chrome.svg) Chrome Extension](https://contactout.com/chrome-extension)[![Image 29: API logo](https://contactout.com/images/data.svg) API](https://contactout.com/api-feature) More [Integrations](https://contactout.com/integrations-feature)[Data Enrichment](https://contactout.com/data-enrichment-feature)[Gmail Enrichment](https://contactout.com/gmail-enrichment-feature)[Email Campaigns](https://contactout.com/email-campaigns)[Support](https://contactout.com/contact)[ContactSheets](https://contactout.com/contactsheets-enrichment)  Overview [![Image 30: our data logo](https://contactout.com/images/database-01.svg) Our Data Learn more about our data](https://contactout.com/our-data)[![Image 31: clients logo](https://contactout.com/images/face-smile.svg)

*[... truncated, 17,120 more characters]*

---

### Press | Narcity Media Group
*1,808 words* | Source: **EXA** | [Link](https://www.narcitymedia.com/press)

Press | Narcity Media Group

===============

**We use cookies**

We may place these for analysis of our visitor data, to improve our website, show personalised content and to give you a great website experience. To find out more about the cookies we use, see our Privacy Policy.

If you decline, your information won’t be tracked when you visit this website. A single cookie will be used in your browser to remember your preference not to be tracked.

Cookies settings

Accept Decline

[](https://www.narcitymedia.com/)

*   [Advertising & Media Solutions](https://www.narcitymedia.com/media-solutions)

*   [Rally](https://www.narcitymedia.com/rally)

*   [Case Studies](https://www.narcitymedia.com/case-study)

*   [Careers](https://www.narcitymedia.com/careers)

*   [Contact](https://www.narcitymedia.com/contact)

*   [About](https://www.narcitymedia.com/about)

*   [Press](https://www.narcitymedia.com/press)

*   [Advertising Terms & Conditions](https://www.narcitymedia.com/advertising-terms-conditions)

*   [Brand Safety Policy](https://www.narcitymedia.com/brand-safety-policy)

*   [Political Ads Registry](https://www.narcitymedia.com/political-ads-registry)

*   [Privacy Policy](https://www.narcitymedia.com/privacy-policy)

[](https://www.facebook.com/NarcityMedia/)[](https://www.instagram.com/narcitymedia/)[](https://twitter.com/narcitymedia)[](https://www.linkedin.com/company/narcity-media-group)[](https://www.tiktok.com/@narcitymedia)

2025 All rights reserved. Narcity Media Inc.

[](https://www.facebook.com/NarcityMedia/)[](https://www.instagram.com/narcitymedia/)[](https://twitter.com/narcitymedia)[](https://www.linkedin.com/company/narcity-media-group)[](https://www.tiktok.com/@narcitymedia)

[](https://www.narcitymedia.com/)

[Get in touch](https://www.narcitymedia.com/contact)[](javascript:void(0))

[![Image 1: Social CPC product by narcity media group](https://www.narcitymedia.com/hubfs/social_cpc_product.png)](https://www.narcitymedia.com/press/introducing-social-cpc-our-new-performance-ad-product)
May 12, 2025

#### Introducing Social CPC: our new performance ad product

Drive tangible results with our new mid-funnel advertising product.**...[keep reading](https://www.narcitymedia.com/press/introducing-social-cpc-our-new-performance-ad-product)**

[![Image 2: Social CPC product by narcity media group](https://www.narcitymedia.com/hubfs/social_cpc_product.png) May 12, 2025 Introducing Social CPC: our new performance ad product](https://www.narcitymedia.com/press/introducing-social-cpc-our-new-performance-ad-product)

[![Image 3](https://www.narcitymedia.com/hubfs/Target%20Right%20Audience.jpg) March 28, 2025 5 audience targeting questions to help you perfect your marketing in 2025](https://www.narcitymedia.com/press/5-questions-to-help-you-target-the-right-audience)

[![Image 4](https://www.narcitymedia.com/hubfs/Benefits.jpg) March 25, 2025 6 benefits of launching display ads in 2025](https://www.narcitymedia.com/press/6-benefits-of-digital-display-advertising)

[![Image 5](https://www.narcitymedia.com/hubfs/localstv-app-screenshots_v3.png) March 6, 2025 Introducing Locals.tv, our new local video app](https://www.narcitymedia.com/press/introducing-localstv-our-new-local-video-app)

[![Image 6: Narcity Media integrates with The Trade Desk's OpenPath](https://www.narcitymedia.com/hubfs/narcitymedia-trade-desk-openpath.png) December 2, 2024 Narcity Media integrates with The Trade Desk's OpenPath](https://www.narcitymedia.com/press/narcity-media-integrates-with-openpath)

[![Image 7: Haligonia and NMG Announce Strategic Sales Partnership](https://www.narcitymedia.com/hubfs/haligonia_narcitymediagroup_salespartnership.png) October 25, 2024 Haligonia and NMG Announce Strategic Sales Partnership](https://www.narcitymedia.com/press/haligonia-and-nmg-announce-strategic-sales-partnership)

[![Image 8](https://www.narcitymedia.com/hubfs/2024-2025-narcitymediagroup-montrealcanadiens.png) August 16, 2024 Narcity Media Group renews partnership with the Montreal Canadiens for 24-25 Season](https://www.narcitymedia.com/press/narcity-media-group-renews-partnership-with-the-montreal-canadiens-for-24-25-season)

[![Image 9: Narcity Media Group is back on Meta](https://www.narcitymedia.com/hubfs/narcitymedia_backonmetaplatforms.png) August 2, 2024 Narcity and MTL Blog are back on Meta platforms](https://www.narcitymedia.com/press/narcity-and-mtl-blog-are-back-on-meta-platforms)

[![Image 10](https://www.narcitymedia.com/hubfs/RALLY%20BANNER%20FOR%20NEWS%20LETTER%20.png) July 26, 2024 Rally™ positioned to thrive as Creator Economy nears half-trillion dollar mark by 2027](https://www.narcitymedia.com/press/rally-positioned-to-thrive-as-creator-economy-nears-half-trillion-dollar-mark-by-2027)

[![Image 11](https://www.narcitymedia.com/hubfs/The%20Drop.jpg) June 6, 2024 "The Drop" Triumphs at the 2024 Canadian Screen Awards with Two Wins](https://www.narcitymedia.com/press/the-drop-wins-two-canadian-screen-awards)

[![Im

*[... truncated, 25,727 more characters]*

---

### Are advertisers over-indexing on Android vs iOS?
*591 words* | Source: **GOOGLE** | [Link](https://uk.themedialeader.com/are-advertisers-over-indexing-on-android-vs-ios/)

##### **Analysis**

“This is a big WTF.”

In a [LinkedIn post](https://www.linkedin.com/feed/update/urn:li:activity:7167962583113678849/) this week, Chuck Lapointe, CEO of Toronto-based Narcity Media Group, pointed to what he saw as a major disconnect between programmatic buying strategies and reality.

Sharing his company’s ad exchange impressions alongside their average revenue per 1,000 ad impressions (defined as eCPM) for both iPhone and Android users, the data showed that the average Android eCPM was more than double that of iPhones.

This is despite, as Lapointe pointed out, the fact that iOS has a [higher market share](https://www.statista.com/statistics/487373/market-share-mobile-operating-systems-uk/#:~:text=Apple's%20iOS%20was%20the%20leading,the%20market%20leader%20in%202019.) in the UK, US and Canada, and generally its users [spend more](https://www.prnewswire.com/news-releases/iphone-users-spend-101-every-month-on-tech-purchases-nearly-double-of-android-users-according-to-a-survey-conducted-by-slickdeals-300739582.html?c=n) than Android ones.

He asked: “In what industry, apart of the programmatic media complex, do we value users that spend _and_ engage less over 150% higher than users with higher spend and engagement?”

‘Vast majority of bots are Android and Chrome’
----------------------------------------------

Other industry figures confirmed that they saw a similar phenomenon of under-investment in iOS and Apple’s browser, Safari.

Among them was ad fraud specialist Dr Augustine Fou, who penned a [Substack post](https://fouanalytics.substack.com/p/ios-is-63-cheaper-and-accounts-for) three years ago on how iOS is not only cheaper but also accounts for most real clicks on programmatic ads.

“Marketers […] are bidding less on traffic without IDs because they think that there is less targeting and reduced ability to track outcomes,” Fou wrote in his post, referring to Apple’s relative lack of user tracking under its then-new app tracking transparency (ATT) policy.

“Because they avoid bidding on iOS or bid lower for iOS devices, the CPMs for iOS devices are far less than the CPMs for Android and desktop web (while third-party cookies remain in effect).”

Apple’s ATT policy has made ad buying less convenient and performance less measurable on iOS devices. On the other hand, Google dominates the digital advertising market through its Google Ads platform and its continued use of third-party cookies has attracted ongoing investment. So it follows that fewer advertisers have bought on iOS and Safari.

However, the majority of valid engagement with ads, according to Fou, comes from iOS devices.

“Ads shown to iOS users account for the majority of human clicks, despite the lack of cookies and identifiers,” Fou told _The Media Leader_. “Keep in mind that bots love to pretend to be Android and Chrome, because they can earn higher CPMs than if they pretended to be iOS. So, by far, the vast majority of bots are Android and Chrome.”

Google did not respond to a request for comment.

Slow deprecation
----------------

Jonathan Harrison, head of digital strategy at the7stars, told _The Media Leader_ that the discrepancy is something the agency is aware of in the UK market.

“It comes down to measurement and, sometimes, a lack of understanding really where your automated tech is optimising towards,” he explained.

“It’s also something that’s going to be even more apparent this year as ‘cookieless’ rolls out more fully and advertisers start to see dips in their performance.”

Whereas Safari has blocked third-party cookies since 2020, Google has repeatedly delayed cookie deprecation on Chrome. In January, the company finally [began deprecating cookies for 1% of users](https://uk.themedialeader.com/google-1-cookie-deprecation-what-will-change/), with continued deprecation expected throughout 2024.

So it may be that, through Google’s deprecation of cookies, some of Android’s relative advantage over iOS could therefore decline. But, in an exchange with _The Media Leader,_ Lapointe expressed doubt over any such erosion of Google’s positioning.

He said: “I don’t think [cookie deprecation] will have much impact, because I think Google will figure out a way to make the spend work within their ecosystem.”

---

### Narcity Media Group launches 'Rally' creator talent agency - Broadcast Dialogue
*1,879 words* | Source: **GOOGLE** | [Link](https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/)

Narcity Media Group launches 'Rally' creator talent agency - Broadcast Dialogue

===============

[Facebook](https://www.facebook.com/broadcastdialogue/ "Facebook")[Instagram](https://www.instagram.com/broadcastdialogue/ "Instagram")[Linkedin](https://www.linkedin.com/company/broadcast-dialogue "Linkedin")[Mail](mailto:info@broadcastdialogue.com "Mail")[Spotify](https://open.spotify.com/show/4AIZVJ4RopqEAKgEhPu9gx "Spotify")[Twitter](https://twitter.com/BroadcastDialog "Twitter")

*   [Sign In](https://broadcastdialogue.com/my-account/)
*   [Subscribe Now – Free!](https://broadcastdialogue.com/subscribe)
*   [Job Listings](https://broadcastdialogue.com/careers-2/)
*   [Post Your Job Listing](https://broadcastdialogue.com/post-a-career/)
*   [Events](https://broadcastdialogue.com/events/)
*   [Advertise With Us](https://broadcastdialogue.com/advertising/)
*   [About](https://broadcastdialogue.com/about/)
*   [Contact](https://broadcastdialogue.com/contact/)

Search

[![Image 4: topLogo](https://broadcastdialogue.com/wp-content/uploads/2016/08/topLogo.png)Broadcast Dialogue Broadcast Dialogue](https://broadcastdialogue.com/)

*   [Sign In](https://broadcastdialogue.com/my-account/)
*   [Subscribe Now – Free!](https://broadcastdialogue.com/subscribe)
*   [Job Listings](https://broadcastdialogue.com/careers-2/)
*   [Post Your Job Listing](https://broadcastdialogue.com/post-a-career/)
*   [Events](https://broadcastdialogue.com/events/)
*   [Advertise With Us](https://broadcastdialogue.com/advertising/)
*   [About](https://broadcastdialogue.com/about/)
*   [Contact](https://broadcastdialogue.com/contact/)

[Twitter](https://twitter.com/BroadcastDialog "Twitter")

[Instagram](https://www.instagram.com/broadcastdialogue/ "Instagram")

[Linkedin](https://www.linkedin.com/company/broadcast-dialogue "Linkedin")

[Spotify](https://open.spotify.com/show/4AIZVJ4RopqEAKgEhPu9gx "Spotify")

[Mail-1](mailto:info@broadcastdialogue.com "Mail-1")

[![Image 5: topLogo](https://broadcastdialogue.com/wp-content/uploads/2016/08/topLogo.png)](https://broadcastdialogue.com/)

[![Image 6](https://broadcastdialogue.com/wp-content/uploads/2025/02/MusicMater728x90.jpg)](https://musicmaster.com/?webbd)![Image 7](blob:http://localhost/5b53771eeb35929db25773b2f8b22705)

*   [Radio + Podcast](https://broadcastdialogue.com/category/radio-audio/)
*   [TV + Film](https://broadcastdialogue.com/category/television-film/)
*   [Online](https://broadcastdialogue.com/category/online-digital/)
*   [Tech](https://broadcastdialogue.com/category/broadcast-tech/)
*   [General News](https://broadcastdialogue.com/category/general/)
*   [Revolving Door](https://broadcastdialogue.com/category/revolving-door/)
*   [Sign Offs](https://broadcastdialogue.com/category/sign-offs/)
*   [The Podcast](https://broadcastdialogue.com/category/broadcast-dialogue-podcast/)
*   [Jobs](https://broadcastdialogue.com/careers-2/)

Search

[](https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/#)

[Home](https://broadcastdialogue.com/)[Latest News](https://broadcastdialogue.com/category/latest-news/ "View all posts in Latest News")Narcity Media Group launches 'Rally' creator...

Narcity Media Group launches ‘Rally’ creator talent agency
==========================================================

[![Image 8: Connie Thiessen](https://broadcastdialogue.com/wp-content/uploads/2024/04/avatar_user_44_1712622561-96x96.jpg)](https://broadcastdialogue.com/author/connie/ "Connie Thiessen")

[Connie Thiessen](https://broadcastdialogue.com/author/connie/)

November 28, 2023

[Twitter](https://twitter.com/intent/tweet?text=Narcity+Media+Group+launches+%E2%80%98Rally%E2%80%99+creator+talent+agency&url=https%3A%2F%2Fbroadcastdialogue.com%2Fnarcity-media-group-launches-creator-talent-agency-rally%2F&via=BroadcastDialog+ "Twitter")[Linkedin](https://www.linkedin.com/shareArticle?mini=true&url=https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/&title=Narcity+Media+Group+launches+%E2%80%98Rally%E2%80%99+creator+talent+agency "Linkedin")[Email](mailto:?subject=Narcity%20Media%20Group%20launches%20%E2%80%98Rally%E2%80%99%20creator%20talent%20agency&body=https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/ "Email")[Copy URL](https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/ "Copy URL")

[](https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/# "More")

[![Image 9](https://broadcastdialogue.com/wp-content/uploads/2025/11/dielectric_fm_digital_728x90.png)](https://dielectric.com/)![Image 10](blob:http://localhost/5b53771eeb35929db25773b2f8b22705)

_**Narcity Media Group**_ (NMG) has announced the launch of new local creator talent agency, [_**Rally**_,](https://www.rallycreators.com/) focused on local Canadian creators who might be overlooked by larger talent agencies.

![Image 11](https://broadcastdialogue.com/wp-content/uplo

*[... truncated, 17,130 more characters]*

---

### The Weekly Briefing - Broadcast Dialogue
*5,134 words* | Source: **GOOGLE** | [Link](https://broadcastdialogue.com/twb-rsa-081822/)

**REVOLVING DOOR:**
-------------------

**![Image 1](https://broadcastdialogue.com/wp-content/uploads/2022/08/lisa-laflamme.jpg)Lisa LaFlamme**[has revealed](https://broadcastdialogue.com/bell-terminates-chief-anchor-lisa-laflammes-contract/) that **Bell Media** terminated her contract at the end of June after 35 years with **_CTV,_**the last 11 as Chief News Anchor and Senior Editor. In its own release, Bell announced LaFlamme’s departure Monday afternoon, saying that “Recognizing changing viewer habits, CTV recently advised LaFlamme that it had made the business decision to move its acclaimed news show, CTV National News, and the role of its Chief News Anchor in a different direction.” LaFlamme, 58, took to social media with her own version of events, saying she’d been “blindsided” by the company and asked to keep her release quiet. She began her career at CTV Kitchener affiliate, **_CKCO,_** as a copywriter and script assistant, going on to serve as a foreign correspondent, and co-host _Canada AM_ in the early 2000s, among other roles. LaFlamme’s unceremonious departure has dominated headlines and spurred numerous editorials, including insights from former CTV colleague [**Kevin Newman**](https://theline.substack.com/p/kevin-newman-a-messy-goodbye-to-a?r=35clq&s=r&utm_campaign=post&utm_medium=email), _**Toronto Sun**_ columnist **[Brian Lilley](https://torontosun.com/opinion/columnists/lilley-the-full-story-behind-lisas-laflamme-out-at-ctv-national)**, and our own editor **[Connie Thiessen](https://broadcastdialogue.com/editorial-laflamme-buyout-evidence-no-one-immune-as-broadcast-journalism-finds-it-place-in-digital-age/)**.

[![Image 2](https://broadcastdialogue.com/wp-content/uploads/2022/08/jo_banner_cab_director_policy_regulatory_ottawa.png)](https://broadcastdialogue.com/job/director-policy-and-regulatory-affairs/)

![Image 3](https://broadcastdialogue.com/wp-content/uploads/2019/04/image-1-224x300.jpg)

Omar Sachedina

**Omar Sachedina** has been named incoming Chief News Anchor and Senior Editor of _CTV National News,_ effective Monday, Sept. 5. Sachedina, who holds a Master of Science degree from **_Columbia Journalism School_**, is currently the network’s National Affairs Correspondent and has been with CTV since 2009. Among other roles, he’s served as Parliamentary Correspondent, contributed to _W5,_ and served as a fill-in host for both CTV National News and _CTV Power Play_. Sachedina’s began his career as an intern at **_Global_** in Vancouver and Montreal. He’s also worked for CTV Northern Ontario, **_Citytv_**, and **_CP24_**.

![Image 4](https://broadcastdialogue.com/wp-content/uploads/2022/08/alicia-barin-crtc-300x225-1.jpg)

Alicia Barin

**Alicia Barin** has been appointed the **_CRTC’s_** interim Vice-Chair of Broadcasting for the next six months. The Quebec commissioner temporarily succeeds **Caroline J. Simard**, who in June was named the new Commissioner of**_Canada Elections_**. Simard’s term was set to end in September.

![Image 5](https://broadcastdialogue.com/wp-content/uploads/2022/08/01b100185506-300x200.jpg)

Darren Throop

**Darren Throop**, President and CEO of **_Entertainment One_** (eOne), will step down at the end of the year when his contract runs out. Throop began his career in Halifax when he opened **_Urban Sound Exchange_**, building an independent chain of music stores, which led to the purchase of **_ROW Entertainment_**which eventually become eOne. The company went public in 2007. His exit follows **_Hasbro’s_** acquisition of the company in 2019.

[![Image 6](https://broadcastdialogue.com/wp-content/uploads/2022/08/jo_banner_bd_cartt_account_executive_remote.png)](https://broadcastdialogue.com/job/account-executive-broadcast-dialogue-cartt-ca/)

![Image 7](https://broadcastdialogue.com/wp-content/uploads/2022/08/VL-lmeXC_400x400-e1660789126642-194x300.jpg)

Catherine Cullen

**Catherine Cullen** is the incoming host of **_CBC Radio’s_**_The House_, succeeding**Chris Hall**who retired as National Affairs Editor at the end of June. Cullen has been a senior reporter in the Parliamentary Bureau since 2014 and with the public broadcaster since 2005, starting as a researcher and eventually TV reporter at CBC Montreal.

![Image 8](https://broadcastdialogue.com/wp-content/uploads/2022/08/1659030191748-e1660707840400-222x300.jpg)

Julie Nolin

**Julie Nolin** has left **_CTV_**Vancouver for **_Global BC_**. Nolin had been a multi-platform journalist and anchor with CTV Vancouver since 2013. She started her career as an intern with the network before moving on to print and eventually **_A-Channel_** in Calgary and Edmonton, **_Citytv_**Vancouver and **_CHEK News_** Victoria, among other stops. Nolin previously worked as a technical producer at Global BC from 2009-12.

![Image 9](https://broadcastdialogue.com/wp-content/uploads/2022/08/image001-1-e1660707879646.jpg)

Robin LaRose

**Robin LaRose** has returned to the time slot he first held when he joined Vancouver’s *

*[... truncated, 44,609 more characters]*

---

### Canadian Online Publishing Awards
*8,088 words* | Source: **GOOGLE** | [Link](https://canadianonlinepublishingawards.com/2022/winners)

Canadian Online Publishing Awards

===============

[![Image 1: Canadian Online Publishing Awards](https://canadianonlinepublishingawards.com/images/layout/logo_2020.png)](https://canadianonlinepublishingawards.com/)

PRESENTED BY:

[![Image 2: Masthead Online](https://canadianonlinepublishingawards.com/images/layout/masthead.png)](https://mastheadonline.com/)

![Image 3: Canadian Online Publishing Awards Let You Show Canada that You're the Best.](https://canadianonlinepublishingawards.com/images/2020/slogan.png)

[![Image 4: Business Wire](https://northislandpublishing.com/ads/www/images/639d3782548522bbcfc13cd9995209df.png)](https://northislandpublishing.com/ads/www/delivery/ck.php?oaparams=2__bannerid=70__zoneid=113__cb=1261071d57__oadest=https%3A%2F%2Fservices.businesswire.com%2Fmedia-journalist-tools%3Futm_source%3Dcopa%26utm_medium%3Dreferral%26utm_campaign%3Dfy22-copa%26utm_content%3Dcopasponsor)

![Image 5](https://northislandpublishing.com/ads/www/delivery/lg.php?bannerid=70&campaignid=19&zoneid=113&loc=https%3A%2F%2Fcanadianonlinepublishingawards.com%2F2022%2Fwinners&cb=1261071d57)

![Image 7](https://www.google.com/images/cleardot.gif)[![Image 8](https://www.google.com/images/cleardot.gif)​![Image 9](https://www.google.com/images/cleardot.gif)▼](https://canadianonlinepublishingawards.com/2022/winners#)

*   [Home](https://canadianonlinepublishingawards.com/ "COPA")
*   [Winners](javascript:void(0) "winners")
    *   [Winners & Finalists](https://canadianonlinepublishingawards.com/winners "winners")
    *   [Promote Your Award](https://canadianonlinepublishingawards.com/promote "promote")

*   [Entry](https://canadianonlinepublishingawards.com/2025/entry "entry")
*   [Judging](javascript:void(0) "judges")
    *   [Judges](https://canadianonlinepublishingawards.com/judges "judges")
    *   [Judge Form](https://canadianonlinepublishingawards.com/judge "Call for Judges")

*   [Sponsors](https://canadianonlinepublishingawards.com/sponsors "sponsors")
*   [Rules](https://canadianonlinepublishingawards.com/rules "rules")
*   [About](https://canadianonlinepublishingawards.com/about "about")
*   [Contact](https://canadianonlinepublishingawards.com/contact "contact")

GOLD SPONSOR:

[![Image 10: Readers Digest](https://canadianonlinepublishingawards.com/images/2014/sponsors/rd.png)](http://www.readersdigest.ca/)

SUPPORTERS:

[![Image 11: Inovva](https://canadianonlinepublishingawards.com/images/2017/sponsors/Inovva175pixelogo.png)](http://www.inovva.com/)

![Image 12: Digital Reno](https://canadianonlinepublishingawards.com/images/2016/sponsors/adclub.png)

[![Image 13: CCAB](https://canadianonlinepublishingawards.com/images/2016/sponsors/ccab.png)](http://www.bpaww.com/)

[![Image 14: CNW](https://canadianonlinepublishingawards.com/images/2017/sponsors/cision.png)](http://www.newswire.ca/)

![Image 15: Digital Reno](https://canadianonlinepublishingawards.com/images/2014/sponsors/digital_reno.png)

![Image 16](https://canadianonlinepublishingawards.com/images/2017/sponsors/SPoinMaster.png)

[![Image 17: Newspapers Canada](https://canadianonlinepublishingawards.com/images/sponsors/nmc.jpg)](http://newspaperscanada.ca/)

[![Image 18: Universities Canada](https://canadianonlinepublishingawards.com/images/2016/sponsors/uaau.png)](http://www.universityaffairs.ca/)

Winners and Finalists 2022

**Academic**

**Business**

**Consumer**

**Media**

**Ethnic**

[Best Feel Good Story (free)](javascript:void(0))

[Best Multicultural Story (free)](javascript:void(0))

[Best Photo Journalism](javascript:void(0))

[Best Podcast](javascript:void(0))

[Best Video Content](javascript:void(0))

[Best Content Marketing Campaign](javascript:void(0))

[Best Digital Edition Publication](javascript:void(0))

[Best Web Site](javascript:void(0))

[Best Feel Good Story (free)](javascript:void(0))

[Best Multicultural Story (free)](javascript:void(0))

[Best Blog Column/Videocast/Podcast](javascript:void(0))

[Best Industry Feature](javascript:void(0))

[Best Company Feature](javascript:void(0))

[Best Investigative Article](javascript:void(0))

[Best Product Story](javascript:void(0))

[Best Video Content](javascript:void(0))

[Best Podcast](javascript:void(0))

[Best Virtual Event/Webinar](javascript:void(0))

[Best Email Newsletter Design](javascript:void(0))

[Best B2B Web Site](javascript:void(0))

[Best Feel Good Story (free)](javascript:void(0))

[Best Multicultural Story (free)](javascript:void(0))

[Best Blog Column/Videocast/Podcast](javascript:void(0))

[Best Service Article](javascript:void(0))

[Best Lifestyle Article](javascript:void(0))

[Best Investigative Article](javascript:void(0))

[Best Photo Journalism](javascript:void(0))

[Best Video Content](javascript:void(0))

[Best Podcast](javascript:void(0))

[Best Virtual Event/Webinar](javascript:void(0))

[Best Content Marketing Campaign](javascript:void(0))

[Best Email Newsletter Design](javascript:void(0))

[Best Digital Edition Publication](javascript:void(0))

[

*[... truncated, 97,710 more characters]*

---

### Jessica Patterson – Independent Media Reporter
*22,282 words* | Source: **GOOGLE** | [Link](https://digitalcontentnext.org/blog/author/jessicapatterson/)

[![Image 1: -Gen Z audience enjoying digital and analog media-](https://digitalcontentnext.org/wp-content/uploads/2025/11/GenZaudience.jpg)](https://digitalcontentnext.org/blog/2025/11/13/reaching-gen-z-means-mastering-authenticity-and-algorithms/ "Reaching Gen Z means mastering authenticity and algorithms")

Publishers are rethinking how they show up on social platforms in 2025, places where Gen Z and Gen Y increasingly discover content through algorithms. Recent [DCN research](https://digitalcontentnext.org/blog/2025/05/20/how-gen-z-gen-y-are-redefining-video-engagement/) reveals that these generational audiences’ media diets are dominated by algorithmically surfaced video. Individual creators now outperform traditional media brands on trust, creativity, and entertainment value. This trend challenges publishers to adapt their approaches while maintaining editorial integrity.

The visibility challenge is fundamental: algorithmic feeds surface content based on engagement rather than quality or brand recognition. Publishers are no longer guaranteed an audience simply because someone follows them. Every post competes equally with creators, memes, and friends’ updates, making traditional media brands just another scroll in the feed.

Media leaders from The Guardian, The Verge, Eater, share how they’re maintaining relationships with younger audiences through platform-native content, personality and experimentation.

The creator connection
----------------------

Andrew Hare, senior vice president of quantitative research at Magid, and co-author of DCN’s report, “[Decoding video content engagement: Gen Z and Gen Y in focus](https://digitalcontentnext.org/wp-content/uploads/2025/05/DCN-Decoding-Video-Content-Engagement-Gen-Z-and-Gen-Y-in-Focus-Quantitative-2025-May-Public-Abridged.pdf),” points out that creators have fundamentally reset audience expectations. “Creators rewrote the playbook: they win on originality, honesty, and personality,” he says.

Hare notes that the definition of quality has shifted. “At one point it was all about the image, professional appearance; it was basically something you would see on television. Now we realize that when we move into these digital spaces, other factors impact trust. Do you believe the creator or brand? Is it an authentic message? Is it real and unfiltered to some degree?”

The nature of engagement with Gen Z and Gen Y is both reactive and participatory. “I think the remixing, commenting and sharing nature of these platforms has been something that brands have been a bit slower to embrace because it means the conversation might be evolving, and they cede some control,” Hare says. “But, as we are seeing, it is this living conversation that creators have innovated upon and the very thing that provides value on social and YouTube.”

Gen Z trust friends and family most at 88%, followed by individual creators at 79%, with brands at only 61%. Hare says younger generations are suspicious of brands when they see them in their digital spaces. “Brands need to build trust in much the same way creators have in order to prove they can be authentic and real and provide relevant value. Otherwise, they are just noise and in the way of more engaging content.”

Kate Scott-Dawkins, global president of business intelligence at WPP Media, notes this aligns with broader shifts. “We have also seen this shift in terms of ad revenue globally, a majority going to creator platforms and UGC platforms rather than legacy media.”

Tuning tone: platform fluency and authenticity
----------------------------------------------

Publishers emphasized they’re not lowering editorial standards to compete on social platforms, Rather, they’re translating their journalism into formats that work in algorithmically-driven spaces. The challenge they outlined was capturing attention in those critical first seconds while staying true to their standards.

In a world where audiences connect with individuals over brands, developing recognizable voices within their own ranks isn’t just a creative choice, it’s a strategic necessity for publishers. Journalists who embody the brand’s values can humanize it, build trust, and compete with the authenticity that individual creators command.

Success, then, depends on how effectively newsrooms and social teams collaborate, from story development to publication.

At The Guardian, Max Benwell, deputy head of audience for The Guardian US, says encountering content off-platform doesn’t preclude building direct relationships. “Because people are encountering our content off platform and maybe without context about the Guardian, it doesn’t mean they can’t build a direct relationship with us over time,” he says. “But the key is all about looking at the data we have and making sure our off-platform content is as engaging as possible. Then, because of how the algorithms work, we can trust that they’ll start seeing more and more of us.”

Benwell identifies short-form video opportunitie

*[... truncated, 159,217 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Narcity brings UGC to Locals.tv » Media in Canada](https://mediaincanada.com/2025/03/10/narcity-locals-tv-ceo-chuck-lapointe/)**
  - Source: mediaincanada.com
  - *Mar 10, 2025 ... CEO Chuck Lapointe answers our ... Chuck Lapointe, Locals.tv, Narcity, Narcity Media Group. Related Articles. Advocacy group uses pod...*

- **[Are advertisers over-indexing on Android vs iOS? – The Media Leader](https://uk.themedialeader.com/are-advertisers-over-indexing-on-android-vs-ios/)**
  - Source: uk.themedialeader.com
  - *Mar 4, 2024 ... Podcast · Features · The Media Plan · Interviews ... In a LinkedIn post this week, Chuck Lapointe, CEO of Toronto-based Narcity Media ...*

- **[Narcity Media Group launches 'Rally' creator talent agency ...](https://broadcastdialogue.com/narcity-media-group-launches-creator-talent-agency-rally/)**
  - Source: broadcastdialogue.com
  - *Nov 28, 2023 ... Narcity Media Group (NMG) has announced the launch of its new ... Chuck Lapointe, in a company announcement. “We believe there's a .....*

- **[The Weekly Briefing - Broadcast Dialogue](https://broadcastdialogue.com/twb-rsa-081822/)**
  - Source: broadcastdialogue.com
  - *Aug 18, 2022 ... Broadcast Dialogue - The PodcastBroadcast Dialogue - The Podcast ... Chuck Lapointe, Narcity Media Group; Farhan Mohamed, Overstory M...*

- **[2022 Canadian Online Publishing Awards](https://canadianonlinepublishingawards.com/2022/winners)**
  - Source: canadianonlinepublishingawards.com
  - *Technality is a podcast by Narcity Media Group. Jacqueline Swan, Host and ... Chuck Lapointe, CEO. SILVER: click image to view website, rabble.ca rabb...*

- **[Jessica Patterson – Independent Media Reporter, Author at Digital ...](https://digitalcontentnext.org/blog/author/jessicapatterson/)**
  - Source: digitalcontentnext.org
  - *Chuck Lapointe, CEO of Narcity Media Group, saw years of investment disappear because of the ban. ... digital advertising, podcast advertising, podcas...*

- **[Pascale st-onge stories at Techdirt.](https://www.techdirt.com/tag/pascale-st-onge/)**
  - Source: techdirt.com
  - *Oct 2, 2023 ... ... Narcity Media Group, Village Media, and ZoomerMedia Limited wanted nothing to do with this.” – Chuck LaPointe ... Podcast · Resear...*

- **[Working at Narcity Media Group | Glassdoor](https://www.glassdoor.com/Overview/Working-at-Narcity-Media-Group-EI_IE1265335.11,30.htm)**
  - Source: glassdoor.com
  - *Chuck Lapointe. 30% approve of CEO. Companies can't alter or remove reviews ... How do job seekers rate their interview experience at Narcity Media Gr...*

- **[Narcity Media Group "coworker" Reviews | Glassdoor](https://www.glassdoor.ca/Reviews/Narcity-Media-Group-coworker-Reviews-EI_IE1265335.0,19_KH20,28.htm)**
  - Source: glassdoor.ca
  - *Chuck Lapointe. 32% approve of CEO. Companies can't alter or remove reviews ... Glassdoor has 106 Narcity Media Group reviews submitted anonymously by...*

- **[Narcity Media Group Reviews: Pros And Cons of Working At Narcity ...](https://www.glassdoor.com/Reviews/Narcity-Media-Group-Reviews-E1265335.htm)**
  - Source: glassdoor.com
  - *Chuck Lapointe ... Related searches: Narcity Media Group jobs | Narcity Media Group salaries | Narcity Media Group benefits | Narcity Media Group inte...*

---

*Generated by Founder Scraper*
