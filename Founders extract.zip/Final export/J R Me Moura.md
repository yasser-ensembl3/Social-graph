# Jérôme Moura

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403602009007747072 | Article |  |  |  | 0 | 1 | 0 | 3h | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.342Z |  | 2025-12-08T01:11:11.221Z | https://www.notion.so/OpenAI-Code-Red-La-Guerre-de-l-IA-en-D-cembre-2025-8463b251e18c4dcb9e5f64130040f237 |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7403230631284858880 | Article |  |  | Je ne comprends pas comment, en 2025 et à l’aube de 2026, des gens peuvent encore survivre dans des cabanes ou des tentes de fortune à Montréal. Avec ce froid glacial et cette neige incessante, c’est un scandale absolu. Quand leur offrira-t-on enfin une aide concrète et réelle ? | 0 | 0 | 0 | 1d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.342Z |  | 2025-12-07T00:35:27.872Z | https://search.app/54wpT |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7403142523642339328 | Article |  |  |  | 0 | 0 | 0 | 1d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.343Z |  | 2025-12-06T18:45:21.373Z | https://share.google/rSVm73axHd91rOLpc |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7403141859021176832 | Article |  |  |  | 0 | 0 | 0 | 1d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.343Z |  | 2025-12-06T18:42:42.915Z | https://search.app/2TuYr |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7403139071750873088 | Article |  |  |  | 0 | 0 | 0 | 1d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.344Z |  | 2025-12-06T18:31:38.378Z | https://search.app/6Dgdb |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7403138766502064128 | Article |  |  |  | 0 | 0 | 0 | 1d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:47:58.344Z |  | 2025-12-06T18:30:25.601Z | https://share.google/bAWN000gEJjWZnQ7g |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7402207195951734785 | Article |  |  |  | 0 | 0 | 0 | 3d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.811Z |  | 2025-12-04T04:48:41.874Z | https://share.google/kPAqB5p1uysDL2zzH |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7402127142974590976 | Article |  |  |  | 0 | 0 | 0 | 4d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.812Z |  | 2025-12-03T23:30:35.757Z | https://www.youtube.com/watch?v=5ZDsCJ4rGD4&list=RDM4Jjd3pV2t0&index=16 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7401701973839777793 | Article |  |  |  | 0 | 0 | 0 | 5d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.814Z |  | 2025-12-02T19:21:07.536Z | https://search.app/MjQo9 |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7401701289258221568 | Article |  |  |  | 0 | 0 | 0 | 5d | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.815Z |  | 2025-12-02T19:18:24.319Z | https://search.app/RtpqN |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7400358338221350912 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEpgUMf-4eAkQ/feedshare-shrink_800/B4EZrNar5oJ0Ag-/0/1764382918053?e=1766620800&v=beta&t=RRctc5NTRTCz_kErkvQ30xRaGgakzDjtIXO5ZvipSKQ | EXCLUSIF — Voici les premières maquettes officielles de l’interface Letsmoviz. (1ères versions). 

Nous simplifions enfin un secteur qui n’avait jamais été modernisé : le placement de produits dans le cinéma indépendant.

Letsmoviz est la première plateforme WaaS – Workflow as a Service dédiée à connecter, fluidifier et optimiser tout le processus, de la recherche de marques, de projets de films jusqu’au contrat final.

🎬 Pour les entreprises/marques :
·       Suivi précis de vos campagnes
·       Visibilité ciblée
·       Et un ROI qui dépasse largement celui des spots TV traditionnels.

📽️ Pour les producteurs et réalisateurs :
·       Avancement des projets en temps réel
·       Recommandations algorithmiques pertinentes
·       Opportunités de financement accessibles en quelques clics.

Découvrez les deux premiers tableaux de bord : 
·       L’interface Entreprise/Marque
·       L’interface Producteur/Réalisateur

Letsmoviz ouvre les portes d’un marché virtuel international, disponible 24/7, pensé pour faire gagner du temps, sécuriser les budgets et simplifier la vie de toute l’industrie cinématographique.

👉 Prochaine étape : Poursuivre nos efforts vers le programme Disney Accelerator, porté par ✨ The Walt Disney Company.

Letsmoviz arrive avec un produit clair, une vision solide et un secteur qui a besoin d’être transformé.

Suite au prochain épisode.

Letsmoviz, le futur du placement de produits dans les films indépendants. | 1 | 2 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.817Z |  | 2025-11-29T02:21:59.841Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7400298881529569280 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.817Z |  | 2025-11-28T22:25:44.261Z | https://share.google/QAV1Fsbr3QAf6gGmJ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7400295268425965568 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.818Z |  | 2025-11-28T22:11:22.830Z | https://www.tvanouvelles.ca/2025/11/28/japon-la-machine-a-laver-pour-humains-arrive-sur-le-marche |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7399503880260255744 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.818Z |  | 2025-11-26T17:46:41.188Z | https://youtube.com/watch?v=7ihmd9Olmeg&feature=shared |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7399278582918959104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7phHbNZKv-g/feedshare-shrink_800/B4EZq.EqXvIIAg-/0/1764125485126?e=1766620800&v=beta&t=jTZT2JiIqzaHefriWh-XYHATslRErpfQ2LhRy8poo2M |  | 1 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.819Z |  | 2025-11-26T02:51:26.116Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7399207819528380416 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.820Z |  | 2025-11-25T22:10:14.809Z | https://search.app/TX57R |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7399126199962120192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHC2gWlW9foHg/feedshare-shrink_800/B4EZq76EgTHUAk-/0/1764089154267?e=1766620800&v=beta&t=tUafOnb9koUxMkaRgiT2Zz7iqY3Rk6BDROHxXRzMDCg |  | 0 | 1 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.821Z |  | 2025-11-25T16:45:55.188Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7398932540612571136 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.821Z |  | 2025-11-25T03:56:23.201Z | https://share.google/GFOlj1UWgjXuooM93 |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7398878270055927809 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.822Z |  | 2025-11-25T00:20:44.092Z | https://share.google/RN6LZsWoz34ndoFqq |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7398875775413800960 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.822Z |  | 2025-11-25T00:10:49.323Z | https://share.google/HDVzaikcmFPu7NsjP |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7398874554439323648 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.823Z |  | 2025-11-25T00:05:58.220Z | https://youtube.com/watch?v=1hecjDC9BqE&si=5j7zzfasWDV_0V0l |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7398749778450370561 | Article |  |  |  | 0 | 0 | 0 | 1w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.823Z |  | 2025-11-24T15:50:09.306Z | https://youtube.com/watch?v=bkGiQajLaH8&si=ZB1ikcjPO7RxV20S |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7398537023982039040 | Article |  |  |  | 0 | 0 | 0 | 2w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.824Z |  | 2025-11-24T01:44:44.688Z | https://share.google/rFzPAMJ9CsvT9BlFQ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7398184114216144896 | Article |  |  |  | 0 | 0 | 0 | 2w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.824Z |  | 2025-11-23T02:22:24.443Z | https://search.app/1AtsD |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7398183712158277632 | Article |  |  |  | 0 | 0 | 0 | 2w | Post | Jérôme Moura | https://www.linkedin.com/in/jeromemoura | https://linkedin.com/in/jeromemoura | 2025-12-08T04:48:04.824Z |  | 2025-11-23T02:20:48.585Z | https://share.google/hjrk3QExYO4m3YvwL |  | 

---

