# Alexandra Lefort

## Position actuelle

**Titre** : Co-Founder - Lead UX/UI Designer
**Entreprise** : Glowtify
**Durée dans le rôle** : 3 years 7 months in role
**Durée dans l'entreprise** : 3 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

As Co-Founder and Lead UX/UI Designer at Glowtify, I bring nearly two decades of multidisciplinary
design and digital production expertise to the forefront of e-commerce and SaaS innovation. My
leadership at Glowtify is grounded in a proven track record of building intuitive, growth-driven user
experiences and scaling digital teams across industries.

My journey spans founding and scaling Walter Interactive, a renowned digital agency known for its
excellence in user-centric solutionsand leading complex projects for major Canadian brands. This
entrepreneurial and executional background positions me uniquely to steer Glowtify's product vision
and design culture with precision, empathy, and an unrelenting commitment to innovation.

Glowtify's mission to empower Shopify merchants through automated marketing tools aligns directly
with my expertise in UX strategy, digital production, and creative leadership. I am the best
positioned to fulfill this role because Ive built and led teams that solve these exact challenges for
over 15 years designing not just for beauty, but for performance, scalability, and real business
results.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABEs1bABeHeSAiJWWQxg3qdi2sG6o7rohj4/
**Connexions partagées** : 23


---

# Alexandra Lefort

## Position actuelle

**Entreprise** : Glowtify

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Alexandra Lefort

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394407829165461504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFzhW-5-eOr0A/feedshare-shrink_800/B4EZp4XG8wIIAg-/0/1762955915786?e=1766620800&v=beta&t=bbojFOW0HtFNFIwxRXXyeAZwV20av9J0Qjl_w8V_5Eg | Très fière d’annoncer, aux côtés de Marc Allard, Olivier Fradette-Roy et JP Arcand, que Glowtify a levé 3,4 M $ pour aider les petites équipes e-commerce  à transformer leurs idées en campagnes en quelques minutes. 🚀

Un immense merci à nos partenaires investisseurs, en particulier à Accelia Capital, qui investit activement dans le leadership féminin, et à Steve Desjarlais pour ses précieux conseils et son soutien continu. 

Ce n’est que le début. Ne manquez pas la vague! 

→ Contactez mon collègue William Topaczewski pour une démo. | 22 | 2 | 1 | 3w | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:08.868Z |  | 2025-11-12T16:16:47.927Z | https://www.linkedin.com/feed/update/urn:li:activity:7394373054585421824/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7376310859356188672 | Text |  |  | Envie de combiner marketing numérique et relation client au sein d’une équipe dynamique? Rejoins l’aventure Glowtify 🚀 | 4 | 0 | 1 | 2mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:08.870Z |  | 2025-09-23T17:45:54.099Z |  | https://www.linkedin.com/jobs/view/4304943562/ | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7348067108267679746 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE07BEpNY0xxA/feedshare-shrink_800/B4EZfmUGJlG4Ag-/0/1751915718011?e=1766620800&v=beta&t=j8sNd1vDMcNVNm1UfO5FY6-wtTaZs4_GbEHmrXIAfEg | « In a start-up, everyone is a salesperson. »

Quelqu’un m’a dit ça récemment et… ça m'a fait réfléchir.

Je suis designer. Je peux passer des heures à peaufiner un flow ou une composante. Mais vendre ? Ouf. Rien que le mot me donne l’impression d’avoir des chaussures trop grandes.

Et pourtant…

L’autre jour, pendant une activité de team building, j’ai vu notre développeur Zachary M. aborder le coach de Pickleball... et commencer direct par :

 🗣️ « Do you know Glowtify? »

Pas une blague. Je pense que c’est sa phrase d’ouverture préférée.

Moi, je ne suis pas très à l’aise d’en parler spontanément. Je n’ose pas trop dire ce que je fais, encore moins vanter ce qu’on construit. J’ai peur de déranger, d’avoir l’air insistante, ou pire… de me transformer en vendeuse malgré moi. 

Même quand on me pose la question directement — « Et toi, tu fais quoi dans la vie? » — je bloque un peu. Je souris, je dis souvent : « C’est compliqué », puis je change de sujet. Comme si parler de mon travail, c’était déjà trop.

Mais parfois, quand quelqu’un montre un peu de curiosité, me pose deux ou trois questions de plus… je me retrouve à parler de Glowtify pendant une heure.

Est-ce que ça vous fait ça, vous aussi?

Je commence à comprendre que partager ce qu’on crée avec passion, ce n’est pas être fatigante.

C’est juste… croire en ce qu’on fait.

Alors je tente quelque chose aujourd’hui. 
Une petite sortie de ma zone de confort.

Tu me poses une question, et je te parle de Glowtify pendant une heure, deal? 😉 | 34 | 1 | 0 | 5mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.688Z |  | 2025-07-07T19:15:19.096Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7348065086663499777 | Text |  |  | 👋 On cherche une·un Senior Product Designer pour rejoindre l’équipe Glowtify. Si tu as de l’expérience en SaaS, un esprit analytique, de la créativité et l’envie de bâtir des outils innovants avec une vraie portée, on veut te parler.

Tu travailleras en étroite collaboration avec l’équipe de développement dirigée par Olivier Fradette-Roy, et tu joueras un rôle clé dans l’évolution de notre vision produit aux côtés de Marc Allard, JP Arcand et moi-même. | 9 | 0 | 2 | 5mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.688Z |  | 2025-07-07T19:07:17.108Z |  | https://www.linkedin.com/jobs/view/4263602295/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7346869436013834240 | Text |  |  | Un nouveau poste s'ouvre dans notre équipe de développement! Une belle opportunité de collaborer avec Olivier Fradette-Roy et toute l'équipe. 👇 | 3 | 1 | 0 | 5mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.689Z |  | 2025-07-04T11:56:11.779Z |  | https://www.linkedin.com/jobs/view/4262023249/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7315389617313124353 | Article |  |  | Une belle étape pour Glowtify!

Quand on a commencé cette aventure, notre ambition était claire : simplifier la vie des équipes e-commerce avec un outil marketing puissant et accessible. Aujourd’hui, voir Glowtify mis de l’avant dans BetaKit nous rappelle tout le chemin parcouru – et tout ce qu’il reste à construire. 

Merci à nos utilisateurs.trices, à notre équipe de feu, et à tous ceux et celles qui croient en cette vision.

On continue d’avancer, de tester, d’apprendre. Ce n’est que le début. 🚀 | 16 | 3 | 0 | 7mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.694Z |  | 2025-04-08T15:06:38.134Z | https://betakit.com/glowtify-wants-to-be-the-ai-driven-marketing-solution-for-lean-e-commerce-teams/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7303875955427594241 | Document |  |  | Quand on fait partie des 25 % de femmes dans une entreprise tech, on comprend vite à quel point c’est important de se serrer les coudes et de se soutenir, jour après jour.

Fière de côtoyer Cassandra, Fanny et Snehee chez Walter Interactive — trois femmes talentueuses et inspirantes avec qui c’est un vrai plaisir de collaborer. Et tout aussi reconnaissante de pouvoir compter sur Mona et Corina chez Glowtify, avec qui chaque défi devient une belle aventure, menée avec passion.

On continue de prendre notre place, de faire briller nos idées et surtout, de ne jamais oublier qu’ensemble, on va vraiment plus loin. | 17 | 4 | 0 | 9mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.696Z |  | 2025-03-07T20:35:27.227Z | https://www.linkedin.com/feed/update/urn:li:activity:7303841085527642113/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7294516027139256320 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGVquw_gcXNIQ/feedshare-shrink_800/B4EZTtTqj1GYAg-/0/1739148145058?e=1766620800&v=beta&t=O-0xt0fPZLNwUwTqzuwYgfJUhRXJzYwzxGYeNP9yNcI | Chaque année, le Super Bowl n’est pas seulement un événement sportif, c’est aussi l’arène ultime du marketing. Les plus grandes marques y déploient des stratégies audacieuses, des campagnes percutantes et des publicités à plusieurs millions de dollars pour capter l’attention du public. Mais au-delà des projecteurs du stade, chaque entreprise – grande ou petite – doit orchestrer son propre Super Bowl marketing tout au long de l’année.

La clé? Unifier les efforts pour maximiser l’impact. Comme une équipe bien rodée sur le terrain, une stratégie marketing efficace repose sur la coordination parfaite des canaux : courriels, publicités, réseaux sociaux, SEO… Tout doit fonctionner en synergie pour marquer des points et convertir les opportunités.

Si vous avez manqué l’occasion de capitaliser sur l’engouement du Super Bowl, Glowtify «would have tackled it for you». Notre solution automatise et unifie vos stratégies marketing pour que vous ne laissiez plus jamais passer une opportunité de marquer. | 13 | 0 | 1 | 9mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.696Z |  | 2025-02-10T00:42:26.424Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7291483484064239616 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEqCqRKnIIEPA/feedshare-shrink_800/B4EZTCNlqYHMAk-/0/1738425130241?e=1766620800&v=beta&t=HXBkhtUENQs5F1vCVvJHCNplmTmVhMfWLB8SAcpY1kc | J’ai partagé beaucoup de publications de Glowtify dernièrement, mais je ne parle pas souvent de mon implication dans cette entreprise.

Il y a presque trois ans, avec Marc Allard, Olivier Fradette-Roy et JP Arcand, on a cofondé Glowtify, une application SaaS conçue pour simplifier la vie des directeurs marketing. Parce qu’on le sait tous : jongler avec plusieurs plateformes, organiser les efforts de son équipe et garder une vue d’ensemble de sa stratégie, ce n’est pas toujours évident.

C’est exactement ce problème que nous nous sommes donné pour mission de résoudre. Notre application centralise tous les efforts marketing en un seul endroit, permettant non seulement d’avoir une vision claire des actions en cours et un message cohérent sur différentes plateformes (cohesive marketing), mais aussi d’obtenir des recommandations adaptées à chaque canal et de générer rapidement du contenu pertinent (no more balls dropped). Une vraie vue 360° pour les équipes marketing qui veulent gagner du temps et être plus efficaces.

On est fiers de voir ce projet évoluer et, surtout, de constater à quel point il répond à un réel besoin sur le terrain. Si ça t’intrigue et que tu veux en savoir plus, n’hésite pas à m’écrire ou à contacter William Topaczewski pour une démo! | 86 | 0 | 1 | 10mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.697Z |  | 2025-02-01T15:52:11.813Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7284736262563872768 | Text |  |  | Notre équipe de développeurs s’agrandit rapidement et nous sommes toujours à la recherche de la personne idéale pour ce rôle clé. 

N’hésitez pas à nous référer le ou les meilleurs développeurs de votre réseau! 👀 | 5 | 1 | 0 | 10mo | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.699Z |  | 2025-01-14T01:01:08.850Z |  | https://www.linkedin.com/jobs/view/4125073993/ | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7269796179926777858 | Text |  |  | Nous sommes toujours à la recherche de la perle rare du développement qui sera notre deuxième Olivier! Tu es ou connais quelqu’un qui serait intéressé à relever le défi? Viens nous rencontrer! 👋 | 2 | 0 | 0 | 1yr | Post | Alexandra Lefort | https://www.linkedin.com/in/alexandra-lefort-04060280 | https://linkedin.com/in/alexandra-lefort-04060280 | 2025-12-08T06:10:12.701Z |  | 2024-12-03T19:34:35.576Z | https://www.linkedin.com/feed/update/urn:li:activity:7262191970142285825/ | https://www.linkedin.com/jobs/view/4074768675/ | 

---



---

# Alexandra Lefort
*Glowtify*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Glowtify wants to be the AI-driven marketing solution for lean e-commerce teams | BetaKit](https://betakit.com/glowtify-wants-to-be-the-ai-driven-marketing-solution-for-lean-e-commerce-teams/)
*2025-04-08*
- Category: article

### [About - Glowtify](https://glowtify.com/about/)
*2025-05-01*
- Category: article

### [Glowtify | LinkedIn](https://ca.linkedin.com/company/glowtify)
*2025-05-08*
- Category: article

### [Glowtify welcomes new strategic investors and advisors](https://glowtify.com/glowtify-welcomes-new-strategic-investors-and-advisors/)
*2024-02-06*
- Category: article

### [Glowtify - 2025 Company Profile - Tracxn](https://tracxn.com/d/companies/glowtify/__BS0-MpF8_8sZ6tBUt3DlO519W2uwfK1v8EtUfiNyFr0)
*2025-05-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Glowtify wants to be the AI-driven marketing solution for lean e ...](https://betakit.com/glowtify-wants-to-be-the-ai-driven-marketing-solution-for-lean-e-commerce-teams/)**
  - Source: betakit.com
  - *Apr 8, 2025 ... Podcast · Newsletter · Quiz · Jobs. Glowtify wants to be the AI ... Glowtify founding team, from L to R: co-founder Alexandra Lefort, ...*

- **[About - Glowtify](https://glowtify.com/about/)**
  - Source: glowtify.com
  - *Talk to an ecomm expert. X. Login · Sign up free · FR. X. Meet Glowtify ... Alexandra Lefort. Co-Founder & Creative Lead. Will. William Topaczewski. H...*

---

*Generated by Founder Scraper*
