# Jon Yu

## Position actuelle

**Titre** : Founder - CEO | Systems Design
**Entreprise** : ELYSIUM
**Durée dans le rôle** : 4 years 11 months in role
**Durée dans l'entreprise** : 4 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

We democratize creative and innovative access to spatial computing by removing the cost and complexity, and enable you to build and deploy interactive augmented reality (AR) worlds with drag-and-drop no-code tools powered by real-time cloud infrastructure. 

ELYSIUM allows anyone to create and share connected, geolocated, and persistent augmented reality worlds for social play at the intersection of people, place and data. With our GEIST interaction engine, ELYSIUM represents a modular and scalable framework for anyone to develop and deploy their own spatial computing layer for unique games, applications and experiences.

## Résumé

Powering Innovation with Spatial Computing with creative solutions at MYTHOLOGI.

We're building Augmented Reality (AR) worlds for the future of Social Play and Real-World Engagement with ELYSIUM.

My vision is to unleash human creativity in building this next dimension for social connectivity. Play to create and actively engage in real world spaces. Share persistent worlds of connected experiences that tell your stories and build fan communities. 

We're turbo charging innovation with spatial computing by democratizing creative access and new models of ownership with ELYSIUM's no-code creation tools and infrastructure.

At MYTHOLOGI, we're an interaction and technology design studio focused on the gamification of engagement with augmented reality (AR) and immersive technologies. I direct both technical and creative development as we build creative tools and necessary infrastructure for this next dimension of connected play.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAgMVlIB66ELMy1BhQ2nseNDed_aekM360M/
**Connexions partagées** : 72


---

# Jon Yu

## Position actuelle

**Entreprise** : ELYSIUM

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jon Yu

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7387618010682851328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGqammbheOOOg/feedshare-shrink_800/B4EZoYUrVhIUAg-/0/1761344667363?e=1766620800&v=beta&t=d8ah3WFy7FTR16PvVm2Arj1ME2k1qRb49neESRouoas | Whose else is excited for Game 1 tonight?!!!!

LFG Toronto Blue Jays from us out here in Montreal!

Completely admitting that I’m a total bandwagonner when it comes to baseball, but that’s the power of sports to convert stoic non-believers like myself in a shared social experience

#fandom #sports #loyalty #gamification #augmentedreality | 5 | 0 | 0 | 1mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:08.958Z |  | 2025-10-24T22:36:29.052Z | https://www.linkedin.com/feed/update/urn:li:activity:7387614988753858560/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7385016062049673217 | Article |  |  | Just a last minute reminder about our Lunch+Learn event next Tuesday!
Come join us over lunch to learn about designing for spatial experiences with AR. 

Lunch is included  for those interested in joining us for the hands-on workshop in the afternoon. (brought to you from our friends: the Parc Ex Curry collective!)

https://lnkd.in/ewMDd-jb | 5 | 0 | 0 | 1mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:08.958Z |  | 2025-10-17T18:17:16.156Z | https://luma.com/y5v18wnz?coupon=TXMYNZ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7383545586957959168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGIyvJx_fAXDQ/feedshare-shrink_800/B4EZnedD3kKcAk-/0/1760373784561?e=1766620800&v=beta&t=qxjZ46AHm2TvMpbNQvb8EL0rrn8BRCWlRRR5xazXMxw | Come join me and the McGillXR team next Tuesday (Oct 21st) for our Lunch & Learn at Ax-C!  Bring your own lunch or let us provide the food. We'll have a fun discussion about how to design for innovation with Spatial Computing. 

Afterwards, sign up to Stay & Play in a hands-on workshop to create and build your own Augmented Reality experience with AI and no-code tools. (snacks included!) 

No experience necessary, just bring your imagination and ideas. 

🎉 Special Offer: The next 10 people to connect and DM me with "World building" will get a link for 50% off the ticket price! | 12 | 3 | 0 | 1mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:08.959Z |  | 2025-10-13T16:54:07.574Z | https://www.linkedin.com/feed/update/urn:li:activity:7383542817475973121/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7382371645165944832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGKkD_ILwBCwg/feedshare-shrink_800/B4EZnNz4QTHMAk-/0/1760094554666?e=1766620800&v=beta&t=2vy2RgKARgQ-8Q4QG6C96G9-Ycjz1z7zYAF60xaB3CE | It was a pleasure to talk all things immersive, and interactive AR with Justin Baillargeon, Ph.D. on a sunny afternoon. In a wide-ranging conversation, we talked about the unique challenges of persistent AR experiences and the vision that guides us at ELYSIUM where we're democratizing social play and creativity. 

🎧 Have a listen to the full episode available on Spotify
🔗 Link in comments below 👇🏽

#augmentedreality #worldbuilding #experiencedesign #gamedesign #UX #fluidexperiences #Loyalty #gamification | 23 | 1 | 2 | 1mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:08.959Z |  | 2025-10-10T11:09:18.040Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7379249992122703872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGG7J_5vlPfxQ/feedshare-shrink_800/B4EZmhUATwHMAk-/0/1759348000501?e=1766620800&v=beta&t=PSxxV8NCEo-TkC5cEGTrL6HMBFrplr99rgx2RxirRMw | So things have been a whirlwind out here in Toronto (more on that coming soon.). But, next stop Viva Las Vegas! 

I'm glad to have met Ryan Rubio a while back via Florence Barbeau and MT Lab and am excited to have been invited to join him and the team at Zero Labs for this opportunity to bring ELYSIUM to the Vegas ecosystem. 

If you're in town DM me here and we'll send you and exclusive invite to the networking event. Come play with ELYSIUM and see for yourself how we're unlocking new modes of fandom with active play and engagement. 

(Yep. I'll also be at the Global Gaming Expo 6-8th) | 23 | 0 | 0 | 2mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:08.960Z |  | 2025-10-01T20:24:57.957Z | https://www.linkedin.com/feed/update/urn:li:activity:7379240361933852672/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7361011309682831360 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEIZ_b_kD8YDQ/feedshare-shrink_800/B56ZieQxNBHcAk-/0/1755001854479?e=1766620800&v=beta&t=Sqn8F8bFOBB2OZ_JBRcs-cJojKPyzE-OFuF4xdtenSQ | Looking forward to be at MUTEK Forum this year as a panelist in a little over a week. 

I'm particularly excited to be engaging with the next generation of emerging artists from Collège LaSalle, Montréal in our panel to discuss the myriad paths taken and the skills necessary to successfully bring together creativity and tech in a constantly evolving landscape. 

Come join me, Aly Kays, Elisa Schaeffer, and our special guest, Sarah Ouellet from Float4 August 21st at Monument National as we talk directly with students to breakdown their challenges and realities on their creative journeys. 

See 🔗 link in comments for event details ⤵️

#education #digitalart #gaming #interactivity #userexperience | 47 | 1 | 2 | 3mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.213Z |  | 2025-08-12T12:30:57.205Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7356678597899608064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE_Mwao51lMYw/feedshare-shrink_800/B4EZhXzGCOHoAg-/0/1753819669047?e=1766620800&v=beta&t=RBmyi3HQKrUbAWXfVnAe51L7VFe1G0ybMZ4u5en509I | I'm excited to be at this year's MUTEK Forum and co-hosting what will be an insightful panel on The Intersection of Play and Technology for a new generation of creators. 

I'll be joined on stage with Ali Kays and our special guest Sarah Ouellet from Float4, alongside Dean of Technology at Collège LaSalle, Montréal Elisa Schaeffer. Students Jingyan Deng and Maxwell Clement will talk about their journeys behind their recent projects. Come join us as we take a deep dive into how studios, students and emerging artists are adapting to navigate the shifting landscape of gaming and digital creativity. 

🎟️ Details and tickets : 
https://lnkd.in/eyiSEf7s

#MUTEK #DigitalArt #Creation #ImmersiveArt #Gaming | 12 | 2 | 0 | 4mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.214Z |  | 2025-07-31T13:34:18.218Z | https://www.linkedin.com/feed/update/urn:li:activity:7356292568931786753/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7342876641007722497 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4DB5HFbBZng/feedshare-shrink_800/B4EZecjZGAHYA0-/0/1750678213645?e=1766620800&v=beta&t=AdI-ytMP8jVlvOnyrm8xg-xZ25YKYPHjit0ssr6W4C0 | Last minute call out to gamers, creators, builders and designers in City of Toronto! Join us this afternoon to build an interactive AR world in an afternoon that we'll launch as part of Toronto Tech Week with AI creation tools and our no-code platform: ELYSIUM. 

We'll take a few minutes to learn and discuss key trends in Sports Entertainment and Retail loyalty where persistent AR gamification fills the gap in your consumer journey to unlock new dimensions of partnership and revenue opportunities. 

But mostly we'll just play and create ;) 

https://lnkd.in/es4vGr5X

#AugmentedReality #creativity #workshop #liveops #adtech #sportsentertainment #retail | 16 | 1 | 1 | 5mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.215Z |  | 2025-06-23T11:30:15.267Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7340714524922044417 | Article |  |  | We're taking the show on the road to Toronto Tech Week next week!
Join me at our AI x AR Craft-a-thon workshop where we'll build an interactive AR world by playing to create. 

Join us for a lunch, some hands-on presentations, and a lot of building and creating. Collectively we'll unleash your imagination to create spatial experiences across the city in a digital takeover! 

All ages, No-coding, no experience required.

Participants will get exclusive access to the ELYSIUM beta along with a grab-bag of free subscriptions/credits from our partners. 

Unfortunately spaces are limited. 
First 20 people to comment below with "play to create" and DM me get a 50% discount code.

Let's get building! | 16 | 1 | 1 | 5mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.216Z |  | 2025-06-17T12:18:46.622Z | https://lu.ma/iec3it8w |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7330307908619927552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGNHhz9wOBRng/feedshare-shrink_800/B4EZbp8L_uGUAw-/0/1747681594912?e=1766620800&v=beta&t=2UUTUaBY2A9BfU4mUMU2035ACl1lmyNBa0bj2rnEXyM | Excited to be back at the alma mater (Concordia University) and presenting some thoughts on how we're now (after a decade) on the cusp of a revolutionary shift in our relationship to spatial computing. 

Focused for builders and designers my mini talk will be 20% history, 40% future insights, 20% provocative language 😇.  Come and call me out ;) 

Afterwards I hear that there will be pizza and Mythologi be there to show off what you can build with ELYSIUM when you join our private beta. 

Thanks to Steven Warsh, MSc., CAT(C), RMT for organizing and for the invitation. 

Event link in comments! | 31 | 2 | 3 | 6mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.216Z |  | 2025-05-19T19:06:35.950Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7315800435804549120 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHKIfhCF5cSyA/feedshare-shrink_800/B4DZYQ9h_JG4Ao-/0/1744041291173?e=1766620800&v=beta&t=VRia1_VpZdGixD1N298IFyWZwR7OdT4n2f_L6CC0tJ4 | In the era of vibe coding and AI, the product moat is UX Design.
 
Successful solutions will be cross-platform and interconnected while also being localized and personalized. The last two features forming that bridge between digital and real human interaction that can't truly be produced by AI. 

This was one of the key realizations I had in the shower 🛀🏻 , the morning after the round-table we hosted at the new Mythologi studios with Collège LaSalle, Montréal last week. 

It was a fantastic event with wide-ranging and insightful discussion. Thanks again to Elisa Schaeffer for the opportunity, and to my co-panelists Justin Penney and Catherine Banville, Eng., MBA for the wonderful conversation. 

If you missed out, feel free re-live the experience in full YouTube glory: 
📹 https://lnkd.in/d-_pH6wu

Learn more about the new UX Design program at College Lasalle here: 
🔗 https://lnkd.in/dCW3Agfq

If you're interested in the intersection of human creativity and technology, and want to attend future events, go ahead and join the ELYSIUM Community on Discord:  👾 https://lnkd.in/eQDNaCx3 | 14 | 3 | 0 | 7mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.218Z |  | 2025-04-09T18:19:04.895Z | https://www.linkedin.com/feed/update/urn:li:activity:7315039369302622208/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7310650653884796928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTk8sK6lnYAg/feedshare-shrink_800/B4EZXSl9MvGwAk-/0/1742994939824?e=1766620800&v=beta&t=PuTTKGLTzxxMtRi4y2_8ANqg6IqKgZHLU-RZgxI56rs | So our panelists got together last week in advance of tomorrow's UX round table.  (I swear I wasn't sleeping ;)

We collectively immediately realized that there's a massive black hole in the discourse around responsible and ethical UX design for runaway tech (*ahem AI)... 

I can't wait to have the opportunity dive deep into sustainable and accessible UX concerns and strategies with Elisa Schaeffer, Justin Penney and Catherine Banville, Eng., MBA at tomorrow's 5à7 in the new Mythologi studio space. 

Come join us and add your voice in person (RSVP link in comments) | 22 | 1 | 0 | 8mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.218Z |  | 2025-03-26T13:15:41.207Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7308136689644814336 | Text |  |  | Need some networking chill out time after 🔙SXSW and 🔙GDC?
Leaders, developers, marketers, creators: 

Join us Thursday March 27 at our new Mythologi studio space for a casual 5à7🍻🍿 and round-table alongside Elisa Schaeffer, Justin Penney, Catherine Banville, Eng., MBA where we'll lead a discussion on the evolving UX-UI landscape in the face of AI and emerging tech trends. 
(event link in comments)

We're excited to host this in partnership with Collège LaSalle, Montréal as the first of more community events that we'll be hosting in our historic space in the RCA Victor Studio. 

Looking forward to seeing you there! 

#EmergingTech #NewAudiences
#AttentionEconomy #DistractionEconomy
#Accessibility #Sustainability #NoCode #AI | 15 | 2 | 1 | 8mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.219Z |  | 2025-03-19T14:46:05.425Z | https://www.linkedin.com/feed/update/urn:li:activity:7308130690041004035/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7295161397745762305 | Text |  |  | To any Canadian developers impacted by the Unity layoffs this week (and to a larger degree the shifts/cuts we've seen across the board in the game industry since last year), feel free to DM me if you're wanting to building something new that you can own and be a part of. 

At ELYSIUM we're reimagining social XR experiences that amplify gaming to build active communities with immersive tech and real-world connectivity. 

We're looking for innovation leaders to join us in building this next dimension of connected play. If this sounds like you. Hit me up and let's talk. 

j. | 30 | 4 | 3 | 9mo | Post | Jon Yu | https://www.linkedin.com/in/jonscyu | https://linkedin.com/in/jonscyu | 2025-12-08T04:59:15.220Z |  | 2025-02-11T19:26:54.767Z |  |  | 

---



---

# Jon Yu
*ELYSIUM*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 10 |

---

## 📚 Articles & Blog Posts

### [How WeFunder democratizes business ownership](https://www.elysian.press/p/how-wefunder-democratizes-business)
*2025-03-26*
- Category: article

### [EP 11: Interview w/ OG Ohmie, Jonathan Wu - Olympus Agora - Medium](https://olympusagora.medium.com/ep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00?source=post_internal_links---------4----------------------------)
*2021-08-30*
- Category: blog

### [Elysium Health](https://www.youtube.com/elysiumhealth)
*2025-05-13*
- Category: video

### [About Our Company & Mission | Elysium Health](https://www.elysiumhealth.com/pages/mission?srsltid=AfmBOorMTNrWtPNwYzckVKTGc_sLyaDQU0X8xmscVYug73Yvs6wp35Qq)
*2025-01-01*
- Category: article

### [Elyos (YC S23) | LinkedIn](https://uk.linkedin.com/company/elyosai)
*2024-10-24*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 95,205 words total*

### How WeFunder democratizes business ownership
*458 words* | Source: **EXA** | [Link](https://www.elysian.press/p/how-wefunder-democratizes-business)

How WeFunder democratizes business ownership

===============

[![Image 1: The Elysian](https://substackcdn.com/image/fetch/$s_!FA2d!,w_80,h_80,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fab667a94-abb8-4ef3-8f11-825061af2d2c_1280x1280.png)](https://www.elysian.press/)

[![Image 2: The Elysian](https://substackcdn.com/image/fetch/$s_!5lH7!,e_trim:10:white/e_trim:10:transparent/h_122,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fc85390a8-6568-4db4-a334-fc25bae9f97b_1344x256.png)](https://www.elysian.press/)
=========================================================================================================================================================================================================================================================================================================================

Subscribe Sign in

Playback speed

1×

Share post

Share post at current time

Share from 0:00

0:00

/

10:00

Preview

15

1

How WeFunder democratizes business ownership
--------------------------------------------

A discussion with Jonny Price, president of WeFunder. 

[![Image 3: Elle Griffin's avatar](https://substackcdn.com/image/fetch/$s_!hGau!,w_36,h_36,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0174b615-8042-4f73-8515-5425e8e86676_750x750.jpeg)](https://substack.com/@ellegriffin)

[![Image 4: Jonny Price's avatar](https://substackcdn.com/image/fetch/$s_!jXUJ!,w_36,h_36,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2Fd35e9884-1dd0-42d1-8674-7dd54c74b06c_813x723.png)](https://substack.com/@jonnyprice)

[Elle Griffin](https://substack.com/@ellegriffin)

 and 

[Jonny Price](https://substack.com/@jonnyprice)

Mar 26, 2025

∙ Paid

15

1

Share

I’m currently crowdfunding ownership of [my next book](https://wefunder.com/elysianpress) and giving readers a share of the profits. I’m using a platform called WeFunder to do this, which allows businesses to crowdfund investment from supporters, not just VCs.

This used to be illegal—only accredited investors with millions of dollars in net worth could invest in private businesses, but WeFunder thought everyone should be able to own a piece of the pie. So they changed the law.

Now, businesses can raise up to $5 million from supporters, and supporters can invest as little as $100 in businesses they care about. This is a different kind of ownership structure—one where businesses answer to their patrons, rather than just investors who want a return.

WeFunder’s mission is not small—they are a Public Benefit Corporation with a mission to “fix capitalism” by changing who owns stake in it. I spoke with their president

[Jonny Price](https://open.substack.com/users/6017440-jonny-price?utm_source=mentions)

 today to learn how we could do that, what case studies are paving the way, and what our future could look like if we change how businesses are funded. 

Guest lectures and interviews are available to paying supporters and investors of The Elysian

Subscribe

This post is for paid subscribers
---------------------------------

[Subscribe](https://www.elysian.press/subscribe?simple=true&next=https%3A%2F%2Fwww.elysian.press%2Fp%2Fhow-wefunder-democratizes-business&utm_source=paywall&utm_medium=web&utm_content=159883393)

[Already a paid subscriber? **Sign in**](https://substack.com/sign-in?redirect=%2Fp%2Fhow-wefunder-democratizes-business&for_pub=ellegriffin&change_user=false)

[![Image 5: The Elysian](https://substackcdn.com/image/fetch/$s_!FgJW!,w_96,h_96,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack.com%2Fimg%2Fpodcast%2Fgeneric.png)](https://www.elysian.press/s/lectures)

Guest Lectures

Guest lectures & interviews with innovative thinkers for paid Elysian League members.

Guest lectures & interviews with innovative thinkers for paid Elysian League members.

Subscribe

Authors

[![Image 6: Elle Griffin's avatar](https://substackcdn.com/image/fetch/$s_!hGau!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F0174b615-8042-4f73-8515-5425e8e86676_750x750.jpeg)](https://substack.com/@ellegriffin)

Elle Griffin

[![Image 7: Jonny Price's avatar](https://substackcdn.com/image/fetch/$s_!jXUJ!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2Fd35e9884-1dd0-42d1-8674-7dd54c74b06c_813x723.png)](https://substack.com/@jonnyprice)

Jonny Price

Writes [The Community Round Up](https://communityroundup.substack.com/)[Subscribe](https://communityroundup.substack.com/subscribe)

Recent Posts

![Image 8](https://substackcdn.com/image/fetch

*[... truncated, 4,305 more characters]*

---

### EP 11: Interview w/ OG Ohmie, Jonathan Wu
*705 words* | Source: **EXA** | [Link](https://olympusagora.medium.com/ep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00?source=post_internal_links---------4----------------------------)

EP 11: Interview w/ OG Ohmie, Jonathan Wu - Olympus Agora - Medium

===============

[Sitemap](https://olympusagora.medium.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fmedium.com%2Fp%2F8773e797d00&%7Efeature=LoOpenInAppButton&%7Echannel=ShowPostUnderUser&%7Estage=mobileNavBar&source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=post_page---top_nav_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---top_nav_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=post_page---top_nav_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&source=post_page---top_nav_layout_nav-----------------------global_nav------------------)

![Image 3](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

EP 11: Interview w/ OG Ohmie, Jonathan Wu
=========================================

[![Image 4: Olympus Agora](https://miro.medium.com/v2/resize:fill:64:64/1*paxAVXIWw3gI84IHIxaL3Q.jpeg)](https://olympusagora.medium.com/?source=post_page---byline--8773e797d00---------------------------------------)

[Olympus Agora](https://olympusagora.medium.com/?source=post_page---byline--8773e797d00---------------------------------------)

Follow

Aug 30, 2021

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&user=Olympus+Agora&userId=1a2089ede445&source=---header_actions--8773e797d00---------------------clap_footer------------------)

1

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&source=---header_actions--8773e797d00---------------------bookmark_footer------------------)

[Listen](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2Fplans%3Fdimension%3Dpost_audio_button%26postId%3D8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&source=---header_actions--8773e797d00---------------------post_audio_button------------------)

Share

![Image 5](https://miro.medium.com/v2/resize:fit:276/0*aI1tt_Iqn7xR62C7.png)

Mark11 & Asfi sit down with Jonathan Wu - ex-private equity turned crypto native.

Get Olympus Agora’s stories in your inbox
-----------------------------------------

Join Medium for free to get updates from this writer.

Subscribe

Subscribe

They talk about Jon’s crypto/Olympus origins, money myths, problems in coordination and much more…

An insightful chat with nuggets of knowledge scattered throughout, we’re keen to hear your thoughts on this one!

Spotify: [https://open.spotify.com/episode/48GiKxDqsjzPUO0Sw8de5k?si=4eea762ac05e4e41](https://open.spotify.com/episode/48GiKxDqsjzPUO0Sw8de5k?si=4eea762ac05e4e41)

RSS: [https://media.rss.com/agorapod/feed.xml](https://media.rss.com/agorapod/feed.xml)

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&user=Olympus+Agora&userId=1a2089ede445&source=---footer_actions--8773e797d00---------------------clap_footer------------------)

1

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fvote%2Fp%2F8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&user=Olympus+Agora&userId=1a2089ede445&source=---footer_actions--8773e797d00---------------------clap_footer------------------)

1

[](https://medium.com/m/signin?actionUrl=https%3A%2F%2Fmedium.com%2F_%2Fbookmark%2Fp%2F8773e797d00&operation=register&redirect=https%3A%2F%2Folympusagora.medium.com%2Fep-11-interview-w-og-ohmie-jonathan-wu-8773e797d00&source=---footer_actions--8773e797d00---------------------bookmark_footer------------------)

[![Image 6: Olympus Agora](https://miro.medium.com/v2/resize:fill:96:96/1*paxAVXIWw3gI84IHIxaL3Q.jpeg)](https://olympusagora.medium.com/?source=post_page---post_author_info--8773e797d00---------------------------------------)

[![Image 7: Olympus Agora](https://miro.medium.com/v2/resize:fill:128:128/1*paxAVXIWw3gI84IHIxaL3Q.j

*[... truncated, 19,670 more characters]*

---

### Elysium Health
*514 words* | Source: **EXA** | [Link](https://www.youtube.com/elysiumhealth)

Elysium Health - YouTube

===============

 Back [![Image 1](https://www.youtube.com/elysiumhealth)](https://www.youtube.com/ "YouTube Home")

Skip navigation

 Search 

 Search with your voice 

[](https://www.youtube.com/elysiumhealth)

[Sign in](https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3Dhttps%253A%252F%252Fwww.youtube.com%252Felysiumhealth&hl=en&ec=65620)

[![Image 2](https://www.youtube.com/elysiumhealth)](https://www.youtube.com/ "YouTube Home")

[Home Home](https://www.youtube.com/ "Home")[Shorts Shorts](https://www.youtube.com/shorts/ "Shorts")[You You](https://www.youtube.com/feed/you "You")[History History](https://www.youtube.com/feed/history "History")

![Image 3](https://yt3.googleusercontent.com/jOS8JP0tEgJnrjk0mjou8NTEVfypsPj0Heb3TAF01eTsjpe9t2kNIP-eiy9zxyz2oa1RvTnc2AA=w1060-fcrop64=1,00005a57ffffa5a8-k-c0xffffffff-no-nd-rj)

![Image 4](https://yt3.googleusercontent.com/ytc/AIdro_mjxyJmrKMFvl3jr6PHjyeLZxkmDgxWdd7wifqUmLn5GQ=s160-c-k-c0x00ffffff-no-rj)

Elysium Health
==============

@Elysiumhealth

•

948 subscribers•25 videos

Elysium Health is a leading life sciences company with a mission to accelerate innovation and enable greater public access to breakthroughs in the field of aging research. Working directly with the world’s foremost scientists, clinicians, and institutions, we develop clinically validated solutions to address some of the most significant needs in healthcare. ...more Elysium Health is a leading life sciences company with a mission to accelerate innovation and enable greater public access to breakthroughs in the field of aging research. Working directly with the world’s foremost scientists, clinicians, and institutions, we develop clinically validated solutions to address some of the most significant needs in healthcare. ...more...more[instagram.com/elysium_health](https://www.youtube.com/redirect?event=channel_header&redir_token=QUFFLUhqa1g1WEZ4bG04QnA1SmpibFpxcDY5QW9LWS1hZ3xBQ3Jtc0tsWjFseElRdFV3U01PUGZLa0NZaWY5RGRPdXpvaTY3YmZCUnVfWmFTMXc3NjB5aTdTd2t0SXhNS0lZb0dYRXJ4VVdVSzREYmVVcTVmU3lGekw2M04zdW5tN1VGYXFHck43OUJTeUktUVI1R3JQczJvSQ&q=https%3A%2F%2Fwww.instagram.com%2Felysium_health)[and 2 more links](javascript:void(0);)

Subscribe

Home

Videos

Playlists

Search 

[](https://www.youtube.com/elysiumhealth)

[](https://www.youtube.com/elysiumhealth)

[What is NAD+?](https://www.youtube.com/watch?v=p0rvu6WuOLc)

[](https://www.youtube.com/elysiumhealth)

Tap to unmute

2x

[![Image 5](https://www.youtube.com/elysiumhealth)](https://www.youtube.com/elysiumhealth)

[](https://www.youtube.com/elysiumhealth)

Search

Info

Shopping

![Image 6](https://www.youtube.com/elysiumhealth)

[![Image 7](https://www.youtube.com/elysiumhealth)](https://www.youtube.com/elysiumhealth)

If playback doesn't begin shortly, try restarting your device.

•

You're signed out

Videos you watch may be added to the TV's watch history and influence TV recommendations. To avoid this, cancel and sign in to YouTube on your computer.

Cancel Confirm

![Image 8](https://www.youtube.com/elysiumhealth)

Elysium Health

Subscribe

Unsubscribe

[](https://www.youtube.com/elysiumhealth)

Share

[](https://www.youtube.com/elysiumhealth "Share link")- [x] Include playlist 

An error occurred while retrieving sharing information. Please try again later.

Watch later

Share

Copy link

![Image 9](https://www.youtube.com/elysiumhealth)

0:00

[](https://www.youtube.com/elysiumhealth)[](https://www.youtube.com/elysiumhealth)

0:00 / 1:23

Live

•Watch full video

•

•

[What is NAD+?](https://www.youtube.com/watch?v=p0rvu6WuOLc)

•

•

139 views 8 months ago

Nicotinamide adenine dinucleotide (NAD+) is an essential molecule found in all living things. NAD+ is essential for life, yet it declines with age. Learn about NAD+ and its important roles in supporting our health. Code: OCX5FLQDAZT2INUT

[Read more](https://www.youtube.com/watch?v=p0rvu6WuOLc)

[![Image 10](https://www.youtube.com/elysiumhealth)](https://www.youtube.com/elysiumhealth "Multiple playlists")

[Multiple playlists](https://www.youtube.com/elysiumhealth#)
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

[![Image 11](https://i.ytimg.com/vi/p0rvu6WuOLc/hqdefault.jpg?sqp=-oaymwEXCOADEI4CSFryq4qpAwkIARUAAIhCGAE=&rs=AOn4CLD6tSuEuQI5hiNTHCQzkeULz-AHsw) 1 video](https://www.youtube.com/watch?v=p0rvu6WuOLc&list=PLsGHs5qQ4ygJFJk2E2DrYwzQts65zq_3i)

### [Basis | NAD+ Supplement for Cellular Aging](https://www.youtube.com/watch?v=p0rvu6WuOLc&list=PLsGHs5qQ4ygJFJk2E2DrYwzQts65zq_3i)

[Elysium Health](https://www.youtube.com/@Elysiumhealth) • [Playlist](https://www.youtube.com/@Elysiumhealth)

[View full playlist](https://www.youtube.com/playlist?list=PLsGHs5qQ4ygJFJk2E2DrYwzQts65zq_3i)

[!

*[... truncated, 4,088 more characters]*

---

### About Our Company & Mission | Elysium Health
*1,383 words* | Source: **EXA** | [Link](https://www.elysiumhealth.com/pages/mission?srsltid=AfmBOorMTNrWtPNwYzckVKTGc_sLyaDQU0X8xmscVYug73Yvs6wp35Qq)

About Our Company & Mission | Elysium Health 

===============
[Skip to content](https://www.elysiumhealth.com/pages/mission?srsltid=AfmBOorMTNrWtPNwYzckVKTGc_sLyaDQU0X8xmscVYug73Yvs6wp35Qq#MainContent)

Your cart is empty
------------------

[Continue shopping](https://www.elysiumhealth.com/)
Have an account?

[Log in](https://www.elysiumhealth.com/account/login) to check out faster.

![Image 3](https://www.elysiumhealth.com/cdn/shop/files/Hero-1.jpg?v=1762187709&width=1500)

### [All Products](https://www.elysiumhealth.com/collections/all)

From the Lab to Your Door Promote optimal aging with Basis, support...

### [All Products](https://www.elysiumhealth.com/collections/all)

Your Cart
---------

Loading...

Order Subtotal
--------------

$0

 Checkout 

Taxes, Discounts and [shipping](https://www.elysiumhealth.com/policies/shipping-policy) calculated at checkout 

[Order Basis now in time for the holidays!](https://www.elysiumhealth.com/products/basis "Basis")

[Order now in time for the holidays!](https://www.elysiumhealth.com/products/basis "Basis")

*   [Refer a Friend](https://www.elysiumhealth.com/pages/mission?srsltid=AfmBOorMTNrWtPNwYzckVKTGc_sLyaDQU0X8xmscVYug73Yvs6wp35Qq#) 
*   [Register Index](https://my.elysiumhealth.com/index/start)

*   [Help Center](https://www.elysiumhealth.com/pages/support)

*   
 Shop All 

 Shop All 
    *   [**Shop All**](https://www.elysiumhealth.com/collections/all)
    *   [![Image 4](https://www.elysiumhealth.com/cdn/shop/files/product_basis-dot_300x.png?v=1761589349)**Basis**NAD+ Supplement](https://www.elysiumhealth.com/products/basis)
    *   [![Image 5](https://www.elysiumhealth.com/cdn/shop/files/product_matter-dot_300x.png?v=1761589349)**Matter**Long-Term Brain Health](https://www.elysiumhealth.com/products/matter)
    *   [![Image 6](https://www.elysiumhealth.com/cdn/shop/files/cofactor-icon_300x.png?v=1738561469)**Cofactor**Advanced Collagen System with NAD+ Boost](https://www.elysiumhealth.com/products/cofactor)
    *   [![Image 7](https://www.elysiumhealth.com/cdn/shop/files/product_mosic-dot_300x.png?v=1761589349)**Mosaic**Skin Aging Support](https://www.elysiumhealth.com/products/mosaic)
    *   [![Image 8](https://www.elysiumhealth.com/cdn/shop/files/product_vision-dot_300x.png?v=1761589349)**Vision**Eye Longevity](https://www.elysiumhealth.com/products/vision)
    *   [![Image 9](https://www.elysiumhealth.com/cdn/shop/files/product_signal-dot_300x.png?v=1761589349)**Signal**Mitochondrial Support](https://www.elysiumhealth.com/products/signal)
    *   [![Image 10](https://www.elysiumhealth.com/cdn/shop/files/product_format-dot_300x.png?v=1761589349)**Format**Advanced Immune Support](https://www.elysiumhealth.com/products/format)
    *   [![Image 11](https://www.elysiumhealth.com/cdn/shop/files/product_senolytic-dot_300x.png?v=1761589349)**Senolytic Complex**](https://www.elysiumhealth.com/products/senolytic-complex)
    *   [![Image 12](https://www.elysiumhealth.com/cdn/shop/files/longevity-starter-pack-icon_300x.png?v=1738561469)**Longevity Starter Pack**](https://www.elysiumhealth.com/products/longevity-starter-pack)
    *   [![Image 13](https://www.elysiumhealth.com/cdn/shop/files/index-icon_300x.png?v=1738600867)**Index**Biological Age Test](https://www.elysiumhealth.com/products/index)

*   
 Index 

 Index 
    *   [![Image 14](https://www.elysiumhealth.com/cdn/shop/files/index-icon_300x.png?v=1738600867)**Index**Biological Age Test](https://www.elysiumhealth.com/products/index)
    *   [**Aging Research Center**](https://www.elysiumhealth.com/pages/arc)

*   
 The Science 

 The Science 
    *   [**Aging 101**](https://www.elysiumhealth.com/blogs/aging101)
    *   [**Clinical Trials**](https://www.elysiumhealth.com/blogs/clinical-trials)
    *   [**Aging Research Center**](https://www.elysiumhealth.com/pages/arc)

*   
 The Company 

 The Company 
    *   [**Mission**](https://www.elysiumhealth.com/pages/mission)
    *   [**Team**](https://www.elysiumhealth.com/pages/team)
    *   [**Scientific Advisory Board**](https://www.elysiumhealth.com/pages/advisory-board)
    *   [**News & Media**](https://www.elysiumhealth.com/pages/news-media)

*   [Login to Index](https://my.elysiumhealth.com/index/register)
*   [Earn a Free Month](https://www.elysiumhealth.com/pages/mission?srsltid=AfmBOorMTNrWtPNwYzckVKTGc_sLyaDQU0X8xmscVYug73Yvs6wp35Qq#) 

*   [Register an Index Kit](https://my.elysiumhealth.com/index/start)
*   [Help Center](https://www.elysiumhealth.com/pages/support)

*   [Log in](https://www.elysiumhealth.com/account/login)
*   [Help Center](https://www.elysiumhealth.com/pages/support)
*   [Order history](https://www.elysiumhealth.com/account)
*   [Index dashboard](https://my.elysiumhealth.com/)

[![Image 15: Elysium Health Home](https://www.elysiumhealth.com/cdn/shop/files/elysium-wordmark.svg?v=1724693675&width=600)](https://www.elysiumhealth.com/)
*   
Shop All

    *   [![Image 16](https://www.elysiumhealth.com/cdn/shop/files/product_basi

*[... truncated, 13,839 more characters]*

---

### Elyos AI | LinkedIn
*2,350 words* | Source: **EXA** | [Link](https://uk.linkedin.com/company/elyosai)

Elyos AI | LinkedIn

===============
[Skip to main content](https://uk.linkedin.com/company/elyosai#main-content)[LinkedIn](https://uk.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Felyosai&fromSignIn=true&trk=organization_guest_nav-header-signin)[Join now for free](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Felyosai&trk=organization_guest_nav-header-join)

![Image 1: Elyos AI’s cover photo](https://media.licdn.com/dms/image/v2/D4E3DAQGHhyyIDQ76ow/image-scale_191_1128/B4EZjtLiZsGUAk-/0/1756325881857/elyosai_cover?e=2147483647&v=beta&t=muUjzol_XT85nheoFHV0-JR92O5kYdxTembH9xVhAy8)

![Image 2: Elyos AI](https://media.licdn.com/dms/image/v2/D4D0BAQHL9ypOvpkhUQ/company-logo_200_200/B4DZntqzIZGwAI-/0/1760629044205/elyosai_logo?e=2147483647&v=beta&t=BhSkBOBDDofdEudFbeppe2U2yq1KU2bgMZhqXUoJu1M)

Elyos AI
========

Software Development
--------------------

#### AI Agents. Built for trades and field services. www.elyos.ai

[See jobs](https://www.linkedin.com/jobs/elyos-ai-jobs-worldwide?f_C=96399132&trk=top-card_top-card-primary-button-top-card-primary-cta)[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Felyosai&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://media.licdn.com/dms/image/v2/D5603AQGTtcgE-0Om6Q/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1689825268077?e=2147483647&v=beta&t=T8X7aSFNHi2Hk-w_xkPcILBjo-3arDqLmJrnomoHveU)![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQGsEPzBcrnlng/profile-displayphoto-shrink_100_100/B4EZozR.EWIwAY-/0/1761796940978?e=2147483647&v=beta&t=Jeubc75avE55TKDmqOsLmtaFHezaTX0yuCkVKFLjNZk)![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQHlkMOKSY739Q/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1666520809957?e=2147483647&v=beta&t=cj_ATudhhU-UWh-nULQUMu1Xi7FjxS7ZpE9SLiZ0o5w) Discover all 17 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B96399132%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fuk.linkedin.com%2Fcompany%2Felyosai&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

Elyos AI is the first totally autonomous customer service agent for trades and field services. Fully integrated with all trades CRMs, these AI Customer Service Reps book and schedule jobs autonomously, helping our trades businesses run their businesses.

 Website [https://www.elyos.ai/](https://www.linkedin.com/redir/redirect?url=https%3A%2F%2Fwww%2Eelyos%2Eai%2F&urlhash=oR0B&trk=about_website)
External link for Elyos AI

 Industry  Software Development 

 Company size  11-50 employees 

 Headquarters  London 

 Type  Privately Held 

 Founded  2023 

 Specialties  AI, Field Engineering, and Software 

Locations
---------

*    Primary London, GB [Get directions](https://www.bing.com/maps?where=London+GB&trk=org-locations_url)

Employees at Elyos AI
---------------------

*   [![Image 6: Click here to view Adrian Johnston’s profile](https://uk.linkedin.com/company/elyosai)### Adrian Johnston](https://uk.linkedin.com/in/adrian-johnston-87667a2b?trk=org-employees)
*   [![Image 7: Click here to view Jinna Li’s profile](https://uk.linkedin.com/company/elyosai)### Jinna Li](https://be.linkedin.com/in/jinnali?trk=org-employees)
*   [![Image 8: Click here to view Philippa Brown’s profile](https://uk.linkedin.com/company/elyosai)### Philippa Brown](https://uk.linkedin.com/in/philippa-brown-?trk=org-employees)
*   [![Image 9: Click here to view Alexandre Polise’s profile](https://uk.linkedin.com/company/elyosai)### Alexandre Polise](https://uk.linkedin.com/in/alexandrepolise?trk=org-employees)

[See all employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B96399132%255D&trk=public_biz_employees-join)

Updates
-------

*   
[](https://www.linkedin.com/posts/elyosai_we-asked-sarah-cantet-a-very-serious-business-critical-activity-7401579743445221378-0gtB)

[![Image 10: View organization page for El

*[... truncated, 44,744 more characters]*

---

### Dr. VR | Podcast on Spotify
*2,308 words* | Source: **GOOGLE** | [Link](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221)

Dr. VR | Podcast on Spotify

===============

[Skip to main content](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221#main-view)

[](https://open.spotify.com/)

What do you want to play?⌘K

Premium Support Download[Install App](https://open.spotify.com/download)

Sign up Log in

Your Library
============

Create your first playlist It's easy, we'll help you

Create playlist

Let's find some podcasts to follow We'll keep you updated on new episodes

[Browse podcasts](https://open.spotify.com/genre/podcasts-web)

[Legal](https://www.spotify.com/us/legal/)

[Safety & Privacy Center](https://www.spotify.com/us/safetyandprivacy/)

[Privacy Policy](https://www.spotify.com/us/legal/privacy-policy/)

[Cookies](https://www.spotify.com/us/legal/cookies-policy/)

[About Ads](https://www.spotify.com/us/legal/privacy-policy/#s3)

[Accessibility](https://www.spotify.com/us/accessibility/)

[Notice at Collection](https://www.spotify.com/us/legal/notice-at-collection/)

Your Privacy Choices

[Cookies](https://www.spotify.com/legal/cookies-policy/)

English

Resize main navigation 

Preview of Spotify

Sign up to get unlimited songs and podcasts with occasional ads. No credit card needed.

Sign up free

-:--

Change progress 

-:--

Change volume 

Dr. VR

![Image 8](https://i.scdn.co/image/ab67656300005f1fa063bc135729567b3257a6eb)

Podcast
Dr. VR
======

Justin Baillargeon, Ph.D

Follow

About
-----

Justin Baillargeon (Dr. VR) is a VR, film and media Professor and Scholar based in Toronto, Canada. In his bilingual podcast (English and French), he discusses all things related to VR, such as its industry and its academic field.

5(8)

[Technology](https://open.spotify.com/genre/tech_interviews_podcasts)

All Episodes
------------

*   * * *

  ![Image 9: Ep. 43 - Shaping the METAVRSE: XR technology & the evolving place of women in immersive futures](https://image-cdn-ak.spotifycdn.com/image/ab6772ab0000e0e7446f85e9862073baaf22477a)     ### [Ep. 43 - Shaping the METAVRSE: XR technology & the evolving place of women in immersive futures](https://open.spotify.com/episode/4tXJ8lHC0OXYm6mRLYwbDR)

Video•[Dr. VR](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221)  I sit down with someone whose influence can be felt across technology, education, entrepreneurship, and global community building. Julie Smithson is the CEO and co-founder of METAVRSE, XR Women and Unlimited Awesome. She is a driving force in shaping how we create, collaborate, and thrive in the spatial web.In this wide-ranging conversation, Julie shares the incredible trajectory that brought her to becoming one of today’s most respected voices in immersive tech. We explore how her human-centric background in hospitality, combined with more than a decade of XR experience, informs the way she leads and designs for people rather than machines. She opens up about the mission behind Unlimited Awesome, a new educational ecosystem focused on perseverance, social impact, environmental responsibility, and preparing young people for a future where entrepreneurship and emerging technologies converge. We also discusse about why AI-first creation tools will redefine how students and creators build immersive worlds. We dive into the importance of governance and AI literacy, the shift toward agents over assistants, and why collaboration may become the most transformative “killer app” in the next wave of immersive adoption. And of course, we celebrate XR Women on its 5th anniversary: a vibrant global community now spanning more than 60 countries, empowering women and girls to lead, innovate, and shape the next era of spatial computing. Julie reflects on the current state of women’s representation in XR, where progress is happening, and where the industry urgently needs to evolve.

 Nov 27

1 hr 6 min            
*   * * *

  ![Image 10: The Stereopsia Sessions - Alexandra Gerard](https://image-cdn-ak.spotifycdn.com/image/ab6772ab0000e0e746d93b742034ed99b35b5ce0)     ### [The Stereopsia Sessions - Alexandra Gerard](https://open.spotify.com/episode/2g9SIwAl6hfaaxF1a8brhn)

Video•[Dr. VR](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221)  In December 2024, live from Stereopsia 2024 in Brussels, I sat down with Alexandra Gerard, Co-Director and Co-Founder of UnitedXR Europe, and Managing Director of Stereopsia, to explore how one of the continent’s leading XR events has evolved over the years. Alexandra shares how she fosters collaboration across Europe’s diverse XR ecosystem, the growing presence of women in immersive tech, and her mission to create a circuit connecting XR events across the continent.

 Nov 4

10 min 33 sec            
*   * * *

  ![Image 11: The Stereopsia Sessions - Christophe Hermanns](https://image-cdn-ak.spotifycdn.com/image/ab6772ab0000e0e7cda5e177356130e26a6e05b7)     ### [The Stereopsia Sessions - Christophe Hermanns](https://open.spotify.com/episode/5Dn31HqiU4u3kMYPzY6Pa4)

Video•[Dr. VR](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221)  Dans ce

*[... truncated, 23,814 more characters]*

---

### Checking your browser
*64 words* | Source: **GOOGLE** | [Link](https://www.f6s.com/companies/entertainment/canada/montreal/co)

Checking your browser

===============

![Image 1](https://www.f6s.com/content-resource/static/f6s-logo-square.svg?v=FVXHfEQcGR)

We think you might be a bot 

 To regain access, please make sure that cookies and JavaScript are enabled before reloading the page.

 Please email [support@f6s.com](mailto:support@f6s.com) with the info below if you think this is an error: 

IP: 34.34.225.23

 Request ID: biS2KORen3E_kfUztCyWF4zllQZ669kk-4jipt_1z9U1Cul1GzuRKQ==

[Terms](https://www.f6s.com/terms)[Privacy](https://www.f6s.com/privacy-policy)[Data Security](https://www.f6s.com/data-security)[Cookie Policy](https://www.f6s.com/cookie-policy)[Cookie Table](https://www.f6s.com/cookie-table)© 2025 F6S Network Limited. All rights reserved. F6S is a registered trademark.

---

### Speakers VRTO 2025 - VRTO Spatial Media World Conference & Expo
*578 words* | Source: **GOOGLE** | [Link](https://conference.virtualreality.to/speakers-vrto-2025/)

[![Image 1: John E. Muñoz](https://conference.virtualreality.to/wp-content/uploads/2025/06/John2019-500x463.jpg)](https://conference.virtualreality.to/speaker/john-e-munoz/)

#### John E. Muñoz

Assistant Professor, Lab Director at Wilfrid Laurier University, University of Waterloo | Brantford, Canada

[![Image 2: Patrick C. K. Hung](https://conference.virtualreality.to/wp-content/uploads/2025/06/Patrick_Hung_headshot-500x500.jpg)](https://conference.virtualreality.to/speaker/patrick-hung/)

#### Patrick C. K. Hung

Professor - Faculty of Business and IT | Ontario Tech University, Canada

[![Image 3: Cindy Poremba](https://conference.virtualreality.to/wp-content/uploads/2025/04/headshot-500x500.jpg)](https://conference.virtualreality.to/speaker/cindy-poremba/)

#### Cindy Poremba

Associate Professor, Digital Futures and Co-Director of game:play Lab at OCAD University | Toronto, Canada

[![Image 4: Sean Evans](https://conference.virtualreality.to/wp-content/uploads/2025/05/Headshots_Sean-Evans-500x500.jpg)](https://conference.virtualreality.to/speaker/sean-evans/)

#### Sean Evans

CTO at EVOQ | Toronto, Canada

[![Image 5: Mandy Canales](https://conference.virtualreality.to/wp-content/uploads/2025/05/MandyCanales.jpg)](https://conference.virtualreality.to/speaker/mandy-canales-3/)

#### Mandy Canales

VR Theater Practitioner | Tri Cities, Washington, United States

[![Image 6: Amar Trivedi](https://conference.virtualreality.to/wp-content/uploads/2025/06/Amar.jpg)](https://conference.virtualreality.to/speaker/amar-trivedi/)

#### Amar Trivedi

Principal Investigator - Software Innovation, Mixed Reality Capture Studio - Durham College | Toronto, Canada

[![Image 7: Karen Darricades](https://conference.virtualreality.to/wp-content/uploads/2025/06/karendarricades_headshot.jpg)](https://conference.virtualreality.to/speaker/karen-darricades/)

#### Karen Darricades

Founder and CEO of LitKit | Toronto, Canada

[![Image 8: Oleksii Koba](https://conference.virtualreality.to/wp-content/uploads/2025/06/photo_okoba.jpeg)](https://conference.virtualreality.to/speaker/oleksii-koba/)

#### Oleksii Koba

Founder, CEO & Creative Director at OK_XR Studio | Toronto, Canada

[![Image 9: Jason Webb](https://conference.virtualreality.to/wp-content/uploads/2025/06/WebbPortraits_SV-1-500x500.jpg)](https://conference.virtualreality.to/speaker/jason-webb/)

#### Jason Webb

Assistant Professor at Syracuse University - S.I. Newhouse School of Public Communications, Oswego, NY

[![Image 10: Neil Chakravarti](https://conference.virtualreality.to/wp-content/uploads/2025/04/Neil_Chakravarti-BW-494x500.png)](https://conference.virtualreality.to/speaker/neil-chakravarti/)

#### Neil Chakravarti

Principal at Shocap, EVOQ/ Toronto

[![Image 11: Jatinder Parmar](https://conference.virtualreality.to/wp-content/uploads/2025/06/IMG_1421.jpeg)](https://conference.virtualreality.to/speaker/jatinder-parmar/)

#### Jatinder Parmar

Virtual Production Supervisor at StradaXR | Toronto, Canada

[![Image 12: Sherwin Shahidi](https://conference.virtualreality.to/wp-content/uploads/2025/06/SherwinShahidi_headshot_square.jpg)](https://conference.virtualreality.to/speaker/sherwin-shahidi/)

#### Sherwin Shahidi

Head of Production Technology | Toronto, Canada

[![Image 13: Winrik Haentjens](https://conference.virtualreality.to/wp-content/uploads/2025/06/selfPortrait_v001.jpg)](https://conference.virtualreality.to/speaker/winrik-haentjens/)

#### Winrik Haentjens

CG Supervisor at Pixomondo | Toronto, Canada

[![Image 14: Harrison Forsyth](https://conference.virtualreality.to/wp-content/uploads/2025/06/harrison_forsyth-500x500.jpg)](https://conference.virtualreality.to/speaker/harrison-forsyth-2/)

#### Harrison Forsyth

Principal Investigator | Durham College, Oshawa, Ontario, Canada

[![Image 15: J. Lee Williams](https://conference.virtualreality.to/wp-content/uploads/2025/06/Head-Shot_Invalid-Symbol_-J-Lee-Williams-500x500.jpg)](https://conference.virtualreality.to/speaker/j-lee-williams/)

#### J. Lee Williams

Founder, Creative Director | Invalid Symbol, Toronto, Ontario, Canada

[![Image 16: Dan Blair](https://conference.virtualreality.to/wp-content/uploads/2025/06/364145069_10168208853385078_1641282920265574551_n-500x500.jpg)](https://conference.virtualreality.to/speaker/dan-blair/)

#### Dan Blair

CTO of BSD XR | Winnipeg, Manitoba

[![Image 17: Simeone Scaramozzino](https://conference.virtualreality.to/wp-content/uploads/2025/06/Simeone-Scaramozzino-2-500x500.jpg)](https://conference.virtualreality.to/speaker/simeone-scaramozzino/)

#### Simeone Scaramozzino

Producer, Totems of Hope

[![Image 18: Jeff Thompson](https://conference.virtualreality.to/wp-content/uploads/2025/05/Jeff-Thompson_Headshot.jpg)](https://conference.virtualreality.to/speaker/jeff-thompson/)

#### Jeff Thompson

Coordinator / Professor, Conestoga College - Virtual Reality Production Dept., Kitchener, Canada

[![Image 19: Dr. Justin Baillargeon](https://conference.virtualrea

*[... truncated, 4,188 more characters]*

---

### VRTO Schedule 2025 - VRTO Spatial Media World Conference & Expo
*2,407 words* | Source: **GOOGLE** | [Link](https://conference.virtualreality.to/vrto-schedule-2025/)

VRTO Schedule 2025 - VRTO Spatial Media World Conference & Expo

===============
[Mastodon](https://masto.ai/@vrto)[](javascript:;)

[](javascript:;)

*   [Home](https://conference.virtualreality.to/)
*   [VRTO 2025 Review](https://conference.virtualreality.to/vrto-2025-review/)
    *   [About the Event](https://conference.virtualreality.to/vrto-2025-review/)
    *   [Speakers 2025](https://conference.virtualreality.to/speakers-vrto-2025/)
    *   [Schedule 2025](https://conference.virtualreality.to/vrto-schedule-2025/#all-events)
    *   [Exhibit Hall 2025](https://conference.virtualreality.to/exhibition-hall-2025)

*   [Past Events](https://conference.virtualreality.to/)
    *   [VRTO 2024 Review](https://conference.virtualreality.to/vrto-2024-review/)
    *   [VRTO 2023 Review](https://conference.virtualreality.to/vrto-2023-review/)
    *   [VRTO 2022 Review](https://conference.virtualreality.to/vrto-2022-review/)

*   [Contact Us](https://conference.virtualreality.to/contact/)

*   Spam Blocked
------------

[**5,364 spam** blocked by **Akismet**](https://akismet.com/?utm_source=akismet_plugin&utm_campaign=plugin_static_link&utm_medium=in_plugin&utm_content=widget_stats) 

*   [](https://www.facebook.com/vrtoc)
*   [](https://twitter.com/@VRtoronto)
*   [](https://www.youtube.com/channel/UCOoo1-FZY2yjG2iTkuekx5A "Youtube")
*   [](https://www.linkedin.com/showcase/vrto-virtual-&-augmented-reality-world-conference-&-expo/?viewAsMember=true "Linkedin")
*   [](https://instagram.com/VRtoronto "Instagram")

[![Image 1](https://conference.virtualreality.to/wp-content/uploads/2023/03/VRTO_2023_Small_Logo_negative-alpha.png)](https://conference.virtualreality.to/)

[![Image 2](https://conference.virtualreality.to/wp-content/uploads/2023/03/VRTO_2023_Small_Logo_negative-alpha.png)](https://conference.virtualreality.to/)

*   [Home](https://conference.virtualreality.to/)
*   [VRTO 2025 Review](https://conference.virtualreality.to/vrto-2025-review/)
    *   [About the Event](https://conference.virtualreality.to/vrto-2025-review/)
    *   [Speakers 2025](https://conference.virtualreality.to/speakers-vrto-2025/)
    *   [Schedule 2025](https://conference.virtualreality.to/vrto-schedule-2025/#all-events)
    *   [Exhibit Hall 2025](https://conference.virtualreality.to/exhibition-hall-2025)

*   [Past Events](https://conference.virtualreality.to/)
    *   [VRTO 2024 Review](https://conference.virtualreality.to/vrto-2024-review/)
        *   [Speakers VRTO 2024](https://conference.virtualreality.to/speakers-vrto-2024/)
        *   [Schedule VRTO 2024](https://conference.virtualreality.to/schedule-vrto-2024/)
        *   [Exhibit Hall 2024](https://conference.virtualreality.to/exhibition-hall-2024/)
        *   [Our Team 2024](https://conference.virtualreality.to/our-team-2024/)

    *   [VRTO 2023 Review](https://conference.virtualreality.to/vrto-2023-review/)
        *   [Speakers VRTO 2023](https://conference.virtualreality.to/speakers-vrto-2023/)
        *   [Schedule VRTO 2023](https://conference.virtualreality.to/schedule-vrto-2023/)
        *   [Exhibit Hall VRTO 2023](https://conference.virtualreality.to/exhibit-hall-vrto-2023/)
        *   [Our Team 2023](https://conference.virtualreality.to/vrto-team-2023/)

    *   [VRTO 2022 Review](https://conference.virtualreality.to/vrto-2022-review/)
        *   [Speakers VRTO 2022](https://conference.virtualreality.to/vrto22_speakers/)
        *   [Schedule VRTO 2022](https://conference.virtualreality.to/schedule2022/)
        *   [Exhibit Hall VRTO 2022](https://conference.virtualreality.to/exhibit-hall-2022/)
        *   [Our Team 2022](https://conference.virtualreality.to/vrto22_about_team/)

[](javascript:;)

VRTO Schedule 2025
==================

Schedule Subject to Change

Gold = Fireside or Panel

*   All Events 
    *   [All Events](https://conference.virtualreality.to/vrto-schedule-2025/#all-events "All Events")

*   [All Events](https://conference.virtualreality.to/vrto-schedule-2025/#all-events "All Events")

|  | June 25th, 2025 | June 26th, 2025 |
| --- | --- | --- |
| 9:45 AM | [VRTO - 10 Years and Overview of the Show](https://conference.virtualreality.to/events/vrto-10-years-and-overview-of-the-show/ "VRTO - 10 Years and Overview of the Show") Keram Malicki-Sanchez | Experience Designer, Producer, Curator | Toronto, Los Angeles 9:50 AM 10:30 AM |  |
| 10:00 AM | [Empowering Diverse Leadership in XR: Building Inclusive Futures Through Confidence and Collaboration](https://conference.virtualreality.to/events/empowering-diverse-leadership-in-xr-building-inclusive-futures-through-confidence-and-collaboration/ "Empowering Diverse Leadership in XR: Building Inclusive Futures Through Confidence and Collaboration") Sheena Yap Chan | Founder, The Tao of Self-Confidence | Toronto, Canada 10:00 AM 10:30 AM |
| 10:15 AM |
| 10:30 AM | [The Historical Evolution of Virtual Reality Technologies](https://conference.virtualreality.to/events/historical_evolution-of-vr/ "Th

*[... truncated, 20,310 more characters]*

---

### Abrahams, Daniel (2020) A philosophical approach to satire and ...
*84,438 words* | Source: **GOOGLE** | [Link](https://theses.gla.ac.uk/79011/1/2020AbrahamsPhD.pdf)

Abrahams, Daniel (2020) A philosophical approach to satire and humour in social context. PhD thesis. 

# https://theses.gla.ac.uk/79011/ 

# Copyright and moral rights for this work are retained by the author 

# A copy can be downloaded for personal non-commercial research or study, without prior permission or charge 

# This work cannot be reproduced or quoted extensively from without first obtaining permission in writing from the author 

# The content must not be changed in any way or sold commercially in any format or medium without the formal permission of the author 

# When referring to this work, full bibliographic details including the author, title, awarding institution and date of the thesis must be given 

> Enlighten: Theses
> https://theses.gla.ac.uk/
> research-enlighten@glasgow.ac.uk

A P hilosophical Approach to Satire and Humour in Social Context 

DANIEL ABRAHAMS 

Submitted in fulfilment for the requirements of the degree of 

Doctor of Philosophy 

Philosophy 

School of Humanities 

College of Arts 

University of Glasgow 

November 2019 II 

Abstract 

The topic of my dissertation is satire. This seems to excite many people, and over 

the past four years I have heard many variations of a similar refrain: “Oh, wow. 

You’re studying satire? That’s very topical. You must have a lot of material to work 

with.” There is a way in which this is true, though I suspect in a way that diverges 

from the way that most of my interlocutors believed. I suspect that the material 

they imagined me to be working with was the output of Donald Trump, first a 

candidate for and now holder of the office of President of the United States. That 

is not the material I find interesting. More interesting to me is their statement. It 

evinces a number of beliefs that I find interesting, chief among them that Trump 

makes the current period pa rticularly apt for satire, as if a doddery and 

incompetent ruling class is somehow a recent phenomenon. And I suspect that 

underneath this belief in the aptness of satire is a belief in the power of satire. 

Satire is somehow how people are going to strike back at the vice -governed fools 

who rule us. Those beliefs are the material I want to work with. 

This is my interest in satire, then: not so much what it is about satire that 

makes it powerful, but what is it about satire that makes people think it is 

pow erful? And what is it about satire that makes people think it is powerful when 

there is pretty powerful evidence that it is not? Unfortunately, here is where I run 

into the problem that in a very important way I do not have a lot of material to 

work with. There is not an awful lot on satire within the analytic tradition: outside 

of a few references to satire, analytic discussions of satire are limited to two short 

articles. Accordingly, I have taken the task of my dissertation to be to create an 

account of satire that helps to bring forward why satire is a thing that people can 

imagine to be powerful, that they can imagine to be politically effective. 

My dissertation will effectively have two halves, one where I build my 

account and one where I begin to app ly it. The purpose of applying my account, 

which will comprise the final two chapters, will not be to show its implications so 

much as how it can be used. My goal will not so much be to give definitive answers 

about the nature of satire, but rather to give a demonstration of how my account 

facilitates engaging questions about the role of satire in social and political 

context .III 

Table of Contents 

Acknowledgements ............................................................................V 

Author’s Declaration .........................................................................VII 

Introduction .............................................................. ....................... 1

Chapter 1: Trust ............................................................................... 7

1.1 Meaning and Reflexive Intentions .............................................. 9

1.2 Metaphor and Linguistic Competence ..... ................................... 12 

1.3 Trust ............................................................................... 18 

2 Engaging Art ........................................................................21 

2.1 The Art Object .............. ..................................................... 21 

2.2 Actual Intentionalism ........................................................... 28 

2.3 The Mid -Point: Hypothetical and Fictional Authors ........................ 30 

2.4 Anti -Intentionalism .... .......................................................... 34 

3 Integrating Art and Trust ......................................................... 36 

4 Conclusion ........................................................................... 40 

Chapter 2: Misrepresentation ......................................................

*[... truncated, 508,217 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Dr. VR | Podcast on Spotify](https://open.spotify.com/show/0br9eeyTmbLcsCFhqAJ221)**
  - Source: open.spotify.com
  - *... podcast (English and French), he discusses all things related to VR ... VR, I sit down with Jon Yu, founder of Elysium AR, a no-code AR co-creatio...*

- **[25 Top Entertainment Companies in Montreal · December 2025 | F6S](https://www.f6s.com/companies/entertainment/canada/montreal/co)**
  - Source: f6s.com
  - *7 days ago ... ELYSIUM creates and deploys interactive AR experiences that are ... Jon Yu | F6S - Images Jon Yu See all investors. About Geek-it! - F6...*

- **[Speakers VRTO 2025 - VRTO Spatial Media World Conference ...](https://conference.virtualreality.to/speakers-vrto-2025/)**
  - Source: conference.virtualreality.to
  - *... Podcast, Assistant Professor in Digital Media and Global Communications at the ... Jon Yu. Founder + CEO, MYTHOLOGI | ELYSIUM | Montreal, Canada ....*

- **[VRTO Schedule 2025 - VRTO Spatial Media World Conference ...](https://conference.virtualreality.to/vrto-schedule-2025/)**
  - Source: conference.virtualreality.to
  - *Justin Baillargeon | Host and Producer of Dr. VR Podcast, Assistant ... Jon Yu, Elysium | Montreal, CA. 5:15 PM. 5:35 PM. XR In Action: Results from ....*

- **[Abrahams, Daniel (2020) A philosophical approach to satire and ...](https://theses.gla.ac.uk/79011/1/2020AbrahamsPhD.pdf)**
  - Source: theses.gla.ac.uk
  - *... Jon Yu, Helge Magnussen, Edvinas. Volkovas, Junhao Xian, and Dwayne ... Blomkamp pulls a similar trick in his next film, Elysium (2013). Early in ...*

- **[100 Top Entertainment Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/entertainment/canada/co)**
  - Source: f6s.com
  - *7 days ago ... ELYSIUM creates and deploys interactive AR experiences that are ... Jon Yu | F6S - Images Jon Yu See all investors. About ARRAY OF STAR...*

- **[La Cancha EN — SPHERE(S)](https://www.spheres-mtl.ca/lacancha-1)**
  - Source: spheres-mtl.ca
  - *... Jon Yu, and Chantal Pontbriand. It innovates by giving a voice to this part ... Download Elysium and discover the scenes in physical locations by ...*

- **[100 Top Gaming Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/gaming/canada/co)**
  - Source: f6s.com
  - *7 days ago ... ELYSIUM creates and deploys interactive AR experiences that are ... Jon Yu | F6S - Images Jon Yu See all investors. About BSGames - F6S...*

- **[Jon Yu - VRTO Spatial Media World Conference & Expo](https://conference.virtualreality.to/speaker/jon-yu/)**
  - Source: conference.virtualreality.to
  - *Jon Yu. Founder + CEO, MYTHOLOGI | ELYSIUM | Montreal, Canada. https://mythologi.es/. Jon Yu is the founder and CEO at MYTHOLOGI, a creative technolog...*

- **[C2 MONTRÉAL ANNOUNCES THE 25 WINNERS OF THE ...](https://www.newswire.ca/news-releases/c2-montreal-announces-the-25-winners-of-the-emerging-entrepreneurs-contest-826857406.html)**
  - Source: newswire.ca
  - *Sep 15, 2022 ... Share this article. Share toX. Share this article. Share toX. MONTREAL, ... Jon Yu, Founder and CEO, ELYSIUM ELYSIUM is an intuitive,...*

---

*Generated by Founder Scraper*
