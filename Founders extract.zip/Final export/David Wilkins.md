# David Wilkins

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Zenapptic.ai
**Durée dans le rôle** : 6 years 5 months in role
**Durée dans l'entreprise** : 6 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Zenapptic is an AI-powered platform for building shared interactive experiences for big screens, little screens, and everything in between.

## Résumé

Tech entrepreneur with over 25 years experience building software companies from the ground up into global leaders in emerging high-growth markets. Hands-on experience in all stages of business development, from early startup to rapid growth to M&A, with proven track record of innovation and strategic vision. Skilled at identifying market opportunities and translating them into successful products and services. Unique combination of technology and business acumen, with extensive experience in strategic planning, fundraising, team building, product development, and go-to-market execution.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAEqZosB-Z5OC2R2wGYxloxUq8-hA8Tg8qc/
**Connexions partagées** : 16


---

# David Wilkins

## Position actuelle

**Entreprise** : Zenapptic.ai

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# David Wilkins

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397759366164135937 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEZDl9mpNPsUg/feedshare-shrink_800/B56ZqnXd7WHYAg-/0/1763744541636?e=1766620800&v=beta&t=wXBLtL_e6hJhfm2ddu4s2cHFYIyzwoM2aDIGkI7jMFM | Proud to sponsor this year's AI Symposium by Conseil des écoles catholiques du Centre-Est (CECCE) in Ottawa, where we used AI to bring in the event's special invitee Mary Mesaglio live from Gartner in Barcelona and show her in a virtual 3D presentation environment. Lots of other immersive features too, and great discussions by AI thought leaders across a wide range of topics. 

Special thanks to our co-sponsors AVI-SPL, Gartner, and Raymond Chabot Grant Thornton. | 17 | 0 | 2 | 2w | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:40.519Z |  | 2025-11-21T22:14:36.616Z | https://www.linkedin.com/feed/update/urn:li:activity:7397725501139771392/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396667567039414272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWX8o8n_uSig/feedshare-shrink_800/B4EZqY98EDKkAg-/0/1763502968694?e=1766620800&v=beta&t=eYp84etDQTUr26Lk0QxvEkm4rIgSe8ZhclX9K_Oaf_0 | Just finished my whirlwind visit to the IAAPA show in Orlando. What an event! Waterslides mixed with bumper cars mixed with exploding kittens (or whatever those were!). Lots of opportunities for the Zenapptic AI-powered immersive experience management platform! | 64 | 3 | 4 | 2w | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:40.519Z |  | 2025-11-18T21:56:11.420Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395085060938559490 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHDcfmJczFXXA/feedshare-shrink_800/B4EZqCeqlfHgAg-/0/1763125671120?e=1766620800&v=beta&t=cPNa2UaQTAWvFNaU6GLXpxzRmAWmQ-uZo7mml90UFQc | MORE exciting news!!
Zenapptic AI just wrapped a major immersive live event for Check Point Software at the stunning Cirque Éloize in Old Montréal—driven entirely by our AI-powered ZEN3 platform.

Check Point Engage brought together hundreds of in-person attendees and  hundreds more online. Partners, customers, and Check Point team members connected through a unified platform that turned an already cool conference into something far more: an interactive, multi-modal experience designed specifically to maximize attendee engagement.

Working closely with the Check Point marketing team, Zenapptic created a fully branded 3D experience featuring stunning projection-mapped visuals, a real-time virtual world displayed on the venue’s massive front wall, and an interactive 3D digital twin that let remote visitors explore the event directly from their browsers.

Throughout the event, Zenapptic software powered every part of the experience:

• Seamless check-in and sponsor booth visitor tracking
• Real-time audience reactions displayed during presentations
• Live audience polling from attendees' mobile phones
• ZEN3 media servers driving 3D content on the big screen
• Microsoft Teams feeds with a live keynote from Check Point’s CEO
• Multiple live video channels streamed into the virtual remote event
• Media Director for drag-and-drop content control
• Real-time AI translation from English to French

And behind the scenes, the ZEN3 analytics engine tracked the entire experience—providing the Check Point team with in-depth insights across both the in-person and online event.

A big Thank You to everyone at Check Point, especially Ron Dekker and the amazing Angel Tar! Another milestone for the Zenapptic AI immersive experience platform. And more to come soon! | 85 | 8 | 7 | 3w | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:40.520Z |  | 2025-11-14T13:07:52.564Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7389008142614818816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFE1pKSTId19A/feedshare-shrink_800/B4EZosHvRQKMAg-/0/1761676821175?e=1766620800&v=beta&t=kn3tfmEInyEN-7u6paaKommwAqBKLeTUwOBNOc9UE0U | Exciting news!! The Zenapptic AI immersive experience went live today at Delta's brand new Sky Club lounge at Salt Lake City International Airport. This is *NOT* your typical video wall that is just playing back videos! These sections of LED panels act like windows into virtual real-time 3D environments that continuously animate and change throughout the day. Across 9 beautiful Utah national parks, we make it rain and snow, we make birds and airplanes fly randomly across the screen, and we continuously change the content with our AI-generated playlists. Combine these photo-realistic environments with 3D spatial audio and other real-time content, and it really is an immersive experience like no other! | 98 | 17 | 9 | 1mo | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:40.521Z |  | 2025-10-28T18:40:22.332Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7338620941985325058 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG_lGuYRJgeJA/feedshare-shrink_800/B56ZcZDm4NG0Ag-/0/1748472066095?e=1766620800&v=beta&t=fvsE3YEly04nwr1Dp5hLn3Ec8zXHX19QaJJZm1eqgUo | Looking forward to tomorrow’s panel. If you’re at InfoComm, drop by room W312AB Thursday June 12th at 11:00 am! | 6 | 0 | 2 | 5mo | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:42.585Z |  | 2025-06-11T17:39:37.553Z | https://www.linkedin.com/feed/update/urn:li:activity:7333623383537917953/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7278890157204811776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgiQuZIMBcRA/feedshare-shrink_800/B4EZQPP8V9HsAg-/0/1735422646742?e=1766620800&v=beta&t=umut9cAHMCWmuAuePwZzIAUXlxE095CFQDF5JWnsJPw | Had a great time working on the Good Riddance Day 2024 project in Times Square. Thanks to everyone at Jamestown and Times Square Alliance for making this happen! And to Jonathan Bennett for being such a fantastic host! What a great application for the Zenapptic Interactive Experience Platform. Everyone had fun watching their bad memories digitally explode on the side of One Times Square!! 

Next up, Virtual New Year’s Eve. Be sure to visit https://vnye.com on December 31st!!! | 54 | 2 | 7 | 11mo | Post | David Wilkins | https://www.linkedin.com/in/david-wilkins-14b6716 | https://linkedin.com/in/david-wilkins-14b6716 | 2025-12-08T05:11:42.585Z |  | 2024-12-28T21:50:48.717Z |  |  | 

---



---

# David Wilkins
*Zenapptic.ai*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 17 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [The Purposeful Investor](https://podcasts.apple.com/us/podcast/the-purposeful-investor/id1727978674)
*2025-05-08*
- Category: podcast

### [David Wilkins, Chief Product, Marketing, and Strategy Officer at TalentNeuron – Interview Series](https://unite.ai/david-wilkins-chief-product-marketing-and-strategy-officer-at-talentneuron-interview-series)
*2025-02-27*
- Category: article

### [Lessons in Leading and Elevating SDR Teams with David Wilkins, Founder of Saleswise and SDR Leaders of EMEA - Why Did It Fail?](https://redefiningoutbound.captivate.fm/episode/redefining-outbound-ep-83)
*2025-04-09*
- Category: article

### [OK13: How to bring top-tier SDR talent and build future leaders - Dave Wilkins, ​Founder of Saleswise, & of the SDR Leaders of EMEA community - Outbound Kitchen - B2B Sales Podcast](https://poddtoppen.se/podcast/1649089244/outbound-kitchen-sales-podcast-ex-sdr-game/ok13-how-to-bring-top-tier-sdr-talent-and-build-future-leaders-dave-wilkins-founder-of-saleswise-of-the-sdr-leaders-of-emea-community)
*2025-04-06*
- Category: podcast

### [Tech Talks for Senior Care Podcast with Guests David Wilkings & Cameron Micules](https://maintenancecare.com/podcast-episode-7-david-wilkings-cameron-micules)
*2025-02-04*
- Category: podcast

---

## 🎬 YouTube Videos

- **[Reimagining Lawyering in a World on Fire  | David Wilkins | TEDxOxford](https://www.youtube.com/watch?v=z-znDCjJcQY)**
  - Channel: TEDx Talks
  - Date: 2021-06-28

- **[David Wilkins on Being the United States Ambassador to Canada](https://www.youtube.com/watch?v=PdaVz6h4dv8)**
  - Channel: TVO Today
  - Date: 2009-02-05

- **[In Conversation With Prof. David Wilkins (Harvard Law School) On Rule of Law,Legal Education &amp; More](https://www.youtube.com/watch?v=ux2-Ae4-PP4)**
  - Channel: Live Law
  - Date: 2019-08-09

- **[A Conversation with David Wilkins on the Legal Profession in the Coming Year](https://www.youtube.com/watch?v=3mLX0neILYs)**
  - Channel: HLS CLP
  - Date: 2021-12-16

- **[HLS Book Talk | David Wilkins&#39; &#39;Diversity in Practice&#39;](https://www.youtube.com/watch?v=gcmMLps_itA)**
  - Channel: Harvard Law School
  - Date: 2016-04-22

- **[#108 The SDR DiscoCall Vidcast – David Wilkins](https://www.youtube.com/watch?v=Av153fqcGWg)**
  - Channel: HappySelling
  - Date: 2025-06-17

- **[The EPN Podcast | David Wilkins (Founder  @SDRleadersEMEA  &amp; Saleswise)](https://www.youtube.com/watch?v=FoT9FQTk1E0)**
  - Channel: ISP NextGen
  - Date: 2024-07-09

- **[#108 The SDR DiscoCall Show – David Wilkins](https://www.youtube.com/watch?v=5rrF0ntOVJ4)**
  - Channel: HappySelling
  - Date: 2025-06-19

- **[David Wilkins - Founder of SDR Leaders of EMEA](https://www.youtube.com/watch?v=0xQ7eqHQ5UY)**
  - Channel: rookieSDR
  - Date: 2024-10-24

- **[Transitioning from a Sports Teacher to a Sales Leader with David Wilkins (Episode 138)](https://www.youtube.com/watch?v=zK6H_QDuTSA)**
  - Channel: Ultimate Global Podcast
  - Date: 2024-04-11

---

## 🔎 Press & Mentions

- **[NYC celebrates Times Square's Good Riddance 2024](https://www.amny.com/lifestyle/holidays/good-riddance-2024-times-square-new-year/)**
  - Source: amny.com
  - *Dec 29, 2024 ... ... Podcasts · Brand Content · CBD & Cannabis Directory ... David Wilkins, founder and CEO of Zenapptic.ai, built the Good Riddance a...*

- **[Exclusive Talk Sessions | Zenapptic AI | Using #VirtualProduction to ...](https://www.youtube.com/watch?v=E-AX_Q04m9M)**
  - Source: youtube.com
  - *Jun 19, 2024 ... Zenapptic AI leverages cutting-edge technologies to create immersive experiences and enhance audience engagement ... David Wilkins:(0...*

- **[InfoComm 2025 - InfoComm 2026](https://www.infocommshow.org/infocomm-2025)**
  - Source: infocommshow.org
  - *Podcast Recording. TV02. 60 mins. Booth 7861. Broadcast AV; Free. Get ready to ... David Wilkins, President and CEO - Zenapptic AI · Enhancing ......*

- **[Design & Integration | InfoComm 2026](https://www.infocommshow.org/design-integration)**
  - Source: infocommshow.org
  - *... conference, collaboration, and meeting spaces have exponentially ... David Wilkins, President and CEO - Zenapptic AI · Crestron AV ......*

- **[Contact Vic Caruso, Email: v***@zenapptic.ai & Phone Number ...](https://www.zoominfo.com/p/Vic-Caruso/630770467)**
  - Source: zoominfo.com
  - *... Zenapptic AI and unlock customer insights to grow your business today ... Director, Product Management. Phone Email. David Wilkins, Founder & Chie...*

- **[La plateforme ZEN3 de Zenapptic.AI alimente la 18e édition ...](https://www.avnation.tv/fr/2024/12/31/La-plateforme-Zenapptic-ais-Zen3-alimente-la-18e-%C3%A9dition-annuelle-de-la-Good-Riddance-Day-%C3%A0-One-Times-Square/)**
  - Source: avnation.tv
  - *Dec 31, 2024 ... « Notre plateforme a pour objectif de créer des liens humains grâce à la technologie », a déclaré David Wilkins, PDG de Zenapptic.AI....*

---

*Generated by Founder Scraper*
