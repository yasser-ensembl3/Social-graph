# Dominic Danis

## Position actuelle

**Titre** : Président et Cofondateur
**Entreprise** : Moov AI
**Durée dans le rôle** : 6 years 9 months in role
**Durée dans l'entreprise** : 6 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Résumé

Démocratiser le AI et contribuer à rendre le Québec plus performant par l'utilisation concrète de l'intelligence artificielle.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAGifukBJfDktGjP2BkhE1rNVX2xs7PrIFM/
**Connexions partagées** : 141


---

# Dominic Danis

## Position actuelle

**Entreprise** : Moov AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Dominic Danis

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7388310471667511296 | Article |  |  | Wow! Brilliant idea! Huge congrats to the Leo Toronto ThePub Productions and Starcom Canada and our Publicis colleagues for this creative home run. | 3 | 0 | 0 | 1mo | Post | Dominic Danis | https://www.linkedin.com/in/dominicdanis | https://linkedin.com/in/dominicdanis | 2025-12-08T05:05:19.179Z |  | 2025-10-26T20:28:04.616Z | https://youtu.be/dAOkzLFo9CQ?si=vpGg8R33GixpV9EM |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7376263518733406208 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE0b3x9eGm98Q/feedshare-shrink_800/B56Zlx0z2iG0Ag-/0/1758551294044?e=1766620800&v=beta&t=gbwt-ITWpm1S4_XcbAQhpUUIZlp4P3OY1M7zMRZf0xE | A proud milestone for Moov AI

Being named a Major Player in the IDC MarketScape: Canadian AI Services 2025 is a strong validation of our vision and the impact of our applied AI approach.

I’m especially proud of our teams, who have earned us a place alongside international giants like CGI, Deloitte, Accenture and other global leaders. Our commitment, creativity, and ability to deliver real, production-ready AI solutions truly set us apart.

A huge thank you to our clients and partners for trusting us to turn AI into real impact across Canada. This recognition belongs to you as much as to us.

Read the full announcement: https://lnkd.in/gQZzaVds | 33 | 2 | 1 | 2mo | Post | Dominic Danis | https://www.linkedin.com/in/dominicdanis | https://linkedin.com/in/dominicdanis | 2025-12-08T05:05:19.180Z |  | 2025-09-23T14:37:47.215Z | https://www.linkedin.com/feed/update/urn:li:activity:7376223853573894144/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7325933709818302464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGocxLNfaEfMg/feedshare-shrink_800/B4EZarx4cuHcAg-/0/1746638704376?e=1766620800&v=beta&t=XeKeln9AJqs4yv06qEP4wflatZ3teX1_I5lFe7mBjRY | Hier, j’étais paneliste avec Olivier Laquinte et Veronica Marquez, cssbb à l’événement Cap vers la réussite organisé par le Réseau des Femmes d'affaires du Québec. Un événement riche en prises de conscience… et en conviction renouvelée : 👉 C’est avec l’IA qu’on va rendre le Québec plus productif. Mais pour y arriver, il faut lever certains freins et oser.
 
Voici quelques constats que j’ai faits hier :
1️⃣ L’urgence n’est pas encore ressentie.
Et pourtant, la productivité au Canada est en baisse. Des secteurs comme la construction sont sérieusement en retard. Ce n’est plus le moment d’attendre.

2️⃣ Les femmes hésitent plus longtemps avant de se lancer.
Pas par manque de talent. Mais parce qu’on cherche la certitude. Or, l’IA, c’est tout sauf certain. C’est nouveau, rapide, évolutif. Et ça peut faire peur.

3️⃣ Moins d’abonnements payants à ChatGPT = moins d’expérimentation = un retard qui s’installe.
Oui, il y a un coût. Mais il y a surtout un coût à ne pas y aller.
 
L’IA ne remplacera pas les gens. Elle nous oblige par contre à sortir d’une pensée linéaire, à revoir notre rôle de gestionnaire et à devenir plus agiles. 
 
Selon Florence Jean-Jacobs, économiste principale chez Desjardins, les projets d’IA générative offrent un retour sur investissement de 3,7 fois. Alors, pourquoi attendre? GO. Allez-y. Osez. Testez. Apprenez.
 
Le Québec a tout pour devenir une force en IA. Mais pour y arriver, on a besoin de plus de femmes, de plus de PME, de plus de leaders qui font le saut. Maintenant. | 57 | 3 | 0 | 7mo | Post | Dominic Danis | https://www.linkedin.com/in/dominicdanis | https://linkedin.com/in/dominicdanis | 2025-12-08T05:05:19.181Z |  | 2025-05-07T17:25:05.687Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7323423040199929856 | Video (LinkedIn Source) | blob:https://www.linkedin.com/751f167b-ddb5-44d2-8c4d-2b51fda6dedb | https://media.licdn.com/dms/image/v2/D4E05AQGhJwKf82z3Uw/videocover-low/B4EZaIGabdHcCI-/0/1746040109207?e=1765778400&v=beta&t=SottCJmNjV2fmgCigbN2G-CAeEoG5v-NEaM-RU2Y5ss | Je suis heureux de participer au panel sur l’intelligence artificielle et la transformation des modèles d’affaires dans le cadre de Cap vers la réussite, organisé par le Réseau des Femmes d'affaires du Québec
 
Aux côtés de Veronica Marquez, cssbb de Aristeío et Olivier Laquinte de TALSOM, nous échangerons sur un sujet qui me passionne : comment l’IA peut devenir un levier concret pour bâtir une compétitivité durable.
 
Pour moi, c’est essentiel de partager notre expérience et de montrer comment l’IA peut aider les organisations à faire face aux défis actuels — que ce soit pour mieux planifier, mieux servir leurs clients ou innover plus rapidement.
 
Merci au RFAQ pour l’invitation et pour créer ces espaces de dialogue qui font avancer les choses. Hâte de vous y retrouver! | 58 | 4 | 2 | 7mo | Post | Dominic Danis | https://www.linkedin.com/in/dominicdanis | https://linkedin.com/in/dominicdanis | 2025-12-08T05:05:19.182Z |  | 2025-04-30T19:08:35.404Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7291128347575660547 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG97n_UcI2Ycg/feedshare-shrink_800/B4EZS3imxIHUAo-/0/1738246091091?e=1766620800&v=beta&t=xzSBk4r2FlDigdjZcYvprHrle_BxcAcd_0N7Y2Y9oz4 | Je suis vraiment fier de toute l'équipe de Moov AI qui a eu cette incroyable idée des bananes! On en parle encore 2 ans plus tard! Good job. | 10 | 1 | 0 | 10mo | Post | Dominic Danis | https://www.linkedin.com/in/dominicdanis | https://linkedin.com/in/dominicdanis | 2025-12-08T05:05:23.666Z |  | 2025-01-31T16:21:00.676Z | https://www.linkedin.com/feed/update/urn:li:activity:7290732538556211203/ |  | 

---



---

# Dominic Danis
*Moov AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [Maxime Boissonneault and Christian Mérat join Moov AI](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai)
*2020-03-03*
- Category: blog

### [Content Sites in the Age of AI: Challenges and Strategies with Dominic Wells, CEO of Onfolio – Market Movers: Building Brands & Links with Linkifi](https://uk-podcasts.co.uk/podcast/market-movers-building-brands-links-with-linkifi/content-sites-in-the-age-of-ai-challenges-and-stra)
*2025-01-01*
- Category: podcast

### [S3E8: Why the World Needs an Internet Computer w. Dominic Williams (Founder, DFINITY) by Blockchain Won't Save the World](https://creators.spotify.com/pod/profile/blockchainwstw/episodes/S3E8-Why-the-World-Needs-an-Internet-Computer-w--Dominic-Williams-Founder--DFINITY-e1vlme9)
*2025-05-03*
- Category: podcast

### [The Bootstrapped Founder | 280: Dominic Monn — Crafting a Thriving Online Mentorship Community](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community)
*2023-12-29*
- Category: article

### [Roundtable: “The Role of AI in the Crypto Space” - MSV Podcast](https://www.msvpodcast.com/2001067/episodes/12804409-roundtable-the-role-of-ai-in-the-crypto-space)
*2023-05-04*
- Category: podcast

---

## 📖 Full Content (Scraped)

*10 articles scraped, 25,362 words total*

### Maxime Boissonneault and Christian Mérat join Moov&nbsp;AI
*3,500 words* | Source: **EXA** | [Link](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai)

Maxime Boissonneault and Christian Mérat join Moov AI - Moov AI

===============

![Image 4: logo](blob:http://localhost/4eb6460ab93a7ae1978320dda45af1eb)

[](https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/)

*   [Consent](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)
*   [Details](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)
*   [[#IABV2SETTINGS#]](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)
*   [About](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services. 

Consent Selection

**Necessary** 

- [x] 

**Preferences** 

- [x] 

**Statistics** 

- [x] 

**Marketing** 

- [x] 

[Show details](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)

Details

*   
Necessary  21- [x]   Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies. 

    *   [Cloudflare 1](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)[Learn more about this provider![Image 5](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.cloudflare.com/privacypolicy/ "Cloudflare's privacy policy")**cf.turnstile.u**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Persistent**Type**: HTML Local Storage   
    *   [Cookiebot 1](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)[Learn more about this provider![Image 6](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.cookiebot.com/goto/privacy-policy/ "Cookiebot's privacy policy")**CookieConsent**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 1 year**Type**: HTTP Cookie   
    *   [Google 2](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)[Learn more about this provider![Image 7](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://business.safety.google/privacy/ "Google's privacy policy")Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.

**test_cookie**Used to check if the user's browser supports cookies.**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie  **_GRECAPTCHA**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [HubSpot 4](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)[Learn more about this provider![Image 8](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://legal.hubspot.com/privacy-policy "HubSpot's privacy policy")**rc::a**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: Persistent**Type**: HTML Local Storage  **rc::b**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Session**Type**: HTML Local Storage  **rc::c**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Session**Type**: HTML Local Storage  **rc::f**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Persistent**Type**: HTML Local Storage   
    *   [LinkedIn 2](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)[Learn more about this provider![Image 9](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.linkedin.com/legal/privacy-policy "LinkedIn's privacy policy")**bcookie**Used in order to detect spam and improve the website's security. **Maximum Storage Duration**: 1 year**Type**: HTTP Cookie  **li_gc**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [challenges.cloudflare.com hsforms.com vimeo.com 4](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)**_cfuvid[x4]**Pending**Maximum Storage Duration**: Session**Type**: HTTP Cookie   
    *   [hubapi.com moov.ai platform.twitter.com vimeo.com 5](https://moov.ai/en/blog/maxime-boissonneault-et-christian-merat-se-joignent-a-moov-ai#)**__cf_bm[x5]**This cookie is used to distinguish between human

*[... truncated, 27,787 more characters]*

---

### Just a moment...
*22 words* | Source: **EXA** | [Link](https://uk-podcasts.co.uk/podcast/market-movers-building-brands-links-with-linkifi/content-sites-in-the-age-of-ai-challenges-and-stra)

uk-podcasts.co.uk
-----------------

Verify you are human by completing the action below.

uk-podcasts.co.uk needs to review the security of your connection before proceeding.

---

### S3E8: Why the World Needs an Internet Computer w. Dominic Williams (Founder, DFINITY) by Blockchain Won't Save the World
*9,497 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/blockchainwstw/episodes/S3E8-Why-the-World-Needs-an-Internet-Computer-w--Dominic-Williams-Founder--DFINITY-e1vlme9)

![Image 1: Currently playing episode](https://d3t3ozftmdmh3i.cloudfront.net/production/podcast_uploaded_episode400/3286365/3286365-1684189691323-87feb9d9cda7e.jpg)

S3E8: Why the World Needs an Interne…
-------------------------------------

Blockchain Won't Save the World Mar 04, 2023

00:00

01:06:40

[![Image 2: S4E34 theMiracle: Web3 Wallets as 'SuperApps' w. Mo Salha](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/3286365/3286365-1762616008050-233c7cd7f0e49.jpg) #### S4E34 theMiracle: Web3 Wallets as 'SuperApps' w. Mo Salha Wallets are where the value is, where users transact, and where we can link intent and action. So why is everyone sleeping on Web3 wallets?Following a 'charmed' panel performance at Zebu Live, Mo and I reconnect to take you through the opportunities and challenges of engaging customers through Web3 wallets, and what's possible for brand and chains todayIn this show we cover:- Mo's diverse history in Web2 and what brought him to Web3- The current state of Web3 wallets and wallet UX- How 'easy' it is to track and target Web3 wallet users- Opportunities and implications for brands and marketeers- Privacy considerations for on-chain data trails Nov 08, 2025 48:22](https://creators.spotify.com/pod/profile/blockchainwstw/episodes/S4E34-theMiracle-Web3-Wallets-as-SuperApps-w--Mo-Salha-e3amcgc)[![Image 3: S4E33 Sequence: How to Fix Web3 UX & Interoperability w. Michael Sanders (Co-Founder)](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/3286365/3286365-1760094203761-2ed0b3e45dd09.jpg) #### S4E33 Sequence: How to Fix Web3 UX & Interoperability w. Michael Sanders (Co-Founder) Many complain about the state of usability and user experience (UX) in Web3, and how it's hindering widespread adoption. But Michael argues, we've already solved these issues TODAY...Sequence has a fascinating history, from early days of Web3 Gaming to a modern, EVM-compatible, multi-chain dApp toolkit which is making life easier for builders and users alike. This is a story you need to hear.In this show we cover:- The fascinating Sequence origin story - Current state of the Ethereum and EVM ecosystem- What people mean by 'improving Web3 UX' (and how Sequence solves this)- Interoperability (making cross ETH, L2 and non-ETH chain transactions easy and secure)- What more is required for wider adoption of Web3 and decentralised apps Oct 10, 2025 39:36](https://creators.spotify.com/pod/profile/blockchainwstw/episodes/S4E33-Sequence-How-to-Fix-Web3-UX--Interoperability-w--Michael-Sanders-Co-Founder-e39bict)[![Image 4: S4E32 CV VC: The State of Crypto Valley and Web3 VCs w. Mathias Ruch](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/3286365/3286365-1758497435822-d4b644d595594.jpg) #### S4E32 CV VC: The State of Crypto Valley and Web3 VCs w. Mathias Ruch The institutions are coming! And they're currently driving the next wave of investment and growth in Web3. But what are they looking for in 2025, and how has the go-to-market offering changed for VCs as the industry matures? Mathias and CV VC have been one of the leading institutions driving forward Web3 adoption, first in Crypto Valley and today across the globe. From partnerships in the UAE, reach into LatAm and AsPac. The model today, as with Web3, is truly global.But it's not just capital that the CV team bring to the table. The business model has evolved a LOT since 2018, as has the competition, as TradFi, Exchanges and even wealthy OGs look to muscle in on traditional VC turf.On this show, Mathias will take us through: - The origins of CV VC and CV Labs - What's changed over the years in terms of thesis and offerings - What has the 2025 'Institutional Wave' brought from his viewpoint - What more is needed from VCs to support wider Web3 growth - A look forward to CV Summit in Zurich, Sept 23-24th Sep 21, 2025 44:25](https://creators.spotify.com/pod/profile/blockchainwstw/episodes/S4E32-CV-VC-The-State-of-Crypto-Valley-and-Web3-VCs-w--Mathias-Ruch-e38hdpl)[![Image 5: S4E31 CryptoProcessing: Meet People With Crypto w. Max Krupyshev (CEO, CoinsPaid)](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/3286365/3286365-1752956893128-31a523fc78072.jpg) #### S4E31 CryptoProcessing: Meet People With Crypto w. Max Krupyshev (CEO, CoinsPaid) People with crypto are ready to pay. This is a call to action for businesses from the travel industry to real estate, from Forex to iGaming. There are 600 Million+ people holding cryptocurrency of some kind, and with EU crypto regulation MiCA comes fully into force, the Genius Bill and stable coin sentiment escalating in the USA; it’s only a matter of time before crypto payments become mainstream.And the good news is, there’s already a solution for businesses: a ‘one button click’ style crypto payments feature today.I’m joined by Max Krupyshev, leader of CryptoProcessing by CoinsPaid - crypto payment gateway, which helps businesses plug into t

*[... truncated, 67,164 more characters]*

---

### The Bootstrapped Founder | 280: Dominic Monn — Crafting a Thriving Online Mentorship Community
*341 words* | Source: **EXA** | [Link](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community)

[Show Notes](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community "View episode details")/[Transcript](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community/transcript "View episode transcript")

Dominic Monn ([@dqmonn](https://twitter.com/dqmonn)), the pioneering founder of MentorCruise, shares the secrets behind building a flourishing online mentorship community that transcends the traditional face-to-face model. Dominic reveals how MentorCruise fosters authentic relationships between mentors and mentees through a rigorous verification process, ensuring a trusted and effective learning environment. Whether you're a mentor, a mentee, or just curious about the virtual mentorship space, this episode offers a wealth of insights into creating genuine connections and a thriving platform for growth.

Dominic Monn on Twitter: [https://twitter.com/dqmonn](https://twitter.com/dqmonn)

[00:00:00](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0h0m0s "Jump to 00:00:00 in this episode") Building and Scaling a Vetted Marketplace

[00:13:05](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0h13m5s "Jump to 00:13:05 in this episode") Startups, Hiring, and Building a Marketplace

[00:20:29](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0h20m29s "Jump to 00:20:29 in this episode") Pricing and Evolution of Mentorship Platform

[00:29:48](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0h29m48s "Jump to 00:29:48 in this episode") Metrics and Tools for Marketplace Growth

[00:41:13](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0h41m13s "Jump to 00:41:13 in this episode") Building a Business in Switzerland

This episode is sponsored by [Acquire.com](http://try.acquire.com/arvid/)

The blog post: [https://thebootstrappedfounder.com/dominic-monn-crafting-a-thriving-online-mentorship-community/](https://thebootstrappedfounder.com/dominic-monn-crafting-a-thriving-online-mentorship-community/)

*   ([00:00](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=0m0s "Jump to 00:00 in this episode")) - Building and Scaling a Vetted Marketplace 
*   ([13:05](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=13m5s "Jump to 13:05 in this episode")) - Startups, Hiring, and Building a Marketplace 
*   ([20:29](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=20m29s "Jump to 20:29 in this episode")) - Pricing and Evolution of Mentorship Platform 
*   ([29:48](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=29m48s "Jump to 29:48 in this episode")) - Metrics and Tools for Marketplace Growth 
*   ([41:13](https://tbf.fm/episodes/280-dominic-monn-crafting-a-thriving-online-mentorship-community#t=41m13s "Jump to 41:13 in this episode")) - Building a Business in Switzerland 

### Creators and Guests

[![Image 1: Arvid Kahl](https://img.transistor.fm/8Cz5xnnBCaZZmJUAVErJwi3OcvOPmzHFk30XMuuyWUQ/rs:fill:0:0:1/w:400/h:400/q:60/mb:500000/aHR0cHM6Ly9pbWct/dXBsb2FkLXByb2R1/Y3Rpb24udHJhbnNp/c3Rvci5mbS9wZXJz/b24vOGJiNDU5YzEt/NjFhMi00NzdhLThm/OWMtMWE1ZTUxMTVi/MzQ5LzE2NjY4ODYy/MjItaW1hZ2UuanBn.webp) Host](https://tbf.fm/people/arvid-kahl "Arvid Kahl")

[Arvid Kahl](https://tbf.fm/people/arvid-kahl "Arvid Kahl")

Empowering founders with kindness. Building in Public. Sold my SaaS FeedbackPanda for life-changing $ in 2019, now sharing my journey & what I learned.

[](https://x.com/arvidkahl "Twitter")[](https://linktr.ee/arvidkahl "Website")

[![Image 2: Dominic Monn](https://img.transistor.fm/RvJd6yttpDL-xBzqo4SJyhJ-JImW8SPvfAeQ7X0fxLA/rs:fill:0:0:1/w:400/h:400/q:60/mb:500000/aHR0cHM6Ly9pbWct/dXBsb2FkLXByb2R1/Y3Rpb24udHJhbnNp/c3Rvci5mbS9wZXJz/b24vNGIyOTE2ZDIt/MTI3Mi00MDY0LTgz/ZmMtM2VlYjE5Yzk5/YjA5LzE3MDM2MDc1/NjAtaW1hZ2UuanBn.webp) Guest](https://tbf.fm/people/dominic-monn "Dominic Monn")

[Dominic Monn](https://tbf.fm/people/dominic-monn "Dominic Monn")

On the silly quest to build a bootstrapped marketplace at https://t.co/OI0swUxdBc 🧪Helped mentors earn $4M. Now sharing learnings on the journey to the next $10M 🚀

[](https://x.com/dqmonn "Twitter")[](https://mentors.to/dom "Website")

![Image 3: 280: Dominic Monn — Crafting a Thriving Online Mentorship Community](https://img.transistor.fm/-2SYiaOSSB9fS2aP9qitxUM-4A-NDFwdogR88sBSD4k/rs:fill:0:0:1/w:800/h:800/q:60/mb:500000/aHR0cHM6Ly9pbWct/dXBsb2FkLXByb2R1/Y3Rpb24udHJhbnNp/c3Rvci5mbS9lcGlz/b2RlLzE2NjA2ODcv/MTcwMzYwNzM0NC1h/cnR3b3JrLmpwZw.webp)

[Broadcast by](https://transistor.fm/ "Transistor.fm - Podcast Hosting and Analytics")

---

### Roundtable: “The Role of AI in the Crypto Space” - MSV Podcast
*561 words* | Source: **EXA** | [Link](https://www.msvpodcast.com/2001067/episodes/12804409-roundtable-the-role-of-ai-in-the-crypto-space)

**Guests:**

*   Humayun Sheikh, Founder of [Fetch.AI](https://twitter.com/Fetch_ai)
*   Pedro Rente Lourenco, Ceo of [Dotmoovs](https://twitter.com/dotmoovs)
*   Sabin Dima, Co-Founder of [HumansAI](https://twitter.com/humansdotai)

**Top 3 Key Takeaways:**

**1. AI and Crypto need strong and timely regulation to promote trust, transparency, and fairness**

During our conversation with industry experts, we delved into the challenges facing the nascent industries of crypto and AI. One point of discussion was the need for regulation in both fields, as it can promote wider adoption and protect users' privacy. However, there are also concerns that excessive regulation can stifle innovation and creativity- arguing that self-regulation could be a viable alternative, but with a potential worry that this approach could lead to exploitation by a few bad actors in the industry.

Regardless, a growing consensus is that regulators must ensure fair economic dispensation and copyright governance in AI. This is particularly important given the potential for big corporations to exploit AI for their gain is already leading to job losses and economic inequality. In short, we need strong and timely regulation to promote trust, transparency, and fairness in these exciting and evolving industries.

**2. A decentralized AI model can empower individuals with unique skills and capabilities**The conversation continued with the hosts stating that most AI solutions today are developed by centralized entities and what the benefits are of a decentralized AI approach. The consensus was while the AI model itself cannot be decentralized, stakeholders involved in its development and utilization can be. A decentralized AI model can empower individuals with skills and capabilities that were previously impossible to attain. In today's world, knowledge is highly valued, and asking a question is considered a luxury. For instance, if we want to draw a difference between how web2 and web3 rewards a question, look at what ChatGPT is doing; it takes credit for the questions we ask and profit from answering questions posed to it.

In contrast, through Web3 and decentralized models, the first person to ask a question owns that unique question. Web3 rewards that person's curiosity and creativity, and every subsequent person who asks your question allows you to receive a reward. This is a significant improvement over Web2, where individuals who ask questions are not rewarded for their contribution.

**3. We must move beyond the generative aspect of AI and focus on how to use the outputs to create actionable items**Although many people view generative AI as a significant breakthrough, it is just the beginning. We must move beyond the generative aspect of AI and focus on how to use the outputs to create actionable items. To do this, we need to develop the necessary frameworks for deployment. For instance, generating an email is just the start; we must also incorporate an email server to send it. Similarly to this concept, to turn AI-generated content into meaningful actions, we need to focus on artificial general intelligence, which is making slow but steady progress. We need to encourage developers to use AI as a tool to generate new business models and make money. They should experiment with new ideas and applications using the frameworks mentioned above. Educating yourself about the field and questioning if things are being done ethically and properly is crucial. Always DYOR (Do Your Own Research) and don't blindly follow what others are saying. Building confidence that you are doing the right thing for the industry is essential.

---

### #12: Culture et intelligence artificielle – Dominic Danis
*372 words* | Source: **GOOGLE** | [Link](https://cultureincpodcast.com/index.php/2019/12/19/culture-et-intelligence-artificielle-dominic-danis/)

#12: Culture et intelligence artificielle – Dominic Danis - Culture Inc

===============

[![Image 1: Culture Inc](https://cultureincpodcast.com/wp-content/uploads/2019/09/cropped-android-icon-144x144-3.png)![Image 2: Culture Inc](https://cultureincpodcast.com/wp-content/uploads/2019/09/cropped-android-icon-144x144-3.png)![Image 3: Culture Inc](https://cultureincpodcast.com/index.php/2019/12/19/culture-et-intelligence-artificielle-dominic-danis/)![Image 4: Culture Inc](https://cultureincpodcast.com/index.php/2019/12/19/culture-et-intelligence-artificielle-dominic-danis/)](https://cultureincpodcast.com/)

[](https://cultureincpodcast.com/index.php/2019/12/19/culture-et-intelligence-artificielle-dominic-danis/#)

[](mailto:mathieu@cultureincpodcast.com)[](https://fb.me/cultureincpodcast)[](https://twitter.com/CultureInc2)[](https://www.google.com/podcasts?feed=aHR0cDovL2N1bHR1cmVpbmNwb2RjYXN0LmNvbS9pbmRleC5waHAvZmVlZC9wb2RjYXN0Lw)[](https://podcasts.apple.com/ca/podcast/culture-inc/id1481792904)[](https://open.spotify.com/show/6pxuX7I4Ok2KeRkhdZJR5M)[](https://www.linkedin.com/company/culture-inc-podcast)

*   [Accueil](https://cultureincpodcast.com/)
*   [À propos](https://cultureincpodcast.com/index.php/a-propos-podcast-culture-inc/)
*   [Épisodes](https://cultureincpodcast.com/index.php/liste-podcast/)

Décembre 19, 2019
#12: Culture et intelligence artificielle – Dominic Danis
---------------------------------------------------------

[https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3](https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3)

Podcast: [Play in new window](https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3 "Play in new window") | [Download](https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3 "Download")

S'abonner [Apple Podcasts](https://podcasts.apple.com/ca/podcast/culture-inc/id1481792904?mt=2&ls=1 "Subscribe on Apple Podcasts") | [RSS](https://cultureincpodcast.com/index.php/feed/podcast/ "Subscribe via RSS")

Podcast: [Play in new window](https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3 "Play in new window") | [Download](https://media.blubrry.com/culture_inc/content.blubrry.com/culture_inc/DominicDanis_Saison1.mp3 "Download") |

L’avancement des technologies, particulièrement au niveau de l’intelligence artificielle, change radicalement la vie des gens et leur manière de travailler. Est-ce que ce changement aura des impacts sur les relations entre personnes dans un future à court et moyen terme? Devra-t-on revoir des éléments fondamentaux de collaboration, évolution et même au niveau de la place de l’humain au centre des entreprises? On explore ce sujet plus que moderne avec Dominic Danis, de [Moov.ai.](https://moov.ai/)

Biographie de l’invité
----------------------

![Image 5: Dominic Danis](http://cultureincpodcast.com/wp-content/uploads/2019/12/dominic-danis.jpg)

Dominic est un gestionnaire et entrepreneur ayant plus de 20 ans d’expérience à mener des équipes et à livrer des projets de qualité. Depuis 2018, Dominic a entrepris un projet ambitieux à l’aide de 4 autres partenaires: fonder une entreprise qui a comme mission de démocratiser l’intelligence artificielle. Après avoir expérimenté, raté notre coup, mais aussi connu des succès transformatifs, [Moov AI](https://moov.ai/) a été créé afin d’accompagner les entreprises québécoises à produire des résultats concrets et à générer de la valeur dans leurs entreprises grâce à l’apprentissage machine et à l’intelligence artificielle.

Il se lève chaque matin pour générer de l’impact et faire adopter ces technologies une fois pour toutes dans les entreprises québécoises.

Liens mentionnés durant l’épisode
---------------------------------

*    Profile LinkedIn de Dominic:[https://www.linkedin.com/in/dominicdanis/](https://www.linkedin.com/in/dominicdanis/)
*   Email de Dominic: [dominic.danis@moov.ai](mailto:dominic.danis@moov.ai)
*   Management 3.0 : [https://jurgenappelo.com/management-30/](https://jurgenappelo.com/management-30/)
*   5 Dysfonctions d’une équipe : [https://www.tablegroup.com/books/dysfunctions/](https://www.tablegroup.com/books/dysfunctions/)
*   Tribal Leadership: [https://www.amazon.com/Tribal-Leadership-Leveraging-Thriving-Organization/dp/0061251321](https://www.amazon.com/Tribal-Leadership-Leveraging-Thriving-Organization/dp/0061251321)
*   Le programme LEADERS 
    *   [https://www4.fsa.ulaval.ca/etudes/autres-formations/programme-leaders/](https://www4.fsa.ulaval.ca/etudes/autres-formations/programme-leaders/)
    *   [https://www.youtube.com/watch?v=Pb0-G-sRxCg&feature=youtu.be](https://www.youtube.com/watch?v=Pb0-G-sRxCg&feature=youtu.be)

*   Livre Osons l’IA à l’école: [https://www.leslibraires.ca/livres/osons-l-ia-a-l-ecole-ugo-cavenaghi-9782924847138.html](https://www.leslibraires.ca/livre

*[... truncated, 1,118 more characters]*

---

### Publicis acquires Moov AI, Canada's Leading AI Company
*3,081 words* | Source: **GOOGLE** | [Link](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html)

Publicis acquires Moov AI, Canada's Leading AI Company

===============

[Close menu](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-0)

*   [News](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-news)
*   [Products](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-products)
*   [Contact](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-contact)

[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-default)
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-news)
*   _3_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-1)News in Focus
*   _5_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-2)Business
*   _5_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-3)Science & Tech
*   _5_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-4)Lifestyle & Health
*   _1_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-5)Policy & Public Interest
*   _1_[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-6)People & Culture
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-products)
*   [Explore Our Platform](https://www.newswire.ca/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.newswire.ca/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.newswire.ca/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.newswire.ca/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.newswire.ca/multichannel-amplification/ "Amplify Content ")
*   [IR](https://www.newswire.ca/products/investor-relations/ "IR")
*   [All Products](https://www.newswire.ca/products/all-products/ "All Products")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html#mm-panel-contact)
*   [Sign Up](https://www.newswire.ca/contact-us "Sign Up")
*   [Request a Demo](https://www.newswire.ca/request-a-demo/ "Request a Demo")
*   [Editorial Bureaus](https://www.newswire.ca/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https://www.newswire.ca/contact-us/partnerships "Partnerships")
*   [General Enquiries](https://www.newswire.ca/contact-us/general-enquiries/ "General Enquiries")
*   [Media Enquiries](https://www.newswire.ca/contact-us/media-enquiries "Media Enquiries")
*   [Worldwide Offices](https://www.newswire.ca/contact-us/worldwide-offices "Worldwide Offices")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/

*[... truncated, 71,555 more characters]*

---

### Publicis acquires Moov AI, Canada's Leading AI Company
*4,439 words* | Source: **GOOGLE** | [Link](https://finance.yahoo.com/news/publicis-acquires-moov-ai-canadas-142000570.html)

Publicis acquires Moov AI, Canada's Leading AI Company

===============

Oops, something went wrong

[Skip to navigation](https://finance.yahoo.com/news/publicis-acquires-moov-ai-canadas-142000570.html#ybar-navigation)[Skip to main content](https://finance.yahoo.com/news/publicis-acquires-moov-ai-canadas-142000570.html#nimbus-app)[Skip to right column](https://finance.yahoo.com/news/publicis-acquires-moov-ai-canadas-142000570.html#right-rail)

### [News](https://www.yahoo.com/)

*   [Today's news](https://www.yahoo.com/news/)
*   [US](https://www.yahoo.com/news/us/)
*   [Politics](https://www.yahoo.com/news/politics/)
*   [2025 Election](https://www.yahoo.com/events/elections/)
*   [World](https://www.yahoo.com/news/world/)
*   [Weather](https://www.yahoo.com/news/weather/)
*   [Climate change](https://www.yahoo.com/issues/climate-change/)
*   [Health](https://health.yahoo.com/)

    *   [Wellness](https://health.yahoo.com/wellness/)

        *   [Mental health](https://health.yahoo.com/wellness/mental-health/)
        *   [Sexual health](https://health.yahoo.com/wellness/sexual-health/)
        *   [Dermatology](https://health.yahoo.com/wellness/dermatology/)
        *   [Oral health](https://health.yahoo.com/wellness/oral-health/)
        *   [Hair loss](https://health.yahoo.com/wellness/hair-loss/)
        *   [Foot health](https://health.yahoo.com/wellness/foot-health/)

    *   [Nutrition](https://health.yahoo.com/nutrition/)

        *   [Healthy eating](https://health.yahoo.com/nutrition/healthy-eating/)
        *   [Meal delivery](https://health.yahoo.com/nutrition/meal-delivery/)
        *   [Weight loss](https://health.yahoo.com/nutrition/weight-loss/)
        *   [Vitamins and supplements](https://health.yahoo.com/nutrition/vitamins-supplements/)

    *   [Fitness](https://health.yahoo.com/fitness/)

        *   [Equipment](https://health.yahoo.com/fitness/equipment/)
        *   [Exercise](https://health.yahoo.com/fitness/exercise/)

    *   [Women's health](https://health.yahoo.com/womens-health/)
    *   [Sleep](https://health.yahoo.com/sleep/)
    *   [Healthy aging](https://health.yahoo.com/healthy-aging/)

        *   [Hearing](https://health.yahoo.com/healthy-aging/hearing/)
        *   [Mobility](https://health.yahoo.com/healthy-aging/mobility/)

*   [Science](https://www.yahoo.com/news/science/)
*   [Originals](https://www.yahoo.com/guides/originals/)

    *   [The 360](https://www.yahoo.com/events/elections/)

*   [Newsletters](https://news.yahoo.com/newsletters/)
*   [Games](https://www.yahoo.com/games)

### [Life](https://www.yahoo.com/lifestyle/)

*   [Health](https://health.yahoo.com/)

    *   [Wellness](https://health.yahoo.com/wellness/)

        *   [Nutrition](https://health.yahoo.com/wellness/nutrition/)
        *   [Fitness](https://health.yahoo.com/wellness/fitness/)
        *   [Healthy aging](https://health.yahoo.com/wellness/healthy-aging/)
        *   [Mental health](https://health.yahoo.com/wellness/mental-health/)
        *   [Sleep](https://health.yahoo.com/wellness/sleep/)

    *   [Your body](https://health.yahoo.com/your-body/)

        *   [Dermatology](https://health.yahoo.com/your-body/dermatology/)
        *   [Children's health](https://health.yahoo.com/your-body/childrens-health/)
        *   [Foot health](https://health.yahoo.com/your-body/foot-health/)
        *   [Hair loss](https://health.yahoo.com/your-body/hair-loss/)
        *   [Hearing](https://health.yahoo.com/your-body/hearing/)
        *   [Oral health](https://health.yahoo.com/your-body/oral-health/)
        *   [Sexual health](https://health.yahoo.com/your-body/sexual-health/)
        *   [Women's health](https://health.yahoo.com/your-body/womens-health/)

    *   [Conditions](https://health.yahoo.com/conditions/)

        *   [Cardiovascular health](https://health.yahoo.com/conditions/cardiovascular-health/)
        *   [Digestive health](https://health.yahoo.com/conditions/digestive-health/)
        *   [Endocrine system](https://health.yahoo.com/conditions/endocrine-system/)

*   [Parenting](https://www.yahoo.com/lifestyle/family-relationships/)

    *   [Family health](https://www.yahoo.com/lifestyle/family-relationships/)
    *   [So mini ways](https://www.yahoo.com/guides/so-mini-ways/)

*   [Style and beauty](https://www.yahoo.com/lifestyle/style-beauty/)

    *   [It Figures](https://www.yahoo.com/guides/it-figures/)
    *   [Unapologetically](https://www.yahoo.com/guides/unapologetically/)

*   [Horoscopes](https://www.yahoo.com/lifestyle/horoscope/)
*   [Shopping](https://shopping.yahoo.com/)

    *   [Style](https://shopping.yahoo.com/style/)

        *   [Accessories](https://shopping.yahoo.com/style/accessories/)
        *   [Clothing](https://shopping.yahoo.com/style/clothing/)
        *   [Luggage](https://shopping.yahoo.com/style/luggage/)
        *   [Shoes](https://shopping.yahoo.com/style/shoes/)

    *   [Beauty](https://shopping.yahoo.com/beauty/)

        *   [Hair](https:/

*[... truncated, 80,468 more characters]*

---

### Publicis fait l'acquisition de Moov AI, chef de file de l’IA au Canada
*1,874 words* | Source: **GOOGLE** | [Link](https://isarta.com/infos/publicis-fait-lacquisition-de-moov-ai-chef-de-file-de-lia-au-canada/)

Publicis fait l’acquisition de Moov AI, chef de file de l’IA au Canada – Isarta Infos | Tendances et Actualités Marketing, Gestion et RH

===============

*   [Emplois](https://isarta.com/emplois/?utm_source=Isarta_Infos)
*   [Candidats](https://isarta.com/emplois/placement.php?utm_source=Isarta_Infos)
*   [Employeurs](https://isarta.com/recrutement/entreprises.php?utm_source=Isarta_Infos)
*   [Formations](https://formations.isarta.com/?utm_source=Isarta_Infos)

*   [twitter](https://twitter.com/Isarta)
*   [facebook](https://www.facebook.com/Isarta)
*   [LinkedIn](http://www.linkedin.com/company/isarta)
*   [rss](https://isarta.com/infos/feed/)

[![Image 2: Isarta Infos | Tendances et Actualités Marketing, Gestion et RH](https://isarta.com/design/images/infos/isarta_tendances_logo_desktop.png?infos)](https://isarta.com/infos)[Emplois](https://isarta.com/emplois/?utm_source=Isarta_Infos) / [Formations](https://formations.isarta.com/?utm_source=Isarta_Infos)

*   [À la une](https://isarta.com/infos)
*   [Marketing et communication](https://isarta.com/infos/category/marketing-communications/ "Le monde des affaires, du marketing et des communications")
*   [Web et numérique](https://isarta.com/infos/category/web-reseauxsociaux/ "Web, réseaux sociaux et monde du digital")
*   [IA](https://isarta.com/infos/tag/ia/ "Intelligence artificielle (IA)")
*   [RH](https://isarta.com/infos/category/rh/ "Ressources humaines et marque employeur")
*   [Carrière](https://isarta.com/infos/category/carriere/ "Astuces carrière et emploi")
*   [Échos de l’industrie](https://isarta.com/infos/category/breves-industries/ "Les nouvelles de l’industrie de la publicité au Québec")
*   [Podcasts](https://formations.isarta.com/podcast "Les balados / podacsts")
    *   [Le Social Show](https://formations.isarta.com/podcast/social-show)
    *   [On parle de bien-être numérique](https://formations.isarta.com/podcast/bien-etre-numerique)

Publicis fait l’acquisition de Moov AI, chef de file de l’IA au Canada Reviewed by La Rédaction on Mar 27. De gauche à droite, derrière : Duncan Bruce (Président et chef de la direction, Publicis Canada), Maxime Boissonneault (Cofondateur, Moov AI), Guillaume Petitcl De gauche à droite, derrière : Duncan Bruce (Président et chef de la direction, Publicis Canada), Maxime Boissonneault (Cofondateur, Moov AI), Guillaume Petitcl Rating: 0

Publicis fait l’acquisition de Moov AI, chef de file de l’IA au Canada
======================================================================

Par [](https://isarta.com/infos/publicis-fait-lacquisition-de-moov-ai-chef-de-file-de-lia-au-canada/)[La Rédaction](https://isarta.com/infos/author/communiques/ "Articles par La Rédaction")

![Image 3](https://isarta.com/infos/wp-content/uploads/2025/03/moov-publicis-1024x676.jpg)

De gauche à droite, derrière : Duncan Bruce (Président et chef de la direction, Publicis Canada), Maxime Boissonneault (Cofondateur, Moov AI), Guillaume Petitclerc, (Cofondateur Moov AI) et Olivier Cabanes (Cofondateur, Moov AI)

Devant: Dominic Danis (Cofondateur, Moov AI), Olivier Blais (Cofondateur, Moov AI) et Andrew Bruce (Président et chef de la direction, Publicis Groupe Canada et Président, Leo Amérique du Nord) – Crédit photo : Annie-Claude Photographie

27 mars 2025

**Publicis Groupe a conclu une entente définitive en vue de l’acquisition de Moov AI, chef de file canadien de solutions en intelligence artificielle et en données, ayant réalisé des activations stratégiques en IA pour plus de 100 clients au Canada.**

Fondée en 2018 et basée à Montréal, Moov AI compte plus de 60 experts dédiés à l’IA, incluant des scientifiques de données, développeurs de données, conseillers stratégiques, gestionnaires de projets IA et analystes de données.

Reconnue « Meilleur employeur startup » par Forbes (2024) et nommé comme un des 9 événements d’envergure des 10 dernières années en IA au Québec par le Conseil du Patronat du Québec (2024), Moov AI aide les entreprises à optimiser leurs activités grâce aux données et à l’intelligence artificielle.

Elle offre des services tels que le conseil stratégique, la formation en IA générative, l’analytique avancée, ainsi que le développement et le déploiement de solutions concrètes en IA à la fine pointe de l’industrie. Avec le marché canadien de l’IA dont la valeur est estimée à 28,2 milliards de dollars d’ici 2028, la combinaison de l’offre CoreAI de Publicis Groupe avec l’expertise de Moov AI en matière de conseil de haut niveau, de solutions propriétaires et d’analyses, constituera un puissant moteur d’innovation alimenté par l’IA et un ensemble de capacités que Publicis Groupe Canada pourra exploiter sur le marché. Grâce à cette acquisition, les clients pourront accélérer leur capacité à offrir une personnalisation à grande échelle :

• Conseil stratégique et solutions sur mesure : Les experts en IA de Moov AI, grâce à leur approche stratégique unique et à leurs outils propriétaires, aident les clients à développer 

*[... truncated, 16,678 more characters]*

---

### TELUS celebrates top 15 finalists of its #StandWithOwners program
*1,675 words* | Source: **GOOGLE** | [Link](https://www.theglobeandmail.com/business/adv/article-telus-celebrates-top-15-finalists-of-its-standwithowners-program/)

TELUS is celebrating small business owners from this year’s [#StandWithOwners](https://www.telus.com/en/business/small/campaigns/stand-with-owners), a program designed to champion groundbreaking, growth-minded, game-changing business owners who are driving innovation in their field, serving their customers and communities in meaningful ways and using technology to grow and differentiate their business.

From thousands of applications, the #StandWithOwners program officially announced [five grand prize winners](https://www.theglobeandmail.com/business/adv/article-telus-celebrates-five-grand-prize-winners-of-its-standwithowners/), selected by a panel of judges, and 15 finalists. The grand prize winners received over $125,000 in funding, advertising and technology and finalists also received $20,000 in funding, technology and additional prizing.

Read the profiles of the top 15 finalists below.

* * *

[Open this photo in gallery: ![Image 1](https://www.theglobeandmail.com/resizer/v2/EAGC66T6KFCXRPANSFJBYPOPHY.jpg?auth=8f79abd8f51e76f2e0209e1c2ba7969bdbfe84f146f0592a93c65af652fcfcd6&width=600&quality=80)](https://www.theglobeandmail.com/resizer/v2/EAGC66T6KFCXRPANSFJBYPOPHY.jpg?auth=8f79abd8f51e76f2e0209e1c2ba7969bdbfe84f146f0592a93c65af652fcfcd6&width=600&height=400&quality=80&smart=true)

Supplied

### Yannick Badeau, Étienne Bernier and Marianne Charbonneau

Co-owners of [Agence Spatiale](https://www.agencespatiale.ca/)

Québec, Que.

Agence Spatiale is a design firm that brings together various disciplines such as architecture, art, interior design, product design, branding and urban planning in one space.

Founded in 2011 by Étienne Bernier, Agence Spatiale has now expanded to include partners Marianne Charbonneau and Yannick Badeau and a full team that uses a variety of cutting-edge technologies like virtual reality, 3D printers and AI tools to reach new heights of creative expression.

* * *

[Open this photo in gallery: ![Image 2](https://www.theglobeandmail.com/resizer/v2/NCCSKZCZFNBSTITHDRFMW6AXDU.jpg?auth=7557ec3a86c7e3ebd10c554dcfc31d147fadf43214e64f67fc55559efa05a0a6&width=600&quality=80)](https://www.theglobeandmail.com/resizer/v2/NCCSKZCZFNBSTITHDRFMW6AXDU.jpg?auth=7557ec3a86c7e3ebd10c554dcfc31d147fadf43214e64f67fc55559efa05a0a6&width=600&height=400&quality=80&smart=true)

Supplied

### Brenda Jenkins, Roxanne Whiting and Candice Presley

Owners of [Asign](https://asign.ca/)

Ottawa, Ont.

Asign is Canada’s leading expert in sign language interpreting and translation services both in-person and via video and provides services to all levels of government, business legal and community settings.

Asign has revolutionized the accessibility landscape for the deaf community. In the past, deaf individuals faced significant barriers when trying to access essential services due to the limited availability of sign language interpreters. By providing access to communication, the Video Remote Interpreting (VRI) on-demand platform ensures that deaf individuals can engage with organizations in the same manner as their non-deaf counterparts.

* * *

[Open this photo in gallery: ![Image 3](https://www.theglobeandmail.com/resizer/v2/XSWIQM7N5VDMHJQCOBP4T3ORJA.jpg?auth=9814825983958432a8e983fb3a8fc2b03344680502c4cb798f9a080af28240f8&width=600&quality=80)](https://www.theglobeandmail.com/resizer/v2/XSWIQM7N5VDMHJQCOBP4T3ORJA.jpg?auth=9814825983958432a8e983fb3a8fc2b03344680502c4cb798f9a080af28240f8&width=600&height=400&quality=80&smart=true)

Supplied

### Shannon Kamins

Owner of [Booch Organic Kombucha](https://boochorganickombucha.com/)

London, Ont.

Booch is one of the most recognizable kombucha brands in Ontario and can be found in over 1,000 retailers across the country including Metro, Sobey’s and Food Basics. Community and sustainability are both tenets of Booch’s operations. They are hyper-local and work directly with farmers for ingredients.

As part of their steady growth, Booch has embraced technology to further their business goals. During the pandemic, they pivoted to an eCommerce model to grow online sales.

* * *

[Open this photo in gallery: ![Image 4](https://www.theglobeandmail.com/resizer/v2/RSM46BKLLBATNEVZKHEBK6LV3A.jpg?auth=114af1384323a9e94e72fd6fb991ab5cc4ab0c68803c31df200b58c822a0bd63&width=600&quality=80)](https://www.theglobeandmail.com/resizer/v2/RSM46BKLLBATNEVZKHEBK6LV3A.jpg?auth=114af1384323a9e94e72fd6fb991ab5cc4ab0c68803c31df200b58c822a0bd63&width=600&height=400&quality=80&smart=true)

Supplied

### Matt Deir

Owner of [Croptracker, Inc.](https://www.croptracker.com/)

Kingston, Ont.

Croptracker is a software company that allows fruit producers to keep track of administrative and regulatory tasks within their orchard and is used by over 300 apple farms and 225 tender fruit growers in Ontario, and other farmers in over 40 countries.

Croptracker’s mission is to make global food production safer, more efficient, and more profitable through integrated software, hardware and consultin

*[... truncated, 12,091 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[#12: Culture et intelligence artificielle – Dominic Danis - Culture Inc](https://cultureincpodcast.com/index.php/2019/12/19/culture-et-intelligence-artificielle-dominic-danis/)**
  - Source: cultureincpodcast.com
  - *Dec 19, 2019 ... Email de Dominic: dominic.danis@moov.ai; Management 3.0 : https ... Culture Inc Podcast © 2020....*

- **[Publicis acquires Moov AI, Canada's Leading AI Company](https://www.newswire.ca/news-releases/publicis-acquires-moov-ai-canada-s-leading-ai-company-851677048.html)**
  - Source: newswire.ca
  - *Mar 27, 2025 ... Dominic Danis, President and Co-Founder, Moov AI, said: "Since day one at Moov AI, we have supported our clients in their transformat...*

- **[Publicis acquires Moov AI, Canada's Leading AI Company](https://finance.yahoo.com/news/publicis-acquires-moov-ai-canadas-142000570.html)**
  - Source: finance.yahoo.com
  - *Mar 27, 2025 ... Podcasts · Videos · RSS · Jobs · Help · World Cup · More news. New on Yahoo ... Dominic Danis, President and Co-Founder, Moov AI, sai...*

- **[Publicis fait l'acquisition de Moov AI, chef de file de l'IA au Canada ...](https://isarta.com/infos/publicis-fait-lacquisition-de-moov-ai-chef-de-file-de-lia-au-canada/)**
  - Source: isarta.com
  - *Mar 27, 2025 ... Podcasts · EMPLOIS · FORMATIONS · logo image Emplois / Formations. Publicis ... Devant : Dominic Danis (Cofondateur, Moov AI), Olivie...*

- **[TELUS celebrates top 15 finalists of its #StandWithOwners program ...](https://www.theglobeandmail.com/business/adv/article-telus-celebrates-top-15-finalists-of-its-standwithowners-program/)**
  - Source: theglobeandmail.com
  - *Nov 1, 2023 ... Olivier Blais, Dominic Danis and Guillaume Petitclerc Owners of Moov AI ... podcast hosting platforms that provide comprehensive data ...*

- **[Démocratiser l'IA et stimuler l'innovation chez les PME avec Dominic ...](https://www.youtube.com/watch?v=9uhI2FDmeMc)**
  - Source: youtube.com
  - *Sep 2, 2024 ... Dans l'épisode #92, Cléo reçoit Dominic Danis et Olivier Blais cofondateurs de Moov AI. Montréal a beau être une plaque tournante de l...*

- **[Moov AI Reviews: What Is It Like to Work At Moov AI? | Glassdoor](https://www.glassdoor.ca/Reviews/Moov-AI-Reviews-E2926794.htm)**
  - Source: glassdoor.ca
  - *Dominic Danis. 84% approve of CEO. Companies can't alter or remove reviews ... Glassdoor has 13 Moov AI reviews submitted anonymously by Moov AI emplo...*

- **[Samer Saab, President of Explorance is elected CEO of the year ...](https://www.aqt.ca/en/articles/samer-saab-president-of-explorance-is-elected-ceo-of-the-year-aqt-investissement-quebec-2023)**
  - Source: aqt.ca
  - *Feb 8, 2023 ... Following an interview with the jury made up of experienced members ... Dominic Danis, CEO of Moov Ai, Mohamed Guetat, CEO of Momentum...*

- **[What is Moov AI? Company Culture, Mission, Values | Glassdoor](https://www.glassdoor.ca/Overview/Working-at-Moov-AI-EI_IE2926794.11,18.htm)**
  - Source: glassdoor.ca
  - *Dominic Danis. 84% approve of CEO. Ratings by category. 4.7. Culture and values. 4.7. Equality, diversity and inclusion. 4.5. Work/Life balance. 4.3. ...*

- **[Working at Moov AI | Glassdoor](https://www.glassdoor.com/Overview/Working-at-Moov-AI-EI_IE2926794.11,18.htm)**
  - Source: glassdoor.com
  - *Dominic Danis. 84% approve of CEO. Companies can't alter or remove reviews ... Moov AI photos. Add photo. Moov AI photo of: Moov AI- dog freindly work...*

---

*Generated by Founder Scraper*
