# Morgane Neto

## Position actuelle

**Titre** : Founder
**Entreprise** : Puxxle
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Building Puxxle – the ultimate solution for stress-free, efficient product design! Are you tired of juggling multiple tools to gather insights for your next big feature? Frustrated with charts that lack context? Exhausted from redoing lost research? Say goodbye to wasted time piecing things together. Let Puxxle handle it all for you. Forget graphs, just ask.

## Résumé

🎯 Small product team?
No time to dig through every piece of feedback?
Using 5 tools but still no idea where things live?

I got you.

👋 I’m Morgane, founder of Puxxle and a product designer with over 10 years of experience working with fast-moving teams, tight deadlines, and way too many sticky notes. I’ve been in your shoes.

That’s why I built Puxxle, to help product teams:
- Turn scattered feedback into clear, shareable insights
- Make smarter decisions without needing a UX PhD
- Build products users love—and actually want to pay for

Puxxle centralizes your user data and delivers ready-to-use insights, so you can focus on building instead of digging.

No endless meetings. No messy spreadsheets.
Just clarity, served fresh.

🚀 The beta is live.
If you're building a product and want sharper UX with zero friction, let’s talk.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABBKONgB2gVH9lwJnLxL6vmqoWeJyXwhmwo/
**Connexions partagées** : 30


---

# Morgane Neto

## Position actuelle

**Entreprise** : Puxxle

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Morgane Neto

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400182997754277888 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFK01f9l16KOg/feedshare-shrink_800/B4EZrK7M2PIIAg-/0/1764341110695?e=1766620800&v=beta&t=ZW6Qq3hoOOKKBB5uzj-CHVHBhqeXv4MXu2k18xjun4M | Hier à l’Agile Tour Montréal, Elena et moi avons animé un atelier qui nous tient vraiment à cœur “Remettre l’UX au cœur du backlog à l’heure de la GenAI.”

Et… wow.
30 personnes ont utilisé Puxxle en même temps. 30 personnes qui ont parlé directement à leurs personas pour comprendre leurs vrais besoins.

On avait pré-uploadé des transcripts et très vite, tout le monde s’est mis à discuter avec leurs personas comme si ces utilisateurs étaient réellement.
Résultat : on les entendait justifier leurs solutions “le persona Anne préfère ci ou ça…”

Mon moment préféré: 
➡️ Le persona Anne disait vouloir un “suivi plus humain”.
Interprétation rapide de l’équipe: “elle veut parler à un humain”.
Mais en creusant avec Anne via le Persona Chat de Puxxle… Ils ont découvert que ce n’était pas une question de canal, mais d’approche et de copywriting.
Moins d’interprétation, plus de vérités.
Et surtout : des décisions produit beaucoup plus alignées avec les besoins utilisateurs.

Les retours ont été incroyables
• Atelier hyper équilibré entre théorie et pratique
• “Puxxle c’est Vraiiiment bien” (dit avec le sourire)
• Et surtout : “Ça a l’air facile de remettre l’UX au centre, pour de vrai.”

Un énorme merci à Elena, co-animatrice de feu! À Sophie et toute son équipe pour le soutien et l’énergie, à l’équipe Agile Tour Montréal (page officielle), impeccable du début à la fin et à tous les participants pour leur curiosité et leur enthousiasme. ✨ | 34 | 2 | 0 | 1w | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:17.522Z |  | 2025-11-28T14:45:15.416Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396577497108303872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGCRzW6GKDI8A/feedshare-shrink_800/B4EZqXnQkNKYBg-/0/1763480242987?e=1766620800&v=beta&t=GVEXNobSLX_q_pit_bhVQzyHvKxPubjb6LTVvxbf5_E | Si vous avez des amis c’est bien, mais des amis UX et PO c’est mieux 😁 
Découvrez comment en faire des amis pour la vie avec Sophie à l’Agile Tour la semaine prochaine! | 8 | 0 | 0 | 2w | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:17.523Z |  | 2025-11-18T15:58:17.075Z | https://www.linkedin.com/feed/update/urn:li:activity:7396572244442914816/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396243145514033152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE3YFIljc7SUQ/feedshare-shrink_800/B4EZqS78qCHgAg-/0/1763401780742?e=1766620800&v=beta&t=Hjc7iTrI-_lxKfP0VLzz0vTVOn2IYsdDnMKfi30Ayp0 | J'aurai pu passer un weekend chill, mais j'ai passé un weekend chill et avec le sourire :) 
On a beau hit the numbers, parfois il suffit juste d'un message comme ça pour savoir qu'on est sur le bon chemin. J'ai le bonheur de rencontrer des entrepreneurs incroyables sur ma route, avec le coeur à la bonne place. Alors désolée Romain j'affiche ton DM sur la place publique, mais un gros merci pour ton message du vendredi soir qui m'a fait chaud au coeur pour cette fin de semaine enneigée ! Tellement hâte de faire mon premier recrutement avec vous :) 
Spread the love guys ! | 28 | 2 | 0 | 2w | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:17.523Z |  | 2025-11-17T17:49:41.443Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394112593738612736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKOMev_v3dTA/feedshare-shrink_800/B4EZp0qN7XGcAk-/0/1762893817077?e=1766620800&v=beta&t=0A4fJsdP1dSg7flcIbgzRie_LdSOySS7W00HFYgzUnU | L'atelier AI Experience Map, c’était la semaine dernière !
Merci à mon coéquipier tristan et à nos participant·e·s pour cette belle première session, pleine de curiosité, d’échanges et de post-its (et de Lego aussi 🧱).

On a parlé de parcours utilisateurs assistés par l’IA avec cette idée d’utiliser un LLM pour assister la réflexion, aller plus loin dans la découverte d’opportunités et mieux préparer un projet IA : quelles données ? quels impacts sur les KPIs ? 

Tous sont repartis avec notre AI Guide for Designers, un carnet pratique pour comprendre les mots de l’IA et mieux dialoguer avec les équipes techniques.

📸 Et parce qu’on aime apprendre en s’amusant : voici les personas Lego que chacun a construits pendant l’atelier. Alors, lequel vous ressemble le plus ? 👇

Et si vous voulez aller plus loin dans les workflows et les outils AI, ça tombe bien : d’autres ateliers arrivent très bientôt!
📍Toutes les infos (et la liste d’attente) sur https://ai-design-hub.com/ | 22 | 0 | 1 | 3w | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:17.524Z |  | 2025-11-11T20:43:38.316Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7388968475836301314 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG-vre6h8uO8Q/feedshare-shrink_2048_1536/B4EZorjrDaHgAw-/0/1761667363801?e=1766620800&v=beta&t=g2unafHzuX_6dfC5ZW6vCMmbmZ8pDFmYv8NbuvfSTlw | **You can’t design for what you don’t understand but you don’t need to code to speak the language.**

Let’s leave the engineering to engineers.
But let’s also embrace what we do best as designers: asking the right questions, challenging assumptions, and making technology feel human.

You don’t need to know how to train a model but you should be able to say:
“We need a verification screen when the confidence score drops below 0.6, because from my user interviews, I know that’s when trust starts to break.”

That’s the kind of thinking the AI Guide for Designers helps you build.
It walks you through the key AI concepts so you can confidently join (and influence) technical conversations.

📘 It isn't public, I only share it with those who join our workshops and the next one is next week:
 🎨 AI Experience Map — Concevoir des parcours utilisateurs assistés par l’IA
 📅 En ligne | En français | Places limitées | https://luma.com/n78wwwz3

Can’t make it? Join the waitlist at ai-design-hub.com to get notified for the next one. | 15 | 2 | 0 | 1mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:17.524Z |  | 2025-10-28T16:02:45.035Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7379222088814845952 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE266HO9Tf4Ig/feedshare-shrink_800/B4EZmhDXgHGUAk-/0/1759343640191?e=1766620800&v=beta&t=keuS8EZDYGHrgMx424kkGp2WHE7ltuhTH9XpyI49QsQ | Yes… another post about ALL IN 🎉
But some things are worth repeating: grateful to have been selected as one of the Top 100 Canadian Startups. It was a beautiful event 💫  Thank you to everyone who showed up - product builders, founders, designers, fellow service providers… so many great conversations.

And because saying thank you is good, but being thankful is even better… here’s a little gift for product builders 👇

I’m keeping my free 15-min audit sessions open through October.
One quick chat, one concrete thing you can improve in your process to make a real impact on your users.

DM me to grab your spot ✨

📸 Photo credit: Mélanie Olmstead | 70 | 0 | 0 | 2mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.831Z |  | 2025-10-01T18:34:05.290Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7376208556443795456 | Text |  |  | ALL IN starts tomorrow! Excited to be part of the Top 100 Canadian startups 🎉

If you’re a founder or part of a product team, you know how messy user feedback can get:
calls, surveys, support tickets… and when it’s time to decide what to build next, it gets blurry.

That’s why during ALL IN, I’m offering a few free 15-min audits.
👉 We’ll look at how you currently handle feedback
👉 I’ll share one concrete way to turn it into actionable insights for your roadmap

No prep needed, just bring your experience.
I only have 5 spots available, so DM me if you’d like one.

And if we don’t get a chance to chat, come find me on Thursday afternoon at Puxxle booth ✨

#AllIn | 30 | 2 | 0 | 2mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.832Z |  | 2025-09-23T10:59:23.184Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7351619358604886016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHfoAbfqAlz2A/feedshare-shrink_800/B4EZgYvlrUGoAg-/0/1752761786190?e=1766620800&v=beta&t=WYStCsPqbR1iMWk2soii7Fr4qSIedZPUpxIYrTmVrYM | Bringing UX to the AI party like it’s 1999 — but with better onboarding 😁 
See you there!

*bonus points if you get the reference | 64 | 4 | 2 | 4mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.832Z |  | 2025-07-17T14:30:41.574Z | https://www.linkedin.com/feed/update/urn:li:activity:7351615774609793029/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7326214359599259651 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE7RYBJ4sIlbg/feedshare-shrink_800/B4EZat6OvPGQAg-/0/1746674445646?e=1766620800&v=beta&t=0w6QMB33LveUYkARUKUsQ9mmTir3R2hF_vc5kLhO0VI | Your interface designs itself.
Your research runs while you sleep.
Your org is on AI-autopilot.
And robots are being funny**

Next week, we’re unpacking what’s real, what’s not, and what’s already happening inside real product teams.
60+ curious minds are already in: designers, researchers, makers... you coming?
🗓️ May 15, 12PM EST / 6PM CET
 🔗 https://lu.ma/u98cfxwb | 16 | 1 | 1 | 6mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.834Z |  | 2025-05-08T12:00:17.809Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7323341811249209344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkb4KOFLsisg/feedshare-shrink_800/B4EZaG8kfZHYAg-/0/1746020747741?e=1766620800&v=beta&t=r0Jv-kM1Z40T1JR4a2ryFWQUgbBs8rFtl6njBSTnekE | Good morning!
Have you saved your spot for our AI + UX roundtable yet?

🗓️ May 15 · 12PM EST · 6PM CET · Online & Free
 🔗 https://lu.ma/u98cfxwb

We'll be talking prompts, research, and the real ways AI is reshaping design work. | 23 | 1 | 4 | 7mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.835Z |  | 2025-04-30T13:45:48.913Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7322618716490248192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFK079Lz09F5g/feedshare-shrink_800/B4EZZoFYUcHoA0-/0/1745502964151?e=1766620800&v=beta&t=DDnfhwFx82wRuQcuWd1ubWjzGxpF-ZC4THu2eJQEAz0 | J’adore entendre comment les designers parlent de Puxxle avec leur propre regard sur les défis qu’on veut résoudre. 😍

Et je dois dire que ça me rend fière de voir Pierre raconter son design process !
Merci pour ton super travail sur ce MVP qui veut rendre la vie des UX researchers, designers et PM plus simple et plus claire.
Et ce n’est que le début… la suite arrive très bientôt ! | 16 | 2 | 0 | 7mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.835Z |  | 2025-04-28T13:52:29.688Z | https://www.linkedin.com/feed/update/urn:li:activity:7321170070578106368/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7321217525218750464 | Article |  |  | You know those conversations that make you rethink how you work?
I had 3 of them recently, all about AI in UX design. So I decided to bring those amazing people together… and invite you to our online roundtable :)

For one hour on May 15, we’ll talk about:
 🧠 Startups building UI with prompts (and what that changes for designers) with Gabriel Lespérance
 📋 Designers doing continuous research with ChatGPT with Alexandre Vilto
 🏛️ How orgs (and humans) are navigating this shift with Sophie Henry

It’s free, it’s online, and it’s participative, so we'll be very happy to have you!
🔗 Save your spot: [https://lu.ma/u98cfxwb] | 39 | 7 | 3 | 7mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.836Z |  | 2025-04-24T17:04:39.656Z | https://lu.ma/u98cfxwb |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7316122458460160001 | Text |  |  | Oof… I got three messages this week asking if I’m still working on Puxxle.
(Spoiler alert: yes!)
But I updated my profile with a new role as a UX consultant for the Scale AI team at CEIM, and bam… the algorithm (and maybe some of you) thought I’d changed direction.
To be fair, I haven’t posted in a month.
And we all know: no LinkedIn post = no product, no traction, no startup. Voilà. 

Nah, the truth is... lately, it’s been less talking, more doing. 
We received an amazing grant from Ministère de l’Économie, de l’Innovation et de l’Énergie du Québec (MEIE), which is helping us move fast with building the foundational features of Puxxle, the ones that will shape everything to come. La base.

And no, we’re not building in a closed garage:
We’ve launched our beta program!
Big thanks to everyone already along for the ride 🫶
If you’re in UX or Product, there’s a good chance you’ll hear from me soon (if you haven’t already 😇).
We’re looking for feedback. Looooots of it.
And don’t worry, Puxxle is here to help us analyze it ;)

Will I see you next week at World Summit AI?
💃 | 71 | 0 | 0 | 7mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.836Z |  | 2025-04-10T15:38:41.079Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7302803827076857857 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHl-cYlU6sEkA/feedshare-shrink_800/B4EZVjFYK_H0Ag-/0/1741124110027?e=1766620800&v=beta&t=280ZkZUYRgIq5KMjtjujffWIdnaQptYqNDRlNjPpJ0o | I've been following The AI Collective and their initiative to gather inputs from entrepreneurs, researchers, and AI professionals to help shape the AI Action Plan in the USA.
I love this kind of initiative, it’s bridging the gap between policy, ethics, and real-world AI applications. 

So where is the Canadian equivalent? 🇨🇦
AI is transforming our industries so fast, and while regulation is crucial for ethical and responsible development, entrepreneurs should have a seat at the table too. We're the ones building, experimenting, and pushing the boundaries. Our insights matter.
If there's already a similar initiative in Canada, I'd love to hear about it. And if not… well, maybe it’s time to get things moving.
What do you think? Should we be more proactive in shaping AI policy? Who's leading these discussions in Canada?

#AI #GenAI #ArtificialIntelligence #Entrepreneurship #Ethics #Canada | 13 | 0 | 0 | 9mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.837Z |  | 2025-03-04T21:35:11.909Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7299925869324611584 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHBpO80_Yl-Ig/feedshare-shrink_800/B4DZU5_xbMHIAk-/0/1740434774170?e=1766620800&v=beta&t=Ncc5kajhaEnTykd4B-buiIRyOfJq77iICdSMvODTOOo | Hâte d’être à jeudi pour partager un bon moment avec la communauté Lorem Ipsum Conf 🤗 | 10 | 0 | 0 | 9mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.838Z |  | 2025-02-24T22:59:13.311Z | https://www.linkedin.com/feed/update/urn:li:activity:7299912538530471936/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7297297181449814016 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHGLDQ0jVCBDg/feedshare-shrink_800/B4DZUUJ36vG8Ag-/0/1739799887996?e=1766620800&v=beta&t=6pEZ0OxbKY_Hln-q01CtOUBIC_JLy6u1DKLMjRNqVhA | On se retrouve la semaine prochaine ! | 14 | 2 | 0 | 9mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.838Z |  | 2025-02-17T16:53:45.283Z | https://www.linkedin.com/feed/update/urn:li:activity:7297249633246887936/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7295821956019335168 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHznBufSM3eEw/feedshare-shrink_800/B4DZT2N_4dG4Ak-/0/1739297652960?e=1766620800&v=beta&t=5O9Ic9ZHYXuPNNCIU26SeZNxR4PrCrbr58YY0KyXg8w | Quand tristan fraud m'a dit qu'il voulait organiser un évènement de rentrée pour Lorem Ipsum Conf, bien évidemment j'ai répondu "attends jvais t'aider pour l'apéro". On vous organise donc un petit apéro de rentrée (oui oui, nous on fait une rentrée en février 😎) avec l'équipe Lorem Ipsum Conf :) 
Évènement ouvert à toute la communauté produit, pas besoin de savoir faire de l'auto layout pour venir ;) 
On vous en dit plus très vite! | 13 | 0 | 1 | 9mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.839Z |  | 2025-02-13T15:11:44.132Z | https://www.linkedin.com/feed/update/urn:li:activity:7295143107442991104/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7287557903815700480 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9JW77qYemSQ/feedshare-shrink_1280/B4EZSKbS7sHgAk-/0/1737489199619?e=1766620800&v=beta&t=p0pQpleg8OGipFIj6akg_QJ8LDMQKRHKYYcPxdH55DA | AI is impacting UX. It started a couple of years ago and I was completely ignorant at the time. Today I'm sharing with you my personal roadmap to navigate this change:

LEARN: Knowledge is the antidote to uncertainty. Understand AI’s potential and its limitations. For instance, you’ll learn quickly enough, if not already, that the democratized ability to generate content doesn’t guarantee the ability to create great content.

ENGAGE: Connect with those driving change. Talk to peers, innovators, and even people outside your field. AI isn’t just happening to us, it can happen for us if we’re part of the conversation.

LEAD: Be the change. Advocate for how AI should be used to benefit UX, users, and society in general. Whether you’re in a large company, a startup, or elsewhere, your voice matters.

ADAPT: You are not your job. If roles shift and you find yourself at a crossroads, remember that you’re more than your title. You’re a creator, an innovator, and a problem solver. Trust in your ability to reinvent yourself. | 39 | 4 | 0 | 10mo | Post | Morgane Neto | https://www.linkedin.com/in/morganeneto | https://linkedin.com/in/morganeneto | 2025-12-08T04:49:20.839Z |  | 2025-01-21T19:53:20.548Z |  |  | 

---



---

# Morgane Neto
*Puxxle*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Podcasts](https://www.morgo.co/podcasts)
*2025-04-28*
- Category: podcast

### [Morgane Neto - Puxxle | LinkedIn](https://ca.linkedin.com/in/morganeneto)
*2025-01-01*
- Category: article

### [Morgane Peng - Interviews](https://www.morganepeng.com/interviews)
*2024-06-27*
- Category: article

### [Blog](https://www.morgo.co/blog)
*2023-01-01*
- Category: blog

### [The Morgo Podcast](https://morgo.libsyn.com/)
*2024-06-10*
- Category: article

---

## 📖 Full Content (Scraped)

*9 articles scraped, 11,635 words total*

### Podcasts
*1,666 words* | Source: **EXA** | [Link](https://www.morgo.co/podcasts)

[ Bridgit Hawkins, Humble Bee Bio ------------------------------- November 25, 2025 The Humble Bee Bio journey began with rare bees, whose genomes it sequenced to uncover novel molecules, including one with a rare and potent property — elastin stimulation. This molecule will soon be available as a hero ingredient for formulation of anti-ageing products. Bridgit is not the founder, she joined to build the business. She says the skills of leading a company are transferable but you need to learn about a new sector and build a network for it.](https://www.morgo.co/podcasts/bridgit-hawkins-humble-bee-bio)

[ Will Hewitt, Heartlab --------------------- November 3, 2025 Heartlab provides a cloud-based cardiology imaging system that helps cardiologists review and report on scans of the heart. Will talks about how they started using AI to improve the reading of ECGs but discovered that the real issue wasn’t better diagnosis, it was access to the images at any time on any platform. Heartlab has customers in Australia, NZ, the US and Canada. Will enjoys learning what issues the customers have and building product to solve them.](https://www.morgo.co/podcasts/will-hewitt-heartlab)

[ Oscar Ellison, Levno -------------------- October 22, 2025 Levno is an intelligent dairy farm monitoring business – remotely monitoring milk, water, fuel, feed silos and providing information to the farmers and suppliers. It is expanding from a strong base in New Zealand into the UK, Ireland and Australia. Oscar talks about how they’ve needed to adapt their offshore strategy to establish credibility in new markets and keeping the culture in the company as it grows. And the importance of learning from your peers.](https://www.morgo.co/podcasts/oscar-ellison-levno)

[ Dean Armstrong, Virscient ------------------------- September 22, 2025 Virscient designs wireless chips for semiconductor companies and integrates wireless technologies into products for other companies. Dean started the company consulting to a semiconductor company he had worked for and gradually added more engineers. Virscient now employs over 50 people. Dean talks about what he’s learned along the way, especially in building the commercial side of the business where he’s been greatly helped by his executive Chair, Mark Ingle.](https://www.morgo.co/podcasts/dean-armstrong-virscient)

[ Peter Boyle, Exaba ------------------ September 1, 2025 Exaba is building a secure, sovereign & highly scalable data protection platform for service providers, data centres, & large enterprises. Peter and Stuart Inglis (CTO) saw the opportunity to give customers their own trusted local alternative to the public cloud. By merging with digital solutions company LuminateOne, Exaba expanded to deliver a complete wrap-around service. Backed from the outset by Guy Haddleton as an investor and advisor, the team is ready to scale globally.](https://www.morgo.co/podcasts/peter-boyle-exaba)

[ Matt Hayter, Projectworks ------------------------- August 12, 2025 Matt is Co-founder, President, and Chief Product Officer of Projectworks, a platform for consulting firms to better manage projects, people and financials. Their niche is boutique management consultants, software services, engineers, and architects. Matt talks about building a product users love and the journey of scaling it to now being used by over 500 consultancies globally and the importance of the team on the journey with you.](https://www.morgo.co/podcasts/matt-hayter-projectworks)

[ Stuart Wilson, Modica Group --------------------------- July 22, 2025 Modica is a CPaaS (Communications Platform as a Service) delivering messaging supported by enterprise analytics, security & world-class support. You choose the channel - voice, video, messaging, chatbots or WhatsApp - and Modica makes it work. Stuart talks about building from a scrappy start-up, through acquisitions, winning in Australia, to a $50M turnover company with operations around the world.](https://www.morgo.co/podcasts/stuart-wilson-modica-group)

[ Sonya Williams, Brooke & Leighton Roberts, Sharesies ---------------------------------------------------- June 30, 2025 It’s rare to have 3 co-founders still running the company as co-CEOs 8 years after it started and great to hear how they interact! Sharesies mission is to provide financial empowerment to everyone. Sonya, Leighton & Brooke talk about growing Sharesies to 800,000 users & $9 bn under management. 200 people work in the company, which now helps people manage wealth, connects companies to shareholders, and has technology it will productise.](https://www.morgo.co/podcasts/sonya-williams-brooke-leighton-roberts-sharesies)

[ Desiree de Spong, Medella Health -------------------------------- June 9, 2025 Desiree shares how she developed Flowpresso, a Class II medical device designed to reset the body through lymphatic therapy. Using compression, heat, and pressure, it helps clear cellular waste, improve sleep, reduce str

*[... truncated, 6,826 more characters]*

---

### Morgane Neto - Puxxle | LinkedIn
*5,226 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/morganeneto)

Morgane Neto - Puxxle | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/morganeneto#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-delaware-oh?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fmorganeneto&fromSignIn=true&trk=public_profile_nav-header-signin)[Join for free](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=morganeneto&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fmorganeneto&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fmorganeneto&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/D4E16AQHGHsFAB8bbJQ/profile-displaybackgroundimage-shrink_200_800/B4EZbSROPpHAAU-/0/1747284452713?e=2147483647&v=beta&t=gePaSTt5MUvCFWDaIR4VEu_j9XmtX85JBYq7vzhEmZw)

![Image 3: Morgane Neto](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)

Morgane Neto
============

![Image 4](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)
Sign in to view Morgane’s full profile
--------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=morganeneto&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=morganeneto&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

### Montreal, Quebec, Canada Contact Info 

![Image 5](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)
Sign in to view Morgane’s full profile
--------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=morganeneto&trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=morganeneto&trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement]

*[... truncated, 50,810 more characters]*

---

### Morgane Peng - Interviews
*543 words* | Source: **EXA** | [Link](https://www.morganepeng.com/interviews)

Morgane Peng – Interviews

===============
Morgane Peng

===============

[MORGANE PENG](https://www.morganepeng.com/)

[MORGANE](https://www.morganepeng.com/)

[![Image 5: Morgane Peng avatar](https://www.morganepeng.com/img/morgane_peng_favicon.svg)](https://www.morganepeng.com/)[Writing](https://www.morganepeng.com/writing)[Speaking](https://www.morganepeng.com/speaking)[Interviews](https://www.morganepeng.com/interviews)[Courses](https://www.morganepeng.com/courses)[About](https://www.morganepeng.com/about)

I’ve been very fortunate to chat and exchange ideas with amazing people across the design industry. I believe this is how we grow stronger as a community.

Quick jump to: [Podcasts](https://www.morganepeng.com/interviews#podcasts)[Podcasts in French](https://www.morganepeng.com/interviews#podcasts-fr)[Articles](https://www.morganepeng.com/interviews#articles)

Podcasts
========

[![Image 6: The DS Pod](https://www.morganepeng.com/img/podcast_thedspodcast.png)](https://www.designsystemspodcast.com/episodes/episode/78c0f54a/65-morgane-peng-managing-director-and-head-of-design-at-societe-generale-corporate-and-investment-banking-is-a-design-system-a-business-asset-or-a-technical-asset)

[Are design-systems business assets or technical assets — The DS Pod](https://www.designsystemspodcast.com/episodes/episode/78c0f54a/65-morgane-peng-managing-director-and-head-of-design-at-societe-generale-corporate-and-investment-banking-is-a-design-system-a-business-asset-or-a-technical-asset)

Chris invited me back to discuss the long-term game of design systems, pitching beyond the technical aspects and articulating business values with stakeholders. We also made silly jokes on design system ownership. Mar 2023

[![Image 7: 97 UX Things](https://www.morganepeng.com/img/podcast_97things.webp)](https://open.spotify.com/episode/2VG5fPkk5l4C5exgIrj6JR)

[Not all interfaces need to be simplified](https://open.spotify.com/episode/2VG5fPkk5l4C5exgIrj6JR)

Dan interviews authors of the book "97 Things Every UX Practitioner Should Know" discuss their chapters, career trajectories, and give advice for anyone working in user experience. This is my episode. Jul 2021

[![Image 8: Design MBA Podcast](https://www.morganepeng.com/img/podcast_design_mba.jpg)](https://designmba.show/episodes/morgane-peng)

[Design leaders need side hustles — Design MBA](https://designmba.show/episodes/morgane-peng)

It's often taboo to talk about your side hustle or side project at work. Jayneil invited me to discuss why design leaders need to embrace it within their teams, and how my own side project - an indie game - ended up making Reddit’s front page during our Kickstarter campaign. Dec 2020

[![Image 9: The DS Pod](https://www.morganepeng.com/img/podcast_thedspodcast.png)](https://www.designsystemspodcast.com/episodes/episode/47e5a769/19-morgane-peng-from-societe-generale-the-right-level-of-complexity-for-the-right-people)

[The right level of complexity for the right people — The DS Pod](https://www.designsystemspodcast.com/episodes/episode/47e5a769/19-morgane-peng-from-societe-generale-the-right-level-of-complexity-for-the-right-people)

Chris and I discuss threading design into the fabric of how business works, capturing complexity needs within a design system, moving away from traditional design tools and the lessons from game development. Sep 2020

Podcasts in French
==================

[![Image 10: The DS Pod](https://www.morganepeng.com/img/podcast_moncarnet.jpg)](https://moncarnet.blog/2024/06/27/design-leadership-en-eaux-troubles/)

[Design leadership in challenging times — Mon Carnet](https://moncarnet.blog/2024/06/27/design-leadership-en-eaux-troubles/)

Jean-Francois brought me back on the podcast to discuss design leadership in challenging times, and to get a preview of my latest talk on this topic. Jun 2024

[![Image 11: The DS Pod](https://www.morganepeng.com/img/podcast_moncarnet.jpg)](https://moncarnet.blog/2023/03/30/mon-carnet-du-31-mars-2023/)

[Scaling in big organisations — Mon Carnet](https://moncarnet.blog/2023/03/30/mon-carnet-du-31-mars-2023/)

I went back on this French Canadian podcast to discuss how design can scale in a big organisation without necessarily hiring armies of designers. Mar 2023

[![Image 12: The DS Pod](https://www.morganepeng.com/img/podcast_moncarnet.jpg)](https://moncarnet.blog/2022/02/11/mon-carnet-du-11-fevrier-2022/)

[Expert applications — Mon Carnet](https://moncarnet.blog/2022/02/11/mon-carnet-du-11-fevrier-2022/)

Mon Carnet is Quebec's number one podcast on digital technologies and I was invited by Jean-Francois to share what it means to design for expert users. Feb 2022

[![Image 13: Design Journeys](https://www.morganepeng.com/img/podcast_designjourneys.png)](https://designjourneys.fr/morgane-peng-societe-generale-sgcib/)

[The place of design in a big org — Design Journeys](https://designjourneys.fr/morgane-peng-societe-generale-sgcib/)

Can design find its way in a big org? And how diff

*[... truncated, 1,588 more characters]*

---

### Blog
*687 words* | Source: **EXA** | [Link](https://www.morgo.co/blog)

[ MORGO 2025 Bay of Islands: Building your Company in a Changing World -------------------------------------------------------------------- MORGO 2025 lived up to its promise of literally 'out of this world' learnings, conversations and brain-stretching recharge.](https://www.morgo.co/blog/morgo-2025-bay-of-islands---building-your-company-in-a-changing-world)

[ Shared learnings from building Portainer ---------------------------------------- Morgo is proud to be part of Neil Cresswell's journey as a CEO. In the following article Neil shares the 'warts and all' learnings of his journey with Portainer to date.](https://www.morgo.co/blog/shared-learnings-from-building-portainer)

[ 10 Reasons CEOs Need Morgo’s CEO Leadership Program --------------------------------------------------- By Alex Black, CEO of AD Instruments. As the CEO of a New Zealand tech company, we face daily challenges that test our resilience, leadership, and decision-making.](https://www.morgo.co/blog/10-reasons-ceos-need-morgos-ceo-leadership-program)

[ MORGO 2024 Queenstown - what journey are you on? ------------------------------------------------ You have to be smart, relentless and focussed to build a new tech company out into the world. When a number of these incredible entrepreneurs get together, magic happens - that’s MORGO.](https://www.morgo.co/blog/morgo-2024-queenstown---what-journey-are-you-on)

[ MORGO Workshop: The Hunter or the Prey? --------------------------------------- The Hunter or the Prey workshop is a chance to role-play the sale and acquisition of a company.](https://www.morgo.co/blog/morgo-workshop-the-hunter-or-the-prey)

[ What Journey are you on? Cautionary tales about when a board might be able to help ---------------------------------------------------------------------------------- If you know where you’re going, you’ll have a much better chance of getting a lot of things right! Let’s start with the board.](https://www.morgo.co/blog/cautionary-tales-about-when-a-board-might-be-able-to-help)

[ MORGO 2023 – AI with that? -------------------------- Everyone is talking about AI these days and MORGO was no exception. MORGO is a two-day get together for the leaders of tech companies going global: two days away from the business to share experiences with other CEOs, make new friends, and above all get reinvigorated with new energy for the challenges ahead.](https://www.morgo.co/blog/morgo-2023-ai-with-that)

[ MORGO 2022 – 20 years of MORGO! ------------------------------- Wow, 20 years of MORGO! How did that happen? From thinking that it would be good to get together people building tech companies from New Zealand into the world – which it was – to fuller and fuller programmes over the years to create this annual re-charge for them!](https://www.morgo.co/blog/morgo-2022-20-years-of-morgo)

[ MORGO Bay of Islands: Welcome to the Future ------------------------------------------- Where would you see Manta5 bikes on the water and a Zerojet electric jet by the wharf? At MORGO, of course, where New Zealand’s leading tech entrepreneurs come together to share experiences and get re-energised for the journey out into the world.](https://www.morgo.co/blog/morgo-bay-of-islands-welcome-to-the-future)

[ Pitching tips to win a free place at MORGO ------------------------------------------ In my time in venture capital I’ve heard a lot of pitches; the good, the bad and, mostly, the frankly-why-bother. A lot of different approaches can work. Here are my tips for those of you keen to attend Morgo but who can’t afford it at this stage in your business journey.](https://www.morgo.co/blog/pitching-tips-to-win-a-free-place-at-morgo)

[ Why listing is good for you --------------------------- Listing is the highest value future you can have, said Neil Craig of CraigsIP to a room full of highly engaged CEOs and CFOs of fast growing tech companies at a recent Morgo workshop.](https://www.morgo.co/blog/why-listing-is-good-for-you)

[ MORGO Queenstown — Resilience, Leadership, Opportunity ------------------------------------------------------ At the MORGO retreat we bring together these high growth business leaders to give them an annual re-charge – send them away with new energy to take on the challenges of building their businesses out into the world. At MORGO 2021 our theme was Resilience, Leadership, Opportunity](https://www.morgo.co/blog/morgo-queenstown-resilience-leadership-opportunity)

[ Building the MORGO programme — so many options! ----------------------------------------------- MORGO Queenstown is just over two months away. I’m deep in designing another amazing programme for you and I thought I’d bring you behind the scenes to share what goes into building a programme at MORGO.](https://www.morgo.co/blog/building-the-morgo-programme-so-many-options)

[ Leadership, resilience, opportunity? ------------------------------------ A lot is being written about how Covid-19 and the lock downs will bring about changes 

*[... truncated, 602 more characters]*

---

### The Morgo Podcast
*737 words* | Source: **EXA** | [Link](https://morgo.libsyn.com/)

The Morgo Podcast

===============

Toggle navigation[](https://morgo.libsyn.com/ "Home Page")

*    
*   [About](https://morgo.libsyn.com/)
*   [Episodes](https://morgo.libsyn.com/#)
    *   [All Episodes](https://morgo.libsyn.com/)
    *   [Archives](https://morgo.libsyn.com/#)
        *   [2025](https://morgo.libsyn.com/2025)
            *   [November](https://morgo.libsyn.com/2025/11)
            *   [October](https://morgo.libsyn.com/2025/10)
            *   [September](https://morgo.libsyn.com/2025/09)
            *   [August](https://morgo.libsyn.com/2025/08)
            *   [July](https://morgo.libsyn.com/2025/07)
            *   [June](https://morgo.libsyn.com/2025/06)
            *   [May](https://morgo.libsyn.com/2025/05)
            *   [April](https://morgo.libsyn.com/2025/04)
            *   [March](https://morgo.libsyn.com/2025/03)
            *   [February](https://morgo.libsyn.com/2025/02)
            *   [January](https://morgo.libsyn.com/2025/01)

        *   [2024](https://morgo.libsyn.com/2024)
            *   [December](https://morgo.libsyn.com/2024/12)
            *   [November](https://morgo.libsyn.com/2024/11)
            *   [October](https://morgo.libsyn.com/2024/10)
            *   [September](https://morgo.libsyn.com/2024/09)
            *   [August](https://morgo.libsyn.com/2024/08)
            *   [July](https://morgo.libsyn.com/2024/07)
            *   [June](https://morgo.libsyn.com/2024/06)
            *   [May](https://morgo.libsyn.com/2024/05)
            *   [April](https://morgo.libsyn.com/2024/04)
            *   [March](https://morgo.libsyn.com/2024/03)
            *   [February](https://morgo.libsyn.com/2024/02)
            *   [January](https://morgo.libsyn.com/2024/01)

        *   [2023](https://morgo.libsyn.com/2023)
            *   [December](https://morgo.libsyn.com/2023/12)
            *   [November](https://morgo.libsyn.com/2023/11)
            *   [October](https://morgo.libsyn.com/2023/10)
            *   [September](https://morgo.libsyn.com/2023/09)
            *   [August](https://morgo.libsyn.com/2023/08)
            *   [July](https://morgo.libsyn.com/2023/07)
            *   [June](https://morgo.libsyn.com/2023/06)
            *   [May](https://morgo.libsyn.com/2023/05)
            *   [April](https://morgo.libsyn.com/2023/04)
            *   [March](https://morgo.libsyn.com/2023/03)
            *   [February](https://morgo.libsyn.com/2023/02)
            *   [January](https://morgo.libsyn.com/2023/01)

        *   [2022](https://morgo.libsyn.com/2022)
            *   [December](https://morgo.libsyn.com/2022/12)
            *   [November](https://morgo.libsyn.com/2022/11)
            *   [October](https://morgo.libsyn.com/2022/10)
            *   [September](https://morgo.libsyn.com/2022/09)
            *   [August](https://morgo.libsyn.com/2022/08)
            *   [July](https://morgo.libsyn.com/2022/07)
            *   [June](https://morgo.libsyn.com/2022/06)
            *   [May](https://morgo.libsyn.com/2022/05)
            *   [April](https://morgo.libsyn.com/2022/04)
            *   [March](https://morgo.libsyn.com/2022/03)
            *   [February](https://morgo.libsyn.com/2022/02)
            *   [January](https://morgo.libsyn.com/2022/01)

        *   [2021](https://morgo.libsyn.com/2021)
            *   [December](https://morgo.libsyn.com/2021/12)
            *   [November](https://morgo.libsyn.com/2021/11)
            *   [October](https://morgo.libsyn.com/2021/10)
            *   [September](https://morgo.libsyn.com/2021/09)
            *   [August](https://morgo.libsyn.com/2021/08)
            *   [July](https://morgo.libsyn.com/2021/07)
            *   [June](https://morgo.libsyn.com/2021/06)
            *   [May](https://morgo.libsyn.com/2021/05)
            *   [April](https://morgo.libsyn.com/2021/04)
            *   [March](https://morgo.libsyn.com/2021/03)
            *   [February](https://morgo.libsyn.com/2021/02)
            *   [January](https://morgo.libsyn.com/2021/01)

        *   [2020](https://morgo.libsyn.com/2020)
            *   [December](https://morgo.libsyn.com/2020/12)
            *   [November](https://morgo.libsyn.com/2020/11)
            *   [October](https://morgo.libsyn.com/2020/10)
            *   [September](https://morgo.libsyn.com/2020/09)
            *   [August](https://morgo.libsyn.com/2020/08)
            *   [July](https://morgo.libsyn.com/2020/07)
            *   [June](https://morgo.libsyn.com/2020/06)
            *   [May](https://morgo.libsyn.com/2020/05)
            *   [April](https://morgo.libsyn.com/2020/04)
            *   [March](https://morgo.libsyn.com/2020/03)
            *   [February](https://morgo.libsyn.com/2020/02)

        *   [2019](https://morgo.libsyn.com/2019)
            *   [December](https://morgo.libsyn.com/2019/12)
            *   [November](https://morgo.libsyn.com/2019/11)
            *   [October](https://morgo.libsyn.com/2019/10)
            *   [September](https://morgo.

*[... truncated, 5,240 more characters]*

---

### Puxxle
*945 words* | Source: **GOOGLE** | [Link](https://www.pierremoret.com/puxxle)

Aider les UX researchers et designers à centraliser leurs données et générer des insights plus rapidement grâce à l’IA.

Compétences

Stratégie produit

Idéation

Prototypage rapide

Tests utilisateurs

Timeline

septembre → octobre 2024

Team Lead

Morgane Neto

Contexte
--------

Le constat de Puxxle est simple : les UX researchers et designers sont noyés sous une masse d’informations éparpillées dans une multitude d’outils. Cela engendre une fatigue mentale importante, une perte de temps dans la préparation et l’analyse des recherches, et au final, des insights souvent peu exploitables.

![Image 1](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67fe5ac9ef8f791c34d19704_Context.avif)

J'ai rejoint l'équipe dès le démarrage du développement du MVP pour réfléchir à une solution permettant de simplifier ce processus.

Notre ambition : aider les équipes produit à produire des insights clairs, structurés et actionnables — plus rapidement.

Comprendre les utilisateurs
---------------------------

Nous avons mené plusieurs interviews qualitatives et une analyse approfondie de la concurrence pour comprendre les enjeux et frustrations des utilisateurs cibles.

![Image 2](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67fe5ea0b894cb14541a85d2_postit%20persona.png)

Trois profils clés sont ressortis de cette phase exploratoire

![Image 3](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67fe5dbb18106bf0bb72cf34_alice.png)

**Alice, UX researcher senior,**a besoin de centraliser des données éparses, d’analyser plus vite et de partager des insights clairs à son équipe.

![Image 4](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67fe5dbb7b19c04292df61f7_thomas.png)

**Thomas, designer UX/UI,**cherche à accéder rapidement à des données fiables pour appuyer ses décisions, tout en jonglant avec de nombreuses responsabilités.

![Image 5](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67fe5dbb80332010d442cfc4_emlily.png)

**Emily, product manager**, veut prioriser les bonnes fonctionnalités mais peine à naviguer dans l’abondance de retours utilisateurs non structurés.

Ces personas ont été essentiels pour cadrer notre réflexion. Ils nous ont permis d’identifier les véritables pain points à adresser : surcharge cognitive, manque de centralisation, difficulté à générer des insights de qualité à partir de données brutes.

Personas complets

[![Image 6](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/68076de5274c37da81b51d5d_Persona%201.png)![Image 7](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/68076de562181f09a0b89a59_Persona%202.png)![Image 8](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/68076de57d403eb386bb424c_Persona%203.png)](https://www.pierremoret.com/puxxle#)

Recherche et définition du problème
-----------------------------------

En parallèle de la définition des personas, nous avons réalisé des démonstrations de l’outil en cours de conception et des tests de premières maquettes.

Ces retours nous ont permis d’affiner nos hypothèses et de faire émerger plusieurs patterns récurrents :

![Image 9](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/6784e8776ba52d323d7ed6e4_caution-icon.svg)

**Processus de recherche est souvent décousu**Les données sont éparpillées dans Notion, Figma, Google Drive, ou d'autres outils peu adaptés à l’analyse.

![Image 10](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/6784e8776ba52d323d7ed6e4_caution-icon.svg)

**Accès contraignant

‍****‍**L’accès aux insights est lent et demande beaucoup de travail manuel.

![Image 11](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/6784e8776ba52d323d7ed6e4_caution-icon.svg)

**Manque de temps et de moyens**

Les designers comme les PM souhaitent des résultats exploitables, mais ont peu de temps pour analyser ou croiser les données.

Idéation et Exploration
-----------------------

Pour répondre à ces enjeux, nous avons imaginé un parcours utilisateur fluide, depuis la création d’un projet jusqu’à la génération et la validation des insights

![Image 12](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67b36c5c03f9c3d795988aab_dashboard-3.svg)

**Benchmark des outils existants

‍**Analyse des solutions comme Notion, Dovetail ou Miro afin d’identifier leurs points forts (partage d’information, accessibilité) et leurs limites (peu d’automatisation, données non connectées aux insights, outils éparpillés).

![Image 13](https://cdn.prod.website-files.com/61e9a0cb4c4b0a867d3cc5d1/67b36c5c6e3c2760444ef40c_tree-2.svg)

**Définition du parcours utilisateur

‍****‍**Construction d’un parcours clair guidant l’utilisateur depuis la création du projet jusqu’à l’exploitation des insights :

*   Définir un projet et ses objectifs
*   Ajouter des données (notes, fichiers, enregistrements)
*   Générer automatiquement un plan de recherche
*   Analyser les données, produire des insights
*   Valider et publier les résultats
*

*[... truncated, 4,059 more characters]*

---

### ADPList: Get mentored by Morgane NETO on ADPList
*260 words* | Source: **GOOGLE** | [Link](https://adplist.org/mentors/morgane-neto)

![Image 1](https://adplist.org/photos/cover-photo.png)

![Image 2](https://adplist-bucket.s3.amazonaws.com/media/profile_photos/77ce78d498ea487884d4c207bf00c184vWM94.webp)

Founder at  Puxxle

### Community statistics

1,140 mins

Total mentoring time

38

Sessions completed

100%

Average attendance

114

Karma Points

* * *

### Top areas of impact

Highly discussed topics during sessions

General mentorship

Resume and portfolio review

Design career path

+4 others

Hi, I'm Morgane, Founder of Puxxle, a tool for UX designers to analyze user data in a second. 

 Former product designer with 10+ years of experience in the B2B industry, I'm specialized in simplifying the complex and making sure my design will have a positive impact on the users and the business.

[Show more](https://adplist.org/)

Profile insights

How do I get these?

Perfect Presence

Mentor is prompt and highly responsive.

Background

Expertise

Design

Product Research

+1

Disciplines

UX Design

Fluent in

English

French

Experience 3

💻

CEO & Head of product

Puxxle

Feb 2024 - Present

Founder of Puxxle, a solution for designers to analyze user data in a second and generate design insights. No more complex graphs to read, just talk to your personas...See more

Education 1

![Image 3: education logo](https://adplist.org/illustrations/education.svg)

Master in UX design

Gobelins School

2016 - 2017

Book a session:

Craft Your Portfolio,+2 more

### Create an account to accelerate your career with expert mentors worldwide.

Be a part of a global community learning and exchanging expert knowledge. Once you’re in, you can access all other member benefits too!

![Image 4](https://adplist.org/images/mentor-1.png)

Laura Brown

Workday

![Image 5](https://adplist.org/images/mentor-2.png)

Saptarshi Prakash

Swiggy

![Image 6](https://adplist.org/images/mentor-3.png)

Jacalin Ding

Service NSW

![Image 7](https://adplist.org/images/mentor-4.png)

Bob Baxley

Various, Thoughtspot, Pinterest, Apple

Already have an account? [Log In](https://app.adplist.org/login)

---

### AI Design Hub
*1,007 words* | Source: **GOOGLE** | [Link](https://ai-design-hub.com/)

AI + UX Workshops

AI-Powered Design. No Hype.
---------------------------

Learn how to actually use AI in your design process. Real workshops, real tools, real results—for designers and product builders who ship.

[Join Next Workshop](https://luma.com/n78wwwz3)[Learn More](https://ai-design-hub.com/#about)

12+

Happy Customers

2hrs

Workshop Duration

En/Fr

Language Options

AI Tools

Collaboration

Why Choose Us

AI and UX. Together. Finally.
-----------------------------

We help designers and product builders make sense of AI—turning it from a buzzword into a tool that actually improves your workflow and makes your products better.

### AI-First Approach

Learn AI tools and techniques that actually work—designed for real UX workflows, not just hype.

### Expert Facilitators

Workshops led by seasoned designers who've been in the trenches—building products, shipping under pressure, and making AI work for real teams.

### Practical Focus

No fluff. Hands-on exercises with real projects you can apply the same day.

### Future-Ready Skills

Build skills that matter now—and will still matter when the next AI wave hits.

Meet Your Facilitators

### Become AI Design Experts

Learn from designers who've spent a decade in the trenches—building products, shipping under pressure, and making AI work in the real world.

![Image 1: Tristan Fraud](https://ai-design-hub.com/_assets/v11/e7c55ee21c71bdccfea3ddfadecf932afa2d7b78.png)

#### Tristan Fraud

Senior Product Designer

Meet Tristan, a seasoned Senior Product Designer with a decade of experience distilling complexity into clarity. As a skilled teacher and facilitator, he excels at making complex concepts accessible and engaging for teams.

His expertise spans user research, design thinking, prototypes, and design systems. Tristan partners with product and engineering teams to build solutions that perform, scale, and delight users—making him the kind of designer you want building product foundations that last.

[LinkedIn Profile](https://www.linkedin.com/in/tristan-fraud/)

![Image 2: Morgane Neto](https://ai-design-hub.com/_assets/v11/baffad9007d5e6b80a3a93e9265075dd24cc1854.png)

#### Morgane Neto

Founder of Puxxle & Product Designer

Morgane Neto is a product designer turned founder, with more than 10 years of experience helping fast-moving teams design under pressure—tight deadlines, shifting priorities, and, yes, too many sticky notes. She knows what it feels like to be in the trenches of product building.

That's why she created Puxxle, the first AI copilot for UX teams. Puxxle takes scattered user feedback, endless research notes, and performance data, and transforms them into clear, actionable insights that product teams can trust.

[LinkedIn Profile](https://www.linkedin.com/in/morganeneto/)

### Why AI Design HUB?

The design world is changing fast. AI isn't coming—it's here. Our workshops help you stay ahead by teaching practical skills, not theory. Learn what works, skip what doesn't, and ship better products faster.

*   Interactive online format in English or French
*   Small groups for personalized attention
*   Ongoing community support and resources

#### Our Mission

Make AI accessible to designers everywhere—no PhD required. Just practical tools, real skills, and products people actually love to use.

Available Now

AI User Journey Workshop
------------------------

Journey mapping, but smarter. Learn to design user journeys using AI—for AI products or features. 2 hours, hands-on, no fluff.

#### Use GenAI to Assist During Experience Mapping

Actually use AI to speed up your mapping—not just talk about it

#### Identify Pain Points Worth Solving with AI

Learn to focus AI where it makes a real difference in the journey

#### Define KPIs That Prove AI's Impact

Connect AI features to measurable goals for product and users

#### Map Data Inputs and Outputs Clearly

Understand what data you need, and how AI results should flow back

#### Pick the Right AI Capability for the Job

Match use cases with AI types—prediction, generation, classification, or more

Nov 4 (FR)

2 hours

Small groups

$59

Early bird until end of October

FR Online

[Book on Luma](https://luma.com/n78wwwz3)

![Image 3: UX Design Process](https://ai-design-hub.com/_assets/v11/6e8fdc597ed85b98762919a291ccac8a8d109066.png)

Live Online

#### Workshop Details

*   • 2-hour interactive online session
*   • This workshop will be in French (check our other event for English)
*   • AI types guide sent before the workshop
*   • Hands-on journey mapping exercises
*   • Small groups for personalized attention
*   • Practical templates and resources

Coming Soon

Upcoming Workshops
------------------

More workshops coming. Want in? Drop your email and we'll let you know when dates go live—no spam, just straight info.

![Image 4: Design Sprint Team](https://images.unsplash.com/photo-1552664730-d307ca884978?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxk

*[... truncated, 2,541 more characters]*

---

### Home - Chloé SIMO
*564 words* | Source: **GOOGLE** | [Link](https://chloesimo.com/en/)

###### Strategic vision

###### Efficient UX

###### Impactful Branding

###### High-performance sites

###### Creativity & innovation

###### Custom solutions

### Hello! I'm Chloé, Digital Strategist based in Tromsø, Norway.

#### Take a look, don't be shy.

**My thing?**Finding the balance between beauty, efficiency and authenticity. Versatile and a jack-of-all-trades, I mix **branding, webdesign, development &[digital marketing](https://chloesimo.com/en/emailing-et-newsletters/)** to build projects that reflect your personality.

In short, I think, I create, and above all, I make things possible.

###### [Shall we talk about it?](https://chloesimo.com/en/#contact-form)

10

TO MATCH CONTENT, FORM AND PERFORMANCE

#### Need to turn your ideas into projects?

I'll help you boost your online business with a sharp digital strategy and a healthy dose of creativity.

Business, restaurant, hotel, brand, label, workshop or studio: I immerse myself in your world to reveal its full potential.

Objective: capture, convert, build loyalty. With style.

### My favourite sectors : **_food, music, tech, crafts, e-commerce, tourism & hospitality_**.

I put the right words on your universe to make it stand out. Positioning, storytelling, graphic & editorial identity, UX: substance and style.

I design bespoke sites that are beautiful, fast and designed to convert, on Shopify or WordPress.

 A turnkey site, tailored to your audience and ready to perform.

Your texts must be convincing. I write for your users: words that guide, reassure and convert. Content becomes fluid, strategic, impactful. I think customer journey, not useless likes.

I turn your emails into business leverage.

 Automations, newsletters, key messages: I create emails that are beautiful, useful and designed to convert.

 Relational, rhythmic, and a strategy that works for you even when you're asleep.

> "My winning combo:
> 
>  Digital strategy + Web design + Web development + Web content that rock.

I'm putting together the right ingredients to power your online presence.

**The result**: a site that attracts, a brand that stands out, and a user experience that keeps people coming back.

No need to get lost in technical names, I'll take care of it for you.

A single contact, a global vision, and zero waste of energy.

**Objective**: to save you time, to give you clarity, visibility and customers.

###### [Shall we?](https://chloesimo.com/en/#contact-form)

My skills, your success. Simple.
--------------------------------

![Image 1: See all projects](https://chloesimo.com/wp-content/plugins/salient-portfolio/img/no-portfolio-item-tiny.jpg)

##### Chloé Simo

### _“_ To create is to translate the invisible into tangible experience _”._

![Image 2: See all projects](https://chloesimo.com/wp-content/plugins/salient-portfolio/img/no-portfolio-item-tiny.jpg)

![Image 3](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Puxxle.jpg)

![Image 4](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Maison-Couleurs.jpg)

![Image 5](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Bed-Republic.jpg)

![Image 6](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Morgane-Neto.jpg)

![Image 7](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Distriartisan.jpg)

![Image 8](https://chloesimo.com/wp-content/uploads/2025/11/Logo-Client-Cdiscount.jpg)

##### They trust me:

### Demanding entrepreneurs Ambitious brands Inspired creatives

> "
> 
> 
> I loved Chloé's creativity and flexibility: she knew how to adapt to my constraints and changing objectives. The result is a professional site that is already receiving excellent feedback from my prospects. Smooth communication, excellent follow-up and invaluable advice, I recommend her 100%!
> 
> Morgane NETOCEO Puxxle

> "
> 
> 
> Really pleased with the work Chloé has done in managing and developing our website.
> 
>  Chloé's professionalism, technical expertise and responsiveness in both technical and marketing areas are absolutely remarkable.
> 
> Luis Rodrigues PiresCEO Bed Republic

> "
> 
> 
> Chloé knows how to add value to editorial content!
> 
>  From building the editorial strategy to writing the copy, we've been able to rely on her skills and ability to work as part of a team on web and social media projects.
> 
> Bruno LeconteAssociate Director, Agence WSB

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Puxxle](https://www.pierremoret.com/puxxle)**
  - Source: pierremoret.com
  - *Morgane Neto. Contexte. Le constat de Puxxle est simple : les UX researchers et designers sont noyés sous une masse d'informations éparpillées dans un...*

- **[Morgane NETO - ADPList](https://adplist.org/mentors/morgane-neto)**
  - Source: adplist.org
  - *Morgane NETO . Founder at Puxxle. OverviewReviews7 ... Hi, I'm Morgane, Founder of Puxxle, a tool for UX designers to analyze user data in a second....*

- **[AI Design Hub](https://ai-design-hub.com/)**
  - Source: ai-design-hub.com
  - *Morgane Neto. Founder of Puxxle & Product Designer. Morgane Neto is a product designer turned founder, with more than 10 years of experience helping f...*

- **[Home - Chloé SIMO](https://chloesimo.com/en/)**
  - Source: chloesimo.com
  - *Shall we talk about it? 10. TO MATCH ... Smooth communication, excellent follow-up and invaluable advice, I recommend her 100%!. Morgane NETOCEO Puxxl...*

---

*Generated by Founder Scraper*
