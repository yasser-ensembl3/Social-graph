# Vicky Boudreau

## Position actuelle

**Titre** : CEO & Cofounder
**Entreprise** : Heylist
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Hey there! 🌟 

I'm Vicky, the co-founder and CEO  Heylist. My cofounders Alex & Nico and I are the brains and heart behind this tech wonderland, democratizing influencer marketing and providing more economic opportunities for creators to monetize their content. Before leading our fab team of tech wizards and customer service heroes, I co-founded an awesome PR & marketing firm called bicom with my partner Marie-Noelle Hamelin. I remain an advisor to my first business which now employs 40+ professionals in Montreal, Toronto, New York, and soon Paris, serving amazing clients like L’Oreal, The North Face, Sezane & Diptyque. 🚀

🌈 **Journey of Awesome:**
With 10 years+ of influencer marketing expertise and a passion for nano-influencers, the idea of turning this into a new tech venture was beyond exciting. Now, picture the thrill of bringing that idea to life through incubation at Zù – a haven that's essentially the startup fairy godparent, founded by the legendary creator of Cirque du Soleil, Guy Laliberté himself. 🧚‍♂️ 

💪 **Entrepreneurial Feats:**
Guess what? Heylist snagged the Emerging Entrepreneur Award from the Bronfman Foundation at C2 Montreal in 2023. In addition, in 2024 we were invited by Quebec’s government and our incubator Zù to join a delegation to participate to SXSW in Austin Texas. It's not our first rodeo, right? 

🎉 **Though leadership **
You might have caught me sharing mymarketing expertise or my experience as a businesswoman & mom on a stage with a fancy microphone, thinking to myself, "I’m either going to perform like J.Lo or maybe I look like I am about to take your order at McDonald's!" With a variable level of confidence, I love to share my story when it can inspire others to turn their dreams into a plan and get started!

🎤 **Philanthropy Fun:**
When I'm not trying to conquer the business universe, catch me spreading good vibes for the cause dearest top my heart: equity & women financial independence by supporting the Lise Watier Foundation. I also collaborate with the Montreal Museum of fine arts as I am moved by it’s inclusive mission to  make art accessible to a maximum of persons . 

🎊 **Let's Connect!**
Need some influencer magic, entrepreneurial inspo or just wanna chat? Hit me up at vicky@heylist.com Let's elevate each other and overflow LinkedIn with business karma! 🚀

Cheers to adventures in business, life, and all things Heylist! 🌈✨!

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAALwtQcBWT0H9fpSwxPaidXLXP4zkmgMZ9s/
**Connexions partagées** : 500


---

# Vicky Boudreau

## Position actuelle

**Entreprise** : Heylist

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Vicky Boudreau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402027125433610241 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4D05AQFNvqsPDFf-fA/mp4-720p-30fp-crf28/B4DZrlIbdWIACI-/0/1764780787903?e=1765774800&v=beta&t=yxx_nKK0Yw738ojGVpE0WqItkGPME2JwNKlMcvBnR6E | https://media.licdn.com/dms/image/v2/D4D05AQFNvqsPDFf-fA/videocover-high/B4DZrlIbdWIABU-/0/1764780785558?e=1765774800&v=beta&t=JYdjS2aY91tOIyi_6n2_ryJXcnjfiTuDAW62K72QIoU | *** NYC INSIDERS 😎  ***

Real connection doesn’t just happen in structured meetings, it comes to life when people sit together, talk openly, and break bread.

Earlier this fall during ADWEEK in New York, to celebrate our US expansion Heylist gathered an extraordinary group of top influencer marketing leaders from iconic brands such as Balmain, MAC Cosmetics, Caudalie, UNIQLO, and Skin Clique for a Think Tank Dinner that left us inspired, energized, and reminded of the power of community.

Here are some of the key insights that surfaced around the table:

✨ Mass Advocacy is the new word-of-mouth.
Marketers are increasingly planning large-scale creator programs often 1,000+ creators at a time to spark authentic conversation at scale. (We see that trend coming to Canada as well!)

✨ Discovery remains personal.
Even if its not scalable, marketers love finding creators on their own, the human touch is still part of the craft to refine the persona.

✨ Creator affinity matters.
When influencer marketing can become transactional, working with creators who already love or mention the brand is now a must.

✨ Relationships = impact.
 Long-term, trust-based partnerships consistently outperform transactional ones.

✨ Authenticity still wins.
 Organic, real content continues to hold incredible value in crowded feeds.

✨ Saves & shares are the new power signals.
 These interactions are often valued even more than likes and comments.

✨ ROI & ROAS remains a challenge.
 Even the best teams are still searching for reliable ways to track performance.

These precious insights are exactly why we’re building Heylist:
to help brands discover creators who already show natural affinity, to power niche campaigns to Mass Advocacy strategies at scale, and to bring clarity to ROI all while preserving the authenticity that makes creator marketing so powerful. 

A huge thank you to the Québec Government Office in New York for hosting us all together at the official Residency of the General Delegate David Brulotte and his team Susan Pak, Paul-Thomas Lacroix, and my colleagues Kiara Jaouich and Nico LeBlanc for such meaningful contributions.

Many thanks as well for Mark Greenspan of The Digital Growth Lab | Invite-Only Events for Executives expertly facilitating the conversation and supporting the event.

In 2026, Heylist will be hosting even more in-person Think Tank gatherings, breakfast roundtables and intimate dinners across North America.

👉 If you’d like to join us or want to tag someone who should be in the room  we’d love to hear from you!

#USA #NYC #influence #marketingtech #AI #creatoreconomy #influencermarketing #marketers #nanoinfluencers | 52 | 1 | 1 | 4d | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:39:57.408Z |  | 2025-12-03T16:53:09.717Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397648488856973312 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8312bed7-4fd2-42b3-8918-972f1bc020e3 | https://media.licdn.com/dms/image/v2/D4E05AQH_O2iKhdCzgg/videocover-high/B4EZqm6E_pKkBY-/0/1763736836026?e=1765774800&v=beta&t=_2kv59nNyCfsHaKON7FEzI6G3nM0lY59Qc41ov1Tdfk | *** UNE TITE PAUSE***

Si donner des conférences (parfois deux dans la même journée, dans deux pays différents), voyager sans arrêt et souper d’amandes de mini-bars d’hôtels était un sport national… je pense que je me serais qualifiée cet automne. 🥜✈️

Mais au milieu de ce tourbillon, il y a des moments qui te rechargent pour vrai.
Parmi ceux-là : ma participation à la conférence SaaSpasse en septembre.

Un événement où j’ai rencontré des humaines et humains brillants, curieux, bienveillants, vraiment de nouveaux amis, le genre de rencontres qui te rappellent pourquoi tu fais tout ça et aussi que t'es pas seule.

Et puis, il y a eu le bonheur de retrouver Francois Lanthier Nadeau pour enregistrer l’épisode du podcast. On était les deux fatigués, un peu brûlés par nos horaires respectifs… mais tellement contents de se revoir. 

Résultat : une conversation honnête, sans fla-fla, sur l’influence, la tech, Heylist, le fundraising et notre parcours unique que Frank à joliement encapsulé: Pas  « née pour un petit reach ». 😉

🎧 L’épisode est ici si vous voulez prendre une petite pause ce week-end:
 https://lnkd.in/evhyzMXp

Merci Frank et Joëlle Arsenault pour l’invitation, et merci à la communauté SaaS Passe pour l’accueil. Toujours un plaisir de partager, échanger et apprendre ensemble. 💙

#SaaSPasse #Podcast #Leadership #InfluenceMarketing #CreatorEconomy
 #TechQuébécoise #Entrepreneuriat #FemmesEnAffaires #StartupLife
 #Heylist #Fundraising #Innovation #SaaS | 48 | 8 | 2 | 2w | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:39:57.409Z |  | 2025-11-21T14:54:01.406Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397338160357298176 | Video (LinkedIn Source) | blob:https://www.linkedin.com/343b2770-9e23-439b-8a71-d0fa6b6e1334 | https://media.licdn.com/dms/image/v2/D4E05AQFdmPkakUR2-g/videocover-high/B4EZqifvqAIUBY-/0/1763662825649?e=1765774800&v=beta&t=3_G_r80M1cyCG7ZqUQ4-_zHz9twmz1CJDz6Dmhti1XQ | *** NO PAUSE FOR BREAST CANCER ***

After 15 years working in influencer marketing… this is the first time an organization has ever approached me to be part of a campaign. Here I am becoming what I've been promoting for so long... a nano-influencer!

And guess what? I made so many rookie mistakes for my first collab with Breast Cancer Canada. 😅

First, the package got lost somewhere in the chaos of office mail.

Then I wanted everything to be perfect, convinced I would film the unboxing from my dreamy room at Germain Hôtels Ottawa… which I did but...
 
When I watched myself on camera doing my very first unboxing and immediately cringed. So I delayed. And delayed again for posting.

And here we are: well past Breast Cancer Awareness Month.

But today, I’m putting my ego aside and sharing this important message:
Breast cancer doesn’t fit in a timeline and it definitely doesn’t fit a one-size-fits-all approach.

There are over 50 different types of breast cancer, and each one needs personalized care. That’s what this campaign is about: going beyond one size to make sure everyone gets the right care, at the right time!

If this post sparks even one conversation, raises one question, or reaches one person at the right moment, then I’m exactly on time.

Visit breastcancer.ca to learn more about why individualized screening and treatment matter.

#BeyondOneSize #BreastCancerAwareness #WomenSupportingWomen #Leadership #InfluencerMarketing #Heylist | 136 | 7 | 0 | 2w | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:39:57.410Z |  | 2025-11-20T18:20:53.326Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396735738957950978 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7692189b-06d0-4ab5-b4fe-69cdcc79ac2e | https://media.licdn.com/dms/image/v2/D4E05AQGVFgFfLX_inw/feedshare-thumbnail_720_1280/B4EZqWOCyZKgA0-/0/1763456857853?e=1765774800&v=beta&t=K1MmjZGOM0CI5fpQgQ4Gq8z0WByRdmR5u5ORNUAiZjA | *** Self-care is not selfish ***

Thanks to myself for the reminder 😅😝 | 12 | 0 | 0 | 2w | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:39:57.411Z |  | 2025-11-19T02:27:04.872Z | https://www.linkedin.com/feed/update/urn:li:activity:7396540396312559618/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396213836573212672 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGDI-MpkQWs-g/feedshare-shrink_800/B4DZqShRvxGwAg-/0/1763394792133?e=1766620800&v=beta&t=-J32mnf_mq5M4tPFNqB1ijcaux-q9vpEyoD839hthw4 | 🚀 We’re Hiring! 🚀

Heylist is on the lookout for a Chief Revenue Officer to join our team at Heylist and help us accelerate growth and take our mission to new heights! 🌟

If you're a visionary revenue leader with a passion for scaling companies, building strong partnerships, and driving innovative revenue strategies, this could be the role for you. 💼

At Heylist, we’re revolutionizing how businesses find and connect with smaller creators, and we need someone to work along myself the CEO, to help lead the charge on growing our revenue, expanding our customer base, and creating lasting impact in the talent acquisition space.

What we’re looking for:

* A strategic thinker with a proven track record in driving revenue growth
* Expertise in scaling sales, marketing, and customer success teams
* A collaborative leader who thrives in a fast-paced, innovative environment

If you’re ready to join a high-energy team that’s passionate about changing the future of recruitment, we want to hear from you!

Apply now, or tag someone you know who would be a perfect fit! 👇

And hey, did I mention we have cool merch? So cool, you’ll want to wear it to your next interview… if you don’t mind giving the competition some serious swag envy. 😎

More info: 

https://lnkd.in/dtR8vPUp


#Hiring #CRO #RevenueLeadership #Sales #Marketing #Growth #Leadership #ChiefRevenueOfficer #Heylist #TalentAcquisition #JoinOurTeam | 88 | 10 | 11 | 2w | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:39:57.412Z |  | 2025-11-17T15:53:13.647Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7386392555992662016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHKEN0TbFGnhQ/feedshare-shrink_800/B4EZoGpeQ8IIAg-/0/1761048127127?e=1766620800&v=beta&t=2hgWVakJGJYf7JShU9lvCyinQhmsfgr7m9ka_vtSMO8 | *** Écosystème québécois en technologie ***

Quelle fierté de voir des programmes comme le Fonds Impulsion de Investissement Québec soutenir concrètement les entreprises d’ici! Heylist a eu la chance d’en bénéficier en 2024, un véritable tremplin pour notre croissance. 

Heureuse de voir le Fonds Impulsion poursuivre sa mission de soutien à l’innovation québécoise. 🚀 

Bravo à toute l’équipe pour cette vision ambitieuse te particulièrement à Adrien Picou, M. Sc. pour son accompagnement et support. 💡

Lors du pannel auquel je participais pour l'occasion hier soir, je me suis surprise à nommer plusieurs personnes et représentants d'initiatives dans la salle! Ces personnes et ces organisations nous ont supporté depuis nos début et notre aventure ne serait pas la même sans eux!

Je me permet d'en renommer quelques uns ici: 
Zú, Québec Tech, Phil G. Joseph, Accelia Capital, Invest Quebec | Investissement Québec International, Roch Paquette, David Brulotte

Amis fondateurs en Tech, n'hésitez pas à prendre le temps de bénéficier des ressources mises à notre disposition au Québec, elles sont vraiment nombreuses. Même si c'est parfois étourdissant, ça vaut vraiment la peine!

Et si vous lever des capitaux pré-amorçage et amorçage, préparez vos candidatures pour le Fond Impulsion! | 38 | 6 | 0 | 1mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.837Z |  | 2025-10-21T13:26:57.886Z | https://www.linkedin.com/feed/update/urn:li:activity:7386371209741127680/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7379526805210390529 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5b430995-1f79-42fb-98c2-9473442e125c | https://media.licdn.com/dms/image/v2/D5605AQEKUmp22NsUsg/videocover-low/B56ZmlYc7XKEB4-/0/1759416287270?e=1765774800&v=beta&t=dUhj27ygKQH8SD8_WMGkMx-0z94cKubo-TnJZXwLFCM | *** BIG UNVEILING!***

Today, we are officially unveiling our Search by AI.

A technological breakthrough that shows how innovation comes to life when you combine vision, scientific rigor, and passion.

This feature was born from the exceptional vision and tech direction of my Heylist cofounders Nico LeBlanc, CXO and Alexandre Borgia, CTO superheading the magic work of our tech team, with our brilliant in-house data scientists César Di Meglio and Bahar Rajabi, as well as the invaluable collaboration of Mila - Quebec Artificial Intelligence Institute. 🙏

I still remember the moment Bahar and Cesar presented us internally with V1.
We were amazed. 😲 

I immediately launched into imagining, with a flood of somewhat dizzying ideas 😅  what phases 2, 3, 4 could look like… then I apologized. And Cesar replied:
 👉 “No! We must keep dreaming and expanding our field of possibilities. What we’re showing you today, three months ago we didn’t even think we could build it!”

Those who know me won’t be surprised that in that instant, I shed a tear of pride and emotion. This was last summer...

And this morning, as we finally shared the news on the Cision press wire, I felt that same wave of pride and emotion driving alone in my car. (and yes shed another tear!)
✨ Pride in what we are building with Heylist.
 ✨Pride in our curious, bright, and committed team.
 ✨Pride in our community of dedicated small creators, growing every day in Canada and the U.S.
 ✨Pride in our amazing clients who trust us and co-develop with us the best influencer marketing platform!

And a deep sense of gratitude for our investors, partners, mentors and friends who's support not just make this journey possible but a tremendous adventure!!! 🥹 

Today, we are not just launching a new feature.
We are taking another step forward in our mission to democratize the creator economy! 

👉 I invite you to take two minutes to watch the launch video (with sound!): every single word of the song was searched through the new feature, and every image on screen comes from real content created by our community of creators with results generated in just a few seconds. | 226 | 63 | 7 | 2mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.838Z |  | 2025-10-02T14:44:55.340Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7378411503043108865 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ed5b77b7-3bfe-4e2c-a149-9988742fc2f8 | https://media.licdn.com/dms/image/v2/D4E05AQFGA7xe3V6sDQ/videocover-high/B4EZmViDSrGcB8-/0/1759150368975?e=1765774800&v=beta&t=4EtubYK4xzXD-sV9sAaCbQFAgEw7lY1xNkOpvwpu3Fs | *** BIG BANG ACADÉMIE ***

En presque 20 ans de carrière avec bicom et maintenant Heylist, j’ai eu la chance de prendre près d’une centaine de cafés ou d’assister à des conférences en petit comité avec des personnes qui m’inspiraient et à qui je me permettait de poser toutes mes questions.

La première était souvent : 
« Quelles sont vos pires erreurs et que feriez-vous différemment avec le recul? »

Pour moi, ces moments précieux ont été un véritable crash course en entrepreneuriat. J’en ressortais chaque fois avec plus d’assurance et la conviction que je gagnais en vitesse grâce à l’expérience partagée des autres. 🚀

Alors, quand les cofondateurs de Big Bang Académie, David Cote et Julie Saulnier de LOOP Mission et Éric Hamelin ex Akufen, m’ont présenté leur concept et invitée à participer au programme comme coach en format capsule, j’ai tout de suite accepté!

Je suis fière de me retrouver aux côtés de collaborateurs inspirants comme :
 ✨ Anne Martel, MBA, ICD.D (entrepreneure, ange et ex- Element AI)
 ✨ Stefano Faita (Faita Forgione Foods )
 ✨ Dominic Gagnon (Connect&GO)
 ✨ Lucie Rhéaume (Girl Crush Inc.)
 ✨ Jean Gabriel Crevier (Le Chiffre)
 ✨ Pierre-Olivier Verret (@mintnumerique) 
…et plusieurs autres!

💡 Le programme s’adresse à vous si vous souhaitez :
- Valider votre rêve
- Lancer votre entreprise
- Optimiser votre croissance

👉 Une ressource précieuse pour accélérer votre parcours entrepreneurial : https://lnkd.in/e9Mh4cHZ

Shoutout aux commanditaires galement: National Bank of Canada, Rio Tinto, Microcrédit Montréal, PME MTL, LexStart Partners, Réseau des SADC et CAE 🙏 | 90 | 2 | 3 | 2mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.839Z |  | 2025-09-29T12:53:06.582Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7375897087554748416 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF237fWQXDTnA/feedshare-shrink_800/B56ZlxzUAtG0Ag-/0/1758550902135?e=1766620800&v=beta&t=f0Bg4xzJw5m3WHxO12tQp1IJUpfUJtUJhQqjVzypY7E | *** SAAS NORTH 2025 ***

Building a tech company like Heylist is a journey full of pivots, late nights, and constant learning. 🚀 🛝 🎢 

The wins matter, but the real story is in the resilience and the people who push you to think bigger.

That’s why I’m so excited to be speaking at SAAS NORTH for the first time this year. I can’t wait to meet new peers who will challenge me and remind me what’s possible.

I’m honored to be part of an inspiring lineup of voices from across the ecosystem, including:

✨ Entrepreneurs I admire:
Marie Chevrier Schwartz, CEO at TechTO & Peerscale
JD Saint-Martin, President at Lightspeed Commerce

📰 Media pros we trust
Sean Silcoff, Author, public speaker and journalist at The Globe and Mail
Siri Agrell, CEO of BetaKit

💸 VCs we respect
Lauren Ledwell, principal at Sandpiper Ventures
Lance Laking, managing director at Graphite Ventures

What makes SAAS NORTH Conference so unique is how it brings together entrepreneurs, investors, and media the perspectives that keep our ecosystem thriving.

📅 Dates: Wednesday, November 5 & Thursday, November 6
 📍 Location: Rogers Centre, Ottawa, ON
 🏢 Address: 55 Colonel By Dr, Ottawa, ON K1N 9J2

A huge thank you to Nicole Haylock and Erin Mussolum from the SAAS NORTH team for the kind invitation. 🙌

Let me know in the comments if I will see you in Ottawa!
And DM me if you want a promo code 😉 
 
🔗 saasnorth.com
#saasnorth #saas #tech #ai | 96 | 9 | 2 | 2mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.841Z |  | 2025-09-22T14:21:43.214Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7370967650191060992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGWIUKIB75pPQ/feedshare-shrink_800/B4EZkrv_e8HgAg-/0/1757375632654?e=1766620800&v=beta&t=Kgov465F_JSTPNP2_vnbVDgqVmxIMfoVde5DttfgeHo | *** COMPLET!!!***

J’avais sous-estimé le pouvoir de LinkedIn 😅Nous allons refaire ce concept convivial. 

______________

🚨 Il nous reste quelques places pour ce vendredi!🚨

En collaboration avec l'experte en marketing et en stratégie de marque,
Sandrine Briatte, Polina Lichagina de bicom et moi, coanimons la table ronde « Visibilité 360°: Médias, influence et événementiel à l’ère de la fragmentation ».

📍 Vendredi 12 septembre – 9h30

 Petit déjeuner & réseautage
 Locaux de bicom / Heylist – 6664 St-Hubert, Montréal

👉 Ensemble, nous partagerons nos perspectives sur :
 
✨ Comment adapter son mix communication (médias, événements, influence) aux réalités canadiennes

 ✨ Quelles stratégies fonctionnent réellement au Québec, en Ontario et dans l’Ouest en 2025

 ✨ Études de cas et démo concrète

🎯 Public cible : Responsables marketing digital, influence et performance de marques

Si vous voulez vous joindre à nous (faites vite! 😉), écrivez-moi directement en message privé. | 72 | 7 | 2 | 2mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.842Z |  | 2025-09-08T23:53:53.762Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7369690028781907968 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGRvoJ_MvaCyg/feedshare-shrink_800/B4EZkZmACaIQAk-/0/1757071023694?e=1766620800&v=beta&t=W4KWIjL6BKcKmxe4USgpm8UdgeCTHPaYDfiCvDnEJB4 | *** INTERNSHIP OPP ***

🚀 We’re hiring: Growth Intern (Biz Dev & Sales)

If you’re curious, nimble, and energized by startup life, come learn with us at Heylist. You’ll work directly with me and our Growth team on real business development, sales ops, market research, campaigns and creator scouting. 

We’re big fans of the office (hybrid setup in Montreal), collaboration, and fun vibes.

What you’ll do:
Support biz dev & sales: prospecting, outreach, pipeline hygiene
Help run real influencer marketing campaigns
Scout creators and research markets & categories
Jump into special projects (we’ve got exciting news coming this Fall 👀)

What you bring
Curiosity, hustle, and strong communication
Comfort with fast-moving teams and changing priorities
Organized, resourceful, and eager to learn
Details

Paid internship
Montreal-based (hybrid)
Start date: Fall (flexible)

How to apply
 Send a short note + CV to hello@heylist.com
 with the subject line “Growth Intern  + Your name”.
(Feel free to @tag folks you’d recommend ✨)
-------------------

🚀 On recrute : Stagiaire en croissance (Dév. d’affaires & ventes)

Curieux·se, agile et motivé·e par l'idée d'une startup en ébulition? Viens jouer avec nous chez Heylist! Tu travailleras directement avec moi et l’équipe Croissance sur du développement d’affaires, des opérations de vente, de la recherche de marché, de vraies campagnes, et du sourcing de créateurs. On adore le bureau (mode hybride à Montréal), la collab et les good vibes.

Ce que tu feras
Soutenir le dév. d’affaires & les ventes : prospection, outreach, pipeline
Contribuer à des campagnes d’influence réelles
Dénicher des créateurs et analyser des marchés & catégories
Participer à des projets spéciaux (grosses nouvelles à l’automne 👀)

Ce que tu apportes
Curiosité, sens du rythme et excellente comm
À l’aise dans un environnement qui bouge vite
Organisé·e, débrouillard·e et prêt·e à apprendre

Détails
Stage payé
Basé à Montréal (hybride)
Début : Automne (flexible)

Comment postuler
Envoie une courte note + ton CV à hello@heylist.com
avec l’objet « Stagiaire Croissance + Ton nom 
(N'hésitez pas à @taggué vos recos ✨) | 31 | 1 | 3 | 3mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.843Z |  | 2025-09-05T11:17:05.081Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7364693237946535937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEJLGYm6X66Ew/feedshare-shrink_800/B4EZjSldxTGUAg-/0/1755879695921?e=1766620800&v=beta&t=hc-RNT3K_OKG2SMzUTcxCCjYK7JAssWgCkmUt74wAeA | *** Appel aux marketers ***

J’ai gradué du Collège LaSalle, Montréal en 2002 (!) et même si ça fait plusieurs années que fin août ne rime plus avec rentrée (du moins pas pour moi perso… mais pour mes enfants 🎒), c’est toujours un moment que j’adore pour prendre un pas de recul et planifier un max.

Comme les moments forts en marketing reviennent année après année (mais varient selon les industries) et qu’on nous pose régulièrement la question chez Heylist, j’ai eu envie de créer un calendrier pratique.

👉 L’idée : calculer le bon moment pour lancer une campagne de marketing d’influence en amont, afin que les publications des créateurs tombent pile sur les temps forts.

En plus des classiques;
Ventes : Black Friday / Cyber Monday / Boxing Day
Fêtes : Festivités, Fête des mères, des pères, St-Valentin
Événements culturels : 1er juillet, rentrée scolaire
Journées officielles importantes (et parfois plus légères 😉) : Journée des droits de la femme, Pizza Day

J’y ajouterai aussi des sensibilités à respecter, parce qu’une bonne campagne, c’est aussi du timing + du contexte.

✨ Pour le recevoir : tag ton marketer préféré ici-bas!

N’hésitez pas aussi à partager d’autres idées de moments forts qui, selon vous, devraient absolument être dans le calendrier!

P.S. Photo prise au Festival Mode et Design de Montréal 2025 de MAD COLLECTIF portant deux de mes créateurs québécois prefs: eve gravel et Maguire Shoes

#InfluencerMarketing #ContentIdeas #NanoInfluencers #Planification #Backtoschool #Fashion | 124 | 22 | 0 | 3mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.845Z |  | 2025-08-22T16:21:37.310Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7364318153142632450 | Article |  |  | *** 127 Million Influencers ***

🌍 The creator economy is bigger than ever: 127 million influencers worldwide; that’s 2.4% of all social media users (based on 5.17B users globally, Statista). 

Even more striking, 54% are nano-influencers (1,000-10,000 followers)
on Instagram  📈 (Source: Statista & StoryBox)

With so many voices in the space, the opportunities for authentic brand–creator collaborations are endless. But here’s the catch: when everyone is pitching, it’s never been harder for brands to cut through the noise.

That’s the challenge we unpack in our latest blog post, written in collaboration with Veronique Vincelli, a talented member of the Heylist creator community. 🙌

📩 Between overflowing inboxes and endless DMs, too many authentic opportunities get lost. The problem isn’t the pitches, it’s the outdated model.

That’s where we change the game with Heylist:
 ✔️ Brands identify and connect with the right creators.
 ✔️ Creators collaborate with brands that align with their values.
 ✔️ Partnerships run smoothly, with less friction and more impact.

👉 A huge thank you to Vero for sharing her perspective as a creator in this piece.

💡 Are you a brand or an agency looking to simplify influencer marketing? Or a creator eager to connect with aligned opportunities?

📲 Let’s talk! Reach out in DM to explore your influencer marketing plans. 

Bonus if you comment below or share: you get to pick my brain for a free 20 minutes videocall :P


Read the full article here: 
https://lnkd.in/gYsRhhnj | 23 | 7 | 0 | 3mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.846Z |  | 2025-08-21T15:31:10.124Z | https://www.heylist.com/academy/are-brands-overwhelmed-by-creators-pitches |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7363559292970385409 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEIdn5I9kzt0w/feedshare-shrink_800/B4EZjCeJcxGoAg-/0/1755609343194?e=1766620800&v=beta&t=Pa3XBerC1i6FSQuarDfZQmprKEYoWkRJcQOy3w0KO3E | *** SaaSpasse Conf'25 ***

Quand j’ai lancé Heylist et que j’ai mis un pied dans le milieu de la tech, d'abord en joignant l'incubateur Zú,  j’avais peur de ne pas fitter. Dans ma tête, la communauté tech locale, c’était 99% de jeunes de 19 ans déjà sur le bord de passer en IPO avec leurs licornes. 🦄

Et je vais être honnête : je me suis un peu ennuyée des petits canapés fancy des événements PR & Marketing quand je suis tombée (of course bin overdressed) sur mes premiers restes de pizza froide et de la bière tablette 🍕🍺.

Mais j’ai vite découvert une communauté qui m’a réellement impressionnée : des gens de tous âges, ultra allumés, sans ego (ou presque 😅), toujours prêts à faire des intros, brainstormer et partager leurs défis.

Alors quand la gang de SaaSpasse m’a invitée à participer comme speaker à leur conférence, je me suis sentie excitée et fière… comme une fille de 15 ans invitée AU PARTY de l’année des secondaires 5. 🎉

👉 SaaSpasse Conf '25
 📍 Montréal, 10 septembre
 🎤 Je vais jaser de croissance, influence et founder marketing.

Et je partagerai le stage en très bonne compagnie avec :
Greg Isenberg, Marc-Olivier Alain, Olivier Falardeau, Guillaume Roy et Raff Paquin. 🙌

Trop hâte! Viens, on va avoir du fun 👇
https://lnkd.in/eFMCj6wc

P.S. Comme on n’arrête pas le progrès, pour la promo l’équipe a même fait une version plutôt AI de moi-même. 👾 | 183 | 2 | 2 | 3mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.846Z |  | 2025-08-19T13:15:43.760Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7354290606006804481 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFmcze6tpo2Kg/feedshare-shrink_800/B4EZg.wUnaGUAg-/0/1753399513600?e=1766620800&v=beta&t=BXKIAXkDGYH0sTSiaTyzHX7mFVbdY7FfFGWuf6OHhWk | *** BOOK RECO ***

📘 Essentialism: The Disciplined Pursuit of Less by Greg McKeown

About 6–7 years ago, my former assistant at bicom, Emilie Madeleine Dextraze gave me this book as she noticed my tendency to say yes a little too often to ideas, projects, events. With her magic touch in managing (and protecting!) my schedule, I was thriving in my CEO role, feeling both grounded and ambitious.

It became a grounding tool I still revisit whenever I feel my schedule spiraling.
The visual that sticks with me? One image showing how energy scattered in too many directions gets nowhere, while the same energy, focused, moves powerfully forward.

Since starting Heylist, I don't have an assistant anymore (hello startup life 😆 ) but I’ve done a real discipline exercise:

I stepped away from all extracurriculars, sitting on boards, teaching at École des dirigeantes et dirigeants HEC Montréal & Institut de leadership en gestion and constantly attending business events. It was time to protect my energy and focus on what matters most.

In his book McKeown asks:
- Do you feel stretched too thin?
- Overcommitted?
- Hijacked by someone else’s agenda?
- Saying yes to please, then regretting it?
If that resonates, Essentialism might be the reset you need.

It’s not about doing less for the sake of it, it’s about doing the right things in the right way, at the right time. A mindset I now try to apply daily as a founder, mom, and leader.

📖 Highly recommend as a summer read!

What are your tricks to protect your agenda?
I’d love to know!

🤗



#Essentialism #FounderFocus #DisciplinedLeadership #Heylist #WomenInBusiness #LessButBetter | 98 | 12 | 0 | 4mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.848Z |  | 2025-07-24T23:25:16.584Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7350899178878750722 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHIpccb0ZyyFw/feedshare-shrink_1280/B56ZgOj2NEHcAk-/0/1752590935377?e=1766620800&v=beta&t=keHB-fWAeUk93xXsrpTQGrS2NoCXyBI0Qs6i4dzq3r0 | *** From Montreal with Love 💌 ***

Honored to be featured in The PR Net alongside fellow marketing and comms pros, including my partner at bicom, Marie-Noelle Hamelin!

Among other Marketing pros, we were asked to share our favorite go-to spots in our city and it reminded me just how powerful a good recommendation really is. Whether it’s where to eat, shop, or unwind, the recos we trust most often come from our entourage: people who live it, love it, and share it authentically.

That same principle is at the heart of what we do at Heylist - helping marketers tap into the influence of smaller, trusted creators who move the needle through relevance and realness.

Here are a few of my fave Montreal addresses, places I turn to for inspiration, nourishment, and a little indulgence:

🍴 Dine
Ferreira Cafe – a timeless spot with vibrant energy and incredible Portuguese dishes, now co-lead by second generation with Sandra Ferreira
MANDY'S – our healthy-but-delicious go-to when days are packed (which is often!). Congrats to Rebecca Wolfe, Mandy Wolfe and their CEO Vanessa Fracheboud on bulding an empire one salad leaf at the time!
Molenne – my current obsession in Mile-End. Elevated brasserie vibes and a Crudo d’Hamachi that’s unforgettable.

🛍️ Shop
SSENSE – bold fashion picks, always ahead of the curve.
Ruse Boutique – curated, pre-loved luxury with heart, the weekly drops are making me visit their website regularly
Eve Gravel – thoughtful, playful everyday wear from a local gem

💪 Move
Mouvement Humain – reformer Pilates is now part of my weekly rhythm making me feel strong and energized.
Parc Maisonneuve – my personal mini Central Park for peaceful runs.
Mont-Royal – perfect for walk-and-talk meetings with a view.

💇‍♀️ Primp
La Rousse Espace Beauté – Sophie Tessier is a magician, from cut to color to quick blowouts.

💆‍♀️ Unwind
Beauties Lab – a self-care haven where I treat myself to customized facials and stock up on my favorite products. The mastermind Léa Bégin leads this project with deep soul and very good taste!

💡 These places aren’t just addresses — they’re built by passionate people shaping our cities and our routines.

Big thanks to ThePRNet for the feature, and proud to have shared the spotlight with Marie-Noëlle, who inspires me daily. ☺️ 💫

Full article here: https://lnkd.in/gCNcbPU3

If you’re in PR, social, or brand marketing: let’s talk. We built Heylist to support teams like yours faster, smarter influencer marketing, made for real-world workflows.

#Entrepreneurship #Marketing #Heylist #ThePRNet #SupportLocal #InfluencerMarketing #MontrealStyle #WomenInBusiness #CommsLife #CreativeEcosystem | 51 | 5 | 0 | 4mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.849Z |  | 2025-07-15T14:48:57.347Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7349033886594572290 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEN6vZLJqLp8g/feedshare-shrink_2048_1536/B4EZf0DYPrH0Aw-/0/1752146216264?e=1766620800&v=beta&t=xFHk5qlGlZE_pOxb-3RacJT-fCau8kjIcvhmkqOZTZM | 🔥 Everyone’s Invited: Morning Fireside Chat at Ax-C -
Come for the community, Stay for the croissants 🥐

I’m excited to be hosting this panel on one of my all-time favorite topics: building strong, meaningful communities.

Join us this Friday, July 11 at 8:30 AM at Ax.C for a special breakfast event ahead of the final day of Startupfest. Think of it as the perfect way to recover from the Startupfest parties, fuel up with a 100% Québécois breakfast, and spark some inspiration to close out your week.

🎤 Fireside Chat: The Art of Building a Community That Lasts
We’re gathering an all-star panel for a dynamic, English-language conversation about how to create deep, lasting engagement around your mission  whether you’re launching a startup, leading an initiative, or growing an ecosystem.

Featuring:
John Gleeson, General Partner at Success Venture Partners - flying in all the way from Silicon Valley to share his wisdom on scaling both companies and communities.

Noah Redler, Founder of Arche Innovation and former Notman House campus director a key architect of Montréal’s innovation scene.

Moderated by me, Vicky Boudreau — CEO of Heylist and cofounder of bicom, lifelong connector, and passionate believer in the power of networks.

📍Details:
When: This Friday, July 11 at 8:30 AM

Where: Espace Ax.C, Place Victoria — 800 Rue du Square-Victoria, Montreal (their new space is so beautiful and fun!)

Language: English (with a French accent for myself 😜  )

RSVP: Spots are limited → Reserve your seat now https://lnkd.in/eGgjdXB5 

Whether you're a founder, investor, community builder, or just startup-curious, this conversation is for you. Come sip, snack, (maybe recover 😅 )and most of all be inspired!

#AxC #Startupfest #CommunityBuilding #Entrepreneurship #Innovation #MontrealEvents | 50 | 2 | 0 | 4mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.851Z |  | 2025-07-10T11:16:57.011Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7347980536000249857 | Article |  |  | *** Art & Business = même combat? *** 

J’ai toujours été fascinée par le milieu des arts. Même si je le trouve parfois intimidant, je suis convaincue que l’art fait du bien et qu’il doit être accessible à plus de gens. 

C’est aussi ce qui motive mon engagement dans la Campagne majeure de financement 2023-2028 de la Fondation du Montreal Museum of Fine Arts avec l'équipe de Jo-Anne Hudon Duchesne.

Quand tout va trop vite, que je manque de perspective ou que l’anxiété s’installe, une visite au musée me recharge comme rien d’autre et ce, même si l’exposition n’a rien à voir avec ce qui occupe mes pensées. L’art remet les choses en place, doucement, mais puissamment.

Dernièrement, j’ai eu le bonheur de participer au podcast OGIVE art, aux côtés de l’incroyable artiste Rosalie Gamache.

On vient d’univers différents, mais on partage un moteur commun : la création guidée par une vision. Merci à Mylène Lachance-Paquin pour cette conversation sensible et éclairée et à Altitude/C pour la production soignée!

🎧 L’épisode est en ligne. On y parle de :
 – branding personnel
 – conciliation des rôles
 – visibilité & fidélité à soi-même
 – leadership féminin

👉 Pour l'écouter: https://lnkd.in/ex8jnRHQ

#OGIVEart #Podcast #Art #Business #LeadershipFéminin #MBAM #Création #Heylist #RosalieGamache | 49 | 15 | 0 | 5mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.852Z |  | 2025-07-07T13:31:18.659Z | https://www.youtube.com/watch?v=yuJJZS0e660 |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7339259633527627779 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPGxzrBZbC5g/feedshare-shrink_800/B4EZdpJvNkHcAk-/0/1749815852295?e=1766620800&v=beta&t=veEj_nUzcw4CAMMc5MiCzPVuYqyBjUHhCMmC_hURiJ4 | *** Taking care of business with style 😎  ***

As a former publicist and forever fashion fanatic, being interviewed and having Heylist featured in The Business of Fashion is truly surreal. A real pinch-me moment. 

Even more special: this comes as we’re gearing up to launch our brand new UGC super feature! 🚀 

When the stars are aligning... 🌟

Huge thanks to the brilliant journalists Haley Crawford and Malique Morris for the thoughtful piece! 

💡 My top 3 takeaways from the article perfectly aligned with where we’re headed at Heylist:

* UGC is becoming the new ad currency
 Authentic creator content is being repurposed into high-performing ads. The era of mass gifting and staged influencer posts is fading; real, relatable content is winning.

* AI is optimizing targeting, but creatives matter more than ever.
 Even with advanced targeting, ~80% of performance depends on creative strength. Storytelling, aesthetics, and authenticity continue to drive real results.

* Strategic creator partnerships over blind mass gifting.
It’s no longer about blind sending products to hundreds of creators. Brands are prioritizing meaningful partnerships with selected communities of creators who genuinely love the product and licensing that content for ads.

The future of advertising is being rewritten, and I couldn’t be more excited to help shape it with our entire team 💪

Extra special thanks to the generous Myriam Belzile-Maguire from Maguire Shoes who made the intro to BOF, forever grateful for these casual connections that ends up creating magic! I met her through Les cheffes de file de La Caisse (Caisse de dépôt et placement du Québec)at C2 Montréal, women lifting each other is powerful!

Read full article here: https://lnkd.in/eQKPqSxK


#Heylist #UGC #CreatorEconomy #BusinessOfFashion #InfluencerMarketing #MarketingEvolution #Grateful #StartUp #LaunchComingSoon | 169 | 26 | 0 | 5mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.853Z |  | 2025-06-13T11:57:33.483Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7338262973439770627 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFR2FAvMtyYrA/feedshare-shrink_800/B4EZda_R3fHcAg-/0/1749578229927?e=1766620800&v=beta&t=hUTyDSNnXf5GGcgQsLW-j6Tb_FBxjPmv-iMo6yrr3D0 | ***The future of influence isn’t Famous—It’s Focused***


MYTH: Bigger reach = bigger impact
TRUTH: In the creator economy, intimacy beats celebrity.

We’ve seen it firsthand at Heylist: brands who work with nano-influencers consistently see higher engagement and more trust-driven conversions than those who rely on big-name endorsements.

Why? Because authenticity scales down, not up. Smaller creators build real relationships with their communities, ones rooted in daily life, honest conversations, and shared values.

💡 In our latest blog post, we explore why brands are swapping celebrity shoutouts for nano-collaborations; from better ROI and precise targeting to true local impact.

👉 Read it here: https://lnkd.in/eGbTEGgd

And shoutout to Dominique Frappier, member of our community and the brilliant voice behind this post and a real example of what trusted influence looks like. Your work continues to inspire brands to think smarter.

Curious how we help brands connect with smaller creators at scale with full performance visibility?

Let’s talk. Demos are open.

#nanoinfluencers #creatoreconomy #influencermarketing #brandpartnerships #socialcommerce #marketingstrategy #digitalmarketing #consumertrust #authenticitywins | 40 | 4 | 1 | 5mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.854Z |  | 2025-06-10T17:57:11.201Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7334211798809665539 | Article |  |  | *** Data, but make it fun!***

👩‍🔬 At Heylist, we're proud to walk the talk on innovation and inclusion.

With 10 out of our 15 team members identifying as women (that’s 67% female representation 🙌), we’re building not only the future of marketing tech—but also the kind of team we want to see more of in tech spaces.

One standout example? Bahar Rajabi, our brilliant Data Scientist. With a background in applied mathematics and data analytics, Bahar brings deep analytical rigor and creative curiosity to everything she touches. Before joining Heylist, she was developing AI-powered forecasting models in the energy sector at Apsooba in Tehran. 

Today, along with her colleague César Di Meglio, she’s helping shape how brands and creators understand performance at the content level.

📊 In her latest blog post, Bahar dives into a question we all ask:

What Instagram formats actually perform best and for what goals?
Using over 2,000 posts from our community of nano influencers, she uncovered some surprising insights:

📹 Reels = reach monsters
 Reels earned 8 million views—263% more than carousels and over 14,000% more than Stories.
But when it comes to engagement rate, they lag behind…

🖼️ Carousels & Images = quiet winners
Though they don’t win on reach, these formats drive deeper engagement.
In fact, static images had the highest engagement rate of all formats.

📉 Stories = intimate, but limited
 Great for urgency or behind-the-scenes moments, but not the strongest for sustained performance.

📌 Takeaway? There’s no one-size-fits-all. Your format should match your objective; visibility, engagement, or intimacy.

👉 Read Bahar’s full analysis here:
 https://lnkd.in/ep-PsPPT 

We're lucky to have minds like Bahar's at Heylist—where data meets creativity, and diversity drives innovation. 💥

Curious about how this data could shape your next campaign? 

Let’s connect and talk about your influencer marketing goals. Send me a DM! 📩 


#Heylist #DataScience #CreatorEconomy #WomenInTech #InstagramStrategy #InfluencerMarketing #ContentMarketing #FemaleFounder #InnovationDriven #StartupCulture | 35 | 3 | 1 | 6mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.856Z |  | 2025-05-30T13:39:15.902Z | https://www.heylist.com/learn/instagram-content-formats-ranked-what-drives-real-performance |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7330254166658842625 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0exU0TtBBKA/feedshare-shrink_800/B4EZbpLTxDHMAo-/0/1747668779356?e=1766620800&v=beta&t=el44SyEmjkRbHo-3nzac02nnSgOHVu9x4SSA-QtHhh0 | ✨ We brought a Webby back to Montreal! ✨

Last week, my cofounder Nico and I had the privilege of attending the 29th ceremony of The Webby Awards in New York—where Heylist was honored with the award for Best Marketing, Content & Management in Apps and Software.

🏆 Often called “the Internet’s highest honor” by The New York Times, the Webby Awards recognize global excellence online, and it’s surreal to see our Montreal-based tech company standing alongside some of the most innovative brands, creators and artists in the world.

👉 What makes me particularly proud is that this recognition isn’t just for a campaign or a moment, it’s for the platform our team has been relentlessly building. Superheaded by our CTO and cofounder Alexandre Borgia brick by brick, line by line, with passion, care, and vision. This award is a total team work!

It’s easy to rush from one milestone to the next, but this one deserved a pause. While in NYC, we made space to get inspired, attending events like the Wealth Catalyst, Betaworks Studios Demo Day, and The PR Net tech demo. Each reminded us that our ecosystem is full of creators and innovators doing brave, bold things.

And the city didn’t disappoint:
 🌆 Shared a spontaneous cab with L.A. podcaster Lauren LoGrasso and her super nice fiancé (a clown friend was involved in their meet - best story!)
 🎬 Reunited with line up pals Erica Rose and Elina Street, the Emmy-winning duo behind The Lesbian Bar Project
 🕺 Hit the dance floor at 1AM with none other than Dr. Howard Tucker the 102-year-old TikTok sensation!

Sometimes, no expectations = the most unforgettable magic. ✨ 
I didn’t realize just how big of a deal the Webby was until I found myself on a red carpet with major media. Thanks to the glam touch of my friend Sandrine Castellan's hair & make-up contacts, and the elegance of Montreal-Lebanese designer Nessrine Nassar from Ness Designs, paired with Maguire Shoes and a repurposed luxury bag from RUSE, I felt confident! 💅 

One tiny regret: I wish we had the budget to bring the whole team and buy a table for everyone. 💛
But don’t worry, we’re planning a proper celebration in Montreal as our statuette will be joining us very soon!

🎤 Fun fact: Our five-word acceptance speech—“Merci! C'est juste le début”—was the only one delivered in French! Huge thanks to Shena Patel for her last-minute approval. ;)

🙏 A heartfelt thank you to the media who helped amplify this moment for us:
Philippe Jean Poirier at Isarta ➡️ Link in comments below
Emmanuel Martinez at Les Affaires 
The Globe and Mail for sharing the Webby press release 
Grenier aux nouvelles for spotlighting our story 


#WebbyAwards #Heylist #InfluencerMarketing #MontrealTech #WomenInTech #Gratitude #NYCMoments #CreatorEconomy #AwardSeason #FoundersJourney | 357 | 65 | 0 | 6mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.857Z |  | 2025-05-19T15:33:02.868Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7326645280739647488 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEXJzA381BwLw/feedshare-shrink_800/B4EZa15DU2HIAg-/0/1746808355665?e=1766620800&v=beta&t=2EW29zdvsLTtQqn6tkSAQldEa027M0teAmultTG4YOM | *** Rolling suitcases, red carpets… and parenting guilt.***

I had my first daughter right as we were expanding with bicom. By the time she turned 5, I had traveled countless times for work—Toronto, New York even Tokyo… ✈️

And honestly? I loved it.

No guilt. No shame. No judgment.

I had the privilege of a supportive partner and tribe who never made me feel like I had to choose between being a mom and being ambitious. I’d cram my trips into 3 days and 2 nights. And I cherished those quiet hotel rooms, solo bar dinners, and reflection time at the airport.

Now my girls are 7 and 11. Post-pandemic, I travel far less. We still laugh about their collection of airport t-shirts from cities they’ve never visited. When I’m away, I don’t really do FaceTime, but I’ll take pics of public art and exhibitions to share and we “debrief” when I get back. It’s our ritual.

Of course, I’ve gotten those comments:
 ❓“How do you manage work-life balance?”
 🍎 Daycare feedback about their diet while I was away (!)

Each time I felt a flicker of guilt, I’d buy a fifth miniature NYC taxi at the airport and ask myself: Would I feel this if I were a man?

But last night, something broke through.

My 11-year-old burst into tears and told me she wishes I would be no businesswoman and had a “regular job” so she and her sister wouldn’t be the only ones picked up by a nanny.
(For context: I’m home most days by 5:30/6 unless I have an event.)

Maybe I was tired. Maybe it had just been a long day. But I didn’t know what to say in that moment. I wanted to explain that the life we have—the family trips, the adventures, the security—are all linked to the life their dad and I have worked so hard to build. But that felt too transactional. So instead, I just sat there, quiet and sad.

I kept wondering:
How do I explain to them that I want them to be proud of their mom? That I work my X off not just for us, but because I believe in what we are building at Heylist for women, for creators, for the next generation?

The next morning, she was all smiles again.
When she found out that her “not-so-cool” mom was going to be on the same red carpet as Snoop Dogg next Monday in NYC at The Webby Awards, she was suddenly back to cheering me on.

Parenting, right?

So here's my honest question to you:

Have you ever had to navigate a moment like this with your kids?
How do you handle those conversations, the trade-offs, the doubts?

Open to tips and advice but might no follow 😜 

#WorkingMoms #Leadership #ParentingWhileAmbitious #WomenInBusiness #RealTalk #FounderLife #Heylist #Startup | 197 | 45 | 0 | 6mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.859Z |  | 2025-05-09T16:32:37.415Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7325281986040770561 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE7P2R0uEnipw/feedshare-shrink_800/B56ZaiQw1iHAAg-/0/1746479029047?e=1766620800&v=beta&t=l1RA2aqqx-6xe2MaWs93kFJmBp9UVgxhZ1L2gCPkKNI | *** Tomorrow lunch time ***

Join us for a free webinar with Monday Girl where I will share about:

​🔧 Behind-the-scenes of building Heylist and raising capital in a competitive market
📈 Real talk on the future of creator monetization and brand partnerships
💬 Lessons learned from agency life to startup scale-up
👑 Candid reflections on women in leadership and financial empowerment

Register here: https://lu.ma/MGxHeylist


​This is a must-attend for creators, founders, marketers, and anyone curious about the intersection of content, commerce, and community.

#CreatorEconomy #Empowerment #Womeninbusiness #Tech #StartUp | 21 | 0 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.860Z |  | 2025-05-05T22:15:22.630Z | https://www.linkedin.com/feed/update/urn:li:activity:7325263981864980480/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7323715235087798275 | Video (LinkedIn Source) | blob:https://www.linkedin.com/41f37b79-3ce5-4554-ac35-b1abb17a4b5e | https://media.licdn.com/dms/image/v2/D5605AQH-6ubSFmk52A/videocover-high/B56ZaMQKGnHUBc-/0/1746109770265?e=1765774800&v=beta&t=zAuP5jj0hduq9ig6a5DOn_j2-xRGIQutU47qdPRnHBQ | ✨ Tout prévoir pour réussir ? ✨

il y a un moment déjà, j’ai eu la chance de m’entretenir avec Josée Fiset, cofondatrice de Gestion Première Moisson Inc. et professeure associée à HEC Montréal dans le cadre de la série Atypique, produite par Le Pôle D — une plateforme de recherche et de transfert dédiée à la profession de PDG, co-dirigée par des chercheurs et des dirigeant.e.s chevronné.e.s.

Notre discussion m’a permis de mettre le doigt sur un de mes super pouvoirs : l’hyper préparation. Pas pour tout contrôler, mais pour mieux créer.

🎬 Cette capsule a été tournée il y a déjà deux ans, alors que je m’apprêtais à faire le saut à temps plein chez Heylist.

La revoir aujourd’hui me permet de mesurer le chemin parcouru… et ce qui n’a pas changé : ma conviction que bien se préparer, c’est un acte de vision et de création.

On y parle de:
 ➡️ Gestion de la peur
 ➡️ Vision à long terme
 ➡️ Intuition comme outil stratégique
 ➡️ Et cette obsession productive qu’est la préparation méthodique

Merci Josée pour cette conversation vraie, pour ton écoute et ton regard bienveillant.

Merci également à l’équipe derrière le projet: Sophie Montminy, Alaric Bourgoin, Célia Rocaspana, Sonia Bluteau, Pierre Duhamel.


🎥 L’épisode complet est en ligne ici :
https://lnkd.in/g9wY_nnT

#Atypique #HEC #Leadership #Préparation #Stratégie #Entrepreneuriat #Inspiration #Heylist | 38 | 6 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.861Z |  | 2025-05-01T14:29:40.094Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7322998227648045056 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHXuwoEBq_aKg/feedshare-shrink_800/B4DZaCEBD1GgAk-/0/1745938814359?e=1766620800&v=beta&t=UswzzybsPVjvYcqRjue723tLIBb-1mQJh4Bt_aKtV6E | 🔎 Nano, micro, macro : chaque influence a son impact

Dans un récent numéro du Grenier aux nouvelles, j’ai eu le plaisir de collaborer comme experte, à titre de CEO de Heylist pour un dossier qui explore en profondeur un sujet stratégique : le marketing d’influence et la valeur des créateurs de contenu de toutes tailles.

Trop souvent, on se demande s’il faut miser sur un macro ou un nano-influenceur. Mais la vraie question est la suivante:
 👉 Quelle collaboration aligne réellement les objectifs de marque avec une relation authentique et performante?

Dans l’article, on parle de :
- L’importance de l’engagement et de la proximité communautaire 🎯
- Comment bien choisir ses partenaires pour un impact durable 🛠️
- L’essor des nano-influenceurs propulsés par TikTok 🚀

Un immense merci à Grenier aux nouvelles pour cette tribune, à Emilie Desgagneé pour sa plume, et à Maude Perreault de Nellie Marketing, dont la vision complémentaire est à la fois lucide et stratégique. Son rappel que “ça ne suffit pas de faire du beau, il faut faire du bon” résume parfaitement les enjeux actuels du marketing d’influence. 👌

📩 Si vous souhaitez échanger sur vos stratégies d’influence, bâtir des campagnes créateurs performantes ou évaluer comment le pouvoir des nano-influenceurs peut propulser vos marques, écrivez-moi - j’adore en discuter!

#Marketingdinfluence #Nanoinfluence #Créateursdecontenu #Stratégiedemarque #Authenticité #Heylist #Influencermarketing | 41 | 0 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.862Z |  | 2025-04-29T15:00:32.199Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7321176183063121922 | Article |  |  | *** Un Webby Award pour Heylist***

Nous avons remporteé le prix de la catégorie Marketing & Content Management / Apps & Software de The Webby Awards… C’est complètement fou! 🤯

Le prix du jury reconnait notre design, notre UX, nos fonctionnalités… mais surtout pour la valeur ajoutée que notre équipe a su créer.

Ce n’est pas un prix de croissance, de pitch ou de visibilité. C’est une reconnaissance du produit. Et ça, c’est précieux. Parce que derrière cette plateforme, il y a une équipe de 14 personnes, co-dirigée par mes partenaires Nico LeBlanc, CXO et Alexandre Borgia, CTO, qui rêve grand, construit avec soin et met de l’intelligence là où il faut pour réinventer le marketing d’influence à l’échelle des nano-créateurs. 💥 MERCI ET BRAVO LA GANG!

Nous serons donc à New York le 11 mai prochain pour recevoir notre prix sur scène! 🤩 🍎 

🙏 Merci au journaliste Emmanuel Martinez pour ce bel article dans Les Affaires.

Et pour boucler la boucle : je lis avec curiosité Les Affaires depuis que je suis ado, quand ça traînait sur le bureau de mon père. C’est juste magique de s’y retrouver pour une nouvelle comme celle-là, je pense qu'il serait pas mal fier. 💫


 #Teamwork #Webbyawards #Heylist #Marketingdinfluence #NanoInfluenceurs #Startup #LesAffaires | 118 | 32 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.863Z |  | 2025-04-24T14:20:22.918Z | https://www.lesaffaires.com/mon-entreprise/entrepreneuriat-et-pme/la-jeune-pousse-montrealaise-heylist-remporte-un-webby-award/?utm_term=Autofeed&utm_campaign=echobox&utm_medium=Social&utm_source=LinkedIn#Echobox=1745448838 |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7320860396305739776 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHvXlXAahNmtA/feedshare-shrink_800/B56ZZjMADTGcAg-/0/1745420816847?e=1766620800&v=beta&t=ayzDlhpJPDy4VjjK6N054VGQ7vQtFFdhAU6Gp5vmwUI | *** Art of connection & Power of business Karma***

Some conversations are effortless like you’re picking up a thread you didn’t even realize had been paused. That’s how it felt stepping into The Not Perfect Networking Podcast; natural, energizing, and refreshingly real. 

What was meant to be a recorded interview quickly turned into one of those rare exchanges that leaves you thinking long after the mics are off; a joy to talk all things networking, courage, karma, and the incredible magic that happens when people are truly intentional about how they connect others.

I loved sharing my theory of business karma—how when you give generously, connect thoughtfully, and show up authentically, the right opportunities find their way back to you. It’s a belief that’s shaped my career and helped me build Heylist into what it is today: a tech-driven platform democratizing influencer marketing and giving power back to creators.

But behind every story of growth and progress, there are people. People who showed up, who believed in you, who made the right introductions at the right time.

And for me, that person is Zoe Weisberg Coady .

Zoe is what I call a Master Connector. Not just someone with a deep Rolodex, but someone with a gift—a thoughtful, intuitive ability to introduce people in a way that always feels meaningful. Even in an email, she strikes that perfect tone: praising both individuals just enough to spark genuine curiosity, never over-selling, never under-delivering.

Never not once have I felt like a connection from Zoe was a waste of time. Quite the opposite. Her introductions have consistently opened doors, inspired new ideas, and expanded my world in ways I’m still grateful for.

We met almost two decades ago through the brilliant Shannon de Laat, and from that moment, Zoe has played a major role in helping me build my network in the United States. It’s not just what she does it’s how she does it. With elegance, generosity, and an uncanny sense of alignment.

Through Heylist, I’m driven by the same ethos: connecting the right people, creators, and brands in ways that are authentic and impactful. We’re on a mission to make influencer marketing more accessible, more transparent, and more equitable. And none of this happens without community. Without the kind of connections that Zoe has modeled so beautifully for me over the years.

Recording this podcast episode felt full circle. It was a chance to reflect on where I’ve come from, the people who’ve helped me along the way, and the values I carry into every conversation and connection.

I hope listeners enjoy the episode as much as I enjoyed being part of it. 🎧✨
And Zoe again thank you. For every email, every intro, and every ounce of faith you’ve had in me. You’ve helped shape my journey, and I’m endlessly grateful.

LISTEN HERE:
Apple: https://lnkd.in/eraqB8hZ

#Podcast #BusinessPodcast #EntrepreneurPodcast #NetworkingTips 
#PersonalGrowth #MindsetMatters #ThoughtLeadership | 33 | 5 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.865Z |  | 2025-04-23T17:25:33.488Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7318270865408679936 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEP71TH2Cnx7w/feedshare-shrink_800/B4EZY.4kjcGYAk-/0/1744811739940?e=1766620800&v=beta&t=FX6z1kQBLi9sURMoBZVq0DJGZgGFshSTax3pyZF-RKw | 🎉 We’re nominated for a Webby! 🎉
 ✨ Best Software Services & Platforms – Marketing & Content Management ✨

We’re absolutely thrilled to share that Heylist has been nominated in the 28th Annual Webby Awards, aka “the Internet’s highest honor” (shoutout to The New York Times for that 🔥 title).

Out of nearly 13,000 entries, we made the shortlist thanks to our AI-powered platform that connects brands with real, relatable creators making campaigns smarter, faster, and more authentic.

For the past year, we’ve been heads down, building something we believe deeply in: a new kind of ecosystem where creators of all sizes can thrive, and brands can scale real impact.

So to find out that The Webby Awards, an international institution that celebrates the very best of the internet has been watching what we’re doing?
That hit differently. 💥


And now, our work is in front of a jury that’s nothing short of out of this world, please meet the judges shaping the digital future:
 🔹 Marian Croak, Google – VP of Engineering, Responsible AI
 🔹 Sarah Harden, Hello Sunshine – CEO
 🔹 Tobe Nwigwe – Artist & Actor
 🔹 shigetaka kurita – Father of Emojis 👾
 🔹 Severin Hacker, Duolingo – Cofounder & CTO
 🔹 Law Roach – Image Architect
 🔹 Yann LeCun, Facebook – Chief AI Scientist
 🔹 Roxane Gay – Host, The Roxane Gay Agenda
 🔹 Quinta Brunson – Creator, Director, Star
 🔹 Questlove – DJ, Producer, Webby icon
 🔹 Todd Kaplan, Kraft Heinz – CMO
 🔹 Ashley Murphy, RareBeauty – VP Global Consumer Marketing
 🔹 Nelly Mensah, LVMH – Head of Web3 & Metaverse
 🔹 Jim Habig, Apple – Product Marketing
 🔹 Tonya Custis, Autodesk – Director of AI Research

This means so much to our team, our creators, and the brands we work with daily. 🙌 Thanks to Nick Borenstein, General Manager of The Webby Awards and the wholwe team!!!

🗳️ YOU can help us win the People’s Voice Award! Vote here until April 18th 👉 https://lnkd.in/ee6PpfiH

 #WebbyAwards #Heylist #InfluencerMarketing #CreatorEconomy #ProudMoment #NanoInfluencers #WomeninTech #Montreal | 104 | 23 | 0 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.866Z |  | 2025-04-16T13:55:41.211Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7317860501349163008 | Text |  |  | **Défi accepté Vanessa Fracheboud ✨**

Voici mes 5 coups de cœur 100 % canadiens qui embellissent mon quotidien!  Autre MANDY'S bien sûr! ;)

Parce qu’encourager local, c’est bon pour l’économie, pour la planète — et pour l’âme.

👟 **Hettas ** 
Une marque de Colombie-Britannique qui crée des chaussures de course haute performance, conçues spécifiquement pour les femmes. Depuis que je me suis foulée la cheville l’an dernier, je suis plus prudente… et leurs souliers me donnent une confiance totale. Allier science, confort et performance : mission accomplie pour Lindsay Housman et son équipe!

🫧 **SOJA&CO. ® ** 
Allumer ma chandelle Melon + Air salin pendant ma méditation matinale ou rentrer dans une maison parfaitement parfumée après une grosse journée… un pur bonheur. Même quand mes soirées sont bien remplies entre devoirs des enfants et événements, cette ambiance apaisante fait toute la différence. Merci Laurence Gaudreau-Pépin!

🐟 **Aphina ** 
Le collagène marin liquide au goût de baies sauvages et hibiscus : un élixir fabriqué à partir de poisson sauvage de la Nouvelle-Écosse. Je l’adore pour sa contribution à la santé de la peau, des cheveux, des ongles et des articulations! Une entreprise fondée par Avalon Lukacs, MBA à Calgary.

🍝 **Faita Forgione Foods ** 
Stefano Faita est mon sauveur pour les soupers de semaine. Au-delà des sauces savoureuses, leur gamme comprend aussi des pâtes, pizzas surgelées, saucisses italiennes, boulettes, huiles d’olive, vinaigres, tartinades noisette-cacao… La qualité des ingrédients fait toute la différence. C’est simple : tout est bon! Même leur vin blanc Catarratto, dispo à l’epicerie du coin. 

🎨 **KEÏ AKAI** 
Une galerie d’art contemporain indépendante située au cœur de Montréal. Anne-Sophie M. et son équipe mettent en lumière et rendent accessibles des artistes aux identités plurielles, avec des visions qui bousculent et inspirent. Parmi mes coups de cœur : Franco Égalité Christine Hodgson et Sandrine Castellan, tous trois artistes canadiens au talent exceptionnel.

Je passe maintenant le flambeau à trois personnes aussi passionnées qu’inspirantes :

✨ Geneviève Tanguay, ex Anges Québec 
✨ Anick Beaulieu, Ceo C2 Montréal 
✨ Anne Martel, MBA, ICD.D, Entrepreneure/ investisseure

À vous de jouer! J’ai hâte de découvrir vos coups de cœur d’ici. 

Et bravo à Isabelle Hudon LL.D pour l’initiative! 

#5AchatsOnFaitÇa #PropulséParBDC #FièrementDici #LeadershipFéminin #EntrepreneuriatQuébécois #EntrepeneuriatCanadien | 52 | 12 | 1 | 7mo | Post | Vicky Boudreau | https://www.linkedin.com/in/vicky-boudreau-14762b14 | https://linkedin.com/in/vicky-boudreau-14762b14 | 2025-12-08T04:40:02.868Z |  | 2025-04-15T10:45:02.795Z |  |  | 

---



---

# Vicky Boudreau
*Heylist*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 14 |
| Press & Mentions (Google) | 20 |

---

## 📚 Articles & Blog Posts

### [Vicky Boudreau of Heylist On Five Things You Need To Create A Highly Successful Startup](https://medium.com/authority-magazine/vicky-boudreau-of-heylist-on-five-things-you-need-to-create-a-highly-successful-startup-5f3e6cf0ee5b)
*2024-11-24*
- Category: blog

### [Interview with Vicky Boudreau, CEO & Co-Founder of Heylist - zu](https://zumtl.com/en/article-en/interview-with-vicky-boudreau/)
*2024-09-04*
- Category: article

### [7. The Business Karma of Connection with Vicky Boudreau by The Not Perfect Networking Podcast](https://creators.spotify.com/pod/profile/zoe-weisberg-coady/episodes/7--The-Business-Karma-of-Connection-with-Vicky-Boudreau-e31sav9)
*2025-05-13*
- Category: podcast

### [From Montreal To Manhattan: Heylist's AI-Powered Push To Democratize Influencer Marketing](https://www.netinfluencer.com/heylist-ai-powered-push-to-democratize-influencer-marketing/)
*2025-11-06*
- Category: article

### [Vicky Boudreau: Empowering the Creator Economy with Heylist’s  — DISRUPTION MAGAZINE](https://www.disruptionmagazine.ca/news/women-in-tech-vicky-boudreau)
*2024-11-01*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 20,689 words total*

### Vicky Boudreau of Heylist On Five Things You Need To Create A Highly Successful Startup
*3,128 words* | Source: **EXA** | [Link](https://medium.com/authority-magazine/vicky-boudreau-of-heylist-on-five-things-you-need-to-create-a-highly-successful-startup-5f3e6cf0ee5b)

**Thank you so much for joining us in this interview series! Before we dive in, our readers would love to “get to know you” a bit better. Can you tell us a bit about your ‘backstory’ and how you got started?**

P rior to[Heylist](https://www.heylist.com/), I co-founded [bicom,](https://www.bicom.ca/en/) a MarComm agency redefining industry expertise, leading a team of 40+ professionals over the course of 18 years. bicom’s award-winning roster has included brands such as L’Oréal, The North Face, Sézane, Diptyque, Vans, Uniqlo, Neutrogena, Aveeno and more.

Over the past decade, I noticed a shift in the public’s perception and trust towards influencers. They were becoming more like celebrities and less relatable. This change presented an opportunity to focus on smaller influencers and return to the peer recommendations that defined the industry in its early days

As a pilot project, we began activating nano-influencers — individuals with 10,000 followers or fewer who achieve very high engagement rates for beauty brands. The idea of turning this into a tech venture was beyond exciting for me. Operating on a software-as-a-service (SaaS) model, Heylist is a marketplace that connects brands and agencies with nano-influencers.

**What was the “Aha Moment” that led to the idea for your current company? Can you share that story with us?**

Heylist was born out of our vision to simplify influencer marketing for both creators and brands.

With the influencer marketing sector projected to expand to $24 billion by the end of 2024, social media influencers have become a powerful force shaping consumer behavior and driving sales. As new platforms emerge and algorithms evolve, the industry needs to stay agile to keep up with its rapid evolution and its evolving trends.

I had a sixth sense telling me that people will want to go back to transparency, authenticity, peer-to-peer recommendation, and so on. I wondered if there was a way to activate “regular people” with their entourage and audience that trust them and saw a white space for brands to be able to connect with this demographic.

I truly believe that people are craving more authentic connections. While big influencers can be aspirational and beneficial for general brand awareness, consumers are increasingly turning to smaller, niche creators for purchase decisions. They want “real” human beings they can relate to. Nano-influencers’ ability to generate high engagement at low cost quickly proved their value to our customers, both brands and agencies. What’s more, their direct and honest feedback helps us fine-tune the platform to meet their needs even better.

**Was there somebody in your life who inspired or helped you to start your journey with your business? Can you share a story with us?**

Definitely my dad, who passed away 20 years ago and did not see any of my businesses, but always knew I would become a business woman and was always supporting me with my projects.

In his mid-30s, Telesphore Boudreau left a stable supervisory job at the local mine to chase his dream of becoming a fisherman. With a vision that others couldn’t yet see, he first worked as a boat inspector across the province, gathering intel for his next big move. He had a gut feeling that Japanese markets would soon buy crab — creatures that were then dismissed as “sea spiders” and thrown back. With minimal savings and two baby daughters at home, he took the leap. It was a high-stakes gamble, but he made a plan, worked tirelessly, and it paid off. Within a year, crab became “orange gold,” and his foresight led to a thriving fishing company with permits for various species.

His belief that anything is possible with hard work and relentless focus became a mantra for me. It’s this same spirit that drives Heylist today: turning bold visions into reality, step by step.

**What do you think makes your company stand out? Can you share a story?**

One of our key strategies has been building strong relationships with influencers and brands through consistent communication and community-building efforts. As the influencer landscape grows more competitive, we are uniquely positioned as a trusted partner for both sides thanks to our seamless user experience and commitment to fostering authentic brand-creator collaborations.

Heylist’s future lies in our ability to anticipate technological developments and integrate new trends, while remaining true to our core mission of democratizing influencer marketing. We plan to leverage advances in artificial intelligence and data analysis to offer even more personalized and effective solutions to our customers and influencers alike. We also focus on continuous improvement of our platform to ensure that it remains at the cutting edge of technology and capable of responding to emerging needs as new social networks grow in popularity. By remaining agile and open to innovation, we hope not only to maintain our market position, but also to create new opportunities for our

*[... truncated, 14,255 more characters]*

---

### Interview with Vicky Boudreau, CEO & Co-Founder of Heylist - zu
*822 words* | Source: **EXA** | [Link](https://zumtl.com/en/article-en/interview-with-vicky-boudreau/)

Vicky Boudreau joined Zú in February 2023. Since then, Vicky, who was already an entrepreneur, has developed an entirely new business model that led her to launch [Heylist](https://www.heylist.com/), an influencer marketing platform that connects brands and agencies to nano-influencers.

****1. Why rely on nano-influencers? What makes nano-influencers so effective in a marketing strategy, and how have they contributed to Heylist’s success?****

With their smaller, but often highly engaged audiences, nano-influencers offer an authentic, personal connection with their subscribers. Their influence is based on the trust they’ve built up with their communities, which often consist of their entourage, family and friends. These close relationships enable brands to benefit from superb content and recommendations perceived as more sincere and credible.For Heylist, nano-influencers have played a crucial role in enabling us to target a growing and previously underserved market segment. Their ability to generate high engagement at low cost quickly proved their value to our customers, both brands and agencies. What’s more, their direct and honest feedback helps us fine-tune the platform to meet their needs even better.

****2. What’s the most valuable piece of advice you’ve received from your mentors, and how do you apply it in your career?****

Even though I’m guided by strong intuition, it’s important to always listen carefully to end-users and remain agile. By actively listening to feedback and remaining flexible, you can quickly adjust your strategy in line with real market needs, rather than embarking on developments based solely on internal assumptions.The way in which mentors have had the biggest impact on my career is in the discipline imposed on me during the incubation program, where I reported to them on a weekly basis. I had to learn to say no to distractions and focus on the essentials to get Heylist off the ground. I’d already been in business for 18 years and was well organized, but I had to relearn how to manage my diary to be able to move into high gear.

****3. How do you see Heylist’s future in an ever-changing technological landscape?****

Heylist’s future lies in our ability to anticipate technological developments and integrate new trends, while remaining true to our core mission of democratizing influencer marketing. We plan to exploit advances in artificial intelligence and data analysis to offer even more personalized and effective solutions to our customers and influencers alike.We will also focus on continuous improvement of our platform to ensure that it remains at the cutting edge of technology and capable of responding to emerging needs as new social networks gain in popularity. By remaining agile and open to innovation, we hope not only to maintain our market position, but also to create new opportunities for our users.

****4. What was the biggest challenge in launching Heylist, and how did you overcome it?****

The biggest challenge was to demonstrate the value of our solution in a saturated market with well-established players. To achieve this, we relied on an outstanding user experience that was both pleasant and accessible to prove the effectiveness of our product. We also chose to focus on the niche of nano-influencers and make them our first ambassadors in order to increase our visibility.At the same time, and in particular with the hiring of two data scientists, we have invested in research and development to ensure that our offering clearly stands out from that of our competitors, while responding precisely to the needs of our target audience.

****5. What advice would you give to those looking to not only launch a business, but also develop a new technological solution? What are the pitfalls to avoid and the opportunities to seize?****

First of all, I’d advise them to start with a thorough understanding of their target market and the specific needs of their users. Even if you start with a strong, intuitive idea, it’s crucial to validate that idea with real users before you fully launch. This will ensure that your solution really does meet a need, and avoid the pitfalls of developing a product that doesn’t find its market, which can lead to great losses of time and money.When it comes to opportunities, it’s essential to surround yourself with the right people. In Quebec, there are a multitude of valuable resources, such as incubators like Zú, Québec Tech, PME Montreal and various entrepreneurial support programs. Don’t underestimate the value of these networks: talking about your project, getting advice and feedback from experts and peers can greatly contribute to your success. One of my greatest surprises over the past two years has been the strength of the local entrepreneurial ecosystem, which is there to support and help innovators turn their ideas into real businesses.

Our sincere thanks go to Vicky’s dedicated mentors: Elisabeth Laett, Richard Laberge and Caroline Côté.

T

*[... truncated, 228 more characters]*

---

### 7. The Business Karma of Connection with Vicky Boudreau by The Not Perfect Networking Podcast
*5,227 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/zoe-weisberg-coady/episodes/7--The-Business-Karma-of-Connection-with-Vicky-Boudreau-e31sav9)

![Image 1: Trailer: Not Perfect Networking Podcast](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/43126311/43126311-1743550975378-5ffac4e5471a1.jpg)

7. The Business Karma of Connection wit…
----------------------------------------

The Not Perfect Networking Podcast Apr 23, 2025

00:00

33:35

[![Image 2: Trailer: Not Perfect Networking Podcast](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/43126311/43126311-1743550975378-5ffac4e5471a1.jpg) #### 23. The Framework Behind Effective Personal Branding In today’s episode, I’m digging into one of the topics I care about most: personal brand positioning in a world where visibility is no longer granted, it’s built.We’re talking about what it really takes to become known for your work (hint: it’s not perfection), why your brand is a living narrative rather than a one-time declaration, and how consistency outperforms talent every single time. I’m also sharing a behind-the-scenes look at what I’ve learned from 15+ years in PR watching leaders rise and the patterns that never fail.If you’ve been waiting to feel “ready” before showing up, this episode is your sign to stop waiting and start leading.In this episode:- Why your personal brand is an evolving story — not a static identity- The Don’t Wait to Be Picked approach and why it matters more than ever- How to build visibility through owned platforms like LinkedIn + Substack- The real engine behind thought leadership (spoiler: consistency beats everything)- What I’ve learned from working with global brands, CEOs, and cultural leaders- How your network amplifies your ideas and why visibility and relationships fuel each otherBy the end, you’ll understand the exact mindset shift and visibility habits that separate “hidden talent” from “recognized leader.”Connect with Zoe:LinkedIn: https://www.linkedin.com/in/zoe-weisberg-coady-57aab37/ Dec 03, 2025 12:13](https://creators.spotify.com/pod/profile/zoe-weisberg-coady/episodes/23--The-Framework-Behind-Effective-Personal-Branding-e3bq3pk)[![Image 3: Trailer: Not Perfect Networking Podcast](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/43126311/43126311-1743550975378-5ffac4e5471a1.jpg) #### 22. No More Small Talk: Building Real Relationships Naturally Through Networking with Wendy Heilbut, Heilbut LLP In this episode of Not Perfect Networking,Zoe sits down with Wendy Heilbut, founder of Heilbut LLP, attorney, angel investor, and connector in New York’s creative business community.Wendy’s career has spanned law, recruiting, entrepreneurship, and nonprofit leadership—giving her a unique perspective on what networking really means. Instead of chasing leads or following sales formulas, Wendy believes the best connections happen through everyday conversations and genuine curiosity.Together, Zoe and Wendy discuss how to move beyond transactional networking and into relationship building that feels natural, sustainable, and fulfilling.In this episode:Why networking doesn’t need to feel forced or awkwardHow relationships you build today can shape your career years laterThe importance of boundaries when being generous with your time and expertiseHow to stay top of mind in your network through authentic updatesUsing platforms like LinkedIn and Substack for genuine connectionWhy every conversation—big or small—can lead to opportunity Connect with Wendy:Website:https://heilbutllp.comLinkedIn:https://www.linkedin.com/in/wendy-heilbut-1356022b/Connect with Zoe:LinkedIn: https://www.linkedin.com/in/zoe-weisberg-coady-57aab37/ Nov 05, 2025 30:26](https://creators.spotify.com/pod/profile/zoe-weisberg-coady/episodes/22--No-More-Small-Talk-Building-Real-Relationships-Naturally-Through-Networking-with-Wendy-Heilbut--Heilbut-LLP-e3ac82r)[![Image 4: Trailer: Not Perfect Networking Podcast](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/43126311/43126311-1743550975378-5ffac4e5471a1.jpg) #### 21. Why Every Founder and Thought Leader Needs a Podcast in 2025 (Not Perfect Podcast Network) Big announcement:I’m launching the Not Perfect Podcast Network— a curated network built for founders, thought leaders, and professionals who are ready to start their own podcasts without the stress or guesswork.Yep, on my birthday, I’m officially turning Not Perfect Networking into something even bigger.Over the past year, I’ve interviewed incredible CEOs, creatives, and entrepreneurs who’ve shared how real, unpolished networking opened doors and shaped their success. One thing they all have in common? They built powerful communities by showing up imperfectly and consistently.That’s what inspired me to launch this network — because podcasting is the new personal branding essential.In 2025, your podcast matters as much as your website or LinkedIn profile. It’s your owned platform— your voice, your authority, your story.And I want to make it simple for you to start.The Not Perfect Podcast Network brings together the

*[... truncated, 40,110 more characters]*

---

### From Montreal To Manhattan: Heylist's AI-Powered Push To Democratize Influencer Marketing
*1,355 words* | Source: **EXA** | [Link](https://www.netinfluencer.com/heylist-ai-powered-push-to-democratize-influencer-marketing/)

[Heylist](https://www.netinfluencer.com/heylist-vicky-boudreau/), a Montreal-based SaaS (Software as a Service) platform founded in January 2024, solves a critical gap in the influencer marketing space: connecting global brands with nano and micro-influencers (those with 50,000 followers or less) who have been largely overlooked by traditional influencer platforms. The company has built a technology that enables brands to find and collaborate with these smaller creators, who often generate significantly higher engagement rates despite their modest following sizes.

Founded by [Vicky Boudreau](https://www.netinfluencer.com/heylist-1-6-million-seed-funding/), who brings more than 15 years of experience in influencer marketing, Heylist automates the entire collaboration process from creator verification to analytics. After raising CA$1.6 million in February 2024 in an oversubscribed round backed by Accelia Capital, Investissement Québec, The51, and other investors, the platform has expanded rapidly with a 36% compounded monthly growth rate and a creator network that quadrupled in one year.

![Image 1](blob:http://localhost/e09ffcbfd52a89567a3c326cab6daf87)
Now, with its official launch into the U.S. market, Heylist is introducing its proprietary AI search technology to help brands discover precisely the right creators for their campaigns.

“For us, creators aren’t inventory, they’re partners,” says Vicky, CEO and co-founder. “This feature pushes the boundaries of a simplified experience and multiplies their opportunities. With AI Search, we’re offering a first-of-its-kind solution that makes a complex process simple. Both brands and creators gain efficiency and authenticity.”

![Image 2](blob:http://localhost/3ae4d04f916712e5394829daa66ef1f5)
**Democratizing Influencer Marketing: What It Means**
-----------------------------------------------------

What exactly does democratizing influencer marketing entail? For Heylist, it means creating a system where smaller creators can generate income through brand partnerships that were previously inaccessible to them. Simultaneously, it allows brands to run more genuine campaigns by connecting with creators whose audiences are highly engaged and trust their recommendations.

The platform’s approach focuses on making these connections accessible, efficient, and scalable. By automating the collaboration process in five steps: profile verification, recruitment and onboarding, centralized campaign management, real-time post tracking, and live audience analytics, Heylist removes barriers that previously made working with multiple smaller creators impractical for many brands.

Vicky’s experience co-founding [bicom](https://www.bicom.ca/), a PR and marketing agency with offices in Montreal, Toronto, and Paris , gave her insight into the untapped potential of nano-influencers. This perspective informed Heylist’s core mission of making influencer marketing more inclusive while maintaining the authenticity that makes it effective.

**AI Search: The Technology Behind the Mission**
------------------------------------------------

Central to Heylist’s U.S. expansion is its proprietary AI Search technology, developed in partnership with MILA, Montreal’s renowned AI research institute. This world-first feature allows brands to discover creators through natural language prompts rather than complex filter systems.

“Because our creators opt-in to the platform, we have access to their content” says Vicky. “Our AI engine lets us search by prompt, even with image recognition.”

![Image 3](blob:http://localhost/e09ffcbfd52a89567a3c326cab6daf87)
The practical applications extend beyond typical discovery methods. Brands can simply type in queries such as “Midwest moms with curly hair” or “vegan runners,” and the platform analyzes visual content and profiles to deliver relevant matches. The technology goes beyond typical hashtag or keyword searches by actually understanding the content itself.

“Even if there’s no hashtag mentioning hiking, AI can see that our creator went hiking last weekend and might be a good fit for a related brand,” Vicky explains.

In one case, Heylist used a client’s logo to identify creators already using their products without tagging the brand. “We described the logo and found 10 creators wearing their sweaters. They hadn’t mentioned the brand, but we knew they were fans,” Vicky says.

The latest version allows for more precise searching. “You can search for creators who love a specific brand in Vancouver or San Francisco, so we can narrow it down by cross filters,” she adds.

**Strategic Market Entry and Recognition**
------------------------------------------

Heylist’s entry into the American market follows successful pilot projects that achieved an average engagement rate of 10.3%, nearly double the platform’s overall average of 5.5%. These results have built confidence in their approach and business model.

“We first started executing campaigns in the U.S. for

*[... truncated, 4,641 more characters]*

---

### Vicky Boudreau: Empowering the Creator Economy with Heylist’s  — DISRUPTION MAGAZINE
*2,076 words* | Source: **EXA** | [Link](https://www.disruptionmagazine.ca/news/women-in-tech-vicky-boudreau)

Vicky Boudreau: Empowering the Creator Economy with Heylist’s — DISRUPTION MAGAZINE

===============

[0](https://www.disruptionmagazine.ca/cart)

[Skip to Content](https://www.disruptionmagazine.ca/news/women-in-tech-vicky-boudreau#page)

[![Image 1: DISRUPTION MAGAZINE](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1d3f9756-5326-4ddf-9a73-e6966b4ab450/Gold+%26+Silver+3d+2K+Thank+You+Followers+Facebook+Post.png?format=1500w)](https://www.disruptionmagazine.ca/)

 About Us 

[Our Team](https://www.disruptionmagazine.ca/our-team)

[News](https://www.disruptionmagazine.ca/news-1)

[Archive](https://www.disruptionmagazine.ca/archive)

[Resource Lists](https://www.disruptionmagazine.ca/resource-lists)

[Contact Us](https://www.disruptionmagazine.ca/contact-us)

[](https://www.linkedin.com/company/disruption-magazine-canada/)

[Subscribe](https://subscribepage.io/disruptionsubscription)

Open Menu Close Menu

[![Image 2: DISRUPTION MAGAZINE](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1d3f9756-5326-4ddf-9a73-e6966b4ab450/Gold+%26+Silver+3d+2K+Thank+You+Followers+Facebook+Post.png?format=1500w)](https://www.disruptionmagazine.ca/)

 About Us 

[Our Team](https://www.disruptionmagazine.ca/our-team)

[News](https://www.disruptionmagazine.ca/news-1)

[Archive](https://www.disruptionmagazine.ca/archive)

[Resource Lists](https://www.disruptionmagazine.ca/resource-lists)

[Contact Us](https://www.disruptionmagazine.ca/contact-us)

[](https://www.linkedin.com/company/disruption-magazine-canada/)

[Subscribe](https://subscribepage.io/disruptionsubscription)

Open Menu Close Menu

[Folder:About Us](https://www.disruptionmagazine.ca/about-us-1)

[News](https://www.disruptionmagazine.ca/news-1)

[Archive](https://www.disruptionmagazine.ca/archive)

[Resource Lists](https://www.disruptionmagazine.ca/resource-lists)

[Contact Us](https://www.disruptionmagazine.ca/contact-us)

[](https://www.linkedin.com/company/disruption-magazine-canada/)

[Subscribe](https://subscribepage.io/disruptionsubscription)

[Back](https://www.disruptionmagazine.ca/)

[Our Team](https://www.disruptionmagazine.ca/our-team)

Vicky

Boudreau:

Empowering

the

Creator

Economy

with

Heylist’s
==================================================================================

[Women in Tech](https://www.disruptionmagazine.ca/news/category/Women+in+Tech)

Oct 17

Written By [Sushmita](https://www.disruptionmagazine.ca/news?author=6679c5a34272e27e91ab4985)

[![Image 3](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/d2bc885a-5e04-4afe-a364-245456afd906/fd602d6b-873a-4def-8443-49ed9e8e0ca0-profile_picture-vicky.jpg)](https://www.linkedin.com/in/vicky-boudreau-14762b14/?locale=en_US)

#### tl;dr

*   Vicky Boudreau, CEO of Heylist, empowers creators to monetize content through a streamlined influencer marketing platform.

*   Heylist focuses on nano-influencers, enhancing collaboration with brands using AI-driven tools and community-building.

*   Vicky aims to scale Heylist internationally while fostering authentic brand-creator partnerships in the evolving influencer landscape.

[Vicky Boudreau](https://www.linkedin.com/in/vicky-boudreau-14762b14/en?originalSubdomain=ca), the dynamic CEO and Co-Founder of [Heylist](https://www.heylist.com/), is on a mission to revolutionize influencer marketing by empowering creators to monetize their content. With a career deeply rooted in public relations and marketing, Vicky’s entrepreneurial spirit has led her to establish two successful ventures, bicom and now Heylist, a platform that bridges the gap between brands and small creators.

### A Career in Innovation and Leadership

Vicky’s journey into entrepreneurship began after an internship that led her to co-found bicom, a Montreal-based communications and marketing firm. At bicom, she built a reputation for industry innovation, leading a team of over 40 professionals and helping brands navigate the evolving media landscape. Under her leadership, bicom flourished, with Vicky earning recognition as Arista’s Entrepreneur of the Year and being named among Canada’s Top 40 under 40 PR professionals.

As influencer marketing gained momentum, Vicky identified a growing opportunity for smaller creators. Realizing that the marketing industry was shifting towards more authentic, relatable content, she launched an internal initiative at bicom to explore influencer marketing. However, as campaigns grew in complexity, she saw the limitations of traditional tools like spreadsheets in managing these collaborations. This challenge inspired her next venture: Heylist.

### The Birth of Heylist

Heylist was born out of Vicky’s vision to simplify influencer marketing for both creators and brands. She partnered with software engineer Alex Borgia and creative strategist Nico LeBlanc to develop a custom platform that automates influencer campaign management while fostering a vibrant community of creators. The pla

*[... truncated, 28,209 more characters]*

---

### Press
*335 words* | Source: **GOOGLE** | [Link](https://www.heylist.com/press)

[![Image 1: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/6908fc9062f1534b6ff8783d_From%20Montreal%20To%20Manhattan.jpg) #### Net Influencer ### From Montreal To Manhattan: Heylist’s AI-Powered Push To Democratize Influencer Marketing Read article](https://www.netinfluencer.com/heylist-ai-powered-push-to-democratize-influencer-marketing/)

[![Image 2: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/681a551f70e38a6309a59d14_Webby.png) #### Cision ### Heylist wins Best Marketing & Content Management App & Software at the 2025 Webby Awards Read article](https://www.theglobeandmail.com/investing/markets/stocks/NYT/pressreleases/32011597/29th-annual-webby-awards/)

[![Image 3: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/681a4d13421860814c010460_maxresdefault.webp) #### Zing ### Now playing Unlocking the Power of Nano-Influencers: With Vicky Boudreau Read article](https://www.youtube.com/watch?v=f6KEJGO8rkI)

[![Image 4: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/681a4afc639e705f5f4967f9_1745339073378.jpg) #### The Not Perfect Networking Podcast ### The Business Karma of Connection with Vicky Boudreau Read article](https://open.spotify.com/show/4LLeyFsua1ExFupdIQupIy)

[![Image 5: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/681a4a326ac7d4c308b816b7_The-future-of-user-generated-content-UGC-and-how-to-get-involved-copy.jpg) #### GritDaily ### 5 Reasons the Future of UGC Is Bright, and How to Get Involved Read article](https://gritdaily.com/reasons-future-of-ugc-is-bright-how-to-get-involved/)

[![Image 6: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d434691b8b11d8ff136ae7_how-to-master-the-digital-marketing-dynamics-in-2025.jpg) #### GritDaily ### Content Is Queen: How to Master the Digital Marketing Dynamics in 2025 Read article](https://gritdaily.com/content-is-queen-master-digital-marketing-dynamics/)

[![Image 7: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d42e6fa166ced999873939_Vicky_Boudreau__2_.webp) #### Carta ### How a Canadian founder's curiosity led to a surprise term sheet Read article](https://carta.com/blog/fundraising-files-heylist/)

[![Image 8: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d42df900e6b7904f319758_pexels-cristian-rojas-7261084.jpg) #### GritDaily ### Why the Creator Economy Needs a New Impulse Read article](https://gritdaily.com/why-the-creator-economy-needs-a-new-impulse/)

[![Image 9: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44c907d66df7d10e4ade2_yura-fresh-xezXEh_fIeU-unsplash-1536x1024.jpg) #### Muskoka ### Study Reveals: Everyday Influencers Driving The Decisions Of Canadian Consumers Read article](https://muskoka411.com/study-reveals-everyday-influencers-driving-the-decisions-of-canadian-consumers/)

[![Image 10: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/681a6115764dcdf8d525e245_CleanShot%202025-05-06%20at%2015.20.36%402x.png) #### Retail Insider ### Everyday influencers driving the decisions of Canadian consumers Read article](https://retail-insider.com/bulletin/2024/12/everyday-influencers-driving-the-decisions-of-canadian-consumers/)

[![Image 11: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44dd6c3e1c32d44529cab_Frame%20768.png) #### Cision ### Étude : Les Influenceurs du quotidien au cœur des décisions des consommateurs canadiens Read article](https://www.newswire.ca/fr/news-releases/etude-les-influenceurs-du-quotidien-au-coeur-des-decisions-des-consommateurs-canadiens-807437960.html)

[![Image 12: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44c60fbbf0829e1130e29_VickyBoudreau.png) #### Disruption ### Vicky Boudreau: Empowering the Creator Economy with Heylist’s Read article](https://www.disruptionmagazine.ca/news/women-in-tech-vicky-boudreau)

[![Image 13: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44bc8eb480bf69abe358e_Heylist-team.png) #### The 51 ### Heylist: Democratizing Influencer Marketing and Enabling Economic Opportunities for Creators Read article](https://the51.com/51blog/heylist-democratizing-influencer-marketing)

[![Image 14: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44af3d5886a22cbf729c5_Heylist-thumbnail-1.png) #### Zú ### Interview with Vicky Boudreau, CEO & Co-Founder of Heylist Read article](https://zumtl.com/en/article-en/interview-with-vicky-boudreau/)

[![Image 15: Blog Image](https://cdn.prod.website-files.com/655e6166fecddb5908ff49d2/67d44ab6b47504fa041a0e58_Heylist_Inc__Heylist_Secures__1_6M_in_Funding_to_Make_Influencer.jpg) #### Betakit ### As Collision kicks off, four Canadian tech startups unveil new funding Read article](https://betakit.com/as-collision-kicks-off-four-canadian-tech-startups-unveil-new-funding/)

[![Image 16: Blog Image](h

*[... truncated, 691 more characters]*

---

### FounderSense
*2,815 words* | Source: **GOOGLE** | [Link](https://podcasts.apple.com/us/podcast/foundersense/id1801710872)

FounderSense - Podcast - Apple Podcasts

===============

[](https://podcasts.apple.com/us/new)

*   [Home](https://podcasts.apple.com/us/home)
*   [New](https://podcasts.apple.com/us/new)
*   [Top Charts](https://podcasts.apple.com/us/charts)
*   [Search](https://podcasts.apple.com/us/search)

Open in Podcasts

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Sign In

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

![Image 5: Validate or Fail: A Founder’s Warning - Dr Bill, Founder of Nutriselect AI.](https://podcasts.apple.com/assets/artwork/1x1.gif)

FounderSense
============

DigitSense

*    5.0 (4) 
*   ENTREPRENEURSHIP
*   UPDATED WEEKLY

Ever wondered what it takes to build and scale a successful business? FounderSense brings you unfiltered conversations with founders and digital leaders who’ve been there, and done that. Get inside the minds of founders and digital leaders as they share real stories, hard-won lessons, and actionable strategies to help you build and scale smarter. Tune in and get inspired to scale smarter, innovate faster, and build with confidence.

MORE

FounderSense
============

Ever wondered what it takes to build and scale a successful business? FounderSense brings you unfiltered conversations with founders and digital leaders who’ve been there, and done that. Get inside the minds of founders and digital leaders as they share real stories, hard-won lessons, and actionable strategies to help you build and scale smarter. Tune in and get inspired to scale smarter, innovate faster, and build with confidence.

 Free Episode 

Follow

Episodes
--------

1.   [![Image 6: Validate or Fail: A Founder’s Warning - Dr Bill, Founder of Nutriselect AI.](https://podcasts.apple.com/assets/artwork/1x1.gif) NOV 25 ### Leading in the Age of AI: Systems, Culture, and Change AI isn’t a technology problem; it’s a leadership one. In this episode of FounderSense, Martin Wilson and Scott Varho, co-founders of Olo Solutions, unpack what it really takes to lead transformation in the age of AI. They explain why most organizations struggle to scale beyond pilots, how leadership culture defines AI outcomes, and why real transformation begins with systems thinking, psychological safety, and trust. From the ARC Framework (Ambition, Risk, Capability, Capacity) to their insights on product-led transformation, Martin and Scott share how today’s best leaders are rethinking governance, talent, and communication for the AI era. This episode is a playbook for leaders who want to build organizations that learn fast, adapt faster, and stay human as technology accelerates. 42 min](https://podcasts.apple.com/us/podcast/leading-in-the-age-of-ai-systems-culture-and-change/id1801710872?i=1000738418055) 
2.   [![Image 7: Validate or Fail: A Founder’s Warning - Dr Bill, Founder of Nutriselect AI.](https://podcasts.apple.com/assets/artwork/1x1.gif) OCT 29 ### Redefining Leadership: A Female Founder’s Journey Through Tech and Influence - Vicky Boudreau, Co-founder and CEO of Heylist. What does leadership look like when you’re building in a space still dominated by men? In this episode, Vicky Boudreau, co-founder and CEO of Heylist, shares what it means to lead, grow, and challenge the status quo as a female founder in tech. With over 20 years of experience building and scaling companies, including growing her first agency from a two-person startup into an international team working with brands like Gap and Banana Republic, Vicky brings a wealth of real-world leadership insight. She shares how she’s bridging human connection and technology, why visibility matters for women in leadership, and how empathy, trust, and authenticity can become powerful tools for change. This is a conversation about redefining leadership and why the future of influence is more inclusive than ever. FounderSense is created by DigitSense Limited. Did you know 80% of enterprises and scaleups are looking to embrace AI, but only 24% are ready? If you're looking to bring AI into your business, Grab our FREE AI Readiness Checklist, the same one we use with our clients, to kickstart your AI journey. Download it now at: https://bit.ly/DigitSenseAIReadinessChecklist 37 min](https://podcasts.apple.com/us/podcast/redefining-leadership-a-female-founders-journey/id1801710872?i=1000734089861) 
3.   [![Image 8: Validate or Fail: A Founder’s Warning - Dr Bill, Founder of Nutriselect AI.](https://podcasts.apple.com/assets/artwork/1x1.gif) OCT 13 ### Mindful Leadership: A Chief Digital Officer’s Guide to Scaling Without Burnout - Johnny Russo Scaling is where most teams break, deadlines tighten, communication frays, and even your best people risk disengagement. In this episode, we explore mindful leadership with Johnny Russo, former Chief Digital Officer at Lamour and a digital leader who has overseen over $1 billion of e-commerce revenue. Johnny shares how to turn communication, trust, and em

*[... truncated, 29,781 more characters]*

---

### Heylist Secures $1.6M in Funding to Make Influencer Marketing Accessible
*2,817 words* | Source: **GOOGLE** | [Link](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html)

Heylist Secures $1.6M in Funding to Make Influencer Marketing Accessible

===============

[Close menu](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-0)

*   [News](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-news)
*   [Products](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-products)
*   [Contact](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-contact)

[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-default)
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-news)
*   _3_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-1)News in Focus
*   _5_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-2)Business
*   _5_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-3)Science & Tech
*   _5_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-4)Lifestyle & Health
*   _1_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-5)Policy & Public Interest
*   _1_[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-6)People & Culture
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-products)
*   [Explore Our Platform](https://www.newswire.ca/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.newswire.ca/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.newswire.ca/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.newswire.ca/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.newswire.ca/multichannel-amplification/ "Amplify Content ")
*   [IR](https://www.newswire.ca/products/investor-relations/ "IR")
*   [All Products](https://www.newswire.ca/products/all-products/ "All Products")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html#mm-panel-contact)
*   [Sign Up](https://www.newswire.ca/contact-us "Sign Up")
*   [Request a Demo](https://www.newswire.ca/request-a-demo/ "Request a Demo")
*   [Editorial Bureaus](https://www.newswire.ca/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https://www.newswire.ca/contact-us/partnerships "Partnerships")
*   [General Enquiries](https://www.newswire.ca/contact-us/general-enquiries/ "General Enquiries")
*   [Media Enquiries](https://www.newswire.ca/contact-us/media-enquir

*[... truncated, 68,420 more characters]*

---

### Heylist: The Platform Connecting Major Brands With The Right Nano Influencers
*1,365 words* | Source: **GOOGLE** | [Link](https://www.netinfluencer.com/heylist-vicky-boudreau/)

![Image 1: Heylist: The Platform Connecting Major Brands With The Right Nano Influencers](blob:http://localhost/1e4f3e66c4cb1600be14d5dec524bfd9)
[Vicky Boudreau](https://www.linkedin.com/in/vicky-boudreau-14762b14/) noticed a significant gap in the market: connecting major brands with content creators with fewer than 10,000 followers. As CEO and co-founder of [Heylist](https://www.netinfluencer.com/heylist-1-6-million-seed-funding/), she’s developed a platform that connects these authentic voices with companies seeking genuine brand advocates.

**Building on PR Expertise and Community**
------------------------------------------

Vicky’s first venture, [bicom](http://www.bicom.ca/), a PR and marketing firm operating in Montreal, Toronto, Paris, and New York, provided crucial insights into managing influencer campaigns. The shift from PR to a tech startup presented unexpected challenges.

“It’s my second business, so I thought this was going to be a walk in the park,” Vicky says. “I had two to three days to decide, and now I have two to three minutes. With all the algorithms, everything changed so fast that you must always be on the tip of your toes.”

Heylist emerged from practical challenges in campaign management. “We tested many tools; some were doing the research, others tracking and reporting, but we couldn’t find one solution that would do what we’re doing in Excel sheet from A to Z,” Vicky explains. “That was one of the first signals, and the other one was that we started as a pilot project to activate what we called early year on [nano Influencers](https://www.netinfluencer.com/nano-vs-micro-influencer/).”

Heylist distinguishes itself through its community-building approach. “Try to call someone who doesn’t know you have their number; they’re not likely to respond and want to collaborate with you,” Vicky notes. “We are more of a community. People register, and they give us access to their data freely.”

The platform reflects Vicky’s marketing expertise. “We’re marketers ourselves, so we’re building what we would have loved to have access to,” she explains. Developing a product from a user’s perspective differs greatly from many people surfing on the influencer marketing trend and the market opportunity.”

She highlights Heylist’s practicality: “Sometimes what you see is super techy and very deep, but it doesn’t make sense for the user, or the product is beautiful, but it’s not useful.”

**Discovering the Power of Nano-Influencers**
---------------------------------------------

The platform’s focus on [smaller creators](https://www.netinfluencer.com/hopelab-report-lgbtq-youth-strong-relationships-with-smaller-creators/) yielded unexpected results. “At the beginning, I was telling them we’re going raw, the pictures will be so-so, and there will be typos. But the pictures were beautiful, there were no mistakes, and the content was amazing,” Vicky shares. “Early on, people saw that as a great way to get the [UGC](https://www.netinfluencer.com/the-ultimate-creator-guide-2024/) with authentic voices and feedback.”

This success demonstrated the value of smaller creators. “There are more and more people who see the value that they’re bringing to brands, and many clients are super interested in talking to them, but they’re harder to find,” Vicky says. “They’re not necessarily very used to doing that, so we’re helping them with the platform and all the steps to guide them in creating their content.”

Different influencer tiers serve distinct purposes. “As a marketer, I like to say that I believe in all [types of influencers](https://www.netinfluencer.com/10-types-of-influencers/) if my clients can afford it,” Vicky notes. “I still suggest that you have one big spokesperson, experts, like [dermatologists](https://www.netinfluencer.com/clinique-forms-derm-creator-council/) for skin care, and regular product users. Nano influencers are part of the marketing mix.”

![Image 2: Heylist: The Platform Connecting Major Brands With The Right Nano Influencers](blob:http://localhost/1e4f3e66c4cb1600be14d5dec524bfd9)
_Left to right: Heylist founders Alex Borgia (CTO), Vicky Boudreau, Nico LeBlanc (CXO)_

The effectiveness varies by product category. “Celebrity influencers are very aspirational,” Vicky explains. “But if I have a zit, I want to know what my best friend used as a product to fix it. Tech – you don’t want to know what the tech journalist thinks about the new iPhone. You want to know if the battery is going to last.”

Market maturity affects nano influencer impact. “There are some markets [U.S., UK, France] where influencer marketing is more mature,” Vicky observes. “I see a lot of opportunities in North Africa, Morocco, and Tunisia, where the big brands are starting to invest heavily and where the women are empowering themselves by becoming influencers. There will always be smaller creators somewhere rising, but today, some markets are already more mature.”

**Streamlining Creator Campaigns**
-------------

*[... truncated, 4,815 more characters]*

---

### Women in Technology — DISRUPTION MAGAZINE
*749 words* | Source: **GOOGLE** | [Link](https://disruptionmagazine.digital/women-in-technology)

[![Image 1: Breaking Boundaries in HealthTech: Meet Tannis Sigurdson, Founder &amp; CEO of Epic Heights](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1761260865944-9FUDFE09FRVCLBQ416AW/Disruption+Blog+-+Cover+Images+16x9+%285%29.png?format=500w)](https://disruptionmagazine.digital/news/breaking-boundaries-in-healthtech-meet-tannissigurdson-founder-ceo-of-epicheights)

Tannis Sigurdson is redefining what it means to lead and scale in healthcare innovation. As Founder & CEO of Epic Heights, she’s on a mission to fast-track the commercialization of life-changing health technologies. Drawing on 20+ years with global leaders like Philips, Idexx, and Alcon, Tannis helps startups bridge the gap between breakthrough science and real-world impact, proving that in healthcare, disruption isn’t optional; it’s essential.

[![Image 2: Using 3D scanning to fix fashion’s fit problem](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1759953024797-AORN2IB7HY3MDJXYFYL9/Disruption+Blog+-+Cover+Images+16x9.png?format=500w)](https://disruptionmagazine.digital/news/using-3d-scanning-to-fix-fashions-fit-problem)

Janice Tam is redefining fashion tech by tackling one of the industry’s biggest challenges, fit. Through True to Form’s 3D body-scanning and size-prediction technology, she’s helping brands cut returns, boost confidence, and make online shopping more sustainable. Her journey proves that when founders listen, adapt, and lead with empathy, innovation truly fits everyone.

[![Image 3: Leading Transformation with Curiosity: The Vivid Vision of Jenny Lemieux](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1744129414926-O43TGK345BYFKR3UQ5AA/Disruption%2BBlog%2B-%2BCover%2BImages%2B%252816%2529.jpg?format=500w)](https://disruptionmagazine.digital/news/leading-transformation-with-curiosity-the-vivid-vision-of-jenny-lemieux)

Jenny Lemieux is reshaping agriculture with AI-powered vision, purpose-driven leadership, and a fearless belief in learning through imperfection.

[![Image 4: Starting Over at 40: My Journey from Academia to Entrepreneurship](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1744037422295-29XC0Y8668VZJUDRE7HS/My+Journey+to+Entrepreneurship.png?format=500w)](https://disruptionmagazine.digital/news/my-journey-from-academia-to-entrepreneurship)

At 40, Dr. Latchmi Raghunanan faced a mid-life crisis—but instead of staying stuck, she founded Maman Biomedical to revolutionize fertility care.

[![Image 5: Breaking Barriers: How April Hicke Is Changing the Face of Tech Recruitment](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1741973614624-K12O74Q7OFVQQ4AJ1E00/Disruption%2BBlog%2B-%2BCover%2BImages%2B%25283%2529.jpg?format=500w)](https://disruptionmagazine.digital/news/breaking-barriers-how-april-hicke-is-changing-the-face-of-tech-recruitment)

What happens when persistence meets purpose? For April Hicke, it led to co-founding Toast—a company transforming how women are hired & empowered in tech.

[![Image 6: Empowering Beauty Entrepreneurship: A Journey with Blanka's Founder](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1740432495364-XO6E3ZY1Z4VVC148FG4S/Kaylee+Lieffers+-+Blanka+CEO+%26+Founder.png?format=500w)](https://disruptionmagazine.digital/news/empowering-beauty-entrepreneurship-blanka-founder)

Kaylee Lieffers shares her journey of building Blanka, empowering beauty entrepreneurs, navigating challenges, and redefining leadership in the tech industry.

[![Image 7: Vicky Boudreau: Empowering the Creator Economy with Heylist’s ](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1744222590441-BUH32RJCYXOPIXJFOUDD/Disruption+Blog+-+Cover+Images+%2817%29.png)](https://disruptionmagazine.digital/news/women-in-tech-vicky-boudreau)

Vicky Boudreau, co-founder of Heylist, is transforming influencer marketing by helping small creators monetize their content through streamlined tools.

[![Image 8: Purvaja Soochit: Driving Innovation in AI-Driven Procurement](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1744223655524-FKHP8AE55J4CN90WNGV9/Disruption+Blog+-+Cover+Images+%2817%29.png)](https://disruptionmagazine.digital/news/women-in-tech-purvaja-soochit)

Purvaja Soochit, CEO of Binoloop Inc., is transforming procurement with AI, reducing assessment time by 80% for various industries.

[![Image 9: Silvana Huaman: Driving Innovation in Light Electric Vehicle Lifecycle Management](https://images.squarespace-cdn.com/content/v1/623cfdd46e287760cf5e5d72/1744225051952-KTFG5KR656TAT5323W9J/Disruption%2BBlog%2B-%2BCover%2BImages%2B%252819%2529.jpg)](https://disruptionmagazine.digital/news/women-in-tech-silvana-huaman)

FTEX is revolutionizing the light electric vehicle industry with software that enhances customer engagement and lifecycle management services.

[![Image 10: Jennifer Schell: Transforming Wealth Management through Behavioral Fina

*[... truncated, 6,594 more characters]*

---

---

## 🎬 YouTube Videos

- **[Les Audacieux: Vicky Boudreau, directrice générale de BICOM Communications](https://www.youtube.com/watch?v=YaLwAJNh6Gc)**
  - Channel: Inspiro Média
  - Date: 2013-11-20

- **[Entrevue avec Vicky Boudreau, CEO &amp; Cofondatrice de Heylist](https://www.youtube.com/watch?v=yhq5ZTQHgH0)**
  - Channel: Zú
  - Date: 2024-09-04

- **[Bicom: Vicky Boudreau - Conseils aux candidats](https://www.youtube.com/watch?v=tOXaPYM0nIk)**
  - Channel: Neos
  - Date: 2017-08-30

- **[Les Divas du Divan - Vicky Boudreau](https://www.youtube.com/watch?v=LzXRtU_xlqA)**
  - Channel: The Vocalist Magazine - TV
  - Date: 2024-05-19

- **[S03-E01 Vicky Boudreau : La définition du temps](https://www.youtube.com/watch?v=nOYC4gT1dws)**
  - Channel: Entre 2 brassées de Maman en affaires
  - Date: 2023-03-15

- **[S03-E01 Vicky Boudreau, Cheffe de la direction et partenaire fondatrice de Bicom](https://www.youtube.com/watch?v=yinp3HIavtc)**
  - Channel: Entre 2 brassées de Maman en affaires
  - Date: 2023-03-15

- **[Découvertes pour entrepreneur•es - Les bases de la nano-influence - Vicky Boudreau](https://www.youtube.com/watch?v=KUG00X4L-Dg)**
  - Channel: alias entrepreneur•e
  - Date: 2023-08-04

- **[Démystifier les RP et le marketing d’influence avec Vicky Boudreau et Marie-Noelle Hamelin - #49](https://www.youtube.com/watch?v=5tdqEd8dqkI)**
  - Channel: hypercroissance
  - Date: 2022-10-03

- **[Extrait #49 avec Vicky Boudreau et Marie-Noelle Hamelin de bicom](https://www.youtube.com/watch?v=wGqmNuR0Bl0)**
  - Channel: hypercroissance
  - Date: 2022-10-06

- **[SaaSpasse Conf &#39;25 : Vicky Boudreau (speaker)](https://www.youtube.com/watch?v=amjLVxutvPM)**
  - Channel: SaaSpasse
  - Date: 2025-08-11

---

## 🔎 Press & Mentions

- **[Press](https://www.heylist.com/press)**
  - Source: heylist.com
  - *The Not Perfect Networking Podcast. The Business Karma of Connection with ... Vicky Boudreau: Empowering the Creator Economy with Heylist's. Read arti...*

- **[FounderSense - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/foundersense/id1801710872)**
  - Source: podcasts.apple.com
  - *Nov 24, 2025 ... Listen to DigitSense's FounderSense podcast on Apple Podcasts ... Vicky Boudreau, Co-founder and CEO of Heylist. What does leadership...*

- **[Heylist Secures $1.6M in Funding to Make Influencer Marketing ...](https://www.newswire.ca/news-releases/heylist-secures-1-6m-in-funding-to-make-influencer-marketing-accessible-801065350.html)**
  - Source: newswire.ca
  - *Jun 18, 2024 ... Radio & Podcast · Television · Entertainment & Media Overview · View ... Led by the distinguished entrepreneur Vicky Boudreau, Heylis...*

- **[Heylist: The Platform Connecting Major Brands With The Right Nano ...](https://www.netinfluencer.com/heylist-vicky-boudreau/)**
  - Source: netinfluencer.com
  - *Nov 4, 2024 ... ... Heylist founders Alex Borgia (CTO), Vicky Boudreau, Nico LeBlanc (CXO). The effectiveness varies by product category. “Celebrity i...*

- **[Women in Technology — DISRUPTION MAGAZINE](https://disruptionmagazine.digital/women-in-technology)**
  - Source: disruptionmagazine.digital
  - *Vicky Boudreau, co-founder of Heylist, is transforming influencer marketing by helping small creators monetize their content through streamlined tools...*

- **[From Montreal To Manhattan: Heylist's AI-Powered Push To ...](https://www.netinfluencer.com/heylist-ai-powered-push-to-democratize-influencer-marketing/)**
  - Source: netinfluencer.com
  - *Nov 3, 2025 ... Founded by Vicky Boudreau, who brings more than 15 years of experience in influencer marketing, Heylist automates the entire collabora...*

- **[Montreal's Heylist Launches AI Search in the U.S. Creator Economy ...](https://finance.yahoo.com/news/montreals-heylist-launches-ai-search-112200115.html)**
  - Source: finance.yahoo.com
  - *Oct 2, 2025 ... Podcasts · Videos · RSS · Jobs · Help · World Cup · More news. New on Yahoo ... Vicky Boudreau, CEO and co-founder of Heylist. "With A...*

- **[Vicky Boudreau (Heylist, bicom) nommée aux prix « Marcomms ...](https://isarta.com/infos/vicky-boudreau-heylist-bicom-nommee-aux-prix-marcomms-most-influential-2024-de-the-pr-net/)**
  - Source: isarta.com
  - *Nov 18, 2024 ... Podcasts · EMPLOIS · FORMATIONS · logo image Emplois / Formations. Vicky Boudreau (Heylist, bicom) nommée aux prix « Marcomms' Most I...*

- **[As Collision kicks off, four Canadian tech startups unveil new ...](https://betakit.com/as-collision-kicks-off-four-canadian-tech-startups-unveil-new-funding/)**
  - Source: betakit.com
  - *Jun 18, 2024 ... Founded in 2022 by CEO Vicky Boudreau, chief experience officer Nicolas LeBlanc, and CTO Alexandre Borgia, Heylist operates a marketp...*

- **[Interview with Vicky Boudreau, CEO & Co-Founder of Heylist - zu](https://zumtl.com/en/article-en/interview-with-vicky-boudreau/)**
  - Source: zumtl.com
  - *Interview with Vicky Boudreau, CEO & Co-Founder of Heylist 4 Sep, 2024 · · 1. Why rely on nano-influencers? · 2. What's the most valuable piece of adv...*

---

*Generated by Founder Scraper*
