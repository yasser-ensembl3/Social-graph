# Sophie Reis

## Position actuelle

**Titre** : Fondatrice, autrice et conférencière
**Entreprise** : Un cancer en cadeau et BB Jetlag, Le Guide des parents voyageurs
**Durée dans le rôle** : 9 years 5 months in role
**Durée dans l'entreprise** : 9 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Un cancer en cadeau est un projet multiplateforme ayant pour mission d'inspirer et outiller les personnes atteintes d'un cancer et leurs proches à passer à travers cette épreuve avec douceur et vitalité.

Le livre best-seller "Un cancer en cadeau : apprendre, comprendre et s'outiller pour agir" (Trécarré, 2023) est LE guide de référence le plus complet pour comprendre et prendre part à l'action. Disponible mondialement numérique et audio (Audible, Apple). Version papier au Canada et en Europe. uncancerencadeau.com

"Le Guide des parents voyageurs : s'inspirer, s'informer, s'équiper, 0-12 ans" est le guide le plus complet en matière de voyage avec de jeunes enfants dans la francophonie (best-seller). Publié en octobre 2018 aux éditions Trécarré (Groupe Librex) et réédité en 2024. Distribué au Canada et en Europe (audio, papier, numérique). bbjetlag.com

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAEkas0BFCVvvziDYY4Flo2RdEk-CMyxUJM/
**Connexions partagées** : 71


---

# Sophie Reis

## Position actuelle

**Entreprise** : adn | conférencier.e.s

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Sophie Reis
*adn | conférencier.e.s*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Sophie Reis | adn conférenciers](https://en.adn-conferenciers.com/conferenciers-sophie-reis)
- Category: article

### [Sophie Frères @LiSA. Disrupting retail industry with next gen shoppertainment SaaS](https://saas.group/podcasts/saas-unbound-interview-sophie-freres-lisa/)
*2024-06-28*
- Category: podcast

### [](https://digitalswitzerland.com/author/sophie/)
- Category: article

### [Impact Interview: Sophie Lane — Reconsidered](https://www.reconsidered.co/interviews/sophie-lane)
*2024-05-01*
- Category: article

### [Blogcast #31 Sophie Lee: Electric Peach Storytelling](https://tricres.com/blog/blogcast-31-sophie-lee-electric-peach-storytelling/)
*2024-04-24*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[adn speakers: International Talent Agency](https://en.adn-conferenciers.com/)**
  - Source: en.adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem ... Alongside his role at Deutsche Bank, Lucas joined the French-Canadian agency adn | conférenc...*

- **[ÉTHIQUE ET RESPONSABILITÉ SOCIALE | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/confiance-et-ethique)**
  - Source: adn-conferenciers.com
  - *LES MEILLEUR.E.S CONFÉRENCIER.E.S QUI VOUS AIDENT À RENFORCER VOTRE ÉTHIQUE ... DÉCOUVREZ TOUTES LES CONFÉRENCES DE SOPHIE REIS SUR L'ÉTHIQUE ET LA .....*

- **[Sandrine Rastello | Journaliste, rédactrice, modératrice ...](https://www.adn-conferenciers.com/conferenciers-sandrine-rastello)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger ... J'ai eu la chance de collaborer avec Sandrine Rastello de adn | conférencier...*

- **[APPARITIONS ET CÉLÉBRITÉS | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/apparitions-et-endossement-de-celebrites)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... DÉCOUVREZ LES MEILLEUR.E.S CONFÉRENCIER.E.S CÉLÈBRES ET INFLUENTS ...*

- **[Contenus clé en main | adn conférenciers](https://www.adn-conferenciers.com/contenus-cle-en-main)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia ... SOURCING, RECHERCHE, BOOKING - notre expertise et notre réseau unique de conférenci...*

- **[ARTS, CULTURE ET DIVERTISSEMENT | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/arts-et-culture)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... DÉCOUVREZ LES MEILLEUR.E.S CONFÉRENCIER.E.S INSPIRANT.E.S QUI METT...*

- **[DIVERSITÉ, ÉQUITÉ ET INCLUSION | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/diversite-equite-et-inclusion)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... DÉCOUVREZ LES MEILLEUR.E.S CONFÉRENCIER.E.S EN DIVERSITÉ, ÉQUITÉ E...*

- **[ENJEUX MONDIAUX ET GÉOPOLITIQUE | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/enjeux-mondiaux)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... E.S CONFÉRENCIER.E.S POUR COMPRENDRE LES DYNAMIQUES MONDIALES. Ani...*

- **[ÉCONOMIE ET FINANCE | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/economie-et-finance)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... DÉCOUVREZ LES MEILLEUR.E.S CONFÉRENCIER.E.S EN ÉCONOMIE ET FINANCE...*

- **[SCIENCES ET TECHNOLOGIE | adn-conférencier.e.s](https://www.adn-conferenciers.com/themes/sciences-technologie-et-stem)**
  - Source: adn-conferenciers.com
  - *Sophie Reis · Stéphane Grenier · Steven Van Belleghem · Sylvia Bréger · Valérie ... DÉCOUVREZ SANDRINE RASTELLO, QUI ANIME DES INTERVENTIONS VARIÉES, ...*

---

*Generated by Founder Scraper*
