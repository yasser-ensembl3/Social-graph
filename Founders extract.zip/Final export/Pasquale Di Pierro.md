# Pasquale Di Pierro

## Position actuelle

**Titre** : President & Founder
**Entreprise** : FONEX data systems inc.
**Durée dans le rôle** : 35 years 11 months in role
**Durée dans l'entreprise** : 35 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Telecommunications

## Description du rôle

FONEX is a telecommunications equipment provider focused on relieving the bandwidth bottleneck ILECs/CLECs/MSOs/CableCos and other service providers face in delivering scalable broadband services to their residential, SMB, and Enterprise customers. We work in partnership with our customers to develop solutions that enable new services, new revenues, cost reduction through IP convergence, and sweating the assets of their existing investment to maximize their overall return on investment and bottom line impact.

Our equipment solutions are grouped into four main areas of focus:
- Carrier Ethernet, Ethernet over multiple transport mediums
- Fiber optic networking 
- Multi-protocol/services transport 
- Broadband in the access network and Home Networking

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAE3vXABRHtemp05RDF1TdkgmPdsHj5Wx0E/
**Connexions partagées** : 15


---

# Pasquale Di Pierro

## Position actuelle

**Entreprise** : FONEX Data Systems Inc

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pasquale Di Pierro

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400235863336566787 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEsA8kNwoqf3Q/feedshare-shrink_800/B4EZrLD8K1HoAg-/0/1764343403183?e=1766620800&v=beta&t=C5HwBm-_IiH4yF5FxtcYGV2UldRBQ_KaEKgbSk31Xj0 | Congratulations to the Engine Team and the Faculty of Engineering for organizing this wonderful event to recognize the accomplishments and awards of your students and professors in the pursuit of technological innovation as a foundation for entrepreneurship. Bravo! | 8 | 0 | 0 | 1w | Post | Pasquale Di Pierro | https://www.linkedin.com/in/pasquale-di-pierro-040a136 | https://linkedin.com/in/pasquale-di-pierro-040a136 | 2025-12-08T05:09:59.360Z |  | 2025-11-28T18:15:19.553Z | https://www.linkedin.com/feed/update/urn:li:activity:7400192600798040064/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7350626071316176897 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGUGFaD0xVe6w/feedshare-shrink_800/feedshare-shrink_800/0/1731486167881?e=1766620800&v=beta&t=ImVmwJTtFCvnIyZKMxO-j6MWu67lAjinK4KabQ4W6ow | FONEX offers IPInfusion solutions for datacenter capacity upgrades along with our full line of LambdaGain 400G optical interfaces and optical patch cords to complete the implementation. Ask us for a proposal to increase capacity, reduce power consumption and rack real estate. 
#fonex #lambdagain #datacenter | 32 | 1 | 3 | 1yr | Pasquale Di Pierro reposted this | Pasquale Di Pierro | https://www.linkedin.com/in/pasquale-di-pierro-040a136 | https://linkedin.com/in/pasquale-di-pierro-040a136 | 2025-12-08T05:10:04.447Z |  | 2025-07-14T20:43:43.430Z | https://www.linkedin.com/feed/update/urn:li:activity:7262494436691968003/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7347292915515158528 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGGMMjjWq37ZA/image-shrink_800/B4EZfQRB0PHsAc-/0/1751545815010?e=1765778400&v=beta&t=Dx4RKk_lvFdtcvt8lP9Zua_vw1NzHd1TJSBDnEWKfi4 | OPEN PON is feasible, reliable and cost effective with Ciena’s microOLT SFP. It’s time to evaluate this alternative to chassis based OLT solutions. Ask how it’s done. | 14 | 0 | 2 | 5mo | Post | Pasquale Di Pierro | https://www.linkedin.com/in/pasquale-di-pierro-040a136 | https://linkedin.com/in/pasquale-di-pierro-040a136 | 2025-12-08T05:10:04.448Z |  | 2025-07-05T15:58:57.160Z | https://www.linkedin.com/feed/update/urn:li:activity:7346515619497820161/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7333506966566117378 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEAA4RcaLyp-w/image-shrink_800/B4EZcR6yx5HcAc-/0/1748352316063?e=1765778400&v=beta&t=PJemYz4vreCls7hLS1vGVuCLhYhPHdtWso0zqH0k6Rs | Avec plus de 20 ans d’expérience dans le déploiement de solutions IPoDWDM, fiez vous à FONEX et LambdaGain pour répondre à vous besoins de décongestionnement de routes fibre-optiques et de transport haute vitesse à coûts optimisés. | 24 | 0 | 0 | 6mo | Post | Pasquale Di Pierro | https://www.linkedin.com/in/pasquale-di-pierro-040a136 | https://linkedin.com/in/pasquale-di-pierro-040a136 | 2025-12-08T05:10:04.451Z |  | 2025-05-28T14:58:30.800Z | https://www.linkedin.com/feed/update/urn:li:activity:7333121125268312065/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7333174371194208257 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFrOPRCINjBIw/image-shrink_800/B4EZcR6yx6H0Ak-/0/1748352316014?e=1765778400&v=beta&t=NPY1n2A9d-iHDtms_ze24uJD7YbAQgOwB9J7fSk1VOw | With more than 20 years experience implementing IPoDWDM solutions in Europe and North America, count on FONEX expertise and LambdaGain reliability for your cost-optimized fiber network de-congestion and transport projects. Ask us how we do it ! | 26 | 2 | 0 | 6mo | Post | Pasquale Di Pierro | https://www.linkedin.com/in/pasquale-di-pierro-040a136 | https://linkedin.com/in/pasquale-di-pierro-040a136 | 2025-12-08T05:10:04.452Z |  | 2025-05-27T16:56:53.884Z | https://www.linkedin.com/feed/update/urn:li:activity:7333121115424256001/ |  | 

---



---

# Pasquale Di Pierro
*FONEX Data Systems Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 15 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [FONEX Data Systems Inc | LinkedIn](https://ca.linkedin.com/company/fonex-data-systems-inc)
*2025-03-07*
- Category: article

### [Packt+ | Advance your knowledge in tech](https://www.packtpub.com/en-LV/product/python-interviews-9781788399081/chapter/6-massimo-di-pierro-6/section/6-massimo-di-pierro-6?srsltid=AfmBOoqI1X-xR11JUI_HYbkfore26F3i6GXAg_w6LHQZSIl9en_8Mjh4)
*2025-01-01*
- Category: article

### [FONEX Data Systems Inc Information](https://rocketreach.co/fonex-data-systems-inc-profile_b5c454aaf42e0df3)
*2025-01-01*
- Category: article

### [Open PON Solutions - FONEX Data Systems](https://www.fonex.com/solutions/open-pon/)
*2025-01-29*
- Category: article

### [Dataduct Networks (DDN) and FONEX Partner to Bring State-of-the-Art Fiber Broadband to Pictou County - FONEX Data Systems](https://www.fonex.com/news/dataduct-networks-and-fonex-partner-to-bring-broadband-to-pictou-county/)
*2024-12-04*
- Category: article

---

## 🎬 YouTube Videos

- **[Hinter dem Vorhang: Julie Fuchs und Nahuel Di Pierro in «Il turco in Italia» - Opernhaus Zürich](https://www.youtube.com/watch?v=nx38Z48GeQg)**
  - Channel: Opernhaus Zürich
  - Date: 2019-04-29

- **[El cantante Nahuel Di Pierro con Jordi Batallé en RFI](https://www.youtube.com/watch?v=sSPSG41XZpg)**
  - Channel: RFI Español
  - Date: 2017-03-06

- **[El cantante argentino Nahuel Di Pierro &#39;Hercules enamorado&#39; en la Opera Comique de París](https://www.youtube.com/watch?v=VM7KBfVzUf0)**
  - Channel: RFI Español
  - Date: 2019-10-30

- **[Duo Dulcamara Adina - Savastano - Di Pierro - Cemin](https://www.youtube.com/watch?v=rPJVJ3CTbpo)**
  - Channel: Mavi chan
  - Date: 2020-05-10

- **[« Ho un gran peso » Florian Sempey/Alphonse Cemin](https://www.youtube.com/watch?v=g9PiiGK-SBA)**
  - Channel: Florian Sempey
  - Date: 2020-11-08

- **[Pietro Taricone contro la gente in sala e contesta la reazione di Paone](https://www.youtube.com/watch?v=EZvXtnj5bZs)**
  - Channel: Alessio Rizzitelli
  - Date: 2018-09-29

- **[🥹 L’ABBRACCIO di DEL PIERO con PLATINI e ZIDANE #shorts #delpiero #platini #zidane #juventus](https://www.youtube.com/watch?v=GxO9xa3MRMM)**
  - Channel: PortAle Bianconero
  - Date: 2023-10-10

- **[The Monster of Florence - What the Netflix Series Didn&#39;t Show](https://www.youtube.com/watch?v=Maz6OiAByr8)**
  - Channel: Deep Dark and Scary
  - Date: 2025-10-23

- **[milva chiove](https://www.youtube.com/watch?v=RnPkttV_dmg)**
  - Channel: pasquale pierro
  - Date: 2009-10-10

- **[La dimensione spirituale della musica: intervista con Nicola Conte | Ep 31](https://www.youtube.com/watch?v=q6Sjhb7DD6w)**
  - Channel: SpinnIt
  - Date: 2021-04-02

---

## 🔎 Press & Mentions

- **[Untitled](https://www.mcgill.ca/engine/files/engine/2019_celebration_of_innovation_and_entrepreneurship_0.pdf)**
  - Source: mcgill.ca
  - *... conference in San. Francisco. The Cansbridge Fellowship has partnerships with ... Pasquale Di Pierro (BEng'76). Fonex Data Systems Inc. The Anna &...*

- **[FINAL VERSION 7th annual celebration summary](https://www.mcgill.ca/engine/files/engine/2021_celebration_of_innovation_and_entrepreneurship_summary.pdf)**
  - Source: mcgill.ca
  - *bootcamp and conference in San Francisco. The Cansbridge Fellowship has ... Pasquale Di Pierro (B.Eng. 1976). Fonex Data Systems Inc. The Anna & Louis...*

- **[BÂTIR L'ESPOIR BuILdIng HOPE - The Montreal Children's Hospital ...](https://www.yumpu.com/en/document/view/24019330/batir-lespoir-building-hope-the-montreal-childrens-hospital-)**
  - Source: yumpu.com
  - *Mar 29, 2014 ... Fonex Data Systems Inc.<br />. * Fuel Transport Inc.<br />. * GazMétro ... Pasquale Di Pierro<br />. * Jeffrey Drummond &<br />. Kath...*

- **[McGill Engine Annual Report (2021-2022)](https://www.mcgill.ca/engine/files/engine/mcgill_engine_annual_report_2021-2022.pdf)**
  - Source: mcgill.ca
  - *Aug 31, 2022 ... The conference provides immersive workshops with industry ... Pasquale Di Pierro (B.Eng. '76). Fonex Data Systems Inc. The Anna ......*

- **[2021 McGill Engine Annual Report](https://www.mcgill.ca/engine/files/engine/2021_mcgill_engine_annual_report.pdf)**
  - Source: mcgill.ca
  - *Feb 23, 2021 ... The conference provides immersive workshops with industry ... Pasquale Di Pierro (B.Eng. 1976). Fonex Data Systems Inc. The Anna ......*

- **[Pasquale Di Pierro Email & Phone Number | FONEX data systems ...](https://rocketreach.co/pasquale-di-pierro-email_40640531)**
  - Source: rocketreach.co
  - *Pasquale Di Pierro, based in Montreal, QC, CA, is currently a President and Founder at FONEX data systems inc....*

- **[FAB Engine Subcommittee | Engine - McGill University](https://www.mcgill.ca/engine/resources/mcgill-engine-centre-support/team/fab-engine-subcommittee)**
  - Source: mcgill.ca
  - *For more information, see this article. McGill University · Engine. Driving ... Pasquale Di Pierro is founder and president of Fonex data systems inc....*

- **[Pasquale Ricciardi Email & Phone Number | FONEX data systems ...](https://rocketreach.co/pasquale-ricciardi-email_12135172)**
  - Source: rocketreach.co
  - *FONEX Data Systems Inc Employee Pasquale Di Pierro's profile photo. Pasquale ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
