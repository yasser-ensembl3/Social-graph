# Tanya Castle

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : How to Conference
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Professional Training and Coaching

## Description du rôle

How to Conference (HTC), takes junior sales teasm from conference rookies to conference commandos who design winning event strategies, generate leads, close deals, and leave every show with measurable success. 

HTC helps you and your company:
- Identify High-Impact Events: Focus on conferences where your target clients are already engaged.  
- Stand Out in the Crowd: Craft compelling approaches that capture decision-makers' attention.  
- Turn Leads into Deals: Master impactful conversations that fast-track sales.  
- Maximize ROI: Transform every event into a growth engine with repeatable, scalable strategies.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAXtW5UB64BMSkpBbmq2wFj-GN_jo7RK10Y/
**Connexions partagées** : 20


---

# Tanya Castle

## Position actuelle

**Entreprise** : SilverRide

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Tanya Castle

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400585841456193536 | Document |  |  | Love these French concepts. | 7 | 0 | 1 | 1w | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:07:56.432Z |  | 2025-11-29T17:26:00.839Z | https://www.linkedin.com/feed/update/urn:li:activity:7400541553355653120/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397734649562779648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHfGxy8pRzPAQ/feedshare-shrink_800/B4EZqoIZ7IKkAg-/0/1763757379467?e=1766620800&v=beta&t=RfniJmlUnZRvbTQWfVPT00H1k1y0jWBl-40zAhnQy74 | My fabulous driver Valerie from Augusta, Georgia to Durham, North Carolina this morning! Found out about the woman-owned local transportation company The Sidity Effect she drives for at the Georgia Transportation Association conference during the opening reception! And of course booked a ride. We had a great 5-hour trip together. Can’t recommend The Sidity Effect enough! See link in the comments. 

#saleslife #transportation #womeninbusiness #gta2025 #roadwarrior | 37 | 1 | 0 | 2w | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:07:56.433Z |  | 2025-11-21T20:36:23.719Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397345691301330944 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF125rz2bVlBg/feedshare-shrink_800/B4EZqcsBa_HMAk-/0/1763565380444?e=1766620800&v=beta&t=m_hwow0wmkr7n1vBryGvULjczVJm325vtbp4KpwDnTs | Say hi to Kim Nguyen and I if you’re at the Ohio or Georgia state #transit conferences! We’re always happy to talk about how we can support your #paratransit service! | 9 | 0 | 0 | 2w | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:07:56.433Z |  | 2025-11-20T18:50:48.843Z | https://www.linkedin.com/feed/update/urn:li:activity:7396929334810419200/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396215616577351680 | Article |  |  | Very exciting day in #Montreal for #publictransit the REM’s 14 station extension is opening! It’s the biggest public transit project since the debut of the metro (subway) in the 60s! | 6 | 0 | 0 | 2w | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:07:56.434Z |  | 2025-11-17T16:00:18.033Z | https://youtu.be/xqrYU0sJYo0?si=N2z-oWKDZrL4fAz_ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7395148626152329216 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE658JAPisRkA/feedshare-shrink_800/B4EZqDYcBWGYAo-/0/1763140823632?e=1766620800&v=beta&t=E66pOC4o1mJAHoU7du6un8sOgtUL4tUG8_GegNUsRRY | I’m often on the road but when I’m in #Montreal I try to support local initiatives. This Wednesday I attended a fabulous women in business event. Hilariously, during our networking activities focused on uncovering commonalities we noticed we all have the same nail colour! Not exactly business related but definitely on trend and in style. :)

MERCI Jeune Chambre de Commerce des Femmes du Québec - JCCFQ for hosting such a lovely event! It was great to talk business with other successful women and share and learn from each other. 

#womeninbusiness #entrepreneur #business #femmesdaffaire | 29 | 2 | 0 | 3w | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:07:56.434Z |  | 2025-11-14T17:20:27.692Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7392611059876126720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEU6IeErwncag/feedshare-shrink_800/B4EZpfUje8IUAg-/0/1762535821583?e=1766620800&v=beta&t=0nOBbcDe_43U9uaXZT4GWDPyoC0YqHK8q-sfC_WleL0 | Spending time with my SilverRide colleagues is one of my favourite parts about attending conferences because we are all scattered across North America. Laura Friedman Williams is our Director of Market Development meaning she recruits and vets our independent contractors before they can join our platform to deliver FTA compliant paratransit trips. Not only is she phenomenal at what she does, passionate about our mission to help our communities most vulnerable people live independent and fulfilled lives, she’s a blast! We had a wonderful time at #Mobilize2025. 

#transit #nemt #paratransit #mobilityforall | 35 | 2 | 1 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.015Z |  | 2025-11-07T17:17:04.746Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7391970817334472704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG-0g4lu88bHg/feedshare-shrink_800/B4EZpTuPvwIUAg-/0/1762341224873?e=1766620800&v=beta&t=psbqR3mNP5vyT5Ofu2FQCuK3PjxeV2RU8Kh4vrr4hQM | My colleague Kim is at CTA today and I’ll be joining her there tomorrow - from The Transportation Alliance show in Las Vegas right to the California Transit Association in Long Beach there’s so much sharing, learning and exciting developments in #transit. | 9 | 2 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.016Z |  | 2025-11-05T22:52:59.029Z | https://www.linkedin.com/feed/update/urn:li:activity:7391821654873763841/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391207192294686720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGx6_tGyZzS-A/feedshare-shrink_800/B4EZpLXsZjKYAg-/0/1762201113717?e=1766620800&v=beta&t=lqj-ghnYXqKdWkJVDUGkfRtRAatFWclek4loz9PNaV0 | This isn’t really a #transit post other than the picture of the #buses used to transport workers from Boulder City to the Hoover Dam construction site but a post on the incredible infrastructure projects that can be realized with political will and vision! Public transit projects require exactly that - vision and political will! Don’t ever believe someone who says transport can’t be better- it can! We have built wonders, we can build a train, a BRT lane, accessible sidewalks…and more to make the world more fair for all to be mobile.

This is also one of the perks of hitting new cities for conferences - sometimes I have a little time to take in some of the local sights. 

#paratransit #lasvegas #infrastructure | 56 | 6 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.017Z |  | 2025-11-03T20:18:36.632Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7390174479093751808 | Article |  |  | Transit really is a lifeline for people and backbone of an economy. | 8 | 0 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.017Z |  | 2025-10-31T23:54:58.618Z | https://youtube.com/shorts/cCyWzms6WGM?si=J2pdoipjF10SyWok |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389467829584175104 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgJCSnHdt32w/feedshare-shrink_800/B4EZorleYaHMAk-/0/1761667840910?e=1766620800&v=beta&t=N-969uKqXu6jqCTyAMsoh3PkF2eUT1jy2sMB1nmtgQ4 | Such a fun time at #calact last week in Lake Tahoe. Great to catch up with our partners and meet potential new ones who share the same passion and commitment to delivering quality paratransit service to their communities with background checked and drug & alcohol tested drivers. 

#paratransit #transit #safetyfirst #publictransit | 14 | 0 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.018Z |  | 2025-10-30T01:07:00.246Z | https://www.linkedin.com/feed/update/urn:li:activity:7388970480948649984/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7386456151137083392 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQET5BEXGzdRuQ/feedshare-shrink_800/B4EZoH2hizIMAg-/0/1761068376294?e=1766620800&v=beta&t=cHmuKx6n3pZd3B3vSvfWfuU4wukaKpij3rYmN_0p_VU | Such gorgeous views of the water from the San Francisco Airport #airtrain station! #SFO definitely challenges the views of the mountains at the Denver Airport. Just arrived to pick up the new SilverRide booth and will be on route for the California Association for Coordinated Transportation conference in Lake Tahoe. Looking forward to seeing SilverRide’s partners who bring us on to deliver life-changing, even life-saving transportation. 

#CALACT2025 #Transit #publictransit #paratransit | 24 | 0 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.018Z |  | 2025-10-21T17:39:40.150Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7384701634460794880 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFWrB1r4m0Hnw/feedshare-shrink_800/B4EZnhfSe7KcAg-/0/1760424701482?e=1766620800&v=beta&t=whV6FwdQXRAXTHIPvjEY_rd-gsxPKYfk-NP7K7y1vvo | So excited to share SilverRide’s new look for those who haven’t seen it yet! I met our wonderful graphic designer Julia Ronnenberg at the Selina #coworking space in #Lisbon back in February and the rest is history! 

Together, and with my colleague Laura Friedman Williams, we’ve worked to modernize SilverRide’s look and above all convey through it (and our new motto) the dedication we have to the important work we do for senior and disabled communities. 

#transit #paratransit #seniors #therewithcare | 18 | 0 | 1 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.019Z |  | 2025-10-16T21:27:50.777Z | https://www.linkedin.com/feed/update/urn:li:activity:7384558754975092736/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7383869696212676608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQER_bqq_0C07Q/feedshare-shrink_800/B4EZnjGVphKwAg-/0/1760451719537?e=1766620800&v=beta&t=4lgLjspTE0vV1I7U2Not3XmK2FcshILOl1ULOpO1Ju0 | Acting as consultants for our #surfandsales classmate Ekaterina Olefirenko was definitely one of the most fun, creative, and enriching experiences of The Surf and Sales Summit in Portugal. In less than 2 hours, 2 teams battled to win her business by pitching ways she could grow her consultancy in #Finland and the #nordics and the ideas, teamwork and presentations that came together in that time really showed what can happen when you’re focused and under a time crunch! Loved this real world activity organized by sales trainers🏄🏼‍♂️ Scott Leese and Richard Harris™. 

#sales #consulting #business | 15 | 4 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.020Z |  | 2025-10-14T14:22:01.242Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7382802886361128960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGoAqFH18A9Lw/feedshare-shrink_800/B4EZnT8ELBJgAg-/0/1760197370080?e=1766620800&v=beta&t=jKRTUvfJ4NvXFgehGBjFARQjGQMYYRRu-zekGyoIycM | My new friend, housemate, and classmate Meg Youngblood giving an incredibly insightful presentation on how #AI can be used as a tool for #sales at #surfandsales in Portugal this week. 

As a sales person in the transit industry for almost 10 years my AI learning has mostly focused on transportation applications of AI like for #selfdriving cars, #buses, #trains and other transit modes so it was great to learn about how it will impact my chosen career. 

Many professionals are concerned about how AI will impact their work -  the more I learn about it the more I see it as a “helper” versus a “replacer.”

#transit #publictransit #business | 7 | 0 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.022Z |  | 2025-10-11T15:42:53.953Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7382339259653062656 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGBAc5Qa46bUQ/feedshare-shrink_800/B4EZnNWZ5zKcAk-/0/1760086834541?e=1766620800&v=beta&t=bUL2ZIOoFW8DaPdq9sUJwjzS2GWv0q8PDlpvnr859To | This week I’ve been learning from some of the greatest minds in #sales at #SurfandSales! This session by Richard Harris™ on time management and internal selling was incredibly helpful for me when it comes to addressing the perennial challenge of splitting time between top of funnel and bottom of funnel activities and how to collaborate with colleagues across departments on sales activities. Thank you Richard for sharing your wisdom!

#business #revenue #B2Bsales #businessdevelopment | 21 | 3 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.022Z |  | 2025-10-10T09:00:36.732Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7381624615414185985 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFVlgbu10CtOg/feedshare-shrink_800/B4EZnDMarvIwAg-/0/1759916448249?e=1766620800&v=beta&t=3e6T5nGrjddFyUl5UE2iL2YZZg8lHekC88MTtUWWhtc | This is a commuter train in the south of France that goes through 3 countries!!! While American governments take decades to study and plan for train networks #Europe gets it done and across borders!! On this commuter train I started in France, ended in Monaco and could have kept going to Italy! 

#trains #transportation #publictransportation #commutertrains #commuting #travel | 44 | 3 | 0 | 1mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.023Z |  | 2025-10-08T09:40:52.268Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7381321946069671937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEsNIwkdY7H0A/feedshare-shrink_800/B4EZm.5K1_KwAg-/0/1759844288715?e=1766620800&v=beta&t=ZDD09qcBehPaTvPG796I6pHgyWc_RQd5Ju3oinx4O_8 | Such an original light design on this commuter train in France. 

#trains #mobility #publictransport | 10 | 2 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.023Z |  | 2025-10-07T13:38:10.273Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7380505615200178176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHP8Pmzala3TA/feedshare-shrink_800/B4EZmzSsoEIQAg-/0/1759649661036?e=1766620800&v=beta&t=m5322aQBq_T2rIpWylP3PLBl2fTGhnySatnt3fTZB6E | It really is wonderful to see such attention to detail for public transit infrastructure in the South of #France. This is an adorable #bus shelter I noticed just outside of St. Tropez. And not only is the infrastructure cute, the prices are incredibly reasonable. I took a 1.5 hour bus ride from St. Tropez to St. Rafael for 2.50 euros! When public transit is safe, clean and accessible it really is the best way to get around affordably. 

#buses #transit #publictransit | 32 | 2 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.024Z |  | 2025-10-05T07:34:21.827Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7379846568545517568 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3133bc75-d4d9-44be-9c5f-452dec2fa5df | https://media.licdn.com/dms/image/v2/D4E05AQF3z9wtZcss9Q/videocover-high/B4EZmp7GjWGcB8-/0/1759492525543?e=1765778400&v=beta&t=fK14hWUwo1HONbLbntEe1rxEytQRfmsImXTXWmmDNZc | This might be the most beautiful bike lane I’ve seen on my travels! The south of #France has incredible cycling infrastructure! And public transportation as this video was taken on a bus! 

#publictransit #publictransportation #travel #transportation #cycling | 34 | 9 | 1 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.025Z |  | 2025-10-03T11:55:32.860Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7379490139594444800 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE49TZxFKpUCw/feedshare-shrink_800/B4EZmk3JECIMAg-/0/1759407551663?e=1766620800&v=beta&t=k3boN7y6YxHhwG9baFCdNvzwOa9hO9Sc80vszaOZ_CM | The transportation info at Charles de Gaule Airport in #Paris is exceptional! Such great signage, even interactive screens and a team of transit experts to help you get where you need to go. A well connected #airport is the best when you’re traveling. 

And there were so many options to get to the city:
-RER B -- the easiest way to go from/to Paris 
-Roissybus -- to the center of Paris (Opéra) in 60 minutes
-Metro lines --  to Porte de la Chapelle in 70 minutes
-Night buses -- when regular service is done 

#publictransit #publictransport #travel #trains #wayfinding | 30 | 4 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.025Z |  | 2025-10-02T12:19:13.576Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7373382888559636482 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF2fbxHRnNvYQ/feedshare-shrink_800/B4EZlOEoNtKsAg-/0/1757951467895?e=1766620800&v=beta&t=5-5MuDFnIQHHHyh4ZJjoWr5sgX7y5sslQibwcW6QkWo | So excited to reveal our new SilverRide tagline “There With Care” that highlights all of the transportation services SilverRide provides that allows seniors and people with disabilities to live full and independent lives! 

Across the USA we deliver 1000s of trips a day that positively impact our riders’ well-being and we hope to deliver 1000s more in the months and years to come! 

Please stop by and visit us at BOOTH 707 at #aptatransform to learn about how you can bring life-changing, even life-saving transportation to the communities you serve! 

#paratransit #transit #mobility #aginginplace | 103 | 7 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.026Z |  | 2025-09-15T15:51:11.462Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7372624330515513344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFCbT3MIOWHFw/feedshare-shrink_800/B4EZlDSwb7HgAg-/0/1757770615770?e=1766620800&v=beta&t=v1Q6P5A6gN-Iuhhj3DviWeTXbbNYoQXIJyvxE1EaOJ4 | I don't much talk about SilverRide's support for PACE programs across the USA because I work on our #paratransit support but I wanted to take a minute and highlight our very cool launch with SEEN Health in California. 

In partnership with SEEN Health we deployed what we think is the first-ever Cantonese and Mandarin speaking PACE transportation platform in the U.S!  As part of the program we connect Cantonese and Mandarin-speaking older adults with linguistically matched drivers who understand their culture and community and it's been life changing for riders!

Together with SEEN Health, we’re building a future where mobility is inclusive, compassionate, and tailored to the people it serves.

#transit #PACE #nemt #transportation #publictransit | 18 | 1 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.027Z |  | 2025-09-13T13:36:57.131Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7371982487280914432 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGxVWvQscniIA/feedshare-shrink_800/B56Zk6K_jiJoAg-/0/1757617588900?e=1766620800&v=beta&t=jI6iCfVWJlYP05ww_ID6TDoORMNFCArol5DTt7RtIH4 | Looking forward to attending #APTATransform next week in one of my favourite American cities: #Boston! For a history and transit lover it's a top spot!  I'll be joined by my SilverRide colleagues Kim Nguyen, Laura Friedman Williams and our CEO Jeff Maltz. And we're so excited because we'll be unveiling our brand new logo, tagline and design! 

#transit #paratransit #publictransit #publictransport #publictransportation | 37 | 5 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.027Z |  | 2025-09-11T19:06:29.779Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7371146652138647552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFzgzSoQnBlKw/feedshare-shrink_800/B4EZkrcmdyIoAk-/0/1757370547289?e=1766620800&v=beta&t=yDcd__fHdQuHnspxYNDarzS81kZXCo7JHP0AUIPiLqs | Last week I was in Tampa for the #FPTA conference and not only was it loads of fun and very informative it took me to an airport I’d never been to before and it takes the cake for the best public art I’ve seen in an airport! 

#airports #art #design #travel #businesstravel #aviation #florida | 27 | 1 | 1 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.028Z |  | 2025-09-09T11:45:11.152Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7370944498736050176 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4041a866-0eca-4097-91dd-9b844e45497d | https://media.licdn.com/dms/image/v2/D4E05AQHCGgBk-p5xyQ/videocover-high/B4EZkq251XKQCM-/0/1757360664887?e=1765778400&v=beta&t=Ietb0mFITWXoi3Ncz6hSmnedkgdcIXBXbL_ZLDVHv7c | I’d never heard about the “Bus Aunty” probably because I’m not on TikTok so I’m glad her videos made it to LinkedIn and we get to share in her love for buses here! I share her passion for London’s double decker red buses. Whenever I’m in London I like to sit right at the top in the front window and see the city around me. | 18 | 3 | 0 | 2mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.029Z |  | 2025-09-08T22:21:54.025Z | https://www.linkedin.com/feed/update/urn:li:activity:7370904908847357952/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7366542043516477441 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFplgcrJaMW6Q/feedshare-shrink_800/B4EZjs283FGYAk-/0/1756320485420?e=1766620800&v=beta&t=o0dn8TpnAcTaiL3ww8sGL2Er9GFW4-QNqYBhofZVCeg | I'm so delighted to share that SilverRide is facilitating nearly 100,000 trips per month across the USA! 🚗✨

Personally, it has been such a joy working with our amazing partners who care about helping seniors and people with disabilities live fulfilled lives just a much as we do. 

Learn more in our latest press release 👉 https://lnkd.in/eUh6bEWG

#SilverRide #AccessibleMobility #paratransit #transit #publictransit #mobility #AgingInPlace #TransportationWithCare | 39 | 1 | 0 | 3mo | Post | Tanya Castle | https://www.linkedin.com/in/tanya-castle-24537729 | https://linkedin.com/in/tanya-castle-24537729 | 2025-12-08T05:08:01.030Z |  | 2025-08-27T18:48:06.907Z |  |  | 

---



---

# Tanya Castle
*SilverRide*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 33 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [SilverRide | LinkedIn](https://ng.linkedin.com/company/silverride)
*2025-04-03*
- Category: article

### [Agencies – SilverRide](https://silverride.com/agencies/)
*2024-01-01*
- Category: article

### [Company – SilverRide](https://silverride.com/company/)
*2024-01-01*
- Category: article

### [A Conversation with Tanya Rolfe | Co-Founder @ Sophia | Host @ The Money Makers Podcast | Her Capital | Ladies Investment Club | Women in Venture Capital Podcast](https://www.everand.com/podcast/671770556/A-Conversation-with-Tanya-Rolfe-Co-Founder-Sophia-Host-The-Money-Makers-Podcast-Her-Capital-Ladies-Investment-Club)
*2022-02-04*
- Category: podcast

### [An Idaho Transit System Provides Second-Chance Employment for Former Felons](https://www.ccam-tac.org/blog/an-idaho-transit-system-provides-second-chance-employment-for-former-felons/)
*2023-11-21*
- Category: blog

---

## 🎬 YouTube Videos

- **[CES 2019 in Las Vegas, interview with Tanya Castle - PBSC Urban Solutions](https://www.youtube.com/watch?v=PZNt62dpkk8)**
  - Channel: Lyft Urban Solutions
  - Date: 2019-01-09

- **[AidEx Africa - Testimonials - Tanya Castle &amp; Helen Walker - Afripads](https://www.youtube.com/watch?v=2b8k29Xwf2k)**
  - Channel: AidExpo
  - Date: 2014-06-13

- **[SALON AUTONOMY PARIS 2022 | On y était!](https://www.youtube.com/watch?v=paByB7PU7FM)**
  - Channel: ID4MOBILITY
  - Date: 2022-03-17

- **[AUTONOMY Paris 2022 | Kisio](https://www.youtube.com/watch?v=Mw1D5fdOkOw)**
  - Channel: Kisio
  - Date: 2022-03-24

- **[By bus or by taxis? The answer is both!](https://www.youtube.com/watch?v=-QCel_RWH6A)**
  - Channel: Spare
  - Date: 2020-06-18

- **[Oegandadag: Afripads](https://www.youtube.com/watch?v=LiClWnXr_II)**
  - Channel: CastingInternational
  - Date: 2013-10-21

- **[PBSC Urban Solutions at the MENA Transport Congress &amp; Exhibition](https://www.youtube.com/watch?v=81ubx-1ftGM)**
  - Channel: Local Search
  - Date: 2022-02-06

- **[Ugandan Factories opt to Generate their own Power to Maintain Profitability](https://www.youtube.com/watch?v=ewxc0SLErMc)**
  - Channel: CGTN Africa
  - Date: 2014-07-30

- **[Malagueños - 101TV - 23-04-2015](https://www.youtube.com/watch?v=feFLcFYVw7Q)**
  - Channel: Ruedas Redondas
  - Date: 2015-05-12

- **[PBSC - À la conquête du monde](https://www.youtube.com/watch?v=kX1D_pi3fTg)**
  - Channel: Lyft Urban Solutions
  - Date: 2016-04-12

---

## 🔎 Press & Mentions

- **[SilverRide Unveils New Branding, Reinforces Focus on High Level ...](https://www.metro-magazine.com/10247368/silverride-unveils-new-branding-reinforces-focus-on-high-level-of-care-in-transp)**
  - Source: metro-magazine.com
  - *Sep 15, 2025 ... Podcasts · Jobs · Webinars · Whitepapers · Contributed Content · Articles ... Tanya Castle, director of growth for transit agencies a...*

- **[Strategic Business Transformation & Workforce Development](https://www.engage3p.com/about)**
  - Source: engage3p.com
  - *Tanya Castle. Black and white portrait of a woman with long hair smiling ... She also leads the sales team at SilverRide, a transportation company ......*

- **[ADA@35: We Reached A Milestone – Now Let's Finish What We ...](https://silverride.com/ada35/)**
  - Source: silverride.com
  - *Oct 31, 2025 ... Tanya Castle is Director of Growth at SilverRide, where she leads transit agency partnerships nationwide. ... Let's talk about the el...*

- **[Tanya Castle Email & Phone Number | SilverRide Director of Growth ...](https://rocketreach.co/tanya-castle-email_12524697)**
  - Source: rocketreach.co
  - *Tanya Castle brings experience from previous roles at How to Conference ... SilverRide Employee Tanya Castle's profile photo. Tanya Castle. Director o...*

- **[Mobility Conference Program](https://s6.goeshow.com/apta/mc/2024/fullprogram.cfm)**
  - Source: s6.goeshow.com
  - *Panelist: Tanya Castle, Director of Growth, SilverRide Panelist: Lisa Womack, Vice- Chair, APTA Access Committee, Senior Manager of Mobility Innovatio...*

- **[Tanya Castle - Director Of Growth at Silver Ride LLC | The Org](https://theorg.com/org/silver-ride-llc/org-chart/tanya-castle)**
  - Source: theorg.com
  - *Tanya Castle ... With a background in journalism and international relations, Tanya has held various roles in companies like SilverRide, PBSC Urban So...*

---

*Generated by Founder Scraper*
