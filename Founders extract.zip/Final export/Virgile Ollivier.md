# Virgile Ollivier

## Position actuelle

**Titre** : Founder
**Entreprise** : Chapter
**Durée dans le rôle** : 5 months in role
**Durée dans l'entreprise** : 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Supporting startup founders, from one chapter to the next. 

Chapter is an impact platform helping tech founders fail wiser, learn deeper, and start again stronger—turning painful endings into powerful new beginnings.

Built by and for tech founders, Chapter creates a supportive community where experience becomes the foundation for bolder next ventures.

## Résumé

I am a serial entrepreneur, advisor, and coach with a passion for helping startups overcome their biggest challenges, currently exploring entrepreneurial fears. 

I bring a unique blend of strategic vision, product development expertise, and hands-on GTM experience from leading tech companies. I want to empower founders through fractional CxO support, workshops, and coaching, inspiring them to build impactful and successful businesses, and foster a positive change around me.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAB3zZQBUpW_9cp8TJVuMvPEJcfj4vnmeCY/
**Connexions partagées** : 195


---

# Virgile Ollivier

## Position actuelle

**Entreprise** : Chapter

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Virgile Ollivier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397710252164685824 | Article |  |  | That time of the year... #SCA

#StartupCommunityAwards is approaching.
Happy to be nominated this year, but that's not my point today.

What's important to me? The categories that matter.

Because two of them deserve the spotlight: #BridgeBuilderOfTheYear and #BackboneOperatorOfTheYear. And I'm thrilled to see people I nominated a few weeks ago making it to the final stage.

Why does this matter?

=> They are the ones you can rely on. The ones who help, commit, and deliver — especially when you lack the support you need.
=> They're the ones we often don't see on screen. Only in the credits. But without them, nothing would happen.
=> They don't have a stake in what you do. They help you because they think you deserve it, and because they care, truly.

So congrats to Geraldine Holliday Sylvain Letellier Sarah Bezeau Gervais Karina R. Josée Desjardins, MBA Constance Jaluzot Andrea Mendoza Patricio Gutierrez Mella Salma Maâfiri Mariona Ferrer Thomas Friedlaender Lisa Séguin Peter Kovacs Charline Kempter Julien Lamarche Marie-Claire H. François St-Hilaire Isabelle Petibon Iliass Lamrini, M. Sc. Danica Virginia Meredith

To all the bridge builders and backbone operators out there: thank you for holding the ecosystem together.

And now... Go vote!!!! and see you on December 4th at Ax-C

https://lnkd.in/eY7cX3F2

#StartupCommunityAwards 
#BridgeBuilderOfTheYear 
#BackboneOperatorOfTheYear
elantech | 24 | 0 | 0 | 2w | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:04.572Z |  | 2025-11-21T18:59:26.926Z | https://docs.google.com/forms/d/e/1FAIpQLSfmXi7Ot3pAChAYtDztwxzvysT71byE1ZV3a_b2ve-kpiHr1g/viewform?usp=dialog |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391483625554477056 | Article |  |  | La semaine dernière a eu lieu le premier souper Chapter.

Mais vous ne trouverez pas de photos à partager, pas de name-dropping ou d'insights inspirants à vous livrer.

Pourquoi ? Parce que dans un monde où tout est public, communication et posture, je pense qu'il faut bâtir des relations plus vraies, fortes et saines, et parfois le faire à l'abris des regards, pour que l'on puisse se dire les vraies affaires...


Et alors, ce souper? Tout le monde a adoré.

Comment je le mesure ? Quand tout le monde fait tourner son iPhone pour se connecter à chaud sur LinkedIn, tu sais qu'il se passe quelque chose. Sans compter tous ceux qui voulaient connaître les détails pour le prochain souper...

Tout ça partait d'une idée de longue date, sur un concept simple :
=> 8 entrepreneurs tech, 1 invité de haut niveau (Merci D. !)
=> Une discussion franche, honnête, sans BS, sur des sujets impactants pour les fondateurs tech
=> Et puis, une bonne table ;-)


Mon KTA? Les entrepreneurs qui étaient autour de la table mercredi dernier sont ceux qui, s'ils ne réussissent pas aujourd'hui, le feront demain, individuellement ou collectivement. Parce que l'entrepreneuriat tech, c'est une aventure, mais aussi une "learning curve" permanente.

Alors si toi aussi tu penses comme nous, rejoins-nous 👉 https://lnkd.in/ePKNt6kX

#Chapter | 28 | 1 | 1 | 1mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:04.573Z |  | 2025-11-04T14:37:03.457Z | https://bit.ly/Chptr-onboard |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7386183349628792832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEtHJ6wafAyww/feedshare-shrink_800/B4EZoBp2g.GUAg-/0/1760964341120?e=1766620800&v=beta&t=DDNt2Gm9H2vdWZY7FyW0gDRtaHOTgwYUjfd9-Tlxc8w | Almost full…
Hâte de faire ce panel demain et parler, sans filtre - ma mauvaise habitude - d’un sujet souvent trop peu abordé…

Edouard Ferron-Mallett 
Open House Montreal | Portes Ouvertes Montreal - #OHMTL | 25 | 0 | 0 | 1mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:04.574Z |  | 2025-10-20T23:35:39.202Z | https://www.linkedin.com/feed/update/urn:li:activity:7386019784846630943/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384312615218384896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnN1czdvrXzw/feedshare-shrink_800/B4EZnjD_epHEAg-/0/1760451099082?e=1766620800&v=beta&t=QJVrTXWHIMDV6suS0j24gzH5QDDobBh3EB5r4_EB7MY | Heureux de participer au panel “Garder la flamme entrepreneuriale dans 
la tech”, organisé par @ProAction Entrepreneurs dans le cadre de Open House Montreal | Portes Ouvertes Montreal - #OHMTL

On parlera de passion, d'ambition, mais aussi de comment naviguer dans les moments plus dur, parce que l'entreprenariat tech est un parcours exigeant.

📅 21 octobre | 17h30 | Montréal

🎟 Gratuit – inscription : https://luma.com/5afy9ptk 

#Entrepreneuriat 
#SantéMentale 
#Tech 
#InnovationDurable | 14 | 0 | 0 | 1mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:04.576Z |  | 2025-10-15T19:42:01.362Z | https://www.linkedin.com/feed/update/urn:li:activity:7383867093966020609/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7376365815475904513 | Article |  |  | 🚨 The Canadian tech startup crisis is no longer a whisper—it’s a scream.

Leaders Fund breaks down in a recent article what many have been quietly discussing, but too many refuse to acknowledge: our startup ecosystem is dried up. Maybe even fundamentally broken.

The brutal numbers speak for themselves:
→ 100,000 fewer entrepreneurs than 20 years ago
→ 4.6x fewer repeat founders than the US
→ 50% of failed tech founders never try again

Despite the current situation, tech founders are moving to the US — physically or virtually — more than ever. Why? Because the AI revolution changed everything. Things go bigger, faster, stronger than ever.

But here’s the real problem in Canada — it’s upstream.

While everyone focuses on funding gaps and market access, we’re missing the core issue: we burn through entrepreneurs like disposable resources.

The Canadian model is backwards:

→ We celebrate first-time founders taking massive risks
→ We watch them crash and burn in isolation
→ We let them disappear into corporate jobs or head south
→ We repeat the cycle with the next batch of naive optimists

Meanwhile, other ecosystems recycle their talent. Failed founders become repeat founders. Experience becomes expertise. Networks become launch pads.

**We don’t have a funding problem. 
We have a founder journey problem.**

As an immigrant who chose to become Canadian, I see all the assets we have to create an amazing environment for tech founders. They’re our most valuable resource. And we’re letting them rot.

>It’s time to wake up.

>It’s time to build systems that catch entrepreneurs when they fall.

>It’s time to refactor our competitive advantage by building pathways for founders to stay in the game.

#chapter

Colin Deacon 🇨🇦🇺🇦 Leaders Fund 

https://lnkd.in/eJeNzYxU | 80 | 46 | 7 | 2mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:04.577Z |  | 2025-09-23T21:24:16.659Z | https://www.leaders.vc/canadianstartups |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7344346385288228864 | Text |  |  | 💥 When startup founders struggle, words can be poison. 
I let you choose yours.

"Focus on the positive" 
"Take some time for yourself now, you deserve it" 
"Failure is just a learning experience" 
"Just move on and start again" 
"I knew this would happen" 
"You're a warrior, I know you'll come up with something" 
"At least you tried"

🌀 When a startup founder fails — like for most founders and entrepreneurs — people who haven't been through that experience usually don't have the words that help, that heal, that boost.

On the contrary, it's usually counterproductive:

▷ You can't "Focus on the positive" , as it takes a digestion process to transform experiences into wisdom;

▷ You don't want to "Take some time for yourself now (...)"  => you need fresh air, need to feed your brain with new topics, new ideas, new connections;

▷ "Failure is just a learning experience", but an expensive experience. With a $350K founder debt in Canada on average, executive education looks like a cheap way to muscle up your skills;

▷ You're not ready - yet - to "Just move on and start again" => Your next venture will consume 3 to 10 years of your life, so you want to choose wisely;

▷ If, as a friend, employee, investor, saying "I knew this would happen", is a weak way to say that you don't have what it takes to do it;

▷ "You're a warrior, I know you'll come up with something" => Being a warrior is a necessary posture. But thanks for gently saying you just don't care;

▷ "At least you tried" => "Trying" is not what you signed up for. But thanks for gently saying you don't know how to help.

Sometimes the best thing to say is nothing at all. 
Just be there. 
And don't try to come up with answers, just try to understand the meaning of the question.

#chapter | 19 | 3 | 0 | 5mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.277Z |  | 2025-06-27T12:50:29.610Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7340755606300991489 | Text |  |  | 💥 Dans une startup, on veut des fondateurs qui veulent changer le monde. Mais en réalité, c’est devenu une posture.


Chaque pitch commence de la même manière. 
On démarre avec une grande vision, des intentions nobles: 
🌍 Sauver la planète. 
🤝 Démocratiser l’accès. 
💪 Redonner du pouvoir aux communautés.

Et puis la réalité s’impose.
💸 Tu passes 80 % de ton temps à chercher du financement — pas à construire des solutions 
📉 Tu t’éloignes de ta mission pour courir après le product-market fit 
👥 Tu embauches des profils plus attachés à leur equity qu’au sens du projet. 
⚖️ Tu fais des compromis que, hier encore, tu aurais jugé inacceptables.
Et un jour, sans bruit, tu n’es plus ce fondateur idéaliste qui voulait tout changer.

Tu es devenu quelqu’un d’autre. 
Plus lucide, certes. 
Plus pragmatique, d'accord. 
Mais aussi plus désabusé, cynique, tanné.

🌀 L’ironie de tout ça? Pendant que tu passes ton temps à “disrupter” des industries, c’est ta startup qui est en train de te disrupter. 
Tes valeurs. Tes relations. Ta santé mentale. 
Ta vision fondatrice.

Peut-être que la vraie transformation, ce n’est pas le monde qu’on prétend changer, mais ce que le fait d’entreprendre change en nous.

Parfois, la vraie rupture ne se joue pas ce qu'on a accompli. 
Mais dans le regard que l’on porte sur soi. 
Et, malgré tout, ce reflet — aussi abîmé soit-il — vaut plus qu’on ne l’imagine.

#chapter | 19 | 0 | 0 | 5mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.278Z |  | 2025-06-17T15:02:01.186Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7340466635369013248 | Text |  |  | 💥 Startup founders set out to change the world. But in real life, it's a fad.


Every pitch deck starts the same way. 
But here's what actually happens. You start with grand visions of impact: 
🌍 Saving the planet. 
🤝 Democratizing access. 
💪 Empowering communities.

Then reality hits: 
💸 You spend 80% of your time chasing funding, not building solutions. 
📉 You pivot away from your mission to chase market fit. 
👥 You hire people who care more about stock options than your cause. 
⚖️ You make compromises that your younger self would hate.

Before you know it, you're not the idealistic founder who wanted to change everything. You're someone else. 
More cynical. 
More pragmatic.

🌀 The irony? 
While you're busy "disrupting" industries, the startup life is disrupting you. 
Your values. Your relationships. Your mental health. Your original vision.

Maybe that's the real transformation we should be talking about. Not the world we're changing, but how building companies changes us.

Sometimes the biggest disruption isn't in the market — it's in the mirror. 
And whatever people say, the image in the mirror looks better than you think.

#chapter | 30 | 15 | 0 | 5mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.279Z |  | 2025-06-16T19:53:45.147Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7338304227108151299 | Text |  |  | 💥 On aime célébrer les startups. Mais on préfère ignorer les dégâts qui se passent en coulisses.


Pendant qu’on vante la puissance de notre écosystème:
👉 15 % des startups canadiennes fermeront cette année
👉 et plus de 30 % sont déjà des zombies, ou dérivent lentement vers du “lifestyle business”

On suit les Inputs. Jamais les Outputs.

Quand une startup échoue, elle disparaît en silence, dans l’oubli:
▷ Pas de post-mortem
▷ Pas de retour d’expérience
▷ Aucune analyse sur ce qu’on pourrait améliorer — ni sur ce que les investissements, notamment publics, ont réellement produits.

On est obsédés par les "vanity metrics", sorties de tout contexte. On est dans la complaisance d’un storytelling qu’on sait pourtant trompeur et nocif :
▷ Combien d’argent levé — mais jamais combien de dette accumulée;
▷ Combien d’emplois “créés” — sans préciser combien étaient subventionnés;
▷ Combien de brevets déposés — mais combien ont réellement été publiés, exploités, valorisés.

💭 Résultat ? On répète les mêmes erreurs.
On finance les mêmes profils de startups, avec les mêmes logiques inefficaces.
Notre écosystème, c’est un "Jour de la Marmotte" permanent: les mêmes cycles, les mêmes blocages — seuls les visages changent.

D’autres écosystèmes font l’autopsie de leurs échecs. 
Nous, on préfère jouer le jeu de l’amnésie.

Peut-être qu’il est temps de changer notre "Operating System". Pas seulement du côté des startups — mais aussi du côté de l’écosystème qui entretient ce cycle.

#chapter | 33 | 11 | 0 | 5mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.280Z |  | 2025-06-10T20:41:06.842Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7338294562131492864 | Text |  |  | 💥 While we celebrate startups, we ignore the wreckage they leave behind.


While we regularly celebrate how powerful we are, 15% of Canadian startups will shut down this year, and more than 30% are zombies or becoming lifestyle businesses.

Because only the Ins. And we don't track the Outs.

When a startup fails here, it disappears into the void.
No post-mortem.
No lessons shared.
No analysis of what went wrong or what outcome our investment led to.

We're obsessed with vanity metrics: 
▷ How much was raised, and forget about accumulated debts 
▷ How many jobs were "created" that are not subsidized in any way 
▷ How many patents were filed that are actually granted and of value

💭 The result? We keep making the same mistakes, funding the same types of companies, in the same inefficient ways. Our startup ecosystem feels like Groundhog Day — same patterns, same problems, different faces.

Other ecosystems do autopsies on their failures. We do amnesia and pretend to do better next time.

Maybe it's time to disrupt our OS. Not just from startups, but from the entire ecosystem that enables this cycle.

#chapter | 14 | 4 | 0 | 5mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.281Z |  | 2025-06-10T20:02:42.532Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7333960533626249218 | Text |  |  | 💥 Un bel exemple de ce qui, honnêtement, me rend dingue ici.

On dit aux entrepreneurs : "Prenez des risques ! Innovez ! Bâtissez l'avenir !" 
Puis quand ils échouent, on dit : "Désolé, pas d'indemnité, faut vous réinventer"

Un employé perd son emploi ? L'assurance-emploi embarque. 
Une startup de fondateur plante ? Silence radio.

Allons dans le détail : 
→ Employé : 55% du salaire d'indice couvert pendant des mois 
→ Fondateur : 0$. Débrouillez-vous tout seul.

Pourtant, on encourage les Entrepreneurs Tech car: 
• Ils prennent les risques 
• Ils stimulent l'innovation
• Ils créent des nouveaux types d'emplois 
• Ils génèrent des revenus fiscaux si succès.

Pendant ce temps, on se demande:
• Pourquoi 50% des fondateurs tech canadiens ne recommencent jamais. 
• Pourquoi on a 4,6x moins d'entrepreneurs en série qu'aux États-Unis. 
• Pourquoi les meilleurs, les ambitieux, partent au sud de la frontière, ou disparaissent se reposer dans des jobs corporatives. 
• Pourquoi on est une "lifestyle" économie avec une productivité si faible...


Voici ma question : Si on demande aux entrepreneurs de tout miser — leurs économies, leur santé mentale, leurs relations — ne devraient-ils pas avoir le même filet de sécurité de base que tout le monde ? 
Et pourquoi l'assurance-emploi ne couvre pas aussi les fondateurs ? 
Et si on redefinissait les périmètres de garanties personnelles ? 
Et si on était vraiment sérieux quand on dit que "l'innovation compte" ?

Parce que là, on demande aux gens de sauter, mais sans parachute. Et on se demande pourquoi il y a si peu de candidat en tenue, avec le sourire, prêt à y aller.

Est-ce vraiment coûteux, honteux, indéfendable, d'avoir pour nos entrepreneurs au moins le même filet de sécurité que leurs employés ?

#chapter | 49 | 16 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.282Z |  | 2025-05-29T21:00:49.614Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7333955988594573312 | Text |  |  | Here's one irony that kills me in Canada.

We tell entrepreneurs: "Take risks! Innovate! Build the future!" 
Then when they fail, we say: "Sorry, no safety net for you."

An employee gets laid off? 
Employment insurance kicks in. 
A founder's startup crashes? 
Radio silence.

Think about it: 
→ Employee: 55% of salary covered for months 
→ Founder: $0. 
Figure it out yourself.

Even though they: 
• Create jobs 
• Drive innovation 
• Take risks 
• Generate tax revenue when successful

Meanwhile, we wonder why 50% of Canadian tech founders never start again. 
Why we have 4.6x fewer repeat founders than the US. 
Why our best talent moves south or disappears into corporate jobs.
Why we are a lifestyle economy with terrible productivity.

Here's my question:
If we're asking entrepreneurs to bet everything — their savings, their sanity, their relationships — shouldn't they get the same basic safety net as everyone else?
What if employment insurance covered founders too? 
What if personal guarantees had limits? 
What if we actually meant it when we said "innovation matters"?

Because right now, we're asking people to jump without a parachute. Then acting surprised when they don't want to jump again.
What would change if founders had at least the same safety net as employees?

#chapter | 364 | 190 | 14 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.284Z |  | 2025-05-29T20:42:45.994Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7333542616178847745 | Text |  |  | Tout les fondateurs tech expérimentent activement les stacks IA.
Mais très peu ont franchi le pas d'en faire une nouvelle startup.

Pourquoi ?

Je parle des fondateurs les plus aguerris — ceux qui testent, construisent, affinent des prototypes. Mais quand il s’agit de se lancer ?
Silence radio.

Parce qu’ils se posent les questions que d’autres cherche à ignorer :
▷ L’évaluation de son risque - ce n’est pas sexy, mais bien réel
▷ Trouver un axe différenciant, un marché à transformer, disrupter,
▷ Une competition qui peut surgir à tout moment, et tout détruire rapidement.

Souvenez-vous de Google I/O, le mois dernier :
Une keynote.
Et boom. Dashlane, 1Password, et des dizaines d’autres ont vu leurs avantages concurrentiels s’effondrer.
Des années de développement. Des millions levés éffacés — non pas par échec, mais parce que une Big Tech a décidé d'adresser une nouvelle opportunité, ton opportunité...

Alors pendant que tout le monde se rue sur le “AI-powered everything”,
les fondateurs expérimentés posent d’autres questions :

▷ Que se passe-t-il si OpenAI sort cette fonctionnalité gratuitement ?
▷ Comment construire quelque chose que Google ne pourra pas répliquer en 6 mois ?
▷ Où sont les marchés trop petits pour un Big Tech, mais assez grands pour moi ?


Le paradoxe est réel : plus on comprend l’IA, moins on est prêt à tout miser dessus.
Parce que la leçon la plus dure à accepter, souvent, c'est que d'être le premier ne sert à rien si tu ne peux pas rester pertinent sur la durée.

Alors… Est-ce que les fondateurs tech les plus lucides procrastinent à l'excès, ou... font-ils simplement preuve d'intelligence stratégique ?

#chapter | 19 | 0 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.285Z |  | 2025-05-28T17:20:10.330Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7333538642801446912 | Text |  |  | Most tech founders are actively experimenting with AI stacks —
but few have taken the leap into building a startup around it.

Why?

I'm talking about the smartest founders in the room — the ones who've been learning, building prototypes, testing models. 
But when it comes to launching? Radio silence. 

Here's what they see that others don't: 
▷ Risk assessment isn't sexy, but it's real 
▷ Defining a defensible market position is harder than ever 
▷ But the biggest fear: your entire business can vanish overnight 

Remember Google I/O few weeks ago? 
One keynote. Boom. Dashlane, 1Password, and dozens of other companies just watched their moats disappear. 
Years of development. Millions in funding. Gone. 
Not because they failed — because Big Tech decided to eat their lunch. 


So while everyone's rushing to build "AI-powered everything," the experienced founders are asking different questions: 
▷ What happens when OpenAI releases this feature for free?
▷ How do I build something Google can't replicate in 6 months? 
▷ Where's the market that's too small for Big Tech but big enough for me? 

The paradox is real: the more you understand AI, the less likely you are to bet your life on it. Understanding the customer problem, the value UX and prioprietary data matters more than ever. 
Tech founders have learned the hardest lesson: being first doesn't matter if you can't stay relevant. 

So, are we witnessing the smartest founders sitting this wave out? 
Or are they just being... smart?

#chapter | 9 | 5 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.286Z |  | 2025-05-28T17:04:23.003Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7331375638831915008 | Text |  |  | 🗓️ 17 mois.

C’est le temps moyen qu’un fondateur tech passe dans le déni, pour pouvoir admettre l'échec de sa startup.

Parce que fermer son entreprise, ce n’est pas juste accepter que la compagnie échoue — C’est surtout se confronter à soi-même, pour accepter la réalité

🏃‍♂️Et ça commence souvent par une course désespérée :
▷  Chercher LE client miracle qui va tout sauver
▷  Attendre après l'acquéreur providentiel qui "s'est montré très interressé"
▷  Bricoler le dossier de subvention, ou de dette, pour acheter du temps
▷  Bombarder d’e-mails des investisseurs “visionnaires” qui sauront voir l'opportunité, pas comme les autres,
▷  Se convaincre qu’un dernier pivot suffira

Tout ça pendant que la réalité avance, en silence :
▷ La dette perso qui s’accumule - pas/peu de salaire, apport en cash, ...
▷ Le filet de sécurité ? Disparu (voir ⬆️)
▷ La ligne entre ta santé et celle de la startup qui devient floue


Et là arrive l’équation dont personne ne parle :
💸 Plus tu attends, plus le prix à payer est lourd.
Chaque mois passé dans le déni ne grille pas juste du runway — Il brûle ton avenir, et parfois bien plus => => https://lnkd.in/eGwBtAjW


J’ai interviewé des fondateurs qui ont perdu: maison, économies, couple, santé, …parce qu’ils n’arrivaient pas à lâcher un business qui était déjà mort, d'une certaine façon. Et le plus tragique ? Beaucoup auraient pu partir avec quelque chose, s’ils avaient regardé la réalité en face, plus tôt.

💭Mais personne ne veut leur dire une vérité, si difficile à entendre.


Il est temps d'accepter que fermer une startup, c'est un échec, mais pas une faute. Celà doit (re)devenir une décision rationnelle, et pouvoir être considéré comme une solution. 
Parce que parfois, le choix le plus courageux, ce n’est pas de continuer — c’est de savoir quand s’arrêter pour mieux redémarrer.

#chapter | 15 | 1 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.287Z |  | 2025-05-22T17:49:22.670Z | https://www.linkedin.com/feed/update/urn:li:activity:7323509658634133504/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7329194905304469504 | Text |  |  | 💥 Le sport préféré des startups canadienne et québécoise? La course aux subventions.


Nombre de fondateurs passent plus de temps à chasser les subventions qu’à chercher des clients. Certains construisent leur runway avec 70 % d’argent public.
Pas avec du revenu. Pas avec de la dette. Pas avec des investisseurs. 
Juste des subventions.

Quand je leur demande à certains leur stratégie de croissance, ils me déroulent leur “cocktail de subventions” et toutes les demandes en cours. Leur roadmap produit ? Parfaitement alignée avec les priorités de financement — mais pas avec les besoins du marché. Leur premier client ? Massivement subventionné, sans engagement long terme, ni retour réel.

💸 Le problème ? Ce “cash gratuit” a un coût invisible :
▷ Des startups qui s’organisent, s’optimisent pour les critères de subvention, pas pour les problèmes clients
▷ Des fondateurs devenus experts en dossiers, pas comprendre et signer du business
▷ Des compagnies sous perfusion, devenant des zombies, qui auraient dû pivoter — ou échouer rapidement.

🪞 Soyons honnêtes :
▷ On a créé un système où des startups peuvent survivre des années sans prouver leur Porduct-Market Fit
▷ Où la validation gouvernementale a remplacé la validation client
▷ Certains écosystèmes — comme les VC US — nous traitent de fou, nous voyant tenter de surfer l’océan en combinaison de hockey,
▷ Et cette approche continue d’alimenter notre usine à “startups zombies” — des compagnies qui sont juste là, qui existent, mais ne grandissent pas, et ne créé ni d’emplois, ni de valeur, ni de propriété intellectuelle monetisable..

💥 Et le plus dur à entendre ? Quand ces startups épuisent toutes les subventions, elles découvrent :
▷ Qu’elles ont construit un truc qui ne tient pas debout seul
▷ Qu’elles ont juste repoussé l’inévitable — à un coût énorme, pour les clients, pour les fondateurs, pour les contribuables.


Il faut qu’on accepte de changer les règles. On se le refuse, et ensuite on chiale. Il faut normaliser la croissance saine, plutôt que la survie subventionnée.
Parce que parfois, ce qu’il faut, ce n’est pas plus de runway… Mais d’oser regarder la réalité en face, plus tôt.

#chapter | 21 | 7 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.289Z |  | 2025-05-16T17:23:55.281Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7329166290760179713 | Text |  |  | 💥 Why is chasing grants the startup playbook in Canada?

Ever notice how many founders here spend more time chasing grants than chasing customers? Some build their runway with 70% government money.
Not with revenue. No personal debt. No investors. 
Just grants.

When I asked about their growth strategy, they walked me through their “grant recipe” and all their applications. Their product roadmap? Aligned perfectly with funding priorities — not market needs. First customer? Heavily subsidized, no long-term commitment, no payback.

💸 The problem? This “free money” comes with invisible costs:
▷ Startups optimizing for grant criteria instead of customer problems
▷ Founders becoming expert grant-writers, not business builders
▷ Companies surviving on subsidies, becoming zombies that should pivot — or fail fast

🪞Let’s be honest:
▷ We’ve created a system where startups survive for years without proving market fit, where government validation replaces customer validation
▷ Some ecosystems — like the US VC scene — laugh at us, watching us build surfers trying to ride the ocean in a hockey suit
▷ This approach fuels a startup zombie factory —Where companies exist, but don’t grow. Don’t hire. Don’t create valuable IP.

💥 And the real kicker?
▷ When these companies finally run out of grants, they realize:
▷ They’ve built something that can’t stand on its own.
▷ They’ve just delayed the inevitable — at massive cost.
To customers. To founders. To taxpayers.


We need to normalize healthy growth over subsidized survival.
Because sometimes, the most valuable thing isn’t more runway — It’s facing reality sooner.

#chapter | 44 | 15 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.290Z |  | 2025-05-16T15:30:13.042Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7328447340061573120 | Text |  |  | 💥 Le plus dur à entendre pour un startup founder? 
Parfois, ce qui bloque l'entreprise… ben c’est toi.

La semaine dernière, j’ai rencontré un fondateur qui a fait un choix rare:
Sortir de sa startup qu’il avait bâtie de zéro à 9M$ de revenus.

Il a compris que son truc, c'est de concevoir, construire. 
Pas d'opérer.
Et à mesure que l'entreprise grandissait, ce décalage est devenu souffrance, trop forte pour être ignoré.

Ses mentors, son network, ChatGPT… tous lui ont donné les mêmes conseils :
– Trouve un remplaçant,
– Forme-le,
– Puis retire-toi comme aviseur au board.

Mais la réalité est rarement aussi simple.

➡️ Dans une startup, le départ du fondateur, c’est souvent perçu comme un signal de déclin — pour le board, les employés, parfois même les clients.
➡️ Le mythe collectif veut que “le fondateur doit tenir bon coûte que coûte.”
➡️ Et le coût réel ? Trouver la bonne personne, transférer la vision, gérer le timing — tout ça se heurte souvent au refus… du board lui-même.


Il faut revoir notre perception du rapport fondateur/startup.
Parce que parfois, le geste le plus courageux, ce n’est pas de continuer…
C’est de reconnaître que l’entreprise a besoin d’une autre énergie pour passer la prochaine étape.

Parfois, vous grandissez avec la startup,
Parfois, votre startup vous dépasse.
Et ce n’est pas un échec. Mais une naturelle évolution.

#Chapter | 6 | 1 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.291Z |  | 2025-05-14T15:53:21.838Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7328169668186152960 | Text |  |  | 💥 Sometimes you're the barrier, not the bridge.

Last week, I met a founder who made the impossible choice — stepping away from the company he built from nothing to seven-figures in revenue.
Because he recognized he was a builder, not an operator. 
And as the company scaled, that misalignment became impossible to ignore. 

ChatGPT, Claude and his peers all gave the same advice:
- Recruit you successor
- Transfer the knowledge 
- Resign gracefully
- Advise on long-term strategy
But reality is more complex. 

For early-stage companies, a founder stepping away often signals death to stakeholders. There's this collective myth that founders must hold on at all costs — that leaving means failure. But the direct cost - finding the candidate, taking the time, transfer the knowledge - is not negligeable, and meet board refusal. The indirect cost - transitioning from CEO to Chairman or Advisor - create mixed feelings.

So, we need to normalize the conversation around founder-company fit. Because sometimes the most courageous act isn't persisting — it's recognizing when your company needs someone else to take it further. 

Sometimes you outgrow your business. But sometimes the business outgrows you
And that's not failure. That's clarity.

#Chapter | 21 | 0 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.293Z |  | 2025-05-13T21:29:59.704Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7326988770241560578 | Text |  |  | So true.

A challenge many founders face: staying focused. Choose your battles wisely, align with the right allies, and stay true to your purpose. Spreading yourself too thin is a fast track to failure

#chapter | 9 | 0 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.294Z |  | 2025-05-10T15:17:31.694Z | https://www.linkedin.com/feed/update/urn:li:activity:7326984403396476930/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7326375659398705152 | Text |  |  | 💥“It’s too early. You’re onto something. You need to pivot”

Board members, investors, mentors, peers. They want you to hustle, try harder. 
Or don't want to be the one to tell you the harsh truth.
And you believe it… because you’ve been taught to prove them wrong.

So, you turn down a buyout, life-changing or not.
And keep going. Not out of ambition — but out of obligation.

Because walking away feels like giving up.
Because stopping looks like failure.
Because someone else decided this isn’t your finish line.

In startup culture, we’ve made suffering a badge of honor.
It’s time to change the conversation:
✅ Sustainable ambition
✅ Real alignment between founders and shareholders
✅ Outcomes that aren’t just big — but healthy to all

#Chapter

-----------------------------------------------------------

💥 “C’est trop tôt. Tu tiens quelque chose. Il te faut faire un pivot.”

Membres du board, investisseurs, mentors, pairs... tout le monde veut te voir continuer, persister.
Car aussi personne n'ose être celui qui va (te) dire les vraies affaires. 
Alors tu y crois… parce qu’on t’a appris à prouver qu’ils ont tort.

Alors tu déclines une offre de rachat, qu’elle soit raisonnable ou importante.
Et tu continues. Pas par ambition — mais par obligation.

Parce que vendre tôt, tu donnes l'impression d'abandonner.
Parce qu’arrêter tôt, ça sonne comme un échec.
Parce que personne ne t'a dit que c'est toi qui décidait de la ligne d’arrivée.

Dans la culture startup, on a fait de la souffrance, de la perseverance, une médaille du mérite incontournable d'une aventure entrepreneuriale.

Il est temps de changer la perspective sur le sujet :
✅ Le droit à une ambition raisonnable
✅ Revoir l'alignement entre fondateurs et actionnaires
✅ Pas uniquement la quête d'un gros exit… mais des sorties bénéfiques pour tous.

#Chapter | 18 | 0 | 0 | 6mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.295Z |  | 2025-05-08T22:41:14.678Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7323509658634133504 | Text |  |  | 💣 $350,000

That’s the average cost of a startup crash… for founders.
And at the heart of it? 👉 Personal guarantees.

Brilliant, naive, ambitious — or simply poorly advised — too many founders end up broke, because they thought they had to guarantee everything.

Because as long as things are going well, they’re told: “A personal guarantee? Just a formality. Don’t worry — we’re here to support tech founders.”
Then when things go south: pressure, legal threats, aggressive tone.
It’s a well-known, systemic process..

And No — these aren’t isolated cases.
And Yes — the final bill for founders is often even higher.
Because before the crash, many:
– stop paying themselves
– inject their savings to make payroll
– double down to “save the company”
💥 And in the end? Personal bankruptcy for some. A long road to recover for all.

So now what?

Do we keep complaining about the “broken startup ecosystem,” celebrating a few rare wins while punishing those who actually take the risks?
Or do we decide it’s time to change the system — from the ground up?
Not with words. With real solutions.

I’m giving myself 45 days to make one happen.
📢 If this matters to you: share it. Get the conversation going.
📩 And if you want to go deeper, DM me.

#Chapter

-------------------------------------------------------------------------

💣 $350,000

C’est la facture moyenne pour les fondateurs quand il faut s'arrêter.
Et au cœur de ce naufrage ? 👉 La caution personnelle.

Brillants, naïfs, ambitieux ou juste mal accompagnés,
trop d’entrepreneurs finissent à sec, pour avoir cru qu’il “fallait” tout garantir.

Parce que tant que tout va bien, on leur dit :
“La garantie perso ? Juste une formalité. Pas d’inquiétude, on est là pour aider les entrepreneurs.” Puis, quand ça dérape : pressions, menaces de poursuite, ton comminatoire.
Un mécanisme bien rodé.

Et non, ce ne sont pas des cas isolés.
Et oui, la facture est souvent encore plus salée.
Car avant le crash, beaucoup ont :
– cessé de se verser un salaire
– injecté leurs économies pour payer les salaires
– abondé la tréso, pensant “sauver” l’entreprise
💥 Et à l’arrivée ? Faillite personnelle pour certains, et un processus long à digérer pour tous.

Alors maintenant, on fait quoi ?

Soit on continue de se plaindre de “l'écosystème startup”, de célébrer les trop rares succès, tout en punissant ceux qui osent, qui prennent des risques. Soit on décide de faire bouger les choses.
Par la base. Avec des solutions, pas juste des mots.

Moi, je me donne 45 jours pour mettre en place une solution. 
📢 Si c’est important pour vous : partagez, faites parler du sujet.
📩 Mais si vous voulez aller plus loin, envoyez un DM.

#Chapter | 79 | 19 | 10 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.297Z |  | 2025-05-01T00:52:46.848Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7320623075186655232 | Text |  |  | Et si “Vibe” était la tendance de 2025 ?

Franchement, pour moi, la question commence à se poser.

Aujourd’hui, j’ai rencontré mon premier "Vibe Entrepreneur" (après un "Vibe Engineer" et un "Vibe Creative").
En 3 mois seulement, il a lancé sa startup — solo.
💸 Il a atteint 100K$ de revenus mensuels en 11 semaines
❌ Aucun cofondateur
❌ Pas de background tech
❌ Pas d’équipe marketing

Que des outils d’IA, utilisés avec intelligence, créativité et beaucoup de tests-erreurs. De l’étude de marché au developpement no-code, du branding à l’analyse client : il a tout construit, testé, lancé.  Seul.

💡 Ça veut dire quoi, "Vibe"? => C’est démultiplier sa productivité en se dotant de nouvelles compétences, tout ça grâce aux outils de GenAI.
On ne remplace pas un sachant ou un expert, mais on "s'octroie" des capacités qui semblaient inaccessibles, nous permettant concrétiser, accélérer, amplifier, ce qu'on accomplir. 

Mais attention, j'y vois quelques réserves :
✅ La barrière technologique, au moins jusqu’au MVP, n’a jamais été aussi basse.
Aujourd’hui, tu peux essayer… et voir que ça ne fonctionne pas, en plus très vite.
🚫 Mais surtout, avoir une idée ne suffira plus.
Il faut comprendre le marché, le domaine, les besoins, mieux que jamais. Et exécuter de façon super pro, car justement la barrière technologique ne protège plus.

Alors, est-ce qu’on entre dans l’ère du "vibe" ? Ou est-ce juste une tendance du moment, comme... le "tout blockchain" par exemple?

👇 On est du pour une bonne bataille idéologique en commentaire 🤪 | 19 | 5 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.298Z |  | 2025-04-23T01:42:31.724Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7320622831732416512 | Text |  |  | So… Will 2025 be the year of the "Vibe Entrepreneur"?


Today, I met my first Vibe Entrepreneur (after a Vibe Developer and a Vibe Creative).
In just 3 months, he launched a startup — solo.
🚀 Hit $100K in monthly revenue in 11 weeks.
❌ No co-founder
❌ No tech background
❌ No marketing team

Just AI tools, used smartly, boldly, and creatively — from market research to no-code dev, from branding to user insights.
He built, tested, shipped. 
Alone.

💡 But what is Vibe? = it's about using AI to massively amplify your capabilities.
But it’s not about replacing roles. It’s about unlocking what felt unreachable so far.

But one thing’s for sure:
✅ The tech barrier — from idea to MVP — has never been lower.
You can now test and fail faster than ever.
🚫 But a good idea isn’t enough anymore.
You need deep customer insight, market understanding and sharp execution — or you’re just making noise.

So, are we entering the Vibe Era? Or is it just a shiny, short-lived fad?
👇 Let’s have a good, old polarizing convo in comments 😅 | 5 | 0 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.299Z |  | 2025-04-23T01:41:33.680Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7320469912441753600 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2154f270-e1d2-4797-9df6-16a92240adba |  | On May 22, I’ll be live on "How I Built This: Not Another Founder Story" — by Amélie.

If you know Amélie, you know this won’t be your usual startup fluff.
It’s going to be sharp, unfiltered, and (hopefully) useful as hell.

We’ll talk founder journey, reinvention — and why the “bounce back” narrative needs to change.

Come hang. It’s gonna be a good one. 😉

🎙️ May 22 — don’t miss it. | 18 | 0 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.300Z |  | 2025-04-22T15:33:54.880Z | https://www.linkedin.com/feed/update/urn:li:activity:7320262592386510848/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7318067667901288448 | Text |  |  | 🗓️ 14 mois


👉 C’est le temps moyen qu’il faut à un entrepreneur tech. pour passer à l’après.
Parce qu’une fermeture de startup, une faillite, un exit forcé… c’est long.
Très long.
Trop long.

❗Puis vient le vrai choc : le vide.
La perte de la fonction sociale de/pour l’entrepreneur.
Rien pour se redéfinir.
Rien pour rebondir.
Parce que ce n’est pas dans la culture d’ici.

💥 Alors, la stat qui tue au Canada : 50 % des entrepreneurs tech. ne (se) relanceront pas dans une nouvelle startup. C’est énorme.
Sur ce sujet, nous sommes l’antithèse des États-Unis.

Pendant ce temps, tous les indicateurs de la tech canadienne sont dans le rouge :
Moins de deals. Moins de financements. Moins d’ambitions.

Vous me voyez venir ?
On a un problème. Un gros.

Il faut faire bouger les choses.
Avec d’autres, on a décidé de pousser le changement.

Ça s’appelle Chapter. 🚀

----------------------------------------------------------------------------

🗓️ 14 months


👉 That’s the average time it takes for a tech founder to move on.
Because a startup shutdown, a bankruptcy, a forced exit… takes time.
Lot of time.
Too much time.

❗Then comes the real shock: the void.
The loss of the tech founder’s social role.
Nothing to redefine yourself.
Nothing to bounce back.
Because that’s just not part of our culture here.

💥 So here’s the killer stat in Canada: 50% of tech entrepreneurs never start another company. That’s massive.
On this issue, we are the antithesis of the U.S.

Meanwhile, all indicators in Canadian tech are flashing red:
Fewer deals. Less fundings. Lower ambitions.

You see where I’m going with this?
We have a problem. A big one.

It’s time to shake things up.
Together with others, we’ve decided to drive change.

It’s called Chapter. 🚀 | 46 | 3 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.302Z |  | 2025-04-16T00:28:15.150Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7315892970048610304 | Text |  |  | 🗓️ One year.

👉 One year since I filed for bankruptcy on my last startup.
One year since the end of Livescale — a wild ride, right through the heart of the pandemic — built with an incredible team…
…and wrapped up in a way that was long, draining, and heavy.

❌ And I felt completely empty. I was not myself for months.
So the “fun” of startup life? Let’s not even go there.

I was like running like a clanky OS - in safe mode — trying to find a solution for our team, our clients, and all the people who had trusted us.
And for that, I paid the price — emotionally, physically, mentally.


In private circles, I now talk about it openly. No filter, no shame, the brutal truth.
I share it all: the stories, the choices, the consequences, the lessons.

But doing it out here, in public, is still hard.
It’s not my thing. Like so many other tech founders, I don’t love being exposed.
And let’s be honest — talking about failure is still stigmatized, whether we admit it or not, across Canada. Even in 2025, despite all the empathy we claim to promote.


👏 So a huge shoutout to those who dare to speak up —
Amélie Morency, Marie Chevrier Schwartz, Dominic Gagnon, Nicholas Routhier, BERT.rand(eng, MBA) Nepveu and so many others for breaking the silence, for keeping the conversation rolling.
After more than 150+ interviews on the topic in the past few months, I know just how much it helps those who aren’t ready — or willing — to take that step.


💬 And for everyone else:
There’s absolutely no shame in staying low profile.
Whether your story is inspiring or simply… uneventful. | 45 | 5 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.303Z |  | 2025-04-10T00:26:46.778Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7315888709063565312 | Text |  |  | 🗓️ Aujourd’hui, ça fait un an.

👉 Un an que j’ai mis ma dernière startup en faillite.
Un an depuis la fin de Livescale — une aventure assez folle, en pleine pandémie — portée par une équipe de feu…
…et terminée de manière lente, usante, pesante.

❌ J’étais vidé. Je n’y trouvais plus aucune satisfaction, et depuis de long mois.
Alors le “fun” de la startup life ? N’en parlons pas.

J’étais juste en "mode sans échec" - soit en fonctions minimales -, à chercher une solution pour nos équipes, nos clients, et tous ceux qui nous avaient fait confiance.
Et pour ça, j’en ai payé le prix — émotionnel, physique, mental.


Dans un cercle restreint, j’en parle aujourd'hui franchement, sans filtre, souvent sans pudeur. Et je partage : anecdotes, choix, séquelles, apprentissages, tout y passe.

Mais ici, à ciel ouvert, c’est toujours difficile. C'est pas mon truc. Comme tant d’autres fondateurs tech, je n'aime pas m'exposer. 
Car en plus, parler d’échec est encore stigmatisant, qu'on le veuille ou non, partout au pays. Même en 2025, et malgré toute l'empathie qu'on cherche à partager.

👏 Alors bravo à celles et ceux qui osent parler, comme Amélie Morency, Marie Chevrier Schwartz, Dominic Gagnon, Nicholas Routhier, BERT.rand(eng, MBA) Nepveu 🥽⚜️, Judith Fetzer, et tant d’autres, pour la prise de parole, désamorcer la conversation. Après plus de 150+ entrevues ces derniers mois sur ce thème, je sais que ça aide énormément ceux qui ne veulent pas, ou ne sont pas prêts, à faire le pas.

💬 Et pour les autres, il n’y a aucune honte à rester low profile sur son histoire. Que cette dernière soit belle ou plate. | 198 | 18 | 0 | 7mo | Post | Virgile Ollivier | https://www.linkedin.com/in/virgileollivier | https://linkedin.com/in/virgileollivier | 2025-12-08T04:42:08.304Z |  | 2025-04-10T00:09:50.880Z |  |  | 

---



---

# Virgile Ollivier
*Chapter*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 9 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Are Canadian founders getting a raw deal?](https://betakit.com/are-canadian-founders-getting-a-raw-deal/)
*2025-07-21*
- Category: article

### [Opening the next chapter](https://ca.linkedin.com/in/virgileollivier)
*2021-03-16*
- Category: article

### [Effortless Online Systems Podcast | Nivek Harrison](https://thevirtualchapter.co/podcast?srsltid=AfmBOoote_7fmFnBVOv8oc9KiADNXavW0sEPf9veMRRXSJwgxXmAlwhr)
*2025-01-01*
- Category: podcast

### [LiveScale - 2025 Company Profile - Tracxn](https://tracxn.com/d/companies/livescale/__DkNB6ZwlYW8TI1BH3xwYt2-X6oNbhTVIBBKHIBaKcew)
*2025-04-25*
- Category: article

### [Publications - Laboratoire Informatique d'Avignon](https://lia.univ-avignon.fr/publications-fr/)
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 151,879 words total*

### Are Canadian founders getting a raw deal? | BetaKit
*1,688 words* | Source: **EXA** | [Link](https://betakit.com/are-canadian-founders-getting-a-raw-deal/)

Plus: The pressure to adopt AI has created a “Wild West” for corporate cybersecurity.

When Katherine Homuth [started pitching](https://betakit.com/betakit-town-hall-showcases-canadian-ambition-at-home-and-abroad/) the idea of a “founder constitution,” she expected every investor in the room to roll their eyes.

The Oomira CEO has argued that a standard employment agreement would give founders more control over their deal terms and working conditions versus having them dictated by VCs. Informed by her experience as founder of SRTX—which she recently departed in a deal to secure the company necessary funding—Homuth said at Startupfest: “An investment document is 100 percent red flags.”

VCs I spoke with said such an agreement [might be a tough sell](https://betakit.com/srtx-and-oomiras-katherine-homuth-is-making-the-case-for-a-founder-constitution-heres-what-that-might-look-like/), but concurred that founders shouldn’t get financially pummelled if their startup fails.

Nine out of 10 startups are [_expected_ to fail](https://web.archive.org/web/20240225051714/https://startupgenome.com/article/the-state-of-the-global-startup-economy). But some claim the price of failure in Canada is so destructive that it disincentivizes entrepreneurship altogether.

Virgile Ollivier has interviewed more than 150 entrepreneurs for a new founder support platform called Chapter. He said the average personal cost of startup bankruptcy is $347,000, and estimates that half of the entrepreneurs he spoke with won’t start another company.

Sign up now for the latest updates on Canadian startup and tech news, delivered straight to your inbox.

Homuth’s suggested founder constitution could help, but deal terms are often dictated by the amount of leverage one has to negotiate.

In the US, founder-friendly SAFE agreements are the norm for early-stage fundraising deals. With a lot more private capital to deploy, the intense competition for deals tilts the scales in favour of founders, said entrepreneur and VC Bertrand Nepveu.

Canada’s early-stage fundraising landscape is [currently bleak](https://betakit.com/seed-deals-in-q1-2025-hit-pandemic-era-low-as-canadian-vc-decline-continues-report/). Founders often face limited equity and debt options with unfavourable deal terms, particularly from banks and large institutions, VCs told me. Even programs meant to boost entrepreneurship rates, such as BDC’s Business Loan Accelerator Program, require a personal guarantee.

Canadian entrepreneurs need more capital options and deal terms that protect them when things go wrong. It’s unlikely that one will happen without the other.

Madison McLauchlan

Reporter

* * *

[![Image 1](https://cdn.betakit.com/wp-content/uploads/2025/07/image-Sadhvika-Challa-Pump.png)](https://www.pump.co/book-a-demo)

**Stop Overspending on Cloud**

At Pump, we help startups unlock lots of savings on their cloud bills for free—automatically. No long-term lock-ins, no complex commitments. Just better pricing, powered by our smart infrastructure purchasing platform.

Whether you’re a fast-growing team or just starting out, Pump ensures you’re always paying the lowest possible rate—without the headaches. Our customers save an average of 20-50% on their cloud spend, and we’re just getting started.

Join the more than 1000 startups already using Pump to extend runway and focus on what matters: building.

Want to see what you could be saving? [Book a free savings analysis.](https://www.pump.co/book-a-demo)

* * *

#### [Tailscale CEO Avery Pennarun says pressure to adopt AI has created a “Wild West” for corporate cybersecurity](https://betakit.com/tailscale-ceo-avery-pennarun-says-pressure-to-adopt-ai-has-created-a-wild-west-for-corporate-cybersecurity/)

Many companies are facing pressure to quickly adopt AI, including agentic solutions. In an interview with BetaKit, Tailscale co-founder and CEO Avery Pennarun claimed that this rush has created a chaotic new “Wild West” for corporate cybersecurity.

In allowing easier access to their systems for large language model and AI agents, Pennarun said some firms have been skipping over some necessary security and privacy checks and simply putting their own private API servers on the public internet—big missteps that open them up to a world of risk, according to the CEO.

* * *

![Image 2](https://cdn.betakit.com/wp-content/uploads/2025/07/Jeff-Shiner-2x1-1.jpg)

#### [Longtime 1Password CEO Jeff Shiner moves to executive chair, cedes reins to David Faugno](https://betakit.com/longtime-1password-ceo-jeff-shiner-moves-to-executive-chair-cedes-reins-to-david-faugno/)

After 13 years at the helm of 1Password, Jeff Shiner has moved from co-CEO to executive chair of the Toronto-based password management company’s board of directors. David Faugno, who became co-CEO of 1Password alongside Shiner last November, will continue to lead the firm going forward as its sole CEO. Faugno has also joined the board.

In a LinkedIn post announcing the tra

*[... truncated, 8,693 more characters]*

---

### Virgile Ollivier - Chapter | LinkedIn
*5,915 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/virgileollivier)

Virgile Ollivier - Chapter | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/virgileollivier#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-williamston-nc?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fvirgileollivier&fromSignIn=true&trk=public_profile_nav-header-signin)[Register now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=virgileollivier&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fvirgileollivier&trk=public_profile_nav-header-join)[![Image 1](https://static.licdn.com/aero-v1/sc/h/9c8pery4andzj6ohjkjp54ma2)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fvirgileollivier&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://media.licdn.com/dms/image/v2/D4E16AQFaovcHyifIOw/profile-displaybackgroundimage-shrink_200_800/profile-displaybackgroundimage-shrink_200_800/0/1711061798366?e=2147483647&v=beta&t=THf6ICPnEy8ykPLQCssGcj8IRYedxbDCqFztVxgUuCw)

![Image 3: Virgile Ollivier](https://media.licdn.com/dms/image/v2/D4E03AQGO0VQrzEIx7g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1715898821647?e=2147483647&v=beta&t=oxhuO8byPo7Mgyyoah9-nQd0PSMuiK1a1yEMdp1z0gs)

![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQGO0VQrzEIx7g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1715898821647?e=2147483647&v=beta&t=oxhuO8byPo7Mgyyoah9-nQd0PSMuiK1a1yEMdp1z0gs)
Sign in to view Virgile’s full profile
--------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=virgileollivier&trk=public_profile_logo_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=virgileollivier&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Virgile Ollivier
================

![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQGO0VQrzEIx7g/profile-displayphoto-shrink_200_200/profile-displayphoto-shrink_200_200/0/1715898821647?e=2147483647&v=beta&t=oxhuO8byPo7Mgyyoah9-nQd0PSMuiK1a1yEMdp1z0gs)
Sign in to view Virgile’s full profile
--------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=virgileollivier&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_sign-in-modal_join

*[... truncated, 58,743 more characters]*

---

### Effortless Online Systems Podcast | Nivek Harrison
*333 words* | Source: **EXA** | [Link](https://thevirtualchapter.co/podcast?srsltid=AfmBOoote_7fmFnBVOv8oc9KiADNXavW0sEPf9veMRRXSJwgxXmAlwhr)

![Image 1](https://static.showit.co/1600/u1l90yYlSqCzM6UJ-lIutw/138900/tvc_shoot2-7.jpg)

[](https://thevirtualchapter.buzzsprout.com/)[](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)

Drowning in the back-end of your business? Let’s fix that. _Effortless Online Systems_ is your go-to podcast for smarter workflows, smoother scaling, and systems that actually make your life easier. Tune in for bite-sized episodes packed with actionable strategies, tech breakdowns, and behind-the-scenes insights from six and seven-figure businesses.

### effortless online systems

[](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)[LISTEN ON APPLE](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)
The Podcast That Makes Systems Sex
----------------------------------

y

[](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[LISTEN ON Spotify](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[](https://thevirtualchapter.buzzsprout.com/)[listen on buzzsprout](https://thevirtualchapter.buzzsprout.com/)

Because scaling shouldn’t feel like spinning plates. We’ll break down the exact systems that help you ditch the overwhelm and grow with ease.

How to Run Your Business Like a CEO, Not a One-Person Circus
------------------------------------------------------------

Not all tools are created equal. We’ll tell you what’s actually worth your time, what’s overhyped, and how to make tech work for you (not the other way around).

### what you'll learn here:

Forget the fluff. We’re pulling back the curtain on how top business owners keep things running smoothly without burning out.

[](http://)

[### listen now](https://www.buzzsprout.com/1997026/episodes/10743399)
### 75. It's time to audit your tech stack!

[](https://www.buzzsprout.com/1997026/episodes/10743399)
### 2. Leading a Million Dollar Team with Ellie Swift

### FAN FAVES

[](https://www.buzzsprout.com/1997026/episodes/14461706)[### listen now](https://www.buzzsprout.com/1997026/episodes/14461706)
### 5. OBM or VA? Who do you need on your team?

[](https://www.buzzsprout.com/1997026/episodes/10821109)[### listen now](https://www.buzzsprout.com/1997026/episodes/10821109)
### 96. 5 Free Tools You Need in Your Business for 2025 (That You’re Probably Not Using!)

[](https://thevirtualchapter.buzzsprout.com/1997026/episodes/16124299)[### listen now](https://thevirtualchapter.buzzsprout.com/1997026/episodes/16124299)

![Image 2](https://static.showit.co/1600/MD7Vb7XHP64BrFhrqgkBpQ/138900/marga888_photo_of_an_old_street_inperfect_cambridge_book_nest_ef3908f8-e033-45b1-90a8-a9ad031721cb_2.png)

I’m Nivek, your resident systems nerd and the woman making business operations _sexy_.

[](https://thevirtualchapter.co/about)[more about me](https://thevirtualchapter.co/about)
Meet your host

Every business owner hits a point where they realise winging it isn’t a growth strategy. That’s where systems come in.

On **_Effortless Online Systems_**, we dive into streamlined workflows, the best tech tools, and proven strategies to help you grow without drowning in admin. If you’re ready to run your business with more ease (and way less stress), you’re in the right place.

My superpower is helping ambitious women scale smarter, work less, and finally feel in control.

[](https://thevirtualchapter.buzzsprout.com/)[](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)[](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)[LISTEN ON APPLE](https://podcasts.apple.com/us/podcast/effortless-online-systems/id1626957686)[](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[LISTEN ON Spotify](https://open.spotify.com/show/4G6JQCnKMIbnPelL9pffRL)[](https://thevirtualchapter.buzzsprout.com/)[listen on buzzsprout](https://thevirtualchapter.buzzsprout.com/)

---

### LiveScale
*1,063 words* | Source: **EXA** | [Link](https://tracxn.com/d/companies/livescale/__DkNB6ZwlYW8TI1BH3xwYt2-X6oNbhTVIBBKHIBaKcew)

### Company Details

Livescale provides a live shopping solution that allows brands to improve the audience engagement and sales conversion rate of their eCommerce through shoppable live videos. Its features include in-video checkout, live chat, branded gamification, customizable design, inventory, order & payment sync, and more. It also offers a white-label live shopping solution for retail brands to engage and sell to customers.

Website[livescale.tv](http://livescale.tv/)

Email ID*****@livescale.tv

Key Metrics

Founded Year

2016

Location

Stage

Seed

Total Funding

Investors

Ranked

Employee Count

Similar Companies

![Image 1: PDF Illustration Image](https://cdn.tracxn.com/images/static/cta/pdf-icon-illustration.svg)

Download LiveScale's company profile

LiveScale has raised a total funding of$3M over 3 round s.Its latest funding round was a Seed round on Mar 16, 2021 for $2M.7 investor s participated in its latest round,lead by[Luge Capital](https://tracxn.com/d/venture-capital/luge-capital/__fUaZQl0zaj0MWHB8TT2spgYJ0PdzE40ueD4rNfM4hlY) and [WatchMojo](https://tracxn.com/d/companies/watchmojo/__At_Ba2fmGepXKLA_vrwLvQVyyB60UBj-eYoRgXHpdTw).

Here is the list of recent funding rounds of

LiveScale

:

| Date of funding | Funding Amount | Round Name | Post money valuation | Revenue multiple | Investors |
| --- | --- | --- | --- | --- | --- |
| Mar 16, 2021 | $2M | Seed | 6111522 | 3607308 | [Luge Capital](https://tracxn.com/d/venture-capital/luge-capital/__fUaZQl0zaj0MWHB8TT2spgYJ0PdzE40ueD4rNfM4hlY), [WatchMojo](https://tracxn.com/d/companies/watchmojo/__At_Ba2fmGepXKLA_vrwLvQVyyB60UBj-eYoRgXHpdTw), and [5 more](https://platform.tracxn.com/a/d/company/QoVT14X_jjgd-FV0tiu7HyuKtHm1JoSXzlp6B9cnaos/livescale.tv#a:funding-and-investors) |
| Jun 17, 2019 | $1M | Seed | 4379240 | 5060215 | [Real Ventures](https://tracxn.com/d/venture-capital/real-ventures/__XPZCizlkpH4IR7IAljMlJQ2mG_mp0uKabeNGMetX0g0), [Panache Ventures](https://tracxn.com/d/venture-capital/panache-ventures/__e3GZaAuy-CUTauMt72OTl84xEVAEORYxeuXevpDnibw), and [1 more](https://platform.tracxn.com/a/d/company/QoVT14X_jjgd-FV0tiu7HyuKtHm1JoSXzlp6B9cnaos/livescale.tv#a:funding-and-investors) |

![Image 2: lock](blob:http://localhost/63e1f5b1c4e612612ccfea893e4c84d1)Access funding benchmarks and valuations.

[Sign up today!](https://tracxn.com/signup)

### LiveScale's employee count trend

LiveScale has 11 - 50 employees as of Jul 24.

Here is

LiveScale

's employee count trend over the years:

![Image 3: chrome_extension_cta_illustration](https://cdn.tracxn.com/images/static/cta/chrome_extension_cta_illustration.svg)

Access Tracxn on any website

Our Google Chrome extension lets you view company details while browsing their websites

[Install Tracxn Extension](https://chromewebstore.google.com/detail/tracxn-extension/mcplkbacfdjapifgiidjidmnfilipnep?hl=en)

Top competitor

s

of

LiveScale

include

[Firework](https://tracxn.com/d/companies/firework/__oMfPWpo-XCG0KtXnkVpq8MpjoLpFOuGhAPQ6wI3KFrg), [Bambuser](https://tracxn.com/d/companies/bambuser/__z-1sBQlhapl4mFu9ur0M_Cjb91xMjoY1qxhC_cqMxNs) and [Eko](https://tracxn.com/d/companies/eko/__IOUw_W4v7LSUV96EPFwQ45dD0bJaO1z7wXrazYDO8i8).

Here is the list of Top 10 competitors of

LiveScale

, ranked by Tracxn score:

| Overall Rank | Company Details | Short Description | Total Funding | Investors | Tracxn Score |
| --- | --- | --- | --- | --- | --- |
| 1st | ![Image 4: Logo for Firework](https://i.tracxn.com/logo/company/fireworkhq_logo_ab84d183-fc43-44c3-9f22-827cadbf0d54.jpeg?devicePixelRatio=2&height=40&width=40) [Firework](https://tracxn.com/d/companies/firework/__oMfPWpo-XCG0KtXnkVpq8MpjoLpFOuGhAPQ6wI3KFrg) 2017 , Redwood City ([United States](https://tracxn.com/d/geographies/united-states/__agFBbaWLXQ9BaxreLIz_EPAASY3VwAK-kFQ6rvJvIco)) , Series B | Provider of a cloud-based software tool to create shoppable and interactive videos | $235M | [SoftBank Vision Fund](https://tracxn.com/d/venture-capital/softbank-vision-fund/__iBoxR9kOl7lv87Qodi9FvPadNCcZMQdUQzjUzbvLg7M), [Lightspeed Venture Partners](https://tracxn.com/d/venture-capital/lightspeed-venture-partners/__PzMkj1UXJCjrJn4ADHeiO_a04brVhLLYKBEqw7d_INY)& [8 others](https://platform.tracxn.com/a/d/company/HDY-T7_xtrEfiorCRGlGJHX6N91eo2pbJ2ovODNkKSY/firework.com#a:funding-and-investors) | 65/100 |
| 2nd | ![Image 5: Logo for Bambuser](https://i.tracxn.com/logo/company/3ae9c2448dbf266dc49151e4dad32413?devicePixelRatio=2&height=40&width=40) [Bambuser](https://tracxn.com/d/companies/bambuser/__z-1sBQlhapl4mFu9ur0M_Cjb91xMjoY1qxhC_cqMxNs) 2007 , Stockholm ([Sweden](https://tracxn.com/d/geographies/sweden/__3OiAv3pREWpxnktEnzWFLBs-TITzSyYFnGpnRCdiEiE)) , Public | Providing solution for live video streaming for businesses | $4.02M | [The Associated Press](https://platform.tracxn.com/a/d/company/52f31105e4b033a23dc72b2f/ap.org), [Vitruvian Partners](https://tracxn.com/d/private-equity/vitruvian-partners/__F-XxJlK7mQeaMul50kWsRQmNw8Djyd_qaWxbAA3

*[... truncated, 11,872 more characters]*

---

### Publications – Laboratoire Informatique d’Avignon
*57,633 words* | Source: **EXA** | [Link](https://lia.univ-avignon.fr/publications-fr/)

*   [Publications](https://lia.univ-avignon.fr/publications-fr/#publications)
*   [Métadonnées](https://lia.univ-avignon.fr/publications-fr/#filtres)
    *   [Auteurs](https://lia.univ-avignon.fr/publications-fr/#auteurs)
    *   [Auteurs de la structure](https://lia.univ-avignon.fr/publications-fr/#affiliated)
    *   [Revues](https://lia.univ-avignon.fr/publications-fr/#revues)
    *   [Année de production](https://lia.univ-avignon.fr/publications-fr/#annees)
    *   [Institutions](https://lia.univ-avignon.fr/publications-fr/#insts)
    *   [Laboratoires](https://lia.univ-avignon.fr/publications-fr/#labs)
    *   [Départements](https://lia.univ-avignon.fr/publications-fr/#depts)
    *   [Équipes de recherche](https://lia.univ-avignon.fr/publications-fr/#equipes)

* * *

2052 documents

### Articles dans une revue 431 document

*   Martin Waffo Kemgne, Olivier Tsemogne, Charles Kamhoua. Shapley value to rank vulnerabilities on attack graphs: Applications to cyberdeception. _Journal of Dynamics and Games_, 2026, 13, pp.130-157. [⟨10.3934/jdg.2025016⟩](https://dx.doi.org/10.3934/jdg.2025016). [⟨hal-05164879⟩](https://hal.science/hal-05164879v1)
*   Hélène Le Cadre, Mandar Datar, Mathis Guckert, Eitan Altman. Learning Market Equilibria Preserving Statistical Privacy Using Performative Prediction. _IEEE Transactions on Automatic Control_, 2025, 70 (11), pp.7125-7140. [⟨10.23919/ECC57647.2023.10178247⟩](https://dx.doi.org/10.23919/ECC57647.2023.10178247). [⟨hal-04343535v5⟩](https://inria.hal.science/hal-04343535v5)
*   Serigne Gueye, P. Michelon. A preprocessing technique for quadratic unconstrained binary optimization. _Discrete Optimization_, 2025, 58, pp.100914. [⟨10.1016/j.disopt.2025.100914⟩](https://dx.doi.org/10.1016/j.disopt.2025.100914). [⟨hal-05331726⟩](https://hal.science/hal-05331726v1)
*   Tarik Bouramtane, Ismail Mohsine, Nourelhouda Karmouda, Marc Leblanc, Yannick Estève, et al.. Dimensionality reduction for groundwater forecasting under drought and intensive irrigation with neural networks. _Journal of Hydrology: Regional Studies_, 2025, 60, pp.102477. [⟨10.1016/j.ejrh.2025.102477⟩](https://dx.doi.org/10.1016/j.ejrh.2025.102477). [⟨hal-05088709⟩](https://hal.science/hal-05088709v1)
*   Sylvie Chaddad, Yezekael Hayel, Vineeth Varma. A Stochastic Model for Optimizing Crowdfunding Campaign Success. _Operations Research Letters_, 2025, 61, pp.107303. [⟨10.1016/j.orl.2025.107303⟩](https://dx.doi.org/10.1016/j.orl.2025.107303). [⟨hal-05060998⟩](https://hal.science/hal-05060998v1)
*   Benjamin O’brien, Anna Marcyzk. A spectrotemporal modulation application for distinguishing modal and whistled speech. _International Journal of Speech Technology_, 2025, [⟨10.1007/s10772-025-10185-1⟩](https://dx.doi.org/10.1007/s10772-025-10185-1). [⟨hal-05025403⟩](https://hal.science/hal-05025403v1)
*   Chiara Mazzocconi, Benjamin O'Brien, Kübra Bodur, Abdellah Fourtassi. Do Children Laugh Like Their Parents? Conversational Laughter Mimicry Occurrence and Acoustic Alignment in Middle-Childhood. _Journal of Nonverbal Behavior_, In press, [⟨10.1007/s10919-025-00478-z⟩](https://dx.doi.org/10.1007/s10919-025-00478-z). [⟨hal-04935267⟩](https://hal.science/hal-04935267v1)
*   Adrien Deschamps, Lucas Potin. Processing and consolidation of open data on public procurement in France (2015–2023). _Data in Brief_, 2025, 58, [⟨10.1016/j.dib.2025.111277⟩](https://dx.doi.org/10.1016/j.dib.2025.111277). [⟨hal-04918105⟩](https://hal.science/hal-04918105v1)
*   Lucas Potin, Rosa Figueiredo, Vincent Labatut, Christine Largeron. Pattern-Based Graph Classification: Comparison of Quality Measures and Importance of Preprocessing. _ACM Transactions on Knowledge Discovery from Data (TKDD)_, 2025, 19 (6), pp.123. [⟨10.1145/3743143⟩](https://dx.doi.org/10.1145/3743143). [⟨hal-05095757⟩](https://hal.science/hal-05095757v1)
*   Noé Cecillon, Vincent Labatut, Richard Dufour. Conversation-Based Multimodal Abuse Detection Through Text and Graph Embeddings. _Computing_, 2025, 107, pp.124. [⟨10.1007/s00607-025-01463-6⟩](https://dx.doi.org/10.1007/s00607-025-01463-6). [⟨hal-04993092v2⟩](https://hal.science/hal-04993092v2)
*   Noémie Févrat, Vincent Labatut, Émilie Volpi, Guillaume Marrel. A Dataset of the Representatives Elected in France During the Fifth Republic. _Data in Brief_, 2025, 60, pp.111542. [⟨10.1016/j.dib.2025.111542⟩](https://dx.doi.org/10.1016/j.dib.2025.111542). [⟨hal-05012514v2⟩](https://hal.science/hal-05012514v2)
*   Motasem Alrahabi, Arthur Amalvy, Vincent Labatut, Perrine Maurel. De l'annotation intégrale à l'analyse des réseaux de personnages : un modèle pour la REN dans les textes littéraires en français. _Revue TAL : traitement automatique des langues_, A paraître, 66 (1). [⟨hal-05128385v2⟩](https://hal.science/hal-05128385v2)
*   Luca Dini, Pierre Jourlin. Normalisation à base de règles: une stratégie efficiente pour l'extraction d'évènements fondée sur des LLMs. _Revue des Nouvelles Technologies de l'Information_, 2025, Extracti

*[... truncated, 579,771 more characters]*

---

### Sommet 2025: Change perspective to better support - MAIN | accélérer l'innovation au Québec
*1,392 words* | Source: **GOOGLE** | [Link](https://mainqc.com/en/announcements-main/sommet-2025-programmation/)

The challenges we face are complex. Innovation no longer follows a linear trajectory, and entrepreneurs navigate in an environment where uncertainty is the only certainty. In this ever-changing ecosystem, the ways in which we accompany, structure and support them must also evolve. But how?

This is precisely the intention of the Accelerators 2025 Summit: to open up the space needed to think collectively about the future of innovation and entrepreneurial support in Quebec.

Many things happen, in the political environment here as elsewhere; but the only thing we have control over is how we work together to get through the trials.

### **Looking differently to understand better**

We sometimes tend to view issues through a limited prism, rooted in our habits and frames of reference. This year, we have chosen to take a step back, to broaden our field of vision, to better grasp the forces shaping the present and those determining the future.

For the sixth edition of the Summit, we propose three pillars of content

*   **Taking the high ground**: strategic content to broaden our vision of the ecosystem and pave the way for greater resilience and collaboration
*   **Crossed perspectives**: co-creation workshops to identify together concrete solutions to boost entrepreneurial intent, simplify entrepreneurial paths and reduce obstacles to innovation.
*   **Putting things into perspective**: opportunities to collectively rethink the way we support entrepreneurs by putting their needs at the heart of our actions.

### **Putting entrepreneurs at the center**

Support must be a point of support, a springboard aligned with the real needs of entrepreneurs. To achieve this, we need to rethink the way we listen to them, understand their needs and support them.

 That's why we've revised our mission, to broaden our scope and reach as many entrepreneurs as possible, wherever they are in Quebec.

Your presence at the Summit should enable you to reflect on three aspects:

1.   What it really means to support innovative entrepreneurs today.
2.   Ways of (re)empowering entrepreneurs to take risks.
3.   The mechanisms of our ecosystem to make it more agile, more human and more conducive to the emergence of innovation in all its forms.

### **Three days to rethink our impact - programming at a glance**

Looking differently is good. Acting accordingly is essential. Entrepreneurial support cannot be static. It must adapt, improve and, above all, co-create with those it supports. That's why we've divided the program into five blocks that will enable you to explore different facets.

Discover the full program online here

### Wednesday AM theme: _Building ecosystems: between global movement and local realities_

Entrepreneurial ecosystems don't build themselves._Ecosystem building_ as a strategic approach inspires us to collectively build sustainable innovation environments. We take you to the heart of best practice with builders who have come to share their local realities and global visions.

Three conferences will give us the opportunity to exchange ideas and gain the necessary perspective for this first day of the Summit:

*   A high-altitude discussion with builders: Philippe Telio (Startupfest), Jean-François Harvey (Canadian Innovators Council), Marie Chevrier Schwartz (TechTO) and ilias Benjelloun (ÉlanTech).
*   A transatlantic conversation between professionals from Quebec and France between Anne Lemieux (accelerator nordique), Éric Darveau (OSEntreprendre), Arnaud Archimede (Whistle), Léa Jouffroy (Pépite Lille Hauts-de-France), and Stéphane Carrier (LOJIQ).
*   A panel on the importance of studying your ecosystem with data, thanks to our PERSÉIS project, featuring Naomie Allard (UQO), Sophie Veilleux (Université Laval), Marie-Michèle Lord (UQTR), Octave Niamié (Polytechnique Montréal) and Charles Beaudry.

And we'll also have the first perspective with Louis-Félix Binette to awaken the _ecosystem-builder_ in you.

### Wednesday PM theme: _The voice of entrepreneurs: a compass for the ecosystem_

Entrepreneurs, who are at the heart of our services, don't care much about the complex mechanisms that surround them. Putting their voice back at the center of authentic conversations and dynamic workshops will enable us to co-create solutions adapted to their real needs. Understanding the entrepreneurial perspective means building an aligned ecosystem.

The afternoon of Wednesday February 12 will be dedicated to presenting different perspectives on entrepreneurial support, and to hearing entrepreneurs tell us the truth.

*   The voice of entrepreneurs: Clément Bouland (co-founder Bello), Elisabeth Gosselin (co-founder Paralog), Sarah DeGrâce (co-founder INSPPI), and Phil Rivard
*   Inclusive support for our entrepreneurs with Tina Pranjic from Élance
*   Adapting support to the diversity of entrepreneurial forms: Chantal Thieblin Goffoz (evol), Diana Horqque (V1 Studio), Isabelle Thibault (Esplanade Québec), Sarah Girouard (Quart

*[... truncated, 4,482 more characters]*

---

### Cinéma du réel 2011
*83,855 words* | Source: **GOOGLE** | [Link](http://chrismarker.ch/_media/cinema-du-reel-cat-2011.pdf)

# Cinéma du réel 2011 Avec le concours de Partenaires Avec le soutien de Scam – Société civile des auteurs multimédia Forum des Images Ambassade de France en Chine Ambassade de France aux États-Unis d’Amérique Ambassade de France en Russie Fondation Calouste Gubenkian German Films  Goethe Institut  Forum Culturel Autrichien 

Institut Cervantes Paris 

Institut Culturel italien  Institut Culturel roumain Swiss films Wallonie-Bruxelles International Archives françaises du film Vectracom Avec la participation de Acrif – Association des Cinémas de Recherche d’Ile-de-France Addoc CIP – Cinémas Indépendants Parisiens Docnet.fr Documentaire sur grand écran Softitrage.com  Aéroports de Paris Partenaires média UniversCiné.com  France Culture 

CineCinéma Evene.fr  Télérama  Festivalscope Critikat.com Fluctuat.net L’Histoire Positif  Écran total 

3 couleurs Chronic’art Bellefaye Aujourd’hui.fr Paris étudiant 

Lieux associés Centre musical Fleury Goutte d’or - Barbara - Paris Ciné 104 - Pantin, 93 Cinéma Louis Daquin Cinéma L’Ecran - Saint-Denis, 93 Le Blanc Mesnil, 93  Ecole nationale supérieure des beaux-arts de Paris Ecole nationale supérieure d’architecture de Paris-La Villette L’Étoile La Courneuve, 93 

Espace 1789 Saint Ouen, 93 

Cinéma Jean Vilar Arcueil, 94 

Espace Khiasma Les Lilas, 93 L’Eclat / Villa Arson - Nice Le Fresnoy - Tourcoing Magic Cinéma - Bobigny, 93 Maison des Métallos - Paris Théâtre André Malraux Chevilly-Larue, 94 Théâtre Cinéma Paul Éluard Choisy-le-Roi, 94 

Sacem Institut français Fondation Joris Ivens Arte France Télévisions Centre Wallonie-Bruxelles MK2 CNC – Centre national de la cinématographie 

Ministère de la culture et de la communication L’Acsé  Région Île-de-France 

Ville de Paris Mission cinéma Procirep Société des producteurs de cinéma et de télévision 

CNRS Images média Comité du film ethnographique 

> AMBASSADE DE FRANCE EN CHINE

## 3Cinéma du réel remercie tout particulièrement 

ACRIF , Quentin Mevel, Didier Kiner, Nicolas Chaudagne, Natacha Juniot 

Accademia dell’Immagine ,Alessia Moretti 

Acsé , Catherine de Luca 

Addoc Aéroports de Paris, 

Stéphanie Arnoux-Couderc 

ALBA , Marina Garde 

Ambassade de France aux Etats -Unis d’Amérique ,Muriel Guidoni, Nathalie Charles, Delphine Selles-Alvarez 

Ambassade de France en Chine, Olivier Delpoux 

Ambassade de France en Russie , Katia Grollet 

Ancor , Jean-Paul Musso 

Anthology Film Archives ,Andrew Lampert, Jed Rapfogel 

Archives françaises du film ,Eric Le Roy, Fereidoun Mahboubi 

Arte Editions , Marie-Laure Lesage, Adrienne Fréjacques, Henriette Souk 

Arte France , Unité Documentaires, Pierette Ominetti 

Bob’s Food etc. , Amaury de Veyrac, Marc Grossman 

Canyon Cinema , Dominic Angerame 

Carlotta Films , Inès Delvaux 

CBA Centre Bruxellois de l’Audiovisuel Centre Culturel Calouste Gulbekian , Jasmin Uhlig 

Centre national du cinéma et de l’image animée (CNC) ,Anne Cochard, Hélène Raymondaud 

CinéCinéma , Bruno Deloye, Maryline Gaillard, Sonia Lukic, Anastasia Malinovskaya 

Cinematek , Gabrielle Claes, Jean-Paul Dorchain 

Cinémathèque Française ,Serge Toubiana, Sylvie Vallon, Catherine Hulin, Fred Savioz 

CIP , Françoise Bévérini, Isabelle Laboulbène, Anne Bargain 

The Conner Family Trust ,Michelle Silva 

Crédit coopératif , Anne-Sophie Arnaud 

Délégation générale et Centre Wallonie-Bruxelles à Paris , Christian Bourgoignie, Louis Héliot 

Docnet , Pierre-Alexis Chevit 

Documentaire sur grand écran , Annick Peigné-Giuly, Hélène Coppel, Laurence Conan 

Ecole Supérieure des Beaux Arts de Tours , Denis Jourdin 

Editions Montparnasse ,Vianney Delourme 

Ensaama , Marie-Josée Mascioni, Mariette Dupont, Carole Appert, Etienne Minet et les étudiants de DSAA1 en section de Communication Visuelle 

Festival del film Locarno ,Olivier Père, Carmen Werner 

Filmair , Alexandra Vallez 

Filmer la musique , Olivier Forest, Marilyn Lours 

The Film-Makers’ Cooperative , MM Serra 

Fipa , Jean-Michel Ausseil 

Fondation Européenne Joris Ivens , André Stufkens 

Fondation Henri Cartier-Bresson , Aude Raimbault 

Forum Culturel Autrichien ,Susanne Keppler-Schlesinger 

Forum des images , Laurence Herszberg, Alain Esmery, Marianne Romeur, Jean-Yves de Lépinay 

France Télévisions ,Yves Rolland, Philippe Vilamitjana 

German Films , Julia Basler 

Goethe Institut – Paris ,Gisela Rueb 

Goethe Institut – Yaoundé ,Irene Bark 

Harvard Film Archive , Mark Johnson 

International Center of Photography , Erin Barnett, Claartje Van Dijk 

Illuminations Films , Simon Field 

L’Instant culinaire , François Furlan, Laurent Corplet 

Institut Cervantes , Raquel Caleya 

Institut culturel italien ,Rossana Rummo, Irene Marta 

Institut culturel roumain à Paris , Katia Danila, Madalina Tureatca 

Institut français , Valérie Mouroux, Anne-Catherine Louvet 

Ircam , Claire Marquet 

Iskra , Lena Fraenkel, Viviane Aquili 

La Java , Christine Picon 

Light Cone , Christophe Bichon, Emmanuel Lefrant 

LUX , Mike Sperlinger 

Lyc

*[... truncated, 510,740 more characters]*

---

---

## 🎬 YouTube Videos

- **[How I built this - Virgile Ollivier : Not Another Founder Story](https://www.youtube.com/watch?v=YPg9kflUNkk)**
  - Channel: Amelie build businesses
  - Date: 2025-09-24

- **[Colloque NPA-Le Figaro : Virgile Ollivier, HUBEE](https://www.youtube.com/watch?v=F3PsJS7jcaE)**
  - Channel: 4Change
  - Date: 2015-11-13

- **[LIVE WITH CAFA: Episode 20 with Virgile Ollivier, CEO and co-founder of Livescale](https://www.youtube.com/watch?v=OkEnm2gOeBA)**
  - Channel: CAFA TV
  - Date: 2020-07-08

- **[test2](https://www.youtube.com/watch?v=mLbk9sN1QIw)**
  - Channel: Virgile OLLIVIER
  - Date: 2017-09-17

- **[LiveScale Chats with #NABShow LIVE in Pre-NAB Show Interview](https://www.youtube.com/watch?v=2MhEETIMjFE)**
  - Channel: Broadcast Beat
  - Date: 2017-04-17

- **[Lacrim, la rue lui appartient](https://www.youtube.com/watch?v=GDLaRlJjFns)**
  - Channel: NoFun Show
  - Date: 2017-04-14

- **[Blake Robbins on the future of media, Twitch, OnlyFans, and creator monetization](https://www.youtube.com/watch?v=e3-a7QUrEk4)**
  - Channel: Means of Creation
  - Date: 2020-09-19

- **[356th 1Mby1M Roundtable June 8, 2017: With Rephael Sweary, WalkMe](https://www.youtube.com/watch?v=psf6FlxBhjU)**
  - Channel: 1Mby1M Roundtables
  - Date: 2017-06-09

- **[UD live](https://www.youtube.com/watch?v=fosLmsLg4_o)**
  - Channel: Virgile OLLIVIER
  - Date: 2020-11-29

---

## 🔎 Press & Mentions

- **[Are Canadian founders getting a raw deal? | BetaKit](https://betakit.com/are-canadian-founders-getting-a-raw-deal/)**
  - Source: betakit.com
  - *Jul 21, 2025 ... Virgile Ollivier has interviewed more than 150 entrepreneurs for a new founder support platform called Chapter. ... The BetaKit Podca...*

- **[Sommet 2025: Change perspective to better support - MAIN ...](https://mainqc.com/en/announcements-main/sommet-2025-programmation/)**
  - Source: mainqc.com
  - *Feb 12, 2025 ... ... chapter of Fuckup Nights. HR improv show - An offbeat ... Navigating uncertainty with Virgile Ollivier (TheConvenors) and Anick P...*

- **[Cinéma du réel 2011](http://chrismarker.ch/_media/cinema-du-reel-cat-2011.pdf)**
  - Source: chrismarker.ch
  - *thy subtitle sets the autobiographical material at a distance in the manner of the chapter ... Virgile Ollivier, Responsable Développement & Nouveaux ...*

---

*Generated by Founder Scraper*
