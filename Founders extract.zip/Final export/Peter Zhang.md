# Peter Zhang

## Position actuelle

**Titre** : Founder
**Entreprise** : Sculptophile
**Durée dans le rôle** : 3 years 11 months in role
**Durée dans l'entreprise** : 3 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Retail Art Supplies

## Description du rôle

Sculptophile partners with 2D artists to make their work into sculptures. We cover other professional services such as toy prototyping, 3D manufacturing, and 3D modeling. 

Notable partners: 
• Emmy and Annie Award winning character designer: Ben Balistereri
• Head of story for Disney and Illustrator for Lucasfilm and Marvel: Brian Kesinger
• Genius Inc. Illustrator: Jeff Snow

## Résumé

Full-stack Analytics Professional, skill sets involves: ETL, data warehouse, data modelling, statistics, machine learning, business process modelling, coding, business understanding, BI products/delivery, client presentation, technical/business documentation, data visualization. 

Expert in Ontario healthcare system in terms of: front-line delivery, IT infrastructure, data collection and utilization, corporate functions, HR practices, financial structure, funding formula, supply chain management and procurement, governmental guidelines, project management, business intelligence, decision support, ancillary departments (pharmacy, lab, diagnostic imagining).

Side interests includes: stock picking (video game industry, semi-conductor, technology. ARR 140%, 7 years, $2.5M AUM), business consulting (e.g. marketing ideation, media outreach, financial modelling), career counseling (e.g. resume, job market analysis, school selection), machine learning (supervised off-the-shelf), startups (e.g. product creation, project management, grant application, contracts, IP law), graphic design (e.g. logo, print outs), physical sciences, and psychology. 

Secret ambitions: become a romance novel writer under the a female pseudonym, become a investigative journalist in healthcare.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAyImnMBJzDX906BShrp973GNHmOmreX8b4/
**Connexions partagées** : 3


---

# Peter Zhang

## Position actuelle

**Entreprise** : ForgeSight

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Peter Zhang

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399949466813972480 | Celebration |  | https://media.licdn.com/media/AAYABAQSAAgAAQAAAAAAAQTtkgRNEU9TSPKdtuYUdRX6eA.gif | I’m happy to share that I’m starting a new position as Head of Delivery and Talent Development at ForgeSight! | 27 | 7 | 0 | 1w | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.891Z |  | 2025-11-27T23:17:17.301Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7395690402319818752 | Article |  |  |  | 0 | 0 | 0 | 3w | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.891Z |  | 2025-11-16T05:13:17.196Z | https://www.youtube.com/watch?v=wpg1ygoooMw |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7392978638918520832 | Article |  |  |  | 2 | 0 | 0 | 4w | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.892Z |  | 2025-11-08T17:37:42.419Z | https://www.youtube.com/watch?v=o1ZFfK8hL5M |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7391544138988601344 | Article |  |  |  | 0 | 0 | 0 | 1mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.892Z |  | 2025-11-04T18:37:30.984Z | https://www.youtube.com/watch?v=BLESJ6KP-E8 |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7384642331007901697 | Article |  |  |  | 1 | 0 | 0 | 1mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.893Z |  | 2025-10-16T17:32:11.732Z | https://www.youtube.com/watch?v=-9LFj6YOK2U |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7383664557103394816 | Article |  |  |  | 0 | 0 | 0 | 1mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:49.893Z |  | 2025-10-14T00:46:52.267Z | https://www.youtube.com/watch?v=TZqADzuu73g |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7379615657535074305 | Text |  |  | https://lnkd.in/gTaW2UmU | 0 | 0 | 0 | 2mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.022Z |  | 2025-10-02T20:37:59.385Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7376449467404922880 | Article |  |  |  | 0 | 0 | 0 | 2mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.023Z |  | 2025-09-24T02:56:40.833Z | https://www.youtube.com/watch?v=jYV5AdFsQMk |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7374573327551676416 | Article |  |  |  | 0 | 0 | 0 | 2mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.023Z |  | 2025-09-18T22:41:34.235Z | https://www.youtube.com/watch?v=c628UgLVXBc |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7363340994378940417 | Article |  |  |  | 0 | 0 | 0 | 3mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.024Z |  | 2025-08-18T22:48:17.320Z | https://www.youtube.com/watch?v=1H3xQaf7BFI |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7356078970154438656 | Article |  |  |  | 1 | 0 | 0 | 4mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.024Z |  | 2025-07-29T21:51:35.823Z | https://www.youtube.com/watch?v=StTKHskg5Tg |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7348741974981607424 | Text |  |  | https://lnkd.in/g9Z_sji4 | 1 | 0 | 0 | 4mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.024Z |  | 2025-07-09T15:56:59.859Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7344853965857017856 | Article |  |  | Beautifully said | 0 | 0 | 0 | 5mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.024Z |  | 2025-06-28T22:27:26.248Z | https://www.youtube.com/watch?v=S8HY-re771U |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7341353970424061952 | Article |  |  | Talking about real modern slavery | 0 | 0 | 0 | 5mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.024Z |  | 2025-06-19T06:39:42.310Z | https://www.youtube.com/watch?v=nfPE4dObRVo |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7301314014020542465 | Article |  |  |  | 0 | 0 | 0 | 9mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.025Z |  | 2025-02-28T18:55:12.797Z | https://www.youtube.com/watch?v=KpCRRoibwV0 |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7291533051862339584 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.025Z |  | 2025-02-01T19:09:09.697Z | https://www.youtube.com/watch?v=OHWnPOKh_S0 |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7288754243992272896 | Article |  |  | Go Anduril!!! | 1 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.025Z |  | 2025-01-25T03:07:10.273Z | https://www.youtube.com/watch?v=SdXsZJsCXqo |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7288698958745387008 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.025Z |  | 2025-01-24T23:27:29.243Z | https://www.youtube.com/watch?v=lb0b4utSxiQ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7287612461531254784 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.026Z |  | 2025-01-21T23:30:08.121Z | https://www.youtube.com/watch?v=ZgtWDsumb0I |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7286067477631979520 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.027Z |  | 2025-01-17T17:10:55.255Z | https://www.youtube.com/watch?v=3pLEpO90jLo |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7285437417765908481 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.027Z |  | 2025-01-15T23:27:17.277Z | https://www.youtube.com/watch?v=Kev_-HyuI9Y |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7284745018290946049 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.027Z |  | 2025-01-14T01:35:56.378Z | https://www.youtube.com/watch?v=mdvqSncd4FY |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7284731352652881920 | Article |  |  |  | 0 | 0 | 0 | 10mo | Post | Peter Zhang | https://www.linkedin.com/in/peterzhangrnmba | https://linkedin.com/in/peterzhangrnmba | 2025-12-08T06:19:52.028Z |  | 2025-01-14T00:41:38.236Z | https://www.youtube.com/watch?v=t9Fj8t485uM |  | 

---



---

# Peter Zhang
*ForgeSight*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [ForgeSight Analytics | Smarter Insights, Better Decisions](https://www.forgesightanalytics.com/)
*2025-08-03*
- Category: article

### [Forge Forward Podast Archives - Forge, Underpressure, Innovation Ignites](https://forgesummit.com.au/tag/forge-forward-podast/)
*2024-03-01*
- Category: article

### [](https://www.everand.com/podcast/417700300/009-Peter-Zhang-Into-the-mechanics-of-our-financial-markets-with-a-street-smart-hedge-fund-operator-This-week-we-pullback-the-curtains-and-shine)
- Category: podcast

### [Building Tableflip Foundry - Forgesight - Dave Chadwick | Art of Failing](https://artoffailing.com/2023/11/11/forgesight-bot/)
*2023-11-11*
- Category: article

### [Hunting for Chinese Cloud Unicorns — with Eminence Ventures Founding Partner Peter Cheng](https://medium.com/the-harbinger-china/hunting-for-chinese-cloud-unicorns-with-eminence-ventures-founding-partner-peter-cheng-8c8d619f88ad)
*2023-04-16*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
