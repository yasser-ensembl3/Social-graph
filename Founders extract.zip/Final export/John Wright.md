# John Wright

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : StatsDrone
**Durée dans le rôle** : 8 years in role
**Durée dans l'entreprise** : 8 years in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

StatsDrone is a software and marketing company that helps webmasters track their sales, commissions and statistics in a single app. We also make tools for affiliate publishers and affiliate programs.

## Résumé

I've been in igaming and affiliate marketing for over 20 years with experience in affiliate management, setting up and managing affiliates sites and now cofounder of StatsDrone. At StatsDrone we make SaaS tools for affiliates (publishers) and affiliate programs (advertisers).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAP3o4IB_q1XNntPwl99Y2X7AQxfxR6fwAc/
**Connexions partagées** : 12


---

# John Wright

## Position actuelle

**Entreprise** : StatsDrone

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# John Wright

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402699460285317120 | Poll |  |  | Affiliates, which is important for you?

Shaving reports, more data viz or data alerts telling you KPIs are crashing? | 3 | 10 | 0 | 2d | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:05.989Z |  | 2025-12-05T13:24:46.837Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402361690039689217 | Poll |  |  | If you could get the best data viz tools with an AI chatbot either with StatsDrone or any other data service (Google Search Console, Voluum data, WordPress clicks or any other source), how would you want that served up? | 1 | 0 | 0 | 3d | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:05.989Z |  | 2025-12-04T15:02:36.135Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402329277406535680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHY025fTzAn6Q/feedshare-shrink_800/B4EZrpbQAIIwAg-/0/1764852827185?e=1766620800&v=beta&t=dCHPY2DGHWWdhyHmNMb_7EHm0-UoOjUeDyQ29mzHYwA | This affiliate research tool we are building is going to be an insane product. | 18 | 1 | 0 | 3d | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:05.990Z |  | 2025-12-04T12:53:48.361Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402296859869859840 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG1Et-fgPGojg/feedshare-shrink_800/B56Zrofv1xLEAk-/0/1764837228111?e=1766620800&v=beta&t=e2VzCAJYAhpxujczlA3tcUQGFbnlnTdyvmZGS_MY3rQ | Working on some more shaving detection stuff as iGaming Times wanted to know | 11 | 0 | 0 | 3d | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:05.990Z |  | 2025-12-04T10:44:59.418Z | https://www.linkedin.com/feed/update/urn:li:activity:7402263852458901504/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401199248429703168 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF4pVsKDTRHPA/feedshare-shrink_800/B4DZrWGOOBGQAg-/0/1764528550170?e=1766620800&v=beta&t=3U62LKLu7cEYI6rLy6nv-86ScEo_zbYkL45Zl-zxKRo | What song am I singing? Wrong answers only version | 13 | 10 | 0 | 6d | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.904Z |  | 2025-12-01T10:03:28.458Z | https://www.linkedin.com/feed/update/urn:li:activity:7401153193063211009/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7400879636500357121 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1WVvK7UJktQ/feedshare-shrink_800/B4EZrU0zorKoAg-/0/1764507205930?e=1766620800&v=beta&t=NJXLwKfr1SjRvRvDtL7M2g3gCNduOJzIZtXxYzJiNr0 | PAM for affiliates is getting very close to becoming a reality!

Imagine emailing a player and having this report. 

Imagine then being able to get the game reports too!

This is the power of dynamic variables which is data you can get with StatsDrone combined with first party data. 

More to come soon so watch this space!

Tagging a few people that may find this interesting. Oscar Karlsten, Andrew Lee, Joachim Ándre Solbakken, Eman PULIS, Pierre Lindh⚡️, Christian Kirk Rasmussen, Giorgi Samkharadze, Sam Sadi, Luka Dretar, Maja Jovančević, Antonín Kučera, Daniel Hansson Sokcic, Nick Hedberg, Staffan Engström, Claudia Heiling | 43 | 19 | 2 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.906Z |  | 2025-11-30T12:53:27.036Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7400541183023927296 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQESc1RnNdeYgg/feedshare-shrink_800/B4EZrQA_N3IIAg-/0/1764426511884?e=1766620800&v=beta&t=zMKBZimHNzGuSSkFWA90uGkYmtJCC0TZx3KRxYbsYR0 | I'm going to spend time this weekend working on 2 projects.

1: is an affiliate network platform, people keep asking us for it.
2: is a PAM for affiliates

For those that don't know what a PAM is, it's a player account management but they are typically associated as being an operator product, not an affiliate product.

So how does a PAM work for an affiliate?

Instead of sending a single campaign to your newsletter list, you send a dynamic parameter either as a page or as a tracking link. 

The end results is you get to see the deposit and revenue activity of your players. 

So, do you got traffic? | 42 | 1 | 1 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.907Z |  | 2025-11-29T14:28:33.439Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7400291797236678656 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHEbh0obnygiw/feedshare-shrink_800/B4EZrMeKnSKkAg-/0/1764367052802?e=1766620800&v=beta&t=x85mI8q80F2q2PDUlgbVLCFT-j3kjfuZUkMwUIElRw8 | Presenting the Connection Analyzer!

Now you can do very important things like know how many Davids, Daniels or Alex (what is the plural of Alex, Alex Pratt?).

You can also filter your contact list by company or by role and even export that list!

First step is you have to download your LinkedIn data which takes up to a day via email. Unzip and find the Connections.csv file and upload it on the URL in the comments. 

Check out the menu and look at StatsDrone or rate StatsDrone at OnlyiGaming. 

Link in comments. PS no data is stored. 

Comments for feature requests | 19 | 4 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.908Z |  | 2025-11-28T21:57:35.234Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400260105109405696 | Article |  |  | Here is a topic I can relate to | 1 | 0 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.909Z |  | 2025-11-28T19:51:39.242Z | https://www.gamblinginsider.com/trafficology/205/why-cro-is-the-next-big-thing-for-operators-and-affiliates |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7399775187686146048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHxt1zwRxEyoQ/feedshare-shrink_800/B4EZrFIUCCIwAg-/0/1764243884296?e=1766620800&v=beta&t=1qF3q8VLX1bvKP6IuMQq4qEpgsN6hAF7MUTlr99OImY | So Favbet (.com) has been down for maintenance all week and there are more than enough affiliates still sending traffic that won't convert.

I learned of Favbet's problems through a post from João Mar so thanks for the article.

We are now scraping more of the affiliate sites still linking out using our Affiliate Track tool.

Link in comments if curious to see. Soon we will have a large database of closed brands and invalidated links too. | 8 | 1 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.911Z |  | 2025-11-27T11:44:45.919Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7399427399529992192 | Text |  |  | This is sad but true. Regulated sites will either flip the switch or likely be acquired. 

Sadly gives me something to track in seeing sites that will switch from regulated brands and gain 'pre-regulated' brands. | 10 | 0 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.913Z |  | 2025-11-26T12:42:46.761Z | https://www.linkedin.com/feed/update/urn:li:activity:7399425938100490240/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7399177393644396544 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8d297199-0328-4138-9a20-7102c3836e6b | https://media.licdn.com/dms/image/v2/D4E05AQF52o1ajrSMIg/videocover-low/B4EZq8ohVtGYBU-/0/1764101333315?e=1765774800&v=beta&t=nwX-V3XD18cDuNdU_WlUW5_F6EETzZV5eY4oIZisEd0 | 4 minute demo to show you what our Affiliate Track app can do. It's in beta and we have a deal for new users. | 14 | 1 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.914Z |  | 2025-11-25T20:09:20.713Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7398669279052742657 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4fb88af7-6385-4f7a-ad46-cff9c5b18647 | https://media.licdn.com/dms/image/v2/D4E05AQEJwF5A1RzjmA/videocover-high/B4EZqz5WHBHcBg-/0/1763954748032?e=1765774800&v=beta&t=1XCJQFdcoU_kAlcP_HzZ0xRBeE8xVH2Xr_L55BzIWF0 | Tired of spreadsheets or inaccurate stats? 

Try StatsDrone! | 3 | 4 | 0 | 1w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.916Z |  | 2025-11-24T10:30:16.754Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7398325703605395456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEKSM8aiNivOw/feedshare-shrink_2048_1536/B4EZqt_2SvKkAw-/0/1763855787668?e=1766620800&v=beta&t=4Vd7H4iW7Y_07cBPR0GRio_5e2fbWPukx-iSElcBCKg | We have a deal for our affiliate finder called Affiliate Track now in beta. 

Save $200/month on an Enterprise license, instead of $299/month, get it for just $99/month. Offer ends December 12, 2025 and the deal will let you lock in the $99/month rate for the next 12 months. 

If you want access, just write Black Friday and I'll send you a link. | 33 | 2 | 2 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.917Z |  | 2025-11-23T11:45:01.984Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7397959626924793856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXvlTTThcfdQ/feedshare-shrink_800/B4EZqeUZemHMAg-/0/1763592739701?e=1766620800&v=beta&t=7KzQ0XG1oMsTCySH4PRG9gsjTdT4_CL3TJ9b-ur4GnU | Out of my 16k+ connections, I decided to run a Python script to learn a few things.

Why? Because I wanted to find all my affiliate manager connections to tell them about a new tool called Affiliate Track. Anyways, here's some stats:

The top 5 common names:
1. David - 134
2. Daniel - 109
3. Alex - 88
4. Anna - 85
5. James - 84

The top 5 companies excluding NDA (512), Self-employed (103) and Freelance (88).
1. Better Collective - 72
2. Betsson Group - 61
3. LeoVegas Group - 59
4. Gentoo Media - 55
5. SiGMA World - 53

The top 5 most common positions
1. Affiliate manager - 557
2. Founder - 500
3. Chief Executive Officer - 344
4. Co-founder - 285
5. Business Development Manager - 235

If you want the script & instructions of how to do this yourself, type in SOCIAL and maybe leave a relevant comment, let's see how far this post goes. | 32 | 25 | 2 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.918Z |  | 2025-11-22T11:30:22.502Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7397585263725658112 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f2a8d856-3416-4755-a756-3b3fe2212f92 | https://media.licdn.com/dms/image/v2/D4E05AQFhVjC92XHPLA/videocover-high/B4EZqmAj8lGcBU-/0/1763721760099?e=1765774800&v=beta&t=AvtwFQZmu2iRxovS6VynoFtLYzMplCP-M36jiI9nTuQ | Since y'all love Black Friday deals, here's one for you.

Our Affiliate Track app is an affiliate link research tool and we are rolling out $99/month licenses for the plans that are normally $299/month. If you lock in this deal, you get to keep it for the next 12 months at this rate. Offer ends Dec 12, 2025. 

What will the tool do?

- Identify broken tracking links on your affiliate sites
- Help affiliate managers find affiliates
- Search for affiliates based on page title keywords

To claim signup and send me a message and I'll sort your account and a payment link. | 13 | 3 | 2 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.919Z |  | 2025-11-21T10:42:47.360Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7397260056028938243 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFqVWsUcWxzyQ/feedshare-shrink_1280/B4EZqhY0e.HMAs-/0/1763644229992?e=1766620800&v=beta&t=WRtEFzpRBVO5ZMG0fk-hxdniUhyfPgnDgy0fWFGuQ24 | 🚀 A 15-year-old iGaming affiliate marketing asset might be changing hands…

That site is Gaffg!

Since then, it's been a lot of interest with most wanting to add top lists and reviews of operators. The site needs some TLC and I think would do very well with anyone with a solid sales team and/or SEO team. 

I’m opening conversations now:
 👉 Full sale preferred, but JV opportunities are on the table.

If a deal happens, I’ll support the new owner with:
 • Tech + data support
 • Affiliate program review data
 • Operators’ logos, brands & bonus info

The brands database is 4000+ and the bonuses will have multiple GEOs.

If you know someone looking for a solid iGaming/affiliate project:
 Likes, comments, tags, and reposts are hugely appreciated. 

Tagging a few people that mind find this asset potentially interesting for their network. Rasmus Sojmark, Eman PULIS, Pierre Lindh⚡️, Gjorgje R., Levon Nikoghosyan, Emre Goktas, Adrian Borg, Maja Jovančević, Tom Galanis, Mehdi V., Sebastian Paris, Johan Svensson, Niklas Forsberg, Alex Pratt, Peter Gunni, Rasmus Hansen, Richard Dennys, Narcis Gavrilescu, Alessandro Gherardi, Frixos Constantinides, Zakaria El Maaroufi, Rune J.N. Jørgensen, Viorel Stan, Alex Bobes | 55 | 23 | 2 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.923Z |  | 2025-11-20T13:10:31.803Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7397213122262085632 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFCbhFzMAXtRg/feedshare-shrink_800/B56ZqeToooI4Ag-/0/1763592539766?e=1766620800&v=beta&t=esWt7yFyBScEVpdMJ4zNIjNY05C4maimV9quh4ObNIg | Congrats to the whole @betblocker team amd all the supporters along the way. | 4 | 0 | 0 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.924Z |  | 2025-11-20T10:04:01.921Z | https://www.linkedin.com/feed/update/urn:li:activity:7397166859436875777/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7397007510735314944 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGss9WtDaqH7w/feedshare-shrink_800/B4DZqdB5U4KQAg-/0/1763571112382?e=1766620800&v=beta&t=y_XyHWVEDsHTgPjSeUxocPSA1yEBCi-pSZ8ea3stUoY | The idea is to repost and pass it on | 5 | 0 | 2 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.924Z |  | 2025-11-19T20:27:00.313Z | https://www.linkedin.com/feed/update/urn:li:activity:7396953374136467456/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7396945246099566592 | Poll |  |  | I’m seeing a quick rise in llms.txt growing. What does everyone think is this an SEO and AI fad or is there more to it? | 1 | 5 | 0 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.925Z |  | 2025-11-19T16:19:35.267Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7396860196960038913 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYQ42MeGt2MQ/feedshare-shrink_800/B4EZqbtJggKMAk-/0/1763548896646?e=1766620800&v=beta&t=nvcm0EiMxMVCWgD2GrFQGzCVlmBaLapNZ5MGUsyPf1I | If only we had a few more affiliate sponsors ;) | 13 | 2 | 0 | 2w | Post | John Wright | https://www.linkedin.com/in/alwayslookright | https://linkedin.com/in/alwayslookright | 2025-12-08T04:43:09.925Z |  | 2025-11-19T10:41:37.972Z |  |  | 

---



---

# John Wright
*StatsDrone*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 18 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [Why do affiliates not use apps to track their affiliate stats?](https://affiliatebi.beehiiv.com/p/why-do-affiliates-not-use-apps-to-track-their-affiliate-stats-2c87)
- Category: article

### [Affiliate Series with John Wright](https://philfraser.co.uk/statsdrone-john-wright/)
*2023-04-03*
- Category: article

### [Ep. 170: Solving the revenue leak problem w/ John Wright from StatsDrone](https://podcasts.apple.com/jp/podcast/ep-170-solving-the-revenue-leak-problem-w-john-wright/id1594903698?i=1000714518239&l=en-US)
*2025-06-25*
- Category: podcast

### [Affiliate BI - the Advanced Affiliate Marketing Podcast by StatsDrone](https://poddtoppen.se/podcast/1700893670/affiliate-bi-the-advanced-affiliate-marketing-podcast-by-statsdrone)
*2025-09-09*
- Category: podcast

### [Are You Ready For This? (Black Hat) SEO for Casino & Gambling Sites With John Wright - SEO Podcast by Olga Zarr](https://poddtoppen.se/podcast/1652341332/seo-podcast-by-olga-zarr/are-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright)
*2025-02-16*
- Category: podcast

---

## 📖 Full Content (Scraped)

*10 articles scraped, 16,310 words total*

### Why do affiliates not use apps to track their affiliate stats?
*936 words* | Source: **EXA** | [Link](https://affiliatebi.beehiiv.com/p/why-do-affiliates-not-use-apps-to-track-their-affiliate-stats-2c87)

Here are some stats I have about the affiliates that is based on some of my research.

1.   Less than 1% of affiliates track their affiliate stats with an app

2.   About 50% of affiliates use adtech and link management tools

So why are affiliates either checking their affiliate stats manually with spreadsheets or simply not tracking anything at all?

BTW quick shoutout to our newsletter sponsors of StatsDrone and FTDx.

I do think more affiliates should use affiliate stats tools like StatsDrone and that inclues other tools like Nifty Stats, **[Routy](https://www.linkedin.com/company/routy/?utm_source=affiliatebi.beehiiv.com&utm_medium=referral&utm_campaign=why-do-affiliates-not-use-apps-to-track-their-affiliate-stats)** and even Voonix. Yes, the same Voonix that I found bidding on the ‘statsdrone’ keywords in Google.

That’s ok, it was about time I started mastering the art of paid ads in B2B and that inspired me to write **[this article](https://statsdrone.com/blog/what-voonix-doesnt-want-you-to-know-about-statsdrone/?utm_source=affiliatebi.beehiiv.com&utm_medium=referral&utm_campaign=why-do-affiliates-not-use-apps-to-track-their-affiliate-stats)** as well.

![Image 1](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/78db2c67-25df-443c-958f-a7e3d07b57b4/tam-slide-statsdrone.jpg?t=1750935904)

### **Let’s start with link management tools**

My definition of link management tools are any means for an affiliate to manage their tracking links. That is, rather than copy and paste the tracking link given to them by the affiliate program, they use a link redirect.

My initial research in scanning tracking links pointing to iGaming operator brands tells me that about 50% of affiliates use these link redirects, or affiliate link cloaking as others would call them. Keep in mind that the biggest affiliates in the world own most of the traffic and almost all of them use link management tools. Kinda like that whole 80/20 rule that everyone talks about.

![Image 2](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/d3a0c10c-f98a-467b-8171-de3c896374ec/affiliate-link-management-tools.jpg?t=1750935770)

### **So how many affiliates use an app to track their stats?**

It is nearly that 80/20 rule happening all over again.

![Image 3](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/e1b5df4e-1a32-4c1d-8cd6-e81fadb1feb9/egr-top-25.jpeg?t=1750935783)

If we look at the EGR Power Affiliates 2025 of the top 25 affiliates, this list is comprised of the following:

*   In-house affiliate stats systems

*   StatsDrone

*   Voonix

*   Routy

At the time of publication, StatsDrone was powering 10% of this list and we have lofty goals to add 5 more customers by the end of this year.

Let me estimate how many affiliates are using any apps

*   Voonix: approx 100 users

*   Routy: 50+

*   StatsDrone: under 100 users

*   Nifty Stats: perhaps 1000 to 2500 users

*   In-house apps: 100+

So if we can all agree that there are millions of affiliates out there based on data from large affiliate networks and programs like **[Amazon Associates](https://www.linkedin.com/company/amazom-associates/?utm_source=affiliatebi.beehiiv.com&utm_medium=referral&utm_campaign=why-do-affiliates-not-use-apps-to-track-their-affiliate-stats)** and **[Awin Global](https://www.linkedin.com/company/awin-global/?utm_source=affiliatebi.beehiiv.com&utm_medium=referral&utm_campaign=why-do-affiliates-not-use-apps-to-track-their-affiliate-stats)**, then I think the following is true.

![Image 4](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/d1257771-5f1a-4a87-a7d6-21da67ec0281/statsdrone-odys-awards-winner.jpg?t=1750936004)

Also another shoutout to Odys Global and Alex Drew for awarding StatsDrone as the **[Best Stats Tracker 2025](https://statsdrone.com/blog/winner-odys-global-awards-2025/?utm_source=affiliatebi.beehiiv.com&utm_medium=referral&utm_campaign=why-do-affiliates-not-use-apps-to-track-their-affiliate-stats)** from the Odys Global Awards.

Back on topic, less than 1% of affiliates globally will track their stats using an app.

So why is that and what is stopping affiliates from using any of these tools?

### **Affiliate data privacy**

One of the most common questions I get asked about StatsDrone is, how do we know you’re not looking at our data?

We answer that direct and tell affiliates that they can choose to store data on their own server and we also have built an on-prem version of our app. Simply put, we are not looking at customer data and the data we are tracking is the success or failure of connections of any affiliate program.

Is that the only reason?

I think the other problem is this tool for affiliates to check their affiliate stats once a day, doesn’t have a big name behind it yet. 

*[... truncated, 4,452 more characters]*

---

### Affiliate Series with John Wright
*1,354 words* | Source: **EXA** | [Link](https://philfraser.co.uk/statsdrone-john-wright/)

Affiliate Series with John Wright and Phil Fraser

===============

[Skip to content](https://philfraser.co.uk/statsdrone-john-wright/#content)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

[](https://philfraser.co.uk/statsdrone-john-wright/# "Menu")

[Phil Fraser - Business Sounding Board](https://philfraser.co.uk/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

© 2025 Phil Fraser - Business Sounding Board. Created for free using WordPress and [Colibri](https://colibriwp.com/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

[](https://philfraser.co.uk/statsdrone-john-wright/# "Menu")

[Phil Fraser - Business Sounding Board](https://philfraser.co.uk/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

© 2025 Phil Fraser - Business Sounding Board. Created for free using WordPress and [Colibri](https://colibriwp.com/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

[](https://philfraser.co.uk/statsdrone-john-wright/# "Menu")

[Phil Fraser - Business Sounding Board](https://philfraser.co.uk/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

© 2025 Phil Fraser - Business Sounding Board. Created for free using WordPress and [Colibri](https://colibriwp.com/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)
*   [Leeds Business Podcast](https://philfraser.co.uk/leeds-business-podcast/)
*   [About Me](https://philfraser.co.uk/about-me/)
*   [Contact me](https://philfraser.co.uk/contact-me/)

[](https://philfraser.co.uk/statsdrone-john-wright/# "Menu")

[Phil Fraser - Business Sounding Board](https://philfraser.co.uk/)

*   [Home](https://philfraser.co.uk/)
*   [What is a Business Sounding Board?](https://philfraser.co.uk/what-is-a-business-sounding-board/)
*   [Watch & Hear Phil](https://philfraser.co.uk/watch-hear-phil/)
*   [What Clients Say](https://philfraser.co.uk/Client-reviews/)
*   [Nous of Fraser](https://philfraser.co.uk/nous-of-fraser/)

*[... truncated, 13,026 more characters]*

---

### Ep. 170: Solving the revenue leak problem w/ John Wright from StatsDrone
*1,546 words* | Source: **EXA** | [Link](https://podcasts.apple.com/jp/podcast/ep-170-solving-the-revenue-leak-problem-w-john-wright/id1594903698?i=1000714518239&l=en-US)

Ep. 170: Solving the revenue l… - The Betting Startups Podcast - Apple Podcasts

===============

[](https://podcasts.apple.com/jp/new?l=en)

*   [Home](https://podcasts.apple.com/jp/home?l=en)
*   [New](https://podcasts.apple.com/jp/new?l=en)
*   [Top Charts](https://podcasts.apple.com/jp/charts?l=en)
*   [Search](https://podcasts.apple.com/jp/search?l=en)

Open in Podcasts

PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

![Image 1: The Betting Startups Podcast](https://podcasts.apple.com/assets/artwork/1x1.gif)

*   JUN 25
*   EPISODE 194
*   40 MIN

Ep. 170: Solving the revenue leak problem w/ John Wright from StatsDrone
========================================================================

[The Betting Startups Podcast](https://podcasts.apple.com/jp/podcast/the-betting-startups-podcast/id1594903698?l=en-US)

 Play 

Ep. 170 features John Wright from StatsDrone, a business intelligence platform helping affiliates eliminate revenue leak and unlock more value from their data. John shares how the company is centralizing fragmented affiliate stats, building tools for operators, and uncovering hidden opportunities in iGaming’s affiliate ecosystem.

Hear them discuss:

*   The origin story from professional gambler to affiliate tech founder
*   How revenue leak inspired the earliest version of StatsDrone
*   Why “business intelligence” became the heart of their value proposition
*   Who uses the platform today—from SEO affiliates to large networks
*   How StatsDrone is building a global map of affiliate sites and links
*   The surprising ROI hiding in broken tracking and closed casino
*   Why affiliate CRM remains an underdeveloped opportunity
*   How operators and affiliate managers are starting to use their insights
*   What it’s like navigating investor interest and potential exit offers
*   His two-year vision to unlock billions in affiliate-side revenue optimization

Applications now open for SBC Summit First Pitch competition returning to Lisbon this September 16-18. Eligible startups can submit their applications until July 25 for a shot at over $100,000 worth of prizes.

Catch the video version of this episode here.

Learn more 👇

➡️ StatsDrone website

➡️ John Wright on Linkedin

📩 Get the top headlines from the industry's most promising growth-stage companies every week—totally free! Subscribe to the Betting Startups newsletter here:https://news.bettingstartups.com/

--

This podcast is presented by Optimove, the #1 CRM Marketing solution for the iGaming industry. Since 2012,Optimove has served iGaming Operators from startups to industry leaders. Today, 4 out of the Top 5 US Operators Personalize Player Experiences with Optimove. iGaming operators know their growth journey begins and continues with Optimove, the #1 CRM Marketing solution for the iGaming industry.

[Episode Webpage](https://bettingstartups.podbean.com/e/ep-170-solving-the-revenue-leak-problem-w-john-wright-from-statsdrone/)

Information
-----------

*   Show [The Betting Startups Podcast](https://podcasts.apple.com/jp/podcast/the-betting-startups-podcast/id1594903698?l=en-US) 
*   Frequency Updated Weekly 
*   Published June 25, 2025 at 2:42 PM UTC 
*   Length 40 min 
*   Episode 194 
*   Rating Clean 

Japan
*   [日本語](https://podcasts.apple.com/jp/podcast/ep-170-solving-the-revenue-leak-problem-w-john-wright/id1594903698?l=ja)

Select a country or region

Africa, Middle East, and India
------------------------------

See All 

*   [Algeria](https://podcasts.apple.com/dz/new)
*   [Angola](https://podcasts.apple.com/ao/new)
*   [Armenia](https://podcasts.apple.com/am/new)
*   [Azerbaijan](https://podcasts.apple.com/az/new)
*   [Bahrain](https://podcasts.apple.com/bh/new)
*   [Benin](https://podcasts.apple.com/bj/new)
*   [Botswana](https://podcasts.apple.com/bw/new)
*   [Brunei Darussalam](https://podcasts.apple.com/bn/new)
*   [Burkina Faso](https://podcasts.apple.com/bf/new)
*   [Cameroun](https://podcasts.apple.com/cm/new)
*   [Cape Verde](https://podcasts.apple.com/cv/new)
*   [Chad](https://podcasts.apple.com/td/new)
*   [Côte d’Ivoire](https://podcasts.apple.com/ci/new)
*   [Congo, The Democratic Republic Of The](https://podcasts.apple.com/cd/new)
*   [Egypt](https://podcasts.apple.com/eg/new)
*   [Eswatini](https://podcasts.apple.com/sz/new)
*   [Gabon](https://podcasts.apple.com/ga/new)
*   [Gambia](https://podcasts.apple.com/gm/new)
*   [Ghana](https://podcasts.apple.com/gh/new)
*   [Guinea-Bissau](https://podcasts.apple.com/gw/new)
*   [India](https://podcasts.apple.com/in/new)
*   [Iraq](https://podcasts.apple.com/iq/new)
*   [Israel](https://podcasts.apple.com/il/new)
*   [Jordan](https://podcasts.apple.com/jo/new)
*   [Kenya](https://podcasts.apple.com/ke/new)
*   [Kuwait](https:

*[... truncated, 19,970 more characters]*

---

### Revenue Optimization with StatsDrone
*661 words* | Source: **EXA** | [Link](https://poddtoppen.se/podcast/1700893670/affiliate-bi-the-advanced-affiliate-marketing-podcast-by-statsdrone)

Revenue Optimization with StatsDrone | Lyssna här | Poddtoppen.se

===============

[](https://poddtoppen.se/ "Poddtoppen")

[](https://poddtoppen.se/min-sida "Min sida")

### Kategorier

*   [Topplistan](https://poddtoppen.se/kategori/topplistan)
*   [Komedi](https://poddtoppen.se/kategori/komedi)
*   [Samhälle och kultur](https://poddtoppen.se/kategori/samhalle-och-kultur)
*   [Näringsliv](https://poddtoppen.se/kategori/naringsliv)
*   [Konst](https://poddtoppen.se/kategori/konst)
*   [Barn och familj](https://poddtoppen.se/kategori/barn-och-familj)
*   [Verkliga brott](https://poddtoppen.se/kategori/verkliga-brott)
*   [Religion och spiritualitet](https://poddtoppen.se/kategori/religion-och-andlighet)
*   [Utbildning](https://poddtoppen.se/kategori/utbildning)
*   [TV och film](https://poddtoppen.se/kategori/tv-och-film)
*   [Musik](https://poddtoppen.se/kategori/musik)
*   [Myndighet & organisation](https://poddtoppen.se/kategori/myndighet-och-organisation)
*   [Teknologi](https://poddtoppen.se/kategori/teknologi)
*   [Historia](https://poddtoppen.se/kategori/historia)
*   [Fritid](https://poddtoppen.se/kategori/fritid)
*   [Skönlitteratur](https://poddtoppen.se/kategori/skonlitteratur)
*   [Vetenskap](https://poddtoppen.se/kategori/vetenskap)
*   [Sport](https://poddtoppen.se/kategori/sport)
*   [Nyheter](https://poddtoppen.se/kategori/nyheter)
*   [Hälsa och motion](https://poddtoppen.se/kategori/halsa-och-motion)

[Om Poddtoppen](https://poddtoppen.se/om "Om Poddtoppen") | [Om Podcast](https://poddtoppen.se/om-podcast "Om Podcast") | [Cookies](https://poddtoppen.se/podcast/1700893670/affiliate-bi-the-advanced-affiliate-marketing-podcast-by-statsdrone#)

Topplistorna hämtas med hjälp av iTunes.

![Image 1: Revenue Optimization with StatsDrone](https://img.poddtoppen.se/revenue-optimization-with-statsdrone-SlkA-rqTioii.png?width=300&height=300)

Revenue Optimization with StatsDrone
====================================

Spela senaste

Dela

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fpoddtoppen.se%2Fpodcast%2F1700893670%2Frevenue-optimization-with-statsdrone&title=Revenue+Optimization+with+StatsDrone&redirect_uri=https%3A%2F%2Fpoddtoppen.se%2Fpodcast%2F1700893670%2Frevenue-optimization-with-statsdrone&app_id=182828318894708&display=popup "Dela Revenue Optimization with StatsDrone på Facebook")[Twitter](http://x.com/intent/tweet?text=Revenue%20Optimization%20with%20StatsDrone&url=https://poddtoppen.se/podcast/1700893670/revenue-optimization-with-statsdrone "Dela Revenue Optimization with StatsDrone på X")Kopiera länk

Welcome to Revenue Optimization with StatsDrone. A business podcast focused on affiliate marketing covering topics such as big data, AI, Business Intelligence, SEO and optimization of course.

This podcast is brought to you by https://statsdrone.com and ____________; your company here!

Welcome to Revenue Optimization with StatsDrone. A business podcast focused on affiliate marketing covering topics such as big data, AI, Business Intelligence, SEO and optimization of course.

This podcast is brought to you by https://statsdrone.com and ____________; your company here!

[Näringsliv](https://poddtoppen.se/kategori/naringsliv)[Entreprenörskap](https://poddtoppen.se/kategori/entreprenorskap)[Marknadsföring](https://poddtoppen.se/kategori/marknadsforing)

Avsnitt

122

Senaste

24 november, 2025

Längd

7 min

 Podden [Revenue Optimization with StatsDrone](https://podcasts.castplus.fm/affiliatebi "Webb för Revenue Optimization with StatsDrone") görs av [John Wright.](https://poddtoppen.se/skapare/john-wright "Skapad av John Wright")

[Rss](https://feeds.castplus.fm/affiliatebi)[Apple Podcaster →](https://podcasts.apple.com/us/podcast/affiliate-bi-the-advanced-affiliate-marketing-podcast/id1700893670?uo=4)

Fler avsnitt av Revenue Optimization with StatsDrone
----------------------------------------------------

Senaste

[### Claude.ai for Advanced Data Viz 2025-11-24| 7 min](https://poddtoppen.se/podcast/1700893670/revenue-optimization-with-statsdrone/claudeai-for-advanced-data-viz "Avsnitt: Claude.ai for Advanced Data Viz")

[### Optimizing pages for AI Search with GEO, tips from Steve Toth 2025-11-16| 6 min](https://poddtoppen.se/podcast/1700893670/revenue-optimization-with-statsdrone/optimizing-pages-for-ai-search-with-geo-tips-from-steve-toth "Avsnitt: Optimizing pages for AI Search with GEO, tips from Steve Toth")

[### A Deeper Look at Closed Casinos 2025-11-07| 8 min](https://poddtoppen.se/podcast/1700893670/revenue-optimization-with-statsdrone/a-deeper-look-at-closed-casinos "Avsnitt: A Deeper Look at Closed Casinos")

[### The AI Shift: Why Affiliates Must Evolve Now 2025-10-31| 9 min](https://poddtoppen.se/podcast/1700893670/revenue-optimization-with-statsdrone/the-ai-shift-why-affiliates-must-evolve-now "Avsnitt: The AI Shift: Why Affiliates Must Evolve Now")

[### Hiring a Revenue Architect for your Affiliate Business 2025-10-24| 3 min](https://poddtoppen.se

*[... truncated, 5,832 more characters]*

---

### Are You Ready For This? (Black Hat) SEO for Casino & Gambling Sites With John Wright - SEO Podcast by Olga Zarr
*408 words* | Source: **EXA** | [Link](https://poddtoppen.se/podcast/1652341332/seo-podcast-by-olga-zarr/are-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright)

[](https://poddtoppen.se/ "Poddtoppen")

[](https://poddtoppen.se/min-sida "Min sida")

### Kategorier

*   [Topplistan](https://poddtoppen.se/kategori/topplistan)
*   [Komedi](https://poddtoppen.se/kategori/komedi)
*   [Samhälle och kultur](https://poddtoppen.se/kategori/samhalle-och-kultur)
*   [Näringsliv](https://poddtoppen.se/kategori/naringsliv)
*   [Konst](https://poddtoppen.se/kategori/konst)
*   [Barn och familj](https://poddtoppen.se/kategori/barn-och-familj)
*   [Verkliga brott](https://poddtoppen.se/kategori/verkliga-brott)
*   [Religion och spiritualitet](https://poddtoppen.se/kategori/religion-och-andlighet)
*   [Utbildning](https://poddtoppen.se/kategori/utbildning)
*   [TV och film](https://poddtoppen.se/kategori/tv-och-film)
*   [Musik](https://poddtoppen.se/kategori/musik)
*   [Myndighet & organisation](https://poddtoppen.se/kategori/myndighet-och-organisation)
*   [Teknologi](https://poddtoppen.se/kategori/teknologi)
*   [Historia](https://poddtoppen.se/kategori/historia)
*   [Fritid](https://poddtoppen.se/kategori/fritid)
*   [Skönlitteratur](https://poddtoppen.se/kategori/skonlitteratur)
*   [Vetenskap](https://poddtoppen.se/kategori/vetenskap)
*   [Sport](https://poddtoppen.se/kategori/sport)
*   [Nyheter](https://poddtoppen.se/kategori/nyheter)
*   [Hälsa och motion](https://poddtoppen.se/kategori/halsa-och-motion)

[Om Poddtoppen](https://poddtoppen.se/om "Om Poddtoppen") | [Om Podcast](https://poddtoppen.se/om-podcast "Om Podcast") | [Cookies](https://poddtoppen.se/podcast/1652341332/seo-podcast-by-olga-zarr/are-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright#)

Topplistorna hämtas med hjälp av iTunes.

![Image 1: SEO Podcast by Olga Zarr](https://img.poddtoppen.se/seo-podcast-by-olga-zarr-v8z5XGwAIwXd.jpg?width=300&height=300)

Avsnitt

Are You Ready For This? (Black Hat) SEO for Casino & Gambling Sites With John Wright
------------------------------------------------------------------------------------

[SEO Podcast by Olga Zarr](https://poddtoppen.se/podcast/1652341332/seo-podcast-by-olga-zarr "SEO Podcast by Olga Zarr")

[Facebook](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fpoddtoppen.se%2Fpodcast%2F1652341332%2Fseo-podcast-by-olga-zarr%2Fare-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright&title=SEO+Podcast+by+Olga+Zarr+-+Are+You+Ready+For+This%3F+%28Black+Hat%29+SEO+for+Casino+%26+Gambling+Sites+With+John+Wright&redirect_uri=https%3A%2F%2Fpoddtoppen.se%2Fpodcast%2F1652341332%2Fseo-podcast-by-olga-zarr%2Fare-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright&app_id=182828318894708&display=popup "Dela avsnittet av SEO Podcast by Olga Zarr på Facebook")[Twitter](http://x.com/intent/tweet?text=SEO%20Podcast%20by%20Olga%20Zarr%20-%20Are%20You%20Ready%20For%20This?%20(Black%20Hat)%20SEO%20for%20Casino%20&%20Gambling%20Sites%20With%20John%20Wright&url=https://poddtoppen.se/podcast/1652341332/seo-podcast-by-olga-zarr/are-you-ready-for-this-black-hat-seo-for-casino-gambling-sites-with-john-wright "Dela avsnittet av SEO Podcast by Olga Zarr på Twitter")

In this episode, I interview John Wright, a professional in the iGaming industry. John shares his unconventional journey from engineering to professional gambling, and eventually to SEO consulting for online casinos and gambling affiliates. The conversation delves into the complexities of SEO in the iGaming space, including data-driven decision making, the impact of Google's algorithm updates, and innovative strategies for building authoritative content. John also discusses his current venture, Stats Drone, a comprehensive software solution tailored for gambling affiliates, and touches upon responsible gambling initiatives.

Follow SEO Consultant Olga Zarr or hire Olga to help you with SEO:

👉 Follow[Olga Zarr X](https://x.com/olgazarr)([https://x.com/olgazarr](https://x.com/olgazarr))

👉Follow[Olga Zarr on LinkedIn](https://www.linkedin.com/in/olgazarr/)([https://www.linkedin.com/in/olgazarr/](https://www.linkedin.com/in/olgazarr/))

👉[SEO newsletter](https://seosly.io/)([https://seosly.io/](https://seosly.io/))

👉[SEO podcast](https://seosly.com/podcast/)([https://seosly.com/podcast/](https://seosly.com/podcast/))

👉[SEO consultant Olga Zarr](https://seosly.com/seo-consultant/)([https://seosly.com/seo-consultant/](https://seosly.com/seo-consultant/))

👉The best[SEO course](https://seosly.com/seo-course/)([https://seosly.com/seo-course/](https://seosly.com/seo-course/))

Watch the video version:https://youtu.be/j9LMpZesI1o

[Rss](https://app.kajabi.com/podcasts/2147507240/feed)[Apple Podcaster →](https://podcasts.apple.com/us/podcast/seo-podcast-by-olga-zarr/id1652341332?uo=4)

Podden och tillhörande omslagsbild på den här sidan tillhör Olga Zarr. Innehållet i podden är skapat av Olga Zarr och inte av, eller tillsammans med, Poddtoppen.

[Populärt på poddtoppen just nu ------------------------------](https://poddtoppen.se/populara)

[![Image

*[... truncated, 2,369 more characters]*

---

### Revenue Optimization with StatsDrone
*2,200 words* | Source: **GOOGLE** | [Link](https://podcasts.apple.com/us/podcast/revenue-optimization-with-statsdrone/id1700893670)

Revenue Optimization with StatsDrone - Podcast - Apple Podcasts

===============

[](https://podcasts.apple.com/us/new)

*   [Home](https://podcasts.apple.com/us/home)
*   [New](https://podcasts.apple.com/us/new)
*   [Top Charts](https://podcasts.apple.com/us/charts)
*   [Search](https://podcasts.apple.com/us/search)

Open in Podcasts

PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

Sign In

1×

1×

*   0.8×  
*   1×  
*   1.3×  
*   1.5×  
*   1.8×  
*   2×  

Faster

Slower

Skip back PLAY PLAY PLAY Skip ahead

![Image 1](https://podcasts.apple.com/assets/artwork/1x1.gif)

Revenue Optimization with StatsDrone
====================================

John Wright

*    5.0 (2) 
*   MARKETING
*   UPDATED WEEKLY

Welcome to Revenue Optimization with StatsDrone. A business podcast focused on affiliate marketing covering topics such as big data, AI, Business Intelligence, SEO and optimization of course. This podcast is brought to you by https://statsdrone.com and ____________; your company here!

MORE

Revenue Optimization with StatsDrone
====================================

Welcome to Revenue Optimization with StatsDrone. A business podcast focused on affiliate marketing covering topics such as big data, AI, Business Intelligence, SEO and optimization of course. This podcast is brought to you by https://statsdrone.com and ____________; your company here!

 Latest Episode 

Follow

Episodes
--------

1.   [NOV 24 ### Claude.ai for Advanced Data Viz I'm here to officially say that tools like Claude.ai and all other AI tools are here to eat data viz tools like Tableau, Power BI, Looker Studio and more. If I were at any of these companies, I would be concerned to see if the revenue from these giants is starting to drop. Likewise, I think people working with these tools need to be spending a lot more time on the AI side of things for better analysis. You need to be using these tools so you can double your output rather than be on the wrong side of employment. 7 min](https://podcasts.apple.com/us/podcast/claude-ai-for-advanced-data-viz/id1700893670?i=1000738055930) 
2.   [NOV 16 ### Optimizing pages for AI Search with GEO, tips from Steve Toth I found a LinkedIn post of someone taking an account of Steve Toth's presentation recently at Chiang Mai SEO that focuses on LLM and how these new AI tools like Claude, Chat GPT and Perplexity are changing search from clicks to conversations. 7 min](https://podcasts.apple.com/us/podcast/optimizing-pages-for-ai-search-with-geo-tips-from-steve-toth/id1700893670?i=1000736958127) 
3.   [NOV 7 ### A Deeper Look at Closed Casinos This past week, I presented a keynote on why online casinos close. I did share some data that shows what is behind the scenes that would lead a casino to close at all in the first place. In this short solo cast, I share a few more insights but my work in analyzing closed casinos isn't done yet! 9 min](https://podcasts.apple.com/us/podcast/a-deeper-look-at-closed-casinos/id1700893670?i=1000735684608) 
4.   [OCT 31 ### The AI Shift: Why Affiliates Must Evolve Now If you haven't made a serious start in AI tools today in running and optimizing your affiliate business, you might be getting left behind. My personal take, the transformation we see today will be more profound than the internet itself. I think this is a new era of affiliate marketing beyond the new world of Google. Google isn't the dominant player it used to be and likely will continue to lose marketshare to other AI tools like ChatGPT, Claude, Perplexity and many others. So how am I using AI for our business? Listen and tune in. 10 min](https://podcasts.apple.com/us/podcast/the-ai-shift-why-affiliates-must-evolve-now/id1700893670?i=1000734456856) 
5.   [OCT 24 ### Hiring a Revenue Architect for your Affiliate Business We are on the look out for a revenue architect for StatsDrone and someone who knows what it is like to negotiate deals with affiliate programs. We don't fun your standard affiliate business as we are a SaaS for affiliates, but the revenue potential could help us grow. This is something I learned from one of our customers that told me, hiring a revenue officer was one of the best decisions they made as a company that grew revenue. Are these people account managers or affiliate managers? No matter what you call them, they are important people that will be sought out as time goes on. 4 min](https://podcasts.apple.com/us/podcast/hiring-a-revenue-architect-for-your-affiliate-business/id1700893670?i=1000733359455) 
6.   [OCT 14 ### Why Online Casinos Close Why do online casinos close? There are many reasons but what should be the bigger concern is that these casinos close taking down their recurring revenue with it. How can you avoid casinos that might close beyond just asking for listing fees? 4 min](https://podcasts.apple.com/us/podcast/why-online-casinos-close/id1700893670?i=1000

*[... truncated, 24,961 more characters]*

---

### Never Stop Innovating: John Wright on iGaming, SEO & Affiliate Marketing
*3,517 words* | Source: **GOOGLE** | [Link](https://www.fortismedia.com/en/articles/john-wright-igaming-affiliate-marketing-seo-trends/)

We recently had the pleasure of speaking with John Wright, the Co-Founder of StatsDrone, an analytics tool designed to optimize affiliate performance by highlighting critical data insights and revenue opportunities. StatsDrone has been recognized for its excellence in affiliate technology, winning Best Tech for Affiliates at the 2024 iGB Affiliate Awards, Affiliate Intelligence of the Year at the 2024 Affpapa Awards, and Best Affiliate Stats Tool at the 2025 Odys Awards. John, a seasoned professional with over two decades of experience in affiliate marketing, data analytics, and digital strategy, shared his expert perspectives on SEO, AI, cryptocurrency, and the future of affiliate marketing.

**Who is John Wright, and what led you to the iGaming and affiliate marketing industry?**
-----------------------------------------------------------------------------------------

**John Wright:**I’ve been involved in iGaming and affiliate marketing for nearly 24 years, initially drawn to the industry by its dynamic nature and continuous innovation. My passion lies in understanding user behavior, leveraging data, and using SEO strategies to help affiliates succeed. Early on, I recognized the potential of digital marketing within the rapidly growing online gambling sector, which led me to specialize in affiliate marketing, SEO strategies, and later, analytics.

What inspired you to create StatsDrone, and how does it help affiliates manage their data?
------------------------------------------------------------------------------------------

**John Wright:** It’s a great question. Creating **StatsDrone was driven by a need to solve practical problems rather than solely focusing on SEO or other marketing strategies**. As an affiliate manager, I often encountered affiliates whose main metric was receiving the highest possible revenue share. However, offering excessively high revenue shares wasn’t sustainable or realistic in the long run. I noticed that many affiliates didn’t thoroughly analyze their own data, which could lead to significant revenue leaks.

Existing tools, such as Stats Remote, provided basic insights but lacked essential functionalities to help affiliates identify issues like outdated links or casino closures. I saw a clear opportunity to develop a more comprehensive solution.

[StatsDrone](https://statsdrone.com/) helps affiliates by providing real-time alerts and detailed analytics, highlighting issues that could impact revenue streams, such as broken links, changes in affiliate software, or closed casinos. By delivering clear, actionable data through intuitive graphs and alerts, StatsDrone enables affiliates to proactively manage their business, ultimately improving their efficiency and profitability.

What trends in user behavior and engagement have you observed through StatsDrone’s analytics?
---------------------------------------------------------------------------------------------

**John Wright:** Not many people realize that StatsDrone doesn’t directly analyze our customers’ data. We don’t access their traffic or revenue data unless explicitly requested, such as for custom dashboard creation. The only time we would see this data is if customers explicitly share it with us, for example, when they request a custom dashboard. I’m continuously engaging with very successful iGaming affiliates and SEO professionals who run their own agencies to better understand industry trends.

Sometimes their answers align closely, but I believe there’s a deeper shift happening beyond just data and traditional SEO practices. **Google’s recent focus on the “helpful content” update suggests that genuine products and authentic, [valuable content](https://www.fortismedia.com/en/articles/igaming-content-marketing/) are becoming increasingly critical.**

For instance, AskGamblers is more than just another review site; it provides tangible products like casino complaints management and a robust community platform. Without these features, they’d merely be another review site, which is a model that’s currently struggling.

To stand out today, affiliates must either produce exceptional, journalism-level content or develop unique products and platforms, creating conversations around topics nobody else is addressing, much like what are you Fortis Media are doing. Additionally, affiliates who effectively capture and analyze first-party data see better user retention and engagement.

![Image 1: myaffiliates-team-in-malta](https://www.fortismedia.com/wp-content/uploads/2025/03/myaffiliates-team-in-malta-1.jpg.webp)

What impact do AI and machine learning have on the iGaming sector?
------------------------------------------------------------------

**John Wright:** I believe there’s a specific time and place for AI in the iGaming sector. Over the past year and a half, we’ve seen people primarily use AI tools for automation, especially in content creation. Initially, this seemed promising, but it’s **clear that simply automating

*[... truncated, 20,092 more characters]*

---

### John Wright - iGaming Club
*518 words* | Source: **GOOGLE** | [Link](https://igaming.club/member/john-wright/)

John Wright - iGaming Club

===============

[![Image 2: iGaming Club Logo](https://igaming.club/wp-content/uploads/2022/12/igaming-club-white-logo.webp)](https://igaming.club/ "iGaming Club")

*   [Barcelona 2026](https://igaming.club/barcelona-2026/ "Barcelona 2026")
*   [Madrid 2026](https://igaming.club/madrid-2026/ "Madrid 2026")
*   [Past Events](https://igaming.club/member/john-wright/# "Past Events")
    *   [Cancun 2025](https://igaming.club/cancun-2025/ "Cancun 2025")
    *   [Lisbon 2025](https://igaming.club/lisbon-2025/ "Lisbon 2025")
    *   [London 2025](https://igaming.club/london-2025/ "London 2025")
    *   [Malaga 2025](https://igaming.club/malaga-2025/ "Malaga 2025")
    *   [Barcelona 2025](https://igaming.club/barcelona-2025/ "Barcelona 2025")
    *   [Lisbon 2024](https://igaming.club/lisbon-2024/ "Lisbon 2024")
    *   [Amsterdam 2024](https://igaming.club/amsterdam-2024/ "Amsterdam 2024")
    *   [Malaga 2024](https://igaming.club/malaga-2024/ "Malaga 2024")
    *   [London 2024](https://igaming.club/london-2024/ "London 2024")
    *   [London 2023](https://igaming.club/london-2023/ "London 2023")
    *   [Malta 2023](https://igaming.club/malta-2023/ "Malta 2023")
    *   [Barcelona 2023](https://igaming.club/barcelona-2023/ "Barcelona 2023")
    *   [Amsterdam 2023](https://igaming.club/amsterdam-2023/ "Amsterdam 2023")
    *   [Amsterdam 2022](https://igaming.club/amsterdam-2022/ "Amsterdam 2022")

*   [Members](https://igaming.club/members/ "Members")
    *   [Ambassadors](https://igaming.club/members/ambassadors/ "Ambassadors")
    *   [Speakers](https://igaming.club/members/speakers/ "Speakers")

*   [Contact Us](https://igaming.club/member/john-wright/# "Contact Us")

[Contact Us](https://igaming.club/member/john-wright/#myModal)

*   [Home](https://igaming.club/ "Home")

*   [Members](https://igaming.club/members/ "Members")

*   John Wright

John Wright
===========

![Image 3: John Wright](https://igaming.club/wp-content/uploads/2024/03/john-wright-sigma-johnny-150x150.jpeg)
*   [](https://www.linkedin.com/in/alwayslookright/ "Social Link")

John Wright
-----------

*   Position: CEO & Co-founder
*   Company Name: StatsDrone
*   Website:[https://statsdrone.com](https://statsdrone.com/ "StatsDrone")
*   Email:[john@statsdrone.com](mailto:john@statsdrone.com "Email")

### Personal Information

John is an iGaming veteran with over 20 years of experience as a pro gambler, affiliate manager, and affiliate. He has extensive experience as an affiliate coach as well as an SEO and UX consultant and is the host of the Affiliate BI podcast.

He has a degree in mechanical engineering focusing on AI and robotics and is taking that experience into building StatsDrone as a tech company for affiliates. He has a keen interest in helping affiliates become more data-driven in their business.

John is advancing his skills as a data analyst by learning BI tools like Looker Studio, Power BI, and Tableau and learning to combine data with AI tools.

Share:
*   [](https://www.facebook.com/sharer/sharer.php?u=https://igaming.club/john-wright/ "Social Link")
*   [](https://www.linkedin.com/sharing/share-offsite/?url=https://igaming.club/john-wright/ "Social Link")
*   [](https://twitter.com/share?text=John%20Wright&url=https://igaming.club/john-wright/&hashtags=iGamingClub,JohnWright,AffPapa "Social Link")
*   [](https://wa.me/?text=https://igaming.club/member/john-wright/ "Social Link")
*   [](https://t.me/share/url?url=https://igaming.club/member/john-wright/&text=John%20Wright "Social Link")

[![Image 4: iGaming Club Logo](https://igaming.club/wp-content/uploads/2022/12/igaming-club-white-logo.webp)](https://igaming.club/ "iGaming Club")[![Image 5: AffPapa.com - iGaming directory for Affiliates and Operators](https://igaming.club/wp-content/uploads/2024/08/AffPapa-Logo.svg)](https://affpapa.com/ "AffPapa.com - iGaming directory for Affiliates and Operators")[![Image 6: AffPapa iGaming Awards](https://igaming.club/wp-content/uploads/2024/08/affpapa-igaming-awards-logo.png)](https://affpapa.com/igaming-awards-latam/ "AffPapa iGaming Awards Latam")[![Image 7: TheGamblest Logo](https://igaming.club/wp-content/uploads/2024/06/logo_footer_white.svg)](https://www.thegamblest.com/ "TheGamblest")

Articles

*   [Best iGaming Affiliates](https://affpapa.com/best-igaming-affiliates/ "Best iGaming Affiliates")
*   [Best iGaming Operators](https://affpapa.com/best-igaming-operators/ "Best iGaming Operators")
*   [Best iGaming B2B Providers](https://affpapa.com/best-igaming-b2b-software-providers/ "Best iGaming B2B Providers")
*   [Get Casino Traffic](https://affpapa.com/where-to-get-casino-traffic-from/ "Get Casino Traffic")
*   [Casino Affiliate Programs](https://affpapa.com/casino-affiliate-programs/ "Casino Affiliate Programs")
*   [Casino Affiliate Management](https://affpapa.com/the-ultimate-guide-to-casino-affiliate-management/ "Casino Affiliate Management")

More From Us

*   [AffPapa](https://affpapa.co

*[... truncated, 1,888 more characters]*

---

### Affiliate Q&A: John Wright, Co-founder at StatsDrone
*843 words* | Source: **GOOGLE** | [Link](https://www.incomeaccess.com/contenthub/affiliate-qa-john-wright-co-founder-at-statsdrone/)

![Image 1: Interviewer sitting with StatsDrone's co-founder](https://www.incomeaccess.com/fileadmin/_processed_/3/6/csm_Affiliate_QA_Stats_Drone_e6573f7b63.png)

For this installment of our Affiliate Q&A series, we sat down with John Wright, Co-founder at [StatsDrone](https://statsdrone.com/), to explore his journey in iGaming, their strategy for 2025, and much more!

**Income Access (IA): Thanks for speaking with us, John. Can you tell us a bit about your background in the iGaming industry?**
-------------------------------------------------------------------------------------------------------------------------------

![Image 2: John Wright, co-founder at StatsDrone](https://www.incomeaccess.com/fileadmin/hub/2025/08/John_Wright_StatsDrone.jpg)

John Wright (JW): My entry into iGaming was kind of accidental. One of my friends was trying to get me into the industry, but I didn’t believe you could make money working in iGaming at first. But after two years of him constantly messaging me, I decided to look into it.

I started playing blackjack online, mainly claiming bonuses and using basic strategy. Surprisingly, it gave me a return on investment very quickly. It worked out well, and that was the beginning of an iGaming journey that’s now been twenty-four years in the making.

Later, I had the opportunity to work on the operator side, including roles such as player manager, VIP manager, [affiliate manager](https://www.incomeaccess.com/affiliate-management/), and even in fraud prevention. Working with affiliates provided me with insight into how they manage their businesses. I saw it as a stable part of the industry. If an operator went out of business, affiliates didn’t lose their entire business, so it felt like a safe space. I stayed in that area for about 14 years.

**IA: That brings us to the next phase of your journey with StatsDrone. How did the idea for StatsDrone come about? What inspired its creation?**
-------------------------------------------------------------------------------------------------------------------------------------------------

JW: I was working as an affiliate manager and realized that not all affiliates are making data-driven decisions. When I switched and became an affiliate, I realized how big a problem revenue leak was. For example, if an[affiliate program](https://www.incomeaccess.com/affiliate-software/) switched platforms, the old links would sometimes be invalidated immediately. Even worse is when a program goes out of business. Those programs don’t email affiliates to tell them to remove their tracking links; they simply disappear, often leaving a trail of unpaid invoices.

I just felt that when running my affiliate sites with my business partner, the problem was big, but nobody had been able to quantify it. I wanted to fix this and do something, which is how StatsDrone came to be! I started building out the idea of helping affiliates make better decisions, such as determining where to send more traffic, identifying patterns, and providing data analysis so they wouldn’t need to be data experts.

**IA: Building on this vision, how does StatsDrone try to solve these key challenges for affiliates?**
------------------------------------------------------------------------------------------------------

![Image 3: The logo for StatsDrone](https://www.incomeaccess.com/fileadmin/_processed_/7/2/csm_statsdrone_logo_631b06d10e.jpg)

JW: StatsDrone is an affiliate stats aggregator, but don’t try to say that three times fast! Most affiliates work with multiple affiliate programs in iGaming, so the core problem we aim to solve is helping affiliates identify and address revenue leaks.

Overall, we offer a range of services: aggregating statistics from various platforms, normalizing and standardizing the data, adding CRM features, invoice generators, and, most importantly, delivering business intelligence to help our customers make informed decisions.

**IA: If StatsDrone were a person, how would you describe its personality in three words?**
-------------------------------------------------------------------------------------------

JW: Precise, innovative, and curious.

If anything, I would double down on the ‘curious’ part. We knew we wanted to solve a problem, but we didn’t know how impactful our work could be. I don’t envision a day when StatsDrone is done building and innovating the product, so I see this as a long-term journey of constant innovation.

**IA: Looking ahead to those entering the field, do you have any advice for new affiliates just getting started in the industry?**
----------------------------------------------------------------------------------------------------------------------------------

I am frequently asked this question by guests of the Affiliate BI podcast. There have been waves of change for affiliates over the last 20 years, and I believe we are currently experiencing our most significant wave of change.

Players will end up at iGaming brands eithe

*[... truncated, 1,132 more characters]*

---

### John Wright: From Affiliate to Operator to Leading StatsDrone
*4,327 words* | Source: **GOOGLE** | [Link](https://gamblingindustryjobs.com/career-conversations/john-wright-from-affiliate-to-operator-to-leading-statsdrone/)

1.   [Home](https://gamblingindustryjobs.com/)>
2.   [Career Conversations](https://gamblingindustryjobs.com/career-conversations/)>

![Image 1: Career Conversations Interview with John Wright](https://gamblingindustryjobs.com/wp-content/uploads/2025/09/John-Wright-1024x576.png)
In this edition of Career Conversations, we speak with John Wright, an iGaming veteran with nearly 25 years of experience across various facets of the industry, from professional gambler to affiliate and operator, and now CEO and Co-founder of StatsDrone.

Trained as an engineer, John “accidentally” entered iGaming and quickly saw recurring pain points: revenue leaks, broken/expired links after platform migrations, closed brands still receiving traffic, and data scattered across dashboards. That led to StatsDrone as a daily “home base” for affiliate revenue and alerts and now Affiliate Track, a tool aiming to map who links to whom, flag quality signals, and help both affiliates and managers make better decisions.

We also explore where the channel is heading: LATAM and parts of Asia heating up, the rise of streamers/influencers and private communities, and a shift toward choosing brands by player value, longevity, VIP, and trust, not just headline commission. John shares how first-party data and smart tracking variables let affiliates “own” their audience, while operators step up their own content and capture more organic demand.

**In this conversation, we talk about:**

*   How StatsDrone tackles revenue leak and why “home base” dashboards matter
*   Markets & channels on the rise (LATAM/Asia, streaming, influencers, private groups)
*   Choosing brands by player value, VIP, and reliability, not vanity offers
*   Finding & vetting affiliates beyond DR/vanity metrics (and spotting fakes)
*   Outreach that works: deliverability hygiene, personalization, and message craft
*   Dealmaking realities: listing fees, when to pay, and why product/retention must come first
*   Tools & automation John rates and why an analyst is the first hire when building a program
*   Tracking platforms, trust, and whether last-click attribution will evolve
*   This article highlights key takeaways from the interview. 👉 You can watch the full conversation in [the video](https://youtu.be/uyq7CU30CHQ?si=e2OBdPmZcdr9fyBL&t=12) below.

[![Image 2: John Wright Video](https://gamblingindustryjobs.com/wp-content/uploads/2025/09/John-Wright-CC-Video-Image-1024x576.png)](https://youtu.be/uyq7CU30CHQ?si=e2OBdPmZcdr9fyBL&t=12)

Industry Beginnings
-------------------

### From Engineering to Pro Gambler

John’s entry into the gambling industry was quite **accidental**, spurred by a high school friend who found success in professional gambling through **card counting** and **bonus hunting.** Initially skeptical, John was convinced by his friend’s financial gains and, as a student with debt, decided to explore it himself. He started with blackjack, learning strategies from resources like “**Wizard of Odds**,” and adapted to new games like video poker (specifically Jacks or Better) and even slots as operators changed bonus rules to deter bonus hunters. **His success stemmed from understanding the mathematics and modelling of data**, allowing him to consistently profit from bonuses.

#### Key Takeaways:

*   John’s entry into iGaming was accidental, inspired by a friend’s success in professional gambling.
*   He leveraged a **mathematical approach** to bonus hunting, evolving from blackjack to video poker and slots as game rules changed.
*   He became proficient in **online poker and sports betting**, showcasing an all-rounder’s versatility.

> Yeah, pure kind of accidental. So I went to school for engineering. And one of my high school friends also went to school for engineering at a different school. And he eventually started switching programs… he was starting to learn how to count cards like play blackjack and be a professional gambler.

### John’s Career Journey

As an affiliate, John experienced the challenges firsthand, including the difficulty of tracking sub-affiliate commissions and the lack of transparency from some affiliate programs, which he suspected of “detagging or shaving commissions”.

This frustration, coupled with his experiences on the operator side, observing affiliates failing to leverage their own data, became the genesis of StatsDrone. The platform was born out of a desire to provide affiliates with a “home base” to monitor earnings, alert them to closed brands or invalidated links, and ultimately prevent revenue leak by bringing data to life through visualisation and analytics.

#### Key Takeaways:

*   John experienced **challenges with sub-affiliate commissions and trustworthiness** of affiliate programs.
*   **StatsDrone was founded to address revenue leak** and improve data analysis for affiliates.
*   The platform aims to provide **actionable insights** beyond raw data, such as alerts for closed brands and invalid tracking links.

> Yeah, s

*[... truncated, 23,877 more characters]*

---

---

## 🎬 YouTube Videos

- **[Ganguly Relives Glory Days With His &quot;Favourite Coach&quot; John Wright | ICC Cricket World Cup](https://www.youtube.com/watch?v=6Z8xWXQWdwo)**
  - Channel: ICC
  - Date: 2019-06-13

- **[The Wonderful World of Foraging. An Interview with John Wright](https://www.youtube.com/watch?v=kP-xuFpbnwU)**
  - Channel: Wild Food in the UK Ltd
  - Date: 2024-03-21

- **[John Wright on what makes an ideal coach](https://www.youtube.com/watch?v=_LioZpggJCY)**
  - Channel: Vimal Kumar
  - Date: 2022-12-03

- **[Sachin Tendulkar on John Wright : Coaching Moments 🏏🔥 #Cricket #WorldCup](https://www.youtube.com/watch?v=JUSWTaiKeXs)**
  - Channel: Cricket Wisdom
  - Date: 2025-02-06

- **[Nardwuar vs. John Wright (Nomeansno) &amp; Steve Turner (Mudhoney)](https://www.youtube.com/watch?v=5aXECDYwu4g)**
  - Channel: NardwuarServiette
  - Date: 2024-02-19

- **[The Real Estate Carry Trade Is A “Death Star”: With John Wright](https://www.youtube.com/watch?v=7Mdc0SuDxO4)**
  - Channel: Walk The World
  - Date: 2025-10-12

- **[Episode 18 - H.I.G.H. (How I Got Here) Podcast - John Wright](https://www.youtube.com/watch?v=tVj1oA09nW4)**
  - Channel: PlayerProps ai - Learn How To Bet & Stop Losing
  - Date: 2025-11-11

- **[Max &amp; John C. Wright: A History of Anti-Trinitarianism and Other Heresies](https://www.youtube.com/watch?v=ZQlmXCRZK5Y)**
  - Channel: Red Pill Religion
  - Date: 2019-05-23

- **[Devil John Wright of the Cumberlands](https://www.youtube.com/watch?v=zJnitNfWkxE)**
  - Channel: Stories of Appalachia
  - Date: 2024-04-12

- **[Foraging Podcast | John Wright | River Cottage Foraging Expert | Go Gather Wild](https://www.youtube.com/watch?v=aHixZzNmAWM)**
  - Channel: Go Gather Wild
  - Date: 2021-03-21

---

## 🔎 Press & Mentions

- **[Revenue Optimization with StatsDrone - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/revenue-optimization-with-statsdrone/id1700893670)**
  - Source: podcasts.apple.com
  - *Revenue Optimization with StatsDrone. John Wright. 5.0 (2); MARKETING; UPDATED WEEKLY. Welcome to Revenue Optimization with StatsDrone. A business pod...*

- **[John Wright on iGaming, Affiliate Marketing & SEO | Fortis Media](https://www.fortismedia.com/en/articles/john-wright-igaming-affiliate-marketing-seo-trends/)**
  - Source: fortismedia.com
  - *We recently had the pleasure of speaking with John Wright, the Co-Founder of StatsDrone ... John Wright: The idea behind the podcast started with our ...*

- **[John Wright - iGaming Club](https://igaming.club/member/john-wright/)**
  - Source: igaming.club
  - *... podcast. He has a degree in mechanical ... John Wright. John Wright. Position: CEO & Co-founder; Company Name: StatsDrone; Website: https://statsd...*

- **[Affiliate Q&A: John Wright, Co-founder at StatsDrone - Income Access](https://www.incomeaccess.com/contenthub/affiliate-qa-john-wright-co-founder-at-statsdrone/)**
  - Source: incomeaccess.com
  - *Aug 15, 2025 ... We sat down with John Wright, Co-founder at StatsDrone, to explore ... I am frequently asked this question by guests of the Affiliate...*

- **[John Wright: From Affiliate to Operator to Leading StatsDrone](https://gamblingindustryjobs.com/career-conversations/john-wright-from-affiliate-to-operator-to-leading-statsdrone/)**
  - Source: gamblingindustryjobs.com
  - *John Wright: From Affiliate to Operator to Leading StatsDrone. Career Conversations Interview with John Wright. In this edition of Career Conversation...*

- **[Revolutionizing Affiliate Analytics with StatsDrone Co-Founder John ...](https://stepbystepbusiness.com/affiliate-analytics-statsdrone-john-wright-interview/)**
  - Source: stepbystepbusiness.com
  - *Dec 22, 2023 ... Revolutionizing Affiliate Analytics with StatsDrone Co-Founder John Wright ... This interview delves into the challenges, user feedba...*

- **[iGaming Business Broker with Gabriel Sita](https://statsdrone.com/blog/igaming-business-broker-gabriel-sita/)**
  - Source: statsdrone.com
  - *iGaming Business Broker with Gabriel Sita. John Wright. By John Wright. , February 22, 2023. Welcome to our affiliate interview ... Copyright StatsDro...*

- **[Affiliate Conferences & Events 2025](https://statsdrone.com/events/)**
  - Source: statsdrone.com
  - *November, 2026 ... To learn what is happening for events you can follow the StatsDrone LinkedIn page. John Wright. By John Wright. , April 10, 2022....*

- **[Meet the team at StatsDrone - about us](https://statsdrone.com/team/)**
  - Source: statsdrone.com
  - *StatsDrone was founded by John Wright & Darrell Helyar that are based upon their collective experiences in iGaming. John was previously an affiliate m...*

- **[Voonix vs StatsDrone in 2025 - Features, Prices and Differences](https://statsdrone.com/blog/voonix-vs-statsdrone/)**
  - Source: statsdrone.com
  - *Mar 7, 2024 ... app vs StatsDrone article. What does StatsDrone have that Voonix ... The co-founders of StatsDrone are John Wright and Darrell Helyar ...*

---

*Generated by Founder Scraper*
