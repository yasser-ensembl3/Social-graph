# Yannick Aussedat

## Position actuelle

**Titre** : CEO - Chef de projet digital
**Entreprise** : Repère de l'Ouest
**Durée dans le rôle** : 4 years 11 months in role
**Durée dans l'entreprise** : 4 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Agence de création à 270° : communication numérique & graphique. 
Repère de l’Ouest vous accompagne dans la réalisation de vos projets de communication numérique et graphique.
Une expertise complète à votre service : plans en drone, création de vidéos, identité visuelle, site web, référencement & analytique.

Yannick Aussedat, Chef de projet digital & fondateur de Repère de l’Ouest, originaire de Trébeurden. Yannick partage son amour de la nature à travers ses réalisations audiovisuelles. Son expertise et sa créativité mettront en lumière votre travail. Télépilote de drone agréé, Yannick réalisera vos vidéos institutionnelles, promotionnelles, touristiques ou pédagogiques, de la réflexion à la production, sur la terre comme dans les airs. Grâce à son expertise du digital, il vous propose une offre sur mesure en collaboration avec une designer graphique pour répondre à vos besoins en tant que professionnel ou particulier à la recherche d’une communication complète sur tout support : vidéo, site web et identité visuelle.

## Résumé

Fort de mes expériences passées en chaîne de télévision et en agence de publicité notamment, j'ai acquis une solide expertise dans le domaine de la création multimédia. La réalisation de vidéos et d’animations graphiques promotionnelles est aujourd’hui mon cœur de métier. Par mon profil polyvalent, je pourrai suivre votre projet vidéo de la conception à la livraison finale de votre produit.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAaYjvEBwy9ZKUES0tOeEipIIWPUTM0OvNE/


---

# Yannick Aussedat

## Position actuelle

**Entreprise** : Repère de l'Ouest

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Yannick Aussedat
*Repère de l'Ouest*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [Épisode #79 - Yannick](https://podcasts.apple.com/ca/podcast/%C3%A9pisode-79-yannick/id1701705862?i=1000697161442)
*2025-03-02*
- Category: podcast

### [Repousser les limites - Le Podcast](https://www.youtube.com/@Repousserleslimiteslepodcast)
*2025-05-14*
- Category: podcast

### [You are so French! Success stories à la française](https://podcasts.apple.com/rw/podcast/you-are-so-french-success-stories-%C3%A0-la-fran%C3%A7aise/id1591332268)
*2025-03-19*
- Category: podcast

### [Episode 49: Yannick Willemin, Catalysium](https://www.compositesworld.com/podcast/episode/episode-49-yannick-willemin-catalysium)
*2025-02-26*
- Category: podcast

### [[EXTRAIT] Yannick Alléno - Comment être rentable avec des restaurants étoilés](https://podmust.com/ep/?podcast=generation-do-it-yourself&epis=W0VYVFJBSVRdIFlhbm5pY2sgQWxsw6lubyAtIENvbW1lbnQgw6p0cmUgcmVudGFibGUgYXZlYyBkZXMgcmVzdGF1cmFudHMgw6l0b2lsw6lz)
*2025-06-21*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Avec Repère de l'Ouest, ce photographe immortalise le littoral de ...](https://www.ouest-france.fr/bretagne/trebeurden-22560/avec-repere-de-louest-ce-photographe-immortalise-le-littoral-de-perros-guirec-vu-du-ciel-1ff8fe0a-501a-11f0-b256-5374093950c1)**
  - Source: ouest-france.fr
  - *Jun 23, 2025 ... Yannick Aussedat, de Repère de l'Ouest, à Trébeurden (Côtes-d'Armor) ... Podcast À portée de clic · Enseignes locales · Bons Plans Cd...*

- **[Odile Guérin et Yannick Aussedat fêtent la nature dimanche 25 mai ...](https://www.ouest-france.fr/bretagne/trebeurden-22560/odile-guerin-et-yannick-aussedat-fetent-la-nature-dimanche-25-mai-a-trebeurden-d98421e0-2e7f-11f0-85eb-9aea224367a6)**
  - Source: ouest-france.fr
  - *May 16, 2025 ... Elle anime régulièrement des sorties, conférences et ateliers. Yannick Aussedat, photographe, est le fondateur de « Repère de l'Ouest...*

- **[Treb'en l'air : une deuxième édition pour le conservatoire du littoral](https://www.ouest-france.fr/bretagne/trebeurden-22560/treben-lair-une-deuxieme-edition-pour-le-conservatoire-du-littoral-6c9fa212-4846-11f0-af40-cc57d5421e95)**
  - Source: ouest-france.fr
  - *Jun 13, 2025 ... ... Yannick Aussédat au sein de Repère de l'Ouest. Nous sommes arrivés dans le top 10, sur plus de 150 dossiers déposés, ce qui nous ...*

- **[Sur l'île Milliau, à Trébeurden, des photos sur bâches de Milliau et ...](https://www.ouest-france.fr/bretagne/trebeurden-22560/sur-lile-milliau-a-trebeurden-des-photos-sur-baches-de-milliau-et-molene-vues-du-ciel-b681cac4-4a5c-11ef-bfeb-1153a1dd3579)**
  - Source: ouest-france.fr
  - *Jul 28, 2024 ... Les œuvres de Yannick Aussedat sont en passe de devenir une référence en matière de photographie d'espaces naturels du Trégor ......*

- **[Création et production de vidéos & Motion design | Repère de l'Ouest](https://reperedelouest.com/production-video-motion-design/)**
  - Source: reperedelouest.com
  - *Repère de l'Ouest crée des vidéos optimisées pour dynamiser vos messages ... Yannick Aussedat. More options. More options. Like. Add to Watch Later. S...*

- **[Bienvenue sur le site internet de la Ville de Perros-Guirec ! |](https://www.perros-guirec.com/ville/)**
  - Source: perros-guirec.com
  - *... Yannick Aussedat, Repère de l'Ouest. ENVIRONNEMENTSensibilisation au littoral5 capsules vidéo. Sensibiliser la population à la protection de l'env...*

- **[Exposition Treb' en l'air : labellisée 50 ans du Littoral en commun](https://reperedelouest.com/50%E1%B5%89-anniversaire-du-conservatoire-du-littoral-trebeurden-et-ses-sites-naturels-vus-par-drone/)**
  - Source: reperedelouest.com
  - *Grâce aux clichés en drone de Yannick Aussedat (Repère de l'Ouest), les ... Merci à Ouest France et Jean-Lou pour ce bel article : https://www.ouest ....*

- **[Conservatoire du littoral à Trébeurden : deux expositions en plein ...](https://www.letelegramme.fr/cotes-d-armor/trebeurden-22560/conservatoire-du-littoral-a-trebeurden-deux-expositions-en-plein-air-6834854.php)**
  - Source: letelegramme.fr
  - *Jun 12, 2025 ... Les expositions, signées Yannick Aussedat, photographe de l'agence Repère de l'Ouest, allient photographies aériennes et paysages sai...*

- **[Ile Milliau (Trébeurden) | Office de Tourisme de la Côte de Granit Rose](https://www.bretagne-cotedegranitrose.com/mon-sejour/loisirs-et-decouvertes-sur-la-cote-de-granit-rose/patrimoine-et-sites-naturels/ile-milliau-trebeurden-fr-2713611/)**
  - Source: bretagne-cotedegranitrose.com
  - *Blog · Billetterie · Boutique. Menu. Office de Tourisme Bretagne Côte de Granit ... Yannick Aussedat, Repère de l'Ouest. Ile Milliau - Trébeurden ©Thi...*

---

*Generated by Founder Scraper*
