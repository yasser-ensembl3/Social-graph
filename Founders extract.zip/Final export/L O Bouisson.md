# Léo Bouisson

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399518484998619136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEAoWMw8r1ZEw/feedshare-shrink_800/B4EZrBVx_THEAg-/0/1764180377412?e=1766620800&v=beta&t=_QJhe4bJY6kkKtY8EWrqCCVW-a0GK9Szb92cEmW9Yb4 | Je viens de commencer un MBA en Gestion d'Organisation Sportive! 🏀 

💥 Après Mark Weightman, l’Alliance de Montréal accueille maintenant Nicolas Lesage au sein d’un Front Office de superstars. Leur expérience combinée représente une avancée majeure pour l’organisation, et une occasion exceptionnelle d’apprendre aux côtés de deux leaders chevronnés.
 2026 et les années suivantes s’annoncent exceptionnelles pour l’Alliance 🚀 | 64 | 5 | 0 | 1w | Post | Léo Bouisson | https://www.linkedin.com/in/leo-bouisson | https://linkedin.com/in/leo-bouisson | 2025-12-08T04:54:01.704Z |  | 2025-11-26T18:44:43.229Z | https://www.linkedin.com/feed/update/urn:li:activity:7399508825889976320/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391840603124215808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFu5_7SW8L1vA/feedshare-shrink_800/B4EZpQ0xLGHcAk-/0/1762292603754?e=1766620800&v=beta&t=eeVA5UCF6XnSdvl3VT0RtG5O9ULwYY5vbOOvgql8_dY | L'Alliance de Montréal recrute sa prochaine cohorte de stagiaires superstars! 💫 
Une occasion en or de rejoindre une organisation sportive en croissance, et d'avoir un réel impact au quotidien! 😎 | 20 | 0 | 1 | 1mo | Post | Léo Bouisson | https://www.linkedin.com/in/leo-bouisson | https://linkedin.com/in/leo-bouisson | 2025-12-08T04:54:01.705Z |  | 2025-11-05T14:15:33.542Z | https://www.linkedin.com/feed/update/urn:li:activity:7391590920279785473/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7385001758772711424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFP1x00iSdgGA/feedshare-shrink_800/B4EZnyny1hIwAg-/0/1760712143047?e=1766620800&v=beta&t=FkDS9ykrFBh_tVDzAnNEGtcYKFCWTGlq2564VUpOxbs | 🏀  L'Alliance de Montréal recrute pour 3 postes cruciaux 🚀 
1- Chef des Opérations: http://bit.ly/47e6GSK
2- Coordonateur Marketing numérique et publicité: https://bit.ly/4onktx8
3- Gestionnaire de compte: https://bit.ly/4nZhs6H

Venez nous aider à bâtir une organisation sportive de premier niveau! | 49 | 0 | 5 | 1mo | Post | Léo Bouisson | https://www.linkedin.com/in/leo-bouisson | https://linkedin.com/in/leo-bouisson | 2025-12-08T04:54:01.706Z |  | 2025-10-17T17:20:25.989Z | https://www.linkedin.com/feed/update/urn:li:activity:7384961988776337408/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7354155170450055168 | Text |  |  | 3 + 1 = ?

Si tu as trouvé la réponse, alors tu es fait(e) pour le job! Applique aujourd'hui!

(Sans blague, c'est vraiment une bonne opportunité pour un(e) comptable de faire une marque dans une entreprise en forte croissance!) | 30 | 3 | 1 | 4mo | Post | Léo Bouisson | https://www.linkedin.com/in/leo-bouisson | https://linkedin.com/in/leo-bouisson | 2025-12-08T04:54:01.707Z |  | 2025-07-24T14:27:06.231Z |  | https://www.linkedin.com/jobs/view/4275376175/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7340404227761926144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHNRhvrQo0rCQ/feedshare-shrink_800/B4EZd5av2LH0Ag-/0/1750088745070?e=1766620800&v=beta&t=QuNZIn9kaRUju9VvLo6FoH3zIGs7iJJsTdj4OoZF90w | J'aime tellement le basket que je suis devenu co-proprio de l'Alliance de Montréal il y a quelques mois 😲 

👏 Ce serait très cool de vous voir mercredi 🏀 (bière offerte si vous venez grâce à ce post 🍺)
📅  Mercredi 18 Juin, 7:30pm📍 Auditorium de Verdun

Prenez vos billets ici: https://bit.ly/443ogam | 53 | 6 | 0 | 5mo | Post | Léo Bouisson | https://www.linkedin.com/in/leo-bouisson | https://linkedin.com/in/leo-bouisson | 2025-12-08T04:54:01.707Z |  | 2025-06-16T15:45:46.014Z |  |  | 

---

