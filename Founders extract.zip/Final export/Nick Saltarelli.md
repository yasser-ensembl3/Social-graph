# Nick Saltarelli

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Mid-Day Squares
**Durée dans le rôle** : 8 years 1 month in role
**Durée dans l'entreprise** : 8 years 1 month in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Food and Beverage Manufacturing

## Description du rôle

We launched: www.MidDaySquares.com

Let another ride begin.

## Résumé

Experienced early stage Entrepreneur with a success record of scaling companies past 8-Figure revenues. I love to help and add value if and only if I feel I can actually add value. Currently helping build www.MidDaySquares.com or on my twitter @nicksalto :)

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA3cGgsBJPKX_YQBBYWVESahQ1I0iEvQLQs/
**Connexions partagées** : 129


---

# Nick Saltarelli

## Position actuelle

**Entreprise** : Mid-Day Squares

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nick Saltarelli

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396956793639440385 | Text |  |  | all i want 

is to tell you all our NEW INNOVATION.

My wife will kill me. So i cant.

but know i want to | 223 | 81 | 0 | 2w | Post | Nick Saltarelli | https://www.linkedin.com/in/nick-saltarelli-063a5965 | https://linkedin.com/in/nick-saltarelli-063a5965 | 2025-12-08T06:03:37.863Z |  | 2025-11-19T17:05:28.415Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379574345653710849 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEw99SnNHTvRw/feedshare-shrink_800/B4EZmmDwz9HIAg-/0/1759427628851?e=1766620800&v=beta&t=q1XS-V88w-4i_slmbrrC0qTa2XMvvzeeBbYmTXhUrp8 | I want to say thank you to someone.

Alastair Dorward let me into his home and allowed me to sleep there without even knowing me when we had just started Mid-Day Squares.

He gave me a 12 hour crash course in CPG using wtvr he had at his disposal.

Im not sure he understands how impactful it was because it was quick.

But I absorb information fast and all I could say is there was a immediate action taken from that trip.

These are the people shaping peoples futures and they ask for nothing in return.

This is what is beautiful about humanity and makes me happy.

Thank you Alastair. | 149 | 23 | 1 | 2mo | Post | Nick Saltarelli | https://www.linkedin.com/in/nick-saltarelli-063a5965 | https://linkedin.com/in/nick-saltarelli-063a5965 | 2025-12-08T06:03:37.863Z |  | 2025-10-02T17:53:49.865Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7342929205820596226 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a8b08a55-adf2-4bd0-ad32-7573b2d2069a |  | Im doing an AMA with Mike Fata tomorrow.

Nothing is off the table. Come have fun. | 34 | 1 | 0 | 5mo | Post | Nick Saltarelli | https://www.linkedin.com/in/nick-saltarelli-063a5965 | https://linkedin.com/in/nick-saltarelli-063a5965 | 2025-12-08T06:03:37.864Z |  | 2025-06-23T14:59:07.695Z | https://www.linkedin.com/feed/update/urn:li:activity:7342538285723938816/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7310007933365342208 | Text |  |  | Need you help

Who are some of the most valuable people know who played  a massive role in scaling CPG Brands from $35 to $100 million

Tag them below. I want to meet them | 132 | 76 | 0 | 8mo | Post | Nick Saltarelli | https://www.linkedin.com/in/nick-saltarelli-063a5965 | https://linkedin.com/in/nick-saltarelli-063a5965 | 2025-12-08T06:03:37.864Z |  | 2025-03-24T18:41:44.694Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7301299359587987456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0djEjdiKawg/feedshare-shrink_800/B4EZVNtDmnH0Ag-/0/1740765417522?e=1766620800&v=beta&t=odUyqluwMjsGPts1GKN7T2ZA8Yeh1Od2epc8ucbIXoA | Health just took me to a halting stop.

No Expo West for me this year.

I caught e.coli poisoning while traveling to South America for Cocoa.

I'm sad that I won't see you all there.

Know that I'm getting better and I'd DIE for this company all again.

Long Live Mid-Day Squares | 576 | 215 | 0 | 9mo | Post | Nick Saltarelli | https://www.linkedin.com/in/nick-saltarelli-063a5965 | https://linkedin.com/in/nick-saltarelli-063a5965 | 2025-12-08T06:03:37.865Z |  | 2025-02-28T17:56:58.908Z |  |  | 

---



---

# Nick Saltarelli
*Mid-Day Squares*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 18 |

---

## 📚 Articles & Blog Posts

### [What Is a Marketing Plan and How To Write One ...](https://www.shopify.com/ca/blog/marketing-plan)
*2025-09-20*
- Category: blog

### [How he's leveraging content to build a chocolate brand // Nick Saltarelli, Co-founder of Mid-Day Squares](https://www.theconsumervc.com/p/how-hes-leveraging-content-to-build)
*2022-05-04*
- Category: article

### [Nick Saltarelli of Mid-Day Squares: 5 Things I Wish Someone Told Me Before I Became A Founder](https://medium.com/authority-magazine/nick-saltarelli-of-mid-day-squares-5-things-i-wish-someone-told-me-before-i-became-a-founder-f0ff3f44b71a)
*2021-03-31*
- Category: blog

### [🎧🍌 Building a $70 Million Chocolate Factory | Nick Saltarelli (Co-founder, Mid-Day Squares)](https://www.thespl.it/p/building-a-70-million-chocolate-factory)
*2023-07-27*
- Category: article

### [‎Invest Like the Best with Patrick O'Shaughnessy: Nick Saltarelli - One Foot in Front of the Other - [Founder’s Field Guide, EP. 54] on Apple Podcasts](https://podcasts.apple.com/us/podcast/invest-like-the-best-with-patrick-oshaughnessy/id1154105909?i=1000545902422)
*2021-12-23*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Female Disruptors: Lezlie Karls of Mid-Day Squares On The Three ...](https://medium.com/authority-magazine/female-disruptors-lezlie-karls-of-mid-day-squares-on-the-three-things-you-need-to-shake-up-your-6dadecae11cc)**
  - Source: medium.com
  - *Mar 31, 2021 ... When my partner in life and business, Nick Saltarelli, and I were out ... We have a podcast here at Mid-Day Squares called Mid-Day Sq...*

- **[The Chocolate Company That Sold One Million Bars In 20 Months ...](https://www.shopify.com/blog/mid-day-squares-production-fundraising)**
  - Source: shopify.com
  - *Dec 6, 2022 ... Mid-Day Squares co-founder Nick Saltarelli.Mid-Day Squares. Growing ... Nick, who hosts the Mid-Day Squares podcast, advises people no...*

- **[Why Mid-Day Squares Said 'No' to an Acquisition Bid From ...](https://www.businessinsider.com/why-this-chocolate-startup-said-no-to-a-hershey-acquisition-2021-5)**
  - Source: businessinsider.com
  - *Jul 7, 2021 ... Mid-Day Squares founders Jake Karls, Lezlie Karls, and Nick Saltarelli. ... They've also turned their business into a reality show and...*

- **[Mid-Day Squares: The Modern-Day Chocolate Company ...](https://xtalks.com/mid-day-squares-the-modern-day-chocolate-company-dominating-the-refrigerated-snack-space-2813/)**
  - Source: xtalks.com
  - *Aug 11, 2021 ... Mid-Day Squares Nick Saltarelli. percent year-over-year, and that ... The Mid-Day Squares team discusses several topics in the podcas...*

- **[Food for Thought Podcast (Season 2) - YouTube](https://www.youtube.com/playlist?list=PLHEIThqo1CCWhgr6el0qeEwWSOq1BGIdJ)**
  - Source: youtube.com
  - *Food For Thought | An EnWave Podcast Series 2021. EnWave Corporation · 1:23 · Sneak Peek: Functional Chocolate Manufacturing (Nick Saltarelli - Mid-Da...*

- **[Building a $70 Million Chocolate Factory | Nick Saltarelli (Co ...](https://www.thespl.it/p/building-a-70-million-chocolate-factory)**
  - Source: thespl.it
  - *Jul 27, 2023 ... Building a $70 Million Chocolate Factory | Nick Saltarelli (Co-founder, Mid-Day Squares) ... Weekly podcast episodes with transcripts...*

- **[Mid-Day Squares Founders Represent Gen Z's Take On ...](https://www.forbes.com/sites/karlmoore/2023/03/26/mid-day-squares-founders-represent-gen-zs-take-on-entrepreneurship/)**
  - Source: forbes.com
  - *Mar 26, 2023 ... ... Nick Saltarelli, Lezlie Karls, Jake Karls of Mid-Day Squares. Courtesy of Mid-Day Squares ... podcast as a mix of Keeping Up with...*

- **[Nick Saltarelli of Mid-Day Squares: 5 Things I Wish Someone Told ...](https://medium.com/authority-magazine/nick-saltarelli-of-mid-day-squares-5-things-i-wish-someone-told-me-before-i-became-a-founder-f0ff3f44b71a)**
  - Source: medium.com
  - *Mar 31, 2021 ... We use interviews to draw out stories that are both empowering and actionable. Follow publication. Nick Saltarelli of Mid-Day Squares...*

- **[Making The Band: How Mid-Day Squares Became One Of The ...](https://www.tasteradio.com/episodes/2021/making-the-band-how-mid-day-squares-became-one-of-the-hottest-brands-in-cpg/)**
  - Source: tasteradio.com
  - *Jun 1, 2021 ... 0:40: Interview: Lezlie Karls Saltarelli, Nick Saltarelli and Jake Karls, Co-Founders, Mid-Day Squares — The co-founders sat down with...*

- **[The Chocolate Company That Sold One Million Bars In 20 Months ...](https://www.shopify.com/ca/blog/mid-day-squares-production-fundraising)**
  - Source: shopify.com
  - *Dec 6, 2022 ... Mid-Day Squares co-founder Nick Saltarelli.Mid-Day Squares. Growing the business from their own kitchen to a full-sized production fac...*

---

*Generated by Founder Scraper*
