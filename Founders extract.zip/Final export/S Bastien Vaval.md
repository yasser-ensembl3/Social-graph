# Sébastien Vaval

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402901549762650112 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFQRa1OPO3FrQ/feedshare-shrink_800/B4EZrxjrfpKgAk-/0/1764989265127?e=1766620800&v=beta&t=OnUPADKx488_G6vzwrpoWVOhcRHr-h3ipGauosLXViY | What an absolutely incredible night at the 8th annual Startup Community Awards 2025! 🎉

Huge congratulations to ilias of elantech and the entire amazing team + volunteers who poured their hearts into making this gala so special. You didn’t just organize an event, you created a warm and, deeply human celebration of the people who hold our tech startup ecosystem together. Truly one of the most authentic and meaningful nights of the year.

And massive congrats to all the well,deserved winners:

- Christian Levan Levan (Investor at Panache Ventures | Building Community with 555) 
- Claude G. Théoret (Senior AI Advisor Innovobot , Founder Nexalogy, Québec Tech Ambassador) 
- Constance Jaluzot Jaluzot (Marketing Advisor Innovobot ) 
- Gabriel Sundaram (Co-founder Attain, Montreal startup community builder) 
- Ruben Lopez Lopez (Nanofacile) 

Seeing 300+ nominations, 10,000+ votes, and 1,000+ stories of gratitude come together under one roof was pure magic. This year’s theme “Les Histoires Qui Comptent” couldn’t have been more spot-on, every award was a reminder of the quiet heroes who show up for each other day after day.

Thank you for this great event. Already counting down to next year. 🔥 | 16 | 0 | 0 | 2d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:08.146Z |  | 2025-12-06T02:47:48.723Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402498417245126658 | Video (LinkedIn Source) | blob:https://www.linkedin.com/768d4471-b48f-4a0b-ab93-aae426b98e72 | https://media.licdn.com/dms/image/v2/D4E05AQG1ix3AtrtvKQ/videocover-low/B4EZrr1DEzKcBU-/0/1764893145645?e=1765774800&v=beta&t=upCuHalWT6pR5Vp0gkigS-mvLF288yShtLqwBnUO5Ow | So happy to be here tonight with Marie 
Celebrating the builders, dreamers, and changemakers who make Montreal’s startup scene absolutely electric! 🌟

Startup Community Awards 2025 from elantech what an incredible night of inspiration, bold ideas, and well-deserved recognition for the founders pushing Quebec innovation forward.

Grateful to be part of this vibrant ecosystem. Here’s to the trailblazers redefining what’s possible! 🚀 | 23 | 0 | 0 | 3d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:08.147Z |  | 2025-12-05T00:05:54.441Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402332224013885440 | Video (LinkedIn Source) | blob:https://www.linkedin.com/531b707e-1deb-41a7-b3a0-68c29abb5143 | https://media.licdn.com/dms/image/v2/D4E10AQGdYGIufUV9ug/ads-video-thumbnail_720_1280/B4EZrpdvfyKkAg-/0/1764853479843?e=1765774800&v=beta&t=rvAvtu-NVIUZyB1PZq5AtSBoE4z0iBmWv2riDziE1Uo | You use AI every day probably without even realizing it.

From search results to maps, Gmail to photos, it’s quietly turning chaos into clarity and speed.

But AI isn’t magic on its own it only works when guided with purpose.

We help businesses harness AI the right way not just to automate, but to focus, align, and move smarter.

If you need help putting AI to work with intention, reach out. | 5 | 0 | 0 | 3d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:08.148Z |  | 2025-12-04T13:05:30.887Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402181704477614080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHeGnAM5n2VtQ/feedshare-shrink_800/B4EZrnU_abHcAg-/0/1764817638324?e=1766620800&v=beta&t=zx4bAoOAjis-bZkZP36Vr3s97nVkbDad6Pw6acLqenA | Just wrapped up an incredible day with Liane at the Miami AI Summit, huge THANKS to Burhan and Melissa for putting together such an awesome event!🔥 

World-class talks, hands-on workshops, 500+ attendees, and that perfect Miami energy 🌴

Mind-blowing speaker lineup, massive shoutout to these absolute legends who took the stage:

- Cathie Wood – Founder, CEO, ARK Funds 
- Clem Delangue 🤗 – Co-founder & CEO, Hugging Face 
- Francis X. Suarez – Mayor, City of Miami 
- Manny Medina – Founder & Chairman, Medina Ventures 
- Daniella Levine Cava – Mayor, Miami-Dade County 
- Rohit Patel – Director, Superintelligence Labs Meta 
- Leon Kuperman – CTO & Co-founder, Cast AI
- Sherrell Dorsey – TED Conferences Host 
- David White – Field CTO, Google 
- Ashraf Hebela, CFA– Co-Head of Tech Banking & Head of Startup Banking, J.P. Morgan 

Got to meet and connect with so many brilliant AI minds right here in Florida, the vibes were unmatched. Also thank you for Coaching en Direct for this Sponsorship! Already counting down to the next one eMerge Americas ! 🚀 | 31 | 4 | 1 | 4d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:08.149Z |  | 2025-12-04T03:07:24.233Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401702786524147712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGJzXjFbW9-Sw/feedshare-shrink_800/B4EZrghaUfHEAg-/0/1764703455427?e=1766620800&v=beta&t=tVeNP_1OqJ86sPBcMwWees2uU5qJHKN_6BJILK6SynA | Even when I’m outside the office, I’m always finding ways to connect, exchange, and build. 

Today was no exception, spent my lunch with an incredible group of CEOs and founders at Ax-C for a peer-to-peer roundtable: real talk, zero pitch, just entrepreneurs helping entrepreneurs.

Huge thanks to our amazing moderators Reine Ateby-Djawrey (OT Space) and Yassine Benarej (SimpleGov.ai), and to Caroline Quijoux from Québec Tech for making this happen.

Grateful to have shared the table with this powerhouse lineup:

🔹 Reine Ateby-Djawrey – OT Space 
🔹 lamia guellif – Hera Care Solutions 
🔹 Jean-Philippe Berger – Smartbiotic 
🔹 Roxanne Lessard – Panorama 
🔹 Alexandre Clarizio – Kaster 
🔹 Mehdi Jafari – Cloud Sibyl 
🔹 Frédérik Gauthier – Reelcruit 
🔹 Yassine Benarej – SimpleGov.ai 
🔹 Soufiane Ajana, PhD, FAAO – Retinov 
🔹 Edward Ko – Mely.ai 
🔹 Amirreza Ataei – Chemia Discovery 
🔹 Anders Rojewski – Neatro 
🔹 Nicholas Routhier – Cubic Space 

Some of the sharpest minds in healthtech, AI, HRtech, govtech, and deeptech, all in one room, openly sharing challenges, wins, and ways we can actually help each other grow.

These are the moments that remind me why I love this ecosystem. More of this in 2026 ✊ | 20 | 0 | 1 | 5d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.478Z |  | 2025-12-02T19:24:21.295Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7401607011030704128 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3a5c7984-4dca-4609-bd5e-2b3c503e51c3 | https://media.licdn.com/dms/image/v2/D4E10AQHQEsoicxuEuQ/videocover-high/B4EZrfKO4_HgA8-/0/1764680601058?e=1765774800&v=beta&t=fCHDsTA96F7kw4zrMXKMVDm9PIaxmuYNMXiX2udVKxA | Ever wonder how Spotify always nails your mood?

It’s not random it’s AI picking up on the tiny patterns you don’t even notice.

Your mornings, your late-night scrolls, your workout pace… it all shapes the soundtrack it builds around you.

It’s more than recommendations it’s mood-matching at scale.
 That’s what real personalization feels like.

We help brands truly understand their audience reading behaviour, spotting patterns, and responding naturally.

If you want help building AI that really listens, get in touch. | 4 | 0 | 0 | 5d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.479Z |  | 2025-12-02T13:03:46.638Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7401417559545106432 | Video (LinkedIn Source) | blob:https://www.linkedin.com/23593275-963e-481a-af49-d15c2ca0efe4 | https://media.licdn.com/dms/image/v2/D4E05AQHSisWnsqPCyg/videocover-high/B4EZrceAqCJ0BU-/0/1764635448500?e=1765774800&v=beta&t=cjkiyfZJMgL0PAN7kIQ9Ztv1A4VNI8EzoqqprreeD4M | 🚀 Excited to be in Boca Raton today at the Quest office with my amazing partner Liane Sangollo PCC, CHRP ! 

This Wednesday, December 3rd, we’re heading to Miami for the exclusive AI Summit! 

Join us for a powerhouse day with over 30 world-class experts, including: 
🔥 Rohit Patel (Meta ) 
🔥 Clem Delangue 🤗 (Hugging Face) 
🔥 Cathie Wood (ARK Funds) 
…and many more visionary leaders shaping the future of AI. 

Super grateful to Liane, business powerhouse, and huge thanks to our partner sponsorship Coaching en Direct for making this happen! 

Who’s coming to Miami? Drop a 🔥 if you’ll be there, let’s connect! | 1 | 0 | 0 | 6d | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.479Z |  | 2025-12-02T00:30:57.884Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7400731773573156864 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e7f8b813-be4a-48e4-ba44-dc0c2382bff3 | https://media.licdn.com/dms/image/v2/D4E05AQG9Vy7FQ5haZQ/videocover-high/B4EZrSuSSmIIBU-/0/1764471942767?e=1765774800&v=beta&t=DNCpmDI_yUfXx0LNhqe2vs7MKeyGIfFghJR5L-alb-E | The song “Walk My Walk” just hit #1 on Billboard digital sales… and it’s 100% AI-made using Blanco Brown’s voice and signature style.

Honestly, the tech is mind-blowing right now.

It’s an awesome proof that AI can be an incredible creative tool, but it also raises the big question: how do we make sure artists are fairly paid and actually consent when their voice is the instrument?

Super excited for the future of music, as long as the humans behind the sound comes from stay protected and respected.

What do you think: total game-changer or do we need some guardrails? 

Check out this video on “Walk My Walk” → https://lnkd.in/e96-e8u9 | 3 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.480Z |  | 2025-11-30T03:05:53.767Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400329436837072896 | Video (LinkedIn Source) | blob:https://www.linkedin.com/728dc571-5275-45f2-909f-48d80a8b799f | https://media.licdn.com/dms/image/v2/D4E10AQHDvJmaDfn2zA/ads-video-thumbnail_720_1280/B4EZrKjyrWIoAk-/0/1764334971980?e=1765774800&v=beta&t=esEBrtDxHX4P7s-SfnCCKb4Bni021n612sqSfkIkyMQ | Gabrielle at IVADO nails it: one message to her → instant access to top PhDs, co-supervised theses, and students who’ll join you before anyone else sees their CV.

In AI, if you’re not plugged into a university ecosystem, you’re fighting with one hand tied.

Reach out to her (or your local equivalent). It’s the highest-ROI move most founders never make.

Who’s your go-to university connector? Tag them 👇 | 0 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.481Z |  | 2025-11-29T00:27:09.214Z | https://www.linkedin.com/feed/update/urn:li:activity:7400157483102654464/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7400305075841282048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG9CxA5fJFyhg/feedshare-shrink_800/B4EZrMqPzOGYAk-/0/1764370218948?e=1766620800&v=beta&t=L57IbAc9QAfU8SMDViCE_oQlnU-2_h221Q402QHYjak | This morning at PME MTL felt like the most beautiful full-circle moment.

Exactly one year ago, I was behind a booth, pitching OUTSOURCE BREEZE. 

Today, I got to walk around, listen, and watch other passionate entrepreneurs light up the room while presenting their innovations. The energy was absolutely electric, thank you for that incredible experience!

A massive thank you to the amazing team who made it all happen from PME MTL: 
🙌 Véronique Perreault – Directrice Commercialisation et Innovation 
🙌 France Sylvain – Directrice Développement industriel 
🙌 Jean-François Fyfe – Directeur Gestion et Financement 

You are the heartbeat of Mtl to ecosystem.

And huge congratulations to the entrepreneurs who showcased this morning, you were inspiring: 
🔥 Jani Beauchamp – Propriétaire Omnichem , DATACHEM LIMITED 
🔥 Claude Beaulieu – Président chez Sycodal Électrotechnique 
🔥 Marc-Evans Jeannot – Créateur de scènes mobiles électriques chez VRIX CANADA 

The Montreal ecosystem is alive, strong, and growing. Proud to be part of it.

See you all next November 28 next year to do it even bigger? 👀 | 15 | 2 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.482Z |  | 2025-11-28T22:50:21.100Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7400157447212023808 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFNAcIUjgHESQ/image-shrink_800/B4EZrKjtIeGoAc-/0/1764334949371?e=1765774800&v=beta&t=HmmEFDtH7OCUdkfyTTaKumWCmKngGoXJOZs70M7A5FQ | To Innovate, You Need Space to Breathe

Most people think innovation comes from constant hustle. But I’ve learned my best ideas show up when I unplug.

My weekend ritual:
☕️ Slow morning coffee
🚶 Walk outdoors with my dog
👨‍👩‍👧‍👧 Family time activities 

This break isn’t downtime, it’s fuel.

In AI, creativity is just as important as computation.  Leaders need rest to see what others don’t.

What’s one habit that helps YOU reset? | 3 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.482Z |  | 2025-11-28T13:03:43.692Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7399907853844578305 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0HJfMEZhjtg/feedshare-shrink_800/B4EZrHA8aQGoAg-/0/1764275509627?e=1766620800&v=beta&t=CHhWWoX49kQsNfwcye_8sLJQN2ae2ozf8yNQNkyHo1g | Had a highly valuable day with two excellent events today.

I attended the Google Cloud for Startups workshop, presented by Stephan Bitton (Startup Lead, Google Cloud), Mathieu Gervais (Fueling Startup Growth) and Julien Coupez (Customer Engineer for Startups). Great overview of the program, eligibility criteria, and the support available, including up to $350K in Google Cloud credits for seed-stage companies, dedicated GTM assistance, and in-depth technical guidance.

In the afternoon, joined the second edition of Café Risqué with Véronique Missout, M.Sc.from Fonds de solidarité Fonds de solidarité FTQ . An open, no-pitch format that allowed for candid discussions on fundraising strategy, team management, and scaling challenges, exactly the kind of frank conversation founders need.

Grateful to Ax-C for organizing these high-impact sessions and bringing such strong expertise directly to the resident startups. | 20 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.483Z |  | 2025-11-27T20:31:55.996Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7399824889542766592 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c6ac3e51-5e63-487e-bb97-c076a4d68f32 | https://media.licdn.com/dms/image/v2/D4E10AQFyfE6q5sifqA/videocover-high/B4EZrF1TmOKMA0-/0/1764255684890?e=1765774800&v=beta&t=DDccuyOpqbvfW5UCPP36gMmDYXB5wVtgmToiF08I7KA | Why does Netflix always nail your next recommendation?

Because it isn’t guessing it’s learning you with every tap, scroll, and pause.

Most people watch what Netflix suggests, not what they search for.

That’s the magic of prediction done right: no pressure, no friction, just flow.

At AEA, we help brands build that same experience.

AI that understands behaviour, serves what people actually want, and keeps them coming back without effort.

Because winning today isn’t about giving more choices.

It’s about offering the right choice at the perfect moment. | 5 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.483Z |  | 2025-11-27T15:02:15.765Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7399447436215099393 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFPOk74O7SIxQ/image-shrink_800/B4EZrAWtjnKYAY-/0/1764163771578?e=1765774800&v=beta&t=pam25rBZe8C7VB0N_nfxhLQF2R7UOp9Uzaz0-aS0fE4 | Right, if Apple can boldly reshape its entire enterprise business, so can you, and AI + smart tech make it easier than ever. 🎯 

In a rare move, Apple just cut several enterprise sales roles, not because demand is slowing, but to run leaner and faster.

They’re streamlining account management, centralizing outreach, and sharpening focus on high-value deals with schools, governments, and large enterprises, all powered by tighter systems and, yes, more intelligent use of AI and automation behind the scenes.

Under Tim Cook’s leadership, this is classic Apple: ruthless efficiency while future-proofing the enterprise strategy.

The lesson? Sometimes the bravest move isn’t hiring more people, it’s restructuring with the help of AI and modern tech to do more with less.

What part of YOUR business could run leaner, sharper, and more profitable with smarter AI-driven systems? | 2 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.484Z |  | 2025-11-26T14:02:23.879Z | https://www.linkedin.com/feed/update/urn:li:activity:7399439209599750144/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7399236919668412416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHY_0tPAPsYZw/feedshare-shrink_800/B4EZq9etfgHgAg-/0/1764115550322?e=1766620800&v=beta&t=osLhlEvEnDLopWdCHLTyRqWnYa3D1aZC5PodMzfN4tg | Just wrapped up an incredible afternoon at the “À la rencontre des investisseurs” reverse-pitch event hosted by Ax-C and Espace CDPQ! 

Putting 20+ active VC funds in one room and letting local startups meet them face-to-face in this reverse-pitch format is absolutely brilliant. Huge thanks to the Ax-C team for organizing, hands-down one of the best connection events of the year.

Super grateful for the great conversations with:

🔹 Amy Laliberté, MBA Laliberté, MBA – Capital de risque, Investissement Québec 
🔹 Samuel Jobin-Morissette Jobin-Morissette – Investor Boreal Venture Corp 
🔹 Nadia Martel, Ad.E., C. Dir. Martel, Ad.E., C. Dir. – Co-Founder & Partner i4 Capital Fund 
🔹 Julien Letartre Letartre – Partner, Venture Capital Accelia Capital 
🔹 Karine Liang Marcoux, PMP, PMP – Conseillère principale Espace CDPQ 
🔹 Marc-Antoine Cantin CPA, ICD.D – Entrepreneur & Angel Investor 
🔹 Jordan Nyinabangi – VC Investor Graphite Ventures 

…and so many other sharp investors sharing their theses.

Bonus: met a colleague a deep-tech founder, Elizabeth Tremblay, Fondatrice of BETA Labs. Aligned with some on going projects, great energy, and already brainstorming future collabs. 🤝

If you’re building in tech and AI and missed this one, definitely get on the list for the next edition. Our ecosystem is on fire right now 🚀 | 28 | 2 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.485Z |  | 2025-11-26T00:05:52.823Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7399100947047686144 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fac7494f-6c2d-44cc-9fb2-a1ceaf7a71fe | https://media.licdn.com/dms/image/v2/D4E10AQFrY2OU5EZ6cw/videocover-high/B4EZq7iUL1HcA0-/0/1764082936734?e=1765774800&v=beta&t=vpjHW9FtVYOD3cf7fwX6f0MW5t_MdezO8vlsNFZScjM | Ever wonder how your iPhone knows what you need before you do?

Those perfect suggestions aren’t luck it’s Apple’s AI learning your rhythm and simplifying your day without making a fuss.

That’s the real power: personalization that feels natural, not noisy.

At AEA, we help brands build AI that works the same way smart, intuitive, and designed around people, not algorithms. | 8 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:10.485Z |  | 2025-11-25T15:05:34.424Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7398944722456838144 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8816a61c-bd99-4a20-b358-f627ddd9576c | https://media.licdn.com/dms/image/v2/D4E05AQGuiNn_nLCB9g/videocover-low/B4EZq5U_5THMBQ-/0/1764045882497?e=1765774800&v=beta&t=uLfl1YoFzWTfSf79m_DrcxYc1TIaqErOPscfkesgJxg | Noon Spark “Episode 12” drops THIS WEDNESDAY and I’m absolutely fired up!🔥

I’m beyond excited to co-host with the amazing Cynthia and interview two absolute legends in the AI & growth space: 
•Burhan Sebin – Chief AI Officer eMerge Americas | Founder Miami AI Hub 
•Joelle Irvine – Growth & AI Advisor | Growclass AI Coach 

We’re going deep on: 
• How AI is fundamentally reshaping entrepreneurship in 2025 
• Real growth frameworks that actually move the needle 
• Leadership in a tech-driven world 
• What’s coming next for AI in Miami… including the massive AI Summit on Dec 3rd and eMerge Americas 2026 happening in April (both in Miami 🔥)

📅 Wednesday, November 26, 2025 
⏰ 12:00 PM EST (Noon sharp!) 
🎥 Save your spot & join live: 
https://lnkd.in/ec2NQqVG

Founders, builders, creators, AI enthusiasts, this is THE conversation to catch before Miami turns into the global AI capital in the coming weeks.

Two days left. Let’s gooo 🚀 | 16 | 0 | 3 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.569Z |  | 2025-11-25T04:44:47.579Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7398923905974976512 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQF6u939_cgnIQ/image-shrink_800/B4EZq1vrJ8J0Ag-/0/1763985765691?e=1765774800&v=beta&t=V6c4ih7y1amv9T0m7vcyLNE3ebQqhfuqk-hUesULXFM | The gap between who you are and who you could be is filled with lonely, boring, uncomfortable moments you chose not to skip. 

Every time you show up when it’s easier not to, you cast a vote for your future self.💪 | 2 | 0 | 0 | 1w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.570Z |  | 2025-11-25T03:22:04.543Z | https://www.linkedin.com/feed/update/urn:li:activity:7398692719247794177/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7398133611578937344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/899d6788-4719-4fd0-a653-2b00e87ef27f | https://media.licdn.com/dms/image/v2/D4E10AQEw39K6XAl1yA/ads-video-thumbnail_720_1280/B4EZqmSl4wKcAo-/0/1763726483362?e=1765774800&v=beta&t=gqtvDz8ZhCANOVXsRDgDCZDAzAsjDzoC1rYviFV3igo | AI in robotics isn’t coming, it’s here.

If you’re not building it in now, you’re already behind.

2026 separates leaders from the rest.

Leap or lag, your move. 🚀 | 7 | 0 | 0 | 2w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.571Z |  | 2025-11-22T23:01:43.676Z | https://www.linkedin.com/feed/update/urn:li:activity:7397605300448681985/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7397741971173298177 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d15b3498-940a-4116-ba13-bbd02a926af2 | https://media.licdn.com/dms/image/v2/D4E05AQE_L9Dcqw5xuQ/videocover-high/B4EZqoPFDPIUBU-/0/1763759119969?e=1765774800&v=beta&t=Hj-CeX9lDl6Swy6rbksymZNGohimSW8zSALbTrX9slk | Spent the day with my son and a colleague diving into AI. They absolutely set the Ax-C office on fire working on their new virtual agent app… 

Huge congrats on an insane day! 🚀 | 44 | 11 | 0 | 2w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.571Z |  | 2025-11-21T21:05:29.327Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7397679769619963905 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEBkqw3_oFkvA/image-shrink_800/B4EZqnWgbMIIAc-/0/1763744287012?e=1765774800&v=beta&t=_ncuaS9l-cV62a2xCMrAtwOaoD7Oyu6i03Ap3el8dN8 | A Lesson I Learned Today: Curiosity Compounds

In AI, yesterday’s knowledge ages faster than ever.

Today I learned about a new automation feature that can save small teams 10+ hours per week, no engineering needed. One small discovery… big efficiency unlocked.

I remind myself daily:
• Stay curious
• Stay open
• Stay uncomfortable

Because innovation rewards the learners not the knowers.

What’s something new you learned this week? | 16 | 0 | 0 | 2w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.571Z |  | 2025-11-21T16:58:19.321Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7397273792504373248 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fa62a97c-a2f9-446a-a58b-281619ec909b | https://media.licdn.com/dms/image/v2/D4E10AQEO2nYmfPswyQ/videocover-high/B4EZqhlJqrKgA4-/0/1763647469152?e=1765774800&v=beta&t=Nyg5haQMZanM4WR8wWvIAMO19uNQfb3fFOy8BDgkRIU | What happens if you don’t use AI? Honestly maybe nothing today.

But fast forward a year, and you’ll start to feel it.

Competitors will move quicker, make sharper decisions, and reach customers before you even get there while you’re still catching up.

At AEA, we help businesses stay ahead of that curve not run behind it.

Because in this new era, the biggest risk isn’t trying AI.

It’s pretending you can grow without it.

Ready to implement real AI solutions?
Book your call and let our team guide you from strategy to execution: https://lnkd.in/e4bz36CW | 4 | 0 | 0 | 2w | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:12.572Z |  | 2025-11-20T14:05:06.834Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7391850776891129856 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3aa1dfc0-b506-4f63-89f4-8d82e8244f90 | https://media.licdn.com/dms/image/v2/D4E10AQFA0VaOLsmdIQ/videocover-high/B4EZpUhAA4KMA4-/0/1762354536102?e=1765774800&v=beta&t=hwfnMJO9W3_VdDCEtqQOFwGHlvs_BvZXzS6xDBkbtCg | Most companies talk about AI.

Very few actually use it to drive results.

Why? 👇
• No clear ROI use case
• Messy data + legacy systems
• Teams aren’t trained for AI workflows
• Fear of change slows everything down

The truth: AI isn’t a tool problem, it’s a transformation problem.

Start small. Solve one real business bottleneck. Scale what works.

The gap is real, but so is the opportunity. | 7 | 0 | 0 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.198Z |  | 2025-11-05T14:55:59.157Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7391490821340160000 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3bc1497c-3301-4eb7-9d6f-95bfe54e1dc4 | https://media.licdn.com/dms/image/v2/D4E10AQHVb3K-6roSIg/videocover-high/B4EZpPZageHUA0-/0/1762268660539?e=1765774800&v=beta&t=uGx-JInTMp_LwlqLu9KhBecJI9Ngg8e0AFhKXzSb2aY | Everyone’s asking it is AI going to replace people?

Short answer: No.

It’s not here to take your job, it’s here to take the boring stuff off your plate.

The reports, the manual updates, the repetitive clicks gone.

So you can spend more time on what actually matters: your ideas, your creativity, your vision.

At AEA,

We help businesses use AI to lift people up, not push them out.

Because when humans and AI team up, it’s not competition it’s collaboration on a whole new level. | 11 | 1 | 0 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.199Z |  | 2025-11-04T15:05:39.066Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7391258350224691200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0OfC6aoDJzw/feedshare-shrink_800/B4EZpMGTT2IIAg-/0/1762213312750?e=1766620800&v=beta&t=oR1ECTo_oHIxZqw1pxJmL1UEk73OdEZHXrI5biKCBk8 | Just caught part of the Embassy of Canada's presentation on Chile's ICT Market, delivered by Christin Azarian, Trade Commissioner for Global Affairs Canada | Affaires mondiales Canada, specializing in telecom, education, and consumer goods based in Chile.

Thrilled to hear Chile's booming at 11% annual growth, with AI exploding to $2.84B by 2031 & IoT transforming mining & aquaculture. Chile Digital 2035 is game-changing.Super insightful! 🇨🇦🇨🇱 

A huge thanks to Ax-C for giving me this opportunity. Had the chance to meet Stephanie Beaudry, Trade Commissioner with the Trade Commissioner Service, and chat about bridging Canadian tech innovation to Chile's dynamic scene. 

Also connected with Michel Bourque, Partner & CEO at CYBERDEFENSE AI inc, Exploring how behavioural AI firewalls could assist businesses. 

Grateful for these powerhouse connections, let’s continue the conversation going! 🚀 | 15 | 5 | 1 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.199Z |  | 2025-11-03T23:41:53.633Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7389791789714661378 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHohjQcPQWXxw/feedshare-shrink_800/B4EZo3QYYhHgAg-/0/1761863647940?e=1766620800&v=beta&t=TAXnc2h_k2nAmn7GJILM1aKBmpa5lOxwjIY95-nE6bI | Had an incredible time at #MEDWeekFlorida, themed "Helping Businesses Survive and Thrive" at FIU Kovens Conference Center!

Packed with sessions on management skills, branding, and access to capital, it was pure inspiration. 

Got to connect with Heather Gordon, VP & Chief Operating Officer at M.Gill & Associates, Inc. and great job to Manny Cid, Senior Advisor for Economic Opportunity with Miami-Dade County, for receiving an award for supporting small businesses and expanding local opportunities. 

Who's ready for more growth? | 20 | 0 | 1 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.200Z |  | 2025-10-30T22:34:18.360Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7389648515422957569 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6d18c967-f694-40b6-86bd-cc4a40d6eb0c | https://media.licdn.com/dms/image/v2/D4E10AQEULCQqygtrwQ/videocover-high/B4EZo1N1ZUGYA0-/0/1761829417534?e=1765774800&v=beta&t=GU9-HFNSsiOwrmCcWucEWHTam5bAJxws2_c4oeBbt7M | Think AI’s only for the big players like Google or Amazon? Not anymore. 🚀

Today, the same tech that built empires is in everyone’s hands from startups to small shops.

AI isn’t some elite advantage; it’s the new equalizer.

You can automate, analyze, and grow smarter with just a few clicks.

At AEA, we help businesses use that same power to compete, create, and scale.

Because innovation shouldn’t belong to the giants — it should belong to everyone. | 10 | 1 | 0 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.201Z |  | 2025-10-30T13:04:59.107Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7389365636528881664 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5595921c-862d-4db5-baed-39b0cf640faf |  | What an incredible ride! 
 
A massive THANK YOU to everyone who joined us for #NoonSpark10 LIVE today with AI Entrepreneurs Alliance, your energy made it epic! Shoutout to co-host Cynthia, powerhouse speakers Jasbir & Liane, and our amazing audience.

➡️ AI, cybersecurity, leadership, mind blown! 

What's next? Drop your dream topics for "NoonSpark11" below, tech trends, digital ethics, or wild card ideas? Let's spark more!💥 

https://lnkd.in/eFzY4E_s | 6 | 1 | 0 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.203Z |  | 2025-10-29T18:20:55.523Z | https://www.linkedin.com/feed/update/urn:li:activity:7387218937429782528/ |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7389043396083920896 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fb538112-e648-471a-b218-cb22a6f76e5c | https://media.licdn.com/dms/image/v2/D4E10AQFVZN2hQFdEfg/ads-video-thumbnail_720_1280/B4EZoskn3EJ0Ak-/0/1761684389765?e=1765774800&v=beta&t=Dw4qPeJHgWUa8W_p3dYbML2d6D5d7efuTTHJpO08GFk | Can't wait for Noon Spark #10 tomorrow; it's really impressive how AI creates awesome promo videos, wow! 🤩

Liane and Jasbir bring invaluable expertise on AI-driven leadership, ethical innovation, and human-centred cybersecurity, topics key to fueling sustainable tech progress.

Let's join the live session! 
Join live: https://lnkd.in/eyT2i2Yg | 4 | 1 | 0 | 1mo | Post | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/sebastien-vaval | 2025-12-08T04:44:15.203Z |  | 2025-10-28T21:00:27.414Z | https://www.linkedin.com/feed/update/urn:li:activity:7389039933073772544/ |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7385425328812392448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGfYoGnN-rpDg/feedshare-shrink_800/B4EZn4dRT7HEAg-/0/1760810056047?e=1766620800&v=beta&t=QYT1EZw38SUq7-tL6Mnj99fhxiTOu2qaIP6HWSSilVQ | What a stellar lineup at today's Open House Montreal | Portes Ouvertes Montreal - #OHMTL kickoff in Montréal with ilias Benjelloun , Arno, Simran, Zakaria…! 🚀

AI visionary Yoshua Bengio unpacked AI's ethical edge for a thriving future, learned more about his LawZero nonprofit, launched to pioneer "safe-by-design" AI that accelerates scientific breakthroughs while building in safeguards against risks, prioritizing humanity over hype.

Andy Nulman ignited personal potential, dived deeper into his PACT! movement, a call to unleash our inner power to act boldly against hate, injustice, and inertia, turning passion into real-world disruption and positive change.

ilias Benjelloun shared startup alchemy:

Outlier founders followed: Charlotte Savage (CEO, HaiLa ) on bold scaling; Nivatha Balendra (CEO, Dispersa ) on sustainable grit; LEO RAMLALL (Co-Founder, DGENZ Studio) on creative code; Hamed Al-Khabbaz (CTO, Stay22 ) on travel tech disruption. Raised 30M+, 40M+ ARR via unconventional wins.

What's a big lesson from AI that sticks with you and how do you spot and chase unconventional paths in your work? | 43 | 6 | 2 | 1mo | Arno Burnuk reposted this | Sébastien Vaval | https://www.linkedin.com/in/sebastien-vaval | https://linkedin.com/in/arnoburnuk | 2025-12-08T06:11:09.072Z |  | 2025-10-18T21:23:32.956Z |  |  | 

---

