# Mathieu Bélanger

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402681569741795328 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEvHsy-_0GeBA/image-shrink_800/B4EZrubpGGHMAg-/0/1764936816015?e=1765774800&v=beta&t=q2WuddHYNF_szVFzybvgay8dQbB2pU_g_VQZjUmxmYQ | On a des traces historiques que le contrôle excessif produit l’effet inverse de ce qu’on souhaite et pourtant, encore aujourd’hui, plusieurs gestionnaires tombent dans le même piège.

Il y a plus de 3000 ans, en Égypte antique, les scribes travaillaient moins vite lorsqu’un supérieur les surveillait de près. Leur écriture devenait hésitante, les erreurs augmentaient, la productivité chutait. La pression tuait la qualité. Et ça, on le sait depuis des millénaires.

Malgré ça, dans nos organisations modernes, on répète encore ces erreurs.
On surveille.
On micro-manage.
On croit que plus on contrôle, mieux ça performe.

Mais le résultat est toujours le même: les gens ralentissent. Ils passent de la création à la protection. Ils n’osent plus. Ils cherchent à éviter les erreurs plutôt qu’à avancer.

La confiance fait accélérer.
Le contrôle fait freiner.

Si on veut que notre équipe progresse, peut-être qu’il faut commencer par lâcher prise et leur faire confiance. | 8 | 6 | 0 | 2d | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:35.492Z |  | 2025-12-05T12:13:41.399Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402314245952098304 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH_6j1DcuZAhA/image-shrink_800/B4EZrpNj78HUAc-/0/1764849239448?e=1765774800&v=beta&t=w0JccnOH0w91lEbqXKzM1X1MfBaukQ1f_jtQSgMPEas | Le télégraphe n’a pas amélioré la communication. Il l’a précipitée dans le chaos.

Quand on a commencé à envoyer des messages instantanés, un paradoxe est apparu: plus c’était facile d’écrire, moins on prenait le temps de réfléchir. Résultat: une explosion de messages et une chute de clarté.

Et pourtant, avant ça, on écrivait des lettres. On les préparait. On les relisait. On s’assurait que chaque mot comptait, parce qu’une mauvaise phrase pouvait retarder une décision de plusieurs jours. La lenteur nous forçait à être intelligents.

Aujourd’hui, au travail, on a le télégraphe, mais en pire.

Les réunions s’empilent. Souvent mal préparées. On jase, on tourne en rond, on collecte une montagne d’inputs et presque aucun output concret. On parle plus, on comprend moins. On se réunit plus, on décide moins.

La productivité ne vient pas du volume d’échanges. Elle vient de l’intention derrière chaque échange.
Une réunion bien préparée en remplace trois.
Un message clair évite plusieurs conversations inutiles.

La question n’est pas: comment communiquer plus vite?
C’est: comment retrouver la rigueur d’une époque où chaque mot devait réellement servir à quelque chose? | 6 | 3 | 0 | 3d | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:35.492Z |  | 2025-12-04T11:54:04.583Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401955648411836416 | Text |  |  | Faire confiance trop vite n’est pas naïf. C’est stratégique.

Selon la Truth-Default Theory du chercheur Timothy R. Levine, commencer par faire confiance améliore réellement notre capacité à repérer les gens fiables et ceux qui ne le sont pas. L’étude montre que lorsque nous adoptons une posture de méfiance, notre précision diminue. Mais lorsque nous faisons confiance au départ, nous captons plus de signaux, donc nous apprenons plus vite à distinguer les intentions sincères des intentions douteuses.

Autrement dit, la confiance est un muscle: on ne le développe qu’en l’utilisant.

En leadership, en affaires et en collaboration, c’est un principe essentiel. Être ouvert dès le début ne veut pas dire être vulnérable. Ça veut dire se donner une longueur d’avance pour mieux lire les gens, plus rapidement et plus justement.

On devient meilleur en prennant des risques. | 5 | 0 | 0 | 4d | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:35.493Z |  | 2025-12-03T12:09:08.267Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401585961261756416 | Text |  |  | On gagne souvent plus en écoutant qu’en parlant.
Certaines personnes aiment beaucoup s’exprimer, moi inclus. On veut être intéressant. Mais dans les faits, il vaut mieux être intéressé. Parce que tout le monde veut raconter son histoire, être compris, être entendu.

En conversation, on a tous un projecteur dans les mains. Certains l’orientent vers eux, d’autres vers la personne en face. Devine lesquels créent les meilleures relations.

Et en leadership, c’est tout aussi vrai. Adopter une posture de coach, poser des questions, aider l’autre à trouver ses propres réponses, c’est souvent beaucoup plus puissant que de dire quoi faire de façon directive.

Poser des questions, chercher à comprendre, c’est plus qu’une technique, c’est une preuve d’empathie.
En vente comme dans la vie en général, être intéressé plus qu’être intéressant, ça change tout. | 8 | 0 | 1 | 5d | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:35.493Z |  | 2025-12-02T11:40:07.982Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401233165492699136 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH0QJMoV7EjZA/image-shrink_800/B4EZrZ2U8UIoAc-/0/1764591489688?e=1765774800&v=beta&t=HTMgsCuHGdQrM61ccdoRZjwCaYaaJ2A3iRTkVjqSgpE | As-tu vu comment il aimait sa montre? Comment elle parlait de sa voiture de luxe?
Hé bien non. Je n’ai rien vu de tout ça.

Et c’est normal: je ne trippe pas sur les montres, alors j’ai même pas remarqué qu’il en portait une. Je ne ressens pas non plus le besoin d’avoir une voiture de luxe. Soyons clair, si on m’en donnait une, je la prendrais, mais ce n’est pas quelque chose qui me manque. 

Ce qui est fascinant, c’est que ce simple décalage ouvre la porte à plusieurs biais psychologiques très connus.
On croit voir la même réalité, mais en fait, on voit surtout ce que nos filtres nous laissent voir.

Il y a d’abord le biais d’attention. On remarque ce qui compte pour nous. Si les objets de luxe t’attirent, tu vas repérer chaque signe, chaque montre, chaque détail. Si ça te laisse indifférent, ça disparaît du décor.

Ensuite, le biais de projection. On projette nos propres préoccupations sur les autres. Quelqu’un pour qui l’argent a une forte importance aura tendance à interpréter certains comportements comme de la vantardise. Une autre personne n’y verra que de la conversation normale.

Il y a aussi le biais de résonance émotionnelle. Un sujet nous dérange seulement s’il touche quelque chose en nous. Une insécurité. Une comparaison. Un désir non assumé. Sinon, ça ne crée aucune réaction.

Un ami était persuadé que l’autre se vantait de son argent. Pour lui, c’était évident. Moi, je n’avais rien capté. 

Et je précise: oui, l’argent me motive, comme (presque) tout entrepreneur, mais ce n’est pas ma motivation première. Je ne focus pas juste là-dessus, je ne suis simplement pas matérialiste. 

Je me suis même demandé si l’autre n’adaptait pas son comportement selon à qui il parlait. Peut-être qu’il savait que l’argent comptait beaucoup pour lui et qu’il sentait que ce n’est pas ce qui me définit.

Au fond, on ne réagit pas aux objets qu’on voit, mais à l’importance qu’on leur accorde.
Ce n’est pas l’autre qu’on observe, c’est notre propre reflet. | 6 | 1 | 0 | 6d | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:35.494Z |  | 2025-12-01T12:18:14.916Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7399049513321119744 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEq_8TWLvhWRw/image-shrink_800/B4EZq60TnnJgAk-/0/1764070865948?e=1765774800&v=beta&t=3_ZTVXvfjiXp8TjVouGo6gcgir3marw30o64pvrRoEo | Quelle est la meilleure méthode? Gérer selon le cash en banque ou selon la profitabilité? Évidemment, lorsqu’on a un défi de cashflow, la question ne se pose pas. Mais il ne faut jamais perdre de vue la profitabilité.

Beaucoup ont du mal à comprendre que ce n’est pas du tout la même chose. Ce n’est pas parce qu’on a de l’argent en banque qu’on est profitable. On est peut-être simplement très bon pour encaisser avant de dépenser ou d’investir. Et quand une entreprise est en forte croissance, elle doit générer d’énormes profits pour accumuler du cash. Sinon, la seule manière d’y arriver, c’est le financement.

Il y a aussi un piège important. Même une entreprise avec beaucoup d’argent en banque peut se tromper. Elle peut croire qu’elle a les moyens d’investir massivement, mais si sa profitabilité est faible ou négative, elle risque d’avancer en aveugle. Le cash disponible reflète le passé, alors que la profitabilité reflète l’avenir. Si on investit sur la base du cash sans comprendre la réalité financière, on peut brûler du capital très vite.

Ce n’est pas tout le monde qui saisit pourquoi les startups doivent absolument se financer. Les premières années, il est pratiquement impossible de générer un cashflow positif, alors qu’elles ont besoin de liquidités pour développer leur produit, leur technologie ou leur marché.

À mon avis, avec le temps, la meilleure position consiste à avoir du cashflow et à ne plus gérer seulement ce qu’il y a en banque. L’objectif, c’est de piloter l’entreprise selon sa performance financière réelle, donc sa profitabilité globale, pas seulement la rentabilité des projets. | 2 | 0 | 0 | 1w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.695Z |  | 2025-11-25T11:41:11.668Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7398695251290517504 | Text |  |  | Certains partent en affaires en pensant qu’ils auront plus de liberté. Par moments, oui, mais les moments où ce n’est pas vrai, on ne les choisit pas. Une réunion familiale qui tombe mal, l’esprit occupé par le travail, un employé ou un client qui part et qui force à revoir ses priorités, autant professionnelles que familiales. On ne choisit pas non plus quand un client fait faillite ou quand un gros mandat arrive et qu’il faut recruter rapidement.

On a du contrôle sur beaucoup de choses, mais pas sur tout, et surtout pas tout le temps. Oui, l’horaire devient plus flexible, mais ce n’est pas une liberté totale. Et on ne devient pas entrepreneur pour avoir des privilèges, mais pour porter la responsabilité qui vient avec ce choix.

On ne naît pas entrepreneur, on le devient, avec de la constance, de la persévérance et de la discipline. Oui, on fait des rechutes, mais on se relève et on s’en sort toujours plus fort. Même quand on est malade, comme depuis une semaine, la majorité du temps, il faut travailler. Parce qu’il y a des moments qu’on ne choisit pas et qui se présentent rarement. Quand notre plus grande opportunité se présente à nous, il faut la saisir, et c’est exactement ce qu’on fait chez Parkour3 cette semaine! Ça en sera toute une, assurément, malade ou pas. | 13 | 2 | 0 | 1w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.696Z |  | 2025-11-24T12:13:29.018Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7397994850123681792 | Article |  |  | Aujourd’hui, le 22 novembre, c’est la Journée internationale des endeuillé·es par suicide. C’est important d’oser en parler, même si c’est difficile.

Pour ma part, mon père s’est enlevé la vie il y a déjà 20 ans. J’y pense encore souvent. Je me permets donc de vous partager comment j’ai tenté de donner du sens à cette épreuve.

Un jour, j’ai voulu participer à un concours de jeune entrepreneur. Mais rapidement, j’ai compris qu’il me manquait quelque chose. J’étais ambitieux, oui, mais pas impliqué. Aucune cause. 

Alors j’ai cherché, pour courir pour une cause. Et je suis tombé rapidement sur «Courir pour la vie», un organisme qui soutenait la prévention du suicide. Étant touché personnellement par ce sujet, c’était la cause qui s’imposait naturellement. J’ai choisi de verser les fonds de ma campagne au Centre de Prévention du Suicide de Montréal (anciennement Suicide Action Montréal), puisqu’ils m’avaient aidé lorsque mon père est décédé.

Je n’avais jamais couru de course officielle, mais je me suis inscrit à un demi-marathon. Ce que je croyais être un simple défi sportif est devenu une mission. J’ai levé des fonds, plus de 12K la première année, puis j’ai été invité à siéger sur le conseil d’administration du Centre de Prévention du Suicide de Montréal. J’ai ensuite été vice-président, puis président du conseil d’administration.

Je me suis impliqué sérieusement pendant plus de 6 ans. J’ai couru 7 ou 8 demi-marathons pour la cause. J’ai participé à plusieurs levées de fonds, dont une qui a dépassé le million. J’ai donc contribué à aider l’organisme à amasser plusieurs millions de dollars.

Je me suis découvert, transformé, grandi.

Et savez-vous quoi?
Je n’ai jamais participé à ce foutu concours.
Parce qu’au fond, j’avais déjà gagné quelque chose de beaucoup plus grand.

Comme quoi, une idée au départ égocentrique peut nous mener ailleurs.
Vers l’humilité.
Vers le sens.
Vers le vrai.

Si vous traversez une période difficile ou si vous pensez au suicide, c’est important de demander de l’aide. Des ressources existent et peuvent faire une réelle différence. Rendez-vous sur https://bit.ly/4oiaR6B. | 38 | 4 | 1 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.697Z |  | 2025-11-22T13:50:20.367Z | https://bit.ly/4oiaR6B |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7397638090296811520 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFyxxDzBFkIqA/image-shrink_800/B4EZqmwn.TKMAc-/0/1763734357225?e=1765774800&v=beta&t=JDrmcOOiAPQEVPFWd24IR1sPOkq9GH-ZH92us1tSkrY | Connaissez-vous l’effet cobra?
C’est ce qui arrive quand un incitatif mal conçu crée l’inverse du résultat souhaité.

Au début des années 1900, à Delhi, le gouvernement voulait réduire la population de cobras. Leur idée: offrir une prime pour chaque cobra mort. Au début, ça semblait fonctionner. Puis des gens ont commencé à en élever pour toucher les primes. Résultat: le programme a coûté cher… et le problème n’était même pas réglé.

Je fais le lien avec ma dernière publication sur les bonus de 200$ pour motiver les employés. Quand un incitatif est trop étroit, les gens finissent par optimiser pour cet objectif précis et négligent le reste. Et rien n’est pire qu’un objectif individuel qui pousse quelqu’un à délaisser les priorités collectives. Les objectifs d’équipe doivent toujours passer en premier.

Comment éviter votre propre effet cobra?
• Avoir plusieurs objectifs et non un seul indicateur.
• Mettre une date de fin à l’incitatif pour montrer qu’il est temporaire.
• Fixer un maximum pour éviter les excès.
• Ajouter des critères qualitatifs pour maintenir l’équilibre.
• Récompenser la collaboration avant les tâches individuelles.
• Réviser régulièrement l’incitatif pour corriger les effets pervers.

Un incitatif bien pensé soutient l’équipe. Un incitatif mal pensé la déstabilise. Soyez vigilant. | 36 | 4 | 4 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.697Z |  | 2025-11-21T14:12:42.196Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7397245375226695680 | Text |  |  | On leur donne un bonus de 200$ et tout sera réglé.
Hé bien non. Ça, c’est de la pensée magique. Les gens motivés surtout par l’argent pensent que tout le monde fonctionne comme eux. Oui, il y en a une bonne portion, environ 40%, mais ce n’est pas la majorité.

Et oui, ça marche au début, évidemment. Mais ce n’est pas durable. Lorsqu’on donne 200$ aux gens pour accomplir quelque chose de précis, ça devient vite un acquis. Essayez de l’enlever et vous aurez l’effet inverse: démotivation assurée. Vous voulez qu’ils en fassent plus? Il faudra ressortir le portefeuille. C’est un cercle vicieux. L’argent procure une satisfaction très courte, souvent à peine deux mois après une augmentation.

On m’a déjà répondu: oui, mais quand j’étais vendeur chez ABC pour vendre des cellulaires, ça fonctionnait.
Évidemment. Dans un contexte de vente ou d’emploi temporaire, comme un travail étudiant, ce type d’incitatif marche très bien. Il y a un taux de roulement  d'employé important dans ce genre d'entreprise.  La grande majorité des vendeurs sont effectivement motivés par l’argent, et c’est correct, c’est même ce qu’on souhaite dans ces rôles.

Mais dans une entreprise, où on veut garder les gens plusieurs années et où les profils sont variés, ce n’est pas la meilleure approche. Il faut diversifier les leviers et les incitatifs. Et rien ne surpasse la reconnaissance pour motiver durablement une équipe. Ce n’est pas un petit 200$ de bonus qui donnera envie à vos employés de rester chez vous pendant une dizaine d'année. | 13 | 5 | 0 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.698Z |  | 2025-11-20T12:12:11.627Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7396880207632297984 | Text |  |  | 82% des équipes marketing n’arrivent toujours pas à adopter l’IA correctement. 

Ce n’est pas un problème de technologie. C’est un problème d’organisation.

Selon une étude de Forrester, combinée aux insights de Blain’s Farm & Fleet et présentée sur MarTech, la majorité des initiatives IA échouent parce que les équipes marketing sont encore structurées autour de rôles trop figés: spécialiste SEO, gestionnaire de contenu, responsable courriels, etc. Résultat: silos, lenteur et projets qui n’avancent pas.

Ce qui fonctionne vraiment: une équipe plus flexible, centrée sur les compétences plutôt que sur les titres. Un modèle où chacun peut exploiter la donnée, expérimenter avec l’IA et contribuer à optimiser l’ensemble du parcours client.

L’étude met en lumière trois constats:

1. Les équipes performantes éliminent les silos et misent sur des rôles transversaux.
2. Les spécialistes deviennent plus polyvalents et utilisent l’IA dans toutes les étapes du marketing.
3. Les organisations qui adoptent cette approche livrent plus vite, s’adaptent mieux et prennent de meilleures décisions basées sur les données.

L’IA ne remplace pas les marketeurs. Elle exige une structure plus agile. | 22 | 6 | 1 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.699Z |  | 2025-11-19T12:01:08.888Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396524271579078656 | Text |  |  | La semaine passée, on a enfin eu accès à Gemini Flows dans notre environnement Google. C'est possible de créer des agents capables d’automatiser des tâches, filtrer des courriels, envoyer des comptes rendus après des meetings, faire des recherches sur les participants, traduire des documents, et plus encore.

J’ai littéralement refait mon agent de détection de courriels de sollicitation en cinq minutes. J’avais passé des heures à bâtir la même logique dans n8n. Après quelques ajustements, celui dans Flows est plus rapide, plus fiable et plus simple à maintenir. Je manque de temps pour en créer d’autres, mais les idées ne manquent pas.

Voici quelques idées: 
• Un agent de suivi des leads entrants: il analyse la source et la qualité du lead.
• Un agent de compte rendu automatique: il génère un résumé clair après chaque meeting et envoie les actions aux participants. (remplace  des outils payants existants)
• Un agent de traduction et d’adaptation de contenu: il transforme un document pour l’adapter au bon marché, au bon ton et au bon contexte.
• Un agent de veille concurrentielle: il surveille des entreprises, technologies ou mots clés et envoie un résumé des nouveautés importantes.

Il existe d'ailleurs plusieurs agents qui sont disponibles gratuitement. Il suffit ensuite de les modifier, ça donne une bonne idée de ce qui est possible.

Gemini Flows va clairement changer ma façon d’automatiser. Hâte de continuer à explorer. | 19 | 5 | 0 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.700Z |  | 2025-11-18T12:26:47.120Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7396153550994829312 | Text |  |  | Jeudi dernier, le 13 novembre, OpenAI lançait les groupes dans ChatGPT. Et la veille, ils sortaient GPT-5.1. Deux annonces majeures, coup sur coup.

Le travail assisté par l’IA, individuel, c’est bien. Mais en équipe, c’est encore mieux.

Les groupes permettent à toute une équipe de partager un même fil, une mémoire commune et un contexte unique. Tout le monde travaille avec le même collègue ultrarapide, parfaitement briefé et toujours disponible.

Avec les groupes, une équipe peut enfin travailler dans un même espace et partager le même contexte. 

Très concrètement, au bureau, ça donne:
Moins de va-et-vient, parce que tout le monde voit la même information au même endroit
Moins de réunions (vraiment?), car les réponses arrivent plus vite et les points se règlent sur-le-champ
Moins de pertes de temps à réexpliquer un projet, le contexte est déjà intégré
Moins de documentation éparpillée, tout reste dans un seul fil partagé

Avec GPT-5.1 en plus, on vient d’entrer dans une nouvelle étape: celle où le travail d’équipe devient réellement amplifié par l’IA. | 9 | 5 | 1 | 2w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.700Z |  | 2025-11-17T11:53:40.445Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7395504117626081280 | Text |  |  | Ne vous laissez pas convaincre trop facilement. Les entrepreneurs sont souvent assertifs, ça parle avec conviction et certitude. 
Mais un entrepreneur, ça a aussi la tête dure.

Dernièrement, un ami entrepreneur m’a répété que ce que je m’apprêtais à faire ne fonctionnerait pas. Quelques années plus tôt, il m’avait aussi assuré qu’il serait impossible d’acheter une entreprise aux comptes spéciaux de la BDC en offrant moins que le montant de leur dette.

On l’a fait. Et cette fois encore, on a réussi ce qu’il croyait impossible.

Les gens donnent des conseils, et c’est correct, mais ils n’ont pas toujours tout le contexte. Utilisez leurs commentaires pour améliorer votre idée, renforcer votre plan et vous préparer au fait que ce sera difficile. Mais ne vous laissez jamais convaincre que ce n’est pas possible. | 8 | 1 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.701Z |  | 2025-11-15T16:53:03.464Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7395067558745305088 | Text |  |  | Etes-vous surpris? Il y a plus de TDAH chez les entrepreneurs selon une étude de la BDC. Je n’ai jamais été diagnostiqué, mais mon fils oui. Et comme c’est souvent héréditaire, j’ai plusieurs symptômes qui lui ressemblent. Bref, une chose est certaine, c’est que je suis entrepreneur :)

L’étude met en lumière plusieurs points intéressants:

• Une proportion importante d’entrepreneurs présentent des symptômes de TDAH, diagnostiqués ou non.
• Plusieurs traits associés au TDAH deviennent des forces en affaires: créativité, énergie, prise de décision rapide, capacité à voir ce que les autres ne voient pas.
• Le TDAH peut aussi amener son lot de défis, notamment une pression mentale plus élevée que la moyenne.
• Les environnements rigides sont souvent difficiles à supporter, alors que l’entrepreneuriat offre plus de liberté pour créer un cadre adapté.
• L’étude recommande de mieux comprendre son profil, d’aller chercher un diagnostic au besoin et de s’entourer pour compenser ce qui l’est moins.

Finalement, ce qui peut sembler un obstacle peut aussi devenir un moteur puissant lorsqu’on le reconnaît et qu’on apprend à l’utiliser.

Lien de l'article en commentaire. | 57 | 25 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.701Z |  | 2025-11-14T11:58:19.716Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7394699840083107840 | Article |  |  | 🔶 Vous cherchez à accélérer votre prospection sans augmenter la charge de travail de votre équipe?

Le mardi 19 novembre, de 11h00 à 12h00, mon collègue Renan Espérance animera un webinaire pour présenter le nouvel agent de prospection IA de HubSpot. Vous verrez comment:
• Activer l’agent IA directement dans votre portail HubSpot
• Automatiser des courriels au ton naturel et adapté au prospect
• Déléguer certaines tâches à l’IA tout en gardant le contrôle
• Transformer vos données en actions concrètes pour votre pipeline

Inscription gratuite: https://bit.ly/4qYBjVn

Cette session s’adresse aux directeurs des ventes, responsables marketing et partenaires d’affaires qui veulent générer plus d’opportunités, plus vite. | 7 | 0 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.702Z |  | 2025-11-13T11:37:08.755Z | https://bit.ly/4qYBjVn |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7394341417298448385 | Text |  |  | T’as manqué ta chance de passer hier à Stratégies PME? Bonne nouvelle: on est encore là aujourd’hui!

On rencontre des dirigeants passionnés, on parle automatisation, HubSpot, croissance, et on continue de faire tirer un billet pour Inbound 2026, le grand rendez-vous marketing et ventes à Boston avec plus de 12 000 participants.

Passe nous voir au kiosque de Parkour3 et viens jaser avec nous.

Et bonne nouvelle: la grève de la STM est terminée! Tu peux reprendre le métro sans stress, peu importe l’heure. T’as plus d’excuse maintenant :)

Ah, et si t’as encore pas ton billet pour Stratégies PME, écris-moi en privé ton courriel. J’en ai quelques-uns gratuits à distribuer. | 10 | 2 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.703Z |  | 2025-11-12T11:52:54.104Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7393975769145851904 | Text |  |  | Veux-tu gagner ton billet pour INBOUND 2026, le méga événement marketing et ventes de HubSpot à Boston, qui réunit plus de 12 000 participants du monde entier?

Passe nous voir aujourd’hui à notre kiosque à STRATÉGIES PME, où plus de 5 000 entrepreneurs et dirigeants se rassemblent cette semaine. On fait tirer un billet pour Inbound 2026 et, en prime, on a du popcorn pour jaser HubSpot, automatisation et croissance.

Si tu n’as pas encore ton billet pour Stratégies PME, écris-moi en privé ton courriel et je t’en envoie un gratuitement.

Pas dispo aujourd’hui? Tu n'as qu'à venir demain! ;) | 6 | 0 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.703Z |  | 2025-11-11T11:39:56.791Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7393615178447147008 | Text |  |  | Êtes-vous là quand ça va mal? Avez-vous votre numéro de cellulaire dans votre signature?

Parce que, tôt ou tard, quelque chose va casser. Un livrable va être en retard, un bug va s’inviter, un malentendu va surgir. C’est inévitable.

Et c’est justement à ce moment-là que le lien avec votre client se forge ou se brise.

Un peu comme un capitaine de bateau. Tout le monde peut naviguer quand la mer est calme. Mais c’est dans la tempête qu’on voit ceux qui gardent le cap, qui rassurent l’équipage et qui ne cherchent pas un coupable, mais une solution.

Le client ne vous quitte pas parce que vous avez fait une erreur. Il vous quitte parce qu’il ne vous sent plus à bord quand la mer se met à brasser. | 48 | 9 | 0 | 3w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.704Z |  | 2025-11-10T11:47:05.269Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7392960769853706241 | Text |  |  | Ton titre? Je m’en fous.

Ce que je veux savoir, c’est si tu as atteint tes objectifs. Évidemment, sans nuire à tes collègues. Es-tu une personne d’équipe? Honnête? Coachable?

Tu étais responsable de quoi, concrètement?

Que tu sois directeur, VP ou coordonnateur, ce sont tes accomplissements qui comptent.
On voit souvent des gens avec de grands titres, mais peu de vraies responsabilités.
Et d’autres, avec un titre plus modeste, qui livrent des résultats exceptionnels.

C’est même dangereux de se cacher derrière un titre. Parce que le jour où tu chercheras un autre emploi, on ne te jugera pas (seulement) sur ton titre LinkedIn, mais sur ce que tu as réellement accompli.
Et tes anciens patrons ou collègues, qu’est-ce qu’ils en pensent? Es-tu une personne fiable? Performante? Humble?

Ne focus pas sur ton titre. Demande plutôt plus de responsabilités, une marge de manœuvre, une équipe à diriger, un budget à gérer. | 49 | 12 | 0 | 4w | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.704Z |  | 2025-11-08T16:26:42.102Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7392535603671621633 | Text |  |  | Hier, j’étais à la soirée-bénéfice du Centre de Prévention du Suicide de Montréal (CPSM).
Même après 7 ans d’implication au conseil d’administration, dont près de 4 comme président, et une dizaine de soirées-bénéfice, j’ai encore été profondément touché par les témoignages des gens qui s’impliquent pour cette cause qui me tient à cœur.

On ne guérit jamais vraiment de ce genre de drame.
On guérit un peu chaque jour, mais la douleur reste toujours quelque part.

C’est dans ce genre de soirée qu’on réalise à quel point l’aide en prévention du suicide et la santé mentale en général sont essentielles.

Le CPSM a d’ailleurs lancé une campagne de financement de 4,5 millions $ sur 5 ans pour poursuivre sa mission et soutenir encore plus de personnes.

Je suis fier de ces 7 années d’implication au sein de cet organisme.
Elles ont réellement changé ma vie et m’ont aidé à retrouver un certain équilibre face à tout le négatif que laisse un suicide dans une vie.

N’hésitez pas à vous impliquer dans une cause qui vous tient à cœur.
Ça fait grandir, et ça remet les choses aux bonnes places.

Ensemble, on peut prévenir des suicides.
Si vous êtes en détresse ou connaissez quelqu’un qui l’est, ou encore une personne endeuillée par le suicide, les gens du CPSM sont là pour vous.
Demandez de l’aide. | 57 | 8 | 1 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.705Z |  | 2025-11-07T12:17:14.585Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7392165342971666433 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGptXBpmK2RTQ/image-shrink_800/B4EZpY_MQBIoAg-/0/1762429551964?e=1765774800&v=beta&t=7P7dGXFfnMABHcSIpzMfQrPgQXKDUI2WmEGC-j8FMOc | Et si le vrai danger dans nos relations professionnelles n’était pas le conflit, mais la peur du conflit?

Je viens de lire un excellent article dans Revue Gestion signé Hubert Corbeil sur l’influence relationnelle.
Il y partage 10 pièges qui fragilisent nos relations au travail: vouloir plaire à tout prix, minimiser ses apports, éviter les désaccords ou renoncer trop vite face à un conflit.

Le plus nocif selon lui?
La peur du conflit.
Cette tendance à choisir le silence pour préserver une fausse harmonie.
Mais comme le dit Gandhi: «La paix n’est pas l’absence de conflit, mais la capacité à y faire face.»

Ma copine m’a dit quelque chose de très juste l’autre jour:
«Vaut mieux avoir une conversation courageuse, que d’avoir à vivre une conversation difficile plus tard.»

En leadership, c’est souvent là que tout se joue.
Dire les vraies choses, avec respect et bienveillance, c’est inconfortable sur le moment, mais tellement plus constructif pour la suite.

Et si la prochaine conversation que vous repoussez était justement celle qui ferait avancer votre équipe? | 14 | 7 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.706Z |  | 2025-11-06T11:45:57.555Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7391806219360866304 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEU0IAktCZWzQ/image-shrink_800/B4EZpT4kc5HEAc-/0/1762343930574?e=1765774800&v=beta&t=0SfO7C39w3ko-4F6BQEJJXaGzcDBShffARbk0MUTz4U | Tu te crois indispensable? 
Laisse-moi te ranconter une histoire.

J’ai eu la chance de faire partie de l’équipe de volleyball au secondaire.
J’étais passeur, donc toujours sur le terrain. Jamais sur le banc.
Je me sentais important. Indispensable.

Il est important de mentionner qu'on perdait tout le temps, on était très mauvais. Notre fiche était d'une ou deux victoires seulement.

Un jour, en plein match, un coéquipier laisse tomber un ballon facile.
Je me fâche. Devant tout le monde.
Je le remets à sa place.

Après le set,  l'entraîneur m’a aussitôt regardé et m’a dit :
« Ce n’est pas un comportement digne d’un joueur d’équipe. »

Set suivant: sur le banc. Pour la première fois. 

Et moi, convaincu que sans moi ils n’avaient aucune chance, je les ai regardés gagner le set.  Sans moi!

Ce jour-là, j’ai compris deux choses :

1. On ne remet jamais quelqu’un à sa place devant ses collègues. Que tu sois employé ou supérieur, ça se fait en privé, point.

2. Personne n’est irremplaçable. Quand quelqu’un d’important s’absente, les autres montent leur jeu. Ils sont souvent capables de grandes choses.

Garde toujours une bonne attitude et garde ton calme, même quand tu es insatisfait des performances de tes collègues. Ça ne changera pas en te fâchant.

Respire! :) | 32 | 11 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.706Z |  | 2025-11-05T11:58:55.814Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7391534147653238787 | Article |  |  | Tout le monde a des billets gratuits pour STRATÉGIES PME, alors je ne ferai pas semblant que c’est un scoop.

Mais tant qu’à y être, si tu veux que ce soit moi qui te les envoie, écris-moi en DM avec ton courriel et le nom de ton entreprise, et je te les fais parvenir.

L’événement a lieu les 11 et 12 novembre au Palais des congrès de Montréal.
Mon collègue Nicolas Brien y présentera une conférence le 11 novembre à 9 h 10.
Et de mon côté, j’y serai aussi, puisque Parkour3 aura un kiosque sur place. On fera même tirer un prix irrésistible. Tu ne veux pas manquer ça.

Plus d’infos ici : https://bit.ly/43bDk6p | 13 | 2 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.707Z |  | 2025-11-04T17:57:48.864Z | https://bit.ly/43bDk6p |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7391460960487514113 | Text |  |  | L’IA ne remplace pas encore les pigistes.

Une étude menée par Scale AI et le Center for AI Safety a voulu tester la capacité réelle des agents d’IA (ChatGPT, Claude, Gemini, Grok, Manus…) à accomplir des mandats de pigistes en ligne.

Résultat : moins de 3 % des tâches réussies.
1 810 $ gagnés sur un potentiel de 143 991 $.

Autrement dit: on est encore loin d’une IA capable de livrer des projets complets, cohérents et utilisables sans supervision humaine.

Mais ce n’est qu’une question de  temps.

Parce qu’entre aujourd’hui (où elle échoue à 97 %) et le moment où elle réussira à 60 %, il n’y aura qu’un petit saut technologiquw et un énorme impact sur nos métiers et nos entreprises.

Alors oui, il reste du temps pour se préparer.
Mais ce temps, c’est maintenant qu’il faut l’utiliser.

À mon avis, les dirigeants qui s’en sortiront le mieux seront ceux qui:

* apprendront à utiliser l’IA avant d’en avoir besoin;
* investiront dans la formation et la curiosité de leurs équipes;
* repositionneront leurs services vers des zones non automatisables: relation, stratégie, créativité, jugement.

Ce n’est pas une course contre la machine.
C’est une course pour travailler avec elle avant qu’elle n’avance sans nous.

Et vous, vous pensez qu’il nous reste combien de temps avant que la bascule s’amorce ? 6 mois ? 1 an ? 2 ans ? | 6 | 0 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.708Z |  | 2025-11-04T13:06:59.684Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7391094800508411904 | Text |  |  | Pourquoi les gens préfèrent-ils souvent ceux qui ont du potentiel plutôt que ceux qui sont déjà les meilleurs?

Une étude menée par Zakary Tormala, Jayson Jia et Michael Norton (Harvard Business School) l’a démontré: nous sommes plus attirés par le potentiel que par la performance démontrée.

Étrange? Pas tant que ça.
Le potentiel fait rêver. Il laisse place à la projection, à l’imagination, à l’histoire qu’on veut voir se réaliser.

C’est d’ailleurs un peu le même réflexe qui nous pousse à encourager l’équipe qui perd, quand on n'est fan d'aucune des deux. On veut assister à la remontée, croire à la surprise, être témoin d’un moment qui dépasse les attentes.

Alors quand une marque dit “nous sommes premiers”, elle ferme le récit.
Mais quand elle dit “nous avons le potentiel de devenir les premiers”, elle invite à faire partie du parcours.

Et au fond, se dire “premier”, ça peut parfois sonner un peu prétentieux.
Or, les gens préfèrent suivre ceux qui avancent que ceux qui se vantent d’être déjà rendus. | 7 | 4 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.709Z |  | 2025-11-03T12:52:00.342Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7390751594398633984 | Text |  |  | Je ne supprime pas les avis contraires ni les commentaires négatifs, même quand ils sont durs.
Je ne bloque personne, sauf ceux qui essaient de me vendre des trucs avec des messages automatisés. J'arrête de suivre des gens qui ne m'intéressent pas ou qui racontent de la BS.

La plupart des commentaires qui dérangent me font réfléchir. Ils m’obligent à voir les choses sous un autre angle. Oui, parfois, ça n’a juste pas rapport, mais ce n’est pas si grave. Oui, des fois ça me met tout à l'envers, mais n'est-ce pas comme cela qu'on grandit? Qui a dit que ça serait toujours confortable?

Il m’est déjà arrivé de très mal interpréter un commentaire. J’étais convaincu que la personne essayait de mettre de l’huile sur le feu, de provoquer encore plus de critiques envers ma publication. J'étais sincèrement frustré. Le lendemain, il s’est mis à commenter toutes mes publications, mais cette fois, de façon positive. Il m’a même invité à prendre un café. Comme quoi, parfois, on passe complètement à côté de l’intention des gens. Comme nous, les gens font parfois des erreurs de jugement.

J’ai reçu une seule fois un commentaire vraiment irrespectueux, sans aucune réflexion, juste de la méchanceté gratuite. Vous savez quoi? Je l’ai laissé là.
Parce que les gens voient bien la différence entre une opinion sincère et une attaque vide de sens. Je ne réponds tout simplement pas. Je n'embarque pas dans ce jeu.

Et ceux qui likent ce genre de commentaire se dévoilent d’eux-mêmes. Tant pis pour eux. 

Je comprends qu’on veuille effacer certains commentaires, mais la ligne s’arrête où?
Je sais bien qu’on n’est pas des journalistes, mais les gens ont quand même le droit à leur opinion, même quand elle va complètement à l’encontre de la nôtre.

Et c’est un peu la même chose en entrepreneuriat.
Quand un employé nous critique, c’est dur à avaler. 
Mais c’est souvent une occasion de mieux comprendre, de préparer un meilleur argumentaire, d’ajuster notre message et d’amener de la nuance.
Oui, c’est difficile, parfois même impossilble. Mais c’est souvent là qu’on grandit le plus. | 12 | 5 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.709Z |  | 2025-11-02T14:08:13.629Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7389984825086017536 | Text |  |  | Hier, grâce à EO Montréal, j’ai eu la chance de participer à un entraînement exclusif avec Georges St-Pierre, juste après une entrevue hyper inspirante.

Il a parlé de pensée positive, de sortir de sa zone de confort et, sans surprise, de visualisation. Selon lui, la vraie raison pour laquelle il est devenu champion, c’est parce qu’il est sorti plus souvent de sa zone de confort que ses adversaires.

Il a aussi parlé d’égo. Et ça m’a frappé à quel point le mot “égoïste” n’est pas si loin. Oui, un certain égo peut être utile, s’il est bien dosé. Mais personne ne veut vraiment avoir l’air égoïste. C’est correct de penser à soi, mais pas au détriment des autres.

C’est fou comment on peut se retrouver dans les propos de quelqu’un qui fait un métier complètement différent du nôtre.

Il a aussi insisté sur l’importance de bien séparer la personne qu’on est au travail et celle qu’on est dans la vie. Et sur un point trop souvent négligé: bien dormir.

Et oui, j’ai pris une photo avec lui.
Et non, je ne la partagerai pas ici juste pour aller chercher plus de vues.
Je t’expliquerai pourquoi un jour. | 4 | 2 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.710Z |  | 2025-10-31T11:21:21.579Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7389621781034213384 | Text |  |  | C’est jamais le fun de voir un client qu’on apprécie se placer sous la protection de la Loi sur la faillite et l’insolvabilité.
Surtout quand c’est une marque québécoise qu’on aime et qui a toujours eu de grandes ambitions.

Je souhaite sincèrement à toute l’équipe de Mayrand de traverser cette période difficile et d’en ressortir plus forte que jamais.

Parce qu’au-delà des affaires, il y a des humains.
Et dans ces moments, c’est la solidarité qui compte.

Les magasins restent ouverts, et on n'a pas besoin de carte de membre pour y aller, allez-y ! | 21 | 0 | 0 | 1mo | Post | Mathieu Bélanger | https://www.linkedin.com/in/mathieubelanger | https://linkedin.com/in/mathieubelanger | 2025-12-08T04:49:38.710Z |  | 2025-10-30T11:18:45.132Z |  |  | 

---

