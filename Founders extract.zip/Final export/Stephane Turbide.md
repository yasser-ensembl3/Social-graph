# Stephane Turbide

## Position actuelle

**Titre** : Co-Founder & COO
**Entreprise** : Maket Technologies
**Durée dans le rôle** : 6 years 2 months in role
**Durée dans l'entreprise** : 6 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Maket is an end to end solution that uses ground-breaking research in generative ai, natural language processing & deep learning to automate the creation of floorplans based on programming needs and environmental constraints.

Partner with MILA and Ivado labs
--
Maket est une solution clé en main qui utilise des recherches novatrices en matière d'IA générative, de traitement du langage naturel et d'apprentissage profond pour automatiser la création de plans en fonction des besoins en programmation et des contraintes environnementales.

Partenaire avec MILA et IVADO labs

## Résumé

Maket is a generative AI technology that automates the design and exploration of residential projects, enabling everyone to plan, design, and create their home.

www.maket.ai

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABDIrYIBuNPHTdQEw5mEbOZmEP9kOYZqwYE/
**Connexions partagées** : 73


---

# Stephane Turbide

## Position actuelle

**Entreprise** : Maket

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Stephane Turbide

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402396374215999489 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG94cLMMfnRuA/feedshare-shrink_800/B4EZrqYRygIUAg-/0/1764868824559?e=1766620800&v=beta&t=3nZ3AthNM3wt9K5jP8YU1Jp9DQAngstC03e9lGF-fZA | I remember when I used to draw house plans, I constantly had to remind clients about things that seemed so obvious to me.

But architecture isn’t easy to understand, and that’s okay.
That’s why at Maket, we’re making it simple and accessible for everyone, no expertise needed. | 9 | 0 | 0 | 3d | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:31.545Z |  | 2025-12-04T17:20:25.487Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401665244407730176 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a45d4f67-72ad-4424-a088-d4b17577cf76 | https://media.licdn.com/dms/image/v2/D4E05AQF8f9azFEJx6g/videocover-high/B4EZrf_Su0IQBY-/0/1764694504039?e=1765778400&v=beta&t=BiDXJ5qplHyAGBhlhKAlGwuqa4DEBW66l2xZ-kXyAbU | Merci Frederic Bastien pour la mention

« Est-ce que l’IA va prendre la place des architectes ? »

C’est une question qu’on entend tout le temps.

La réalité, c’est que non.
L’IA ne remplacera pas les architectes — elle va les aider à augmenter leur productivité, élargir leurs capacités et concevoir encore plus de projets, plus rapidement.

🎧 Pour écouter la discussion complète :

https://lnkd.in/ev4MrxMP | 5 | 0 | 0 | 5d | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:31.546Z |  | 2025-12-02T16:55:10.557Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401259523522392065 | Article |  |  | Toujours un plaisir de voir notre travail reconnu ! 
Merci à Innovations FR pour ce bel article sur la vision de maket et notre mission de rendre l'architecture plus accessible grâce à l'IA. 
----
Thank you to Innovation FR for this great article about Maket’s vision and our mission to make architecture more accessible through AI. | 14 | 0 | 0 | 6d | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:31.546Z |  | 2025-12-01T14:02:59.160Z | https://innovations.fr/maket-revolutionne-larchitecture-avec-lia/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7400212936431923200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGysAErEabTqw/feedshare-shrink_800/B4EZrLWcvyJ0Ag-/0/1764348251881?e=1766620800&v=beta&t=Z7Pu_XAKDOXLPRrtJVtjI0V47TpquR574RXfZHl3T_Y | Hier soir, Maket a remporté le Prix Innovation en intelligence artificielle au gala de l’ADRIQ.

C’est une belle reconnaissance du travail accompli par toute notre équipe au cours des dernières années, à bâtir une technologie qui vise à rendre la conception architecturale plus rapide, plus accessible et plus adaptée aux réalités du terrain.

Merci à l’ADRIQ pour cette reconnaissance, et à tous ceux qui contribuent de près ou de loin à cette aventure.
------
Last night, Maket received the AI Innovation Award at the ADRIQ Innovation Gala.

It’s a great recognition of the work our team has been putting in over the past few years, building technology that makes architectural design faster, more accessible, and more grounded in real-world needs.

Thanks to ADRIQ for this recognition, and to everyone who’s been part of this journey.

#innovation #AI #architecture #maket #adriq | 108 | 22 | 1 | 1w | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:31.547Z |  | 2025-11-28T16:44:13.353Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7399177887842738176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbk_n8Qm0O1A/feedshare-shrink_800/B4EZq8pFGtIQAg-/0/1764101477292?e=1766620800&v=beta&t=dKx9GtGWYDvCz4GcSTPvARE8ROfjTP_nM8SeD7we1ec | It’s a wrap! 🎉
The last 10 days have been incredible in Helsinki for Slush, an inspiring event filled with innovation, meaningful connections, and bright ideas for the future of tech.

A huge thank you to Québec Tech and Clara St-Pierre Lamy from Investissement Québec for their guidance and support throughout the mission, and to Ryan K. for the great discussions and insights.

Feeling energized and ready to bring what I’ve learned back home.

#Slush2025 #QuébecTech #Innovation #StartupEcosystem #AI | 27 | 0 | 0 | 1w | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:31.547Z |  | 2025-11-25T20:11:18.539Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7393649711049768960 | Text |  |  | I’ll be at Slush next week (November 18–20) in Helsinki!
If you’re a real estate developer or construction company, it’s the perfect time to connect and discuss how AI is transforming the way we design and build.

#Slush2025 #PropTech #AI #Architecture #ConstructionTech | 19 | 0 | 1 | 3w | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.821Z |  | 2025-11-10T14:04:18.483Z | https://www.linkedin.com/feed/update/urn:li:activity:7393648739812552704/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7392228469402804224 | Article |  |  | Grateful to The Founder Press for featuring Maket !

Proud of our team and my co-founders Patrick Murphy & Simon Vallee who were in San Francisco showcasing how we’re using AI to make architecture accessible to everyone. Exciting times ahead! | 16 | 1 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.821Z |  | 2025-11-06T15:56:48.069Z | https://thefounderspress.com/how-maket-is-rebuilding-design-from-the-ground-up/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391894174523957248 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEuu0vIc09jyw/feedshare-shrink_800/B4EZpVIlL6HoAk-/0/1762364904906?e=1766620800&v=beta&t=THub0urJwpg-SZhDhyaVrwNOAPmiyETkg3IheRFjbYg | Here’s how to draw a house… without Maket.
Hard to say I’d actually want to live in it 😅 | 8 | 0 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.822Z |  | 2025-11-05T17:48:25.959Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7389642645142179840 | Article |  |  | Maket in BetaKit 🚀
We’re on a mission to make architecture accessible to everyone, empowering people to go from idea to plan in minutes.

Grateful to our amazing team, partners, and investors who believe in this vision.

Read more here 👇 | 65 | 6 | 2 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.822Z |  | 2025-10-30T12:41:39.523Z | https://betakit.com/maket-secures-3-4-million-to-make-floor-planning-quicker-with-ai/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389358595307487232 | Video (LinkedIn Source) | blob:https://www.linkedin.com/69d7282a-2c38-4aaf-ba77-7894c222bd00 | https://media.licdn.com/dms/image/v2/D4E05AQG7n17DylyKJg/videocover-low/B4EZoxGYJ1HUBQ-/0/1761760351214?e=1765778400&v=beta&t=58WFRjE7Jdq3p1oecaq3yf34Xxjfthe43EudysVy9MY | I’m thrilled to share that we’ve just raised a $3.4M Seed round, led by Amiral Ventures with participation from Blitzscaling Ventures, BY Venture Partners, Spatial Capital, and Hidden Layers.

Coming from architecture, I saw how hard it was for people to explore ideas for their homes.
The tools were powerful — but built by architects, for architects.
That gap inspired us to start Maket few years ago — and it’s been incredible to see how far this idea has come.

This round will accelerate our mission to make architectural design approachable, playful, and empowering for everyone.

Over the past few years, we’ve spent countless hours working closely with homeowners and builders.
We realized the real problem wasn’t about making architects more efficient — it was about giving everyone access.
People wanted to test ideas, understand possibilities, and be part of the process.

By the time we launched in 2023, it was clear — people everywhere wanted a simpler way to bring their ideas to life and be part of the design process.
In just two years, over 1 million people have generated millions of floorplans on Maket — proof that change is happening fast.

After welcoming Simon Vallee as Co-Founder & CPO earlier this year, we’ve been hard at work on Maket 2.0 — a fully agentic version of our platform that will change how people design their homes forever.

Grateful for everyone who’s believed in us and supported this journey from day one.

Frederic Bastien Nectarios Economakis Dominic Becotte Bruno Tontodonati Jeffrey D. Abbott Therence Bois Isaac Souweine Bruno Morency Richard Chénier Justine Marchand Marc G. Bellemare Amélie Chagnon Claude G. Théoret George Korkejian Louis Lachapelle Jean-Philippe Taillon, CFA Nicolas Lapierre Mila - Quebec Artificial Intelligence Institute Josée Desjardins, MBAGabrielle Langlois Vanessa Alarie • MA • PhD(c) • MBA Marie-Pier Bergeron Isabelle Fisher Eric Morin Philippe Valentine, M.A. Maxime Bélanger-Quesnel Christian Wopperer Emilie Mikura Sophie Le Drew

#FundingNews #StartupJourney #ArchitectureTech #PropTech #AIDesign #GenerativeAI #FutureOfDesign #BuildingTheFuture | 74 | 48 | 2 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.823Z |  | 2025-10-29T17:52:56.765Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7388644930128175108 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGf7x7sOQU5Lw/feedshare-shrink_800/B4DZom9aQVJIAg-/0/1761590224259?e=1766620800&v=beta&t=cqr5nt7SrlEjSEXVAtgrKz_uxZqrFh17C-0ijwPekdE | Le 29 octobre, je serai sur scène à l'Expo Design EXPERIENCE B2B pour la 10e édition à Québec pour parler d’un sujet qui change déjà notre manière de travailler : l’intelligence artificielle en architecture.

Je vais présenter les grandes lignes des changements à venir dans notre industrie et partager la vision de Maket sur ce que pourrait être la pratique architecturale de demain.

Pas une vision futuriste, mais une réalité qui s’installe déjà : des outils capables de générer, ajuster et contextualiser un projet en quelques secondes, tout en gardant l’humain au centre du processus. | 12 | 2 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.824Z |  | 2025-10-27T18:37:05.727Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7386023190730559488 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvaXn7OcR-zg/feedshare-shrink_800/B4EZoBs81OIUAk-/0/1760965153184?e=1766620800&v=beta&t=UKmv1GIoX_2d6mC0eKh8WD0clEvTbBA0BL4AJkj_U8I | In the U.S., some universities left their campuses completely green — no sidewalks, just grass.

Then, they simply waited for people to walk.
Where the grass wore down, they paved the paths.
No assumptions — just observation.

That’s exactly the mindset behind Maket 2.0.
We’re not building in the dark.
We’re watching how people use, test, and explore.

Learning from real behavior before setting anything in stone.

Join the waitlist for Maket 2.0 : https://lnkd.in/eQtJtPv7 | 10 | 0 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.825Z |  | 2025-10-20T12:59:14.345Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7384320487146881024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1J0ehjMGAhg/feedshare-shrink_800/B4EZnpgU5ZIwAk-/0/1760559193612?e=1766620800&v=beta&t=XAHCQqn2ARwyJs3J0DcJ1i9vnMRiN0mA3W8923Ffa4k | Grande Fête du Québec Tech chez Ax-C
Jeudi dernier, nous avons eu le plaisir de présenter Maket devant la communauté tech du Québec, lors de la grande fête organisée par Québec Tech.

Cet événement marquait aussi notre 1 an dans le programme Stade V, une année riche en apprentissages, en défis et en réussites. Depuis notre entrée dans le programme, une multitude de choses se sont passées : de nouveaux partenariats au Japon à une forte croissance de notre équipe et de notre technologie. 

Un immense merci à Québec Tech pour cette belle soirée et pour tout le soutien offert à l’écosystème technologique québécois. | 43 | 1 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.826Z |  | 2025-10-15T20:13:18.176Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7383877438096982016 | Text |  |  | I found an old note on my phone from the time when Maket was just a thought. It said:
“Architecture should just be simple.”

Funny how that one line ended up shaping everything we’ve built.
Sometimes the best ideas start as a sentence that just feels right. | 9 | 2 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.826Z |  | 2025-10-14T14:52:47.051Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7382122771339751424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEB-9TweEVa6Q/feedshare-shrink_800/B4EZnKRiuUGoAg-/0/1760035220762?e=1766620800&v=beta&t=HMCr9vZb6ypfa3LCOxeLXWSCZjfjmZ_qQxT1tf9XhiE | $1,500 just to move a garage?

Here’s a real story from a Maket client.
He just wanted to move his garage to the other side of the house.
The quote? $1,500 USD.
And he doesn’t even know if he’ll like the result yet.

The problem?
The architect is at the center of everything.
Every small change depends on their time, their schedule, their fee.

That’s where Maket comes in. 🚀
We’re shifting the power back to homeowners | 9 | 0 | 0 | 1mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.827Z |  | 2025-10-09T18:40:21.896Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7381034635432185856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFSDh5dz8sTyQ/feedshare-shrink_800/B4EZm6z4qhHgAg-/0/1759775788967?e=1766620800&v=beta&t=eOVILwbQ3mz02iHh1o3mkXEf9b2FDg9ljSHQl1AjrYA | From hand sketches to instant design.
I found this old plan from my practice days — every blue note was a client change I had to redraw manually.

What took hours (or days) back then will take seconds with Maket 2.0.
No more endless revisions or version chaos.

Just fast, intelligent, collaborative design — powered by AI.

The future of architectural iteration is coming. | 5 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.827Z |  | 2025-10-06T18:36:30.079Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7379861805508034562 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHFX_xXHkIBzQ/feedshare-shrink_800/B4EZmqJM1rHgAo-/0/1759496164375?e=1766620800&v=beta&t=5uVWSr-B9kEYXsWOBvgB86z1_bwzxjnt4V_lNo_AEZY | Yesterday, an architect told me: “AI can’t really help me.”

My answer: AI isn’t coming… it’s already speeding at 200 km/h. 

Maybe it doesn’t replace all your tasks today. But if you ignore it, you’ll be left standing on the platform.

Stay immobile, while your customers want AI
Or get on the train. | 7 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.828Z |  | 2025-10-03T12:56:05.635Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7379507798868533249 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFJG9Ww8V-TyA/feedshare-shrink_800/B4EZmlHPMcGYAg-/0/1759411762614?e=1766620800&v=beta&t=CzE-7OtGsXRHz8of9PRz1QfARXRNiW02RULn1YB_zOQ | Maket participe au programme d’accompagnement en Expérience Utilisateur asterX | Quebecor, en partenariat avec la Chaire UX d’HEC Montréal et le Tech3Lab | HEC Montréal.

Notre objectif : optimiser l’expérience utilisateur pour rendre Maket encore plus fluide et intuitive.

----
Maket is joining the UX mentorship program asterX | Quebecor, in partnership with the HEC Montréal UX Chair and Tech3Lab | HEC Montréal.

Our goal: optimize the user experience to make Maket even more seamless and intuitive. | 17 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.828Z |  | 2025-10-02T13:29:23.875Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7379142865605779456 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGHqpfrFaMcdg/feedshare-shrink_800/B4EZmf7U6xIoAg-/0/1759324755581?e=1766620800&v=beta&t=m0xh_Qjq0XxW5948vs5kWnnaogTWRjfasCkEF4g4Pkc | Last week, I had the pleasure of joining the ALL IN panel on AI in the creative industry, alongside Wemba OPOTA, Prompt, and Pierre-Edouard G.

The message I wanted to deliver: 
Yes, AI is disrupting architecture… but it’s here to deliver much more value to the end client. 

-----

La semaine passée, j’ai eu le plaisir de participer au panel sur l’IA dans l’industrie créative, aux côtés de Wemba OPOTA, Prompt et Pierre-Edouard G.

Le message que je voulais transmettre :
Oui, l’IA bouscule l’architecture… mais c’est pour offrir beaucoup plus de valeur au client final. | 40 | 1 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.829Z |  | 2025-10-01T13:19:17.005Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7377300476578672640 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQECauk933QUzw/feedshare-shrink_800/B4EZmFvr9xHcAg-/0/1758885495590?e=1766620800&v=beta&t=TtGfRKo7xcHYWelxUm-v_cp4y2hP0O-tiiB4xms5H28 | Maket was present both on the ground and On Stage at ALL IN to showcase Maket 2.0.

More info : https://lnkd.in/eQtJtPv7
-----
Maket était présent sur le terrain et On Stage à All In pour présenter Maket 2.0 | 28 | 0 | 1 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.829Z |  | 2025-09-26T11:18:17.231Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7376960676847837184 | Article |  |  | A new chapter is beginning at Maket.

For the past 6 months, under the incredible leadership of Simon Vallee we’ve been quietly rebuilding the platform from the ground up, guided by conversations with hundreds of users, thousands of data points and deep technological advancements from our research team.

The result is Maket 2.0, and while we’re not launching it 𝘫𝘶𝘴𝘵 𝘺𝘦𝘵, I wanted to share a first look.

This new version is radically simpler, faster, and more intelligent. 

We’ve put an LLM trained in architecture at the heart of the experience, paired with a set of agents that help you generate, edit, visualize, and refine floorplans in ways that feel natural and intuitive.

But more importantly, we’ve designed the entire journey with the architectural experience at its core — not just supporting you, but executing your requests and turning ideas into reality.

Huge thanks to our entire team for the insane amount of work they’ve poured into this.

More to come soon 👀

Read the full announcement here : https://lnkd.in/e5rfg3ih | 30 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.830Z |  | 2025-09-25T12:48:02.662Z | https://www.maket.ai/post/a-new-maket-is-coming |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7376631596101177344 | Article |  |  | 🚀 Maket was featured in X Tech Japan, highlighting our collaboration with Lib Work.

Through this partnership, we are working on adapting our generative algorithms to Japan’s unique regulatory context — a key step toward making generative architecture more accessible and compliant with local realities.

We’re proud to see Maket recognized internationally and excited to contribute to the future of residential construction in Japan.

https://lnkd.in/etNZbiDP | 10 | 0 | 1 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.830Z |  | 2025-09-24T15:00:23.698Z | https://xtech.nikkei.com/atcl/nxt/column/18/03045/090200035/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7376623375005151234 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFsgzQQyuyeug/feedshare-shrink_800/B4EZl8DesPKcAk-/0/1758722911672?e=1766620800&v=beta&t=wC97PHKZ1ZhdygxcQa_di3lhk9BLz5p2djI480F4W7I | Find my co-founder Patrick Murphy at TechCrunch Disrupt in SF, Oct 27–29! 👋 | 10 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.831Z |  | 2025-09-24T14:27:43.636Z | https://www.linkedin.com/feed/update/urn:li:activity:7376618549857136640/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7375884146319196160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEQQKenZsmblw/feedshare-shrink_800/B4EZlSbxhCKwAk-/0/1758024637335?e=1766620800&v=beta&t=pC5WS5UAoUm8eqwRzO5kq_Rls-GVxzQKi-bsiK0Tqko | Ce jeudi 25 septembre, nous donnerons la conférence « La place de l’IA dans les industries créatives », de 14h45 à 15h05, dans le cadre de l’événement ALL IN.

En collaboration avec Prompt et E-AI, nous explorerons comment l’intelligence artificielle transforme la créativité et ouvre de nouvelles perspectives pour nos industries.

Vous y serez?
-----
This Thursday, September 25, we’ll be giving the talk “The Role of AI in Creative Industries”, from 14:45 to 15:05 PM, as part of the ALL IN event.

In collaboration with Prompt and E-AI, we’ll explore how artificial intelligence is transforming creativity and opening new perspectives for our industries.

Will you be there?

#ALLIN #IA #IndustriesCréatives #Innovation #Tech | 59 | 1 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.831Z |  | 2025-09-22T13:30:17.783Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7374798902614499328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHPRBekzAZaIA/feedshare-shrink_800/B4EZliMhHKKoAg-/0/1758289074256?e=1766620800&v=beta&t=ELZl72EGE9eYMlN1n6zgHMbrvDz5n0SY5w1xHcPuUAw | I’ve been in Japan for two weeks now, exploring the market and meeting with partners.

What strikes me most walking around here is how strong the avatar & gadget culture is — it’s everywhere.

It makes me wonder… maybe for Maket, we should already start thinking about our own avatar.

What do you think? 😅 | 14 | 2 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.832Z |  | 2025-09-19T13:37:55.521Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7374397387471101953 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGZHkPNB9TrUA/feedshare-shrink_800/B4EZlcfV5oHIAg-/0/1758193346038?e=1766620800&v=beta&t=VNX9-Bx_sHASXc2rrL7P4JCoBIwHqKKCiJ1xIrkIFsk | This week I was in Osaka for Tech Osaka 🇯🇵.

One of the most interesting comments I kept hearing was: “Architects must not like you very much.”

It made me reflect. If I were still practicing, I wouldn’t see this as a threat or replacement of my role—but rather as progress. Giving clients the power to prepare better before meeting with an architect means they arrive with clearer ideas, more confidence, and a stronger foundation to collaborate.

That’s not about replacing architects—it’s about empowering people to express what’s in their minds and making architecture more accessible to everyone.

I’m curious to hear from professionals across all fields: how do you perceive the role of AI in your industry? | 18 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.832Z |  | 2025-09-18T11:02:26.851Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7373986742535897090 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEkcPgJV4J_5g/feedshare-shrink_800/B56ZlNxxNFKMAo-/0/1757946517279?e=1766620800&v=beta&t=Yvy-xkjlO52JG9w3GOApBXoaE4M48f1xH9DKM6X7e7M | Ne ratez pas l’occasion de participer à ce programme unique pour stimuler l’innovation et propulser la croissance de votre entreprise.
--
Don’t miss the opportunity to join this unique program to boost innovation and drive your company’s growth. | 1 | 0 | 0 | 2mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.833Z |  | 2025-09-17T07:50:41.469Z | https://www.linkedin.com/feed/update/urn:li:activity:7373362116084506625/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7369734807385169922 | Text |  |  | “AI is everywhere. But do clients really care?”
These days, every company and startup seems to have “AI” in their tagline. 

It’s the buzzword of the decade, everyone wants that shiny “AI-powered” label.

But let’s be real: do clients actually want AI?

We’ve seen so many tools slap on “AI” without delivering real value. At the end of the day, people don’t care how it works. They just want results. They want to see their project come to life, their home, their space, their dream.

That’s why at Maket, AI isn’t the headline. It’s just the engine. What matters is helping every client turn their vision into a real architectural plan they can trust. | 5 | 0 | 0 | 3mo | Post | Stephane Turbide | https://www.linkedin.com/in/stephane-turbide-5963777a | https://linkedin.com/in/stephane-turbide-5963777a | 2025-12-08T05:18:35.834Z |  | 2025-09-05T14:15:01.132Z |  |  | 

---



---

# Stephane Turbide
*Maket*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Most companies in generative AI focus on creating images to visualize a… | Stephane Turbide](https://fr.linkedin.com/posts/stephane-turbide-5963777a_most-companies-in-generative-ai-focus-on-activity-7287546203200749568-A5eI)
*2025-01-21*
- Category: article

### [Stéphane Turquay - Product Leader & SaaS Builder](https://stephaneturquay.com/seventh-post)
*2025-05-24*
- Category: article

### [Maket Technologies | F6S](https://www.f6s.com/company/makettechnologies)
*2025-05-14*
- Category: article

### [Maket - 2025 Company Profile - Tracxn](https://tracxn.com/d/companies/maket/__TbOgaM8l8bfm3jThvnWcDyyPXvoAjF7MQfZk5BRt4yA)
*2025-04-25*
- Category: article

### [Behind the Deal: Maket - Front Row Ventures Blog](https://blog.frontrow.ventures/behind-the-deal-maket-2fba98d833fa?gi=5a67f7e8a7a5&source=read_next_recirc---------0---------------------501306da_7714_47a8_ab2a_5075a90ccc77-------)
*2022-06-28*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Entrevue avec Stéphane Turbide de Maket.ai - Comment l'AI ...](https://baladoquebec.ca/la-technique-moneyball/entrevue-avec-stephane-turbide-de-maketai-comment-lai-revolutionne-le-domaine-de-larchitecture)**
  - Source: baladoquebec.ca
  - *Apr 11, 2023 ... La Technique MoneyBall - Entrevue avec Stéphane Turbide de Maket ... Good talk! Si vous avez des suggestions ou des questions, n ......*

- **[Consulting Services | Mila](https://mila.quebec/en/industry/applied-research-projects-for-industry/consulting-services)**
  - Source: mila.quebec
  - *Blog · Speed Science Contest · Publications · Open Source Software. Column1 ... - Stephane Turbide, COO, Maket. As an early stage deep tech company, i...*

- **[Companies - Front Row Ventures | Canada's first student-run ...](https://frontrow.ventures/companies/)**
  - Source: frontrow.ventures
  - *Maket Founded by Patrick Murphy, Jessen Gibbs, Stephane Turbide. Concordia ... Blog · Contact Us. © Copyright 2017-2025 Front Row Ventures. All Rights...*

---

*Generated by Founder Scraper*
