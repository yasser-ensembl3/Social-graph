# Jonathan Blanchard

## Position actuelle

**Titre** : Founder and Embedded Software Consultant
**Entreprise** : JBLopen Inc.
**Durée dans le rôle** : 9 years 5 months in role
**Durée dans l'entreprise** : 9 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Consultant in the field of high performance embedded software.
- Embedded RTOS development, integration and support
- BSP and Driver development
- MCU/SoC support and software migration
- SDK design and implementation

About JBLopen Inc.:
Located in Montreal, Canada, JBLopen Inc. is dedicated to providing quality technical expertise in the field of high performance embedded software.

## Résumé

Results driven embedded software expert specialized in high performance deeply embedded RTOS and bare-metal applications. I've acquired a considerable experience with the requirements of high end embedded applications. Not only about the technical aspects, but about the overall solution requiring co-operation between multiple entities. Modern embedded software projects demand participation of multiple third parties such as the semiconductor manufacturers,  OEM software providers, distributors, independent consultants and more. Understanding that the success or failure of a single participant makes the difference for a successful product launch is key in the world of modern highly complex embedded designs.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAANMxSIBefyYj9q228Ccor2rjMf6674FhEE/
**Connexions partagées** : 9


---

# Jonathan Blanchard

## Position actuelle

**Entreprise** : JBLopen Inc.

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jonathan Blanchard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389022949313503235 | Article |  |  | Serial NAND Flash should not be overlooked by demanding applications targeting #Zephyr OS. Our latest article explores three possible software solutions, LittleFS, Yaffs2 and TSFS, and enumerates the considerable cost and performance advantages of serial NAND Flash over NOR Flash or eMMC.

https://lnkd.in/eEsvcaTK | 10 | 0 | 2 | 1mo | Post | Jonathan Blanchard | https://www.linkedin.com/in/blanchardj | https://linkedin.com/in/blanchardj | 2025-12-08T07:01:52.315Z |  | 2025-10-28T19:39:12.524Z | https://www.jblopen.com/serial-nand-flash-zephyr-os/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7341092027645739008 | Article |  |  | By popular request we've updated our article on the QSPI protocol to include the "Command-Address-Data" notation often seen in Micron Technology's and other manufacturers' datasheets. The notation lists the number of lanes used for each phase of a QSPI transfer for example 1-1-4 for a basic Quad SPI transfer where the data phase is using 4 lanes but the command and address phase use 1 lane. This is often easier and less confusing than remembering the difference between, for example, Quad I/O Fast Read and Quad SPI Fast Read.

https://lnkd.in/dPJJyzu | 6 | 0 | 0 | 5mo | Post | Jonathan Blanchard | https://www.linkedin.com/in/blanchardj | https://linkedin.com/in/blanchardj | 2025-12-08T07:01:52.316Z |  | 2025-06-18T13:18:50.285Z | https://www.jblopen.com/qspi-nor-flash-part-3-the-quad-spi-protocol/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7339039334852911106 | Article |  |  | Not all file systems are created equal. We compared four fail-safe, flash compatible, embedded file systems on features and performances. Namely:

- LittleFS
- YAFFS2
- FILEX
- TSFS

Are you using one of them in your embedded system project?

https://lnkd.in/eP4nbAcB | 7 | 0 | 1 | 5mo | Post | Jonathan Blanchard | https://www.linkedin.com/in/blanchardj | https://linkedin.com/in/blanchardj | 2025-12-08T07:01:52.316Z |  | 2025-06-12T21:22:10.186Z | https://www.jblopen.com/comparing-embedded-file-systems/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7335675914145423360 | Article |  |  | Are you leveraging your SoC or MCU's internal memory in your embedded application? Even when using external SDRAM an MCU internal RAM or a SoC's On-Chip RAM can be put to good use by the application.

For example:

- Low latency access to latency critical code and data.
- Reduce the bandwidth usage on the central interconnect.
- Low power state retention.
- More secure memory location to hold unencrypted sensitive data and keys.
- Potentially optimized location for DMA buffers.
- Coherent shared memory in multi-core systems.

https://lnkd.in/etiQmZuy | 45 | 0 | 1 | 6mo | Post | Jonathan Blanchard | https://www.linkedin.com/in/blanchardj | https://linkedin.com/in/blanchardj | 2025-12-08T07:01:52.317Z |  | 2025-06-03T14:37:08.200Z | https://www.jblopen.com/introduction-ocram/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7333996142789103618 | Article |  |  | Have you considered Serial NAND Flash for your embedded application as a lower-cost, higher performance alternative to high density Serial NOR?

Serial NAND such as the Winbond W35, Macronix MX35 or the Micron Technology MT29 devices provides considerable advantages including:

- Higher density (128MiB+) 
- Considerably lower cost compared to NOR Flash for the same density.
- Higher performance and lower power usage.
- Often smaller than parallel nor and NAND and even smaller than large dual die NOR

We can help! Check out our article on the subject and do not hesitate to contact us if you need help integrating serial NAND into your next embedded project. https://lnkd.in/dUMNZSV | 12 | 0 | 0 | 6mo | Post | Jonathan Blanchard | https://www.linkedin.com/in/blanchardj | https://linkedin.com/in/blanchardj | 2025-12-08T07:01:52.317Z |  | 2025-05-29T23:22:19.500Z | https://www.jblopen.com/qspi-nand-intro/ |  | 

---



---

# Jonathan Blanchard
*JBLopen Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 5 |

---

## 📚 Articles & Blog Posts

### [JBLopen Inc. | LinkedIn](https://ca.linkedin.com/company/jblopen-inc)
*2025-01-01*
- Category: article

### [Jonathan Blanchet](https://jonathanblanchet.com/)
- Category: article

### [Jonathan Blow on his programming language jai and upcoming game(s)!](https://podcast24.fr/episodes/game-engineering-podcast/jonathan-blow-on-his-programming-language-jai-and-upcoming-games-UNhq9qTEje)
*2025-01-18*
- Category: podcast

### [Jonathan Blow on his programming language jai!](https://www.youtube.com/watch?v=jamU6SQBtxk&pp=0gcJCdgAo7VqN5tD)
*2025-01-18*
- Category: video

### [Game devs are drowning in complicated proprietary systems (Jonathan Blow)](https://www.youtube.com/watch?v=AtlO5Zne6ec)
*2024-01-24*
- Category: video

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[BASEplatform Bring-Up on the Toradex Colibri iMX7 - JBLopen](https://www.jblopen.com/baseplatform-bring-up-on-the-toradex-colibri-imx7/)**
  - Source: jblopen.com
  - *Nov 21, 2018 ... ... Evaluating Embedded File System RAM Usage Under Real-Time Constraints. April 3, 2024. © 2025 JBLopen Inc. All rights reserved....*

- **[Embedded Software Blog - JBLopen](https://www.jblopen.com/blog-list/)**
  - Source: jblopen.com
  - *Zynq-7000 Bare-Metal Benchmarks. Jonathan Blanchard March 20, 2022. In this article we'll look at some well ... © 2025 JBLopen Inc. All rights reserve...*

- **[Improving Interrupt Latency on the ARM Cortex-A9 - JBLopen](https://www.jblopen.com/improving-interrupt-latency-on-the-cortex-a9/)**
  - Source: jblopen.com
  - *August 6, 2024 March 19, 2017 by Jonathan Blanchard Tagsarmbenchmarkinterrupt. Continuing from the last post, this article explores features specific ...*

- **[BASEplatform in Depth: The I/O API - JBLopen](https://www.jblopen.com/baseplatform-in-depth-the-io-api/)**
  - Source: jblopen.com
  - *BASEplatform in Depth: The I/O API. February 24, 2021 November 27, 2017 by Jonathan Blanchard Tagsbaseplatform ... April 3, 2024. © 2025 JBLopen Inc. ...*

- **[QSPI NOR Flash Part 1 – Hardware Characteristics](https://www.jblopen.com/qspi-1-hardware/)**
  - Source: jblopen.com
  - *QSPI NOR Flash Part 1 – Hardware Characteristics. December 27, 2021 May 14, 2020 by Jonathan Blanchard Tagsembedded storage. This article ... © 2025 J...*

---

*Generated by Founder Scraper*
