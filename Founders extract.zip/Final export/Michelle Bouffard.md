# Michelle Bouffard

## Position actuelle

**Titre** : Founder/Organizer
**Entreprise** : Tasting Climate Change
**Durée dans le rôle** : 8 years 11 months in role
**Durée dans l'entreprise** : 8 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAIJaoQB2LEqCNnqg_FKVWEk50AevK3hb4c/
**Connexions partagées** : 7


---

# Michelle Bouffard

## Position actuelle

**Entreprise** : Michelle Bouffard

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Michelle Bouffard
*Michelle Bouffard*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 24 |

---

## 📚 Articles & Blog Posts

### [Michelle Bouffard – Tasting Climate Change](https://tastingclimatechange.com/en/author/michelle/)
*2023-05-10*
- Category: article

### [Montreal Spotlight](https://www.guildsomm.com/public_content/features/articles/b/spotlight/posts/montreal-spotlight)
*2025-10-31*
- Category: article

### [In-depth interview with Michelle Bouffard](https://www.saq.com/en/content/inspiration/profiles/michelle-bouffard-interview)
*2024-07-03*
- Category: article

### [A drink with… Michelle Bouffard](https://www.decanter.com/wine/a-drink-with-michelle-bouffard-499491/)
*2023-04-06*
- Category: article

### [ASI Magazine 14: Sustainability Edition (English)](https://issuu.com/associationsommellerieinternationale/docs/232_asi_magazine_apr24_issue_14_english_hr)
*2024-04-29*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[What Wine Tomorrow? In Conversation with Michelle Bouffard ...](https://areni.global/what-wine-tomorrow-in-conversation-with-michelle-bouffard-jeremy-cukierman-mw/)**
  - Source: areni.global
  - *Apr 7, 2022 ... You will find the entire podcast here. What wine for tomorrow? In Conversation with Michelle Bouffard and Jeremy Cukierman MW. ·ARENI ...*

- **[Articles - D'Amato & Szabo: Wine Thieves – Episode 31 ... - WineAlign](https://www.winealign.com/articles/2021/04/26/damato-szabo-wine-thieves-episode-31/)**
  - Source: winealign.com
  - *Apr 26, 2021 ... D'Amato & Szabo: Wine Thieves – Episode 31: Femmes du Vin Part II: Emily Pearce and Michelle Bouffard ... Podcast Addict Castro Castb...*

- **[Michelle Bouffard: Accueil](https://michellebouffard.com/)**
  - Source: michellebouffard.com
  - *La sommelière Michelle Bouffard explique les causes de la crise vinicole en France, où on constate une chute de la consommation de vin. ÉCOUTER LE POD...*

- **[Discovering a new favourite appellation in the Centre-Loire – Wining ...](https://winingwithmel.com/centre-loire/)**
  - Source: winingwithmel.com
  - *Apr 14, 2025 ... So on April 1, armed with podcasts and a playlist entitled Songs ... The event started with a masterclass led by Michelle Bouffard, a...*

- **[Presse - Michelle Bouffard](https://michellebouffard.com/presse/)**
  - Source: michellebouffard.com
  - *La sommelière Michelle Bouffard explique les causes de la crise vinicole en France, où on constate une chute de la consommation de vin. ÉCOUTER LE POD...*

- **[NEWS – Tasting Climate Change](https://tastingclimatechange.com/en/blog/)**
  - Source: tastingclimatechange.com
  - *- Michelle Bouffard - 19 January 2023. Cat. Articles · The Resurgence of Indigenous Grapes. 21 December 2022. - Michelle Bouffard - 21 December 2022. ...*

- **[The Wine Conversation — Let's Talk About... Climate Change with ...](https://www.wine-conversation.com/conversations/lets-talk-about-climate-change)**
  - Source: wine-conversation.com
  - *Nov 5, 2025 ... Jeremy wrote the book with Michelle Bouffard, stage-two MW student ... Emergency Bordeaux podcast! Jane Anson and Sarah Kemp discuss ....*

- **[Quel vin pour demain ? Rencontre avec Michelle Bouffard](https://nibuniconnu.fr/quel-vin-pour-demain-rencontre-avec-michelle-bouffard/)**
  - Source: nibuniconnu.fr
  - *Jan 20, 2022 ... Michelle Bouffard, co-autrice du livre "Quel pour demain ?" évoque ses engagements pour aider le monde du vin face aux défis climatiq...*

- **[Purse increases to $140,000 at the Victoriaville – Fenergic Canada ...](https://www.coupecanada.com/en/publication/news/purse_increases_to_140000_at_the_victoriaville_-_fenergic_canada_cup.html)**
  - Source: coupecanada.com
  - *Jun 12, 2024 ... Alain Rayes, Michelle Bouffard, Pierre Beauchesne, Antoine Tardif, Alain Danault, Jerry Séguin ... In addition, the Victoriaville – F...*

- **[A drink with… Michelle Bouffard - Decanter](https://www.decanter.com/wine/a-drink-with-michelle-bouffard-499491/)**
  - Source: decanter.com
  - *Apr 6, 2023 ... Tasting Climate Change: Founder Michelle Bouffard talks to Clive Pursehouse ahead of the next conference in Nova Scotia April 22-23....*

---

*Generated by Founder Scraper*
