# Christopher Diggins

## Position actuelle

**Titre** : Founder and Lead Software Developer
**Entreprise** : Ara 3D
**Durée dans le rôle** : 7 years 4 months in role
**Durée dans l'entreprise** : 7 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Working on the next generation of 3D CAD and BIM tools for AEC professionals.

## Résumé

I am a software developer, entrepreneur, instructor, and technical communicator with over twenty five years of professional experience. My passion is solving software related problems, and making software more effective and accessible.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAMdqMBzEuxJq6T9GI-ZhzbvE_2cnHpUnY/
**Connexions partagées** : 13


---

# Christopher Diggins

## Position actuelle

**Entreprise** : Ara 3D

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Christopher Diggins

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403253436550578176 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQGS-8_W0Ekp1w/mp4-720p-30fp-crf28/B4EZr2jw7SHECI-/0/1765073164331?e=1765782000&v=beta&t=7LGGf5mw2sKeWIqSoLKEApd-bJLMbi_CB8wszk2CrxU | https://media.licdn.com/dms/image/v2/D4E05AQGS-8_W0Ekp1w/feedshare-thumbnail_720_1280/B4EZr2jw7SHEA4-/0/1765073162347?e=1765782000&v=beta&t=vvyPLJMhnBKuZijSYgCyhIem30MQ1UicyIcsbQSaY6A | I just wanted to share a little development update, that may not look like much but represents a pretty big milestone for me and Ara 3D Studio. It's a BIM Category filter. 

Here's why it is important for me:

- It's importing the BIM Open Schema (BOS) data format. It took me a long time to get the data format and the Revit exporter to a place I'm happy with. 
 
- The modifier is a C# script meaning you can edit it while Ara 3D is running. This is a feature that I think will be quite important to tool adoption in the long term. 

- The C# rendering engine, is now able to rebuild the visible scene very quickly, as demonstrated in this video. I had to do some significant work recently to get the performance this snappy.

 The goal of all this work is to lay down a solid foundation for a modern design tool. Hopefully, you appreciate the little updates. Let me know if you have any questions or suggestions. | 16 | 4 | 0 | 1d | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:44.044Z |  | 2025-12-07T02:06:05.071Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402796808432877568 | Video (LinkedIn Source) | blob:https://www.linkedin.com/518c4e5b-206c-4851-b46b-7bf8e5f760af | https://media.licdn.com/dms/image/v2/D4E05AQF4hh9oYNbZtw/videocover-low/B4EZrwEdOtGcBQ-/0/1764964292727?e=1765782000&v=beta&t=FGcgVHj8VFpWUYW8hj3Qqu_4kSxIE9steox4dDTu1qA | I've released a new version of the BIM Open Schema exporter for Revit 2025 (https://lnkd.in/eyCUGG9w).

BIM Open Schema files are zip archives of Parquet files containing BIM data. 

Some of the changes and improvements:
- Comes with BIM Open Schema table explorer tool
- Includes instanced geometry data
- Several new types and dozens of new parameters 
- Supported by the next release of Ara 3D Studio 
- Files have .bos extension but are still zip archives | 31 | 0 | 2 | 2d | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:44.045Z |  | 2025-12-05T19:51:36.444Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401700323070980097 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE0-GpOI1DrPQ/feedshare-shrink_2048_1536/B4EZrgYFhEJ0Ak-/0/1764701002102?e=1766620800&v=beta&t=cUYOdxHhDjOeK9eBLr4WmZmeWeTKbkeY0KSf5VvmJbM | Great summary of what we can expect from a Lakehouse! | 4 | 0 | 0 | 5d | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:44.046Z |  | 2025-12-02T19:14:33.962Z | https://www.linkedin.com/feed/update/urn:li:activity:7401692480179707904/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401660216381202432 | Article |  |  | Another excellent issue of AEC Magazine, with a great summary of how the industry is evolving to use data in a more modern way by Martyn Day. 

This aligns with the Ara 3D vision for BIMLakehouse.com. Let us know if you want to join our beta! | 6 | 0 | 0 | 5d | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:44.046Z |  | 2025-12-02T16:35:11.782Z | https://aecmag.com/data-management/aec-magazine-november-december-2025/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400233945268846592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGotJimjK0kxw/feedshare-shrink_800/B4EZrLpj0YGoAg-/0/1764353261327?e=1766620800&v=beta&t=TxNvAK1d0ShEcpEmLEGPPHJHbC1h_SahIG3rI_r53pg | Just a small feature update ... but an important one: 
GLB export for Ara 3D Studio. 

Good news is that Ara 3D Studio loads the GLB file 5x faster than the default Windows 3D viewer. I think this is one of the places where Ara 3D Studio will be useful for a large number of users. 

Separately, I've been thinking at one point I'm probably going to have to separate Ara 3D Studio into a Free and Pro version. What are your thoughts? What features would you recommend I put into each version? | 17 | 4 | 0 | 1w | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:44.047Z |  | 2025-11-28T18:07:42.250Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7398182008536997888 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEssxOjopY4Pg/feedshare-shrink_800/B4EZqufVTBIQAg-/0/1763864041320?e=1766620800&v=beta&t=MTORYdwPibUsdUndk1OebzFEfjT87SqzZStstesHI5I | I've been experimenting with ray tracing for creating higher quality single frame images, both to test out the geometric representation that I've developed for #BIMOpenSchema and as a potential feature for Ara 3D studio. 

Below is a test frame created using OSPRay, an open source ray tracing engine from Intel. I still have a lot to learn about properly setting up lights, materials, and the various settings, but I think the early results are promising. | 20 | 6 | 3 | 2w | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.753Z |  | 2025-11-23T02:14:02.410Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396578479955390464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0UhNBS3WUrw/feedshare-shrink_800/B4EZqXs7k6HMAk-/0/1763481729919?e=1766620800&v=beta&t=uM_pDaCHE4xjzkX4AcqXOHVTM4jYv3pBS8tNZZQOFGs | I'm excited to announce that #BIMOpenSchema is getting geometry!

The BIM Open Schema (BOS) project started as a way to provide an efficient representation of BIM data that could be transported in tabular data formats like Parquet or CSV. Parquet is extremely fast to load the data into data-bases (like DuckDB) and analytical data tools (like Power BI).

BOS uses the Entity-Attribute-Value data model which is particularly efficient for sparse data (e.g., BIM data parameters). When combined with the excellent compression capabilities of the Parquet standard, we can represent the entire linked Snowdon model (3D data and parameters) in just 12 MB. To compare that is 1/10th the size of a compressed GLB (binary GLTF).

I was motivated to continue this work thanks to my amazing #AECTech Hackathon team, #ProjectSieve who helped me understand the value and use cases for being able to efficiently extract BIM data from Revit: Greg Schleusner AIA, Jim Smell, AIA, Yao(Jiayao) Zhao, Nikita Bokhan, Travis Potter, PE, John Pierson, Anthony Samaha, and 张森（Sen Zhang).

The Project Sieve team put together an excellent presentation showing a variety of practical use cases for tracking changing design data before it is saved or uploaded to the cloud, and working with it in a standardized form. Unfortunately I wasn't able to get the geometry extraction working in time for the end of the hackathon ... maybe I just needed the extra sleep. 😴 | 52 | 11 | 5 | 2w | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.754Z |  | 2025-11-18T16:02:11.404Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394402629692600320 | Article |  |  | Lately I've been looking into ways that we can simplify extraction of useful insights out of BIM data, particularly as it is stored in Revit. 

The first step is to extract the raw data from Revit put it into a database. Over the years, I have done this using different formats and approaches, the latest being BIM Open Schema: https://lnkd.in/eyCUGG9w. You can do basic queries, filters, and grouping, which is fine for demos, but in the real world most use cases require much more sophisticated processing. 

AI can definitely help with constructing queries, but if the data model is too complex, or incomplete, we can get a bit stuck. Additionally, we tend to want to get additional data from other sources (such as spatial, geometric, norm and standards, material databases). 

I think that there would be value in a service that can preprocess the raw BIM data, into something that is "query friendly". That anyone with basic data processing experience can use, and that can make AI agents more effective as well. 

Some example of what I was thinking it could do:
- precompute the bounding boxes 
- create navigation / egress graphs 
- classify rooms / spaces into categories 
- compute basic materials 
- assign objects and materials to specific trades
- find big-ticket (high-cost) items
- flag items that are missing parameters
- tag items that have outlier values 

What else should I precompute and store in a database to simplify queries? What are your thoughts about this, is it a service that could be valuable with a simple interface? | 32 | 4 | 2 | 3w | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.756Z |  | 2025-11-12T15:56:08.276Z | https://github.com/ara3d/bim-open-schema |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391135119916396544 | Poll |  |  | In your opinion is the BIM data, as it is represented in Autodesk Revit, an example of structured data or unstructured data? 

https://lnkd.in/gNtBXDCv

I have an opinion, as usual, but I think it is more important to hear what my peers think. | 1 | 12 | 0 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.759Z |  | 2025-11-03T15:32:13.238Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7389730081004371968 | Article |  |  | If you are an aspiring entrepreneur in AEC you should attend: https://lnkd.in/efPtGBjW. See what is happening in our space and learn how other entrepreneurs pitch. Thanks to David Niewiadomski for hosting it! | 8 | 0 | 1 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.759Z |  | 2025-10-30T18:29:05.857Z | https://kpreddy.co/demo-day |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7389684355985743872 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7d429a37-45a9-4b0b-b7cf-cacb25ef7454 | https://media.licdn.com/dms/image/v2/D4D05AQEneDgG5YEbhg/videocover-high/B4DZo1n_iVG8BY-/0/1761836269334?e=1765782000&v=beta&t=djkaXTnkv3rha8DZMUdQlGEOJn8mVxETrJo3ytYDvIA | This is great news: the free GLTF exporter from e-verse now supports textures. This further deepens the value of GLTF in AEC data pipelines. | 12 | 4 | 0 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.761Z |  | 2025-10-30T15:27:24.163Z | https://www.linkedin.com/feed/update/urn:li:activity:7389676970290221058/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7388698405318844417 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9df34c01-8fb8-4d1d-af5f-9ba13a6e969b | https://media.licdn.com/dms/image/v2/D5605AQHA9toT6u0KAQ/videocover-high/B56ZomGMAzJkB8-/0/1761575755366?e=1765782000&v=beta&t=aB3WyxDGHz6g_fEzoZm6yQuME0QB5DGJ1gcOucyknEg | Just want to say that I'm a huge fan of the Zea online rendering engine. Vive la secteur technologique du Montreal! | 17 | 0 | 0 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.763Z |  | 2025-10-27T22:09:35.206Z | https://www.linkedin.com/feed/update/urn:li:activity:7388584267666132992/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7385106434109222912 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e6b4d839-3bc8-49ed-81a5-7b6ba235b145 | https://media.licdn.com/dms/image/v2/D4E05AQGVgYqt2hBb-A/videocover-low/B4EZn0rJqvHoCQ-/0/1760746578757?e=1765782000&v=beta&t=DlBlU90lBK0oqApQEra0FwV0DPLRMDYX6HZxh1zEP6I | Continuous data extraction while you work in Revit?! 

For my Friday evening mic drop, here is a sneak peek of a project which allows you to export room data (shown here as JSON files) while you work without interrupting your flow. 

Architects may also find my usage of Revit rather amusing! | 49 | 3 | 6 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.764Z |  | 2025-10-18T00:16:22.534Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7384431901723377664 | Video (LinkedIn Source) | blob:https://www.linkedin.com/38478985-ed69-4d58-b222-e241abcb46bf | https://media.licdn.com/dms/image/v2/D4E05AQHaEwlx55ddTw/feedshare-thumbnail_720_1280/B4EZnrFqY8KkAs-/0/1760585755031?e=1765782000&v=beta&t=47TrY2zXZVAeGg4_cC7oAwS9fnviRoD3ROQAZmrklBY | 🧭 Have you heard about the Indoor Mapping Data Format (IMDF) from the Open Geospatial Consortium? 

🧠 I only just learned about it. Thanks to ChatGPT actually. It is built on top of extension GeoJSON, so it can be loaded and read by a GeoJSON importer. I've found that it It's a great way to represent floor plans. 

📐Working on an IMDF / GeoJSON loader for Ara 3D Studio has helped motivate some additional work on my 2D polygon routines, e.g. for triangulating floors. 

🚪The next step is to represent openings, and to create navigation graphs, so we can figure out how to get from room to room. | 42 | 9 | 3 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.766Z |  | 2025-10-16T03:36:01.481Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7383878004990623744 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b47f7e1b-7d42-4c2e-944e-c5617a54ca78 | https://media.licdn.com/dms/image/v2/D4E05AQGH5EKbPfl4hQ/videocover-low/B4EZnimunuHMB8-/0/1760443429897?e=1765782000&v=beta&t=yAreU0Q-yY6lDcuJz0pVEw6hBrD8yvRVpSGFMcKfKgI | It's not every day that significant new advances are made in computing simulation. Some interesting applications for efficient clash detection in AEC! | 40 | 0 | 1 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.767Z |  | 2025-10-14T14:55:02.209Z | https://www.linkedin.com/feed/update/urn:li:activity:7383834955656880128/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7382444492827664384 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG6i-yPPkJcCA/feedshare-shrink_1280/B4EZnO2JVnKYAs-/0/1760111924921?e=1766620800&v=beta&t=c77qfVSL_Hp2P6kaA3PcMhqJ8i70v_UpoEPCoyPw90Q | 👨‍🏫 I've taught computer science at the University level, and one thing I learned is that being computer literate is the first skill students need. 

If you don't know the difference between an environment variable and a command line argument (surprisingly common) I can't effectively start to explain the basics of compiling, running, and debugging a program. 

Here are the key things that I try to teach before I start showing people how to write programs:

- How to open a command prompt / terminal session 
- How to navigate files and directories from the command line
- How to list the contents of a directory in different formats 
- The different between absolute paths, relative paths, and symbol links 
- Valid characters you can use in a path
- How to supply different command-line options to a command or program
- How to redirect the output of a command or program
- The difference between standard output and standard error 
- How to redirect standard output and standard error into different places. 
- How to pipe the output of one command into the input of another 
- How to set and read environment variables 
- How to put multiple commands in a batch script 
- How to perform conditional execution in a batch script
- How to repeat a command in a batch script (e.g., for each file in a directory)

Once you get a solid grasp of these skills you've already started coding, and probably don't realize it. Teaching someone how to use other languages and writing more powerful and interesting tools, becomes a lot easier. They will also have more techniques available to them for problem solving: not everything needs to be done with code! 

Please let me know if you would be interested in seeing me put together a YouTube video series on these basic skills. | 15 | 0 | 1 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.769Z |  | 2025-10-10T15:58:46.276Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7381715966268874752 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGewG4uOXkZ1A/feedshare-shrink_1280/B4EZmwsrwcGUAs-/0/1759606128345?e=1766620800&v=beta&t=978M508DrkbK3YF62okvE8wvzmLF9MCViMiwXW6SRfY | So refreshing, fundamental machine learning principles applied to AEC. This is the kind of work that is going to move the needle for our industry! | 4 | 0 | 1 | 1mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.770Z |  | 2025-10-08T15:43:52.009Z | https://www.linkedin.com/feed/update/urn:li:activity:7380323029169491968/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7381347855145525249 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b5442ecb-d7a2-430d-aef2-13068a9e87d9 | https://media.licdn.com/dms/image/v2/D4E05AQFLetiiNAS7kw/videocover-low/B4EZm_Qv7uGcB4-/0/1759850464797?e=1765782000&v=beta&t=MJsC9BIxcJIiqFJq0OhWS6kVIQnprxnqB7tawsIwNno | 💫 2 million objects and over 200 million polygons in real-time. This is why we are building a desktop tool, and not a web-based one! 

Web based tools fill an important role for AEC. We continue to develop technology to support it, but Ara 3D Studio is desktop first for several reasons:

1. No bandwidth latency - 16 GB of data can be loaded into RAM in a couple of seconds. 

2. Full access to GPU - WebGL and WebGPU don't provide access to the instancing calls required to handle data at the scale you are seeing here. 

3. Direct access to disk - We can store terabytes of data on a typical hard-drive and access it extremely fast. 

4. Multi-threaded - It is very hard to write efficient multi-threaded code for the browser. WASM based code is single-threaded by default.

5. Full SIMD support - Support for data parallelism (performing multiple numerical operations per cycle) is very limited for the browser: WASM only supports a subset of 128-bit operations vs 512-bit on desktop. 

6. OS calls - In a desktop tool, I can do things like bump up the priority of the process, or specific threads. I can also leverage memory mapped calls, for extremely fast access to disk. 

All of these are interesting technical points, but where they matter to users, is when you want to load and manipulate data and geometry at the scale of modern projects, without having to arbitrarily cut and slice the data, or look at it through a pinhole. 

The mission of Ara 3D is to enable architects and engineer to do their design work with the full context of the project at their finger tips. If scale matters to you, reach out to us! | 55 | 15 | 3 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.771Z |  | 2025-10-07T15:21:07.478Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7380998672840441856 | Video (LinkedIn Source) | blob:https://www.linkedin.com/af146bcd-f34b-48bb-9865-c5da9f8b7fa7 | https://media.licdn.com/dms/image/v2/D4E05AQHi5Ln2F3es7w/videocover-low/B4EZm6TKAiHIB4-/0/1759767210001?e=1765782000&v=beta&t=UXmNatugFpsdMgv4oOvbwF-ENbTiKwDdOY28HME1SCM | This weekend, inspired by a screenshot made by Antonio González Viegas showing the new LOD system of Fragments on Friday, I decided to share some development videos of the instancing system being developed for Ara 3D studio.

We are working on a system that supports GPU instancing and real-time manipulation of geometry on the desktop. These are key components for a next-generation 3D design tool that can handle millions of objects at a time. 

Let me know if you have any questions, or want to see a live demo! | 33 | 2 | 1 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.772Z |  | 2025-10-06T16:13:35.929Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7379923584766603264 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fca364dc-0516-443e-b3ae-94a57e45e299 | https://media.licdn.com/dms/image/v2/D4E05AQE0kLEaBt8hrg/videocover-low/B4EZmrBXMfHcB4-/0/1759510889350?e=1765782000&v=beta&t=YRat4PkYyWCSIagKzjQzOyjuncKwIJUipL8TYZOqggI | A little development update on Ara 3D studio.

This week started with me working on developing filtering objects based on properties (e.g., trying to see all of the electrical routing) and ended up with several nice fixes, because I'm obsessive that way:

- The skybox is a much higher quality image than before and supports EXR - though to be honest I'm not convinced about the shiny reflective ground. 

- Aliasing (jaggies) along object edges that have the sky as the background is now fixed. I am using multi-sampled anti-aliasing (MSAA), but previously failed to blend with the skybox. 

- Transparency is now fixed. It isn't sophisticated yet, but at least it is present. 

- I can write a scripted modifier that reads the properties from a GLB file exported using the e-verse GLTF exporter. 

I don't show it in this video, but I did some work this week to read and write geometry in a parquet format as an extension to the #BIMOpenSchema project. 

I'm hoping to package this up for a new release next week. Have a great weekend! | 21 | 1 | 0 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.774Z |  | 2025-10-03T17:01:34.958Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7378140757632712704 | Article |  |  | Two updates for #BIMOpenSchema today. 

Tomo Sugeta continues to explore new possibilities for loading columnar BIM data using Duck DB running in the browser (https://lnkd.in/edp85YHc). 

At the same I've started developing a companion system for transporting and serializing massive amounts of 3D geometry (https://lnkd.in/ezfYzWpW). I've developed a prototype GLTF to Parquet converter that gets an impressive 10x reduction in file size using the built-in Parquet support for Brotli compression. 

I've been reflecting on the rapid progress on Tomo's BIM query tool and I realize that one of the most empowering bits of this technology is the fact that open-source tools like DuckDB "just work" out of the box with Parquet files. 

It significantly reduces the barriers to interoperability! | 31 | 1 | 2 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.775Z |  | 2025-09-28T18:57:15.846Z | https://github.com/ara3d/bim-open-geometry |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7376634104059961344 | Text |  |  | I'll be speaking at Open Source Construction Live #1 and talking about BIM Open Schema! Make sure to attend it on September 29. Thank you to opensource.construction for inviting me!

The goal of #BIMOpenSchema is to provide a standardized cross-platform mechanism for efficient interchange of BIM data, inspired by modern software engineering practices and recent open technology such as Apache Parquet, and DuckDB. 

Our mission is to prove that BIM data can be far more efficiently handled at scale than previously imagined while leveraging open-standards and without adding complexity. 

Comment or DM if you want to join our discord and shape the future of AEC! | 22 | 0 | 2 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.776Z |  | 2025-09-24T15:10:21.642Z | https://www.linkedin.com/feed/update/urn:li:activity:7376616015977238528/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7375657571178942466 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1410e7c4-25e5-4b78-9845-3287c7cd128a | https://media.licdn.com/dms/image/v2/D5605AQE3tRj6FVRbww/videocover-high/B56Zlse25xJ0B8-/0/1758461662637?e=1765782000&v=beta&t=Wzaoz-ojm7I-c8Yj16QY8Xlvin6G0_e7u-KHl3EU6JE | Using DuckDB and Parquet, Tomo Sugeta is building some powerful open source BIM tools that execute locally in your browser. | 7 | 1 | 1 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.778Z |  | 2025-09-21T22:29:58.060Z | https://www.linkedin.com/feed/update/urn:li:activity:7375522819528560640/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7372286437456617472 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d3b1ebda-0d85-4d82-ac04-539866ebc4b8 | https://media.licdn.com/dms/image/v2/D4E05AQFiWgpVKRIeUg/videocover-low/B4EZk.faIMKYCE-/0/1757690047888?e=1765782000&v=beta&t=XC8Lqcejp1J3JV6Ew4IcBf42DWYx4b2H_nV17VgPsq8 | Here is a deeper dive into the scripting capabilities of Ara 3D Studio. With just a couple of lines of C# and you can see which objects satisfy a given criteria, in this case the number of triangles in the mesh. 

In the coming weeks we will demonstrate how C# scripts can be useful for even more powerful validation workflows, especially in the context of a real-time visualization engine. 
 
Additionally, we have just released a new beta of Ara 3D with some bug fixes, and performance enhancements. The link is in the comments. Thanks everyone for your continued support and encouragement! | 29 | 8 | 1 | 2mo | Post | Christopher Diggins | https://www.linkedin.com/in/cdiggins | https://linkedin.com/in/cdiggins | 2025-12-08T06:07:48.779Z |  | 2025-09-12T15:14:17.148Z |  |  | 

---



---

# Christopher Diggins
*Ara 3D*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [Christopher Diggins – Medium](https://medium.com/@cdiggins)
*2024-12-30*
- Category: blog

### [Code Builds the Future: Christopher Diggins on Innovation in AEC Software](https://e-verse.com/learn/the-code-that-shapes-buildings-a-look-at-innovation-in-aec-software/)
*2024-07-10*
- Category: article

### [Martin Coven and Christopher Diggins on MCG and possible future developments](https://cgpress.org/archives/martin-coven-and-christopher-diggins-on-mcg-and-possible-future-developments.html)
*2015-08-24*
- Category: article

### [Another Software Development Blog by Christopher Diggins](https://cdiggins.github.io/blog.html)
*2019-01-01*
- Category: blog

### [The G3D Geometry Exchange Format - Christopher Diggins - Medium](https://medium.com/@cdiggins/the-g3d-geometry-exchange-format-8b1ac189526c)
*2019-09-19*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Code Builds the Future: Christopher Diggins on Innovation in AEC ...](https://e-verse.com/learn/the-code-that-shapes-buildings-a-look-at-innovation-in-aec-software/)**
  - Source: e-verse.com
  - *Oct 5, 2023 ... The Code that Shapes Buildings: A Look at Innovation in AEC Software. April 3, 2024. Podcast. Christopher Diggins cover....*

- **[Beyond regular expressions: An introduction to parsing context-free ...](https://medium.com/free-code-camp/beyond-regular-expressions-an-introduction-to-parsing-context-free-grammars-ee77bdab5a92)**
  - Source: medium.com
  - *Jul 23, 2018 ... Written by Christopher Diggins ... Founder and Development Lead at Ara 3D. We develop software for the Architecture, Engineering, and...*

- **[Christopher DIGGINS | CEO | Research profile](https://www.researchgate.net/profile/Christopher-Diggins)**
  - Source: researchgate.net
  - *Christopher Diggins currently is the founder of Ara 3D. He is working on a ... Conference Paper. Jan 2008. Christopher Diggins ......*

- **[AECtech 2024 NYC | Annual Conference — AEC Tech](https://www.aectech.us/blog/aectech-2024-nyc-annual-conference)**
  - Source: aectech.us
  - *May 13, 2025 ... Ara 3d | An Introduction to C# Programming for AEC Professionals. Christopher Diggins / Founder. This 3-hour workshop will provide AE...*

- **[‪Christopher Diggins‬ - ‪Google Scholar‬](https://scholar.google.com/citations?user=z5J10EcAAAAJ&hl=en)**
  - Source: scholar.google.com
  - *Christopher Diggins. Ara 3D. Verified email at ara3d.com - Homepage ... 2008 International Conference on Computational Intelligence for Modelling …, 2...*

- **[Ara 3D · GitHub](https://github.com/ara3d)**
  - Source: github.com
  - *We are based in Montreal, QC. Our founder and lead developer is Christopher Diggins. Technologies Used. Currently most of our development is done in C...*

- **[AECtech+ 2025 | Barcelona — AEC Tech](https://www.aectech.us/blog/aectech-2025-barcelona)**
  - Source: aectech.us
  - *Jun 17, 2025 ... Blog Past Events. Back Values & Promise FAQ. Back Symposia ... Christopher Diggins | Founder, Ara 3D. One of the great advantages of ...*

- **[Making SIMD Operations in C# Easier | by Christopher Diggins ...](https://medium.com/@cdiggins/making-simd-operations-in-c-easier-ab1576e336d3)**
  - Source: medium.com
  - *Dec 30, 2024 ... At Ara 3D we developed an open-source easy to use C# SIMD library ... Get Christopher Diggins's stories in your inbox. Join Medium fo...*

---

*Generated by Founder Scraper*
