# William Maurer

## Position actuelle

**Titre** : Co-Fondateur et Réalisateur de Podcast
**Entreprise** : Virage Sonore
**Durée dans le rôle** : 5 years 3 months in role
**Durée dans l'entreprise** : 5 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Broadcast Media Production and Distribution

## Description du rôle

Virage Sonore est une société de production de podcast créé en 2020 par William Maurer et Kevin Gironnay. 
Nous fournissons des services de création sonore, réalisation de podcast pour le milieu de l'entreprise, des campagnes publicitaires ainsi que des créations purement artistiques.

## Résumé

Leader ambitieux, polyvalent et créatif. Après une formation artistique et une quinzaine d'années de pratique dans le milieu du son et de la musique, mon amour pour les arts m'a poussé à me spécialiser dans la gestion d'organismes culturels. Je suis, depuis 2016, directeur général du média numérique CHOQ.ca, ainsi que producteur indépendant de musique et de podcast.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABKgf_UBg5Zqax2RsgXmheZcBNmwcmhM8rI/
**Connexions partagées** : 6


---

# William Maurer

## Position actuelle

**Entreprise** : Virage Sonore

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# William Maurer

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402008409136500737 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF0_zrATAIYgg/feedshare-shrink_800/B4EZrfZGY8KgAk-/0/1764684494516?e=1766620800&v=beta&t=HORs6f2esorrbj_HoeWnYMHsUvGKY7J_4c6ymgP2KZo | Lundi soir, on a vécu un moment franchement inspirant.

Le Musée des beaux-arts de Montréal était le présentateur officiel de Full Plumé devant public, au Cabaret Mado… et la salle affichait complet.
Une centaine de personnes, une énergie folle, et une annonce en host reading de l’exposition Kent Monkman – L’histoire est dépeinte par les vainqueurs qui a été accueillie… par des applaudissements spontanés.

Voir une grande institution culturelle aller à la rencontre du public queer, dans un lieu aussi emblématique, avec autant d’aisance et d’audace… ça fait vraiment du bien.

💛 Bravo au MBAM pour ce geste fort et pour la confiance envers Full Plumé.
C’est exactement comme ça qu’on crée du lien et du sens. | 0 | 0 | 0 | 4d | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:20.242Z |  | 2025-12-03T15:38:47.404Z | https://www.linkedin.com/feed/update/urn:li:activity:7401991127987277824/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401610643235098624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHNdCjEMWea7A/feedshare-shrink_800/B4EZrfMYunIUAk-/0/1764681163338?e=1766620800&v=beta&t=5wpaiEgqXGfGYCg7VfhYgTkeA6e77V0fC0lAdqusrqc | La semaine dernière, on est sorti du studio pour accompagner le Syndicat québécois de la construction (SQC) avec notre studio mobile lors de la captation et de la diffusion en direct de leur AGA.

Faire appel à une équipe professionnelle pour une diffusion en direct, un webinaire ou une Assemblée générale, c’est l’assurance d’une qualité qui respecte votre image de marque et qui impressionne vos client·es et partenaires. Rien n’est laissé au hasard : son, image, stabilité, fluidité… tout compte.

Et pour les organisations qui souhaitent aller encore plus loin, le balado en direct est une formule géniale : vos auditeurices peuvent interagir en temps réel, poser des questions, réagir au contenu et vivre l’expérience avec vous.

Toujours un plaisir de sortir du studio et d’amener l’expertise de Virage Sonore directement sur le terrain. | 4 | 0 | 0 | 5d | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:20.242Z |  | 2025-12-02T13:18:12.623Z | https://www.linkedin.com/feed/update/urn:li:activity:7401609271974580225/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399807871426797569 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFe_NGLloW4yw/feedshare-shrink_800/B4EZrFkv_hJ0Ag-/0/1764251337790?e=1766620800&v=beta&t=K0b3-Z9gEQZVjSz8YlsiTY_Culbhih3CAHwGyhpTgn0 | Travailler sur ce balado est un privilège en soi…
Mais côtoyer et collaborer avec quelqu’un de la trempe de Michel Desautels, pour Virage Sonore , c’est un vrai honneur. Son professionnalisme, sa rigueur, sa curiosité tranquille : tout cela élève naturellement le projet, saison après saison.

La 3ᵉ saison d’Arrêt sur le droit vient d’arriver, et ce qui me frappe encore, c’est de voir des auditeur·trices découvrir les nouveaux épisodes… tout en prenant le temps de revenir à la saison 1.
C’est exactement ce que nous répétons aux entreprises, aux OBNL et aux marques avec qui on discute.

Je cite souvent une métaphore de Kevin G , que je trouve parfaitement juste :
👉 « Un balado, ce n’est pas un sprint. C’est un marathon. »

Et c’est vrai.
Un balado se bâtit dans le temps, dans la constance, dans la qualité et dans la relation de confiance avec les partenaires.
Avec le CAIJ, cette relation-là est sincère, simple, et elle avance au même rythme que le projet. | 3 | 3 | 0 | 1w | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:20.243Z |  | 2025-11-27T13:54:38.330Z | https://www.linkedin.com/feed/update/urn:li:activity:7399806446063996928/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398770119109410816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH_3cxLVJLKCg/feedshare-shrink_800/B4EZq22N63HgAk-/0/1764004258018?e=1766620800&v=beta&t=2pAfLhQhbSxXvuOYAujP_QRoR5PveKLbLJCEdoWCQRw | ❓ Un balado doit-il absolument être en vidéo en 2025 ? 🎥

C’est LA question qu’on me pose le plus souvent en ce moment. Et honnêtement… la réponse n’est pas si simple.

 Parce qu’au-delà de la tendance, il faut surtout comprendre pourquoi on voudrait ajouter de la vidéo à un balado.

🎥 Quand la vidéo fait vraiment la différence
La vidéo peut devenir un formidable levier :
idéale pour la promotion et les formats courts ;
incontournable dans un univers où l’image amplifie l’audio ;
efficace pour attirer une nouvelle audience sur YouTube ;
utile pour activer la monétisation à partir d’un certain volume de vues.
Pour les balados de discussion, ça fonctionne particulièrement bien : naturel, spontané, engageant.

🎧 Les limites de la vidéo
À l’inverse, les documentaires audio, les balados narratifs ou immersifs ne se prêtent pas à ce format. Leur force repose sur la création sonore, la narration, la post-production et l’espace imaginaire.
Également, lorsqu’on souhaite recueillir des témoignages sensibles, la vidéo peut devenir un frein : le matériel impressionne, et on perd l’intimité d’un studio exclusivement audio. 
Ajouter des caméras change complètement la proposition : on glisse vers un documentaire vidéo, ce qui devient un tout autre genre.
Et il ne faut jamais laisser la vidéo prendre le pas sur l’audio. Une grande partie de l’auditoire écoute sans écran ; penser uniquement pour l’image peut exclure celles et ceux qui privilégient l’écoute pure. L’objectif est d’éviter les « angles morts » créatifs, pas d’en créer.

🎛️ Et chez Virage Sonore?
À Virage Sonore, notre agence créative spécialisée en production balado, on accompagne quotidiennement des projets qui naviguent entre audio pur et formats audiovisuels.
 Notre approche est simple :
 Le format doit servir le propos.
 Si la vidéo apporte une valeur réelle – portée, interaction, visibilité – on l’intègre.
 Si elle dilue l’immersion ou trahit l’intention du balado, on mise tout sur l’audio… et on le pousse au maximum.
C’est cette réflexion sur mesure qui guide chaque production que l’on signe.

Au final, la vraie question n’est pas « faut-il ajouter la vidéo ? »
 mais « que gagne l’histoire si on la filme ? » | 6 | 0 | 1 | 1w | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:20.243Z |  | 2025-11-24T17:10:58.897Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7397615975157886976 | Text |  |  | Cher·es membres de mon réseau,

Je suis à la recherche d’un·e spécialiste — ou d’une agence — en marketing stratégique pour m’accompagner dans un repositionnement de marque ainsi que pour des conseils SEO / GEO.

Idéalement, j’aimerais collaborer avec quelqu’un à Montréal, que vous avez déjà essayé et recommandé.

Si vous avez une personne ou une équipe à suggérer, je serais vraiment preneur.
Merci d’avance pour vos recommandations ! | 4 | 3 | 0 | 2w | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:20.244Z |  | 2025-11-21T12:44:49.536Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7389633096738025473 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGjApA_61im5A/feedshare-shrink_800/B4EZo0.dB_KYAg-/0/1761825379022?e=1766620800&v=beta&t=QMEy9UvrHFetnT_84LZXHSR8ZMmbN9JtRxfskPW8WBU | 🎧 Le balado n’est plus une tendance, c’est une nouvelle habitude d’écoute.
 Aujourd’hui, 32 % des Canadiens francophones écoutent des balados chaque mois… et ce chiffre continue de monter 📈

Moi, mon moment préféré pour écouter un balado, c'est en cuisine !  👨‍🍳
On dirait que je n'imagine plus mon découpage de carottes sans entendre des balados d'histoire ou de politique. 

Comme cofondateur de Virage Sonore, une agence créative spécialisée en balado et en production sonore, je vois chaque jour à quel point ce média peut transformer la communication des marques, des organismes et des créateurs.

Un balado, c’est plus qu’un contenu, c'est un lien durable et une façon authentique de faire résonner vos valeurs, de raconter une histoire.
Si vous songez à créer le vôtre, c’est le bon moment d’embarquer.
 🎙️ Parlons-en → viragesonore.com | 9 | 2 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.831Z |  | 2025-10-30T12:03:43.006Z | https://www.linkedin.com/feed/update/urn:li:activity:7389631239567118336/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7387451925899735040 | Article |  |  | 🎧 Cet automne, Full Plumé, le magazine culturel Queer produit par Virage Sonore est soutenu par Pneusx4.

Une jeune entreprise d’ici qui a choisi de miser sur le balado pour rejoindre une nouvelle clientèle, tout en encourageant la production indépendante. 🪶

Un bel exemple de partenariat local où le commerce et la création se renforcent mutuellement.

Et si vous cherchez les pneus les moins chers du marché pour cet hiver, c’est par ici 👉 https://lnkd.in/eez6NEXw ❄️🛞

#FullPlumé #VirageSonore #balado #partenariatlocal #pneus #créationdici #baladoquébécois | 3 | 0 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.832Z |  | 2025-10-24T11:36:31.354Z | http://pneusx4.com/discount/PLUMES5 |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7386008237726334976 | Article |  |  | 🎙️ Vous pensiez que le podcast était uniquement un hobby à temps partiel ? Détrompez-vous. Voici comment une équipe l’a transformé en vrai business.
L’article du The Wall Street Journal montre que même un podcast tout juste lancé peut s’organiser pour générer des millions — et devenir une entreprise à part entière.

📰 En résumé :
Un podcast tech lancé il y a seulement 11 mois a déjà embauché un président pour gérer sa monétisation publicitaire.
🎯 Objectif : tripler ses revenus, passant de 5 M $ à 15 M $ d’ici 2026.
🎧 Son secret : un positionnement premium (public aisé, ton entre info et divertissement) et un modèle d’affaires agile — ventes pub directes, partenariats luxe et diversification (événements, production) — le tout sans financement externe.

🎧 Faire un podcast de niche, c’est souvent bien plus payant que vouloir parler à tout le monde.

L’exemple du podcast TBPN, le prouve : en ciblant un public précis — fondateurs, investisseurs, passionnés de tech.

💡 La clé : mieux vaut un auditoire restreint mais engagé, qu’une audience large et distraite.
Un podcast bien positionné, avec une stratégie claire de monétisation et une production soignée, peut rapidement devenir un véritable média.

Et c’est là que la qualité entre en jeu.
Un son professionnel, un rythme maîtrisé, une identité sonore forte : ce sont des atouts qui font la différence entre un projet amateur et un contenu qui inspire confiance — autant aux auditeurs qu’aux partenaires.

Chez Virage Sonore , on aide justement les créateurs et les organisations à transformer leurs idées en podcasts qui se démarquent — par leur fond, leur forme et leur impact.

#Podcast #Balado #Audio #Niche #Monétisation #VirageSonore #StratégieAudio

https://lnkd.in/ePStDYK3 | 3 | 0 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.834Z |  | 2025-10-20T11:59:49.271Z | https://www.wsj.com/articles/this-podcast-is-11-months-old-it-just-hired-a-president-to-manage-ad-revenue-6d4551fc |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7385332384138838016 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ba156366-a835-4840-9f91-0b234956134b | https://media.licdn.com/dms/image/v2/D4E05AQG36X_yhOmtXg/videocover-high/B4EZn33vK1GUBw-/0/1760800216061?e=1765785600&v=beta&t=FGGYV5ieH_vk65Ohr0cQW6GDNehv3Q56p7YAiFArs3k | Il y a deux ans, je suis parti sur la Côte-Nord pour Virage Sonore afin de réaliser le balado Parole de Nord-Côtières avec Ann-Édith Daoust et le Regroupement des femmes de la Côte-Nord.
Une expérience humaine et inspirante que je n’oublierai pas. 💜

À l’occasion de la 6e Marche mondiale des femmes, je vous invite à écouter le 5e épisode, qui revient sur la marche de 2000, quand des femmes de la Côte-Nord ont marché jusqu’à New York. | 2 | 0 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.834Z |  | 2025-10-18T15:14:13.219Z | https://www.linkedin.com/feed/update/urn:li:activity:7385331446380593152/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7384234697523961857 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG67IXyViA5Tw/feedshare-shrink_800/B4DZnoQzHSKoAg-/0/1760538342445?e=1766620800&v=beta&t=uOzHoh96WjIHiezPHaWLwRcwX0PNwj_7KSjylD0UnOg | 🎧 Chaque mois, on prépare avec l’équipe de Virage Sonore une petite infolettre pleine de découvertes sonores.
 On y partage nos suggestions d’écoutes, quelques conseils de réalisation, et des nouvelles du milieu du balado.
Parce que Virage Sonore, ce n’est pas qu’un studio d’enregistrement :
 c’est un studio de création et de production qui a à cœur les sujets qu’il fait entendre — et qui aime les faire connaître.
Si vous aimez le balado (ou simplement découvrir de belles histoires audio), je vous invite à vous abonner ici 👇
 https://lnkd.in/eWjnmEM6
💚 À bientôt dans vos oreilles. | 6 | 0 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.835Z |  | 2025-10-15T14:32:24.336Z | https://www.linkedin.com/feed/update/urn:li:activity:7384233015465652224/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7382385568082526208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE13fe1nZhecA/feedshare-shrink_800/B4EZnN_XKQJ0Ag-/0/1760097564528?e=1766620800&v=beta&t=_YdLEIXCBwzlBoy80c1QLcPwux06hoz984103CUg22g | 🎧 Journée mondiale de la santé mentale

La santé mentale nous touche toutes et tous.
Chez Virage Sonore, on a eu la chance de produire plusieurs balados qui abordent ces enjeux avec sensibilité — sur des thèmes aussi variés que la jeunesse, le travail, la parentalité, la condition féminine ou encore le sport.

Parce qu’en parler, c’est déjà prendre soin. | 2 | 0 | 0 | 1mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.836Z |  | 2025-10-10T12:04:37.522Z | https://www.linkedin.com/feed/update/urn:li:activity:7382384263284854784/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7380941034656264192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF8qHmfGHVIuw/feedshare-shrink_800/B4EZm5co7.GYAk-/0/1759752918178?e=1766620800&v=beta&t=xXe2lzkvOqUCcarpfB7o5_cutM_Qqeyy7UdtpiWcNhM | Les OBNL portent des histoires puissantes et profondément humaines.
Chez Virage Sonore, on les aide à leur donner une voix — à transformer leur mission en balado.

Vous avez une OBNL, on se parle? | 6 | 0 | 0 | 2mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.837Z |  | 2025-10-06T12:24:33.915Z | https://www.linkedin.com/feed/update/urn:li:activity:7380938721631674368/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7379137069001891840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGMkMpXgECgmQ/feedshare-shrink_1280/B4EZmf1XW4IoAs-/0/1759323191702?e=1766620800&v=beta&t=MXYaRgOnqJro1yuS5W9YP6yRs4CkSZ6BOrf6J6SYb68 | 🎉 Fierté personnelle aujourd’hui : le Musée des beaux-arts de Montréal devient commanditaire de Full Plumé! 🪶

Je suis vraiment heureux de voir un acteur culturel d’une telle envergure s’associer à notre balado pour donner de la visibilité à l’exposition Kent Monkman – L’HISTOIRE EST DÉPEINTE PAR LES VAINQUEURS.

C’est exactement ce qu’on souhaite avec Virage Sonore : créer des ponts entre les univers et montrer que le balado peut être un outil stratégique aussi bien qu’un espace de création.

Merci au MBAM pour leur confiance 🙏
Et bravo à toute l’équipe de Full Plumé qui rend ça possible 💚 | 7 | 2 | 0 | 2mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.837Z |  | 2025-10-01T12:56:14.987Z | https://www.linkedin.com/feed/update/urn:li:activity:7379136313016602624/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7376604508677672963 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEkjmQNZeSmkg/feedshare-shrink_800/B4EZl72jSrHoAk-/0/1758719523019?e=1766620800&v=beta&t=1IuFVrJt0WwrbLKCyNJAtrpP0EOYNNFrmXiDMSN7vfI | On ouvre maintenant le samedi! | 6 | 0 | 0 | 2mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.838Z |  | 2025-09-24T13:12:45.553Z | https://www.linkedin.com/feed/update/urn:li:activity:7376604336975532032/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7376241993061933057 | Article |  |  | Il y a quelques mois, j’animais un panel sur l’intelligence artificielle au Festival Transistor.

Aux côtés de Chloé Sondervorst et Jean-Sébastien Côté, nous avons discuté de l’IA comme outil d’aide à la création audio, tout en abordant ses limites et les enjeux éthiques qu’elle soulève.

L’enregistrement est maintenant disponible à l’écoute sur les plateformes!

Bonne écoute | 7 | 0 | 0 | 2mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.838Z |  | 2025-09-23T13:12:15.095Z | https://transistor.media/balado/festival-de-la-radio-numerique/9e-edition-2025-episode-1-lutilisation-de-lintelligence-artificielle-en-balado/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7375863555041943553 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG4jqERieOilQ/feedshare-shrink_800/B4EZlxR1cBHEAg-/0/1758542127194?e=1766620800&v=beta&t=piCjFgIi81N7WR1D3Fy7ZYrJpvgKceLUhIIWO-md4vk | 🎉 Déjà 5 ans de Virage Sonore et 2 ans dans notre studio sur Rachel !

Fier de la confiance de nos clients et heureux de voir leur satisfaction à travers leurs projets et leurs retours 5 étoiles. 🙏

🚀 Merci à tous ceux qui rendent cette aventure possible — et la suite s’annonce encore plus inspirante ! | 6 | 0 | 0 | 2mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.839Z |  | 2025-09-22T12:08:28.440Z | https://www.linkedin.com/feed/update/urn:li:activity:7375860293282988032/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7361415561064382466 | Article |  |  | Alors que s’achève le Festival de la Fierté à Montréal 🎙

Nous sommes fiers de présenter « Je m’appelle GRIS-Montréal », un balado qui met en lumière 30 ans d’engagement, de bénévolat et de témoignages inspirants.
À travers des conversations intimes et authentiques, cette série prolonge la mission du GRIS-Montréal : sensibiliser aux réalités des personnes LGBTQ+ et briser les préjugés, comme le font depuis toujours leurs ateliers de démystification.
Chez Virage Sonore, nous sommes honorés d’avoir accompagné le GRIS dans la réalisation de ce projet et de contribuer à la diffusion de ces histoires puissantes.

Merci à Fanny Jasmin pour le magnifique graphisme et bravo à mon associé Kevin G pour la création de cette introduction puissante et la réalisation de ce balado ! 

🎧 Disponible sur toutes les plateformes d’écoute.
#GRISMontréal #Podcast #Balado #LGBTQ #Diversité #Inclusion #VirageSonore #FiertéMontréal | 5 | 0 | 0 | 3mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.840Z |  | 2025-08-13T15:17:18.245Z | https://viragesonore.com/je-mappelle-gris-montreal/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7360680423988805632 | Article |  |  | 🌈 Et si votre marque devenait… fabuleuse ? 🎙
Avec 400 000 écoutes, 29 000 abonné·es sur les réseaux sociaux et un public fidèle à 88 % québécois, Full Plumé est LE rendez-vous incontournable de l’humour queer au Québec.
 Chaque semaine, Lady Guidoune et Charlie Morin reçoivent des invité·es du monde culturel québécois afin de replumer un sujet beige et drabe de la culture hétérosexuelle.
💡 En commanditant Full Plumé, vous gagnez :
Une visibilité authentique auprès d’une communauté engagée
Une présence multi-plateforme (YouTube, Spotify, TikTok, Instagram…)
Un taux d’engagement jusqu’à 19 %
Que vous soyez une marque ou un autre balado, c’est l’occasion parfaite de briller dans un univers où humour, créativité et inclusion se rencontrent.
📩 Intéressé·e ? Écrivez-nous à commandite@viragesonore.com

https://lnkd.in/dcwrctN9 | 8 | 0 | 1 | 3mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.841Z |  | 2025-08-11T14:36:07.908Z | https://viragesonore.com/plumeskit/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7341844664032919555 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGlPENwpa1JPQ/feedshare-shrink_800/B4EZeMZvgsHgAg-/0/1750407249104?e=1766620800&v=beta&t=b82j36H0cXdLFAPY_xwwWxnY5DkXrwNOcYgU5uVmWvA | 🎧 Ça fait longtemps qu’on me demande : « Quand est-ce que vous lancez une formation ? »
Eh bien… c’est maintenant.

Avec l’équipe de Virage Sonore, on a enfin monté la formation qu’on aurait rêvé avoir au début.
C’est pratique, concret, en petit groupe… et ça commence en octobre.

Si t’as un projet de balado en tête (ou juste l’envie d’apprendre) 👇👇👇 | 6 | 0 | 0 | 5mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.842Z |  | 2025-06-20T15:09:32.783Z | https://www.linkedin.com/feed/update/urn:li:activity:7341804529727729665/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7335734576520081409 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHF0pamtbywNw/feedshare-shrink_800/B4EZc2ZW6UHYAg-/0/1748964307036?e=1766620800&v=beta&t=hbpAPH07kv3nLYXRLdtvOpJptDaIoC7Z8TMmOqdNxko | ✨ Une étape importante pour Virage Sonore ✨

Après 5 ans à développer notre studio de balado sans subvention ni financement bancaire, on est très heureux de pouvoir enfin offrir un premier emploi à temps plein dans notre équipe.
C’est une petite victoire pour nous, mais une grande avancée dans notre projet : bâtir un studio humain, créatif et durable.
🎧 Si tu penses être la bonne personne pour ce poste, on a hâte de découvrir ton CV !
Et bien sûr, on encourage fortement les candidatures de femmes et de personnes issues de la diversité (autochtones, racisées, LGBTQIA+, appartenant à la diversité capacitaire ou à un groupe historiquement marginalisé).

📩 À partager sans modération !

Plus d'infos ici : https://lnkd.in/eBA-EHJb | 10 | 0 | 1 | 6mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.843Z |  | 2025-06-03T18:30:14.400Z | https://www.linkedin.com/feed/update/urn:li:activity:7335687997918507008/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7322661583820648448 | Text |  |  | 🎙️ Vous cherchez un moyen authentique et puissant de connecter votre entreprise à votre public cible ? Et vous ne voulez pas vous lancer dans la production d'un balado de marque  ? 

Pensez aux publicités en host reading ou en spot de pub sur les podcasts produits par Virage Sonore (Full Plumé, l'Imagination Artificielle, Encres de peau).

Pourquoi c’est si efficace ?

➡️ Fidélisation accrue : les auditeurs de podcasts développent une vraie relation de confiance avec les animateurs qu’ils écoutent chaque semaine. Quand c’est lui ou elle qui recommande un produit, le message est perçu comme crédible et sincère.
➡️ Association positive : en plaçant votre marque au cœur d’un contenu que les auditeurs aiment, vous bénéficiez d’un transfert naturel d’affection et de loyauté. Votre produit ne "casse" pas l’expérience d’écoute : il l’accompagne.
➡️ Attention maximale : contrairement à d'autres formats publicitaires souvent ignorés ou zappés, les host readings captent réellement l’attention. Ils sont intégrés, personnalisés, et mémorables.

👉 Dans un monde saturé de messages publicitaires, miser sur l’authenticité d’une voix familière, c’est choisir l’impact.

Envie d’en parler ? Écrivez-moi ! | 7 | 0 | 0 | 7mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.843Z |  | 2025-04-28T16:42:50.056Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7313581039019261952 | Text |  |  | ✨ L'IA et la création de podcasts : un mariage prometteur ou une révolution en marche ? 🎙️🤖
Je suis ravi d'annoncer que j'aurai le plaisir d’animer un panel sur ce sujet passionnant lors du Festival Transistor Media ! 🎧🔥
Avec moi sur scène, trois experts du milieu :
 🎤 Chloé Sondervorst (Radio-Canada)
 🎤 Anne-Claire Lainé (Longueur d'ondes)
 🎤 Jean-Sébastien Côté (Transistor Média)
Nous explorerons comment l’intelligence artificielle transforme la création sonore, de la génération de voix à la production automatisée, et ce que cela signifie pour les créateurs et le public.
📅 Rendez-vous le 25 Avril dès 9h30 au Festival Transistor !
Hâte d’échanger avec vous sur place ou en commentaires ! 🚀
#Podcast #IA #Transistor #CréationSonore #Innovation | 5 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.845Z |  | 2025-04-03T15:19:59.467Z | https://www.linkedin.com/feed/update/urn:li:activity:7313578870354440192/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7313537735963607040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPNwg--KyzdA/feedshare-shrink_800/B4EZTh9GL0G0Ag-/0/1738957677619?e=1766620800&v=beta&t=jVqLA5pwBLESI_vGlH0S2HyqjX3DrNAHIBm3ruhenxs | Mardi c’était la diffusion du dernier épisode de Parkinson Québec! 
Merci à l’équipe de Parkinson Québec pour leur confiance! 

Ce balado est un excellent moyen d’en apprendre plus sur la maladie avec des témoignages saisissants. | 1 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.846Z |  | 2025-04-03T12:27:55.214Z | https://www.linkedin.com/feed/update/urn:li:activity:7293717149888446465/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7312863610324557824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvoaKJCp8ftQ/feedshare-shrink_800/B4EZXtuX_GHMAk-/0/1743450113650?e=1766620800&v=beta&t=PyYDT-s3u47z5Qx-7TCLVHJcDALph_odAHc-VCN8_hI | C’est LA nouveauté | 2 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.846Z |  | 2025-04-01T15:49:11.137Z | https://www.linkedin.com/feed/update/urn:li:activity:7312805986098905088/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7311506677889953793 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF5lENXsoEWYg/feedshare-shrink_800/B4DZXewX9SHYAk-/0/1743198989617?e=1766620800&v=beta&t=FBZ_tt1O6a5ODlcHVdwcchK8A4o3BbTj9XAjT6PhlnQ | 💡 Le balado documentaire, c'est un excellent moyen pour votre entreprise de montrer à vos client.e.s et futur.e.s client.e.s votre réalité.

Merci au CIUSSS de l'Ouest-de-l'Île-de-Montréal pour leur confiance en ayant donné à Virage Sonore le mandat de réaliser un balado immerssif sur le service des urgences de l'hôpital général du Lakeshore. 

Je vous invite à écouter ce balado pour avoir la réponse à la fameuse question ''Mais pourquoi c'est si long quand je vais aux urgences'' 

Bonne écoute | 3 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.847Z |  | 2025-03-28T21:57:13.234Z | https://www.linkedin.com/feed/update/urn:li:activity:7311506513821417474/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7310319118736334852 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF250hJtBLOiA/feedshare-shrink_800/B4EZW080onGgAk-/0/1742497599512?e=1766620800&v=beta&t=fThjPrAdNKN6KWmmLPGk6tuDTl3ttWqB7_xwNqVZq34 | 💡Vous saviez que le balado est un excellent moyen de faire de la formation? 

📚Que ce soit pour compléter une formation en personne ou en ligne, accueillir vos nouveaux employé.e.s dans votre organisation ou simplement mettre à jour votre personnel sur les informations importantes, en complément d’une infolettre interne par exemple. 

🎯Le balado est un moyen ludique et rapide de faire passer un message 

Merci au Barreau du Québec d’avoir fait confiance à Virage Sonore pour la production audio et vidéo de son balado | 1 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.848Z |  | 2025-03-25T15:18:17.068Z | https://www.linkedin.com/feed/update/urn:li:activity:7309978558943092736/ |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7309215940519313408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGzqXIAni-FRQ/feedshare-shrink_800/B4EZW5KkCUHUAk-/0/1742568309799?e=1766620800&v=beta&t=N_3H_rkfR7aTtLF4GU1EMxHu7jFEJwdN4Dcz9cnsR_Q | Une nouvelle série balado qu’on a eu la chance de réaliser avec Virage Sonore. Chaque semaine on vous invite à découvrir un nouvel épisode avec des femmes inspirantes parlant d’enjeux féministes. 

Merci au Réseau des groupes de femmes Chaudière-Appalaches - RGFCA pour leurs confiances | 4 | 0 | 0 | 8mo | Post | William Maurer | https://www.linkedin.com/in/william-maurer-9317a988 | https://linkedin.com/in/william-maurer-9317a988 | 2025-12-08T07:16:24.848Z |  | 2025-03-22T14:14:38.885Z | https://www.linkedin.com/feed/update/urn:li:activity:7308861257355309056/ |  | 

---



---

# William Maurer
*Virage Sonore*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [Virage Sonore | Studio de production et réalisation Balado et Podcast à Montreal](https://viragesonore.com/en/accueil/)
*2024-09-01*
- Category: article

### [Will Maurer on VR, VFX and Stereoscopic 3D Conversion on Waskul.TV](https://www.waskul.tv/will-maurer-steve-waskul-2016/)
*2017-02-04*
- Category: article

### [Testimonials](https://viragesonore.com/en/testimony/)
*2024-08-28*
- Category: article

### [Morgane Billuart: Virtuality and Aesthetics, An Evening in the Void Club](https://donotresearch.substack.com/p/morgane-billuart-virtuality-and-aesthetics)
*2024-01-02*
- Category: blog

### [The Artist Behind Berlin’s World-Class Spatial Sound Studio - Slowness](https://slowness.com/journal/the-artist-behind-berlins-world-class-spatial-sound-studio/)
*2023-10-12*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Notre équipe – Virage Sonore | Studio de production et réalisation ...](https://viragesonore.com/a-propos/)**
  - Source: viragesonore.com
  - *Une équipe de création et de production qui vit pour le son — du premier brief jusqu'au mix final. William Maurer ... Virage Sonore. 79 Rue ......*

- **[25 janvier 2024 • L'univers du balado/podcast dans la mire de deux ...](https://www.intentioninc.ca/post/25-janvier-2024-l-univers-du-balado-podcast-dans-la-mire-de-deux-artistes-entrepreneurs)**
  - Source: intentioninc.ca
  - *Jan 24, 2024 ... Épisode 72 • François Morin va à la rencontre de William Maurer et Kevin Gironnay, deux musiciens cofondateurs de Virage Sonore https...*

- **[Laval en trois temps saison 2 : cohabiter le territoire | Magazine](https://signelaval.com/fr/magazine/laval-en-trois-temps-saison-2-cohabiter-le-territoire)**
  - Source: signelaval.com
  - *Jul 26, 2022 ... Apple Podcasts Google Podcasts RSS. En appuyant sur le bouton ... William Maurer (Virage sonore). Visuel : Luc Mélanson. Poursuivez ....*

- **[Historique - Transistor Media](https://transistor.media/festival/historique/)**
  - Source: transistor.media
  - *Conférence sur la formation en balado – Festival Transistor 2025 ... L'utilisation de l'intelligence artificielle en balado avec William Maurer (Virag...*

- **[Aide-toi et la pub t'aidera | Le Devoir](https://www.ledevoir.com/culture/medias/799563/l-eldorado-du-balado-aide-toi-pub-aidera)**
  - Source: ledevoir.com
  - *Oct 7, 2023 ... Article. Pourquoi faire confiance au Devoir ? Parlons d'argent ... Virage sonore, William Maurer. « Nous, on a fait le pari commercial...*

- **[Laval en trois temps : s'impliquer dans la communauté | Magazine](https://signelaval.com/fr/magazine/laval-en-trois-temps-simpliquer-dans-la-communaute)**
  - Source: signelaval.com
  - *Jun 8, 2021 ... ... Virage sonore / Kevin Gironnay et William Maurer. Visuels : Luc ... Partager cet article. Lien copié! Abonnez-vous à notre infolet...*

- **[Les créateurs de balados s'organisent pour défendre leur art | Le ...](https://www.ledevoir.com/culture/846745/createurs-balados-organisent-defendre-art)**
  - Source: ledevoir.com
  - *Feb 21, 2025 ... Article. Pourquoi faire confiance au Devoir ? Face aux nombreux ... C'est exactement ce que déplore William Maurer, de Virage sonore....*

- **[Marlihan : La reprise du pouvoir est au coeur de la guérison -](https://canadianwomen.org/fr/blog/marlihan-la-reprise-du-pouvoir-est-au-coeur-de-la-guerison/)**
  - Source: canadianwomen.org
  - *May 16, 2023 ... ... Virage sonore Kevin Gironnay et William Maurer. Ce projet a été subventionné par Femmes et Égalité des genres Canada. WAGE Canada...*

- **[Les #Édubrèves – édition du 2 mai 2023 - École branchée](https://ecolebranchee.com/les-edubreves-edition-du-2-mai-2023/)**
  - Source: ecolebranchee.com
  - *May 2, 2023 ... ... article. Comme pour le téléphone cellulaire, l'ordinateur portable ... William Maurer et Kevin Gironnay de Virage sonore. La Coali...*

---

*Generated by Founder Scraper*
