# Pamela Azanfouet

## Position actuelle

**Titre** : Founder
**Entreprise** : NKWANGTECH Fondation
**Durée dans le rôle** : 5 years 1 month in role
**Durée dans l'entreprise** : 5 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Non-profit Organizations

## Résumé

Hardworking, curious, ambitious, and determined, I now bring my expertise in functional analysis with a strong interest in DevOps engineering to innovative projects. Specializing in the design, deployment, and monitoring of cloud-based applications, I am proficient in technologies such as AWS, Kubernetes, Jenkins, Ansible, and Travis CI.

Currently preparing for the AWS Cloud Practitioner and AWS Solutions Architect certifications, I firmly believe in continuous learning as a way to address technological and social challenges. My goal is to contribute to solutions that push the boundaries of innovation while having a positive impact on society.
Alongside my technical career, I am the founder of a non-profit organization dedicated to empowering young people. Through training and mentorship programs, I help future talents acquire technological skills and access meaningful employment in this rapidly growing field.

What drives me:
Analyzing business needs and translating requirements into robust technical solutions.
Collaborating with multidisciplinary teams to design and deploy innovative systems.
Using technology as a tool to break down social barriers and create opportunities.

If you share my passion for technology and community impact, feel free to reach out to exchange ideas or collaborate on inspiring projects!

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABSL5tUBQVsZ9SBk-D4ROlTpaLPp7te1Juk/
**Connexions partagées** : 1


---

# Pamela Azanfouet

## Position actuelle

**Entreprise** : NKWANGTECH Foundation

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pamela Azanfouet

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403526252961353729 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGA7WkytQfO4g/feedshare-shrink_800/B4EZr6SeC_GYAg-/0/1765135741110?e=1766620800&v=beta&t=Uqi2K6wM-sbF13MFGjbtxZHfT9uHXXboi5YwvP8FvmI | Go Estelle NOUMBOU you are simply the best! | 5 | 0 | 0 | 9h | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:08:58.788Z |  | 2025-12-07T20:10:09.572Z | https://www.linkedin.com/feed/update/urn:li:activity:7403515908587012096/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402816289041248256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFsIxVEvsXIgQ/feedshare-shrink_2048_1536/B4EZrwWL2LGoAo-/0/1764968939263?e=1766620800&v=beta&t=-QLE6dhWFR0IZsZ62eAMW82_9_PHuI85D2Jgzk8-Z3o | 𝗪𝗶𝗹𝗳𝗿𝗶𝗲𝗱 𝗵𝗮𝘀 𝗳𝗶𝗻𝗮𝗹𝗹𝘆 𝗹𝗼𝘀𝘁 𝗵𝗶𝘀 𝗹𝗲𝗴!
A few months ago, I raised an alarm about the health condition of Wilfried, a volunteer at the NKWANGTECH Foundation, who was suffering from acute #osteomyelitis.
 We hoped, we prayed, and we believed that with God’s grace and your support, his foot could be saved.
Unfortunately… after a difficult thirteenth surgery, his foot could not be preserved, and amputation became inevitable. It has now been 2 months since Wilfried has been living with this new reality.
I would like to express my deepest gratitude to everyone who contributed, whether through #donations, #messages, #prayers, or #emotional support. Your kindness and generosity helped Wilfried make it through one of the hardest moments of his life.
At one point, Wilfried wanted to quit school. We encouraged him not to let this pain close the door to his future.
 Today, he is receiving psychological support, as he is dealing with phantom limb syndrome;
he is determined to continue his education and plans to enroll in a degree program next year; and above all, he continues to pursue his passion: #robotics.

Wilfried told me that this is not an end, but a new beginning.
 He may have fallen, but he got back up.
 He is moving forward with exceptional courage, strong determination, and the belief that he will achieve his dreams.
Wilfried is a true example of resilience, courage, and determination. His journey is far from over, and every act of support still makes a difference.
 For anyone who would like to continue supporting him with his rehabilitation, psychological care, education, or technical equipment, you may contribute or share his fundraising page here:
 👉 https://lnkd.in/ewnnnTn2
𝗧𝗵𝗮𝗻𝗸 𝘆𝗼𝘂 𝗳𝗼𝗿 𝘆𝗼𝘂𝗿 𝘀𝗼𝗹𝗶𝗱𝗮𝗿𝗶𝘁𝘆 𝗮𝗻𝗱 𝗳𝗼𝗿 𝘁𝗵𝗲 𝗵𝗼𝗽𝗲 𝘆𝗼𝘂 𝗰𝗼𝗻𝘁𝗶𝗻𝘂𝗲 𝘁𝗼 𝗯𝗿𝗶𝗻𝗴 𝘁𝗼 𝗪𝗶𝗹𝗳𝗿𝗶𝗲𝗱.

For the full story read here: https://lnkd.in/e92MdYrU | 36 | 1 | 1 | 2d | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:08:58.789Z |  | 2025-12-05T21:09:00.983Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395616760311226368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHn1fQa6BkFzQ/feedshare-shrink_800/B4EZqJviKFGYAg-/0/1763247531603?e=1766620800&v=beta&t=c3CrezXizN-lzt0CqkPyeeCLrWUlNWe1mY4BppAxwME | Nous sommes ravies de recevoir Natacha NJONGWA YEPNGA dans le cadre des échanges #tech chez NKWANGTECH Foundation. Les #Nkwangtech #Talks sont des initiatives visant à rapprocher les jeunes des outils digitaux et des métiers de la #technologie, afin qu'ils puissent visualiser toutes les opportunités à l'horizon dans ce monde en perpétuelle transformation.
Un grand merci à toute l’équipe #Nkwangtech, et particulièrement à Gwladys GODEM POKAM, qui, depuis toujours, a pleinement intégré la mission de l'organisation !

les inscriptions sont possibles via ce lien: 
https://lnkd.in/eQZPRf5a | 22 | 2 | 0 | 3w | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:09:04.082Z |  | 2025-11-16T00:20:39.573Z | https://www.linkedin.com/feed/update/urn:li:activity:7395596178039443456/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394121112638353408 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGqxw6UL48uOw/feedshare-shrink_800/B4EZp0oZqQHUAo-/0/1762893348631?e=1766620800&v=beta&t=zq3u5_bcbXf79f7LkpE67q-JRS6yoe4I8hGfZgkppeM | Félicitations Lauriane Djouka pour cette! première journée réussie! 
WomenUP Program - Cameroon 
NKWANGTECH Foundation | 14 | 0 | 0 | 3w | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:09:04.083Z |  | 2025-11-11T21:17:29.380Z | https://www.linkedin.com/feed/update/urn:li:activity:7394110719417348096/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7379883217660604416 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHLKn0z0b7ltA/feedshare-shrink_2048_1536/B4EZmoNfLvHgAw-/0/1759463733868?e=1766620800&v=beta&t=YQUWY-pdYaGDxhjrKGU6hmE5BqqZVvlwwYcZmdoawOs | ✨ Big up to Lauriane Djouka ! 🙌
Your dedication and unstoppable drive are making a huge difference. 🌍💡
Through your tireless work with NKWANGTECH Foundation and the WomenUP Program - Cameroon, you’re proving how much can be achieved with passion and purpose. 💪👩🏾‍💼💖

Forever grateful for your commitment to creating real social impact! 🚀💫
#WomenLeadership #SocialImpact #Innovation #NKWANGTECH #WomenUP | 10 | 0 | 0 | 2mo | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:09:04.090Z |  | 2025-10-03T14:21:10.690Z | https://www.linkedin.com/feed/update/urn:li:activity:7379725787815485440/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7374539799505977344 | Document |  |  | Je suis très fière de toi! continue ainsi ! | 2 | 1 | 0 | 2mo | Post | Pamela Azanfouet | https://www.linkedin.com/in/azanfouet | https://linkedin.com/in/azanfouet | 2025-12-08T06:09:04.099Z |  | 2025-09-18T20:28:20.526Z | https://www.linkedin.com/feed/update/urn:li:activity:7374522667951091712/ |  | 

---



---

# Pamela Azanfouet
*NKWANGTECH Foundation*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [Pwani Teknowgalz | LinkedIn](https://ke.linkedin.com/company/pwani-teknowgalz)
*2025-04-28*
- Category: article

### [Pwaniteknowgalz](https://pwaniteknowgalz.org/)
*2024-05-28*
- Category: article

### [This "Girls Only" Tech Hub at Kenya's Coast is Cracking Social Codes - Prime Progress NG](https://primeprogressng.com/spotlight/this-girls-only-tech-hub-at-kenyas-coast-is-cracking-social-codes/)
*2024-01-15*
- Category: article

### [This “girls only” tech hub at Kenya’s Coast is cracking social codes](https://nairobilawmonthly.com/this-girls-only-tech-hub-at-kenyas-coast-is-cracking-social-codes/)
*2024-01-16*
- Category: article

### [How Africa’s women-led businesses are bridging the funding gap - Prime Progress NG](https://primeprogressng.com/news/how-africas-women-led-businesses-are-bridging-the-funding-gap/)
*2024-05-21*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Economic Impact — Page 13 — TechWomen](https://www.techwomen.org/impact-story-policy-area/economic-impact/page/13)**
  - Source: techwomen.org
  - *Fellow Pamela Azanfouet (Cameroon, 2022) recently expressed gratitude to ... Nkwangtech Foundation, an NGO that she established in 2021 to connect ......*

- **[**Événement Exceptionnel : Rencontrez des Pionnières !** – She ...](https://shesteminafrica.com/%F0%9F%8C%9F-%F0%9D%90%84%F0%9D%90%AF%F0%9D%90%9E%F0%9D%90%A7%F0%9D%90%9E%F0%9D%90%A6%F0%9D%90%9E%F0%9D%90%A7%F0%9D%90%AD-%F0%9D%90%84%F0%9D%90%B1%F0%9D%90%9C%F0%9D%90%9E%F0%9D%90%A9/)**
  - Source: shesteminafrica.com
  - *Jul 23, 2024 ... —— Le replay est accessible ici ——. ✨ Nous avions sur le panel : – Pamela Azanfouet, Présidente de NKWANGTECH Foundation Objectif ......*

- **[Portfolio West Tech | PDF | Entrepreneuriat | Innovation](https://fr.scribd.com/document/861061676/PORTFOLIO-WEST-TECH-1)**
  - Source: fr.scribd.com
  - *May 13, 2025 ... with their continent. NKWANGTECH Foundation NKWANGTECH Foundation is an NGO which aims to ... d'idées innovantes; Mme Pamela Azanfoue...*

- **[11 days to (re)discover Women in STEM - Les GO Sciencent](https://www.lesgosciencent.com/11-days-to-rediscover-women-in-stem/)**
  - Source: lesgosciencent.com
  - *: organizations like CAYSTI, NKWANGTECH FOUNDATION, YAAPA are ... Pamela Azanfouet, Mrs. Fadimatou Noutchemo, Arielle Kitio and many more made ......*

---

*Generated by Founder Scraper*
