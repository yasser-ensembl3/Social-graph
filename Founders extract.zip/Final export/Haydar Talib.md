# Haydar Talib

## Position actuelle

**Titre** : Founder, Chief Scientist
**Entreprise** : deepreality Group
**Durée dans le rôle** : 1 month in role
**Durée dans l'entreprise** : 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Engineering Services

## Résumé

I am an AI research and product leader, and have built Voice Security AI technologies for voice authentication, fraud detection, and DeepFake detection. Securing interactions between businesses and individuals, detecting/resisting malicious use of AI technologies have been top of mind for me, helping to make people's identities safer. The technologies I've developed are deployed and provide massive value to organizations worldwide.

My experience over the past 20+ years has allowed me to bridge research, market-ready products, and enterprise customers' business needs as I developed firsthand expertise in each of these areas.

Inventor of ConversationPrint and other AI-based technologies.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACCDEABgJWP4tK0zR_Kf9H0wciWwU72dRQ/
**Connexions partagées** : 5


---

# Haydar Talib

## Position actuelle

**Entreprise** : deepreality Group

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Haydar Talib

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402330940347420673 | Text |  |  | Do you want to do a bit of science together, right here? Yes, you- YOU can do so by reading along the latest issue of the Deepfake Field Notes. 🫵 

One of the last things I did while still at Microsoft a couple months ago was to complete work on a scientific publication on how to improve deepfake detection research and technology development. 

While this might be the most information-dense article I've written, my attempt to walk through the key points of our scientific publication is intended for a broader audience. No math required, no hands-on experience training AI models. Because, as it turns out, some of the most important steps to doing research well is in how you conceptualize a problem and build the research program that will lead to robust deepfake detection technologies.

Of course, for the more technical audience members who want all the unfiltered details, you can skip straight to the article we wrote, available on arXiv, which I also link to.

"On Deepfake Voice Detection - It's All in the Presentation" provides detailed recipes on how you can apply some of the ideas on deepfake detection I've shared here in the past year. The 10 Key Ideas on Deepfakes are not just theory - they've been implemented, led to material advances in deepfake detection technology, and have been productized.

Perhaps unsurprisingly, we focus on the importance of dataset quality when building AI technologies.

Our hot take? Addressing the gap towards broader, more realistic deepfake benchmarks and training data is more impactful than training a model using the latest hot neural network architecture. | 25 | 2 | 0 | 3d | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:43.674Z |  | 2025-12-04T13:00:24.837Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397619876124651520 | Text |  |  | Even after launching this newsletter one year ago with the announcement that we, the people, cannot tell deepfakes apart from real media, I am dismayed to still find many security organizations and other groups giving advice of what you should look out for in video or audio to tell if it's a deepfake. 🤦‍♂️ 

The truth is we can't. We lost that battle at least two years ago. So what CAN you, as an individual, do to become more resilient to deepfakes?

Adapting a couple of ideas from philosopher/options trader/flaneur Nassim Nicholas Taleb (no relation), my advice boils down to returning to the old school and applying some street smarts. 

What advice would YOU would give to loved ones to help increase their resilience to deepfakes? Let me know in the comments! 👇👇👇 | 24 | 4 | 0 | 2w | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:43.674Z |  | 2025-11-21T13:00:19.599Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7392546407196409856 | Text |  |  | A colleague told me last year that I was shooting myself in the foot by announcing that the newsletter was going to cover specifically 10 key ideas on deepfakes. And indeed, once we concluded the series, it felt like we'd said everything.

But today, exactly one year after starting the original series, I'm here to announce that this newsletter goes to 11! 🤘 

The format will change, but I will still cover topics related to deepfakes and generative AI from the perspective of a practitioner in the field.

How do last year's "10 Key Ideas" hold up today? Does Sora 2 or Veo3 change anything? 🤷 

You can read the latest issue of the Deepfake Field Notes newsletter to get my retrospective, but I'd love to hear from you all! 👇👇👇 

New readers welcome!! | 56 | 6 | 0 | 1mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:43.675Z |  | 2025-11-07T13:00:10.346Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7295552903551819776 | Text |  |  | After three months of posting each Key Idea on (audio) deepfakes in its own article, at last you have all 10 Key Ideas in one place! 🤩 

This is the most condensed form to date, so if you only have 10 minutes to spend on the topic of #deepfakes and #voice_authentication, the below article is where you should spend them! 👇 | 27 | 9 | 1 | 9mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:43.675Z |  | 2025-02-12T21:22:37.025Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7291184831449702400 | Text |  |  | "your scientists were so preoccupied with whether or not they could, they didn't stop to think if they should" -Dr. Ian Malcolm, fictional character in Jurassic Park 🦖 

This is it, the 10th and FINAL Key Idea on deepfakes.

After two months discussing the myths and merits of voice authentication, deepfakes, and spoofing countermeasures, as well as the future of our voice interactions, today we explore the final critical dimension - 

You, the people. 🫵

Shouldn't you have a say on whether your voice (or other personal data) can be used for authentication or any other AI technology?

Read this week's article to find out! 👇 

While this officially completes the full list of 10 Key Ideas, we will probably be back in the near future with a couple of follow-up articles to round things out. As always, please let me know your thoughts or if you had any questions! | 15 | 5 | 1 | 10mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:43.676Z |  | 2025-01-31T20:05:27.481Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7285748496069001217 | Text |  |  | We've just spent two months going deep into the technology behind #voice_authentication and #deepfakes, and how we can all manage in a post-generative AI world.

But who is actually making phone calls anymore? Is this even relevant, or is voice about to become totally obsolete? 😵‍💫 

I've invited my colleague Cliff Mann to guide us through his investigations into these questions, and hope you will find his summary as thought-provoking and insightful as I have. Please let Cliff know what you think in the comments below! 👇 | 25 | 3 | 0 | 10mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.809Z |  | 2025-01-16T20:03:24.124Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7283187757500268545 | Text |  |  | It's a new year and we are back on schedule with this series, presenting our 10 Key Ideas on Deepfakes. Today's article comes courtesy of my colleagues Tim Savage and Simone Onizzi, who introduce a framework for how organizations can go about evaluating voice authentication systems when it comes to #deepfakes.

This week's entry marks the 7th article in the 10-part series. 🤩 

Have we been covering the actual key concerns you have around audio deepfakes? Please keep your suggestions coming, and let me know either in the comments below or via PM if you'd like to see a certain angle covered. 🫵 | 25 | 3 | 0 | 10mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.809Z |  | 2025-01-09T18:27:56.473Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7275553274819170306 | Text |  |  | I want to thank you for joining us on this odyssey over the past few weeks, as we went in-depth into all the ways we can defend against audio #deepfakes, and how #voice_authentication plays a key role therein.

But we haven't yet asked *who* is building the #deepfake technologies? And *how* are they being built? 🤔 

For this week's entry, we share 3 recommendations on how anyone building generative voice AI technology can do so more safely, aiming to minimize harmful misuse of their work. 🧙‍♂️ 

If you or anyone you know works on #synthetic_speech #deepfakes, please let us know in the comments what you think of our recommendations. 👇 

Would you implement our suggestions? Do you have other ideas on how to build #generative_AI more safely?

This is the last post of 2024, so I will also wish everyone HAPPY HOLIDAYS. 🎄

We'll be back in early 2025 with the four remaining Key Ideas on Deepfakes. | 27 | 5 | 0 | 11mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.810Z |  | 2024-12-19T16:51:13.960Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7274431871558553601 | Text |  |  | One more tangent before we get back to the key ideas on Deepfakes (number 6 is coming next). #NeurIPS2024 was a lot to take in, so here is just a very small summary of some parts. Other takeaways specific to voice authentication or deepfakes will percolate into future articles in this series. | 12 | 0 | 0 | 11mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.811Z |  | 2024-12-16T14:35:10.588Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7272958453441085440 | Text |  |  | Do you only have 5 minutes? That's all you need to read this week's post, which summarizes the first 5 Key Ideas on Deepfakes I shared over the past several weeks.

You can dive into the long-form articles for any of the Key Ideas that interest you!

Thought I'd prepare something a little different for this week's entry while I attend #NeurIPS2024 (more on this in future articles). | 25 | 0 | 1 | 11mo | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.812Z |  | 2024-12-12T13:00:20.334Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7270511653979394048 | Text |  |  | For this article I’m joined by Héctor Delgado as co-author. This completes a mini-trilogy of key ideas around the technologies  that can help keep us safe against deepfakes, and what researchers and technologists need to do to build those technologies safely and effectively. 🚨
 
Today we tear down the state of deepfake detection research over the past few years, calling out inadequacies in the datasets used to develop these technologies. 🫣 

The key message is it’s all about trying to be as realistic as possible in the data. ⚡ 

While we’re at it, we also have a few scathing comments about recent press coverage of deepfakes. 👈 

#voice_authentication #deepfakes #fraud #AI

Read below for more, subscribe to the newsletter, and please let us know what you think in the comments. 👇 | 32 | 1 | 0 | 1yr | Post | Haydar Talib | https://www.linkedin.com/in/haydar-talib-228a302 | https://linkedin.com/in/haydar-talib-228a302 | 2025-12-08T06:15:45.813Z |  | 2024-12-05T18:57:37.883Z |  |  | 

---



---

# Haydar Talib
*deepreality Group*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Talk:Haydar - Wikipedia](https://en.wikipedia.org/wiki/Talk%3AHaydar)
*2024-01-29*
- Category: article

### [Interview with Talal Bayaa, CEO & Co-Founder of Bayzat](https://www.youtube.com/watch?v=jSkpmh8xQ90)
*2024-03-04*
- Category: video

### [Our Smart Glasses Future, According to Xreal | Haystack News](https://www.haystack.tv/v/smart-glasses-future-xreal)
*2024-12-04*
- Category: article

### [Sufism in the Modern World - Special Issue of 'Religions' ...](https://www.academia.edu/121833483/Sufism_in_the_Modern_World_Special_Issue_of_Religions_2024_)
- Category: article

### [LA ROCCA DI PIEVE DI GUSALIGGIO – Valmozzola](https://www.valcenoweb.it/2020/03/10/conoscere-il-nostro-appennino-la-rocca-di-pieve-di-gusaliggio-valmozzola/)
*2020-03-10*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
