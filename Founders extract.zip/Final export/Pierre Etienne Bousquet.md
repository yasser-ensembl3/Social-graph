# Pierre Etienne Bousquet

## Position actuelle

**Titre** : President and Co-Founder
**Entreprise** : Thirdbridge
**Durée dans le rôle** : 14 years 2 months in role
**Durée dans l'entreprise** : 14 years 2 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Third Bridge se spécialise dans le développement de logiciels multi-plateformes.

Nous travaillons à titre de partenaire d’innovation avec des entreprises d’ici afin de les accompagner dans la concrétisation de leurs projets numériques les plus avant-gardistes.

Voici certaines réalisations:

Couche-Tard : Faciliter la fidélisation à travers une plateforme moderne et accessible
Desjardins : Multiple projets de recherche et développement
Prélib : Mise en place d’une plateforme numérique automatisée de dépistage autonome des ITSS

## Résumé

I co-founded Third Bridge in 2012 in order to tackle a growing market; mobile applications. Besides the technology, at its core, Third Bridge is a people-first company that strives to create the best culture and work environment for all its team members. Throughout the years, Third Bridge has built a growing expertise in the web and mobile industry and now serves global clients to deliver their innovation projects into the hands of millions. I am driven by innovation, people, and learning opportunities.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA0HBNMB6d4N1WCMbqxIzbqgLWaVmY9RnM8/
**Connexions partagées** : 107


---

# Pierre Etienne Bousquet

## Position actuelle

**Entreprise** : Thirdbridge

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pierre Etienne Bousquet

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7387530057130483712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGwpY_9vF98BQ/feedshare-shrink_800/B4EZoXHXfnIIAo-/0/1761324417548?e=1766620800&v=beta&t=tTWqJ1cYi1nOWeJBWyLBs5zK3_7cjtGG_gxQfrc70u8 | L'OQLF est débarqué chez nous!

J'anticipais cette rencontre autant que mon prochain traitement de canal.
Notre nom d'entreprise est anglo, nos outils de travail sont en anglais, nous avons de plus en plus de talents anglophones dans l'entreprise…

J'étais prêt : la machine à café et à popcorn avec les mots anglos biffés.

Nos bean bags avec notre logo (anglo) étaient cachés dans le coin, mon Gmail, HubSpot, etc. changés au français. Bring it on l'OQLF.

En vrai, deux dames super sympathiques débarquent. 👯 

Elles nous demandent de voir nos outils de travail, nous expliquent les requis du gouvernement pour être certifiés, et nous proposent un plan… relativement simple pour ajuster 2-3 éléments dans l'entreprise avec 12 mois pour exécuter ces changements.

Une expérience pas si pire, des gens fair qui ont utilisé leur gros bon sens.

La question qui me reste en tête : une fois que cette police de la langue aura estampé « Solutions numériques Thirdbridge » comme certifié et que nous allons ressortir nos bean bags et reprendre notre Gmail dans la langue de notre choix, quel type d'impact l'OQLF a réellement pour les petites entreprises du Québec?

C'est un rendez-vous dans 3 ans l'OQLF ✌️ | 70 | 12 | 0 | 1mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:45.458Z |  | 2025-10-24T16:46:59.291Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7377450169254035456 | Article |  |  | Vous êtes en tech? Vous avez du sang? 

Venez à notre événement - La tech dans le sang. 🩸 

Après notre collecte de sang, Thirdbridge, Workleap, et Héma-Québec vont parler de leurs expériences à bâtir des produits numériques d'impact.

https://lnkd.in/esp-7gaS | 6 | 0 | 0 | 2mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:45.459Z |  | 2025-09-26T21:13:06.746Z | https://www.eventbrite.ca/e/la-tech-dans-le-sang-tickets-1665325937709 |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7373758876426448896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHn13DmMYYgOg/feedshare-shrink_800/B4EZlTanxAIUAg-/0/1758041112462?e=1766620800&v=beta&t=qYXCL9g0yfVD0n52_NJtqKFMDl_vpsMr1oMrQXTV1mA | Avez-vous déjà manqué de sang? 🩸 

Non? Moi non plus.

C’est grâce à Héma-Québec, qui s’acharne à maintenir les réserves de sang du Québec bien remplies.

Ils nous appellent, nous envoient des courriels… et aujourd’hui, c’est moi qui vous sollicite pour une journée de don de sang organisée par Thirdbridge et Workleap.

C’est important, et c’est facile!

Venez faire votre tour au Nordelec, on vous attend en grand nombre! | 31 | 3 | 0 | 2mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:45.459Z |  | 2025-09-16T16:45:13.955Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7366924895550713857 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH4G2xyR3AxGg/feedshare-shrink_2048_1536/B4EZjyTJt_IUA0-/0/1756411764528?e=1766620800&v=beta&t=cNwfFCrcXEuqBkyiCuDyrrXCzoHGLQwp1mhExyFia4c | My team told me they didn’t really know what I did in a day…

Fair feedback - and I wanted to do something about it.

How do you explain a typical day in the shoes of a company president?

Every day is different: challenges, meetings, client calls, team lunches… no two are the same.

My solution: I started an Instagram account where I vlog my days and share what I’m working on with the team.

The feedback so far has been unanimous:
 “This is great!”
 “We love your updates.”
 “We finally understand what you do!” 😄

It’s been a simple way to bring more transparency to the team.

How do you keep your team aware of your work as a CEO/leader? | 74 | 7 | 0 | 3mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:45.460Z |  | 2025-08-28T20:09:25.945Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7358163445508177922 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPlOIzOKSDzA/feedshare-shrink_800/B4EZh1yqdOGcAo-/0/1754322872538?e=1766620800&v=beta&t=ccpxKbXHd-4zT-K11wbJYAESqWUIztdHejpDGuczS_I | A great user experience often starts before users even see your product.

When login is seamless, secure, and scalable -> everyone wins.

We recently helped a client redesign their onboarding flow using Okta’s CIAM platform. The result?

✅ One-click login
✅ Fewer support tickets
✅ Happier users
✅ Faster time-to-value

Customer Identity (CIAM) isn’t just a backend concern.
It’s a core part of your user experience strategy

Done right, tools like Okta become invisible to the user and that’s exactly the point.

We are proud to annonce our partnership with Okta, working to make products that users truly love. | 31 | 1 | 0 | 4mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:45.460Z |  | 2025-08-04T15:54:33.475Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7324072445517119488 | Video (LinkedIn Source) | blob:https://www.linkedin.com/14da7c7e-8219-4319-a288-92dd5931c152 | https://media.licdn.com/dms/image/v2/D4E05AQHRpwIPcZgS1w/videocover-low/B4EZaRVBeFHoCE-/0/1746194937796?e=1765782000&v=beta&t=ua615l_cc9MSCYFLjZemnIy-SM2gxZJdtw5W_WXb9Uo | We build apps that users truly love. 💙

We’re excited to unveil our brand refresh — a bold statement of the quality Thirdbridge brings to every project.

Proud doesn’t even begin to describe how it feels to be part of a team that consistently pushes for excellence.

Planning your next app?
Look no further than Thirdbridge. | 39 | 0 | 1 | 7mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.847Z |  | 2025-05-02T14:09:05.697Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7320118504639156224 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGBYQw1-VXh0w/feedshare-shrink_800/B4EZZZI6BTHYAg-/0/1745252249811?e=1766620800&v=beta&t=FKcHYXBwc4lK905pTSaYpRaLzWlwVLviNn3TZgxchMM | Pro sport is changing FAST

During my conversation with Éric Gagné, we discussed how technology is reshaping the Major League Baseball (MLB) and the sport of baseball in general.

Is it all good? Nope!

From cheating techniques to data science, AI, and online betting, fans, players, coaches, and umpires are exposed to new realities and exciting new perspectives.

Some don’t want change. Some love it.

Just like with any software, you need to talk to your end user. It’s the only way!

Eric said it best:
👉 “MLB needs to talk to its fans. Lose your fans, and you’re done.”

That’s proper UX at its core!

Listen to Product Misfire’s latest episode with a baseball legend. ⚾ 🏆 | 39 | 1 | 0 | 7mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.848Z |  | 2025-04-21T16:17:32.731Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7308138809106313216 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7c5ef876-a42d-44b9-af48-415304fac50d | https://media.licdn.com/dms/image/v2/D4E05AQEdfmBv3o73kA/feedshare-thumbnail_720_1280/B4EZWuZHywHMBA-/0/1742387578588?e=1765782000&v=beta&t=EJrPfvbbO0EzQN6NXocjvXYzAUBr1Ji1mQ1mNOwc4Dg | Nul autre que TechNic sera sur scène! À ne pas manquer 🗓️ | 7 | 0 | 0 | 8mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.849Z |  | 2025-03-19T14:54:30.744Z | https://www.linkedin.com/feed/update/urn:li:activity:7308103333163003904/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7307445405561114625 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7d789f1e-1d2d-453b-936b-0e1bc57dafac | https://media.licdn.com/dms/image/v2/D4E05AQGpj5iITdAU4w/feedshare-thumbnail_720_1280/B4EZWlCyJZG0A8-/0/1742230726480?e=1765782000&v=beta&t=Z1qv0VcY9e-nZosX6TqV2E5mH2XDCO6ASlyKqOeaXN8 | Providing exceptional veterinary care is at the heart of Vet et Nous’s mission, and Thirdbridge is proud to have supported them on this journey!

When we first connected with Vet et Nous, they were looking to build 
a digital solution that would help reduce communication friction between vets, emergency centers, and specialists.

Together, we implemented a conversational agent on their platform, with a well-structured management process and an automated workflow that handles frequently asked questions and redirects specific inquiries to relevant informative articles.

The result? Specialists now spend less time managing emails and calls, allowing them to focus more on what truly matters: providing the best care for animals.

This collaboration proves that with the right tools in place, it's possible to enhance both efficiency and the quality of service in the veterinary field.

A big thank you to the Vet et Nous team for their trust in this transformative solution. | 14 | 1 | 0 | 8mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.850Z |  | 2025-03-17T16:59:10.456Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7305637265332989955 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFwpgCA4_lVKQ/image-shrink_800/B4EZWLWWEMH0Ac-/0/1741799646573?e=1765782000&v=beta&t=2LoPDlLoFjZnKg2-AUQZNzPtB0iKhUiWKsdj1zGrHik | Fenplast and Thirdbridge share a common goal: delivering an outstanding customer experience.

When we first connected, Fenplast was looking for a digital partner to enhance a key part of their operations—their extranet. 

As a leading Quebec-based manufacturer of doors and windows, Fenplast is dedicated to supporting its retail partners, and their extranet plays a crucial role in streamlining order management, deliveries, and communications.

Our team delivered a web portal that enhances daily operations and strengthens relationships with their partners.

The result? Improved efficiency, simplified processes, and an even better experience for their network.

This collaboration is proof that with the right technology and a shared commitment to excellence, innovation drives real impact.

A huge thank you to the Fenplast team for their trust and dedication to providing the best client and user experience there is! | 31 | 0 | 2 | 8mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.850Z |  | 2025-03-12T17:14:16.232Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7302803283583066112 | Text |  |  | Pourquoi ne voyons-nous pas plus de magasins sans caisse comme le concept du Genius Bar d’Apple?

C’est l’une des questions qui a été soulevée dans le dernier épisode de L’Update Thirdbridge, où Virginie et Nicolas ont échangé avec Olivier, CEO de Leav.

Les consommateurs se rendent toujours en magasin, mais leurs attentes et habitudes d’achat ont évolué. 

Les détaillants doivent s’adapter et offrir des meilleurs outils numériques pour créer une expérience d’achat fluide et unifiée. | 15 | 5 | 0 | 9mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.851Z |  | 2025-03-04T21:33:02.330Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7295125297547407360 | Video (LinkedIn Source) | blob:https://www.linkedin.com/67788032-b5db-47a7-8e28-1203af520477 | https://media.licdn.com/dms/image/v2/D4E10AQGgRoIFebbduw/ads-video-thumbnail_720_1280/B4EZT19Q7xGYAY-/0/1739293287094?e=1765782000&v=beta&t=aQrF88JcdEVsbYvDGCwSpIfKrPruTID4zS9OwzsjXEY | L'idée de shipping bleu a fait pas mal réagir sur le TikTok de L'Update Thirdbridge.

Les avis sont partagés: certains adorent le concept, d'autres soulèvent des défis intéressants.

Je serais curieux de savoir ce que les gens sur LinkedIn en pensent. | 36 | 2 | 0 | 9mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.852Z |  | 2025-02-11T17:03:27.809Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7292538459070607361 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQH3mpHXaj8bJw/image-shrink_800/B4EZTRNCroGwAg-/0/1738676647147?e=1765782000&v=beta&t=milD7gCjpg9Outl8LuA56w3wCzLut_cWQyyg2GBFkTU | Back in 2012, we were building apps because everyone needed an app— even when it wasn’t always necessary…

Thirteen years ago, Nicolas and I launched Thirdbridge with our long lifelong friends Louis and Julien.

Today, Thirdbridge is much more than a development shop. From digital strategy and design to development and maintenance, we’ve managed to build a team of passionate tech experts dedicated to creating the best digital experiences for our clients and their users.

But one thing has never changed: my obsession with building useful applications—ones that provide real value and that people actually use.

Technology matters if it serves a real need or solves a real problem. 

And that will always be true. | 105 | 8 | 1 | 10mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.852Z |  | 2025-02-04T13:44:17.455Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7290379495285420032 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQG_qOK7FlHDEw/image-shrink_800/B4EZSyhffMGgAg-/0/1738161912653?e=1765782000&v=beta&t=mOGVjxrC4msCA4x_EzctOYIilss9h9mpa8BLSoemb4U | Modernizing an old-school industry starts with the right MVP. 

In the latest episode of Thirdbridge's podcast Product Misfires, I had the pleasure of speaking with Daniela Santangelo, founder of Freeway and former founder of Shyft.

Shyft built a CRM-powered logistics platform used by 300+ moving companies in more than 50 countries, proving that even the most resistant industries can be transformed with a well-executed MVP.

But disruption isn’t easy—scaling digital products in traditional markets comes with unique challenges. 

Daniela shares how she navigated these challenges and now helps startup founders succeed using insights from her journey.

Catch the full episode to hear her story. Link in the comments. | 53 | 3 | 0 | 10mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.853Z |  | 2025-01-29T14:45:20.377Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7288550392508874753 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b7a00b3e-716e-4d90-8100-a3ae3f6b13db | https://media.licdn.com/dms/image/v2/D4E05AQHoPr6Md4PgMA/feedshare-thumbnail_720_1280/B4EZSYhl9zGwA8-/0/1737725733813?e=1765782000&v=beta&t=mXl0B1oqvjGBgSXNu_8SaR2lD6HG3FyQiv0pw5bdu3k | Here’s the story behind how Pierre-Charles Jolicoeur decided to create his own digital solution to offer a customer experience like no other.

When we first met, PC was looking for a digital partner to bring his vision to life: a web application for his mortgage brokerage team that would elevate the customer experience throughout the entire mortgage journey, from application to renewal and beyond.

From our very first discussions, it was clear that our vision and work ethics were perfectly aligned. 

Together, Thirdbridge and JA Hypothèques designed a custom web platform for brokers, enabling them to provide a personalized and unique service to each of their client. 

With this application, they now have access to a wealth of key insights and specific statistics, making it easier to manage and track client files through times. 

The result: significant time savings and an optimized customer experience.

Our partnership with JA Hypothèques is proof that with the right tools and a trust-based collaboration, a fast return on investment is not just possible—it’s guaranteed.

A huge thank you to PC and his entire team for their vision and commitment to this on-going project. | 34 | 0 | 1 | 10mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.854Z |  | 2025-01-24T13:37:08.292Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7284562973518364672 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d8e2ccff-eeac-4815-b849-c4434f4ad06b | https://media.licdn.com/dms/image/v2/D4E10AQFWytp1Gcmq_g/ads-video-thumbnail_720_1280/ads-video-thumbnail_720_1280/0/1736775032784?e=1765782000&v=beta&t=plpx7vx8EiS_f-fMqyaDTwXUOfDmMQYbLHzd_tvlgMo | What’s next for CleanTech innovation?

That's what I discussed with Jay Foster, founder of Carbon Utility and Kris Saunders, founder of Extend EV on my podcast Product Misfires. 

Together, we explored how cutting-edge sustainable energy solutions are driving the evolution of CleanTech in America.

At Thirdbridge, we put effort to incorporate sustainable practices into our use of technology. Creating a podcast episode about people who share those values—and who also use tech to make a direct environmental impact—was important to me.

Listen now on Spotify, Apple Podcasts, or YouTube. The link is in the comments. 👇 | 40 | 2 | 0 | 10mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.855Z |  | 2025-01-13T13:32:33.522Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7283191589793873920 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGB1weEuUz8rw/feedshare-shrink_800/B4EZRMYKEEHsAk-/0/1736448189275?e=1766620800&v=beta&t=sUdbQbwWhlhzvFY_mFJdX2RCiHbQH7OR9al1DbBfkJI | Our team at Thirdbridge has identified the 25 key trends to take your app's development projects to the next level in 2025.

From content personalization to immersive experiences, enhanced security, and simplified payments, these innovations are crucial for staying competitive.

Each trend is an opportunity to optimize customers' experience, improve operational efficiency, and maximize ROI.

Read the full article to gear up your app for what’s next.👇
https://lnkd.in/es_bmjuP | 22 | 2 | 0 | 10mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.855Z |  | 2025-01-09T18:43:10.163Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7274467943088885760 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6af7ea59-76df-481d-938e-6218e0fcb760 | https://media.licdn.com/dms/image/v2/D4E05AQGHt3scvdcS1g/videocover-high/videocover-high/0/1734368300374?e=1765782000&v=beta&t=OUquG8XU75VjAB91jtVX8l2M6l3PB1bu7xBjRoDOUfI | Good or bad? Your team is poking fun at your vision. 🤔 

Could this be a telltale sign that your message is resonating?

They understand what you’re trying to achieve but might still hesitate to commit fully.

David Berg from Redirect Health shares that, in his experience, this moment often comes right before the team fully embraces the vision as their own.

A great episode of Product Misfires! Truly inspiring entrepreneur. | 27 | 1 | 0 | 11mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.856Z |  | 2024-12-16T16:58:30.711Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7271859891999326210 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3da89f8e-a535-4d22-9589-aaf5e5895409 | https://media.licdn.com/dms/image/v2/D4E05AQE0-NJ6PdUqjA/videocover-high/videocover-high/0/1733715004850?e=1765782000&v=beta&t=ZEfj90LsLkZ744pqMzwrCYXtp_TMTe2bDU9GnIy0BSE | 6 years ago, I got to sit down with finance guys who were not ALL ABOUT MONEY

Michael and Maxime were talking about their project to create wealth for their customers by being fully TRANSPARANT.

They are an actual NFP! Brokers not trying to squeeze their big fees to get rich, but rather work their a**** off to offer amazing customer experience and try to make their client’s wealth projects come to reality.

Working with them on the FÉRIQUE app has been an absolute privilege and a powerful lesson: putting your customers at the center of EVERYTHING is the real path to creating value. | 31 | 0 | 0 | 11mo | Post | Pierre Etienne Bousquet | https://www.linkedin.com/in/pebousquet | https://linkedin.com/in/pebousquet | 2025-12-08T06:12:49.857Z |  | 2024-12-09T12:15:02.876Z |  |  | 

---



---

# Pierre Etienne Bousquet
*Thirdbridge*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 11 |

---

## 📚 Articles & Blog Posts

### [How to Succeed in Mobile App Development in 2025](https://www.thirdbridge.ca/en/blog/mobile-app-development-guide-2025)
- Category: blog

### [Why Is Building an App So Expensive?](https://www.thirdbridge.ca/en/blog/mobile-app-expensive)
- Category: blog

### [Ratings & Reviews: Their Impact on an App's Success](https://www.thirdbridge.ca/en/blog/2078b043-df0f-5236-8988-38a0ca64a4a7/)
*2025-03-31*
- Category: blog

### [CMS for your mobile app?](https://www.thirdbridge.ca/en/blog/5244b58d-96e5-543c-abe5-173def20f67f/)
*2025-04-04*
- Category: blog

### [Thirdbridge | The Ultimate Podcast for Challenges and Insights on Software Products](https://www.thirdbridge.ca/en/podcasts/product-misfires/S01E03)
*2025-01-01*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Contact - About us - Thirdbridge](https://www.thirdbridge.ca/en/it-company/contact)**
  - Source: thirdbridge.ca
  - *Pierre-Étienne Bousquet · pe@t-b.ca. Virginie. Marketing Director. Virginie ... copyright Thirdbridge ©2025. All rights reserved....*

- **[Les Dérangeants | QUB | QUB radio](https://www.qub.ca/balado/les-derangeants/saison6)**
  - Source: qub.ca
  - *... podcast Les Dérangeants ... Carlo Coccaro, accompagné de l'incontournable Étienne Crevier, accueille Pierre-Étienne Bousquet, PDG de Thirdbridge....*

- **[About us - Thirdbridge](https://www.thirdbridge.ca/en/it-company)**
  - Source: thirdbridge.ca
  - *The Thirdbridge team unites its forces around a common goal ... In 2012, Pierre-Étienne Bousquet and Nicolas St-Aubin, both old friends and ......*

- **[Hypergrowth business strategies podcasts for 2021 - J7 Media](https://www.j7media.com/en/our-hypergrowth-podcasts)**
  - Source: j7media.com
  - *This week, we interview Pierre-Étienne Bousquet, President and co-founder of Thirdbridge. Listen to the podcast · Listen to the podcast. Ep.322 - The ...*

- **[Why Is Building an App So Expensive? - Thirdbridge](https://www.thirdbridge.ca/en/blog/mobile-app-expensive)**
  - Source: thirdbridge.ca
  - *Thirdbridge in La Presse: Vision and Growth. Our President and Co-Founder, Pierre-Étienne Bousquet, was recently the guest of Camille Dauphinais-Pelle...*

- **[Hypercroissance et développement d'entreprise - Notre Podcast - J7 ...](https://www.j7media.com/fr/podcast-hypercroissance)**
  - Source: j7media.com
  - *Dans cet épisode du podcast Hypercroissance, Antoine Gagné partage comment son podcast ... Pierre-Étienne Bousquet, président et co-fondateur de Third...*

- **[Couche-Tard Connecté: The Cashierless Convenience ... - Thirdbridge](https://www.thirdbridge.ca/en/blog/735f4fa1-8250-55a2-b49d-2d820483768a)**
  - Source: thirdbridge.ca
  - *Thirdbridge in the spotlight: L'Arrière-Scène's digital partner ... Our president and co-founder, Pierre-Étienne Bousquet, discussed with Jean ......*

- **[Ep.85 - Alexandre & Nicolas St-Aubin : Les succès & échecs de la ...](https://www.youtube.com/watch?v=pCY8F_hsraE)**
  - Source: youtube.com
  - *May 9, 2024 ... ... podcast qu'on aime bien — L'Update. Thirdbridge c'est presque 60 ... Pierre Etienne Bousquet https://www.linkedin.com/in/pebousque...*

- **[CMS for your mobile app? - Thirdbridge](https://www.thirdbridge.ca/en/blog/5244b58d-96e5-543c-abe5-173def20f67f)**
  - Source: thirdbridge.ca
  - *Apr 4, 2025 ... Thirdbridge in La Presse: Vision and Growth. Our President and Co-Founder, Pierre-Étienne Bousquet, was recently the guest of Camille ...*

- **[What is Third Bridge (Canada)? Company Culture, Mission, Values ...](https://www.glassdoor.ca/Overview/Working-at-Third-Bridge-Canada-EI_IE2113844.11,30.htm)**
  - Source: glassdoor.ca
  - *At Thirdbridge, our vision is to prove that the best working conditions will ... Pierre Etienne Bousquet. 83% approve of CEO. Companies can't alter or...*

---

*Generated by Founder Scraper*
