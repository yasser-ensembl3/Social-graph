# Abigail Hirsch

## Position actuelle

**Titre** : Founder
**Entreprise** : AskAbigail Productions
**Durée dans le rôle** : 15 years 11 months in role
**Durée dans l'entreprise** : 15 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Independent filmmaker and blogger

## Résumé

Abigail Hirsch is a film producer, blogger, and founder of AskAbigail Productions. She holds a BA in Jewish history and English literature from the Hebrew University of Jerusalem and an MSW from Yeshiva University in New York City. Based in Montreal, Abigail actively covers Jewish events both locally and internationally, fostering dialogue to promote peace and deepen understanding of Jewish culture and society.

In 2014, she released her feature-length film, Yiddish: A Tale of Survival, which was screened at numerous national and international film festivals and aired on PBS. Abigail remains a passionate advocate, dedicated to combating misinformation about Jewish communities and making a lasting impact through her work.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAg_1dsB6zTLA0rxQK161xQeVbc9CC-0H4k/
**Connexions partagées** : 1


---

# Abigail Hirsch

## Position actuelle

**Entreprise** : AskAbigail Productions

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Abigail Hirsch

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403419989019500545 | Article |  |  | A great article about the BBC today 
Can it be reformed? What do you think? | 0 | 0 | 0 | 17h | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.379Z |  | 2025-12-07T13:07:54.274Z | https://substack.com/@askabigail/note/c-185160540?r=24cbn9&utm_medium=ios |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401254837104975872 | Article |  |  | WATCH: Groundbreaking medical research from Israel
Potential
Treatment for Alzheimer’s and MS 

https://lnkd.in/eCYDK_ec | 0 | 0 | 0 | 6d | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.380Z |  | 2025-12-01T13:44:21.831Z | https://k0osz.app.link/R7xALL6VJYb |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401246267143659520 | Article |  |  | WATCH: Former Qatari PM admits paying off journalists and media members

https://lnkd.in/eEWSV9vq

Straight from the horses mouth 
Corrupt Quatari journalists | 0 | 0 | 0 | 6d | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.380Z |  | 2025-12-01T13:10:18.593Z | https://k0osz.app.link/fTGjRtvVJYb |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401239350384168962 | Text |  |  | https://lnkd.in/epdJ-Ra6 | 0 | 0 | 0 | 6d | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.381Z |  | 2025-12-01T12:42:49.509Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7401232239260291072 | Article |  |  | https://lnkd.in/emMVp9GJ

This just in 
New law proposed to disqualify members of congress not born in the US | 0 | 0 | 0 | 6d | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.381Z |  | 2025-12-01T12:14:34.085Z | https://www.facebook.com/share/p/1KT8jJ7k8o/?mibextid=wwXIfr |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7401194592991191041 | Article |  |  | We have all known this for years re
Dr Mengele the angel of death in Auschwitz, 
But now it has been proven from the archives released by president Milei of Argentina he was known to authorities and living a carefree life in Buenos Aires and Paraguay 



*Bombshell declassified docs reveal Nazi ‘Angel of Death’ was allowed to live carefree life after Auschwitz horrors: docs*

A Nazi doctor known for barbaric prisoner experiments and handpicking gas chamber victims led a carefree post-war life in Argentina – despite authorities knowing his true identity, declassified documents revealed..

Coldblooded SS Commander Josef Mengele aka “The Angel of Death” gleefully oversaw the horrific torture of Jews and other prisoners at Auschwitz concentration camp under the guise of medical research before he fled Germany for Argentina in 1949.

He escaped justice under an assumed name just as the Nuremburg trials exposed his crimes.

Bombshell intelligence files, recently declassified by Argentinian President Javier Milei, detail how Argentinian authorities tracked Mengele’s life across South America but never apprehended him, Fox News Digital’s Solly Boussidan reported.

The then Argentinian government was known for harboring Nazis, and allowing an underground community to prosper, according to Reuters. Surveillance reports, immigration records, and intelligence briefs paint a picture of fractured law enforcement efforts, which the twisted Nazi doctor was able to evade.

Mengele entered Argentina to begin in 1949 with an Italian passport under the name Helmut Gregor. There, he began a new life.

By the mid 1950s, documents prove Argentinian authorities knew the ‘Angel of Death’ was among them, according to an-depth analysis of the Spanish language records by Fox.

Newspaper clippings in the file include a chilling undated interview with one of Mengele’s victims, José Furmanski.

“He gathered twins of all ages in the camp and subjected them to experiments that always ended in death. Between the children, the elderly, and women… what horrors,” Furmanski said in the interview.

In 1956, Mengele requested his original birth certificate from the West German Embassy in Buenos Aires and had shockingly begun using his real name, requesting identification cards be reprinted.

A memo written by officials a year later says Mengele “explained” why he originally entered Argentina under a fake name.

“He (Mengele) demonstrated being nervous, having stated that during the war he acted as a physician in the German S.S., in Czechoslovakia, where the Red Cross labeled him a ‘war criminal,’” read the memo.

Argentine agencies knew Mengele lived in Carapachy, a town on the outskirts of Buenos Aires….

In 1959, West Germany issued an arrest warrant for Mengele, requesting his extradition, but a local judge denied the warrant, saying it was based on “political persecution.”

. 
https://lnkd.in/eeZi9sCM

‎Open this link to join *CBN UNFILTERED*:
 https://lnkd.in/ec4Kjhnp | 1 | 1 | 1 | 6d | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:29.383Z |  | 2025-12-01T09:44:58.515Z | https://nypost.com/2025/11/30/world-news/declassified-docs-reveal-how-nazi-josef-mengele-was-able-to-evade-capture-in-argentina/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7401077474568273920 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0369fa69-b5c9-4b79-81f2-2439a14f3ea7 | https://media.licdn.com/dms/image/v2/D4D05AQGxf8udlVTlPg/videocover-high/B4DZrL0oBLJABU-/0/1764356163042?e=1765782000&v=beta&t=4d0dm9Ut99RHKDYKM6YJifbeVzb4PQfmwht3oCm1gm8 | Quaradawi, the originator of the Muslim
brotherhood and his role at Oxford University bu Charles Small head of ISGAP 
The Institute for the study of governmental antisemitism and policy | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.704Z |  | 2025-12-01T01:59:35.307Z | https://www.linkedin.com/feed/update/urn:li:activity:7400246151771447297/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7401074859168133120 | Text |  |  | https://lnkd.in/eB7USddb | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.706Z |  | 2025-12-01T01:49:11.747Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7401074172698836992 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGbKYRZBRQAyw/feedshare-shrink_2048_1536/B4DZrVpkDfGkAw-/0/1764521034825?e=1766620800&v=beta&t=Py1iJZthl6YaCGqb3Qi9SJO0XhrMdBpNaL6R4e3iWeg | Please repost this many times 
All good people must be alerted 
Brodie Fenlon 
Jayme Poisson 
CBC/Radio-Canada 
CBC | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.706Z |  | 2025-12-01T01:46:28.080Z | https://www.linkedin.com/feed/update/urn:li:activity:7400937639664820225/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7401073524712345601 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEBE30vL5LSgw/feedshare-shrink_800/B4EZrU2MEUIoAg-/0/1764507570449?e=1766620800&v=beta&t=42UMISpxxT5Km0NZ5cIG3Ed3xBJLXmmVBfx1zDKryw0 | This is horrifying and must be stopped legally | 3 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.707Z |  | 2025-12-01T01:43:53.588Z | https://www.linkedin.com/feed/update/urn:li:activity:7400881166985367552/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7401034828953014272 | Article |  |  | Collell. Chabad charities help families with food year around | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.708Z |  | 2025-11-30T23:10:07.800Z | https://www.instagram.com/p/DRQGLpZgNoP/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7401034223450603520 | Article |  |  | Leonard Cohens Yiddish soul coming to light | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.708Z |  | 2025-11-30T23:07:43.437Z | https://www.instagram.com/reel/DRIsKWykVsi/?igsh=ZXZ3c3JnMmprbndz |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7401032821886066688 | Article |  |  | Germany prepares to ban Muslim Brotherhood activity on its soil
Just in case you havn’t heard the latest news!

https://lnkd.in/eiU4x7sg | 1 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.708Z |  | 2025-11-30T23:02:09.278Z | https://k0osz.app.link/xr42cNMfIYb |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7400983061330370560 | Article |  |  | Mohammad the first Islamic prophet 7 th century CE 
Israel mentioned in the land of Canaan 3000 years ago | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.709Z |  | 2025-11-30T19:44:25.437Z | https://www.instagram.com/reel/DRpiZ8pDKDU/?igsh=eHcwN2NsbnE1Nm9p |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7400976073376550912 | Article |  |  | NEWSRAEL LIVE UPDATES - Nov. 30, 2025

https://lnkd.in/engCqzmf

Live updates daily from newsreal, a Christian proisrael news source that anyone can sign up for - free | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.709Z |  | 2025-11-30T19:16:39.379Z | https://k0osz.app.link/fB6p3zxtIYb |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7400919333356445700 | Article |  |  | ICYMI: WATCH Trump: If Hamas doesn’t disarm, US will do the job ‘quickly and perhaps violently’



https://lnkd.in/e_DFMqwC | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.709Z |  | 2025-11-30T15:31:11.504Z | https://newsil.page.link/aeUDnYfvcqwn2rkF9 |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7400882601114169345 | Article |  |  | Everyone can do this! | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.710Z |  | 2025-11-30T13:05:13.855Z | https://middle-east-forum.quorum.us/campaign/designate-cair |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7400157707179302912 | Article |  |  | WATCH: The 100 year plan to Islamize the West

https://lnkd.in/ep7ER2cH | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.710Z |  | 2025-11-28T13:04:45.673Z | https://k0osz.app.link/HNFFk7p7EYb |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7400141353537552384 | Video (LinkedIn Source) | blob:https://www.linkedin.com/72de04bb-749d-40f1-b24a-760e16036425 | https://media.licdn.com/dms/image/v2/D4D05AQF0cOxDa6pbdg/videocover-low/B4DZrEd6KUHsBQ-/0/1764232768531?e=1765782000&v=beta&t=72ebNlKrMgXjTMYsmpMQ3Y0wTxLK7HL9oU9ovOgPebU | About how social media flipped the narrative on important platforms - we are all of us on this learning curve 
Important to understand as was said in the past 
By Mark Twain; A lie circles the world before truth can get his pants on! | 2 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.711Z |  | 2025-11-28T11:59:46.661Z | https://www.linkedin.com/feed/update/urn:li:activity:7399728704848998400/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7399871504244449280 | Text |  |  | Gal Gadot explains it all to you! 
She is an Israeli Jew and a Hollywood actress - the star of Superwoman | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.711Z |  | 2025-11-27T18:07:29.576Z | https://www.linkedin.com/feed/update/urn:li:activity:7267326836055891969/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7399870050280718336 | Text |  |  | And this is what Putin is saying to his people according to Israeli news 

Putin: We are in an armed conflict with Ukraine, but we  held regional elections and a presidential election during it. "For some reason" they did not do so

*News Center>>*
https://lnkd.in/eVkZ4HSt | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.712Z |  | 2025-11-27T18:01:42.924Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7399869606519267328 | Text |  |  | Here is what the leader of Iran, Khaminai is saying to his people as reported by Israeli news link below 

More gems from Khaminai "the one who is up  to date on everything that's happening": The casualties  inflicted on the enemy in the war were much greater than the casualties inflicted on our country. We also suffered casualties, of course - but the one who started the attack got it many times over

*News Center>>*
https://lnkd.in/eVkZ4HSt | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.712Z |  | 2025-11-27T17:59:57.123Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7399867592741449728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH98BLLMgMZJQ/feedshare-shrink_800/B4EZq6x12gJgAk-/0/1764070220233?e=1766620800&v=beta&t=BN_LbvrRu3NcVKjUB9QgJZk2F8B5vFXoQwVRiHnrCag | Check this out 
Who Mamdani appointed to deal with refugees to NYC 

Good luck New York 
Yes I know I sound prejudiced but read the article | 0 | 1 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.712Z |  | 2025-11-27T17:51:57.001Z | https://www.linkedin.com/feed/update/urn:li:activity:7399084464552960000/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7399865123525480448 | Article |  |  | Miracles happen when courage care and love come together 
Gal Gadot Superwoman Jewish American actress 
Speaking about the miracles that affected her personally when her baby and her life  was saved by doctors at Mount Sinai hospital; 8 months pregnant she was diagnosed with a brain blood clot: her baby was surgically delivered and she was operated and saved from an imminent stroke by quick action. 

Mount Sinai Hodpital in Los Angeles was built and financed  by Jews at a a time when Jews were denied medical care by Catholic hospitals because they were Jews: the same situation reigned in Montresl and that’s why the Jewish General Hodpital was established 100 years ago. 

Courage care and love are universal 

characteristics intrinsic to all mankind 
They can be called universal 

Human societies ie cultures can be compared and are not equally just or virtuous 

Our hostages who returned from captivity shared how they did It; 

When the hostages returned  after being held in Hamas captivity, what stood out was not just relief or reunion, but a profound spiritual awakening. Many survivors spoke of how their connection to Hashem, their Jewish identity, and the rituals, prayers and memories of home became their lifeline ❤️ 

✨ Want to join our status? ✨
Save our number + send “Subscribe” + your name ❤️

WhatsApp community: https://lnkd.in/emBvXZfw

 Instagram: https://lnkd.in/eX7Ap8dX

Proof text 
Essay by Frederic Alexander 
In future of Jewish 

Some cultures are demonstrably better than others 
No one want to move to Mogadishu or Biafra or Sudan 
Refugees are all risking their lives to flee to Europe, the US and Canada 


Rabbi Dee spoke in Montreal | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.714Z |  | 2025-11-27T17:42:08.294Z | https://x.com/taligoldsheft/status/1993811215148290243?s=56 |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7399784589709225985 | Article |  |  | A wonderful new tune to an old classic Shabbat table hymn Baruch Kel Elyon - blessed is the Lord of the world who has given us the the gift of the Sabbath | 0 | 0 | 0 | 1w | Post | Abigail Hirsch | https://www.linkedin.com/in/abigail-hirsch-38b4253a | https://linkedin.com/in/abigail-hirsch-38b4253a | 2025-12-08T06:15:32.714Z |  | 2025-11-27T12:22:07.536Z | https://www.instagram.com/reel/DRUdOMIjmRN/?igsh=MTFqbmk4eWR2c25xcg== |  | 

---



---

# Abigail Hirsch
*AskAbigail Productions*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Abigail Hirsch | AskAbigail Productions](https://www.askabigailproductions.com/author/abigail/)
*2024-06-11*
- Category: article

### [Tag Archives: Antisemitism in Canada - AskAbigail Productions](https://www.askabigailproductions.com/tag/antisemitism-in-canada/)
*2025-01-27*
- Category: article

### [Francisco Gil-White: Jews, Israel, Media Narratives, and ...](https://www.askabigailproductions.com/francisco-gil-white-jews-israel-media-narratives-and-antisemitism/)
*2024-07-05*
- Category: article

### [The Power of Humor: Jewish Resilience in a World of Absurdities | AskAbigail Productions](https://www.askabigailproductions.com/the-power-of-humor-jewish-resilience-in-a-world-of-absurdities/)
*2025-03-12*
- Category: article

### [The Heart of Elul: Lessons in Justice and Compassion](https://www.askabigailproductions.com/the-heart-of-elul-lessons-in-justice-and-compassion/)
*2024-10-02*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Abigail Hirsch - Biography - IMDb](https://www.imdb.com/name/nm3860479/bio/)**
  - Source: imdb.com
  - *Abigail Hirsch. Director: Yiddish: A Tale of Survival. Abigail Hirsch is a ... AskAbigail Productions, is dedicated to making high quality films that ...*

- **[Is CBC's Coverage of the Middle East War Truly Balanced?](https://www.askabigailproductions.com/is-cbcs-coverage-of-the-middle-east-war-truly-balanced/)**
  - Source: askabigailproductions.com
  - *Jul 25, 2025 ... AskAbigail Productions. Videos, Films, and Blogs. A tilted scale with ... This entry was posted in A Jewish Lens, Blog by Abigail Hir...*

- **[Francisco Gil-White: Jews, Israel, Media Narratives, and Antisemitism](https://www.askabigailproductions.com/francisco-gil-white-jews-israel-media-narratives-and-antisemitism/)**
  - Source: askabigailproductions.com
  - *Jul 5, 2024 ... ... Abigail Hirsch. Bookmark the permalink. Leave a Reply. Your email ... Copyright © 2024 AskAbigail Productions. All rights reserved...*

- **[Power, Belief, and the Stories We Tell Ourselves](https://www.askabigailproductions.com/power-belief-and-the-stories-we-tell-ourselves/)**
  - Source: askabigailproductions.com
  - *Oct 15, 2025 ... AskAbigail Productions. Videos, Films, and Blogs. Sunset skyline with ... This entry was posted in A Jewish Lens, Blog by Abigail Hir...*

- **[Unsung Heroes: Jewish Canadians Who Helped Shape Our Nation](https://www.askabigailproductions.com/unsung-heroes-jewish-canadians-who-helped-shape-our-nation/)**
  - Source: askabigailproductions.com
  - *May 24, 2025 ... This entry was posted in A Jewish Lens, Blog, Film and Theatre Reviews by Abigail Hirsch. ... Copyright © 2024 AskAbigail Productions...*

- **[A Living Memory](https://www.askabigailproductions.com/the-resilience-of-holocaust-survivors-and-their-descendants-a-living-legacy/)**
  - Source: askabigailproductions.com
  - *AskAbigail Productions. Videos, Films, and Blogs. Abigail Hirsch with her parents and her younger sister. Search. Main menu. Home; Projects in Develop...*

- **[When the World Spins: Finding Renewal Across Generations](https://www.askabigailproductions.com/forog-a-vilag-finding-meaning-in-a-spinning-world/)**
  - Source: askabigailproductions.com
  - *Oct 10, 2025 ... This entry was posted in A Jewish Lens, Blog by Abigail Hirsch. ... Copyright © 2024 AskAbigail Productions. All rights reserved. SSL...*

- **[Published Articles](https://www.askabigailproductions.com/articles/)**
  - Source: askabigailproductions.com
  - *Articles written by Abigail Hirsch that were published ... Copyright © 2024 AskAbigail Productions. All rights reserved. SSL site ......*

- **[About Us](https://www.askabigailproductions.com/about/)**
  - Source: askabigailproductions.com
  - *Abigail Hirsch, a Montreal-raised film producer and blogger, was born in postwar Hungary. She founded AskAbigail Productions to uncover untold stories...*

- **[The Story of Moshe Kraus](https://www.askabigailproductions.com/the-story-of-moshe-kraus/)**
  - Source: askabigailproductions.com
  - *The Story of Moshe Kraus. Posted on 21/07/2020 by Abigail Hirsch ... Copyright © 2024 AskAbigail Productions. All rights reserved. SSL site seal - cli...*

---

*Generated by Founder Scraper*
