# Nurra Barry

## Position actuelle

**Titre** : Programme Accélération
**Entreprise** : Centech Mtl
**Durée dans le rôle** : 3 months in role
**Durée dans l'entreprise** : 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Professional Training and Coaching

## Description du rôle

Programme d'accélération sur 12 semaines pour comprendre l'écosystème local et se lancer

## Résumé

Comment faites-vous pour intégrer les problématiques environnementales dans vos projets ?
Comment faites-vous pour gagner du temps lorsque vous dessinez derrière votre ordinateur ?  
Comment avez-vous choisi votre logiciel de dessin d'architecture ?
Comment faites-vous pour dessiner des projets réellement durables ?
Comment faites-vous pour calculer la performance énergétique de vos projets ou sélectionner un isolant bio-sourcé ?

Sachant que : 
🍃 Le bâtiment représente 40% de notre empreinte carbone
💻 Nous passons 50% de notre temps à accomplir des tâches répétitives et abrutissantes dans nos logiciels de dessin
💪 En France, nous sommes 600 000 professionnels à avoir un impact en amont des projets d'architecture et de rénovation, dont 150 000 architectes... L'union fait la force !

Conscients de ces problématiques et ces constats, nous vous proposons de rejoindre notre communauté d'architectes et de professionnels du bâtiment engagés dans la transition écologique. 

Nous nous sommes donné 1 an pour aboutir à de premières solutions concrètes et accessibles à tous, à plusieurs c'est mieux ! Pari tenu avec la première version de Carbon Saver. Maintenant, nous avons 1 an pour mettre l'IA au service de l'éco-conception et du design durable.

Nous vous proposons de rejoindre notre communauté pour co-créer le logiciel dont vous avez vraiment besoin.

Nous vous proposons d'unir nos force pour trouver une solution qui vous assiste pour dessiner des projets durables.

💌 On en discute ?
Email nurra.barry[at]carbon-saver.com
Site web http://www.carbon-saver.com 
Page Linkedin https://www.linkedin.com/company/carbon-saver

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAxTTUBy7XTK68H47ZccTG4IuVu4YPSztw/
**Connexions partagées** : 11


---

# Nurra Barry

## Position actuelle

**Entreprise** : Centech Mtl

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nurra Barry

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389810521207681024 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGUIKyrjD1nnA/feedshare-shrink_800/B4EZo3hgdfKkAg-/0/1761868122623?e=1766620800&v=beta&t=ZTuRgqvwEVLMu5CgAYqm6d8m5FWUQMOaN9_Bh9QbdhM | 🗓️RDV au Centech Mtl jeudi 6 novembre de 14h à 19h!

Nous faisons partie des startups de la cohorte Accélération qui exposent leur innovation à Ax.c 

En tout il y aura plus de 35 startups technologiques qui font bouger les lignes dans la deeptech, la medtech, l’edtech (et plus encore). 💡🌱🤖📚🧠

C’est un après-midi gratuit, vivant et ouvert à toutes et tous – pour rencontrer les entrepreneures et entrepreneurs derrière les projets, échanger avec la communauté Centech, et sentir le pouls de l’innovation montréalaise.

Vous verrez, l’énergie est contagieuse!

👉 lien d’inscription en commentaire | 46 | 6 | 2 | 1mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:34.508Z |  | 2025-10-30T23:48:44.296Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7345404711480553472 | Article |  |  | 🌡️ Impossible de travailler lorsqu'il fait trop chaud ? Pour nos enfants, c'est pareil !
Fermer les écoles à cause de la chaleur va devenir monnaie courante si nous ne faisons rien. 

👉 Vous pilotez un projet de rénovation d’école, de crèche, de collège ou de lycée ?

📆 RDV le 8 mardi 8 juillet à Montpellier pour le Campus annuel EduRénov pour apprendre à structurer votre démarche, connaître les leviers de financement, bénéficier de retours d’expérience concrets d’autres collectivités engagées. En plus, vous allez rencontrer les acteurs qui pourront vous aider à mener votre projet à bien et dont Carbon Saver fait partie ! (lien en commentaire)

C'est gratuit et c'est organisé par la Banque des Territoires. L'équipe de Carbon Saver est très heureuse d'accompagner la diffusion de ce programme qui vise à améliorer les confort thermique dans les bâtiments scolaires. 

EduRénov c'est 5 Milliards € pour réaliser les travaux et 50M€ pour les études préalables. Il y a des moyens, venez les mettre au service de votre établissement scolaires.
 
https://lnkd.in/e6crMd7E

Alexandra Ringot-Bottemanne, Nicolas Turcat, Blandine Calcio Gaudino, Hakim Lahlou, JFD, ACTEE (FNCCR), Cerema, AREC Occitanie, ADEME, ADEME Occitanie, Ministère de l'Éducation nationale, Sophie Larmaillard | 37 | 1 | 4 | 5mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:34.519Z |  | 2025-06-30T10:55:54.237Z | https://www.lemonde.fr/education/article/2025/06/29/canicule-plusieurs-municipalites-vont-fermer-leurs-ecoles-l-apres-midi-lundi-et-mardi_6616371_1473685.html |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7338852315539365890 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOCaN9h23tEg/feedshare-shrink_800/B4EZdjXRy2H0Ag-/0/1749718737629?e=1766620800&v=beta&t=UwOP6NIAQZjSiJM1PR55PkblgbzPlTSSgVhTeNwJZAE | 🏆 And the winner is… Tada ! 💪 
Vous l’avez deviné, Carbon Saver a gagné sa compétition de pitch à l’occasion de VivaTech et c’était extraordinaire de partager cette joie avec l’équipe. 
Big up à Karine Cuanbinh-Michelon, Carine BARNETCHE, Anika Hong, Manny Espinoza, you rock! 🙌 

Bravo à toutes les compétitrices ! Nous étions dans un mouchoir de poche, autant dire que tous nos projets méritent d’être regardés de plus près : Nathalie LESSELIN, Rachida Belarri, Emilie Brossier, Katya Lainé, Marine LIBOZ 🧜🏻‍♀️, Roxana Rotaru et Isabelle Wrigglesworth 🔥 

Merci pour ce prix assorti d'une année d’adhésion à numeum, CCI Paris Export et World Trade Center Paris Île-de-France. Au delà de la visibilité offerte par Business France, c’est un réel coup de boost pour notre activité qui se lance à l'international. 🤩 
Et derrière ce genre d’initiative il y a des personnes. Bravo pour tout ce que vous faites Maÿlis Staub, Agnes Gomes, Alban Dastugue, Clara Merino Montero, Cécile H., Sophie S. et Sabine Vu 👏 👏 👏 
... Pardon à toutes les personnes que j’ai oublié de citer 
————————————

Notre SaaS repose sur une Deep Tech frugale qui aide à réduire l'impact des bâtiments 
#WomenInTech, #VivaTech, #Pitch, #Innovation, #Climate, #FRTECHQC gener8tor STATION F | 236 | 91 | 6 | 5mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:34.523Z |  | 2025-06-12T08:59:01.307Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7338195345522237441 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE1EKH8LAePEg/feedshare-shrink_800/B4EZdaBxxcH0Ag-/0/1749562106075?e=1766620800&v=beta&t=Xb5emKZ2beXCfdUI_lYZQhqrvhMzZCjlMmVbGRdAutI | 📢 VivaTech, nous voilà ! Très heureuse de pitcher Carbon Saver dans le cadre de la sélection #𝗪𝗼𝗺𝗲𝗻𝗶𝗻𝗧𝗲𝗰𝗵𝗳𝗼𝗿𝗙𝘂𝘁𝘂𝗿𝗲.

RDV demain, mercredi 11 juin à 16h30 (Hall 1 D33) pour vous présenter nos dernières avancées, ou comment une Deep Tech frugale peut nous aider à réduire l'impact des bâtiments 🤩 

Et en plus, ce sera l'occasion de rencontrer Carine BARNETCHE, notre chercheuse en mathématiques appliquées.

Un grand merci à Maÿlis Staub, Agnes Gomes, Alban Dastugue, Clara Merino Montero, ainsi que numeum, CCI Paris Export, CCI Paris IdF et Business France pour leur soutien à une tech plus diverse.

Venez à la rencontre de toutes ces "pitcheuses" exceptionnelles : Nathalie LESSELIN, Rachida Belarri, Emilie Brossier, Anne 👾 Dumesges  🔺 🔺 杜欣安 👾, Katya Lainé, Marine LIBOZ 🧜🏻‍♀️, Roxana Rotaru, Wafaâ AMAL et Isabelle Wrigglesworth. Amplifions cette belle initiative ensemble ! 💪

#WomenInTech, #VivaTech, #Pitch, #Innovation, #Climate, #FRTECHQC

gener8tor STATION F | 197 | 38 | 7 | 5mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:34.524Z |  | 2025-06-10T13:28:27.449Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7313129322364489728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH3dBPIBInfWw/feedshare-shrink_800/B4EZX10VV4HcAo-/0/1743585893559?e=1766620800&v=beta&t=UPeUpNukbXVU9o8uubxWSHYljQLzdbQQqkIA1XrsxBs | Le point commun entre Doctolib, Carbon Saver, Dataiku, Leetchi et ManoMano? Le prix La Tribune Tech for Future pardi ! 🙃 
Le plus grand concours de startup de France. 

🏆 Debut avril, j'ai reçu ce prix des mains de Cécile H. de Business France, symbole de nos ambitions nord américaines. Turbulences géopolitiques ou pas, l'impact des bâtiment reste un sujet mondial et majeur : 40% de notre consommation d'énergie et 1/4 de nos gaz à effet de serre. Heureusement, nous avons trouvé une martingale productiviste pour concilier impact et business : bizarrement ça parle à tout le monde 🤑 

🙏 Merci pour ce prix #TechForFuture, et la surprise du GITEX GLOBAL Largest Tech & Startup Show in the World qui nous donne encore plus de visibilité, d'opportunités et de crédibilité. Merci à notre team de choc d'avoir fait déplacement, c'est si bon de célébrer ensemble : Paris, Bordeaux, Bayonne, Orléans... We are so French 💙🤍❤️ 

Un grand bravo à tous les autres lauréats :
Pierre-Emmanuel Casanova de HSL Technologies (HySiLabs)
Melpomeni Dimopoulou de PEARCODE
Jean-Sebastien Moulet de Wormsensing
Tassadit QUIVY de YOO SOFT
Françoise Cailler de Surgimab SAS
Marius Celette de Alpha Impulsion
Jonathan Stauber de Vaxinano
jean-christophe HABOT de FEELBAT
Doudou TAMBA de RepTik Analytics Solution

--

🌿 Carbon Saver, est un SaaS d’écoconception et d’enseignement de l’écoconception des bâtiments labellisé Ecolab - Greentech Innovation par le Ministères Ecologie, Territoire, Transports, Ville et Logement, partenaire de Banque des Territoires et basé à STATION F | 255 | 87 | 6 | 8mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:39.925Z |  | 2025-04-02T09:25:01.824Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7300770047516422145 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7462103f-d522-4afc-82b6-2dbaa8a0f890 | https://media.licdn.com/dms/image/v2/D4E05AQG2WnsIN4tC5w/videocover-low/B4EZVGLl_uHcCM-/0/1740639209578?e=1765778400&v=beta&t=7AM4ts-LzBXf7wrebWOowS447JHei48nw5MydtUyHQI | 🧐 Je suis un arbre exploité dans les bâtiments sans être abattu. Je suis… je suis… le liège !

👏 Bravo aux personnes qui avaient la réponse. Lorsque nous avons sélectionné des solutions parmis les nombreuses trouvailles dans mes locaux de Yemanja (B Corp) - Aménagement de bureaux, il était impensable de ne pas parler du liège. D’autant qu’on le trouve avec une certaine abondance au Portugal 🇵🇹 (souvenez-vous, tant que l’on reste en Europe continentale, les distances de transport restent acceptables lorsque le gain en impact est si important - local is best).

Ici, le revêtement de sol d’Amorim Cork 100% liège. Dans les bureaux, le revêtement de sol fait partie des principaux impacts, tout simplement car il peut représenter une part importante du tonnage. Simple. Basic. Alors leur choix est crucial, ça peut faire une grande différence !

🌷La pièce ou nous étions étant si exemplaire, nous en avons profité pour vous faire découvrir « Marmoleum », le papier peint en fleurs séchées de Oberflex 

🚮Autre trouvaille surprenante : Anga. Vous voyez du marbre, et pourtant c’est à base de plastiques qui habituellement ne sont pas recyclés.

🙏 Un grand merci aux équipes Yemanja, avec qui nous cocréons notre parcours d’écoconception pour les bureaux et tout particulièrement :
- Constance Chappey pour ses intros (d’ailleurs elle présente des alternatives en video sur la page Yemanja (B Corp) - Aménagement de bureaux)
- Doriane De Macedo, qui nous a accordé du temps pour vous présenter ces solutions
- Marie VAILLANT pour sa confiance 
Et Solenn Bouëtel, femme de l’ombre 😉

Le durable sait se faire désirable, je crois que cette vidéo parle d’elle même !

#RSE #architecture #artisanat #durabilité #bureaux

--

🌿 Carbon Saver, est un SaaS d’écoconception et d’enseignement de l’écoconception des bâtiments labellisé Greentech Innovation par le Ministères Ecologie, Territoire, Transports, Ville et Logement. | 105 | 11 | 5 | 9mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:39.928Z |  | 2025-02-27T06:53:41.076Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7295698236864954369 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5bc7858c-9950-48ad-aeea-8e6ad7fc2eab | https://media.licdn.com/dms/image/v2/D4E05AQHjkUurIhPdNQ/feedshare-thumbnail_720_1280/B4EZT8kgECHgBA-/0/1739404216112?e=1765778400&v=beta&t=dq_M2o4D1Wzuq1OkJQnbynCnNlxuiWhgafNpLeLCqcE | Chez Yemanja (B Corp) - Aménagement de bureaux, nous sommes loin du bagne 😍 

Hier, Constance Chappey, responsable RSE de Yemanja avait créé le suspense, il est temps de regarder le résultat de plus près, et ça vaut le détour. 💚

Cette fois nous avons fait un tour du côté de leur cuisine. Dans le genre "Je montre l'exemple", ils sont vraiment à suivre ! Grâce Clément, vous allez en savoir plus sur les nouvelles filières des coquillages : huîtres, Saint-Jacques,  moules, tout est possible 🤯 
🤓 C'est dur comme de la pierre. Et comme la nature a bien fait les choses, pas besoin de colle pétrochimique puisqu'elle est naturellement contenue dans le coquillage. Ici, il s'agit de plans de travail issus de la R&D d'Ostrea, implantés en France, à Renne. elle est pas belle la vie ?

💡 Vous l'ignoriez ? Depuis plusieurs mois, les équipes de Yemanja et de Carbon Saver collaborent à notre nouvelle option : l'écoconception de bureaux. Comme toujours, nous avons fait en sorte de travailler avec des acteurs de premier plan pour analyser des projets réels et peaufiner nos scores environnementaux. A suivre !

#designdurable #greentech #madeinfrance #biomatériau 
 Greentech Innovation | 107 | 28 | 7 | 9mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:39.929Z |  | 2025-02-13T07:00:07.187Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7288197317277421569 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEPnBLqP-_e9A/feedshare-shrink_800/B4DZSTg1T7HUAk-/0/1737641647578?e=1766620800&v=beta&t=AmFP-gMvRA9zkcqvKQanbWeasyLco7anCsi_S2guppI | 🌟 Carbon Saver rejoint STATION F ! 🌟
Nous avons une grande nouvelle à partager avec vous tous aujourd’hui : Carbon Saver rejoint le prestigieux Fighter’s Program de STATION F,  le plus grand campus de start-up au monde! 🎉

Ce programme emblématique représente une opportunité exceptionnelle pour accélérer notre croissance et déployer notre vision : permettre à chaque professionnel, même novice, de concevoir des projets écoresponsables avec une précision digne des meilleurs ingénieurs en environnement 🌱.

🌍 Pourquoi c'est important ? Parce que 80% de l’impact environnemental d’un projet se joue dès la conception et que nous avons besoin de soutien et de visibilité pour généraliser cette approche. Carbon Saver aide les professionnels du bâtiment à agir en amont, tout en étant productifs.

🙏 Merci la team STATION F, nous bénéficions de vos bienfaits aux quotidien, vous êtes au top : Chloé LE COSSEC 🎈Roxanne Varza Marwan Elfitesse Héloïse Nogues Hafssa Maldji, Louis Comte 

To the moon ! 🚀

Un immense merci à notre communauté, à nos partenaires et à tous ceux qui croient en notre mission : WinLab'- L'incubateur du CCCA-BTP et CCCA-BTP, gener8tor JFD Ecolab - Greentech Innovation et Greentech Innovation, Banque des Territoires Centech Mtl Humanskills ween

Stay tunned, bientôt des révélations sur notre IA qui enrichit automatiquement vos plans de bâtiment avec l’électricité, l’isolation, le chauffage, la récupération d’eau et bien d’autres chose qui vont améliorer la résilience de nos bâtiments.
 #FightersProgram #StationF #Innovation #Ecoconception #ImpactPositif #Startup | 282 | 80 | 9 | 10mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:39.936Z |  | 2025-01-23T14:14:08.597Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7287491612086054913 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG9AbtH5ojhKA/feedshare-shrink_800/B4EZSJe_6NHMAk-/0/1737473393247?e=1766620800&v=beta&t=VYE5gJ3bkEIoHqmKndElp3HN0JqjkNBIOVAeX784Wzs | 📅 C'est ce soir ! 🕡 18h30 – 21h 📍 Paris Sia Partners

#JFDClub - JFD Night avec Veolia France : Women rAIsing in Environment !

Une soirée au cœur de l’intersection entre intelligence artificielle, durabilité environnementale et inclusion lors de notre JFD Night x Veolia ! 

🔹 18h30 | Welcome 

🔹 19h | Introduction par Delphine Remy-Boutang, fondatrice & CEO JFD et arver. 
Je participe à cette table ronde avec Fabienne ARATA-CAMPS, Country Manager LinkedIn France, Laura Hassan, Directrice Générale EPITECH - European Institute of Technology et Meriem Riadi, Chief Information Officer Veolia | France, activité Eau. 
🎤 Modération par Aurélie Pasquier, journaliste Maddyness. 

🔹 19h50 | Cocktail networking 

#greentech #AI #deeptech | 94 | 1 | 1 | 10mo | Post | Nurra Barry | https://www.linkedin.com/in/nurrabarry | https://linkedin.com/in/nurrabarry | 2025-12-08T05:15:39.937Z |  | 2025-01-21T15:29:55.368Z |  |  | 

---



---

# Nurra Barry
*Centech Mtl*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Nurra Barry - Founder & CEO at Carbon Saver | The Org](https://theorg.com/org/carbon-saver/org-chart/nurra-barry)
*2024-11-01*
- Category: article

### [Nurau - About](https://www.nurau.com/about)
*2025-01-01*
- Category: article

### [Empowering Managers, Transforming Workplaces: Nurau's Mission to Build a Better Working Environment](https://www.mcgill.ca/dobson/article/empowering-managers-transforming-workplaces-nuraus-mission-build-better-working-environment)
*2024-05-07*
- Category: article

### [Nurau - ACET](https://acet.ca/en/portfolio/our-startups/nurau/)
*2024-05-13*
- Category: article

### [Nurau develops a preventive solution to improve mental health at work](https://caissetech.com/en/nurau-develops-a-preventive-solution-to-improve-mental-health-at-work/)
*2023-06-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Julian Lucchesi Email & Phone Number | Centech Mtl Director ...](https://rocketreach.co/julian-lucchesi-email_77372164)**
  - Source: rocketreach.co
  - *Centech Mtl Employee Nurra Barry's profile photo. Nurra Barry. Programme ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
