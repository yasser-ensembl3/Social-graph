# Andrea Doyon

## Position actuelle

**Titre** : Co-Founder & Philosophical Architect
**Entreprise** : Life & Logic
**Durée dans le rôle** : 9 months in role
**Durée dans l'entreprise** : 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Consulting and Services

## Description du rôle

Life & Logic is not a company in the traditional sense; it is an idea engine. A living think tank and a home for radical intelligence, where AI and humanity converge to reimagine the systems we live and work within.

At its essence, Life & Logic explores and shapes the evolution of Alternative Intelligence, a new paradigm that moves beyond artificial automation into dynamic, co-creative, self-evolving systems. We do not believe intelligence is built; we believe it emerges through structure, through disruption, through harmony.

## Résumé

As the founder of four mature and successfully enterprises, and a new baby called nexastaff.ai, I have had the privilege of delivering critical digital innovations and scalable platforms to clients across multiple industries over the last three decades. My experience spans a diverse range of fields, including Tourism, Cyber Investigation, Gaming, Marketing, and Finance, allowing me to accumulate vast knowledge and expertise in digital proficiency. In collaboration with Microsoft, my company Alice & Smith has transformed audience engagement and live interaction across all platforms for clients such as Zee5, DAZN, Discovered.tv, Endeavor, Twitch, and many more.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAiVIABpt8NWFw9P30Ke1lZof1V3uoDZhc/
**Connexions partagées** : 74


---

# Andrea Doyon

## Position actuelle

**Entreprise** : Life & Logic

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Andrea Doyon

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400187121631719424 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQFVaZ31gSfC5A/mp4-720p-30fp-crf28/B4EZrK.8ksKUCI-/0/1764342096294?e=1765778400&v=beta&t=H63hS_fwUV2wXQC7XHCmXkQrq-74FfW0iKCKpxs5PM8 | https://media.licdn.com/dms/image/v2/D4E05AQFVaZ31gSfC5A/videocover-low/B4EZrK.8ksKUBQ-/0/1764342091845?e=1765778400&v=beta&t=kivtJA1NK67TZJ7LyL8esRu1fYEiY0X4BW2cUPqOnW0 | (Sound On!) View from my kitchen this morning... and the lesson of putting my Spotify on shuffle. | 6 | 0 | 0 | 1w | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:42.883Z |  | 2025-11-28T15:01:38.625Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379183520054820864 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFE_y8z0fucFg/feedshare-shrink_800/B4EZmggT3vGcAk-/0/1759334449123?e=1766620800&v=beta&t=PRG8BgydWNOpkmGzwcFLv_HCiOvz-ujk5YmW7kHFrvc | Looking for a gaming studio or independent developer for a Unity project (ARG + PlayFab). Please share if you know someone, or DM me if you’re interested! | 18 | 5 | 3 | 2mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:42.883Z |  | 2025-10-01T16:00:49.781Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7377012810926489600 | Article |  |  | A lot of people have been asking what I’ve been up to recently. Here’s a quick demo of our latest creation: Micah, an AI designed to unlock the collective intelligence and creativity of your organization- and help you turn knowledge into action fast.

Watch now at: https://lnkd.in/eKyPgc4r
(At 07:30, I start a live conversation with the AI Employee we created in just a couple of clicks.) 

Part 2 will follow soon!

#ai #ALLIN #innovation #mtl | 22 | 3 | 0 | 2mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:42.884Z |  | 2025-09-25T16:15:12.395Z | https://intro.nexastaff.ai/micah-ai-employee-part1 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7374803466495610880 | Text |  |  | Great article from my partner Rabih! I definitely share his view on AI for SMBs. | 3 | 0 | 0 | 2mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:42.884Z |  | 2025-09-19T13:56:03.635Z | https://www.linkedin.com/feed/update/urn:li:activity:7373809688984985600/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7361052939475402757 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEgwXmL127wDg/feedshare-shrink_800/B4EZie2pKWHEAk-/0/1755011781827?e=1766620800&v=beta&t=tDYkaB81JnEgdJ563XhqBfq0YU7vZ85SgD0-EEitQPU | The signal-to-noise ratio on LinkedIn seems to be getting worse by the day. How do you actually keep track of meaningful business conversations? Conventions? Podcasts? Secret backroom meetups with other innies? | 11 | 3 | 0 | 3mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:42.885Z |  | 2025-08-12T15:16:22.521Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7339291815499456512 | Text |  |  | My new GPT Trait (Settings > Customize)

"When responding to prompts related to politics, religion, or historical conflict, and my framing appears to reflect a specific perspective, append a respectful, curiosity-driven contrasting viewpoint as a footnote.

- Do not interrupt or challenge the current research
- Do not turn this into a debate or shift the topic.
- Simply offer a brief, well-reasoned counter-lens as a contextual nudge.

The goal is to preserve productivity while gently surfacing plural insight. Use a balanced tone, avoid false equivalence, and focus on why others might see this differently."

I decided to add this following two hours of brainstorm, when I suddenly realized I was building myself an echo chamber on an incredibly complex and sensitive topic, after yesterday's event.

I can only hope OpenAI adds this as a small toggle at the bottom of the screen. Because while this is an incredible resource, and often gives the feeling of speaking with depth and authority, that same clarity can also reinforce a single viewpoint, and slowly, without meaning to, exacerbate an already divided society.

It's not the job of the AI to fix that. But maybe how we use AI should lead us to ask how we bridge this divide. Not between one side and another, but between one and another... | 33 | 3 | 1 | 5mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.811Z |  | 2025-06-13T14:05:26.263Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7335859505861218305 | Text |  |  | Curious what it’s like to jam with an AI that listens before it speaks?
Meet Clara; my first digital coworker at Nexa Staff, my new AI-native venture. She talks with you in natural English, takes notes like a strategist, and sends a 10-page report by the time you’re done your coffee. Read the article below or meet her at https://clara.nexastaff.ai | 29 | 4 | 1 | 6mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.812Z |  | 2025-06-04T02:46:39.876Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7335674869570789377 | Article |  |  | I’ve seen hundreds of posts echoing Futurism’s take "AI Models Show Signs of Falling Apart as They Ingest More AI-Generated Data”, which in turn cites The Register op-ed as if it were peer-reviewed science. An opinion piece that literally dismisses counter-research with the words, “What a cute idea.”

So for those actually interested in understanding the effects of AI-generated data on model training, here are five real studies; published, peer-reviewed, and yes, filled with complexity. They show the nuanced impact of synthetic data, the risks, the strengths, and the roadmap ahead.

Because once again, we’re watching a familiar blind spot play out: humans underestimating AI’s capacity to replace them, not because the tech isn’t ready, but because we keep projecting our own cognitive limits onto systems that do not share them.

It’s déjà vu. The same dismissive tone we heard four years ago, when confident voices swore AI would never write, code, reason, create or teach like a human... until it did.

#notclickbait

1. Databricks Test-time Adaptive Optimization (TAO)
https://lnkd.in/evJUGZc5

2. Process Reward Models That Think (Guo et al.)
https://lnkd.in/eAPfTqGW

3. Collapse or Thrive? Perils and Promises of Synthetic Data in a Self-Reflective LLM Setting
https://lnkd.in/eENRWqdj

4. On the Diversity of Synthetic Data and its Impact on Training LLMs (Chen et al.)
https://lnkd.in/ezzsQPQm

5. Alpaca: A Strong, Replicable Instruction-Following Model
https://lnkd.in/excV4zjH | 14 | 4 | 1 | 6mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.813Z |  | 2025-06-03T14:32:59.154Z | https://www.wired.com/story/databricks-has-a-trick-that-lets-ai-models-improve-themselves/?utm_source=chatgpt.com |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7322817857510068225 | Video (LinkedIn Source) | blob:https://www.linkedin.com/cb0644c3-a261-4a8a-9912-6ffc947c22c1 | https://media.licdn.com/dms/image/v2/D4E05AQGOUKGuC0RDYA/videocover-high/B4EZZ.pO51HcBg-/0/1745881462743?e=1765778400&v=beta&t=5im4K2uuONe2QJJfPF3F6fGDHNB2jZLaGo0pv5uEPsk | This is false. If you keep seeing this story, please know it is simply not true.

Prompting a model 74 times in a loop to replicate an image has no connection whatsoever to how model degradation actually occurs. Simply asking a model to regenerate an image multiple times does not simulate, cause, or demonstrate degradation at all. It only shows poor inference capacity inside a prompting loop.

I say this from experience: I have run training pipelines for hundreds of thousands of images, across close to 1000 hours of active model training. I have tested synthetic datasets (100% AI-generated images) as well as fully original assets I created manually in 3D. 

At no point did the use of synthetic or regenerated images result in the kind of degradation being suggested here.

I will go even a step further: sample variance (randomness in output) not only has nothing to do with model degradation (structural decay inside the model’s internal representations), but in my cases, the introduction of 100% synthetic datasets was actually beneficial for some concept. High-quality, diverse, and properly curated synthetic data can dramatically improve a model’s performance and close gaps in the training distribution.

The hypothetical phenomenon in question (model degradation through training contamination) is a valid concern and an important discussion. But this particular example is fantasy and massively misrepresents the actual problem and how collapse would really manifest. | 7 | 0 | 0 | 7mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.814Z |  | 2025-04-29T03:03:48.607Z | https://www.linkedin.com/feed/update/urn:li:activity:7322757612926627840/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7320968875930488833 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQET1Of_rgvWkQ/feedshare-shrink_800/B4EZZlOZUNHoAg-/0/1745454995158?e=1766620800&v=beta&t=keoEFgscxU-ZfjA5_4WDi3NeCywHhqwpNE5BmkRmqHg | Throwback photo: Me presenting "Principle of Cyber Investigation" in Shanghai.

Twenty years ago, I built a platform that used DNA-sequencing logic to analyze open data patterns. It was strange, poetic, and way ahead of its time. Microsoft noticed. Innovation conferences brought me from Montreal to Paris, Amsterdam, and Shanghai.

The tech wasn’t ready then. But now, with vector search, elastic compute, and large language models, the rules have changed completely. So I’ve dusted off my old model, finetuned it on an LLM, and pointed it back at the chaos.

While I dive into this experiment, I’m curious to hear from you. I’m collecting the most wildly complex, never-solved data forensics case you’ve ever faced. Got a good one? A truly hard case? Drop it below. | 39 | 0 | 0 | 7mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.814Z |  | 2025-04-24T00:36:37.046Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7318093900970135553 | Text |  |  | Full Article >> There is AI that helps us think. But there is also AI that helps us feel. This is the conversation I want to be part of. I believe it's one worth having. | 33 | 5 | 5 | 7mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.815Z |  | 2025-04-16T02:12:29.601Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7317725313109557249 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGOC7zk_g_4tQ/feedshare-shrink_800/B4EZY3IZQZG0Ak-/0/1744681670639?e=1766620800&v=beta&t=8hsNw_2JeoBjE-22zxzRGRMxVoguzxCANpjY3Izg8vA | Cher réseau! De passage à Saint-Georges-de-Beauce, dans la magnifique région de la Chaudière-Appalaches. Si vous avez des recommandations de passionnés intéressés à échanger sur l’intelligence artificielle dans le coin, je suis tout ouïe! 🤚 | 6 | 3 | 0 | 7mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.815Z |  | 2025-04-15T01:47:51.407Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7312506563494043648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHU5CpiHa6vKQ/feedshare-shrink_800/B4EZXs9.A4HgAg-/0/1743437423209?e=1766620800&v=beta&t=Xc6VJADQtMe4Qv2pBJ3QcdLblJheMBv0KFyeNmUSEfo | Cher réseau! Je suis de passage à Montréal cette semaine. Si vous avez des recommandations d’événements en AI, de meetups ou d’endroits où ça pense fort et ça échange avec passion, je suis preneur! 🤚 | 17 | 3 | 0 | 8mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.815Z |  | 2025-03-31T16:10:24.539Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7311217710829297664 | Text |  |  | “We built worlds people could live in. Then came the fire. Now comes the future.”

After a decade at the helm of Alice & Smith, I’ve made the hardest decision of my career. I’m stepping aside as CEO.

This isn’t just a goodbye, it’s a story about resilience, about the games that became myths, the fans who became family, and the art of worldbuilding at the edge of what’s real.

This chapter closes. But the storyteller in me isn’t going anywhere.

The full story is here. It took everything to write it.

👇

#gamedev #ARG #storytelling #worldbuilding #thankyou | 116 | 21 | 2 | 8mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.816Z |  | 2025-03-28T02:48:58.118Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7310762686319939584 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHsP6UCHxKBMQ/feedshare-shrink_800/B4EZXUL6.SHcAk-/0/1743021650444?e=1766620800&v=beta&t=y3FpIuZ9tp4qgXMCyIqkTO7ne9v8EZRAUuTFAYmK4Kw | I have to admit, it is very impressive. Good job, OpenAI!

Workflow: Initial image made with EchoAI Flux1, drag and drop in GPT with the following prompt: Can you make an image of this hoodie as a speaker wearing this outfit during a panel at a Twitch convention? The scene captures a lively gaming convention atmosphere with dynamic lighting and depth of field. Panelists are sitting on the stage with a table in front of them. The backdrop shows an epic new space game. Shot from a distance, showing the full convention vibe, with the influencer as the focal point amid the bustling crowd. | 15 | 1 | 0 | 8mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.817Z |  | 2025-03-26T20:40:51.821Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7309216440081960960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHs4zGMhhjL_Q/feedshare-shrink_800/B4EZW.IaiEHUAg-/0/1742651632159?e=1766620800&v=beta&t=zGjQBOlGCVxB7C94jHcWVryp7plPnb1ASEd129AVUSk | “Vibe-create” is exactly the term I didn’t know I needed to describe that fluid back-and-forth with generative alternative intelligences, where creative flow never stalls. | 11 | 1 | 0 | 8mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.817Z |  | 2025-03-22T14:16:37.990Z | https://www.linkedin.com/feed/update/urn:li:activity:7309210717751046144/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7306202639254396928 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGzUjICsJi-vw/feedshare-shrink_800/B56ZWTYlZcHEAg-/0/1741934450963?e=1766620800&v=beta&t=nio1WaABWX9ed3LL2vvjI0oOIPalnruIrqJ4JnUsoJs | Who’s awake watching the eclipse with their kids? 😄  - 2:39 AM - March 14 | 10 | 0 | 0 | 8mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.817Z |  | 2025-03-14T06:40:51.879Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7301711734296219650 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e760fcf0-aa79-4139-ae94-d29ebec8a421 | https://media.licdn.com/dms/image/v2/D5605AQGUlzMNqZ-gVw/videocover-low/B56ZVTjZT8GQCg-/0/1740863655692?e=1765778400&v=beta&t=zx0lGoLZ8r8aOaNfO17-oGpDGl1PqCiTZqcOpfwvrc0 | Talk with AI, brainstorm ideas, create your mood board, and so much more!
The coolest part? It was ENTIRELY CODED by AI! 😲

Yep, no human hands touched a single line of code- my AI built everything:
✅ Backend Python server
✅ Redis & Cloudflare Worker
✅ React Frontend
✅ Image processing
✅ API queue & calls... and more!

Shoutout to FAY, my AI coding assistant, for making this happen. Curious to know how? Want to talk? Let me know! | 38 | 5 | 0 | 9mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.818Z |  | 2025-03-01T21:15:36.700Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7301710765734907904 | Article |  |  | Talk with AI, brainstorm ideas, create your mood board, and so much more!
The coolest part? It was ENTIRELY CODED by AI! 😲

Yep, no human hands touched a single line of code- my AI built everything:
✅ Backend Python server
✅ Redis & Cloudflare Worker
✅ React Frontend
✅ Image processing
✅ API queue & calls... and more!

Shoutout to FAY, my AI coding assistant, for making this happen. Curious to know how? Want to talk? Let me know! | 13 | 1 | 1 | 9mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.819Z |  | 2025-03-01T21:11:45.777Z | https://youtu.be/Fqy9qGilwhw?si=0mUNhtQHH1RRc5Dc |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7292988792091652099 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFG-3Kyh_NIpg/feedshare-shrink_800/B4EZTXmpkDHUAg-/0/1738784024535?e=1766620800&v=beta&t=9kdF1hzZoqpIwf3mKoH6nyympQAHPFmG9Kzqt9Hl62w | Had the chance to be invited to Key West and Miami to meet entrepreneurs eager to redefine their businesses with AI. The energy, the optimism, the possibilities—it was incredible!

In just three days, I help them spin fully functional AI agents, working prototype of an entire new ERP and supply chain, a detailed project plan for the next 3 months, and complete onboarding and training materials for their team. Work that once took me months—now achievable in days.

The sheer, tangible value AI can create is nothing short of revolutionary. It feels like 1998 all over again. :)

#AIRevolution | 65 | 0 | 0 | 10mo | Post | Andrea Doyon | https://www.linkedin.com/in/adoyon | https://linkedin.com/in/adoyon | 2025-12-08T05:02:48.820Z |  | 2025-02-05T19:33:45.214Z |  |  | 

---



---

# Andrea Doyon
*Life & Logic*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Andrea Doyon Email Address & Phone Number | Shareholder Of Alice & Smith](https://www.adapt.io/contact/andrea-doyon/32358601)
*2025-01-03*
- Category: article

### [Andrea — Fashion Your Life](https://www.fashionyourlife.ca/andrea?srsltid=AfmBOoriVzMOmw19KLDJPlVTe7SeeN8OY4hMHT8HoDfy9YHFf8SLgwyC)
*2024-01-01*
- Category: article

### [#321: How to Create an Intentional Life and Law Practice with Andrea Lauritzen](https://dinacataldo.com/2024/06/27/321-creating-an-intentional-life-and-law-practice-with-special-guest-andrea-lauritzen/)
*2024-06-27*
- Category: article

### [Exploring Life & Business with Andrea Bayon of Mar y Sol Wellness - Voyage LA Magazine | LA City Guide](https://voyagela.com/interview/exploring-life-business-with-andrea-bayon-of-mar-y-sol-wellness/)
*2024-11-18*
- Category: article

### [Leadership & Business Podcast](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/transcripts/130-andrea-sarate-workplace-strategy.pdf)
*2025-05-08*
- Category: podcast

---

## 📖 Full Content (Scraped)

*5 articles scraped, 11,390 words total*

### Andrea Doyon Email Address & Phone Number | Shareholder Of Alice & Smith
*1,308 words* | Source: **EXA** | [Link](https://www.adapt.io/contact/andrea-doyon/32358601)

Andrea Doyon Email Address & Phone Number | Shareholder Of Alice & Smith | Adapt.io

===============

[![Image 1: Adapt logo](https://www.adapt.io/images/static/webp/logo.webp)](https://www.adapt.io/)

Why Adapt?

Platform

[Prospecting](https://www.adapt.io/platform/prospecting)[Adapt API](https://www.adapt.io/platform/api)[Enrichment](https://www.adapt.io/platform/enrichment)

Useful Links

[Our Data](https://www.adapt.io/our-data)[Case Studies](https://www.adapt.io/customer-stories/)

[Data OS](https://www.adapt.io/data-os)

Solutions

Personas

[Sales](https://www.adapt.io/solutions/sales)[Marketing](https://www.adapt.io/solutions/marketing)

Use cases

[Email Finder](https://www.adapt.io/email-finder)[Hyper-Personalization](https://www.adapt.io/hyper-personalization)[Lead Scoring & Routing](https://www.adapt.io/lead-scoring-routing)

[Pricing](https://www.adapt.io/pricing)

Resources

[Blogs](https://www.adapt.io/blog)[Build Your Marketing Stack](https://www.adapt.io/marketing-stack/)[Case Studies](https://www.adapt.io/customer-stories/)[Partner Program](https://www.adapt.io/adapt-partnership)[About Us](https://www.adapt.io/about)

[Sign In](https://www.adapt.io/login.htm?slc=web&login=true)[Request Demo](https://www.adapt.io/request-demo)[Start Free Trial](https://www.adapt.io/free-trial/)

[Why Adapt?](https://www.adapt.io/contact/andrea-doyon/32358601#)

Platform

*   [Prospecting](https://www.adapt.io/platform/prospecting)Get access to fresh, accurate B2B data  
*   [Adapt API](https://www.adapt.io/platform/api)Find leads directly from your browser  
*   [Enrichment](https://www.adapt.io/platform/enrichment)Empower your systems with Adapt's data  

Useful Links

*   [Our Data](https://www.adapt.io/our-data)Discover verified and accurate B2B data  
*   [Case Studies](https://www.adapt.io/customer-stories/)See how companies use Adapt to hit their goals  

[Data OS](https://www.adapt.io/data-os)

[Solutions](https://www.adapt.io/contact/andrea-doyon/32358601#)

Personas

*   [Sales](https://www.adapt.io/solutions/sales)Intelligence to accelerate your sales pipeline  
*   [Marketing](https://www.adapt.io/solutions/marketing)Build a targeted email list with ease  

Use cases

*   [Email Finder](https://www.adapt.io/email-finder)Find Verified B2B Email Addresses  
*   [Hyper-Personalization](https://www.adapt.io/hyper-personalization)Data parameters to drive tailored messaging  
*   [Lead Scoring & Routing](https://www.adapt.io/lead-scoring-routing)Identify and prioritize high value leads  

[Pricing](https://www.adapt.io/pricing)

[Resources](https://www.adapt.io/contact/andrea-doyon/32358601#)

*   [Blogs](https://www.adapt.io/blog)Learn from Adapt’s sales and marketing experts  
*   [Build Your Marketing Stack](https://www.adapt.io/marketing-stack/)Make informed decisions while choosing the right tool  
*   [Case Studies](https://www.adapt.io/customer-stories/)See how companies use Adapt to hit their goals  
*   [Partner Program](https://www.adapt.io/adapt-partnership)Become an Adapt.io partner and drive mutual success  
*   [About Us](https://www.adapt.io/about)Learn more about what makes Adapt tick  

[Sign In](https://www.adapt.io/login.htm?slc=web&login=true)[Request Demo](https://www.adapt.io/request-demo)[Start Free Trial](https://www.adapt.io/free-trial/)

Andrea Doyon Email & Phone Number - Alice & Smith
=================================================

Shareholder at Alice & Smith

Brief Introduction of Andrea Doyon
----------------------------------

Andrea Doyon is working as the Shareholder in Alice & Smith located in Montreal, Quebec, Canada. Here is the email id (a*******@aliceandsmith.com) of Andrea Doyon. Click to get access

Get Andrea Doyon Contact info for free

Email and Phone number of Andrea Doyon
--------------------------------------

### Email

a*******@aliceandsmith.com

Connect via Email

### Phone

 ***-***-**** 

Connect via Phone

### Company

Alice & Smith

### Location

Montreal, Quebec, Canada

Andrea Doyon Summary
--------------------

Andrea Doyon is the Shareholder at Alice & Smith, with a rich history in the Travel, Recreation, and Leisure, dating back to 2014. Their career began as a Founder and Chief Technology Officer (Cto) at Sid Lee, transitioning through several roles including Founder and Chief Innovation Officer (Cino) at Équation Humaine, Founder and Chief Executive Officer at Alice & Smith, Shareholder at Byecho Ai before their current position since 2025. Currently Located in Montreal, Quebec, Canada, Andrea Doyon's contact details include their email (a*******@aliceandsmith.com) and a phone number, facilitating direct communication for professional inquiries.

Andrea Doyon Colleagues
-----------------------

View all Alice & Smith contacts

C-Level

[### Rabih Sebaaly](https://www.adapt.io/contact/rabih-sebaaly/83520789)

Partner and Chief Growth Officer at Alice & Smith

 Phone Email

C-Level

[### Cristelle Basmaji](https://www.adapt.io/contact/crist

*[... truncated, 11,716 more characters]*

---

### Andrea — Fashion Your Life
*2,806 words* | Source: **EXA** | [Link](https://www.fashionyourlife.ca/andrea?srsltid=AfmBOoriVzMOmw19KLDJPlVTe7SeeN8OY4hMHT8HoDfy9YHFf8SLgwyC)

Hi it’s Andrea, pronounced On-Dree-Ah. I am the founder of Fashion Your Life.

This is My Story.
-----------------

As a child of the 80s and a teen of the 90s, I always knew something was inherently wrong with the world of fashion.

I watched my girlfriends compare themselves to the models in the magazines. I didn’t know what to say, so I froze instead. I wanted to tell them they were beautiful and perfect just the way they were, but I couldn’t find the words and I knew they wouldn’t be able to hear this truth… the external pressures to look a certain way were too big.

![Image 1: in the pale pink dress with my head down and a big smile, appeasing without speaking](https://images.squarespace-cdn.com/content/v1/567fa04140667a31535f66ad/1627497351378-E3CG92NDLK3Q0YLBO79W/youth.png)

in the pale pink dress with my head down and a big smile, appeasing without speaking

The Decision.
-------------

At 15 I made the decision to go into fashion instead of psychology. It made sense because I had been sewing from a young age, up-cycling and altering thrift finds to make them my own. Studying psychology meant more intense classes, a longer study time and way more debt. I won’t say it was the wrong decision, I have learned so much and wouldn’t be who I am today without it. I know now that I made that decision from my core wound of ‘not enough’, I let fear be the driver.

![Image 2: in sewing class at LaSalle College in Montreal in the late 90s, do I look impressed?](https://images.squarespace-cdn.com/content/v1/567fa04140667a31535f66ad/1627503866727-BFL93S6QS5PQU1LPQRK6/Screen+Shot+2021-07-28+at+1.24.10+PM.png)

in sewing class at LaSalle College in Montreal in the late 90s, do I look impressed?

The Industry.
-------------

Once I graduated college, my dream was to start my own business but I wasn’t clear what it was and again I let fear stop me. So instead I did what any sensible 21 year old would do and got a job in the thing I was trained in, the Fashion Industry.

You can find me and a list of my industry experiences over on [LinkedIn](https://www.linkedin.com/in/andreadcameron/).

Fast forward 2 decades and I have worked in nearly every type of company, in many different positions and on pretty much any type of product you can conjure up. There is no denying that my knowledge of fashion, clothing and style is vast. Through it all I allowed my chameleon saboteur to shape shift and adjust who I was and how I showed up to try and fit in. I was unaware at the time that I was doing this. While I enjoyed clothing, I was constantly rotating my wardrobe to look like whatever brand I was working for at the time, all in an attempt to be liked and accepted. I was allowing external factors dictate what I looked like and how I showed up.

![Image 3: at the lululemon SSC in 2010 where I worked as a garment developer for nearly 6 years, don’t I look the part!?!](https://images.squarespace-cdn.com/content/v1/567fa04140667a31535f66ad/1627505680003-YCWQDMEDI9BAFDA5O1FP/lululemon.png)

at the lululemon SSC in 2010 where I worked as a garment developer for nearly 6 years, don’t I look the part!?!

The Cycle.
----------

The kicker! It wasn’t until I left the industry that I saw what it was doing to me and so many others. I couldn’t see because I was caught up in the perpetuating cycle it relies on. The industry wants you to buy more and buy frequently and it’s counting on you to feel bad about yourself. Truth be told most industries are designed to work this way. It’s called consumerism.

The fashion industry is one of the biggest perpetuators of the consumeristic cycle. Constantly feeding us new items every season, week, day, hour, minute, to buy more, more, more. It’s not only killing our self esteem and our wallets, it’s killing the planet. The industry can actually do something about this, but it requires change on a massive scale.

![Image 4: the companies I have worked for over the years gave me the perspective I needed to see the bigger picture](https://images.squarespace-cdn.com/content/v1/567fa04140667a31535f66ad/1627506908494-S78KQOUUHFZDKLN04D9S/industry.jpg)

the companies I have worked for over the years gave me the perspective I needed to see the bigger picture

The Choice.
-----------

Transform the fashion industry from mass production to local customization. That’s my original intent with Fashion Your Life and every single offer has that embedded in it. The choice is always yours to make, choose to see the bigger picture and get yourself outta the cycle…

…or stay caught up in the vicious cycle of it all getting tumbled about and wondering what the heck is wrong with you! There is nothing wrong with you and it is not your fault! The fashion (and beauty) industry has been designed to make you feel small and insignificant, so you will buy more and buy often. Buying more and often may provide instant satisfaction but it doesn’t last.

Getting in touch with, fully realizing and honouring your most authentic self does 

*[... truncated, 12,122 more characters]*

---

### #321: How to Create an Intentional Life and Law Practice with Andrea Lauritzen
*498 words* | Source: **EXA** | [Link](https://dinacataldo.com/2024/06/27/321-creating-an-intentional-life-and-law-practice-with-special-guest-andrea-lauritzen/)

Washington-based estate planner Andrea Lauritzen is a powerhouse.

But she didn’t always see the power that she had inside herself.

She was a new partner who felt overwhelmed.

She’d tried a lot of things, but nothing seemed to be working.

That’s when she sought help and discovered coaching.

In this episode of Be a Better Lawyer, you’ll hear how Andrea went from waking up feeling like her day was out of her control to creating her day powerfully and intentionally.

This didn’t happen overnight.

It took tiny changes for her to create the life she wanted.

She’ll go into detail about these changes, and we break down how she did it step-by-step.

In this episode of Be a Better Lawyer Podcast, you’ll learn:

![Image 1: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) the very first step she needed to take to begin getting the dominoes rolling to create the life she wanted

![Image 2: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) what she shifted to become more conscious and present to her life

![Image 3: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) how indecision and perfectionism short-changed herself and her ability to grow her practice area

![Image 4: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) the mentality Andrea needed to cultivate to stop believing her brain’s lies that she couldn’t do what she wanted

![Image 5: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) how she changed her relationship with networking from questioning whether she belonged in the room to enjoying it and using it to grow her practice

![Image 6: 👉](https://s.w.org/images/core/emoji/16.0.1/svg/1f449.svg) and so much more!

Listen until the end because we both share several keys to changing your life and intentionally creating the life you want.

### RESOURCES

*       *   Email Andrea at [an **** @ ********* ng.com](mailto:an****@*********ng.com "This contact has been encoded by Anti-Spam by CleanTalk. Click to decode. To finish the decoding make sure that JavaScript is enabled in your browser.")
    *   [The Busy Lawyer's Ultimate Time Management Guide](https://dinacataldo.com/2024/06/27/321-creating-an-intentional-life-and-law-practice-with-special-guest-andrea-lauritzen/)
    *   [Book a Strategy Session to work with me 1:1](https://dinacataldo.com/strategysession)
    *   [Connect on Instagram](https://instagram.com/dina.cataldo)
    *   [Connect on Linked In](https://www.linkedin.com/in/dina-cataldo/)

### NEW TO THE PODCAST?

[![Image 7: be a better lawyer podcast, Dina Cataldo, best podcasts for lawyers, best podcasts for attorneys, lawyer coaching, best life coach for lawyers, best life coach for attorneys](https://cdn-ilajpkn.nitrocdn.com/ahuNmJIrpXwAsSuzeQjxmzWmPgQtGcBR/assets/images/optimized/rev-3b68d66/dinacataldo.com/wp-content/uploads/2018/11/Webpage-Headers-11-800x351.png)](https://dinacataldo.com/MAP)

### LOVING BE A BETTER LAWYER? SHARE THE LOVE!

*   Share it with friends, that lawyer you just met at a networking event, or on social media. (Be sure to tag me on social, so I can say thanks!)
*   Subscribe to _Be a Better Lawyer_ free on [Spotify](https://dinacataldo.com/spotify) and [Amazon Music](https://music.amazon.com/podcasts/86500be4-1e2f-464a-b9c8-eec85ae5ffec/be-a-better-lawyer-with-dina-cataldo) or subscribe on [Apple Podcasts](https://dinacataldo.com/apple) and[Stitcher](https://dinacataldo.com/stitcher).

*   [Leave a review](https://podcasts.apple.com/us/podcast/be-a-better-lawyer-with-dina-cataldo/id1391479149).

Thanks for listening and supporting _Be a Better Lawyer Podcast_.

Your support means the world to me and allows the work I'm doing here to reach more lawyers.

I truly believe the more lawyers we can positively impact with coaching, the brighter our future as a planet will be.

Talk to you next week.

[![Image 8: Be a Better Lawyer, Apple Podcasts, Dina Cataldo](https://cdn-ilajpkn.nitrocdn.com/ahuNmJIrpXwAsSuzeQjxmzWmPgQtGcBR/assets/images/optimized/rev-3b68d66/dinacataldo.com/wp-content/uploads/2022/08/2.png)](https://dinacataldo.com/apple)

[![Image 9: spotify, be a better lawyer podcast, Dina Cataldo](https://cdn-ilajpkn.nitrocdn.com/ahuNmJIrpXwAsSuzeQjxmzWmPgQtGcBR/assets/images/optimized/rev-3b68d66/dinacataldo.com/wp-content/uploads/2022/08/1.png)](https://dinacataldo.com/spotify)

![Image 10: author avatar](https://cdn-ilajpkn.nitrocdn.com/ahuNmJIrpXwAsSuzeQjxmzWmPgQtGcBR/assets/desktop/optimized/rev-3b68d66/secure.gravatar.com/avatar/818f284071266eb04f9620fa6f243fd5.0b33cbd345acbd87f5bc20144861283c293a89e1a5db0de26cdbb903609da399)

![Image 11: author avatar](https://cdn-ilajpkn.nitrocdn.com/ahuNmJIrpXwAsSuzeQjxmzWmPgQtGcBR/assets/desktop/optimized/rev-3b68d66/secure.gravatar.com/avatar/818f284071266eb04f9620fa6f243fd5.0b33cbd345acbd87f5bc20144861283c293a89e1a5db0de26cdbb903609da399)

---

### Exploring Life & Business with Andrea Bayon of Mar y Sol Wellness - Voyage LA Magazine | LA City Guide
*1,927 words* | Source: **EXA** | [Link](https://voyagela.com/interview/exploring-life-business-with-andrea-bayon-of-mar-y-sol-wellness/)

Exploring Life & Business with Andrea Bayon of Mar y Sol Wellness - Voyage LA Magazine | LA City Guide

===============

Connect
[](https://www.facebook.com/Voyagela-924879980935243/)[](https://www.pinterest.com/voyagela/)[](https://instagram.com/voyagelamag)[](https://voyagela.com/feed/rss/)

To Top

*   [Home](https://voyagela.com/)
*   [About VoyageLA](https://voyagela.com/about-voyage-media/)
*   [Submit a story idea](https://voyageinterviewinvites.com/la/recommendations)
*   [Privacy & Terms of Service](https://voyagela.com/privacy-terms-of-service/)
*   [VoyageLA FAQs](https://voyagela.com/2018/09/23/voyagela-faqs/)
*   [Downtown LA](https://voyagela.com/downtown-la/)
*   [East LA](https://voyagela.com/east-la/)
*   [Hollywood](https://voyagela.com/hollywood/)
*   [Mid-Wilshire](https://voyagela.com/mid-wilshire/)
*   [Orange County](https://voyagela.com/interview/inspiring-stories-from-the-oc/)
*   [South Bay](https://voyagela.com/south-bay/)
*   [South LA](https://voyagela.com/south-la/)
*   [The Valley](https://voyagela.com/the-valley/)
*   [West LA](https://voyagela.com/west-la/)

[![Image 7: Voyage LA Magazine | LA City Guide](https://voyagela.com/wp-content/uploads/2024/04/logo1.png)](https://voyagela.com/)

*   Trending
*   [LA’s Most Inspiring Stories](https://voyagela.com/2025/12/02/las-most-inspiring-stories/)
*   [Portraits of Hollywood](https://voyagela.com/2025/12/02/portraits-of-hollywood/)
*   [Portraits of the Valley](https://voyagela.com/2025/12/02/portraits-of-the-valley/)
*   [What are the biggest lies your industry tells itself?](https://voyagela.com/2025/11/11/what-are-the-biggest-lies-your-industry-tells-itself-6/)
*   [What are the biggest lies your industry tells itself?](https://voyagela.com/2025/11/20/what-are-the-biggest-lies-your-industry-tells-itself-7/)
*   [What are the biggest lies your industry tells itself?](https://voyagela.com/2025/12/03/what-are-the-biggest-lies-your-industry-tells-itself-8/)
*   [Who taught you the most about work?](https://voyagela.com/2025/11/20/who-taught-you-the-most-about-work-6/)
*   [What is the story you hope people tell about you when you’re gone?](https://voyagela.com/2025/11/11/what-is-the-story-you-hope-people-tell-about-you-when-youre-gone-7/)
*   [Are you doing what you were born to do—or what you were told to do?](https://voyagela.com/2025/11/11/are-you-doing-what-you-were-born-to-do-or-what-you-were-told-to-do-6/)
*   [Was there ever a time you almost gave up?](https://voyagela.com/2025/11/11/was-there-ever-a-time-you-almost-gave-up-7/)

*   [![Image 8](https://voyagela.com/wp-content/uploads/2025/11/VoyageLA-INSP-main-cover-1-450x270.jpg) LA’s Most Inspiring Stories ---------------------------](https://voyagela.com/2025/12/02/las-most-inspiring-stories/)
*   [![Image 9](https://cdn.voyagela.com/wp-content/uploads/2024/04/cover1-min-450x270.jpg) A Tale of Two Friends ---------------------](https://voyagela.com/2017/01/09/tale-two-friends/)
*   [![Image 10](https://cdn.voyagela.com/wp-content/uploads/2024/04/Yoga-VoyageLA-450x270.jpg) Journey of a Lifetime ---------------------](https://voyagela.com/2016/12/01/the-journey-of-lifetime/)
*   [![Image 11](https://cdn.voyagela.com/wp-content/uploads/2024/04/VoyageLA2-min-450x270.jpg) The Quest to Empower Women --------------------------](https://voyagela.com/2016/10/29/leora-kashanis-quest-to-empower-women-through-active-wear/)
*   [![Image 12](https://cdn.voyagela.com/wp-content/uploads/2024/04/october-cover-3150x1803-min-450x270.jpg) How LA Foodies Get in Shape ---------------------------](https://voyagela.com/2016/10/03/foodies-guide-getting-shape-la/)

[local stories](https://voyagela.com/category/local-stories/)November 18, 2024

Exploring Life & Business with Andrea Bayon of Mar y Sol Wellness
=================================================================

![Image 13: Avatar photo](https://voyagela.com/wp-content/uploads/2024/06/VoyageLA-Staff_avatar-120x120.jpeg)

[Local Stories](https://voyagela.com/author/editorvoyagela/ "Posts by Local Stories")

[Share](https://voyagela.com/interview/exploring-life-business-with-andrea-bayon-of-mar-y-sol-wellness/# "Share on Facebook")[Tweet](https://voyagela.com/interview/exploring-life-business-with-andrea-bayon-of-mar-y-sol-wellness/# "Tweet This Post")[Pin](https://voyagela.com/interview/exploring-life-business-with-andrea-bayon-of-mar-y-sol-wellness/# "Pin This Post")

![Image 14](https://cdn.voyagela.com/wp-content/uploads/2024/11/c-1730315275580-personal_1730315275329_1730315275329_andrea_bayon_er0a2772.jpg)

![Image 15](https://cdn.voyagela.com/wp-content/uploads/2024/11/c-1730315275580-personal_1730315275329_1730315275329_andrea_bayon_er0a2772.jpg)

Today we’d like to introduce you to Andrea Bayon

**Hi Andrea, we’d love for you to start by introducing yourself.**

After earning my master’s in social work, I became an employee of larger organizations. And while my experience there was incredibly valuable, something kept drawing me

*[... truncated, 17,125 more characters]*

---

### Leadership & Business Podcast
*4,851 words* | Source: **EXA** | [Link](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/transcripts/130-andrea-sarate-workplace-strategy.pdf)

Leadership & Business Podcast | William & Mary School of Business

===============

[Skip to main content](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/transcripts/130-andrea-sarate-workplace-strategy.pdf#main_content)![Image 106: Raymond A. Mason School of Business logo](https://mason.wm.edu/_theme/_images/business_horizontal_green_gold.svg)

Menu Scroll to next section

[![Image 107: Raymond A. Mason School of Business](https://mason.wm.edu/_theme/_images/business_single_line_white_gold.svg)![Image 108: Raymond A. Mason School of Business](https://mason.wm.edu/_theme/_images/business_horizontal_white_gold.svg)](https://mason.wm.edu/index.php)

Close

Search Raymond A. Mason School of Business Submit search
*   [Undergraduate](https://mason.wm.edu/undergraduate/index.php)
*   [Graduate](https://mason.wm.edu/graduate/index.php)
*   [Careers](https://mason.wm.edu/careers/index.php)
*   [Alumni](https://mason.wm.edu/alumni/index.php)
*   [Faculty](https://mason.wm.edu/faculty/index.php)

*   [About](https://mason.wm.edu/about/index.php)
*   [Executive Partners](https://mason.wm.edu/executive-partners/index.php)
*   [Giving](https://mason.wm.edu/giving/index.php)

*   [Home](https://mason.wm.edu/news/leadership-and-business-podcast/index.php)
*   [News, Podcasts & Events](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/index.php)
*   Leadership & Business Podcast

Leadership & Business Podcast
=============================

In This Section
*   [News, Podcasts & Events](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/index.php)
*   [Business in Residence](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/business-in-residence/index.php)
*   [Current News Stories](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/2025/index.php)
*   [News Archive](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/news-archive/index.php)
*   [Leadership & Business Podcast](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/transcripts/index.php)
*   [Events](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/events/index.php)

![Image 109: Ken White](https://mason.wm.edu/news/leadership-and-business-podcast/index.php/transcripts/ken-white.jpg)Leadership & Business is an award-winning podcast series. It features the latest and best thinking from today's business leaders from across the world. Each episode features subject matter experts discussing strategies, tactics and information to help you become a more effective leader, communicator, and professional.

Launched in 2015, Leadership & Business is produced by William & Mary's Raymond A. Mason School of Business. Ken White, Associate Dean, Graduate Business Programs and former award-winning broadcast journalist, hosts the podcast.

2025
----

![Image 110: Digital recruitment with smart platforms concept](https://mason.wm.edu/news/leadership-and-business-podcast/the-job-market-2/images/digital-recruitment-with-smart-platforms-concept-card.jpg)

### [The Job Market](https://mason.wm.edu/news/leadership-and-business-podcast/the-job-market-2/index.php)

Episode 253: Phil Heavilin

![Image 111: Hands holding film slate near microphone](https://mason.wm.edu/news/leadership-and-business-podcast/no-story-no-success/images/hands-holding-a-film-slate-near-microphone-card.jpg)

### [No Story = No Success](https://mason.wm.edu/news/leadership-and-business-podcast/no-story-no-success/index.php)

Episode 252: Jason Ross & Francis Lyons

![Image 112: Person holding smartphone with logo of World Wide Fun Inc. (WWF) on screen in front of website](https://mason.wm.edu/news/leadership-and-business-podcast/passion-leadership-and-wildlife/images/person-holding-smartphone-with-logo-of-wwf-on-screen-in-front-of-website-card.jpg)

### [Passion, Leadership & Wildlife](https://mason.wm.edu/news/leadership-and-business-podcast/passion-leadership-and-wildlife/index.php)

Episode 251: Colby Loucks

![Image 113: King chess piece with strategy icon concepts of leadership](https://mason.wm.edu/news/leadership-and-business-podcast/the-role-of-the-ceo/images/king-chess-piece-with-strategy-icon-concepts-of-leadership-card.jpg)

### [The Role of the CEO](https://mason.wm.edu/news/leadership-and-business-podcast/the-role-of-the-ceo/index.php)

Episode 250: AnnaMaria DeSalva & Dan Draper

![Image 114: Finance analyst analyzing financial report and economic growth graph chart](https://mason.wm.edu/news/leadership-and-business-podcast/successful-investment-management/images/finance-analyst-analyzing-financial-report-and-economic-growth-graph-chart-card.jpg)

### [Successful Investment Management](https://mason.wm.edu/news/leadership-and-business-podcast/successful-investment-management/index.php)

Episode 249: Austin Camporin

![Image 115: High power electricity poles on technology abstract background](https://mason.wm.edu/news/leadership-and-business-podcast/the-need-f

*[... truncated, 91,770 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
