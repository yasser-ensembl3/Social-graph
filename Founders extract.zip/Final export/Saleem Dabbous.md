# Saleem Dabbous

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : KO_OP
**Durée dans le rôle** : 13 years 8 months in role
**Durée dans l'entreprise** : 13 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Co-Founder

## Résumé

I'm the studio director and co-founder of KO_OP, a worker owned studio. We've worked on original award winning games and high profile collaborations on major IPs. I oversee business, am an executive producer for our projects, and help guide the studio's direction alongside all full-time employees.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA1CaE4B0FvcJwbCMU1Rz65Fifyabri6b4Y/
**Connexions partagées** : 5


---

# Saleem Dabbous

## Position actuelle

**Entreprise** : KO_OP

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Saleem Dabbous
*KO_OP*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 24 |

---

## 📚 Articles & Blog Posts

### [AMA with Saleem Dabbous of KO_OP - Work With Indies](https://www.workwithindies.com/learn/ama-with-saleem-dabbous-of-ko-op)
*2025-05-21*
- Category: article

### [About – Saleem Dabbous – Medium](https://medium.com/@seemo/about)
*2025-04-29*
- Category: blog

### [Saleem Dabbous \(^-^)/ Work With Indies](https://www.workwithindies.com/people/saleem-dabbous)
*2025-01-01*
- Category: article

### [4 day work weeks, Goodbye Volcano High, and “self-care”](https://medium.com/@minimaker/four-day-work-weeks-goodbye-volcano-high-and-self-care-a-chat-with-ko-ops-saleem-dabbous-5307112f1eaa)
*2021-09-29*
- Category: blog

### [Saleem Dabbous - Studio Director at KO_OP | The Org](https://theorg.com/org/ko-op/org-chart/saleem-dabbous)
*2024-11-18*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[The independent studio behind some of Lara Croft GO's best levels ...](https://www.killscreen.com/independent-studio-behind-lara-croft-gos-best-levels/)**
  - Source: killscreen.com
  - *... Podcast · Explore · About. Sign in Subscribe. 21 Dec 2016 5 min ... Saleem Dabbous of KO_OP Mode to arrange a meeting. KO_OP Mode started to explo...*

- **[Indie game Winding Worlds is heading to Apple Arcade ...](https://www.godisageek.com/2020/05/indie-game-winding-worlds-is-heading-to-apple-arcade/)**
  - Source: godisageek.com
  - *May 15, 2020 ... The team at KO_OP like to add a personal touch to their games and each character you meet is named after a member of the team. Saleem...*

- **[Goodbye Volcano High Review - Teen problems, pop music and the ...](https://explosionnetwork.com/goodbye-volcano-high-review/)**
  - Source: explosionnetwork.com
  - *Sep 8, 2023 ... Kyle McKernan, Saleem Dabbous. Jenna Yow. Lucie Viatge, Ellen ... KO_OP may have taken a long time to get Goodbye Volcano High out the...*

- **[Black jackets, sunglasses, and radical accountability as a worker co ...](https://www.gamesindustry.biz/the-glory-society-black-jackets-sunglasses-and-radical-accountability)**
  - Source: gamesindustry.biz
  - *Mar 11, 2019 ... "Ted [Anderson] from Pixel Pushers Union 512 was super helpful, and of course our good friend Saleem [Dabbous] from KO_OP in Montreal...*

- **[Goodbye Volcano High (Video Game 2023) - IMDb](https://www.imdb.com/title/tt12497076/)**
  - Source: imdb.com
  - *Saleem Dabbous · Kyle McKernan. Writers. Kyle McKernan · Jenna Yow · All cast & crew ... KO_OP · See more company credits at IMDbPro · Tech specs · Ed...*

- **[Super Bomberman R vs Goodbye Volcano High Configuration, Price ...](https://www.gadgets360.com/compare-super-bomberman-r-107237-vs-goodbye-volcano-high-106930)**
  - Source: gadgets360.com
  - *Podcasts · Guide · Photos · Videos · Latest ... KO_OP. Developer. Konami Digital Entertainment, HexaDrive, KO_OP. Director. Akihiro Mitsuda, Saleem Da...*

- **[Video games are the new runway. Coveted fashion brands are ...](https://www.yahoo.com/entertainment/video-games-runway-coveted-fashion-201054797.html)**
  - Source: yahoo.com
  - *Dec 4, 2020 ... Podcasts · Videos · RSS · Jobs · Help · World Cup · More news. New on Yahoo ... Saleem Dabbous, KO_OP's studio director in Montreal, s...*

- **[AMA with Saleem Dabbous of KO_OP - Work With Indies](https://workwithindies.com/learn/ama-with-saleem-dabbous-of-ko-op)**
  - Source: workwithindies.com
  - *Hi! My name is Saleem Dabbous (he/they). I'm the co-founder and studio director over at KO_OP where we're making Goodbye ......*

- **['Gnog' Lets You Play Head Games In VR](https://www.alistdaily.com/digital/gnog-lets-play-head-games-vr/)**
  - Source: alistdaily.com
  - *May 2, 2017 ... Saleem Dabbous, KO_OP co-founder, studio director and producer for Gnog, described the game to AListDaily. “Gnog is about exploring th...*

- **[4 day work weeks, Goodbye Volcano High, and “self-care” | by Casa ...](https://medium.com/@minimaker/four-day-work-weeks-goodbye-volcano-high-and-self-care-a-chat-with-ko-ops-saleem-dabbous-5307112f1eaa)**
  - Source: medium.com
  - *Sep 29, 2021 ... ... Saleem Dabbous Saleem Dabbous (@Seemo on Twitter) is the … ... When interviewed (before the tweets above were made) Saleem mentio...*

---

*Generated by Founder Scraper*
