# Eloi Beauchamp

## Position actuelle

**Titre** : CEO & FOUNDER
**Entreprise** : L'ELOI
**Durée dans le rôle** : 25 years 11 months in role
**Durée dans l'entreprise** : 25 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Media Production

## Description du rôle

We are a Full Service Creative Studio
We are a Design Driven Production Company

## Résumé

“It’s just because I love the creative process of producing images that I do this crazy job…” l’Éloi

Production l’Éloi was founded in 2000 in Montreal. The business model is simple: we manage incredible talent and we make their lives easier by producing the shoots. That way, all they have to do is focus on creating stunning images.

We represent true artists. Photographers, cinematographers, art directors, stylists, hair & make-up artists.

What really matters for us is that through the entire process, we keep a smooth flow with clear objectives and great communication. We act as the “catalyst” between the client and the artist. We carry the vision throughout the project. Because we’re focused and experienced, we know the result will be great.


*******************************************************************************************************

« C’est parce que le processus créatif derrière la production d’images me fascine que j’aime ce métier de fous… ». l’Éloi

Productions l’Éloi a vu le jour à Montréal en l’an 2000. Le modèle d’affaires est simple : nous gérons des talents exceptionnels et nous leur simplifions la vie en produisant les « shoots ». Ainsi, ils n’ont qu’à se concentrer sur la création d’images. 

Nous représentons de véritables artistes. Photographes, vidéastes, directeurs artistiques, stylistes, maquilleurs et coiffeurs.

Ce qui nous importe avant tout, c’est de mettre en place un processus fluide, avec des objectifs clairs et une excellente communication. Nous agissons comme catalyseur entre le client et l’artiste. Parce que nous sommes rigoureux et avons des années d’expérience, nous savons que le résultat sera saisissant.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAPDJfABffb5vI9fTrm6Lo2TuaujLE2oWu0/
**Connexions partagées** : 101


---

# Eloi Beauchamp

## Position actuelle

**Entreprise** : L'ÉLOI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Eloi Beauchamp

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7388668422764601344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/040a4371-d339-4f44-951b-4f3fe841f7dc | https://media.licdn.com/dms/image/v2/D4E05AQFhBMaeLDltrQ/feedshare-thumbnail_720_1280/B4EZljiWvEHEAw-/0/1758311575386?e=1765778400&v=beta&t=V-cNHCItiqoVkQTFeanknlJsi1MKYw-yYztEape8L4M | Dans mon parcours entrepreneurial, j'ai toujours voulu continuer à apprendre. Formation, mentorat, coaching, accompagnement... La Piscine MTL a été un partenaire important. Tant comme mentoré que comme mentor. Le grand cercle de la vie! Merci pour votre beau travail auprès de la communauté d'affaire de MTL. Merci Delphine Beauchamp. | 17 | 0 | 0 | 1mo | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:56.758Z |  | 2025-10-27T20:10:26.808Z | https://www.linkedin.com/feed/update/urn:li:activity:7374893408508600320/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7378858880711426049 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e461fb53-be83-4765-9e8f-6b8de8ea0252 | https://media.licdn.com/dms/image/v2/D4E05AQGCKXQclyP6Cg/videocover-low/B4EZl9HS4fGYB4-/0/1758740723864?e=1765778400&v=beta&t=3kZx-6WIa3isbuWQAshuLIwpUKqIfj3GtB4FXwcWsPk | I love this amazing team 🩵💙🩵 | 21 | 0 | 0 | 2mo | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:56.759Z |  | 2025-09-30T18:30:49.730Z | https://www.linkedin.com/feed/update/urn:li:activity:7376693318883176448/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7328073007531270145 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHicfOkHkC7sQ/feedshare-shrink_800/B4EZa2uTIxHoAk-/0/1746822314427?e=1766620800&v=beta&t=gXwhg-xit6uLoWnQT7EEPhy_gI6LbBLGtxWP5Yy4a8w | Vive les étudiants allumés et inspirants!
Bravo Felix! | 36 | 0 | 0 | 6mo | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:56.759Z |  | 2025-05-13T15:05:54.008Z | https://www.linkedin.com/feed/update/urn:li:activity:7326703828408438785/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7299198381334188032 | Article |  |  | OK!
Qui veut venir jouer à faire briller les plus beaus créateurs visuels à l'international! Depuis 25 ans on grandit et maintenant on joue dans la cour des grands. Viens nous aider a continuer cette croissance.
Great people, amazing artists, fun company and infinite possibilities!
GO! | 52 | 1 | 6 | 9mo | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:56.760Z |  | 2025-02-22T22:48:26.658Z | https://www.grenier.qc.ca/emplois/83862/producteurtrice-executifve |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7290448698554155010 | Article |  |  | Si tu aime les images - If you love images
If you're into social media - Si t'es dans les médias sociaux
Si t'écris comme Shakespeare - If you write like Molière
This is a dream job your you - Voici ton emploi de rêve.
Équipe de feu - Énergie vitale - Good People - Good Vibe | 50 | 2 | 5 | 10mo | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:56.761Z |  | 2025-01-29T19:20:19.722Z | https://www.grenier.qc.ca/emplois/83480/coordonnateurtrice-marketing-et-medias-sociaux |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7269852293888405505 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ed3206a1-9689-4835-8624-6fa2b91263ae | https://media.licdn.com/dms/image/v2/D4E05AQF4jp0YW81Qjg/videocover-high/videocover-high/0/1733258117322?e=1765778400&v=beta&t=M_tr9b4cK8vvTT6cim7jD_47jWivECxAVFK7ROyUXU8 | WOW... if you knew how happy this makes me. I love humans. I love ping pong. Amazing people playing ping pong...  Happy Camper, I am. Félicitation à l'équipe d'avoir organisé ce bel événement. Bravo à Clément Ginon et Souléman Diallo! Trop hâte à la prochaine édition pour prendre ma revenge!!! Great work on the shooting & Edit Hugo Beaupré. Vive la vie! | 69 | 7 | 0 | 1yr | Post | Eloi Beauchamp | https://www.linkedin.com/in/eloibeauchamp | https://linkedin.com/in/eloibeauchamp | 2025-12-08T05:20:59.325Z |  | 2024-12-03T23:17:34.187Z | https://www.linkedin.com/feed/update/urn:li:activity:7269811560930332672/ |  | 

---



---

# Eloi Beauchamp
*L'ÉLOI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [INTERVIEW: Eloi — Internet Tattoo](https://www.internettattoo.com/blog/interview-eloi-2021)
*2025-05-05*
- Category: blog

### [Synergy - avec Éloi Beauchamp (L'Éloi) - zu](https://zumtl.com/en/events/synergy-avec-eloi-beauchamp-leloi/)
*2021-09-28*
- Category: article

### [Episode 16 : Making Every Day Worth Writing About](https://www.growthstory.ca/episode-16-eloi-beauchamp-leloi/)
*2017-12-14*
- Category: article

### [Startup With Eloi - Podcast - Follow on Spotify](https://startupwitheloi.com/)
- Category: article

### [L’ÉLOI Reveals the World’s Beauty | LBBOnline](https://lbbonline.com/news/leloi-reveals-the-worlds-beauty)
*2024-06-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[L'ÉLOI: conquérir le monde, un edge créatif à la fois | Grenier aux ...](https://www.grenier.qc.ca/actualites/42990/leloi-conquerir-le-monde-un-edge-creatif-a-la-fois)**
  - Source: grenier.qc.ca
  - *Jul 25, 2024 ... Eloi Beauchamp par Jodi+Alex. Des débuts dans la mode à la pub. À sa création, L'ÉLOI était avant tout reconnue pour ses photographie...*

---

*Generated by Founder Scraper*
