# Alexandre Bouchard

## Position actuelle

**Titre** : CEO & Co-Founder
**Entreprise** : Hookdeck
**Durée dans le rôle** : 4 years 11 months in role
**Durée dans l'entreprise** : 4 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAuN98oBrtOIR0Kr7pX-q5NJH5WTQP5FnHo/
**Connexions partagées** : 193


---

# Alexandre Bouchard

## Position actuelle

**Entreprise** : Hookdeck

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Alexandre Bouchard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402708388620574720 | Article |  |  | When Shopify starts delivering duplicate webhooks, it’s usually because the app registered the same subscription twice, in config, code, or both.

Shopify’s structure is pretty simple.

Every store maintains its own webhook registry, and each entry is nothing more than a topic paired with a destination URL.

Every call that creates a webhook subscription adds a row for that store.

If your app registers orders/updated to /webhooks through shopify.app.toml and then does the same thing through shopifyApp() or a custom install script, you now have multiple active subscriptions that all point to the same handler.

From the outside, this shows up as duplicate jobs, repeated syncs, or background tasks that trigger more often than they should. 

It is easy to blame retries or network quirks, but the root cause is usually that you described the same intent several times in different layers of your app.

The fix is to standardize on one configuration path and strip out the rest.

With embedded apps, the expectation now is that webhook declarations live in shopify.app.toml, and the CLI handles creating or updating subscriptions automatically.

If you still have webhook registration inside shopifyApp() or install routines from older setups, remove that code so you’re not registering the same webhook twice.

If you want to be thorough, inspect what is already live by querying the Admin API for a store and grouping the returned webhooks by topic and URL.

Where you see duplicates, keep one record, delete the others, and then commit to TOML-only configuration so you do not reintroduce the same problem later.

Once you do that, duplicate deliveries stop being a recurring surprise and turn into something you have explicitly ruled out by design. | 14 | 1 | 1 | 2d | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.539Z |  | 2025-12-05T14:00:15.518Z | https://www.shopify.com/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402415902186586115 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFK2OY8Qj1l2Q/feedshare-shrink_800/B4EZrqqCR1GYAg-/0/1764873480739?e=1766620800&v=beta&t=Mot8zQUZZNk5mTnA_FA9KOfd2NPc_DQg6Imn1baB8lM | New in Hookdeck: Custom & suggested columns.

Gone are the days when you had to keep clicking through events to compare values or find the right one. You can now add any payload or header field directly to your event list. Email, order_id, topic, x-request-id — whatever helps you debug faster.

Hookdeck suggests columns based on your data and saves them with your views so they persist across sessions. | 20 | 3 | 1 | 3d | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.539Z |  | 2025-12-04T18:38:01.318Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401253216769748992 | Text |  |  | If you need to ship a fix for a webhook bug, you should be able to reproduce and test it on localhost in minutes.

 CLI exists to make that realistic, not just for one person on the team but for everyone who touches webhook code.

<1> It gives you a clean networking model. Providers send webhooks to a Hookdeck Source URL that never changes.

And the CLI is the one that reaches out from your machine, pulls events over that connection, and forwards them to your local server.

Your ports remain closed to the outside world, so you don't have to remember which ngrok URL is current. Additionally, you can stop and restart your app as many times as you want without needing to modify the provider configuration.

<2> It is built with multi-developer setups in mind because Hookdeck does not treat your local process as the thing that must answer the provider directly.

It can safely duplicate events and fan them out to more than one listener. You can have multiple CLI sessions connected to the same Source, each one filtered down to the events that matter for that developer.

One person might set Hookdeck listen 3000 shopify-source --filter-body '{"topic": "orders/updated"}' while another listens for a different topic or shop domain, all on the same app and store.

<3> The CLI tries to behave like a proper debugging tool, not just a pipe. The interactive screen shows a list of events with timestamps, methods, URLs, headers, bodies, and your local responses.

You can scroll through past webhooks, jump into a specific one, resend it, open it in the dashboard, or inspect every attempt and response.

Pressing R on a selected event resends that webhook to your app, so you can change your code, hit save, and then press R again to see how the new handler behaves with the same payload, status, and headers.

That makes regression debugging much easier: capture one real webhook that triggered a bug, save it in Hookdeck, and keep replaying it against your local branch until the bug is gone.

<4> It mirrors the same patterns you care about in production. Signature headers from providers are preserved, so you can test your HMAC checks or token validation locally.

Finally, this local flow is available for free, which lowers the friction for teams who want every developer, not just one “backend person,” to be able to run webhook tests on their own machine.

If you are still wiring webhooks straight into staging just to test a handler change, that is exactly the kind of workflow we wanted the CLI to replace. | 16 | 7 | 2 | 6d | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.540Z |  | 2025-12-01T13:37:55.513Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397288589828726784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHzb1XdqE6xOg/feedshare-shrink_800/B4EZqhyxUNHcAg-/0/1763651032853?e=1766620800&v=beta&t=xht3qAb1IlN3upTkj8YoV8Rwo-WV3i7KGaD9BxiEur0 | If you noticed a lag with your Shopify webhooks yesterday, 𝘆𝗼𝘂 𝘄𝗲𝗿𝗲𝗻'𝘁 𝗶𝗺𝗮𝗴𝗶𝗻𝗶𝗻𝗴 𝗶𝘁. Shopify experienced significant latency degradation for its webhooks.

Hookdeck Radar caught the anomaly immediately. Here is the timeline of what went down:

 • 6:00 PM UTC: Latency spiked to several minutes (p90) across all topics. This suggests generalized backpressure on the delivery services.
 • 6:15 PM UTC: Recovery.
 • 6:20 PM UTC: Performance degraded again—but this time, it was different.

While the first spike was general, the second spike was concentrated on specific topics: Product Updates and Inventory Levels.

This suggests the Shopify team likely made a deliberate decision to throttle specific topics to protect the wider system, or that downstream inventory services were hitting a bottleneck.

You cannot trust event sequences or timing. In distributed systems, degradation isn't an "if," it's a "when."

Don't wait for your customers to tell you things are broken. Get notified first with Hookdeck Radar alerts. | 32 | 7 | 4 | 2w | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.540Z |  | 2025-11-20T15:03:54.791Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7395098267304501250 | Text |  |  | You never really understand the importance of queuing until your system collapses because you didn’t have one.

We were running a massive promotional email campaign for a retail brand. The plan was simple: half a million personalized messages, each one dynamically generated using a shopper’s purchase history, product recommendations, and loyalty data.

We had tested this logic in staging, and everything looked clean, fast, and efficient.

But when I hit “Send” on the campaign launch day, our database got flooded with nearly a million webhook requests to generate and send those emails.

What followed was the kind of chaos engineers dread. Each one tried to query the same data store, trigger the same rendering job, and push the email out simultaneously.

It was one of those painful but unforgettable moments, realizing the issue wasn’t code quality; it was architecture. Looking back, the code did exactly what it was supposed to, until the system faced real pressure.

That’s when I realized reliability isn’t something you plug in later; it has to be baked into every design decision early on.

After that incident, we redesigned everything around buffered ingestion. Requests don’t go straight in anymore; they get staged, queued, retried intelligently, and processed predictably. | 17 | 2 | 1 | 3w | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.541Z |  | 2025-11-14T14:00:21.207Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394053357193142272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpow1tTbuePg/feedshare-shrink_800/B4EZpz0FtUIQAk-/0/1762879679579?e=1766620800&v=beta&t=4eVpwdqsxD8k20WsQAfuyBMUDiDUp__C50yPA99kF4Q | Small changes compound into big improvements. Last week, finding the right events in your Hookdeck history just got easier. | 13 | 5 | 0 | 3w | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:13:56.541Z |  | 2025-11-11T16:48:15.223Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7392599703122767872 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEFbwKqrH4IaA/image-shrink_800/B4EZpfKP.7GoAc-/0/1762533115223?e=1765778400&v=beta&t=kENO591BwfUlLBzs2wmkiWIitPfWo5ypVCerRM1rvC4 | Agree. You cannot scale what you cannot see. 

Put Hookdeck in the middle, get queues, replays, and clean logs, then move faster without hoping nothing breaks. | 14 | 0 | 2 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.633Z |  | 2025-11-07T16:31:57.085Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7391650282293866496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHzBhVDraPyYQ/feedshare-shrink_800/B4EZpQ5N7rIwAg-/0/1762293769613?e=1766620800&v=beta&t=ewqTGudWgfYtMrgYj8twhqdGRiLTgrbGR6LkAXc9sp4 | A year ago, Hookdeck Outpost was a side-project for something we truly believed in. Today, it's taking center stage, with Fran Mendez joining our team to lead it. 😳

For those who might not realize what this means, Fran is the best person we could have hoped for to scale Outpost and the Event Destinations Initiative. Having built the AsyncAPI Initiative into a leading standard for event-driven architecture, he has demonstrated that great ideas, dedication, and conviction, when built with a community and open-source-first approach, can lead to an outsized impact.

We have a lot more news to come on that front, but if you are looking to send events (& webhooks) to your end users, and your current system is not stable enough or too costly, reach out! | 35 | 3 | 2 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.634Z |  | 2025-11-05T01:39:17.520Z | https://www.linkedin.com/feed/update/urn:li:activity:7391595811765170177/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7391120858544762880 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZJgretI1blw/feedshare-shrink_800/B4EZpKJP7YKsAo-/0/1762180531499?e=1766620800&v=beta&t=hIKPFsIRq9Vh1xQ8yGvckIBFwWjAe4fuSMGOYTvTH1s | You can now track the real-time latency of Shopify webhooks!

When your webhooks go from 2 seconds to 30 seconds, you're left guessing. Is Shopify having issues, or is it your infrastructure? You can't tell because you only see your own webhooks.

Hookdeck Radar solves this by aggregating data from billions of webhooks and making it public, so you can actually see what's happening. Subscribe to latency spike alerts via email or webhooks.

Here's what Shopify's baseline actually looks like:

Avg latency sits around 2.3 seconds
p90 varies between 3-6 seconds
p99 can spike to 20+ seconds during peak periods

During events like Black Friday, if Radar shows elevated latency across the board, you know it's the producer scaling under load—not your infrastructure failing.

We're planning to add more producers based on demand—Stripe, GitHub, and Twilio are next on the list. Which one should we add next?

Link in the comments ✌️ | 29 | 6 | 3 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.634Z |  | 2025-11-03T14:35:33.062Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7390007452118757376 | Text |  |  | As a Shopify app developer, if Hookdeck didn’t exist, your options would look something like this 👇

1. No infrastructure at all

Most apps do this at first: no queue, no retry strategy, just synchronous webhook calls. 

It’s fine for a dev store with a few orders, but when a single merchant grows or Shopify retries about 1000 updates, your app falls behind.

By changing one webhook URL to Hookdeck, everything is automatically queued, retries occur on failure, and you gain full visibility into every request, all without needing to modify any code.

2. AWS EventBridge or Google Pub/Sub

Most Shopify devs aren’t running massive AWS or GCP stacks, and if they try, they’ll lose hours wrestling with IAM permissions, tangled policies, and access rules long before a single webhook even reaches their system.

Then come the dashboards, messy configuration, vague logs, and retries that need to be glued together with three other services.

Hookdeck combines the parts you would need to cobble together (EventBridge, SQS, CloudWatch, DynamoDB) but focuses entirely on reliable webhook delivery.

3. Build your own (RabbitMQ, etc.)

Launching RabbitMQ on Fly or Heroku feels simple at first, but once your queues start filling and memory hits its limit, the system fails, forcing you to chase lost events, spend hours debugging, and pay far more in compute than the app is actually worth.

Hookdeck exists to remove all the webhook headaches from your life: we handle automatic queuing, retrying failures, and logging every request so your app always processes every event without you having to touch a line of infrastructure code. | 25 | 4 | 4 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.635Z |  | 2025-10-31T12:51:16.284Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7389285020030414848 | Text |  |  | We once had a large dev team reach out about intermittent timeouts, the kind of issue that makes you question your own monitoring setup before blaming anything else.

Their requests to Hookdeck occasionally brushed against a 3-second response limit, which resulted in a few being timed out in Shopify logs.

But here’s the thing: the actual failure rate was just around one in a hundred thousand.

The data always went through, and the retries succeeded instantly, so in practice, nothing was broken.

But anyone who’s watched production logs knows seeing “timeout” in your logs makes you question everything, even when the system’s fine.

So we took it up and

- tore down the ingestion path,
- rebuilt the request handler,
- tuned our concurrency model, and
- restructured acknowledgment logic to eliminate even those rare spikes.

It took weeks to fix what most teams would’ve ignored.

But it mattered to someone watching the dashboard turn red, and that was enough for us to pick it up. | 24 | 2 | 3 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.636Z |  | 2025-10-29T13:00:35.052Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7388996085576388609 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGgRpRgwY1aBA/feedshare-shrink_800/B4EZor8rZeGcAg-/0/1761673941064?e=1766620800&v=beta&t=pUm8-AgWAmwjgD_uZCygU7NxmH9tofXQ-6bDVQI2mpw | I'll just say it, you are sleeping on the Hookdeck CLI.

Working with webhooks locally is unparalleled on v1.1.0

→ Your entire team can listen to the same webhook URL simultaneously

→ Filter events for your session server-side: --filter-headers { "x-shopify-topic": "orders/created" }

→ Retry recent events without leaving the terminal with key [R]

→ Browse history and view request/response data with key [D]

It's 100% free. No account needed.

𝗻𝗽𝗺 𝗶 –𝗴 𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸–𝗰𝗹𝗶 or 𝗯𝗿𝗲𝘄 𝗶𝗻𝘀𝘁𝗮𝗹𝗹 𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸/𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸/𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸 

What should we add next? | 74 | 14 | 4 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.637Z |  | 2025-10-28T17:52:27.710Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7387114340413517824 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGBJpjHNFTOSA/image-shrink_800/B4EZoRNWfHKcAc-/0/1761225304492?e=1765778400&v=beta&t=c6A0L08W2F4ugA00nEEyvyIt030vplSwTm3hEDNsyEg | That feeling when a customer passes on free $250 in credits because he's thankful for your product and support 🤩 | 23 | 1 | 2 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.638Z |  | 2025-10-23T13:15:04.702Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7386744426301386752 | Text |  |  | I used to build for smooth checkouts and happy customers, until custom apps made everything depend on webhooks. 

That’s when I learned reliability decides the journey.

Here are 4 things I wish I knew before touching webhooks:

𝟭. 𝗪𝗲𝗯𝗵𝗼𝗼𝗸𝘀 𝗻𝗲𝘃𝗲𝗿 𝗯𝗲𝗵𝗮𝘃𝗲 𝘁𝗵𝗲 𝘄𝗮𝘆 𝘆𝗼𝘂 𝗲𝘅𝗽𝗲𝗰𝘁

Webhooks are late, duplicated, or sometimes don’t arrive at all, which means you can’t trust their order or timing. 

The only thing you can rely on is proper idempotency and retries that actually guarantee each event is processed exactly once.

First-time developers rarely anticipate how often this happens, and it’s one of those issues you only truly understand when duplicates start showing up in your orders or payments unexpectedly retry themselves.

𝟮. 𝗥𝗲𝗹𝗶𝗮𝗯𝗶𝗹𝗶𝘁𝘆 𝗽𝗿𝗼𝗯𝗹𝗲𝗺𝘀 𝘀𝗵𝗼𝘄 𝘂𝗽 𝗯𝗲𝗳𝗼𝗿𝗲 𝘀𝗰𝗮𝗹𝗲

We thought skipping queues was fine at first, but customer complaints about missing orders quickly showed that some webhooks weren’t being processed at all. Suddenly, all our time went into debugging delivery instead of shipping new features.

𝟯. 𝗩𝗼𝗹𝘂𝗺𝗲 𝗲𝘅𝗽𝗼𝘀𝗲𝘀 𝗲𝘃𝗲𝗿𝘆 𝘄𝗲𝗮𝗸 𝗹𝗶𝗻𝗸

You can handle raw HTTP requests without issue at 1,000 per minute, but once traffic grows to 10,000, messages get dropped.

When the volume reaches a million, queuing systems like RabbitMQ start inflating costs while requiring constant attention to retries, dead-letter queues, and memory management.

𝟰. 𝗧𝗵𝗲 𝘀𝗲𝗻𝗱𝗲𝗿 𝗰𝗼𝗻𝘁𝗿𝗼𝗹𝘀 𝘁𝗵𝗲 𝘁𝗲𝗺𝗽𝗼

It’s not your consumer that sets the pace. 

One producer might stop sending anything for hours, while another will dump 50,000 events in one go, and unless your queues, retries, and processing logic are built to absorb that unpredictability, you’ll inevitably lose data.

Webhooks sound small, but they pull you into distributed systems territory: queues, error recovery, and monitoring. 

Hookdeck makes sure you don’t have to learn distributed systems just to catch a webhook. | 21 | 5 | 3 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.639Z |  | 2025-10-22T12:45:10.305Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7386023416832618496 | Text |  |  | Most Shopify apps start with one webhook and end up battling queues, missed events, and scaling headaches. 

Hookdeck fixes that with instant queuing, full logs, smart retries, and deduplication. 

Let’s dive into each:

1. Full webhook logs, history, and metrics

View, search, and find every event that Shopify ever sent. Replay them, bookmark them, and build collections of test cases that mirror production behavior. Visualize your webhooks traffic, server response time, and error rates.

2. Queuing without code and infrastructure change

Traditional queues force you to spin up background workers, manage concurrency, and pray your DB holds. Hookdeck queues through an HTTP proxy; just swap the URL in Shopify, and you’re done.

Hookdeck queues automatically, without code changes or infrastructure.

3. Retry and replay control

When your server crashes, a migration fails, or you forgot about an edge case, replay what matters. Bulk retry all webhooks based on timestamp, status, or even payload content, such as x-shopify-store-name

4. Deduplicate to only process the webhooks you need

You’d be shocked at how many webhooks are redundant. Hookdeck lets you skip 90% of redundant events (like inventory updates). We’ve seen applications uselessly queue and process over 90% of webhooks from inventory updates. 

Hookdeck lets you only process the ones that actually change your product data, saving compute and queuing time. | 21 | 8 | 4 | 1mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.641Z |  | 2025-10-20T13:00:08.252Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7381336365138915328 | Article |  |  | If you haven't tried Railway yet, what they've done with their template is truly a world-class developer experience. It's without a doubt both the fastest and cheapest way to run Outpost right now if you want to give it a spin 💪 | 18 | 2 | 1 | 2mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.644Z |  | 2025-10-07T14:35:28.047Z | https://railway.com/deploy/outpost-starter |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7378769492375552000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgmmJH7GtgRQ/feedshare-shrink_800/B4EZmanv._HgAg-/0/1759235736757?e=1766620800&v=beta&t=lZ9zrBDGSvKTQ7Kqk7nMTS-_WGsmWdykW8oHAT3xYtE | I get it. Metrics in Hookdeck aren't enough. That's why we shipped metrics export to Prometheus so you can bring Hookdeck into your Grafana Labs dashboards.

Monitor webhook & events metrics such as throughput, error rates, queue depth and response latencies. | 15 | 1 | 1 | 2mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.647Z |  | 2025-09-30T12:35:37.890Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7376362155350126592 | Text |  |  | Nuntly is deploying Outpost from Hookdeck to power their webhook delivery. 💪 It enables the configuration management, queueing, retry logic, signatures, secret rotation, multi-tenancy and much more.

outpost.hookdeck.com | 11 | 1 | 0 | 2mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.649Z |  | 2025-09-23T21:09:44.017Z | https://www.linkedin.com/feed/update/urn:li:activity:7376301358259380226/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7375994699674775552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGdk7FwXtlMaA/feedshare-shrink_800/B4EZlzMFxdKgAg-/0/1758574174906?e=1766620800&v=beta&t=I5L_CXip0RB8HbQHaZzq5IhZR2SHkXF0ksU4nWGx6m4 | Ever had 1000,000 webhooks in your queue from a bulk Shopify import that you know will fail? Now you can cancel them. All of them. While they're still queued.

Hookdeck just shipped event cancellation – and as far as I know, we're the first event gateway where you can remove events from the queue based on any condition.

This isn't just about skipping events. It's queue control at a granular level:
- Filter by payload content, headers, or metadata
- Cancel events mid-flight during incidents or unexpected conditions

You're no longer stuck processing events you already know are problematic. Traditional queues don't give that level of granular control. Hookdeck represents a paradigm shift, offering fully controllable queues.

Details in the comments 👇 | 19 | 2 | 2 | 2mo | Post | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/alex-bouchard | 2025-12-08T05:14:01.650Z |  | 2025-09-22T20:49:35.757Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7402416083061866496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFK2OY8Qj1l2Q/feedshare-shrink_800/B4EZrqqCR1GYAg-/0/1764873480739?e=1766620800&v=beta&t=Mot8zQUZZNk5mTnA_FA9KOfd2NPc_DQg6Imn1baB8lM | New in Hookdeck: Custom & suggested columns.

Gone are the days when you had to keep clicking through events to compare values or find the right one. You can now add any payload or header field directly to your event list. Email, order_id, topic, x-request-id — whatever helps you debug faster.

Hookdeck suggests columns based on your data and saves them with your views so they persist across sessions. | 20 | 3 | 1 | 3d | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:03:55.848Z |  | 2025-12-04T18:38:44.442Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7401272900634320896 | Text |  |  | If you need to ship a fix for a webhook bug, you should be able to reproduce and test it on localhost in minutes.

 CLI exists to make that realistic, not just for one person on the team but for everyone who touches webhook code.

<1> It gives you a clean networking model. Providers send webhooks to a Hookdeck Source URL that never changes.

And the CLI is the one that reaches out from your machine, pulls events over that connection, and forwards them to your local server.

Your ports remain closed to the outside world, so you don't have to remember which ngrok URL is current. Additionally, you can stop and restart your app as many times as you want without needing to modify the provider configuration.

<2> It is built with multi-developer setups in mind because Hookdeck does not treat your local process as the thing that must answer the provider directly.

It can safely duplicate events and fan them out to more than one listener. You can have multiple CLI sessions connected to the same Source, each one filtered down to the events that matter for that developer.

One person might set Hookdeck listen 3000 shopify-source --filter-body '{"topic": "orders/updated"}' while another listens for a different topic or shop domain, all on the same app and store.

<3> The CLI tries to behave like a proper debugging tool, not just a pipe. The interactive screen shows a list of events with timestamps, methods, URLs, headers, bodies, and your local responses.

You can scroll through past webhooks, jump into a specific one, resend it, open it in the dashboard, or inspect every attempt and response.

Pressing R on a selected event resends that webhook to your app, so you can change your code, hit save, and then press R again to see how the new handler behaves with the same payload, status, and headers.

That makes regression debugging much easier: capture one real webhook that triggered a bug, save it in Hookdeck, and keep replaying it against your local branch until the bug is gone.

<4> It mirrors the same patterns you care about in production. Signature headers from providers are preserved, so you can test your HMAC checks or token validation locally.

Finally, this local flow is available for free, which lowers the friction for teams who want every developer, not just one “backend person,” to be able to run webhook tests on their own machine.

If you are still wiring webhooks straight into staging just to test a handler change, that is exactly the kind of workflow we wanted the CLI to replace. | 16 | 7 | 2 | 6d | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:03:55.849Z |  | 2025-12-01T14:56:08.512Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7395165008453840898 | Text |  |  | You never really understand the importance of queuing until your system collapses because you didn’t have one.

We were running a massive promotional email campaign for a retail brand. The plan was simple: half a million personalized messages, each one dynamically generated using a shopper’s purchase history, product recommendations, and loyalty data.

We had tested this logic in staging, and everything looked clean, fast, and efficient.

But when I hit “Send” on the campaign launch day, our database got flooded with nearly a million webhook requests to generate and send those emails.

What followed was the kind of chaos engineers dread. Each one tried to query the same data store, trigger the same rendering job, and push the email out simultaneously.

It was one of those painful but unforgettable moments, realizing the issue wasn’t code quality; it was architecture. Looking back, the code did exactly what it was supposed to, until the system faced real pressure.

That’s when I realized reliability isn’t something you plug in later; it has to be baked into every design decision early on.

After that incident, we redesigned everything around buffered ingestion. Requests don’t go straight in anymore; they get staged, queued, retried intelligently, and processed predictably. | 17 | 2 | 1 | 3w | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:03:55.851Z |  | 2025-11-14T18:25:33.537Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7392616928097292288 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEFbwKqrH4IaA/image-shrink_800/B4EZpfKP.7GoAc-/0/1762533115223?e=1765782000&v=beta&t=_rUj5SfutTaCk2euZwEi2LC4ItPJeZKEfQPsDHGpqug | Agree. You cannot scale what you cannot see. 

Put Hookdeck in the middle, get queues, replays, and clean logs, then move faster without hoping nothing breaks. | 14 | 0 | 2 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:03:55.853Z |  | 2025-11-07T17:40:23.839Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7391121274254610432 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZJgretI1blw/feedshare-shrink_800/B4EZpKJP7YKsAo-/0/1762180531499?e=1766620800&v=beta&t=hIKPFsIRq9Vh1xQ8yGvckIBFwWjAe4fuSMGOYTvTH1s | You can now track the real-time latency of Shopify webhooks!

When your webhooks go from 2 seconds to 30 seconds, you're left guessing. Is Shopify having issues, or is it your infrastructure? You can't tell because you only see your own webhooks.

Hookdeck Radar solves this by aggregating data from billions of webhooks and making it public, so you can actually see what's happening. Subscribe to latency spike alerts via email or webhooks.

Here's what Shopify's baseline actually looks like:

Avg latency sits around 2.3 seconds
p90 varies between 3-6 seconds
p99 can spike to 20+ seconds during peak periods

During events like Black Friday, if Radar shows elevated latency across the board, you know it's the producer scaling under load—not your infrastructure failing.

We're planning to add more producers based on demand—Stripe, GitHub, and Twilio are next on the list. Which one should we add next?

Link in the comments ✌️ | 29 | 6 | 3 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:03:55.856Z |  | 2025-11-03T14:37:12.175Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7389300715736948737 | Text |  |  | We once had a large dev team reach out about intermittent timeouts, the kind of issue that makes you question your own monitoring setup before blaming anything else.

Their requests to Hookdeck occasionally brushed against a 3-second response limit, which resulted in a few being timed out in Shopify logs.

But here’s the thing: the actual failure rate was just around one in a hundred thousand.

The data always went through, and the retries succeeded instantly, so in practice, nothing was broken.

But anyone who’s watched production logs knows seeing “timeout” in your logs makes you question everything, even when the system’s fine.

So we took it up and

- tore down the ingestion path,
- rebuilt the request handler,
- tuned our concurrency model, and
- restructured acknowledgment logic to eliminate even those rare spikes.

It took weeks to fix what most teams would’ve ignored.

But it mattered to someone watching the dashboard turn red, and that was enough for us to pick it up. | 24 | 2 | 3 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.018Z |  | 2025-10-29T14:02:57.200Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7389001051481202689 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGgRpRgwY1aBA/feedshare-shrink_800/B4EZor8rZeGcAg-/0/1761673941064?e=1766620800&v=beta&t=pUm8-AgWAmwjgD_uZCygU7NxmH9tofXQ-6bDVQI2mpw | I'll just say it, you are sleeping on the Hookdeck CLI.

Working with webhooks locally is unparalleled on v1.1.0

→ Your entire team can listen to the same webhook URL simultaneously

→ Filter events for your session server-side: --filter-headers { "x-shopify-topic": "orders/created" }

→ Retry recent events without leaving the terminal with key [R]

→ Browse history and view request/response data with key [D]

It's 100% free. No account needed.

𝗻𝗽𝗺 𝗶 –𝗴 𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸–𝗰𝗹𝗶 or 𝗯𝗿𝗲𝘄 𝗶𝗻𝘀𝘁𝗮𝗹𝗹 𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸/𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸/𝗵𝗼𝗼𝗸𝗱𝗲𝗰𝗸 

What should we add next? | 74 | 14 | 4 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.019Z |  | 2025-10-28T18:12:11.674Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7386755465960951808 | Text |  |  | I used to build for smooth checkouts and happy customers, until custom apps made everything depend on webhooks. 

That’s when I learned reliability decides the journey.

Here are 4 things I wish I knew before touching webhooks:

𝟭. 𝗪𝗲𝗯𝗵𝗼𝗼𝗸𝘀 𝗻𝗲𝘃𝗲𝗿 𝗯𝗲𝗵𝗮𝘃𝗲 𝘁𝗵𝗲 𝘄𝗮𝘆 𝘆𝗼𝘂 𝗲𝘅𝗽𝗲𝗰𝘁

Webhooks are late, duplicated, or sometimes don’t arrive at all, which means you can’t trust their order or timing. 

The only thing you can rely on is proper idempotency and retries that actually guarantee each event is processed exactly once.

First-time developers rarely anticipate how often this happens, and it’s one of those issues you only truly understand when duplicates start showing up in your orders or payments unexpectedly retry themselves.

𝟮. 𝗥𝗲𝗹𝗶𝗮𝗯𝗶𝗹𝗶𝘁𝘆 𝗽𝗿𝗼𝗯𝗹𝗲𝗺𝘀 𝘀𝗵𝗼𝘄 𝘂𝗽 𝗯𝗲𝗳𝗼𝗿𝗲 𝘀𝗰𝗮𝗹𝗲

We thought skipping queues was fine at first, but customer complaints about missing orders quickly showed that some webhooks weren’t being processed at all. Suddenly, all our time went into debugging delivery instead of shipping new features.

𝟯. 𝗩𝗼𝗹𝘂𝗺𝗲 𝗲𝘅𝗽𝗼𝘀𝗲𝘀 𝗲𝘃𝗲𝗿𝘆 𝘄𝗲𝗮𝗸 𝗹𝗶𝗻𝗸

You can handle raw HTTP requests without issue at 1,000 per minute, but once traffic grows to 10,000, messages get dropped.

When the volume reaches a million, queuing systems like RabbitMQ start inflating costs while requiring constant attention to retries, dead-letter queues, and memory management.

𝟰. 𝗧𝗵𝗲 𝘀𝗲𝗻𝗱𝗲𝗿 𝗰𝗼𝗻𝘁𝗿𝗼𝗹𝘀 𝘁𝗵𝗲 𝘁𝗲𝗺𝗽𝗼

It’s not your consumer that sets the pace. 

One producer might stop sending anything for hours, while another will dump 50,000 events in one go, and unless your queues, retries, and processing logic are built to absorb that unpredictability, you’ll inevitably lose data.

Webhooks sound small, but they pull you into distributed systems territory: queues, error recovery, and monitoring. 

Hookdeck makes sure you don’t have to learn distributed systems just to catch a webhook. | 21 | 5 | 3 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.023Z |  | 2025-10-22T13:29:02.365Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7386097355046952961 | Text |  |  | Most Shopify apps start with one webhook and end up battling queues, missed events, and scaling headaches. 

Hookdeck fixes that with instant queuing, full logs, smart retries, and deduplication. 

Let’s dive into each:

1. Full webhook logs, history, and metrics

View, search, and find every event that Shopify ever sent. Replay them, bookmark them, and build collections of test cases that mirror production behavior. Visualize your webhooks traffic, server response time, and error rates.

2. Queuing without code and infrastructure change

Traditional queues force you to spin up background workers, manage concurrency, and pray your DB holds. Hookdeck queues through an HTTP proxy; just swap the URL in Shopify, and you’re done.

Hookdeck queues automatically, without code changes or infrastructure.

3. Retry and replay control

When your server crashes, a migration fails, or you forgot about an edge case, replay what matters. Bulk retry all webhooks based on timestamp, status, or even payload content, such as x-shopify-store-name

4. Deduplicate to only process the webhooks you need

You’d be shocked at how many webhooks are redundant. Hookdeck lets you skip 90% of redundant events (like inventory updates). We’ve seen applications uselessly queue and process over 90% of webhooks from inventory updates. 

Hookdeck lets you only process the ones that actually change your product data, saving compute and queuing time. | 21 | 8 | 4 | 1mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.025Z |  | 2025-10-20T17:53:56.496Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7378787295509848064 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHgmmJH7GtgRQ/feedshare-shrink_800/B4EZmanv._HgAg-/0/1759235736757?e=1766620800&v=beta&t=lZ9zrBDGSvKTQ7Kqk7nMTS-_WGsmWdykW8oHAT3xYtE | I get it. Metrics in Hookdeck aren't enough. That's why we shipped metrics export to Prometheus so you can bring Hookdeck into your Grafana Labs dashboards.

Monitor webhook & events metrics such as throughput, error rates, queue depth and response latencies. | 15 | 1 | 1 | 2mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.029Z |  | 2025-09-30T13:46:22.488Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7375999444531552256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGdk7FwXtlMaA/feedshare-shrink_800/B4EZlzMFxdKgAg-/0/1758574174906?e=1766620800&v=beta&t=I5L_CXip0RB8HbQHaZzq5IhZR2SHkXF0ksU4nWGx6m4 | Ever had 1000,000 webhooks in your queue from a bulk Shopify import that you know will fail? Now you can cancel them. All of them. While they're still queued.

Hookdeck just shipped event cancellation – and as far as I know, we're the first event gateway where you can remove events from the queue based on any condition.

This isn't just about skipping events. It's queue control at a granular level:
- Filter by payload content, headers, or metadata
- Cancel events mid-flight during incidents or unexpected conditions

You're no longer stuck processing events you already know are problematic. Traditional queues don't give that level of granular control. Hookdeck represents a paradigm shift, offering fully controllable queues.

Details in the comments 👇 | 19 | 2 | 2 | 2mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.030Z |  | 2025-09-22T21:08:27.019Z |  |  | 

---

## Post 31

https://www.linkedin.com/feed/update/urn:li:activity:7368733747078123520 | Text |  |  | Hookdeck is hiring a Technical Product Marketer to build awareness for the Event Gateway to developers building event-driven systems. We process billions of events monthly, but that means nothing if developers don't know we exist.

The role: Own top-of-funnel growth. Plan launches. Write technical content that actually gets read. Turn our product capabilities into distribution strategies that reach developers where they are.

You'll be working directly with me and Phil Leggetter. Recent projects include launching Outpost (our open-source event destination implementation), Hookdeck's new dashboard and rebuilding our website messaging.

We're a small team that values high autonomy. Your work ships fast and directly impacts how thousands of developers discover and understand modern event management.

Shoot me a DM! More in the comments 👇

#hiring #productmarketing | 51 | 6 | 7 | 3mo | Maurice Kherlakian reposted this | Alexandre Bouchard | https://www.linkedin.com/in/alex-bouchard | https://linkedin.com/in/mkherlakian | 2025-12-08T06:04:00.034Z |  | 2025-09-02T19:57:09.756Z |  |  | 

---



---

# Alexandre Bouchard
*Hookdeck*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 19 |
| Press & Mentions (Google) | 16 |

---

## 📚 Articles & Blog Posts

### [Alex Bouchard from Hookdeck. Competition is a good sign](https://metacast.app/podcast/scaling-devtools/sWRNa8lj/alex-bouchard-from-hookdeck-competition-is-a-good-sign/SERHBi0o)
- Category: podcast

### [Hookdeck and Building an Event Gateway with Alex Bouchard](https://softwareengineeringdaily.com/2024/04/16/hookdeck-and-building-an-event-gateway-with-alex-bouchard/)
*2024-04-16*
- Category: article

### [Company - Hookdeck](https://hookdeck.com/company)
*2025-01-01*
- Category: article

### [Webhooks at Scale with Alexandre Bouchard](https://softwareengineeringdaily.com/2023/01/16/webhooks-at-scale/)
*2023-01-16*
- Category: article

### [Alexandre Bouchard – Medium](https://alexbouchard.medium.com/?source=post_internal_links---------3----------------------------)
*2021-05-05*
- Category: blog

---

## 🎬 YouTube Videos

- **[Performer sur Linkedin avec Alexandre Bouchard, Président V3 Stent](https://www.youtube.com/watch?v=fFJIKkU-GSE)**
  - Channel: Défi Montréal
  - Date: 2023-09-02

- **[Paroles d&#39;entrepreneurs avec Alexandre Bouchard, co-fondateur de V3 Stent](https://www.youtube.com/watch?v=hnRxR4bqPh0)**
  - Channel: Québec Tech
  - Date: 2024-09-19

- **[Road to the IPO | Podcast #76 | Alexandre Bouchard](https://www.youtube.com/watch?v=lfnPxTvufa4)**
  - Channel: Hugo Prince
  - Date: 2020-04-13

- **[Alternatives au marketing numérique pour faire connaître ses services professionnels B2B](https://www.youtube.com/watch?v=zc8-IOj9Bsg)**
  - Channel: Marie-Eve Plamondon - Communications
  - Date: 2025-06-11

- **[Alexandre Bouchard vs Joel Roch LHSAM Dec 3/11](https://www.youtube.com/watch?v=1XtsBFYU7iU)**
  - Channel: 4thLineVoice
  - Date: 2025-09-15

- **[EP.26 : L’histoire d’Alexandre Bouchard: donner vie à vos idées et devenir un entrepreneur à succès](https://www.youtube.com/watch?v=AcT4gQn_VIc)**
  - Channel: Openmind Tech
  - Date: 2023-07-06

- **[PodCast des Chassé Brothers du 31 Janvier avec Alexandre Bouchard du groupe Tout Croche.](https://www.youtube.com/watch?v=aFa9SjMP_N8)**
  - Channel: Nic Chassé
  - Date: 2025-02-01

- **[ÉPISODE 25 - On discute entreprenariat avec Alexandre Bouchard - Équilibre Digital](https://www.youtube.com/watch?v=n5e7WiZU0tQ)**
  - Channel: Wavency
  - Date: 2021-09-29

- **[SXSW vu par mon invité Alexandre Bouchard | L&#39;Accélérateur #085](https://www.youtube.com/watch?v=7SESP2zhwBI)**
  - Channel: Académie du Podcast
  - Date: 2018-03-23

- **[Alexandre Bouchard – Non-Reversible Parallel Tempering](https://www.youtube.com/watch?v=bRZ1kXYEfh8)**
  - Channel: MCQMC 2020
  - Date: 2020-08-21

---

## 🔎 Press & Mentions

- **[Manage webhooks at scale with AWS Serverless - DEV Community](https://dev.to/aws-builders/manage-webhooks-at-scale-with-aws-serverless-fof?bb=59814)**
  - Source: dev.to
  - *Dec 15, 2021 ... Alexandre Bouchard. Alexandre Bouchard. Alexandre Bouchard. Follow. Co-Founder @ Hookdeck. ... Podcasts · Videos · DEV Education Trac...*

- **[Stay within limits: API rate-limit-friendly pattern for Stripe webhooks ...](https://stripe.dev/blog/stay-within-limits-api-rate-limit-friendly-pattern-for-stripe-webhooks)**
  - Source: stripe.dev
  - *Jul 3, 2025 ... Catch more details on using Stripe with Hookdeck in this interview with co-founder Alexandre Bouchard, on the Stripe Developers YouTub...*

- **[Working with Webhooks: Security - DEV Community](https://dev.to/hookdeck/working-with-webhooks-security-2a32)**
  - Source: dev.to
  - *Don't get scammed on an interview. Cover Image. Logo If You Think YOUR Commit Messages Are Bad, ... Alexandre Bouchard for Hookdeck. Posted on May 5, ...*

- **[The future of event-driven apps: lessons from 100B+ webhooks ...](https://www.youtube.com/watch?v=uwcSJFsQ83c)**
  - Source: youtube.com
  - *Jun 19, 2025 ... Join Stripe's Ben Smith for a deep dive into the future of event-driven architecture with Alexandre Bouchard, co-founder and CEO of H...*

- **[How to Synchronize Orders with Shopify Webhooks](https://hookdeck.com/webhooks/platforms/how-to-synchronize-orders-shopify-webhooks)**
  - Source: hookdeck.com
  - *Feb 20, 2021 ... Author picture Alexandre Bouchard. How to Synchronize Orders with ... Hookdeck CLI is a great tool just for that. hookdeck listen 300...*

- **[Hookdeck raises $2.65 million CAD to connect the information that ...](https://betakit.com/hookdeck-raises-2-9-million-to-connect-the-information-that-rules-the-web/)**
  - Source: betakit.com
  - *Apr 12, 2022 ... Alexandre Bouchard and Eric Bang-Tri Tran worked on Hookdeck as a ... “Soon after launching … and having the chance to talk with many...*

- **[Hookdeck - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/hookdeck)**
  - Source: crunchbase.com
  - *Founders Alexandre Bouchard, Eric Tran, Maurice Kherlakian. About the Company. Hookdeck is a fast and reliable event gateway for receiving, processing...*

- **[The Future of AI Monetization: Announcing Orb Simulations - Orb](https://www.withorb.com/blog/announcing-orb-simulations)**
  - Source: withorb.com
  - *Feb 24, 2025 ... ... Talk to Orb. Announcements. 4. min read. The Future of AI ... Alexandre Bouchard, CEO & Co-founder at Hookdeck. ‍The Future of AI...*

- **[Orb | Simulations](https://www.withorb.com/simulations)**
  - Source: withorb.com
  - *... Talk to Orb. Orb Simulations. Stop hallucinating on pricing. Test pricing ... Alexandre Bouchard. CEO & Co-founder at Hookdeck. Let's build the fu...*

- **[MTL_code · Luma](https://luma.com/u1urhxu3)**
  - Source: luma.com
  - *MTL_code is a laid-back evening where you can expect pizza, drinks, and a talk ... ​Alexandre Bouchard, CEO and Co-Founder of Hookdeck, will present W...*

---

*Generated by Founder Scraper*
