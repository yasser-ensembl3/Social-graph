# Claude Perron

## Position actuelle

**Titre** : President & Founder
**Entreprise** : FIAMtl
**Durée dans le rôle** : 5 years 11 months in role
**Durée dans l'entreprise** : 5 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Non-profit Organizations

## Résumé

With over 27 years of leadership at Crystalline Management, the focus has been on crafting tailored asset and portfolio management solutions to meet diverse client needs. Previous experience as Vice-President of Investment Banking at Midland/Merrill Lynch further strengthened a strategic approach to investment strategies, enabling the organization to deliver impactful results. Driven by a commitment to empowering clients, Crystalline Management leverages expertise in investment strategies to foster long-term financial growth. Dedicated to collaboration and adaptability, the aim is to align with client goals while navigating a dynamic financial landscape.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAGBRkQBGqf5obv0LOIQxM09Gco4PTWpbak/
**Connexions partagées** : 59


---

# Claude Perron

## Position actuelle

**Entreprise** : FIAMtl

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Claude Perron

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402036310812815360 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEVrKyBr21RwA/feedshare-shrink_800/B56ZrlAn7ALEAg-/0/1764778750191?e=1766620800&v=beta&t=Bu8ZwqoPRX-NcUd_bu_jXlXu_FKqSeDKuEyEuRr8rhA | À very successful event that highlight a growing culture of collaboration / togetherness in Montreal | 16 | 1 | 0 | 4d | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:34.969Z |  | 2025-12-03T17:29:39.682Z | https://www.linkedin.com/feed/update/urn:li:activity:7402018593439428608/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7398489789718556672 | Text |  |  | I am reinforcing Russ’ invitation to PhD students 
-  Join FIAM’s unique Institutionnal  academic/ industry ecosystem -  great learning opportunities - promising personal exposure to industry leadership | 2 | 0 | 0 | 2w | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:37.880Z |  | 2025-11-23T22:37:03.162Z | https://www.linkedin.com/feed/update/urn:li:activity:7394054075648204801/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397764127789641728 | Article |  |  | Une occasion d’être exposé à l’écosystème d’opération du COO - donc - mieux comprendre son rôle dans le mandat global  du COO - une opportunité d’apprentissage exceptionnelle pour un candidat qui épouse  la culture de IA - innovation , team work , strategic thinking … | 7 | 0 | 0 | 2w | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:37.883Z |  | 2025-11-21T22:33:31.876Z | https://ia.ca/fr/carrieres/job/JR10024875 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7393471127970525184 | Text |  |  | Congradulations to the HEC Team | 0 | 0 | 0 | 4w | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:42.724Z |  | 2025-11-10T02:14:40.959Z | https://www.linkedin.com/feed/update/urn:li:activity:7392540182752964608/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7393469254790197248 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGBNtUxFunvWw/feedshare-shrink_800/B4DZplNhoRIAAg-/0/1762634636513?e=1766620800&v=beta&t=AcHMMIIHyRcNUQ4gf_fBhdJUwy4HkT-ROKnTP0XxwQA | Une expérience d’apprentissage exceptionnelle - une collaboration étroite industrie/ académique appuyée en présentielle par la haute direction de grandes institutions financières | 10 | 0 | 0 | 4w | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:42.725Z |  | 2025-11-10T02:07:14.358Z | https://www.linkedin.com/feed/update/urn:li:activity:7393025513004449792/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7392412635411156992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH3IsojXmZxyQ/feedshare-shrink_800/B4EZpbaDHfIIAg-/0/1762470149736?e=1766620800&v=beta&t=vlF4UFdm9Da8PXXNi-Kc3wQ058t9s-LACAim9BKkmFs | Félicitations Going concern | 3 | 0 | 0 | 1mo | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:42.726Z |  | 2025-11-07T04:08:36.667Z | https://www.linkedin.com/feed/update/urn:li:activity:7392335608029032448/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7385051906584363010 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHzhxpuzxx_nA/feedshare-shrink_800/B4EZnzDW7AKcAg-/0/1760719368695?e=1766620800&v=beta&t=5TfFAeZbuNEtzJZizUDaEYsj3QxeTrFNeibkhoFwiNc | An amaysing event I attend every year except this year unfortunately. 
Congradulations to Claire, Michelle and team 
Great testimonials photos | 5 | 0 | 0 | 1mo | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:42.729Z |  | 2025-10-17T20:39:42.159Z | https://www.linkedin.com/feed/update/urn:li:activity:7384992294447366144/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7379910629974855680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEfFGs5ELaXeg/feedshare-shrink_800/B4EZmqJs_oGYAg-/0/1759496295105?e=1766620800&v=beta&t=0F_w1ipZkOpbsDaxTP_ov0uwRokg_yXXMYstz-ilkuc | Montreal is priviledged to host CAASA’s Flagship event every year - Great content, engineered and assembled by Bodhi Research - congradulations Ranjan, James and team | 6 | 0 | 0 | 2mo | Post | Claude Perron | https://www.linkedin.com/in/claude-perron-a845578 | https://linkedin.com/in/claude-perron-a845578 | 2025-12-08T04:47:42.734Z |  | 2025-10-03T16:10:06.295Z | https://www.linkedin.com/feed/update/urn:li:activity:7379862353120628736/ |  | 

---



---

# Claude Perron
*FIAMtl*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Claude Perron - Crystalline Management | LinkedIn](https://ca.linkedin.com/in/claude-perron-a845578)
*2025-05-12*
- Category: article

### [Ambassadors – FIAMtl](https://fiamtl.com/ambassadors/)
*2025-01-01*
- Category: article

### [About Us – FIAMtl](https://fiamtl.com/about-us/)
*2024-06-01*
- Category: article

### [](https://fiamtl.com/about-us/founding-members/)
- Category: article

### [CAASA Annual Review 2022](https://caasa.ca/wp-content/uploads/2023/03/CAASA-2022-Annual-Review-no-MD.pdf)
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 56,233 words total*

### Claude Perron - FIAMtl | LinkedIn
*4,223 words* | Source: **EXA** | [Link](https://ca.linkedin.com/in/claude-perron-a845578)

Claude Perron - FIAMtl | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/in/claude-perron-a845578#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_profile_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=public_profile_guest_nav_menu_articles)
*   [People](https://ca.linkedin.com/pub/dir/+/+?trk=public_profile_guest_nav_menu_people)
*   [Learning](https://ca.linkedin.com/learning/search?trk=public_profile_guest_nav_menu_learning)
*   [Jobs](https://ca.linkedin.com/jobs/jobs-in-clovis-ca?trk=public_profile_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=public_profile_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fclaude-perron-a845578&fromSignIn=true&trk=public_profile_nav-header-signin)[Join for free](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=claude-perron-a845578&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fin%2Fclaude-perron-a845578&trk=public_profile_nav-header-join)[![Image 1](https://ca.linkedin.com/in/claude-perron-a845578)](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fca%2Elinkedin%2Ecom%2Fin%2Fclaude-perron-a845578&fromSignIn=true&trk=public_profile_nav-header-signin)

![Image 2](https://static.licdn.com/aero-v1/sc/h/5q92mjc5c51bjlwaj3rs9aa82)

![Image 3: Claude Perron](https://ca.linkedin.com/in/claude-perron-a845578)

![Image 4](https://ca.linkedin.com/in/claude-perron-a845578)
Sign in to view Claude’s full profile
-------------------------------------

Claude can introduce you to 2 people at FIAMtl

 Email or phone  

 Password  

Show

[Forgot password?](https://ca.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=claude-perron-a845578&trk=public_profile_logo_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

Claude Perron
=============

![Image 5](https://ca.linkedin.com/in/claude-perron-a845578)
Sign in to view Claude’s full profile
-------------------------------------

Claude can introduce you to 2 people at FIAMtl

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=claude-perron-a845578&trk=public_profile_top-card_title-modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

### Montreal, Quebec, Canada Contact Info 

![Image 6](https://ca.linkedin.com/in/claude-perron-a845578)
Sign in to view Claude’s full profile
-------------------------------------

Claude can introduce you to 2 people at FIAMtl

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/public-profile-join?vieweeVanityName=claude-perron-a845578&trk=public_profile_profile-info-subheader_contact-info_modal_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

 4K followers  500+ connections

#### ![Image 7](https://ca.linkedin.com/in/claude-perron-a845578)![Image 8](https://ca.linkedin.com/in/claude-perron-a845578)![Image 9](https://ca.linkedin.com/in/claude-perron-a845578)

See your mutual connections

![Image 10](https://ca.linkedin.com/in/claude-perron-a845578)
View mutual connections with Claude
-----------------------------------

Claude can introduce you to 2 people at FIAMtl

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=csm-v2_forgot_password) Sign in 

Sign in with Email

or

New to LinkedIn? [Join now](https:

*[... truncated, 47,997 more characters]*

---

### Ambassadors – FIAMtl
*2,762 words* | Source: **EXA** | [Link](https://fiamtl.com/ambassadors/)

Ambassadors – FIAMtl

===============

![Image 10: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 11: Close](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie _GRECAPTCHA 
*   Duration 5 months 27 days 
*   Description Google Recaptcha service sets this cookie to identify bots to protect the website against malicious spam attacks. 

*   Cookie cookieyes-consent 
*   Duration 1 year 
*   Description CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors. 

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie wp-wpml_current_language 
*   Duration session 
*   Description WordPress multilingual plugin sets this cookie to store the current language/language settings. 

*   Cookie __cf_bm 
*   Duration 30 minutes 
*   Description Cloudflare set the cookie to support Cloudflare Bot Management.  

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

*   Cookie CONSENT 
*   Duration 2 years 
*   Description YouTube sets this cookie via embedded YouTube videos and registers anonymous statistical data. 

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

- [x] 

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

*   Cookie YSC 
*   Duration session 
*   Description Youtube sets this cookie to track the views of embedded videos on Youtube pages. 

*   Cookie VISITOR_INFO1_LIVE 
*   Duration 5 months 27 days 
*   Description YouTube sets this cookie to measure bandwidth, determining whether the user gets the new or old player interface. 

*   Cookie yt-remote-device-id 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie yt.innertube::requests 
*   Duration never 
*   Description YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen. 

*   Cookie yt.innertube::nextId 
*   Duration never 
*   Description YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen. 

*   Cookie yt-remote-connected-devices 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

Uncategorized

- [x] 

Other uncategorized cookies are those that are being analyzed and have not been classified into a category as yet.

*   Cookie VISITOR_PRIVACY_METADATA 
*   Duration 5 months 27 days 
*   Description Description is currently not available. 

Accept All Save My Preferences Reject All

Powered by [![Image 12: Cookieyes logo](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent/?ref=cypbcyb&utm_source=cookie-banner&utm_medium=powered-by-cookieyes)

![Image 13](https://fiamtl.com/wp-content/uploads/2023/06/administration-bg.png)

[![Image 14](https://fiamtl.com/wp-content/uploads/2024/08/FIAM-HORIZ-LOGO_COUL.png)![Image 15](https://fiamtl.com/wp-content/up

*[... truncated, 19,541 more characters]*

---

### About Us – FIAMtl
*880 words* | Source: **EXA** | [Link](https://fiamtl.com/about-us/)

#### A global scope of action

FIAM is committed to staying at the forefront of global advancements, major trends, pivotal issues, and emerging opportunities. We focus on leading companies, cutting-edge technologies, innovative applications, and the ever-evolving landscape of the industry.

#### Event organization

**Objective**

 Inspiring Awareness and Knowledge – FIAM works to elevate awareness, provide informative insights, deliver educational experiences, and catalyze research through a range of engaging platforms. These include conferences, webinars, collaborative working sessions, content-rich events, and valuable networking opportunities.

In recent years, FIAM has proudly orchestrated Montreal’s premier summer gathering for the financial community. The 9th edition, held on August 25, 2022, saw a remarkable turnout, with around 300 participants coming together to partake in this influential event.

#### Collaboration with key partners

FIAM nurtures strategic relationships with vital local, national, and international partners, encompassing professional associations, semi-public institutions, industrial collaborators, and esteemed institutes/universities. This strategic positioning serves as a dynamic bridge, facilitating the seamless exchange of information and enabling us to operate as a conduit. Through these collaborations, we identify and harness sources of synergy, fostering collective engagement among diverse stakeholders.

In Quebec, FIAM stands at the nexus of the academic and financial realms, with a special focus on the asset management community. This includes active engagement with key players in the AI domain, such as Mila, IVADO, and Scale AI, thus fortifying our commitment to driving innovation and collaboration at the intersection of these spheres.

### The 5 main activities of FIAM

![Image 1: Asset 17](https://fiamtl.com/wp-content/uploads/2023/10/Asset-17.png)

The organization of content-rich events, such as the November 2021 conference, the Bloomberg-CDPQ event in August 2023, and the summer social event “Le Méchoui”, aims not only to weave and strengthen ties but also to foster stimulating exchanges between industry professionals. These initiatives allow FIAM to substantially enrich its network of relationships and optimize its execution capacity.

![Image 2: Asset 18](https://fiamtl.com/wp-content/uploads/2023/10/Asset-18.png)

Thanks to this network, several opportunities can arise. For example, the aggregation and dissemination of information facilitate companies/institutions’ rapid identification of expertise within universities and research centers. This network also promotes the connection between researchers and companies to meet specific needs. It further allows the organization of networking activities and knowledge transfer, such as conferences, workshops, or internship for students.

![Image 3: Asset 19](https://fiamtl.com/wp-content/uploads/2023/10/Asset-19.png)

There emerge a manifest and pressing need for education and awareness within the academic and industrial community, especially regarding exploring the potential applications of Artificial Intelligence (AI) and Machine Learning (ML). These technologies prove to be crucial pillars in the digital transformation process of organizations, specifically in the asset management sector.

![Image 4: Asset 20](https://fiamtl.com/wp-content/uploads/2023/10/Asset-20.png)

FIAM will maintain active strategic monitoring, ensuring regular and comprehensive updates of global developments, encompassing major trends, notable challenges, and opportunities, focusing on leading companies, technological evolution, relevant applications, and academic research while meticulously assessing the applicability of results from fundamental research.

![Image 5: Asset 21](https://fiamtl.com/wp-content/uploads/2023/10/Asset-21.png)

FIAM dedicates its efforts to talent development, especially those combining hybrid skills in finance and artificial intelligence/machine learning (AI/ML). This role turns out to be one of the fundamental pillars of FIAM’s mission. The crystallization of a talent community emerges through various initiatives to which FIAM is called to contribute, networking with industry professionals, organizing a Hackathon, implementing internships, awarding training scholarships, and through the creation of a robust and enriching mentoring network.

#### The 5 main activities of FIAM

*   #### Development of a Broad Relationship Network

 The organization of content-rich events, such as the November 2021 conference, the Bloomberg-CDPQ event in August 2023, and the summer social event "Le Méchoui", aims not only to weave and strengthen ties but also to foster stimulating exchanges between industry professionals. These initiatives allow FIAM to substantially enrich its network of relationships and optimize its execution capacity.
*   #### Networking and Dissemination of Information

 Thanks to this network, several opportunit

*[... truncated, 1,888 more characters]*

---

### Founding Members – FIAMtl
*1,077 words* | Source: **EXA** | [Link](https://fiamtl.com/about-us/founding-members/)

Founding Members – FIAMtl

===============

![Image 1: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie _GRECAPTCHA 
*   Duration 5 months 27 days 
*   Description Google Recaptcha service sets this cookie to identify bots to protect the website against malicious spam attacks. 

*   Cookie cookieyes-consent 
*   Duration 1 year 
*   Description CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors. 

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie wp-wpml_current_language 
*   Duration session 
*   Description WordPress multilingual plugin sets this cookie to store the current language/language settings. 

*   Cookie __cf_bm 
*   Duration 30 minutes 
*   Description Cloudflare set the cookie to support Cloudflare Bot Management.  

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

*   Cookie CONSENT 
*   Duration 2 years 
*   Description YouTube sets this cookie via embedded YouTube videos and registers anonymous statistical data. 

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

- [x] 

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

*   Cookie YSC 
*   Duration session 
*   Description Youtube sets this cookie to track the views of embedded videos on Youtube pages. 

*   Cookie VISITOR_INFO1_LIVE 
*   Duration 5 months 27 days 
*   Description YouTube sets this cookie to measure bandwidth, determining whether the user gets the new or old player interface. 

*   Cookie yt-remote-device-id 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

*   Cookie yt.innertube::requests 
*   Duration never 
*   Description YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen. 

*   Cookie yt.innertube::nextId 
*   Duration never 
*   Description YouTube sets this cookie to register a unique ID to store data on what videos from YouTube the user has seen. 

*   Cookie yt-remote-connected-devices 
*   Duration never 
*   Description YouTube sets this cookie to store the user's video preferences using embedded YouTube videos. 

Uncategorized

- [x] 

Other uncategorized cookies are those that are being analyzed and have not been classified into a category as yet.

*   Cookie VISITOR_PRIVACY_METADATA 
*   Duration 5 months 27 days 
*   Description Description is currently not available. 

Accept All Save My Preferences Reject All

Powered by [![Image 3: Cookieyes logo](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent/?ref=cypbcyb&utm_source=cookie-banner&utm_medium=powered-by-cookieyes)

![Image 4](https://fiamtl.com/wp-content/uploads/2023/06/administration-bg.png)

[![Image 5](https://fiamtl.com/wp-content/uploads/2024/08/FIAM-HORIZ-LOGO_COUL.png)![Image 6](https://fiamtl.com/wp-content/upl

*[... truncated, 6,359 more characters]*

---

### CAASA Annual Review 2022
*23,743 words* | Source: **EXA** | [Link](https://caasa.ca/wp-content/uploads/2023/03/CAASA-2022-Annual-Review-no-MD.pdf)

> Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca CAASA ANNUAL REVIEW - 2022 |1

# CAASA Annual Review 2022 

YYZ - EYW - MIA - PHX - ZHR - GVA - LAX - DFW - AUS - IAH - LAX - PBI - LGA - AUS - YYZ 

YYZ - EWR - GCM - IAH - YYZ - YUL - DUB - LHR - LUX - MUC - DFW - AUS - DUB - YVR - YYZ YYZ - YUL - GVA - XGZ - YYC - YVR - ORD - MIA - ICN - YUL - ICN - PUS - YVR - SFO - YYZ YYZ - YWG - SEA - LAX - YYC - BDA - YUL - LGA - DXB - LHR - YUL - EWR - YUL - LGA - YYZ 2 | CAASA ANNUAL REVIEW - 2022 Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca  Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca CAASA ANNUAL REVIEW - 2022 | 3CAASA MEMBER ADVISORY PANEL DIVERSE LEADERSHIP FOR A DIVERSE INDUSTRY 

Caroline Chow 

Co-Founder & Partner 

CAASA 

# MESSAGE FROM CAASA ANOTHER PIVOT EXECUTED 

Our move from virtual events to in-person was pretty seamless thanks to our growing team. When we started, James and Caroline did everything from sales to content planning/programming, to website and database creation and maintenance, to accounting. It was a true, boot-strapped start-up and we thank the 100 or so members that 

joined us on this journey in our first year: 2018. In 2019 we brought on Paul who straddled both worlds of front office (with James) to mid/back (with Caroline) and it was a fabulous time during COVID. As we emerged from 

lock-down and saw many, large in-person events on the horizon we added Stanley to manage our books in-house, 

Alexis to take the reins of the events (thanks to her years of experience in the field), and Manya to help make our 

database and membership servicing shine as much as members expect it to. Thanks to the team, we were able to produce a record number of conferences across the country, attract members and attendees from around the world, and introduce new services such as The KYP Nexus where asset managers 

can disseminate significant changes to their funds (as required by law starting January 1, 2022) to any advisor and 

dealer in Canada without charge. As always, if members or others have ideas for our programming, format, initiatives, or other areas of activity we 

are only a (Zoom) call or email away! 

Your CAASA Team 

James Burron, CAIA 

Co-Founder & Partner 

CAASA 

Brian D’Costa 

Founding Partner 

Algonquin Capital 

Wilson Tow 

Managing Partner 

Altrust Solutions 

Michael Schnitman 

SVP, Head of Alternative Investments 

Mackenzie Investments 

Athas Kouvaras 

Client Relationship & Development Manager 

Richter Family Office Inc. 

Jason Chertin 

Partner 

McMillan LLP Caroline Chow James Burron Paul Koonar 

Co-Founder & Partner Co-Founder & Partner Partner 

Kimberly Poster 

Chief Legal Counsel & SVP 

AUM Law 

Dean Shepard 

Chief Executive, Managing Partner 

Picton Mahoney Asset Management 

Jessica Clark Barrow 

Executive Vice President 

Waratah Capital Advisors 

Stanley Tow Manya Thakur Alexis St-Cyr 

Accounting Manager Membership Coordinator Event Manager 4 | CAASA ANNUAL REVIEW - 2022 Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca  Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca CAASA ANNUAL REVIEW - 2022 | 52022 EVENTS, PUBLICATIONS &MILESTONES 

Thank you to our many speakers, presenters, and those who added their themes and topics, panel and non-industry speaker ideas, and other invaluable input! Thanks also, of course, to our growing audience and your interest in the topics. 

# ABOUT CAASA INCLUSIVE, ACTIVE, AND PAN-ALTERNATIVE 

The Canadian Association of Alternative Strategies & Assets (CAASA) was created in response to industry requests for 

a national group to represent the Canadian alternative investment participants, including investors, asset managers, and service providers. CAASA is inclusive in that it welcomes participation from all companies active in the space as well as 

select individuals (those with investors) who might want to participate in committees and working groups - or simply attend 

member events - without their employer being a member of the association. CAASA is very active in both committees & 

groups and events: 33 events in 2018 and at least 50 planned in 2019 (15 in the first 2 months alone). Pan-alternative , for 

CAASA, encompasses all alternative strategies and assets including: hedge funds / alternative trading strategies, private and public real estate (funds and direct), private lending, private equity, development & project finance, digital assets / 

cryptoassets, weather derivatives & cat bonds, and all aspects of diligence, trading, structuring, dealing, and monitoring alternatives in a stand-alone portfolio and as part of a larger investment strategy. 

MEMBER BENEFITS 

Investors join CAASA to be a part of a formal network of pension plans, foundations, endowments, sovereign wealth funds, 

and family offices to discuss ideas, strategies,

*[... truncated, 141,702 more characters]*

---

### CFA Montréal salue l’engagement exemplaire de Lédéenne Chapleau envers la relève en finance
*1,028 words* | Source: **GOOGLE** | [Link](https://cfamontreal.org/en/cfa-montreal-salutes-ledeenne-chapleaus-exemplary-commitment-to-the-new-generation-in-finance/)

CFA Montréal salutes Lédéenne Chapleau's exemplary commitment to the next generation of finance professionals - CFA Montréal

===============
[Aller au contenu](https://cfamontreal.org/en/cfa-montreal-salutes-ledeenne-chapleaus-exemplary-commitment-to-the-new-generation-in-finance/#content)

[![Image 1: CFA-Montreal](https://cfamontreal.org/wp-content/uploads/2024/08/CFA-Montreal-White.v2.webp)](https://cfamontreal.org/en)

*    About us  Close About Open About 

Who we are
----------     

    *   [About CFA Montréal](https://cfamontreal.org/en/about-us/)
    *   [The association](https://cfamontreal.org/en/about-us/the-association/)
    *   [Mission and vision](https://cfamontreal.org/en/about-us/mission-and-vision/)
    *   [Awards](https://cfamontreal.org/en/about-us/awards/)

Administration and team
-----------------------

    *   [Board of Directors](https://cfamontreal.org/en/administration-and-team/#ca)
    *   [Team CFA Montreal](https://cfamontreal.org/en/administration-and-team/#equipe)
    *   [Past Presidents](https://cfamontreal.org/en/administration-and-team/#presidents)

Governance
----------

    *   [Governance](https://cfamontreal.org/en/governance/)

    *   [Contact us](https://cfamontreal.org/en/contact-us/)

    *   [](https://www.facebook.com/cfamontreal/?locale=fr_CA)
    *   [](https://www.instagram.com/cfa_montreal/)
    *   [](https://www.youtube.com/@cfamontreal8926)
    *   [](https://www.linkedin.com/company/association-cfa-montreal/?originalSubdomain=ca)

*    News & events  Close News & Events Open News & Events 

News
----     

    *   [News](https://cfamontreal.org/en/news/)
    *   [Press releases](https://cfamontreal.org/en/news/#communiques)
    *   [Newsletters](https://cfamontreal.org/en/news/#infolettres)

Events
------

    *   [Events and webinars](https://cfamontreal.org/en/events/)
    *   [Global Program Passport](https://cfamontreal.org/en/events/#passeport)
    *   [Training credits](https://cfamontreal.org/en/events/#credits)
    *   [75th anniversary celebrations](https://cfamontreal.org/en/album75/)

University competitions
-----------------------

    *   [Research Challenge](https://cfamontreal.org/en/university-competitions/)
    *   [Ethics Challenge](https://cfamontreal.org/en/university-competitions/#defiethique)

*    Membership & services  Close Membership & services Open Membership & services 

Membership
----------     

    *   [Benefits](https://cfamontreal.org/en/membership/)
    *   [Join or renew](https://cfamontreal.org/en/membership/)
    *   [Ethics & standards](https://www.cfainstitute.org/standards/professionals)
    *   [Login](https://cfamontreal.org/en/connection/)

Services
--------

    *   [Jobs](https://cfamontreal.org/en/jobs/)
    *   [Mentorship program](https://cfamontreal.org/en/services/)
    *   [Professional learning](https://www.cfainstitute.org/en/membership/professional-development/pl)
    *   [Member directory](https://www.cfainstitute.org/en/membership/directory)
    *   [Career resources](https://www.cfainstitute.org/programs/all-programs)

*    CFA program  Close CFA program Open CFA Program 

CFA program     

    *   [Overview](https://cfamontreal.org/en/cfa-program/)
    *   [Registration](https://www.cfainstitute.org/programs/cfa-program)
    *   [Reviews](https://www.cfainstitute.org/programs/cfa-program#fees-calendar)

Candidates

    *   [CFA Institute scholarships](https://www.cfainstitute.org/en/programs/cfa/scholarships)
    *   [CFA Montréal Scholarships](https://cfamontreal.org/en/candidates/)

*    Resources  Close Resources Open Resources 

Employers     

    *   [Employers](https://cfamontreal.org/en/employers/)
    *   [Post a job offer](https://cfamontreal.org/en/jobs/employers/)
    *   [Recruit a CFA member](https://cfamontreal.org/en/employers/#recruter-cfa)
    *   [Top employers](https://cfamontreal.org/en/employers/#top-employeurs)
    *   [Sponsorship](https://cfamontreal.org/en/employers/#commandite)

Professional learning

    *   [Professional learning](https://cfamontreal.org/en/continuing-education/)
    *   [Certificates & courses](https://www.cfainstitute.org/en/events/professional-learning)
    *   [Competency framework](https://interactive.cfainstitute.org/cpd-framework-feedback/landing-page--post-feedback-152ZL-1020Y8.html)

Publications

    *   [Podcast Finance in action](https://cfamontreal.org/en/publications/)
    *   [Research & Policy Center](https://rpc.cfainstitute.org/en/)

*    Get involved  Close Get involved Open Get involved 

Volunteers     

    *   [Become a volunteer](https://cfamontreal.org/en/volunteers/#formulaire)
    *   [Committees](https://cfamontreal.org/en/volunteers/#comites)

Sponsorship

    *   [Thanks to our partners](https://cfamontreal.org/en/sponsorships/)

[](https://cfamontreal.org/en/cfa-montreal-salutes-ledeenne-chapleaus-exemplary-commitment-to-the-new-generation-in-finance/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2

*[... truncated, 8,012 more characters]*

---

### Page not found - CFA Montréal
*400 words* | Source: **GOOGLE** | [Link](https://www.cfamontreal.org/en/news/cfa-montreal-salutes-ledeenne-chapleaus-commendable-commitment-to-the-next-generation-of-finance-professionals-50456)

Page not found - CFA Montréal

===============
[Aller au contenu](https://www.cfamontreal.org/en/news/cfa-montreal-salutes-ledeenne-chapleaus-commendable-commitment-to-the-next-generation-of-finance-professionals-50456#content)

[![Image 1: CFA-Montreal](https://cfamontreal.org/wp-content/uploads/2024/08/CFA-Montreal-White.v2.webp)](https://cfamontreal.org/en)

*    About us  Close About Open About 

Who we are
----------     

    *   [About CFA Montréal](https://cfamontreal.org/en/about-us/)
    *   [The association](https://cfamontreal.org/en/about-us/the-association/)
    *   [Mission and vision](https://cfamontreal.org/en/about-us/mission-and-vision/)
    *   [Awards](https://cfamontreal.org/en/about-us/awards/)

Administration and team
-----------------------

    *   [Board of Directors](https://cfamontreal.org/en/administration-and-team/#ca)
    *   [Team CFA Montreal](https://cfamontreal.org/en/administration-and-team/#equipe)
    *   [Past Presidents](https://cfamontreal.org/en/administration-and-team/#presidents)

Governance
----------

    *   [Governance](https://cfamontreal.org/en/governance/)

    *   [Contact us](https://cfamontreal.org/en/contact-us/)

    *   [](https://www.facebook.com/cfamontreal/?locale=fr_CA)
    *   [](https://www.instagram.com/cfa_montreal/)
    *   [](https://www.youtube.com/@cfamontreal8926)
    *   [](https://www.linkedin.com/company/association-cfa-montreal/?originalSubdomain=ca)

*    News & events  Close News & Events Open News & Events 

News
----     

    *   [News](https://cfamontreal.org/en/news/)
    *   [Press releases](https://cfamontreal.org/en/news/#communiques)
    *   [Newsletters](https://cfamontreal.org/en/news/#infolettres)

Events
------

    *   [Events and webinars](https://cfamontreal.org/en/events/)
    *   [Global Program Passport](https://cfamontreal.org/en/events/#passeport)
    *   [Training credits](https://cfamontreal.org/en/events/#credits)
    *   [75th anniversary celebrations](https://cfamontreal.org/en/album75/)

University competitions
-----------------------

    *   [Research Challenge](https://cfamontreal.org/en/university-competitions/)
    *   [Ethics Challenge](https://cfamontreal.org/en/university-competitions/#defiethique)

*    Membership & services  Close Membership & services Open Membership & services 

Membership
----------     

    *   [Benefits](https://cfamontreal.org/en/membership/)
    *   [Join or renew](https://cfamontreal.org/en/membership/)
    *   [Ethics & standards](https://www.cfainstitute.org/standards/professionals)
    *   [Login](https://cfamontreal.org/en/connection/)

Services
--------

    *   [Jobs](https://cfamontreal.org/en/jobs/)
    *   [Mentorship program](https://cfamontreal.org/en/services/)
    *   [Professional learning](https://www.cfainstitute.org/en/membership/professional-development/pl)
    *   [Member directory](https://www.cfainstitute.org/en/membership/directory)
    *   [Career resources](https://www.cfainstitute.org/programs/all-programs)

*    CFA program  Close CFA program Open CFA Program 

CFA program     

    *   [Overview](https://cfamontreal.org/en/cfa-program/)
    *   [Registration](https://www.cfainstitute.org/programs/cfa-program)
    *   [Reviews](https://www.cfainstitute.org/programs/cfa-program#fees-calendar)

Candidates

    *   [CFA Institute scholarships](https://www.cfainstitute.org/en/programs/cfa/scholarships)
    *   [CFA Montréal Scholarships](https://cfamontreal.org/en/candidates/)

*    Resources  Close Resources Open Resources 

Employers     

    *   [Employers](https://www.cfamontreal.org/en/employers/)
    *   [Post a job offer](https://www.cfamontreal.org/en/jobs/employers/)
    *   [Recruit a CFA member](https://www.cfamontreal.org/en/employers/#recruter-cfa)
    *   [Top employers](https://www.cfamontreal.org/en/employers/#top-employeurs)
    *   [Sponsorship](https://www.cfamontreal.org/en/employers/#commandite)

Professional learning

    *   [Professional learning](https://cfamontreal.org/en/continuing-education/)
    *   [Certificates & courses](https://www.cfainstitute.org/en/events/professional-learning)
    *   [Competency framework](https://interactive.cfainstitute.org/cpd-framework-feedback/landing-page--post-feedback-152ZL-1020Y8.html)

Publications

    *   [Podcast Finance in action](https://cfamontreal.org/en/publications/)
    *   [Research & Policy Center](https://rpc.cfainstitute.org/en/)

*    Get involved  Close Get involved Open Get involved 

Volunteers     

    *   [Become a volunteer](https://cfamontreal.org/en/volunteers/#formulaire)
    *   [Committees](https://cfamontreal.org/en/volunteers/#comites)

Sponsorship

    *   [Thanks to our partners](https://cfamontreal.org/en/sponsorships/)

[](https://www.cfamontreal.org/en/news/cfa-montreal-salutes-ledeenne-chapleaus-commendable-commitment-to-the-next-generation-of-finance-professionals-50456#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2MzQ5IiwidG9nZ

*[... truncated, 2,793 more characters]*

---

### Adriana Arrillaga reçoit un prix pour son leadership et son impact auprès des femmes en finance
*1,004 words* | Source: **GOOGLE** | [Link](https://cfamontreal.org/en/adriana-arrillaga-receives-award-for-her-leadership-and-impact-on-women-in-finance/)

Adriana Arrillaga receives award for her leadership and impact on women in finance - CFA Montréal

===============
[Aller au contenu](https://cfamontreal.org/en/adriana-arrillaga-receives-award-for-her-leadership-and-impact-on-women-in-finance/#content)

[![Image 3: CFA-Montreal](https://cfamontreal.org/wp-content/uploads/2024/08/CFA-Montreal-White.v2.webp)](https://cfamontreal.org/en)

*    About us  Close About Open About 

Who we are
----------     

    *   [About CFA Montréal](https://cfamontreal.org/en/about-us/)
    *   [The association](https://cfamontreal.org/en/about-us/the-association/)
    *   [Mission and vision](https://cfamontreal.org/en/about-us/mission-and-vision/)
    *   [Awards](https://cfamontreal.org/en/about-us/awards/)

Administration and team
-----------------------

    *   [Board of Directors](https://cfamontreal.org/en/administration-and-team/#ca)
    *   [Team CFA Montreal](https://cfamontreal.org/en/administration-and-team/#equipe)
    *   [Past Presidents](https://cfamontreal.org/en/administration-and-team/#presidents)

Governance
----------

    *   [Governance](https://cfamontreal.org/en/governance/)

    *   [Contact us](https://cfamontreal.org/en/contact-us/)

    *   [](https://www.facebook.com/cfamontreal/?locale=fr_CA)
    *   [](https://www.instagram.com/cfa_montreal/)
    *   [](https://www.youtube.com/@cfamontreal8926)
    *   [](https://www.linkedin.com/company/association-cfa-montreal/?originalSubdomain=ca)

*    News & events  Close News & Events Open News & Events 

News
----     

    *   [News](https://cfamontreal.org/en/news/)
    *   [Press releases](https://cfamontreal.org/en/news/#communiques)
    *   [Newsletters](https://cfamontreal.org/en/news/#infolettres)

Events
------

    *   [Events and webinars](https://cfamontreal.org/en/events/)
    *   [Global Program Passport](https://cfamontreal.org/en/events/#passeport)
    *   [Training credits](https://cfamontreal.org/en/events/#credits)
    *   [75th anniversary celebrations](https://cfamontreal.org/en/album75/)

University competitions
-----------------------

    *   [Research Challenge](https://cfamontreal.org/en/university-competitions/)
    *   [Ethics Challenge](https://cfamontreal.org/en/university-competitions/#defiethique)

*    Membership & services  Close Membership & services Open Membership & services 

Membership
----------     

    *   [Benefits](https://cfamontreal.org/en/membership/)
    *   [Join or renew](https://cfamontreal.org/en/membership/)
    *   [Ethics & standards](https://www.cfainstitute.org/standards/professionals)
    *   [Login](https://cfamontreal.org/en/connection/)

Services
--------

    *   [Jobs](https://cfamontreal.org/en/jobs/)
    *   [Mentorship program](https://cfamontreal.org/en/services/)
    *   [Professional learning](https://www.cfainstitute.org/en/membership/professional-development/pl)
    *   [Member directory](https://www.cfainstitute.org/en/membership/directory)
    *   [Career resources](https://www.cfainstitute.org/programs/all-programs)

*    CFA program  Close CFA program Open CFA Program 

CFA program     

    *   [Overview](https://cfamontreal.org/en/cfa-program/)
    *   [Registration](https://www.cfainstitute.org/programs/cfa-program)
    *   [Reviews](https://www.cfainstitute.org/programs/cfa-program#fees-calendar)

Candidates

    *   [CFA Institute scholarships](https://www.cfainstitute.org/en/programs/cfa/scholarships)
    *   [CFA Montréal Scholarships](https://cfamontreal.org/en/candidates/)

*    Resources  Close Resources Open Resources 

Employers     

    *   [Employers](https://cfamontreal.org/en/employers/)
    *   [Post a job offer](https://cfamontreal.org/en/jobs/employers/)
    *   [Recruit a CFA member](https://cfamontreal.org/en/employers/#recruter-cfa)
    *   [Top employers](https://cfamontreal.org/en/employers/#top-employeurs)
    *   [Sponsorship](https://cfamontreal.org/en/employers/#commandite)

Professional learning

    *   [Professional learning](https://cfamontreal.org/en/continuing-education/)
    *   [Certificates & courses](https://www.cfainstitute.org/en/events/professional-learning)
    *   [Competency framework](https://interactive.cfainstitute.org/cpd-framework-feedback/landing-page--post-feedback-152ZL-1020Y8.html)

Publications

    *   [Podcast Finance in action](https://cfamontreal.org/en/publications/)
    *   [Research & Policy Center](https://rpc.cfainstitute.org/en/)

*    Get involved  Close Get involved Open Get involved 

Volunteers     

    *   [Become a volunteer](https://cfamontreal.org/en/volunteers/#formulaire)
    *   [Committees](https://cfamontreal.org/en/volunteers/#comites)

Sponsorship

    *   [Thanks to our partners](https://cfamontreal.org/en/sponsorships/)

[](https://cfamontreal.org/en/adriana-arrillaga-receives-award-for-her-leadership-and-impact-on-women-in-finance/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2MzQ5IiwidG9nZ2xlIjpmYWxzZX0%3D)

[](https://cfamo

*[... truncated, 7,885 more characters]*

---

### Wealth Managers' Forums 2023 | CAASA
*18,257 words* | Source: **GOOGLE** | [Link](https://caasa.ca/wp-content/uploads/2023/03/CAASA-2023-WMF-Program.pdf)

Wealth Managers’ Forums 2023 

Presented by: The Canadian Association of Alternative Strategies & Assets 

## YVR 

## Weds, Feb 15 th 

## YYC 

## Thurs, Feb 16 th 

## YYZ 

## Thurs, Feb 23 rd 

## YUL 

## Tues, Feb 21 st 

## Program Sponsor: 2 | CAASA WEALTH MANAGERS’ FORUM - 2023  Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca  Read more at caasa.ca - or contact us at +1 (647) 953-0737 or caroline@caasa.ca  CAASA WEALTH MANAGERS’ FORUM - 2023  | 3

## YOUR SOURCE FOR ALL THINGS ALTERNATIVE 

Welcome to our first cross-Canada conference series focused on the requirements and preferences 

of retail, HNW, and UHNW Investment Advisors and allocators. We specially designed each city’s 

program to reflect their particular preferences and have (what we believe to be) a balance of talks from 

seasoned Investment Advisors and asset managers. Our format reflects the high value you put on 

your time – we start at about lunch time and end with a reception – and appreciate your taking time 

to attend the session in your city. We also have small group discussions (Table Talks) where you can 

delve in to particular topics and query the presenters. We also have our CAASA CE Centre at your 

disposal which will have 70+ of our webinars and podcasts from 2021 ported over as well as a course 

from each of our conference sponsors, and a selection of our panels and presentations. 

## THANK YOU TO NATIONAL SPONSORS 

## AND OUR CITY SPONSORS 

# ABOUT CAASA 

INCLUSIVE, ACTIVE, AND PAN-ALTERNATIVE 

The Canadian Association of Alternative Strategies & Assets (CAASA) was created in response to industry requests for 

a national group to represent the Canadian alternative investment participants, including investors, asset managers, 

and service providers. CAASA is  inclusive  in that it welcomes participation from all companies active in the space as 

well as select individuals (those with investors) who might want to participate in committees and working groups - or 

simply attend member events - without their employer being a member of the association. CAASA is very  active  in both 

committees & groups and events: 33 events in 2018 and at least 50 planned in 2019 (15 in the first 2 months alone).  Pan-

alternative , for CAASA, encompasses all alternative strategies and assets including: hedge funds / alternative trading 

strategies, private and public real estate (funds and direct), private lending, private equity, development & project finance, 

digital assets / cryptoassets, weather derivatives & cat bonds, and all aspects of diligence, trading, structuring, dealing, 

and monitoring alternatives in a stand-alone portfolio and as part of a larger investment strategy. 

MEMBER BENEFITS 

Investors  join CAASA to be a part of a formal network of pension plans, foundations, endowments, sovereign wealth 

funds, and family offices to discuss ideas, strategies, and operational issues particular to their businesses - all within a 

closed group where managers and service providers may or may not be included, depending on the forum. 

Managers  see the association as a way to connect with peers, investors, and service providers to speak to fund structuring, 

sales & marketing, and regulatory issues. CAASA is not a capital introduction platform, but we do create forums where 

investors and managers can meet organically or via structured meeting sessions where participation by the investors is 

strictly opt-in. 

Service providers  participate in our events and working groups as well as assist in the production of thought leadership 

pieces which provide relevant information to both association members and the industry and investing public at large. 

Founders  participate in our Founders’ Pitch Competitions as well as other initiatives created to propel their fledgeling 

businesses forward. 

NATIONAL AND GLOBAL 

CAASA believes that the Canadian alternatives industry has a great deal to offer Canadians and the global community. 

The  Canadian Model of Pension Management  is well-known for its large alternatives focus, managed in-house in many 

cases with substantial allocations to external managers as well. Canadian investment managers operate in a robust 

regulatory regime (of hedge fund managers) that is becoming the norm across the globe and a stable banking back-drop 

that provides solace for investors as well as opportunities for managers. Talent in investment management (approximately 

10% of all CFA charterholders reside in Canada) as well as newer areas such as digital assets and robo-advisory services 

are a differentiator. Of course, Canadian investors and managers are keen to learn of best practices in operations and 

portfolio management from their global peers. 

WHY JOIN? 

As mentioned, we have attracted 330+ members over the last 4 years or so and the reasons are plentiful and varied. 

Whether an investor, manager, or service provider, some seek a 

*[... truncated, 125,377 more characters]*

---

### 2020 Virtual "Mechoui"
*2,859 words* | Source: **GOOGLE** | [Link](https://www.aima.org/event/mechoui.html)

2020 Virtual "Mechoui"

===============

![Image 21: logo](blob:http://localhost/468adb9479e9a06ed84c90ffd1f40e43)

[](https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/)

*   [Consent](https://www.aima.org/event/mechoui.html#)
*   [Details](https://www.aima.org/event/mechoui.html#)
*   [[#IABV2SETTINGS#]](https://www.aima.org/event/mechoui.html#)
*   [About](https://www.aima.org/event/mechoui.html#)

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services. 

Consent Selection

**Necessary** 

- [x] 

**Preferences** 

- [x] 

**Statistics** 

- [x] 

**Marketing** 

- [x] 

[Show details](https://www.aima.org/event/mechoui.html#)

Details

*   
Necessary  9- [x]   Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies. 

    *   [Cookiebot 2](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 22](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.cookiebot.com/goto/privacy-policy/ "Cookiebot's privacy policy")**1.gif**Used to count the number of sessions to the website, necessary for optimizing CMP product delivery. **Maximum Storage Duration**: Session**Type**: Pixel Tracker  **CookieConsent**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 1 year**Type**: HTTP Cookie   
    *   [LinkedIn 2](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 23](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.linkedin.com/legal/privacy-policy "LinkedIn's privacy policy")**ar_debug**Checks whether a technical debugger-cookie is present. **Maximum Storage Duration**: 1 month**Type**: HTTP Cookie  **li_gc**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [Vimeo 4](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 24](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://vimeo.com/privacy "Vimeo's privacy policy")**rc::a**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: Persistent**Type**: HTML Local Storage  **rc::c**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Session**Type**: HTML Local Storage  **__cf_bm**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie  **_cfuvid**This cookie is a part of the services provided by Cloudflare - Including load-balancing, deliverance of website content and serving DNS connection for website operators. **Maximum Storage Duration**: Session**Type**: HTTP Cookie   
    *   [widget.sndcdn.com 1](https://www.aima.org/event/mechoui.html#)**sc_anonymous_id**Used in context with the 3D-view-function on the website.**Maximum Storage Duration**: 10 years**Type**: HTTP Cookie   

*   
Preferences  11- [x]   Preference cookies enable a website to remember information that changes the way the website behaves or looks, like your preferred language or the region that you are in. 

    *   [Acast 1](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 25](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.acast.com/privacy "Acast's privacy policy")**AcastLang**This cookie is used to determine the preferred language of the visitor and sets the language accordingly on the website, if possible.**Maximum Storage Duration**: Persistent**Type**: HTML Local Storage   
    *   [Tawk.to 3](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 26](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.tawk.to/privacy-policy/ "Tawk.to's privacy policy")**twk_uuid_#**Pending**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie  **twk_#**Pending**Maximum Storage Duration**: Persistent**Type**: HTML Local Storage  **twk_idm_key**Allows the website to recoqnise the visitor, in order to optimize the chat-box functionality. **Maximum Storage Duration**: Session**Type**: HTTP Cookie   
    *   [YouTube 7](https://www.aima.org/event/mechoui.html#)[Learn more about this provider![Image 27](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://business.safety.google/privacy/ "YouTube's privacy policy")**yt-remote-cast-available**Stores the user's video player prefere

*[... truncated, 36,403 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Ambassadors – FIAMtl](https://fiamtl.com/ambassadors/)**
  - Source: fiamtl.com
  - *Claude Perron, FIAM's founding president, is delighted to announce the ... info@fiamtl.com. Subscribe to our newsletter. I agree to receive informatio...*

- **[CFA Montréal salutes Lédéenne Chapleau's exemplary commitment ...](https://cfamontreal.org/en/cfa-montreal-salutes-ledeenne-chapleaus-exemplary-commitment-to-the-new-generation-in-finance/)**
  - Source: cfamontreal.org
  - *Every year, the Méchoui organized by FIAMtl is a not-to-be-missed event ... Claude Perron, who commented: "It is with deep admiration that we salute ....*

- **[CFA MONTRÉAL SALUTES LÉDÉENNE CHAPLEAU'S ...](https://www.cfamontreal.org/en/news/cfa-montreal-salutes-ledeenne-chapleaus-commendable-commitment-to-the-next-generation-of-finance-professionals-50456)**
  - Source: cfamontreal.org
  - *Aug 23, 2024 ... Every year, the Méchoui organized by FIAMtl is an unmissable event for the Montreal financial community. ... Claude Perron, who said:...*

- **[Adriana Arrillaga receives award for her leadership and impact on ...](https://cfamontreal.org/en/adriana-arrillaga-receives-award-for-her-leadership-and-impact-on-women-in-finance/)**
  - Source: cfamontreal.org
  - *In keeping with a long-established tradition, FIAMtl's Méchoui once ... Claude Perron. Her commitment to the next generation of women and her desire ....*

- **[Wealth Managers' Forums 2023 | CAASA](https://caasa.ca/wp-content/uploads/2023/03/CAASA-2023-WMF-Program.pdf)**
  - Source: caasa.ca
  - *Fund Operator and host of the Absolute Return Podcast. Ida Khajadourian. Portoflio ... FIAMtl - Forum d'investissement alternatif de Montréal. Claude ...*

- **[2020 Virtual "Mechoui"](https://www.aima.org/event/mechoui.html)**
  - Source: aima.org
  - *Aug 20, 2020 ... 4:00pm Opening Remarks - Claude Perron founder of Fiamtl and Chairman de Crystalline Management. 4:05pm Interview #1: Moving to a sus...*

- **[Virtual Conference 2020 – FIAMtl](https://fiamtl.com/archives/2020-events/virtual-conference-2020/)**
  - Source: fiamtl.com
  - *On behalf of Claude Perron, founder of FIAM, we are thrilled to invite you ... info@fiamtl.com. Subscribe to our newsletter. I agree to receive ......*

- **[AIMA Canada Founder Interviews](https://www.aima.org/global-network/aima-in-the-americas/canada/aima-canada-publications/aima-canada-founder-interviews.html)**
  - Source: aima.org
  - *James McGovern, Arrow Capital Management Inc. · Michael Burns, McMillan LLP · Phil Schmitt, Summerwood · Claude Perron, FIAMtl · Rob Lemon, CIBC Capit...*

- **[Program – FIAMtl](https://fiamtl.com/2024-events/program/)**
  - Source: fiamtl.com
  - *The event will conclude with closing remarks by Mario Therrien and an invitation by Claude Perron to proceed to the Mechoui Networking event. ... info...*

- **[Trans-Canada Capital Open For New Clients](http://pensionpulse.blogspot.com/2020/09/trans-canada-capital-open-for-new.html)**
  - Source: pensionpulse.blogspot.com
  - *Let me first thank Claude Perron, founder of FiaMTL, for organizing this year's virtual Mechoui (7th Edition) and inaugural Montreal Investment Forum ...*

---

*Generated by Founder Scraper*
