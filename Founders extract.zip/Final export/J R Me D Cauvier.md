# Jérôme D Cauvier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399853566196359168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHK-3nT0ZlsUw/feedshare-shrink_800/B4EZrF1sEfHcAg-/0/1764255778225?e=1766620800&v=beta&t=95WjCwAF8RqazOg3xyG7z0mkwh4vcBLBsMyccUIYAbE | Nous sommes très fiers d’annoncer le deuxième webinaire de notre série avec des piliers de l’industrie de la réadaptation au Québec.

Cette fois-ci, nous avons l'immense plaisir d'accueillir Melody Meilleur, directrice Marketing et Innovation chez Hexa Physio.

Au plaisir de vous y voir en grand nombre !

 🗓️ 11 décembre à 12 h (EST)
 🎟️ Inscription gratuite: https://lnkd.in/eCbEq87t | 12 | 0 | 0 | 1w | Post | Jérôme D Cauvier | https://www.linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | https://linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | 2025-12-08T04:50:31.452Z |  | 2025-11-27T16:56:12.812Z | https://www.linkedin.com/feed/update/urn:li:activity:7399847008578064384/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394809832534417409 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHr3ORHlPPhsQ/feedshare-shrink_800/B4EZp9nf9jIQAo-/0/1763044099212?e=1766620800&v=beta&t=5fIJOfWqdp-eJ2fNxX85fpWHDBhH6vUATmI8_ZDWC5Q | Merci à toute l'équipe de l'ACET, ainsi qu'à nos coachs Phil et Jonathan, de nous pousser, de nous challenger et de nous amener constamment à nous remettre en question. | 42 | 4 | 0 | 3w | Post | Jérôme D Cauvier | https://www.linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | https://linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | 2025-12-08T04:50:31.453Z |  | 2025-11-13T18:54:12.999Z | https://www.linkedin.com/feed/update/urn:li:activity:7394742920475672576/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391170532655648768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHmMtpJE_-rcg/image_350_624/B4DZpKw8yIJUAY-/0/1762190937402?e=1766620800&v=beta&t=cz2pubTd88WFNug71ShJuq-6oNGQlmpcOlqlgegkqdI | Walaw a le plaisir d'annoncer son premier webinaire d'une série de plusieurs avec des gestionnaires et des fondateurs de cliniques inspirants ! | 22 | 0 | 0 | 1mo | Post | Jérôme D Cauvier | https://www.linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | https://linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | 2025-12-08T04:50:31.454Z |  | 2025-11-03T17:52:56.293Z | https://www.linkedin.com/feed/update/urn:li:activity:7391161580975079424/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387154531555414016 | Article |  |  | **English version in the comments below**

Après plus de quatre années chez Davies Ward Phillips & Vineberg LLP, j’ai tourné une page importante de ma vie professionnelle le 1er août dernier.

J’ai fait mes débuts chez Davies comme étudiant à l’été 2021, avant de rejoindre l’équipe de M&A et de valeurs mobilières comme avocat. Chez Davies, j’ai rencontré des personnes et des mentors exceptionnels.

C’est aussi là-bas que j’ai appris l’importance de la rigueur, de l’excellence et de la satisfaction client - des valeurs qui me suivront pour toujours.

Aujourd’hui, il est temps de sortir de l’ombre et de dévoiler le projet sur lequel je travaille depuis plusieurs mois avec deux personnes extraordinaires, Marc Obeid et L. : Walaw

💡 D’où vient Walaw?

Walaw est né d’un constat, issu de nombreuses rencontres avec des gestionnaires de cliniques — des professionnels de la réadaptation (physio, ergo, ostéo, etc.), des dentistes et d’autres acteurs du domaine de la santé.

Les mêmes défis revenaient :

🟦 Des équipes administratives débordées
🟨 Jusqu’à 30 % des appels mis en attente ou manqués
🟦 Des patients frustrés de tomber sur des boîtes vocales
🟨 Et 10 à 20 % des rendez-vous qui se soldent par des no-shows

Nous avons donc décidé d’agir — et de créer une solution conçue, pensée et développée avec eux.

🎯 Notre mission 

Walaw a pour mission de centraliser l’ensemble des communications entre les cliniques et leurs patients sous un même hub — et d’assurer que chaque demande patient soit adéquatement et rapidement traitée.

Aujourd’hui, Walaw accompagne déjà plusieurs dizaines de cliniques à travers le Québec et gère des milliers de communications chaque mois.

Merci à toutes les personnes qui m’ont accompagné jusqu’ici — y compris ma famille et mes amis — ainsi qu’à tous ceux qui nous soutiennent dans cette aventure.

👉 Pour en savoir plus : https://lnkd.in/ee5_s4uk
💬 Et si vous gérez une clinique, parlons-en !

Êtes-vous prêts à transformer vos communications patients ? | 218 | 36 | 1 | 1mo | Post | Jérôme D Cauvier | https://www.linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | https://linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | 2025-12-08T04:50:31.455Z |  | 2025-10-23T15:54:47.017Z | https://calendly.com/jerome-walaw/30min |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7269343184068005889 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFKw0xQ3iHQ9w/image-shrink_800/image-shrink_800/0/1732732246004?e=1765774800&v=beta&t=nSyd-QBMMEXK3EV6OymPB0O_uE6UGtbaFPBAmBTcsJo | Je suis très fier d’avoir collaboré sur cette transaction incroyable. Félicitations à notre équipe et à Groupe Dynamite pour cet accompagnement! 

***

I am very proud to have worked on this incredible transaction. Congratulations to our team and Groupe Dynamite for this achievement! | 89 | 1 | 0 | 1yr | Post | Jérôme D Cauvier | https://www.linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | https://linkedin.com/in/j%C3%A9r%C3%B4me-d-cauvier-2a1935151 | 2025-12-08T04:50:36.464Z |  | 2024-12-02T13:34:32.947Z | https://www.linkedin.com/feed/update/urn:li:activity:7267605791384244224/ |  | 

---

