# Cedric Seaut

## Position actuelle

**Titre** : Co-Founder, President, Art Director
**Entreprise** : keos Masons
**Durée dans le rôle** : 11 years 8 months in role
**Durée dans l'entreprise** : 11 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Résumé

Art Director and Business Manager at Keos Masons

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAACcdpgBQnaQk8tf69GwKP3VBp8WwlHaCMM/
**Connexions partagées** : 2


---

# Cedric Seaut

## Position actuelle

**Entreprise** : keos Masons

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Cedric Seaut

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402331723209797632 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E10AQEhvdvkGHt17A/mp4-720p-30fp-crf28/B4EZrpdbfWHgB0-/0/1764853408729?e=1765785600&v=beta&t=6jyX09W1CSuTZIZN3EMY_KIyYwCZMJO-3omzgCmUi4E | https://media.licdn.com/dms/image/v2/D4E10AQEhvdvkGHt17A/ads-video-thumbnail_720_1280/B4EZrpdbfWHgAg-/0/1764853397907?e=1765785600&v=beta&t=oNlgSq2zG6RTSxIQrTC9wpKkz7Uwkt6XbvXcUGE56Ys | Care Kid ! 🎵
--
RealTime Videos here 🚀 
https://lnkd.in/ej4Mux2H
https://lnkd.in/eZgtpZf2
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #gameplay
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 102 | 0 | 2 | 3d | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:29.610Z |  | 2025-12-04T13:03:31.486Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399794639437864960 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d9abcd52-f733-4bb1-aa40-97bf7e5d7207 | https://media.licdn.com/dms/image/v2/D4E10AQHXxVHywmLMrA/ads-video-thumbnail_720_1280/B4EZrFZ.EiJgAk-/0/1764248511156?e=1765785600&v=beta&t=pnwlXVagZcI6nFMNgMfQ7vBhyyKaVgINuxdxkXjC1io | Leg ! (Polish 01) 🎵 
--
RealTime Videos here 🚀 
https://lnkd.in/ei8BXa3x
--
#cyborg #zbrush #artwork #scifi #mechanic #space #fyp #trailer #anime #creature #hunt #warriors #fashiontrends #learning 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 146 | 2 | 1 | 1w | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:29.612Z |  | 2025-11-27T13:02:03.578Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7397257882066493440 | Video (LinkedIn Source) | blob:https://www.linkedin.com/97017e66-3f5d-4421-b863-b2602f6fc043 | https://media.licdn.com/dms/image/v2/D4E10AQHB7yErAtfbZw/ads-video-thumbnail_720_1280/B4EZqhWx9PIoAk-/0/1763643695365?e=1765785600&v=beta&t=s56ss0EB8dV_2yAZoccCcz45OJh0WxDvARkfXpxMh_8 | Pionner Head ! 🎵
--
RealTime Videos here 🚀 
https://lnkd.in/epachH6u
--
#cyborg #zbrush #artwork #scifi #mechanic #space #fyp #trailer #anime #creature #hunt #warriors #fashiontrends #learning 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 129 | 0 | 3 | 2w | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:29.612Z |  | 2025-11-20T13:01:53.490Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394721151974846464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6e74b4cc-445d-4295-b1d8-9281dc7a2869 | https://media.licdn.com/dms/image/v2/D4E10AQHrLUfLPWULkQ/ads-video-thumbnail_720_1280/B4EZp9TqHeIoAk-/0/1763038897007?e=1765785600&v=beta&t=CfYw-cZOeg9kIxHKPrViZR-rZguxxjcdK2XakfdtKd0 | Mecha Process ! 🎵 On
--
RealTime Videos here 🚀 
https://lnkd.in/eDudkhKK
--
#cyborg #zbrush #artwork #scifi #mechanic #space #fyp #trailer #anime #creature #hunt #warriors #fashiontrends #learning 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 640 | 8 | 27 | 3w | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:29.613Z |  | 2025-11-13T13:01:49.906Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7392184196527509504 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHj6jmtzhAe8w/image-shrink_800/B4EZpZQVEEIwAc-/0/1762434046408?e=1765785600&v=beta&t=TrwH9M6pYiOHLBg5sFVijAyr8zU62Qs3Oxwsu2MOhMI | Mother woods Teaser ! 🎵
--
#creature #forest #woods #poetry #flowers #trailer #fyp #universe #spirituality #video #art #learning #nature #birth
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 80 | 0 | 0 | 1mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:29.614Z |  | 2025-11-06T13:00:52.593Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7382022442120126464 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7e82203b-ee0b-4ca1-8b2e-d17ad9ea3777 | https://media.licdn.com/dms/image/v2/D4E10AQGMAN0NwkHqZQ/ads-video-thumbnail_720_1280/B4EZnI2QAjHIAY-/0/1760011291762?e=1765785600&v=beta&t=q70fU9I6e72MopnlBH_1Fmsr6uLEI3D4oMbz3hvZxIo | Medic Arm ! 🎵 On
--
RealTime Videos here 🚀 
https://lnkd.in/eMZb-d3u
https://lnkd.in/eMT84gZp
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #video #learning #tutorial
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 354 | 3 | 7 | 1mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.761Z |  | 2025-10-09T12:01:41.546Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7379485765312880640 | Video (LinkedIn Source) | blob:https://www.linkedin.com/602d3fa1-98e9-49ef-9989-73fb16d3f822 | https://media.licdn.com/dms/image/v2/D4E10AQEEFLVTR01iYw/ads-video-thumbnail_720_1280/B4EZmky7SDIMAc-/0/1759406497563?e=1765785600&v=beta&t=IyH4Y3IVkUX60iSr9glyvTa840G-ontXTHFb03jzbPI | Creature polish ! 🎵 On
--
RealTime Videos here 💯 
https://lnkd.in/e6CnSvsU
--
#zbrush #artwork #scifi #space #fyp #trailer #creature #hunt #warriors #dead #horror #kill #hunting #learning #tutorial 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 137 | 2 | 2 | 2mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.762Z |  | 2025-10-02T12:01:50.666Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7376948877788147712 | Video (LinkedIn Source) | blob:https://www.linkedin.com/79a23bbf-efda-4645-9c9d-8904f9df7660 | https://media.licdn.com/dms/image/v2/D4E10AQHT_XS3y1G-Ag/ads-video-thumbnail_720_1280/B4EZmAvwlTKkAc-/0/1758801656436?e=1765785600&v=beta&t=QFmzeeQUK6CO-Q1w8VlCOZj4uKLHCGUlhuUoMB5bU_I | Moon Polish ! (Part 2) 🎵 On
--
RealTime Videos here 💯 
https://lnkd.in/eBpV6NHn
--
#creature #moon #space #poetry #flowers #trailer #fyp #universe #spirituality #video #art #learning 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 212 | 4 | 4 | 2mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.763Z |  | 2025-09-25T12:01:09.547Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7374412281197248512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/49905861-b9ce-45ac-b790-5aa47ab2528f | https://media.licdn.com/dms/image/v2/D4E10AQGIGpnuvRUO9g/ads-video-thumbnail_720_1280/B4EZlcssdtKoAc-/0/1758196879504?e=1765785600&v=beta&t=C6WhSg7LAns3gn-o-VrQmp4E2WFXSIQUe1vcNHUMQtQ | Shape Block-out ! 🎵 On
--
RealTime Videos here 🎉 
https://lnkd.in/ecMy64Yk
--
#zbrush #artwork #scifi #mechanic #fyp #trailer #learning #tutorial #video #share #school #learn 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 177 | 1 | 7 | 2mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.765Z |  | 2025-09-18T12:01:37.792Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7371875412085317632 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c783a5d1-f905-4c7a-9da0-ac154749a195 | https://media.licdn.com/dms/image/v2/D4E10AQG4MHYlE81T-w/ads-video-thumbnail_720_1280/B4EZk4plrFKQAc-/0/1757592053553?e=1765785600&v=beta&t=hPyyUg2y2YEkr9Ju445-DyGg85G1o9TIm7H-b6JD5VE | Scout Teaser ! 🎵 On
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #learning #trailer #fyp #video #tutorial #scout 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 80 | 1 | 0 | 2mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.765Z |  | 2025-09-11T12:01:01.063Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7370197076581965824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEL1FqU_hlu3w/feedshare-shrink_800/B4EZkgzGVNGoAg-/0/1757191900205?e=1766620800&v=beta&t=4_hJxc2JUSNi7WqAr2bLntgm5TyQwLjbyNv620p-eCg | XDS 2025 was truly incredible, filled with unexpected, amazing, and heartfelt moments. It was such a pleasure to connect with so many talented and wonderful people.

A huge thank you to Claude Bordeleau for bringing us together, it was an unforgettable and priceless evening.

Philip Stilgoe, you are such a remarkable person. We deeply enjoyed spending time with you, it was precious 👊❤️‍🔥

Mathieu Savard (🔜 XDS) it was wonderful to meet you. Your kindness and genuine nature are truly unique ☺️

David Hubert 🔜 XDS & Eve Turpin, it’s always a pleasure to see long-time friends in such a delightful setting. You both are beautiful souls!

And a Special thanks to Isabelle Renaud for guiding and organizing everything during the trip as our leader. Your support made it all possible.

See you next year !! | 49 | 1 | 0 | 3mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.766Z |  | 2025-09-06T20:51:54.697Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7369339029034528769 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c24a596a-b29d-4757-a9f9-4818d2398730 | https://media.licdn.com/dms/image/v2/D4E10AQEj3Oq5urKPGA/ads-video-thumbnail_720_1280/B4EZkUmkzsHoAc-/0/1756987327033?e=1765785600&v=beta&t=qGNcLKRcVEE9v9C5s8P4OFksFIMAQfC9eAO_SyivjdY | Mind Blocking ! 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/erzsABtC
--
#sweetcreature #shadow #dark #creature #newconcept #video #art #gameart #learning #magnificAI #ai #night #horror #parasite #monster 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 173 | 1 | 2 | 3mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.767Z |  | 2025-09-04T12:02:20.220Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7356655176130174976 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d8e4449e-dabb-4d9d-82fe-c57b7738240f | https://media.licdn.com/dms/image/v2/D4E10AQFGbBQov-N0UA/ads-video-thumbnail_720_1280/B4EZhgWwyCHgAc-/0/1753963260882?e=1765785600&v=beta&t=HUWG19tQ3--MYpTcorNrrzAD6gW8ox4Cbfwyq_laQiU | Pionner Chest ! 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/e3c-rGGm
https://lnkd.in/ekhjq-Nz
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 223 | 1 | 2 | 4mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.768Z |  | 2025-07-31T12:01:14.033Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7354118468079689729 | Video (LinkedIn Source) | blob:https://www.linkedin.com/57d18951-e6fc-4133-b765-853b216b9517 | https://media.licdn.com/dms/image/v2/D4E10AQE0Sm12EFI8Xg/ads-video-thumbnail_720_1280/B4EZg8TvFkHgAc-/0/1753358467412?e=1765785600&v=beta&t=Cwu776AzdlZX8p7-cz1kDCNxjvZqdzoE5nxlYtYPcME | Medic Teaser ! 🎵 On
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #video #learning #tutorial
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 92 | 0 | 1 | 4mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.769Z |  | 2025-07-24T12:01:15.704Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7351581942837878788 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c0249537-08cf-44c4-a105-32b86adf8d4a | https://media.licdn.com/dms/image/v2/D4E10AQHTUCPgf0HqFQ/ads-video-thumbnail_720_1280/B4EZgYQnVUHIAg-/0/1752753707374?e=1765785600&v=beta&t=cXN2rFoX2ZCwJ7RMMCn7HiWMG8ud97eI5gYP1NAkxkw | Shade blocking ! 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/eD3XR7EH
--
#sweetcreature #shadow #dark #creature #newconcept #video #art #gameart #learning #magnificAI #ai #night #horror 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 119 | 0 | 1 | 4mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.770Z |  | 2025-07-17T12:02:00.960Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7349045070072815616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f4303340-e131-4bef-a888-15fe6fe4f2ea | https://media.licdn.com/dms/image/v2/D5610AQF44fz0CRsbcw/ads-video-thumbnail_720_1280/B56Zf0NbDdHoAs-/0/1752148870159?e=1765785600&v=beta&t=4gw-RCJCvLabFqYvAmrEXo9X1VfLn_vdij8uZh5ule0 | Care Head ! 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/gTur_ryN
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #gameplay 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 185 | 2 | 3 | 4mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.771Z |  | 2025-07-10T12:01:23.360Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7346508539953119232 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ae08e8f6-8b90-4d25-a85b-7f6a0b8a8ffa | https://media.licdn.com/dms/image/v2/D4E10AQH8nmrmQ1lBAw/ads-video-thumbnail_720_1280/B4EZfQKR7WHYAg-/0/1751544114057?e=1765785600&v=beta&t=nSdF2EC-OrUz89FGxeWLTv3fqkgwINp4gXa9yb0icXU | Scene Polish ! 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/ejuN-wna
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #gameart #learning #video #art #robot #future 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 315 | 0 | 3 | 5mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.772Z |  | 2025-07-03T12:02:07.453Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7343971510568542209 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2b62039e-65f1-4aad-8f6b-45c1d3355ac1 | https://media.licdn.com/dms/image/v2/D4E10AQEwcE-ggBnsMw/ads-video-thumbnail_720_1280/B4EZesHDZAHwAc-/0/1750939239548?e=1765785600&v=beta&t=sKWBTL7-9NVDBfYOGNBSH_24lwdbqGV7h8sVftGjlTU | Mess ID-03 ! 🎵 On
--
Random R&D concept 🚀 
--
#gold #jewellery #ai #magnificai #newconcept #gameart #learnzbrush #sweetcreature #video #art 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 95 | 1 | 0 | 5mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.773Z |  | 2025-06-26T12:00:52.512Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7341434799485571075 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQGXc13-S1JNTw/image-shrink_800/B56ZeID_9cHQAg-/0/1750334441701?e=1765785600&v=beta&t=kJfNJhuL42mBO9TuUMskoqMwV5z9tdy0WadzkAtjAAs | Hunter creature Teaser ! 
--
#cyborg #zbrush #artwork #scifi #mechanic #space #fyp #trailer #anime #creature #hunt #warriors #fashiontrends 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 78 | 2 | 0 | 5mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.774Z |  | 2025-06-19T12:00:53.460Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7338898221349396481 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a0e6604d-6c3b-446d-a741-99f610a8ced2 | https://media.licdn.com/dms/image/v2/D4E10AQF9xhIUJAgHoA/ads-video-thumbnail_720_1280/B4EZdkA7U9G4AU-/0/1749729672419?e=1765785600&v=beta&t=AUFr4-w5KilJnKGcBQZBFbXEnHaB-P7CuUwCs4jPak4 | Moon Polish ! (Part 1) 🎵 On
--
RealTime Videos here 🙌 
https://lnkd.in/eBtYFXEc
--
#creature #moon #space #poetry #flowers #trailer #fyp #universe #spirituality #video #art #learning 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 156 | 1 | 4 | 5mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.775Z |  | 2025-06-12T12:01:26.105Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7336361354854850564 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9d472568-c2bd-42c5-8834-fee8641205b4 | https://media.licdn.com/dms/image/v2/D4E10AQG-_imhzLFrTw/ads-video-thumbnail_720_1280/B4EZc_9rzcHQAg-/0/1749124837294?e=1765785600&v=beta&t=hZKwF9boKUJAdp3sC5mYX3US3iX4M3LDsdMo9oQXztE | Mess ID-02 ! 🎵 On
--
Random R&D concept 🚀 
--
#gold #jewellery #ai #magnificai #newconcept #gameart #learnzbrush #sweetcreature #video #art 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 130 | 3 | 0 | 6mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.776Z |  | 2025-06-05T12:00:50.000Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7333824914765869056 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3e4f085d-7ca2-42a5-ad65-243634dec713 | https://media.licdn.com/dms/image/v2/D4E10AQFWOqE69sRlLA/ads-video-thumbnail_720_1280/B4EZcb60gGHIAg-/0/1748520102922?e=1765785600&v=beta&t=c8DDEGm6QhZNfJ3mFukHGcyzgLsRSg64BDlDkPkNScg | Shoe Blocking ! 🎵 On
--
RealTime Videos here 👍 
https://lnkd.in/eqCEpeig
--
#cyborg #zbrush #artwork #scifi #mechanic #space #fyp #trailer #anime #creature #hunt #warriors #fashiontrends #learning 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 231 | 2 | 9 | 6mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.777Z |  | 2025-05-29T12:01:55.558Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7331288012447744000 | Video (LinkedIn Source) | blob:https://www.linkedin.com/20cfe718-134a-4df1-87f5-001e030d5717 | https://media.licdn.com/dms/image/v2/D4E10AQEvCBjraIZoyQ/ads-video-thumbnail_720_1280/B4EZb33bV9GQAg-/0/1747915252213?e=1765785600&v=beta&t=yha0lkdyYlD2wdfudhuck2eB6aCRyu9NlIgvntib_f4 | Stroll ! 🎵 On
--
RealTime Videos here :
https://lnkd.in/e6tzSsjk
--
#sweetcreature #love #creature #newconcept #video #art #GameArt #LearnZBrush #magnificAI
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 231 | 11 | 4 | 6mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.778Z |  | 2025-05-22T12:01:10.912Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7328751269701955586 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQE2Sz_r44257A/image-shrink_800/B4EZbT0ax.HYAg-/0/1747310458200?e=1765785600&v=beta&t=MG8bk3qqBL7E9H48hZKtLakLvBtp_cPTCCa-KPB3bFk | Pionner Teaser ! 
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 446 | 1 | 5 | 6mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.778Z |  | 2025-05-15T12:01:04.311Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7326214631071301633 | Video (LinkedIn Source) | blob:https://www.linkedin.com/36006bde-13dd-47bf-afaa-b02004a13ff2 | https://media.licdn.com/dms/image/v2/D4E10AQFvS4UFZ13fLw/ads-video-thumbnail_720_1280/B4EZavxOX0HYAY-/0/1746705669833?e=1765785600&v=beta&t=Kwy19yzYfkubEF-Nu5029FX_bBx0lEJdj0qMmj17VAo | Plug ! 🎵 On
--
RealTime Videos here 👍 
https://lnkd.in/ebt_7FGM
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #learning #robot 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 319 | 6 | 2 | 6mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.779Z |  | 2025-05-08T12:01:22.533Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7323677785787424769 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4e1b1927-b47f-460c-a57d-025501b89f25 | https://media.licdn.com/dms/image/v2/D4E10AQGB7zyZ35Kqkw/ads-video-thumbnail_720_1280/B4EZaLuB6YHMAY-/0/1746100838957?e=1765785600&v=beta&t=IJLmYw5KfGP-sgNFymC0-YmYI8wvnJpa1vPc_9-Gyq4 | Lab blocking ! 🎵 On
--
RealTime Videos here :
https://lnkd.in/eauHQm_3
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #dream #spiritualawakening 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 482 | 7 | 7 | 7mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.780Z |  | 2025-05-01T12:00:51.485Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7321141141603561472 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5ed1ffaf-94d5-491f-9266-86c3c32f8f6f | https://media.licdn.com/dms/image/v2/D4E10AQEvFPDDEO5HDA/ads-video-thumbnail_720_1280/B4EZZnq7MtGYAg-/0/1745496049966?e=1765785600&v=beta&t=EK_tsoRMXWhQi4WGJvJf5gxpGS8ElOPzmLDX5yuU08E | Retro shoe Blocking ! 🎵 On
--
RealTime Videos here :
https://lnkd.in/eD_EaaCs
--
#LearnZBrush #gameart #nike #sneakers #streetwear #urbanfashion #fitness #conceptart #3d 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 386 | 8 | 6 | 7mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.781Z |  | 2025-04-24T12:01:08.383Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7318605699851116544 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9cd33106-836f-4625-99dd-336db85a5af2 | https://media.licdn.com/dms/image/v2/D4E10AQEMd-Pxbi6VTw/ads-video-thumbnail_720_1280/B4EZZDo5bPHUAY-/0/1744891548134?e=1765785600&v=beta&t=GHhTf5Gn9uMbvFVESeBrP5Rh9F2gFzIdh_Btrd26Kl8 | Care Backpack ! 🎵 On
--
RealTime Videos here 👍 
https://lnkd.in/eAp-xq_P
--
#cyborg #zbrush #artwork #scifi #mechanic #fashion #space #creature #trailer #fyp #gameplay 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 376 | 6 | 13 | 7mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.782Z |  | 2025-04-17T12:06:11.963Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7313531044261998592 | Video (LinkedIn Source) | blob:https://www.linkedin.com/40ae4720-f8e6-477c-8761-80f5b2ca880e | https://media.licdn.com/dms/image/v2/D4E10AQEXoD3U3ykd-A/ads-video-thumbnail_720_1280/B4EZX7hqfZG0Ak-/0/1743681672156?e=1765785600&v=beta&t=seeN_t2HRTDu2JUVYbIJ1zGQZBA42mhbdAv2Htaaw9Y | Moon Teaser ! 🎵 On
--
#creature #moon #space #poetry #flowers #trailer #fyp #universe #spirituality 
--
Art Direction : Cedric Seaut
https://lnkd.in/eRHYwpm5 | 103 | 3 | 0 | 8mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.783Z |  | 2025-04-03T12:01:19.788Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7310994218544492545 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e6c560ec-da0e-4694-8a03-1d1029464ac6 | https://media.licdn.com/dms/image/v2/D4E10AQGvmZG-szEAmw/ads-video-thumbnail_720_1280/B4EZXXeXm5HUAY-/0/1743076840360?e=1765785600&v=beta&t=xZCL9QOOS-a43Ox1cykCND6sfJGQN7kTFfpiQau5yoI | Mess ID-01 ! 🎵 On
--
Random R&D concept 🚀 
--
#gold #jewellery #ai #magnificai #newconcept #gameart #learnzbrush #sweetcreature #video #art 
--
Art Direction : Cedric Seaut
linktr.ee/CedricSeaut | 307 | 3 | 6 | 8mo | Post | Cedric Seaut | https://www.linkedin.com/in/cedric-seaut-0205263 | https://linkedin.com/in/cedric-seaut-0205263 | 2025-12-08T07:04:34.784Z |  | 2025-03-27T12:00:53.405Z |  |  | 

---



---

# Cedric Seaut
*keos Masons*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [About - Keos Masons](https://keosmasons.com/about/)
*2025-04-11*
- Category: article

### [Keos Masons | LinkedIn](https://ca.linkedin.com/company/keos-masons)
*2025-05-03*
- Category: article

### [Keos Masons: Interview & Tutorials](https://magazine.artstation.com/2017/10/keos-masons/)
*2017-10-12*
- Category: article

### [Outfit, Cedric Seaut (Keos Masons)](https://www.artstation.com/artwork/1YYnX)
*2017-04-11*
- Category: article

### [Hex - Keos Masons](https://keosmasons.com/assets/hex/)
*2025-03-07*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Character Design & Production with ZBrush for the Industry with ...](https://pixologic.com/zbrushlive/character-design-production-with-zbrush-for-the-industry-with-keos-masons-2019-zbrush-summit/)**
  - Source: pixologic.com
  - *Aug 2, 2020 ... ... Cedric Seaut, Guillaume Tiberghien, & Marco Plouffe – 2019 ZBrush Summit #ZBrushSummit #ZBrushLIVE #ZBrush2019 #Pixologic #ZBrush....*

- **[The Longest Journey Recreated With Modern Tools](https://80.lv/articles/the-longest-journey-diorama-created-with-modern-tools)**
  - Source: 80.lv
  - *Aug 2, 2018 ... ... (who introduced me to ZBrush at school), Cedric Seaut and Guillaume Tiberghien of Keos Masons. zoom-icon. 1 of 3....*

- **[Marco Plouffe – ZBrushLIVE](https://pixologic.com/zbrushlive/author/marco-plouffe/)**
  - Source: pixologic.com
  - *Character Design & Production with ZBrush for the Industry with Keos Masons – 2019 ZBrush Summit ... Cedric Seaut, Guillaume Tiberghien, & Marco Plouf...*

- **[Visually Describing a SolarPunk Future](https://www.reddit.com/r/ImaginarySolarPunk/)**
  - Source: reddit.com
  - *Mar 17, 2016 ... mycp_architecture [podcast]. Play. Upvote 6. Downvote ... r ......*

- **[Character Design & Production with ZBrush for the Industry with ...](https://www.youtube.com/watch?v=UthCuDB1IEQ)**
  - Source: youtube.com
  - *Sep 29, 2019 ... Character Design & Production with ZBrush for the Industry with Keos Masons Featuring Cedric Seaut ... Podcasts, and More! https://su...*

- **[ChatGPTで執行役員を勝手に遊戯王カードにしてみた #機械学習 - Qiita](https://qiita.com/kotauchisunsun/items/917e55c41fe6c7542eb9)**
  - Source: qiita.com
  - *Apr 27, 2023 ... ... Cedric Seaut (Keos Masons), character portrait, a character portrait ... Podcast. Our service. Qiita Team · Qiita Zine · Official...*

- **[VilliamBoom @VilliamBoom1 - Twitter Profile | TwStalker](https://www.twstalker.com/VilliamBoom1)**
  - Source: twstalker.com
  - *Keos Masons @KeosMasons. 19K Followers 200 Following Concept design and 3D character modelling company for games, films and collectibles, created by C...*

- **[Developer Interview - Concept Artist - QingYi Li : r/pathofexile](https://www.reddit.com/r/pathofexile/comments/jwto05/developer_interview_concept_artist_qingyi_li/)**
  - Source: reddit.com
  - *Nov 19, 2020 ... Developer Interview - Concept Artist - QingYi Li. Information. r ... r/ImaginaryHorrors - The Dreamcatcher by Cedric Seaut (Keos Maso...*

- **[About page. Meet the team behind the project... - Neo-Apocalypse](https://neo-apocalypse.com/about/)**
  - Source: neo-apocalypse.com
  - *Having attended New3dge, a school for 3D arts in Paris, he met and was taught by Marco Plouffe and Cedric Seaut, and swiftly got hired at Keos Masons ...*

- **[Official ZBrush SUMMIT 2015 Presentation - Keos Masons - YouTube](https://www.youtube.com/watch?v=umg_spkkeu0)**
  - Source: youtube.com
  - *Oct 2, 2015 ... Presentation Day 3 Featuring Cedric Seaut & Marco Plouffe Cedric Seaut ... Official ZBrush SUMMIT 2015 Interview - Keos Masons. Maxon ...*

---

*Generated by Founder Scraper*
