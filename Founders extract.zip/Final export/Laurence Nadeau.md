# Laurence Nadeau

## Position actuelle

**Titre** : Cofondatrice
**Entreprise** : Immigrer.com Inc.
**Durée dans le rôle** : 26 years 9 months in role
**Durée dans l'entreprise** : 26 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Online Audio and Video Media

## Description du rôle

Le site de référence pour les francophones, francophiles désirant vivre, étudier et travailler au Québec / Canada.

## Résumé

Cofondatrice du site immigrer.com. 6 millions de visiteurs uniques chaque année en 2015-2016-2017-2018.
Depuis 1999, le site de référence no 1 et premier média en français pour tout immigrant ou nouvel arrivant voulant s'installer au Québec et au Canada. 
Des 6 millions de visiteurs uniques par année 40% sont au Québec et 40% en France. 

Forum de discussion très actif, une véritable réseau social pour les immigrants et site mise à jour avec actualités, blogues, etc. 
Auteure des guides de L'Express sur le travail et l'installation au Québec "S'installer et travailler au Québec"

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAdjjJcBtUH6avBwDVVjzQ6vd2pFuii8uC4/
**Connexions partagées** : 6


---

# Laurence Nadeau

## Position actuelle

**Entreprise** : Immigrer.com Inc.

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Laurence Nadeau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394436023990132736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFyA4rzFO19Ng/feedshare-shrink_800/B4EZp5QYUSHoAk-/0/1762970929204?e=1766620800&v=beta&t=wFEfL1mwZ6rZ0bCwdoQ4FtZYIvPTVKKg2BL8nFvqYRA | Si vous avez manqué notre webinaire d’hier sur les nouveautés en immigration avec Alexandre Henaut , il est en ligne 👇
https://lnkd.in/eD74HwJr | 10 | 0 | 0 | 3w | Post | Laurence Nadeau | https://www.linkedin.com/in/laurencenadeau | https://linkedin.com/in/laurencenadeau | 2025-12-08T07:15:16.215Z |  | 2025-11-12T18:08:50.097Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392234854551134209 | Article |  |  | Québec revoit sa stratégie d’immigration : moins d’admissions, fin du PEQ et priorité au français. 
Ne manquez pas notre webinaire de la semaine prochaine où nous décortiquerons cette nouvelle annonce avec Alexandre Henaut 
https://lnkd.in/eFYpkzJa | 2 | 0 | 1 | 1mo | Post | Laurence Nadeau | https://www.linkedin.com/in/laurencenadeau | https://linkedin.com/in/laurencenadeau | 2025-12-08T07:15:16.217Z |  | 2025-11-06T16:22:10.407Z | https://www.immigrer.com/quebec-revoit-sa-strategie-dimmigration-moins-dadmissions-fin-du-peq-et-priorite-au-francais/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7387222787494420480 | Article |  |  | Je vais animer un webinaire le 11 novembre prochain avec comme invité Maître Alexandre Henaut sur les dernières nouveautés en immigration. C’est gratuit et à 19 h (Paris), 13 h (Montréal). 

https://lnkd.in/eD74HwJr Webinaire : nouveautés en immigration – automne 2025 - Immigrer.com | 5 | 0 | 0 | 1mo | Post | Laurence Nadeau | https://www.linkedin.com/in/laurencenadeau | https://linkedin.com/in/laurencenadeau | 2025-12-08T07:15:16.220Z |  | 2025-10-23T20:26:00.501Z | https://www.immigrer.com/webinaire-nouveautes-en-immigration-automne-2025/ |  | 

---



---

# Laurence Nadeau
*Immigrer.com Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [](https://podcasts.apple.com/ca/podcast/my-immigrant-story/id1595878466?l=fr-CA)
- Category: podcast

### [My Immigrant Story](https://podcasts.apple.com/ca/podcast/my-immigrant-story/id1595878466)
*2023-07-24*
- Category: podcast

### [My Immigrant Story • A podcast on Spotify for Creators](https://creators.spotify.com/pod/profile/my-immigrant-story/)
*2023-07-24*
- Category: podcast

### [Podcast — Blog — Immitracker](https://www.immitracker.app/blog/category/Podcast)
*2023-07-24*
- Category: podcast

### [“It hurts”: the discourse on immigration and housing bothers](https://www.laconverse.com/en/articles/ca-fait-mal-le-discours-sur-limmigration-et-le-logement-derange)
*2025-12-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Vous attendez l'entretien (Algériens) - Page 984 - Salle d'attente ...](https://forum.immigrer.com/topic/133192-vous-attendez-lentretien-algeriens/page/984/)**
  - Source: forum.immigrer.com
  - *Apr 28, 2014 ... Interview de Laurence Nadeau. immigrer.com · By immigrer.com, December ... Immigrer.com Inc. ×. Utilisateur existant ? Connexion · S ...*

- **[Webinaire : nouveautés immigration Québec/Canada en 2025 ...](https://forum.immigrer.com/topic/187904-webinaire-nouveautes-immigration-quebeccanada-en-2025/)**
  - Source: forum.immigrer.com
  - *Feb 19, 2025 ... @Laurence Nadeau & Maitre Alexandre Hénaut pour leur réponse et ... Immigrer.com Inc. ×. Utilisateur existant ? Connexion · S'inscrir...*

- **[Immigrer après 40 ans - Québec - Immigrer.com](https://forum.immigrer.com/topic/25069-immigrer-apres-40-ans/)**
  - Source: forum.immigrer.com
  - *May 6, 2005 ... Laurence Nadeau · Posté(e) 6 mai 2005 · Laurence Nadeau · Laurence Nadeau Newbie. Habitués ... Immigrer.com Inc. ×. Utilisateur exista...*

- **[j habite le plus beau pays du monde.. - Québec - Immigrer.com](https://forum.immigrer.com/topic/22105-j-habite-le-plus-beau-pays-du-monde/)**
  - Source: forum.immigrer.com
  - *Feb 28, 2005 ... Christophe. Citer. Habitués. Laurence Nadeau Newbie · Laurence Nadeau · Posté(e) 28 février 2005 · Laurence Nadeau · Laurence Nadeau ...*

---

*Generated by Founder Scraper*
