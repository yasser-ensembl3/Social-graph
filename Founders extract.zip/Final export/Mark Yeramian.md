# Mark Yeramian

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Moast
**Durée dans le rôle** : 3 years 10 months in role
**Durée dans l'entreprise** : 3 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Moast connects shoppers with local product owners to provide honest, authentic and unique shopping experiences. With Moast, shoppers can build trust with brands and feel more confident in their purchasing decisions allowing brands to accelerate their sales cycle. A brand’s loyal customers are their biggest untapped resource. Moast allows brands to build a community around these customers, connecting like-minded people and helping attract new customers.

## Résumé

Launched Moast in 2022 alongside 2 other co-founders. Moast is a Shopify app that helps brands collect and display awesome content from customers on auto-pilot. We display that content on store sites through our interactive widgets. 

Moast is Shopify's first conversational UGC app. Our unique widgets allow shoppers to ask questions to real customers, helping brands build trust and social proof and ultimately drive more purchases.

We're currently working with hundreds of top Shopify brands including Oru Kayaks, Mockingbird, Transformer Table and more.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA_1Z-oBFg_Zv9T0M-mv19YzyLVtXFddmYM/
**Connexions partagées** : 119


---

# Mark Yeramian

## Position actuelle

**Entreprise** : Moast

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Mark Yeramian

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402370131798171648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFUU8EDGthF4A/feedshare-shrink_800/B4EZrqAaBhKoAg-/0/1764862566935?e=1766620800&v=beta&t=u2PSNPxObrz8_5nw9Rap1JnznRFWlxcB7A2jieHaI8c | Black Friday / Cyber Monday was a wild week across ecommerce, but this year hit differently for us.

We finally got to see what happens when thousands of shoppers interact with real customer videos and shoppable experiences during the biggest shopping weekend of the year.

Here’s what our merchants saw in just a few days:

- $1.5M+ in sales influenced by Moast widgets across product pages.
- $107K+ in direct sales generated from shoppers who watched and bought through shoppable video.

A noticeable lift in time on site as shoppers browsed customer videos, photos, and profiles before checkout.

What I love most is that all of this came from real customers, sharing real experiences, right on the product page. No production crews. No fancy shoots. Just authentic social proof that actually moves revenue.

There’s a shift happening in how people shop online and last weekend was the clearest signal yet. Brands that show real customer experiences win more trust and convert more shoppers. Moast just makes that part easier and more repeatable.

Proud of the team and grateful for the merchants who trusted us during the busiest week of the year.

Special shoutout to Sand Society for their super clean setup on their PDPs. | 22 | 8 | 1 | 3d | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:16:55.802Z |  | 2025-12-04T15:36:08.807Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394767058887999488 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGuhOYGKPenDA/feedshare-shrink_800/B4EZp99ZBiHgAg-/0/1763049837332?e=1766620800&v=beta&t=oGDBOl9igQk2Um9Y9M2Vaf-bgX5pJjVLazF_Fgodtkg | Moast is now powering video commerce for more than 2,000 merchants on Shopify!

What started as a simple idea to help brands bring their products to life has grown into a global network of merchants using shoppable video to build trust and boost conversions.

From Sydney to Chicago and everywhere in between, brands are using Moast to show real customers, real products, and real experiences right on their store. It has been incredible to see how creative merchants get when they have the tools to offer unique video commerce experiences.

We’re just getting started. So much more on the way. | 47 | 19 | 0 | 3w | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:16:55.803Z |  | 2025-11-13T16:04:14.967Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394742495349256192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJ_Mt9x_AHjQ/feedshare-shrink_800/B4EZp6FRNoJ0Ao-/0/1762984793824?e=1766620800&v=beta&t=OHR6601Y3PbgrIb_nuropQqfZGdcUVgciYbCPZPicME | This is a small update that is going to have a big impact on merchant's ability to rank on Google and LLMs. | 13 | 0 | 0 | 3w | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:16:55.803Z |  | 2025-11-13T14:26:38.563Z | https://www.linkedin.com/feed/update/urn:li:activity:7394494179923509250/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7391470541540335617 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHWlc3TM5pGPw/feedshare-shrink_1280/B4EZpLgRi9KYAs-/0/1762203343496?e=1766620800&v=beta&t=p6TDO72PBLV11tJVjZlnY2-ccalCbpos_TLmNjWmnb0 | This is a real ad that circulated for True Classic.

Meta’s AI ad generator is pumping out all kinds of weird ads and the crazy part is that advertisers can’t even see them.

Some of them are hilariously off-brand, others are straight up bad.
It’s a perfect example of where “AI everything” starts to backfire and I think it’s time to start scaling it back.

Because while AI can test 100 versions of an ad, it can’t tell when something feels fake.

And in categories like fashion and beauty, that feeling is everything.

Take Aerie by AEO, Inc. They publicly pledged to never use AI in their content and it became their most-liked post on Instagram ever.

Real people, real stories, real connection. That’s what today’s consumers want.

If something is supposed to be ‘creative’ but it’s generated by AI, all creativity is completely erased. 

AI should enhance creativity, not erase it.

The brands that win won’t be the ones letting algorithms write their story, they’ll be the ones using tech to amplify their human voice.

#AI #ecommerce | 28 | 8 | 1 | 1mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:16:55.804Z |  | 2025-11-04T13:45:03.985Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7390005929498521600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGdt68DM6oSFw/feedshare-shrink_800/B4EZoxmudfJ0Ag-/0/1761768827421?e=1766620800&v=beta&t=pL1JPhdYBglvI2Nn0qdzvshjMG-XTQUuUGFAMt9_-zw | McKinsey just released a new forecast that I think every e-commerce brand should be aware of.

Agentic commerce (where AI agents shop, compare, and buy on behalf of consumers) could drive up to $5 trillion in global sales by 2030. 

In short, agentic commerce means handing part of the shopping journey to AI. 

Instead of browsing and adding to cart yourself, your digital “agent” will handle discovery, negotiation, and checkout based on your preferences.

A few weeks ago, Shopify announced an integration with ChatGPT that lets customers buy products directly inside the ChatGPT interface without leaving the conversation. This takes that concept a step further.

It’s still incredibly early in this shift (think internet in the mid-90s), but here’s what this could mean for brands on Shopify:

- Customer journeys will change. Shopping will become automated, driven by AI rather than search or ads.

- Websites must become agent-friendly. Clear data, open APIs, and structured content will matter more than flashy design.

- Trust will be everything. Consumers will need confidence that agents act in their best interest.

McKinsey projects that up to $1 trillion of this new market will come from the U.S. alone.

It’s early days, but the takeaway is clear: brands that start preparing their infrastructure, data, and messaging for AI-driven shopping now will have a serious head start when agents begin buying at scale.

#shopify #ecommerce | 347 | 62 | 34 | 1mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:16:55.804Z |  | 2025-10-31T12:45:13.263Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7385050911716306944 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e433f7f1-9baf-4c70-94ef-9ff302d9220e | https://media.licdn.com/dms/image/v2/D4E05AQGNHJKrXdhaLA/videocover-low/B4EZny7qjIHgB4-/0/1760717354418?e=1765778400&v=beta&t=uZ2UZVvgow8xsg1kZgXQakUPmePoqL4N1Z6d91GMRDw | This is a big update. 

Instead of just displaying videos on your store in a random order, Moast now uses AI to automatically sort videos based on performance. 

We're calling it Smart Feeds - check it out 👇 | 15 | 2 | 0 | 1mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.330Z |  | 2025-10-17T20:35:44.964Z | https://www.linkedin.com/feed/update/urn:li:activity:7384983858758225921/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7369020617842507776 | Video (LinkedIn Source) | blob:https://www.linkedin.com/be86066b-ff33-4da6-92bf-30ad81637bfd | https://media.licdn.com/dms/image/v2/D4E05AQEjbmBskgiTXA/videocover-high/B4EZkQFMbTIoCQ-/0/1756911422580?e=1765778400&v=beta&t=RDkoyWs2gNwrEKSnkGuuCI7d7A3xB-aJOGpHzP-VZdQ | Helpful hack for Shopify merchants:

If you have an ad of a static image that’s already performing well, a super simple way to level it up is to turn it into a video.

You can use Midjourney to add motion to still photos. The prompt doesn't need to be overly complicated, you can start with this:

"Can you add subtle, natural-looking motion to this image to make it feel more alive and dynamic, without changing the core content?"

If you’re experimenting with prompts, action verbs help a lot—things like grabbing, pouring, rotating. The more specific you are, the better the result.

Adding subtle movement like that doesn’t just work for ads. It makes your product pages feel more alive too. Motion keeps people on site longer and makes everything feel more interactive.

Or if you want the easier route, Moast can do this in one click. We’ll take your static image and bring it to life automatically, right from inside the app.

This video was originally an image 👇 | 8 | 0 | 0 | 3mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.331Z |  | 2025-09-03T14:57:05.076Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7367271374668603392 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEXt6thDmVzMA/feedshare-shrink_800/B4EZj3ORVNGwAs-/0/1756494371800?e=1766620800&v=beta&t=r5l_VfhJ44Mh6GKUX5Ak8z1mYEIkKbcvzhoSu47_5Lg | Moast just hit a big milestone: 100 reviews.

99- 5 stars
1 - 4 stars

The Shopify app store is incredibly competitive and a wide range of positive reviews is the best way to stand out. 

It's crazy to think that we officially launched shoppable videos just this past February. 

Feels like we worked incredibly hard to get here and we're just getting started. | 44 | 3 | 0 | 3mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.332Z |  | 2025-08-29T19:06:13.004Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7366869710295994369 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFx8n5JJL-YCQ/feedshare-shrink_1280/B4EZjxg9r5GYAs-/0/1756398607438?e=1766620800&v=beta&t=ZgRubhpN0Bg1u6jChl1ukOy--ojnwqaWvR48GeAidwI | It's so critical for Shopify brands to stay on top of the latest social trends.

Here's the latest: Instagram is building a new feature called “Picks” where users can select their favourite movies, shows, books, games, etc., and then see which friends share the same interests.

It’s still in testing, but here’s why I think Shopify brands should be paying attention:
 
This feels like the early stages of interest-based discovery, something Instagram hasn’t really done well until now. 

Instead of just relying on the algorithm to surface content, users are self-declaring their tastes. That’s powerful. If this rolls out more broadly, I can see a few clear opportunities for #ecommerce brands:

 - Build content that ties into pop culture and shared interests (TV shows, music, podcasts, etc.)
 
- Create product bundles or #UGC that speaks to niche communities (“For fans of…” or “If you love XYZ, you’ll love this”)
 
 - Encourage customers to share their picks and tag your brand to start creating community around shared tastes.
 
- Stay ahead by identifying which fandoms or micro-communities your audience already overlaps with. 

Instagram has been moving toward more social connection lately: friends’ likes, reposts, even map-based features. This is one more signal. And it could be a great thing for brands who know how to tap into identity and culture.

If you run a Shopify brand, it’s worth starting to experiment with interest-driven content now, even before Picks goes live.

Happy to connect on ideas for how to make it work depending on your niche. | 7 | 0 | 0 | 3mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.333Z |  | 2025-08-28T16:30:08.755Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7360774728124358658 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPwiD7WyzDGQ/feedshare-shrink_800/B4EZia5ml5GUAg-/0/1754945450745?e=1766620800&v=beta&t=ZmJFCF8CHxGB74_uGGxU9AAzP8nHzQWAu_aj0_QSkVk | Moast is officially Built for Shopify!

We applied for the badge back in April and spent months going through revisions before finally being accepted late last week.

The Built for Shopify badge is Shopify's highest recognition for apps. 

It’s given to apps that meet strict standards for performance, design, and merchant experience. 

For context only ~2% of apps are BFS. It’s like getting a Michelin star… but for Shopify apps.

We’re proud to be part of this and are committed to making Moast the best shoppable video app for Shopify merchants. | 52 | 7 | 0 | 3mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.333Z |  | 2025-08-11T20:50:51.766Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7358213086807216129 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c059e4e2-a6d2-402f-a4b2-622f72b7404f | https://media.licdn.com/dms/image/v2/D4E05AQHoLwHxExNurQ/videocover-low/B4EZh2fvpYGYCM-/0/1754334699230?e=1765778400&v=beta&t=r7d4H9JMlsVSHN7OJGbVE9Rr3rJOnK--CVvTLrZdGb4 | I see hundreds of Shopify stores every week.

This one stopped me in my tracks (doesn't hurt that it happens to be selling products for a sport I love).

Par x Design is a masterclass in thoughtful design.

Take a closer look and you'll notice their product grid looks like a score card. Hover over their header menu and you'll see it looks like a golf ball.

These subtle details are what make a store memorable and sharable.

Bonus points: they're using the Moast widget beautifully on the homepage and product pages 🙂.

If you're into golf, grab yourself some awesome wall art 👇 

https://parxdesign.com/ | 30 | 10 | 1 | 4mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.334Z |  | 2025-08-04T19:11:48.883Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7348721626722496512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3182e332-c50d-4a27-9eba-7343cb4270f1 | https://media.licdn.com/dms/image/v2/D4E05AQHS7wEGMB-MzA/videocover-low/B4EZfvnW0jGcCE-/0/1752071763664?e=1765778400&v=beta&t=cRGIRw2B8jMUFmAUc-VqIF_faOLRNcbYP5fqqqNAbYI | The team really nailed it with this one.

Now, brands can quickly preview our carousel widget by simply entering their Instagram handle directly on the Moast website. 

This feature gives brands a seamless way to experience how our interactive widgets can showcase their video content in real-time. | 14 | 0 | 1 | 4mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.335Z |  | 2025-07-09T14:36:08.456Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7347976439125749761 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHaKCMr6p3nfQ/feedshare-shrink_800/B4EZfhTc5_HgAo-/0/1751831664057?e=1766620800&v=beta&t=_rq8SQ7jLvYN3QG6Z6sBi5yTMXpZ9cDIAQ73MZ1OFbs | Only a few days into our partnership with Judge.me, and it's already having a massive impact on our install rate.

Judge.Me is hands down the leader in Shopify's 'Reviews' apps category and their approach of packing as much value as possible into a single $15 / month plan has been a huge inspiration for us.

Super excited to see this partnership come off the ground and have such an immediate impact. | 51 | 3 | 0 | 5mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.335Z |  | 2025-07-07T13:15:01.888Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7342977644340080640 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEaNCnM1D3BkA/feedshare-shrink_800/B4EZed_QXcHsAo-/0/1750702295606?e=1766620800&v=beta&t=UNNwThTccgg3DXf7HDo1g4ZBkfuXUrIF8zGkDEQyTzM | Moast is now seeing over 600k video views across our customers PER WEEK.

Shoutout to Mantle for making it easy for us to track all our important metrics on our app. | 30 | 6 | 0 | 5mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.336Z |  | 2025-06-23T18:11:36.338Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7341544600139878400 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d8973edc-5c70-4902-be95-33eed96f8a38 | https://media.licdn.com/dms/image/v2/D4D05AQEUtVHPnGn41g/videocover-high/B4DZeJn478G8CE-/0/1750360628769?e=1765778400&v=beta&t=SJgWslBgG-Y4mZnldO7qJv2Sbps3d3QZpeEseN0k5eA | This is one of our coolest features yet!

Turn any image into a video with just 1 click.

This is our first AI feature in the Moast Shopify app and creates smooth, natural motion that enhances the realism of any photo.

It's a perfect for brands that don't have a big library of UGC content or simply want to bring that perfect photo they took to life 📸 | 18 | 3 | 0 | 5mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.336Z |  | 2025-06-19T19:17:11.976Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7338660378492452865 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d897d502-58c4-43be-a860-33caea4c21fe | https://media.licdn.com/dms/image/v2/D4E05AQHuupoPQpiGXg/videocover-low/B4EZdgotkmGcC8-/0/1749672976657?e=1765778400&v=beta&t=SJr3ahPzFMp1xQOTkPyTgNWTTvFgRIPhyjKrHMfIJek | This floating player feature is so clean 🙏 .

Now shoppers can minimize our video carousel to the bottom right (or left) of the screen and continue shopping while they watch.

The transition between the full screen to the floating player is so smooth. 

Most shoppers won't notice this but it's the small details that matter.

The floating player is now available to all our merchants on the Pro plan. | 17 | 3 | 0 | 5mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.337Z |  | 2025-06-11T20:16:19.949Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7335735649926324225 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGbMORkXsIb6w/feedshare-shrink_800/B4EZc3EsYyH0Ak-/0/1748975668550?e=1766620800&v=beta&t=HjFAfqtf-0ldUVSP4UpezDGwR3_dlH8Ty3oqswvHXV4 | We just hit 60 five-star reviews on our Shopify app!

One thing that keeps coming up in these reviews: how hands-on we are during onboarding.

We’ve been told this level of support isn’t scalable, and maybe it isn’t. But it’s a key part of who we are.

Staying close to our merchants helps us build real relationships. And the feedback we get from those conversations is invaluable. 

It’s how we keep improving the product every week.

Dropping a few of my favorite reviews below 🙏 | 49 | 4 | 1 | 6mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.338Z |  | 2025-06-03T18:34:30.320Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7331358825368739840 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4e925866-fe21-464c-ab51-cb37b1557aac | https://media.licdn.com/dms/image/v2/D4E05AQFbhuCwqBoH4A/videocover-low/B4EZb439MYGQBs-/0/1747932149353?e=1765778400&v=beta&t=KeufGNOQzRB_cmZZHvdqEjCDvSbFEYjgw2f1Qrb7gko | Shopify's Summer 2025 Editions was released yesterday. 

As usual, there were a ton of new updates to what is already a pretty incredible e-commerce platform.

But what stood out to me was the AI Block Generation part of the Horizon theme framework.

Simply describe your desired elements in natural language and custom theme blocks are created right before your eyes. 

Very powerful stuff 💪 | 9 | 0 | 0 | 6mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.339Z |  | 2025-05-22T16:42:34.028Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7322703296073240576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGcGyUf4eEJOA/feedshare-shrink_800/B4EZZ931vSGYAg-/0/1745868513942?e=1766620800&v=beta&t=Rcs4TeAbXeSv2hqqfFA3dE4Z8ewDaGUhDLbe0t5-PuU | ChatGPT is about to become a shopping channel.

This is really really big news.

OpenAI is integrating Shopify’s checkout directly into ChatGPT, meaning users can browse and buy without ever leaving the chat.

For merchants, this unlocks a completely new way to reach customers with zero extra integration work.

The obvious question now becomes: how do I get ChatGPT to recommend my product?

Well, since it gets its answers by scrapping the internet, ironically, the best way to rank in prompt responses is to have strong SEO.

Keep a close eye on how this develops. | 23 | 2 | 0 | 7mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.339Z |  | 2025-04-28T19:28:35.032Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7316200965966036993 | Video (LinkedIn Source) | blob:https://www.linkedin.com/dd02ae74-20ef-47c1-904c-0821ddeeffa9 | https://media.licdn.com/dms/image/v2/D4E05AQG_291bWF6Afw/videocover-low/B4EZYhd.9HHcCY-/0/1744318233915?e=1765778400&v=beta&t=QrqMHRDBGFQmzUKJuLIx6BLIS-oD9Jxv-h6TBVy7nts | I've always wanted to have some chickens roaming around my backyard producing fresh eggs everyday. 

A few weeks ago, a company called GoodEgg installed our app. They offer amazing brushes and soap for cleaning backyard eggs.

Their CMO Shane McGuire reached out with a fun idea. He wanted to know if we could design our carousel and story widgets to look like eggs.

I ran the idea by Edi Bouazza, and he quickly added the ability to drop custom CSS into the app block, making it easy to bring Shane's idea to life, as well as any other creative styling requests from merchants.

What a great way to make a website more fun and engaging.

Can't wait to get my hands on some Good Egg cleaners once I get my chickens 🐔 

Check out their products if you have some chicken roaming around your backyard 👇 

https://goodeggstuff.co/ | 21 | 0 | 0 | 7mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.340Z |  | 2025-04-10T20:50:38.727Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7315834895719649280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1aad0980-da5e-4f11-ab31-e74d22ca02d7 | https://media.licdn.com/dms/image/v2/D4E05AQF9jmqUnr8apg/videocover-low/B4EZYcRBcBHcCU-/0/1744230951214?e=1765778400&v=beta&t=8OiRNdIHiGY3nRuUMUrgrOcaE-UAeLrqg5SytKtYKD4 | This new Feeds feature on Moast is pretty cool. 

It lets merchants create custom video playlists and display them anywhere on their site. 

Start by tagging your media in the app, then build a feed that suits your brand’s needs. 

From there you can easily rearrange the videos with a simple drag-and-drop feature, giving you full control over how your content is presented.

We’re already seeing some great ways merchants are using Feeds. Food brands are tagging recipe videos to help customers visualize how to use their products, while clothing companies are showcasing seasonal collections to highlight the latest trends. 

Other merchants are using Feeds for product demos or even creating gift guides for special occasions.

How would you use this feature to enhance your site?

#shopify #ecommerce | 25 | 1 | 1 | 7mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.342Z |  | 2025-04-09T20:36:00.779Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7303857893718515713 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHsi5fF5aQ3-Q/feedshare-shrink_800/B4EZVxmVidHMAo-/0/1741367630480?e=1766620800&v=beta&t=ZCUz2A7tBb0K8XEiz15uAt56LSUcP4gaxU1DZ8cosI4 | Exciting new features at Moast
- Instagram import
- Stories widget
- In-app media editing
- Speed improvements

and more 🚀 

If you're on Shopify, download the app for free 👉 https://lnkd.in/e8nSnpX6 | 18 | 1 | 0 | 9mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.343Z |  | 2025-03-07T19:23:40.980Z | https://www.linkedin.com/feed/update/urn:li:activity:7303825224465022979/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7300583507649527809 | Video (LinkedIn Source) | blob:https://www.linkedin.com/261edf58-e8bb-49fb-bf83-cd9aa763cddd | https://media.licdn.com/dms/image/v2/D4E05AQHRqB0JHqrzlg/videocover-low/B4EZVDh.WYGwCQ-/0/1740594739548?e=1765778400&v=beta&t=KDZQIrQVjj4xZ8TyLGEaRc3CtXdbPOjEWe2fxd1lKLQ | Big update to share!

For years, Moast has been helping brands build social proof and trust through community. Along the way, we noticed how extremely overpriced and overcomplicated shoppable video apps were.

Moast is changing that, now offering the most affordable shoppable video solution on the Shopify App Store. 

And we’re combining it with the high-quality, beautifully designed widgets that brands already love. Before launching these new features, we spent weeks researching the space to make sure we weren’t just another option; but that we are the best value option.

There are just 2 plans:
- Forever Free
- $15 / month

Both plans offers unlimited views with no hidden fees (none of that pay-per-view nonsense). Just simple, high-quality shoppable video that works. 

Brands are already on board! DAVIDsTEA, one of Montreal’s most known brands, is using Moast for their shoppable video.

If you’re thinking about adding shoppable video to your Shopify store, see how much you can save with our Savings Calculator 👇 

https://lnkd.in/eiWPMU_r | 84 | 22 | 3 | 9mo | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.345Z |  | 2025-02-26T18:32:26.506Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7270491499421745152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHwkcLLhjPu9Q/feedshare-shrink_800/feedshare-shrink_800/0/1733420251673?e=1766620800&v=beta&t=fmYezfKBuQS7hcPI3T6Thcb5LKj6YYIg4u-PM0lcQDQ | Just a few months after launching on the Shopify App Store, and we’ve already hit 17 five-star reviews! 

Moast is quickly becoming a must have UGC app for Shopify merchants.

Couldn’t be prouder of what the team has achieved so far—and I can’t wait to share what’s coming next week 👀

Huge shoutout to Andrew Finlayson, Steve Mastro, and Edi Bouazza for your incredible work and dedication 💪 | 47 | 4 | 2 | 1yr | Post | Mark Yeramian | https://www.linkedin.com/in/markyeramian | https://linkedin.com/in/markyeramian | 2025-12-08T05:17:01.346Z |  | 2024-12-05T17:37:32.662Z |  |  | 

---



---

# Mark Yeramian
*Moast*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [About – Mark Yeramian – Medium](https://medium.com/@moast-io/about)
*2025-09-05*
- Category: blog

### [Organic Social: How do you achieve high growth one-to-one social proof? with Mark Yeramian, Moast (episode 172) - Keep Optimising Marketing Podcast](https://keepoptimising.com/moast-social-proof-podcast/)
*2023-10-04*
- Category: podcast

### [Keep Optimising](https://redcircle.com/shows/keep-optimising)
- Category: article

### [How to Evolve with Digital Marketing Trends](https://gritdaily.com/how-to-evolve-with-digital-marketing-trends/)
- Category: article

### [Blog | Moast.io](https://www.moast.io/blog?9d0b6a78_page=14)
*2025-06-02*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Organic Social: How do you achieve high growth one-to-one social ...](https://keepoptimising.com/moast-social-proof-podcast/)**
  - Source: keepoptimising.com
  - *Oct 4, 2023 ... Mark Yeramian is the co-founder and CEO at Moast, a tool that enables you to connect new shoppers with local product owners to provide...*

- **[Grow Revenue Between Shopify Direct-To-Consumer And Retail ...](https://open.spotify.com/episode/7HDYwsvIOyGAqQLrOBc2Cu)**
  - Source: open.spotify.com
  - *... podcast show notes, full transcripts, actionable DTC marketing ... Grow Revenue Between Shopify Direct-To-Consumer And Retail With Mark Yeramian O...*

- **[Grow Revenue Between Shopify Direct-To-Consumer And Retail ...](https://ecommercefastlane.com/podcast/episode-225/)**
  - Source: ecommercefastlane.com
  - *Grow Revenue Between Shopify Direct-To-Consumer And Retail With Mark Yeramian Of Moast · A Shopify Podcast To Grow Revenue And Loyalty · Get Your Comp...*

- **[Acquiring UGC From Customers: A 2023 Playbook | HackerNoon](https://hackernoon.com/acquiring-ugc-from-customers-a-2023-playbook)**
  - Source: hackernoon.com
  - *Jun 28, 2023 ... With Moast, brands onboard customers to the platform so that ... Mark Yeramian. Jun 23, 2023....*

- **[Is the return-to-office push backfiring on employers? - Fast Company](https://www.fastcompany.com/91392977/is-the-return-to-office-push-backfiring-on-employers-retrun-to-work-office-policy-debate)**
  - Source: fastcompany.com
  - *Sep 23, 2025 ... Podcasts · Video · INNOVATION FESTIVAL. |. Custom Studio · IBM · Texas A&M ... Mark Yeramian, Cofounder and CEO, Moast.io. Build Trus...*

- **[Mark Yeramian, Co-Founder, CEO - Moast.io | Featured](https://featured.com/p/mark-yeramian)**
  - Source: featured.com
  - *Mark Yeramian. Co-Founder, CEO at Moast.io. About. Launched Moast in 2022 alongside 2 other co-founders. Moast is a Shopify app that helps brands coll...*

- **[Why Are You Passionate About Diversity and Inclusion? - Pursue ...](https://pursuethepassion.com/why-are-you-passionate-about-diversity-and-inclusion-2/)**
  - Source: pursuethepassion.com
  - *Oct 18, 2023 ... Mark Yeramian Co-Founder, CEO, Moast.io. Making a Critique of Exclusive Diversity Approaches. I am not passionate ......*

- **[100 Top Direct-to-Consumer (D2C) Companies · December 2025 ...](https://www.f6s.com/companies/direct-to-consumer-d2c/mo)**
  - Source: f6s.com
  - *... Interview, L'Officiel and others. KORSUN ... Moast uses your community of loyal customers to accelerate your sales cycle. Mark Yeramian | F6S - Im...*

- **[The SEO + Content Marketing Agency | Placeholder](https://placeholderseo.com/)**
  - Source: placeholderseo.com
  - *I've worked with so many agencies who talk ... They know the technical factors, they produce great content, and they're super responsive. Mark Yeramia...*

- **[21 High-Powered Takeaways from Ad Universe Summit - Customers ...](https://customers.ai/blog/ad-universe-summit-takeaways)**
  - Source: customers.ai
  - *Feb 22, 2024 ... Create Trust Through Localized Experiences – Mark Yeramian. Co-Founder, CEO of Moast ... talk to our sales team or sign up and start ...*

---

*Generated by Founder Scraper*
