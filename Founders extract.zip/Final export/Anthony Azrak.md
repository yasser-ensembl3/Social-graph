# Anthony Azrak

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : OpenSesame
**Durée dans le rôle** : 1 year 5 months in role
**Durée dans l'entreprise** : 1 year 5 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Embedded Software Products

## Résumé

I help you harness the power of AI agents in seconds

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACcabSIBfCwrpAY70TFYzMnLsSR5ufKX1w4/
**Connexions partagées** : 51


---

# Anthony Azrak

## Position actuelle

**Entreprise** : OpenSesame

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Anthony Azrak

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397669685887922176 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4D05AQFDR8qXRtINVw/videocover-low/B4DZqm7VvPGwBU-/0/1763737168587?e=1765774800&v=beta&t=Sd1jawD--ros3stT0eGqWA_QbmOrKKORzoK1mARk6fo | It's always day 1 at OpenSesame | 33 | 3 | 0 | 2w | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:18.353Z |  | 2025-11-21T16:18:15.172Z | https://www.linkedin.com/feed/update/urn:li:activity:7397649922369597440/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396260571781890048 | Text |  |  | Ending the year in style 🫡 | 17 | 0 | 0 | 2w | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:18.354Z |  | 2025-11-17T18:58:56.189Z | https://www.linkedin.com/feed/update/urn:li:activity:7396221854547578880/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7393798638612684800 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEWD8H4vhm74g/feedshare-shrink_800/B4DZpu9xJkIgAk-/0/1762798278732?e=1766620800&v=beta&t=q5-pz-QcHXG_N_HfPOkWPAY3JBTjasUAz4ME5UIHyFY | We met Parsa at the very beginning of the company, while we were part of the Next36 incubator. Thrilled to finally be able to work with him! | 21 | 0 | 0 | 3w | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:18.355Z |  | 2025-11-10T23:56:05.581Z | https://www.linkedin.com/feed/update/urn:li:activity:7393711875705835520/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7369752947100004352 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a22e9ee3-4ae1-4a1d-8ba5-841528c48aaf | https://media.licdn.com/dms/image/v2/D5605AQGOfz58a1Edig/videocover-high/B56ZkaMUAWIACQ-/0/1757081062133?e=1765774800&v=beta&t=rXjEkYbmsl2DdSV8w5HAaLKaoRCp6CUXuQf3J9xJa_s | Had a blast chatting with Evan McCann on his podcast! We dove into our thoughts on a16z speedrun , what the future of interfaces is going to look like, and much more! | 19 | 2 | 1 | 3mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.357Z |  | 2025-09-05T15:27:05.977Z | https://www.linkedin.com/feed/update/urn:li:activity:7369732167892942852/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7369077636888698880 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9cbdf20d-de9c-4dd9-83a6-37f481ec9bf5 | https://media.licdn.com/dms/image/v2/D4D05AQFcGGFCFVzqTw/videocover-low/B4DZkQybH2IcCE-/0/1756923291771?e=1765774800&v=beta&t=doCVZDh7tMhaEx4pjIlVpQAwzbYcHzeelBkP3XmVu8o | We're finally unveiling our new branding.
Contrary to all these AI companies that are IN YOUR FACE and opt to use darker colors, we've chosen to do the opposite.
Our brand, just like our product, should feel like a breath of fresh air, like stepping into a world where your AI woes go away.

Let us know what you think! | 44 | 3 | 0 | 3mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.359Z |  | 2025-09-03T18:43:39.476Z | https://www.linkedin.com/feed/update/urn:li:activity:7369070435872792577/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7365777851482021891 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2c0d2301-28af-4f8c-9610-153d670fc527 | https://media.licdn.com/dms/image/v2/D4D05AQE9ZJs1rDo15Q/feedshare-thumbnail_720_1280/B4DZjgfVwkHwA4-/0/1756112970128?e=1765774800&v=beta&t=dHJE90twt4kKEsLbF9sKZEi07Ttg-5YbxOAzMxZh3Ug | It’s never been easier for product teams to future-proof their software! | 16 | 0 | 0 | 3mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.360Z |  | 2025-08-25T16:11:29.328Z | https://www.linkedin.com/feed/update/urn:li:activity:7365776977905016834/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7364329084102819840 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGv7lgHSiCVHA/feedshare-shrink_800/B4DZjNSo12GQAg-/0/1755790898533?e=1766620800&v=beta&t=He9fdYHV9Uu-cNInSOcJov2mOq4ozgTsSuIdhtQ-1A0 | Come see us at our booth on the second floor at the a16z speedrun AI Faire!! | 16 | 0 | 0 | 3mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.361Z |  | 2025-08-21T16:14:36.268Z | https://www.linkedin.com/feed/update/urn:li:activity:7364320759931973632/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7363242725351034881 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bd93b0a3-38a3-4c2f-a623-e143a940a984 | https://media.licdn.com/dms/image/v2/D4D05AQFTLdK4oETXkQ/feedshare-thumbnail_720_1280/B4DZi8T3WKHwA4-/0/1755505982202?e=1765774800&v=beta&t=OgyJJUnv2ToXi0KfjmkyatNOfGRoOL7R2L_KRzRDugE | Every product person should learn more about the new AI interfaces that are slowly taking over SaaS | 13 | 0 | 0 | 3mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.362Z |  | 2025-08-18T16:17:48.158Z | https://www.linkedin.com/feed/update/urn:li:activity:7363240011221131266/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7359297382410330113 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3f290d32-a185-4342-a238-2cf5f2c8b8df | https://media.licdn.com/dms/image/v2/D4D05AQGAmbQ5vG5rig/videocover-high/B4DZiF3vqvHYCM-/0/1754592659168?e=1765774800&v=beta&t=yx24uK84_0Iz4sCwHMVgTpxhLQRCVWnMVUmuMKoQo98 | We set a pretty ambitious goal for ourselves, now it's time to execute 🫡 | 39 | 8 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.363Z |  | 2025-08-07T19:00:25.100Z | https://www.linkedin.com/feed/update/urn:li:activity:7359295087362662400/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7358149072374898688 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f99ccaec-8f76-4995-abba-9ac280d73c93 | https://media.licdn.com/dms/image/v2/D4D05AQESLRUZz5zAYw/feedshare-thumbnail_720_1280/B4DZh0N3y3HYA0-/0/1754296454043?e=1765774800&v=beta&t=Tv1dqbZbPjBM_ANqQp1zfRT9aC2ePJ85wfc0zBnQx_Q | TLDR:

- New Collaboration feature (you can now share and work on your Cell with your coworkers)

- New Add-on panel (Voice dictation is our first!)

- New Analytics window

Much more planned for this week 🎉 | 22 | 2 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.364Z |  | 2025-08-04T14:57:26.653Z | https://www.linkedin.com/feed/update/urn:li:activity:7358145954258075649/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7354157157996503040 | Article |  |  | Big thanks to BetaKit, Madison McLauchlan, and Aaron Anandji for covering the next step in our journey!! | 61 | 5 | 1 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.365Z |  | 2025-07-24T14:35:00.099Z | https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7354153210229465088 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e33a1c08-d8d5-4e98-9b71-a6dbcf268af1 | https://media.licdn.com/dms/image/v2/D4E05AQHZuCNFMUA9-g/feedshare-thumbnail_720_1280/B4EZg8yyY5HgBA-/0/1753366604483?e=1765774800&v=beta&t=TQ5NB_BoQNCmiNDtW-Ev7CQjxAXOpuTH2U_iI7wfCnc | We just got backed by a16z speedrun.

A year ago, OpenSesame didn’t exist.

It was just two of us in a tiny meeting room on Bloor Street East in Toronto, scribbling on a whiteboard, trying to chase an idea only we had conviction behind.

We built the wrong thing first.

Got some traction. But we weren’t proud of it. There was a sense of emptiness.

It didn’t feel like it was solving anything important, and at that point, the pressure was pretty high. We had lost a core team member, and we entered a spiral of overbuilding, which led us to realize that we needed to start thinking through what the future of the company would be without building anything.

So we went back to the whiteboard.

And we started from the beginning, this time with the concept of interfaces.

Consider this: for over 50 years, the GUI has been the standard way we interact with software. But the world’s changing. Users are changing. And work is changing too.

People want to use software the way they think: with language.

But for most companies, building an AI-native interface is hard:

• It takes a full team of AI engineers
• It requires months of infrastructure changes
• It needs constant iteration and testing

To make this possible, we're creating something called the Language User Interface (LUI). This interface can connect to your APIs, learn about your product, and enable users to get work done by using natural language.

Proud to say we’re backed by a16z speedrun, with participation from Aidan Gomez(CEO, Cohere), Kevin Wang + Spencer B. (CPO and SVP of Growth Braze), Daniel Nieto, Comma Capital, and advisors from Merge, Drift, a Salesloft company and AngelList.

Our current customers are in management software: construction, workforce, and financial services, where product complexity is high and time is scarce.

But this is just the beginning.

We believe the LUI will replace the GUI as the primary way people get work done across every category of software.

If you’re building a product that should be AI-native, or if your users are asking about AI that isn't a generic wrapper, and you don’t want to spend months figuring it out

We’d love to show you what we’ve been working on.

A big thank you to those who have supported the journey early: 

David Ongchoco, Daniel Nieto, Adarsh Bhatt, Robert Williams, Matt Bilotti, Alexandra McGregor, Mischa Hamara, Kyle J Winters, NEXT Canada, Reza Satchu, Ajay Agrawal, Mike Murchison, John Gleeson, Troy Kirwin, Lester Chen, Aidan Gomez, Kevin Wang, Spencer B., Aditya Uppal, Puru Arora and to the many others who've helped and backed us from day 0.

Want to put Cell into your product? Comment "LUI" below, and we'll reach out :) | 350 | 90 | 7 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.367Z |  | 2025-07-24T14:19:18.878Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7354146813076987905 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b269fe47-b807-4e07-8016-93f0196bd14e | https://media.licdn.com/dms/image/v2/D5605AQEEq3rLxKADgQ/videocover-low/B56Zg8qZPDHMCE-/0/1753364412616?e=1765774800&v=beta&t=kYOy41QNpUnESlEi6T8LNupp6ViLcaEL_6DFvrKrJn8 | Absolute pleasure speaking to Rudraksh and Manit! We’ve poured our hearts and souls into OpenSesame so it was nice to talk about the journey so far | 26 | 2 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.368Z |  | 2025-07-24T13:53:53.678Z | https://www.linkedin.com/feed/update/urn:li:activity:7354143386011910145/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7353842704973197314 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF4EEICghrMoA/feedshare-shrink_800/B4DZg35P_AHYAk-/0/1753284412017?e=1766620800&v=beta&t=8yr8tmUatHUgN7jMuEW8paLxXrJ1tCy1j1zF34bgVH0 | I pretty much always carry a notebook and pen with me, inspiration is fleeting, so the quicker you can get some ideas on paper, the quicker you can start iterating on them | 18 | 2 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.369Z |  | 2025-07-23T17:45:28.656Z | https://www.linkedin.com/feed/update/urn:li:activity:7353807829062901760/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7353134959093510145 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4e2d3783-b3d0-4d50-aaca-172f9feb3499 | https://media.licdn.com/dms/image/v2/D4D05AQFV-sEQGuyG_Q/videocover-low/B4DZguNlsFGsCE-/0/1753121989992?e=1765774800&v=beta&t=gg_tVo_joPj3lmdafGPxgc7CsGOQruCtCeo-vyvVdYM | Embedded intelligence should be available to everyone, regardless of whether you're technical or not! | 15 | 0 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:23.370Z |  | 2025-07-21T18:53:08.889Z | https://www.linkedin.com/feed/update/urn:li:activity:7353127610203222017/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7351390088259379200 | Text |  |  | Browser automations vs API-based automations: a debate

Early on at OpenSesame, we had to make a crucial decision: should the language user interface (LUI) we’re building use browser-based automations or API-based ones? This one question led us to explore the pros and cons of each, and here’s a summary of our findings:

Browser automations
Pros:
1. It has a “wow” factor (it feels crazy to see an AI controlling a cursor)
2. Users have a way easier time understanding what actions are being performed
3. No constraints on whether the website has APIs or not

Cons:
1. It's pretty slow
2. Prone to errors and endless loops
3. Goes against certain website guidelines

-------------------------------------------
API-based automations
Pros:
1. Very quick
2. Made for software
3. Very reliable

Cons:
1. Lots of websites/products don’t have any documentation
2. Limited feedback options available beyond text-based confirmation


We ended up picking API-based automations because speed and accuracy are our priorities. 
Although we recognize that browser-based automation tools are still in their infancy and are likely to improve drastically in the coming months, the sticking point for us was that it simply made no sense to us that a software-based entity (AI agents) should use interfaces (mouse cursor, GUI) that were made for humans. And with MCP, OpenAPI specs, and llms.txt becoming more and more prevalent, we were comfortable enough to take the leap on API-based automations. | 19 | 2 | 1 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:25.569Z |  | 2025-07-16T23:19:39.264Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7350963918468448256 | Video (LinkedIn Source) | blob:https://www.linkedin.com/04688015-5bdc-49d9-a2a9-20d342f1734f | https://media.licdn.com/dms/image/v2/D4D05AQGHTlSVboDBxg/videocover-low/B4DZgPet51GgCI-/0/1752606370273?e=1765774800&v=beta&t=VYkXhKm4ZLYXEv3xwHC2QTC4eysUjRDNHUiPWMH-o9g | A little preview ☀️ | 76 | 5 | 1 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:25.569Z |  | 2025-07-15T19:06:12.468Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7350299893938184192 | Text |  |  | What the hell is MCP??

It seems obvious to me that in a world where AI agents will one day do most of our work, or at the very least, where all work is done through natural language, we would need some kind of protocol that allows for the translation from language to software action. This is what MCP, or Model Context Protocol, allows you to do.

In theory, it's a great protocol, but in practice, it suffers from a couple problems:
1. It's hard to set up and use
2. It's not something you can easily monetize
3. Beyond plugging it into your favourite AI tool (Claude, Cursor, Cline, etc.), people don't really know what to do with them

I would also argue that MCPs have another, less-obvious problem: their name.
An ugly, 3-letter acronym that doesn't really mean much. It's almost like Anthropic didn't want the average person to adopt them.

We're rapidly moving more and more towards a world where anyone can easily make their own bespoke software using tools like Bolt and Lovable, and it seems apparent that beyond the necessary technological advancements needed to make that happen, companies must stop assuming that their end-user is technical and begin to merge the concepts of developer experience (DX) and user experience (UX), and start thinking about the overall human experience (HX). | 22 | 3 | 0 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:25.570Z |  | 2025-07-13T23:07:36.683Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7349249332904194048 | Text |  |  | Some thoughts on legacy software companies and the AI wave

It’s no secret that we’re currently going through a technological shift, and a pretty large one at that. Historically speaking, we’ve seen other evolutions of the sort with mobile and cloud. However, the notable difference stems from the finite benefit that these previous technologies brought. In other words, AI is one of the only technologies that I can think of that seems to have no end-state. What that means in practice is that being slow to adopt AI is a lot less forgiving; if you don’t invest in AI, you risk playing catch-up for a long long time.

Legacy software companies are in a precarious position. On the one hand, they’ve created profitable, sticky products that serve a very specific vertical; in other words, a great business. But on the other hand, they’re starting to face pressure from their users to release AI features and bring their product closer to the ChatGPT experience they love.

These legacy companies, sooner or later, will have to make up their minds: build or buy.

Setting my bias aside, I do genuinely think that purchasing from third-party AI companies is the way to go for most.

Although the prospect of keeping everything in-house might seem appealing, the large price tag that comes with hiring AI talent and the months of development required are likely to dissuade most. 

Once again, these AI features aren’t things that you release and forget about; you have to continuously improve upon them, implementing the latest models, the latest agentic workflows, and the best practices, just to stay competitive in the market. 

The AI wave will be a huge test for legacy software companies: invest in AI early, and reap the benefits, or be slow to adopt, and they can expect new AI-native companies in their vertical to siphon off their customers very quickly. | 31 | 0 | 1 | 4mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:25.571Z |  | 2025-07-11T01:33:03.414Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7345863384870907906 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHDpXNamFLUsg/feedshare-shrink_800/B56ZfD9bxfHEAg-/0/1751339364999?e=1766620800&v=beta&t=9ZFHVkatgUTa_4NE4xJGTcNTb6iK0Hq2rOhLLDEOc1o | Can’t believe it’s already been close to a year since we met David! 
I can’t thank him enough for taking a chance on us and helping us at every step of the way 

Happy Canada Day to all!! 🇨🇦 | 15 | 1 | 0 | 5mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:25.572Z |  | 2025-07-01T17:18:30.495Z | https://www.linkedin.com/feed/update/urn:li:activity:7345809389213126659/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7336797211361525763 | Video (LinkedIn Source) | blob:https://www.linkedin.com/cdadd51d-2ee9-4df7-9297-25f73c28e8fb | https://media.licdn.com/dms/image/v2/D4D05AQEGnc-7RkeWng/feedshare-thumbnail_720_1280/B4DZdFwikLHAA0-/0/1749222043790?e=1765774800&v=beta&t=McjEycGZWdjn-xlSFZbk_mkz4QrDd-GjAvwQnNd-clY | We've been asked to increase capacity

but nah, we're only accepting the best hackers around,

apply today: https://lu.ma/amkza3nz | 15 | 3 | 0 | 6mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.986Z |  | 2025-06-06T16:52:46.289Z | https://www.linkedin.com/feed/update/urn:li:activity:7336769094613880833/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7335854926033534976 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFZQ49oVJcYhg/feedshare-shrink_800/B4DZc4rbIrGkAg-/0/1749002623685?e=1766620800&v=beta&t=a1BFikwVgp2CzDY0BV-tzow5wOxfG2TrcCoxLiEsMRw | Come hang out with the three of us! | 54 | 5 | 0 | 6mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.987Z |  | 2025-06-04T02:28:27.960Z | https://www.linkedin.com/feed/update/urn:li:activity:7335848703863193600/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7331011023702740992 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e5293fc9-000b-438e-98c6-d570f7df4060 | https://media.licdn.com/dms/image/v2/D4E05AQG6zZ3MbDTSJA/videocover-low/B4EZbz7hRQHYBo-/0/1747849208347?e=1765774800&v=beta&t=_dkTjaZzmnYykYGRpwZCdDVAZqmKsVSedinZcFXRT0o | Management software hasn’t evolved in over 20 years, and users are done waiting.

The teams relying on these platforms every day are tired of clunky interfaces and rigid workflows. They’re churning from legacy SaaS to products that actually feel like 2025, not 2005.

Why should they be stuck with outdated tools while the rest of the world rides the AI wave?

OpenSesame is helping modern SaaS products break free from old paradigms.
By embedding Cell, our drop-in AI coworker, companies are turning their management software into next-gen Language User Interfaces (LUIs), where human users and AI agents collaborate through a single, powerful command bar.

✅ Instantly surface KPIs
✅ Trigger complex workflows
✅ Execute product-specific API actions, all in plain English

This isn’t just an upgrade, it’s a reinvention of how users interact with software.

If you're building a SaaS platform and want to see how others are using embedded AI to drive retention, unlock new revenue, and delight users, let’s talk. | 24 | 0 | 0 | 6mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.988Z |  | 2025-05-21T17:40:31.649Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7326677420760096771 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHN8lWyFILAxQ/feedshare-shrink_800/B4EZa2WSnNHYAg-/0/1746816019222?e=1766620800&v=beta&t=Mw2kGaf0NKLknLJW1KTgGHNP0JEzAOD8r3CfOL2N9mc | You might've missed it, but yesterday, Stripe CEO Patrick Collison and ex-Apple Chief Design Officer Jony Ive sat down for an hour-long discussion about design, history, and rituals. Here's a breakdown of the parts I found interesting:

🖥️ 1984-Level Awe, Revisited:
Ive recalled first touching a Macintosh in art school and instantly sensing a renegade team’s empathy. That single moment lured him from London to Cupertino. “Products are declarations of our values,” he said. Build only to hit a price, and the object will advertise compromise forever. Build to “sincerely elevate the species,” and even the way a power cable unspools whispers, Someone cared about me.

❤️‍🩹 Care You Can Sense, and Neglect You Can Smell:
He obsesses over the invisible parts of a device because “what we do when no one sees” reveals who we are. 

🌅 From Innocent Euphoria to IPO Mania:
Early-’90s Silicon Valley, Ive said, was “innocent euphoria” in service to humanity. Today, profit and power crowd purpose. He isn’t nostalgic but cautionary: velocity can’t excuse damage. 

🍳 Rituals Worth Stealing:
Friday “make something for each other.” At Apple it was breakfast; service kept the team humble.
Design days in colleagues’ homes. Sketching UI on a coffee table anchors decisions in real life, not conference rooms.
Tiny, high-trust squads. “Opinions aren’t ideas.” Listening protects fragile concepts long enough to grow. | 19 | 3 | 2 | 6mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.989Z |  | 2025-05-09T18:40:20.193Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7325897685171933202 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFdzUa4n0tI7A/feedshare-shrink_800/B56ZanfKrzGUAg-/0/1746566687992?e=1766620800&v=beta&t=akV9oN6V7Rpx0b_DORE-i_X7g3DjsHRTRNg9QPG4JYc | We've been keeping this under wraps for a few weeks, but now it's time to unveil our next event!

We're excited to give more details as we get closer to June 26th, but trust me, if you're in Toronto for Toronto Tech Week, you won't want to miss it. 

It won't be your usual hackathon. | 34 | 6 | 0 | 7mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.990Z |  | 2025-05-07T15:01:56.742Z | https://www.linkedin.com/feed/update/urn:li:activity:7325895575629979648/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7323782826040987648 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKnTA8cuLFTg/feedshare-shrink_800/B4EZaNNq.UGQAk-/0/1746125893846?e=1766620800&v=beta&t=1lQY4H_WEjIH_i5-dhWo9DOWxQfvSV4q4YziirodRGo | Andrej Karpathy might've just posted one of the most important threads about what the future of Language User Interfaces will look like in the future, and nobody on LinkedIn is talking about it...

A summary:
Chatting with LLMs today feels like using a computer terminal in the '80s; the GUI for this new paradigm hasn’t been invented yet. But here's what he thinks it'll look like:

1️⃣ Visual-first: Vision is our brain’s highest-bandwidth input. Future interfaces will lean heavily on visuals, charts, images, animations, not long text.

2️⃣ Generative & adaptive: The interface will be generated on-the-fly, personalized for your exact prompt and immediate purpose.

3️⃣ Procedural by design: Not just one big blob of output, but dynamic canvases built from composable, interactive components, charts, diagrams, and maybe even full apps.

It's already starting. Look closely, things like code blocks, LaTeX, markdown, tables, even Mermaid charts or OpenAI’s Artifacts tab, are hints of what’s to come.

He's betting the interface of the future is a generative, fluid 2D canvas, ephemeral, intelligent, and made just for you.

No need to click around different buttons or menus; remembering a monotonous, repetitive workflow will be a thing of the past. The future of interfaces is generative and language-driven. | 21 | 2 | 0 | 7mo | Post | Anthony Azrak | https://www.linkedin.com/in/anthony-azrak | https://linkedin.com/in/anthony-azrak | 2025-12-08T04:41:27.991Z |  | 2025-05-01T18:58:15.033Z |  |  | 

---



---

# Anthony Azrak
*OpenSesame*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 12 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [Kevin's Journey with Humi by Pitch Please](https://creators.spotify.com/pod/profile/pitchpleasepodcast/episodes/Building-Canadas-1-Employment-Platform-Kevins-Journey-with-Humi-e2og343)
- Category: podcast

### [Meet the Founders of OpenSesame](https://ideamensch.com/open-sesame/)
*2019-12-07*
- Category: article

### [Let’s talk Content & Courses with Don Spear, CEO, OpenSesame, Andrew Barnes,CEO, GO1, Laura Baldwin, President, O’Reilly Media](https://elearninfo247.com/2022/08/24/lets-talk-content-courses-with-don-spear-ceo-opensesame-andrew-barnesceo-go1-laura-baldwin-president-oreilly-media/)
*2022-08-24*
- Category: article

### [Friday Feature: Open Source CEO](https://sparkloop.app/blog/friday-feature-open-source-ceo)
*2024-01-01*
- Category: blog

### [Speedrun - Company Profile](https://speedrun.a16z.com/companies/opensesame)
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 56,221 words total*

### Building Canada’s #1 Employment Platform: Kevin’s Journey with Humi by Pitch Please
*24,254 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/pitchpleasepodcast/episodes/Building-Canadas-1-Employment-Platform-Kevins-Journey-with-Humi-e2og343)

![Image 1: Building Canada’s #1 Employment Platform: Kevin’s Journey with Humi](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/41105780/41105780-1727654117583-d126178ddf304.jpg)

Building Canada’s #1 Employment Platform…
-----------------------------------------

Pitch Please Sep 30, 2024

00:00

39:49

[![Image 2: Assembling a Dream Team: Hiring Strategies for Startup Founders — Rocket Fuel Ep #10](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/41105780/41105780-1732085079090-4b0b157377d4.jpg) #### Assembling a Dream Team: Hiring Strategies for Startup Founders — Rocket Fuel Ep #10 Rocket Fuel Ep #10 – Building Your Dream Team: Hiring for Startup Success In this episode of Pitch Please, Mike Thibodeau explores one of the most crucial aspects of startup growth: assembling your dream team. Joining him is Farial Karbasi, founder and CEO of HRXconnect, a seasoned expert in hiring and team-building for startups. Together, they dive into the strategies, challenges, and frameworks that can help founders hire their first employees, attract top talent, and retain them to scale their ventures. With insights drawn from over a decade of experience, Farial shares actionable advice for startups navigating the early stages of hiring, from defining roles to ensuring cultural alignment. They discuss key considerations like when to hire generalists vs. specialists, how to leverage contractors, and the importance of building an environment where employees thrive. In This Episode, You’ll Learn: • Early-Stage Hiring Tips: How to define roles, avoid misalignment, and set the foundation for a strong team. • Generalists vs. Specialists: Deciding which type of hire is best for your startup’s current needs. • Attracting Top Talent: Practical strategies for standing out as a startup and competing for the best candidates. • Employee vs. Contractor: When to hire full-time employees, work with contractors, or outsource. • Retention Done Right: How to onboard and keep employees motivated, even in a fast-paced, ever-changing environment. Chapters 00:00 - Assembling the Dream Team 02:30 - Defining Roles and Expectations 04:17 - Qualities to Look for in Hires 07:35 - Avoiding Unrealistic Expectations 11:31 - Hiring Employees vs. Contractors 15:12 - Clarity and Communication in the Hiring Process 18:58 - Transitioning from Founder-led Hiring 21:30 - Choosing Between Employees, Contractors, and Outsourcing 26:08 - Attracting and Retaining Talent 29:02 - Avoiding Pitfalls in Retention 33:00 - Taking Care of Mental Health 35:42 - Continuous Iteration for Success More About Farial Karbasi Farial has always been passionate about helping businesses thrive by creating stronger, higher-performing and more engaged teams and cultures. She has spent the past 8 years building the proven frameworks and strategies to achieve this and decided to launch her own business,HRXconnect, to really help more businesses who are looking to significantly improve their HR strategies, grow their business, and improve overall company culture but don't have this expertise internally. More About HRXconnect HRXconnect works with owner-operated businesses that have grown to the point where building a solid HR foundation is essential to attract and keep top talent, strengthen their team and culture, and achieve long-term success. Relying on finance or other departments to manage HR is no longer practical. Many of these businesses don’t have the time or expertise to create a proper HR function, so they hire us to not only design and manage an HR strategy that fits their needs but also to act as their HR team. Whether it’s navigating complex employment issues, developing workplace policies, or fostering inclusive environments,HRXconnect provides hands-on support and strategic guidance. Our goal is to empower organizations with the tools and expertise needed to build a thriving workforce while focusing on long-term, sustainable growth. Want to Connect? Farial: https://www.linkedin.com/in/farial-k/ HRXconnect: https://www.linkedin.com/company/hrxc/ Want to Learn More? Struggling to build your dream team? HRXconnect offers personalized hiring and HR solutions to help startups navigate early-stage growth. From defining roles to implementing retention strategies, their team works with you to create the foundation for long-term success. Visit HRXconnect to learn more about their startup-focused services. Nov 20, 2024 36:39](https://creators.spotify.com/pod/profile/pitchpleasepodcast/episodes/Assembling-a-Dream-Team-Hiring-Strategies-for-Startup-Founders--Rocket-Fuel-Ep-10-e2r85hh)[![Image 3: Nourishing Energy for a Healthier You: The Benny Story — Founder Stories Ep #79](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/41105780/41105780-1731295025298-7ffcc956e6175.jpg) #### Nourishing Energy for a Healthier You: The Benny Story — Founder Stories Ep #79 In this episode of Pitch Please, Mike Thibodeau sits

*[... truncated, 175,801 more characters]*

---

### Meet the Founders of OpenSesame
*1,230 words* | Source: **EXA** | [Link](https://ideamensch.com/open-sesame/)

#### Don Spear, President & CEO

With more than 25 years of experience in starting and growing companies, Don served at PetSmart in senior officer and director positions from its founding through IPO. Don also served as President of Banfield, the Pet Hospital, where he led its expansion from 4 to 250 pet hospitals. More recently, Don co-founded BlueVolt (www.BlueVolt.com), a successful elearning company focused on the manufacturing and distribution markets.

#### Joshua Blank, Senior Vice President & General Manager

Josh has an extensive background in technology and software development. After co-founding PopArt, an Internet services agency and Eleven Wireless, a broadband network management system focused on the hospitality market, Josh co-founded BlueVolt with Don. Josh architected and oversaw development of BlueVolt’s web-based software products including its flagship product, the BlueVolt learning management system.

#### Tom Turnbull, Vice President, Business and Community Development

Tom has worked in business development, product, and legal roles at several Internet companies, including Internet Brands (NASDAQ: INET), SplashCast Media, and the Los Angeles Times. Additionally, Tom led new business development for Knowledge Universe, the largest privately held for-profit education company. Tom previously worked as an associate attorney with Williams Kastner and a consulting manager with Arthur Andersen.

#### Aaron Bridges, Lead Software Engineer

Aaron has ten years of experience in software engineering and design, in addition to industry-specific experience designing and managing elearning platforms. As an OpenSesame co-founder, Aaron designed OpenSesame’s patent-pending platform technology. Aaron joined BlueVolt in 2002 as an Application Developer and rose through the ranks to Product Development Manager, leading the team that designed and built the BlueVolt elearning platform product.

#### What are you working on right now?

Don Spear (DS): In November 2010 the four of us founded OpenSesame (www.OpenSesame.com) an online marketplace for elearning content. Our mission is to make it as easy to buy and sell elearning courses as it is to buy a song on iTunes. We recently completed a $2 million seed funding round, so right now we’re focused on accelerating growth of our marketplace by attracting course buyers and sellers, hiring more great people, and adding new features to the site. These new features will make it easier to find courses and share them with diverse groups.

### What does your typical day look like?

Tom Turnbull (TT): The OpenSesame team sits in one big room, because we value collaboration, paired engineering and open sharing of ideas. We all have our own workspace, but we spend a good chunk of every day working together, whether it’s brainstorming what a new feature should look like or pairing to write code. We make decisions thoughtfully and then move quickly. We also value Mongolian BBQ, bagels and burritos – Chipotle is our favorite.

### 3 trends that excite you?

Josh Blank (JB): Unconventional educators. I’m excited to see new content authoring tools enabling all kinds of subject matter experts to create elearning content. No longer is teaching limited to traditional teachers or traditional course developers. With the affordable and easy-to-use authoring tools available today, everyone can share their expertise.

Aaron Bridges (AB): Mobile technology. I’m excited to see learning content developed specifically for mobile devices that will enable people to find information and apply it within the context of their everyday jobs.

TT: Social learning. I love learning about the ways people are building professional learning networks through social media – it brings new skills into reach for a wide variety of people.

### How do you bring ideas to life?

JB: We have great, talented people and a commitment to bringing big ideas to life. The challenge for us is prioritizing our many new ideas to decide what we’re going to do next. To make these difficult decisions, we work with our team, our advisory group and, most importantly, use social media and meet-ups to ask our customers what they need.

### What inspires you?

DS: We are inspired by the hundreds of millions of people worldwide who want to get better at their jobs through professional training. It’s our goal to make learning and development accessible, easy and affordable, for everyone, anywhere.

### What is one mistake you’ve made, and what did you learn from it?

AB: Through ten years of working together in a variety of startups and technology companies, we’ve learned to simplify everything: Our product, our business model and our relationships with customers. In previous businesses, we’ve created a customized solution for every customer. That is an excellent service model, but it makes it difficult to keep each and every customer satisfied over time. Our straightforward and consistent business model means our customers kno

*[... truncated, 2,880 more characters]*

---

### Let’s talk Content & Courses with Don Spear, CEO, OpenSesame, Andrew Barnes,CEO, GO1, Laura Baldwin, President, O’Reilly Media
*3,625 words* | Source: **EXA** | [Link](https://elearninfo247.com/2022/08/24/lets-talk-content-courses-with-don-spear-ceo-opensesame-andrew-barnesceo-go1-laura-baldwin-president-oreilly-media/)

Perspectives. When it comes to 3rd party content/courses from publishers and/or providers, most folks just focus on the courses/content they want for their learners, regardless if they are association members, customers, clients, partners, employees or students.

Yet the folks who are overseeing these entities are rarely asked their take on the industry, the approach and other aspects around the industry of content/courses and its application in L&D, Training, HR or other areas.

I reached out to three key players in the 3rd party content/courses space to take a deeper dive.

*   Don Spear, CEO of OpenSesame, an aggregator of a couple hundred content/courses, from publishers, for the learning system space – You can purchase their courses/content either thru a learning system marketplace (via your learning system) or contact them directly, and then add it to your learning system (if the system does not have a partnership in place). One of the top two aggregators in the industry. Plays huge in the corporate market (inc. associations). 
*   Andrew Barnes, CEO and Co-Founder of GO1, n aggregator of a couple hundred content/courses, from publishers, for the learning system space. You can purchase their courses/content either thru a learning system marketplace (via your learning system) or contact them directly, and then add it to your learning system (if the system does not have a partnership in place). You can also go direct to GO1 and use them as your learning platform with the publishers content on the system already (you can access the admin side too). You still pay for the courses/content though. The other top aggregator in the learning system space. Plays huge in the corporate market (inc. associations). 
*   Laura Baldwin, President, O’Reilly Media – 3rd party course/content publisher. You can purchase their online courses/content and add it to your learning system OR use their platform with the courses/content on it. They, for whatever reason, are not a player in the learning system marketplace, nor space itself, even though they have a strong brand name recognition with F100 companies – especially around leadership development – they are also known in the “EdTech” – higher education segment and K-12. 

**Note:** There are vendors, including publishers/providers who use the term “EdTech” to refer to corporate, associations, education and government, which only adds to the confusion. The term really means education (hence educational technology) – K-12 and HigherEd. In the case of O’Reilly Media, the use of the term in this interview, refers to every market (inc. corporate), and not just education.

Responses have been slightly edited for clarity (when applicable).

My questions are in “**bold”**, their responses are in “_italics_” with their first name, prior to the response, thus – Don, Andrew, Laura.

One additional note, for those vendors who have a marketplace (the client – i.e. whoever is overseeing the program – are the ones who purchase the content/courses and then provide said content/courses to their learners for free). There are way too many vendors who only have either GO1 or OpenSesame, which to me is a major error on their part. Add both, and thus reduce the need for folks who are clients of either, to reach out their preferred and have you the vendor, take the time to setup the API etc. It’s a pain for the client, and a pain to the learning system vendor.

The most common method nowadays in the content/course publisher/provider is the all you can eat buffet, where you purchase the seat(s) and then each learner gets unlimited access to all the courses/content, rather than say a bundle or per item.

Let’s Talk Content!

**Q: There is a lot of off-the-shelf content/courses available. What should a buyer (client) look for when choosing a vendor? Should they just focus on the topic (they are interested in) or should they consider other factors as well?**

**Don:**_When choosing a vendor, buyers should take a wide range of factors into account. For example, there are a variety of course formats that should be considered. We like to say that “one size does not fit all” because different learners and departments require different approaches._

_Buyers should also ask about quality standards._ _The range of topics is, of course, important_

_Companies should also ask about languages and localization._

**Andrew:**_You can look at off-the-shelf content two ways. One is for specific content for a given department or team. An example of this is Pluralsight who has some fantastic content which serves a specific purpose for a specific group. These vendors are typically higher in cost, but you might only need to purchase them for a subset of employees._

_The other way is to look for a vendor who is going to cover the topics needed for the majority of your learning program needs – everything from compliance (say from Skillsoft) to leadership (for example from Harvard Manage Mentor). These providers usuall

*[... truncated, 17,730 more characters]*

---

### Friday Feature: Open Source CEO
*1,632 words* | Source: **EXA** | [Link](https://sparkloop.app/blog/friday-feature-open-source-ceo)

How Bill Kerr scaled his newsletter to 28K subscribers while running a company.
-------------------------------------------------------------------------------

Meet Bill Kerr.

Bill launched the [**Open Source CEO**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cub3BlbnNvdXJjZWNlby5jb20vP3V0bV9zb3VyY2U9U3BhcmtMb29wX05ld3NsZXR0ZXI=) newsletter in March 2023.

Fast-forward to December 2023: Open Source CEO is driving impactful sponsorship revenue—AND has grown to nearly 28k subscribers.

Impressive.

![Image 1](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65baccbc5f1f3a26a38dae1c_not-bad-ryan-reynolds.gif)

**_But what's even more impressive?_**

Open Source CEO is not Bill’s full-time “job”.

He writes a newsletter for CEOs _because_ he’s a CEO: Bill cofounded [**Athyna**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cuYXRoeW5hLmNvbS8_dXRtX3NvdXJjZT1TcGFya0xvb3BfTmV3c2xldHRlcg==) in 2018 and has been the CEO since 2019.

And he uses **Open Source CEO** as a separate—but mutually beneficial —media entity where he shares leadership content and deep dives on successful founders.

But how does he balance running his business and growing the newsletter?

In this week’s Friday Feature, you’ll learn how Bill...

1.   _Uses pattern interrupts in his content and brand_
2.   _Grows his newsletter in a quick, scalable way_
3.   _Manages building two complementary companies_

Let’s dive in!

#1 - **Using pattern interrupts in content and brand**
------------------------------------------------------

I’m sure it’s happened to you:

You’re mindlessly scrolling through your feed when suddenly...

_You see a unique post._

Your thumb freezes.

You stop scrolling.

The post actually…. got your attention.

Maybe it’s an image of a cow cycling. Or an unusual video. Or clever ad copy [**like this**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly94LmNvbS93d2ZfdWsvc3RhdHVzLzE2ODg4MzAxNzcwMzAxMjc2MTY_cz0yMA==):

![Image 2](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65bacd256ba4b3f0f1bf0d5f_wwf%20twitter%20blur.png)

This is a**pattern interrupt**.

And ever since Bill heard how successful pattern interrupts worked for brands like the [**Dollar Bear Club**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cuZm9yYmVzLmNvbS9zaXRlcy9qdWxlc3NjaHJvZWRlci8yMDE2LzExLzA4L2hvdy10aGlzLWZvdW5kZXItdG9vay1oaXMtdmlkZW9zLXZpcmFsLWFuZC1tYWRlLThtLWluLXNhbGVzLz9zaD01OWEyNTQ3MTMxYjE=), he uses them everywhere.

‍

🧐 Why it’s awesome
-------------------

→ **Capture attention:**Short-form videos have messed up our attention spans _(I’m looking at you, TikTok)_. If your content doesn’t capture people’s attention within 2–3 seconds, it’s as good as dead. Pattern interrupts help you to battle this.

→ **Avoiding content fatigue:**The internet is littered with the same boring, bland content format. So “interrupting” readers by doing something unexpected will help increase engagement keeping them invested in your content.

For example, read through this [**newsletter**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cuc21hcnRub25zZW5zZS5jb20vcG9zdC9kbmE=) 👇

![Image 3](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65bacd4c882ecb3bb0ebf25b_smart%20nonsense%20gif.gif)

It uses eye-catching visuals and infographics to get you to read to the end.

→ **Brand recall:**Which newsletter will you remember, the one you read above or a different one?

🙋 How Open Source CEO does it
------------------------------

Right from the start, Bill wanted to create a playful brand.

_“We have a very loud brand, a very in-your-face brand, but it's also a pattern interrupt. It's supposed to look dumb. It's supposed to look silly, but it's also kind of cool.” — Bill Kerr_

When you visit the OS CEO [**homepage**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cub3BlbnNvdXJjZWNlby5jb20v), the thumbnails immediately draw you in and persuade you to read.

![Image 4](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65bacf81638318bff993b828_Bill%20Kerr%20quote.png)

When you visit the OS CEO [**homepage**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cub3BlbnNvdXJjZWNlby5jb20v), the thumbnails immediately draw you in and persuade you to read.

![Image 5](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65bacfaf06485aa78cefa587_os%20ceo%20homepage%20blur.png)

Even Bill's [**posts**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cub3BlbnNvdXJjZWNlby5jb20vcC9hbWF6b24tYXVkaXQ=) are filled with pattern interrupts: GIFs, videos, images, memes, and more.

You can even see the pattern interrupts on Athyna’s [**landing page**](https://preview.convertkit-mail2.com/click/dpheh0hzhm/aHR0cHM6Ly93d3cuYXRoeW5hLmNvbS8=).

![Image 6](https://cdn.prod.website-files.com/6278ffab9cf6e9a20662ea91/65bacfc42532eff8b767e2fb_athyna%20blur.png)

Did you expect a tiger & hum

*[... truncated, 9,990 more characters]*

---

### Speedrun - Company Profile
*168 words* | Source: **EXA** | [Link](https://speedrun.a16z.com/companies/opensesame)

![Image 1: company cover image](https://speedrun.a16z.com/_next/image?url=https%3A%2F%2Fspeedrun-prod-media.s3.amazonaws.com%2Fcompanies%2F3bc1e839-c9a4-43fb-b362-2feb0398f62c%2Fcover-images%2FOpenSesame_Brand_Final_10.png&w=3840&q=100)

![Image 2: company logo](https://speedrun.a16z.com/_next/image?url=https%3A%2F%2Fspeedrun-prod-media.s3.amazonaws.com%2Fcompanies%2F3bc1e839-c9a4-43fb-b362-2feb0398f62c%2Flogos%2FOpenSesame_Icon_Black.png&w=3840&q=100)

COHORT

005

OpenSesame

![Image 3: jai-mansukhani profile picture](https://speedrun.a16z.com/_next/image?url=https%3A%2F%2Fspeedrun-prod-media.s3.amazonaws.com%2Ffounders%2Fbcd603e4-7339-4247-9519-b758da570f8f%2Fimages%2FJai_Mansukhani_Profile.jpeg&w=64&q=75)

![Image 4: anthony-azrak profile picture](https://speedrun.a16z.com/_next/image?url=https%3A%2F%2Fspeedrun-prod-media.s3.amazonaws.com%2Ffounders%2F58f58382-2ca9-4f6f-b026-40848a9e7be1%2Fimages%2F1752445759216.jpeg&w=64&q=75)

Founded 2024

3 Employees

Located in Toronto, Canada

[opensesame.dev](https://opensesame.dev/)

AI AI Models/Infrastructure B2B

Turning Legacy Software AI-Native in Days, Not Quarters.

OpenSesame is building the fastest path for software companies to become entirely AI-native, turning any product’s existing APIs into a dedicated customer-facing AI agent. For decades, software interfaces have remained essentially unchanged; they are one-size-fits-all, failing to address the unique needs of each user. Today, legacy, more established software companies are facing pressure from their boards, investors, customers, and the media to incorporate AI into their products. However, long implementation timelines, rising AI talent costs, and outdated infrastructure are hindering their ability to reinvent themselves for the AI age. OpenSesame solves this by providing companies with an AI-native interface that they can embed within their existing software products, enabling their end customers to perform all their work using natural language across the entire product offering.

---

### Anthony Azrak and Jai Mansukhani from OpenSesame - The Hard Part with Evan McCann
*1,361 words* | Source: **GOOGLE** | [Link](https://open.spotify.com/episode/23AusEjZQl5FMqEtjRZumE)

Episode Description
-------------------

[See all episodes](https://open.spotify.com/show/0ZLCia43cBVsrzmAeoCn2w)

Anton Osika is the co-founder and CEO of Lovable, which is building what they call “the last piece of software”—an AI-powered tool that turns descriptions into working products without requiring any coding knowledge. Since launching three months ago, Lovable hit $4 million ARR in the first four weeks and $10 million ARR in two months with a team of just 15 people, making it Europe’s fastest-growing startup ever.What you’ll learn:Why you need to be in the top 1% of AI tool usersWatch Lovable build a functional Airbnb clone in 30 seconds—complete with working features and modern designThe unconventional hiring approach that helped build a 15-person team capable of extraordinary executionHow traditional product development will look with AIWhat skills will matter most to product teams going forwardHow Anton’s team discovered a breakthrough in AI “unsticking itself”—Brought to you by:• ⁠Sinch⁠—Build messaging, email, and calling into your product• ⁠Persona⁠—A global leader in digital identity verification• ⁠Fundrise Flagship Fund⁠—Invest in $1.1 billion of real estate—Find the transcript at: https://www.lennysnewsletter.com/p/building-lovable-anton-osika—Where to find Anton Osika:• X: https://x.com/antonosika• LinkedIn: https://www.linkedin.com/in/antonosika/—Where to find Lenny:• Newsletter: https://www.lennysnewsletter.com• X: https://twitter.com/lennysan• LinkedIn: https://www.linkedin.com/in/lennyrachitsky/—In this episode, we cover:(00:00) Introduction to Anton and Lovable(05:12) Lovable’s rapid growth(09:39) Live demo: Building an Airbnb clone(18:34) Tips for mastering Lovable(21:42) The origin story(26:50) Scaling laws and getting AI unstuck(33:20) Reliability and unique features(36:25) The vision and future of Lovable(38:14) Skills and job market evolution in the age of AI(40:30) Hiring philosophy and team dynamics(46:21) Building in Europe(48:02) Prioritization and product roadmap(51:38) Tools and work environment(53:17) Tactics for moving fast(54:37) Advice for building product teams(57:11) Empowering non-technical founders(58:31) Future developments and user support(01:01:23) Failure corner(01:05:20) Final thoughts and advice—Referenced:• Lovable: https://lovable.dev/• Lovable Launched: https://launched.lovable.app/• Cloudflare: https://www.cloudflare.com/• Supabase: https://supabase.com/• GPT engineer: https://github.com/gpt-engineer-org/gptengineer.app• Microsoft Copilot: https://copilot.microsoft.com/chats/cmFw8dTsGU8D6b9siqQ6U• Fabian Hedin on LinkedIn: https://www.linkedin.com/in/fabian-hedin-2377b0144/• Behind the product: Replit | Amjad Masad (co-founder and CEO): https://www.lennysnewsletter.com/p/behind-the-product-replit-amjad-masad• Replit: https://replit.com/• Cursor: https://www.cursor.com• Bolt: https://bolt.new/• GitHub: https://github.com/• Lane Shackleton on LinkedIn: https://www.linkedin.com/in/laneshackleton/• FigJam: https://www.figma.com/figjam/• Linear: https://linear.app/• Sana Labs: https://sanalabs.com/• Duolingo: https://www.duolingo.com/• Claude: https://claude.ai/• ChatGPT: https://chatgpt.com/• Lovable on X: https://x.com/Lovable_dev—Production and marketing by https://penname.co/. For inquiries about sponsoring the podcast, email podcast@lennyrachitsky.com.—Lenny may be an investor in the companies discussed.

E

Mar 9

1 hr 9 min

In this episode, Joe Kim, the new CEO of DRUID AI, unpacks what might be the biggest shift in technology since the internet.We discuss the evolving landscape of artificial intelligence and its growing impact on businesses. Joe, who has been in his role for 70 days, brings fresh perspectives on how DRUID AI positioned itself as a workflow automation platform years before the market caught up, a bet that's now paying off as companies move beyond AI experimentation into real implementation.The discussion covers the current state of the AI market, including the challenges of customer adoption, why some customers actively prefer interacting with AI over humans, and the importance of maintaining a balance between generative and agentic AI.Joe also shares his vision of AI as the next major distribution platform. Just as Amazon has tried to make Alexa the operating system of our lives, OpenAI’s ChatGPT and similar platforms could become the primary gateway to accessing services in the future.Chapters00:00 - Meet Joe Kim00:33 - Celebrating 70 days at DRUID AI01:35 - What attracted Joe to DRUID03:06 - The real value of AI06:43 - What Joe learnt about the market11:19 - The AI God Box for enterprises14:08 - The state of the AI market20:29 - Why you should learn about AI as much as you can23:47 - Generative AI adoption among enterprises27:36 - The concept of agent washing36:05 - Is AI bigger than the internet?39:11 - ChatGPT as the new distribution platform48:52 - Will chatbots replace websites and apps?50:31 - The next 6–12 months for DRUID A

*[... truncated, 4,999 more characters]*

---

### a16z says OpenSesame to Canadian agentic AI startup for its speedrun accelerator | BetaKit
*1,481 words* | Source: **GOOGLE** | [Link](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/)

a16z says OpenSesame to Canadian agentic AI startup for its speedrun accelerator | BetaKit

===============

Read [BetaKit Most Ambitious](https://bit.ly/4k6pCHn): Telling the story of what’s possible.

✕

[![Image 2: BetaKit - Canadian Startup News & Tech Innovation](https://betakit.com/wp-content/uploads/2024/01/BetaKit_Logo_White_250px.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [About](https://betakit.com/about-us/)
*   [Advertise](https://betakit.com/advertise/)
*   [Members](https://betakit.com/innovation-leaders/)
*   [Contact](https://betakit.com/about-us/#contact)

*   [](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/#)
    *   [](https://www.linkedin.com/company/BetaKit)
    *   [](https://twitter.com/BetaKit)
    *   [](https://www.youtube.com/user/Betakit)
    *   [](https://www.facebook.com/BetaKit)

[![Image 3: BetaKit - Canadian Tech & Startup News](https://betakitdev.trypl.com/wp-content/uploads/2025/04/betakit-logo-OG.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [News](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/#)

    *   [Latest News](https://betakit.com/#Latest)
    *   [By Topics](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/#)

        *   [Funding](https://betakit.com/tag/funding)
        *   [Acquisitions](https://betakit.com/tag/acquisitions)
        *   [Layoffs](https://betakit.com/tag/layoffs/)
        *   [VC](https://betakit.com/tag/vc/)
        *   [Events](https://betakit.com/tag/events)
        *   [Markets](https://betakit.com/tag/markets/)
        *   [Reports](https://betakit.com/tag/reports)
        *   [Impact](https://betakit.com/tag/impact)

    *   [By Verticals](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/#)

        *   [AI](https://betakit.com/tag/ai)
        *   [FinTech](https://betakit.com/tag/fintech)
        *   [SaaS](https://betakit.com/tag/saas)
        *   [Retail](https://betakit.com/tag/retail)
        *   [Healthtech](https://betakit.com/tag/healthtech)
        *   [Cleantech](https://betakit.com/tag/cleantech)
        *   [Deep Tech](https://betakit.com/tag/deep-tech/)
        *   [Defence Tech](https://betakit.com/tag/defence-tech/)

    *   [By Regions](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/#)

        *   [Toronto](https://betakit.com/tag/toronto)
        *   [Montréal](https://betakit.com/tag/montreal)
        *   [Vancouver](https://betakit.com/tag/vancouver)
        *   [Waterloo Region](https://betakit.com/tag/kitchener-waterloo)
        *   [Ottawa](https://betakit.com/tag/ottawa)
        *   [Calgary](https://betakit.com/tag/calgary)
        *   [Prairies](https://betakit.com/tag/prairies)
        *   [Atlantic Canada](https://betakit.com/tag/atlantic-canada/)

*   [Podcast](https://betakit.com/category/podcasts)
*   [Newsletter](https://betakit.com/category/newsletters)
*   [Quiz](https://betakit.com/category/quiz/)
*   [Jobs](https://betakit.com/tag/jobs/)

a16z says OpenSesame to Canadian agentic AI startup for its speedrun accelerator
================================================================================

 By [Madison McLauchlan](https://betakit.com/author/madison-mclauchlan/ "Posts by Madison McLauchlan")July 24, 2025

[Email](mailto:?subject=a16z%20says%20OpenSesame%20to%20Canadian%20agentic%20AI%20startup%20for%20its%20speedrun%20accelerator&body=https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/)[Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/&title=a16z+says+OpenSesame+to+Canadian+agentic+AI+startup+for+its+speedrun+accelerator&source=BetaKit)[Share on X](https://twitter.com/intent/tweet?original_referer=https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/&text=a16z+says+OpenSesame+to+Canadian+agentic+AI+startup+for+its+speedrun+accelerator&tw_p=tweetbutton&url=https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/&via=BetaKit)[Share on Reddit](http://www.reddit.com/submit?url=https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/&title=a16z+says+OpenSesame+to+Canadian+agentic+AI+startup+for+its+speedrun+accelerator)[Share on BlueSky](https://bsky.app/intent/compose?text=a16z+says+OpenSesame+to+Canadian+agentic+AI+startup+for+its+speedrun+accelerator%20https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/)

![Image 4: OpenSesame | BetaKit](https://cdn.betakit.com/wp-content/uploads/2025/07/Smile2-Grain-770x513.jpg)

OpenSesame co-founders Jai Ma

*[... truncated, 18,134 more characters]*

---

### Shopify president calls Montréal “the most entrepreneurial city on the planet” at North Star event | BetaKit
*1,544 words* | Source: **GOOGLE** | [Link](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/)

Shopify president calls Montréal “the most entrepreneurial city on the planet” at North Star event | BetaKit

===============

Read [BetaKit Most Ambitious](https://bit.ly/4k6pCHn): Telling the story of what’s possible.

✕

[![Image 2: BetaKit - Canadian Startup News & Tech Innovation](https://betakit.com/wp-content/uploads/2024/01/BetaKit_Logo_White_250px.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [About](https://betakit.com/about-us/)
*   [Advertise](https://betakit.com/advertise/)
*   [Members](https://betakit.com/innovation-leaders/)
*   [Contact](https://betakit.com/about-us/#contact)

*   [](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/#)
    *   [](https://www.linkedin.com/company/BetaKit)
    *   [](https://twitter.com/BetaKit)
    *   [](https://www.youtube.com/user/Betakit)
    *   [](https://www.facebook.com/BetaKit)

[![Image 3: BetaKit - Canadian Tech & Startup News](https://betakitdev.trypl.com/wp-content/uploads/2025/04/betakit-logo-OG.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [News](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/#)

    *   [Latest News](https://betakit.com/#Latest)
    *   [By Topics](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/#)

        *   [Funding](https://betakit.com/tag/funding)
        *   [Acquisitions](https://betakit.com/tag/acquisitions)
        *   [Layoffs](https://betakit.com/tag/layoffs/)
        *   [VC](https://betakit.com/tag/vc/)
        *   [Events](https://betakit.com/tag/events)
        *   [Markets](https://betakit.com/tag/markets/)
        *   [Reports](https://betakit.com/tag/reports)
        *   [Impact](https://betakit.com/tag/impact)

    *   [By Verticals](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/#)

        *   [AI](https://betakit.com/tag/ai)
        *   [FinTech](https://betakit.com/tag/fintech)
        *   [SaaS](https://betakit.com/tag/saas)
        *   [Retail](https://betakit.com/tag/retail)
        *   [Healthtech](https://betakit.com/tag/healthtech)
        *   [Cleantech](https://betakit.com/tag/cleantech)
        *   [Deep Tech](https://betakit.com/tag/deep-tech/)
        *   [Defence Tech](https://betakit.com/tag/defence-tech/)

    *   [By Regions](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/#)

        *   [Toronto](https://betakit.com/tag/toronto)
        *   [Montréal](https://betakit.com/tag/montreal)
        *   [Vancouver](https://betakit.com/tag/vancouver)
        *   [Waterloo Region](https://betakit.com/tag/kitchener-waterloo)
        *   [Ottawa](https://betakit.com/tag/ottawa)
        *   [Calgary](https://betakit.com/tag/calgary)
        *   [Prairies](https://betakit.com/tag/prairies)
        *   [Atlantic Canada](https://betakit.com/tag/atlantic-canada/)

*   [Podcast](https://betakit.com/category/podcasts)
*   [Newsletter](https://betakit.com/category/newsletters)
*   [Quiz](https://betakit.com/category/quiz/)
*   [Jobs](https://betakit.com/tag/jobs/)

Shopify president calls Montréal “the most entrepreneurial city on the planet” at North Star event
==================================================================================================

 By [Madison McLauchlan](https://betakit.com/author/madison-mclauchlan/ "Posts by Madison McLauchlan")January 24, 2025

[Email](mailto:?subject=Shopify%20president%20calls%20Montr%C3%A9al%20%E2%80%9Cthe%20most%20entrepreneurial%20city%20on%20the%20planet%E2%80%9D%20at%20North%20Star%20event&body=https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/)[Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/&title=Shopify+president+calls+Montr%C3%A9al+%E2%80%9Cthe+most+entrepreneurial+city+on+the+planet%E2%80%9D+at+North+Star+event&source=BetaKit)[Share on X](https://twitter.com/intent/tweet?original_referer=https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/&text=Shopify+president+calls+Montr%C3%A9al+%E2%80%9Cthe+most+entrepreneurial+city+on+the+planet%E2%80%9D+at+North+Star+event&tw_p=tweetbutton&url=https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/&via=BetaKit)[Share on Reddit](http://www.reddit.com/submit?url=https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/&title=Shopify+president+calls+Montr%C3%A9al+%E2%80%9Cthe+most+entrepreneurial+city+on+the+planet%E2%80%9D+at+North+Star+event)[Sha

*[... truncated, 19,076 more characters]*

---

### Next Canada - Ventures
*19,452 words* | Source: **GOOGLE** | [Link](https://www.nextcanada.com/directory/ventures/)

Tenomix Inc.
------------

Tenomix is medical-technology startup that is revolutionizing the way cancer tissues are processed in pathology laboratories using robotics, ultrasound imaging and AI. With our current patent-pending platform technology, we are currently automating a tedious, unreliable, and expensive process in the colon cancer staging pathway: the manual lymph node search process.

Local Energy Solutions
----------------------

Local Energy Solutions se consacre à l'efficacité énergétique en exploitant l'énergie résiduelle des processus industriels. Notre Laboratoire Virtuel aide les fournisseurs d'infrastructures dans la planification et le développement de projets d'infrastructures énergétiques. Complétant le Laboratoire Virtuel, notre plateforme marketplace permet des transactions énergétiques en temps réel entre les usines industrielles voisines. La plateforme permet non seulement le commerce de pair à pair, mais transforme également les infrastructures industrielles en marchés énergétiques locaux (LEMs), réduisant ainsi la consommation d'énergie totale consommée.

Cranberry Payments
------------------

Cranberry Payments effortlessly protects a merchant's payments with three lean solutions across a single unified platform. Cranberry Payments uses artificial intelligence to detect fraud at the point of sale, automates chargeback disputes, and quantifies a cardholder's risk for a potential chargeback claim.

Analyst3
--------

Deal sourcing and diligence platform for strategic acquirers that helps close transactions in weeks, instead of months.

reFern
------

reFern is the only AI-powered SaaS tool tailored for interior emissions, intended for use by designers and sustainability professionals. It enables tracking of circularity, exploration of sustainable materials, and reaching decarbonization objectives for building interiors. reFern supports the global aim of achieving net-zero emissions by 2050, crucial as buildings currently account for 40% of worldwide emissions.

Cove
----

Cove uses data to add value to rental relationships for both sides of the lease. Helping owners protect their assets and renters make their largest monthly payment mean more.

LUCA Theory
-----------

LUCA Theory is a revolutionary Crowd AI that is poised to transform capital decision-making. Designed to power decentralized operations while creating prediction market alpha

Elev8 and Perform
-----------------

Founded by an athlete, scientist (Team Canada, UofT) and a human rights award recipient, Elev8 is a technology designed to reduce fatigue and improve human health performance. The hardware consists of a small, lightweight breathing device used during training that releases a special supplement to enhance oxygen intake in the lungs and heart, significantly improving their natural capacity. This enables users to achieve faster progress, turning an hour of work into 30 minutes. Our software app tracks real-time biological metrics and provides personalized medical recommendations using advanced algorithms to optimize performance. Our mission is to enhance physical activity and health through innovative technology.

ZebraKet.Ltd (Acquired by Alinged IT LLC.)
------------------------------------------

We aim to help companies to have a more resilient and sustainable supply chain by using AI and quantum technologies.

Mutuo Health Solutions
----------------------

- Problem: Doctor burnout and major clinical inefficiencies due to onerous administrative tasks such as medical charting (note taking). - Solution: Our product AutoScribe uses AI to analyze patient-doctor conversations in real-time to automatically generate high-quality medical notes, saving up to 20% of a doctor's current work-time. - Differentiators: Our tool outperforms the competition at a lower cost.We prioritize transparency regarding scientific credibility and appropriate use of medical data which builds trusting and sticky relationships with our clients.

Nova Food
---------

Nova Food is a grocery companion app that aims to help users save money, eat healthier, and reduce their environmental impact. The app provides a curated dashboard that shows personalized recommendations for food items based on the user's dietary preferences and budget. Nova Food also offers discounts and cashback offers on select grocery items to help users save money while making healthier and sustainable choices.

vopemed
-------

Vope Medical has developed an AI-driven software to address a significant unmet need for clear vision in minimally invasive surgery. The lack of automation in current cleaning processes brings frustration, increased errors, and poorer patient outcomes. We optimize the cleaning process by reducing the number of cleaning events through image enhancement and minimize disruptions by fully automating the cleaning process, allowing the surgeon to stay completely focused on the procedures they are performing.

EduBeyond
---------

EduBeyond is improving

*[... truncated, 132,579 more characters]*

---

### Is Canada’s productivity saviour a hallucination? | BetaKit
*1,474 words* | Source: **GOOGLE** | [Link](https://betakit.com/is-canadas-productivity-saviour-a-hallucination/)

Plus: OMERS Ventures refocuses on Canada under new leadership.

In February last year, the national conversation focused on the potential for artificial intelligence to be [Canada’s productivity saviour](https://betakit.com/is-ai-canadas-productivity-saviour/?utm_source=B%7CK%3A%20The%20BetaKit%20Newsletter&utm_medium=email&utm_campaign=B%7CK%3A%20The%20BetaKit%20Newsletter%2007.27.25%20%2801ManualNorthernIrelandWeek%29). But a recent report might slow the AI hype train (for some).

New [StatCan data](https://www150.statcan.gc.ca/n1/daily-quotidien/250604/dq250604a-eng.htm?utm_source=B%7CK%3A%20The%20BetaKit%20Newsletter&utm_medium=email&utm_campaign=B%7CK%3A%20The%20BetaKit%20Newsletter%2007.27.25%20%2801ManualNorthernIrelandWeek%29) shows Canada’s labour productivity increased just 0.2 percent last quarter. The majority of gains came from goods-producing businesses, while the services industry—a broad tent that includes technology companies—_dropped_ 0.5 percent.

AI adoption has [doubled in Canadian businesses](https://betakit.com/statscan-finds-ai-adoption-has-doubled-in-businesses-but-hasnt-yet-affected-headcounts/?utm_source=B%7CK%3A%20The%20BetaKit%20Newsletter&utm_medium=email&utm_campaign=B%7CK%3A%20The%20BetaKit%20Newsletter%2007.27.25%20%2801ManualNorthernIrelandWeek%29) over the past year, with companies like Shopify and OpenText recently going “AI-first.” But the productivity benefits have yet to appear in the data. So when will they?

Sign up now for the latest updates on Canadian startup and tech news, delivered straight to your inbox.

I spoke with Float CEO Rob Khazzam about his company’s new internal “AI Manifesto,” which dictates how it builds products and hires staff with AI in mind. Float hopes to fully automate more transactions on its platform, from 30 to 80 percent, by year’s end. Doing so could save customers upwards of 10,000 hours per month.

Khazzam believes the benefits of these AI-driven optimizations will trickle down and boost productivity for Float’s SMB customers, which he called “the lifeblood of the Canadian economy.” Less time chasing tax receipts means more time for them to drive innovation in their own businesses, continuing the cycle.

“There is absolutely no question in my mind: Canadian companies can leverage this to grow economic prosperity, or we get left behind,” Khazzam said. “That’s the two options ahead, and we know where we’re going to be.”

And the productivity numbers? Khazzam doesn’t put much stock into the data yet. “It takes time, even for early adopters, to determine how and where to start.”

As far as he’s concerned, if Canadian companies continue to innovate on how they deploy talent and automate workflows, productivity will follow. But that’s what we were told last year, too.

Alex Riehl

Staff Writer

Ottawa

* * *

[![Image 1](https://cdn.betakit.com/wp-content/uploads/2025/07/A32602-INI-L2-BETA-KIT-SPONSORED-CONTENT_600x300_ST2-3.png)](https://www.investni.com/expand-your-business-to-northern-ireland?utm_campaign=canadafdi&utm_source=betakit&utm_medium=email&utm_content=%20email_banner)

[**Northern Ireland is attracting a growing list of high-profile international tech companies.**](https://www.investni.com/expand-your-business-to-northern-ireland?utm_campaign=canadafdi&utm_source=betakit&utm_medium=email&utm_content=email_banner)

Firms such as Fujitsu, SAP, Microsoft, Qualcomm, Nvidia, Rapid7, and Whitehat Security are already operating in Northern Ireland. It’s also home to 35 Canadian businesses, as well as being Europe’s leading location for new software development projects.

So what makes Northern Ireland special? We give companies access to a highly skilled and educated talent pool, excellent infrastructure, cost-effectiveness, a supportive business environment, and much more. All these factors helped us build a glowing international reputation for tech expertise and develop one of the fastest-growing tech sectors in the UK.

If you are interested in expanding your business to Northern Ireland, we can offer tailored overseas expansion guidance, financial incentives, and soft-landing support.

Keen to explore this opportunity? [Request more information from our Canadian team.](https://www.investni.com/expand-your-business-to-northern-ireland?utm_campaign=canadafdi&utm_source=betakit&utm_medium=email&utm_content=email_banner)

* * *

![Image 2](https://cdn.betakit.com/wp-content/uploads/2025/07/michael_yang_2x1.jpg)

#### [Michael Yang departs OMERS Ventures as pension fund refocuses on Canada in “strategic shift”](http://betakit.com/michael-yang-to-depart-omers-ventures-as-pension-fund-refocuses-on-canada-in-strategic-shift/?utm_source=B%7CK%3A%20The%20BetaKit%20Newsletter&utm_medium=email&utm_campaign=B%7CK%3A%20The%20BetaKit%20Newsletter%2007.27.25%20%2801ManualNorthernIrelandWeek%29)

Michael Yang stepped down as the head of OMERS Ventures while the Canadian public pension fund undergoes a “strategic shift” to refocus its investment act

*[... truncated, 11,082 more characters]*

---

---

## 🎬 YouTube Videos

- **[Fred again.., Ezra Collective, CA7RIEL &amp; Paco Amoroso - Beto’s Horns, Ezra Remix (London, 25th June)](https://www.youtube.com/watch?v=BOtCBy_FSZE)**
  - Channel: Fred again . .
  - Date: 2025-11-10

- **[Verscents Battle: Top 10 best date night Scents ever ft: Bowtie FragranceGuy: The Cipher episode 4](https://www.youtube.com/watch?v=dBtvc1orefM)**
  - Channel: Equality Fragrances
  - Date: 2023-02-18

- **[North Star | Founder Panel](https://www.youtube.com/watch?v=J_fU0tNoJ7U)**
  - Channel: TechPoutine
  - Date: 2025-02-14

- **[Tony Ma (2012) vs. Premal Patel (2014) - 2019 Chicago Edgeball [Short Form]](https://www.youtube.com/watch?v=Urv8gxPuCzY)**
  - Channel: Tony Ma
  - Date: 2019-10-29

- **[Our Top 10 Fragrances](https://www.youtube.com/watch?v=d4joqEAxxDs)**
  - Channel: Frag Lluminati
  - Date: 2023-02-12

- **[AI Hallucinations: Detecting and Managing Errors in Large Language Models](https://www.youtube.com/watch?v=voml1EMTG70)**
  - Channel: Pitch Please
  - Date: 2024-09-09

- **[Azrak Haddad Great Party!](https://www.youtube.com/watch?v=7QJdpTiBhaA)**
  - Channel: Epk22
  - Date: 2012-02-19

- **[Franky - LORO (OFFICIAL VIDEO)](https://www.youtube.com/watch?v=Z0VJNrJj670)**
  - Channel: Dj Franky
  - Date: 2018-03-20

- **[Camilla Cabello ft, Ed sheeran- Bam Bam- مترجمة](https://www.youtube.com/watch?v=Ng7yZ40jrzg)**
  - Channel: Safae
  - Date: 2022-03-10

- **[THE DOOR IS UNLOCKED - SONIC](https://www.youtube.com/watch?v=uwshW8nZGiI)**
  - Channel: Rooster Time
  - Date: 2024-12-20

---

## 🔎 Press & Mentions

- **[Anthony Azrak and Jai Mansukhani from OpenSesame - The Hard ...](https://open.spotify.com/episode/23AusEjZQl5FMqEtjRZumE)**
  - Source: open.spotify.com
  - *Sep 5, 2025 ... Listen to this episode from The Hard Part with Evan McCann on Spotify. Anthony Azrak and Jai Mansukhani are the Co-Founders of OpenSes...*

- **[a16z says OpenSesame to Canadian agentic AI startup for its ...](https://betakit.com/a16z-says-opensesame-to-canadian-agentic-ai-startup-for-its-speedrun-accelerator/)**
  - Source: betakit.com
  - *Jul 24, 2025 ... Toronto-based OpenSesame is the only Canadian company accepted ... Anthony Azrak and Jai Mansukhani know how to capitalize on coincid...*

- **[Shopify president calls Montréal “the most entrepreneurial city on ...](https://betakit.com/shopify-president-calls-montreal-the-most-entrepreneurial-city-on-the-planet-at-north-star-event/)**
  - Source: betakit.com
  - *Jan 24, 2025 ... Anthony Azrak, co-founder of artificial intelligence (AI) software-as-a-service (SaaS) platform OpenSesame ... Podcast last September...*

- **[Ventures - Next Canada](https://www.nextcanada.com/directory/ventures/)**
  - Source: nextcanada.com
  - *https://www.opensesame.dev/. Business Model: SaaS. Cohort: Next 36, 2024. Founders: Jai Mansukhani Anthony Azrak. Draft&Goal. Draft&Goal offers a turn...*

- **[Is Canada's productivity saviour a hallucination? | BetaKit](https://betakit.com/is-canadas-productivity-saviour-a-hallucination/)**
  - Source: betakit.com
  - *Jul 28, 2025 ... Anthony Azrak and Jai Mansukhani know how to capitalize on coincidences. When the co-founders of Toronto-based AI startup OpenSesame ...*

- **[How to Make a Viral Launch Video - a16z speedrun](https://speedrun.substack.com/p/how-to-make-a-viral-launch-video)**
  - Source: speedrun.substack.com
  - *Aug 19, 2025 ... Case Study #6 - Opening Doors With OpenSesame ... As one of the newest companies on this list, cofounders Jai Mansukhani and Anthony ...*

- **[OpenSesame AI - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/opensesame-ai)**
  - Source: crunchbase.com
  - *Legal Name OpenSesame AI Inc. ; Also Known As OpenSesame, OpenSesame AI ; Operating Status Active ; Company Type For Profit ; Founders Anthony Azrak, ...*

- **[a16z speedrun: toronto founders · Luma](https://luma.com/2mxkiq4t)**
  - Source: luma.com
  - *​As a reminder, OpenSesame is a Toronto-founded startup backed by a16z speedrun, giving product teams the ... anthony azrak · Troy Kirwin · Robin Guo ...*

- **[OpenSesame: The Canadian AI Startup Selected for a16z Speedrun ...](https://www.startupecosystem.ca/news/opensesame-the-canadian-ai-startup-selected-for-a16z-speedrun-accelerator/)**
  - Source: startupecosystem.ca
  - *Founded by Anthony Azrak and Jai Mansukhani, OpenSesame was the only ... Read Full Article →. Stay in the know. Explore valuable insights and practica...*

---

*Generated by Founder Scraper*
