# Simon Roberts

## Position actuelle

**Titre** : Co-Founder & CTO
**Entreprise** : VOID
**Durée dans le rôle** : 2 years 9 months in role
**Durée dans l'entreprise** : 2 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Working on VOID: the framework for building sovereign multi-chain apps.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABX_99wB7ilPixyCE1JhwxbcesNGNT2hR9Q/


---

# Simon Roberts

## Position actuelle

**Entreprise** : VOID

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Simon Roberts

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394777622557392896 | Article |  |  | https://lnkd.in/edFWYQ9P | 0 | 0 | 0 | 3w | Post | Simon Roberts | https://www.linkedin.com/in/simonroberts0204 | https://linkedin.com/in/simonroberts0204 | 2025-12-08T07:07:18.581Z |  | 2025-11-13T16:46:13.542Z | https://x.com/simonr0204/status/1989009583625371700 |  | 

---



---

# Simon Roberts
*VOID*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Embodiment & AI: Interview with Simon Roberts](https://response-ability.tech/embodiment-ai-interview-with-simon-roberts/)
*2019-07-02*
- Category: article

### [Photography, The Photographer and the User Experience](https://unitednationsofphotography.com/2021/11/01/photography-the-photographer-and-the-user-experience/)
*2021-11-01*
- Category: article

### [](https://www.lewissilkin.com/en/our-thinking/future-of-work-hub/insights/2024/09/04/in-conversation-with-simon-roberts)
- Category: article

### [Chester Visual Arts bring photography exhibition by Simon Roberts to city](https://thechesterblog.com/2023/05/16/chester-visual-arts-bring-photography-exhibition-by-simon-roberts-to-city)
*2023-05-16*
- Category: blog

### [Revolutionizing Sustainable Packaging with VOID Technologies](https://www.venaripartners.com/post/circular-economy-sustainable-packaging-insights-from-void-technologies)
*2024-09-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Andrew Roberts on The Habits of Churchill, Lessons from Napoleon ...](https://tim.blog/2024/10/17/andrew-roberts-churchill-napoleon/)**
  - Source: tim.blog
  - *Oct 17, 2024 ... Filling the Void (97); Gadgets (15); Geoarbitrage (8); Interviews ... Simon Roberts · Edward I · Elizabeth II · Warren Hastings · Nel...*

- **[The Peril of Joyce Farrell? : r/learnprogramming](https://www.reddit.com/r/learnprogramming/comments/ierzq/the_peril_of_joyce_farrell/)**
  - Source: reddit.com
  - *Jul 2, 2011 ... A family member who is a programmer recommended 'Complete Java 2 Certification Study Guide' by Phillip Heller, and Simon Roberts ... v...*

- **[Three Cheers For The Outsiders! – The United Nations of Photography](https://unitednationsofphotography.com/2022/08/07/three-cheers-for-the-outsiders/)**
  - Source: unitednationsofphotography.com
  - *Aug 7, 2022 ... It is inspiring and I think it points to an increasing void ... PODCAST: A Photographic Life, Episode 167: Plus Photographer Simon Rob...*

- **[Good PR for M&S' CEO, toys and balls, bad for BBC | PRmoment.com](https://www.prmoment.com/good-bad-pr/good-pr-for-m-s-ceo-toys-and-balls-bad-for-bbc)**
  - Source: prmoment.com
  - *Nov 13, 2025 ... The supermarket industry has had a void for charismatic comms ... Great work by the comms team to convince Simon Roberts to go with t...*

- **[Williams appoints former McLaren COO Simon Roberts - ESPN](https://www.espn.co.uk/f1/story/_/id/29160725/williams-appoints-former-mclaren-coo-simon-roberts)**
  - Source: espn.co.uk
  - *May 11, 2020 ... Williams has appointed McLaren's former chief operating officer, Simon Roberts, as its new managing director ... Void in ONT/OR/NH. E...*

- **[Documentary Storytellers | Podcast on Spotify](https://open.spotify.com/show/48fNvLu3qvg17qm6GcM9Ht)**
  - Source: open.spotify.com
  - *... Simon Roberts Bell Hooks Chris Killip Mark Neville Anastasia Traylor-Lind ... void Catfish Act of Terror (animation by Gemma) Una Marzorati Equide...*

- **[How Castaway made my life hell | Reality TV | The Guardian](https://www.theguardian.com/tv-and-radio/2010/aug/11/castaway)**
  - Source: theguardian.com
  - *Aug 11, 2010 ... ... Simon Roberts/BBC ONE. Reality TV. This article is more than 15 years old ... void of intrusive camera crews. This will be the fi...*

- **[Need help with preparing for Java certification exam : r/javahelp](https://www.reddit.com/r/javahelp/comments/wvlt45/need_help_with_preparing_for_java_certification/)**
  - Source: reddit.com
  - *Aug 23, 2022 ... public class HelloWorld { public static void main(String[] args) ... I see that Simon Roberts has a bunch of test questions available...*

- **[Rules and Processes. The cultural logic of dispute in an African ...](https://voidnetwork.gr/wp-content/uploads/2016/08/Rules-and-Processes.-The-cultural-logic-of-dispute-in-an-African-context-by-John-Comaroff-and-Simon-Roberts.pdf)**
  - Source: voidnetwork.gr
  - *pendium drawn from informant interviews, the examination of vernacular texts, and the analysis of case histories--and does not discuss dispute process...*

- **[Quiz yourself: Handling side effects in Java | javamagazine](https://blogs.oracle.com/javamagazine/java-quiz-stream-api-side-effects/)**
  - Source: blogs.oracle.com
  - *Jan 23, 2023 ... Profile picture of Simon Roberts Simon Roberts. This question ... public static void testMyRunnable(Stream<Runnable> s) { s.map( i .....*

---

*Generated by Founder Scraper*
