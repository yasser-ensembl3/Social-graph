# Narjes Boufaden

## Position actuelle

**Titre** : Founder and CEO
**Entreprise** : Keatext
**Durée dans le rôle** : 15 years 3 months in role
**Durée dans l'entreprise** : 15 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Narjès is a dedicated leader and innovator who is passionate about using artificial intelligence to solve complex business challenges. With over two decades of experience, her career has been defined by her ability to bridge the gap between the sophisticated technology of Natural Language Understanding and the business needs of customer experience management.

Her journey began as a pioneer in Text Mining for conversational data, a field where her early research and scientific publications helped establish foundational approaches. In 2010, she founded KeaText Consulting Services, where, as CEO, she built the company from the ground up, scaled its capabilities, and defined its strategic vision.

Identifying an opportunity in the customer experience management industry, she made the bold decision to focus the company's energy on creating a customer feedback analytics platform that uses Deep Learning to transform consumer reviews into actionable insights. In 2015, she made a strategic pivot by surrounding herself with a brilliant team, which allowed the company to successfully transition from a service-based model to a product-focused one.

Her deep understanding of both the market and the technology has been a major asset. This allowed her to successfully raise capital and build strong partnerships with some of the biggest names in the customer experience industry.

Expertise: Natural Language Understanding, Machine Learning, Text Analytics, Conversational Analytics

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAHbSxkBZhuey1h0idQUZeNvcn2wBVIx_Os/
**Connexions partagées** : 155


---

# Narjes Boufaden

## Position actuelle

**Entreprise** : Keatext

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Narjes Boufaden

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398739031158607872 | Celebration |  | https://media.licdn.com/media/AAYABAQSAAgAAQAAAAAAANJLzxZspMXOR2qc6yZIDOjDfQ.gif | I’m happy to share that I’ve obtained a new certification in "Responsible AI for Professionals and Leaders": Certificat du Parcours complet from KCJ! | 24 | 21 | 0 | 1w | Post | Narjes Boufaden | https://www.linkedin.com/in/narjesboufaden | https://linkedin.com/in/narjesboufaden | 2025-12-08T05:22:24.599Z |  | 2025-11-24T15:07:26.952Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7338218746181791744 | Video (LinkedIn Source) | blob:https://www.linkedin.com/81a3e90a-3af5-4333-9b27-22121029a85a |  | Excited to dive into the world of AI and LLMs transforming customer experience in an upcoming webinar, "Decoding AI in CX Analytics." Join me as we explore practical applications of AI and Large Language Models across various CX use cases. Discover how these tools revolutionize customer insights and operational efficiency. Don't miss out on this enlightening session! #AI #CX #Webinar https://lnkd.in/dqi-uRzB | 14 | 1 | 0 | 5mo | Post | Narjes Boufaden | https://www.linkedin.com/in/narjesboufaden | https://linkedin.com/in/narjesboufaden | 2025-12-08T05:22:24.601Z |  | 2025-06-10T15:01:26.601Z | https://www.linkedin.com/feed/update/urn:li:activity:7337924635763564545/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7290071854885588993 | Article |  |  |  | 2 | 0 | 0 | 10mo | Post | Narjes Boufaden | https://www.linkedin.com/in/narjesboufaden | https://linkedin.com/in/narjesboufaden | 2025-12-08T05:22:24.601Z |  | 2025-01-28T18:22:53.190Z | https://www.questionpro.com/blog/generative-ai-in-cx-boldly-going-where-no-one-has-gone-before-tuesday-cx-thoughts/ |  | 

---



---

# Narjes Boufaden
*Keatext*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 16 |

---

## 📚 Articles & Blog Posts

### [Narjès Boufaden | Founder and CEO - Keatext | Forbes Technology Council](https://councils.forbes.com/profile/Narj%C3%A8s-Boufaden-Founder-CEO-Keatext/0d945020-6be4-4033-8b83-b508599aa1c3)
*2024-03-06*
- Category: article

### [Narjes Boufaden - Keatext | LinkedIn](https://ca.linkedin.com/in/narjesboufaden)
*2025-01-01*
- Category: article

### [Narjès Boufaden, Author at QuestionPro 1](https://www.questionpro.com/blog/author/narjes-boufaden/)
*2024-08-05*
- Category: blog

### [NARJES BOUFADEN, FOUNDER AND CEO, KEATEXT – Innovations of the World](https://innovationsoftheworld.com/narjes-boufaden-founder-and-ceo-keatext/)
*2025-03-01*
- Category: article

### [PitchBook All Columns 2021 05 27 01 04 03 | PDF | Business](https://www.scribd.com/document/681297227/PitchBook-All-Columns-2021-05-27-01-04-03)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[The State of AI in Montreal - Startups, Investment, and What it Means ...](https://emerj.com/the-state-of-ai-in-montreal/)**
  - Source: emerj.com
  - *Dec 19, 2017 ... Narjes Boufaden, founder of Keatext, a software company that claims to help businesses audit customer feedback through machine learni...*

- **[Hear more on the Women advancing AI in Montreal and Canada!](https://blog.re-work.co/30-influential-women-advancing-ai-in-montreal/)**
  - Source: blog.re-work.co
  - *Oct 6, 2019 ... 30 Influential Women Advancing AI - Montreal Edition · 30. Narjes Boufaden, Founder & CEO, Keatext · 29. Rebecca (Becks) Simpson, Mach...*

- **[PitchBook All Columns 2021 05 27 01 04 03 | PDF | Business](https://www.scribd.com/document/681297227/PitchBook-All-Columns-2021-05-27-01-04-03)**
  - Source: scribd.com
  - *AudioTech digital media company, podcast, podcast media. Venture Capital ... Narjès Boufaden Co-Founder & Chief Executive Officer narjes.boufaden@keat...*

- **[Rebuilding Company Culture with Text Analytics | Keatext](https://www.keatext.ai/en/blog/leadership/rebuilding-company-culture/)**
  - Source: keatext.ai
  - *Feb 6, 2024 ... Rebuilding Company Culture with Text Analytics. Narjes Boufaden ... Keatext's text and sentiment analysis of customer and employee rev...*

- **[Sessions: WomenTech Global Conference | Women in Tech Network](https://www.womentech.net/en-gb/women-tech-conference/sessions?amp%3Bamp%3Bpage=4&amp%3Bamp%3Bwebform_submission_value_2=All&amp%3Bcreated=All&amp%3Bpage=35&combine=&created=All&page=48)**
  - Source: womentech.net
  - *Jul 31, 2025 ... ... Interview Prep, Leadership, Mentorship & Sponsorship, Personal Branding ... Narjes Boufaden. CEO at Keatext. Inclusion and divers...*

- **[Weekend read: The startups shaping the next wave of AI in Montreal ...](https://montrealgazette.com/news/local-news/up-and-coming-ai-companies)**
  - Source: montrealgazette.com
  - *Nov 25, 2017 ... Boufaden is the founder and CEO of Keatext, a Montreal-based company that's using artificial intelligence to help companies navigate ...*

- **[Female Founder Challenge - 2nd Edition Award Ceremony | Pitch ...](https://www.youtube.com/watch?v=n0v_uKlhGzc)**
  - Source: youtube.com
  - *Jun 25, 2020 ... ... Narjes Boufaden, Co-founder and CEO, Keatext (Canada) 35:43 Pitch 5 ... interviews of the globe's brightest minds, entrepreneurs ...*

- **[Decoding AI in CX Analytics - YouTube](https://www.youtube.com/watch?v=lPLjoUGgB2Q)**
  - Source: youtube.com
  - *Jun 19, 2025 ... ... Narjes Boufaden is a pioneer with a vision of a world where AI helps ... Keatext in 2010, becoming one of the first entrepreneurs...*

- **[Committees | Canadian AI 2019 Conference](https://www.caiac.ca/en/conferences/canadianai-2019/committees)**
  - Source: caiac.ca
  - *Virendra Bhavsar, University of New Brunswick, Canada; Narjes Boufaden, KeaText Inc., Canada; Nizar Bouguila, Concordia University, Canada; Scott Buff...*

- **[30 Influential Women Advancing AI — Montreal Edition | by RE•WORK](https://teamrework.medium.com/montreal-is-considered-to-be-a-global-hub-for-the-advancement-of-artificial-intelligence-ai-dc6ed4bbd417)**
  - Source: teamrework.medium.com
  - *Oct 8, 2019 ... Narjes Boufaden, Founder & CEO, Keatext. Last but by no means least, Narjes Boufaden! Narjes is passionate about solving technical cha...*

---

*Generated by Founder Scraper*
