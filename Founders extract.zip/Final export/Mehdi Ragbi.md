# Mehdi Ragbi

## Position actuelle

**Titre** : Co-founder & CTO
**Entreprise** : Blawnt
**Durée dans le rôle** : 6 months in role
**Durée dans l'entreprise** : 6 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Software Development

## Résumé

My role is to help organizations create value and succeed in their data and analytics modernization. 
Support business leaders into defining their data vision and build their implementation roadmap, design the technical landscape and drive delivery teams into achieving successful milestones.    

In constant research of how to create business value through data and technology.
"To know, is to know that you know nothing. That is the meaning of true knowledge."

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABK7coIBsxlb-sBa3-_A9OEemyQMepaHoFQ/
**Connexions partagées** : 20


---

# Mehdi Ragbi

## Position actuelle

**Entreprise** : Blawnt

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Mehdi Ragbi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392233823217958912 | Text |  |  | Restaurant Franchise Enthousiastes 🤩 
Meet us in Las Vegas 11-12 November 
and Toronto 13 November ! 

We will be happy to discuss and explain how Blawnt can help restaurant franchisors get most of their procurement strategy across all their franchise brands. 💵🚚 | 20 | 1 | 1 | 1mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:21.302Z |  | 2025-11-06T16:18:04.518Z | https://www.linkedin.com/feed/update/urn:li:activity:7392209126438899712/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7370889445098590209 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFquV-N-SmoKg/feedshare-shrink_800/B4EZkhMATIKcAg-/0/1757198420019?e=1766620800&v=beta&t=VPaVn06zSSi5xibpjdZZ63_z_nk5n3Q1pe83JZ3Ekxo | Welcome Tovit Neizer , amazing to have all your positive energy and culinary experience *wink wink* part of the team 🤩🤩 🚀 | 8 | 1 | 0 | 2mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.245Z |  | 2025-09-08T18:43:08.215Z | https://www.linkedin.com/feed/update/urn:li:activity:7370871074743427073/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7369307351138353153 | Text |  |  | Startup Canadienne, rôle basé à Casablanca.

Stagiaire Développeur Full-Stack motivé(e), avec des connaissances en JavaScript/TypeScript, React, Node.js et SQL, passionné(e) par le développement de produits réels et l’apprentissage rapide dans un environnement startup. 
Initié ou Habitué(e) aux outils de codage assisté par l’IA (Cursor, Copilot, ChatGPT), possède une mentalité de croissance, de la curiosité et une forte capacité à résoudre des problèmes. 

Enthousiaste à l’idée de contribuer activement aux discussions produit tout en apprenant à construire et déployer plus vite.

Possibilité d’embauche si affinité 😊 | 35 | 2 | 1 | 3mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.245Z |  | 2025-09-04T09:56:27.621Z |  | https://www.linkedin.com/jobs/view/4295659600/ | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7369303110650920964 | Text |  |  | 🚀 Full-Stack Developer Intern (Canadian Startup) — Casablanca, Morocco

We’re building a global SaaS platform for US and Canada market, and we’re looking for a full stack developer intern who will work during a startup phase and can potentially become our first hire, someone who’s not afraid to dream big, learn fast, and grind to make it happen.

If you…
• Want to work on real products used by real clients
• Learn to build faster with AI-assisted coding tools (Cursor, ChatGPT, Copilot)
• Have a growth mindset and take ownership instead of waiting for instructions
• Love problem-solving and learning on the fly
…then this might be the perfect fit.

What you’ll do:
• Build full-stack features with React, Node.js, and PostgreSQL.
• Use AI to code smarter, prototype faster, and ship quicker.
• Collaborate in a lean startup environment — expect constant learning and changes.
• Be part of product discussions — not just an executor.

Requirements:
• Knowledge on front end and backend development, be able to develop a product.
• Knowledge on SQL, JavaScript/TypeScript, React, and Node.js, academic or personal projects is a must. 
• Native to AI-enhanced coding ( Cursor, Lovable, Claud Code …) 
• Curious and hungry to learn.
• Comfortable with uncertainty and working in a fast-paced environment.

Perks:
• Direct mentorship from experienced professionals and SaaS founders.
• Learn both tech and entrepreneurship.
• Potential full-time role after internship.

📍 Location: Morocco (remote-friendly, but we will start with Casablanca locally first)
⏳ Duration: 6 months (pay depends on profile)
💡 Apply with: Your CV + 3 sentences on why you want to work in a startup. | 44 | 6 | 1 | 3mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.247Z |  | 2025-09-04T09:39:36.610Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7354478919456022531 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEHN4YZJI_4WA/feedshare-shrink_800/B4EZhBblr0HoAk-/0/1753444413134?e=1766620800&v=beta&t=vKJry6rUXIT0-P6tVPU7ArtZe6rTxgyJoLqDBGuc2QI | “I realized in 2025… I’m already obsolete. 🤯”

Or at least, that’s how it felt when I started building with tools like Lovable, Cursor, Claude Code.

This last months, I’ve been deep in the build phase of my SaaS journey.
And wow… these tools completely changed the game.

For someone like me – used to punch every single line of code by hand –
this new way of building has been… uncomfortable.
There’s this weird FOMO of not knowing exactly what’s happening under the hood.
Letting go of control felt like losing a superpower.

But here’s the truth I had to learn (and unlearn):

⚡️ The game is no longer about knowing every detail.
It’s about knowing where to push, what to test, and how to connect it all end‑to‑end.

Today, building is about:
 •	Strategy + execution in one person
 •	Jumping between code, design, data, product thinking…
 •	Letting AI do 80% so you can focus on the 20% that moves the needle

It’s messy. It’s frustrating. But it’s also the most exciting era to be a builder.

I’m slowly learning to trade control for speed and efficiency and work new muscles/reflexes.
And honestly? It feels like leveling up. 🎮

Curious:
Anyone else struggling with that balance between deep craftsmanship and speed in this new AI-powered era?

 #AI #SaaS #Efficiency #MindsetShift | 21 | 3 | 0 | 4mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.248Z |  | 2025-07-25T11:53:34.009Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7341549602401050625 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | New chapter, new mission 🚀✨

After months of discussions, real-world insights, and whiteboard marathons , I’m thrilled to finally share the start of Blawnt — a smart platform built to help restaurant franchisors take back control of their supply chain revenue .

In the franchise world, every missed rebate, off-contract purchase, or untracked invoice quietly eats away at margins… and trust 😕.
 At Blawnt, we’re on a mission to partner with our clients to unlock hidden revenue 💰, boost compliance ✅, and build stronger, healthier franchise networks 🤝.

Grateful to be building this alongside my brilliant co-founder Rahul Choudhary — whose vision and entrepreneurial fire sparked this journey 🔥. Together, we’re blending deep industry expertise with real-time data to solve a problem that's long been ignored.
We’re just getting started — and we’re building Blawnt for franchisors, with franchisors 💡👥.

👉 Curious about what we're building? Want to collaborate or help us grow? Let’s connect — our inbox is always open! 

🇫🇷 Nouveau chapitre, nouvelle mission 🌍
Derrière chaque chaîne de restauration qui réussit, il y a des efforts souvent invisibles : négociations avec les fournisseurs 🤝, contrats de remises 📄, contrôle des achats 🛒...
 Mais trop souvent, tout cela est fragilisé par un manque de visibilité ou de conformité sur le terrain 😓.
Avec Blawnt, notre ambition est simple mais puissante : aider les franchiseurs à sécuriser et maximiser leurs revenus liés aux achats, grâce à une plateforme intuitive 📊, des alertes intelligentes 🚨, et une vraie transparence sur la performance du réseau 🔍.
Merci à toutes celles et ceux qui croient en notre mission 🙏
Ce n’est que le début !

👉 Vous travaillez dans la restauration, les franchises ou la chaîne d’approvisionnement ? Parlons-en ! on sera ravi d’échanger ou d’explorer des synergies. 🤝📩 | 198 | 43 | 0 | 5mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.249Z |  | 2025-06-19T19:37:04.608Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7337517803328925698 | Text |  |  | Casablanca , Maroc.

Des postes encore libre au GROUPE SCOLAIRE WESTMOUNT , une équipe dynamique avec de grandes ambitions. 

Objectif : Enseignez dans un cadre qui valorise à la fois l’exigence des contenus et la liberté pédagogique pour faire grandir des élèves autonomes et engagés.

Nous cherchons à allier l’exigence et la rigueur de la pédagogie marocaine 🇲🇦 avec la responsabilisation de l’élève acteur de son apprentissage par la pratique et l’autonomie, de la pédagogie canadienne 🇨🇦.

Merci de contacter Meriem M. | 24 | 0 | 3 | 5mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.251Z |  | 2025-06-08T16:36:08.802Z | https://www.linkedin.com/feed/update/urn:li:activity:7337415014082887680/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7315802292639682560 | Article |  |  | Le poste de concepteur analytique est actuellement ouvert à la CDPQ ! 
 un rôle moderne au cœur des enjeux d’aujourd’hui, dans une organisation dont la mission est porteuse de sens 
— le tout sous la supervision de Marie-Aude Thérien une gestionnaire exceptionnelle et humaine. | 17 | 0 | 1 | 7mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.253Z |  | 2025-04-09T18:26:27.599Z | https://cdpq.wd10.myworkdayjobs.com/fr-CA/CDPQ/job/Montral/Premierre-concepteurtrice--Analytique_R04122 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7315783810946650113 | Text |  |  | Thank you Marc Mouzannar for reviewing my Data & Analytics Platform  service. It was great working with you. To learn more about my work, visit my Service Page. | 34 | 1 | 0 | 7mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.253Z |  | 2025-04-09T17:13:01.220Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7314094109894344705 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEGTmydUDqHnQ/feedshare-shrink_800/B4DZYCdN_BGwAg-/0/1743797941401?e=1766620800&v=beta&t=YfERYDZ46Y5E9QkvTs-mvR0gGlNxmDFDf0gwoaq_ELM | “With great power comes great responsibility”
AI is a tool, a very powerful tool as we have never seen before and it keeps getting more powerful and impactful.

It can be a life saviour tool or mass destruction and killing tool. 

Ethical regulation and AI “CounterDefense” should become clearly a priority already in this stage. 

What changed ? WE are fueling the technology with our data so WE should be collectively aware and responsible. | 8 | 0 | 0 | 8mo | Post | Mehdi Ragbi | https://www.linkedin.com/in/mehdi-ragbi-9422bb89 | https://linkedin.com/in/mehdi-ragbi-9422bb89 | 2025-12-08T04:55:26.254Z |  | 2025-04-05T01:18:45.096Z | https://www.linkedin.com/feed/update/urn:li:activity:7314018735718068225/ |  | 

---



---

# Mehdi Ragbi
*Blawnt*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [FOUNDER’S INTERVIEW: Bloq.it | Fil Rouge Capital](https://www.filrougecapital.com/blog-post/founders-interview-bloq-it)
*2024-09-26*
- Category: blog

### [OneRagtime Marketing Website](https://www.oneragtime.com/team/mehdi-benjelloun)
*2025-01-01*
- Category: article

### [Mehdi Benjelloun - Chief Of Staff at OneRagtime | The Org](https://theorg.com/org/oneragtime/org-chart/mehdi-benjelloun)
*2024-11-18*
- Category: article

### [Blog - Home](https://www.oneragtime.com/blog/home)
*2024-03-25*
- Category: blog

### [UWI St. Augustine Campus](https://sta.uwi.edu/resources/documents/UWI_FacultyReport_23-24.pdf)
- Category: article

---

## 📖 Full Content (Scraped)

*5 articles scraped, 100,556 words total*

### FOUNDER’S INTERVIEW: Bloq.it | Fil Rouge Capital
*1,017 words* | Source: **EXA** | [Link](https://www.filrougecapital.com/blog-post/founders-interview-bloq-it)

**Name:** Miha Jagodic

**Company name:** Bloq.it

**Colour of your eyes:** blue

**How many people are in the team:**

Approximately 85 talented individuals are part of our team today, driving Bloq.it forward with their dedication and expertise, and we’ll be 100 people in a couple of months.

Many more to join shortly.

**What is the difference between you and Steve Jobs?**

While I deeply respect Steve Jobs’ brilliance and innovation, I give more attention to healthy work culture and long-term talent retention. Although I do enjoy the occasional stroll during a meeting, same as Steve back in the day.

Discussion on the product/service
---------------------------------

**Can you describe your product/service to us?**

Bloq.it is transforming the logistics industry by offering cutting-edge smart parcel locker solutions.

We’re doing so by offering an end-to-end smart locker solution that allows companies to quickly and effectively launch these networks, create user adoption, and manage them at scale.

H**ow did you get the idea to start with this**?

The inspiration for Bloq.it stemmed from recognizing the challenges in the logistics sector, particularly in last-mile delivery. E-commerce was on the rise (and boomed during Covid), and we understood that there is infrastructure to be built to accommodate this growth. Smart parcel lockers seemed to be one of the most reliable and long-term solutions for the industry, that no one really tackled correctly until then.

**What are your plans for the future?**

Our vision for Bloq.it is to establish ourselves as the global leader in smart locker solutions for the logistics industry. We aim to expand our footprint internationally, forging strategic partnerships and continuously innovating to meet the evolving needs of our customers. “We want Bloq.it to become the synonym of Smart Lockers excellence,” — this is our goal. We believe that by the end of 2026, we will be the largest smart parcel locker provider worldwide, and later on achieve the vision of becoming the largest out-of-home solution provider.

**Rather Ginto or Whiskey?**

Personally, I appreciate the company more than the beverage itself. But to be fair, I do enjoy a bit of a stronger drink..

Personal conversation
---------------------

**What is it like to run a business and what do you like the most?**

Running a business is a journey of constant growth and learning. It’s a very fulfilling journey that causes you many sleepless nights, constant pressure, and stress, which is something I can relate to as a recent father as well. The business is a baby just like my daughter.

**What are your biggest obstacles?**

Over time I learned that the biggest obstacle is growing the team. Once you achieve an advantage in the market and build a great product, you need to scale the team that will transform your vision on a much wider scale. This is a challenge we still haven’t solved completely!

**Are you more Goulash or Odojak? Caviar or Foie gras?**

I like to experiment with different cuisines, especially in Europe, since I am constantly traveling to different countries representing our team. Goulash would still be my choice from the mentioned.

**What advice would you give to other people that are interested in starting something new?**

Surround yourself with capable people that you trust, both in terms of founders and people outside, such as investors and advisors. You will face unpredictable challenges, downturns, and pivots of some sort are unavoidable; this is where the people you surround yourself with make all the difference.

**What would you advise a founder to do?**

Be consistent and focused on what’s important. Work on healthy fundamentals, those win long-term. Have a vision that reflects monetary outcome, and not how to win an award at a startup event. Resources compared to larger competitors are typically limited, therefore time and execution are worth more.

**What would you advise a founder not to do?**

It’s easy to get distracted by awards, events, and potential investors so don’t forget that sales is what determines your success, especially long-term. Be very careful what you dedicate your time to. Don’t celebrate investment rounds, this is a responsibility you onboarded and is not yet paid off.

**What is a key factor to success?**

The team is a key enabler to success. The key values to success are focus and consistency. Success is not to get on top (eg. build a leading product, or win the best client), but to stay on top afterward (since only that brings the desired outcome for shareholders). For that, you need the right team to be focused and consistent. You should never relax and think that the job is done.

**How to teach a frog to smile?**

Teaching a frog to smile is not something I’ve done yet, but sounds like vacation compared to running a business.

**FRC**experience
-----------------

**Can you tell us something about your experience**with the FRC team?

We’ve received quite impo

*[... truncated, 1,233 more characters]*

---

### Not Found
*119 words* | Source: **EXA** | [Link](https://www.oneragtime.com/team/mehdi-benjelloun)

Not Found

===============

[![Image 1](https://cdn.prod.website-files.com/625588512e942a74d372f853/641331cc4cf3e6daf8ef4e6e_ORT_logo_normal_vectorial%201.svg)](https://www.oneragtime.com/)

Portfolio

[Portfolio Companies](https://www.oneragtime.com/portfolio-companies)[Portfolio Support](https://www.oneragtime.com/team/mehdi-benjelloun#)

Invest

[Why Join OneRagtime?](https://www.oneragtime.com/team/mehdi-benjelloun#)[How to invest](https://www.oneragtime.com/team/mehdi-benjelloun#)

Trending Questions

[Get the most out of the platform...](https://www.oneragtime.com/team/mehdi-benjelloun#)[Clone webflow components...](https://www.oneragtime.com/team/mehdi-benjelloun#)

[Pitch](https://www.oneragtime.com/team/mehdi-benjelloun#)[Community](https://www.oneragtime.com/team/mehdi-benjelloun#)[About us](https://www.oneragtime.com/team/mehdi-benjelloun#)[Blog](https://www.oneragtime.com/team/mehdi-benjelloun#)[Jobs](https://careers.oneragtime.com/jobs)

[Join](https://platform.oneragtime.com/platform/join)[Login](https://platform.oneragtime.com/platform/)

[![Image 2](https://cdn.prod.website-files.com/625588512e942a74d372f853/641331cc4cf3e6daf8ef4e6e_ORT_logo_normal_vectorial%201.svg)](https://www.oneragtime.com/team/mehdi-benjelloun#)

Portfolio

[Portfolio Companies](https://www.oneragtime.com/portfolio-companies)[Portfolio Support](https://www.oneragtime.com/team/mehdi-benjelloun#)

Invest

[Why Join OneRagtime?](https://www.oneragtime.com/team/mehdi-benjelloun#)[How to Invest](https://www.oneragtime.com/team/mehdi-benjelloun#)

[Pitch](https://www.oneragtime.com/team/mehdi-benjelloun#)[Community](https://www.oneragtime.com/team/mehdi-benjelloun#)[About us](https://www.oneragtime.com/team/mehdi-benjelloun#)[Blog](https://www.oneragtime.com/team/mehdi-benjelloun#)[Jobs](https://careers.oneragtime.com/jobs)

[Join](https://platform.oneragtime.com/platform/join)

[Log in](https://platform.oneragtime.com/platform/)

Page not found
==============

We can't seem to find the page you're looking for.

[Back to home](https://www.oneragtime.com/old-home)

![Image 3](https://cdn.prod.website-files.com/625588512e942a74d372f853/625817f9ed08e518009109f9_Default.png)

[****](https://twitter.com/oneragtime)[****](https://www.linkedin.com/company/oneragtime)

[FAQ](https://www.oneragtime.com/faq)[Privacy Policy](https://www.oneragtime.com/privacy-policy)[Terms of use](https://www.oneragtime.com/team/mehdi-benjelloun#)[ESG](https://cdn.prod.website-files.com/625588512e942a74d372f853/6310de1c257da3fc45bb7e16_OneRagtime%20-%20SFDR.pdf)[Procedures](https://www.oneragtime.com/procedures)[Contact](https://www.oneragtime.com/contact)

Join our newsletter

This is some text to have here as a placeholder

[Sign up now ![Image 4](https://cdn.prod.website-files.com/625588512e942a74d372f853/64134b3d78d22f35e304a935_arrow-narrow-up-right.svg)![Image 5](https://cdn.prod.website-files.com/625588512e942a74d372f853/64134e8e68d7ad19937b722c_arrow-narrow-up-right.svg)](https://6155cf0e.sibforms.com/serve/MUIEAGr7bZp0qYcudchxI9zm_oNICnnS_upazc02hb5xQGTtNO4S_tJ4Mbn9Ykl0qC5OxY1udWcW32Ybhv2AbjyiAjjINikB_8X9FN9rY8Uz6-IWMeV_v6LV0-KntwsLj89i5u0YokNRaZnDRns3f1AKmgsEwBM4TiZ024eEcQa6a3I1YaNrapoHgoDxo95pYqxDw1vSXhOnyiYS)

Get the app

[![Image 6](https://cdn.prod.website-files.com/625588512e942a74d372f853/626024a716f587be4cf70998_app-store-png-logo-33123%204.png)](https://play.google.com/store/apps/details?id=com.oneragtime.platform&hl=en&gl=US&pli=1)[![Image 7](https://cdn.prod.website-files.com/625588512e942a74d372f853/626023eccd66c254a65ef2df_app-store-png-logo-33123%203.png)](https://apps.apple.com/es/app/oneragtime/id1112926303)

© Copyright 2024 - OneRagtime SAS

[contact@oneragtime.com](mailto:contact@oneragtime.com)

60 Rue de Londres, Paris

Carrer de Rosa Sensat, 9, Barcelona

© Copyright 2024 - OneRagtime SAS

---

### Mehdi Benjelloun - Chief Of Staff at OneRagtime | The Org
*209 words* | Source: **EXA** | [Link](https://theorg.com/org/oneragtime/org-chart/mehdi-benjelloun)

![Image 1: Mehdi Benjelloun's profile picture](https://cdn.theorg.com/e39ebc34-3624-411f-a2a8-583b5400dc90_thumb.jpg)

### Chief Of Staff

Mehdi Benjelloun is a seasoned venture capital professional currently serving as a VC Ecosystem Catalyst at OneRagtime since May 2022, where the focus is on European Seed and Series A investments with a diverse portfolio that includes companies like Jellysmack and Homa Games. As a founding member of Moroccans in Tech and co-founder of baby vc, an 8-week venture capital bootcamp with extensive alumni across Europe, Mehdi has contributed significantly to the startup ecosystem. Previous roles include Operations Strategy Analyst at Doctolib, VC Analyst positions at Heartcore Capital and CapHorn Invest, and experience in business development at Neuroprofiler. Academic achievements include a Master's degree in Finance & Entrepreneurship from emlyon business school, an Erasmus exchange at Maastricht University, and a Bachelor's degree in Economics and Management from Université Paris-Sorbonne. Additionally, Mehdi completed a computer science program at 42 Silicon Valley and holds a Bac S from Lycée Lyautey au Maroc.

Location

Paris, France

Links

Previous companies

[![Image 2: Cap Horn logo](https://cdn.theorg.com/8b2766f7-bdcf-4f6e-a4cb-2c62dc16510c_thumb.jpg)](https://theorg.com/org/cap-horn "Cap Horn")[![Image 3: Neuroprofiler logo](https://cdn.theorg.com/c1c2f241-5651-4bc0-baf9-191ed4c683f5_thumb.jpg)](https://theorg.com/org/neuroprofiler "Neuroprofiler")[![Image 4: Heartcore Capital logo](https://cdn.theorg.com/ce98cbc2-2a28-43ae-805c-f89d55a71324_thumb.jpg)](https://theorg.com/org/hearthcore "Heartcore Capital")

* * *

Org chart
---------

No direct reports

* * *

Teams
-----

This person is not in any teams

* * *

Offices
-------

---

### Not Found
*119 words* | Source: **EXA** | [Link](https://www.oneragtime.com/blog/home)

Not Found

===============

[![Image 1](https://cdn.prod.website-files.com/625588512e942a74d372f853/641331cc4cf3e6daf8ef4e6e_ORT_logo_normal_vectorial%201.svg)](https://www.oneragtime.com/)

Portfolio

[Portfolio Companies](https://www.oneragtime.com/portfolio-companies)[Portfolio Support](https://www.oneragtime.com/blog/home#)

Invest

[Why Join OneRagtime?](https://www.oneragtime.com/blog/home#)[How to invest](https://www.oneragtime.com/blog/home#)

Trending Questions

[Get the most out of the platform...](https://www.oneragtime.com/blog/home#)[Clone webflow components...](https://www.oneragtime.com/blog/home#)

[Pitch](https://www.oneragtime.com/blog/home#)[Community](https://www.oneragtime.com/blog/home#)[About us](https://www.oneragtime.com/blog/home#)[Blog](https://www.oneragtime.com/blog/home#)[Jobs](https://careers.oneragtime.com/jobs)

[Join](https://platform.oneragtime.com/platform/join)[Login](https://platform.oneragtime.com/platform/)

[![Image 2](https://cdn.prod.website-files.com/625588512e942a74d372f853/641331cc4cf3e6daf8ef4e6e_ORT_logo_normal_vectorial%201.svg)](https://www.oneragtime.com/blog/home#)

Portfolio

[Portfolio Companies](https://www.oneragtime.com/portfolio-companies)[Portfolio Support](https://www.oneragtime.com/blog/home#)

Invest

[Why Join OneRagtime?](https://www.oneragtime.com/blog/home#)[How to Invest](https://www.oneragtime.com/blog/home#)

[Pitch](https://www.oneragtime.com/blog/home#)[Community](https://www.oneragtime.com/blog/home#)[About us](https://www.oneragtime.com/blog/home#)[Blog](https://www.oneragtime.com/blog/home#)[Jobs](https://careers.oneragtime.com/jobs)

[Join](https://platform.oneragtime.com/platform/join)

[Log in](https://platform.oneragtime.com/platform/)

Page not found
==============

We can't seem to find the page you're looking for.

[Back to home](https://www.oneragtime.com/old-home)

![Image 3](https://cdn.prod.website-files.com/625588512e942a74d372f853/625817f9ed08e518009109f9_Default.png)

[****](https://twitter.com/oneragtime)[****](https://www.linkedin.com/company/oneragtime)

[FAQ](https://www.oneragtime.com/faq)[Privacy Policy](https://www.oneragtime.com/privacy-policy)[Terms of use](https://www.oneragtime.com/blog/home#)[ESG](https://cdn.prod.website-files.com/625588512e942a74d372f853/6310de1c257da3fc45bb7e16_OneRagtime%20-%20SFDR.pdf)[Procedures](https://www.oneragtime.com/procedures)[Contact](https://www.oneragtime.com/contact)

Join our newsletter

This is some text to have here as a placeholder

[Sign up now ![Image 4](https://cdn.prod.website-files.com/625588512e942a74d372f853/64134b3d78d22f35e304a935_arrow-narrow-up-right.svg)![Image 5](https://cdn.prod.website-files.com/625588512e942a74d372f853/64134e8e68d7ad19937b722c_arrow-narrow-up-right.svg)](https://6155cf0e.sibforms.com/serve/MUIEAGr7bZp0qYcudchxI9zm_oNICnnS_upazc02hb5xQGTtNO4S_tJ4Mbn9Ykl0qC5OxY1udWcW32Ybhv2AbjyiAjjINikB_8X9FN9rY8Uz6-IWMeV_v6LV0-KntwsLj89i5u0YokNRaZnDRns3f1AKmgsEwBM4TiZ024eEcQa6a3I1YaNrapoHgoDxo95pYqxDw1vSXhOnyiYS)

Get the app

[![Image 6](https://cdn.prod.website-files.com/625588512e942a74d372f853/626024a716f587be4cf70998_app-store-png-logo-33123%204.png)](https://play.google.com/store/apps/details?id=com.oneragtime.platform&hl=en&gl=US&pli=1)[![Image 7](https://cdn.prod.website-files.com/625588512e942a74d372f853/626023eccd66c254a65ef2df_app-store-png-logo-33123%203.png)](https://apps.apple.com/es/app/oneragtime/id1112926303)

© Copyright 2024 - OneRagtime SAS

[contact@oneragtime.com](mailto:contact@oneragtime.com)

60 Rue de Londres, Paris

Carrer de Rosa Sensat, 9, Barcelona

© Copyright 2024 - OneRagtime SAS

---

### The Univesity of the West Indies St Augustine Campus Faculty Report 2023/2024
*99,092 words* | Source: **EXA** | [Link](https://sta.uwi.edu/resources/documents/UWI_FacultyReport_23-24.pdf)

A PUBLICATION OF THE MARKETING & COMMUNICATIONS OFFICE, THE UNIVERSITY OF THE WEST INDIES, ST. AUGUSTINE CAMPUS ABOUT OUR COVER & THEME 

At The UWI St Augustine Campus, we are makers — of knowledge, solutions, and progress. For 65 years, our teaching, innovation and research have shaped industries, influenced policies, and empowered communities in Trinidad & Tobago and across the Caribbean. Now, we are taking that impact even further. The launch of UWI Made , our new commercial brand, marks a bold new step towards enhancing our mission. Under this umbrella brand, we are converting our years of rigorous research into real-world innovations that are sustainable and commercially viable. Our new products include superior sealing and marine compounds built for tropical conditions, an eco-friendly organic pesticide and growth stimulant, a premium line of dark chocolate and cutting-edge by-products and methodologies using nationally-grown cocoa — each with the potential to spark not just new businesses, but new industries. 

UWI Made is a testament to the power of research, persistence and creativity and to the limitless potential of this Campus and Caribbean peoples. 

> Cover art by Shayam Karim based on the UWI Made logo developed by Dara Jordan-Brown

Faculty of Engineering  2

Faculty of Food & Agriculture  18 

Faculty of Humanities & Education  24 

Faculty of Law  38 

Faculty of Medical Sciences  46 

Faculty of Science & Technology  64 

Faculty of Social Sciences  82 

Faculty of Sport  100 

Centres & Institutes  104 

ANSA McAL Psychological Research Centre  104 

Centre for Health Economics (HEU)  109 

Institute for Gender & Development Studies (IGDS)  114 

Institute of International Relations (IIR)  121 

Seismic Research Centre (SRC)  132 

Sir Arthur Lewis Institute of 

Social & Economic Studies (SALISES)  143 

Publications & Conferences (ONLINE ONLY)  146 Dean’s Summary 

In 2023/2024, the Faculty of Engineering continued to work towards achieving the major goals aligned with Phase II: Revenue Revolution of The UWI’s Triple “A” Strategies and its six strategic objectives established through collaborative strategic planning. These were included in all aspects of our operations: 

Professor Bheshem Ramlal Dean 

• teaching and learning; 

• re-accreditation of postgraduate and undergraduate programmes; 

• research and innovation; 

• outreach; 

• national, regional, and international engagement; 

• staff development; 

• professional service; 

• safety; 

• collaborations and alliances with industry, governmental agencies, and other tertiary level institutions; and 

• curriculum and quality assurance reviews. Overall, the last academic year was a successful one. 3

Department of Chemical Engineering 

The Department of Chemical Engineering continues to offer several academic programmes at the undergraduate and post-graduate levels. Most of these programmes are accredited by international bodies including the Institution of Chemical Engineers (IChemE), and Engineering Institute (EI) London, have accredited the Bachelor of Science and Master of Science programs in Chemical and Process Engineering, Petroleum and Reservoir Engineering, and Petroleum Geoscience, respectively. The MSc in Food Science and Technology is also approved by the Institute of Food Science and Technology (IFST) of the UK. In the 2023/2024 academic year, an MoU was signed between The UWI and UTT that allows for significant collaboration between the two institutions. The Ministry of Energy and Energy Industries (MEEI) for the Petroleum Geoscience (PGSC) programme is offering 30 scholarships and incentives for persons interested in pursuing the programme. So far, 24 students were admitted after a long break because of these bursaries. The Department was able to attract additional industry sponsorship for its awards and prizes. For the reporting period, more than twenty international peer-reviewed journal publications were published. The website was recently updated to showcase our programmes, achievements, opportunities available to students and commercial services we can offer to our stakeholders. 

Department of Civil & Environmental Engineering 

The Department of Civil & Environmental Engineering continues to build on existing initiatives and are well on course towards another successful Quality Assurance Review of our undergraduate and post-graduate programmes. The Department objections are aligned with the six strategic objectives linked to the UWI A strategy. Several initiatives were undertaken by members of staff in the Department to pursue these objectives, including participation in several outreach activities; sensitisation and training of staff in the use of the Virtual Learning Environment for assessment and feedback; several publications – comprising of two conference and 41 journal publications, six patents and 6 technical reports; public and professional services with various academic, industrial and govern

*[... truncated, 692,198 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
