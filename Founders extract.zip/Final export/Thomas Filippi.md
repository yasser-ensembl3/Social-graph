# Thomas Filippi

## Position actuelle

**Titre** : Co-fondateur et PDG
**Entreprise** : Flyos Games inc.
**Durée dans le rôle** : 8 years 10 months in role
**Durée dans l'entreprise** : 8 years 10 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Description du rôle

- Setting and executing the organization’s strategy/values,
- Creating and allocating capital, 
- Building and overseeing the Sales, Communication and Logistic teams.

## Résumé

Je suis le co-fondateur et le PDG de Flyos Games, une entreprise québécoise, qui crée et produit des jeux originaux et immersifs. Depuis plus de huit ans, je définis et exécute la stratégie, les valeurs et la vision de l'organisation, en accordant une attention particulière à la satisfaction des clients, des partenaires et des collaborateurs.

En tant que leader, je crée et alloue le capital, je construis et supervise les équipes de vente, de communication et de logistique, et je développe des relations solides avec les acteurs clés du secteur. 

Je possède des compétences en marketing, communication, gestion des opérations, game design et leadership. Je suis passionné par les jeux de société, les jeux-vidéos, la technologie, le JDR, la narration et l'innovation. J’améliore constamment nos processus afin d’offrir des expériences toujours plus ludiques et enrichissantes à notre public.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAZDJlABysG20NmplNIVqkEqo2rwp_AlZLs/
**Connexions partagées** : 29


---

# Thomas Filippi

## Position actuelle

**Entreprise** : FLYOS

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Thomas Filippi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393331912351719424 | Article |  |  | Soon, I will attend MIGS 2025. Excited to connect with industry experts and stay updated on the latest trends. Open to meeting requests, let's network and explore opportunities together! | 26 | 0 | 0 | 4w | Post | Thomas Filippi | https://www.linkedin.com/in/thomas-filippi-b282282b | https://linkedin.com/in/thomas-filippi-b282282b | 2025-12-08T06:20:10.635Z |  | 2025-11-09T17:01:29.369Z | https://app.meettomatch.com/migs2025/public/profile/aDlxb0hhaHhLYTEyQjhyUGRGbnVIQT09 |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384663488239054848 | Article |  |  | Ca y est! C'est officiel!
Suivez la campagne de Brawlhalla, prochainement sur Kickstarter: https://lnkd.in/drwV2fUv | 46 | 4 | 0 | 1mo | Post | Thomas Filippi | https://www.linkedin.com/in/thomas-filippi-b282282b | https://linkedin.com/in/thomas-filippi-b282282b | 2025-12-08T06:20:10.635Z |  | 2025-10-16T18:56:16.009Z | https://www.kickstarter.com/projects/maestromedia/brawlhalla-the-card-game |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7373805425051484160 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEQqjRXFiUikQ/feedshare-shrink_800/B4EZlT_uXCKcAk-/0/1758050838963?e=1766620800&v=beta&t=SmeEQ_GDNkbrM8kjfOeCsNRKJ7bdgU1NUaJ1FNg0UsI | Équipe fantastique ☺️ | 4 | 0 | 1 | 2mo | Post | Thomas Filippi | https://www.linkedin.com/in/thomas-filippi-b282282b | https://linkedin.com/in/thomas-filippi-b282282b | 2025-12-08T06:20:10.636Z |  | 2025-09-16T19:50:12.012Z | https://www.linkedin.com/feed/update/urn:li:activity:7373799672043249666/ |  | 

---



---

# Thomas Filippi
*FLYOS*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Thomas Filippi](https://www.boardgamebliss.com/collections/thomas-filippi?srsltid=AfmBOoq7btVn5KxvTRdbKMqVDR-Ws_92kAw-aOeWkApXIAul8a-JVx63)
*2025-06-10*
- Category: article

### [A new path to full-time open source featuring Filippo Valsorda (Changelog Interviews #533)](https://changelog-2025-05-05.fly.dev/podcast/533)
*2025-05-05*
- Category: podcast

### [Talking With Thomas Filippi, Co-Founder of Flyos Games, On VAMPIRE: THE MASQUERADE - CHAPTERS — GameTyrant](https://gametyrant.com/news/talking-with-thomas-filippi-co-founder-of-flyos-games-on-vampire-the-masquerade-chapters)
*2020-05-01*
- Category: article

### [The Hub — Your Monthly Look Behind the Scenes (Vol.4) - FLYOS](https://www.flyosgames.com/the-hub-vol-4)
*2025-09-18*
- Category: article

### [[RTAS ’22 Best Student Paper] FlyOS: Integrated Modular Avionics for Autonomous Multicopters – ACM SIGBED](https://sigbed.org/2022/07/25/rtas-22-best-student-paper-flyos-integrated-modular-avionics-for-autonomous-multicopters/)
*2022-07-25*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Vampire: The Masquerade - Chapters bridges the gap between ...](https://www.dicebreaker.com/categories/board-game/feature/vampire-the-masquerade-chapters-preview)**
  - Source: dicebreaker.com
  - *Feb 12, 2020 ... Flyos Games co-founders Thomas Filippi and Gary Paitre have been ... She is also a member of the Critical Hit actual play podcast and...*

- **[Rules are pretty unclear to me | BoardGameGeek](https://boardgamegeek.com/thread/1804138/rules-are-pretty-unclear-to-me)**
  - Source: boardgamegeek.com
  - *Jun 28, 2017 ... Thomas Filippi. Canada flag. Designer · @Flyos Games · @Flyos Games · Jun 30, 2017. Full Date. Hello Trevyn, Thomas here from Flyos G...*

- **[Play Survive Until Daylight online through your web browser - Board ...](https://tabletopia.com/games/survive-until-daylight)**
  - Source: tabletopia.com
  - *FLYOS. Artists. Ben Bauchau, Elsa Lamy. Thomas Filippi, Gary Paitre. Links. Game ... Other Games by FLYOS6. Brawlhalla: The Card ......*

- **[Vampire: The Masquerade - Chapters. Playable prologues ...](https://boardgamegeek.com/thread/2357530/vampire-the-masquerade-chapters-playable-prologues)**
  - Source: boardgamegeek.com
  - *Jan 27, 2020 ... Podcast Ep. Advanced Search. Skip Sidebar. Vampire: The ... Thomas Filippi. Canada flag. Designer · @Flyos Games · @Flyos Games · Jan...*

- **[Werewolf The Apocalypse: Retaliation, FLYOS, and Narrative Board ...](https://techraptor.net/tabletop/interview/werewolf-apocalypse-retaliation-flyos-and-narrative-board-game-design)**
  - Source: techraptor.net
  - *Jan 28, 2022 ... We sit down to talk to FLYOS' own Thomas Filippi about his studio's ... About Us Contact Us Podcasts Blog. Header sidebar menu. Video...*

- **[A few questions about the game | BoardGameGeek](https://boardgamegeek.com/thread/2704275/a-few-questions-about-the-game)**
  - Source: boardgamegeek.com
  - *Aug 5, 2021 ... Podcast Ep. Advanced Search. Skip Sidebar. Vampire: The ... Thomas Filippi. Canada flag. Designer · @Flyos Games · @Flyos Games · Aug ...*

- **[Tabletop Gaming - Strange Assembly](https://www.strangeassembly.com/podcasts/strange_assembly_gaming.xml)**
  - Source: strangeassembly.com
  - *... Podcast The Strange Assembly crew gives a rundown of Kotei season ... Thomas Filippi of Flyos Games about the board game Vampire the Masquerade .....*

- **[Flyos Games on Vampire: The Masquerade - Chapters](https://www.geek-pride.co.uk/thomas-filippi-interview/)**
  - Source: geek-pride.co.uk
  - *Nov 15, 2019 ... Categories: Features, Previews / Interviews. Tags: board game, Chapters, flyos games, Paradox Interactive, Thomas Filippi, vampire, V...*

- **[Kiwetin Intrigues, But Is It Enough? | Gameosity](https://www.gameosity.com/2017/01/24/kiwetin-intrigues-but-is-it-enough/)**
  - Source: gameosity.com
  - *Jan 24, 2017 ... Kiwetin, designed by Thomas Filippi and Gary Paitre of Flyos Games, is a 2-6 player game where everyone is forest spirits racing up a...*

- **[Talking With Samuel Bailey, Co-Designer of FORBIDDEN STARS ...](https://gametyrant.com/news/talking-with-samuel-bailey-co-designer-of-forbidden-stars)**
  - Source: gametyrant.com
  - *Jun 11, 2020 ... ... Talking With Thomas Filippi, Co-Founder of Flyos Games, On VAMPIRE: THE ......*

---

*Generated by Founder Scraper*
