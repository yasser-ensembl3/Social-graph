# Phil Bouchard

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Fornux Corporation
**Durée dans le rôle** : 4 years 9 months in role
**Durée dans l'entreprise** : 7 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Fornux saves IT companies, time, money and their own reputation by fixing crashes and memory leaks in their C++ software. Fornux also brings plenty of new innovative solutions for various groundbreaking physics technologies such as stealth propulsion (TRL4), force fields (TRL3) and antimatter genesis (TRL2).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAIxjeYB9_DrK3crVxET4PeptgBMiFM2qgE/
**Connexions partagées** : 15


---

# Phil Bouchard

## Position actuelle

**Entreprise** : Fornux Corporation

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Phil Bouchard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403519254404386816 | Article |  |  | Elevator pitch a Defi Montreal - Cyberecho ce 4 Decembre 2025:
https://lnkd.in/eaKGdhQQ | 1 | 0 | 0 | 9h | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:10.475Z |  | 2025-12-07T19:42:20.986Z | https://youtu.be/RfwIXGdIkLQ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7403228825142132736 | Article |  |  | Epic episode from yesterday, where Newton's Strong Equivalence Principle is voided!
https://lnkd.in/ehmfew5X | 3 | 2 | 0 | 1d | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:10.476Z |  | 2025-12-07T00:28:17.254Z | https://youtu.be/M1AmZoH8bS4?t=2132 |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7398581989731160064 | Article |  |  | Fornux Inc. is #55 from the top 59 AI companies in Montreal!
https://lnkd.in/eJeYYZSu | 4 | 0 | 0 | 2w | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:10.477Z |  | 2025-11-24T04:43:25.358Z | https://www.f6s.com/companies/artificial-intelligence/canada/montreal/co |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398471991395233792 | Article |  |  | Bingo! *Newton's Equivalence Principle is refuted!* I just compiled the acceleration statistics and the theory is pretty close to the experiment (± 0.022 m/s^2 vs ± 0.023 m/s^2):
https://lnkd.in/eHvugNHG
https://lnkd.in/eNQu57PF | 5 | 0 | 1 | 2w | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:10.478Z |  | 2025-11-23T21:26:19.711Z | https://static.fornux.com/files/freefall/day5/Finite_Theory-Magnet_FreeFall_Experiment-Mean.pdf |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7398409430448623617 | Article |  |  | Ok I flipped the current flow which automatically flips the polarity of the magnet and I get the same result:
https://lnkd.in/eHvugNHG
https://lnkd.in/eJ-xMAZQ
https://lnkd.in/edwCSjc8

So what matters is the energy density, as the polarity is not effective. | 3 | 0 | 0 | 2w | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:12.647Z |  | 2025-11-23T17:17:44.019Z | https://youtu.be/_EM055BJCsk |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7398020260949331968 | Article |  |  | Now this time I made it official magnets don't fall at the same speed and as predicted by Finite Theory. *The scientific community will have to go back to the drawing board!*

Freefall experiment:
https://lnkd.in/eEVQcMkm

High precision video:
https://lnkd.in/eYKiT_Nk

Here's the theory behind the effect:
https://lnkd.in/eHvugNHG | 2 | 3 | 0 | 2w | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:12.648Z |  | 2025-11-22T15:31:18.780Z | https://youtu.be/Oy_N-KunmAE |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7390410011832889344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH8sNqCNKaJOA/feedshare-shrink_800/B4EZpACuzZIQAg-/0/1762011052296?e=1766620800&v=beta&t=TORZl_g9cq13Vl4NezpZhhKLPmbeun1tHq8KZLbt6x8 | Fornux is now part of 2026 DARPA drone innovation challenge... We will not fail! | 20 | 8 | 1 | 1mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.653Z |  | 2025-11-01T15:30:53.999Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7382740208280162304 | Article |  |  | Check this out, our Friday podcast:
https://lnkd.in/enbKsTBp | 6 | 0 | 0 | 1mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.654Z |  | 2025-10-11T11:33:50.334Z | https://www.youtube.com/live/6s0XcRe1Cp8 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7382248405076701184 | Article |  |  |  | 1 | 0 | 0 | 1mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.654Z |  | 2025-10-10T02:59:35.313Z | https://eventship.com/event/10-15-25-founder-resilience-founder-support-44-mile-sponsored-run |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7382057051855831040 | Video (LinkedIn Source) | blob:https://www.linkedin.com/98f3ab1b-c826-432e-bc94-70b18df98db8 | https://media.licdn.com/dms/image/v2/D4D05AQFZDFg8syHnFw/videocover-low/B4DZnJUJzUGgB8-/0/1760019365118?e=1765774800&v=beta&t=g_JxjRDWqe4egTskHrK5OiI-LvaeAhsDBbdToFJQuLw | Martin Duchaîne est ingenieur egalement donc tres objectif. | 9 | 1 | 0 | 1mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.655Z |  | 2025-10-09T14:19:13.150Z | https://www.linkedin.com/feed/update/urn:li:activity:7382056436505239552/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7381861156514324481 | Article |  |  | I finally received the neodymium and stainless steal balls and immediately done some DIY testing and in this video we see the magnetic ball reaching the floor first:
https://lnkd.in/eFHK7R74

But I still need to improve the video resolution and motion detection algorithm. But this basically refutes Galileo, and no hard feelings on Galileo... | 5 | 13 | 0 | 1mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.655Z |  | 2025-10-09T01:20:48.061Z | https://youtu.be/AZhcJK7-rJ4 |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7377674040406196224 | Article |  |  | Historical milestone:
https://lnkd.in/eFp7yaXD | 2 | 0 | 0 | 2mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.657Z |  | 2025-09-27T12:02:41.788Z | https://www.youtube.com/live/MlGSBl4aFrs?t=430s |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7375901058734227456 | Article |  |  | So I'm just confirming my prediction here that the permeability of the material affects the gravitational acceleration of the object as well (GEM):
https://lnkd.in/gjc6d2nD

Just like Tesla predicted as well. | 3 | 0 | 0 | 2mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.657Z |  | 2025-09-22T14:37:30.017Z | https://youtu.be/vQ7yw_4tUPE |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7374171978917761024 | Article |  |  | Demystify Sci - Paradigm Drift #6:

Featuring Gerald, Joe and me!

https://lnkd.in/ePi9Uynf | 1 | 0 | 0 | 2mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.657Z |  | 2025-09-17T20:06:45.264Z | https://youtu.be/rLYsN3SMJ-o |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7372600810024742912 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFD7JAnCqO-Dw/feedshare-shrink_1280/B4EZlC9XnUIMAs-/0/1757765008171?e=1766620800&v=beta&t=ZuYzLNHiPOc7jGMY9mnVoCrevDEjRqZ3wvy_5XjMtko | Personal thesis:

Here's my contribution to *antigravity* research: magnetic / electric fields can easily be converted into accelerated fields using basic algebra as seen attached. Here's practical evidence:
https://lnkd.in/e7v-BE69

The relativistic explanation such as mass increase for me is all garbage and will have to be rewritten from scratch but meanwhile high school algebra / undergrad calculus are sufficient to explain any types of forces:
https://lnkd.in/ecZhmaMz

Also again: a force is simply the derivative of an energy potential so I'm not sure what can be simpler than that.

Thank you. | 6 | 3 | 0 | 2mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.658Z |  | 2025-09-13T12:03:29.409Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7363240603184226306 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQE0ZieCm7r3Sg/feedshare-shrink_2048_1536/B4DZi98Q5zGQAo-/0/1755533359845?e=1766620800&v=beta&t=yHp2bDopcFzq_caJxxcHLWmKFSy0tj1GY2Mf2Is-UxA | The very powerful C++ Superset 2.1.0, featuring unrolling complex C++ templates, was just released this morning!
https://lnkd.in/e2UYm_kJ | 17 | 1 | 0 | 3mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.658Z |  | 2025-08-18T16:09:22.194Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7359945925386985472 | Article |  |  | That's definitely where the future relies:
https://lnkd.in/ejmeTcVA | 6 | 1 | 0 | 3mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.659Z |  | 2025-08-09T13:57:29.795Z | https://youtu.be/njaBPMuiX3I?t=428 |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7357458881842692096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1jLXtfLln2g/feedshare-shrink_2048_1536/B4EZhrx3V.GUAs-/0/1754154891157?e=1766620800&v=beta&t=VPTz5VKxAF8u8-WKavYhci03z2dahaxQK7XLh9SWpdk | Fornux Inc. is excited to announce its membership in the NVIDIA Connect program! | 15 | 10 | 1 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.659Z |  | 2025-08-02T17:14:52.407Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7356780745522094080 | Article |  |  | https://lnkd.in/ekPERN_M | 4 | 0 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.659Z |  | 2025-07-31T20:20:12.109Z | https://youtu.be/alrwszibBiU |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7356609863776415744 | Article |  |  | Check out the comments from the public on C++ Superset:
https://lnkd.in/ePUhM47a | 4 | 0 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.660Z |  | 2025-07-31T09:01:10.726Z | https://www.reddit.com/r/programming/comments/1mc7g45/c_superset_200/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7356120273215004672 | Article |  |  | https://lnkd.in/eMjFJ4sy | 2 | 0 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.660Z |  | 2025-07-30T00:35:43.240Z | https://www.finalroundai.com/blog/sam-altman-says-world-wants-1000x-more-software |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7355922876933279744 | Article |  |  | The real deal is on Reddit:
https://lnkd.in/ePUhM47a | 3 | 0 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.661Z |  | 2025-07-29T11:31:20.299Z | https://www.reddit.com/r/programming/comments/1mc7g45/c_superset_200/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7355534832631717888 | Article |  |  | Not to miss early August TeslaTech event!
https://lnkd.in/epBibHuD | 3 | 0 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.661Z |  | 2025-07-28T09:49:23.328Z | https://www.howtube.com/lp/teslatech |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7354461702790234113 | Article |  |  | My first joint paper is finally public!
https://lnkd.in/eG9eh4h4 | 9 | 2 | 0 | 4mo | Post | Phil Bouchard | https://www.linkedin.com/in/phil-bouchard-5723a910 | https://linkedin.com/in/phil-bouchard-5723a910 | 2025-12-08T04:51:17.661Z |  | 2025-07-25T10:45:09.236Z | https://www.scirp.org/journal/paperinformation?paperid=144270 |  | 

---



---

# Phil Bouchard
*Fornux Corporation*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Vision, Innovation and Future of AI: an interview with Philip Bouchard, Founder & CEO of Fornux Corporation](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/)
*2024-07-29*
- Category: article

### [Phil Bouchard: Combining Modern Tech Advancement and Innovative Ideas for a Better Tomorrow](https://successpitchers.com/phil-bouchard-combining-modern-tech-advancement-and-innovative-ideas-for-a-better-tomorrow/)
*2023-02-02*
- Category: article

### [ANTIC The Atari 8-bit Podcast: ANTIC Interview 369 - Philip Bouchard, The Oregon Trail](https://ataripodcast.libsyn.com/antic-interview-369-philip-bouchard-the-oregon-trail)
*2019-02-04*
- Category: podcast

### [We Are All About RESEARCH and INNOVATION](https://static.fornux.com/)
*2023-09-24*
- Category: article

### [Pioneering Sustainability: An Interview with ESG Global Tech Fund’s Philipe Evangelou](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/)
*2024-08-05*
- Category: article

---

## 📖 Full Content (Scraped)

*6 articles scraped, 6,684 words total*

### Vision, Innovation and Future of AI: an interview with Philip Bouchard, Founder & CEO of Fornux Corporation
*958 words* | Source: **EXA** | [Link](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/)

Vision, Innovation and Future of AI: an interview with Philip Bouchard, Founder & CEO of Fornux Corporation - xraised

===============

[![Image 1](https://xraised.com/wp-content/uploads/2023/02/logo-xraised-300x77.png)](https://xraised.com/)

*   [Home](https://xraised.com/)
*   [Interviews](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/#)
    *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Regular Guests](https://xraised.com/videos_cat/regular-guests/)

    *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Artificial Intelligence](https://xraised.com/videos_cat/artificial-intelligence/)

    *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Fintech](https://xraised.com/videos_cat/fintech/)

    *   [B2B](https://xraised.com/videos_cat/b2b/)
    *   [Sustainability](https://xraised.com/videos_cat/sustainability/)
    *   [Healthcare](https://xraised.com/videos_cat/healthcare/)
    *   [Manufacturing](https://xraised.com/videos_cat/manufacturing/)
    *   [Supply Chain](https://xraised.com/videos_cat/supply-chain/)
    *   [Digitalisation](https://xraised.com/videos_cat/digitalisation/)
    *   [Real Estate](https://xraised.com/videos_cat/real-estate/)
    *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Life Coaching](https://xraised.com/videos_cat/life-coaching/)

    *   [Retail](https://xraised.com/videos_cat/retail/)
        *   [Luxury goods](https://xraised.com/videos_cat/luxury-goods/)
        *   [Fashion](https://xraised.com/videos_cat/fashion/)
        *   [Interior & Exterior Desing](https://xraised.com/videos_cat/interior-exterior-desing/)

*   [SEO Services](https://xraised.com/seo-articles/)
*   [Prospecting](https://xraised.com/lead-generation/)
*   [About Us](https://xraised.com/about-us/)
    *   [About Us](https://xraised.com/about-us/)
    *   [Contact Us](https://xraised.com/contact/)

*   [News](https://xraised.com/blog/)
*   [Spotify](https://open.spotify.com/show/7etNTKOaQFx7Uchomgh12N?si=0cae6466efc64e09&nd=1&dlsi=af4eb318137748e1)
*   [Amazon Music](https://music.amazon.com/podcasts/04efeb4a-c716-440b-a935-0a38ad4e868f/xraised)

Please enter keywords

![Image 2: usd_img](https://xraised.com/wp-content/uploads/2023/02/earch.svg)EN

[JP](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/#)

[FR](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/#)

[](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/#)

[![Image 3](https://xraised.com/wp-content/uploads/2023/02/logo-xraised-300x77.png)](https://xraised.com/)

Please enter keywords

*   [Home](https://xraised.com/)
*   [Interviews](https://xraised.com/videos/vision-innovation-and-future-of-ai-an-interview-with-philip-bouchard-founder-ceo-of-fornux-corporation/#)
    *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Regular Guests](https://xraised.com/videos_cat/regular-guests/)

    *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Artificial Intelligence](https://xraised.com/videos_cat/artificial-intelligence/)

    *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Fintech](https://xraised.com/videos_cat/fintech/)

    *   [B2B](https://xraised.com/videos_cat/b2b/)
    *   [Sustainability](https://xraised.com/videos_cat/sustainability/)
    *   [Healthcare](https://xraised.com/videos_cat/healthcare/)
    *   [Manufacturing](https://xraised.com/videos_cat/manufacturing/)
    *   [Supply Chain](https://xraised.com/videos_cat/supply-chain/)
    *   [Digitalisation](https://xraised.com/videos_cat/digitalisation/)
    *   [Real Estate](https://xraised.com/videos_cat/real-estate/)
    *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Life Coaching](https://xraised.com/videos_cat/life-coaching/)

    *   [Retail](https://xraised.com/videos_cat/retail/)
        *   [Luxury goods](https://xraised.com/videos_cat/luxury-goods/)
        *   [Fashion](https://xraised.com/videos_cat/fashion/)
        *   [Interior & Exterior 

*[... truncated, 12,031 more characters]*

---

### Phil Bouchard: Combining Modern Tech Advancement and Innovative Ideas for a Better Tomorrow
*968 words* | Source: **EXA** | [Link](https://successpitchers.com/phil-bouchard-combining-modern-tech-advancement-and-innovative-ideas-for-a-better-tomorrow/)

Many beginners to the tech sector enter with the intention of becoming a CTO and moving up to the C-suite. They might be eager to impart their knowledge and vision for the technological devices, goods, and services that their company will use and implement in the future. While achieving that goal is undoubtedly at the core of a CTO’s responsibilities, the position now entails much more. To ensure that the business becomes the catalyst for tech adoption, CTOs must demystify the topic for leaders, given how quickly technology is growing.

Founder and CTO of [****Fornux Corporation****](https://fornux.com/), ****Phil Bouchard****brings more than two decades of experience in the commercial sector for companies in San Diego, CA, and Ottawa, Canada, in the gaming, bioinformatics, automobile, and defense industries.

Over the course of his academic years, Phil focused on computer science while also studying general science. Even though he had always intended to study business management, he never had the chance because of the difficulties that innovative businesses entail and the wealth that they primarily return to their home countries in the form of credibility. Additionally, he is the author of an astrophysics book that introduces a ground-breaking new gravitational theory that can account for the universe at all scales. He also likes hockey, weightlifting, skiing, and martial arts.

****The CTO Role****

As the founder and Chief Technical Officer, Phil wrote the MVP product: Fornux C++ Superset, that fixes memory issues implicitly, the main painpoint of C++ and a big cybersecurity concern, up to this day. He also created all of the other products, such as AI Powershift, which converts Python code into C++ to drastically speed it up.

Phil also created a tool called Acumen that computes the depth perception of recognized objects in various video streams in real time. It is more efficient than all other solutions available to this day, and it is compiled using the previously mentioned two products, so it cannot be easily reverse engineered.

Furthermore, Phil penned a groundbreaking new gravitational theory called “Finite Theory” that leads to novel technologies such as antigravity, perfect cryonics, faster-than-light communication, even force fields, tractor beams, and wireless energy transfer.

Memory management consists of 70% of cybersecurity issues, and even popular browsers are affected by this issue. So, all corporations are affected by this issue. The advancements in science that Fornux is offering will create green new technologies and solve many of the present and limited energy issues we currently have. Phil states, _\_“We are offering is very innovative, so I am proud of all of them, but the ones with the buggiest potentials will definitely derive from our novel discoveries with Finite Theory.”\__

****Fornux Corporation****

The Fornux Corporation was founded in 2004 to conduct research and development on some of the most challenging scientific issues, including astrophysics and memory management in C++. The chances of failure were initially very high, but the chances of success were also very high, and all that was required to finish the tasks was time and effort.

The working method strategy was modified along the way as the scientific community’s cooperation gradually decreased as the research shifted away from accepted science. As a result, the research used the commercial alternative to come to a conclusion because the opposition to the mainstream, particularly in astrophysics, is aimed at a century of research. As far as memory management is concerned, the process has been more cooperative but nonetheless targets 60 years of computer science research and is once again against mainstream science. It is not a common research process, but now the technology is quite robust and ready to be used for various tasks in the commercial sector.

So Fornux developed a strong solution to manage memory efficiently and deterministically with Fornux C++ Superset, which has the potential to become an industry standard due to its predictability for the defense and aerospace sectors in particular.

In combination with that, the team also developed, on top of the C++ Superset, a tool that converts pure Python code into C++ code by inferring the types of the variables implicitly, making the resulting C++ code 10x faster than its original Python counterpart.

It should be noted that both software is designed to coexist in order to produce an executable that is much more efficient and predictable without requiring the existing hardware to be upgraded.

Now, in 2021, the company has turned to artificial intelligence, seeing the potential of the program combined with the advancement of technology and knowledge in various fields. In fact, Fornux has a very ambitious goal, which is the development of an artificial superintelligence (A.S.I.).

****Roles and Responsibilities that Vary****

Phil was initially the CEO of hi

*[... truncated, 1,256 more characters]*

---

### ANTIC The Atari 8-bit Podcast: ANTIC Interview 369 - Philip Bouchard, The Oregon Trail
*676 words* | Source: **EXA** | [Link](https://ataripodcast.libsyn.com/antic-interview-369-philip-bouchard-the-oregon-trail)

ANTIC The Atari 8-bit Podcast: ANTIC Interview 369 - Philip Bouchard, The Oregon Trail

===============

Toggle navigation[](https://ataripodcast.libsyn.com/ "Home Page")

*    
*   [About](https://ataripodcast.libsyn.com/about)
*   [Blog](https://ataripodcast.libsyn.com/blog)
*   [Contact](https://ataripodcast.libsyn.com/contact)
*   [Episodes](https://ataripodcast.libsyn.com/antic-interview-369-philip-bouchard-the-oregon-trail#)
    *   [All Episodes](https://ataripodcast.libsyn.com/)
    *   [Categories](https://ataripodcast.libsyn.com/antic-interview-369-philip-bouchard-the-oregon-trail#)
        *   [general](https://ataripodcast.libsyn.com/category/general)
        *   [Interview Index](https://ataripodcast.libsyn.com/category/Interview+Index)
        *   [IOS Atari Emulation Guide](https://ataripodcast.libsyn.com/category/IOS+Atari+Emulation+Guide)

    *   [Archives](https://ataripodcast.libsyn.com/antic-interview-369-philip-bouchard-the-oregon-trail#)
        *   [2025](https://ataripodcast.libsyn.com/2025)
            *   [October](https://ataripodcast.libsyn.com/2025/10)
            *   [September](https://ataripodcast.libsyn.com/2025/09)
            *   [August](https://ataripodcast.libsyn.com/2025/08)
            *   [July](https://ataripodcast.libsyn.com/2025/07)
            *   [June](https://ataripodcast.libsyn.com/2025/06)
            *   [April](https://ataripodcast.libsyn.com/2025/04)
            *   [March](https://ataripodcast.libsyn.com/2025/03)
            *   [February](https://ataripodcast.libsyn.com/2025/02)
            *   [January](https://ataripodcast.libsyn.com/2025/01)

        *   [2024](https://ataripodcast.libsyn.com/2024)
            *   [December](https://ataripodcast.libsyn.com/2024/12)
            *   [November](https://ataripodcast.libsyn.com/2024/11)
            *   [October](https://ataripodcast.libsyn.com/2024/10)
            *   [September](https://ataripodcast.libsyn.com/2024/09)
            *   [July](https://ataripodcast.libsyn.com/2024/07)
            *   [June](https://ataripodcast.libsyn.com/2024/06)
            *   [May](https://ataripodcast.libsyn.com/2024/05)
            *   [April](https://ataripodcast.libsyn.com/2024/04)
            *   [March](https://ataripodcast.libsyn.com/2024/03)
            *   [February](https://ataripodcast.libsyn.com/2024/02)
            *   [January](https://ataripodcast.libsyn.com/2024/01)

        *   [2023](https://ataripodcast.libsyn.com/2023)
            *   [December](https://ataripodcast.libsyn.com/2023/12)
            *   [November](https://ataripodcast.libsyn.com/2023/11)
            *   [October](https://ataripodcast.libsyn.com/2023/10)
            *   [September](https://ataripodcast.libsyn.com/2023/09)
            *   [August](https://ataripodcast.libsyn.com/2023/08)
            *   [June](https://ataripodcast.libsyn.com/2023/06)
            *   [May](https://ataripodcast.libsyn.com/2023/05)
            *   [April](https://ataripodcast.libsyn.com/2023/04)
            *   [February](https://ataripodcast.libsyn.com/2023/02)
            *   [January](https://ataripodcast.libsyn.com/2023/01)

        *   [2022](https://ataripodcast.libsyn.com/2022)
            *   [December](https://ataripodcast.libsyn.com/2022/12)
            *   [November](https://ataripodcast.libsyn.com/2022/11)
            *   [October](https://ataripodcast.libsyn.com/2022/10)
            *   [August](https://ataripodcast.libsyn.com/2022/08)
            *   [June](https://ataripodcast.libsyn.com/2022/06)
            *   [May](https://ataripodcast.libsyn.com/2022/05)
            *   [April](https://ataripodcast.libsyn.com/2022/04)
            *   [March](https://ataripodcast.libsyn.com/2022/03)
            *   [January](https://ataripodcast.libsyn.com/2022/01)

        *   [2021](https://ataripodcast.libsyn.com/2021)
            *   [December](https://ataripodcast.libsyn.com/2021/12)
            *   [October](https://ataripodcast.libsyn.com/2021/10)
            *   [September](https://ataripodcast.libsyn.com/2021/09)
            *   [August](https://ataripodcast.libsyn.com/2021/08)
            *   [July](https://ataripodcast.libsyn.com/2021/07)
            *   [June](https://ataripodcast.libsyn.com/2021/06)
            *   [May](https://ataripodcast.libsyn.com/2021/05)
            *   [April](https://ataripodcast.libsyn.com/2021/04)
            *   [March](https://ataripodcast.libsyn.com/2021/03)
            *   [February](https://ataripodcast.libsyn.com/2021/02)
            *   [January](https://ataripodcast.libsyn.com/2021/01)

        *   [2020](https://ataripodcast.libsyn.com/2020)
            *   [December](https://ataripodcast.libsyn.com/2020/12)
            *   [November](https://ataripodcast.libsyn.com/2020/11)
            *   [October](https://ataripodcast.libsyn.com/2020/10)
            *   [September](https://ataripodcast.libsyn.com/2020/09)
            *   [August](https://ataripodcast.libsyn.com/2020/08)
            *   [July](https://at

*[... truncated, 9,740 more characters]*

---

### We Are All About RESEARCH and INNOVATION
*273 words* | Source: **EXA** | [Link](https://static.fornux.com/)

![Image 1](https://static.fornux.com/wp-content/uploads/2023/06/new-about.png)

![Image 2](https://static.fornux.com/wp-content/uploads/2023/06/Ban-ai-1024x789.png)

Fornux Corporation began in 2004 in a research and development effort to target the most difficult problems in science such as memory management in C ++ and astrophysics. The chances of not succeeding were initially very high, but the convictions were also very high, and only time and effort was needed to complete the tasks.

So Fornux came up with a strong solution to manage the memory efficiently and in a deterministic way with Fornux C++ Superset, that can easily become an industry standard given its predictability for the defense and aerospace sectors mostly. In combination with that we also developed on top of the C++ Superset, a tool that converts pure Python code into C++ code by inferring the types of the variables implicitly, making the resulting C++ code 10x faster than its original Python counterpart. Not to mention an efficient depth perception tool and positive research in antigravity.

![Image 3](https://static.fornux.com/wp-content/uploads/2023/06/Products.jpg)

![Image 4](https://static.fornux.com/wp-content/uploads/2023/06/96.gif)

###### REVIEWS

The Silicon Reviews
-------------------

![Image 5](https://static.fornux.com/wp-content/uploads/2023/06/96.gif)

###### REVIEWS

The Silicon Reviews
-------------------

[![Image 6](https://static.fornux.com/wp-content/uploads/2023/06/Reviews.png)](https://www.analyticsinsight.net/phil-bouchard-transforming-the-research-and-development-industry-with-innovative-ai-solutions/)

![Image 7](https://static.fornux.com/wp-content/uploads/2023/06/Rewards.jpg)

![Image 8](https://static.fornux.com/wp-content/uploads/2023/06/Scientific11.jpg)

Scientific Research

Astrophysics Research

Finite Theory: new gravitational theory already tested multiple times with simple thought experiments and also ready to be tested again aboard the International Space Station.

![Image 9](https://static.fornux.com/wp-content/uploads/2023/06/85.jpg)

Collaboration
-------------

[![Image 10](https://static.fornux.com/wp-content/uploads/2023/06/365.png)](https://www.altpropulsion.com/)
[![Image 11: Follow Phil Bouchard on F6S](https://www.f6s.com/images/f6s-follow-secondary.png)](https://www.f6s.com/member/philbouchard?follow=1 "Follow Phil Bouchard on F6S")

![Image 12](https://static.fornux.com/wp-content/uploads/2023/06/AKtAwa.gif)

Gravitational Theory
--------------------

The theory has been debated for 10 years online against 100s of physicists. I also propose an experiment aboard the ISS to prove its validity and which consists of a simple wavelength meter measuring a laser in all 90 degrees angles.

![Image 13](https://static.fornux.com/wp-content/uploads/2023/06/form.jpg)

---

### Pioneering Sustainability: An Interview with ESG Global Tech Fund’s Philipe Evangelou
*955 words* | Source: **EXA** | [Link](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/)

Pioneering Sustainability: An Interview with ESG Global Tech Fund’s Philipe Evangelou - xraised

===============

[![Image 1](https://xraised.com/wp-content/uploads/2023/02/logo-xraised-300x77.png)](https://xraised.com/)

*   [Home](https://xraised.com/)
*   [Interviews](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/#)
    *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Regular Guests](https://xraised.com/videos_cat/regular-guests/)

    *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Artificial Intelligence](https://xraised.com/videos_cat/artificial-intelligence/)

    *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Fintech](https://xraised.com/videos_cat/fintech/)

    *   [B2B](https://xraised.com/videos_cat/b2b/)
    *   [Sustainability](https://xraised.com/videos_cat/sustainability/)
    *   [Healthcare](https://xraised.com/videos_cat/healthcare/)
    *   [Manufacturing](https://xraised.com/videos_cat/manufacturing/)
    *   [Supply Chain](https://xraised.com/videos_cat/supply-chain/)
    *   [Digitalisation](https://xraised.com/videos_cat/digitalisation/)
    *   [Real Estate](https://xraised.com/videos_cat/real-estate/)
    *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Life Coaching](https://xraised.com/videos_cat/life-coaching/)

    *   [Retail](https://xraised.com/videos_cat/retail/)
        *   [Luxury goods](https://xraised.com/videos_cat/luxury-goods/)
        *   [Fashion](https://xraised.com/videos_cat/fashion/)
        *   [Interior & Exterior Desing](https://xraised.com/videos_cat/interior-exterior-desing/)

*   [SEO Services](https://xraised.com/seo-articles/)
*   [Prospecting](https://xraised.com/lead-generation/)
*   [About Us](https://xraised.com/about-us/)
    *   [About Us](https://xraised.com/about-us/)
    *   [Contact Us](https://xraised.com/contact/)

*   [News](https://xraised.com/blog/)
*   [Spotify](https://open.spotify.com/show/7etNTKOaQFx7Uchomgh12N?si=0cae6466efc64e09&nd=1&dlsi=af4eb318137748e1)
*   [Amazon Music](https://music.amazon.com/podcasts/04efeb4a-c716-440b-a935-0a38ad4e868f/xraised)

Please enter keywords

![Image 2: usd_img](https://xraised.com/wp-content/uploads/2023/02/earch.svg)EN

[JP](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/#)

[FR](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/#)

[](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/#)

[![Image 3](https://xraised.com/wp-content/uploads/2023/02/logo-xraised-300x77.png)](https://xraised.com/)

Please enter keywords

*   [Home](https://xraised.com/)
*   [Interviews](https://xraised.com/videos/pioneering-sustainability-an-interview-with-esg-global-tech-funds-philipe-evangelou/#)
    *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Recommended by us](https://xraised.com/videos_cat/recommended-by-us/)
        *   [Regular Guests](https://xraised.com/videos_cat/regular-guests/)

    *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Tech](https://xraised.com/videos_cat/tech/)
        *   [Artificial Intelligence](https://xraised.com/videos_cat/artificial-intelligence/)

    *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Financial Services](https://xraised.com/videos_cat/financial-services/)
        *   [Fintech](https://xraised.com/videos_cat/fintech/)

    *   [B2B](https://xraised.com/videos_cat/b2b/)
    *   [Sustainability](https://xraised.com/videos_cat/sustainability/)
    *   [Healthcare](https://xraised.com/videos_cat/healthcare/)
    *   [Manufacturing](https://xraised.com/videos_cat/manufacturing/)
    *   [Supply Chain](https://xraised.com/videos_cat/supply-chain/)
    *   [Digitalisation](https://xraised.com/videos_cat/digitalisation/)
    *   [Real Estate](https://xraised.com/videos_cat/real-estate/)
    *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Consulting](https://xraised.com/videos_cat/consulting/)
        *   [Life Coaching](https://xraised.com/videos_cat/life-coaching/)

    *   [Retail](https://xraised.com/videos_cat/retail/)
        *   [Luxury goods](https://xraised.com/videos_cat/luxury-goods/)
        *   [Fashion](https://xraised.com/videos_cat/fashion/)
        *   [Interior & Exterior Desing](https://xraised.com/videos_cat/interior-exterior-desing/)

*   [SEO Services](https://xraised.com/seo-article

*[... truncated, 11,673 more characters]*

---

### 1StartupWorld Conference
*2,854 words* | Source: **GOOGLE** | [Link](https://1businessworld.com/1startupworld-conference/)

1StartupWorld Conference | 1BusinessWorld

===============

Manage Consent

To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.

Functional- [x] Functional  Always active 

The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network.

Preferences- [x] Preferences 

The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user.

Statistics- [x] Statistics 

The technical storage or access that is used exclusively for statistical purposes.The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you.

Marketing- [x] Marketing 

The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes.

*   [Manage options](https://1businessworld.com/1startupworld-conference/#)
*   [Manage services](https://1businessworld.com/1startupworld-conference/#)
*   [Manage {vendor_count} vendors](https://1businessworld.com/1startupworld-conference/#)
*   [Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

Accept Deny View preferences Save preferences[View preferences](https://1businessworld.com/1startupworld-conference/#)

*   [{title}](https://1businessworld.com/1startupworld-conference/#)
*   [{title}](https://1businessworld.com/1startupworld-conference/#)
*   [{title}](https://1businessworld.com/1startupworld-conference/#)

Manage Consent

To provide the best experiences, we use technologies like cookies to store and/or access device information. Consenting to these technologies will allow us to process data such as browsing behavior or unique IDs on this site. Not consenting or withdrawing consent, may adversely affect certain features and functions.

Functional- [x] Functional  Always active 

The technical storage or access is strictly necessary for the legitimate purpose of enabling the use of a specific service explicitly requested by the subscriber or user, or for the sole purpose of carrying out the transmission of a communication over an electronic communications network.

Preferences- [x] Preferences 

The technical storage or access is necessary for the legitimate purpose of storing preferences that are not requested by the subscriber or user.

Statistics- [x] Statistics 

The technical storage or access that is used exclusively for statistical purposes.The technical storage or access that is used exclusively for anonymous statistical purposes. Without a subpoena, voluntary compliance on the part of your Internet Service Provider, or additional records from a third party, information stored or retrieved for this purpose alone cannot usually be used to identify you.

Marketing- [x] Marketing 

The technical storage or access is required to create user profiles to send advertising, or to track the user on a website or across several websites for similar marketing purposes.

*   [Manage options](https://1businessworld.com/legal-hub/opt-out-preferences/#cmplz-manage-consent-container)
*   [Manage services](https://1businessworld.com/legal-hub/opt-out-preferences/#cmplz-cookies-overview)
*   [Manage {vendor_count} vendors](https://1businessworld.com/legal-hub/opt-out-preferences/#cmplz-tcf-wrapper)
*   [Read more about these purposes](https://cookiedatabase.org/tcf/purposes/)

Accept Deny View preferences Save preferences[View preferences](https://1businessworld.com/legal-hub/opt-out-preferences/#cmplz-manage-consent-container)

*   [Opt-out preferences](https://1businessworld.com/legal-hub/opt-out-preferences/)
*   [Privacy Statement](https://1businessworld.com/legal-hub/privacy-statement-us/)
*   [Imprint](https://1businessworld.com/legal-hub/imprint/)

**Already have an account?**

[Sign in](https://1businessworld.com/my-account)

* * *

**New to 1BusinessWorld?**

[Create an account](https://1businessworld.com/my-account)

[Skip to navigation](https://1businessworld.com/1startupworld-conference/#site-navigation)[Skip to content](https://1businessworld.com/1startupworld-conference/#content)

[1BusinessWorld](https://1businessworld.com/)

Search for: Search

[](https://1businessworld.com/events/)

[](https://1businessworld.com/my-account)

[](https://1businessworl

*[... truncated, 25,464 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[1StartupWorld Conference | 1BusinessWorld](https://1businessworld.com/1startupworld-conference/)**
  - Source: 1businessworld.com
  - *Join the 2024 1StartupWorld Conference to access the conference lobby and the live sessions. ... Fornux Corporation | Phil Bouchard. Play Video. Fundr...*

---

*Generated by Founder Scraper*
