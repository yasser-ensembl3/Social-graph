# Adel Abusitta

## Position actuelle

**Titre** : Founder and Director of the Security and Trustworthy AI (STAI) Lab
**Entreprise** : Polytechnique Montréal
**Durée dans le rôle** : 2 years 3 months in role
**Durée dans l'entreprise** : 2 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Higher Education

## Résumé

I am a Professor of Cybersecurity and AI in the Department of Computer and Software Engineering at Polytechnique Montréal (Université de Montréal). I lead the Security and Trustworthy AI (STAI) Lab, which focuses on advancing artificial intelligence to enhance intelligent threat analysis and on designing robust, trustworthy AI models that are resistant to adversarial and AI-powered attacks.

My research spans adversarial machine learning, federated and multi-agent learning, game-theoretic trust modeling, and privacy-enhancing technologies. I aim to build AI systems that are not only intelligent but also secure, interpretable, and aligned with ethical and regulatory standards.

I actively collaborate with leading institutions and organizations, including—but not limited to—the Multidisciplinary Institute for Cybersecurity and Cyber-Resilience (IMC²) and IVADO, to bridge academic innovation with real-world impact.

I am passionate about training the next generation of leaders, researchers, and engineers, fostering interdisciplinary collaboration, and driving innovation in secure and trustworthy AI to address the evolving challenges of the digital era.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABL3bAgB3H5ULHEo5AXMQGdlyC36ZOkmzdE/
**Connexions partagées** : 1


---

# Adel Abusitta

## Position actuelle

**Entreprise** : Polytechnique Montréal

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Adel Abusitta
*Polytechnique Montréal*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Abusitta, Adel](https://www.polymtl.ca/expertises/en/abusitta-adel)
*2025-04-23*
- Category: article

### [Adel Abusitta - Profile on Academia.edu](https://mcgill.academia.edu/AdelAbusitta)
*2024-09-02*
- Category: article

### [School of Computer Science Colloquium Presentation by Dr. Adel Abusitta:"AI for Cybersecurity: Building Robust and Sustainable Malware Detection and Classification System”](https://www.uwindsor.ca/science/computerscience/201529/school-computer-science-colloquium-presentation-dr-adel-abusitta%E2%80%9Dai-cybersecurity-building)
*2023-03-17*
- Category: article

### [Directory of Experts](https://www.polymtl.ca/expertises/en/recherche/expertises/intelligence%20artificielle)
*2025-01-01*
- Category: article

### [Hanes: Polytechnique’s new tech institute ‘will change the lives of possibly millions, possibly billions’](https://www.montrealgazette.com/opinion/columnists/article816070.html)
*2025-03-17*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[‪Adel Abusitta‬ - ‪Google Scholar‬](https://scholar.google.com/citations?user=BiKkFU8AAAAJ&hl=en)**
  - Source: scholar.google.com
  - *Adel Abusitta. Polytechnique Montréal. Verified email at polymtl.ca. Secure and ... 2022 International Joint Conference on Neural Networks (IJCNN), 1-...*

- **[Abusitta, Adel | Directory of Experts](https://www.polymtl.ca/expertises/en/abusitta-adel)**
  - Source: polymtl.ca
  - *Adel Abusitta. PhD (Polytechnique Montreal), Post-Doc. (University of ... Expert Systems With Applications, 255, 124710 (18 pages). Conference paper....*

- **[Adel Abusitta (37)](https://www.polymtl.ca/expertises/abusitta-adel/publications)**
  - Source: polymtl.ca
  - *© Polytechnique Montréal 2025. Répertoire des expertises. Abusitta, Adel. Poly ... Adel Abusitta (37). Articles de revue (14). 2024. Article de revue....*

- **[(PDF) Deep Learning-Enabled Anomaly Detection for IoT Systems](https://www.researchgate.net/publication/365232074_Deep_Learning-Enabled_Anomaly_Detection_for_IoT_Systems)**
  - Source: researchgate.net
  - *Aug 7, 2025 ... ... Adel Abusitta at Polytechnique Montréal. Adel Abusitta · Polytechnique ... Conference Paper. Full-text available. A PCA-based meth...*

- **[An extensive network of multidisciplinary expertise in cybersecurity ...](https://i-mc2.ca/en/the-institute/our-team/)**
  - Source: i-mc2.ca
  - *Adel Abusitta. Assistant Professor in the Department of Computer Engineering and Software Engineering. Polytechnique Montréal. See details. Dr. Adel A...*

- **[Malware classification and composition analysis: A survey of recent ...](https://www.researchgate.net/publication/351248310_Malware_classification_and_composition_analysis_A_survey_of_recent_developments)**
  - Source: researchgate.net
  - *Adel Abusitta at Polytechnique Montréal · Adel Abusitta · Polytechnique Montréal ... Conference Paper. Sep 2025. Hassan Rehan · Goutham Sunkara · Venu...*

- **[Agentic AI for Stream and Service-based Systems (AA2S) – AICCSA ...](https://conferences.sigappfr.org/aiccsa2025/agentic-ai-for-stream-and-service-based-systems-aa2s/)**
  - Source: conferences.sigappfr.org
  - *The submission and review process for this Special Track will be managed through the EasyChair conference system. ... Adel Abusitta, Polytechnique Mon...*

- **[Detecting Poisoning Attacks in Collaborative IDSs of Vehicular ...](https://dl.acm.org/doi/abs/10.1145/3696462)**
  - Source: dl.acm.org
  - *Adel Abusitta. Adel Abusitta. Department of Computer Engineering and Software Engineering, Polytechnique Montréal, Montreal, Canada ... Conference on ...*

- **[Talal Halabi (0000-0002-1922-5803) - ORCID](https://orcid.org/0000-0002-1922-5803)**
  - Source: orcid.org
  - *I have a PhD in Computer Engineering from Polytechnique Montréal (University of Montreal). ... : Ahmed Saleh Bataineh; Mohammad Zulkernine; Adel Abusi...*

- **[Deep Learning-Enabled Anomaly Detection for IoT Systems by Adel ...](https://papers.ssrn.com/sol3/papers.cfm?abstract_id=4258930)**
  - Source: papers.ssrn.com
  - *Nov 7, 2022 ... ... article. A ... Adel Abusitta. University of Windsor. Glaucio Haroldo Silva de Carvalho. Brock University. Omar Abdel Wahab. Polyte...*

---

*Generated by Founder Scraper*
