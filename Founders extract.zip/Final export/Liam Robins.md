# Liam Robins

## Position actuelle

**Titre** : Founder
**Entreprise** : Hyrus
**Durée dans le rôle** : 1 year 1 month in role
**Durée dans l'entreprise** : 1 year 1 month in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Description du rôle

Hyrus is a done for you content department.
We make brands look and feel like they have a full team, without the hires.
First drop in 2 days. Weekly after that.

Platforms we specialize in
• Instagram
• X
• LinkedIn
• Article copy for your site or newsletter

What we deliver
• Volume every week so you stay seen
• Posts placed where they perform
• Clear words and hooks that drive action
• Videos that stop the scroll
• Motion that shows your product
• Edits that feel on brand
• Sizes for each channel
• Clean images
• Captions ready for ads and social

Creative types
• Ongoing content for social and site
• Ad creatives for paid campaigns
• Drop campaigns with timed releases and assets

Who we serve
Luxury, finance, e commerce, and real estate brands that want big team output without big team cost or chaos.

How we work

Brand and competitor teardown to find angles and look

30 day content map tied to goals and channels

Weekly sprints, quality control, on time delivery

Fast notes in Frame.io, minor edits in 48 to 72 hours

Keep what wins and scale it

Proof
• Over 1,000 assets shipped
• Over 10 million organic views
• First cut approval above 90 percent
• Full commercial use

Plans
• 2 Day Sprint. One time, fast output
• Department Lite. 20 plus assets per month
• Department Pro. 40 plus assets per month
Add ons available. Voiceover, paid ads variants, UGC sourcing

## Résumé

For years, only big brands could afford cinematic campaigns that made them and their products feel untouchable.
I changed that.

What I do
I create premium Ai videos that help direct to consumer brands increase recurring sales, conversions, all while looking world-class, at a fraction of the usual cost.

The result
Up to 99% savings in production costs
450+ total premium assets produced
120+ premium Ai videos made
2-3x conversion rate increase
1M+ views across campaigns
Over $5M saved for clients
2-3x average LTV increase

Why it matters
Your content should make people stop, stare, and talk.
Your brand should feel like it belongs on global screens.

If you’re a founder looking to bring in recurring sales, while looking world-class, using premium Ai videos, let’s connect. I’m always open to chat about how I can help.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAFPRzmgB5J5FOrYpcLDxnA9UJ1UHd13QB2o/
**Connexions partagées** : 1


---

# Liam Robins

## Position actuelle

**Entreprise** : Hyrus

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Liam Robins

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402724508194729985 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGnHbwVyHFITA/image-shrink_800/B4EZrvCrFcGcAg-/0/1764947047790?e=1765785600&v=beta&t=UZHnEK-f9GNBLZhX-p9BBQB_iE63Mmn-S4QPfsL81v8 | Most people write prompts like:
“cool vibe,”
“soft light,”
“cinematic portrait,”
“make it aesthetic.”

None of that is direction.
Those are adjectives.
Adjectives don’t build visuals.

Direction looks like:
• “soft side light from the left”
• “35mm focal length”
• “matte skin texture with micro-shadows”
• “neutral beige palette”
• “subject centered with a shallow depth of field”
• “editorial minimalism”

When your prompts look like this,
AI finally understands the visual logic, not just the concept.

The goal isn’t to write more.
The goal is to write clearly.

Describe the physics, the mood, the behavior of light,
and you’ll stop getting random chaos.

Save this to stop producing slop. | 6 | 0 | 0 | 2d | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:14.188Z |  | 2025-12-05T15:04:18.724Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402449281963479040 | Document |  |  | Hot take: Its your fault Ai is slop.

"Make it pop"

AI only knows what you tell it,
and when you leave out the key details,
it fills the gaps with defaults.

And defaults always look:
• generic
• flat
• plastic
• visually cheap

Here’s how you fix it:

Use the 7 elements that every high-quality prompt includes:

1) Subject & Detail
Define what the image should be, not what you hope it becomes.

2) Materials & Textures
This is what makes AI outputs feel physical instead of synthetic.

3) Composition & Framing
Camera angle, lens type, focal length; this is the “director” part.

4) Lighting
Soft?
Hard?
Backlit?
Rim-lit?
Lighting is the #1 lever for quality.

5) Style & Realism
Cinematic,
editorial,
minimalist,
photoreal

Give AI a visual world to pull from.

6) Background
Clean?
Textured?
Studio?
Natural?
The background defines the aesthetic.

7) Technical Elements
Aperture,
detail level,
resolution cues.

These are the finishing moves.

The more direction you give,
the less AI has to guess.

And the less it guesses,
the more the output reflects your vision.

Save this if you want your prompts to finally produce visuals you’re proud of. | 3 | 1 | 1 | 3d | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:14.189Z |  | 2025-12-04T20:50:39.677Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402058214768340992 | Document |  |  | Your Ai image looks random because you’re skipping one crucial step:

You need references.

Most founders jump straight into prompting.
No feeling.
No direction.
No reference.

Just "Make an image of a cyclist wearing sun glasses"

Ai is too literal for that.

If your input is random, your output has to be random.

Here’s the fix:

1) Start with the feeling.
Not the prompt; the emotion you want the viewer to feel.

So instead of saying:
"Make me an image of a cyclist"

Say instead:

"Create professional cycling photography THAT CAPTURES both athletic performance and style, utilizing consistent visual aesthetics through style reference techniques.
FOCUS on the intersection of sport and fashion, highlighting technical gear while maintaining editorial quality.
Compositions SHOULD EMPHASIZE the athlete's focus and determination while showcasing equipment design and aerodynamic forms.
Lighting SHOULD CREATE dramatic effects that enhance both the human element and technical equipment.
The imagery SHOULD APPEAL to both serious cyclists and lifestyle audiences, balancing performance credibility with visual sophistication."

Same instructions, vastly different results.

2) Collect 3–5 references images.

Most people assume the Ai knows what you're thinking about.

You need a taste library to show your vision to the Ai.

Pinterest,
Midjourney,
other brands you like,

The more references you show, the more it'll understand.

3) Pick one palette + one lighting style.

Most people assume the ai will produce the same exact style when prompting

And they wonder why they always come out random.

You don't specify what you want each time.

Don't say:
"Cinematic lighting"

Say:
"Professional studio lighting creating strong contrast with bright key light from
camera right. Rim lighting highlighting helmet edges and jersey contours."

Once you have:
- Proper instructions,
- Proper references,
You get consistency.

Consistency is what makes visuals feel premium.

4) Lock your composition.

Most people get vague images because they forget to include what made thier image great.

Center?
Rule-of-thirds?
Symmetry?

Pick one.
And include it in all your prompts.

Once you have that, you get consistent generations.

5) Direct the image, don’t hope for it.

AI reflects your clarity, not your creativity.

Know the terminology
Know the vocabulary

Assume you're talking to an intern.
The clearer you are, the better the results.

This is the blueprint every founder needs if they want their visuals to stop feeling chaotic and start feeling intentional.

Save this so you never create “random" visuals again. | 2 | 0 | 0 | 4d | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:14.190Z |  | 2025-12-03T18:56:41.992Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399522951579987968 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGC-7TSTBFxqQ/image-shrink_800/B4EZrBi37kIIAg-/0/1764183736806?e=1765785600&v=beta&t=4-P-WEcr_UKxRHUuGB2BJUR_ww14O0erJ0-6FyiIC5c | He was doing everything himself.
Burnt out, exhausted, ready to throw in the towel...

6 months later, he's being called:
“One of the fastest-rising brands in his niche.”

Here’s exactly how we used Ai to help him go from DIY hustle to brand standout:

1/ We defined what it meant to be #1

His space? Instagram-heavy.

We looked at what others were doing:

2x product animations
3x product shots
3x athlete features
2x a week

We learned two things:
- Be consistent
- Do more

So we used AI tools to create:

4x product animations
4x product shots
4x athlete features
3x a week

The best part?
No one could tell it was Ai.

6 months later:

Podcast invites
Magazine features
Stores reaching out

He didn’t grow because he had more money.
He grew because he understood what mattered most to his audience.

2/ The vision came first...not the product

Everyone in his space talked about “high quality.”
But when we asked customers why they actually bought his stuff?

They said:

“It tastes good.”
“I believe in what the brand stands for.”

So we made sure every video,
Whether it was a teaser or a promo,
Told the same story:

Ruthless greatness in all areas of life.

Not just the product.
The mission.

That changed everything.

People didn’t just buy to try.
They bought to support.

Because when you sell a vision, you don’t get customers,
You get believers.

3/ When others zig, zag hard

Most brands in this niche sound the same:

Gym hype videos with loud music
Reposted reviews

That worked back in 2015.
Not today.

His brand had an edge.
Instead of softening it, we doubled down.

Every post.
Every video.
Every frame.
All built with a sharp, bold energy.

Result?

His content stood out.
His brand sparked real conversation.
Retention doubled.

No paid ads needed.
Just brand resonance doing the heavy lifting.

These 3 steps aren’t magic.

They’re simple.
Repeatable.
And you can start today, with tools already at your fingertips.

Most brands wait years.
He moved in one week.

Because today, how you show up matters more than how long you’ve been around.

It doesn’t take millions.

It takes clarity,
consistency,
and the courage to be different. | 1 | 0 | 0 | 1w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:14.191Z |  | 2025-11-26T19:02:28.145Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7399160537634480128 | Text |  |  | The hardest decision I ever made was choosing to do less.

For months, I buried myself in client work.

To me, busy meant safe.

Full calendar meant valuable.

If I was constantly in motion, I couldn't be questioned.

But here's what I wouldn't admit: I was hiding.

Because I was terrified of what an empty calendar would expose about me.

I kept telling myself, "If you're as good as you say you are, why aren't you being successful on the very first go?"

The irony?

That's the exact fear I coached my clients through every single day.

I'd tell them: 

- the game is iteration.
- Keep doing until something works.

But I couldn't give myself that same grace.

So I constrained my work.

I freed up my calendar.

And then I sat in it.

That empty void.

That vast, uncomfortable space forcing me to confront what I'd been avoiding.

It was inevitable, but I'd run from it for so long.

I reached out for help.

To someone who was already doing what I was trying to figure out.

And that first move?

It showed me how much I didn't know.

He was running his business, solving the thing I was stuck on, doing it successfully while I was spinning in place.

That moment made me realize: if I kept doing it alone, I'd either never get there or it would take 10x longer.

The next step illuminated.

Not because I had it all figured out.

But because I was finally willing to look at my faults.

To ask, "Okay, what's the next move?"

To fail.

To iterate.

To learn that the entire game is iterations until it works.

Not perfection on the first crack.

Not a viral strategy that saves me from the work.

Just reps.

Maybe you've been here too.

Telling yourself that staying busy protects you from being exposed.

But the truth is, busy work doesn't build your business.

It protects your ego.

The moment you stop hiding is the moment everything becomes possible. | 0 | 0 | 0 | 1w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:14.192Z |  | 2025-11-25T19:02:21.927Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396252513081085952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a11534ad-9cc0-44d2-bc40-00e6252923d0 | https://media.licdn.com/dms/image/v2/D4E05AQHXH9eltZZdpw/videocover-low/B4EZqTEbieHcCE-/0/1763404006961?e=1765785600&v=beta&t=G5dVP0mJmJDqmoemRt3ah58E2bEKHxKikUlviPaP7qw | 76k views

13k likes

1000+ reposts

1000+ shares

1000+ saves 

All with one AI-generated video.

Here's how I did it in 4 steps

(without creating generic slop):

---

1/ I maintained the authentic structure

Most people slap AI together and call it content.

I didn't do that.

I used a reference video and kept the original shot sequence and sound effects intact. 

The only difference? 

I generated the visuals with AI.

This gave me a blueprint to study. 

---

2/ I used strategic AI generation

I didn't just type "make a cool racing video."

I learned the language: 

"close up angle of driver racing through stormy rain over the mountains, visible water marks on camera lens from rain, driver navigating through chaos to survive the race."

That level of direction changes everything.

I used Hailuo AI with start and end frames to generate 6-second clips. 

Then I made a choice: 

1. Use the full clip if it came out clean, or
2. Pull specific partial footage for shots under a second.

The output quality comes from the precision of your prompts.

---

3/ I kept the editing subtle in CapCut

Here's where most people lose the plot.

They get fancy. 

They add transitions, effects and overlays to show off their editing skills.

This kills the emotional pull.

I edited just enough to remove AI traces. 

Nothing more. 

No clever tricks. 

No distractions.

Too much polish makes people focus on the production instead of the story.

---

4/ I focused on emotion over tech

I was transparent about using AI in the caption.

But the video itself? 

It had to pull you in emotionally first.

The goal wasn't to showcase the tool. 

It was to prove I'm not limited by the tool.

When you prioritize the feeling over the flex, people stop caring how it was made…

They just care that it moved them.

---

These aren't complicated strategies.

Anyone can do them.

But when you combine them...

That's how you go from: 

- struggling with expensive production
- wrestling with long timelines
- hating generic Ai outputs

To viral engagement that doesn't feel like AI slop…

In 1 day of focused work.

Working on an ad campaign video and want to see how this could work for you?
Send me a DM, and I'll give you a free guide on how to prompt these videos for yourself. | 27 | 18 | 0 | 2w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:19.996Z |  | 2025-11-17T18:26:54.845Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394416881123610624 | Text |  |  | How I can tell you’re using AI in your videos every time:

You wrote a one-sentence prompt, and hit upload.

No editing. No iteration. No soul.

That’s not premium content.

That’s AI slop.

And your audience can tell.

Here’s what lazy AI creation looks like:


1. You rely on Veo 3 defaults.

Veo 3 is powerful, but surface-level prompts create surface-level videos.

If you’re not iterating, directing camera angles, and refining scenes until they feel real, you’re not creating; you’re delegating to a machine.


2. Your voiceover is generic.

Using AI to clone your voice is smart.

But use your own tone, cadence, and delivery.

It shows care. It makes people listen.


3. Your visuals have no originality.

Accepting the first draft kills your brand’s credibility.

It screams “convenience over craft.”

And that reputation sticks.

There’s nothing wrong with using AI to produce premium content.

But it has to feel intentional. Authentic. Directed.


Here’s how to actually use AI like a creative:

Define the emotion and action you want your viewer to take.

Use AI to rough out the idea, not finalize it.

Communicate like a director, not a consumer.

Refine, cut, rearrange, and polish until it feels human.


Premium AI video isn’t about tools.

It’s about taste. | 2 | 1 | 0 | 3w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:19.997Z |  | 2025-11-12T16:52:46.082Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394061236964839424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHvqklSNMNBrA/feedshare-shrink_800/B4EZpz7gBTHEAg-/0/1762881572377?e=1766620800&v=beta&t=z6Uir5GunetOfsE01GveyANV8ThIuumbjzTNxFLpdIA | Every October for the last four years has tested how badly I wanted this dream.

October 2022: 
Lost everything after graduating. 
First partnership collapsed. 
Working 4 AM airport shifts just to pay bills.

October 2023: 
Knocking on doors in a province where I barely spoke the language. Built a sales team anyway. 
Moved into B2B to learn a new world. Then my car broke down. Waiting for the next job to hire and pay me before rent was due. Unsure if I’d make it.

October 2024: 
Left that job in May to build what I thought would be my forever business. By October, I sold my share to avoid bankruptcy. Walked away with $50 to my name.

And now, October 2025: My biggest struggle wasn’t rent or bills. It’s random strangers hating on a viral video I made with AI.

But that hate? It’s proof I’m exactly where I need to be.

Each October came with its own storm. Each time, I thought it was the one that would break me. But it didn’t.

Because every October, no matter how uncertain or heavy, I refused to quit. 
I refused to let go of the vision.
 And now, the problems I have are the ones I used to dream about.

The lesson? If your dream keeps testing you, it’s because you’re getting closer. 

You’re just in an October. And Octobers pass. | 10 | 3 | 0 | 3w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:19.998Z |  | 2025-11-11T17:19:33.907Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7393674765837758464 | Text |  |  | Why your AI videos look obviously AI 
(while top brands in your niche are doing it 10x better).

It’s not about ease of execution.
It’s about how you communicate with the tools.

After studying 50+ AI campaigns across 10 industries, these 3 elements actually matter:


1. Iteration over gambling

Most users write one prompt and hope for perfection. 
That’s not how it works.

Premium AI content takes hundreds, 
sometimes thousands, of iterations.
You’re not gambling. 
You’re refining until it matches your vision.


2. Specialized tools over one-size-fits-all platforms

Everyone defaults to ChatGPT because it’s familiar.
But you wouldn’t film a Hollywood scene on an iPhone.
You’d use gear built for that purpose.
Same principle here.

Need premium transitions? Use Kling.
Need multiple angles of a product? Use Hailuo or Higgsfield.
The tool defines the quality.


3. Post-production to remove “AI” artifacts

Generation is only the rough draft.
Now you edit out everything that screams “AI.”
That plastic skin texture? Replace “clear skin” with “matte texture.”
Refine terminology across every frame.

In practice:
Generate the rough vision.
Refine with specialized tools.
Edit until nothing feels artificial.
Premium AI videos use all three.
AI slop videos miss at least one.

Key insight:
Top brands treat AI like a production assistant, not a finished product.
They iterate relentlessly, use advanced tools, and polish their edits just like traditional productions.

The edge is speed and cost, not quality. | 3 | 2 | 0 | 3w | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:19.999Z |  | 2025-11-10T15:43:52.010Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7392649322284331008 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHfufjw-1V_NA/feedshare-shrink_800/B4EZpf3YZ3GUAg-/0/1762544945568?e=1766620800&v=beta&t=bW2yC0je3w1H3e6f-wT-h-k8zK_VohH5Dq8rci8S2Cw | 2024: Ready to give up on content.
2025: Quoted “one of the country’s most talked about brands” on a podcast in his niche.
Here were the 3 things my client did right that got him to that point:



1. He treated brand-building like investing, not gambling


Most owners want instant ROI.
They post once, panic when it flops, then quit.

He played the long game.
He stayed consistent, patient, and focused on building something people actually care about.

That mindset alone put him ahead of 90% of his competitors.



2. He focused on emotional impact, not view count


We didn’t chase virality. 
We aimed to make people feel something.

Each video had one purpose: communicate the brand’s vision so the right audience stopped scrolling.

Product animations, athlete promos, content that looked like million-dollar productions.

The goal wasn’t reach, it was resonance;
Who shared it. 
Who tagged friends. 
Who bought into the brand.

That’s how customer lifetime value doubles.



3. He used content to amplify the work, not replace it


Views don’t equal growth if the real work isn’t being done.

No amount of content fixes weak partnerships or poor execution.

But when you’re already building the business, content becomes a multiplier.

It amplifies your efforts and accelerates momentum.


His results came from this combo:

He built the business. 
We built the brand around it.
The content reflected real progress, not fantasy.

In a year, he went from posting iPhone pics to being featured in major industry magazines.

More partnerships.
More athletes. 
More events.

All earned by trusting the process.

Most of these results came in under 6 months. | 3 | 1 | 0 | 1mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.001Z |  | 2025-11-07T19:49:07.215Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7392261879613595649 | Article |  |  | You've been told to "implement AI into your business".
But no one tells you how
→ Let's fix that.

First off: building premium AI content isn't always obvious.

It's easy to mess up.

And when you do? You get lumped into the "AI slop" category.

Customers start treating you like you're cheap. 
Like you're just trend-hopping instead of actually running a real business.

Because it's one thing to be frustrated that you don't have the resources your competitors have.

It's another thing entirely to be seen as someone cutting corners with low-effort AI garbage.

Because there's more to it than...
→ Using ChatGPT to spit out basic graphics 
→ Posting whenever you feel like it 
→ Copying whatever everyone else in your industry is doing

You gotta:
→ Stop people mid-scroll 
→ Make it so real, they wouldn’t believe its Ai 
→ Actually understand how to communicate with AI tools

But...
I've got a genius solution.
And honestly? It's stupid simple once you see it.

It's probably why I can create content that has brokers and founders asking "wait, thats Ai?"

And it boils down to 3 steps:
1. Define the feeling or action first
↳ What do you want your audience to DO or FEEL from this content? That dictates everything else.

2. Break down the traditional execution
↳ List out what it would take with real crews, budgets, and timelines. Scene by scene. Then identify what's actually necessary.

3. Train the AI to think like your creative team
↳ You need to either learn the technical terminology yourself, or teach the AI to translate your vision into industry-standard execution.

Example:
Say you're a real estate broker (or even a product founder promoting a drop)...
You want a video that makes people stop scrolling and think "damn, this person is operating differently."

You'd normally need: 
location scouts, a DP, lighting crew, editors, motion graphics team. 
Weeks of turnaround. Thousands spent.
↳ this is defining the traditional path

Instead, you communicate with AI like you would a creative director: "I need a 15-second teaser. Luxury feel. Smooth camera movement through the space. End on the address reveal."
↳ this is treating AI as your department

Then you either learn terms like "camera dolly movement" and "warm color grading" yourself, or you train the model to understand YOUR language and translate it into technical specs.
↳ this is building your system

This approach changed how I create content for clients.

No more "cool Ai video" comments.
No more getting grouped with the trend-hoppers.

If you want to stand out in your niche without burning cash on traditional production?
I'm building something for founders and brokers who want this exact system.
The one that has competitors asking "how are they pulling this off?"

Join the waitlist and I'll reach out to see how I'd break it down for your business.
https://lnkd.in/eRCQAZme | 6 | 0 | 0 | 1mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.002Z |  | 2025-11-06T18:09:33.684Z | https://hyrusenterprise.carrd.co/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7387549265092423680 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHTA5KuKv__aw/feedshare-shrink_800/B4EZoXY3mPJgAg-/0/1761328994089?e=1766620800&v=beta&t=v2UZ6NvhH1u82Uz-PkLYSbsjjwKq2Js4oMYfHzJE6OI | One year, 100+ videos, 500K+ views... and a run-in with seven howler monkeys.

It’s been a while since I last posted here. 
In that time:

- Saved $2 million in content costs for clients.
- Pulled 500,000+ views organically
- Built 400+ ad creatives.
- Made 100+ videos.

But stats only tell part of the story. The past year also included:

- Got called “unc” 7 times.
- Drove 5600km to see big rocks
- Celebrating 365 days of building Hyrus.
- Still don’t know what “6-7” means (its driving me insane).

Eventful to say the least

Proud of the work. Grateful for the people.

Let’s see what comes next. | 8 | 1 | 0 | 1mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.003Z |  | 2025-10-24T18:03:18.826Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7342987939208962049 | Video (LinkedIn Source) | blob:https://www.linkedin.com/39265e8e-1f5b-4c2f-9a7b-bdb692ae1357 | https://media.licdn.com/dms/image/v2/D4E05AQF7MCKOrYDhnw/videocover-high/B4EZeeImhCGwB8-/0/1750704746817?e=1765785600&v=beta&t=QvpXdMZzCOnjyOMjJuGs4fWJlKLYuM-nxilyuCl0ISg | When you’re selling a $3M car, speed isn’t optional. It’s survival.

Most exotic dealers wait 10–14 days for a single studio video.

That’s 10–14 days their competitor is winning attention. Ranking reels. Selling the story first.

Meanwhile, yours is still in post.

With AI-assisted workflows and precision visuals, I deliver cinematic content in under 24 hours.

Same quality. Same prestige. Faster than anyone else.

Because in luxury, the first impression doesn’t just win—

It sells. | 10 | 0 | 0 | 5mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.004Z |  | 2025-06-23T18:52:30.826Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7341546674445606913 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d570823c-8b9d-4c83-89fa-a8b231efedd4 | https://media.licdn.com/dms/image/v2/D4D05AQHTw2bFCfanOw/videocover-high/B4DZeJpxikGYCE-/0/1750361121539?e=1765785600&v=beta&t=aqlttQlCaBhaUO_1spY1Vc8oPO__l-zvizsfm-25HNQ | Why wait 2 weeks for a single video, when you can have the same result in 3 hours?

No compromise on quality. 

Just less time, 

Less friction, 

and more ROI.

Last week, I created a cinematic dealership video—from concept to completion—in just one afternoon.

Here’s how:

• I identified the exact angles, light, and movement I needed before stepping on-site.
• Created the footage in under 90 minutes.
• Combined it with AI-powered editing tools to speed up production.
• Delivered a ready-to-post asset the same day.

The final result?

A video that looks like it took a crew, a crane, and a whole weekend.

Except it didn’t.

And here’s the ROI most overlook:

→ No disruption to daily operations.
→ No waiting for edits, approvals, or reshoots.
→ No multi-day shoot pulling salespeople off the floor.
→ Time saved is time reinvested—into selling inventory, following up with leads, or launching your next promotion.

In a dealership, every hour counts.
I don’t just deliver content. I buy you back time.

If you’re running a high-performance brand, your content should move just as fast.

Let’s connect. | 20 | 2 | 0 | 5mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.005Z |  | 2025-06-19T19:25:26.529Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7315428539233656832 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEelKrh57zB6Q/feedshare-shrink_800/B4DZYWfe2JHAAg-/0/1744134075503?e=1766620800&v=beta&t=F-6odtXYcvS7hj53PZzmYcH-WVDq0USMmmC3hd0MGyQ | The moment I knew my videos weren’t normal.

I used to see video campaigns and think,
“Why does this feel so flat? Why doesn’t this move me?”

I didn’t have the budget. I didn’t have the gear.
But I had the feeling — and I knew how to make it real.

The first time I made a video that was living inside my head for over a year, it changed everything.
I edited it on CapCut. Posted it. And the client cried.

Louis Butterfield messaged me after I made one for him.
He said over a zoom call: “Your understanding of vibe is world class.”

And it wasn’t just him.
Each time I made a video just to capture what I felt, people reached out — not for edits, but for emotion.
I knew this wasn’t normal.
I knew this was something bigger.

⸻

And I think part of the reason I do what I do comes from my dad.

He was the sharpest man in every room — a jazz musician at 13, top of his class, athletic weapon, built teams, led divisions, and dominated any debate or negotiation. But what always stuck with me was what he said to me before he passed:

“You’ve got more balls than I ever did. I could never go my own way like you’re doing.”

Which felt surreal, because I always imagined myself as being too scared to be bold in going my own way.

Feeling like a shadow of him, being “Simon’s kid”.

When he saw the videos I made, he’d light up.
Show them off. Tell my brother,

“Did you see what he made? I can’t even understand how he does that.”

He believed in what I had — especially when it was raw and true.

Now that he’s gone, that’s my compass.

Each video I make, or big campaign I develop, 

If it feels like something he’d want to show off again, I know I’ve done my job.

If not, I throw it out.


I don’t make content.

I fabricate belief.

And every project is a conversation with the man who believed in me more than I ever did. | 30 | 5 | 1 | 7mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.006Z |  | 2025-04-08T17:41:17.843Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7312922437858263041 | Video (LinkedIn Source) | blob:https://www.linkedin.com/233a19a6-62f2-41d9-8015-6cc39a187e21 | https://media.licdn.com/dms/image/v2/D4E05AQGYqz7Yu034UQ/videocover-high/B4EZXy4KLbHcBs-/0/1743536568660?e=1765785600&v=beta&t=mCJIVeaRhDsoMVpDlEmwq25ppZK0vnlqvR8TpaYLVGw | I made this video using only CapCut and ChatGPT.

Not Premiere Pro.
Not After Effects.
Just free tools.

Because I wanted to prove one thing:

It’s not about the tools.
It’s about getting the job done.

I generated the visuals using ChatGPT.
Layered overlays to create motion.
Added flashing effects for that video game feel.
And synced it to a soundtrack from YouTube’s free audio library.

No fancy production.
No big budget.
Just execution.

Here’s the funny part…

The client? Competing with giants.
Their competitors’ marketing departments?

They’re now in meetings asking:
“Why don’t we do what he’s doing?”

Trick question.
It’s just one guy.
And it’s me.

Moral of the story?

Stop hiring based on tools.
Start hiring based on outcomes. | 13 | 2 | 0 | 8mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.007Z |  | 2025-04-01T19:42:56.714Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7312918735831400448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpN7gmVuPMtw/feedshare-shrink_800/B4EZXy01QWHgAg-/0/1743535692530?e=1766620800&v=beta&t=Jmo_VKVcHEzgoKou2RPs3Gx3Z3za9x118TqtGABhEH0 | Most people think sales is about “handling objections on the call.”

But what if you handled objections before the call ever happened?

Here’s what I mean:

You could…

→ Follow up 5 times
→ Get ghosted 3 times
→ Fight through a 2-hour objection battle
→ Maybe close the deal after 3 weeks

Or…

You could publish content that speaks to every objection before the first DM is sent.

Because when your content does the heavy lifting?

→ You build trust on autopilot
→ You answer their biggest doubts
→ You shift them from “Who are you?” to “How do I get started?”

That’s the magic of strategic content.

Not job updates.
Not internal promotions.
Not corporate flexes.

But real, direct content that mirrors the sales call itself.

I had a client selling high-ticket web development via cold outreach.

His biggest frustration?

“They don’t even realize they have a problem. It drives me nuts.”

My advice?

Build a content bank that reflects your sales process:
→ Your beliefs
→ Your objections
→ Your worldview

When people see the problem, they admit the problem.

And once they do that?
They trust you.
And they buy.

Let your content warm them up before you ever hit “send” on a message.

That’s the modern sales funnel.

And LinkedIn is your pre-call playground.

P.S. What’s one objection your content could start addressing today? | 11 | 3 | 0 | 8mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.008Z |  | 2025-04-01T19:28:14.082Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7304922132809986048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEi9KaLJzQdeA/feedshare-shrink_800/B4EZWBL9LLGYAg-/0/1741629153881?e=1766620800&v=beta&t=lkquXS9_u3EJsjKT59wHT300vDUUrA--PsgQqammBx4 | Hey LinkedIn, it’s been a while.

It might seem like I left abruptly. 

Maybe it looked like I abandoned what I was doing. 

Or maybe… you didn’t even notice I was gone.

But this is more a post to document than anything.

——————-

In early 2025, my father suffered a heart attack. 

On February 11, he passed away at 61 in the ICU.

No one saw it coming, and it forced us to handle everything the best we could.

It also forced me to look inward. 

To ask myself:

Is what I’m building coming from a solid foundation?

—————-

I was lucky to keep some clients. 

I lost others. 

But above all, I was fortunate enough to be in a position to spend every moment with him in the hospital until his passing.

Since then, I’ve reflected on what I do and why I do it. 

And what stood out?

The moments my dad was most proud. 

—————-

The times he knew I was doing exactly what I was meant to do. 

He bragged to everyone about my work when I was aligned with my gift. 

And when I was forcing it? Was when he was most concerned.

I was lucky to find that alignment before he passed. 

Lucky that he got to see it.

——————-

As for the plan here?

I’m still scaling from scratch—just not in public.

I’ve been doing it silently. 

Restructuring the business, reshaping the content, refining the model.

————-

If there’s one lesson from all of this:

Everything I create now is calculated, yet comes from my deepest intuition—like I’m communicating with him, and I can hear his pride.

For those who thought I left abruptly—I’m sorry.

For those who didn’t notice—keep doing what you’re doing lol.

Excited to start posting again. Stay tuned.

—Liam | 62 | 20 | 0 | 8mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.010Z |  | 2025-03-10T17:52:35.352Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7284633904194486272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1c56d24b-ade2-4372-bd8d-58e01e7ccce2 | https://media.licdn.com/dms/image/v2/D4E05AQHLeI3a-GeHdw/videocover-high/B4EZRg317JGYBw-/0/1736792056307?e=1765785600&v=beta&t=KKPgVtMz-HIkxGoEfAcxg0mrYHLsk3KPqS1fDehcAJU | Every piece of content you create should tie back to your offer.

That’s what worked for Haley Lytle 🪩 

Who’s grown her business on LinkedIn to well over five figures a month.

Her philosophy:

The insight you share should connect to your offer in some way.

Don’t just tell people what to do—that doesn’t convert.

Instead, start with a story about how you came up with your solution.

Then, tie it back to your offer.

This makes your audience feel heard, relate to you, and see your solution as their answer.

Part two next week—follow Liam Robins to be ready for when it comes out. | 24 | 12 | 0 | 10mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.011Z |  | 2025-01-13T18:14:24.713Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7282102528853344256 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8ba2a624-6b7c-4308-8bcf-9384c1ca5871 | https://media.licdn.com/dms/image/v2/D4E05AQHBMq-ATT1-NQ/videocover-high/B4EZQ85Ui6GcBw-/0/1736188511628?e=1765785600&v=beta&t=Z7-8UhAtqkrqJREo_T8GT0Ck6NrFj3OIL6mctb0jGow | I finally solved my biggest problem.

It wasn’t about what I can do.

Spreading myself thin was holding me back.

Steve Jobs said marketing is about values.

The videos I make answer one question: “Describe your brand without describing your product.”

DarcSport mastered this. 

They started in bodybuilding 

But expanded into a broader niche without losing their identity. 

They didn’t sell clothes; 

they sold a mindset.

Brands that try to appeal to everyone with generic messaging fail every time over a longer time horizon.

Your values make you stand out. 

That’s what my videos capture.

Here’s how I help business owners bridge the gap:


Step 1: Find the starting point.

If they have raw content and a brand identity, 

I analyze how often they’re posting compared to a brand like DarcSport 

And create a plan to build that consistency.


Step 2: Hone in on values.

Stick to 

- one identity, 
- one mission
- one value. 

Remove anything that contradicts it. 

This creates novelty and positions the brand as a status symbol, not a commodity.



Analyzing my old content:

One of my best-performing hooks was: “Drawing this guy until he followed me back, day ___.”

Here’s why it worked:

- Stipulations in the first 5 seconds:
- What happens when he follows?
- Why hasn’t he followed yet?
- I don’t want to follow him first because he might stop.

This created a chaotic yet intriguing scenario that left viewers needing to know the outcome.

The hook works because it sparks curiosity and leaves questions unanswered (if they don’t watch the video)


My goal on my service?

To make videos that help brands stand out, stay authentic, and connect deeply with their audience over a longer time horizon.

Follow Liam Robins for more of these videos. | 41 | 21 | 0 | 11mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.014Z |  | 2025-01-06T18:35:37.801Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7279153075968176128 | Video (LinkedIn Source) | blob:https://www.linkedin.com/98c512dd-0b3b-4937-be8c-9e4b3bbe4b23 | https://media.licdn.com/dms/image/v2/D4E05AQGNJZm86TMSbg/videocover-high/B4EZQS.9.xHgB0-/0/1735485291310?e=1765785600&v=beta&t=EpMvJ9uz-nrX-VeROQaWzZOsNG80I3v6Zbfim-nvZHM | I gained 10 million views on TikTok and Instagram in 2 weeks (it nearly k*lled my business)

Here’s how to avoid it:

Let’s say your post does go viral. Then what?

If 1 million people visit your profile, but you don’t have:
- A clear offer
- A content library that explains what you do
- An easy way for people to contact you

You’ll lose their trust and attention.

Imagine inviting a million people to “the best party ever.”

They show up, and there’s nothing there.

Will they come back? Or tell others it was a waste?

The key is to build trust before aiming for attention.

Here’s how I fix this with clients:

Step 1: Build the foundation.
Make content that answers every question a client may have before they buy.

Answer things like:
- Why should they trust you?
- How does your offer help them?
- Do you solve their problem?

Step 2: Go for viral content.
When the foundation is ready, focus on virality.

A good hook is everything:
- It needs to create curiosity.
- It should explain the video in 4-5 seconds.
- If it takes longer, the idea isn’t clear enough.

Do you agree? Or have a different take? Let me know in the comments!

Follow Liam Robins for more | 53 | 39 | 0 | 11mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.015Z |  | 2024-12-29T15:15:33.435Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7276735519525335040 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c4e23060-f3fe-474d-9f0e-95875d5d83b1 | https://media.licdn.com/dms/image/v2/D4E05AQGE48bi-rWKuw/videocover-high/B4EZPwoR90GcBs-/0/1734908921967?e=1765785600&v=beta&t=A0cA_0DP2nZ0igfRjdGxC2tYiquhS2Tk9OaFlwh2_qQ | When building an offer, people tell you to focus on one thing.

I want to challenge that idea (let me explain)

Alex Hormozi says it’s essential—you’ll spread yourself too thin otherwise.

And while that’s true, I want to challenge how we think about it.

If you’re saying, “I do film AND web design,” then yes, you’re diluting your expertise.

But if you’re saying, “I specialize in film across various different stages of the business,” you’re staying focused on one skill (video), applied through multiple viewpoints.

This is the approach I’m taking as I build Hyrus into a sustainable, scalable business.

Here’s how I’m approaching it:

I position myself as a strategic growth partner who specializes in media, helping enterprises improve the buying process from A to Z using video.

Step 1: Identify the industry (finance, law, hospitality, IT, etc.).

Step 2: Map out the business model:
 •	How they acquire clients (LinkedIn, landing pages, websites, referrals).
 •	Which pipeline stages need improvement.

Step 3: Match the video type to the pipeline:
 •	LinkedIn leads: Objection-based content (no money, no time, no trust).
 •	Landing pages: VSLs scripted to educate, engage, and convert.
 •	Referrals: Testimonial videos to build trust and credibility.

Every video is tailored to the enterprise’s client acquisition model, ensuring objections are resolved before sales calls even start.

The Offer Structure

To keep this simple and scalable, I’m building:
 1.	One core offer tailored to my ideal client.
 2.	Sub-offers as smaller entry points under the main offer.

Each sub-offer ensures I’m not spreading myself thin while still giving everyone the opportunity to work with me. Whether they start small or go all in, the focus is on delivering value at every level—without compromising quality or my capacity.

It’s like running a restaurant. If a customer wants a cookie instead of the most expensive item, I sell them the cookie. From there, they work their way up to bigger purchases.

Next week, I’ll tackle a common concern many have about LinkedIn videos:

“What if my first videos don’t go viral?”

I’ll address the misconceptions around virality and how I’m focusing on creating consistent content to generate proper leads—not just views. Because the goal isn’t to go viral, it’s to attract the right opportunities.

Follow Liam Robins to know when the video comes out | 41 | 12 | 0 | 11mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.016Z |  | 2024-12-22T23:09:03.063Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7274189854308024320 | Video (LinkedIn Source) | blob:https://www.linkedin.com/acd7cb7e-ad7a-4189-9a38-e7292f910d9f | https://media.licdn.com/dms/image/v2/D4E05AQEa-rmwOlo07Q/videocover-high/videocover-high/0/1734301955525?e=1765785600&v=beta&t=IV7ABmH9fFyEmKj-ZhMqJ2fHW-65hMxnv0Fp467Hclk | Fortune 500 companies use this strategy to dominate their competitors.

I used it to find my unique video style.

And I’m going to show you how I did it.

Most creators say, “Study what already works.”

But the real secret? It’s not about the style. It’s about the substance.

Your style is simply the way you showcase the substance.

That’s why creators like Louis and Aidan stand out.
They might talk about similar topics, but their delivery makes them unforgettable.


Here’s how I figured this out for myself:

Step 1: Understand the common content topics

→ To make in easier, I took Niall Ratcliffe recent post on B2B content that works according to him
→ Once you know this, you can focus on how to differentiate yourself within this structure.

Step 2: Apply the “Blue Ocean Strategy”

Here’s the concept in simple terms:

→ Instead of competing in a crowded “red ocean” of sameness, 
→ You create your own “blue ocean” by delivering something unique.

How do you do it? Follow these steps:

1.Eliminate what’s unnecessary
→ Stop copying every trend just because it works for others.

2.Reduce overused elements
→ Tone down clichés or overdone ideas in your niche.

3.Raise your unique strengths
→ What makes your delivery different? Highlight that.

4.Create something entirely yours
→ Add a layer of originality—whether it’s tone, visuals, or a specific vibe only you can bring.

Step 3: Test and refine your style
→ Once you’ve defined your unique delivery, start creating and see what resonates.
→ This strategy doesn’t just apply to finding your style—it can work across any industry.

The result? 
You’ll stand out in a sea of sameness, even if you’re talking about similar topics.

Follow for more Liam Robins 

By the way, 
Louis Butterfield is launching his cohort in January 2025
Aidan Brannigan is taking on clients for his creative agency « No Boring brands »

Check them out 🤝 | 51 | 22 | 0 | 11mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.018Z |  | 2024-12-15T22:33:29.179Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7271618079552331777 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8b6a3ca4-2848-49ba-9ec1-d4936238c8f2 | https://media.licdn.com/dms/image/v2/D4E05AQGaoeKVnoO-LA/videocover-high/videocover-high/0/1733688827373?e=1765785600&v=beta&t=Xqi5k2891jGowlKRLzekDCY8DcDDhYuKDguOdIvVw9g | It’s not my business. It’s my future clients.

That’s the biggest bottleneck. Let me explain.

But first: Lara prompt setup from episode 1 was a battle, GBT put up a great fight by earning 300/500 posts analyzed, but will need more training to take on Jasmin Alić

Ok back to the show:

If a client’s philosophy doesn’t align with mine, it’s always a headache.

Two principles keep things smooth:

1) Focus on the long-term, not short-term. Forget quick wins—build a community.
2) Stay flexible with methods, not outcomes. Experiment until you find what works.

With these principles, I ensure results, keep clients happy, and let them do the heavy lifting—referrals. That’s how I’m building my “team.”


Highlights this week:

- Got over 30 calls in 2 weeks.
- Had a great chat with Haley Lytle 🪩—shoutout to her.

On these calls, I’m solving the big question:

What makes someone confidently invest 4-5 figures in a service?

Here’s my thought process:

It’s not just about the deliverable. 

Clients need clarity on:
- The exact problem being solved.
- How the solution fits their goals.
- What outcomes they can expect over time.

I’m designing solutions to answer these questions upfront—through content, PDFs, or tools they can apply immediately.

When all of this is built into the offer, the decision isn’t IF they buy, but who they think of when they’re ready.

What’s Next?
Next week’s episode:
What to talk about and how to stand out.

Want my current writing formatting prompt? 
Comment “Liam” and connect with me. I’ll DM it to you—but it’s only available for 48 hours.

Follow Liam Robins for more videos like these

See you next week. | 115 | 39 | 1 | 11mo | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.021Z |  | 2024-12-08T20:14:10.296Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7271307642126450688 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f97f739b-3647-4035-a59e-0c30bcd65f0d | https://media.licdn.com/dms/image/v2/D4E05AQF-KI0FNBDOww/videocover-high/videocover-high/0/1733088898672?e=1765785600&v=beta&t=RxayxyZaCEJZBso7xaiCzcl2cqkN16njVx4qjqlTxRo | Most creators think they have to choose between growth and their craft.

But what if you didn’t?


When creators gain traction, they’re hit with the same challenge:

 •	They bring on clients but lose time for content.
 •	They stop creating content and stall their growth.

It feels impossible to balance both.

I’ve seen it firsthand with myself and others. And now, I want to solve it.

Shoutout to Louis Butterfield for inspiring this idea through a convo we had.


My plan:

In the short term, Hyrus will be an agency name for brand and video services.

Long term, my vision is to turn Hyrus into a PRODUCT (like Jarvis from Ironman),  that helps creators and businesses thrive without sacrificing their essence or growth.

The goal isn’t just to scale. It’s to create something that supports my clients and myself at every level.


The process:

 •	Identify the task. What’s necessary, and what’s just noise?
 •	Delete unnecessary steps. Eliminate anything that doesn’t serve the end goal.
 •	Simplify the workflow. Make the process as lean as possible.
 •	Accelerate execution. Focus on speed without sacrificing quality.
 •	Automate strategically. Only automate once the foundation is solid.

For example: when a client wants to make a story announcement of a restock, my current process of pulling assets, editing, and posting takes too much time. 

By simplifying the steps and accelerating execution, I can save hours without compromising results.


 2.	Create a content ecosystem
This series isn’t just a behind-the-scenes—it’s a blueprint for creators.

 •	Weekly episodes documenting the journey.
 •	Actionable tips you can adapt.
 •	Honest insights into what works and what doesn’t.

It’s all about showing, not telling, what’s possible with LinkedIn video.


 3.	Write proper captions for videos

One of the biggest challenges creators face is nailing their messaging. Great videos need great captions.


Here’s how I’m tackling it:
 •	I’m taking two years’ worth of Lara Acosta’s posts and added them into ChatGPT.
 •	I’ll use this as my structure to write captions that engage, inspire, and convert.

Next week, once I’m done doing this—i’ll give the prompt away for free.


Why I’m doing this:

Creators often get stuck in a cycle:

 •	Sacrificing content to focus on clients.
 •	Or sacrificing clients to keep creating.

I don’t believe it has to be either-or.

By building Hyrus into a scalable tool, I can:
 •	Show clients what’s possible through video.
 •	Bring on more clients who align with my vision.
 •	Share the journey and lessons with you along the way.



What’s your biggest challenge when it comes to creating content?

Let’s figure it out together. | 128 | 70 | 1 | 1yr | Liam Robins reposted this | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.023Z |  | 2024-12-07T23:40:36.246Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7269101896810876929 | Video (LinkedIn Source) | blob:https://www.linkedin.com/23cb5d42-1b8c-4ce6-9798-aa1ad261604e | https://media.licdn.com/dms/image/v2/D4E05AQF-KI0FNBDOww/videocover-high/videocover-high/0/1733088898672?e=1765785600&v=beta&t=RxayxyZaCEJZBso7xaiCzcl2cqkN16njVx4qjqlTxRo | Most creators think they have to choose between growth and their craft.

But what if you didn’t?


When creators gain traction, they’re hit with the same challenge:

 •	They bring on clients but lose time for content.
 •	They stop creating content and stall their growth.

It feels impossible to balance both.

I’ve seen it firsthand with myself and others. And now, I want to solve it.

Shoutout to Louis Butterfield for inspiring this idea through a convo we had.


My plan:

In the short term, Hyrus will be an agency name for brand and video services.

Long term, my vision is to turn Hyrus into a PRODUCT (like Jarvis from Ironman),  that helps creators and businesses thrive without sacrificing their essence or growth.

The goal isn’t just to scale. It’s to create something that supports my clients and myself at every level.


The process:

 •	Identify the task. What’s necessary, and what’s just noise?
 •	Delete unnecessary steps. Eliminate anything that doesn’t serve the end goal.
 •	Simplify the workflow. Make the process as lean as possible.
 •	Accelerate execution. Focus on speed without sacrificing quality.
 •	Automate strategically. Only automate once the foundation is solid.

For example: when a client wants to make a story announcement of a restock, my current process of pulling assets, editing, and posting takes too much time. 

By simplifying the steps and accelerating execution, I can save hours without compromising results.


 2.	Create a content ecosystem
This series isn’t just a behind-the-scenes—it’s a blueprint for creators.

 •	Weekly episodes documenting the journey.
 •	Actionable tips you can adapt.
 •	Honest insights into what works and what doesn’t.

It’s all about showing, not telling, what’s possible with LinkedIn video.


 3.	Write proper captions for videos

One of the biggest challenges creators face is nailing their messaging. Great videos need great captions.


Here’s how I’m tackling it:
 •	I’m taking two years’ worth of Lara Acosta’s posts and added them into ChatGPT.
 •	I’ll use this as my structure to write captions that engage, inspire, and convert.

Next week, once I’m done doing this—i’ll give the prompt away for free.


Why I’m doing this:

Creators often get stuck in a cycle:

 •	Sacrificing content to focus on clients.
 •	Or sacrificing clients to keep creating.

I don’t believe it has to be either-or.

By building Hyrus into a scalable tool, I can:
 •	Show clients what’s possible through video.
 •	Bring on more clients who align with my vision.
 •	Share the journey and lessons with you along the way.



What’s your biggest challenge when it comes to creating content?

Let’s figure it out together. | 128 | 70 | 1 | 1yr | Post | Liam Robins | https://www.linkedin.com/in/liam-robins-208b53332 | https://linkedin.com/in/liam-robins-208b53332 | 2025-12-08T07:05:20.025Z |  | 2024-12-01T21:35:45.582Z |  |  | 

---



---

# Liam Robins
*Hyrus*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Introducing the Hyli Guide](https://blog.hyli.org/introducing-the-hyli-guide/)
*2025-08-21*
- Category: blog

### [Liam Robinson - Head Physiotherapist, Melbounre Storm, NRL - How did you get into sport?](https://www.buzzsprout.com/2110776/episodes/12779945-liam-robinson-head-physiotherapist-melbounre-storm-nrl)
*2023-05-12*
- Category: article

### [Interview with Liam Martin, Co-Founder of Time Doctor | Fellow.app](https://fellow.app/supermanagers/liam-martin-time-doctor-running-remote-teams-applying-the-hierarchy-of-communication/)
*2024-05-14*
- Category: article

### [The secret behind fast-growth B2B socials | Liam Curley](https://www.liamcurley.co.uk/blog/the-secret-behind-fast-growth-b2b-socials)
*2024-01-01*
- Category: blog

### [The New Age of Remote Work - An Interview with Liam Martin](https://www.jeffbullas.com/podcasts/40-new-age-of-remote-work/)
*2024-06-13*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
