# Max Musing

## Position actuelle

**Titre** : Founder
**Entreprise** : Basedash
**Durée dans le rôle** : 5 years 6 months in role
**Durée dans l'entreprise** : 5 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Basedash is the next-gen BI tool that lets you create dashboards and understand your customers using natural language. Connect your data source, describe the chart you want, and let AI generate the visualization. No SQL or drag-and-drop required.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB6-5WYBrFH546k4JKZj5O-2J60_sqANuQM/
**Connexions partagées** : 37


---

# Max Musing

## Position actuelle

**Entreprise** : Basedash

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Max Musing

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403153764141912064 | Text |  |  | I used to think:
Product-market fit is a single moment you hit.
Now I think:
It is a moving target you keep up with or lose.

I used to think:
Better product automatically beats better distribution.
Now I think:
Great distribution with a good product usually wins. Great product with weak distribution usually loses.

I used to think:
More features equals more value.
Now I think:
Fewer, sharper outcomes make the product feel 10x more valuable.

I used to think:
Hiring solves bottlenecks.
Now I think:
Hiring magnifies whatever systems and clarity you already have, good or bad.

I used to think:
Fundraising is a signal you are on the right track.
Now I think:
Revenue and retention are the only signals you cannot fake.

The uncomfortable part is that these lessons only really sink in when you learn them the hard way.
The advantage is that once you see them clearly, your decision making gets a lot quieter. | 8 | 2 | 0 | 1d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.278Z |  | 2025-12-06T19:30:01.317Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402776276329058304 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFhjBdMWzXMow/feedshare-shrink_2048_1536/B4EZrHYn50KgA0-/0/1764281712765?e=1766620800&v=beta&t=NW3POuQfMOiXbcI6ZAj2fe5WkgR0sh477W4oX4TTwm4 | People connect more deeply with products that feel like they’re truly theirs. Not just functional, but personal.

It’s easy to treat customization as a nice-to-have, yet it often defines whether a tool becomes something people enjoy using every day or just something they tolerate.

At Basedash, we spend a lot of time thinking about this. If teams build their most important dashboards in our product, those dashboards should reflect their identity. They should feel intentional, consistent, and crafted—not generic.

That’s why we built our own icon system from the ground up and designed a custom icon picker to match it. We wanted every icon, every color, and every small interaction to feel coherent. Nothing off-the-shelf could match the level of precision we were aiming for, so we created the full set ourselves—pixel by pixel.

This level of detail may seem obsessive, but it compounds. When people can shape their workspace to match their taste and their workflow, the product stops feeling like software and starts feeling like theirs. And that sense of ownership is what turns a tool into a partner.

Customization isn’t decoration. It’s part of how people build trust with the products they rely on. | 2 | 0 | 0 | 2d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.278Z |  | 2025-12-05T18:30:01.209Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7402749857746268160 | Text |  |  | Saying yes built our early momentum at Basedash.
Learning what to say no to kept us alive.

Here are some things I say no to now:
• Building “just in case” features
• Roadmaps that quietly assume everything goes right
• Custom work that only helps one big logo
• Meetings where the real decision maker is “not on this call”
• Growth tactics that do not also improve the product

And what I try to say yes to:
• One painful, specific problem we can own completely
• A smaller surface area with clearly better outcomes
• Direct access to customers, even when feedback stings
• Rethinking something that “works” but is slowing us down
• Simple metrics that everyone on the team can recite

Most of the leverage in a startup is hidden in these small choices.
Not in the vision document, but in what you quietly refuse to do every day. | 11 | 1 | 0 | 2d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.279Z |  | 2025-12-05T16:45:02.528Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7402463699094962176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHGxmQmDqoYGA/feedshare-shrink_800/B4EZrrVgLFIoAg-/0/1764884875403?e=1766620800&v=beta&t=8XscBDu8ZIrIzfuRJXncO-rLtu1ET0ZYTlkA5IPnpRw | If your strategy isn’t visible in your calendar, it isn’t your strategy.

Look at the past week on your calendar and add up:
1. Hours talking to users
2. Hours improving core product
3. Hours fixing what breaks
4. Hours in recurring meetings
5. Hours on “optional” projects and partnerships

Now circle the line that matches what you say is your top priority.

If they don’t line up, you don’t have a strategy problem. You have a calendar problem.

In my experience at Basedash, the biggest inflection points didn’t come from new docs or decks. They came from changing how we spent a few specific hours, every single week. | 2 | 0 | 0 | 3d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.280Z |  | 2025-12-04T21:47:56.989Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7402458826614136832 | Text |  |  | Ten principles I’ve learned while building Basedash:

1. Start before you have the full picture.
Clarity comes from shipping, not planning.

2. Make uncertainty your advantage.
When you’re small, you can change direction faster than anyone else.

3. Stay close to users.
The fastest feedback loop wins.

4. Keep the team lean for as long as possible.
You learn more when you can hear every problem firsthand.

5. Treat each release like a question.
If it doesn’t teach you something, it wasn’t small enough.

6. Avoid premature stability.
Flexibility is more valuable early on than perfect systems.

7. Don’t outsource the hard conversations.
Direct communication saves months of drift.

8. Bias toward action when stakes are low.
Momentum compounds faster than deliberation.

9. Rebuild your convictions often.
What was true at 10 customers may not be true at 100.

10. Make progress visible.
Teams move faster when they see the path forming under their feet.

The work rarely feels linear. But if you keep moving, the shape of the company starts to reveal itself. | 9 | 1 | 0 | 3d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.281Z |  | 2025-12-04T21:28:35.299Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7402379923622883329 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHcz3YIrtXLvg/feedshare-shrink_800/B4EZrHYDuSIoAg-/0/1764281564494?e=1766620800&v=beta&t=VxG93djs6QI-zDjFNkCbR74E_PpaPyuGwVQB6_ENIzo | AI is starting to do something unexpected at our company: it’s giving us product ideas that are so good they’re making some of us uncomfortable.

Every morning, our internal AI system posts a Slack insight about how to improve product-market fit. It looks at activation, retention, onboarding behavior, and patterns across cohorts. Then it tells us what changes would make the biggest impact.

Today it flagged a product change that, based on our own data, is likely to increase our activation rate by >10%.

And the wild part is that the insight wasn’t abstract or fluffy. It was detailed, quantified, and immediately actionable. It surfaced a lever we already suspected was powerful, confirmed it with real numbers, and suggested exactly how to operationalize it inside onboarding.

That feature is already in development.

This is the moment where you realize the real shift happening with AI inside product teams. It’s no longer just speeding up execution. It’s starting to participate in strategy. It’s noticing patterns across thousands of user interactions that humans don’t have the bandwidth to constantly track. And it’s doing it with a level of clarity that directly informs roadmap decisions.

We built this system originally to help us understand the business better. Now it’s becoming a strategic partner. It’s showing us where to focus, what to build, and which small changes will have an outsized impact on growth.

It’s both exciting and a little uncomfortable.

Because when your own AI tells you how to grow your company better than you can, you start to understand just how much leverage these tools are about to create for product teams everywhere. | 7 | 3 | 0 | 3d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.282Z |  | 2025-12-04T16:15:03.360Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7401670248564940800 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzKa_5whS9LQ/feedshare-shrink_1280/B4EZrHW_9YHoAs-/0/1764281286934?e=1766620800&v=beta&t=JKSSN2eB1hxEc8UCmQ5O_tTIuRuHvgxfqIv84gMsU3s | Most teams obsess over AI model quality, but far fewer obsess over the interface that delivers that model to real users. That gap is becoming the difference between products people try and products people adopt.

One simple example: voice input.

The moment people experience frictionless voice input in an AI product, their expectations shift permanently. It removes typing as a bottleneck. It unlocks faster thinking. It brings AI closer to how we naturally communicate. And once users feel that, they don’t want to go back.

If your AI chat interface doesn’t support effortless voice input by default, you’re not just missing a feature. You’re adding invisible friction to every interaction. The product might be powerful, but the experience feels dated. And users churn when something feels dated.

AI is no longer judged only by how smart it is. It’s judged by how it fits into the way people already communicate. Voice is becoming a baseline expectation, not a nice-to-have.

Teams that understand this aren’t just building models. They’re building habits. They’re building products that users reach for every day because the interface gets out of the way.

The future of AI is as much about how we talk to it as it is about what it can do. Products that lean into that will win. Products that don’t will feel obsolete faster than they expect. | 7 | 0 | 0 | 5d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:04.282Z |  | 2025-12-02T17:15:03.641Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7401322963129614337 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHf89QdlfnhJQ/feedshare-shrink_800/B4EZrHVqqdHgAg-/0/1764280937672?e=1766620800&v=beta&t=a3FSxzNX2_ljT_Mj1WI2cafY2G4pvPZlFZIXvfKTrJU | Most web apps still treat right-click like a second-class citizen. That’s a missed opportunity.

For years, we’ve built interfaces around top bars, sidebars, and hidden dropdowns, forcing users to hunt for actions that should be immediately available. Meanwhile, native apps have relied on context menus to streamline workflows and reduce friction. The web has largely ignored this pattern, even as more complex, professional tools move fully into the browser.

I think it’s time to change that.

At Basedash, we’ve been experimenting with bringing rich, native-feeling context menus to the web. Not as a gimmick, but as a core interaction model. The moment you expose contextual actions right where the user needs them, workflows speed up. Power users feel at home instantly. And the interface becomes more discoverable without adding visual clutter.

It’s a simple idea, but it has a big impact: meet the user where they already are.

My goal is to help normalize this pattern across modern web apps. The browser is capable of far more than most teams give it credit for. We should be building tools that feel as fluid and powerful as native software, not settling for the lowest common denominator.

Right-click isn’t an afterthought. It’s part of the future of great web UX. | 12 | 0 | 1 | 6d | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.021Z |  | 2025-12-01T18:15:04.341Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7400243335485104128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHJ730B1cBBIg/feedshare-shrink_800/B4EZrHVLEIHoAg-/0/1764280808198?e=1766620800&v=beta&t=u7_fbvfJB045I8W9_SEGLJ1L5FitXDdHEXI8AfAlJ6o | Most product teams obsess over big, flashy features. But the truth is that small interaction patterns often shape how users actually feel about your product.

One detail we recently shipped at Basedash has had an outsized impact on clarity and usability: every breadcrumb now doubles as both a tooltip and an entry point for quick editing.

Hovering shows essential context about the page. Clicking opens a lightweight dialog to rename the entity. No digging through settings, no hunting for hidden menus. Just a simple pattern that helps users understand where they are and make changes without friction.

It’s the kind of small design choice that reinforces a bigger philosophy: reduce ambiguity, reduce steps, and respect the user’s time. When your product surface grows and you introduce more entities, models, and dashboards, it becomes even more important that navigation stays intuitive.

We’ve found that patterns like this do more than polish the interface, they preserve momentum for users who want to stay in flow. And in complex data products, protecting that sense of flow matters more than almost anything else.

If you’re building tools with depth, don’t underestimate the power of thoughtful micro-interactions. They compound. | 7 | 1 | 0 | 1w | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.021Z |  | 2025-11-28T18:45:01.052Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7399929076888784896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFP_yfgG-cUaA/feedshare-shrink_2048_1536/B4EZrHUSLeHgA4-/0/1764280575147?e=1766620800&v=beta&t=0BkHHPyTrpBvKbBFBSnFsbBdg3las64_MoMJgtdtjZw | It’s rare for a model update that everyone assumes is incremental to turn out to be the most impactful one.

GPT-5.1 didn’t arrive with the hype of the newer Gemini or Opus releases, and most people treated it as a small step forward. Honestly, I expected the same. But after integrating it into our AI data analyst at Basedash, the results caught me off guard.

We saw a full 2× performance speedup with no drop in analytical quality.

In BI workflows, that kind of improvement isn’t cosmetic. Latency directly shapes how deeply and quickly people can explore their data. Halving response times changes the feel of the entire product. It makes the interaction more conversational, more iterative, and more useful.

What struck me is how easily this upgrade could have been overlooked. In a cycle dominated by big-name model releases, a “minor” update ended up delivering one of the most tangible performance gains we’ve seen in months.

It’s a good reminder that progress doesn’t always follow the marketing narrative. Sometimes the quiet update is the one that actually moves the needle. | 7 | 0 | 1 | 1w | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.023Z |  | 2025-11-27T21:56:15.964Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7399922788935028736 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHwRGPkW275-w/feedshare-shrink_1280/B4EZrHF3UvGYAs-/0/1764276795083?e=1766620800&v=beta&t=FoKEwIY1_LQQG8xia8TRoTw5DdFhGJpAq5ik97dBYWA | Shipping features is easy.
Polishing them until people love using them is the real work.

One thing I’ve learned building Basedash is that the difference between “we support this” and “this is delightful” is months of iteration, refinement, and obsessive attention to detail.

A good example:
We shipped basic Slack integration a while ago. It worked. It solved the problem. But it wasn’t special yet.

So we kept going.

We smoothed the rough edges. Improved message sync. Tuned the experience for real workflows. Made responses faster. Made threads feel natural. Removed friction in places most people never notice—but always feel.

This week, we shipped something that made me smile: two-way syncing between Slack and Basedash chats now works so seamlessly that a conversation feels native in both places. Start in Slack, continue in Basedash, and everything just stays perfectly in sync.

This didn’t come from adding “one more feature.”
It came from polishing until it felt inevitable.

That’s the bar we try to hit across the product: not just capability, but craft.

If you’re building product: shipping is step one.
The magic happens in the refining. | 7 | 1 | 2 | 1w | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.024Z |  | 2025-11-27T21:31:16.799Z | https://www.linkedin.com/feed/update/urn:li:activity:7399913225842032640/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396238804791083008 | Text |  |  | We just upgraded our AI data analyst to GPT-5.1 and saw a 2x performance speedup for the same quality of data-backed insights.

Speed like this isn’t just a nice UX improvement, it meaningfully changes the way people use products like Basedash. When answers feel instant, people ask more questions, explore more data, and pull AI deeper into their daily workflows.

This is the real story of the next few years in AI: models getting simultaneously smarter, faster, and cheaper on a predictable cadence. The teams that design their products to ride that curve—swapping in better models as soon as they land—will compound value without rewriting their stack every six months.

That’s the bar we hold ourselves to at Basedash, and why we always move quickly on upgrades like GPT-5.1. | 5 | 0 | 0 | 2w | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.026Z |  | 2025-11-17T17:32:26.534Z | https://www.linkedin.com/feed/update/urn:li:activity:7396235280766283777/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7392669454633185281 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2e996afb-a321-41f7-8af8-f47101b67959 | https://media.licdn.com/dms/image/v2/D4E05AQHsfyd8bG6TnA/videocover-high/B4EZpgJPTEGcCM-/0/1762549714758?e=1765782000&v=beta&t=U8o_YBD8AK-5V--Nx7DYU25Cf5opMjVnCqrzX4eTtuM | The best product teams in the world all ship a weekly changelog that covers all the new updates to the product. If you're not already publishing a changelog, you should be!

Problem is, it takes time every week to look up everything new your team has shipped and write up a post in a consistent style.

At Basedash, we're building an AI agent that has access to your company's data, including tools like GitHub, Jira, and Linear. That means you can use our AI to automatically write your changelog every week, saving you hours every month.

Interested in automating your changelog, or any other data analysis process at your company? Let me know and I'll get you set up. | 20 | 3 | 1 | 1mo | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.030Z |  | 2025-11-07T21:09:07.141Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7387515589516242944 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFYjpwvNsS2dQ/feedshare-shrink_800/B4DZoW6R.JIAAk-/0/1761320968680?e=1766620800&v=beta&t=8zsLD4641ozWHUrFNYQApAV1d5gTqeVeSZVg4heptN4 | We've been running a crazy experiment of letting AI guide our product roadmap, with the goal of optimizing our activation rate. And it's been working.

Here's how it works:

There's a feature in Basedash that lets you run an AI agent in the background to constantly analyze all your business data.

We connected our product database, Google Analytics, Stripe, HubSpot, and basically anything else we thought might be relevant.

We gave the AI a simple task: find ways to improve our activation rate.

Every morning, it sends us a Slack message with its top findings and suggested actions. We've just been implementing everything it tells us to, and our activation rate has gone up 10x. | 148 | 27 | 4 | 1mo | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.030Z |  | 2025-10-24T15:49:29.943Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7387214232519598080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPDmXZtOcQZw/feedshare-shrink_800/B4EZoShGszJ0Ag-/0/1761247260001?e=1766620800&v=beta&t=FvJ2DRDoBcQlhI-mE_PFzm8DpWzFR3Ty4h8ATkYRKb4 | AI is now reaching superhuman levels at data analysis.

At Basedash we've been building tools to empower non-technical business users to make better decisions backed by real data. That dream is finally becoming reality. We have hundreds of companies using Basedash to analyze their data and make better decisions every day.

Tom Johnson's an incredible designer, but he's not a professional data analyst. With Basedash, he can perform competitive data analysis tasks faster than professionals in traditional tools.

This is going to happen across every industry. If you're not already using these AI tools, you should learn them now so you don't fall behind. | 3 | 0 | 1 | 1mo | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.031Z |  | 2025-10-23T19:52:00.836Z | https://www.linkedin.com/feed/update/urn:li:activity:7387206431399387136/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7376329414785155072 | Video (LinkedIn Source) | blob:https://www.linkedin.com/eb6a93fe-4805-4868-9b13-94a167531086 | https://media.licdn.com/dms/image/v2/D4E05AQF923skIilDIQ/videocover-low/B4EZl373CqGcB4-/0/1758653962499?e=1765782000&v=beta&t=1uGJJ4M0FPvL90pViZ4il6j8w08hAdoawANgB5OugHI | Today at Basedash, we're launching Basedash Agent: your new AI data analyst.

It can answer questions, create visualizations, and surface insights on all your company's data.

https://lnkd.in/eiqfTNBp | 11 | 2 | 1 | 2mo | Post | Max Musing | https://www.linkedin.com/in/maxmusing | https://linkedin.com/in/maxmusing | 2025-12-08T06:06:10.037Z |  | 2025-09-23T18:59:38.058Z |  |  | 

---



---

# Max Musing
*Basedash*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [Basedash: Low Code Database Editor with Max Musing](https://softwareengineeringdaily.com/2020/10/12/basedash-low-code-database-editor-with-max-musing/)
*2020-10-12*
- Category: article

### [Max Musing, Founder at Basedash](https://paulgasseedotcom.wordpress.com/testimonial/max-musing-founder-at-basedash/)
*2023-08-28*
- Category: article

### [How Supabase became this generation’s database | Basedash](https://www.basedash.com/blog/how-supabase-became-this-generations-database)
*2024-05-31*
- Category: blog

### [About Basedash - Team - Stack - Careers | Basedash](https://www.basedash.com/about)
*2024-05-31*
- Category: article

### [Basedash | The AI-native Business Intelligence Platform](https://www.basedash.com/blog)
*2025-04-28*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Basedash: Low Code Database Editor with Max Musing - Software ...](https://softwareengineeringdaily.com/2020/10/12/basedash-low-code-database-editor-with-max-musing/)**
  - Source: softwareengineeringdaily.com
  - *Oct 12, 2020 ... Basedash: Low Code Database Editor with Max Musing. SE Daily. By SE Daily. Podcast ... Max Musing is a founder of Basedash, and he jo...*

- **[How Basedash hit $1M revenue with a 7 person team in 2024.](https://getlatka.com/companies/basedash.com)**
  - Source: getlatka.com
  - *Basedash CEO Max Musing shares how Basedash grew to $1M over the past 5 years ... Podcast · Blog. Resources. Churn Calculator · Customer Acquisition C...*

- **[AI Speech to Text Reviews: Mac Voice AI Testimonials | Willow](https://willowvoice.com/testimonials)**
  - Source: willowvoice.com
  - *I love using it." Max Musing. Founder @ Basedash. "Willow is hands down my favorite new way to write. It makes writing long messages, emails, and note...*

- **[11 Canadian startups at Y Combinator's Summer 2020 Demo Day ...](https://betakit.com/11-canadian-startups-at-y-combinators-summer-2020-demo-day/)**
  - Source: betakit.com
  - *Aug 24, 2020 ... Podcast · Newsletter · Quiz · Jobs. 11 Canadian startups at Y ... Founded and run by Max Musing of Montreal, BaseDash is an internal ...*

- **['Dockhunt' site lets you share your macOS dock and discover apps](https://9to5mac.com/2023/02/06/dockhunt-share-your-dock-mac/)**
  - Source: 9to5mac.com
  - *Feb 6, 2023 ... Max Musing, one of the creators of Dockhunt, explained the ... Working on Basedash has introduced me to tons of talented builders. It'...*

- **[Cron - Dockhunt](https://www.dockhunt.com/apps/Cron)**
  - Source: dockhunt.com
  - *Nov 26, 2025 ... Max Musing⋅@MaxMusing · Max Musing's avatar · Texts app icon. Slack app icon. Safari app icon. Notion app icon. Basedash app icon. Th...*

- **[Startups in Montreal Going Places in 2025 | GrowthMentor](https://www.growthmentor.com/location/montreal/startups/)**
  - Source: growthmentor.com
  - *Basedash offers a seamless solution for swiftly converting databases into ... Max Musing. Company Headquarters. Montréal, Quebec, Canada. Industry....*

- **[Slack - Dockhunt](https://www.dockhunt.com/apps/Slack)**
  - Source: dockhunt.com
  - *Basedash · Twitter · GitHub · npm. Sun Nov 30 4:00 PM. Log in. Slack app icon. Slack ... Max Musing⋅@MaxMusing · Max Musing's avatar · Texts app icon....*

- **[SaaSpasse chez Basedash](https://www.saaspasse.com/startups/basedash)**
  - Source: saaspasse.com
  - *Aucun code, déploiement ou maintenance requis. Fondateurs. Max Musing. Fondateur. Suivre. Basedash....*

- **[10 Top Database Startups to Watch in 2025 | TRUiC](https://startupsavant.com/startups-to-watch/database)**
  - Source: startupsavant.com
  - *Oct 24, 2025 ... Basedash. Location: Montréal, Canada; Founders: Max Musing; Founded In ... Podcast. how-to guides. Start a Startup · Start a Small Bu...*

---

*Generated by Founder Scraper*
