# François Bélanger

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392223383477981188 | Text |  |  | 🚀 Élisa recrute ! / Élisa is hiring!
Nous cherchons un·e créateur·trice de contenu et gestionnaire de communauté pour notre nouvelle marque pour les créateurs Roblox / Social Content Creator & Community Manager for our new brand for Roblox creators. | 8 | 0 | 3 | 1mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:10.727Z |  | 2025-11-06T15:36:35.490Z |  | https://www.linkedin.com/jobs/view/4334597724/ | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388940956311535616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ef83de06-6d2a-42f4-95e5-6fff8681684b | https://media.licdn.com/dms/image/v2/D4E05AQHMtS0V0yNM7g/feedshare-thumbnail_720_1280/B4EZoqpXjtKcA0-/0/1761652082135?e=1765778400&v=beta&t=Yn_INrUo2i8WdKDW-wpQCgNd4I6aO88WY_5dXNDKhSs | 🚀 Découvrez comment notre nouvel agent Builder crée des intérieurs entièrement explorables en quelques secondes! / See how our new Builder Agent creates fully explorable interiors in seconds! | 6 | 0 | 0 | 1mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:10.729Z |  | 2025-10-28T14:13:23.869Z | https://www.linkedin.com/feed/update/urn:li:activity:7388937722360594434/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7387194430195286016 | Text |  |  | Élisa is hiring a Plugin Developer – Game Engines (Unity / Unreal / Roblox Studio)! / Élisa recrute un·e Développeur·e de plugins pour moteurs de jeu (Unity / Unreal / Roblox Studio)! | 5 | 0 | 3 | 1mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:10.730Z |  | 2025-10-23T18:33:19.594Z |  | https://www.linkedin.com/jobs/view/4291891855/ | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7366503432293154817 | Text |  |  | 🚀 Élisa recrute ! / Élisa is hiring! | 11 | 0 | 2 | 3mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:10.730Z |  | 2025-08-27T16:14:41.274Z |  | https://www.linkedin.com/jobs/view/4291892873/ | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7364204582337429504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdXWvDv3XAXA/feedshare-shrink_800/B4EZjLopJ0GcAo-/0/1755763190241?e=1766620800&v=beta&t=Mjfa_9loe_U5LLpSCJB2Ge7sF5C3BSr4t_7wupz00wY | Après devcom, Gamescom! Trop content de rencontrer plus de 20 entreprises intéressées par Élisa... en 2 jours 😅  / After devcom, Gamescom! Thrilled to be meeting more then 20 studios and companies interested in Élisa... in 2 days 😅 

#gamescom #jeuxvideoqc #gamesfromquebec #unreal #unity3d | 30 | 1 | 0 | 3mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:10.730Z |  | 2025-08-21T07:59:52.734Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7356329168982142976 | Text |  |  | 🚀 Élisa embauche! / Élisa is hiring!
Nous cherchons un(e) ingénieur(e) cloud passionné(e) par l'infrastructure-as- code, le DevOps, l’IA et le 3D. / We’re looking for a Cloud Platform Engineer to help us scale the fastest conversational 3D scene creator.
🔗 Postulez ici / Apply here: https://lnkd.in/eMZVNNrv

#Emploi #AIJobs #ML #3D #CloudEngineering #GCP #DevOps #MachineLearning #3dGraphics #LLM #Hiring #JobAlert | 7 | 1 | 5 | 4mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.651Z |  | 2025-07-30T14:25:47.872Z |  | https://www.linkedin.com/jobs/view/4277698062/ | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7354169452466163714 | Text |  |  | 🚀 Élisa embauche! / Élisa is hiring!
Nous cherchons un(e) ingénieur(e) en apprentissage automatique passionné(e) par l’IA, le 3D, et les pipelines de données. 
We’re looking for a creative ML Engineer to help us build the fastest conversational 3D scene creator. 
🔗 https://lnkd.in/e3cyqPSU

#Emploi #AIJobs #ML #3D #AIJobs #MachineLearning ⁠#3dGraphics #LLM | 6 | 1 | 0 | 4mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.652Z |  | 2025-07-24T15:23:51.329Z |  | https://www.linkedin.com/jobs/view/4275397319/ | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7340431789288574976 | Video (LinkedIn Source) | blob:https://www.linkedin.com/93928105-121d-4d9f-91c6-6d6256b3c506 | https://media.licdn.com/dms/image/v2/D5605AQGoJMaBqT1L2A/feedshare-thumbnail_720_1280/B56ZdF_GOlHEAs-/0/1749225858925?e=1765778400&v=beta&t=0zOOJmO4nH9Q026Wtt24W3fQnok7kipmxelYGmYhOaA | Thrilled to announce: Élisa is now live on Unity—download, chat, create 3D scenes now! / Fier d’annoncer : Élisa est maintenant sur Unity—téléchargez, jasez, créez vos scènes 3D dès maintenant ! | 6 | 0 | 0 | 5mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.653Z |  | 2025-06-16T17:35:17.194Z | https://www.linkedin.com/feed/update/urn:li:activity:7336785131384225795/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7336785362133897217 | Video (LinkedIn Source) | blob:https://www.linkedin.com/29843f2a-97ce-4376-a4b6-4bfc61e88b38 | https://media.licdn.com/dms/image/v2/D5605AQGoJMaBqT1L2A/feedshare-thumbnail_720_1280/B56ZdF_GOlHEAs-/0/1749225858925?e=1765778400&v=beta&t=0zOOJmO4nH9Q026Wtt24W3fQnok7kipmxelYGmYhOaA | Proud of our team: bringing Élisa to Unity—less than a month after Unreal ! / Fier de notre équipe : Élisa arrive sur Unity, moins d’un mois après le lancement sur Unreal ! | 10 | 0 | 1 | 6mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.653Z |  | 2025-06-06T16:05:41.213Z | https://www.linkedin.com/feed/update/urn:li:activity:7336785131384225795/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7336381424565968898 | Document |  |  | Très heureux de participer à cette conférence cruciale à éclairer le chemin de l’adoption responsable de l’IA dans les industries créatives. | 9 | 6 | 0 | 6mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.654Z |  | 2025-06-05T13:20:34.992Z | https://www.linkedin.com/feed/update/urn:li:activity:7330990293682376706/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7331737634139959296 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8c698f2a-0d94-4476-b707-afd495bb4cf8 | https://media.licdn.com/dms/image/v2/D4E05AQHw5GuZmoaOJA/feedshare-thumbnail_720_1280/B4EZb.NtD.HAAs-/0/1748021728151?e=1765778400&v=beta&t=iDOaZ-uKVnCci9qMOfInvjpGMRs93V1fFTdn5pwwTI4 | Un sommaire de ce qu’Élisa permet de faire dans Unreal: déjà des dizaines d'abonnés! N'hésitez-pas à repartager et upvoter pour notre post Reddit! / An overview of what Élisa can do in Unreal—dozens of new users already! Feel free to reshare and upvote our Reddit post! | 11 | 0 | 1 | 6mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.655Z |  | 2025-05-23T17:47:49.077Z | https://www.linkedin.com/feed/update/urn:li:activity:7331734632188567553/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7329140310557552640 | Article |  |  | Nous avons débuté la R&D Élisa y a plus de 18 mois avec une mission claire : réinventer la création de scènes 3D avec l’IA. Tellement fier de notre équipe!
/ We started R&D on Élisa more than 18 months ago with a clear mission: reinvent 3D scene creation with AI. So proud of our team! | 19 | 6 | 0 | 6mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.655Z |  | 2025-05-16T13:46:58.879Z | https://elisainteractive.com/getaccess |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7325893545662312451 | Video (LinkedIn Source) | blob:https://www.linkedin.com/55eb3c15-ce2a-4197-8898-594228d23c48 | https://media.licdn.com/dms/image/v2/D4E05AQFDnsXeQKmQ_g/feedshare-thumbnail_720_1280/B4EZarLYJCH4A0-/0/1746628609348?e=1765778400&v=beta&t=v0dgFJ51MWGk2hzXMMg5K-GnrHvqId8J34vE6yCnSBY | Concepteurs, auteurs : vous pouvez désormais prototyper vous-même, directement dans Unreal, simplement en discutant avec Élisa! /  Designers and writers: prototype directly in Unreal—just by chatting with Élisa! | 8 | 0 | 1 | 7mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.656Z |  | 2025-05-07T14:45:29.806Z | https://www.linkedin.com/feed/update/urn:li:activity:7325891533562404865/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7323373115613323264 |  |  |  |  | 1 | 1 | 1 | 7mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.656Z |  | 2025-04-30T15:50:12.455Z |  | https://www.linkedin.com/jobs/view/4219801412/ | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7317913350523269120 | Video (LinkedIn Source) | blob:https://www.linkedin.com/97d5d5fe-e022-4924-8638-601933589d21 | https://media.licdn.com/dms/image/v2/D4E05AQGdMz4P9dNYSg/feedshare-thumbnail_720_1280/B4EZY5ucGcHMA8-/0/1744725198865?e=1765778400&v=beta&t=Ww-H4kNASmJCtcrLvCc5GT4O_zc2ytJ6398z7YoVnMo | Another quick look at Élisa in action—this time on mobile! 📱
Building a mobile runner level in minutes with over 1000 assets placed. Fast iteration, real collaboration.

Encore une démo d’Élisa, cette fois pour jeux mobiles ! 🛠️
Niveau de jeu "runner" généré  avec plus 1000 objets placés en quelques minutes. Rapide, fluide, efficace.

👉 https://lnkd.in/eg_d9tjK
#GameDev #UnrealEngine #MobileGame #ElisaInteractive #AI #LevelDesign | 4 | 0 | 0 | 7mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.657Z |  | 2025-04-15T14:15:03.020Z | https://www.linkedin.com/feed/update/urn:li:activity:7317907974805413889/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7310393914379698176 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5e3d69fd-b568-430a-8740-d402a773b3a7 | https://media.licdn.com/dms/image/v2/D4E05AQFybt193_w8lA/feedshare-thumbnail_720_1280/B4EZXOuNXLHUA8-/0/1742929975843?e=1765778400&v=beta&t=0X0eKkhCUFhs3wXJ7MK0UXKaEvBehaCk8C6CwPGSyuc | Incredible response to Élisa at GDC from studios across 3 continents. 🚀
Our first official post is live—follow, reshare, and join the wave:
https://lnkd.in/eg_d9tjK

#ÉlisaInteractive #GDC2025 #GameDev #AI #UnrealEngine #LevelDesign | 15 | 5 | 1 | 8mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.658Z |  | 2025-03-25T20:15:29.739Z | https://www.linkedin.com/feed/update/urn:li:activity:7310378273249591296/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7306339123017990150 | Video (LinkedIn Source) | blob:https://www.linkedin.com/54c4f856-1395-402e-a5f0-eeeccdc2b9ab | https://media.licdn.com/dms/image/v2/D4E05AQHPluJ9BwlgrA/feedshare-thumbnail_720_1280/B4EZWVTOkEHUBE-/0/1741966601601?e=1765778400&v=beta&t=qyQ8Luq46E1ME7_UDilnFqATKvesRNgmwI51Ke2TqlY | Another look at Élisa in action! 

Julien just shared a quick teaser showing how Élisa helps game devs by handling tedious tasks—so artists can focus on creativity.

🎨 How do you see AI assisting in game development? Let’s discuss! and if you’re at GDC 2025, let’s connect! 
Or join the waitlist:
👉 https://lnkd.in/eg_d9tjK

#GDC2025 #GameDev #AI #UnrealEngine #CreativeTech #ÉlisaInteractive | 10 | 0 | 1 | 8mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.659Z |  | 2025-03-14T15:43:12.144Z | https://www.linkedin.com/feed/update/urn:li:activity:7306337581347065859/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7305970502634754048 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3b293d79-a1a0-4cc5-83b0-ea315371635c | https://media.licdn.com/dms/image/v2/D4E05AQE6skO_sh1eAQ/feedshare-thumbnail_720_1280/B4EZWQERIiHUBE-/0/1741878793854?e=1765778400&v=beta&t=n674AREbysklqQek0xUXIZdQAFf-yu6X0DZ71mEQV_E | Proud to be heading to GDC 2025 with Julien to showcase Élisa—our AI-powered tool for faster, smarter 3D scene creation.
We’ll be meeting with studios and artists throughout GDC—if you’re attending and want a closer look, let’s connect! And if you want to be among the first to try Élisa, sign up for the waitlist: https://lnkd.in/eg_d9tjK
Looking forward to seeing many of you there!
#GDC2025 #GameDev #AI #UnrealEngine #CreativeTech | 18 | 1 | 1 | 8mo | Post | François Bélanger | https://www.linkedin.com/in/francoisbel | https://linkedin.com/in/francoisbel | 2025-12-08T05:04:14.660Z |  | 2025-03-13T15:18:26.196Z | https://www.linkedin.com/feed/update/urn:li:activity:7305969237364277249/ |  | 

---

