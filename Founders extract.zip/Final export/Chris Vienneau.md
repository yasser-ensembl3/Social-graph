# Chris Vienneau

## Position actuelle

**Titre** : Founder
**Entreprise** : ME-DMZ
**Durée dans le rôle** : 5 years 7 months in role
**Durée dans l'entreprise** : 5 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Entertainment Providers

## Résumé

I am a senior leader with 25+ years of experience developing tools and services for the entertainment industry for customers such as Disney, Electronic Arts and Google. I have managed market leading tools like Maya, FBX and Arnold generating over 100m per year with consistent 20+% yoy growth. I have fostered innovation on several ground breaking projects like Bifrost, ShaderX and Arnold GPU and have several authored patents. I have managed 100+ person global product teams and integrated several acquisitions. I have overseen partnerships with companies like Apple, Adobe, and Nvidia. I am a huge advocate for standards and open source having driven Autodesk's contributions to the Academy Software Foundation, USD and Materialx. I am currently advising with Movie Labs helping them with their fantastic ten year vision of the future of production and consulting with Fusion workflows helping customers migrate their workflows to the cloud.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABzz4ABSutOgHN2jt4EATVj53XAFV9cXGw/
**Connexions partagées** : 9


---

# Chris Vienneau

## Position actuelle

**Entreprise** : ME-DMZ

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Chris Vienneau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7392648701355184128 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF8REJ6ig3BeA/feedshare-shrink_800/B56ZpfOvLpI0BU-/0/1762534316574?e=1766620800&v=beta&t=C2rujRGDRaGUQQw8B1lErRtULjn6HAWI0Euw9jMO8dc | Such a great day at the MovieLabs forum with the studios and 49 strong members of the new forum. I learned so much and so great to spend time with the people making the future of content creation. | 19 | 0 | 0 | 1mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.939Z |  | 2025-11-07T19:46:39.174Z | https://www.linkedin.com/feed/update/urn:li:activity:7392604771574009857/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7375958305363615744 | Text |  |  | We are just getting started Shailendra Mathur. Can't wait to take Content Core out on the open road and press the pedal to the floor. | 6 | 0 | 0 | 2mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.939Z |  | 2025-09-22T18:24:58.677Z | https://www.linkedin.com/feed/update/urn:li:activity:7373341807952240640/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7375507685212884992 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE2Nvr69O34aA/feedshare-shrink_800/B56Zk46PgqI4Ak-/0/1757596418212?e=1766620800&v=beta&t=xHFxSwPm_ux5QZqz4Zkn5Dw7t89d8xxF0v1AjEAQgeA | These are some great companies figuring out how to get the right data through the production process. | 6 | 0 | 0 | 2mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.940Z |  | 2025-09-21T12:34:22.461Z | https://www.linkedin.com/feed/update/urn:li:activity:7371893694083362817/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7375501809101987840 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF_-vXxP9WkDg/feedshare-shrink_800/B4DZlIPtpNHwAk-/0/1757853707311?e=1766620800&v=beta&t=h19b12zoCkc8akuyatJb_AgvUxpcrP3JTIKjlYyEPdA | So many ask me why I am leaning back into work and the industry after some time away for family and sleep and I can honestly say it is the people and the chance to help people make great content. | 52 | 2 | 0 | 2mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.941Z |  | 2025-09-21T12:11:01.487Z | https://www.linkedin.com/feed/update/urn:li:activity:7372972851680776192/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7372209129484095488 | Article |  |  | So awesome to see this work starting to make it into the products and workflows . Lots more on the way. | 14 | 1 | 0 | 2mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.941Z |  | 2025-09-12T10:07:05.491Z | https://www.televisual.com/news/avid-unveils-avid-content-core/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7283232044292210689 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGgDagBlF_Lfw/feedshare-shrink_800/B4EZRLjc0wHEAo-/0/1736434374263?e=1766620800&v=beta&t=0mm3q9bpmiU9Chbp0fQOchaN09pIqAiql1Wrbjr-r6M | So cool to see this finally coming out! | 11 | 0 | 0 | 10mo | Post | Chris Vienneau | https://www.linkedin.com/in/cvfxdmz | https://linkedin.com/in/cvfxdmz | 2025-12-08T06:12:58.944Z |  | 2025-01-09T21:23:55.267Z | https://www.linkedin.com/feed/update/urn:li:activity:7283149772977278976/ |  | 

---



---

# Chris Vienneau
*ME-DMZ*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Jon Peddie Research Announces Chris Vienneau as Senior Vice President of Media and Entertainment](https://jonpeddie.com/news/jon-peddie-research-announces-chris-vienneau-as-senior-vice-president-of-me)
*2022-01-18*
- Category: article

### [Paul Vienneau](https://jmcgs.blogspot.com/2016/07/profile.html)
*2016-07-19*
- Category: blog

### [Marie Vienneau, FACHE, President & CEO, Mayo Hospital](https://healthleaderforge.blogspot.com/2019/06/marie-vienneau-fache-president-ceo.html)
*2019-06-15*
- Category: blog

### [Two Chances to Meet, Greet and Eat With Local Cookbook Author Nancy Vienneau](https://www.nashvillescene.com/food_drink/two-chances-to-meet-greet-and-eat-with-local-cookbook-author-nancy-vienneau/article_ba116a09-db77-50c1-93c1-4e0733658b18.html)
*2021-05-04*
- Category: article

### [Marie Vienneau, President and CEO, Mayo Hospital (abridged) by HealthLeaderForge](https://creators.spotify.com/pod/profile/healthleaderforge/episodes/Marie-Vienneau--President-and-CEO--Mayo-Hospital-abridged-egra5n)
*2023-12-17*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Who we are](https://fx-dmz.webflow.io/who-we-are)**
  - Source: fx-dmz.webflow.io
  - *We want to see a world where content creators thrive, and the best stories are being told. Meet the ME-DMZ Team. Chris Vienneau. CEO & Founder ......*

---

*Generated by Founder Scraper*
