# Rory Galvin

## Position actuelle

**Titre** : CEO & Founder
**Entreprise** : Navirum
**Durée dans le rôle** : 7 years 8 months in role
**Durée dans l'entreprise** : 7 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Leading Navirum. Helping the next generation of companies to achieve their business goals.

## Résumé

Rory is the visionary founder and CEO of Navirum, a rapidly growing Salesforce consulting firm that serves clients around the globe. With over 15 years of diverse experience at Accenture, Bank of America, and Salesforce, he is passionate about empowering businesses to unlock their full potential through digital innovation. Beyond his professional life, Rory is a devoted husband and father who enjoys cooking, traveling, reading, and exploring a wide range of music. He also aspires to master the guitar one day.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAK5VXMBcV2Uc-ap8GWATTVX22lXntHAV5Q/
**Connexions partagées** : 45


---

# Rory Galvin

## Position actuelle

**Entreprise** : Navirum

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Rory Galvin

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402126664815628289 | Article |  |  | Why Redtail to Salesforce Migrations Are Surging in 2025
Navirum | 3 | 0 | 0 | 4d | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:41.075Z |  | 2025-12-03T23:28:41.755Z | https://medium.com/p/why-redtail-to-salesforce-migrations-are-surging-in-2025-db6686691115?source=social.linkedin&_nonce=cNJvwh9h |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399985342843625472 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFJirXf1GsQLQ/feedshare-shrink_800/B4EZrF5JS3IwAg-/0/1764256683853?e=1766620800&v=beta&t=e_T6xC3kuurrMfWtKr6NtxEiI_2Py8mYzvHNUG2huFk | Bad day to be a turkey 🦃 , great day to be an American 🇺🇸 !!  .. Happy Thanksgiving Y'all ❤️ ..from all of us at Navirum

https://lnkd.in/e3TeksrQ #happythanksgiving #thanksgiving | 3 | 0 | 0 | 1w | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:41.075Z |  | 2025-11-28T01:39:50.813Z | https://www.linkedin.com/feed/update/urn:li:activity:7399828870931107840/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391890246793207808 | Article |  |  | I enjoyed reading Kaitlyn Lawson recent article on  CRM3, effective January 2026. Key points noted: 
- Mandates full disclosure of embedded investment costs (MERs, TERs) in dollar terms. 
- Advisors fear client backlash, regulators and studies show transparency can deepen trust. 
- Success depends on proactive communication, framing value beyond fees, and preparing now to turn compliance into stronger client relationships. 

https://lnkd.in/eeekwQAr #crm3 #crm2 #compliance #regtech #CIRO #CSA #FinancialServices #AdvisorGrowth #ClientEngagement #WealthTech Navirum | 10 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:41.076Z |  | 2025-11-05T17:32:49.515Z | https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387265252645830656 | Article |  |  | Great to take part in the discussion with FormAssembly and Fintech Magazine, sharing insights on automation, cybersecurity, and digital transformation in financial services. At Navirum , we’ve seen firsthand how fixing data at the front end - through secure, automated intake - reduces compliance risk and builds lasting trust.

https://lnkd.in/e4B9PEmP

#DigitalTransformation #Automation #CyberSecurity #FinancialServices #Salesforce #DataIntegrity #FinTech #RegTech #Compliance #Innovation #FormAssembly #Navirum #FinTechMagazine Salesforce Navirum | 10 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:41.078Z |  | 2025-10-23T23:14:44.982Z | https://www.formassembly.com/blog/how-financial-services-can-eliminate-data-chaos-at-the-source/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7384768363874582528 | Text |  |  | Bellissimo! #df25 .. Canadian is a country Luca Benini ! We still still love you over here Navirum | 1 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.476Z |  | 2025-10-17T01:53:00.309Z | https://www.linkedin.com/feed/update/urn:li:activity:7381945117747859456/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7384023671536926720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEs98zwiXTypQ/feedshare-shrink_800/B4EZnkEss0GcAk-/0/1760468061982?e=1766620800&v=beta&t=A3Hr_CXQKEROd3a7NlOl_HA7e6xQthnCAe1oiVsF3bk | CRM 3 (Total Cost Reporting) takes effect January 2026, with major wealth and asset managers already preparing. Learn how Salesforce can streamline compliance: https://lnkd.in/eXYU-8wk #crm3 #df25 #complaince #canada Navirum | 4 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.477Z |  | 2025-10-15T00:33:51.820Z | https://www.linkedin.com/feed/update/urn:li:activity:7383938238807457792/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7382950014186102784 | Article |  |  | The Agentic Revolution: Why AI Will Eat Software and Your Operating Model

Finextra - thanks for the opportunity

#finanicalservices #banking #insurance #wealthmanagement #ai #agentic
Salesforce Navirum | 6 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.478Z |  | 2025-10-12T01:27:31.960Z | https://www.finextra.com/blogposting/29559/the-agentic-revolution-why-ai-will-eat-software-and-your-operating-model |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7382219927161835520 | Video (LinkedIn Source) | blob:https://www.linkedin.com/01393dc8-6b72-42d2-af2b-20b3c2b39554 | https://media.licdn.com/dms/image/v2/D4E05AQGgNgWlrQZ6oQ/videocover-high/B4EZnLpvvtKwCA-/0/1760058364898?e=1765774800&v=beta&t=6OYUMvKaJE2loUal9Qkjz6-wAoLIjz6zeHbOikyNzU4 | Happy Canadian Thanksgiving 🍻🇨🇦🍁

Joyeuse Action de grâce! 🍻🇨🇦🍁 | 26 | 2 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.479Z |  | 2025-10-10T01:06:25.649Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7381883651623522304 | Poll |  |  | Quick pole on CRM3 for Canadian wealth and asset managers 🤓 | 3 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.479Z |  | 2025-10-09T02:50:11.313Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7381830597809442816 | Text |  |  | Some thoughts.. 

The Agentic Revolution: How AI Is Replacing Software and Redefining Work in 2025 

Navirum
#ai #agentic #future #innovation #financialservices #software | 6 | 0 | 0 | 1mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.480Z |  | 2025-10-08T23:19:22.298Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7381341090236383234 | Text |  |  | The Agentic Future Demands an Open Semantic Layer. 

Salesforce is making a first-of-its-kind commitment with an alliance of industry leaders to build towards an open, interoperable future required to accelerate agentic AI.

 ttps://https://lnkd.in/eFWZic63 Salesforce #agentic #ai | 3 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.480Z |  | 2025-10-07T14:54:14.598Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7380020064684761088 | Article |  |  | Discussing Salesforce data security and digital vaults - all important for the financial services industry with Ali M. Qureshi SideDrawer™ Inc. | 9 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.481Z |  | 2025-10-03T23:24:57.563Z | https://medium.com/@rory_9620/the-navirum-podcast-transforming-client-data-management-with-ai-featuring-ali-qureshi-from-2dc01989204f |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7379620323622834176 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSN4l14UAXbQ/feedshare-shrink_800/B4EZleX4VtKwAg-/0/1758224943178?e=1766620800&v=beta&t=knAVX5nylWBxyXD8PmrvjcH2Nc6qcKEiXZSJRQWNujk | Looking forward to joining FormAssembly to discuss compliant cloud solutions for financial services in 2025 and beyond. With the surge in cybercrime this year, secure, encrypted, and compliant solutions are more critical than ever.

#FinancialServices #FinServ #WealthManagement #InsuranceTech #BankingTech #regtech
Navirum | 4 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.481Z |  | 2025-10-02T20:56:31.867Z | https://www.linkedin.com/feed/update/urn:li:activity:7379575911312048129/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7377689590867890176 | Article |  |  | Wealth managers, advisors, and credit unions are rapidly migrating from Redtail, ACT!, and Maximizer to Salesforce FSC - driven by AI adoption, compliance demands, and legacy CRM limits. 

For those considering the move, we posted some useful guides, FAQs, and checklists available. https://lnkd.in/eFepHUEc

#SalesforceFSC #WealthManagement #CRMMigration #FinancialAdvisors #CreditUnions #DigitalTransformation #AI #Redtail #Maximizer #ACT | 7 | 1 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.482Z |  | 2025-09-27T13:04:29.307Z | https://navirum.com/2022/10/07/4-tips-for-migrating-from-redtail-to-salesforce/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7375976032467656704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEnLGf1YKBTog/feedshare-shrink_800/B4EZlytKk9IMAg-/0/1758566067292?e=1766620800&v=beta&t=StgOCir_tg-Mw-8nFzFzawhw3hlaq_vrzpCnHvQsMzk | 🚨 New Podcast! 🎙️ Episode #3 explores Salesforce cybersecurity, AI’s impact, and today’s threat landscape with Valo CEO Jari Salomaa - essential insights for financial services companies. #cybersecurity #salesforce #financialservices Navirum | 6 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.483Z |  | 2025-09-22T19:35:25.148Z | https://www.linkedin.com/feed/update/urn:li:activity:7375960696678928384/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7374929233481060352 | Article |  |  | 😀 We’re Hiring: Salesforce Technical Lead 😀

Navirum’s Technical Services Practice is growing fast - and we’re looking for a Salesforce Technical Lead to join the team. This is a big one.

We want someone who is:

✅ Passionate about technology & building software solutions
✅ The type who nerds out on tech even on weekends (join the club 🤓)
✅ Humble, hardworking, collaborative, and service-oriented (the stuff your friends & family say about you… not just your résumé 😅)
✅ Naturally technical, with a deep sense of how great software should be built

Why Navirum?
 ✨ Average tenure here is 3+ years (pretty rare in consulting)
 ✨ A culture built on innovation, learning, and real client impact
 ✨ A team that values trust, growth, and having fun along the way

You’ll work with some of the biggest financial institutions in the world. The learning and growth potential is massive - but it’s up to you to grab it.

If this sounds like you (or someone you know), check out the role ⤵️ 
 🔗 Salesforce Technical Lead - https://lnkd.in/eeBTDH6a

#SalesforceJobs #SalesforceTechnicalLead #FinancialServices #DigitalTransformation #Hiring #TechCareers #JoinOurTeam
Navirum Lavinia Picu Debbie-Anne Cheng Lin Cinchana Pushparaj | 9 | 0 | 3 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.484Z |  | 2025-09-19T22:15:48.821Z | https://ca.indeed.com/job/salesforce-technical-lead-ea3a481b7dea7465 |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7374614540640002048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEt5Qmhz5oNbA/feedshare-shrink_800/B4EZlfk0s9GoAk-/0/1758245117929?e=1766620800&v=beta&t=oPbS6BBlJgSX0jHmEgEyhb1uUZJ5AnOYAw3_bV-RW04 | Thanks for a wonderful evening Deloitte. Navirum’s tax and innovation partner. 

Great to meet fellow minded businesses and the wider team. We’re all about partnerships at Navirum. Teamwork makes the dream work! | 26 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.485Z |  | 2025-09-19T01:25:20.201Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7372412548442136576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH7sCF3TJdDtQ/feedshare-shrink_800/B4EZk9G_JNKwAg-/0/1757666866158?e=1766620800&v=beta&t=sJPJWSP0ZvVGBEstWPee6T6V9SR5xRWPM3LgnD0nGbI | 💥 Noticed a drop in web traffic this year? You are not alone ⬇️ | 2 | 0 | 0 | 2mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.486Z |  | 2025-09-12T23:35:24.350Z | https://www.linkedin.com/feed/update/urn:li:activity:7372189174113656832/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7370114285127041024 | Text |  |  | We’re hiring! 🚀
From experienced financial services professionals to Salesforce consultants, developers, and beyond - a range of exciting roles are open.
👉 More details here: 

https://lnkd.in/eseCj4qg

#Hiring #JoinOurTeam #Careers #FinancialServices #SalesforceJobs #ConsultingCareers #TechJobs #WeAreHiring #LifeAtNavirum #NowHiring #Developers #SalesforceConsultant #FinancialServicesCloud #DigitalTransformation | 15 | 0 | 1 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.489Z |  | 2025-09-06T15:22:55.676Z | https://www.linkedin.com/feed/update/urn:li:activity:7369883255199916032/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7369898595010899968 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHfz8O-dkPEFg/feedshare-shrink_800/B4EZkcjt12KkAg-/0/1757120750042?e=1766620800&v=beta&t=_44LE9Nqtb17miAjYSEq3naBadbtyTrGRi2peTAcyFI | I had a great week in Chicago 

Fueled by too much Blue Bottle Coffee ☕️ … thanks to Intercom's Aaron Cooley. 

Great to be back in the amazing Salesforce Tower on the banks of the Chicago River alongside our partners TaskRay and FormAssembly, before wrapping things up with Matthew Perrigo and his fantastic team for an evening of darts, cheer, and banter at Flight Club USA...as Oasis dialed down, the competition amped up - darts were flying and so was the NFL speculation. Will this be the season for the Chicago Bears? I can’t wait to see 🚀 🚀 🚀 …

These events don't happen on their own Lavinia Picu Debbie-Anne Cheng Lin, and Navirum great job organizing!

Back again very soon!

#gobears #chicago #salesforce #financialservices | 40 | 1 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.489Z |  | 2025-09-06T01:05:51.145Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7367321183790268418 | Text |  |  | On behalf of the Navirum Team, wishing our clients, team, partners, and community a wonderful Labor Day weekend across North America 🇺🇸 🇨🇦. 

It’s one of my favourite times of year - the shift in seasons (at least here in the Northeast 🍂), kids going back to school 😭 😁, and the faint whiff of pumpkin spice latte in the air 😆 

Enjoy all!

#LaborDayWeekend #HappyLaborDay #NorthAmerica #Canada #USA #EndOfSummer #BackToSchool | 6 | 0 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.490Z |  | 2025-08-29T22:24:08.424Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7366995306170699776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE1kL1uNBWHsg/feedshare-shrink_1280/B4EZjzMTtaGYAw-/0/1756426747516?e=1766620800&v=beta&t=QJ8kmTkKdurXHpoV-oaEESLPjyu063cNX2y-SHZ3tKA | Chicago - its good to be back! https://lnkd.in/ewSiq-YG

Navirum Salesforce #chicago | 8 | 0 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.491Z |  | 2025-08-29T00:49:13.145Z | https://www.linkedin.com/feed/update/urn:li:activity:7366987735347142656/ |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7365023414455083009 | Text |  |  | 🧭 AI Readiness for Financial Services: Take the Leap with Confidence

AI is the biggest risk - and the biggest opportunity - our industry has faced since the internet. Fintechs move fast, incumbents hold trust. The winners will be those who prepare now and take the leap with confidence.

#AI #FinancialServices #AIReadiness #DigitalTransformation #Fintech #WealthManagement #Trust #Innovation #Compliance #FutureOfFinance #Salesforce Navirum | 6 | 2 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.491Z |  | 2025-08-23T14:13:37.524Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7364064185946701825 | Article |  |  | I enjoyed Bryan Clagett’s recent Substack piece on stablecoins and their implications for the banking system - the pros and cons, and the broader trend toward blockchain, for better or worse

https://lnkd.in/ebVtB8Rj

.. the only question is Bryan...who does your artwork 😆 ? | 1 | 0 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.492Z |  | 2025-08-20T22:41:59.626Z | https://substack.com/home/post/p-170938503 |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7363189177443590144 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGUCH99eVh3lg/feedshare-shrink_800/B4EZivaW4WGUAg-/0/1755289579841?e=1766620800&v=beta&t=2Bn0Ex9mh2ESfDIXPqZoom9UAZ3TH_z7E45ZOtk4BBA | We're Hiring: Salesforce Technical Delivery Consultant 

https://lnkd.in/eAmf7K79

#SalesforceJobs #NowHiring #TechJobs #SalesforceConsultant 
#ConsultingCareers #DeliveryConsultant Cinchana Pushparaj Navirum | 4 | 0 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.493Z |  | 2025-08-18T12:45:01.342Z | https://www.linkedin.com/feed/update/urn:li:activity:7362218115096530945/ |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7362503558056841216 | Text |  |  | ✨ For Advisors, Succession Isn’t An Event - It’s a Strategy ✨ 

At Navirum, we’ve partnered with thousands of advisors across North America, and succession planning consistently stands out as the most important - and most difficult - initiative they face. Not because of markets or products, but because it’s about legacy, clients, and the business built over decades.

Yet, 60% of Financial Advisors have no succession plan, even when they’re within 10 years of retirement? 

Some thoughts on what Advisors can do...

#SuccessionPlanning #FinancialAdvisors #BusinessExit #WealthManagement #RetirementPlanning #RIA #Advisors | 10 | 6 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.494Z |  | 2025-08-16T15:20:36.942Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7362199294780530688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFRkRs2X3JGQ/feedshare-shrink_800/B4EZiuzQ_rGUAk-/0/1755279331921?e=1766620800&v=beta&t=v0-1lV7ARF38fPgGtIVyX5_cg0wc695iw-Rp1j8ixlw | We’re excited to announce Navirum’s partnership with Intercom, a leading customer support platform with powerful AI capabilities, enabling us to deliver even more client-centric, high-impact solutions. 🎉 🥂 

https://lnkd.in/e-96sm7b. | 2 | 0 | 0 | 3mo | Post | Rory Galvin | https://www.linkedin.com/in/rorygalvin | https://linkedin.com/in/rorygalvin | 2025-12-08T04:52:46.495Z |  | 2025-08-15T19:11:34.924Z | https://www.linkedin.com/feed/update/urn:li:activity:7362175129327390720/ |  | 

---



---

# Rory Galvin
*Navirum*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [When to Hire Your First Salesperson](https://paulhigginsmentoring.com/when-to-hire-your-first-salesperson-with-rory-galvin/)
*2024-07-01*
- Category: article

### [How Salesforce Transforms Venture Capital Firms - Navirum](https://navirum.com/2025/11/07/how-salesforce-transforms-venture-capital-firms-2/)
*2025-11-07*
- Category: article

### [Salesforce Consulting and Support for Financial Service - Navirum](https://navirum.com/about-navirum-salesforce-consulting/)
*2020-09-19*
- Category: article

### [#salesforce strategy Archives - Navirum](https://navirum.com/tag/salesforce-strategy/)
*2024-05-10*
- Category: article

### [Kristina, Author at Navirum](https://navirum.com/author/kristina/)
*2025-10-01*
- Category: article

---

## 📖 Full Content (Scraped)

*9 articles scraped, 20,417 words total*

### When to Hire Your First Salesperson
*740 words* | Source: **EXA** | [Link](https://paulhigginsmentoring.com/when-to-hire-your-first-salesperson-with-rory-galvin/)

[![Image 1](https://paulhigginsmentoring.com/wp-content/uploads/2024/07/PHS-Rory-Galvin.png)](https://paulhigginsmentoring.com/when-to-hire-your-first-salesperson-with-rory-galvin/ "546 – When to Hire Your First Salesperson with Rory Galvin")

Subscribe to the Podcast Now!

![Image 2: Apple_podcast_logocolor__03](https://paulhigginsmentoring.com/wp-content/uploads/tcb_content_templates/images/Apple_podcast_logocolor__03.png)

Listen on

Apple Podcast

![Image 3: GPodcastLogo-Symbol](https://paulhigginsmentoring.com/wp-content/uploads/tcb_content_templates/images/GPodcastLogo-Symbol.png)

Listen on

Google Podcasts

![Image 4: Spotify-Logo-Symbol](https://paulhigginsmentoring.com/wp-content/uploads/tcb_content_templates/images/Spotify-Logo-Symbol.png)

Listen on

Spotify

![Image 5: Castbox-Logo-Symbol](https://paulhigginsmentoring.com/wp-content/uploads/tcb_content_templates/images/Castbox-Logo-Symbol.png)

Listen on

Castbox

**546 - When to Hire Your First Salesperson with Rory Galvin**

**Why you should listen**

1.   Learn when and how to hire your first salesperson to scale your tech consulting business.
2.   Discover strategies for building a high-quality, effective team.
3.   Gain insights into maintaining a strong company culture and leveraging your network for growth.

You've grown your tech consulting business and are juggling too many responsibilities, one of which is sales. In this episode, I talk to Rory Galvin, founder and CEO of Navirum, about the crucial decision of when to hire your first salesperson and how to build a high-performing team. Rory shares his journey from the corporate world to founding Navirum, his insights on scaling through quality hires, and the importance of cultivating a strong company culture. Tune in to learn from Rory's extensive experience and practical advice.

**Key Highlights**

*   **Ideal clients and problems solved:** Navirum's ideal clients are mid-market wealth and investment management firms with decent budgets and a vision for growth. The key problems they solve include delivering the best client experience, improving internal productivity, navigating regulatory changes, and integrating Salesforce with other critical systems.
*   **Transition from Salesforce to starting Navirum:** Rory enjoyed his time at Salesforce and the training they provided in sales and marketing. When his wife got a job in Canada, he saw an opportunity to start his own consulting business, despite having to build a new network from scratch in the new country.
*   **Hiring the first salesperson:** After running sales himself for the first 3-4 years, Rory decided to hire a dedicated salesperson to help scale the business. This was driven by a need to increase sales capacity and free up Rory's time. The new salesperson had prior enterprise software sales experience.
*   **Building the team and company culture:** Navirum has a remote-first model with a focus on flexibility and work-life balance for employees. The compensation structure includes a base salary plus bonuses tied to individual and company performance. Rory emphasizes the importance of treating the team well, as they are the company's most valuable asset.
*   **Lessons learned and future plans:** Rory shares that one of the key lessons he's learned is the critical role that people play in the success of the business. He is looking to continue growing Navirum's reputation as a leading financial services technology consulting firm, and is open to getting advice from experienced entrepreneurs to help guide the company's future.

**About****Rory Galvin**

Rory is the founder and CEO of Navirum, a high-growth Salesforce consulting company serving Clients across the globe. Before setting up the business, Rory spent over fives years in the financial services division of Salesforce helping a broad range of traditional banks and insurance companies, as well as new innovative fintech companies to reach their business goals using Salesforce. Before joining Salesforce, Rory spent over 7 years working in consulting for Accenture and as an analyst with the investment bank Merrill Lynch. Rory holds a B.A. in ICT (Computer Science) and an MBA from Trinity College Dublin. Rory is a certified Salesforce Administrator, Sales Cloud, Service Cloud Consultant and Salesforce Trailhead Ranger.

**Resources and Links**

*   [Navirum.com](https://navirum.com/)
*   [Rory’s LinkedIn profile](https://www.linkedin.com/in/rorygalvin/)
*   [Indeed](https://indeed.com/)
*   [Join the Salesforce Partner Program](https://partners.salesforce.com/)
*   [Salesforce Financial Services Cloud](https://www.salesforce.com/financial-services/)
*   Previous episode: [545 - Using AI to Improve Sales Call Rapport](https://paulhigginsmentoring.com/using-ai-to-improve-sales-call-rapport/)
*   [Check out more episodes of The Paul Higgins Show](https://paulhigginsmentoring.com/podcast/)
*   [Paul Higgins Mentoring Youtube channel](https://www.youtube.com/@PaulHigginsMentoring

*[... truncated, 1,536 more characters]*

---

### How Salesforce Transforms Venture Capital Firms - Navirum
*1,191 words* | Source: **EXA** | [Link](https://navirum.com/2025/11/07/how-salesforce-transforms-venture-capital-firms-2/)

How Salesforce Transforms Venture Capital Firms’ Operations: From Deal Sourcing to Portfolio Management
-------------------------------------------------------------------------------------------------------

November 7, 2025

[![Image 1](https://secure.gravatar.com/avatar/d7a0ffd95d6d7ce67d8e59fd322df7cb7b31231a9f2cc7d19b42896915752cb8?s=48&d=mm&r=g)](https://navirum.com/author/lavinia/)

Lavinia Picu

Venture Capital’s New Operational Mandate
-----------------------------------------

Venture capital has always been about identifying tomorrow’s winners today. But in today’s increasingly competitive and data-rich landscape, success demands more than instinct and networks—it requires visibility, speed, and operational precision.

Managing hundreds of relationships across LPs, startups, co-investors, and funds—while keeping tabs on performance metrics and fundraising—has become increasingly complex. Excel sheets and fragmented tools are no longer enough.

That’s where Salesforce enters the picture.

**Salesforce for Venture Capital** is more than just a CRM—it’s an end-to-end platform that connects deal sourcing, pipeline tracking, investor relations, and portfolio insights in one secure, customizable interface. Whether you’re a partner at a growth fund, an investor relations lead, or an operations executive, [Salesforce](https://www.salesforce.com/ca/?ir=1) helps you scale your firm’s impact while staying agile and data-driven.

In this article, we explore how Salesforce empowers VC firms to streamline operations, improve collaboration, and make faster, smarter investment decisions.

#1 Centralize Deal Flow and Relationship Intelligence
-----------------------------------------------------

Venture capital is fundamentally a relationship business. But managing thousands of connections across founders, angels, accelerators, and other funds is nearly impossible without a system of record.

Salesforce allows you to capture every interaction—emails, meetings, notes, follow-ups—linked directly to contacts, startups, and deals. The result? A dynamic, living repository of institutional knowledge accessible across your team.

### Benefits:

*   Eliminate duplicate efforts and lost opportunities
*   Instantly access a history of all touchpoints with a founder or startup
*   Customize scoring criteria and funnel stages for your firm’s investment thesis

**VC Insight**: Partners and investment professionals can instantly identify which team member has the strongest relationship with a founder and prioritize outreach accordingly.

#2 Accelerate Due Diligence and Internal Collaboration
------------------------------------------------------

When a high-potential deal hits your inbox, timing is everything. But vetting, collaborating, and coordinating across partners can quickly become a bottleneck—especially across remote teams.

With Salesforce, you can build deal-specific workspaces that integrate data rooms, diligence templates, and task assignments in one shared view. Use [Slack](https://navirum.com/2025/09/18/salesforce-slack-integration-6-practical-benefits/) for real-time updates and approval workflows to move faster from inbound to term sheet.

### Benefits:

*   Centralize notes, documents, and investor memos
*   Automate reminders for follow-ups and stage transitions
*   Ensure consistent evaluation criteria across investment committee members

**VC Insight**: Associates and analysts save time and reduce context-switching; GPs stay informed and in control without micromanaging.

#3 Better Fundraising and LP Engagement
---------------------------------------

Managing Limited Partner relationships is just as critical as sourcing top-tier deals. With Salesforce, you can build a full picture of LP touchpoints, fundraising progress, and commitments—so your IR team is always prepared and proactive.

Track fund subscriptions, capital calls, side letters, and communications over time—whether you’re managing one fund or a dozen.

### Benefits:

*   Segment LPs by geography, fund, commitment size, and interest
*   Automate capital call reminders and quarterly reporting
*   Use email journeys to keep LPs updated on performance and insights

**VC Insight**: IR teams can personalize outreach at scale, while partners gain clarity on fundraising cycles and LP sentiment ahead of renewal conversations.

#4 Real-Time Portfolio Management and Insights
----------------------------------------------

Once you’ve invested, the real work begins. Tracking portfolio performance manually across dozens of startups leads to inconsistent data, missed red flags, and reactive rather than proactive support.

With Salesforce, you can build dashboards to track metrics like ARR, burn rate, headcount, and fundraising runway—automatically updated via integrated founder surveys or API connections to financial tools like QuickBooks, Xero, or Carta.

### Benefits:

*   Get real-time visibility into portfolio health across sectors and stages
*   Iden

*[... truncated, 5,150 more characters]*

---

### Salesforce Consulting and Support for Financial Service - Navirum
*422 words* | Source: **EXA** | [Link](https://navirum.com/about-navirum-salesforce-consulting/)

Transforming Financial Services With Salesforce And AI Solutions

![Image 1](https://navirum.com/wp-content/uploads/2020/09/dots.svg)

Our Mission
-----------

Navirum’s mission is to **improve the quality of the financial system – and, in turn, people’s lives**. We do this by equipping **banking, insurance, and wealth** firms with **Salesforce and AI** to connect data, automate work, and embed governance. We **constantly innovate** and **push to be our best**, so financial professionals deliver faster, safer, more human experiences at scale.

![Image 2](https://navirum.com/wp-content/uploads/2020/09/dots.svg)

How We Create Value
-------------------

Navirum helps financial firms win on Salesforce with senior-led strategy, implementations, and managed services. **We cover the full [Salesforce stack](https://navirum.com/services/) for financial firms: [Financial Services Cloud](https://navirum.com/salesforce-financial-services/?utm_source=chatgpt.com), core CRM (Sales/Service Cloud), Marketing Cloud, and Agentforce.** We combine advisory, delivery, and Orbit managed services to turn Salesforce into measurable outcomes – faster onboarding, tighter governance, and lower operating cost. Our architects and PMs have shipped thousands of complex, regulated projects across banking, insurance, and wealth, and **50%+ of our work is repeat business.** Our average **[CSAT score](https://appexchange.salesforce.com/appxSearchKeywordResults?keywords=Navirum&type=consultants)**is 4.75+. We accelerate results with **[insights](https://navirum.com/blog)**, proven **[ecosystem partners](https://navirum.com/our-network-of-partners?utm_source=chatgpt.com)** and ISVs to reduce risk, time-to-value, and produce the best outcomes for our clients for the long term.

![Image 3](https://navirum.com/wp-content/uploads/2020/09/rory.png)

#### Rory Galvin

CEO

Founder
-------

Rory Galvin is the founder and CEO of Navirum, a Salesforce consultancy for financial services he launched in 2018. Before Navirum, Rory spent 15+ years in **Salesforce’s Financial Services** organization helping banks, insurers, and fintechs achieve measurable outcomes with Financial Services Cloud and secure integrations. Earlier, he worked in consulting at **Accenture** and as a Senior Analyst at **Merrill Lynch**. Rory holds a **BA in ICT (Computer Science)** and an **MBA** from Trinity College Dublin. He writes on [**Finextra**](https://www.finextra.com/?utm_source=chatgpt.com), mentors founders with [**Futurpreneur Canada**](https://futurpreneur.ca/?utm_source=chatgpt.com), is a proud **D****ad**, and you can connect with him on **[LinkedIn](https://www.linkedin.com/in/rorygalvin/?utm_source=chatgpt.com)**.

The Name Navirum?
-----------------

The name Navirum comes from a contraction of the Latin phrase _navigare ad futurum_, which loosely translates to ‘navigate to the future.’ It reflects what we do for our clients – helping them navigate toward the future potential of their companies. What started as a small attempt at originality has become a great conversation starter with staff, clients, and partners

The name Navirum comes from a contraction of the Latin phrase _navigare ad futurum_, which loosely translates to ‘navigate to the future.’ It reflects what we do for our clients – helping them navigate toward the future potential of their companies. What started as a small attempt at originality has become a great conversation starter with staff, clients, and partners

About Navirum 09.19.2020

---

### Kristina, Author at Navirum
*7,189 words* | Source: **EXA** | [Link](https://navirum.com/author/kristina/)

[![Image 1: How Salesforce Helps Mortgage Brokers To Win More Deals](https://navirum.com/wp-content/uploads/2023/03/How-Salesforce-Helps-Mortgage-Brokers-To-Win-More-Deals.png)](https://navirum.com/2023/03/02/how-can-salesforce-financial-service-cloud-help-mortgage-brokers-in-the-united-states/)

[5 Powerful Ways Salesforce Helps Mortgage Brokers Win More Deals](https://navirum.com/2023/03/02/how-can-salesforce-financial-service-cloud-help-mortgage-brokers-in-the-united-states/ "Permalink to 5 Powerful Ways Salesforce Helps Mortgage Brokers Win More Deals")
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

October 1, 2025

_At **Navirum**, we specialize in helping **mortgage brokers** grow their business using [**Salesforce Financial Services Cloud (FSC)**](https://www.salesforce.com/financial-services/cloud/)— the world’s #1 CRM. In today’s highly competitive mortgage industry, success hinges on efficiency, compliance, and client experience._

_Salesforce gives brokers a powerful edge by automating workflows, enhancing client communications, and ensuring regulatory compliance. Below are five key ways **Salesforce FSC** can help your mortgage brokerage win more deals and scale efficiently._

What is Salesforce Anyway?

5 Ways to Win More Deals
------------------------

**#1 Streamline Lead Generation and Management**
------------------------------------------------

Effective **lead management** is critical for growing a mortgage business. **Salesforce Financial Services Cloud** helps brokers:

*   Capture and track leads from multiple sources
*   Analyze lead behavior and engagement
*   Prioritize high-quality leads for outreach

With these insights, brokers can focus their energy where it matters most—on qualified prospects—leading to faster conversions and a stronger sales pipeline.

**#2**Simplify Loan Origination and Processing
----------------------------------------------

Loan origination can be time-consuming without the right tools. Salesforce helps brokers manage the full **loan lifecycle**, from initial application to closing, by:

*   Centralizing borrower data
*   Tracking application progress in real time
*   Automating communication with clients and internal teams

Salesforce also integrates seamlessly with popular mortgage systems like [Encompass](https://app.salesforceiq.com/r?target=63ff8846e6e2af296d375698&t=AFwhZf2EW-wSHDIV6BuQGoJ4_1X76QyEXExd8SfeSQNboCyByPyMUN6e_70PlFQFLm2Be23HXySRic1gmHu_mOo0AqrKxd-GZMF8K4bEEE7AYCTgDjr8h9Qp3TYsh49Z571QEj4m4ooz&url=https%3A%2F%2Fwww.icemortgagetechnology.com%2Fproducts%2Fencompass) reducing manual data entry and improving speed-to-close.

**#3 Stay Ahead of Regulatory Compliance**
------------------------------------------

Compliance is a top concern for mortgage professionals. **Salesforce FSC** supports brokers by offering:

*   Automated tracking of disclosures and document submissions
*   Real-time alerts on changing regulations
*   Detailed audit trails to ensure full transparency

This makes it easier to remain compliant while reducing the administrative burden on your team.

**#4 Build Stronger Customer RelationshipsCustomer Relationship Management:**
-----------------------------------------------------------------------------

Great client experience drives repeat business and referrals. Salesforce helps mortgage brokers build trust and loyalty by:

*   Keeping client records and communication history in one place
*   Automating personalized follow-ups and updates
*   Providing secure client portals for real-time loan updates

This level of **customer relationship management** improves satisfaction and keeps clients engaged throughout the loan process.

#5 **Gain Insights with Analytics and Reporting**
-------------------------------------------------

Data-driven decisions give you a competitive edge. Salesforce provides robust **analytics and reporting tools** that allow mortgage brokers to:

*   Monitor loan volume and conversion rates
*   Track sales performance and pipeline metrics
*   Identify bottlenecks and optimize processes

These insights help you run a more efficient and profitable mortgage operation.

Salesforce Agentforce is Game Changer For Financial Services Firms

Ready to Grow Your Mortgage Business with Salesforce?
-----------------------------------------------------

At **Navirum**, we help mortgage brokers implement and optimize **Salesforce Financial Services Cloud** to unlock growth and efficiency. Whether you’re just starting or looking to improve your existing Salesforce setup, our expert team is here to help.

Ready to Grow Your Mortgage Business with Salesforce? Book A Consultation
-------------------------------------------------------------------------

Recent Navirum Client Success Stories
---------

*[... truncated, 62,580 more characters]*

---

### Rory Galvin - Navirum
*759 words* | Source: **GOOGLE** | [Link](https://navirum.com/our-team/rory-galvin/)

**Background**
--------------

#### **About Rory**

Is the Founder & CEO of Navirum, where he leads business growth and drives innovation. With more than 17 years of experience in technology consulting, financial services, and Salesforce, Rory helps organizations harness cutting-edge technology to scale efficiently. He is passionate about building Navirum into a global leader in Salesforce-based business solutions, empowering companies to unlock their full potential through innovative technology and strategic guidance. Rory believes in fostering a culture of collaboration and innovation. His leadership style is guided by his personal and company values that focus on empowering teams to excel while providing top-tier solutions to clients to help them achieve their unique goals. Favourite parts of the Navirum website are:

*   **[Client Stories](https://navirum.com/navirum-proven-success-in-salesforce-ai-and-financial-services/)**
*   **[Leadership Team](https://navirum.com/team/)**
*   **[Salesforce Expertise](https://navirum.com/salesforce-expertise-for-financial-services/)**
*   **[Navirum Podcast](https://navirum.com/exec-talk-salesforce-ai-financial-services-podcast/)**&**[Blog](https://navirum.com/blog/)**

**Entrepreneurship**
--------------------

#### **Early Days**

Rory has always been passionate about building businesses and helping companies achieve their goals. His entrepreneurial spirit began early—by the age of 18, he had already delivered newspapers, cut grass for neighbors, organized garage sales, and managed local businesses. These experiences helped him develop a strong work ethic, a deep appreciation for community, and an understanding of the importance of customer relationships.

#### **Breaking Out**

This foundation, combined with his love of problem-solving and technology, eventually led him to found**[Navirum](https://www.navirum.com/)**, which is Rory’s second company. Rory founded a niche investment technology company called GCS, in London in 2010, which was exited in 2012 as a profitable business.

#### **Navirum’s Growth**

Rory grew **[Navirum](https://ca.linkedin.com/company/navirum)** from a small desk in the spare bedroom in Montreal to a thriving international business with clients across the **United States, Canada, Europe, and Asia**, showcasing his ability to scale a business globally while maintaining a strong client-focused approach.

#### **Helping Others**

Rory is also passionate about supporting entrepreneurs at every stage of their journey and encourages them to reach out directly for a personal meeting (**[Linkedin](https://ca.linkedin.com/in/rorygalvin)**) to discuss their business challenges and goals.

**Corporate Life**
------------------

#### **From Consulting and Banking**

Before starting Navirum, Rory gained deep industry experience in consulting, banking, and cloud technology. He began his career at**[Accenture](https://www.accenture.com/)**, where he worked in technology consulting, helping Fortune 500 clients with digital transformation. He then moved to**[Bank of America](https://www.bankofamerica.com/)**, where he held multiple roles in investment banking, gaining firsthand experience in financial operations and large-scale corporate strategies.

#### **To Salesforce**

After that, Rory spent over 7 years at**[Salesforce](https://www.salesforce.com/)**, working in various roles and helping global enterprises drive business success through the Salesforce platform.

#### **Thought Leadership**

Rory is a frequent contributor to industry conversations, sharing insights on technology, financial services, business, and life across platforms including [LinkedIn](https://www.linkedin.com/in/rorygalvin/recent-activity/articles/), [FinExtra](https://www.finextra.com/blogposting/29150/for-advisors-succession-isnt-an-event---its-a-strategy), [Substack](https://rorygalvin437022.substack.com/), [Medium](https://medium.com/@rory_9620) ([Salesforce](https://medium.com/@rory_9620/20-salesforce-insurance-success-stories-cc9e9c89fc97), [financial services](https://medium.com/@rory_9620/the-harsh-reality-of-moving-to-a-new-investment-platform-and-how-to-avoid-the-pain-ed12b40ea9e7), [AI&Tech](https://ai.plainenglish.io/the-agentic-revolution-how-ai-is-replacing-software-and-redefining-work-in-2025-26278dc206df)), and the [Navirum Blog](https://navirum.com/blog/) and[podcast](https://open.spotify.com/show/0XbVpMn2kKueAvrJoia3rt).

**Personal Life**
-----------------

#### **Education**

Rory holds a B.A. in Computer Science (ICT) from**[Trinity College Dublin](https://www.tcd.ie/)** and an MBA. He is also a**[Salesforce Certified Professional](https://www.salesforce.com/certification)** (4 certifications) and a PRINCE2-Certified Project Manager.

#### **Family and Fitness**

Rory is based in Montreal with his family and is passionate about sports, cooking, and travel. He is an active member of the[**Montreal Shamrocks GAA**](https://www.montrealshamrocks.com/) (Gaelic f

*[... truncated, 2,414 more characters]*

---

### Rory Galvin
*711 words* | Source: **GOOGLE** | [Link](https://www.moneyneversleeps.ie/guests/rory-galvin/)

Rory Galvin

===============

[![Image 6: MoneyNeverSleeps podcast by Pete Townsend](https://images-cf.getpodpage.com/cdn-cgi/image/quality=70,fit=contain,height=30,format=auto,dpr=1/https://s3.us-west-1.amazonaws.com/redwood-labs/showpage/uploads/images/b075829d-f952-4fe2-9abd-7fcc887177a2.png)](https://www.moneyneversleeps.ie/)

*   [Episodes](https://www.moneyneversleeps.ie/guests/rory-galvin/#)[All Episodes 299](https://www.moneyneversleeps.ie/episodes/)
###### By Category

[Startups 7](https://www.moneyneversleeps.ie/categories/startups/)[entrepreneurship 119](https://www.moneyneversleeps.ie/categories/entrepreneurship/)[founder 168](https://www.moneyneversleeps.ie/categories/founder/)[Flywheels 5](https://www.moneyneversleeps.ie/categories/flywheels/)[Venture Capital 70](https://www.moneyneversleeps.ie/categories/ventures/)[Crypto 125](https://www.moneyneversleeps.ie/categories/crypto/)[web3 70](https://www.moneyneversleeps.ie/categories/web3/)[Blockchain 132](https://www.moneyneversleeps.ie/categories/blockchain/)[Distributed Ledger Technology 31](https://www.moneyneversleeps.ie/categories/distributed-ledger-technology/)[fintech 11](https://www.moneyneversleeps.ie/categories/fintech-1/)[See all categories →](https://www.moneyneversleeps.ie/categories/)
###### By Season

[Season 0 1](https://www.moneyneversleeps.ie/guests/rory-galvin/)[Season 1 31](https://www.moneyneversleeps.ie/episodes/season/1/)[Season 2 37](https://www.moneyneversleeps.ie/episodes/season/2/)[Season 3 46](https://www.moneyneversleeps.ie/episodes/season/3/)[Season 4 48](https://www.moneyneversleeps.ie/episodes/season/4/)[Season 5 33](https://www.moneyneversleeps.ie/episodes/season/5/)[Season 6 41](https://www.moneyneversleeps.ie/episodes/season/6/)[Season 7 32](https://www.moneyneversleeps.ie/episodes/season/7/)[Season 8 18](https://www.moneyneversleeps.ie/episodes/season/8/)  
*   [About](https://www.moneyneversleeps.ie/about/)
*   [Reviews](https://www.moneyneversleeps.ie/guests/rory-galvin/#)[All Reviews](https://www.moneyneversleeps.ie/reviews/)[Leave a Review](https://www.moneyneversleeps.ie/reviews/new/)[![Image 7: Apple Podcasts podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/applepodcasts-icon@2x.d8701eb5b99b.png) Rate on Apple Podcasts](https://podcasts.apple.com/ie/podcast/id1455819294?mt=2&ls=1)[![Image 8: Spotify podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/spotify-icon@2x.d6a55c3ea35a.png) Rate on Spotify](https://open.spotify.com/show/4F8uOLxiscYVWVGEfNxTnd)  
*   [Rate Show](https://www.moneyneversleeps.ie/rate/)
*   [X / Twitter](https://twitter.com/mnsshow?lang=en)
*   [YouTube](https://www.youtube.com/channel/UCvaaHrJjizUEd0-93mjCKsQ)
*   [LinkedIn](https://www.linkedin.com/company/28661903/admin/)
*   [Sponsor](https://www.moneyneversleeps.ie/support/)
*   [Newsletter](https://www.moneyneversleeps.ie/newsletter/)
*   [Sponsors](https://www.moneyneversleeps.ie/sponsors/)
*   [Follow](https://www.moneyneversleeps.ie/guests/rory-galvin/#)[![Image 9: Spotify podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/spotify-icon@2x.d6a55c3ea35a.png) Spotify](https://open.spotify.com/show/4F8uOLxiscYVWVGEfNxTnd)[![Image 10: Apple Podcasts podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/applepodcasts-icon@2x.d8701eb5b99b.png) Apple Podcasts](https://podcasts.apple.com/ie/podcast/id1455819294?mt=2&ls=1)[![Image 11: Amazon Music podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/amazonmusic-icon@2x.c82e9a7d5383.png) Amazon Music](https://music.amazon.com/podcasts/756bf95c-ebc4-4238-b3e6-64033f94eb94/MoneyNeverSleeps)[![Image 12: Overcast podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/overcast-icon@2x.3dc8dd4c0bb9.png) Overcast](https://overcast.fm/itunes1455819294)[![Image 13: Castro podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/castro-icon@2x.4b308ef39665.png) Castro](https://castro.fm/itunes/1455819294)[![Image 14: PocketCasts podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/pocketcasts-icon@2x.a277c9a336fe.png) PocketCasts](https://pca.st/itunes/1455819294)[![Image 15: Castbox podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/castbox-icon@2x.11e5d2fdb55a.png) Castbox](https://castbox.fm/channel/MoneyNeverSleeps-id3161750?country=us)[![Image 16: RadioPublic podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/radiopublic-icon@2x.156fa6357286.png) RadioPublic](https://radiopublic.com/moneyneversleeps-GELaBv)[![Image 17: RSS Feed podcast player icon](https://static.getpodpage.com/public/images/players-light-v1/icons/rss-icon@2x.106f007438c6.png) RSS Feed](https://anchor.fm/s/14826914/podcast/rss)  

 Follow 

[![Image 18: Spotify podcast player

*[... truncated, 8,258 more characters]*

---

### Success stories
*1,876 words* | Source: **GOOGLE** | [Link](https://vinton.ai/customers/success-stories/)

Success stories - Vinton AI Notetaker

===============

![Image 1: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking "Accept All", you consent to our use of cookies.

Customize Reject All Accept All

Customize Consent Preferences![Image 2: Close](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorized as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

No cookies to display.

Functional

- [x] 

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

*   Cookie TawkConnectionTime 
*   Duration session 
*   Description Tawk.to, a live chat functionality, sets this cookie. For improved service, this cookie helps remember users so that previous chats can be linked together. 

*   Cookie twk_idm_key 
*   Duration session 
*   Description Tawk set this cookie to allow the website to recognise the visitor in order to optimize the chat-box functionality.  

Analytics

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

No cookies to display.

Performance

Performance cookies are used to understand and analyze the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

Advertisement cookies are used to provide visitors with customized advertisements based on the pages you visited previously and to analyze the effectiveness of the ad campaigns.

No cookies to display.

 Reject All  Save My Preferences  Accept All 

 Powered by [![Image 3: Cookieyes logo](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent)

[Skip to content](https://vinton.ai/customers/success-stories/#content)

[![Image 4: Vinton logo with powered by Nativevideo](https://vinton.ai/wp-content/uploads/2024/03/newvintonlogo.png)](https://vinton.ai/)

Toggle Navigation
*   [Solutions](https://vinton.ai/customers/success-stories/)
    *   [Vinton for Sales](https://vinton.ai/solutions/vinton-for-sales/)
    *   [Vinton for Service](https://vinton.ai/solutions/vinton-for-service/)
    *   [Vinton for Agentforce](https://vinton.ai/solutions/vinton-for-agentforce/)
    *   [TalentVinton](https://vinton.ai/solutions/talentv/)
        *   [Overview](https://vinton.ai/solutions/talentv/)
        *   [Product Features](https://vinton.ai/solutions/talentv/product/)
        *   [Use Cases](https://vinton.ai/solutions/talentv/use-cases/)

    *   [Use Cases](https://vinton.ai/solutions/use-cases/)
    *   [Nativevideo](https://vinton.ai/solutions/nativevideo/)

*   [Customers](https://vinton.ai/customers/success-stories/)
    *   [Success stories](https://vinton.ai/customers/success-stories/)
    *   [Industries](https://vinton.ai/customers/industries/)
        *   [High Tech](https://vinton.ai/customers/industries/tech-sector/)
        *   [Financial Services](https://vinton.ai/customers/industries/financial-services/)
        *   [Manufacturing](https://vinton.ai/customers/industries/manufacturing/)
        *   [Health & Life Sciences](https://vinton.ai/customers/industries/health-life-sciences/)
        *   [Staffing and Recruitment](https://vinton.ai/customers/industries/staffing-recruitment/)
        *   [Higher Education](https://vinton.ai/customers/industries/higher-education/)

*   [Resources](https://vinton.ai/resources/)
    *   [Blog](https://vinton.ai/blog/)
    *   [Setup and User Guides](https://nativevideo.atlassian.net/wiki/spaces/VN/overview)
    *   [Podcast](https://vinton.ai/podcast/)
    *   [Live Demo Sessions](https://vinton.ai/linkedin-live-demos/)
    *   [Compliance](https://vinton.ai/resources/compliance/)
    *   [ROI Calculator](https://vinton.ai/roi-calculator/)
    *   [Try Vinton](https://vinton.ai/try/)

*   [Pricing](https://vinton.ai/pricing/)
*   [About us](https://vinton.ai/about-us/)
    *   [Partnerships](https://vinton.ai/about-us/partnerships/)
    *   [Giving back](https://vinton.ai/about-us/giving-back/)

*   [Contact us](https://vinton.ai/contact-us/)

[Try for Free](https://vinton.ai/try/)

Success stories[Catherine Nottage](https://vinton.ai

*[... truncated, 18,568 more characters]*

---

### Navigating CRM3: Increasing Transparency, Increasing Trust
*6,389 words* | Source: **GOOGLE** | [Link](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html)

Navigating CRM3: Increasing Transparency, Increasing Trust | CI Global Asset Management 

===============

![Image 1: logo](blob:http://localhost/4eb6460ab93a7ae1978320dda45af1eb)

[](https://www.cookiebot.com/en/what-is-behind-powered-by-cookiebot/)

*   [Consent](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)
*   [Details](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)
*   [[#IABV2SETTINGS#]](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)
*   [About](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services. You consent to our cookies if you continue to use our website.For more details, please see "Terms and conditions for all websites (including IOL and AOL)" in our ["Terms of use"](https://www.cifinancial.com/ci-gam/ca/en/legal/terms-of-use.html).

Consent Selection

**Necessary** 

- [x] 

**Preferences** 

- [x] 

**Statistics** 

- [x] 

**Marketing** 

- [x] 

[Show details](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)

Details

*   
Necessary  16- [x]   Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies. 

    *   [Adobe Inc.8](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)[Learn more about this provider![Image 2](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.adobe.com/privacy.html "Adobe Inc.'s privacy policy")**com.adobe.reactor.core.visitorTracking.cookiesMigrated**Used in context with the cache-function on the website, facilitating data transfer between Adobe DTM onto Adobe Launch. **Maximum Storage Duration**: Persistent**Type**: HTML Local Storage  **at_check[x2]**This cookie determines whether the browser accepts cookies.**Maximum Storage Duration**: Session**Type**: HTTP Cookie  **test**Used to detect if the visitor has accepted the marketing category in the cookie banner. This cookie is necessary for GDPR-compliance of the website. **Maximum Storage Duration**: Session**Type**: HTTP Cookie  **TEST_AMCV_COOKIE_WRITE**Determines whether the user has accepted the cookie consent box. **Maximum Storage Duration**: Session**Type**: HTTP Cookie  **__cf_bm[x2]**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie  **sat_track**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: Session**Type**: HTTP Cookie   
    *   [Google 3](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)[Learn more about this provider![Image 3](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://business.safety.google/privacy/ "Google's privacy policy")Some of the data collected by this provider is for the purposes of personalization and measuring advertising effectiveness.

**test_cookie**Used to check if the user's browser supports cookies.**Maximum Storage Duration**: 1 day**Type**: HTTP Cookie  **rc::a**This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.**Maximum Storage Duration**: Persistent**Type**: HTML Local Storage  **rc::c**This cookie is used to distinguish between humans and bots. **Maximum Storage Duration**: Session**Type**: HTML Local Storage   
    *   [LinkedIn 1](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)[Learn more about this provider![Image 4](blob:http://localhost/7c37f61654102a88a9be209f9569ef78)](https://www.linkedin.com/legal/privacy-policy "LinkedIn's privacy policy")**li_gc**Stores the user's cookie consent state for the current domain**Maximum Storage Duration**: 180 days**Type**: HTTP Cookie   
    *   [Sharethis 1](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html#)[Learn more about this provider![Image 5](blob:http://localhost/7c37f

*[... truncated, 66,166 more characters]*

---

### How Financial Services Can Eliminate Data Chaos
*1,140 words* | Source: **GOOGLE** | [Link](https://fintechmagazine.com/webinars/how-financial-services-can-eliminate-data-chaos)

![Image 1: Company Logo](https://cookie-cdn.cookiepro.com/logos/88098002-488e-41b6-8cad-32ce44d5f0fe/72ec1e24-bcba-43ca-be2f-21d97933a89c/f0d03859-56ce-4ebd-b07a-97b520a37f66/Logo1.jpg)

Privacy Preference Center
-------------------------

When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer. 

[Cookie Policy](https://fintechmagazine.com/cookie-policy)

### Manage Consent Preferences

#### Strictly Necessary Cookies

Always Active

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.

#### Performance Cookies

Performance Cookies

These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.

#### Targeting Cookies

Targeting Cookies

These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

Consent Leg.Interest

checkbox label label

checkbox label label

checkbox label label

![Image 2: Company Logo](https://cookie-cdn.cookiepro.com/logos/88098002-488e-41b6-8cad-32ce44d5f0fe/72ec1e24-bcba-43ca-be2f-21d97933a89c/f0d03859-56ce-4ebd-b07a-97b520a37f66/Logo1.jpg)

Privacy Preference Center
-------------------------

When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer. 

[Cookie Policy](https://fintechmagazine.com/cookie-policy)

### Manage Consent Preferences

#### Strictly Necessary Cookies

Always Active

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, logging in or filling in forms. You can set your browser to block or alert you about these cookies, but some parts of the site will not then work. These cookies do not store any personally identifiable information.

#### Performance Cookies

Performance Cookies

These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site. They help us to know which pages are the most and least popular and see how visitors move around the site. All information these cookies collect is aggregated and therefore anonymous. If you do not allow these cookies we will not know when you have visited our site, and will not be able to monitor its performance.

#### Targeting Cookies

Targeting Cookies

These cookies may be set through our site by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant adverts on other sites. They do not store directly personal information, but are based on uniquely identifying your browser and internet device. If you do not allow these cookies, you will experience less targeted advertising.

Consent Leg.Interest

checkbox label label

checkbox label label

checkbox lab

*[... truncated, 2,513 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Rory Galvin - Navirum](https://navirum.com/our-team/rory-galvin/)**
  - Source: navirum.com
  - *... rory-galvin/ Rory Galvin Leadership Rory Galvin. ... Navirum Podcast & Blog. Entrepreneurship. Early Days. Rory has always been ......*

- **[Rory Galvin](https://www.moneyneversleeps.ie/guests/rory-galvin/)**
  - Source: moneyneversleeps.ie
  - *In this conversation, we've got an all-star cast with Rory Galvin from Navirum, Kerry Ryan from Salesforce, Christian-Maynard Philipp from Pattern and...*

- **[Success stories - Vinton AI Notetaker](https://vinton.ai/customers/success-stories/)**
  - Source: vinton.ai
  - *Podcast · Live Demo Sessions · Compliance · ROI Calculator · Try Vinton · Pricing ... Intuitive to setup and users love it.” — Rory Galvin, Founder & ...*

- **[Navigating CRM3: Increasing Transparency, Increasing Trust | CI ...](https://www.cifinancial.com/ci-gam/ca/en/expert-insights/articles/navigating-CRM3-increasing-transparency-increasing-trust.html)**
  - Source: cifinancial.com
  - *Nov 3, 2025 ... Podcasts · Commentaries · Videos. November 03 ... Rory Galvin, "The Impact of CRM3 on Canadian Financial Services: What to Expect," Na...*

- **[How Financial Services Can Eliminate Data Chaos | FinTech ...](https://fintechmagazine.com/webinars/how-financial-services-can-eliminate-data-chaos)**
  - Source: fintechmagazine.com
  - *Oct 8, 2025 ... Interviews · Top 10 · Videos · Industry Events. Magazines. FinTech ... Rory Galvin, CEO & Founder, Navirum. Rory is the visionary foun...*

- **[Thought Leadership - Navirum](https://navirum.com/category/thought-leadership/)**
  - Source: navirum.com
  - *At Navirum, we pride ourselves on the deep industry expertise and ... Rory GalvinFor Advisors, Succession Isn't An Event – It's a Strategy 08.17 ......*

- **[Season 4 | Money Never Sleeps](https://www.moneyneversleeps.ie/episodes/season/4/)**
  - Source: moneyneversleeps.ie
  - *We talk through the long iterative climb involved in launching a business ... Rory Galvin from Navirum, Bryan Clagett from Moven, Cory Haberkorn from ...*

- **[Investing Episodes | Money Never Sleeps](https://www.moneyneversleeps.ie/categories/investing/)**
  - Source: moneyneversleeps.ie
  - *... Rory Galvin from Navirum, Kerry Ryan from Salesforce, Christian-Maynard Philipp from Pattern and… ... We talk through the long iterative climb inv...*

- **[Pete Townsend](https://www.moneyneversleeps.ie/guests/pete-townsend/)**
  - Source: moneyneversleeps.ie
  - *... conference last week … Guests: Pete Townsend , Eoin Fitzgerald · 157 ... Navirum and Salesforce), this episode features an all-star cast with Rory...*

- **[Phil Unger - CEO at Cadeon Inc.](https://www.ceorankings.com/philunger)**
  - Source: ceorankings.com
  - *Rory Galvin · CEO at Navirum. CEO Rankings Logo. 2020 - 2025 Pegasus Media Group Ltd. All rights reserved. Cookie & Ad-Free Network. Rules and Guideli...*

---

*Generated by Founder Scraper*
