# Yannick Boucher

## Position actuelle

**Titre** : Founder & Principal Producer
**Entreprise** : Foreword Ltd
**Durée dans le rôle** : 8 years 6 months in role
**Durée dans l'entreprise** : 8 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Operations Consulting

## Description du rôle

With a combined total of over 45 years of experience in the industry, we are providing punctual production services across the game industry to indie and AAA Developers, Publishers, IP Holders, and Investors. 

- Concept Development and Review
- Pitching
- Product Planning
- Budgeting and Staffing
- Forecasting
- Process Improvement
- Risk Assessment
- Outsourcing Management
- Mocap & Cinematics Production
- Partner/Vendor Due Diligence
- Production Coaching
- And much more

We are available globally, on-site, hybrid, and remote.

Reach out to us  for a (free) chat to discuss your needs and how we can help:
https://calendly.com/ybouc

## Résumé

More than 20 years of experience shipping top tier titles with dev experience in North America, Asia, and Europe, chiefly in the AAA space. I am simply passionate about making great creative and entertainment endeavors with great teams, on any platform.

My aim is to help development and publishing teams come together to be even more creative, more effective, communicate better, and ultimately, build experiences that are fun, look and feel amazing, and are critically and commercially successful.

- PMP, CSM
- Game production and development.
- Multi-cultural teams / work environments.
- Strong strategic understanding of global and local game markets and trends.
- Agile / Scrum methodologies 
- Realization and production values.
- Budgeting & Scheduling.
- Outsourcing & Insourcing / Multi-site projects.
- Public Relations / Marcom / Public Speaking.
- Hiring, training, coaching, evaluating staff.
- Publishing & licensing relationships.
- Sound production, technical.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADKcYYBuRuf2Di-_w0MAaOStSgTbQshQ04/
**Connexions partagées** : 4


---

# Yannick Boucher

## Position actuelle

**Entreprise** : Foreword Ltd

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Yannick Boucher

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399881328562688000 | Video (LinkedIn Source) | blob:https://www.linkedin.com/94d239b1-b174-406f-89eb-521cca40ac93 | https://media.licdn.com/dms/image/v2/D5605AQF42WlvOdZ0pQ/videocover-low/B56Zq8j.osHABQ-/0/1764100143031?e=1765778400&v=beta&t=KIFPXc9ynwCpaLvXWwi_xnFsjy0wKhFVb7xWybtXPWE | I just love this. | 13 | 0 | 0 | 1w | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.834Z |  | 2025-11-27T18:46:31.876Z | https://www.linkedin.com/feed/update/urn:li:activity:7399172330478030852/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7371626531208716288 | Text |  |  | My super-serious take on AI: 

One fun thing about ChatGPT is that the way the text is drawn on screen is reminiscent of the good old days of ASCII/ANSI text transmitted over 1200-2400 baud modems, so the kids can get a feel for it! | 5 | 1 | 0 | 2mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.835Z |  | 2025-09-10T19:32:03.238Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7345790868160757760 | Text |  |  | See you in Brighton next week? 

Let me know if you'll be there and let's meet up! | 9 | 1 | 0 | 5mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.835Z |  | 2025-07-01T12:30:21.164Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7340313430878240768 | Article |  |  | Oh my! Hello!  😄 

Can't believe it's been over 10 years already.  Not only that, but I am truly shocked at the progress they're making!


https://lnkd.in/e8Kv9Huc | 5 | 2 | 0 | 5mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.836Z |  | 2025-06-16T09:44:58.350Z | https://www.eurogamer.net/with-borderlands-4-nearly-here-a-community-of-archivists-are-racing-to-revive-a-dead-borderlands-mmo |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7339042298657210368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH73Utv8IhQzw/feedshare-shrink_800/B4EZdmEFDuHYAk-/0/1749764035633?e=1766620800&v=beta&t=hlTdMN-0v22DefMg4f34eKmNMCkvxoP1NjWqyjFC2SA | Folks, drop everything!! | 56 | 9 | 1 | 5mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.836Z |  | 2025-06-12T21:33:56.812Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7336898505367560192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFlWdU5gHPCDg/feedshare-shrink_800/B4EZdHmT_QHQAg-/0/1749252915731?e=1766620800&v=beta&t=0SXLoWNsSa8RCnhds7k_HOmwCdWLMJnjUT2SyaI1Plc | Oh I am SO here for it. | 19 | 3 | 0 | 6mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.836Z |  | 2025-06-06T23:35:16.662Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7335487561517207553 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3CYq9Hi3AvQ/feedshare-shrink_800/B4EZczjD.8HYAg-/0/1748916519841?e=1766620800&v=beta&t=0C-432bTq0725Jw96trAmwEmHUqfGvjHBggWoWjIpO4 | Haha, love it! “RGG West” ‘s marketing is always great. And yes, I did call, give it a try!  I’m always down for more Yakuza content! | 2 | 0 | 0 | 6mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:39.837Z |  | 2025-06-03T02:08:41.434Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7298590902233542656 | Article |  |  | Great article from the New York Times on Metroidvanias, past and present. Includes words from the creators of Animal Well and Ultros, too. 

Bonus: very cool page layout! 
Nicely done, NYT. | 11 | 0 | 0 | 9mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:42.901Z |  | 2025-02-21T06:34:32.354Z | https://www.nytimes.com/interactive/2025/02/20/arts/metroidvania-games-metroid-castlevania.html?unlocked_article_code=1.yk4.ngK5.BpswsEp-yfs3&smid=url-share |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7281111167127719936 | Text |  |  | Not a big proclamation but a small “prediction” (or at least, a wish!) for 2025, and it has nothing to do with games:

This year will mark the biggest drop in engagement for social media across the board.  Between troll farms, billionaire antics, evermore aggressive ragebait, and AI slop, to name but a few, the enshitiffication is in full swing, and most sane people are starting to disengage and fall back on more meaningful, more personal connections.  I believe that will be supercharged further this year.

Bonus content: On the topic, if you don’t know it yet, have a look at r/LinkedinLunatics . Thank me later!  ;) | 43 | 5 | 0 | 11mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:42.901Z |  | 2025-01-04T00:56:18.747Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7273302457819009025 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFCdIFJsR9lqA/feedshare-shrink_800/feedshare-shrink_800/0/1726014492906?e=1766620800&v=beta&t=jWXhGbsJnOnDFjNFhrpbnfEhBXIBrBN8ukQkycWk_9E | I am happy to say I get to wear my shorts for another day!  (I never had any doubt, to be honest!)

Congrats Team ASOBI on Astro Bot winning Game of the Year at The Game Awards last night! | 2 | 0 | 0 | 11mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:42.902Z |  | 2024-12-13T11:47:17.369Z | https://www.linkedin.com/feed/update/urn:li:activity:7239429496544645121/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7273156908713168896 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQEe6ICD-ZPgAQ/feedshare-shrink_800/B4DZO9xqKcGgAk-/0/1734055734387?e=1766620800&v=beta&t=i5bBTtECUT9vJltcLhhve1P6i8UiXGzcAAQQE1rvPIA | Look at this guy, it's Amir Satvat taking the first Game Changer award ! 

That was a great moment at The Game Awards , Geoff Keighley. | 52 | 2 | 0 | 11mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:42.903Z |  | 2024-12-13T02:08:55.758Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7272316802657878016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF2oRc8-fDaHQ/feedshare-shrink_800/B4EZOx1l6_HkAs-/0/1733855438068?e=1766620800&v=beta&t=3wR1Tzc0STbugRtm1nbYC4wo_sVs5728O9ggngXOHYU | Indiana Jones and the Great Circle is *chef's kiss* .  That is all. | 16 | 2 | 1 | 11mo | Post | Yannick Boucher | https://www.linkedin.com/in/yannickb | https://linkedin.com/in/yannickb | 2025-12-08T05:25:42.903Z |  | 2024-12-10T18:30:38.866Z |  |  | 

---



---

# Yannick Boucher
*Foreword Ltd*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Yannick, Co-founder of Hypefury](https://traction.substack.com/p/yannick-co-founder-of-hypefury)
*2022-10-03*
- Category: blog

### [- Forward Launch Your SaaS](https://forwardlaunchyoursaas.com/)
*2022-08-02*
- Category: article

### [Podcast - Forward Launch](https://forwardlaunchdigital.com/podcast/)
*2024-09-10*
- Category: podcast

### [YB Digital](https://ybierling.com/en/podcast-yonumerique-yaniss-comment-apprehender-un-parcours-de-fondation-dentreprise)
*2026-09-10*
- Category: podcast

### [10 Go-to-Market Lessons from Fintech Founders – Branding, Channels and Beyond](https://forefrontcomms.com/10-go-to-market-lessons-from-fintech-founders-branding-channels-and-beyond/)
*2025-06-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Mike Lewis Email & Phone Number | CMO SaaS B2B | Demand ...](https://contactout.com/Mike-Lewis-87043154)**
  - Source: contactout.com
  - *Yannick Boucher. Producer & Strategic Advisor. 15+ years delivering top-tier franchises with top-tier teams at Foreword Ltd (旭言有限公司) ... Blog Best Ema...*

---

*Generated by Founder Scraper*
