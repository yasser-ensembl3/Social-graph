# Roxanne Lessard

## Position actuelle

**Titre** : Founder, CEO
**Entreprise** : Panorama
**Durée dans le rôle** : 3 years 3 months in role
**Durée dans l'entreprise** : 3 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Panorama is the first governance software designed to empower forward-thinking board of directors. The software automates governance processes and recommends best practices. It centralizes all strategic information for informed, value-creating decision-making.

www.usepanorama.com

🏆 Winner of the IMPACT Prize 2024 @ Startupfest by Fonds de solidarité FTQ
🏆 Top 20 startups revelations of 2024 by Québec Tech
🏆 Top 105 strongest startup @ Web Summit 2023 in Portugal
⚙️ Currently incubated @ Centech, 2-year Propulsion program world's top 10 according to UBI Global

## Résumé

Roxanne Lessard is a UX developer and founder of Panorama, a software that helps organizations better structure their governance practices. As an MBA graduate from Laval University, she has extensive experience in entrepreneurship, IT, and organization development.

Being a results-driven entrepreneur at heart, Roxanne led a number of IT projects, including transforming the growth strategy of Caswil, a fintech startup, as General Manager, before going into business for herself. Having been invested and engaged in the world of governance for nearly 6 years, Roxanne serves on the board of Motivaction Jeunesse since 2019 and also joined the board of the Speach Pathologists and Audiologists Quebec Association in 2021. She also holds certification in corporate governance from Columbia University (NYC) and NPO governance from the Collège des administrateurs de sociétés.

Her expertise puts her in a key position to bridge the gap between technical issues and business objectives. In fact, this is what led her to found Panorama - board members needed a simple, accessible, and secure tool to carry out their duties. With Panorama, Roxanne aims to help the world of corporate governance evolve, to improve transparency, accountability, and ethical decision-making in organizations, and to enable a greater diversity of directors.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABWi4bEB8nItZUBVi_upRUrJxW_BU0AEYG0/
**Connexions partagées** : 234


---

# Roxanne Lessard

## Position actuelle

**Entreprise** : Panorama

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Roxanne Lessard

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397258025691934720 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQEOkfmlxp6xxA/mp4-720p-30fp-crf28/B4EZqhW8lUGUCI-/0/1763643744235?e=1765778400&v=beta&t=zhfvLysAbsYpqVxl9zSHCLSeZS1OGICug0mv3eImed0 | https://media.licdn.com/dms/image/v2/D4E05AQEOkfmlxp6xxA/videocover-low/B4EZqhW8lUGUBQ-/0/1763643741568?e=1765778400&v=beta&t=u8LsbIwMjAJ1avdVDtahaKSR-gG8km-or0UgGWvaCqQ | De 8 heures de rédaction à 10 minutes de révision. La différence ? MinutesIQ : notre nouvelle intelligence artificielle 🚀

Aujourd'hui, on lance MinutesIQ – notre deuxième produit chez Panorama.
Une IA qui génère des procès-verbaux professionnels instantanément. En français ou en anglais. En direct ou à partir d'enregistrements. Vous révisez en moins de 10 minutes et c'est tout.

Derrière ce lancement, il y a une équipe qui a écouté nos clients, itéré sans relâche, et donné absolument tout dans les derniers jours avant d’officialiser ce lancement. MinutesIQ, ce n'est pas juste de la tech – c'est une réponse aux secrétariats corporatifs qui terminent leur semaine épuisés par la rédaction de procès-verbaux.

Nos utilisateurs parlent déjà d’un changement majeur :
- Révision du procès-verbal généré en moins de 10 minutes
- 98 % de précision dans la capture des discussions et décisions clés
- Approbations accélérées grâce à des procès-verbaux disponibles immédiatement

Envie de l'essayer gratuitement ? C'est disponible dès maintenant au : minutesiq.com

Vous avez du feedback ? Écrivez-moi directement.

Merci à l'équipe Panorama. Vous êtes incroyables. 💜🩵

–

From 8 hours of writing to 10 minutes of review. The difference? MinutesIQ: our new artificial intelligence 🚀

Today, we're launching MinutesIQ – our second product at Panorama.
An AI that generates professional meeting minutes instantly. In English or French. Live or from recordings. You review in under 10 minutes and that's it.

Behind this launch is a team that listened to our clients, iterated relentlessly, and gave everything in the final days before this launch. MinutesIQ isn't just tech – it's a response to corporate secretaries who end their week exhausted from writing meeting minutes.

Our users are already calling it a game-changer:
- Review of the minutes generated in less than 10 minutes
- 98% accuracy in capturing discussions and key decisions
- Faster approvals with minutes available immediately

Want to try it for free? It's available now at : www.minutesiq.com

Have feedback? Message me.

Thank you to the Panorama team. You're incredible. 💜🩵

#MinutesIQ #AI #Governance #BoardManagement #Panorama #usepanorama #Innovation #ProductLaunch | 119 | 13 | 4 | 2w | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:45.184Z |  | 2025-11-20T13:02:27.733Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7389995711213305856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEgwynDoFHCdQ/feedshare-shrink_800/B4EZo6J8EZKMAg-/0/1761912275609?e=1766620800&v=beta&t=vGnd0zM2Bb1xLCAZy4YVtyX8VSjwXyWK4Tty-kJbX8s | C’est officiel : nous l’avons rapporté à la maison. 🏆✨

Je suis honorée d’avoir remporté le Prix Femmes en Tech aux MTL Tech Awards présenté par Printemps numérique. 

C'est une très belle reconnaissance du travail accompli avec Panorama pour transformer la gouvernance moderne. 🗃️🚨

Félicitations aux deux autres finalistes qui m’ont inspirée par leur leadership et leur vision 🩵 :
- lamia guellif, PDG et cofondatrice de SaHera
- Marie-Gabrielle Ayoub, CEO, Le Wagon Canada

Ce prix, je le vois comme une reconnaissance du travail de toutes celles et ceux qui bâtissent un numérique plus inclusif, responsable et durable. 🚀 🌱

#MTLconnecte #MTLTechAwards #Innovation #Technologie #Inclusion #Durabilité #NumériqueResponsable #Prix | 298 | 55 | 6 | 1mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:45.185Z |  | 2025-10-31T12:04:37.034Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7389294065789444096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQESSOOVrtjvDA/feedshare-shrink_800/B4EZowLytXIMAo-/0/1761744989836?e=1766620800&v=beta&t=ij_9S1AZrHQBedGC773gCkC_V67ebRhznMdoA0mgv2k | Présenter Panorama est un des moments que je préfère. Mais… quand on me donne 4 minutes et maximum 5 slides, l’adrénaline embarque vite 😅

Je suis honorée d’être finaliste du Prix Femmes en Tech 🏆 aux MTL Tech Awards présenté par Printemps numérique, aux côtés de deux autres femmes inspirantes qui font avancer le numérique :
- lamia guellif, PDG et co-fondatrice, SaHera
- Marie-Gabrielle Ayoub, CEO, Le Wagon Canada

✨ Hier était la première journée de MTL connecte 2025 : de l’énergie, des rencontres et une vitrine incroyable pour l’innovation d’ici.

Bravo également aux finalistes des autres catégories : votre impact est réel et nécessaire. 🩵

📅 Rendez-vous ce jeudi 30 octobre pour la remise des prix.
Peu importe l’issue, je me sens déjà privilégiée de cette reconnaissance.

À tous ceux et celles qui contribuent à bâtir un numérique plus inclusif, responsable et durable : continuons.

#MTLconnecte #MTLTechAwards #Innovation #Technologie #Inclusion #Durabilité #NumériqueResponsable 🚀 | 186 | 21 | 2 | 1mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:45.186Z |  | 2025-10-29T13:36:31.729Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384207672536928256 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF7F1Q7obZQow/feedshare-shrink_800/B4DZnhwWVsHYAg-/0/1760429172909?e=1766620800&v=beta&t=eCQmMDMGpsNB6XXpXCD6LQ4fSNGVemUrUQhwryL5oi0 | 🇨🇦🤝🇫🇷 Une matinée inspirante à Toulouse sous le signe du partenariat, de l’innovation et du rayonnement économique entre la France et le Québec.

Un grand merci pour l’accueil Patrice VASSAL & Toulouse Team (ex-Agence d'attractivité de Toulouse Métropole) ! | 21 | 0 | 0 | 1mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:45.187Z |  | 2025-10-15T12:45:01.077Z | https://www.linkedin.com/feed/update/urn:li:activity:7383775131279474688/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7381301024768098305 | Document |  |  | Notre équipe façonnons l’avenir de la gouvernance et nous cherchons la personne qui fera grandir nos clients… et notre impact.

Panorama recherche un(e) Responsable succès client & croissance

Tu deviendras l’architecte de l’expérience client et le moteur de notre expansion : transformer des comptes satisfaits en véritables partenaires d’affaires, représenter Panorama dans des présentations et événements, et activer des opportunités d’upsell/cross-sell.

Plus de détails ici: https://lnkd.in/e8jjaz3f

#Recrutement #Gouvernance #SaaS #CustomerSuccess #Growth #Montréal #B2B #AI | 43 | 1 | 3 | 2mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:45.187Z |  | 2025-10-07T12:15:02.246Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7373777515405942785 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6414fd75-e029-4b6c-9c28-2f284579dcc6 | https://media.licdn.com/dms/image/v2/D4E05AQEMuy6Hj3_U_A/videocover-high/B4EZlTrixSGUB8-/0/1758045550521?e=1765778400&v=beta&t=hYn3wiKbO9bSS5TQNY_tjOVSPA63ZCpor8oSOLftuMs | 🎉 Rentrée animée chez Ax-C aujourd’hui, avec plusieurs start-ups exposantes… dont Panorama!
Je ne dirai pas qu’on avait le meilleur booth… mais avouons-le, on avait une belle présence. 😉

L’effervescence dans le parquet était palpable et ça fait du bien de connecter avec autant de monde passionné.
Merci à l’équipe Ax-C pour l’organisation et à tous ceux qui sont passés nous voir.

👉 Petit aperçu en vidéo pour revivre l’ambiance!

#startup #innovation #gouvernance #AXC | 38 | 1 | 2 | 2mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.137Z |  | 2025-09-16T17:59:17.834Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7371620143480864768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdrF4mVVwATg/feedshare-shrink_800/B4EZk1BazEGUAk-/0/1757531197363?e=1766620800&v=beta&t=WREuCfQva8TlArLBjX_PR1lvoNQdC5N8B0i9kiau9Tg | Du contenu de qualité A+, well done Francois Lanthier Nadeau, SaaSpasse & aux conférenciers, dont deux qui m’impressionnent particulièrement Raff Paquin & Vicky Boudreau 🚀

C’est toujours un plaisir de connecter avec celles et ceux qui bâtissent l’avenir logiciel du Québec, et ce, chez Workleap ! 🙌 | 46 | 7 | 1 | 2mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.138Z |  | 2025-09-10T19:06:40.285Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7368979077426360321 | Text |  |  | 🚀 Panorama recrute !
Tu as envie de rejoindre une startup SaaS B2B en pleine croissance, où ton impact sera visible au quotidien ? Nous cherchons un·e Responsable du succès client et de la croissance pour accompagner nos clients, renforcer leur adoption de notre plateforme et identifier de nouvelles opportunités.

✨ Ton profil
- Expérience en Customer Success ou gestion de comptes
- Capacité à déceler des opportunités commerciales (upsell / cross-sell)
- À l’aise pour travailler dans un environnement startup dynamique
- Solides compétences en communication et relation client
- Bilingue français/anglais

👉 Découvre l’offre complète et postule ici : https://lnkd.in/e2MfNxme

Chez Panorama, nous croyons qu’une bonne gouvernance transforme les organisations. Viens bâtir avec nous l’avenir des conseils d’administration.

#UsePanorama #Recrutement #StartupJobs #CustomerSuccess #Growth | 45 | 0 | 2 | 3mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.139Z |  | 2025-09-03T12:12:01.069Z |  | https://www.linkedin.com/jobs/view/4293208804/ | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7368619961197420546 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFIEGNmuwIkyw/feedshare-shrink_800/B4EZj1euOwGUAg-/0/1756465128949?e=1766620800&v=beta&t=xrzRkXKrELqV9nmqO0Rsoys9qSgEiyb_yJqlaEw3U2M | 🌟 Thoughts on #GPCConf2025 in Montréal from last week
What stands out most from this conference isn’t just the packed agenda or the panels, it’s the clear signal that governance is evolving faster than ever.

The challenges boards face today : from digital transformation to transparency and efficiency — require bold thinking and modern tools. That’s the conversation we had again and again at Panorama’s booth, and it’s what motivates us to keep pushing innovation forward.

We’re heading home with new ideas, stronger relationships, and an even deeper commitment to helping boards embrace this new era of governance.

Thank you to the Governance Professionals of Canada (GPC) for bringing such a passionate community together. It was a pleasure to be part of this in our very hometown!

#UsePanorama #GovernanceInnovation #BoardSoftware #FutureOfGovernance #MontrealEvents | 50 | 1 | 1 | 3mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.140Z |  | 2025-09-02T12:25:01.088Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7366923957066682369 | Text |  |  | Q. Rapide : Quels sont les meilleurs systèmes de paie pour petites entreprises ? | 2 | 10 | 0 | 3mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.140Z |  | 2025-08-28T20:05:42.193Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7365752335169404928 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFuIzgEinnOVA/feedshare-shrink_800/B4EZjhjoLQHEAg-/0/1756130871053?e=1766620800&v=beta&t=yvuxW_NZVqEDxZkUT86iMOyLdtorOEHw4Xq-i5ggcfE | 🍁 A few highlights from Day 1 at #GPCConf2025 in Montréal!
It’s inspiring to see so many governance professionals gathered to exchange ideas, challenge perspectives, and shape the future of governance.
From great conversations at Panorama's booth to reconnecting with peers and meeting new faces, the energy here is undeniable.

For us at Panorama, this conference is a reminder of why we’re building what we’re building: to give boards the tools they need to work smarter, lead with impact, and embrace modern governance practices with confidence.

📸 Sharing some snapshots of the day — excited for what the rest of the conference will bring!

#UsePanorama #GovernanceInnovation #BoardSoftware #MeetingManagement #GovernanceProfessionals #MontrealEvents | 47 | 0 | 2 | 3mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.141Z |  | 2025-08-25T14:30:05.765Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7364280321304870914 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF_Kwe7QNi-Sw/feedshare-shrink_800/B4EZjMt62dHIAo-/0/1755781248760?e=1766620800&v=beta&t=AgX1jMky4GU4kk1iy1bD-tegEs-nVGx21T1dV2mQZZ4 | ✨ Ready for this fall.

Every new season is an opportunity to raise the bar — and that’s exactly what we’re doing.

Behind every bold ambition, there’s a team that shows up with grit, creativity, and the determination to make it happen. I’m incredibly proud of Panorama's team: their creativity, resilience, and drive are the fuel behind everything we’re building. Together, we’re proving that governance can be reimagined — smarter, more impactful, and more human. 🩵

This fall, we’re stepping into a new season of growth with a clear vision and the energy to match. 🚀

For us, it’s not just about scaling a company. It’s about:
- Creating real impact for the boards and leaders we work with.
- Bringing clarity and efficiency where complexity once reigned.
- Shaping the future of governance with purpose and conviction.

We’re building, pushing boundaries, and moving governance forward — together. Momentum is on our side, and the best is yet to come.

Here’s to a season of transformation, collaboration, and impact.

Ben Unyolo Clara Petit Raff Paquin Natalia Targowska Justine Dupuis Soulière
#Leadership #Teamwork #Innovation #Governance #Growth | 92 | 9 | 3 | 3mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.142Z |  | 2025-08-21T13:00:50.311Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7358832979508359169 | Text |  |  | Serving on a board looks prestigious ✨ from the outside.

Inside? 🤯 It often looks like email chains, scattered files, unclear next steps, and hours lost chasing documents before the meeting.

It’s easy to be drawn to the idea of serving on a board — the strategy, the impact, the leadership role.

But let’s be real. 
Most directors aren’t stepping into high-leverage work. They’re stuck in low-leverage systems.

Let’s break a few myths:

🧠 Strategic Oversight
Expectation: High-level discussions, forward-looking decisions
Reality: Wasting time clarifying what was decided last time, what’s missing, and who owns what

🗂 Information Access
Expectation: A centralized, secure board portal with everything you need
Reality: PDF attachments lost in inboxes, login issues, outdated folders, chaos at quarter-end

🕒 Time Commitment
Expectation: 4–6 meetings a year, minimal prep
Reality: Hours prepping, trying to follow threads, reading 80-page packs with no context — just to feel "caught up"

Serving on a board should drive value — not get lost in the noise.

—

Hey 👋, I'm Roxanne Lessard, and I build Panorama to make that shift happen — for real.

It’s not just a place to store and secure documents.
It’s a smarter system that helps boards run effective meetings, track decisions, and create value.

If you're on a board, lead one, or support one — and you’ve lived this disconnect — you’re not alone.

Let’s stop romanticizing inefficiency and start modernizing governance.

📩 DM me if you’re ready for the reality shift.

#governance #boardofdirectors #saas #efficiency #transparency #entrepreneurship | 26 | 1 | 0 | 4mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.143Z |  | 2025-08-06T12:15:02.820Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7356663666412273665 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFb3z9WlllcVg/feedshare-shrink_800/B56ZhX2wcqHQAg-/0/1753820630242?e=1766620800&v=beta&t=kzqdijsdCRRY_xpA0LgBkQtXCYSNnqxEZcGoYmOULzE | Already on the ground in Montréal for the Governance Professionals of Canada (GPC)Annual Corporate Governance Conference — where the future of governance takes shape.

Panorama is proud to be part of this premier event, alongside the leaders and innovators redefining how boards operate.

‼️ We didn’t just build another board portal.
We’re setting a new standard — one that replaces complexity with clarity, and manual processes with modern efficiency.

📍 Find us at Booth #9 next month.
If you care about driving strategic impact at the board level, you’ll want to see what we’re bringing to the table.

#GPCConf2025 #CorporateGovernance #BoardEfficiency #GovernanceInnovation #BoardSoftware #ModernGovernance #MontrealEvents #BoardSupport | 17 | 1 | 1 | 4mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.145Z |  | 2025-07-31T12:34:58.274Z | https://www.linkedin.com/feed/update/urn:li:activity:7356056887928217600/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7351681402280550402 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEdclWFYP8CiA/feedshare-shrink_800/B56Zf1TDx1GoAk-/0/1752167104208?e=1766620800&v=beta&t=DvWlL015zHzUexFoS78HBC_YLTkqfllpkE-RrrQwgzU | 💚 Je suis particulièrement fière de lire ce message de l’équipe de Cycle Momentum, qui illustre parfaitement la raison d’être de Panorama : offrir aux conseils d’administration des outils conçus ici, avec clarté, rigueur et modernité, pour les aider à atteindre leurs ambitions.

Merci à l’équipe de Cycle Momentum pour leur confiance envers Panorama et pour leur engagement envers l’innovation locale et durable. C’est un privilège de collaborer avec des leaders qui partagent nos valeurs et qui contribuent à faire rayonner l’écosystème d’ici.

#gouvernance #board #usepanorama #panorama | 32 | 2 | 0 | 4mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.146Z |  | 2025-07-17T18:37:13.939Z | https://www.linkedin.com/feed/update/urn:li:activity:7351585232120139776/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7344332172679389185 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFdEItWreE3PA/feedshare-shrink_800/B4EZc2MnK7H0Ag-/0/1748960966076?e=1766620800&v=beta&t=6i8hB-Na9a6E2UmpiyNUO5diJl2Tz_VK36LXBAAalDA | Depuis plus d’un an, j’ai le privilège de collaborer avec le Développement économique Pierre-De Saurel, un acteur essentiel du développement économique régional. 🌱

Leur conseil d’administration s’appuie sur Panorama pour centraliser l’information stratégique, automatiser les processus et renforcer l’efficacité de leur gouvernance. Voir notre solution contribuer concrètement à leur mission est exactement ce qui nous motive chaque jour.

Merci au DÉPS pour votre confiance renouvelée !

➡ En savoir plus : usepanorama.com

#Gouvernance #LeadershipRégional #Innovation #DéveloppementÉconomique | 8 | 0 | 0 | 5mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:48.146Z |  | 2025-06-27T11:54:01.060Z | https://www.linkedin.com/feed/update/urn:li:activity:7343993949411270679/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7340737627068751872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEAYWlsWZX6PQ/feedshare-shrink_800/B4EZd.J8BpHsA0-/0/1750168230015?e=1766620800&v=beta&t=rTH_K1qGlhI6GlLBSD3myomW-TSNROnpW3WBk4FiL7k | 📣 Panorama est au Carrefour Gouvernance, organisé par le Collège des administrateurs de sociétés des administrateurs de sociétés cette semaine à Québec !

C’est un plaisir d’être parmi les leaders en gouvernance pour échanger sur les pratiques qui façonnent l’avenir des conseils d’administration.

Notre équipe est sur place pour présenter comment Panorama simplifie la gouvernance, automatise les bonnes pratiques et soutient les organisations dans leur croissance.

Au plaisir de vous croiser sur place !

#Gouvernance #CarrefourGouvernance #Panorama #ConseilsDAdministration #Leadership #Innovation | 55 | 2 | 0 | 5mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:50.219Z |  | 2025-06-17T13:50:34.603Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7340403435294392323 | Text |  |  | 🚨 L’équipe Panorama est à Québec demain ! Vous êtes dans la région ? Venez nous rencontrer dans notre espace lounge au Hilton. On y sera pour échanger autour des enjeux de gouvernance, vous faire découvrir notre solution (démo à la clé 👀) et surtout, connecter avec la communauté locale.

🤝 Communauté de Québec : on veut vous rencontrer. Que vous soyez DG, administrateur·trice ou curieux·se de moderniser vos pratiques, passez nous voir !

📍 Salle Pellan, Hôtel Hilton Québec
🗓️ 17 juin et 18 juin

#Gouvernance #Panorama #Québec #Leadership #CA #StartupQuébécoise #Réseautage | 17 | 1 | 1 | 5mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:50.219Z |  | 2025-06-16T15:42:37.075Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7338540583143067648 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHOqpghafTwKQ/feedshare-shrink_800/B56ZdVOGhmHoA4-/0/1749481450282?e=1766620800&v=beta&t=qBYrKdBm2vV4pasOMSLMUDvWlJXVEkl9XUSscDbshnQ | 👋 Communauté de #Québec l’équipe Panorama vous reçoit au Hilton Québec le 17 et 18 juin prochain dans notre espace lounge ! Prenez RDV dès maintenant, les places sont limitées. | 7 | 0 | 0 | 5mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:50.220Z |  | 2025-06-11T12:20:18.512Z | https://www.linkedin.com/feed/update/urn:li:activity:7338521132272164865/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7334171736596226049 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEE_mRGrxtqyw/feedshare-shrink_800/B4EZcTTSyoHkAg-/0/1748375516944?e=1766620800&v=beta&t=9iuAIPGtngILK5PaD5pdpOi6YqYD8q-kAbh9P4fEF0I | 📣 J’aurai le plaisir d'animer webinaire en compagnie de Justine Dupuis Soulière le lundi 10 juin prochain à midi ! On y parlera des nouvelles pratiques qui transforment les conseils d’administration les plus performants.

🎯 Ce sera l’occasion de faire le point sur :
 ✔️ Les tendances qui redéfinissent le rôle des CA
 ✔️ Les signaux à ne pas manquer pour anticiper les changements à venir
 ✔️ Ce que les meilleurs conseils ont déjà mis en place
 ✔️ Et surtout, comment la technologie (comme Panorama) peut vraiment amplifier l’impact des CA

💡 Les CA les plus agiles ne se contentent pas de réagir : ils s’outillent pour rester en avance.

🔗 Réservez votre place ici : subscribepage.io/Zq3UZg

#Gouvernance #ConseilDAdministration #Webinaire #Leadership #ESG #PriseDeDécision #GouvernanceModerne #usePanorama | 6 | 0 | 0 | 6mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.051Z |  | 2025-05-30T11:00:04.326Z | https://www.linkedin.com/feed/update/urn:li:activity:7333454507365879813/ |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7329140503281623042 | Text |  |  | SAAQclic : Plus de 300 millions en dépassements… et « ce n’est pas ça qui va arrêter la Terre de tourner » ? 🥴 Il est plus que temps de renforcer la rigueur et la responsabilité autour des conseils d’administration. 🎯
#Gouvernance #SAAQ #SAAclic #Conseiladministration #Présidence | 11 | 0 | 0 | 6mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.051Z |  | 2025-05-16T13:47:44.828Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7328772276504379393 | Text |  |  | 💡 𝐋𝐚 𝐠𝐨𝐮𝐯𝐞𝐫𝐧𝐚𝐧𝐜𝐞 𝐞́𝐯𝐨𝐥𝐮𝐞. 𝐄𝐭 𝐜’𝐞𝐬𝐭 𝐭𝐚𝐧𝐭 𝐦𝐢𝐞𝐮𝐱.
Chaque semaine, en échangeant avec des administrateurs et des dirigeants, une conviction se renforce : la gouvernance ne peut plus être un simple exercice de conformité.

Elle doit devenir un 𝐯𝐞́𝐫𝐢𝐭𝐚𝐛𝐥𝐞 𝐥𝐞𝐯𝐢𝐞𝐫 𝐝𝐞 𝐩𝐞𝐫𝐟𝐨𝐫𝐦𝐚𝐧𝐜𝐞, 𝐝’𝐢𝐦𝐩𝐚𝐜𝐭 𝐞𝐭 𝐝𝐞 𝐜𝐫𝐞́𝐚𝐭𝐢𝐨𝐧 𝐝𝐞 𝐯𝐚𝐥𝐞𝐮𝐫. Un espace où les décisions transforment concrètement les organisations, où l’information circule mieux, et où les meilleures pratiques deviennent naturelles grâce aux bons outils.

C’est exactement la mission qu’on poursuit chez Panorama : 𝐟𝐚𝐢𝐫𝐞 𝐠𝐚𝐠𝐧𝐞𝐫 𝐝𝐮 𝐭𝐞𝐦𝐩𝐬, 𝐫𝐞𝐧𝐟𝐨𝐫𝐜𝐞𝐫 𝐥’𝐞𝐟𝐟𝐢𝐜𝐚𝐜𝐢𝐭𝐞́ 𝐝𝐞𝐬 𝐜𝐨𝐧𝐬𝐞𝐢𝐥𝐬 𝐝’𝐚𝐝𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐭𝐢𝐨𝐧 𝐞𝐭 𝐜𝐨𝐧𝐜𝐞𝐧𝐭𝐫𝐞𝐫 𝐥’𝐞́𝐧𝐞𝐫𝐠𝐢𝐞 𝐥𝐚 𝐨𝐮̀ 𝐞𝐥𝐥𝐞 𝐚 𝐥𝐞 𝐩𝐥𝐮𝐬 𝐝’𝐢𝐦𝐩𝐚𝐜𝐭.

La technologie permet aujourd’hui de simplifier l’accès à l’information stratégique et de soutenir une gouvernance plus agile, plus éclairée… et surtout, plus porteuse de résultats concrets.

#Gouvernance #Impact #Leadership #ConseilDAdministration #CréationDeValeur #Technologie | 8 | 1 | 0 | 6mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.052Z |  | 2025-05-15T13:24:32.723Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7327651258897416192 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYeWElxQvoEw/feedshare-shrink_800/B4EZZi5imoHMAo-/0/1745415973984?e=1766620800&v=beta&t=3xUFScySr8vXfQ5OTIjnSgWaM65GgeqiDZ2L4TIEdhs | 🔍 Coulisses produit Panorama — Mieux encadrer un moment clé pour les secrétaires de CA

Le mois dernier, on a amélioré un détail qui, pour nos utilisateurs, fait toute la différence : le flux de validation des procès-verbaux dans Panorama.

La majorité des secrétaires nous ont confié :
« Je préfère que personne ne voie le PV tant que je ne l’ai pas révisé au moins une fois. »

On comprend très bien. Partager un document non final peut créer de l'inconfort et de la confusion.

✅ On a donc repensé ce moment clé :
- Par défaut, les PV sont masqués en révision jusqu’à leur publication
- Un système clair de notifications permet d’indiquer quand le document est prêt à relire
- On peut suivre facilement qui a validé
- Et bien sûr, les automatisations de courriels sont intégrées — nos clients les apprécient toujours autant pour gagner du temps et ne rien laisser passer

💡 Résultat : plus de contrôle, moins d’ambiguïté, et un processus clair, aligné sur le rythme de chacun.

🛠️ Cette fonctionnalité n’existait pas au lancement. Et pourtant, on a avancé.
Parce qu’attendre que tout soit parfait, c’est risquer de ne jamais se lancer.
Chez Panorama, on évolue vite, au rythme des besoins concrets de nos utilisateurs.

📩 Curieux d’en savoir plus ? Contactez Clara Petit ou Justine Dupuis Soulière afin qu'elles vous en fassent la démonstration.

#Gouvernance #Produit #BoardManagement #UX #Startup #SaaS #Panorama #Usepanorama | 14 | 0 | 0 | 6mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.054Z |  | 2025-05-12T11:10:01.298Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7322575364193480705 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHt6xJjXrzfIg/feedshare-shrink_800/B4EZZjFuavHMAk-/0/1745419168108?e=1766620800&v=beta&t=amTAjWs-lGdsVnXgDLzb0BmIWZ44qOw2WdRuEcJE0m0 | 🗳️ Jour d’élections — et si on parlait de gouvernance ?
Aujourd’hui, des millions de personnes sont appelées à voter. C’est un exercice fondamental dans une démocratie et aussi un rappel : la gouvernance, ce n’est pas qu’une affaire de politique.

Dans nos organisations comme dans l’État, la gouvernance joue un rôle clé :
✔️ Équilibrer les pouvoirs
✔️ Veiller à la transparence
✔️ Prendre des décisions éclairées
✔️ Assurer une reddition de comptes
✔️ Planifier, anticiper, décider… collectivement

Ce qu’on attend d’un gouvernement élu — vision, rigueur, éthique, responsabilité — devrait aussi être exigé de tout conseil d’administration.

Mais dans la pratique ?
Trop d’organisations tombent dans le piège des CA qui valident, mais ne pilotent pas.
❌ Les ordres du jour ne sont pas stratégiques
❌ Les décisions sont prises à la dernière minute
❌ Les administrateurs ne sont pas pleinement mobilisés

Chez Panorama, on croit que bien gouverner, c’est mettre en place les bons mécanismes pour prendre les bonnes décisions — au bon moment, avec les bonnes personnes.

🗓️ Aujourd’hui, on élit un gouvernement. Et si c’était aussi l’occasion de réfléchir à la manière dont on gouverne nos organisations ?

#Gouvernance #Élections2025 #ConseilDAdministration #Leadership #Responsabilité #Startup #Panorama #UsePanorama | 14 | 0 | 2 | 7mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.057Z |  | 2025-04-28T11:00:13.695Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7321128276301660162 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGyPwW6xjVXPQ/feedshare-shrink_800/B4EZZjwP9NHQAg-/0/1745430315522?e=1766620800&v=beta&t=1qk5H8UErO5Fbif9fowpngdGgRdtvrUSVddf1rnOcXI | ☂️ La gouvernance en période d’incertitude : un vrai test pour les conseils d’administration

Le contexte économique et politique actuel oblige les CA à se poser les bonnes questions.

Fluctuations des marchés, contraintes budgétaires, changements réglementaires... Ce sont souvent les périodes d’instabilité qui révèlent la solidité (ou les failles) d’une gouvernance.

Ce que j’observe chez les CA les plus efficaces : 
✔️ Une structure claire, mais adaptable
✔️ Un ordre du jour axé sur les enjeux de fond
✔️ Des discussions préparées, centrées sur l’anticipation
✔️ Des outils qui facilitent l’accès à l’information stratégique — pas juste à l’information administrative

Chez Panorama, on accompagne chaque semaine des équipes de direction et des conseils qui veulent mieux se préparer, mieux se structurer, et surtout, prendre les bonnes décisions au bon moment.

💡 La résilience, ce n’est pas de faire face à la tempête, c’est de s’y être préparé bien avant !

#Gouvernance #ConseilDAdministration #CA #LeadershipStratégique #Efficacité #Résilience #Panorama #UsePanorama | 16 | 0 | 2 | 7mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.058Z |  | 2025-04-24T11:10:01.056Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7315726245386682368 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE9Ymd0_4cY5w/feedshare-shrink_800/B4EZYatqHwHMAg-/0/1744204982863?e=1766620800&v=beta&t=2UoacwIyG7zCp-f-aXi7WsanAkhgJFfLHaxYECpo2jo | De retour de Québec après un RDV Numérique marquant et plein d’impact 💥

Justine et moi avons eu le plaisir de représenter Panorama comme exposantes à cet événement inspirant, aux côtés de Jaqln.ai, Hint, Dok2u et Enjoy Social — que du beau monde !

Un immense bravo à tous les membres du CA de Capitale Numérique et à l’équipe d’organisation pour la qualité de l’événement et la richesse des rencontres. C’est toujours un privilège de faire partie d’un écosystème aussi vivant et collaboratif.

Mention spéciale à Justine Dupuis Soulière, qui vivait sa deuxième journée dans l’équipe (!), et qui a déjà plongé à fond dans l’aventure. Quel démarrage 🚀

Et fidèle à l’esprit startup… on a bien failli rater notre train 🚆 : notre bagage – rempli de tout notre matériel d’exposition (backdrop, moniteur, bannière, etc.) – était hors dimension et mal réparti. Résultat : session de repacking express à la gare. Au moins, notre set-up a fait fureur 😄

Le clou de la journée ? Un souper improvisé avec Francois Lanthier Nadeau, Marie-Katherine Jobin et Justine Dupuis Soulière - un moment vrai, rempli d’échanges riches et de plaisir. Le genre de soirée qui donne de l’énergie ! ✨

Québec, on revient bientôt 💙

#RDVNumérique #StartupLife #Panorama #Gouvernance #QuébecTech #FemmesEnTech #ÉvénementTech | 50 | 3 | 0 | 7mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.059Z |  | 2025-04-09T13:24:16.521Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7315370113740791809 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHIuo2oIl-l5g/feedshare-shrink_800/B4EZYVqVEmHgAk-/0/1744120145031?e=1766620800&v=beta&t=U3nYrsBkPnjiuE9yo_9slzHRGD4dTt9YFwhr5Ck_Ulc | Aujourd’hui, nous sommes à Québec pour le Rendez-vous numérique, sous le thème ESG.

Passez nous voir à l’espace startup : Justine Dupuis Soulière et moi y serons toute la journée pour parler d’innovation en gouvernance, de technologie responsable… et vous montrer comment Panorama peut outiller les conseils d’administration pour prendre de meilleures décisions.

P.S. Justine Dupuis Soulière vient tout juste de se joindre à l’équipe — c’est sa deuxième journée — et elle pitch déjà Panorama avec assurance et conviction ! L’occasion est idéale pour entrer en action dès maintenant et contribuer à l’impact positif de notre mission.

#Gouvernance #StartupQuébécoise #ESG #Innovation #Technologie #RendezVousNumérique #Québec #Panorama | 46 | 1 | 1 | 7mo | Post | Roxanne Lessard | https://www.linkedin.com/in/roxannelessard | https://linkedin.com/in/roxannelessard | 2025-12-08T05:08:57.060Z |  | 2025-04-08T13:49:08.120Z |  |  | 

---



---

# Roxanne Lessard
*Panorama*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 8 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [2024: A Year of Growth, Innovation, and Connection](https://www.usepanorama.com/en-us/updates/2024-a-year-of-growth-innovation-and-connection)
*2024-06-10*
- Category: article

### [About Panorama](https://www.usepanorama.com/en-us/about)
*2026-06-01*
- Category: article

### [Panorama: Quebec's new governance software for boards of directors](https://www.usepanorama.com/en-us/updates/panorama-launch)
*2025-04-10*
- Category: article

### [Updates - Panorama](https://www.usepanorama.com/en-us/updates)
*2025-03-25*
- Category: article

### [Panorama | LinkedIn](https://ca.linkedin.com/company/usepanorama)
*2025-06-05*
- Category: article

---

## 🎬 YouTube Videos

- **[Épisode jeudi 4 juillet | Est-ce que le gouvernement se tire dans le pied avec Lion Électrique?](https://www.youtube.com/watch?v=MnHSz5pOoJA)**
  - Channel: QUB - radio / télé / balado / vidéo
  - Date: 2024-07-15

- **[Mon Carnet du 19 janvier 2024](https://www.youtube.com/watch?v=78ERzS9J6mk)**
  - Channel: Mon Carnet - Le Podcast
  - Date: 2024-01-19

- **[Série de conférences : Comment prendre en main son traitement pour une meilleure qualité de vie](https://www.youtube.com/watch?v=R-W0emfljz4)**
  - Channel: OvarianCancerCanada
  - Date: 2022-03-30

- **[Challenger ses méthodes de leadership - Roxanne Lessard](https://www.youtube.com/watch?v=TgZLPE_y2lA)**
  - Channel: L'effet A
  - Date: 2021-04-07

- **[May 3, 2025](https://www.youtube.com/watch?v=bYOwhKshS80)**
  - Channel: Roxanne Lessard
  - Date: 2025-05-03

- **[December 14, 2020](https://www.youtube.com/watch?v=ZTA2EYsYClw)**
  - Channel: Roxanne Lessard
  - Date: 2020-12-14

- **[Atelier virtuel – Outils de gestion des conseils d’administration: l’exemple de Panorama](https://www.youtube.com/watch?v=FA9xE2M7B8o)**
  - Channel: Concertation Montréal CMTL
  - Date: 2023-10-20

- **[Jeune entrepreneur.e en démarrage du Québec | Concours ARISTA 2024](https://www.youtube.com/watch?v=RT_N2BX4pLc)**
  - Channel: Jeune Chambre de commerce de Montréal (JCCM)
  - Date: 2024-09-03

---

## 🔎 Press & Mentions

- **[UX – prototypage avec Roxanne Lessard – Mon Carnet](https://moncarnet.com/2024/01/23/ux-prototypage-avec-roxanne-lessard/)**
  - Source: moncarnet.com
  - *Jan 23, 2024 ... Mon Carnet, le podcast · {BONUS} – Parlons prototypage avec Roxanne Lessard ... Roxanne Lessard, fondatrice de Panorama, un logiciel ...*

- **[AI-powered solution reduces Board minutes production from 8 hours ...](https://www.newswire.ca/news-releases/ai-powered-solution-reduces-board-minutes-production-from-8-hours-to-10-minutes-panorama-launches-minutesiq-844707391.html)**
  - Source: newswire.ca
  - *Nov 20, 2025 ... Radio & Podcast · Television · Entertainment & Media Overview · View ... Roxanne Lessard, CEO and founder of Panorama. "MinutesIQ giv...*

- **[AI-powered solution reduces Board minutes production from 8 hours ...](https://www.marketwatch.com/press-release/ai-powered-solution-reduces-board-minutes-production-from-8-hours-to-10-minutes-panorama-launches-minutesiq-21fc231d?gaa_at=eafs&gaa_n=AWEtsqel8ey903yszLl81zT2GnThpmipVxL7Ojo2OybI47l1d0KRj_4pRUws&gaa_ts=69368a2f&gaa_sig=BTB1RNFNdLRrnlPWfluWq1oE_sX48GASWHJLstQafXT7pTIwI62-7y-BRM4nIyWb6TXO9ZG3DHCsI1P0WQYb-w%3D%3D)**
  - Source: marketwatch.com
  - *Nov 20, 2025 ... Podcasts. 0 Results. No Results Found. Authors. No results found ... Roxanne Lessard, CEO and founder of Panorama. "MinutesIQ gives t...*

- **[Prosperity For Every Generation](https://www.prosperityforeverygeneration.ca/)**
  - Source: prosperityforeverygeneration.ca
  - *Jessica Reitmeier, Founder, Pandata Tech, . Roxanne Lessard, Founder, CEO, Panorama, Montréal. Shail Silver, Entrepreneur, ParagraphAI, Toronto. Alber...*

- **[Épisode jeudi 4 juillet | Est-ce que le gouvernement se tire dans le ...](https://www.youtube.com/watch?v=ZMKWqCNNaXM)**
  - Source: youtube.com
  - *Jul 4, 2024 ... ... Roxanne Lessard, PDG de Panorama Jonathan Bélanger, président et co ... InPower Podcast. Auto-dubbed 33K views · 24:33. Go to chan...*

- **[Our entrepreneurs at Startup Fest 2024 – Groupe 3737](https://groupe3737.com/en/article-entrepreneur/our-entrepreneurs-at-startup-fest-2024/)**
  - Source: groupe3737.com
  - *– Roxanne Lessard, co-founder and CEO of Panorama, for the Fonds FTQ Impact Grant award. ... CBC : Montreal conference aims to help BIPOC-led non-prof...*

- **[L'UQAC prend part à la 7e édition de MTL connecte - Uqac Nad](https://www.nad.ca/actualites/luqac-prend-part-a-la-7e-edition-de-mtl-connecte/)**
  - Source: nad.ca
  - *Nov 19, 2025 ... ... Roxanne Lessard, fondatrice de Panorama, le premier logiciel de gouvernance dédié à l'automatisation des processus des conseils d...*

- **[About Panorama](https://www.usepanorama.com/en-us/about)**
  - Source: usepanorama.com
  - *“Joining Panorama also means supporting our movement to reinvent modern governance to shape a more fair, sustainable, and inclusive future.” Roxanne L...*

- **[La vue panoramique de Roxanne Lessard](https://www.lenouvelliste.ca/affaires/le-nouvelliste-affaires/juin-2024/2024/06/10/la-vue-panoramique-de-roxanne-lessard-YRPRFKCBZFG5ZJYDE5NK7DMT6M/)**
  - Source: lenouvelliste.ca
  - *Jun 10, 2024 ... Roxanne Lessard, fondatrice ... Cet article est réservé aux abonnés. Pour profiter pleinement ......*

- **[Panorama: Quebec's new governance software for boards of directors](https://www.usepanorama.com/en-us/updates/panorama-launch)**
  - Source: usepanorama.com
  - *Apr 3, 2023 ... ... Roxanne Lessard, founder of Panorama. ‍. The Panorama Advantage. Panorama is designed to solve these problems by providing easy-to...*

---

*Generated by Founder Scraper*
