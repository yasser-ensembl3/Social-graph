# Nicholas Routhier

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Metric Empire
**Durée dans le rôle** : 7 years 1 month in role
**Durée dans l'entreprise** : 7 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Résumé

Co-Founder and Technical Director of Metric Empire.

Previously Shipped Titles:
Battle Shapers
Design Technical Director : Assassin's Creed Origins
Level Design Technical Director : Assassin's Creed IV : Black Flag
Level Design Technical Director : Assassin's Creed Revelations
Level Design Technical Director : Prince of Persia : The forgotten sands
Level Design Technical Director : Prince of Persia (PS3, XboX360)

Level Designer : FarCry:Instincts Predator
Level Designer : FarCry:Instincts Evolution (Misson Pack).
Level Designer : FarCry:Instincts. 
Level Designer : Batman Rise of Sin Tzu

Speaker at GDC 2018 & MIGS 2017

Twitter: @NyksterR

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAA5_GEBhhJicy3oKbZCvtBdUk-St5tkX1A/
**Connexions partagées** : 5


---

# Nicholas Routhier

## Position actuelle

**Entreprise** : Metric Empire

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nicholas Routhier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391992560862404608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGHy-hhiZXpNQ/feedshare-shrink_800/B4EZpLhOgqHoAg-/0/1762203593402?e=1766620800&v=beta&t=NP2QHoZcVCa-VZvfxr5i0TayUDyP4mQw46oOhgwy_84 | Next week Forrest and I will be at the Migs to present a new game project and meet studios looking for co-development support. 

Message me if you'd like to meet! | 37 | 0 | 0 | 1mo | Post | Nicholas Routhier | https://www.linkedin.com/in/nicholas-routhier | https://linkedin.com/in/nicholas-routhier | 2025-12-08T06:13:06.178Z |  | 2025-11-06T00:19:23.090Z | https://www.linkedin.com/feed/update/urn:li:activity:7391217584920035328/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7381792419916296193 | Text |  |  | Our HR Lead is embarking on a new adventure! Marilou, we're grateful for everything and wish you nothing but the best. In the meantime, we are now looking for a HR & Ops Generalist. Hit us up if you are up for the challenge! | 8 | 1 | 0 | 1mo | Post | Nicholas Routhier | https://www.linkedin.com/in/nicholas-routhier | https://linkedin.com/in/nicholas-routhier | 2025-12-08T06:13:06.179Z |  | 2025-10-08T20:47:39.979Z | https://www.linkedin.com/feed/update/urn:li:activity:7381712667880726528/ | https://www.linkedin.com/jobs/view/4312080911/ | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7331423158220062720 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHNjktQ-GMlVw/feedshare-shrink_800/B4EZb4REgaHQAk-/0/1747921947509?e=1766620800&v=beta&t=lcjYjJt1GhxwpJvnjBFMw8MbJCOrl1QGVOHDkoXT4w4 | It's been a pleasure collaborating with these awesome teams on these beautiful games.

If you need help with yours, feel free to reach out! | 45 | 2 | 0 | 6mo | Post | Nicholas Routhier | https://www.linkedin.com/in/nicholas-routhier | https://linkedin.com/in/nicholas-routhier | 2025-12-08T06:13:06.180Z |  | 2025-05-22T20:58:12.175Z | https://www.linkedin.com/feed/update/urn:li:activity:7331316022076928001/ |  | 

---



---

# Nicholas Routhier
*Metric Empire*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [How To Make Beautiful, Shareable And Engaging Content (with Nick Routley from Visual Capitalist)](https://indiemedia.club/media/make-beautiful-shareable-engaging-content-nick-routley/)
*2023-11-27*
- Category: article

### [Cracking the Content Code: How to Create Quality Content at Scale with Nick Jordan [Ep.125] - Empire Flippers](https://empireflippers.com/creating-quality-content-at-scale)
*2023-04-10*
- Category: article

### [Reinventing Digital Real Estate: A Fresh Take on Rank and Rent with Nick Wood [The Opportunity Ep.115]](https://player.fm/series/empire-flippers-podcast/reinventing-digital-real-estate-a-fresh-take-on-rank-and-rent-with-nick-wood-the-opportunity-ep115)
*2022-12-23*
- Category: podcast

### [Reinventing Digital Real Estate: A Fresh Take on Rank and Rent with Nick Wood [Ep.115] - Empire Flippers](https://empireflippers.com/rent-first-rank-later)
*2022-12-27*
- Category: article

### [The 3 newsletter growth metrics that matter](https://www.growmynewsletter.com/posts/the-3-newsletter-growth-metrics-that-matter?ref=ghost.org)
*2024-10-10*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **["The platform is like a wizard" - Metric Empire's Story Self-Organizing ...](https://antidote.gg/case-study/metric-empire-self-organized-playtests/)**
  - Source: antidote.gg
  - *Jun 4, 2024 ... A video interview with Nicholas Routhier and Pier-Luc Papineau, Co-Founders and Directors at Metric Empire. In this case study, they d...*

- **[Battle Shapers interview: "we're developing with a premium game ...](https://www.godisageek.com/2023/09/battle-shapers-interview-were-developing-with-a-premium-game-mindset/)**
  - Source: godisageek.com
  - *Sep 6, 2023 ... After multiple hands-on, I've been impressed by the team at Metric Empire ... So I was excited to sit down with Nicholas Routhier, Co ...*

- **[『Spiritfarer』開発元の未発表作品も。資金提供をメインに自由な ...](https://news.denfaminicogamer.jp/news/210205e)**
  - Source: news.denfaminicogamer.jp
  - *Feb 5, 2021 ... o ベテランAAAディレクターのNicholas RouthierとPier-Luc Papineauによって設立されたMetric Empireは、長年の経験に基づいてデザインされた高品質な ......*

- **[Interviews | TheGamer](https://www.thegamer.com/video-interviews/)**
  - Source: thegamer.com
  - *Interview With Enric ... Nicholas Routhier, the founder and technical director of Metric Empire. Take Names, Kick Bolts - Interviewing Nicholas Routhi...*

- **[Battle Shapers is a roguelike FPS that's going to smash its way into ...](https://www.thesixthaxis.com/2023/10/03/battle-shapers-is-a-roguelike-fps-thats-going-to-smash-its-way-into-your-psyche/)**
  - Source: thesixthaxis.com
  - *Oct 3, 2023 ... ... Nicholas Routhier's, co-founder and. ... However, the team at Metric Empire have clearly spent a lot of time finding ways to make ...*

- **[Roguelike | TheGamer](https://www.thegamer.com/tag/roguelike/)**
  - Source: thegamer.com
  - *... Interview · Spread Chaos In ... Nicholas Routhier, the founder and technical director of Metric Empire · Take Names, Kick Bolts - Interviewing Nic...*

- **[Antidote - Playtesting & User Research Platform For Game Studios](https://antidote.gg/)**
  - Source: antidote.gg
  - *Nicholas Routhier. Co-Founder @ Metric Empire. “The platform is like a wizard ... Contact us to explore a custom solution for you needs. Let's talk .....*

- **[Montreal indie studio with Ubisoft design background presents ...](https://cultmtl.com/2023/10/montreal-indie-studio-with-ubisoft-design-background-present-battle-shapers/)**
  - Source: cultmtl.com
  - *Oct 11, 2023 ... We spoke with Nicholas Routhier, co-founder of Montreal game company Metric Empire, about their new game, Battle Shapers....*

- **[Playtesting & User Research Platform for Game Studios](https://antidote.gg/platform-features/)**
  - Source: antidote.gg
  - *Nicholas Routhier. Co-Founder @ Metric Empire. Metric Empire used Antidote's platform to save time and avoid logistical challenges when organizing a p...*

---

*Generated by Founder Scraper*
