# Eduardo Mandri

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Angel Host
**Durée dans le rôle** : 7 years 1 month in role
**Durée dans l'entreprise** : 7 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Travel Arrangements

## Description du rôle

Angel Host is a technology-driven, human-first, marketing and guest communication company that serves the needs of Property Managers in the short-term and vacation rental industry. From creating the perfect listing and dynamically changing prices to taking care of reservation requests 7-days a week, we make sure property owners from around the world can maximize their revenue and minimize the time needed to rent their properties.

## Résumé

Specialties: Start-ups, Online Marketing, Finance

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADTfKwBEz0GaMqI2o-OfN7_Noy4OmHcSyA/
**Connexions partagées** : 82


---

# Eduardo Mandri

## Position actuelle

**Entreprise** : Angel Host

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Eduardo Mandri
*Angel Host*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 19 |

---

## 📚 Articles & Blog Posts

### [Eduardo Mandri - Angel Host | LinkedIn](https://ca.linkedin.com/in/eduardo-mandri)
*2025-05-14*
- Category: article

### [Eduardo Mandri Email & Phone Number | Angel Host Founder and CEO Contact Information](https://rocketreach.co/eduardo-mandri-email_43767965)
*2025-01-01*
- Category: article

### [Eduardo Mandri – Medium](https://eduardo-39714.medium.com/?source=post_internal_links---------4----------------------------)
*2021-04-13*
- Category: blog

### [Eduardo Mandri - SCALE](https://scalerentals.show/speaker/eduardo-mandri/#:~:text=Eduardo%20Mandri%20is%20the%20Co,properties%20across%2060%20cities%20worldwide.)
*2025-10-09*
- Category: article

### [- YouTube](https://www.youtube.com/watch?v=ReOmGQYPG-E)
*2025-10-22*
- Category: video

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Meet the Expert Team Behind Angel Host](https://myangelhost.com/team/)**
  - Source: myangelhost.com
  - *Property Management Success with Angel Host · Eduardo Mandri · Veronique Lalonde · Adrienn Janics · Sebastien Muñoz · Manoli Gonzalez · Liza Armenta ·...*

- **[How Property Managers Can Tackle the 2025 Shoulder Season ...](https://www.rentalscaleup.com/shoulder-season-2025-strategies-property-managers/)**
  - Source: rentalscaleup.com
  - *Aug 29, 2025 ... Eduardo Mandri, Founder & CEO, Angel Host, brings the perspective of ... Our latest Podcast. Lake.com's AI Strategy: Making Waterfron...*

- **[The 3rd Annual Short Term Rental Forum (Winter) - Conference ...](https://conferenceconnect.com/events/the-3rd-annual-short-term-rental-forum-winter)**
  - Source: conferenceconnect.com
  - *Eduardo Mandri. CEO & Co-Founder Angel Host. Chris Miller. President Stay Coastal Hospitality. Andy Moore. CEO Choose Gulf ......*

- **[SaaSpasse chez Angel Host](https://www.saaspasse.com/startups/angel-host)**
  - Source: saaspasse.com
  - *Angel Host. Montréal. Financée. 1 - 50. Ventes. + 0. Job du mois · Visiter le site ... Eduardo Mandri. CEO, co-fondateur. Suivre. Angel Host. Offres d...*

- **[Shoulder Season Pricing Strategy Tips For Property Managers](https://hello.pricelabs.co/shoulder-season-pricing-strategy/)**
  - Source: hello.pricelabs.co
  - *Sep 10, 2025 ... During a recent RSU x RevLabs session, industry experts—including Jessica Mollard (Urban Network, French Alps) and Eduardo Mandri (An...*

- **[Eduardo Mandri: Angel Host Helping Vacation Rental and Short ...](https://madeinca.ca/eduardo-mandri-angel-host/)**
  - Source: madeinca.ca
  - *Nov 16, 2022 ... Home » Interviews » Eduardo Mandri: Angel Host Helping Vacation Rental and Short-Term Rental Managers in Canada and Around the World ...*

- **[Working at Angel Host | Glassdoor](https://www.glassdoor.com/Overview/Working-at-Angel-Host-EI_IE3536064.11,21.htm)**
  - Source: glassdoor.com
  - *Eduardo Mandri. 100% approve of CEO. Companies can't alter or remove ... How do job seekers rate their interview experience at Angel Host? 100% of ......*

- **[Angel Host Guest Services Agent Reviews | Glassdoor](https://www.glassdoor.co.in/Reviews/Angel-Host-Guest-Services-Agent-Reviews-EI_IE3536064.0,10_KO11,31.htm)**
  - Source: glassdoor.co.in
  - *Angel Host Guest Services Agent reviews. 5.0. Be the first to recommend this company. (4 total reviews). Eduardo Mandri. 100% approve of CEO. Companie...*

- **[Angel Host Reviews: Pros And Cons of Working At Angel Host ...](https://www.glassdoor.com/Reviews/Angel-Host-Reviews-E3536064.htm)**
  - Source: glassdoor.com
  - *Eduardo Mandri. 100% approve of CEO. 95% positive ... Related searches: Angel Host jobs | Angel Host salaries | Angel Host benefits | Angel Host inter...*

- **[Angel Host Reviews: What Is It Like to Work At Angel Host ...](https://www.glassdoor.ca/Reviews/Angel-Host-Reviews-E3536064.htm)**
  - Source: glassdoor.ca
  - *Eduardo Mandri. 100% approve of CEO. Companies can't ... Add salaryAdd interviewAdd benefits · Reviews> · Angel Host. Popular conversations. image for...*

---

*Generated by Founder Scraper*
