# Matt Holden

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : CarbonSuite
**Durée dans le rôle** : 3 years 11 months in role
**Durée dans l'entreprise** : 3 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Environmental Services

## Description du rôle

CarbonSuite is a Built for NetSuite SuiteApp that enables companies to Record, Report, and Reduce their environmental impact. 

Learn more: https://www.carbon-suite.com/

## Résumé

We need to redefine what it means to be a business.

Accounting, as we know it, was born in 15th-century Venice. It was designed to tell the "story" of a business venture at a time when companies set sail in search of new lands and new resources to extract. It was a tool to assess risk and determine if an investment was worth the return.

Fast forward 600 years, and we are still using the same fundamental accounting principles. Businesses report financials to a select group of shareholders, who focus solely on monetary returns, all under the banner of "fiduciary duty."

But the world has changed. And the story of business must change with it.

Today, we have the data and technology to see beyond financial statements. We can account for the real impact of a business, which includes its carbon emissions, energy & water consumption, waste generation, supply chain effects, and social impact. We must expand our definition of value to include a wider boundary of stakeholders and the well-being of our planet & society.

At CarbonSuite, we believe in uniting accounting and sustainability into a single, powerful storytelling framework. Through integrated carbon accounting and sustainability reporting, we can build a more complete picture of business impact and redefine the role companies play in shaping our future.

Because we believe accountants will save the earth.


🌍 Join the movement: https://carbon-suite.com/

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABf5puQBekbEXSCxfsEJRWQY5GDPHbicnNs/
**Connexions partagées** : 33


---

# Matt Holden

## Position actuelle

**Entreprise** : CarbonSuite

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Matt Holden
*CarbonSuite*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 6 |

---

## 📚 Articles & Blog Posts

### [](https://carbon-suite.com/about-us/)
- Category: article

### [Blog - CarbonSuite](https://carbon-suite.com/blog/)
- Category: blog

### [[173] Digital footprints and carbon fingerprints – with Matt and Will from Carbon Fingerprint – Sustainable(ish)](https://www.asustainablelife.co.uk/173-digital-footprints-and-carbon-fingerprints-with-matt-and-will-from-carbon-fingerprint/)
*2025-04-06*
- Category: article

### [Customers - CarbonSuite](https://carbon-suite.com/customers/)
*2025-07-17*
- Category: article

### [ESG NetSuite Reporting](https://carbon-suite.com/esg-netsuite-reporting/)
*2025-05-12*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[CSA Letter — Women Leading on Climate](https://www.womenleadingonclimate.org/csa-letter)**
  - Source: womenleadingonclimate.org
  - *Jun 3, 2025 ... Our Podcast · Our Local Chapters · News · Supporters · Get Involved. Open ... Matt Holden, CarbonSuite Inc., CEO. Virginia Roe, McGill...*

- **[LEAD Signatures • ClimateVoice](https://climatevoice.org/lead-statement-signatures/)**
  - Source: climatevoice.org
  - *... Podcast / Ecology-Facing Poet at Large. Flavia Bisi. Founder, Life ... Matt Holden. CEO, CarbonSuite. Jeffrey Hollender. Adjunct Professor, New Yo...*

- **[Carbon Accounting 101 - YouTube](https://www.youtube.com/watch?v=xdyBANVTabk)**
  - Source: youtube.com
  - *Nov 20, 2024 ... Join Matt Holden, Co-founder and CEO of CarbonSuite, for a webinar on how accountants can ... Podcast. Embark•2.7K views · 1:02:51. G...*

- **[Sustainability for the Promotional Products Industry](https://carbon-suite.com/sustainability-promotional-products-industry-ppai-carbonsuite/)**
  - Source: carbon-suite.com
  - *Aug 5, 2024 ... CarbonSuite's guide to sustainability in the promotional products ... For more information, contact us at info@carbon-suite.com. Matt ...*

- **[About Us - CarbonSuite](https://carbon-suite.com/about-us/)**
  - Source: carbon-suite.com
  - *At CarbonSuite, we are fully dedicated to using the power of data to ... Matt Holden. LinkedIn. Poyan Jadidian. CIO. Poyan Jadidian. LinkedIn. Alejand...*

- **[CarbonSuite Management Team | Org Chart](https://rocketreach.co/carbonsuite-management_b79ac8dfc5663b3c)**
  - Source: rocketreach.co
  - *Mina Behrooz (Director, Product Marketing and GTM) | Poyan Jadidian (Co-Founder) | Matt Holden (Co-Founder and CEO) | View more for CarbonSuite >>>...*

---

*Generated by Founder Scraper*
