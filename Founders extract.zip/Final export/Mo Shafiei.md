# Mo Shafiei

## Position actuelle

**Titre** : Co-Founder, CEO
**Entreprise** : zyme
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABDrFw0BmdSz4IJfSsnxh-HIvQD0ULhPvNw/
**Connexions partagées** : 6


---

# Mo Shafiei

## Position actuelle

**Entreprise** : zyme

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Mo Shafiei

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7388271022296358912 | Article |  |  | Some users asked for educational content and we heard them.

We’ve just published the first version of our docs and will keep improving them step by step.

Would love to hear any feedback, feel free to DM me anytime!

https://docs.zyme.sh | 16 | 0 | 0 | 1mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.082Z |  | 2025-10-26T17:51:19.153Z | https://docs.zyme.sh/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7383682978146607104 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEZgHm6iYZBTQ/feedshare-shrink_800/B56Zne0PbfJ4Ag-/0/1760379862783?e=1766620800&v=beta&t=WdEM9xXyUnD0vfLslZ4mq9mzRE1m7Hlvn8C3U8UaBFA | We were just updating our About page. Turns out writing about yourself is way harder than it looks. 

After a few rewrites, tweaks, and identity crises, this is what we ended up with: https://zyme.sh/about | 38 | 2 | 0 | 1mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.084Z |  | 2025-10-14T02:00:04.186Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7379364560501145600 | Text |  |  | The best decision I’ve ever made:

 💡 Leaving Apple to work on something I deeply believe in.

Since then, every day has been about learning, tackling new challenges, meeting amazing founders, and pushing zyme.sh forward.

If you’re thinking about leaving your job to start something you believe in, don’t overthink it. Just go for it.

You’ll figure out how to survive, grow and get it done along the way 🌱 | 27 | 2 | 0 | 2mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.084Z |  | 2025-10-02T04:00:13.187Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7378786188100485120 | Article |  |  | Our Product Hunt launch is live! 🎉 

https://lnkd.in/gXADzH8w | 16 | 0 | 0 | 2mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.085Z |  | 2025-09-30T13:41:58.461Z | https://www.producthunt.com/products/zyme?utm_source=linkedin&utm_medium=social |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7378639738100060160 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF665Oh26bDfA/feedshare-shrink_800/B4DZmX8VADJIAg-/0/1759190798897?e=1766620800&v=beta&t=a5r9WDP4PUi4LiTVmlzAfcMVyJYCHyBW5A3sjGeyR1c | 🚀 We just launched zyme.sh!

Join the waitlist to secure your username and get early access. | 24 | 4 | 0 | 2mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.085Z |  | 2025-09-30T04:00:02.060Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7378548312733376512 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHtEuRCGrNWaw/feedshare-shrink_800/B4DZmXelxRH4Ag-/0/1759183003412?e=1766620800&v=beta&t=458p1qrVLG0KajGnbvXXb_al7ZQMn6WzHE2V4ZSUKyU | 🚀 Big news: we launched https://zyme.sh!

Our mission is simple: human coordination must be fast, effortless, and reliable.

zyme will be the easiest way to connect with clients, teach classes, run interviews, onboard new hires, and more.

We are rolling out and ramping up servers, and we’re opening early access.

Join the waitlist and secure your spot.

#Startup #ProductLaunch | 23 | 0 | 0 | 2mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.086Z |  | 2025-09-29T21:56:44.554Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7375636096954724352 | Text |  |  | We’ve been working on something exciting lately and will be announcing it soon. Stay tuned! | 37 | 3 | 0 | 2mo | Post | Mo Shafiei | https://www.linkedin.com/in/mohsenshafiei | https://linkedin.com/in/mohsenshafiei | 2025-12-08T06:01:50.086Z |  | 2025-09-21T21:04:38.206Z |  |  | 

---



---

# Mo Shafiei
*zyme*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Mo Shafiei](https://www.blog.mohsenshafiei.com/)
*2024-08-16*
- Category: blog

### [Home :: Product Categories :: Digestion :: Alkalizing :: Mo-Zyme](https://bioticscanada.com/products/digestion/alkalizing/mo-zyme/)
*2025-01-01*
- Category: article

### [Zyme - an evolvable language](https://zyme.dev/blog/1_image_classification_by_evolving_bytecode)
*2023-01-01*
- Category: blog

### [zyme-20231231](https://www.sec.gov/Archives/edgar/data/1937653/000193765324000019/zyme-20231231.htm)
*2023-12-31*
- Category: article

### [The person and the personality behind AI companion MoeMate: Getting personal with founder Ahad Shams](https://venturebeat.com/business/the-person-and-the-personality-behind-ai-companion-moemate-getting-personal-with-founder-ahad-shams/)
*2024-03-08*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Mo Shafiei](https://mohsenshafiei.com/)**
  - Source: mohsenshafiei.com
  - *I'm a software engineer who loves creating, learning, and helping others grow. Right now, I'm focused on building zyme. Github LinkedIn Image 1. Home ...*

- **[GitHub · Where software is built](https://github.com/orgs/dubinc/followers)**
  - Source: github.com
  - *Blog · Changelog · Marketplace · View all features. Solutions. BY COMPANY SIZE ... Mo Shafiei moshafiei. zyme mtl. Follow · @shoaibrain. Shoaib Rain s...*

---

*Generated by Founder Scraper*
