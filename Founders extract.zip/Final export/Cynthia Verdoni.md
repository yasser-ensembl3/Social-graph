# Cynthia Verdoni

## Position actuelle

**Titre** : Inside sales/ parts coordinator
**Entreprise** : EMEC Machine Tools Inc
**Durée dans le rôle** : 2 months in role
**Durée dans l'entreprise** : 2 months in company

## Localisation & Industrie

**Localisation** : Pointe-Claire, Quebec, Canada
**Industrie** : Machinery Manufacturing

## Résumé

I believe in building relationships with  customers. The customer needs to know that they bring  value to you and your company. I am very strong in customer building and following up with my current client base. Listening to the client is also very important, in order to bring proper value.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAa1zgUBC7If6-GJMco7rqt0Qq01E-DG7tA/
**Connexions partagées** : 3


---

# Cynthia Verdoni

## Position actuelle

**Entreprise** : EMEC Machine Tools Inc

## Localisation & Industrie

**Localisation** : Pointe-Claire, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Cynthia Verdoni

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394024339735552000 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQElwqsr6DVa_A/feedshare-shrink_800/B56Zo7N6ATKAAg-/0/1761930093350?e=1766620800&v=beta&t=xSw5v8WyN3cz_8TLCzP3Z-tcnKySZtldGqfYzNalnbQ | Always in our hearts! 🙏🏻 | 3 | 0 | 0 | 3w | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:15:57.785Z |  | 2025-11-11T14:52:56.922Z | https://www.linkedin.com/feed/update/urn:li:activity:7393999703182524417/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388684628150079488 | Text |  |  | Luke Szymanski is #hiring. Know anyone who might be interested? | 3 | 1 | 0 | 1mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:15:57.786Z |  | 2025-10-27T21:14:50.473Z |  | https://www.linkedin.com/jobs/view/4319194884/ | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7344152865050968064 | Text |  |  | Congratulations Brianna, we are very proud of you! | 9 | 1 | 0 | 5mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.534Z |  | 2025-06-27T00:01:30.790Z | https://www.linkedin.com/feed/update/urn:li:activity:7343778801534873600/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7341484430311550977 | Article |  |  | Please help support a cause that is dear to my heart! My third year biking and supporting these beautiful children. | 3 | 0 | 0 | 5mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.534Z |  | 2025-06-19T15:18:06.371Z | https://greatcyclechallenge.ca/riders/CynthiaVerdoni?utm_source=share&utm_medium=linkedin&utm_campaign=gcc_profile_share_ind_post |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7340846615802310657 | Video (LinkedIn Source) | blob:https://www.linkedin.com/cd02c1c1-5d52-4909-bb0a-3e8e05db5221 | https://media.licdn.com/dms/image/v2/D4D05AQHSddF0qwZKdA/videocover-high/B4DZd3Yeg_HMB4-/0/1750054628099?e=1765785600&v=beta&t=J39K4foCjSi7wiwzz85ju45gIYdY0iCrRSYxfk_r5Qk | Kindness goes long ways, even in leadership! | 3 | 0 | 0 | 5mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.535Z |  | 2025-06-17T21:03:39.542Z | https://www.linkedin.com/feed/update/urn:li:activity:7340261166633353216/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7319072132418719744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEB7OUVH4RH9w/feedshare-shrink_800/B4EZZKPXMGG0Ak-/0/1745002264638?e=1766620800&v=beta&t=OSqlKe5mejN9lCNiuLQ6lcAIro_GpCpBYrzghpfaKDg | A Dear friend of mine published a book, please feel free to pick up a copy in beautiful Pointe-Claire. Very proud of you Kate | 2 | 0 | 0 | 7mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.537Z |  | 2025-04-18T18:59:38.153Z | https://www.linkedin.com/feed/update/urn:li:activity:7319069984364650496/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7309021658520956928 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQH7415MvEVtQw/feedshare-shrink_800/B4DZWO3lggG4Ag-/0/1741858693785?e=1766620800&v=beta&t=PcSXoJHH3yed50ibzcXXdfLETS_gGYVsFb3EqHVEXfQ | 🇮🇹👏🏻 | 5 | 0 | 0 | 8mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.537Z |  | 2025-03-22T01:22:38.447Z | https://www.linkedin.com/feed/update/urn:li:activity:7305884892997836800/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7287455953329815552 | Text |  |  | Come join our team, you won’t regret it! | 5 | 1 | 1 | 10mo | Post | Cynthia Verdoni | https://www.linkedin.com/in/cynthia-verdoni-40585131 | https://linkedin.com/in/cynthia-verdoni-40585131 | 2025-12-08T07:16:01.538Z |  | 2025-01-21T13:08:13.658Z | https://www.linkedin.com/feed/update/urn:li:activity:7287454424375914496/ |  | 

---



---

# Cynthia Verdoni
*EMEC Machine Tools Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Events & News | EMEC Machine Tools Inc.](https://www.emecmt.com/en/events-news/)
*2021-12-05*
- Category: article

### [New Multitasking Machine Leads to Significant Efficiency Gains – Customer Testimonial | EMEC Machine Tools Inc.](https://www.emecmt.com/en/new-multitasking-machine-leads-to-significant-efficiency-gains-customer-testimonial/)
*2024-01-25*
- Category: article

### [Women Leaders in Manufacturing Connect at EMO 2023](https://www.imts.com/read/article-details/Women-Leaders-in-Manufacturing-Connect-at-EMO-2023/1850/type/Read/1)
*2025-03-25*
- Category: article

### [EMEC: Reaching your event attendees’ emotional minds](https://www.mpi.org/blog/article/emec--reaching-your-event-attendees--emotional-minds)
*2025-01-31*
- Category: blog

### [EMEC education: Embracing change, creating our industry’s future | MPI](https://www.mpi.org/blog/article/emec-education-embracing-change-creating-our-industry-s-future)
*2023-02-01*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
