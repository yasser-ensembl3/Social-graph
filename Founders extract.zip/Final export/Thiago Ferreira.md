# Thiago Ferreira

## Position actuelle

**Titre** : Co-founder and publisher
**Entreprise** : Comix Zone
**Durée dans le rôle** : 6 years 5 months in role
**Durée dans l'entreprise** : 6 years 5 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Book and Periodical Publishing

## Description du rôle

Established in 2019, Comix Zone has quickly distinguished itself for its mission of reviving classic works from the past and promoting emerging talents of today. With a diverse catalog of over 120 titles, the publisher takes pride in featuring an impressive lineup of internationally renowned authors including Alberto Breccia, Alejandro Jodorowsky, Milo Manara, and Richard Corben, alongside notable Brazilian talents like Flavio Colin and Lourenço Mutarelli. Its YouTube channel also stands out as one of the most relevant in the segment, with over 70,000 subscribers. In 2023, Comix Zone was honored with the prestigious HQMix Trophy for Publisher of the Year. The following year, it earned the prestigious Jabuti Prize for the publication of Como Pedra.

## Résumé

Thiago Ferreira is a publisher, graphic designer, and comics critic. He graduated in Architecture from the Federal University of Alagoas and in Advertising from the Université de Montréal. Co-founder of Comix Zone, he has published more than 120 books since 2019.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAfvKf8B6JNynTOX5R9SrYB36wS1Ceffj5o/
**Connexions partagées** : 6


---

# Thiago Ferreira

## Position actuelle

**Entreprise** : Comix Zone

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Thiago Ferreira

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399461820689973248 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH1ySKq9eYIXQ/feedshare-shrink_800/B4EZrArT1PHUAk-/0/1764169171628?e=1766620800&v=beta&t=gi6BOk0X3JL2HRJ0ddClbWRyd-LfqFRovG943KV9MYw | Começou a 27ª Festa do Livro da USP, e a Comix Zone marca presença com os maiores descontos do ano – tudo com até 60% OFF!

Não vai conseguir comparecer pessoalmente? Sem problema. As ofertas também estão disponíveis em comixzone.com.br durante todo o período do evento.

É a sua chance de completar sua coleção CZ! com os melhores preços do ano.

Nos vemos lá!

🕘 Das 9h às 21h (quarta, quinta e sexta-feira)
🕖 Das 9h às 19h (sábado e domingo)
📍 Av. Professor Mello Moraes, travessa C - Cidade Universitária, São Paulo/SP | 16 | 1 | 0 | 1w | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:06:59.070Z |  | 2025-11-26T14:59:33.405Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397109401645391872 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHYh8_zr0EviQ/feedshare-shrink_800/B4EZqfPzKiHoAg-/0/1763608312102?e=1766620800&v=beta&t=aSzocd3H1VEyG6Zm02HSLOxzFqot4kbE6vYLGhxBrr0 | A história real de um cartunista e da revista satírica mais famosa de seu país, em plena resistência ao regime autoritário turco.

Longe de ser um militante ou um intelectual, Ersin Karabulut é, antes de tudo, um desenhista movido pela paixão de criar. Entre dúvidas e inseguranças, ele só quer fazer o que ama: desenhar. Ao lado de um grupo de amigos, funda a Uykusuz, uma revista de humor que rapidamente conquista o público, sobretudo os mais jovens. Mas, numa Turquia em plena transformação, as tensões políticas acabam abalando o seu cotidiano.

Em meio a momentos engraçados, comoventes e, por vezes, dolorosos, este livro revela o cotidiano de um artista arrastado, sem querer, pelos ventos turbulentos de seu tempo — em um país cada vez mais conservador, onde as liberdades vão desaparecendo pouco a pouco.

Pré-venda Diário Inquieto de Istambul vol. 2 por R$ 90,95 (30% OFF): https://lnkd.in/emx9uEaa | 14 | 0 | 0 | 2w | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:06:59.070Z |  | 2025-11-20T03:11:52.999Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394776617891557376 | Video (LinkedIn Source) | blob:https://www.linkedin.com/994aa8be-25da-4f05-ae47-9a3e04b372ae | https://media.licdn.com/dms/image/v2/D4E05AQFTmr6r0ClDcw/videocover-high/B4EZp.GEFPIQBU-/0/1763052120099?e=1765785600&v=beta&t=fXXmCtIdqNJUU_JTU_hl9peHTH166irPaFmGKqh2SRo | Já falei que a Comix Zone foi convidada para participar da Taipei International Book Exhibition 2026? Pois é — fevereiro está logo ali, e a animação só aumenta!

Taiwan tem uma das cenas culturais mais vibrantes da Ásia, com quadrinistas incríveis e um mercado editorial cheio de originalidade. Já publicamos Yan, do talentoso Chang Sheng, e recentemente anunciamos Baby, sua nova série.

Estar lá vai ser uma oportunidade única de conhecer novos autores, descobrir obras incríveis e aprofundar o diálogo com o mercado taiwanês. Espero voltar com muitas novidades e, quem sabe, novos projetos para ampliar ainda mais a presença das HQs de Taiwan no nosso catálogo. | 31 | 2 | 1 | 3w | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:06:59.072Z |  | 2025-11-13T16:42:14.011Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7392304624411705344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE0wFURKIiZHA/feedshare-shrink_800/B4EZpa94HQIUAg-/0/1762462763332?e=1766620800&v=beta&t=P4TaknGNzEMXq9xnr8fvq1mFDiYMfjNDwIBCidGfyFU | É com grande satisfação que anuncio minha participação, representando a Comix Zone, no Taipei International Book Exhibition 2026, que acontece de 2 a 6 de fevereiro, em Taiwan.

Agradecemos à Taiwan Creative Content Agency (TAICCA) pelo convite e pela oportunidade de fortalecer nossos laços com o cenário editorial taiwanês. Estamos entusiasmados para conhecer novos autores e obras e continuar ampliando a diversidade da produção asiática publicada no Brasil. | 42 | 0 | 0 | 1mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:06:59.072Z |  | 2025-11-06T20:59:24.838Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7392176958798712834 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFxuD-kg2skg/feedshare-shrink_800/B4EZpZJxYzKcAk-/0/1762432326372?e=1766620800&v=beta&t=Dg8uKIfn998EIC6hmud0kxeVMy5h4ZL_ai1dK3rh8Hg | 1º de dezembro de 2043. O “Dia da Extinção” está próximo. Nas ruas devastadas de Taiwan, um parasita misterioso conhecido como Baby transforma pessoas em monstros mecânicos, provocando um verdadeiro massacre e deixando a humanidade à beira do colapso. Atacada por um desses mutantes, Elisa sobrevive, mas um Baby se aloja em sua mão esquerda, sem, no entanto, transformá-la em um híbrido mecânico.

Um ano depois, decidida a descobrir a verdade, ela deixa a cidade em busca de respostas. Gravemente ferida, Elisa encontra um esquadrão de resgate em uma missão secreta: escoltar uma jovem enigmática chamada Alice até o último refúgio dos humanos. Encurralados pelos mutantes, eles percebem que Alice pode ser a peça central desse enigma.

Qual é a verdadeira origem de Baby? Talvez a identidade de Alice seja a chave para desvendar a origem do caos...

Pré-venda Baby vols. 1 e 2 por R$ 48,95 cada (30% OFF): https://lnkd.in/esu-zeAA | 12 | 0 | 0 | 1mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:06:59.072Z |  | 2025-11-06T12:32:06.984Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7389412725619339264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF4ddN3O7Z8sQ/feedshare-shrink_800/B4EZox3tTRGoAg-/0/1761773281204?e=1766620800&v=beta&t=ndbmVsXxpo-HE1fFUDVJ41UFnkpSIDXFZZ1TDKx_n-s | Hoje tive o prazer de encontrar o Cônsul-Geral Fernando Coimbra e a Cônsul-Geral Adjunta Bárbara Bélkior de Souza e Silva no Consulado-Geral do Brasil em Montreal.

Foi uma conversa muito agradável, em que pude apresentar a Comix Zone e discutir como a nossa editora pode contribuir para a promoção dos quadrinistas brasileiros no Canadá.

Fiquei muito feliz com o interesse e a receptividade e saio com várias ideias sobre como fortalecer essas pontes culturais. Agradeço imensamente pela acolhida e pelo diálogo tão produtivo. | 75 | 4 | 1 | 1mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.705Z |  | 2025-10-29T21:28:02.437Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7384559079790104576 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOYIXgQuNkKQ/feedshare-shrink_800/B4EZns5WQaKkAg-/0/1760616082146?e=1766620800&v=beta&t=o3Wm5Sq8BFL2TO2x4KYkIsDxRA-9ngek6YarTlMbrgU | Livremente adaptado da lenda dos Nibelungos, que inspirou Wagner em uma de suas mais belas óperas, Siegfried é uma obra-prima da fantasia heroica em quadrinhos. O lendário matador de dragões das sagas nórdicas e germânicas ganha vida sob o traço magistral de Alex Alice, criador de O Castelo das Estrelas e de O Terceiro Testamento.

Siegfried, filho de um mortal e de uma deusa, é criado por Mime, o Nibelungo, em meio aos lobos. Perseguido por Odin, o jovem se apaixona por uma valquíria, em uma jornada épica repleta de coragem, paixão e lendas ancestrais.

Pré-venda Siegfried por R$ 132,95 (30% OFF): https://lnkd.in/eQFErew3 | 22 | 0 | 0 | 1mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.706Z |  | 2025-10-16T12:01:23.095Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7381302610139492352 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGaZAcjUOxmwA/feedshare-shrink_800/B4EZm.nmPRKUAg-/0/1759839676583?e=1766620800&v=beta&t=Ngv3G_JQ6ecdRa2ZeV6wj-DLGCcFc46dRQjCoUSq1hI | Quando Vera era criança, um demônio rondava sua casa, atormentando sua mãe e martelando seus nervos até deixá-la prostrada na cama por dias. E quando, enfim, o demônio adormecia, era preciso manter silêncio absoluto para não acordá-lo. Entre as sessões de exorcismo com a curandeira e as consultas com o psiquiatra, ano após ano, a superstição se dissipa para dar lugar ao diagnóstico. Mas, apesar dos abusos, da doença e das excentricidades, o amor entre mãe e filha é mais forte que tudo, resistindo ao tempo e às tempestades.

Vencedor do Prêmio do Público do Festival de Angoulême 2024, O Corpo de Cristo é a declaração de amor de uma filha à mãe, a quem precisa cuidar desde muito jovem, e o retrato trágico e universal de uma mulher presa aos papéis de filha, mãe e esposa em uma Espanha patriarcal, pobre e católica.

Pré-venda O Corpo de Cristo por R$ 90,95 (30% OFF): https://lnkd.in/eFacE8Px | 17 | 2 | 0 | 2mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.706Z |  | 2025-10-07T12:21:20.228Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7377382689319907328 | Video (LinkedIn Source) | blob:https://www.linkedin.com/228a0b32-080a-43e0-8827-d4fef8ff5a72 | https://media.licdn.com/dms/image/v2/D4E05AQHHL3rPnVwKnQ/videocover-high/B4EZmG6GaIKUCE-/0/1758905072298?e=1765785600&v=beta&t=vC4f9YV-YkdEksntBqPyzRsUmDAqlZsOn7X76acclCk | No começo do mês, celebramos o lançamento oficial da Edição Histórica da Turma do Arrepio na Livraria Martins Fontes Paulista, com a presença especial do incrível César Sandoval, criador desta turminha que marcou gerações.

Foi uma noite mágica: leitores de todas as idades bateram papo com o autor, descobriram curiosidades dos bastidores, garantiram seus exemplares e saíram de lá com autógrafos e fotos inesquecíveis.

E se você não conseguiu ir, não se preocupe: o César estará na CCXP – e quem sabe o Belfedo também não dá as caras por lá?! | 19 | 0 | 0 | 2mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.707Z |  | 2025-09-26T16:44:58.276Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7374821371039760386 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f4a66c52-5e02-4e3c-8391-8634a831e1ab | https://media.licdn.com/dms/image/v2/D4E05AQHaFLG7QWuTxw/videocover-low/B4EZligycKGUB4-/0/1758294420235?e=1765785600&v=beta&t=IznZXqp1-BeqNB_JlrSS8eJik0eyXyJfwpDGGWJYNU4 | “Com uma trama comovente e profunda, personagens marcantes, páginas memoráveis e uma leitura crítica da nossa sociedade, Shin Zero reúne todas as qualidades de uma grande história em quadrinhos.” — Antoine Chevet (9eme Art)

Pré-venda SHIN ZERO Vol. 1 – R$ 48,95 (30% OFF): https://lnkd.in/egpZuB8u | 16 | 0 | 0 | 2mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.707Z |  | 2025-09-19T15:07:12.411Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7374577619805155328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG_f4ltwoxbbA/feedshare-shrink_800/B4EZlfDQwLKQAg-/0/1758236315900?e=1766620800&v=beta&t=6BSYNtOoBfAqAZ6_kE7f73VuXf7JoReoEIxK0hC733o | Há vinte anos, o último kaiju tombou diante do brilho multicolorido dos sentai. A vitória prometia um futuro de esperança, mas o tempo apagou a lenda. O heroísmo virou mercadoria, e os guerreiros que já salvaram cidades inteiras hoje precisam fazer bicos para sobreviver.

Shin Zero é homenagem e reinvenção do universo tokusatsu: uma narrativa poderosa sobre juventude, desencanto e a busca por sentido em um mundo que já não acredita em heróis.
 A edição nacional de Shin Zero tem acabamento de luxo, com capa cartão com orelhas e detalhes em hotstamp holográfico. São 216 páginas coloridas, impressas em papel pólen bold de alta gramatura, com miolo colado e costurado para maior durabilidade. Além disso, inclui quatro cards colecionáveis exclusivos, limitados à primeira tiragem do livro.  Pré-venda Shin Zero vol. 1, por R$ 48,95 (30% OFF): https://lnkd.in/egpZuB8u | 23 | 0 | 0 | 2mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.708Z |  | 2025-09-18T22:58:37.588Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7371269452220395520 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8a70977c-514f-4746-be56-ec5284573047 | https://media.licdn.com/dms/image/v2/D5605AQHBlSkUft8yAQ/videocover-high/B56ZkwCbyGH8CI-/0/1757447581714?e=1765785600&v=beta&t=jF8J0nTZaGilHtX9m0wJI-WXMqCURm_PQ04swX6smbc | A Turma do Arrepio vai invadir o Artists’ Valley da #CCXP25!

César Sandoval, o mestre por trás da Turma do Arrepio, está confirmado no maior festival de cultura pop do mundo, em uma parceria especial entre a Comix Zone e a CCXP.

Se você cresceu nos anos 90, lendo as revistinhas e acompanhando a turma na TV, sabe bem a importância que essas criações tiveram para a cultura pop brasileira.

Agora é a sua chance de conhecer o criador que deu vida a monstros divertidos, histórias inesquecíveis e ao humor dos Trapalhões nos quadrinhos. | 15 | 0 | 0 | 2mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.708Z |  | 2025-09-09T19:53:08.973Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7369529994760388609 | Article |  |  | Confira a resenha de Érico Assis sobre Dormindo Entre Cadáveres, publicada na Quatro Cinco Um. O quadrinho, escrito por Luís Moreira Gonçalves e Felipe Parucci, saiu recentemente pela Comix Zone.

https://lnkd.in/e2CFTB98 | 11 | 0 | 0 | 3mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.710Z |  | 2025-09-05T00:41:09.997Z | https://quatrocincoum.com.br/resenhas/quadrinhos/na-linha-de-frente/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7369340685218488321 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFnm474EWMl0Q/feedshare-shrink_800/B4EZkUoTPfIoAo-/0/1756987733675?e=1766620800&v=beta&t=BaifcS6yjvXtTqLFPL9wGeF0cDOP7TMUt3qkwjx2_uE | Petit é filho do Rei-Ogro – e o mais frágil da linhagem real. Para o pai, é uma vergonha que merece a morte. Já a mãe acredita que ele pode representar a regeneração do clã.

Este é o primeiro volume da monumental saga de fantasia sombria Os Ogros-Deuses, criada por Hubert e Bertrand Gatignol.

Pré-venda Ogros-Deuses: Petit por R$ 97,95 (30% OFF): https://lnkd.in/eM7UHJ55 | 24 | 1 | 0 | 3mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.710Z |  | 2025-09-04T12:08:55.085Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7364280592189775873 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHnVo3hiUKsKw/feedshare-shrink_800/B4EZjMuLHEGUAg-/0/1755781314166?e=1766620800&v=beta&t=EwBg2bNiwgnSqT8qBi5B7zsKpFzodrj80bC2drzFRE0 | Referência máxima da ficção científica nos quadrinhos, Juan Giménez está no auge de sua arte ao se aventurar pelas terras mágicas da fantasia heroica. Em EU, DRAGÃO, o autor argentino constrói uma epopeia grandiosa, marcada por disputas de poder, rivalidades familiares, batalhas épicas e criaturas lendárias.

Atendendo a pedidos, essa obra inesquecível retorna ao catálogo da Comix Zone em uma edição de luxo: formato grande, capa dura com verniz localizado, 192 páginas em cores, impressas em papel couché de alta gramatura.

Pré-venda EU, DRAGÃO por R$ 132,95 (30% OFF): https://lnkd.in/eaR-pTX8 | 15 | 0 | 0 | 3mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.711Z |  | 2025-08-21T13:01:54.895Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7363269672214904832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWzSBM4Lja0A/feedshare-shrink_800/B4EZi.Wv5cHgAg-/0/1755540291686?e=1766620800&v=beta&t=gwv37l7iaNV3WOQCWv2nMIL-5nf73PimPI0cLbvI1X4 | SOMOS 40 MIL!

A Comix Zone chegou a 40 mil seguidores no Instagram – e quem ganha o presente é você! Durante 48 horas, todo o site estará com até 40% de desconto.

Acesse comixzone.com.br e complete sua coleção! | 14 | 0 | 0 | 3mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.711Z |  | 2025-08-18T18:04:52.791Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7361007746541916160 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHe5MPSffgz3w/feedshare-shrink_800/B56ZieNiYaHQAk-/0/1755001006225?e=1766620800&v=beta&t=JfaPfnv6h3iwXr9QE3A4KMz4uwbKxCDjiUB98x4GXY4 | Em Dano Cerebral, o mestre do ero guro nansensu Shintaro Kago reúne quatro histórias curtas que vão testar os limites do seu cérebro – e do seu estômago.

Garotas idênticas presas em um labirinto mortal. Um quarto amaldiçoado que desafia as leis da lógica. Vizinhos desaparecem sem deixar rastro. Cadáveres mutilados encontrados dentro de carros perfeitamente intactos. Nada faz muito sentido – e é justamente aí que mora o terror.

Com seu traço vibrante e sua mente pervertidamente criativa, Kago convida o leitor para um passeio sem freios por pesadelos surreais, violência gráfica e reviravoltas insanas.

A edição da Comix Zone apresenta 192 páginas em altíssimo padrão de qualidade para colecionadores, com capa cartão, sobrecapa, papel pólen bold de alta gramatura e miolo com acabamento colado e costurado, garantindo o melhor manuseio das páginas. Além disso, inclui um marcador de página exclusivo.

Pré-venda Dano Cerebral, por R$ 48,95 (30% OFF): https://lnkd.in/gB3EdBdX | 10 | 0 | 0 | 3mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.712Z |  | 2025-08-12T12:16:47.686Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7356323962911375360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH5mI_5b4thQQ/feedshare-shrink_800/B4EZhbpqYTHIAg-/0/1753884305950?e=1766620800&v=beta&t=7Cj62_NkIoQWXiYOS6Hk3uLot0ANSTwfevulgvhNg8o | Gabriel Dantas resume gente que você conhece em dois balões. Mesmo quando essa gente é um sapo, um dragão, um gato de tapa-olho ou uma abelha. Você sempre diz: Eu conheço alguém assim.

São bifes do cotidiano, servidos em fábula e fantasia. Você vai dizer: Eu conheço essa abelha. Ah, eu conheço uma abelha bem assim.

Bife de Unicórnio: Só o Filé é a coletânea definitiva dos quadrinhos de Gabriel Dantas, reunindo o melhor de sua produção entre 2019 e 2024. A edição tem acabamento de luxo, com capa dura e 288 páginas coloridas, impressas em papel pólen de alta gramatura. Acompanha ainda um brinde exclusivo: um livro de colorir com ilustrações inéditas do autor.

Pré-venda Bife de Unicórnio: Só o Filé, por R$ 90,95 (30% OFF): https://lnkd.in/eA6J66aM | 24 | 0 | 0 | 4mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.713Z |  | 2025-07-30T14:05:06.648Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7354244716789473281 | Video (LinkedIn Source) | blob:https://www.linkedin.com/9e61399a-d4bf-4b6b-8b8d-cee4a916d5af | https://media.licdn.com/dms/image/v2/D4E05AQG-Jsr1RrxPgg/videocover-high/B4EZg.GamuHgCI-/0/1753388565481?e=1765785600&v=beta&t=s-v4mTljv625_1ijhpK4OLhUu9ygvWLEhFT3YvJ2ai8 | A magia dos Smurfs foi além dos quadrinhos e das telas – chegou ao Capão Redondo e tocou o coração de dezenas de crianças!

A ONG Interferência atende diariamente mais de 80 crianças, oferecendo educação, cultura e a chance de um futuro melhor.

Recentemente, a Comix Zone, editora que publica os Smurfs no Brasil, presenteou cada uma dessas crianças com um exemplar da série. A alegria foi imensa – mas a surpresa ficou ainda maior quando a Paramount Pictures convidou todas para assistir, em primeira mão, ao novo filme dos Smurfs, que estreou na última sexta-feira! Foi uma tarde mágica, cheia de risos e encantamento.

Nosso muito obrigado à equipe da Paramount, especialmente à Bruna Maniscalco, por tornar tudo isso possível. | 26 | 3 | 1 | 4mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.714Z |  | 2025-07-24T20:22:55.742Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7353920647955128323 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHOQduIblFDZA/feedshare-shrink_800/B4EZg5f2NmHIAo-/0/1753311309557?e=1766620800&v=beta&t=a-E8kRX8Y3br614J-gO_vFbMcZ2x9me7R17tKwHWnkE | Os anos da pandemia podem parecer um limbo na nossa memória. Um tempo suspenso, difícil até de revisitar. Mas lembrar é essencial. Dormindo Entre Cadáveres cumpre esse papel: um quadrinho que mergulha no relato de quem esteve na linha de frente e viu tudo de perto. Conheça mais sobre a nova graphic novel da Comix Zone.

Pré-venda Dormindo Entre Cadáveres, por R$ 87,45 (30% OFF): https://lnkd.in/ePgDujGy | 24 | 1 | 1 | 4mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.714Z |  | 2025-07-23T22:55:11.711Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7352753157887664129 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a13aa983-fe30-4d97-a751-149752bd8ec2 | https://media.licdn.com/dms/image/v2/D4E05AQEKRwrldRn9ww/feedshare-thumbnail_720_1280/B4EZgo56rJHEA8-/0/1753032929738?e=1765785600&v=beta&t=0aWH0I9KROW8vxLc1TkHIq93Rz0VBP9q_uChLDdAgZ8 | "Impactante, intenso e profundamente doloroso, Dormindo Entre Cadáveres é um testemunho necessário do horror e da solidariedade que marcaram o Brasil neste início de século. Uma narrativa arrebatadora, que documenta um episódio ao mesmo tempo pessoal e global, e que ganha pujança e densidade na linguagem dos quadrinhos – muito mais do que teria na prosa ou no audiovisual. O sensível equilíbrio encontrado por Felipe Parucci entre o grafismo estilizado e o registro jornalístico revela-se preciso diante da complexidade das situações retratadas, contrapondo, por exemplo, breves pausas de leveza e compaixão a uma tragédia de proporções e desumanidade grotescas. Uma obra poderosa, que traça um retrato revelador do pior e do melhor do Brasil." — Bruno Porto

Escrito pelo médico português Luís Moreira Gonçalves e desenhado por Felipe Parucci, Dormindo Entre Cadáveres é o mais novo lançamento da Comix Zone. Esta graphic novel autobiográfica narra os dias vividos por Luís na linha de frente do combate à pandemia, no coração da Amazônia, no auge da crise sanitária. Um relato cru e profundamente comovente dos bastidores da maior tragédia da nossa história recente.

Garanta o seu exemplar na pré-venda com 30% de desconto: https://lnkd.in/ePgDujGy | 15 | 0 | 2 | 4mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.715Z |  | 2025-07-20T17:36:00.388Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7351222163275685889 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFx2aw1TujXRQ/feedshare-shrink_800/B4EZgTJl74HIAk-/0/1752667941353?e=1766620800&v=beta&t=w6iaGhn3bmMRXoJftQ7NXOsznnX-iylCrORw2aWmIpA | Diziam que duraria só três meses. Erraram. Pensavam que o vírus não resistiria ao calor. Erraram de novo. Avisaram que o sistema de saúde da Amazônia poderia colapsar. Dessa vez, acertaram... Esta é a história de como a COVID devastou o pulmão do mundo.

O artista Felipe Parucci se une ao médico português Luís Moreira Gonçalves para narrar uma história real: os dias vividos por Luís na linha de frente do combate à pandemia, no coração da Amazônia, no auge da crise sanitária. Um relato cru e profundamente comovente dos bastidores da maior tragédia da nossa história recente.

A edição tem acabamento de luxo, com capa dura, verniz localizado, 320 páginas em preto e branco, impressas em papel pólen de alta gramatura.

Pré-venda Dormindo Entre Cadáveres, por R$ 87,45 (30% OFF): https://lnkd.in/ePgDujGy | 36 | 2 | 0 | 4mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.716Z |  | 2025-07-16T12:12:22.828Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7346650129606598656 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF9sQTYfcpdJA/feedshare-shrink_800/B4EZfSLXIBG4Ak-/0/1751577883720?e=1766620800&v=beta&t=vN7-msZg6TRkZK0qrIluGT3dQBxqXlbVucjw6wFWbzQ | De 4 a 7 de setembro, a Bienal de Quadrinhos de Curitiba está de volta — e a Comix Zone chega com tudo!
Vamos marcar presença com um time de autores de peso: Luckas Iohanathan, Felipe Parucci e Gabriel Dantas lançam seus novos trabalhos durante o evento.
Vai ser um encontro imperdível com o melhor da produção nacional contemporânea. Esperamos vocês por lá! | 33 | 0 | 3 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.717Z |  | 2025-07-03T21:24:45.057Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7346582232699944960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETsYJ92BHOXg/feedshare-shrink_800/B4EZfRNm89HgAk-/0/1751561696049?e=1766620800&v=beta&t=XQIXQkIt48hsELUi--U96VjGC7HECX3xcWZnRLajfUQ | A TURMA DO ARREPIO NO TOPO!

É isso mesmo: A Turma do Arrepio – Edição Histórica acaba de se tornar o quadrinho infantil mais vendido na Amazon ! E mais: é a única HQ entre os 100 livros mais vendidos do site hoje.

Esse resultado celebra a força dos nossos clássicos – e abre caminho pra muitos outros resgates de quadrinhos infantojuvenis.

Pré-venda A Turma do Arrepio – Edição Histórica, por R$ 125,90 (30% OFF): https://amzn.to/44xbGRi | 15 | 0 | 0 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.717Z |  | 2025-07-03T16:54:57.173Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7346134754099884032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQB0dKnsiWAg/feedshare-shrink_800/B4EZfK2oYDG4Ag-/0/1751455009047?e=1766620800&v=beta&t=eV5cc9U7kGfdODdbEdEA57Q58jlqGUOITRerEcv71C0 | Criada por Cesar Sandoval no fim dos anos 1980, A Turma do Arrepio foi um dos maiores sucessos dos quadrinhos infantis brasileiros. Com um humor assustadoramente afiado e personagens inspirados nos monstros clássicos do cinema, a turma rapidamente virou febre nas bancas, nas telas da TV e nos recreios da escola.

Draky, Medeia, Stein, Tuty, Luby e o inconfundível Belfedo estão de volta nesta Edição Histórica – uma seleção especialíssima com as melhores histórias da série original, todas cuidadosamente restauradas e recoloridas.

A Comix Zone reapresenta este clássico em uma edição de luxo, com capa dura, lombada arredondada e 304 páginas coloridas impressas em papel couché. O volume vem recheado de extras: capas, esboços, estudos de personagens e uma entrevista exclusiva com Cesar Sandoval. Como brinde, a edição traz ainda seis tazos colecionáveis com toda a turminha.

Se você cresceu com eles, prepare-se para reencontrar velhos amigos. Se está conhecendo agora, pode entrar sem medo: a casa é assombrada, mas o riso é garantido!

Pré-venda A Turma do Arrepio – Edição Histórica, por R$ 125,90 (30% OFF): https://lnkd.in/esFu5-Yd | 48 | 8 | 1 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.718Z |  | 2025-07-02T11:16:49.961Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7345940601277734914 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHY4zJ6xWkwNQ/feedshare-shrink_800/B4EZfIGCL.GwAk-/0/1751408718125?e=1766620800&v=beta&t=_U8NiK7a0B8lQNgMiuhdtWClg55fJfVAZKpJ4lvOPu8 | O novo lançamento da Comix Zone, Ouroboros, já está nas mãos dos leitores – e a recepção não poderia ser melhor. As primeiras reações destacam a força da narrativa, o apuro estético e a ousadia da linguagem gráfica de Luckas Iohanathan.

Para quem já conhecia o autor por Como Pedra, esta nova obra aprofunda ainda mais seu estilo único e sua visão do mundo.

Reunimos no post alguns dos primeiros comentários sobre Ouroboros.

Já leu? Compartilhe com a gente suas impressões! | 33 | 0 | 0 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.719Z |  | 2025-07-01T22:25:20.321Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7341544618632597504 | Article |  |  | A Comix Zone publicará no Brasil Dano Cerebral, mangá de terror experimental assinado por Shintaro Kago. O volume único reúne quatro histórias curtas marcadas pelo grotesco e pelo absurdo, marcas registradas do autor.

Publicadas originalmente entre 2016 e 2017 na revista Web Comic Gum, da editora japonesa Wami Books, as histórias chegam em formato 15,5 x 22 cm, com sobrecapa e brindes especiais.

Leia a matéria completa em:
https://lnkd.in/gQj-NvHa | 11 | 0 | 0 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.719Z |  | 2025-06-19T19:17:16.385Z | https://foradoplastico.com.br/dano-cerebral-comix-zone-anuncia-manga-de-shintaro-kago/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7341445471577456641 | Article |  |  | A Comix Zone publicará no Brasil Smiley, mangá de suspense psicológico criado por Mitei Hattori. A obra será lançada em formato 2 em 1, com mais de 400 páginas por volume – totalizando cinco edições. Ainda sem data de estreia definida, Smiley será o mangá mais extenso já lançado pela editora.

Publicado originalmente na revista seinen Manga Goraku, Smiley chegou ao fim no Japão em março deste ano, com 11 volumes e 1,5 milhão de cópias em circulação. A série também ganhará uma adaptação em live-action.

Leia a matéria completa em:
https://lnkd.in/gSNC93SA | 16 | 0 | 0 | 5mo | Post | Thiago Ferreira | https://www.linkedin.com/in/thiagofe | https://linkedin.com/in/thiagofe | 2025-12-08T07:07:02.720Z |  | 2025-06-19T12:43:17.885Z | https://foradoplastico.com.br/comix-zone-anuncia-o-manga-mais-longo-de-seu-catalogo/ |  | 

---



---

# Thiago Ferreira
*Comix Zone*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 23 |

---

## 📚 Articles & Blog Posts

### [Indie Founder](https://www.listennotes.com/podcasts/indie-founder-tiago-ferreira-8DSsfqCrney/?srsltid=AfmBOopZ9VEgvcKxobXubh2P0UAWdo-oMKpVLFM8c52Y82viNcvj3STM)
*2024-12-31*
- Category: podcast

### [Tiago Ferreira |
Wannabe Entrepreneur](https://www.wannabe-entrepreneur.com/authors/tiago-ferreira/)
*2022-01-01*
- Category: article

### [6 Questions for Thiago Cesar of Transfero](https://cointelegraph.com/magazine/questions-thiago-cesar-transfero)
*2023-06-08*
- Category: article

### [Thiago Costa - Cultivating taste as a designer](https://podcasts.apple.com/us/podcast/thiago-costa-cultivating-taste-as-a-designer/id1686414242?i=1000694635671&l=fr-FR)
*2025-02-21*
- Category: podcast

### [Thiago Costa - Cultivating taste as a designer | Podcast | Boomplay](https://www.boomplay.com/episode/9085135)
*2025-02-21*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Comix Zone - YouTube](https://www.youtube.com/c/canalcomixzone)**
  - Source: youtube.com
  - *Learn more. Comix Zone. Home. Shorts. Library. Comix Zone. @canalcomixzone. 69K subscribers•1.4K videos. Established in 2019 by Ferréz and Thiago Ferr...*

- **[Torre Entrevista: Thiago Ferreira (Comix Zone) – Torre de Vigilância](https://www.torredevigilancia.com/torre-entrevista-thiago-ferreira-comix-zone/)**
  - Source: torredevigilancia.com
  - *Aug 13, 2021 ... ... Thiago Ferreira, o popular Arromboss,ambos lançam a Editora Comix Zone em 2019. ... 12 – O Ferréz falou lá no Flow Podcast, e em ...*

- **[065: DUAS VEZES LUCKAS IOHANATHAN - by Érico Assis](https://virapagina.substack.com/p/065-duas-vezes-luckas-iohanathan)**
  - Source: virapagina.substack.com
  - *Nov 22, 2024 ... “Eu estava em processo de mudança, hospedado na casa do irmão, e quem me avisou foi o Thiago Ferreira da Comix Zone”, conta Luckas. “...*

- **[Comix Zone e FIQ-BH ganham prêmio no 35º Troféu HQMIX; veja a ...](https://www.publishnews.com.br/materias/2023/11/09/comix-zone-e-fiq-bh-ganham-premio-no-35-trofeu-hqmix-veja-a-lista-completa-de-vencedores)**
  - Source: publishnews.com.br
  - *Nov 9, 2023 ... Em 2019, o apresentador Thiago Ferreira e o escritor Ferréz uniram forças e criaram a editora Comix Zone, com a missão de trazer para ...*

- **[Hoje dedicado à literatura, Lourenço Mutarelli relança HQs dos ...](https://oglobo.globo.com/cultura/hoje-dedicado-literatura-lourenco-mutarelli-relanca-hqs-dos-anos-1990-e-redescoberto-por-jovens-leitores-24734442)**
  - Source: oglobo.globo.com
  - *Nov 7, 2020 ... Podcast · Vídeos · Fotos · Infográficos · Defesa do Consumidor · Últimas ... Comix Zone da dupla Thiago Ferreira e Ferréz. — Cheguei a...*

- **[Pai de Mentira - por Joe Ollmann - Comix Zone](https://www.pensanddolls.com.br/produtos/pai-de-mentira-por-joe-ollmann-comix-zone/)**
  - Source: pensanddolls.com.br
  - *... Joe Ollmann (Autor), Thiago Ferreira (Autor), Érico Assis (Tradutor) ... Comix Zone. Código do produto: comix_37. R$119,90 R$77,99. R$74,09 à vist...*

- **[Coletânea de Lourenço Mutarelli é publicada em edição capa dura](https://omaringa.com.br/noticias/cultura/coletanea-de-lourenco-mutarelli-e-publicada-em-edicao-capa-dura/)**
  - Source: omaringa.com.br
  - *Oct 26, 2023 ... A editora brasileira Comix Zone, dos editores Thiago Ferreira e ... podcast). Os candidatos serão avaliados conforme os seguintes ......*

- **[Abram as portas (e o coração) pra Turma do Arrepio - Gibizilla](https://www.gibizilla.com.br/2025/07/a-turma-do-arrepio-comix-zone/)**
  - Source: gibizilla.com.br
  - *Jul 4, 2025 ... Um dos editores da Comix Zone, Thiago Ferreira, contou recentemente ... ESCUTE O NOSSO PODCAST Aqui você escolhe ONDE quer ouvir. SIGA...*

- **[Mutarelli sequelado | Quadrinheiros](https://quadrinheiros.com/2023/11/06/mutarelli-sequelado/)**
  - Source: quadrinheiros.com
  - *Nov 6, 2023 ... Porém, o trabalho da Comix Zone foi capaz de mudar a relação do autor com os quadrinhos e Thiago Ferreira afirmou recentemente que est...*

- **[Evaristo (exclusivo Amazon) (Portuguese Edition ... - Amazon.com](https://www.amazon.com/-/es/Carlos-Sampayo-ebook/dp/B0B46PLCGS)**
  - Source: amazon.com
  - *Thiago Ferreira. Editor · Jana Bianchi. Traductor. Evaristo (exclusivo ... Comix Zone. Fecha de publicación, 15 Julio 2022. Edición, 1er. Accesibilida...*

---

*Generated by Founder Scraper*
