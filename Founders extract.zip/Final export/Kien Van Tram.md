# Kien-Van Tram

## Position actuelle

**Titre** : Founder
**Entreprise** : Dataunfold
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Technology, Information and Internet

## Résumé

“Van received his engineering degree in IT. At the age of 18, he developed and hosted multiples technology products that attracted millions of users and was a worldwide success where he led a team coming from around the world. He understands very well most of the important technical concepts and has a solid practical background that will enable him to face today IT challenges. From server administration to database passing through programming and management, he possesses all the skills and knowledge required to make him a unique technologist and visionary.”

Team management
Visionary & Leadership
System administrator
Web development
Software Development
Design Patterns
Language Patterns
AI / Bigdata
Security analyst and Firewall
ci/cd dockers and orchestrations
Linux, Windows
Analytics
SQL and NoSQL

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAIlhjMBf9dX84uunmSYyKuJReqhWFa6bDs/
**Connexions partagées** : 72


---

# Kien-Van Tram

## Position actuelle

**Entreprise** : Dataunfold

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Kien-Van Tram

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401268794637123584 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHXuxofLoq7CA/feedshare-shrink_800/B4EZraWv_HGYAo-/0/1764599988677?e=1766620800&v=beta&t=yCa98Zebwnu83w300ytIou2cE-NNt5zHdldNuEvsvxI | Today, I went to Héma-Québec to donate blood, and I’ve decided to make it a personal rule: I will donate every 2–3 months.

It surprised me to learn that only less than 3% of the population donates blood, even though a single donation can save multiple lives. It only takes a few minutes, yet its impact can be enormous.

For me, it’s a simple habit that quietly makes a difference, something small, consistent, and meaningful. It’s beneficial both for your own blood regeneration and for the people who rely on these donations. Win-Win situation!

If you’re able to donate, I truly encourage you to try. Someone out there might live because of you. | 67 | 1 | 0 | 6d | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:50.555Z |  | 2025-12-01T14:39:49.566Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397406476933160960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHjjkaWGriuLw/feedshare-shrink_800/B4EZqjd_XbHMAg-/0/1763679139903?e=1766620800&v=beta&t=YM8LygH5LPLpQC2UoQG56Kh8b9_xwUULYspj2vcOmvo | Google a dévoilé Nano Banana Pro, un nouveau modèle capable de produire et d’éditer des images de très haute qualité, avec un niveau de contrôle qui se rapproche du travail professionnel.

Ce que Nano Banana Pro permet :
- Générer des visuels haute fidélité jusqu’en 4K.
- Contrôler finement l’éclairage, la caméra, la profondeur et le style.
- Intégrer du texte lisible directement dans les images.
- Utiliser plusieurs images de référence pour assurer une cohérence visuelle (logos, couleurs, personnages, scènes).
- Créer des visuels ancrés dans le réel comme des cartes, des schémas ou des objets techniques.

Pourquoi c’est intéressant pour les professionnels :
- Marketing : création rapide de visuels localisés, adaptés à différentes audiences.
- Design & création : qualité « production » avec un gain de vitesse important.
- PME & startups : accès simplifié à des capacités créatives avancées, intégrées dans plusieurs outils de productivité.

Quelques limites à noter :
- La génération de texte n’est pas parfaite dans tous les contextes.
- Le modèle peut avoir une latence plus élevée et des coûts liés à l’usage intensif.

En bref : Nano Banana Pro est le meilleur ai image generation : plus cohérentes, plus lisibles, et plus contrôlables. | 4 | 0 | 0 | 2w | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:50.555Z |  | 2025-11-20T22:52:21.267Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7395541493484142592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHiBDFzHahL_Q/feedshare-shrink_800/B4EZqI9y5mGUAk-/0/1763234492894?e=1766620800&v=beta&t=Fz6Ky585g7QmMpRSGl1HC0CYgaC8-QADOAlS2S6szZE | If AI is a bubble, Santa Claus is real.

Every few months, this question comes back. The cycle keeps repeating itself.
Lately, we’ve seen the momentum of some big tech stocks slow down, and it has sparked the familiar debate once again: “Is AI just another bubble?”
 I understand the concern. There is massive spending, aggressive investments, and of course a few companies riding the hype with little substance.

But here is the reality:
 Most of the skepticism comes from people who are not inside the tech world, people who do not see how deep, structural, and transformative AI truly is.

AI is not a bubble.
 Yes, some players will fade, but the core technological shift is real, irreversible, and just getting started. Deep learning and generative AI are already reshaping industries and giving us tools to solve problems we have struggled with for decades.

And here is something people forget:
 No one says no to intelligence.
 How can intelligence, the very thing that drives human progress, be a bubble?

AI is not a trend. It is the amplification of our ability to think, create, and solve problems. That is not something society abandons. It only accelerates.

Are there limitations today? Absolutely.

 Infrastructure costs, energy constraints, limited context windows, hallucinations, and much more. But these challenges are being solved one by one. Algorithms are becoming more efficient, models are cheaper to run, memory is expanding, and the entire stack is improving at a speed we have never seen before.

Just a few years ago, GPT-3.5 had a context window of around 1,024 tokens. Today, we are operating in the millions.

If this is a bubble, it is one where the underlying technology keeps getting exponentially better, and where each improvement unlocks new, practical, real-world possibilities.

We are witnessing the early chapters of a transformation that will touch every corner of society.

And it is only the beginning. | 13 | 1 | 0 | 3w | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:50.556Z |  | 2025-11-15T19:21:34.563Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394370018106372096 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFN_zjnSlNefg/feedshare-shrink_800/B4EZp4UWA5IoAg-/0/1762955191047?e=1766620800&v=beta&t=zQmbxxrd2mjzd3Hyw2OlTU-L-LiCK50Z5UV2R4X6G6k | Last week was really inspiring — I had the privilege of attending the WEDO Canada | Women’s Entrepreneurship Day Organization (Quebec)– Women Entrepreneurship Quebec Summit.

Big kudos to the panelists who shared such practical insights: Ziyi, Sylvie, Miguel, and Larissa. Your conversations were powerful. What stood out to me is how often women succeed in business because they approach things differently — more intentional, more careful — and that’s actually their strength. They may speak less… but they act more.

Dorothy’s talk also really resonated with me. She reminded us that it’s not just about creating — you have to dare, and you have to be bold. Daring is the action you take; being bold is the image you project. Together, they give you power.

Shoutout to Zoonie and her team for putting together such a high-quality event. 👏 | 33 | 1 | 1 | 3w | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:50.556Z |  | 2025-11-12T13:46:33.068Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7393723384359968768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFwMZfyX6T2Mw/feedshare-shrink_1280/B4EZpvIO3xIUAw-/0/1762801020927?e=1766620800&v=beta&t=YSAU7qW4CCylS0-gY5QUvmsuxE3YOKrPQCDdAi0IPwk | Shout-out to Ascend Montréal for hosting such an incredible evening — the Ascend Montréal Gala 2025! What an inspiring community that brings together professionals and entrepreneurs alike.

Congratulations to the award recipients — Mishel Wong, Selena Lu, ASC, C.Dir., Nivatha Balendra, Fariha Naqvi-Mohamed and William C. L.. (The order doesn’t matter because each of them has achieved something truly outstanding!) 

A big thank-you to Carin and Ian for the warm hospitality. It was wonderful catching up with so many peers, friends and make new connections for years to come — Winston, Caroline, Ailin, Khang, Charles, Stéfanie, Radia Amina , An N., Marie, Eric In, Lynda, Anh-Tan, Sherine, Melody Meilleur... | 39 | 7 | 0 | 3w | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:50.557Z |  | 2025-11-10T18:57:03.569Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7378761684670377984 | Text |  |  | Le 7 octobre, j’aurai l’honneur de participer au panel « Innover et prospérer : L’esprit d’entreprise panasiatique ».
Organisé par Ascend Montréal, en collaboration avec Deloitte, National Bank of Canada et Asian Canadian Ventures Collective,  cet événement mettra en valeur la richesse de la diversité, les hauts et les bas du parcours entrepreneurial, ainsi que la force de l’innovation. Je suis impatiente de partager la scène avec des leaders inspirants : Caroline Nguyen, Ponora Ang, Adi Vashist et Zoonie Nguyen, B. Eng..
Un immense merci à Carin R. et Khang pour cette initiative et pour leur confiance. Hâte de contribuer à cette discussion.

https://lnkd.in/ecxNEKXg | 26 | 6 | 0 | 2mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.554Z |  | 2025-09-30T12:04:36.388Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7377318465818501120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhdIozVfPfZQ/feedshare-shrink_800/B4EZmGABIiIIAg-/0/1758889784697?e=1766620800&v=beta&t=_F7c2BFRHLExXm7WL4WFSZ99mokcq-sQx58bTT7xbVo | Yes, I was at ALL IN this week, the biggest AI event in Canada. I met a lot of amazing people, but I really want to highlight one team in particular, Conseil de l'innovation du Québec. They were there, standing with us, listening, helping, challenging, and pushing for AI innovation in Québec.
It was also great to catch up with Anne Nguyen, Philip Oligny, Philippe Duguay, and their team. Good vibes and great conversations.

In moments like this, you realize that innovation isn’t just about technology — it’s about the people who dare to listen, to challenge, and to believe that the future can be shaped right here, by us.

-------

Oui, j’étais à ALL IN cette semaine, le plus grand événement sur l’IA au Canada. J’ai rencontré des gens extraordinaires, mais je veux surtout mettre en lumière une équipe en particulier, Conseil de l'innovation du Québec. Ils étaient là, à nos côtés, pour écouter, aider, challenger et pousser plus loin l’innovation en IA au Québec.

J’ai aussi eu beaucoup de plaisir à revoir Anne Nguyen, Philippe Duguay, Ph.D., Philip Oligny et l'equipe. Toujours de belles discussions et de belles énergies.
Dans des moments comme celui-ci, on réalise que l’innovation n’est pas seulement une question de technologie — c’est avant tout une affaire d'humain qui osent écouter, remettre en question, et croire que l’avenir peut se construire ici, chez nous. | 56 | 4 | 0 | 2mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.555Z |  | 2025-09-26T12:29:46.200Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7376062533545406464 | Text |  |  | I will be at ALL IN event this week.

Reach out if you want to connect, chat or just say hi! | 3 | 0 | 0 | 2mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.555Z |  | 2025-09-23T01:19:08.612Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7374794727344201729 | Text |  |  | One place we can all predict we’ll be at some point in our lives is a hospital bed. Healthcare touches everyone — whether it’s for ourselves, a loved one, or just a routine visit.

That’s why supporting healthcare isn’t just about helping others, it’s about preparing for our own future. And today, AI is becoming a powerful ally in that mission: reducing wait times, assisting doctors with faster diagnoses, cutting through paperwork, and giving patients more personalized care.

When we make healthcare stronger, smarter, and more efficient with AI, we’re really helping ourselves and the people we love.

Because sooner or later, we’ll all need it. | 22 | 0 | 0 | 2mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.556Z |  | 2025-09-19T13:21:20.059Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7373356818049400832 | Article |  |  | Excited to be part of this upcoming panel.
For me, entrepreneurship is about solving problems, learning from others, and creating opportunities. Excited to share ideas and hear different perspectives! | 11 | 4 | 0 | 2mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.556Z |  | 2025-09-15T14:07:35.768Z | https://www.eventbrite.ca/e/innover-et-prosperer-lesprit-dentreprise-panasiatique-tickets-1685640850159?aff=oddtdtcreator |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7359002945444536322 | Text |  |  | What a week for OpenAI!

- OpenAI is now available on AWS!
 OpenAI’s newly released open-weight models (gpt-oss-120b and gpt-oss-20b) are now accessible via Amazon Bedrock and SageMaker — marking the first time AWS offers OpenAI models, ending Microsoft’s exclusive cloud hold.

- Two powerful open-weight models released.
 OpenAI introduced gpt-oss-120b and gpt-oss-20b — their first open-weight models since GPT-2. These models support chain-of-thought reasoning, tool use, and come with an Apache 2.0 license for commercial use.

- Strong performance, high accessibility.
 gpt-oss-120b delivers performance close to o4-mini and can run on a single 80GB GPU. gpt-oss-20b can run locally on devices with just 16GB of RAM — including PCs and mobile devices.

- A strategic move in the global AI race.
 These models empower local deployment, reduce cloud dependency, and boost U.S. competitiveness against international AI players.

And by the end of this week... something big is coming. | 14 | 0 | 0 | 4mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.558Z |  | 2025-08-06T23:30:25.857Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7348051457205583872 | Text |  |  | I will be at Startupfest this week, feel free to connect if you guys want to hang out.
Cheers! | 15 | 0 | 0 | 5mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.558Z |  | 2025-07-07T18:13:07.592Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7346966883549544449 | Text |  |  | As tech leaders, we're wired to create. But too often, we fall into the trap of building things that already exist — just because we can.

Here’s the reality:
- Building from scratch takes time
- It costs more than you think
- Maintenance becomes your new full-time job
- Innovation slows while you reinvent the wheel

Buying a solution means:
- Faster time to value
- Proven reliability
- Focus on what truly differentiates your business

You should build — but only what makes you unique.

Buy the rest, integrate smartly, and scale faster.

Let your team build the future, not internal tools you’ll spend years maintaining. | 23 | 3 | 0 | 5mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.559Z |  | 2025-07-04T18:23:25.082Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7339375685527916545 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETiXB4oFEEww/feedshare-shrink_800/B4EZdqzR0mHsAg-/0/1749843518789?e=1766620800&v=beta&t=WhrziMd11Osr2KUMSujKi2gxqjPPVUP6kc_Iw_Z2KXw | Had the chance to meet so many amazing people during the Conference of Montreal! Thank you all for the great conversations, energy, and inspiring moments.  We had fun! It was truly a fantastic event — grateful for the experience!

J’ai eu la chance de rencontrer des personnes formidables lors de la Conférence de Montréal!  Merci à tous pour les échanges inspirants, votre énergie et ces beaux moments partagés. On a eu du fun!  Ce fut un événement vraiment exceptionnel — je suis reconnaissant pour cette expérience!

Nam Hoang @vycegood Dorothy Rhau Yu L. JC Duliepre Félix-Antoine Léveillé Jeffery A Thomas Luc Jousselin Kimly C. Morgan Homo Korin B.Winston Chan Mathieu Portier Verdim Ângelo José Nancy Tang Chen Luc Jousselin Jacques Loranger Aya Rafia Xin L. Léa Perceval, MBA Hanyin CHEN Kevin Chu Jean Emmanuel Maillet Mira Vassileva Nancy Tang Chen Martin Michaud, MBA, PMP (Sure I’ve missed a few — it’s probably because I couldn’t find your LinkedIn!) | 54 | 11 | 1 | 5mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.559Z |  | 2025-06-13T19:38:42.436Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7335323205479403521 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFJDdcrIrL-vw/feedshare-shrink_800/B4EZcxNlNRHYAk-/0/1748877334382?e=1766620800&v=beta&t=5aQcQHrjtGPQ_a73ce9IyIdAwwrZ2PVJym8U2_ip0mI | Last week, I had the chance to attend the CHU Sainte-Justine Recognition Gala — a wonderful event that shines a light on the amazing individuals and teams making a real impact at the hospital.

I’m proud to have been part of the team led by Dr. Jouvet from the Applied AI in Pediatric Acute Care Group. We were nominated in the Innovation category for developing a visual bed board for the pediatric intensive care unit. This tool provides clinicians with a real-time view of the unit’s status, enabling them to anticipate patient flow and staffing needs through advanced AI-driven indicators.

Huge congratulations to all the nominees and winners for their inspiring contributions to healthcare and a better tomorrow. CHU Sainte-Justine is a place full of dedicated individuals working every day to save the lives of countless children!!!!  TRUE HEROES in action.

See more here: https://lnkd.in/etpp8cy5
#hospital #Innovation #HealthcareAI #Pediatrics #ai #healthcare | 33 | 0 | 0 | 6mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.560Z |  | 2025-06-02T15:15:35.901Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7332879563334565888 | Text |  |  | Vibe coding for hours... nuked 2 branches.

Give up...

Look into the code, make a class, and move some functions manually. took 5 minutes. Done. | 18 | 1 | 0 | 6mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.560Z |  | 2025-05-26T21:25:26.213Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7328576776878583808 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHZcsSd5uO-nQ/feedshare-shrink_800/B4EZbRVunNHcAg-/0/1747268860260?e=1766620800&v=beta&t=KCjODX8i2sPO5azxeLM63KsFrSEaMbDC5HtvlkYKfRA | Thrilled to be part of M3C 2025 — where AI and healthcare come together on the metaverse-based conference, discussing AI and the inspiring efforts of so many working to improve health for children and humanity.  Congrats to Philippe Jouvet and the team who have put this in action. | 27 | 0 | 0 | 6mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.560Z |  | 2025-05-15T00:27:41.980Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7314991069241171969 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH4H6mGcW33tw/feedshare-shrink_800/B4EZYQRnWEHYAk-/0/1744029776277?e=1766620800&v=beta&t=-9m4bwdCqolqNIinu8tdohkIeASg17lmKxMZhTgGM_4 | Before jumping on the AI agent bandwagon, please take a moment to think it through.

AI agents are the hot topic right now. Everyone is talking about them. Some are building real ones, others are simply riding the hype. But just because it's trending doesn't mean it's the right fit for your needs.
Here’s what’s important to understand:

An AI agent is not just an advanced workflow or an automation script.
It involves self-reflection, interaction with external environments, and near-autonomous decision-making. It’s complex, expensive, and not always necessary.

In many cases, a well-designed AI-powered workflow can solve the problem more efficiently, at a lower cost, and with less risk.

Running a real AI agent can cost 100 times more than running a traditional workflow-based system. It will be slower in execution due to the added complexity. That’s why tools like Manus or ChatGPT Agents often start at a couple thousand dollars and can reach much higher depending on the use case.

So, before you start building your “autonomous workforce,” ask yourself:
What is the actual problem you’re trying to solve?

- Do you need autonomy, or do you need efficiency and accuracy?
- Are you solving a genuine business need or just following the trend?

Build with purpose, not just because it’s popular. | 15 | 0 | 1 | 8mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.561Z |  | 2025-04-07T12:42:56.869Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7313596399370055683 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEqqbxbusZqIQ/feedshare-shrink_480/B4EZX8dK1wHgAY-/0/1743697260184?e=1766620800&v=beta&t=kxhB4OF8sv4uaLALwPEUnhO-EvCJSQTm_O6ZnL_EMuo | This seems to be the tariff formula the white house uses to calculate the tariff...

Here's a simpler breakdown:
mi​: This is how many goods are imported right now.
xi​: This is the target number of goods you want to import.
xi​−mi​: This shows the difference between your goal and what you currently have. It tells you how much you need to change the number of imports.
ε (epsilon): This measures how sensitive buyers are to changes in price. If buyers quickly stop buying when prices go up, even a small tax increase can lead to a big drop in imports.
ϕ (phi): This tells us how much of the tax gets added to consumers' final price. If most of the tax is passed on to the price, it affects buying decisions more. | 4 | 3 | 0 | 8mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.562Z |  | 2025-04-03T16:21:01.660Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7311359220950417409 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE51vmB7OO11g/feedshare-shrink_800/B4EZXcqd1AHUAg-/0/1743163876014?e=1766620800&v=beta&t=HG4zCPbX2ZNskpS1Kf1JESxRVdH4PGLztrURhotbyIM | AI continues to accomplish extraordinary things, despite the debates and possible risks tied to each new development. The latest OpenAI image generator tool is nothing short of amazing, enabling me to recapture moments I cherished with my grandma from over thirty years ago. She passed away more than 15 years ago after battling Alzheimer’s, and even though she couldn’t recognize me in her final days, my memory of her refuses to fade. Certain moments with her still feel as clear and alive as if they happened just yesterday.

OpenAI #openai | 43 | 3 | 0 | 8mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.562Z |  | 2025-03-28T12:11:16.760Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7309045478430568448 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFvoTaPbLQ_9w/feedshare-shrink_800/B4EZW7yIcEGwAg-/0/1742612236725?e=1766620800&v=beta&t=iLgKoGCeCfCUGBCloovVpZ-E69IdOCZ_jnnXvVnlMAw | Companies sell dreams... here is the truth. AI Coding Agent will never replace us. End of story.

Lately, I’ve been exploring AI agent development tools that supposedly write code for you—via written prompts or even what some call "vibe coding" (yes, that’s real now). Tools like Cursor and Cline are genuinely impressive. They can prototype small apps, catch bugs early, and accelerate my development flow like never before.

Truth? I can’t work without them anymore. But let’s be real: these tools are nowhere near ready to replace the full human development cycle.

The real bottleneck isn’t the code—it’s the communication.

 You’ve heard it before: “garbage in, garbage out.”
 I often spend more time trying to explain my intentions to the AI than just writing the code myself. And when the AI misunderstands? It technically works—but the logic or architecture is off, and suddenly you're chasing down bugs you didn’t expect.

Building solid software takes planning, architecture, and intentional design. You can't let AI blindly code your enterprise-grade platform. Sure, it might "work"—until it doesn’t. And when it breaks? Debugging auto-generated spaghetti code is no joke.

To non-developers, it might look like it’s working—until they hit a wall. Then asking follow-up questions doesn’t help, because the code itself has become unreadable. 

But until they can read our minds… full autonomy is a distant dream. | 10 | 2 | 0 | 8mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.563Z |  | 2025-03-22T02:57:17.556Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7301075811531382784 | Text |  |  | I just stumbled on something cool—Diffusion Language Models (DLMs) by InceptionAILabs. I never really looked into them before, but now that I have, it’s pretty fascinating.

Unlike traditional transformer models like ChatGPT, which predict the next word one at a time, DLMs take a completely different approach. They start with a noisy blob of text and gradually refine it—kind of like how Stable Diffusion generates images but for language instead.

- Generates text all at once, instead of word by word—potentially faster than transformers.
- Works on entire context, which could mean fewer hallucinations and better long-form responses.
- Some benchmarks even show it performing on par with frontier models, which is kind of a big deal. Still early days, but definitely something to keep an eye on.

🚀 #AI #MachineLearning #NLP | 10 | 0 | 0 | 9mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.563Z |  | 2025-02-28T03:08:40.898Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7295098944378818560 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHcDnu7AlJ63A/feedshare-shrink_800/B4EZT1l1M4H0Ag-/0/1739287123096?e=1766620800&v=beta&t=DgCXKhFAUQZIV7lmxA_jboAxqX579Un6Y_aTu3t7Jco | AI adoption isn’t a race to research—it’s about finding the right level of AI integration for your business. Some companies thrive as AI Users, while others push boundaries with cutting-edge research. Success is possible at any level.

💡 This is my 7-Pillar Framework to classify AI maturity in organizations. It’s not a roadmap every company must follow, but a way to evaluate their AI approach and make strategic decisions.
Here’s my perspective:

🔴 No AI – No AI adoption yet, relying on traditional processes.
🔴 User 1 – Using AI-powered tools like ChatGPT, Copilot, and automation tools to enhance productivity.
🔴 User 2 – Leveraging no-code AI platforms with pre-built models embedded within applications.
🔴 Builder 1 – Deep AI integration, where teams explore different models and techniques like RAG (Retrieval-Augmented Generation), vector searches, and hybrid AI approaches to enhance applications.
🔴 Builder 2 – Fine-tuning AI models for domain-specific needs, optimizing beyond off-the-shelf solutions.
🔴 Researcher 1 – Building AI models from scratch, leveraging architectures like RNNs, LSTMs, GRUs, CNNs, and Transformers to develop custom solutions.
🔴 Researcher 2 – Innovating beyond existing AI, creating new AI architectures, and pushing the possible limits.

- Every company has its own AI journey, and success isn’t about reaching the "top"—it’s about finding the level that drives the most value for your business.

Where does your company stand today?

#AI #MachineLearning #ArtificialIntelligence #Innovation #BusinessTransformation | 11 | 2 | 0 | 9mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.564Z |  | 2025-02-11T15:18:44.724Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7290700491833892864 | Text |  |  | You Are Wrong About Compute Overall is Going Down

It’s true that training large models requires a lot of compute power, but more and more companies are focusing on optimizing the training phase. One technique I’ve been using for years is transfer learning—or distillation from other models. This technique can be applied to all types of models, not just language allows to create smaller models as good. Even with this, companies still need compute resources to train these models, though.

Then, there's the Jevons paradox. For those who don’t know, it’s similar to electricity: when the cost of something decreases, it becomes more accessible. That means more smaller companies and individuals will have access to it. Personally, I’m dreaming of having my own H100 at home… 😄

For a long time, the focus of compute was on the training phase. But recent research has shifted the focus toward inference, with what’s known as Test-Time Compute. This allows models to conduct a chain of thought over a question to produce the best answer. The more time you put into it, the better the result. This will require even MORE computing than before.

To solve complex problems, even with sophisticated models, it’s important to follow a process similar to how humans think: don’t settle for the first answer. Analyze, think through multiple iterations, reflect, seek help, and then come up with something truly sound.

So, to everyone claiming compute will decrease… Keep dreaming! 

#ComputePower #TransferLearning #JevonsEffect #AI #MachineLearning #Inference #ModelOptimization #TechTrends #AIResearch #Innovation #FutureOfAI #DeepLearning | 8 | 1 | 0 | 10mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.565Z |  | 2025-01-30T12:00:51.918Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7290499136057987072 | Text |  |  | Happy Lunar New Year!!!! | 10 | 1 | 0 | 10mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.565Z |  | 2025-01-29T22:40:44.960Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7289670182422102016 | Text |  |  | Nvidia's stock plunged 11% today amid investor concerns about rising competition from Chinese companies and the launch of DeepSeek R1. This new model directly rivals OpenAI's O1, widely regarded as the most capable reasoning model ever created.

What remains unconfirmed, but speculated, is that DeepSeek might already have access to Nvidia's most advanced GPUs, despite government-imposed restrictions. Innovation knows no boundaries, and attempts to enforce guardrails cannot stop its relentless progress.

#AI #Nvidia #Innovation #DeepLearning | 11 | 0 | 0 | 10mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.566Z |  | 2025-01-27T15:46:47.012Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7287916086967054336 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHvOun99HgUKA/feedshare-shrink_800/B56ZSPhD59GsAk-/0/1737574596806?e=1766620800&v=beta&t=_s_iTUxxWrhS_uKmbBXlTYsdtrkJBSfdRKcpSdO0m98 | DeepSeek, a Chinese AI research company, has released DeepSeek-R1, an open-source AI model that rivals OpenAI's o1 in reasoning tasks, including mathematics and coding. DeepSeek-R1 is available under the MIT license, allowing for free use and modification. 

The model's largest version contains 671 billion parameters, which may require substantial hardware resources to run locally. However, DeepSeek has also released distilled versions, such as DeepSeek-R1-Distill with 1.5B, 7, 8B and their 32B which outperform OpenAI's o1-mini across various benchmarks and are more feasible for local deployment on consumer-grade hardware.

I tried the tiny model with only 8B parameters running local and it is quite impressive... | 15 | 0 | 0 | 10mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.566Z |  | 2025-01-22T19:36:38.066Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7286113430850134017 | Text |  |  | - Why AI Has No Limit: Beyond the Scaling Laws
In the world of Artificial Intelligence, there’s a lot of talk about scaling laws—how bigger models, more data, and greater computing lead to better performance. But here’s the truth: while scaling laws have driven AI’s evolution, they don’t define its limits. AI’s potential goes far beyond these principles.

- Scaling Is Just the Beginning
Scaling laws show us that increasing resources improves performance. But as gains begin to plateau, we’re discovering new ways to innovate that push past these boundaries. The limits of scaling are simply a gateway to infinite opportunities.

- Innovation is Infinite
1- Smarter Algorithms: New architectures and techniques are allowing models to achieve more with less.
2-  Specialized Intelligence: Focused models are outperforming general-purpose systems in niche areas.
3- Synthetic Data: When real-world data runs low, we’re generating new, high-quality datasets to fuel AI.

- Creativity Meets Capability
AI’s growth isn’t just technical; it’s about our vision. From addressing global challenges to revolutionizing industries, the possibilities are only limited by our imagination.

- Collaboration Expands the Horizon
The AI community thrives on shared knowledge, pushing innovation forward faster than ever. Together, we’re building a network of intelligence that constantly evolves.

- The Future Is Open
The question isn’t whether AI has limits—it’s how far we’re willing to go to break them. AI’s journey reflects the limitless potential of human creativity and perseverance.

#ArtificialIntelligence #AIInnovation #ScalingLaws #MachineLearning #FutureOfAI | 8 | 1 | 0 | 10mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.567Z |  | 2025-01-17T20:13:31.356Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7277517849995182080 | Text |  |  | May your Christmas be filled with joy, love, and cherished moments with your loved ones. Thank you for being part of my network, whether through meaningful conversations, inspiring collaborations, or sharing your unique insights.

Looking forward to reconnecting in 2025! | 33 | 0 | 0 | 11mo | Post | Kien-Van Tram | https://www.linkedin.com/in/kien-van-tram-26b08910 | https://linkedin.com/in/kien-van-tram-26b08910 | 2025-12-08T04:46:54.567Z |  | 2024-12-25T02:57:45.182Z |  |  | 

---



---

# Kien-Van Tram
*Dataunfold*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [@crimrose - Kien Tran](https://faun.dev/@crimrose/stories/)
*2025-05-14*
- Category: article

### [ket qua loc viet 7-2025.xlsx](https://www.agribank.com.vn/wcm/connect/f9456e7a-b988-434f-9bb1-8cdac9642a7a/ket+qua+loc+viet+7-2025.pdf?MOD=AJPERES&CVID=pz5clIn)
*2025-08-20*
- Category: article

### ['The Quintessence of the Vietnamese Revolution' through the Lens of Veteran Journalist Ha Dang](https://www.vietnam.vn/en/tinh-hoa-cach-mang-viet-nam-qua-lang-kinh-cua-nha-bao-lao-thanh-ha-dang)
*2025-06-05*
- Category: article

### [Data & AI: the year that was and looking ahead to what comes next](https://kendravant.substack.com/p/data-and-ai-the-year-that-was-and)
*2024-12-10*
- Category: blog

### [Blog | Trần Chiến](https://tranchien.com/category/blog/)
*2024-10-04*
- Category: blog

---

## 📖 Full Content (Scraped)

*6 articles scraped, 35,977 words total*

### Kien Tran (@crimrose) on FAUN.dev()
*1,617 words* | Source: **EXA** | [Link](https://faun.dev/@crimrose/stories/)

Kien Tran (@crimrose) on FAUN.dev()

===============
FAUN.dev() | The fastest way for busy developers to keep up with technologies 🚀 | www.faun.dev

===============
![Image 7](https://analytics.twitter.com/i/adsct?txn_id=o8bid&p_id=Twitter&tw_sale_amount=0&tw_order_quantity=0)![Image 8](https://t.co/i/adsct?txn_id=o8bid&p_id=Twitter&tw_sale_amount=0&tw_order_quantity=0)

[![Image 9](https://cdn.faun.dev/prod/static/public/img/faun/50-white.png)FAUN.dev()](https://faun.dev/c/)
*   [create()](https://faun.dev/co/choose/)
*   [amplify()](https://faun.dev/business/)
*   [shop()](https://bytevibe.co/)
*   [topics()](https://faun.dev/u/update/topics/)
*   [sensei()](https://faun.dev/sensei/academy/)
*   [sensei()](https://faun.dev/sensei/academy/)
*   [shop()](https://bytevibe.co/)
*   [1](https://faun.dev/@crimrose/stories/#)###### Notifications

[Now Join us today!](https://faun.dev/accounts/login/)[Login/Signup](https://faun.dev/accounts/login/) 
*   [![Image 10: Avatar](https://cdn.faun.dev/prod/static/public/img/defaults/default-avatar.png)](https://faun.dev/@crimrose/stories/#)@You [Join FAUN.dev!](https://faun.dev/accounts/login/)    [Update profile](https://faun.dev/accounts/login/)[Manage subscriptions](https://faun.dev/accounts/login/) 

#### FAUN.dev() is where engineers from GitHub, Netflix, and Shopify go to stay ahead — fast.

An effortless, straightforward way to keep up with technologies...so you can keep your tabs closed and your mind open!

[Continue with GitHub](https://faun.dev/accounts/github/login/?process=login&action=reauthenticate&method=oauth2)[Continue with Twitter](https://faun.dev/accounts/twitter/login/?process=login&action=reauthenticate&method=oauth2)

🎯 Join

Privacy-first – No spam – Always free. Already have an account? [Sign in here](https://faun.dev/accounts/magic/login/)

**70,000+** developers already joined⭐⭐⭐⭐⭐

**Trusted by developers at**

Google•Microsoft•AWS•Netflix

[![Image 11: Avatar](https://cdn.faun.dev/prod/media/public/cache/07a1ca84d74aace78bd673c36c9e36e9/37244957.jpg)](https://faun.dev/@crimrose/)
### [Kien Tran](https://faun.dev/@crimrose/)

[@crimrose](https://faun.dev/@crimrose/)

Bookworm, witty commenter, looking for innovative technologies. Can-do attitude Adaptability - take challenges for gaining "pain"

[![Image 12](https://cdn.faun.dev/prod/static/public/img/social/24/github.24.png)](https://github.com/Crimrose)

###### Developer Influence

##### 6

Influence

##### 615

Total Hits

##### 0

Posts

[Join and showcase your work and skills](https://faun.dev/accounts/signup/)

![Image 13: Content](https://cdn.faun.dev/prod/static/public/img/defaults/note.png)Posts from @crimrose..

![Image 14: Discovery Icon](https://cdn.faun.dev/prod/static/public/img/defaults/pointing-down.png)That's all from @crimrose — explore more posts below...

 Link

[![Image 15: anjali](https://cdn.faun.dev/prod/media/public/cache/9e1d3b3d3baa8cd7fb03b1ee95413d84/picture.jpg)](https://faun.dev/@anjali/)

[@anjali](https://faun.dev/@anjali/)shared a link, 2 days, 15 hours ago

Customer Marketing Manager, Last9

#### [Which Observability Tool Helps with Visibility Without Overspend](https://faun.dev/c/links/anjali/which-observability-tool-helps-with-visibility-without-overspend/)[](https://last9.io/blog/observability-tool-helps-with-visibility-without-overspend/)

A detailed look at observability platforms so you can choose tools that keep visibility high and costs steady as your systems scale.

[![Image 16: go](https://cdn.faun.dev/prod/media/public/images/go.width-545.format-webp.webp)](https://faun.dev/c/links/anjali/which-observability-tool-helps-with-visibility-without-overspend/)

![Image 17: PAW five!](https://cdn.faun.dev/prod/static/public/img/social/paw-five.png)

×

Hey, sign up or sign in to add a reaction to my post.

![Image 18](https://faun.dev/@crimrose/stories/)

### Join thousands of other developers, 100% free, unsubscribe anytime.

[Join using Twitter](https://faun.dev/accounts/twitter/login/?process=login&action=reauthenticate&method=oauth2)[Join using Github](https://faun.dev/accounts/github/login/?process=login&action=reauthenticate&method=oauth2)
We hate spam and **we will never spam you**. Already have an account? Please [**sign in**](https://faun.dev/accounts/magic/login/).

Share: [Twitter](http://twitter.com/share?text=Which%20Observability%20Tool%20Helps%20with%20Visibility%20Without%20Overspend&url=http://faun.dev/c/links/anjali/which-observability-tool-helps-with-visibility-without-overspend/&hashtags= "Share on Twitter")
|

[Linkedin](https://www.linkedin.com/sharing/share-offsite/?url=http://faun.dev/c/links/anjali/which-observability-tool-helps-with-visibility-without-overspend/ "Share on Linkedin")
|

[Facebook](https://www.facebook.com/sharer/sharer.php?u=http://faun.dev/c/links/anjali/which-observability-tool-helps-with-visibility-without-overspend/&t=Which%20Observability%20Tool%20Helps%20with%20Visibility%20Without%20Overspend "Share on Fac

*[... truncated, 23,577 more characters]*

---

### ket qua loc viet 7-2025.xlsx
*26,960 words* | Source: **EXA** | [Link](https://www.agribank.com.vn/wcm/connect/f9456e7a-b988-434f-9bb1-8cdac9642a7a/ket+qua+loc+viet+7-2025.pdf?MOD=AJPERES&CVID=pz5clIn)

STT Số thẻ Tên chủ thẻ Số tài khoản Số tiền hoàn (VND) 

2 970405******1158 NGO THI KIM THINH 5100*****1951 10.080 

3 970405******1806 PHAN THI PHUONG 7003*****2947 10.110 

4 970405******5051 NGUYEN THI HUYEN TRANG 4009*****0413 10.113 

5 970405******7983 NGUYEN DINH CHIEU 1480*****1902 10.185 

6 970405******4931 NGUYEN THI BAO CHAU 7110*****6666 10.201 

7 970405******3199 TRAN QUOC THANH 7006*****0870 10.215 

8 970405******5665 LUONG DINH CUONG 8411*****4503 10.230 

9 970405******3241 NGUYEN VIET AN 8812*****0387 10.260 

10 970405******3591 LE THANH HIEN 2202*****0889 10.288 

11 970405******3354 HUYNH TRONG TAI 5703*****6789 10.302 

12 970405******7803 NGUYEN THI PHU QUE 4608*****0039 10.323 

13 970405******3055 NGUYEN TRONG HUONG 8506*****6600 10.335 

14 970405******7944 DINH THI BICH THU 8801*****8562 10.348 

15 970405******0722 DAO THI THOAN 2118*****1120 10.353 

16 970405******9219 HOANG CONG CHINH 8802*****5888 10.356 

17 970405******9025 HA MINH BAO 7703*****1671 10.359 

18 970405******2923 NGUYEN THI DIEU HUYEN 4700*****1059 10.371 

19 970405******4321 VO VAN THAI 3603*****3029 10.416 

20 970405******1827 LAI TUU THANH 4608*****0363 10.430 

21 970405******6398 HUYNH DUC TON 7406*****1118 10.434 

22 970405******7236 HOANG HAI HUNG 2700*****8999 10.480 

23 970405******1159 NGUYEN THI HUYEN TRANG 6320*****0913 10.486 

24 970405******2262 NGUYEN VAN HUY 3519*****9799 10.509 

25 970405******0245 HO LE VY 6222*****6153 10.590 

26 970405******0395 DUONG MINH CHI 7406*****0402 10.590 

27 970405******2716 NGUYEN THI KIEU HUONG 3708*****4731 10.610 

28 970405******3113 VU NGOC VIET 8704*****0559 10.614 

29 970405******7076 TRANG THI THUY TRINH 4811*****4285 10.656 

30 970405******6871 NGUYEN TU TRINH 5101*****0759 10.656 

31 970405******3225 NGO THUY AN 5592*****0431 10.680 

32 970405******8735 LAM THUY THU NGAN 7500*****1778 10.740 

33 970405******1840 PHAM PHU CUONG 5702*****2364 10.787 

34 970405******1722 LE THI TU 7009*****2517 10.800 

35 970405******7985 TA THANH BINH 5615*****1564 10.810 

36 970405******9984 NGUYEN NGO HIEN 3120*****1097 10.829 

37 970405******4152 NGUYEN THANH NHI 5200*****9999 10.860 

38 970405******9824 NGUYEN VIET HUNG 6280*****0350 10.866 

39 970405******0220 PHAM HUU THE 3180*****2885 10.891 

40 970405******6883 DAO PHUONG THAO 2215*****8868 10.920 

41 970405******7815 NGUYEN THI PHUNG HUONG 6280*****0590 10.926 

42 970405******7214 NGUYEN THI HA 8910*****0262 11.040 

43 970405******7017 NGO KIM THUC 6440*****0885 11.070 

44 970405******0819 NGUYEN THI THU TRANG 1504*****8888 11.085 

45 970405******6489 TRAN THI KIM DUNG 6600*****5242 11.088 

46 970405******1012 NGUYEN THI KHANH PHUONG 4011*****1608 11.100 

47 970405******4008 NGUYEN THI BICH THUYEN 7606*****2168 11.100 

48 970405******7046 DU MY TRAM 6280*****0741 11.175 

49 970405******5281 NGUYEN THI DAO 4504*****8992 11.184 

50 970405******4680 PHAM THI MONG 3100*****1900 11.193 

PHỤ LỤC: DANH SÁCH KHÁCH HÀNG NHẬN HOÀN TIỀN THÁNG 7/2025 

CỦA CHƯƠNG TRÌNH KHUYẾN MẠI VUI CHI TIÊU - NHẬN NHIỀU TÍCH LŨY STT Số thẻ Tên chủ thẻ Số tài khoản Số tiền hoàn (VND) 

51 970405******2318 LE THI HANH 3522*****8888 11.250 

52 970405******8368 PHUNG THI MAI ANH 2215*****8999 11.256 

53 970405******0537 HO THI KIM QUYEN 7403*****0515 11.356 

54 970405******3734 NGUYEN THI CAM NGOC 5500*****1074 11.400 

55 970405******0231 PHAM THANH CONG 3407*****1463 11.460 

56 970405******3750 LA BICH HIEP 8400*****3553 11.490 

57 970405******1718 TRINH THI YEN NHI 6703*****5666 11.538 

58 970405******7725 HOANG THI THU THUY 3606*****8999 11.586 

59 970405******8867 LE DUC TRUNG 4511*****1991 11.587 

60 970405******8188 LE THI HONG NGOC 2112*****9999 11.643 

61 970405******1866 VO THI OANH 6280*****0294 11.761 

62 970405******5561 TRAN THI THOI 2008*****0065 11.790 

63 970405******1276 KIM THI THANH HUYEN 2700*****2373 11.790 

64 970405******5067 CHU THI THU HIEN 2215*****0773 11.805 

65 970405******2852 TRANG TU MANH 7000*****2388 11.847 

66 970405******9541 NGUYEN CHAU HANG CHI 6222*****7740 11.903 

67 970405******8204 NGUYEN DOAN KIM THANH 6000*****2203 11.925 

68 970405******2384 NGO THI KHANH VAN 1305*****1080 11.940 

69 970405******3974 TRUONG THI THU 2604*****1091 11.970 

70 970405******1295 PHAM DUC VINH 3160*****4901 12.000 

71 970405******4632 DIEN THI HAI YEN 3300*****1099 12.000 

72 970405******0587 NGUYEN CANH SINH 3603*****5333 12.000 

73 970405******5324 TRUONG CONG MAO 3908*****0086 12.000 

74 970405******6561 TRAN THANH QUANG 5206*****1305 12.000 

75 970405******8519 NGUYEN ANH NHU 7102*****8910 12.000 

76 970405******9113 LUU VAN TAN 5104*****0328 12.001 

77 970405******9321 NGUYEN THI TRANG THUY 8206*****0242 12.002 

78 970405******8877 TRAN VAN CHUC 5400*****3640 12.090 

79 970405******4719 NGUYEN THI XUYEN 2211*****6642 12.120 

80 970405******7781 PHAM THI THANH NHAN 3620*****0113 12.153 

81 970405******6031 LUONG THI DUNG 3618*****0121 12.229 

82 970405***

*[... truncated, 217,091 more characters]*

---

### 'The Quintessence of the Vietnamese Revolution' through the lens of veteran journalist Ha Dang
*5,863 words* | Source: **EXA** | [Link](https://www.vietnam.vn/en/tinh-hoa-cach-mang-viet-nam-qua-lang-kinh-cua-nha-bao-lao-thanh-ha-dang)

'The Quintessence of the Vietnamese Revolution' through the lens of veteran journalist Ha Dang

===============

[![Image 4: vietnam-icon](https://vjs.vietnam.vn/assets/images/full-logo.png)](https://www.vietnam.vn/en/ "Vietnam.vn - Nền tảng quảng bá Việt Nam")
----------------------------------------------------------------------------------------------------------------------------------------------------

English

Login

*   [Home](https://www.vietnam.vn/)
*   [Topic](https://www.vietnam.vn/topics)
*   [News](https://www.vietnam.vn/news)
*   [Political System](https://www.vietnam.vn/political-activities)
*   [Destination](https://www.vietnam.vn/destination)
*   [Event](https://www.vietnam.vn/events)
*   [Travel](https://www.vietnam.vn/du-lich)
*   [Happy Vietnam](https://happy.vietnam.vn/)
*   [Enterprise](https://www.vietnam.vn/enterprise)
*   [Product](https://www.vietnam.vn/product)
*   [Heritage](https://www.vietnam.vn/di-san)
*   [Museum](https://www.vietnam.vn/museum)
*   [Figure](https://www.vietnam.vn/figure)
*   [Multimedia](https://www.vietnam.vn/multimedia)
*   [Data](https://www.vietnam.vn/data)

1.   [Home](https://www.vietnam.vn/en/)
2.    
3.   [News](https://www.vietnam.vn/en/category/news)
4.    
5.   [Culture – Society](https://www.vietnam.vn/en/category/van-hoa-xa-hoi)

'The Quintessence of the Vietnamese Revolution' through the lens of veteran journalist Ha Dang
==============================================================================================

### The book is a collection of articles with profound theoretical content, crystallizing the concerns, thoughts and aspirations of a journalist - political activist throughout his life devoted to the revolution.

![Image 5: vietnamplus-vn](https://vphoto.vietnam.vn/thumb/24x24/vietnam/resource/IMAGE/2025/1/23/350b6aa1505d47ae958041623ccfad44)VietnamPlus•05/06/2025

* * *

Follow Vietnam.vn on

G o o g l e

 News

0

Towards the 100th anniversary of Vietnam Revolutionary Press Day (June 21, 1925 - June 21, 2025), on the afternoon of June 5, Nhan Dan Newspaper in collaboration with the National [Political](https://www.vietnam.vn/category/chinh-tri "Politics") Publishing House Su That launched the book _"Quintessence of Vietnamese Revolution"_ by veteran journalist Ha Dang.

The book is a selection of 112 articles and interviews by journalist Ha Dang from 1955 to present. Many of these articles have been published in Nhan Dan Newspaper, Communist Magazine, books by the National Political Publishing House Truth...

With a capacity of nearly 800 pages, the book consists of three parts.

Part I includes 50 articles on the Party's guidelines and policies, the State's policies and laws, [Ho Chi Minh](https://www.vietnam.vn/destination/ho-chi-minh "Ho Chi Minh") 's ethics and ideology, important resolutions of the Party through congresses, Party building, building a rule-of-law State, the path to socialism, people's mastery...

![Image 6: hadang.jpg](https://vstatic.vietnam.vn/vietnam/resource/IMAGE/2025/6/5/470545af448345a6be124807d99aab07)

 The book "The Quintessence of Vietnamese Revolution" is a collection of articles with profound theoretical content. (Photo: PV/Vietnam+)

Part II selects 32 articles about leaders and some leaders of the Vietnamese revolution, such as: President Ho Chi Minh, President Ton Duc Thang, [General Secretary](https://www.vietnam.vn/tag/tong-bi-thu "General Secretary") Truong Chinh, General Secretary Le Duan, General Secretary Nguyen Van Linh, General Secretary Nguyen Phu Trong, Prime Minister Pham Van Dong, Advisor at the Paris Conference Le Duc Tho, Chairman of the Council of Ministers Pham Hung...

Part III reflects the achievements in implementing the Party's guidelines and policies, the State's policies and laws, including 30 articles in many genres: reportage, essays, analysis, and comments that Ha Dang appreciated in his career as a journalist. One can mention the article "Three times catching up with the middle peasants" written about Dai Phong Cooperative, which received a letter of praise from Uncle Ho...

In this section, he also devoted many articles to discussing journalism, the combative nature of revolutionary journalism, and the role of journalists in the process of national renewal.

![Image 7: bnd-4482.jpg](https://vstatic.vietnam.vn/vietnam/resource/IMAGE/2025/6/5/1c042bb8a5dd409ea4f59abe1747e43e)

 The organizers and journalist Ha Dang presented the book to representatives of the National Library of Vietnam, Hanoi Library, Academy of Journalism and Communication, and Vietnam Press Museum. (Photo: PV/Vietnam+)

Sharing at the book launch ceremony, author Ha Dang said that the first article he wrote was in 1955 when he was first assigned to work at Nhan Dan Newspaper in Hanoi, and the most recent article was in July 2024, published in Communist Magazine.

“At the age of 96, I have spent nearly 80 years writing many articles. Although this is not my official job, my journalism career is what 

*[... truncated, 81,214 more characters]*

---

### Data & AI: the year that was and looking ahead to what comes next
*450 words* | Source: **EXA** | [Link](https://kendravant.substack.com/p/data-and-ai-the-year-that-was-and)

Data & AI: the year that was and looking ahead to what comes next

===============

[![Image 1: Data Runs Deep](https://substackcdn.com/image/fetch/$s_!rpS_!,w_80,h_80,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F57642f3a-7b85-4086-9939-a7d8dde97ac2_480x480.png)](https://kendravant.substack.com/)

[Data Runs Deep](https://kendravant.substack.com/)
==================================================

Subscribe Sign in

Data & AI: the year that was and looking ahead to what comes next
=================================================================

### A series of interviews with folks I wanted to hear from

[![Image 2: Kendra Vant's avatar](https://substackcdn.com/image/fetch/$s_!W9VF!,w_36,h_36,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F20543e59-1b00-44c8-ba8a-1c5b988e260e_763x763.jpeg)](https://substack.com/@kendravant)

[Kendra Vant](https://substack.com/@kendravant)

Dec 10, 2024

4

Share

Because we take our long summer break over the Christmas New Year period in Australia, December has a bad habit of turning into a slog to the finish line for a lot of folks.

Then the holidays come, all your favourite podcasts go on break and it can be a bit of a content desert.

Not this year dear reader.

I woke up on Sunday and decided I would see if I could twist the arms of some of my favourite data & AI veterans to briefly share their reflections on what they’ve found interesting this year, what they are hoping 2025 might bring and who they read/follow/listen to to stay current.

Turns out I could! Which was rather fabulous.

Starting later this week and continuing through December and January I will be sharing my conversations. Read along as they come or store them all up for a lazy day in the sun / in front of the fire.

Subscribe, share widely and stay tuned!

Artwork by [BoliviaInteligente](https://unsplash.com/@boliviainteligente?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash) on [Unsplash](https://unsplash.com/photos/a-number-of-letters-with-confetti-falling-around-them-I5Th1B4eMos?utm_content=creditCopyText&utm_medium=referral&utm_source=unsplash)

* * *

#### Subscribe to Data Runs Deep

By Kendra Vant · Launched 2 years ago

Explore the opportunities and impacts of data and AI in the world today alongside a forever curious lapsed physicist with an insatiable interest in real world impacts and 7 years spent building AI powered products in SaaS companies with global reach. 

Subscribe

By subscribing, I agree to Substack's [Terms of Use](https://substack.com/tos), and acknowledge its [Information Collection Notice](https://substack.com/ccpa#personal-data-collected) and [Privacy Policy](https://substack.com/privacy).

 

[![Image 3: Andrew John's avatar](https://substackcdn.com/image/fetch/$s_!G0tJ!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F94804a2b-99f0-4c72-8adf-ec073eadecd3_144x144.png)](https://substack.com/profile/167122597-andrew-john)

[![Image 4: Pipeline to Insights's avatar](https://substackcdn.com/image/fetch/$s_!gpOd!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd98ddb69-fdec-4599-b3f2-906f7673c8de_408x408.png)](https://substack.com/profile/42238863-pipeline-to-insights)

[4 Likes](https://kendravant.substack.com/p/data-and-ai-the-year-that-was-and)

[](https://substack.com/note/p-152879397/restacks?utm_source=substack&utm_content=facepile-restacks)

4

Share

Previous Next

#### Discussion about this post

Comments Restacks

![Image 5: User's avatar](https://substackcdn.com/image/fetch/$s_!TnFC!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack.com%2Fimg%2Favatars%2Fdefault-light.png)

Top Latest Discussions

[The disturbing new ubiquity of AI note takers](https://kendravant.substack.com/p/the-disturbing-new-ubiquity-of-ai)

[Because data is like toothpaste; hard to put back in the tube after collection](https://kendravant.substack.com/p/the-disturbing-new-ubiquity-of-ai)

May 21•

[Kendra Vant](https://substack.com/@kendravant)

11

1

![Image 6](https://substackcdn.com/image/fetch/$s_!VFet!,w_320,h_213,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2F8675d056-bf05-4e4f-98a7-9585b4032301_2992x2000.jpeg)

[Which humans in which loop are we on about?](https://kendravant.substack.com/p/which-humans-in-which-loop-are-we)

[And why it worries me ...](https://kendravant.substack.com/p/which-humans-in-which-loop-are-we)

Aug 13•

[Kendra Vant](https://substack.com/@kendravant)

11

6

3

![Image 7](https://substackcdn.com/image/fetch/$s_!3I2I!,w_320,h_213,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.co

*[... truncated, 1,094 more characters]*

---

### Không tìm thấy trang này
*380 words* | Source: **EXA** | [Link](https://tranchien.com/category/blog/)

[Trần Chiến](https://tranchien.com/)Chia sẻ những gì mình biết

*   [Marketing](https://tranchien.com/category/marketing/)
*   [Branding](https://tranchien.com/category/branding/)
*   [Business](https://tranchien.com/category/business/)
*   [Đọc sách](https://tranchien.com/category/doc-sach/)
*   [Checkout](https://tranchien.com/tds-checkout/)
*   [My account](https://tranchien.com/tds-my-account/)
*   [Login/Register](https://tranchien.com/tds-login-register/)
*   [Privacy Policy](https://tranchien.com/privacy-policy/)

Ooops... Error 404

Sorry, but the page you are looking for doesn't exist.

You can go to the [HOMEPAGE](https://tranchien.com/)

#### OUR LATEST POSTS

[![Image 1: bảng tuần hoàn các yếu tố content marketing](https://tranchien.com/wp-content/uploads/bang-tuan-hoan-contents-marketing-768x483.jpg)](https://tranchien.com/bang-tuan-hoan-cac-yeu-to-content-marketing/ "Bảng tuần hoàn các yếu tố của Content Marketing")

[Content Marketing](https://tranchien.com/category/marketing/content-marketing/)

### [Bảng tuần hoàn các yếu tố của Content Marketing](https://tranchien.com/bang-tuan-hoan-cac-yeu-to-content-marketing/ "Bảng tuần hoàn các yếu tố của Content Marketing")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

10/09/2020

[0](https://tranchien.com/bang-tuan-hoan-cac-yeu-to-content-marketing/#respond)

[![Image 2: Từ khóa người mua](https://tranchien.com/wp-content/uploads/buyer-keywords-768x480.png)](https://tranchien.com/cach-toi-uu-3-loai-tu-khoa-cua-nguoi-mua/ "Cách tối ưu 3 loại từ khóa của người mua bằng công cụ của Alexa")

[Search Engine Optimization](https://tranchien.com/category/marketing/seo/)

### [Cách tối ưu 3 loại từ khóa của người mua bằng công cụ của Alexa](https://tranchien.com/cach-toi-uu-3-loai-tu-khoa-cua-nguoi-mua/ "Cách tối ưu 3 loại từ khóa của người mua bằng công cụ của Alexa")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

05/09/2020

[0](https://tranchien.com/cach-toi-uu-3-loai-tu-khoa-cua-nguoi-mua/#respond)

[![Image 3: Email marketing là gì](https://tranchien.com/wp-content/uploads/email-marketing-la-gi-768x432.jpg)](https://tranchien.com/email-marketing-la-gi/ "Email Marketing là gì? Những lưu ý khi triển khai Email Marketing")

[Email Marketing](https://tranchien.com/category/marketing/email-marketing/)

### [Email Marketing là gì? Những lưu ý khi triển khai Email Marketing](https://tranchien.com/email-marketing-la-gi/ "Email Marketing là gì? Những lưu ý khi triển khai Email Marketing")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

21/08/2020

[0](https://tranchien.com/email-marketing-la-gi/#respond)

[![Image 4: Hướng dẫn xây dựng chuỗi Email Marketing Automation](https://tranchien.com/wp-content/uploads/chuoi-email-marketing-768x328.jpg)](https://tranchien.com/xay-dung-chuoi-email-marketing-automation/ "Hướng dẫn xây dựng chuỗi Email Marketing Automation")

[Email Marketing](https://tranchien.com/category/marketing/email-marketing/)

### [Hướng dẫn xây dựng chuỗi Email Marketing Automation](https://tranchien.com/xay-dung-chuoi-email-marketing-automation/ "Hướng dẫn xây dựng chuỗi Email Marketing Automation")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

20/08/2020

[0](https://tranchien.com/xay-dung-chuoi-email-marketing-automation/#respond)

[![Image 5: Cách viết Email Marketing: Từ cơ bản – Nâng cao](https://tranchien.com/wp-content/uploads/cach-viet-email-marketing-768x432.jpg)](https://tranchien.com/cach-viet-email-marketing/ "Cách viết Email Marketing: Từ cơ bản – Nâng cao")

[Email Marketing](https://tranchien.com/category/marketing/email-marketing/)

### [Cách viết Email Marketing: Từ cơ bản – Nâng cao](https://tranchien.com/cach-viet-email-marketing/ "Cách viết Email Marketing: Từ cơ bản – Nâng cao")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

20/08/2020

[0](https://tranchien.com/cach-viet-email-marketing/#respond)

[![Image 6: Chương trình referral thất bại](https://tranchien.com/wp-content/uploads/chuong-trinh-referral-that-bai.jpg)](https://tranchien.com/4-ly-do-khien-chuong-trinh-gioi-thieu-that-bai/ "4 lý do khiến chương trình giới thiệu thất bại")

[Referral Marketing](https://tranchien.com/category/marketing/referral-marketing/)

### [4 lý do khiến chương trình giới thiệu thất bại](https://tranchien.com/4-ly-do-khien-chuong-trinh-gioi-thieu-that-bai/ "4 lý do khiến chương trình giới thiệu thất bại")

[Trần Chiến](https://tranchien.com/author/mrtranchien/) -

16/08/2020

[0](https://tranchien.com/4-ly-do-khien-chuong-trinh-gioi-thieu-that-bai/#respond)

*   [Marketing](https://tranchien.com/category/marketing/)
    *   [Search Engine Optimization](https://tranchien.com/category/marketing/seo/)
    *   [Content Marketing](https://tranchien.com/category/marketing/content-marketing/)
    *   [Email Marketing](https://tranchien.com/category/marketing/email-marketing/)
    *   [Social Media Marketing](https://tranchien.com/category/marketing/social-media-marketing/)

*   [Brandin

*[... truncated, 429 more characters]*

---

### DataUnfold - ACET
*707 words* | Source: **GOOGLE** | [Link](https://acet.ca/en/portfolio/our-startups/dataunfold/)

DataUnfold - ACET

===============
[Skip to content](https://acet.ca/en/portfolio/our-startups/dataunfold/#content)

[![Image 4](https://acet.ca/wp-content/uploads/2023/12/ACET_logo-white-national-bank.svg)](https://acet.ca/en/)

[Present your project](https://acet.ca/en/lets-schedule-a-call/)

*   [Français](https://acet.ca/portfolio/nos-entreprises/dataunfold/ "Switch to Français")
*   [English](https://acet.ca/en/portfolio/our-startups/dataunfold/)

[Menu](https://acet.ca/en/portfolio/our-startups/dataunfold/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6OTg0LCJ0b2dnbGUiOnRydWV9)

[Present your project](https://acet.ca/en/lets-schedule-a-call/)

*   [Presentation](https://acet.ca/en/portfolio/our-startups/dataunfold/#presentation)
*   [Personalized support](https://acet.ca/en/portfolio/our-startups/dataunfold/#accompagnement)
*   [iA7](https://acet.ca/en/portfolio/our-startups/dataunfold/#ia7)
*   [Quantacet](https://acet.ca/en/portfolio/our-startups/dataunfold/#quantacet)
*   [Acet & Quantino](https://acet.ca/en/portfolio/our-startups/dataunfold/#acet)

*   [Presentation](https://acet.ca/en/portfolio/our-startups/dataunfold/#presentation)
*   [Personalized support](https://acet.ca/en/portfolio/our-startups/dataunfold/#accompagnement)
*   [iA7](https://acet.ca/en/portfolio/our-startups/dataunfold/#ia7)
*   [Quantacet](https://acet.ca/en/portfolio/our-startups/dataunfold/#quantacet)
*   [Acet & Quantino](https://acet.ca/en/portfolio/our-startups/dataunfold/#acet)

[Home](https://acet.ca/en/)[Startups](https://acet.ca/en/portfolio/)DataUnfold

Propelled

DataUnfold
==========

Turn unstructured data into actionable insights using AI

![Image 5](https://acet.ca/wp-content/uploads/2025/05/van_photo-e1747066271114-567x600.jpeg)

[](https://www.linkedin.com/in/kien-van-tram-26b08910/)Kien-Van Tram

Cofounder, CEO

![Image 6](https://acet.ca/wp-content/uploads/2025/05/vince_photo-e1747066173258.jpg)

[](https://www.linkedin.com/in/vincent-archambault/)Vincent Archambault

Cofounder, Director of product

DataUnfold empowers organizations to turn unstructured data into actionable insights using AI. Our solution streamlines classification, analysis, and action on documents.

![Image 7](blob:http://localhost/a1bb74cf88b886e877fb209050189e2b)

Links

[See the website](https://www.dataunfold.com/)

[](https://www.linkedin.com/company/dataunfold/)

Discover other incubated startups
---------------------------------

Here are the companies that are at the heart of each of our decisions and that we are proud to support.

[Digital technologies ![Image 9](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/agendrix/)

[Digital technologies ![Image 11](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Incubated](https://acet.ca/en/portfolio/our-startups/amical-ai-en/)

[Digital technologies ![Image 13](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/araura/)

[Digital technologies ![Image 15](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/bankeo/)

[Digital technologies ![Image 17](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/bb-inventions-en/)

[Digital technologies ![Image 19](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/berkindale-analytics/)

[Digital technologies ![Image 21](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Incubated](https://acet.ca/en/portfolio/our-startups/biasafe-en/)

[Digital technologies ![Image 23](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Incubated](https://acet.ca/en/portfolio/our-startups/byecho-ai-en/)

[Digital technologies ![Image 25](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Incubated](https://acet.ca/en/portfolio/our-startups/cdao-services-en/)

[Digital technologies ![Image 27](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/classcraft-en/)

[Digital technologies ![Image 29](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/cogni-xr/)

[Digital technologies ![Image 31](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/cubicspace/)

[Digital technologies ![Image 33](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Incubated](https://acet.ca/en/portfolio/our-startups/datasophia-en/)

[Digital technologies ![Image 35](blob:http://localhost/2397d1366f84c41288c148c7050a4723) Learn more Propelled](https://acet.ca/en/portfolio/our-startups/dataunfold/)

[Digital technologies ![Image 37](blob:http://localhost/239

*[... truncated, 11,802 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[DataUnfold - ACET](https://acet.ca/en/portfolio/our-startups/dataunfold/)**
  - Source: acet.ca
  - *DataUnfold. Turn unstructured data into actionable insights using AI. Kien-Van Tram ... Blog and news (FR) · Contact us · Français · Present your proj...*

---

*Generated by Founder Scraper*
