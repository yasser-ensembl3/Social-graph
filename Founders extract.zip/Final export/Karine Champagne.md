# Karine Champagne

## Position actuelle

**Titre** : Biok+ (sept 2012) et Genuine Health (nov 2013) Denis Breton buick Chevrolet GMC (2014) Boiron (2014)
**Entreprise** : Ambassadrice
**Durée dans le rôle** : 13 years 3 months in role
**Durée dans l'entreprise** : 13 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Promotion des saines habitudes de vie 
Merci d'être partenaires de mes projets les plus fous !

## Résumé

Conférencière depuis 2015,  Karine surprend et renverse par sa présence, sa simplicité, son énergie sa vulnérabilité et sa grande force.

''J'étais présente ce week-end à La Place Bell. J'entends, je vois , je lis, je cherche, mais n'avais pas encore compris.....   Ta présence, ta prestance, ton dynamisme, tes mots, tes rires, tes gestes, toi... ta façon d'être toi m'ont définitivement fait comprendre plusieurs heures de théories....  que je pourrai enfin , mettre en pratique, car je comprends, je ressens.....  Merci, Merci, Merci à la vie de t'avoir mise sur ma route..... 
Annie R.
Abitibi

Karine explique avec douceur et légèreté ce qu'elle appelle son grand rituel de passage, c'est à dire la dépression qui l'a frappée en 2010-2011. Bien que l'événement soit sombre, à travers son talent de raconteuse, elle partage avec l'audience toutes les clés de son rétablissement et surtout cette prise en charge exemplaire qu'elle a choisi afin de connecter avec qui elle est vraiment.  Et chaque apprentissage se transpose dans les différentes sphères de la vie. Les stratégies s'appliques partout, pour la santé, le travail, le leadership, les finances, la famille ou l'aventure.

S'autoriser à changer à s'améliorer est le plus grand cadeau que l'on puisse s'offrir.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA6dQJ0BwJ1ytYxsgeMAjMRmx6Ewj88nZXc/
**Connexions partagées** : 56


---

# Karine Champagne

## Position actuelle

**Entreprise** : Champagne Sports Medias inc

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Karine Champagne
*Champagne Sports Medias inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Karine Champagne - Women's Y Foundation](https://fondation.ydesfemmesmtl.org/en/laureates/karine-champagne/)
*2023-08-02*
- Category: article

### [Impacter le monde avec Karine Champagne](https://podcastai.com/it/programmi/cwcie6-impacter-le-monde-avec-karine-champagne)
*2025-04-25*
- Category: podcast

### [Studio Champagne I Luxury Travel Planner & Consultant](https://www.studiochampagne.fr/)
*2025-01-01*
- Category: article

### [](https://karagoldin.com/podcasts/marc-champagne/)
- Category: podcast

### [Full article: “Tell the Story as You'd Tell It to Your Friends in ...](https://www.tandfonline.com/doi/full/10.1080/1461670X.2021.1910541)
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Impacter le monde: Le podcast de Karine Champagne](https://www.karinechampagne.ca/podcast)**
  - Source: karinechampagne.ca
  - *Le podcast de Karine Champagne. Ce podcast est dédié à celles qui souhaitent ... Champagne Sports Medias Inc. Politique de confidentialité Conditions ...*

- **[Jouer avec son corps](https://www.karinechampagne.ca/joueravecsoncorps)**
  - Source: karinechampagne.ca
  - *Si tu ne me connais pas déjà, je m'appelle Karine Champagne, Monitrice de camp de jour terrestre. ... Champagne Sports Medias Inc. Join Our Free Trial...*

- **[La grande expérience terrestre](https://www.karinechampagne.ca/Lagrandeexperienceterrestre11)**
  - Source: karinechampagne.ca
  - *... Karine Champagne. J'ai 49 ans d'âge terrestre, mais des millions d'années d ... Champagne Sports Medias Inc. Join Our Free Trial. Get started toda...*

- **[S'empuissancer: Le podcast de Karine Champagne](https://www.karinechampagne.ca/en/podcast)**
  - Source: karinechampagne.ca
  - *... Karine Champagne. More Info. Encore plus de questions: Le podcast de Karine Champagne ... Champagne Sports Medias Inc. Politique de confidentialit...*

- **[Coaching](https://www.karinechampagne.ca/coaching)**
  - Source: karinechampagne.ca
  - *Sur cette planète, je m'appelle Karine Champagne. J'ai 47 ans d'âge ... Non, les séances ne sont pas remboursables. © 2025 Champagne Sports Medias Inc...*

- **[karine champagne - Poussière peut attendre(La)](https://www.archambault.ca/livres/poussi%C3%A8re-peut-attendre-la/karine-champagne/9782981987709/?id=3514942)**
  - Source: archambault.ca
  - *Jan 1, 2021 ... article. Sous-total. 0,00 $. Votre panier est vide. Passer à la ... KARINE CHAMPAGNE. Éditeur. CHAMPAGNE SPORTS MEDIAS INC. Prix. 23,4...*

- **[KARINE CHAMPAGNE - La Poussière peut attendre - Croissance ...](https://www.renaud-bray.com/Livres_Produit.aspx?id=3514942&def=Poussi%C3%A8re+peut+attendre(La)%2CCHAMPAGNE%2C+KARINE%2C9782981987709)**
  - Source: renaud-bray.com
  - *karine champagne. KARINE CHAMPAGNE. Titre : La Poussière peut attendre. Date de parution : 01 janvier 2021. Éditeur : CHAMPAGNE SPORTS MEDIAS INC. ......*

---

*Generated by Founder Scraper*
