# Jeffrey Dungen

## Position actuelle

**Titre** : Co-Founder and CEO
**Entreprise** : reelyActive
**Durée dans le rôle** : 13 years 4 months in role
**Durée dans l'entreprise** : 13 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Telecommunications

## Description du rôle

If the best way to predict the future is indeed to create it, then my role at reelyActive is perhaps best defined as chief creator.  Despite a current economic culture that encourages short-term gains over long-term impact, together as a team we have persevered not only in creating this future, both from a technological and philosophical standpoint, but have also created a resilient business.
My experience co-founding and leading reelyActive has reinforced my value as a tech CEO, able to wear many hats when required, and, critically, to pitch to any target audience then execute to deliver as promised.
With major clients and partners around the globe, the reelyActive of today is a disruptive business with a strong activist culture which has never sacrificed its vision and edge.

## Résumé

Hi, I’m Jeff, and my objective is to contribute significantly to the sustainable advancement of humanity.

Imagine a world in which the contribution of value is traceable across human activities, and how that may foster an inclusive economy in which all participants benefit equitably.  Not only do I envisage that world, in fact I have chosen to live my life as if that world currently exists.

The foundational technologies that I, as a computer engineer, develop and democratise, are open source and accessible to all.  My contributions are therefore entirely traceable: just visit github.com/jeffyactive.  I therefore have a vested interest in an inclusive economy in which the value of such contributions benefits the participants, like myself.

My passions extend beyond technology to include activism, philosophy and entrepreneurship, which together serve me well in both my personal mission and my role as co-founder and CEO of reelyActive where we are making this world a reality.  Through the paradigm of context-aware physical spaces―in which the natural human environment is the interface―computers can make sense of our reality, helping us freely exchange whatever information we consider to be of value.

Thanks for taking the time to learn more about me, my motivations and my principles.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAR-V8BW5_q6mobPmsODWtwImHQrL9CKlM/
**Connexions partagées** : 117


---

# Jeffrey Dungen

## Position actuelle

**Entreprise** : reelyActive

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jeffrey Dungen
*reelyActive*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [The reelyActive Blogs](https://blog.reelyactive.com/page/2/)
*2023-02-03*
- Category: blog

### [Team](https://www.reelyactive.com/team/)
*2025-01-01*
- Category: article

### [Jeffrey Dungen - Contact Information](https://www.leadsforge.ai/contact/jeffrey-dungen-a3f8508d)
*2025-01-01*
- Category: article

### [RFID – The reelyActive Blogs](https://blog.reelyactive.com/tag/rfid/)
*2019-10-20*
- Category: blog

### [A brief history of Ambient IoT](https://blog.reelyactive.com/2023/04/09/a-brief-history-of-ambient-iot/)
*2023-04-09*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Press Coverage](https://www.reelyactive.com/press/)**
  - Source: reelyactive.com
  - *reelyActive measuring the real world like the Web. Mélanie Pilon, Vitrine Star Tech. EN FR. 09 03 18. PNR Podcast Episode 26: Jeffrey Dungen, CEO @ re...*

- **[reelyActive heads to Silicon Valley's Plug and Play to make ...](https://betakit.com/reelyactive-represents-canada-at-silicon-valleys-plug-and-play-demo-day/)**
  - Source: betakit.com
  - *Sep 20, 2016 ... Podcast · Newsletter · Quiz · Jobs. reelyActive represents Canada at ... ” – reelyActive CEO Jeffrey Dungen. Yet, a small fraction of...*

- **[Artistic Collaborations](https://www.reelyactive.com/art/)**
  - Source: reelyactive.com
  - *Light Wires (Slow Tech). Evelyne Drouin (Kinesthetic Artist) and Jeffrey Dungen (reelyActive) ... Exhibition Interview (FR). Together, let's make sens...*

- **[TILES-2019: A longitudinal physiologic and behavioral data set of ...](https://pmc.ncbi.nlm.nih.gov/articles/PMC9436730/)**
  - Source: pmc.ncbi.nlm.nih.gov
  - *... interview with six residents prior to the full study. ... We also thank Evidation Health for their help with data collection and Jeffrey Dungen fr...*

- **[Scientific Publications](https://www.reelyactive.com/science/)**
  - Source: reelyactive.com
  - *Mohamed Imran Jameel, Jeffrey Dungen (reelyActive). PDF IEEE Xplore. 2nd IEEE ... Tutorials presented by Jeffrey Dungen at the annual IEEE RFID confer...*

- **[A brief history of Ambient IoT – The reelyActive Blogs](https://blog.reelyactive.com/2023/04/09/a-brief-history-of-ambient-iot/)**
  - Source: blog.reelyactive.com
  - *Apr 9, 2023 ... ... conference in 2013. reelyActive's demo at IEEE LCN 2013. The ... I (Jeffrey Dungen, reelyActive co-founder and CEO) remember a day...*

- **[IEEE RFID 2022 – The 16th Annual IEEE International Conference ...](https://2022.ieee-rfid.org/)**
  - Source: 2022.ieee-rfid.org
  - *TUTORIAL: RFID as Ambient Data – PDF slides of Jeffrey Dungen's talk are available here! Jeffrey Dungen – reelyActive. There are tens of billions of s...*

- **[Occupying the space in the middle of 100 Billion+ radio-identifiable ...](https://dl.acm.org/doi/pdf/10.1145/3565887.3567511)**
  - Source: dl.acm.org
  - *Koozoo, reelyActive), and is the co-founder and CEO of reelyActive. Jeffrey ... He is a regular conference speaker. ACM Reference Format: Jeffrey Dung...*

- **[Minew and reelyActive: Unlocking Scalable, Open IoT with ...](https://www.minew.com/minew-and-reelyactive-hardware-software-integration/)**
  - Source: minew.com
  - *Aug 7, 2025 ... ... Jeffrey Dungen, co-founder and CEO of reelyActive. “Our partnership ... Conference · Ultra-Long Range · Ultra-Thin · UWB technolog...*

- **[a deployable solution for indoor tracking of workers in construction ...](https://www.itcon.org/papers/2025_56-ITcon-Khazen.pdf)**
  - Source: itcon.org
  - *Jeffrey Dungen, Co-founder and Chief Executive Officer ... The authors would also like to acknowledge the support of reelyActive company with respect ...*

---

*Generated by Founder Scraper*
