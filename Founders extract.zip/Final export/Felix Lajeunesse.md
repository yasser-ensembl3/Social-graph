# Felix Lajeunesse

## Position actuelle

**Titre** : Co-Founder / Chief Creative Officer
**Entreprise** : Félix & Paul Studios
**Durée dans le rôle** : 12 years 3 months in role
**Durée dans l'entreprise** : 12 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Media Production

## Résumé

Felix Lajeunesse is a Primetime Emmy Award-winning and Peabody Award-winning director. He is the Co-Founder and Chief Creative Officer of Felix & Paul Studios - a world leader in immersive entertainment. 

Over the past 10 years, Felix has directed more than 30 virtual reality experiences that have helped expand the world of interactive and immersive storytelling, including "The People's House with Barack and Michelle Obama", "Space Explorers : The ISS Experience" and "Space Explorers : The Infinite". Through Felix & Paul Studios' award-winning projects, Felix has collaborated closely with world-renowned organizations, leaders and artists : NASA, President Barack and Michelle Obama, President Bill Clinton, LeBron James, Eminem, Drake, Wes Anderson, Reese Witherspoon, Brie Larson, Jeff Goldblum and many others.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAO-I5sBnT8ek43ju4kzbJW4hPG3mZImfdc/
**Connexions partagées** : 49


---

# Felix Lajeunesse

## Position actuelle

**Entreprise** : Felix & Paul Studios

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Felix Lajeunesse

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401827535807807488 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE4vW6OP-Z72g/feedshare-shrink_800/B4EZrg5O.LKMAg-/0/1764709691725?e=1766620800&v=beta&t=qtMATGuCghv_9cgCj479MIOIPxwvPSI07X8zmoq0uQo | Thanks to Travel Weekly for providing great insights on Interstellar Arc! | 10 | 0 | 0 | 5d | Post | Felix Lajeunesse | https://www.linkedin.com/in/felix-lajeunesse-38b04219 | https://linkedin.com/in/felix-lajeunesse-38b04219 | 2025-12-08T04:52:29.321Z |  | 2025-12-03T03:40:03.842Z | https://www.linkedin.com/feed/update/urn:li:activity:7401728922779930624/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394087344011915265 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFje-loaweMxg/feedshare-shrink_800/B4EZp0P8BcIIAg-/0/1762886930990?e=1766620800&v=beta&t=EP1WBnGdVkTET5JiKICK2ok7gqAprlTsOSzKUNHYFx4 | This is the beginning of an odyssey. We just premiered Interstellar Arc at AREA15, Las Vegas - and we were fortunate enough to be surrounded by friends and partners from the industry, and creative collaborators who've helped us make this vision come to life. Thanks to everyone involved, this was a huge milestone! | 144 | 16 | 1 | 3w | Post | Felix Lajeunesse | https://www.linkedin.com/in/felix-lajeunesse-38b04219 | https://linkedin.com/in/felix-lajeunesse-38b04219 | 2025-12-08T04:52:29.322Z |  | 2025-11-11T19:03:18.312Z | https://www.linkedin.com/feed/update/urn:li:activity:7394083718853963778/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7388777183822979072 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE0SH9L9X_RbA/feedshare-shrink_800/B4EZonbykrHoAg-/0/1761598189754?e=1766620800&v=beta&t=_TruVkifCG4sVGE5MBeUNIlOlX1HqL_zkJKOhuPo5FQ | Thanks to Neon for this first-ever review of Interstellar Arc! | 39 | 0 | 0 | 1mo | Post | Felix Lajeunesse | https://www.linkedin.com/in/felix-lajeunesse-38b04219 | https://linkedin.com/in/felix-lajeunesse-38b04219 | 2025-12-08T04:52:29.323Z |  | 2025-10-28T03:22:37.465Z | https://www.linkedin.com/feed/update/urn:li:activity:7388678339827310593/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7357222279384047616 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFr1PHFib4uxg/feedshare-shrink_800/B4EZhQlASBGoAs-/0/1753698535192?e=1766620800&v=beta&t=gaDkzPR5jtQ2DzUa1C1HHJeVQ_n6Fve8ok5Rc6HZowA | Boum! | 56 | 2 | 0 | 4mo | Post | Felix Lajeunesse | https://www.linkedin.com/in/felix-lajeunesse-38b04219 | https://linkedin.com/in/felix-lajeunesse-38b04219 | 2025-12-08T04:52:29.324Z |  | 2025-08-02T01:34:41.985Z | https://www.linkedin.com/feed/update/urn:li:activity:7355544788403666945/ |  | 

---



---

# Felix Lajeunesse
*Felix & Paul Studios*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 21 |

---

## 📚 Articles & Blog Posts

### [Félix Lajeunesse](https://xp.land/xlist/xlistings/felix-lajeunesse)
*2024-01-23*
- Category: article

### [Felix & Paul Studios Marks 10th Anniversary With Behind-the-Scenes Series Inside Felix & Paul Studios](https://www.felixandpaul.com/news/inside-felix-and-paul-studios/)
*2025-02-03*
- Category: article

### [SIGGRAPH Spotlight: Episode 57 – In Conversation With Félix and Paul](https://blog.siggraph.org/2022/07/siggraph-spotlight-episode-57-in-conversation-with-felix-and-paul.html/)
*2022-07-01*
- Category: blog

### [Félix Lajeunesse - Co-Founder & Creative Director at Felix & Paul Studios | The Org](https://theorg.com/org/felix-paul-studios/org-chart/felix-lajeunesse)
*2024-11-12*
- Category: article

### [Our Team | Immersive Entertainment | Felix & Paul Studios](https://www.felixandpaul.com/team/)
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*9 articles scraped, 21,983 words total*

### Félix Lajeunesse
*425 words* | Source: **EXA** | [Link](https://xp.land/xlist/xlistings/felix-lajeunesse)

[![Image 1](https://www.xp.land/wp-content/uploads/2023/08/xlist-2023-label-1.png)](https://www.xp.land/xlist/)

![Image 2: Félix Lajeunesse](https://www.xp.land/wp-content/uploads/2023/09/FelixLajeunesse_NEWMEDIA-1024x1024.png)

The Virtual Reality Pioneer
---------------------------

As the co-founder of the **Emmy award-winning immersive entertainment studio** Felix & Paul Studios, Félix Lajeunesse has created AR, VR, and MR originals like _Space Explorers_ with NASA, _Traveling While Black_ with Roger Ross Williams, and _The Confessional_ with Judd Apatow. His studio calls both LA and Montréal home, which perfectly reflects its unique blend of creativity (hello, Hollywood) and technology (Montreal’s VFX, AI, blockchain, and VR scene). Félix met the studio’s other co-founder, Paul Raphaël, while studying film at Montréal’s Concordia University; after school, he teamed up with Paul to produce the world’s first VR film, _Strangers_ with musician Patrick Watson. “The main struggle was to ‘make the leap’ from the established world of film and television, to the totally uncharted world of virtual reality,” Felix told _Voyage Houston_. The rest, as they say, is VR history. For the past decade, the duo have been trailblazers in the field, working on immersive cinema for franchises like _Jurassic World_ and _Wild,_ and collaborating with the likes of the Obamas, Eminem and Wes Anderson.

![Image 3: INDIVIDUALS IN SPACE TWIRLING AROUND IN METAL RINGS DURING CIRQUE DU SOLEIL PERFORMANCE, ALEGRIA](https://www.xp.land/wp-content/uploads/2023/09/LEAD_Alegria_-A-Spark-of-Light.jpg)

Photo via @felixandpaul on Instagram

### Projects

The studio’s focus for the past few years has been on the human space experience. An official NASA partner, the duo first worked on the virtual reality series _Space Explorers_. Now, brave guests with strong stomachs can climb aboard the International Space Station (ISS) via _**THE INFINITE**_, an immersive space experience in Houston. It’s one small step for man, one giant leap for mankind. In 2019, Felix & Paul took us on an intimate ride through Eminem’s hometown in _**Marshall**_ _**From Detroit,**_ and in 2017, they won an Emmy for Original Interactive Program for _**The People’s House: Inside the White House With Barack and Michelle Obama**_. Their most recent project, an AR version of 1987’s _Jim Henson’s The Storyteller: The Seven Ravens_, premiered at the 80th Venice International Film Festival in summer 2023.

*   [![Image 4: Video via @felixandpaul on Instagram](https://www.xp.land/wp-content/uploads/2023/09/thumbnail-vimeo-test-540x644.png)](https://player.vimeo.com/video/868819745?h=afcb90102e&dnt=1&app_id=122963)

### Alegria: A Spark of Light 
*   [![Image 5: Photo via @spaceexplorers.theinfinite on Instagram](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite.jpg)

### The Infinite 
*   [![Image 6: The Infinite](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite-2-1-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite-2-1.jpg)

### The Infinite 
*   [![Image 7: The Infinite](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite-1-1-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/09/The-Infinite-1-1.jpg)

### The Infinite 
*   [![Image 8: Photo via @felixandpaul on Instagram](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black.jpg)

### Traveling While Black 
*   [![Image 9: Traveling While Black](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black-2-1-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black-2-1.jpg)

### Traveling While Black 
*   [![Image 10: Traveling While Black](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black-1-1-540x607.jpg)](https://www.xp.land/wp-content/uploads/2023/09/Traveling-While-Black-1-1.jpg)

### Traveling While Black 
*   [![Image 11: Photo via @felixandpaul on Instagram](https://www.xp.land/wp-content/uploads/2023/10/The-Peoples-House-1-540x644.jpg)](https://www.xp.land/wp-content/uploads/2023/10/The-Peoples-House-1.jpg)

### The People’s House

---

### Felix & Paul Studios Marks 10th Anniversary With Behind-the-Scenes Series Inside Felix & Paul Studios
*411 words* | Source: **EXA** | [Link](https://www.felixandpaul.com/news/inside-felix-and-paul-studios/)

### Inside Felix & Paul Studios presented by Canon lifts the curtain on the studio’s pioneering creative process, decade of groundbreaking immersive storytelling, and upcoming productions.

**Montreal, Canada - November 15, 2023 -**To celebrate its 10th anniversary, Felix & Paul Studios, the Emmy-Award winning creator of immersive entertainment experiences, proudly introduces Inside Felix & Paul Studios, an 8-episode series presented by Canon available on Meta Quest (3D 180) and YouTube (2D and 3D 180). This series offers an exclusive look at the studio’s decade-long journey as a pioneer of immersive entertainment experiences, providing unique access into its creative and technological laboratories.

> "Inside Felix & Paul Studios is an intimate journey into the heart of what makes our studio tick. We are excited to take viewers on this immersive trip, showcasing the blend of artistry and innovation that has propelled our presence-based approach to storytelling for the last decade,"Felix Lajeunesse, Chief Creative Officer and Co-founder, Felix & Paul Studios

**Felix Lajeunesse, Chief Creative Officer and Co-founder, Felix & Paul Studios**

*   The series reflects on the studio’s legacy, emphasizing how instilling a profound sense of presence has been pivotal to each project.

*   The series spotlights the technical and creative teams breaking ground on immersive camera engineering, sound design, and post-production, sharing the intricacies of their process.

*   Viewers will gain insights into the studio's unfolding projects focused on the future of space exploration.

*   The series demystifies technology, celebrates creativity, and showcases how challenges transform into opportunities, igniting innovative solutions.

*   The series revisits iconic Felix & Paul Studios' productions, including the first-ever cinematic VR film "Strangers with Patrick Watson", the intimate tour of the White House with the Obamas in "The People’s House", and the awe-inspiring journey into outer space with the Emmy-award-winning "Space Explorers" series.

*   Filmed utilizing Canon's cutting-edge RF5.2mm F2.8 L Dual Fisheye lens and the EOS R5 C camera, each 7-8-minute episode showcases the blend of innovative creativity and technology that underpins Felix & Paul Studios’ success.

> We've had an incredible decade of pushing the boundaries in immersive entertainment. With Inside Felix & Paul Studios we're thrilled to give unprecedented access to our creative and technological labs and shine a light on the incredible people working behind-the-scenes,"Paul Raphael, Chief Innovation Officer and Co-founder, Felix & Paul Studios

**Paul Raphael, Chief Innovation Officer and Co-founder, Felix & Paul Studios**

All episodes are available on Meta Quest and on the Felix & Paul Studios YouTube channel.

---

### SIGGRAPH Spotlight: Episode 57 – In Conversation With Félix and Paul
*989 words* | Source: **EXA** | [Link](https://blog.siggraph.org/2022/07/siggraph-spotlight-episode-57-in-conversation-with-felix-and-paul.html/)

SIGGRAPH Spotlight: Episode 57 – In Conversation With Félix and Paul - ACM SIGGRAPH Blog

===============

*   [Contributor Toolkit](https://blog.siggraph.org/siggraph-contributor-amplification-toolkit/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

*   [Contributor Toolkit](https://blog.siggraph.org/siggraph-contributor-amplification-toolkit/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

[Join SIGGRAPH](https://www.siggraph.org/join-siggraph/)

[![Image 1](https://blog.siggraph.org/wp-content/uploads/2024/03/siggraph-blog-logo.svg)](https://blog.siggraph.org/)

*   [Categories](https://blog.siggraph.org/2022/07/siggraph-spotlight-episode-57-in-conversation-with-felix-and-paul.html/#)
    *   [ACM SIGGRAPH](https://blog.siggraph.org/category/acm-siggraph/)
    *   [Animation](https://blog.siggraph.org/category/animation/)
    *   [Art](https://blog.siggraph.org/category/art/)
    *   [Augmented Reality](https://blog.siggraph.org/category/augmented-reality/)
    *   [Business](https://blog.siggraph.org/category/business/)
    *   [Conferences](https://blog.siggraph.org/category/conferences/)
    *   [Data](https://blog.siggraph.org/category/data/)
    *   [Design](https://blog.siggraph.org/category/design/)
    *   [Education](https://blog.siggraph.org/category/education/)
    *   [Emerging Technologies](https://blog.siggraph.org/category/emerging-technologies/)
    *   [Film](https://blog.siggraph.org/category/film/)
    *   [Gaming](https://blog.siggraph.org/category/gaming/)
    *   [Graphics](https://blog.siggraph.org/category/graphics/)
    *   [Hardware](https://blog.siggraph.org/category/hardware/)
    *   [Industry Leaders](https://blog.siggraph.org/category/industry-leaders/)
    *   [Interactive Techniques](https://blog.siggraph.org/category/interactivetechniques/)
    *   [Mobile](https://blog.siggraph.org/category/mobile/)
    *   [Production](https://blog.siggraph.org/category/production-1/)
    *   [Programming & Scripting](https://blog.siggraph.org/category/programming-scripting/)
    *   [Real-Time](https://blog.siggraph.org/category/realtime/)
    *   [Research](https://blog.siggraph.org/category/research/)
    *   [Simulation](https://blog.siggraph.org/category/simulation/)
    *   [Software](https://blog.siggraph.org/category/software/)
    *   [Students](https://blog.siggraph.org/category/students/)
    *   [Theory](https://blog.siggraph.org/category/theory/)
    *   [Uncategorized](https://blog.siggraph.org/category/uncategorized/)
    *   [Virtual Reality](https://blog.siggraph.org/category/virtualreality/)
    *   [Visual Effects](https://blog.siggraph.org/category/visualeffects/)

*   [Join SIGGRAPH](https://www.siggraph.org/join-siggraph/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

*   [Categories](https://blog.siggraph.org/2022/07/siggraph-spotlight-episode-57-in-conversation-with-felix-and-paul.html/#)
    *   [ACM SIGGRAPH](https://blog.siggraph.org/category/acm-siggraph/)
    *   [Animation](https://blog.siggraph.org/category/animation/)
    *   [Art](https://blog.siggraph.org/category/art/)
    *   [Augmented Reality](https://blog.siggraph.org/category/augmented-reality/)
    *   [Business](https://blog.siggraph.org/category/business/)
    *   [Conferences](https://blog.siggraph.org/category/conferences/)
    *   [Data](https://blog.siggraph.org/category/data/)
    *   [Design](https://blog.siggraph.org/category/design/)
    *   [Education](https://blog.siggraph.org/category/education/)
    *   [Emerging Technologies](https://blog.siggraph.org/category/emerging-technologies/)
    *   [Film](https://blog.siggraph.org/category/film/)
    *   [Gaming](https://blog.siggraph.org/category/gaming/)
    *   [Graphics](https://blog.siggraph.org/category/graphics/)
    *   [Hardware](https://blog.siggraph.org/category/hardware/)
    *   [Industry Leaders](https://blog.siggraph.org/category/industry-leaders/)
    *   [Interactive Techniques](https://blog.siggraph.org/category/interactivetechniques/)
    *   [Mobile](https://blog.siggraph.org/category/mobile/)
    *   [Production](https://blog.siggraph.org/category/production-1/)
    *   [Programming & Scripting](https://blog.siggraph.org/category/programming-scripting/)
    *   [Real-Time](https://blog.siggraph.org/category/realtime/)
    *   [Research](https://blog.siggraph.org/category/research/)
    *   [Simulation](https://blog.siggraph.org/category/simulation/)
    *   [Software](https://blog.siggraph.org/category/software/)
    *   [Students](https://blog.siggraph.org/category/students/)
    *   [Theory](https://blog.siggraph.org/category/theory/)
  

*[... truncated, 9,323 more characters]*

---

### Félix Lajeunesse - Co-Founder & Creative Director at Felix & Paul Studios | The Org
*447 words* | Source: **EXA** | [Link](https://theorg.com/org/felix-paul-studios/org-chart/felix-lajeunesse)

Félix Lajeunesse - Co-Founder & Creative Director at Felix & Paul Studios | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

*   [![Image 1: Felix & Paul Studios logo](https://cdn.theorg.com/af3817a6-eb7a-4829-a6cd-8a13cf1172e3_thumb.jpg) Felix & Paul Studios](https://theorg.com/org/felix-paul-studios)
*   Félix Lajeunesse

Unverified

![Image 2: Félix Lajeunesse's profile picture](https://cdn.theorg.com/a0e2b958-df98-4ce3-ba33-f51c4c0bde1b_thumb.jpg)

Félix Lajeunesse
================

### Co-Founder & Creative Director

Contact

Félix Lajeunesse is a Canadian virtual reality filmmaker and the co-founder and creative director of Felix & Paul Studios. Félix has directed and produced numerous virtual reality films, including the Emmy Award-winning Nomads series.

Lajeunesse was born in Montreal, Quebec, Canada. Félix studied film at Concordia University, where they met their future business partner, Paul Raphael. After graduation, the two founded Felix & Paul Studios in 2010.

The studio quickly gained a reputation for its high-quality virtual reality experiences, and has since produced a wide variety of films and series, including the critically acclaimed Nomads series. In 2017, the studio released its first feature-length film, Miyubi.

Lajeunesse is a pioneer in the field of virtual reality filmmaking, and their work has helped to shape the medium in its early years. Félix is one of the most respected VR filmmakers working today, and their studio is at the forefront of the industry.

Félix Lajeunesse attended Concordia University, where they studied cinematography and film/video production.

Location

Montréal, Canada

Links

[](https://www.linkedin.com/in/felix-lajeunesse-38b04219/ "View on linkedIn")

* * *

Org chart
---------

1

![Image 3: Félix Lajeunesse's profile picture](https://cdn.theorg.com/a0e2b958-df98-4ce3-ba33-f51c4c0bde1b_thumb.jpg)

Félix Lajeunesse

Co-Founder & Creative Director

No direct reports

* * *

Teams
-----

### Leadership Team

4 people, 0 jobs

### Marketing and Communications Team

4 people, 0 jobs

* * *

Offices
-------

This person is not in any offices

* * *

Related people
--------------

*   [![Image 4: Cesar Cabrera's profile picture](https://cdn.theorg.com/438cdd92-f188-4090-a0b4-14d978d79181_thumb.jpg) ![Image 5: Company logo](https://cdn.theorg.com/446155e3-2465-45ed-b4cf-9aa6250ec5e1_thumb.jpg) ### Cesar Cabrera Spotdly](https://theorg.com/org/spotdly/org-chart/cesar-cabrera) 
*   [![Image 6: Colin Marshall's profile picture](https://cdn.theorg.com/c54a59cf-862f-4433-960d-adfe1c9b578e_thumb.jpg) ![Image 7: Company logo](https://cdn.theorg.com/87c6b64d-5b89-407f-ba37-0a4f9b262cfd_thumb.jpg) ### Colin Marshall Your Story Agency](https://theorg.com/org/your-story-agency/org-chart/colin-marshall) 
*   [![Image 8: Danielle Casey's profile picture](https://cdn.theorg.com/e3436838-41f8-4f47-a46a-7f6528bdf1ed_thumb.jpg) ![Image 9: Company logo](https://cdn.theorg.com/eacaa3b8-a996-4f2c-9f18-e1cc2459d32a_thumb.jpg) ### Danielle Casey 1909](https://theorg.com/org/1909/org-chart/danielle-casey) 
*   [![Image 10: Anne Gillyard's profile picture](https://cdn.theorg.com/d4e70f82-5681-4bbd-a288-5732bb8e780e_thumb.jpg) ![Image 11: Company logo](https://cdn.theorg.com/2571247f-4df8-4514-b88a-4334ab0daede_thumb.jpg) ### Anne Gillyard grOH! Playrooms](https://theorg.com/org/groh-playrooms/org-chart/anne-gillyard) 
*   [![Image 12: Adam Groves' profile picture](https://cdn.theorg.com/290fdc02-af59-416e-a447-9cac7a02cec2_thumb.jpg) ![Image 13: Company logo](https://cdn.theorg.com/c66dba50-fb8e-4321-95a9-70da0bfa419a_thumb.jpg) ### Adam Groves MODERN ARTS](https://theorg.com/org/modern-arts/org-chart/adam-groves) 

View more

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https

*[... truncated, 177 more characters]*

---

### How Felix & Paul Studios Enhance Virtual Reality Instead of Replacing it
*1,052 words* | Source: **GOOGLE** | [Link](https://www.moviemaker.com/felix-and-paul-enhance-real-life/)

Some people think of virtual reality as an escape from actual reality. But helping you escape reality is the opposite of what Felix Lajeunesse and Paul Raphaël hope to do through their immersive virtual reality company, Felix & Paul Studios.

The Emmy-winning Montreal-based studio takes audiences to places they might otherwise never go — to the International Space Station, inside the Oval Office, even back in time. Rather than distracting people from real life, they want to instill a sense of presence that can help us expand our consciousness.

“How do we evolve our consciousness as humans in the real world? We go out and we have experiences,” says Lajeunesse. “We read books, we meet people, we travel, we question ourselves. We engage our minds in the real world. That is how we progress — because we’re curious, we explore, right? That is how we progress as individuals and as a civilization.

“Virtual reality wants to help with that. Virtual reality wants to be able to engage your mind into not just passive storytelling, where you receive something, but to actually live an experience, empathizing with the characters… activating your mind in a deeper way, being affected in a deeper way, in order to move your consciousness forward.”

In a new eight-episode series, [“Inside Felix & Paul Studios,”](https://www.youtube.com/watch?v=RIlAHMXrmHc&list=PLrgNJiDpkRKaQtwSItzSwudeW-Nr7XWg5) they and their team show you the astonishing lengths they go to in order to bring audiences a sense of presence in once-unreachable destinations. One episode, for example, details the process of recording and replicating the sounds of the International Space Station.

The series, which you can stream on Meta Quest or YouTube, uses 180-degree stereoscopic video to provide a sense of depth and three-dimensional space. It is presented by Canon and shot using Canon’s RF5.2mm F2.8 L Dual Fisheye lens and the EOS R5 C camera.

_Inside Felix & Paul._

The Felix & Paul Social Experience
----------------------------------

As much as Lajeunesse and Raphaël love cinema, Lajeunesse notes that it is “an abstraction of reality — just like painting is an abstraction of reality.”

“But virtual reality is different,” he explains. “Virtual reality has the pretension, or the goal, to try to _emulate_ reality, in a sense.”

He adds: “It’s not about escaping, it’s about _enriching_ your experience of the real world. We’re just not interested in escapism, in general. … The focus is better engaging with the world you know, not getting away from it.”

Raphaël notes that many people already escape reality by “staring at a tiny little rectangle for the larger part of their day. Sometimes it’s a larger rectangle in their living room, or on their desk.” He likens these to “inferior simulations of reality.”

Listen to our full interview with Felix & Paul Studios founders Felix Lajeunesse and Paul Raphaël on [Apple](https://podcasts.apple.com/us/podcast/moviemaker/id1487350721) or [Spotify](https://open.spotify.com/show/1LPuyCknbjhvByRPS5OamA) or here:

Lajeunesse and Raphaël first crossed paths when they were a year apart at Montreal’s Concordia University, where both studied film production, had friends in common, and admired each other’s work. After graduation, they sometimes found themselves competing at film festivals. When they each received the opportunity to pitch on a music video — a 2003 production for the electronic musician Akido — they decided to join forces.

“It was the first gig for both of us— we were just coming out of school and we both needed the gig. So instead of fighting for bread crumbs, we decided to try to do it together,” Lajeunesse recalls. “And it turns out that it was a lot of fun. We immediately connected on a human level and on a creative level, but also in terms of like, what he was good at and what I was good at, which was not the same. And we just started working together and became friends.”

They became interested in more and more immersive cinematic experiences, and in 2014 Felix & Paul debuted their VR experience, _Strangers With Patrick Watson_, at South by Southwest.

“It was a one-on-one with a musician writing music in his studio, at the piano, just writing music with cameras there. It’s one shot, it’s one moment with him and his dog,” says Lajeunesse. “It’s so simple and down to earth. But the point was to try to create a full sense of presence, to try to make people feel like they’re just present with this person, and that they can start to feel the humanity and the presence of the person and they can start to feel their own presence in that space.”

**Also Read:**[Making a Movie? Moviemaker Production Services Can Cut Your Costs](https://www.moviemaker.com/mmps)

Soon Felix & Paul moved on to ever-more ambitious projects, including 2016’s _Nomads_, about the lives of nomadic people in Mongolia, Kenya, and Borneo; 2017’s _The People’s House: Inside the White House With Barack and Michelle Obama_; 2019’s _Traveling Whil

*[... truncated, 1,569 more characters]*

---

### The ISS Experience” – Voices of VR Podcast
*10,873 words* | Source: **GOOGLE** | [Link](https://voicesofvr.com/1029-breathtaking-vr-shots-from-space-in-latest-episode-of-felix-pauls-emmy-winning-space-explorers-the-iss-experience/)

Felix & Paul Studios just released Episode #3 of their [_Space Explorers: ISS Experience_](https://www.oculus.com/experiences/quest/3006696236087408/), which features some absolutely stunning & breathtaking shots captured outside of the International Space Station. They gave a sneak peak of some of this footage at the end of Meta’s Connect 2021, and some of those shots are included in Episode #3 titled “Unity,” and there will be more space walk footage included within Episode #4 launching later in 2022. In October, [they also released a 7-minute montage of clips called _Home Planet_](https://twitter.com/kentbye/status/1453496815098105856) shot from the ISS Cupola Observation Module of the ISS view of the Earth. So in total there’s over 100 minutes of really compelling documentary footage that gives a visceral sense of what life on the ISS is like through the stories and phenomenological experiences shared by astronauts.

![Image 1: felix-and-paul](http://voicesofvr.com/wp-content/uploads/2021/12/felix-and-paul-150x150.jpg.webp)

 Felix Lajeunesse & Paul Raphaël won a [2021 Emmy for Outstanding Interactive Program for the first two episodes of _Space Explorers: ISS Experience_,](https://www.emmys.com/awards/nominees-winners/2021/outstanding-interactive-program) and I had a chance to speak to them after the premiere of the 2nd episode at SXSW in March 2021. This series represents a culmination of everything they’ve learned both technically and the perspective of immersive storytelling as it’s some of the most compelling and engaging 360 video content that I’ve seen so far. We talked about building trust with NASA over many years, how they had to plan out story arcs over 6-month missions, the technical challenges of shooting 360 VR video in space, and the themes of diversity as they shot the first-ever, all-woman space walk.

Felix & Paul have also been experimenting with taking the 360-degree panoramic video shot in Space and creating television, IMAX, dome, and large-scale, location-based entertainment experiences — specifically _[The Infinite,](https://theinfiniteexperience.world/)_ which just recently opened up in Houston, Texas on December 20th.

The [_Space Explorers: ISS Experience_](https://www.oculus.com/experiences/quest/3006696236087408/) is one of the more amazing 360 videos produced up to this point, and releasing a new episode just in time as VR gets a new batch of users from the holiday season.

**LISTEN TO THIS EPISODE OF THE VOICES OF VR PODCAST**

### _This is a listener-supported podcast through the [Voices of VR Patreon.](https://www.patreon.com/voicesofvr)_

Music: [Fatality](http://ccmixter.org/files/Tigoolio/45377)

Rough Transcript
----------------

[00:00:05.412] **Kent Bye:** The Voices of VR Podcast. Hello, my name is Kent Bye, and welcome to the Wists of VR podcast. So a brand new episode of the Felix and Paul's Space Explorers, the ISS Experience, just dropped, and it's got some really stunning and amazing shots. They're taking the camera outside of the International Space Station for the first time to be able to share some of the different shots that they've been collecting over the last number of years in their collaboration of sending up this camera onto the International Space Station. So this is a four episode series and the episode 3 unite just dropped today on Wednesday December 22nd 2021 I first saw it I think back earlier this year at either South by Southwest I may have seen the earlier episode but at South by Southwest I was able to see advance and adjust the first two episodes and I did an interview them back in March of 2021 and At the MetaConnect 2021, they were premiering a new episode, which is an extra home planet episode that has shots from the cupola. You're able to look out what's essentially a framed version of what the Earth looks like, as the view of what the astronauts would look at. It's kind of the observation area to look at the Earth as you go around the Earth. They have about a seven-minute clip of different shots from the cupola. Then Unite starts to show some shots that are just absolutely breathtaking, where you see the sunset at the very beginning, and you see some shots out on the arm shot out in space. I'm looking forward to Episode 4, because I think there's going to be more shots that they previewed at the live event at the end of Connect 2021 to show some of the different shots that they've been collecting. Just absolutely incredible. In fact, when I did this conversation with them in March, I was like, I want to see those shots. And having seen them now, They are just one of the more amazing immersive experiences that I've had and the storytelling within the space explorers is also quite exquisite in fact Felix and Paul won another Emmy Award at the 7th or Emmy Awards for the outstanding interactive program So it's an Emmy awarding program that was produced in collaboration with Felix and Paul studios and time studios So definitely go check it

*[... truncated, 55,655 more characters]*

---

### “INTERSTELLAR ARC’s true promise lies in its ability to connect with people as intensely as real-life experiences” – Félix Lajeunesse (Felix & Paul Studios)
*4,495 words* | Source: **GOOGLE** | [Link](https://xrmust.com/xrmagazine/interstellar-arc-felix-lajeunesse/)

“_To infinity and beyond_”, as a character from a famous animated film once said. And while this phrase is often repeated, sometimes out of place, I think that today, in this particular article, it feels more fitting than ever.

“_To infinity and beyond_” is not only a theme tied to space exploration, which [INTERSTELLAR ARC](https://www.interstellararc.com/), the new work by [Felix & Paul Studios](https://www.felixandpaul.com/), explores. It also defines our imagination and its innate ability — that some people lose along the way — to picture what lies beyond our human limits and everyday experiences, taking us “_where no man has gone before_“.

With their creations and their presence in the field, Felix & Paul Studios have certainly transformed it. Yet what struck me most in my conversation with Félix Lajeunesse about the origins of INTERSTELLAR ARC was realizing how much this fictional vision is rooted in something profoundly human: the drive to explore, the urge to discover, and above all, the longing to experience emotions and wonder with the openness of a child.

It’s a concept very dear to me, and I cannot wait to see how it comes to life in this new project, when it will open its doors to the audience on October 15 at [AREA15](https://area15.com/) in Las Vegas.

> _Passengers begin their journey in the 25th century, departing from HEXO Spaceport One, located in Zone 2: The Terminals at AREA15 in Las Vegas. After boarding the INTERSTELLAR ARC, voyagers enter cryogenic sleep and awaken 262 years later as they approach exoplanet Arcadia. Passengers get to explore the vast, gravity-defying spaces of the INTERSTELLAR ARC, preparing themselves for arrival on this new world. Their journey culminates at Cosmopolis — a sprawling space city orbiting Arcadia, where humanity’s next chapter begins._
> 
> 
> [_www.interstellararc.com_](https://www.interstellararc.com/)

#### Creating space for emotion and wonder in a collective setting

FÉLIX LAJEUNESSE – I have been now focusing on creating fully immersive experiences for more than a decade, since 2012, [when Paul and I began to explore immersive storytelling](https://xrmust.com/xrmagazine/paul-raphael-felix-paul/) from within and we created our studios.

The recurring idea I always return to is that, **at its core, we are trying to recreate real life. We are attempting to design something that carries the same emotional spectrum as a real-life experience**s.

That is a massive endeavor, because when you think about what makes up real life, you think about its strangeness and its endless possibilities, but you also think about subjectivity.

Reality is filtered through a person’s mind, feelings, and emotions. It is not the same for you, for me, for Paul, or for a stranger crossing the street. We all perceive reality differently, shaped by our senses, our consciousness, our subjectivity, and the places we come from.

To simplify it, the experience of reality is essentially a subjective perception. **A subjective being perceives something open-ended, something filled with possibilities. That is, in many ways, what it feels like to exist in reality. When we create an immersive experience, what we try to preserve is precisely this sense of possibility and openness**.

If you move closer to the television while watching a film, nothing in the film changes. But if you step outside and approach your neighbor’s fence, the situation may shift: you might bump into the fence, your neighbor could react, the dog might start barking, and events would unfold in response to your actions. That is what we associate with an open-ended reality.

We want participants in our experiences to feel that almost anything could happen, and that within the experience they will find space for their imagination, their sensibility, and their subjectivity to engage with the world we have created for them.

![Image 1](https://xrmust.com/wp-content/uploads/2025/09/XRMust_InterstellarArc_BlueFox-1024x576.webp)
F. L. – From the very beginning, I have been reluctant to claim that immersive media and VR are entirely about storytelling. I have never truly believed that. At times I have used that language when speaking with a Hollywood executive or with people who need that framing to understand the medium. But **at the core, I see VR as a medium in which storytelling is certainly present, yet it is not the entirety of what is happening. It is a component, not the equation itself.**

In our work, including INTERSTELLAR ARC, we focus on creating the conditions in which emotions can emerge within the participant. We design a ritual, a story, in which the participant evolves through an unfolding experience. Everyone is exposed to the same sequence of moments, yet we do not dictate how people should feel about them.

This becomes especially powerful in a collective setting, because hundreds of people share the same ritual, the same story, the same experience, and still arrive at very different emotional res

*[... truncated, 23,154 more characters]*

---

### Felix & Paul Studios Archives - ACM SIGGRAPH Blog
*429 words* | Source: **GOOGLE** | [Link](https://blog.siggraph.org/tag/felix-paul-studios/)

Felix & Paul Studios Archives - ACM SIGGRAPH Blog

===============

*   [Contributor Toolkit](https://blog.siggraph.org/siggraph-contributor-amplification-toolkit/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

*   [Contributor Toolkit](https://blog.siggraph.org/siggraph-contributor-amplification-toolkit/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

[Join SIGGRAPH](https://www.siggraph.org/join-siggraph/)

[![Image 2](https://blog.siggraph.org/wp-content/uploads/2024/03/siggraph-blog-logo.svg)](https://blog.siggraph.org/)

*   [Categories](https://blog.siggraph.org/tag/felix-paul-studios/#)
    *   [ACM SIGGRAPH](https://blog.siggraph.org/category/acm-siggraph/)
    *   [Animation](https://blog.siggraph.org/category/animation/)
    *   [Art](https://blog.siggraph.org/category/art/)
    *   [Augmented Reality](https://blog.siggraph.org/category/augmented-reality/)
    *   [Business](https://blog.siggraph.org/category/business/)
    *   [Conferences](https://blog.siggraph.org/category/conferences/)
    *   [Data](https://blog.siggraph.org/category/data/)
    *   [Design](https://blog.siggraph.org/category/design/)
    *   [Education](https://blog.siggraph.org/category/education/)
    *   [Emerging Technologies](https://blog.siggraph.org/category/emerging-technologies/)
    *   [Film](https://blog.siggraph.org/category/film/)
    *   [Gaming](https://blog.siggraph.org/category/gaming/)
    *   [Graphics](https://blog.siggraph.org/category/graphics/)
    *   [Hardware](https://blog.siggraph.org/category/hardware/)
    *   [Industry Leaders](https://blog.siggraph.org/category/industry-leaders/)
    *   [Interactive Techniques](https://blog.siggraph.org/category/interactivetechniques/)
    *   [Mobile](https://blog.siggraph.org/category/mobile/)
    *   [Production](https://blog.siggraph.org/category/production-1/)
    *   [Programming & Scripting](https://blog.siggraph.org/category/programming-scripting/)
    *   [Real-Time](https://blog.siggraph.org/category/realtime/)
    *   [Research](https://blog.siggraph.org/category/research/)
    *   [Simulation](https://blog.siggraph.org/category/simulation/)
    *   [Software](https://blog.siggraph.org/category/software/)
    *   [Students](https://blog.siggraph.org/category/students/)
    *   [Theory](https://blog.siggraph.org/category/theory/)
    *   [Uncategorized](https://blog.siggraph.org/category/uncategorized/)
    *   [Virtual Reality](https://blog.siggraph.org/category/virtualreality/)
    *   [Visual Effects](https://blog.siggraph.org/category/visualeffects/)

*   [Join SIGGRAPH](https://www.siggraph.org/join-siggraph/)
*   [Join a Chapter](https://www.siggraph.org/join-a-chapter/)
*   [Hear From Us](https://www.siggraph.org/hear-from-us/)
*   [Contact](https://www.siggraph.org/contact-us/)

*   [Categories](https://blog.siggraph.org/tag/felix-paul-studios/#)
    *   [ACM SIGGRAPH](https://blog.siggraph.org/category/acm-siggraph/)
    *   [Animation](https://blog.siggraph.org/category/animation/)
    *   [Art](https://blog.siggraph.org/category/art/)
    *   [Augmented Reality](https://blog.siggraph.org/category/augmented-reality/)
    *   [Business](https://blog.siggraph.org/category/business/)
    *   [Conferences](https://blog.siggraph.org/category/conferences/)
    *   [Data](https://blog.siggraph.org/category/data/)
    *   [Design](https://blog.siggraph.org/category/design/)
    *   [Education](https://blog.siggraph.org/category/education/)
    *   [Emerging Technologies](https://blog.siggraph.org/category/emerging-technologies/)
    *   [Film](https://blog.siggraph.org/category/film/)
    *   [Gaming](https://blog.siggraph.org/category/gaming/)
    *   [Graphics](https://blog.siggraph.org/category/graphics/)
    *   [Hardware](https://blog.siggraph.org/category/hardware/)
    *   [Industry Leaders](https://blog.siggraph.org/category/industry-leaders/)
    *   [Interactive Techniques](https://blog.siggraph.org/category/interactivetechniques/)
    *   [Mobile](https://blog.siggraph.org/category/mobile/)
    *   [Production](https://blog.siggraph.org/category/production-1/)
    *   [Programming & Scripting](https://blog.siggraph.org/category/programming-scripting/)
    *   [Real-Time](https://blog.siggraph.org/category/realtime/)
    *   [Research](https://blog.siggraph.org/category/research/)
    *   [Simulation](https://blog.siggraph.org/category/simulation/)
    *   [Software](https://blog.siggraph.org/category/software/)
    *   [Students](https://blog.siggraph.org/category/students/)
    *   [Theory](https://blog.siggraph.org/category/theory/)
    *   [Uncategorized](https://blog.siggraph.org/category/uncategorized/)
    *   [Virtual Reality](https://blog.siggraph.org/category/virtualreality/)


*[... truncated, 3,269 more characters]*

---

### Felix & Paul Studios Leadership Guides the Company Ahead
*2,862 words* | Source: **GOOGLE** | [Link](https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/)

Felix & Paul Studios Leadership Guides the Company Ahead

===============
Felix & Paul Studios Leadership Guides the Company Ahead

===============

*   [Plus Icon Film](https://variety.com/v/film/)
*   [Plus Icon TV](https://variety.com/v/tv/)
*   [Plus Icon What To Watch](https://variety.com/what-to-watch-streaming-movies-shows-online/)
*   [Plus Icon Music](https://variety.com/v/music/)
*   [Plus Icon Docs](https://variety.com/t/documentaries-to-watch/)
*   [Plus Icon Digital & Gaming](https://variety.com/v/digital/)
*   [Plus Icon Global](https://variety.com/c/global/)
*   [Plus Icon Awards Circuit](https://variety.com/e/contenders/)
*   [Plus Icon Video](https://variety.com/videos/)
*   [Plus Icon What To Hear](https://variety.com/t/what-to-hear/)

Plus Icon Click to expand the Mega Menu

Plus Icon Click to Expand Search Input

*   [Got a Tip?](https://variety.com/tips)
*   [Newsletters](https://cloud.email.variety.com/signup/)

[Switch edition between U.S. Edition Asia Edition Global Edition](https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/#)
*   [U.S.](https://variety.com/)
*   [Asia](https://variety.com/c/asia/)
*   [Global](https://variety.com/c/global/)

[Variety](https://variety.com/)

Plus Icon Click to expand the Mega Menu

Plus Icon Click to Expand Search Input

[Variety](https://variety.com/)[Plus Icon Read Next: ‘Testament of Ann Lee’ Composer Daniel Blumberg Wrote ‘Clothed by the Sun’ on His First Attempt](https://variety.com/2025/artisans/news/testament-of-ann-lee-daniel-blumberg-clothed-by-the-sun-1236597948/)

1.   [Home](https://variety.com/)
2.   [Artisans](https://variety.com/v/artisans/)
3.   [News](https://variety.com/c/news/)

 Mar 22, 2018 8:25am PT 

Felix & Paul Studios Leaders Forge New Path
===========================================

By [Todd Longwell](https://variety.com/author/todd-longwell/)

Plus Icon

### [Todd Longwell](https://variety.com/author/todd-longwell/)

#### Latest

*   [From Cardboard Boxes to AI: Stunt Legends Share Stories, Wisdom at Round Top Film Festival](https://variety.com/2025/film/news/cardboard-boxes-ai-stunt-legends-round-top-film-festival-1236582410/) 3 weeks ago 
*   [How Business Managers Helped Stars with Lost Homes and Million-Dollar Insurance Premiums After the L.A. Fires](https://variety.com/2025/biz/news/business-managers-help-stars-million-dollar-insurance-fires-1236576019/) 4 weeks ago 
*   [How Variety Business Managers Elite Honoree Phil Sarna’s Firm Became the Money Maestros for Billie Eilish, Chappell Roan, Duran Duran and More](https://variety.com/2025/biz/news/business-managers-elite-honoree-phil-sarna-money-maestro-1236576016/) 4 weeks ago 

[See All](https://variety.com/author/todd-longwell/)

[](https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/#article-comments)

*   [](https://www.facebook.com/dialog/share?title=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path&sdk=joey&display=popup&ref=plugin&src=share_button&app_id=278816682243900&href=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/)
*   [](https://twitter.com/intent/post?url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&text=Felix%20%26%20Paul%20Studios%20Leaders%20Forge%20New%20Path&via=variety)
*   [](https://google.com/preferences/source?q=https%3A%2F%2Fvariety.com)
*   [](https://share.flipboard.com/bookmarklet/popout?v=2&url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&title=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path)
*   [](https://pinterest.com/pin/create/link/?url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&description=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path)
*   [](https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/#)
*   [](https://www.tumblr.com/widgets/share/tool/preview?shareSource=legacy&canonicalUrl&url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&posttype=link&title=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path)
*   [](https://www.reddit.com/submit?url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&title=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path)
*   [](https://www.linkedin.com/shareArticle?mini=1&url=https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/&title=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path&summary&source=variety)
*   [](whatsapp://send?text=Felix%20&%20Paul%20Studios%20Leaders%20Forge%20New%20Path%20-%20https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path

*[... truncated, 36,321 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[How Felix & Paul Studios Enhance Virtual Reality Instead of ...](https://www.moviemaker.com/felix-and-paul-enhance-real-life/)**
  - Source: moviemaker.com
  - *Feb 22, 2024 ... Felix & Paul Studios, one of the major VR businesses, want ... But helping you escape reality is the opposite of what Felix Lajeuness...*

- **[#1029: Breathtaking VR Shots from Space in Latest Episode of Felix ...](https://voicesofvr.com/1029-breathtaking-vr-shots-from-space-in-latest-episode-of-felix-pauls-emmy-winning-space-explorers-the-iss-experience/)**
  - Source: voicesofvr.com
  - *Dec 22, 2021 ... [00:02:43.735] Felix Lajeunesse: So I'm Félix Lajeunesse. I'm the co-founder and creative director of Félix & Paul Studios. I've been...*

- **[INTERSTELLAR ARC x Félix Lajeunesse (Félix & Paul Studios)](https://xrmust.com/xrmagazine/interstellar-arc-felix-lajeunesse/)**
  - Source: xrmust.com
  - *Le Podcast (FR) · About Us · LinkedIn · YouTube · X · Facebook · Instagram ... Félix Lajeunesse (Felix & Paul Studios). 2025-09-09. Agnese Pietrobon....*

- **[Felix & Paul Studios Archives - ACM SIGGRAPH Blog](https://blog.siggraph.org/tag/felix-paul-studios/)**
  - Source: blog.siggraph.org
  - *Jul 1, 2022 ... ... Félix Lajeunesse and Paul Raphaël, co-founders of ... Felix & Paul Studios, Felix Lajeunesse, immersive, Metaverse, Paul Raphael, ...*

- **[Felix & Paul Studios Leadership Guides the Company Ahead](https://variety.com/2018/artisans/news/bryan-besser-felix-paul-studios-leaders-forge-new-path-1202731969/)**
  - Source: variety.com
  - *Mar 22, 2018 ... Felix & Paul Studios Leaders Forge New Path. By Todd Longwell. Plus ... Felix Lajeunesse, Paul Raphaël Creative directors and co-foun...*

- **[The ISS Experience Brings Space to Earth](https://issnationallab.org/iss360/the-iss-experience-dream-to-virtual-reality/)**
  - Source: issnationallab.org
  - *Jun 23, 2020 ... ... Podcast,” Felix Lajeunesse and Paul Raphael, co-founders and creative directors of Felix & Paul Studios, discuss their work on “T...*

- **[Felix & Paul Studios Launches VR Space Experience](https://variety.com/2023/biz/tech/felix-amp-paul-studios-launches-vr-experience-space-explorers-apollo-to-artemis-for-space-day-nasa-1235604301/)**
  - Source: variety.com
  - *May 5, 2023 ... Felix & Paul Studios launches "Space Explorers - Apollo to ... Felix Lajeunesse and Chief Innovation Officer Paul Raphaël. “Gene ......*

- **[Felix & Paul Studios partners with Oculus for production deal | BetaKit](https://betakit.com/felix-paul-studios-partnering-with-oculus-for-multi-project-production-deal/)**
  - Source: betakit.com
  - *Jul 20, 2015 ... Podcast · Newsletter · Quiz · Jobs. Felix & Paul Studios partnering ... Felix Lajeunesse, co-founder of Felix & Paul Studios. “Our st...*

- **[Cinema And The Digital World |](https://theconcordian.com/2018/02/cinema-digital-world/)**
  - Source: theconcordian.com
  - *Feb 27, 2018 ... A portrait of Félix Lajeunesse, the co-founder of the world-renowned virtual reality company Felix & Paul Studios. ... Podcast episod...*

- **[Oculus Connect 3: Cirque du Soleil, Felix & Paul Producing New ...](https://www.hollywoodreporter.com/movies/movie-news/oculus-connect-3-cirque-du-935682/)**
  - Source: hollywoodreporter.com
  - *Oct 6, 2016 ... Both are created with Felix & Paul Studios, based on the Las Vegas Shows ... Felix Lajeunesse and Paul Raphael. “It's a gravity-defyin...*

---

*Generated by Founder Scraper*
