# Patricia Rimok

## Position actuelle

**Titre** : Author/Founder
**Entreprise** : Heart2Hearts.ca
**Durée dans le rôle** : 2 years 4 months in role
**Durée dans l'entreprise** : 2 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Author of HeartConomics: The Business Edge You Didn't Expect.

HeartConomics is a transformative approach to business that introduces love and kindness as core drivers for productivity, retention, and stakeholder success. In today’s fast-evolving world, sustainable growth hinges on values-driven strategies that foster genuine connection, trust, and well-being within organizations.

As the author of HeartConomics, I consult with companies and government entities on applying the HeartConomics Framework to enhance productivity and employee satisfaction across all levels. By centering love and kindness in decision-making and leadership practices, we unlock unprecedented workforce engagement, innovation, and resilience.

Learn more about the HeartConomics Framework to explore how a heart-centered approach can elevate your organization’s impact by reaching out.

## Résumé

Author | Communications Strategist | Founder of HeartConomics |  Advocate for Ethical and Compassionate Leadership

I help organizations and governments lead with heart, proving that empathy, kindness, and emotional intelligence are powerful drivers of loyalty, performance, and sustainable success.

As the author of HeartConomics: The Business Edge You Didn’t Expect, I champion a leadership framework that centers relationships at the core of decision-making and results, reimagining what success can look like across sectors.

A dedicated advocate for social impact and ethical leadership, I want to collaborate with Fortune 500 companies, governments, and nonprofits to rewire how we measure growth, placing people and human connection at the heart.

When not writing or consulting, I engage with communities to advance the HeartConomics movement and leverage value-added partnerships in sustainable sectors such as waste-to-energy and smart agriculture through my ib2ib Global Network of Partners.

Let’s connect if you’re ready to lead with strength, ethics, and heart!

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAgHGcBvBbdrtI-D4yF2d6mMUtr7K2tobg/
**Connexions partagées** : 17


---

# Patricia Rimok

## Position actuelle

**Entreprise** : Heart2Hearts.ca

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Patricia Rimok

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402015729799020544 | Text |  |  | What if loss whether of a loved one, a job you loved, or a relationship doesn’t just leave an empty space? What if it also opens a door to deeper resilience, new meaning, and a chance to rebuild stronger?

This powerful TedTalk video moved me, not just because of the pain of loss, but because it shows how the human heart, at its most wounded, can find a way to heal, to fill that void with new hope and ultimately, new joy.

https://lnkd.in/dr4mWVYa

In grief, trauma, or sudden change, our emotional landscape is shaken. But when we give ourselves and each other  permission to feel, to express our grief, to acknowledge despair... we open the possibility for transformation.

That’s why in HeartConomics we emphasize emotional literacy. We use tools like Plutchik’s Wheel of Emotions to help individuals and teams name what they feel whether sorrow, fear, anger, or hope and to recognize that every emotion, even painfully intense ones, has purpose and meaning. 

Because when we decode our feelings  when we truly see them, we give ourselves the clarity to heal, to grow, to reconnect. And from that place of clarity, come empathy, compassion, renewed purpose.

That kind of healing isn’t just personal. It’s relational. It’s social. It can ripple out into our workplaces, our communities, and even the culture of entire organizations.

If grief and loss remind us of what’s fragile … maybe they also invite us to rebuild what’s possible.

I’d love to hear from you.  Have you ever experienced loss that forced you to rethink, rebuild, or rediscover yourself? How did naming your emotions help you move through that journey? | 1 | 0 | 6 | 4d | Post | Patricia Rimok | https://www.linkedin.com/in/patricia-rimok-a07855 | https://linkedin.com/in/patricia-rimok-a07855 | 2025-12-08T04:48:33.271Z |  | 2025-12-03T16:07:52.786Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401798573883039744 | Text |  |  | Many employees who lose their jobs after burnout or emotional overload believe they’re alone — but the data tells a very different story. This article explores a human-centered, structured approach to rebuilding trust after a breakdown impacts performance. It includes a practical roadmap, a call to rethink how we view emotional safety at work, and clear steps for employers and employees to repair trust. If your group is interested in mental health, leadership, resilience, or healthier workplace cultures, this conversation may open important doors. | 1 | 0 | 0 | 5d | Post | Patricia Rimok | https://www.linkedin.com/in/patricia-rimok-a07855 | https://linkedin.com/in/patricia-rimok-a07855 | 2025-12-08T04:48:33.277Z |  | 2025-12-03T01:44:58.781Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400216842138558464 | Text |  |  | This act of clemency reminds us that beyond the letter of the law lies the heart of justice. When courts combine procedural fairness with compassion and respect for dignity, they open the door not only to mercy — but to real restoration, social reintegration, and a second chance at life. 

https://lnkd.in/ePxiTJPE

Research on therapeutic jurisprudence and restorative justice shows that such humane approaches can lead to lower recidivism, greater accountability, and renewed hope. 

In a world where rules alone don’t always heal — compassion may be the most powerful catalyst for transformation. That’s exactly what we mean when we bring the principles of HeartConomics into justice, communities and organizations. | 0 | 0 | 0 | 1w | Post | Patricia Rimok | https://www.linkedin.com/in/patricia-rimok-a07855 | https://linkedin.com/in/patricia-rimok-a07855 | 2025-12-08T04:48:33.278Z |  | 2025-11-28T16:59:44.546Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399532680142356480 | Text |  |  | In today’s workplace, we talk a lot about KPIs — but emerging neuroscience is revealing a new one we can’t ignore: how the brain is wired.
 When teams practice gratitude, empathy, and recognition, the brain responds in ways that strengthen emotional balance, connection, and resilience.
 I’m sharing this post because it aligns deeply with HeartConomics and our mission to build workplaces rooted in dignity, kindness, and human performance. 
Would love to hear how your organizations are integrating these practices. | 1 | 1 | 0 | 1w | Post | Patricia Rimok | https://www.linkedin.com/in/patricia-rimok-a07855 | https://linkedin.com/in/patricia-rimok-a07855 | 2025-12-08T04:48:33.284Z |  | 2025-11-26T19:41:07.615Z |  |  | 

---



---

# Patricia Rimok
*Heart2Hearts.ca*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Write Your Way to the Life You Want](https://writers.work/patrimok)
*2025-01-01*
- Category: article

### [Patricia Rimok (rimok) - Profile | Pinterest](https://in.pinterest.com/rimok/)
*2021-10-21*
- Category: article

### [Coaching with the Heart in Mind: What We Do & Why](https://www.heartrich.ca/coaching-with-the-heart-in-mind/)
*2024-11-04*
- Category: article

### [Why Heart Matters - in Life, Love and Leadership](https://www.heartrich.ca/why-heart-matters/)
*2024-11-05*
- Category: article

### [HEARTS Global Network | LinkedIn](https://ca.linkedin.com/company/heartsglobalnetwork)
*2025-04-28*
- Category: article

---

## 📖 Full Content (Scraped)

*7 articles scraped, 13,973 words total*

### Write Your Way to the Life You Want
*4,669 words* | Source: **EXA** | [Link](https://writers.work/patrimok)

Thank you for using the Writers Work LLC website (accessible at Writers.work hereinafter, the 'Website'). This page states the terms and conditions ('Terms of Service') under which you may use the Website and any materials, online communications and other information that is or becomes available on the Website.

By accessing the Website you accept and agree to be bound, without limitation or qualification by these terms and conditions. By entering your email or credit card information, you’ve officially “signed” the Terms of Service. If you sign up to Writers.work on behalf of a company or another entity, you represent and warrant that you have the authority to accept these terms of their behalf. If you do not accept any of the terms or conditions stated here, please do not use the Website.

Agreement Between You & Writers Work LLC

The Website is owned and operated by Writers Work LLC, a limited liability corporation located in Austin, TX (hereinafter 'Writers.work') and is offered to you conditioned on your acceptance without modification of the terms, conditions, disclaimers and notices contained herein. Use of the content, services, and/or products presented in any or all areas of this site constitutes your agreement that you will not use the Website for any unlawful purpose and that you will abide by these Terms of Service and those posted in specific areas of the site. In addition, when using particular Writers.work owned or operated services, you shall be subject to any posted guidelines or rules applicable to such services, which may be posted and modified from time to time. All such guidelines or rules (including but not limited to our Earnings Disclaimer) are hereby incorporated by reference into these Terms of Service.

This agreement between you and Writers.work may be terminated by Writers.work at any time, with prior notice. Please note that Writers.work reserves the right to change the Terms of Service under which this Website and its offerings are extended to you. Any such change shall be effective upon notice, which may be given by Writers.work posting such change on the Website, by e-mail, or any other reasonable way. All modifications to this Terms of Service webpage shall be deemed a posting for purposes of notice. If a change is notified by a posting on the Website, it shall be deemed to take effect when posted; if a change is notified by e-mail, it shall be deemed to take effect when the e-mail is sent; and if a modification is notified in any other way, it shall be deemed to take effect when the relevant notice is sent or issued by or on behalf of Writers.work. Your continued use of the Website following notice of such modifications will be conclusively deemed acceptance of any changes to these Terms of Service. You agree that notice of changes to these Terms of Service on the Website, by posting, such as modification of this Terms of Service webpage, or delivered by email, or provided in any other reasonable way constitutes reasonable and sufficient notice.

Collection & Use of Information by Writers.work

Writers.work collects personal information when you use Writers.work products or services, when you register with Writers.work, and when you visit Writers.work web pages or the web pages of Writers.work partners. Writers.work may combine the information that we have with information we obtain from business partners or other companies.

Texas Law and Venue

These Terms of Service will be interpreted and governed by the domestic laws of the State of Texas, without giving effect to any choice of law or conflict of law provision or rule that would cause the application of the laws of any jurisdiction other than the State of Texas. By using this Website you expressly agree, acknowledge and consent to personal jurisdiction in the State of Texas and that venue for any dispute between you and Writers.work relating to your use of the Website, the Terms of Service, or any other dispute relating to the Website shall be exclusively in the state and federal courts located in Austin, TX.

Restrictions

Writers.work expends significant time and expense gathering, preparing, compiling and developing the data and other information and content provided on the Writers.work Website. Consequently, data scraping, website scraping, screen scraping, and all other forms of automated and/or manual data and content mining are expressly prohibited and you agree not use any of the data, information, or content on the Website except as expressly permitted by these Terms of Service. You further warrant that you will not attempt or actually systematically extract data contained in this Website to populate databases for internal or external use.

License

These Terms of Service provide you with a personal, revocable, nonexclusive, nontransferable license to use this Website, conditioned on your continued compliance with these Terms of Service. You may print and download materials and information on this Website so

*[... truncated, 25,528 more characters]*

---

### Patricia Rimok (rimok) - Profile | Pinterest
*280 words* | Source: **EXA** | [Link](https://in.pinterest.com/rimok/)

[Skip to content](https://in.pinterest.com/rimok/#)

When autocomplete results are available use up and down arrows to review and enter to select. Touch device users, explore by touch or with swipe gestures.

Log in

Sign up

[](https://in.pinterest.com/)

[](https://in.pinterest.com/ideas)

[](https://in.pinterest.com/shopping)

Patricia Rimok
==============

rimok

Follow

[Created](https://in.pinterest.com/rimok/_created)[Saved](https://in.pinterest.com/rimok/_saved)

[![Image 1](https://i.pinimg.com/236x/17/0e/d3/170ed3e864a09908052a93da0427bf2d.jpg) ![Image 2](https://i.pinimg.com/170x/af/82/6f/af826f163f189809ef7acf42400669ca.jpg) Grilled chicken marinade ------------------------ , 2 Pins · , 4y](https://in.pinterest.com/rimok/grilled-chicken-marinade/)

[![Image 3](https://i.pinimg.com/236x/49/76/5f/49765ff6b8221a24b0bd5abb9d33ba6e.jpg) ![Image 4](https://i.pinimg.com/170x/68/9e/0d/689e0d0e1628d353a367830b14d49207.jpg) ![Image 5](https://i.pinimg.com/170x/4e/34/30/4e34309a8d82236a5662ced33b5bd8b3.jpg) Médecine douce -------------- , 14 Pins · , 9y](https://in.pinterest.com/rimok/m%c3%a9decine-douce/)

[![Image 6](https://i.pinimg.com/236x/b7/5d/0d/b75d0d2a8d4488ec5f7fd6c98e944258.jpg) ![Image 7](https://i.pinimg.com/170x/9b/53/26/9b5326e4fd6d016de85bae826ccdd5cc.jpg) ![Image 8](https://i.pinimg.com/170x/09/47/92/0947924adc901537a9f378ec60abdb86.jpg) santé globale, médecine alternative, spiritualisme, ésotérisme, magie --------------------------------------------------------------------- , 11 Pins · , 10y](https://in.pinterest.com/rimok/sant%c3%a9-globale-m%c3%a9decine-alternative-spiritualisme-%c3%a9/)

More ideas from Patricia Rimok
------------------------------

[![Image 9: This may contain: the ultimate guide to how to cook chicken marinade in minutes or less with this recipe](https://i.pinimg.com/videos/thumbnails/originals/8f/59/d1/8f59d116698f50f99ab0e1797f2020fd.0000000.jpg)](https://in.pinterest.com/pin/556616835204470747/)

1:20

[Smoked Chicken Marinade Recipe](https://in.pinterest.com/ideas/smoked-chicken-marinade-recipe/919535536544/)

[Smoked Chicken Marinade](https://in.pinterest.com/ideas/smoked-chicken-marinade/934894173262/)

[The Best Chicken Marinade](https://in.pinterest.com/ideas/the-best-chicken-marinade/933740611528/)

[Chicken Leg Marinade For The Grill](https://in.pinterest.com/ideas/chicken-leg-marinade-for-the-grill/933480869626/)

[How To Marinate Chicken](https://in.pinterest.com/ideas/how-to-marinate-chicken/902422948236/)

[Chicken Wing Marinade For The Grill](https://in.pinterest.com/ideas/chicken-wing-marinade-for-the-grill/909711095160/)

[Chicken Leg Marinade](https://in.pinterest.com/ideas/chicken-leg-marinade/895715715564/)

[Marinade For Chicken On The Grill](https://in.pinterest.com/ideas/marinade-for-chicken-on-the-grill/948986582391/)

[Chicken Marinade Baked](https://in.pinterest.com/ideas/chicken-marinade-baked/953490543870/)

[](https://in.pinterest.com/pin/556616835204470747/)

[![Image 10](https://i.pinimg.com/236x/af/82/6f/af826f163f189809ef7acf42400669ca.jpg)](https://in.pinterest.com/pin/556616835203911779/)

[Chicken Burger Marinade](https://in.pinterest.com/ideas/chicken-burger-marinade/933180514309/)

[All Star Chicken Marinade](https://in.pinterest.com/ideas/all-star-chicken-marinade/944903720656/)

[Marinade For Grilled Chicken Thighs](https://in.pinterest.com/ideas/marinade-for-grilled-chicken-thighs/897960985684/)

[Chicken Sandwich Marinade](https://in.pinterest.com/ideas/chicken-sandwich-marinade/918349318501/)

[Marinade For Chicken Sandwiches](https://in.pinterest.com/ideas/marinade-for-chicken-sandwiches/926608807622/)

[Grilled Chicken Sandwich Marinade](https://in.pinterest.com/ideas/grilled-chicken-sandwich-marinade/933717437468/)

[Chicken Thigh Marinade For The Grill](https://in.pinterest.com/ideas/chicken-thigh-marinade-for-the-grill/894735152490/)

[Killer Chicken Thigh Marinade Recipe](https://in.pinterest.com/ideas/killer-chicken-thigh-marinade-recipe/897730733267/)

[Quick Grilled Chicken Marinade](https://in.pinterest.com/ideas/quick-grilled-chicken-marinade/945712098276/)

[](https://in.pinterest.com/pin/556616835203911779/)

[![Image 11](https://i.pinimg.com/236x/a9/a0/65/a9a0658b457bb297f890eca747349ff8.jpg)](https://in.pinterest.com/pin/556616835178501664/)

[Body Health](https://in.pinterest.com/ideas/body-health/951906855381/)

[Herbal Remedies](https://in.pinterest.com/ideas/herbal-remedies/947560429307/)

[Health Tips](https://in.pinterest.com/ideas/health-tips/908753449504/)

[Massage](https://in.pinterest.com/ideas/massage/916932742155/)

[Meditation](https://in.pinterest.com/ideas/meditation/950957470346/)

[Health Care](https://in.pinterest.com/ideas/health-care/945484429093/)

[Essential Oils](https://in.pinterest.com/ideas/essential-oils/961952774867/)

[Medical](https://in.pinterest.com/ideas/medical/912753135383/)

[Health](https://in.pinterest.com/ideas/health/898620064290/)

[](https://in.pinterest.com/pin/5566

*[... truncated, 1,350 more characters]*

---

### Coaching with the Heart in Mind: What We Do & Why
*1,920 words* | Source: **EXA** | [Link](https://www.heartrich.ca/coaching-with-the-heart-in-mind/)

Coaching with the Heart in Mind: What We Do & Why

===============

[![Image 2: HeartRich Coaching](https://www.heartrich.ca/wp-content/uploads/2024/11/heartrich-newheart-logo-banner-300w.jpg)](https://www.heartrich.ca/)

*   [Home](https://www.heartrich.ca/)
*   [Coaching](https://www.heartrich.ca/self-leadership-coaching)
    *   [Self Leadership Coach](https://www.heartrich.ca/self-leadership-coaching/)
    *   [Executive Coach](https://www.heartrich.ca/executive-coach/)
    *   [Whole Life Coach](https://www.heartrich.ca/life-coach-self-growth)
    *   [Heart Centered Solutions Coach](https://www.heartrich.ca/heart-centered-solutions-coaching)
    *   [Inner Critic Coach](https://www.heartrich.ca/inner-critic-coaching/)

*   [Resilience](https://www.heartrich.ca/resilience-fundamentals)
    *   [HeartRich Resilience Fundamentals](https://www.heartrich.ca/resilience-fundamentals/)
    *   [HeartMath for Leaders](https://www.heartrich.ca/heartmath-training-for-leaders-executives/)

*   [Blog](https://www.heartrich.ca/blog)
*   [Get to Know](https://www.heartrich.ca/coaching-with-the-heart-in-mind/#)
    *   [HeartRich Vision & Mission](https://www.heartrich.ca/about-us)
    *   [Coaching with the Heart in Mind](https://www.heartrich.ca/coaching-with-the-heart-in-mind)
    *   [Why Heart Matters](https://www.heartrich.ca/why-heart-matters)
    *   [The Hero’s Journey](https://www.heartrich.ca/the-heros-journey/)

*   [Learn More](https://www.heartrich.ca/coaching-with-the-heart-in-mind/#)
    *   [Trauma-Responsive Coaching Manifesto](https://www.heartrich.ca/trauma-responsive-coaching/)
    *   [Inner Leadership Skills](https://www.heartrich.ca/inner-leadership-skills/)
    *   [Managing Your Inner World](https://www.heartrich.ca/inner-world-tools/)
    *   [Coaching with Anxiety & Depression](https://www.heartrich.ca/coaching-with-anxiety-depression/)
    *   [Helpful Resources](https://www.heartrich.ca/helpful-resources/)
        *   [RIP NOTES](https://www.heartrich.ca/ripnotes/)

*   [Reviews](https://www.heartrich.ca/reviews)
*   [Let’s Talk](https://www.heartrich.ca/consult)
    *   [Coaching Exploration Sessions](https://www.heartrich.ca/consult/)
    *   [Contact](https://www.heartrich.ca/contact/)

*   [Shop](https://www.heartrich.ca/theshop/)
    *   [How to Talk Amongst Your Selves](https://www.heartrich.ca/product/how-to-talk-amongst-your-selves/)
    *   [The Heart of Values](https://www.heartrich.ca/product/the-heart-of-values/)

[](https://www.heartrich.ca/cart/)

Select Page
*   [Home](https://www.heartrich.ca/)
*   [Coaching](https://www.heartrich.ca/self-leadership-coaching)
    *   [Self Leadership Coach](https://www.heartrich.ca/self-leadership-coaching/)
    *   [Executive Coach](https://www.heartrich.ca/executive-coach/)
    *   [Whole Life Coach](https://www.heartrich.ca/life-coach-self-growth)
    *   [Heart Centered Solutions Coach](https://www.heartrich.ca/heart-centered-solutions-coaching)
    *   [Inner Critic Coach](https://www.heartrich.ca/inner-critic-coaching/)

*   [Resilience](https://www.heartrich.ca/resilience-fundamentals)
    *   [HeartRich Resilience Fundamentals](https://www.heartrich.ca/resilience-fundamentals/)
    *   [HeartMath for Leaders](https://www.heartrich.ca/heartmath-training-for-leaders-executives/)

*   [Blog](https://www.heartrich.ca/blog)
*   [Get to Know](https://www.heartrich.ca/coaching-with-the-heart-in-mind/#)
    *   [HeartRich Vision & Mission](https://www.heartrich.ca/about-us)
    *   [Coaching with the Heart in Mind](https://www.heartrich.ca/coaching-with-the-heart-in-mind)
    *   [Why Heart Matters](https://www.heartrich.ca/why-heart-matters)
    *   [The Hero’s Journey](https://www.heartrich.ca/the-heros-journey/)

*   [Learn More](https://www.heartrich.ca/coaching-with-the-heart-in-mind/#)
    *   [Trauma-Responsive Coaching Manifesto](https://www.heartrich.ca/trauma-responsive-coaching/)
    *   [Inner Leadership Skills](https://www.heartrich.ca/inner-leadership-skills/)
    *   [Managing Your Inner World](https://www.heartrich.ca/inner-world-tools/)
    *   [Coaching with Anxiety & Depression](https://www.heartrich.ca/coaching-with-anxiety-depression/)
    *   [Helpful Resources](https://www.heartrich.ca/helpful-resources/)
        *   [RIP NOTES](https://www.heartrich.ca/ripnotes/)

*   [Reviews](https://www.heartrich.ca/reviews)
*   [Let’s Talk](https://www.heartrich.ca/consult)
    *   [Coaching Exploration Sessions](https://www.heartrich.ca/consult/)
    *   [Contact](https://www.heartrich.ca/contact/)

*   [Shop](https://www.heartrich.ca/theshop/)
    *   [How to Talk Amongst Your Selves](https://www.heartrich.ca/product/how-to-talk-amongst-your-selves/)
    *   [The Heart of Values](https://www.heartrich.ca/product/the-heart-of-values/)

Coaching With The Heart In Mind
-------------------------------

### What We Do & Why We Do It

**Bringing Heart to Life & Leadership**
=======================================

### **Coaching wi

*[... truncated, 14,621 more characters]*

---

### Why Heart Matters - in Life, Love and Leadership
*1,960 words* | Source: **EXA** | [Link](https://www.heartrich.ca/why-heart-matters/)

Why Heart Matters - in Life, Love and Leadership

===============

[![Image 2: HeartRich Coaching](https://www.heartrich.ca/wp-content/uploads/2024/11/heartrich-newheart-logo-banner-300w.jpg)](https://www.heartrich.ca/)

*   [Home](https://www.heartrich.ca/)
*   [Coaching](https://www.heartrich.ca/self-leadership-coaching)
    *   [Self Leadership Coach](https://www.heartrich.ca/self-leadership-coaching/)
    *   [Executive Coach](https://www.heartrich.ca/executive-coach/)
    *   [Whole Life Coach](https://www.heartrich.ca/life-coach-self-growth)
    *   [Heart Centered Solutions Coach](https://www.heartrich.ca/heart-centered-solutions-coaching)
    *   [Inner Critic Coach](https://www.heartrich.ca/inner-critic-coaching/)

*   [Resilience](https://www.heartrich.ca/resilience-fundamentals)
    *   [HeartRich Resilience Fundamentals](https://www.heartrich.ca/resilience-fundamentals/)
    *   [HeartMath for Leaders](https://www.heartrich.ca/heartmath-training-for-leaders-executives/)

*   [Blog](https://www.heartrich.ca/blog)
*   [Get to Know](https://www.heartrich.ca/why-heart-matters/#)
    *   [HeartRich Vision & Mission](https://www.heartrich.ca/about-us)
    *   [Coaching with the Heart in Mind](https://www.heartrich.ca/coaching-with-the-heart-in-mind)
    *   [Why Heart Matters](https://www.heartrich.ca/why-heart-matters)
    *   [The Hero’s Journey](https://www.heartrich.ca/the-heros-journey/)

*   [Learn More](https://www.heartrich.ca/why-heart-matters/#)
    *   [Trauma-Responsive Coaching Manifesto](https://www.heartrich.ca/trauma-responsive-coaching/)
    *   [Inner Leadership Skills](https://www.heartrich.ca/inner-leadership-skills/)
    *   [Managing Your Inner World](https://www.heartrich.ca/inner-world-tools/)
    *   [Coaching with Anxiety & Depression](https://www.heartrich.ca/coaching-with-anxiety-depression/)
    *   [Helpful Resources](https://www.heartrich.ca/helpful-resources/)
        *   [RIP NOTES](https://www.heartrich.ca/ripnotes/)

*   [Reviews](https://www.heartrich.ca/reviews)
*   [Let’s Talk](https://www.heartrich.ca/consult)
    *   [Coaching Exploration Sessions](https://www.heartrich.ca/consult/)
    *   [Contact](https://www.heartrich.ca/contact/)

*   [Shop](https://www.heartrich.ca/theshop/)
    *   [How to Talk Amongst Your Selves](https://www.heartrich.ca/product/how-to-talk-amongst-your-selves/)
    *   [The Heart of Values](https://www.heartrich.ca/product/the-heart-of-values/)

[](https://www.heartrich.ca/cart/)

Select Page
*   [Home](https://www.heartrich.ca/)
*   [Coaching](https://www.heartrich.ca/self-leadership-coaching)
    *   [Self Leadership Coach](https://www.heartrich.ca/self-leadership-coaching/)
    *   [Executive Coach](https://www.heartrich.ca/executive-coach/)
    *   [Whole Life Coach](https://www.heartrich.ca/life-coach-self-growth)
    *   [Heart Centered Solutions Coach](https://www.heartrich.ca/heart-centered-solutions-coaching)
    *   [Inner Critic Coach](https://www.heartrich.ca/inner-critic-coaching/)

*   [Resilience](https://www.heartrich.ca/resilience-fundamentals)
    *   [HeartRich Resilience Fundamentals](https://www.heartrich.ca/resilience-fundamentals/)
    *   [HeartMath for Leaders](https://www.heartrich.ca/heartmath-training-for-leaders-executives/)

*   [Blog](https://www.heartrich.ca/blog)
*   [Get to Know](https://www.heartrich.ca/why-heart-matters/#)
    *   [HeartRich Vision & Mission](https://www.heartrich.ca/about-us)
    *   [Coaching with the Heart in Mind](https://www.heartrich.ca/coaching-with-the-heart-in-mind)
    *   [Why Heart Matters](https://www.heartrich.ca/why-heart-matters)
    *   [The Hero’s Journey](https://www.heartrich.ca/the-heros-journey/)

*   [Learn More](https://www.heartrich.ca/why-heart-matters/#)
    *   [Trauma-Responsive Coaching Manifesto](https://www.heartrich.ca/trauma-responsive-coaching/)
    *   [Inner Leadership Skills](https://www.heartrich.ca/inner-leadership-skills/)
    *   [Managing Your Inner World](https://www.heartrich.ca/inner-world-tools/)
    *   [Coaching with Anxiety & Depression](https://www.heartrich.ca/coaching-with-anxiety-depression/)
    *   [Helpful Resources](https://www.heartrich.ca/helpful-resources/)
        *   [RIP NOTES](https://www.heartrich.ca/ripnotes/)

*   [Reviews](https://www.heartrich.ca/reviews)
*   [Let’s Talk](https://www.heartrich.ca/consult)
    *   [Coaching Exploration Sessions](https://www.heartrich.ca/consult/)
    *   [Contact](https://www.heartrich.ca/contact/)

*   [Shop](https://www.heartrich.ca/theshop/)
    *   [How to Talk Amongst Your Selves](https://www.heartrich.ca/product/how-to-talk-amongst-your-selves/)
    *   [The Heart of Values](https://www.heartrich.ca/product/the-heart-of-values/)

Why Heart Matters
=================

### Using Our Hearts to Speak to Our Brains to Shape Our Lives

**What does being Heart-Centered mean?**
========================================

**Being heart-centered means coming back to the heart to lead onese

*[... truncated, 15,019 more characters]*

---

### Canadian International Peace Summit (CIPS) | LinkedIn
*2,588 words* | Source: **EXA** | [Link](https://ca.linkedin.com/company/heartsglobalnetwork)

Canadian International Peace Summit (CIPS) | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/company/heartsglobalnetwork#main-content)[LinkedIn](https://ca.linkedin.com/?trk=organization_guest_nav-header-logo)
*   [Articles](https://www.linkedin.com/pulse/topics/home/?trk=organization_guest_guest_nav_menu_articles)
*   [People](https://www.linkedin.com/pub/dir/+/+?trk=organization_guest_guest_nav_menu_people)
*   [Learning](https://www.linkedin.com/learning/search?trk=organization_guest_guest_nav_menu_learning)
*   [Jobs](https://www.linkedin.com/jobs/search?trk=organization_guest_guest_nav_menu_jobs)
*   [Games](https://www.linkedin.com/games?trk=organization_guest_guest_nav_menu_games)

[Sign in](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fcanadianinternationalpeacesummit&fromSignIn=true&trk=organization_guest_nav-header-signin)[Join now](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fcanadianinternationalpeacesummit&trk=organization_guest_nav-header-join)

![Image 1: Canadian International Peace Summit (CIPS)’s cover photo](https://media.licdn.com/dms/image/v2/D4E3DAQFrI39tX1Wmqw/image-scale_191_1128/B4EZn0y8wWIUAc-/0/1760748621419/canadianinternationalpeacesummit_cover?e=2147483647&v=beta&t=OxtmSxB06FEpXoBvW4bHK6xrSHPn1Cgp1CE44DolpVc)

![Image 2: Canadian International Peace Summit (CIPS)](https://media.licdn.com/dms/image/v2/D4E0BAQEyW8IGS8dfSQ/company-logo_200_200/B4EZn004CBIwAI-/0/1760749126158/canadianinternationalpeacesummit_logo?e=2147483647&v=beta&t=sb2_yJutbYGiyo-OEPHVTLkkRiMXm7u69wJIM9esdIU)

Canadian International Peace Summit (CIPS)
==========================================

Education
---------

### Halifax, NS  472 followers

#### Building Global Peace & Empowering Communities| Education, Entrepreneurship, Storytelling | SDGs (1,3, 4,5, 8,10,13,16).

[Follow](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fcompany%2Fcanadianinternationalpeacesummit&fromSignIn=true&trk=top-card_top-card-secondary-button-top-card-secondary-cta)

*   [![Image 3](https://media.licdn.com/dms/image/v2/C4E03AQG8gXZ5jka4jA/profile-displayphoto-shrink_100_100/profile-displayphoto-shrink_100_100/0/1550512938477?e=2147483647&v=beta&t=7rN3BxeknCjW5KFfdXCgfu5_JIhraEJLv4iJWtmQDE4)![Image 4](https://media.licdn.com/dms/image/v2/D4E03AQEDrilgshNVUg/profile-displayphoto-scale_100_100/B4EZqcNy1LIoAc-/0/1763557457150?e=2147483647&v=beta&t=IF9LYZeVwyjyCBxRIsgn6EEXxwniJsfV6xLI73qzE1o)![Image 5](https://media.licdn.com/dms/image/v2/D4E03AQG3qs-zjmeV3w/profile-displayphoto-shrink_100_100/B4EZVxEngtG0AU-/0/1741358791428?e=2147483647&v=beta&t=2vCAFmKOgPe_s0t_DEGIyJ_rNm8fBX17y6DOeV8Vzj4) Discover all 5 employees](https://www.linkedin.com/signup/cold-join?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D%255B100833857%255D&trk=org-employees_cta_face-pile-cta)

*   [Report this company](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fcompany%2Fcanadianinternationalpeacesummit&trk=top-card_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=COMPANY&_f=guest-reporting)

About us
--------

HEARTS Global Network is a social venture advancing global peace by empowering individuals and communities to address critical challenges through innovative education and entrepreneurship. Guided by the United Nations Sustainable Development Goals (SDGs), we focus on fostering quality education (Goal 4) and promoting resilience, equity, and sustainable development (Goals 1, 3, 8, 10, 13, and 16). Our programs include: Heartfelt Podcast: Celebrating underrepresented voices through stories of resilience, connection, and growth. Dialogue & Conferences: Facilitating expert-led discussions on social justice, culture, and economic reform. Peace & Conflict Resolution Training: Equipping communities with practical tools for nonviolence and constructive change. Startup Incubation: Supporting women, youth, and entrepreneurs with mentorship and resources to launch impactful businesses.

 Website [heartsglobal.ca](https://www.linkedin.com/redir/redirect?url=http%3A%2F%2Fheartsglobal%2Eca&urlhash=h25-&trk=about_website)
External link for Canadian International Peace Summit (CIPS)

 Industry  Education 

 Company size  2-10 employees 

 Headquarters  Halifax, NS 

 Type  Nonprofit 

 Founded  2024 

 Specialties  Storytelling , Advocacy, Global Peacebuilding, Innovative Education, Entrepreneurial Leadership, Sustainable Development Goals (SDGs), and Women & Youth Empowerment 

Locations
---------

*    Primary Halifax, NS B3M 4K8, CA [Get directions](https://www.bing.com/maps?where=Halifax+B3M+4K8+NS+CA&trk=org-locations_url)

Employees at Canadian International Peace Summit (CIPS)
-------------------------------------------------------

*   [![Image 6: Click here to view Ryan 

*[... truncated, 45,947 more characters]*

---

### Heart2Hearts.ca |  HeartConomics: The Business Edge You Didn't Expect | Business Community of Heart Makers
*1,204 words* | Source: **GOOGLE** | [Link](https://www.heart2hearts.ca/)

![Image 1: HeartConomics: The Business Edge You Didn't Expect NEW BOOK RELEASE](https://static.wixstatic.com/media/1e13c7_76b0e0ae777d4951ad8d02a86f5059e0~mv2.jpg/v1/fill/w_280,h_432,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Cover%20without%20bleed%20%26%20Trim%20marks.jpg)

![Image 2: Boosts Stakeholder Loyalty: Strengthens connections with customers, partners, and communities by embedding love and empathy i](https://static.wixstatic.com/media/11062b_5e7c973a30524fa48fd4931b32b6228e~mv2.jpg/v1/fill/w_293,h_301,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/11062b_5e7c973a30524fa48fd4931b32b6228e~mv2.jpg)

Transforming Organizations with Love and Kindness

Unlock the Power of HeartConomics

Discover how love, kindness, and empathy can revolutionize your business and government policies.

HeartConomics is a pioneering framework that integrates love, kindness, and compassion into the DNA of organizations and governments. Written by [Patricia Rimok](https://www.heart2hearts.ca/about-5), this new book addresses [eleven relational-based pain points](https://www.heart2hearts.ca/_files/ugd/1e13c7_ad2f094697f34b7186f189b8ae230d4e.pdf) most organizations face and that traditional performance metrics overlook. By adopting a human-centric approach and AI, HeartConomics:

​

*   Fosters Trust and Collaboration: Resolves issues of mistrust and siloed communication by cultivating open, compassionate relationships within teams and across organizational levels.

​

*   Enhances Employee Engagement and Well-Being: Addresses [disengagement](https://www.heart2hearts.ca/_files/ugd/1e13c7_63b22871a9da45d981b295e48ba99556.pdf), burnout, and stress by creating a workplace culture centered on kindness, appreciation, shared purpose and holistic well-being.

​

*   Improves Conflict Resolution: Provides tools to navigate relational tensions and conflicts constructively, transforming challenges into opportunities for growth and understanding.

​

*   Boosts Stakeholder Loyalty: Strengthens connections with customers, partners, and communities by embedding love and empathy into decision-making and value creation.

​

By incorporating its human-centric approach, HeartConomics empowers organizations

to achieve remarkable outcomes while cultivating a more empathetic, productive, and sustainable environment.

[![Image 3: HeartConomics receives 5-Star Rating from Readers' Choice ](https://static.wixstatic.com/media/1e13c7_275aee6afcfa49c282263d2203796871~mv2.png/v1/fill/w_82,h_82,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/5star-flat-web.png)](https://readersfavorite.com/book-review/heartconomics)

![Image 4: Digital Sticker.png](https://static.wixstatic.com/media/1e13c7_39581b66d86e4d1aaff193771c6ac183~mv2.png/v1/fill/w_82,h_82,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Digital%20Sticker.png)

![Image 5: Digital Sticker.png](https://static.wixstatic.com/media/1e13c7_39581b66d86e4d1aaff193771c6ac183~mv2.png/v1/fill/w_227,h_227,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Digital%20Sticker.png)

![Image 6: 16.png](https://static.wixstatic.com/media/1e13c7_0d6d4a433d4a4d7fbede84064a9b9d74~mv2.png/v1/fill/w_339,h_239,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/16.png)

[Click here](https://www.heart2hearts.ca/_files/ugd/1e13c7_1b556320bcdc42b0a04b01bc368d0b34.pdf)for Press Release

[![Image 7: HeartConomics receives a warm press release review from Readers' Choice](https://static.wixstatic.com/media/1e13c7_275aee6afcfa49c282263d2203796871~mv2.png/v1/fill/w_198,h_198,al_c,lg_1,q_85,enc_avif,quality_auto/5star-flat-web.png)](https://readersfavorite.com/book-review/heartconomics)

HeartConomics: The Business Edge You Didn’t Expect has been awarded a prestigious 5-star rating by Readers’ Favorite, earning their official seal of excellence.

​

[Click here](https://readersfavorite.com/book-review/heartconomics) to read what reviewer K.C. Finn had to say.

​​

[Click here](https://www.heart2hearts.ca/_files/ugd/1e13c7_952b16e52d164fca8a27631195c24b10.pdf) to read Readers' Favorite Press Release

![Image 8: Colleagues Working Together](https://static.wixstatic.com/media/a01493bb8ec84e25a44424b088065876.jpg/v1/fill/w_301,h_196,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Colleagues%20Working%20Together.jpg)

![Image 9: Human-Centric Approach: Prioritizing well-being and relational-based challenges to improve overall performance.](https://static.wixstatic.com/media/11062b_1dfa0dd378b74726bd8e109220bbb142~mv2.jpg/v1/fill/w_306,h_196,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/11062b_1dfa0dd378b74726bd8e109220bbb142~mv2.jpg)

What is HeartConomics?

​

HeartConomics is a unique communications framework that focuses on the interpersonal, social, and psychological dimensions of organizations. By emphasizing acts of love and kindness, HeartConomics provides a comprehensive set of measurable indicators that can transform both business practices and government policies.

​

Core Principles:

​

*   Empat

*[... truncated, 9,393 more characters]*

---

### Blog | Why still marry if listening to your heart hurts?
*1,352 words* | Source: **GOOGLE** | [Link](https://www.heart2hearts.ca/blog)

Blog | Why still marry if listening to your heart hurts?

===============

top of page

![Image 1: Heart2Hearts.ca Logo](https://static.wixstatic.com/media/1e13c7_13e594c421904885871d6fedbfb5d382~mv2.jpg/v1/fill/w_69,h_71,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/happy-heart-back-cover%252520(1)_edited_ed.jpg)

![Image 2: HeartConomics: The Business Edge You Didn't Expect NEW BOOK RELEASE](https://static.wixstatic.com/media/1e13c7_76b0e0ae777d4951ad8d02a86f5059e0~mv2.jpg/v1/crop/x_0,y_0,w_1650,h_559/fill/w_200,h_71,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/Cover%20without%20bleed%20%26%20Trim%20marks.jpg)

*   [HeartConomics](https://www.heart2hearts.ca/)
*   [Join the Movement](https://www.heart2hearts.ca/home)
    *   [Comments/Kindness](https://www.heart2hearts.ca/comments-kindness)
    *   [Kindness Quiz](https://www.heart2hearts.ca/acts-of-kindness-quiz)
    *   [HeartMaker Board](https://www.heart2hearts.ca/heartmaker-board)

*   [About me](https://www.heart2hearts.ca/about-5)
*   [Blog](https://www.heart2hearts.ca/blog)
*   [Subscribe Mailing List](https://www.heart2hearts.ca/blog)
*   More   

Use tab to navigate through the menu items.

Log In

![Image 3: HeartConomics: The Business Edge You Didn't Expect - Kindle Version](https://static.wixstatic.com/media/1e13c7_706478ab46c1428baad351c40d97f12e~mv2.png/v1/fill/w_333,h_250,fp_0.50_0.50,q_35,blur_30,enc_avif,quality_auto/1e13c7_706478ab46c1428baad351c40d97f12e~mv2.webp)![Image 4: HeartConomics: The Business Edge You Didn't Expect - Kindle Version](https://static.wixstatic.com/media/1e13c7_706478ab46c1428baad351c40d97f12e~mv2.png/v1/fill/w_514,h_386,fp_0.50_0.50,q_95,enc_avif,quality_auto/1e13c7_706478ab46c1428baad351c40d97f12e~mv2.webp)

[HeartConomics: The Business Edge You Didn’t Expect – Now on Kindle! -------------------------------------------------------------------](https://www.heart2hearts.ca/post/heartconomics-the-business-edge-you-didn-t-expect-now-on-kindle)

HeartConomics reveals how love & kindness drive real business success. Now on Kindle—accessible, practical, and game-changing.

[![Image 5: Writer: Patricia Rimok](https://static.wixstatic.com/media/1e13c7_45b12c62457f49e98a5594568414f87d%7Emv2.jpg/v1/fill/w_32,h_32,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/1e13c7_45b12c62457f49e98a5594568414f87d%7Emv2.jpg)](https://www.heart2hearts.ca/profile/patrimok/profile)

[Patricia Rimok](https://www.heart2hearts.ca/profile/patrimok/profile)

1 min read

![Image 6: Purpose with Heart: Reconnecting Passion and People in the Nonprofit World](https://static.wixstatic.com/media/1e13c7_a36d8d535fae46d693a269c008f1646a~mv2.png/v1/fill/w_333,h_250,fp_0.50_0.50,q_35,blur_30,enc_avif,quality_auto/1e13c7_a36d8d535fae46d693a269c008f1646a~mv2.webp)![Image 7: Purpose with Heart: Reconnecting Passion and People in the Nonprofit World](https://static.wixstatic.com/media/1e13c7_a36d8d535fae46d693a269c008f1646a~mv2.png/v1/fill/w_514,h_386,fp_0.50_0.50,q_95,enc_avif,quality_auto/1e13c7_a36d8d535fae46d693a269c008f1646a~mv2.webp)

[Nonprofits & NGOs: Purpose with Heart: Reconnecting Passion and People in the Nonprofit World ---------------------------------------------------------------------------------------------](https://www.heart2hearts.ca/post/nonprofits-ngos-purpose-with-heart-reconnecting-passion-and-people-in-the-nonprofit-world)

Nonprofits are burning out. HeartConomics helps mission-driven teams refuel their purpose, trust, and passion without losing heart.

[![Image 8: Writer: HeartConomics](https://static.wixstatic.com/media/1e13c7_76b0e0ae777d4951ad8d02a86f5059e0%7Emv2.jpg/v1/fill/w_32,h_32,al_c,q_80,usm_0.66_1.00_0.01,enc_avif,quality_auto/1e13c7_76b0e0ae777d4951ad8d02a86f5059e0%7Emv2.jpg)](https://www.heart2hearts.ca/profile/55b1f4bf-cba6-4fc5-ac03-ba4872c5de60/profile)

[HeartConomics](https://www.heart2hearts.ca/profile/55b1f4bf-cba6-4fc5-ac03-ba4872c5de60/profile)

3 min read

![Image 9: HR & DEI: The HeartConomics Empathy MachineEngine](https://static.wixstatic.com/media/1e13c7_ee58fc280fef47b6a3ad3daa4365e584~mv2.png/v1/fill/w_333,h_250,fp_0.50_0.50,q_35,blur_30,enc_avif,quality_auto/1e13c7_ee58fc280fef47b6a3ad3daa4365e584~mv2.webp)![Image 10: HR & DEI: The HeartConomics Empathy MachineEngine](https://static.wixstatic.com/media/1e13c7_ee58fc280fef47b6a3ad3daa4365e584~mv2.png/v1/fill/w_514,h_386,fp_0.50_0.50,q_95,enc_avif,quality_auto/1e13c7_ee58fc280fef47b6a3ad3daa4365e584~mv2.webp)

[HR & DEI: The Empathy Engine: HeartConomics for Culture Builders and Inclusion Leaders --------------------------------------------------------------------------------------](https://www.heart2hearts.ca/post/hr-dei-the-empathy-engine-heartconomics-for-culture-builders-and-inclusion-leaders)

Rethink DEI: HeartConomics transforms inclusion into felt connection—anchored in ethics, merit, fairness & emotional safety.

[![Image 11: Writer: HeartConomics](https://static.wixstatic.com/media/1e13c7_76b0e0ae777d4951ad8d02a86f5059e0%7Emv2.jpg

*[... truncated, 22,920 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Heart2Hearts.ca | HeartConomics: The Business Edge You Didn't ...](https://www.heart2hearts.ca/)**
  - Source: heart2hearts.ca
  - *Heart2Hearts.ca - HeartConomics is a leadership and transformation ... ​Follow Patricia Rimok in her communities: ​. Join our mailing list. Subscribe ...*

- **[Blog | Why still marry if listening to your heart hurts?](https://www.heart2hearts.ca/blog)**
  - Source: heart2hearts.ca
  - *Heart2Hearts.ca Logo. HeartConomics · Comments/Kindness · Kindness Quiz ... ​Follow Patricia Rimok in her communities: ​. Join our mailing list. Subsc...*

---

*Generated by Founder Scraper*
