# Jérôme Malevez

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Silera
**Durée dans le rôle** : 11 months in role
**Durée dans l'entreprise** : 11 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Software Development

## Description du rôle

Silera empowers companies to build high-performing vision AI quickly and cost-effectively. We simplify AI development by providing scalable synthetic data solutions that remove data obstacles and foster rapid innovation.

## Résumé

From VFX to my own agency, and now exploring vision AI.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABiSW2wBSnS0HSd-3f9N11eLmk5z9HB8JyI/
**Connexions partagées** : 15


---

# Jérôme Malevez

## Position actuelle

**Entreprise** : Silera

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jérôme Malevez
*Silera*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 8 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Silera | Vision AI Powered by Synthetic Data](https://www.silera.ai/)
*2025-05-06*
- Category: article

### [Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data - Silera](https://www.silera.ai/blog/silera-joins-nvidia-inception-to-accelerate-vision-ai-with-synthetic-data)
*2025-10-14*
- Category: blog

### [“We remove CO2 from the air and lock it away”](https://www.ergo.com/en/next-magazine/sustainability-and-engagement/2022/start-ups-silicate-enhanced-weathering-carbon-removal-co2-accelerator-climate-kic)
*2024-12-10*
- Category: article

### [Serena](https://blog.serenacapital.com/?gi=f5fc98d5d353&source=post_page-----fd31e3b220fc--------------------------------)
*2023-10-09*
- Category: blog

### [Combining profitability and growth: 3 lessons from the DNVB model](https://landing-new.silvr.co/blog/combining-profitability-and-growth-3-lessons-from-the-dnvb-model)
*2023-09-06*
- Category: blog

---

## 📖 Full Content (Scraped)

*4 articles scraped, 1,918 words total*

### Silera |  Generate the vision data your model needs
*379 words* | Source: **EXA** | [Link](https://www.silera.ai/)

Silera | Generate the vision data your model needs

===============

[![Image 1](https://framerusercontent.com/images/cqAfmqvV5Jcz56VbH9a1pr8Cs.png)](https://www.silera.ai/)

[Home](https://www.silera.ai/)

[FAQ](https://www.silera.ai/#faq)

[Pricing](https://www.silera.ai/pricing)

[G e t i n T o u c h](https://www.silera.ai/contact)

The fastest path 

to vision AI.
================================

Turn a few images into a

Cheaper
=======

L
=

a
=

r
=

g
=

e
=

r
=

training set.

Request Access

**Build in hours**

Not months

**Build cheaper**

**Get better accuracy**

![Image 2](https://framerusercontent.com/images/MAjSrgz4qvxZUUB3mu0n5T8fHpQ.png?width=824&height=824)

![Image 3](https://framerusercontent.com/images/6dPMYUJraNfEYQ4NYTox3rA4NRc.png?width=824&height=824)

![Image 4](https://framerusercontent.com/images/57NJevDRlDjo4AUhbmF5LwTlxk.png?width=342&height=296)

![Image 5](https://framerusercontent.com/images/TJbQGrz1wdRGliU1jOkVkQnioTM.png?width=824&height=824)

**Where Silera delivers value**
===============================

#### **Industrial Inspection & Automation**

Generate every defect case so your model reaches target accuracy, fast.

Swap sensors, skip the data hunt.

![Image 6](https://framerusercontent.com/images/YFKqfByl20xpKlvkws0Z7oTdJ0.png?width=1024&height=1024)

![Image 7](https://framerusercontent.com/images/zbe2uHmWlbJ27WtdMj9Vn5sH4.png?width=1024&height=1024)

#### **Industrial Inspection 

& Automation**

Generate every defect case 

so your model reaches target accuracy, fast.

20x less real data needed.

#### **Recycling & Material Recovery**

Cover every condition and contaminant so sorting stays accurate.

Crushed, dirty, mislabeled? 

Covered.

![Image 8](https://framerusercontent.com/images/git4RoVL9KRpw6jr39isF8hNkZ8.png?scale-down-to=1024&width=1254&height=721)

#### **Agriculture & Environmental Detection**

Weeds, disease, pests, wildfire/smoke, varied across fields and seasons

and hard to label at scale.

Adapt to each field with a tiny sample.

![Image 9](https://framerusercontent.com/images/u3msUyZNkvTcwmU2z7sYIJw.png?scale-down-to=1024&width=1536&height=688)

EASY TO USE

**How it works?**
-----------------

Upload Images

01

Mark What Matters

02

Generate & Export

03

### 01.

### Upload Images

Drop a few real images. 

We ingest and prep them.

[R e q u e s t A c c e s s](https://www.silera.ai/contact)

![Image 10](https://framerusercontent.com/images/Oc1tJVvl3L4wPZwgS0u6m0UL3JI.png?scale-down-to=2048&width=2151&height=1145)

OUR BLOG

**Review our latest articles**
------------------------------

Do you want to learn more about us, let’s go the blog page.

[![Image 11](https://framerusercontent.com/images/385PsvIsxQ4WJJln8mtdjKPm160.png?width=1080&height=1080) What if your line caught the defects that matter, on the first pass? Quality Inspection](https://www.silera.ai/blog/synthetic-defects-turned-a-good-vision-system-into-a-great-one)[![Image 12](https://framerusercontent.com/images/UqFwWjld6K1dugFnXY7UZ81T5c.png?width=1920&height=1080) Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data Nvidia Inception 1 min read](https://www.silera.ai/blog/silera-joins-nvidia-inception-to-accelerate-vision-ai-with-synthetic-data)

FAQ

**Frequently Asked Questions**
------------------------------

Do I need lots of real images to start?

No. one is enough. You highlight the pattern/condition once and we expand it.

Who owns the generated data?

What if I don’t have a real example of the issue (defect, weed, leak)?

How are labels delivered?

How do you ensure the synthetic data actually improves my model?

FREE TRIAL

**Try Silera********for****free****today**
------------------------------------------

Request Access

Start your free trial! — No credit card required.

### 500

Average Images

### 30%

Recall Increase

### $25.8k

Monthly Value

![Image 13](https://framerusercontent.com/images/I1FFb6LW9VOjVIBPHMvPhGorR3Q.png)

![Image 14](https://framerusercontent.com/images/cqAfmqvV5Jcz56VbH9a1pr8Cs.png)

[Home](https://www.silera.ai/)

[Pricing](https://www.silera.ai/pricing#pricing)

[Contact](https://www.silera.ai/contact)

[FAQ](https://www.silera.ai/#faq)

[Cookie Policy](https://www.silera.ai/legal/cookie-policy)

[Privacy Policy](https://www.silera.ai/legal/privacy-policy)

[](https://www.linkedin.com/company/silera/)

---

### Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data - Silera
*193 words* | Source: **EXA** | [Link](https://www.silera.ai/blog/silera-joins-nvidia-inception-to-accelerate-vision-ai-with-synthetic-data)

Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data - Silera

===============

[![Image 1](https://framerusercontent.com/images/cqAfmqvV5Jcz56VbH9a1pr8Cs.png)](https://www.silera.ai/)

[Home](https://www.silera.ai/)

[FAQ](https://www.silera.ai/#faq)

[Pricing](https://www.silera.ai/pricing)

[G e t i n T o u c h](https://www.silera.ai/contact)

Automation

Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data
=========================================================================

Apr 17, 2025

1 min read

![Image 2](https://framerusercontent.com/images/UqFwWjld6K1dugFnXY7UZ81T5c.png?width=1920&height=1080)

We’re thrilled to announce that **Silera joined the NVIDIA Inception**, which supports startups using AI to reshape industries.

Silera generates photorealistic, synthetic datasets that help computer vision teams train and iterate in days instead of months. Joining Inception connects us with NVIDIA’s deep bench of AI expertise and an ecosystem of like‑minded builders, fuel we’ll use to push our tooling even further.

[‹ Previous Article](https://www.silera.ai/blog/synthetic-defects-turned-a-good-vision-system-into-a-great-one)

[Next Article ›](https://www.silera.ai/blog/data-for-recycling)

**Relevant Articles**
=====================

[![Image 3](https://framerusercontent.com/images/385PsvIsxQ4WJJln8mtdjKPm160.png?width=1080&height=1080) What if your line caught the defects that matter, on the first pass? Quality Inspection](https://www.silera.ai/blog/synthetic-defects-turned-a-good-vision-system-into-a-great-one)[![Image 4](https://framerusercontent.com/images/UqFwWjld6K1dugFnXY7UZ81T5c.png?width=1920&height=1080) Silera Joins NVIDIA Inception to Accelerate Vision‑AI With Synthetic Data Nvidia Inception 1 min read](https://www.silera.ai/blog/silera-joins-nvidia-inception-to-accelerate-vision-ai-with-synthetic-data)

FREE TRIAL

**Try Silera********for****free****today**
------------------------------------------

Request Access

Start your free trial! — No credit card required.

### 500

Average Images

### 30%

Recall Increase

### $25.8k

Monthly Value

![Image 5](https://framerusercontent.com/images/I1FFb6LW9VOjVIBPHMvPhGorR3Q.png)

![Image 6](https://framerusercontent.com/images/cqAfmqvV5Jcz56VbH9a1pr8Cs.png)

[Home](https://www.silera.ai/)

[Pricing](https://www.silera.ai/pricing#pricing)

[Contact](https://www.silera.ai/contact)

[FAQ](https://www.silera.ai/#faq)

[Cookie Policy](https://www.silera.ai/legal/cookie-policy)

[Privacy Policy](https://www.silera.ai/legal/privacy-policy)

[](https://www.linkedin.com/company/silera/)

---

### 404 - Not found
*625 words* | Source: **EXA** | [Link](https://www.ergo.com/en/next-magazine/sustainability-and-engagement/2022/start-ups-silicate-enhanced-weathering-carbon-removal-co2-accelerator-climate-kic)

404 - Not found

===============

Skip to content

[![Image 1: Logo ERGO Group AG](https://assets.ergo.com/content/dam/ergocom/en/logos/ergo-logo-munich-re/ergo-logo-munich-re.dam.svg)](https://www.ergo.com/en)

[![Image 2: Logo ERGO Group AG](https://assets.ergo.com/content/dam/ergocom/en/logos/ergo-logo-munich-re/ergo-logo-munich-re.dam.svg)](https://www.ergo.com/en)

Menu

 Menu 

 Company 

Company

 About ERGO The ERGO Group at a glance 

About ERGO

[![Image 3](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Portrait The ERGO Group at a glance](https://www.ergo.com/en/company/about-ergo/portrait-ergo-group)

[![Image 4](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Facts and figures Reports, key figures, ratings and history](https://www.ergo.com/en/company/about-ergo/facts-and-figures)

[![Image 5](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Management Board members and their responsibilities](https://www.ergo.com/en/company/about-ergo/management)

[![Image 6](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) ERGO companies Germany Our brands: ERGO and DKV](https://www.ergo.com/en/company/about-ergo/companies-germany)

[![Image 7](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) ERGO companies International Represented in over 20 countries worldwide](https://www.ergo.com/en/company/about-ergo/international-companies)

[![Image 8](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Technology and service provider IT solutions for ERGO on a global level](https://www.ergo.com/en/company/about-ergo/technology-and-service-provider)

![Image 9](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_forward.svg) Corporate Governance ERGO places great value on good corporate governance and an effective compliance system. Find out here how ERGO adheres to statutory and company regulations and minimises risks. 

Corporate Governance

[![Image 10](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Corporate Governance ERGO's compliance system and other guidelines and regulations](https://www.ergo.com/en/company/corporate-governance/uebersicht-corporate-governance)

[![Image 11](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) EU Disclosure Regulation Sustainability-related disclosure requirements](https://www.ergo.com/en/company/corporate-governance/eu-disclosure-regulation)

[![Image 12](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_right_alt.svg) Human rights ERGO is committed to respecting and protecting human rights.](https://www.ergo.com/en/company/corporate-governance/human-rights)

[Business partners ERGO Group offers long-term partnerships to qualified suppliers. Sustainability, transparency and compliance are important to us. Find out more, even if you are already one of our suppliers.](https://www.ergo.com/en/company/business-partner)

[![Image 13](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/arrow_forward.svg) Sports sponsorship ERGO promotes sport and believes in the unifying power of football. Find out more about the company's commitment and its collaboration with the DFB.](https://www.ergo.com/en/company/sports-sponsorship)

[//radar Magazine](https://www.ergo.com/en/radar-magazine)

[Career](https://www.ergo.com/en/career)

[Sustainability](https://www.ergo.com/en/sustainability)

[Newsroom](https://www.ergo.com/en/newsroom)

EN English
*   [Deutsch](https://www.ergo.com/de/errors/404)
*   [English](https://www.ergo.com/en/errors/404)

![Image 14: Claim](https://assets.ergo.com/content/dam/ergocom/en/claim/ergo-claim-en-default-top-red-rgb-2.dam.svg)

![Image 15](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/search.svg)Search

![Image 16](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/search.svg)Submit

![Image 17](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/close.svg)Close Search

[![Image 18](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/pictograms/globe2.svg)International](https://www.ergo.com/en/company/about-ergo/international-companies)

[![Image 19](https://www.ergo.com/etc.clientlibs/carbon/core/clientlibs/clientlib-cc-icons-v1/resources/icons/menu.svg)Menu](https://www.ergo.com/en/next-magazine/

*[... truncated, 5,120 more characters]*

---

### Serena
*721 words* | Source: **EXA** | [Link](https://blog.serenacapital.com/?gi=f5fc98d5d353&source=post_page-----fd31e3b220fc--------------------------------)

Serena

===============

[Sitemap](https://blog.serenacapital.com/sitemap/sitemap.xml)

[Open in app](https://rsci.app.link/?%24canonical_url=https%3A%2F%2Fblog.serenacapital.com&%7Efeature=LoOpenInAppButton&%7Echannel=ShowCollectionHome&%7Estage=mobileNavBar&source=---publication_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fblog.serenacapital.com%2F&source=collection_home---publication_layout_nav-----------------------global_nav------------------)

[](https://medium.com/?source=---publication_layout_nav-----------------------------------------)

[Write](https://medium.com/m/signin?operation=register&redirect=https%3A%2F%2Fmedium.com%2Fnew-story&source=---publication_layout_nav-----------------------new_post_topnav------------------)

[Search](https://medium.com/search?source=---publication_layout_nav-----------------------------------------)

Sign up

[Sign in](https://medium.com/m/signin?operation=login&redirect=https%3A%2F%2Fblog.serenacapital.com%2F&source=collection_home---publication_layout_nav-----------------------global_nav------------------)

![Image 1](https://miro.medium.com/v2/resize:fill:64:64/1*dmbNkD5D-u45r44go_cf0g.png)

![Image 2: Publication header background image](https://miro.medium.com/v2/resize:fit:0/1*oWnFgmBWb6CMJ5_jyC9J9Q.png)

[![Image 3: Serena](https://miro.medium.com/v2/resize:fill:128:128/1*HySQxZhuXP5L6rJwsF5b2Q.png)](https://blog.serenacapital.com/?source=collection_home_page----a78ab5774bda----------------------------------------)

[![Image 4: Serena](https://miro.medium.com/v2/resize:fill:160:160/1*HySQxZhuXP5L6rJwsF5b2Q.png)](https://blog.serenacapital.com/?source=collection_home_page----a78ab5774bda----------------------------------------)

Serena
------

[4.1K followers](https://blog.serenacapital.com/followers?source=collection_home_page----a78ab5774bda----------------------------------------)·

![Image 5: Bertrand Diard](https://miro.medium.com/v2/resize:fill:40:40/0*mvXCrWqapvs7A5vN.)

![Image 6: Xavier Lorphelin](https://miro.medium.com/v2/resize:fill:40:40/0*FuaiwFL-2K4eDbRA.jpg)

![Image 7: Sébastien Le Roy](https://miro.medium.com/v2/resize:fill:40:40/1*a4mh7-vjDebEwyr41c9VnA.jpeg)

![Image 8: Matthieu Lavergne](https://miro.medium.com/v2/resize:fill:40:40/1*ZTdv9aPqZqWqWN7EXtzPZQ.jpeg)

![Image 9: Floriane de Maupeou](https://miro.medium.com/v2/resize:fill:40:40/1*dykZ59yqFjp7JC7iHWbk8w.jpeg)

![Image 10: overlapping-avatar-placeholder](https://miro.medium.com/v2/da:true/resize:fill:40:40/8b8e1370130673fdb1f5d4d1959d531bac2bcbdfa845d624da64813200e537af)

5+editors

Follow

[🔥 Venture stuff](https://blog.serenacapital.com/subpage/97e510e10e7c?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

[🚀 Scale](https://blog.serenacapital.com/subpage/b935f32dff07?source=collection_home_page----a78ab5774bda-----1-----------------------------------)

[🤖 Deep Tech](https://blog.serenacapital.com/subpage/371a46564df5?source=collection_home_page----a78ab5774bda-----2-----------------------------------)

[AI Meets Physics: Why We’re Backing the Future of Industrial Simulation with Emmi AI ------------------------------------------------------------------------------------ ### In high-stakes industries like aerospace, semiconductors, and energy, simulation is essential. It’s how we model the airflow over an…](https://blog.serenacapital.com/ai-meets-physics-why-were-backing-the-future-of-industrial-simulation-with-emmi-ai-0891e27bd66e?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

[![Image 11: Guillaume Decugis](https://miro.medium.com/v2/resize:fill:20:20/1*UhTLB6i1f91cBQYGYhCDew.jpeg)](https://medium.com/@gdecugis?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

[Guillaume Decugis](https://medium.com/@gdecugis?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

·Apr 25·5 min read

![Image 12: AI Meets Physics: Why We’re Backing the Future of Industrial Simulation with Emmi AI](https://miro.medium.com/v2/resize:fill:80:53/format:webp/1*OW60CazrljUDkF5efarZPQ.png)

![Image 13: AI Meets Physics: Why We’re Backing the Future of Industrial Simulation with Emmi AI](https://miro.medium.com/v2/resize:fill:160:107/format:webp/1*OW60CazrljUDkF5efarZPQ.png)

[![Image 14: Guillaume Decugis](https://miro.medium.com/v2/resize:fill:20:20/1*UhTLB6i1f91cBQYGYhCDew.jpeg)](https://medium.com/@gdecugis?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

[Guillaume Decugis](https://medium.com/@gdecugis?source=collection_home_page----a78ab5774bda-----0-----------------------------------)

·Apr 25·5 min read

[The Open Source Payoff ---------------------- ### The Data-Backed Financial Case from 25 Years of Commercial Open Source](https://blog.serenacapital.com/the-open-source-payoff-5e835c54c0f1?source=collection_home_page----

*[... truncated, 12,101 more characters]*

---

---

## 🎬 YouTube Videos

- **[TRAILER - Vers 2 heures de philosophie et de citoyenneté à l’école : c’est nécessaire et maintenant?](https://www.youtube.com/watch?v=FcYfspTKxJg)**
  - Channel: Centre d'Action Laïque
  - Date: 2022-01-20

- **[LIO - Teaser #04 (Edrick &amp; Violette) [4K]](https://www.youtube.com/watch?v=q47RBh3rcl8)**
  - Channel: L'Incroyable Odyssée
  - Date: 2016-10-02

- **[Vers 2 heures de philosophie et de citoyenneté à l’école : c’est nécessaire et maintenant ?](https://www.youtube.com/watch?v=fo3Ot4mtl8U)**
  - Channel: Centre d'Action Laïque
  - Date: 2022-01-23

- **[VFX Demoreel  | Jerome Malevez](https://www.youtube.com/watch?v=Fd0N1QNSqXo)**
  - Channel: Jérôme Malevez
  - Date: 2023-01-11

- **[jerome malevez](https://www.youtube.com/watch?v=Ao2SrZGuYew)**
  - Channel: Jérôme Malevez
  - Date: 2014-08-02

- **[Jérôme MALEVEZ et François VERMER](https://www.youtube.com/watch?v=l7Orx-sr94k)**
  - Channel: CulturaEuropa
  - Date: 2017-09-28

- **[Onboard Jerome Malevez  Cà Bianca , Finale Ligure](https://www.youtube.com/watch?v=lSXsXSbUiL8)**
  - Channel: Clément Malevez
  - Date: 2023-02-17

- **[Marie&#39;ART • Jérôme Malevez - Marie de Hongrie](https://www.youtube.com/watch?v=sPIAn8bPGz0)**
  - Channel: Domaine & Musée royal de Mariemont
  - Date: 2024-06-07

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
