# Félix La Rocque Carrier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399142651679186945 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGZs0SUFHRzcQ/feedshare-shrink_800/B4EZq70qPtKoAs-/0/1764087738728?e=1766620800&v=beta&t=cYokTD9FE2cX5cn-nUkLnahhC03NmhaKP_96rpqd4IA | Loving this spotlight on one of my favourite Clinia programs. If you're curious how a simple idea can shape a healthier workplace, definitely give this a read. | 8 | 0 | 0 | 1w | Post | Félix La Rocque Carrier | https://www.linkedin.com/in/felixlrc | https://linkedin.com/in/felixlrc | 2025-12-08T06:21:11.403Z |  | 2025-11-25T17:51:17.583Z | https://www.linkedin.com/feed/update/urn:li:activity:7399120266775207959/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394791799971536896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQETXD6IbCf10A/feedshare-shrink_800/B4EZp.AOZwJ0Ak-/0/1763050581101?e=1766620800&v=beta&t=cJ1rSlxCfUwmlyNfeP0d-s_l-8wZOGpEvNoqbMk4zmQ | Proud to share Clinia’s latest milestone! 🎉

Clinia has once again achieved SOC 2 Type II compliance, reaffirming our commitment to the highest standards of security and privacy.

Huge shoutout to our amazing team. | 14 | 0 | 0 | 3w | Post | Félix La Rocque Carrier | https://www.linkedin.com/in/felixlrc | https://linkedin.com/in/felixlrc | 2025-12-08T06:21:11.403Z |  | 2025-11-13T17:42:33.701Z | https://www.linkedin.com/feed/update/urn:li:activity:7394770109967278080/ |  | 

---

