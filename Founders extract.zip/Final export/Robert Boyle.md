# Robert Boyle

## Position actuelle

**Titre** : Senior Strategic Cloud Engineer
**Entreprise** : Google
**Durée dans le rôle** : 1 month in role
**Durée dans l'entreprise** : 4 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Strategic Cloud Engineer at Google Cloud with a background in full-stack application development. Focusing on Google's Vertex AI, Kubernetes Engine and Compute platforms, I work with key enterprise partners to design and scale their infrastructure within GCP.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAkY1ycBfILAxGjRPsDWUscpVQIgxGJXHig/
**Connexions partagées** : 2


---

# Robert Boyle

## Position actuelle

**Entreprise** : Google

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Robert Boyle
*Google*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 26 |

---

## 📚 Articles & Blog Posts

### [The Faith of a Great Scientist: Robert Boyle’s Religious Life, Attitudes, and Vocation - Article - BioLogos](https://biologos.org/articles/the-faith-of-a-great-scientist-robert-boyles-religious-life-attitudes-and-vocation)
*2013-08-08*
- Category: article

### [Robert Boyle](https://www.pepysdiary.com/encyclopedia/8282/)
- Category: article

### [Boyle: Between God and Science - Simply Charly](https://www.simplycharly.com/read/reviews/robert-boyle-between-god-and-science/)
*2021-08-12*
- Category: article

### [Beyond Alchemy: Robert Boyle's Mechanical Philosophy](https://researchoutreach.org/articles/beyond-alchemy-robert-boyles-mechanical-philosophy/)
*2023-11-08*
- Category: article

### [The Blogs: Parshat Vaera -- Boyle's law | David Sedley](https://blogs.timesofisrael.com/parshat-vaera-boyles-law/)
*2020-01-24*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[The works of the Honourable Robert Boyle. In six volumes. To which ...](https://archive.org/details/bub_gb_LqYrAQAAMAAJ)**
  - Source: archive.org
  - *Nov 6, 2014 ... The works of the Honourable Robert Boyle. In six volumes. To which is prefixed the life of the author .. ; Foldoutcount: 0 ; Google-id...*

- **[Robert Boyle - Wikipedia](https://en.wikipedia.org/wiki/Robert_Boyle)**
  - Source: en.wikipedia.org
  - *For other people named Robert Boyle, see Robert Boyle (disambiguation). ... Hydrostatical Paradoxes – Google Books; "A disquisition about the final .....*

- **[Robert Boyle | Science History Institute](https://www.sciencehistory.org/education/scientific-biographies/robert-boyle/)**
  - Source: sciencehistory.org
  - *Google Classroom. About Scientific Biographies · Filter Biographies. Every general-chemistry student learns of Robert Boyle (1627–1691) as the person ...*

- **[Newton, Hooke, and 'Boyle's Law' (Discovered by Power and ...](https://www.nature.com/articles/204618a0)**
  - Source: nature.com
  - *Fulton, John F., A Bibliography of the Honourable Robert Boyle, second ed., Nos. 13–14 (Oxford, 1961). Google Scholar. Tait, P. G., Properties of Matt...*

- **[Robert Hooke's Experimental Philosophy by Felicity Henderson ...](https://www.the-tls.com/science-technology/sciences/robert-hookes-experimental-philosophy-felicity-henderson-review-hunter-dukes)**
  - Source: the-tls.com
  - *Dec 13, 2024 ... ... Robert Boyle, the wealthy youngest son of the First Earl of Cork ... Google Podcasts · Spotify · Apple Podcasts · Terms & Conditi...*

- **[The Alchemies of Robert Boyle and Isaac Newton: Alternate ...](https://www.cambridge.org/core/books/rethinking-the-scientific-revolution/alchemies-of-robert-boyle-and-isaac-newton-alternate-approaches-and-divergent-deployments/6FE3F359DAE5DF934F98218722966E3D)**
  - Source: cambridge.org
  - *10 - The Alchemies of Robert Boyle and Isaac Newton: Alternate Approaches and Divergent Deployments ... Google Drive or other file sharing services Pl...*

- **[Anna Keay on Historic Architecture, Monarchy, and 17th Century ...](https://conversationswithtyler.com/episodes/anna-keay/)**
  - Source: conversationswithtyler.com
  - *Apr 19, 2023 ... Subscribe on Google Podcasts · Subscribe on Apple Podcasts. April 19 ... Robert Boyle learned from Sir William Petty, why some monarc...*

- **[The impact of living in an un‐or under‐furnished house on ...](https://onlinelibrary.wiley.com/doi/abs/10.1002/jcop.22865)**
  - Source: onlinelibrary.wiley.com
  - *Apr 16, 2022 ... Robert Boyle,. Robert Boyle. Furniture Bank of Southeastern Michigan ... CRESR, Sheffield Hallam University. Google Scholar. Baggett ...*

- **[The Aspiring Adept: Robert Boyle and His Alchemical Quest on JSTOR](https://www.jstor.org/stable/j.ctv36zpwn)**
  - Source: jstor.org
  - *Google icon Continue with Google · Microsoft icon Continue with Microsoft ... Robert Boyle (1627-1691) is undoubtedly one of the most influential and ...*

- **[Targeting Revolutionaries | Radical History Review | Duke ...](https://read.dukeupress.edu/radical-history-review/article/2023/146/11/352718/Targeting-RevolutionariesThe-Birth-of-the-Carceral)**
  - Source: read.dukeupress.edu
  - *May 1, 2023 ... Letter from Dhoruba Bin Wahad to Robert Boyle, May 6, 1978. In ... https://doi.org/10.1080/07393149908429859. Google Scholar · Crossre...*

---

*Generated by Founder Scraper*
