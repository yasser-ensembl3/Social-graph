# Sylvain Chamberland

## Position actuelle

**Titre** : CEO et Fondateur
**Entreprise** : Arsenal Media
**Durée dans le rôle** : 7 years 3 months in role
**Durée dans l'entreprise** : 7 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAZRyqkBfGA972jsYCyEu75ec1fK2VTAozY/
**Connexions partagées** : 18


---

# Sylvain Chamberland

## Position actuelle

**Entreprise** : Arsenal Media

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Sylvain Chamberland

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399489645077614592 | Article |  |  | Pas le choix de publier une troisième fois cette année !! Une acquisition extrêmement stratégique qui nous permets d’atteindre le chiffre magique de 30 stations de radio au Québec! Arsenal Media le plus grand radiodiffuseur au Québec 

https://lnkd.in/erBSpcHu | 59 | 10 | 1 | 1w | Post | Sylvain Chamberland | https://www.linkedin.com/in/sylvainchamberland | https://linkedin.com/in/sylvainchamberland | 2025-12-08T06:18:33.233Z |  | 2025-11-26T16:50:07.256Z | https://www.newswire.ca/fr/news-releases/une-seconde-station-dans-la-capitale-nationale-pour-arsenal-media-869852757.html |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397004289027571712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFg0yvdAbYIxA/feedshare-shrink_800/B4EZqdwM9eHcAg-/0/1763583250803?e=1766620800&v=beta&t=mJtJbGiYXU3KIMEAnoxkcsna-j7LVWEnwqJutn382BU | J’abuse avec un deuxième post cette année mais je peux difficilement faire autrement! Quand on est jeune on a parfois des rêves qui sont plus forts que d’autres…. Acheter un réseau de sport en était définitivement un. Mon entreprise Arsenal Media est très fier d’annoncer l’acquisition du Réseau BPM SPORTS à Montréal, Québec et Gatineau. Avec 29 stations probables dans quelques mois, Arsenal Media est sans équivoque le plus important radiodiffuseur au Québec ! 

https://lnkd.in/e-TAR8G9 | 173 | 52 | 10 | 2w | Post | Sylvain Chamberland | https://www.linkedin.com/in/sylvainchamberland | https://linkedin.com/in/sylvainchamberland | 2025-12-08T06:18:33.234Z |  | 2025-11-19T20:14:12.198Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7337776984510357504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG3c8lZzyAPfA/feedshare-shrink_800/B4EZdUFQ3DH0Ak-/0/1749462360023?e=1766620800&v=beta&t=FP-tRqrq6xwXS7ZCkPojgATr-dTSGycU8gxT0ZMf5pk | Un premier post en 15 ans. 
Je dis toujours qu’il faut rester focus alors disons que je n’abuse pas ;)
En route pour Kelowna. 
C’est avec fierté que j’ai accepté l’offre de siéger au Conseil d’administration de Vista Radio en Colombie Britannique. Vista est le deuxième plus grand radiodiffuseur au Canada et un des médias les plus importants au pays. 
Un defi comme je les aime et un honneur qui rejaillit aussi sur toute ma gang de Arsenal Média. 
Une véritable reconnaissance de notre savoir faire au Québec et de notre capacité à gérer avec le vent dans la face comme on dit chez nous!! 
Prochain post dans 15 ans, j’ai trop à faire! | 127 | 33 | 1 | 5mo | Post | Sylvain Chamberland | https://www.linkedin.com/in/sylvainchamberland | https://linkedin.com/in/sylvainchamberland | 2025-12-08T06:18:33.234Z |  | 2025-06-09T09:46:02.411Z |  |  | 

---



---

# Sylvain Chamberland
*Arsenal Media*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 25 |

---

## 📚 Articles & Blog Posts

### [About us | Arsenal Media](https://arsenalmedia.com/about-us/)
*2024-02-08*
- Category: article

### [](https://chamberds.libsyn.com/aa-15-sylvain-gauchet-how-to-make-an-app-video)
- Category: article

### [BPM Sports radio stations being sold to Arsenal Media](https://montrealgazette.com/business/local-business/bpm-sports-radio-stations-being-sold-to-arsenal-media)
*2025-11-19*
- Category: article

### [Arsenal Media](https://en.wikipedia.org/wiki/Arsenal_Media)
*2025-04-27*
- Category: article

### [Racine & Chamberland – Our Team](https://racinechamberland.com/en/brokers/)
*2025-05-13*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Arsenal Media to acquire 'Radio Classique' Quebec City - Broadcast ...](https://broadcastdialogue.com/arsenal-media-to-acquire-radio-classique-quebec-city/)**
  - Source: broadcastdialogue.com
  - *Nov 26, 2025 ... Sylvain Chamberland, President and CEO of Arsenal Media, said the ... Radio + Podcast · TV + Film · Online · Tech · General News · Re...*

- **[Broadcasting Decision CRTC 2024-114 | CRTC](https://crtc.gc.ca/eng/archive/2024/2024-114.htm)**
  - Source: crtc.gc.ca
  - *May 27, 2024 ... Arsenal Media Inc. (Arsenal) filed an application to operate a new ... (50.75%), which is owned by Sylvain Chamberland, and Fondactio...*

- **[Arsenal Media set to acquire Quebec's BPM Sports radio network ...](https://broadcastdialogue.com/arsenal-media-set-to-acquire-quebecs-bpm-sports-radio-network/)**
  - Source: broadcastdialogue.com
  - *Nov 19, 2025 ... “I myself am a BPM Sports listener and have always been a sports enthusiast,” said Sylvain Chamberland, President and CEO of Arsenal ...*

- **[BPM Sports finally sold: what you need to know about the station's ...](https://dose.ca/2025/11/19/bpm-sports-finally-sold-what-you-need-to-know-about-the-stations-future/)**
  - Source: dose.ca
  - *Nov 19, 2025 ... I'm not convinced that Arsenal Media intends to be ultra-aggressive with its podcast offering . We'll see. 13. Sylvain Chamberland is...*

- **[Lagacé second behind Masbourian: I predicted it! : r/causerie](https://www.reddit.com/r/causerie/comments/1l3e1bq/lagac%C3%A9_deuxi%C3%A8me_derri%C3%A8re_masbourian_je_lavais_is/?tl=en)**
  - Source: reddit.com
  - *Jun 4, 2025 ... Brisson is married to the boss of Arsenal Media, Sylvain Chamberland. They want to keep their options open, and not upset her, lol. Wh...*

- **[Media | Fagstein](https://blog.fagstein.com/category/media/)**
  - Source: blog.fagstein.com
  - *Arsenal Media, which has been slowly expanding its Quebec radio station ... Arsenal's president and founder Sylvain Chamberland said in the company's ...*

- **[Radio | Fagstein](https://blog.fagstein.com/category/media/radio/)**
  - Source: blog.fagstein.com
  - *Arsenal Media, which has been slowly expanding its Quebec radio station ... Arsenal's president and founder Sylvain Chamberland said in the company's ...*

- **[Rattrapage - O 104,3-102,1-95,7 Abitibi-Témiscamingue](https://oabitibi.ca/rattrapage)**
  - Source: oabitibi.ca
  - *Chronique Médias avec J-F Dumas d'Influence communication – top 5 des nouvelles qui ont retenu l'attention cette semaine · La Game avec Sylvain Chambe...*

- **[L'achat de BPM s'est négocié avec des cigares et un porto au Lac ...](https://punchinggrace.com/nouvelles/lachat-de-bpm/)**
  - Source: punchinggrace.com
  - *Nov 20, 2025 ... Ils se sont tous retirés. Photo: Arsenal Media – Sylvain Chamberland, président et propriétaire d'Arsenal Media ... Podcasts de Louis...*

- **[ARSENAL MEDIA BECOMES QUEBEC'S LARGEST BROADCASTER](https://arsenalmedia.com/2025/04/23/arsenal-media-becomes-quebecs-largest-broadcaster/)**
  - Source: arsenalmedia.com
  - *Apr 22, 2025 ... For Sylvain Chamberland, President and CEO of Arsenal Media, « This acquisition is excellent news for listeners and local communities...*

---

*Generated by Founder Scraper*
