# Alex Blackie

## Position actuelle

**Titre** : Founder, President
**Entreprise** : BlackieOps
**Durée dans le rôle** : 2 years 3 months in role
**Durée dans l'entreprise** : 2 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

I am the founder of BlackieOps, a technology products and digital infrastructure company. We're building Worktree.ca: a Git collaboration platform and new sovereign cloud for Canada.

## Résumé

I'm the founder of BlackieOps, where we build Worktree -- a Canadian-sovereign DevOps and Cloud platform -- and and offer consulting for software development, cloud infrastructure, and DevSecOps.

I bring 15+ years of professional experience in the software and DevOps industries, ranging from tiny startups to companies in the Fortune 100, Shopify, and Wealthsimple.

I've worked on a multitude of projects that have grown a diverse skillset. At Flow, I built the backend that powered a Slack competitor; at Shopify I worked on critical payments infrastructure and within tight regulatory requirements; and at BlackieOps I've worked on everything from large enterprise eCommerce platforms to a niche Stripe integration for a small non-profit.

Sound like I could help? cal.com/alexblackie and let's talk.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACzsciEBIIsF65EIGJHqbNr5oMSsEJKALPw/
**Connexions partagées** : 16


---

# Alex Blackie

## Position actuelle

**Entreprise** : BlackieOps

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Alex Blackie

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399096837523132418 | Article |  |  | Worktree Cloud is getting drop-in, S3-compatible Object Storage. It's not just an off-the-shelf rebrand of an existing project; this is a from-scratch reimplementation with our own (open source) distributed storage backend.

This has been an incredibly cool thing to build, and even cooler to see it used in production.

If you store data in Canada (or want to), you should check this out.

Sign up for the waiting list! https://lnkd.in/eX57ktnF

Or check out the open source storage layer: https://lnkd.in/eGbWGADp | 13 | 0 | 2 | 1w | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.016Z |  | 2025-11-25T14:49:14.637Z | https://about.worktree.ca/cloud/object-storage/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7360666126827094016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG-Bv7frZnqRg/feedshare-shrink_800/B4EZiZW1hIGcAg-/0/1754919557627?e=1766620800&v=beta&t=han8w_UtZ4svFFQRMrDtUvd3K1dC8XlHi1GjY8s5yYE | If you're Canadian, your data is under threat from foreign governments, even if it resides on servers physically in Canada. 😰

To run cloud infrastructure in Canada, it’s always been at the feet of foreign companies: Amazon, Google, Microsoft, Oracle… We’ve piggy-backed on American tech for decades, and so local options have been scarce and under-developed.

But, this reliance on US cloud providers has exposed most Canadian citizens and businesses to US policies like the “Cloud Act” and “Patriot Act.” These invasive policies cross borders and threaten the privacy and security of Canadians’ data, even when it physically resides on Canadian soil. `ca-central-1` won't save you.

It’s time for change. It's time to build.

We're building a from-scratch, modern cloud platform. Starting today, you can sign up for Worktree Cloud and run your static site for $5 CAD. And we're already working on the next phase: object storage, a container PaaS, load balancers, and much more.

Read more 👇 or sign up today at worktree.ca.

https://lnkd.in/ee6V4wCq 

#worktree #canada #cloud #paas #containers #devops #git #cloudinfrastructure #privacy #docker #databases #staticsites #launch #startups #entrepreneurship #youcanjustdothings #hashtag | 20 | 2 | 1 | 3mo | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.017Z |  | 2025-08-11T13:39:19.199Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7350989481405046784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbNOPXbMJOog/feedshare-shrink_800/B4EZgP1VyQGwAo-/0/1752612299238?e=1766620800&v=beta&t=fNILlsZL1bwJi0mtxfgnUerqo0J-Bo7QhIbQH88-12g | From discovery call to official launch in under a year... Excited to announce that Dave is now live! 🚀👷

Dave started when a friend-of-a-friend who runs a general contracting company shared their frustrations. That conversation has grown into what is now probably the best software to run a trades business.

After speaking with dozens of contractors across the country, we kept hearing the same pain points:

- Spreadsheets can't keep up;
- Existing software is clunky and overwhelming; and
- Existing software gets in the way more than it helps.

Dave is built to melt into your business and help you get work done, not be the work you do.

I'm stoked to be on the founding team along with Derek Grudnicki, Vanessa Montoya Fendt, Jakeob Maltesen, and Jeremy Harper.

👉 If you're in trades or know someone that is, check out Dave (https://lnkd.in/e5HF3FFW) or hit me up to set up a demo. | 26 | 2 | 2 | 4mo | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.018Z |  | 2025-07-15T20:47:47.147Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7345897108534620161 | Article |  |  | Happy Canada Day, friends ✨🇨🇦🫡

Now seems like the perfect time to recap how far Worktree.ca has come since we launched earlier this year, and what ongoing projects are coming up next for the platform.

Worktree now hosts hundreds of Git repos from nearly 200 users and is growing every day. It's been amazing to see, and encouraging to hear great feedback from everyone who's switched to it so far.

Looking into 25H2, there's some incredibly exciting stuff is coming down the pike to share.

Check out our July update in full below, and if you haven't yet, sign up for Canada's independent DevOps platform!

https://lnkd.in/eSEGjkyB | 10 | 0 | 1 | 5mo | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.018Z |  | 2025-07-01T19:32:30.843Z | https://about.worktree.ca/blog/2025-07-01-worktree-july-2025-update/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7325523081416871937 | Article |  |  | My birthday was a couple months ago, but I noticed something was missing... I never got my automated "happy birthday" email from the Dynamic Drive Forums! That's when I learned that the site had been shut down only a few months prior.

Now, a couple months later (oops), I finally wrote a quick in-memoriam to the legacy of Dynamic Drive and the impact it had on little Alex all those years ago:

https://lnkd.in/dcNgq6dh

Farewell, Dynamic Drive. 🫡 | 1 | 0 | 0 | 7mo | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.018Z |  | 2025-05-06T14:13:24.247Z | https://www.alexblackie.com/articles/farewell-dynamic-drive/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7305328695387279361 | Article |  |  | Anyone who knows me knows I've spent the better part of two decades trying to keep my data in Canada. At one point I had a kitted-out 12U rack in my apartment running everything from websites, to CI, to file storage for my family. (That last one is still the case!)

One of the things I've always run for myself has been Git. Fifteen years ago it was Atlassian Stash using their now-forgotten $10-to-charity licenses, and then it was cgit, Gitea, GitLab, Pagure... The software changed but the goal was the same: mirror everything, and keep private repos close to home.

Fast forward to today: Worktree. A fork of Gitea, but being heavily modified and refactored behind the scenes. Backed by my company. Running in a real cloud, not my closet (although my closet *does* have great uptime...). Hosted CI compatible with GitHub Actions. Even a fancy website...

What started as "a hobby for fun" is now a "business-ready platform". What started as "only on my own VPN" is now "fostering a community".

I'm so excited to see where we go from here.

Rejoins-moi? | 42 | 7 | 5 | 8mo | Post | Alex Blackie | https://www.linkedin.com/in/alexblackie | https://linkedin.com/in/alexblackie | 2025-12-08T06:11:42.019Z |  | 2025-03-11T20:48:07.424Z | http://worktree.ca/ |  | 

---



---

# Alex Blackie
*BlackieOps*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Canadian entrepreneur and software developer](https://alexblackie.com/index.xml)
*2025-05-06*
- Category: article

### [We can solve your Cloud, Software, and DevSecOps problems.](https://www.blackieops.com/consulting/)
*2025-01-01*
- Category: article

### [Bug Bounty Q&A with Jhaddix & Blaklis – Bug Bounty Reports Explained](https://www.bugbountyexplained.com/bug-bounty-qa-with-jhaddix-blaklis/)
*2025-04-01*
- Category: article

### [Why Blackbird invested in Lexer](https://alexanderjarvis.com/why-blackbird-invested-in-lexer)
*2025-02-24*
- Category: article

### [Sweetie Pie Baked Apple Cheddar Dessert recipe](https://saltypaloma.com/blogs/salty-talk/sweetie-pie-baked-apple-cheddar-dessert-recipe?comment=134951469347&page=53)
*2022-05-17*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[We can solve your Cloud, Software, and DevSecOps problems ...](https://www.blackieops.com/consulting/)**
  - Source: blackieops.com
  - *Alex Blackie. Founder, President. Website · LinkedIn ... Book a quick call and let's talk about how BlackieOps can help you ship better software, fast...*

- **[Quick and Dirty Containers with systemd - Alex Blackie](https://www.alexblackie.com/articles/nspawn/)**
  - Source: alexblackie.com
  - *Jul 22, 2015 ... Avatar for Alex Blackie Alex Blackie Articles My Setup Hire Me. Find ... That said, here at BlackieOps we've been using systemd-nspaw...*

---

*Generated by Founder Scraper*
