# Grégoire L.

## Position actuelle

**Titre** : Music Composer / Producer / Writer / Audio-Visual Technician
**Entreprise** : NÅ Productions
**Durée dans le rôle** : 5 years 8 months in role
**Durée dans l'entreprise** : 5 years 8 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Media Production

## Description du rôle

Music composition, writing, editing and production work for award-winning feature movies (Humanist Vampire Seeking Consenting Suicidal Person (2022), Calorie (2025)...), screen projects (Checkpoint, Je Suis Père,...), VR experiences (Interstellar Arc Operation,...), theater plays (LUNA,...), video-games, podcasts, online broadcasts (TFO), art exhibitions (RAW Artists San Francisco, San Rafael, Le Labo Toronto Arts Center...) and EP projects.

## Résumé

Hi, I'm Greg ✌️

Over 10 years experience in the Entreprise Software/Saas Solutions business, taking care and growing top-tier accounts in various regulated industries (Pharma, Manufacturing, Transportation, Finance...), I have a passion for missions that require a problem-solving mindset, curiosity, and creativity.

Inside Sales and Post-Sales management is where I thrive, as I get to accompany valued customers and partners towards success in diverse and matrixed business environments. 
I also work on different artistic projects (screen composing, writing, filming, editing, and music production) with other eclectic and creative minds. 

Optimistic during tough times, "teamwork", "perspectives" and "nuance" gained a deeper meaning for me over the years and I rarely deal in absolutes. 🙃

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAmQmREB5UYnH2DZgRliCHeBqEOMWOnlPL4/
**Connexions partagées** : 2


---

# Grégoire L.

## Position actuelle

**Entreprise** : Unity

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Grégoire L.
*Unity*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 33 |

---

## 📚 Articles & Blog Posts

### [About – Grégoire Charpe-Civatte – Medium](https://medium.com/@GregoireCC/about)
*2025-05-14*
- Category: blog

### [Interview: Multigres on Database School](https://multigres.com/blog/database-school)
*2025-07-01*
- Category: blog

### [How to disrupt and make an impact with serial entrepreneur Gregoire Vigroux](https://therecursive.com/how-to-disrupt-and-make-an-impact-with-serial-entrepreneur-gregoire-vigroux/)
*2021-12-07*
- Category: article

### [Grégoire Charles - Product Manager](https://greg.pm/55f7dba1d3604bb1bd7ae2c244bdc792)
*2024-01-01*
- Category: article

### [A conversation with Yannick Gregoire](https://timrodenbroeker.de/yannick-gregoire)
*2023-03-10*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 185,171 words total*

### About – Grégoire Charpe-Civatte – Medium
*1,301 words* | Source: **EXA** | [Link](https://medium.com/@GregoireCC/about)

Art & work have always been core pillars of my life and make the best canvas to describe my journey to date. **Start them young: my childhood as a creator kid.**

At age 12, my bedroom was covered with my “creations”: cardboard based city models, stain sculptures, electronic gadget inventions, and “startup” ideas on floating papers. I was doing my best to materialize the world of possibilities that was blooming in my head. What I couldn’t actually make, I would at least design; I was keeping with me a “book of inventions”, documenting machines to “wake up dead people”, a cow dung based lighter, electric scooters, and more.

2 years later, my mother was always slightly puzzled to receive packages from Africa in the mail: addressed to me, as the self-proclaimed “CEO” of a music production company, these would include VHS tapes with the latest video clips from the rap band I was supporting there, helping them getting aired on radios in Europe or access recording studios in their countries. At the time, the internet wasn’t what it is today: one had to actually code to get anything up and running online, and If you had a website that looked good enough, people would assume you were a real business or organization. Being able to actually make a small yet tangible impact for bands across Europe or Africa, all while being a mid-school guy essentially experimenting from his bedroom computer, created a deep fascination for what creation and experimentation could offer. I became obsessed with technology and “new things”. I had up to 5 computers in my bedroom at some point, always building new things and engaging with more people.

The online “financial advisory” business I launched when I was 15 wasn’t that much of a success to say the least (I was essentially stealing and adapting recommendations published by serious websites or media, and received a warning by their lawyer, which naturally got the 15 yo me scared), but it just kept me going with this habit of trying anyway. 20 years later, I would realize that this fearless approach, where you start and do things anyway, would be the key.

**Defining years: building versatility as a core in my twenties**

From age 17 to 23, I became fascinated with politics and democracy and felt invested of a “mission” to push youth to care about public debate, and get involved. In parallel with my studies, I organized many public debates and lectures, eventually becoming the youngest president of one of France’s oldest and most private societies: the [“Conference Olivaint”](https://en.wikipedia.org/wiki/Conf%C3%A9rence_Olivaint?source=user_about----------------------aedce8f12ac2---------------------- "https://en.wikipedia.org/wiki/Conf%C3%A9rence_Olivaint") (founded in 1874). This was an era of deep intellectual stimulation for me.. and of disillusions too, as I engaged weekly with some of the most influential leaders that would often turn to be driven by egos and an opportunistic approach to politics. My naive or idealistic views took a hit and I took distance with politics.

Art and creativity were reaching new heights in me at the time. I started to immerse myself in the electronic music scene, discovering the Parisian nightlife, then transitioning from deejaying in my 9m2 studio facing a wall to playing in front of thousands across Europe and beyond. I co-created a production and live act duo: we composed dozens of tunes, signed on about 20 labels, had our own radio show in multiple countries, were supported by the biggest international artists (Roger Sanchez, John Aquaviva, David Guetta, LaidbackLuke, and more), ultimately working with some of them. I loved that complete stretch between extremes: interacting with the government or influential industry captains during the day, hanging out with the dj scene and music fans at night, making lifelong memories as I could impact people’s emotions by the touch of knobs on my turntables and mixer.

Play, create, explore, but then again: work hard. I studied for 7 years: Business Law, first, at La Sorbonne, and then Communications & Marketing at France’s leading Grande Ecole in this field; the CELSA. The reality is that I wasn’t the model student: I would typically be very committed for the first few years, enjoying the great aura of some of the top notch professors we had, and then essentially leverage my fast learning abilities to skip classes and go on tours instead, as my music projects were picking up. I’d lock myself up for 2 weeks before the exams, and put up a pretty stimulating “all in” effort that would get me through.

**Remixing the corporate life through explorations.**

While developing my music career, I started to put these academic degrees to use: advising politicians as a freelance consultant at first, then joining some of the largest companies over the last 15 years, to help push their transformation agenda. I’ve always been stimulated by the ambition to embrace new ways, build bridges, and help my large corporate em

*[... truncated, 3,111 more characters]*

---

### Interview: Multigres on Database School
*11,202 words* | Source: **EXA** | [Link](https://multigres.com/blog/database-school)

Sugu discusses Multigres on the Database School YouTube channel. He shares the history of Vitess, its evolution, and the journey to creating Multigres for Postgres. The conversation covers the challenges faced at YouTube, the design decisions made in Vitess, and the vision for Multigres.

Chapters[​](https://multigres.com/blog/database-school#chapters "Direct link to Chapters")
------------------------------------------------------------------------------------------

*   [00:00](https://www.youtube.com/watch?v=28q9mFh87KY) - Intro
*   [1:38](https://www.youtube.com/watch?v=28q9mFh87KY&t=98s) - The birth of Vitess at YouTube
*   [3:19](https://www.youtube.com/watch?v=28q9mFh87KY&t=199s) - The spreadsheet that started it all
*   [6:17](https://www.youtube.com/watch?v=28q9mFh87KY&t=377s) - Intelligent query parsing and connection pooling
*   [9:46](https://www.youtube.com/watch?v=28q9mFh87KY&t=586s) - Preventing outages with query limits
*   [13:42](https://www.youtube.com/watch?v=28q9mFh87KY&t=822s) - Growing Vitess beyond a connection pooler
*   [16:01](https://www.youtube.com/watch?v=28q9mFh87KY&t=961s) - Choosing Go for Vitess
*   [20:00](https://www.youtube.com/watch?v=28q9mFh87KY&t=1200s) - The life of a query in Vitess
*   [23:12](https://www.youtube.com/watch?v=28q9mFh87KY&t=1392s) - How sharding worked at YouTube
*   [26:03](https://www.youtube.com/watch?v=28q9mFh87KY&t=1563s) - Hiding the keyspace ID from applications
*   [33:02](https://www.youtube.com/watch?v=28q9mFh87KY&t=1982s) - How Vitess evolved to hide complexity
*   [36:05](https://www.youtube.com/watch?v=28q9mFh87KY&t=2165s) - Founding PlanetScale & maintaining Vitess solo
*   [39:22](https://www.youtube.com/watch?v=28q9mFh87KY&t=2362s) - Sabbatical, rediscovering empathy, and volunteering
*   [42:08](https://www.youtube.com/watch?v=28q9mFh87KY&t=2528s) - The itch to bring Vitess to Postgres
*   [44:50](https://www.youtube.com/watch?v=28q9mFh87KY&t=2690s) - Why Multigres focuses on compatibility and usability
*   [49:00](https://www.youtube.com/watch?v=28q9mFh87KY&t=2940s) - The Postgres codebase vs. MySQL codebase
*   [52:06](https://www.youtube.com/watch?v=28q9mFh87KY&t=3126s) - Joining Supabase & building the Multigres team
*   [54:20](https://www.youtube.com/watch?v=28q9mFh87KY&t=3260s) - Starting Multigres from scratch with lessons from Vitess
*   [57:02](https://www.youtube.com/watch?v=28q9mFh87KY&t=3422s) - MVP goals for Multigres
*   [1:01:02](https://www.youtube.com/watch?v=28q9mFh87KY&t=3662s) - Integration with Supabase & database branching
*   [1:05:21](https://www.youtube.com/watch?v=28q9mFh87KY&t=3921s) - Sugu's dream for Multigres
*   [1:09:05](https://www.youtube.com/watch?v=28q9mFh87KY&t=4145s) - Small teams, hiring, and open positions
*   [1:11:07](https://www.youtube.com/watch?v=28q9mFh87KY&t=4267s) - Community response to Multigres announcement
*   [1:12:31](https://www.youtube.com/watch?v=28q9mFh87KY&t=4351s) - Where to find Sugu

Transcription[​](https://multigres.com/blog/database-school#transcription "Direct link to Transcription")
---------------------------------------------------------------------------------------------------------

#### Intro[​](https://multigres.com/blog/database-school#intro "Direct link to Intro")

Welcome back to Database School, I am your host, Aaron Francis. In this episode, I talk to the co-creator of Vitess and the co-founder of PlanetScale. The same person. His name is Sugu Sougoumarane. We talk about his time at YouTube and the invention of Vitess, moving on to PayPal, then founding PlanetScale. And finally, his time in the wilderness. He took a little sabbatical and then he comes back to create Vitess for Postgres. He's joining Supabase to bring Vitess to Postgres. You're really going to enjoy this - he's incredibly smart but also very, very humble and very thoughtful. So, enough yapping from me, let's enjoy this episode of Database School.

This is kind of some breaking news.

So, I'm super excited to be here. I am here with Sugu Sougoumarane. He is the co-creator of Vitess, the co-founder of PlanetScale. And he is back to talk with us about his next adventure. But before we get into that, we're going to dive into a little bit about the history of Vitess. And then we'll talk about what's up next. So, Sugu, thank you for being here. Do you want to introduce yourself a little bit? Sure, yeah. I'm Sugu. And I have been involved with databases for a pretty long time, I think since the 90s. Wow. I was working at Informix and then I moved on to PayPal in the early days and took care of scalability there. And from there, I moved

#### The birth of Vitess at YouTube[​](https://multigres.com/blog/database-school#the-birth-of-vitess-at-youtube "Direct link to The birth of Vitess at YouTube")

to YouTube, and that is where I co-created Vitess with my colleague Mike Solomon. This was because YouTube was falling apart on the database side, and we had to come up with something that would leap us 

*[... truncated, 58,674 more characters]*

---

### How to disrupt and make an impact with serial entrepreneur Gregoire Vigroux
*1,405 words* | Source: **EXA** | [Link](https://therecursive.com/how-to-disrupt-and-make-an-impact-with-serial-entrepreneur-gregoire-vigroux/)

How to disrupt and make an impact with serial entrepreneur Gregoire Vigroux - TheRecursive.com

===============

[![Image 1: The Recursive](https://therecursive.com/cdn-cgi/image/formatauto/wp-content/themes/therecursive/assets/imgs/TheRecursive.png)](https://therecursive.com/)

[![Image 2: The Recursive](https://therecursive.com/cdn-cgi/image/formatauto/wp-content/themes/therecursive/assets/imgs/TheRecursive.png)](https://therecursive.com/)

[![Image 3: The Recursive](https://therecursive.com/cdn-cgi/image/formatauto/wp-content/themes/therecursive/assets/imgs/TheRecursive.png)](https://therecursive.com/)

*   [Channels](https://therecursive.com/how-to-disrupt-and-make-an-impact-with-serial-entrepreneur-gregoire-vigroux/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE1MTU0IiwidG9nZ2xlIjpmYWxzZX0%3D)
*   [Podcast](https://therecursive.com/channel/podcasts/)
*   [Storytelling Studio](https://storytelling.therecursive.com/)
*   [HNWI Investing Report](https://hnwi.therecursive.com/)

[Donate](https://therecursive.com/donations/subscribe-for-recurring-donations/)[](https://www.facebook.com/therecursive)[](https://www.linkedin.com/company/the-recursive/)[](https://www.instagram.com/the_recursive/)[](https://twitter.com/TheRecursiveEU)[](https://www.youtube.com/channel/UC0t-WA2tlHRjOI9Pb6OTTmQ)

*   [Channels](https://therecursive.com/how-to-disrupt-and-make-an-impact-with-serial-entrepreneur-gregoire-vigroux/#)
    *   [Startups](https://therecursive.com/channel/startups/)
    *   [Ecosystem](https://therecursive.com/channel/innovation-ecosystem/)
    *   [Diaspora](https://therecursive.com/channel/innovation-ecosystem/diaspora/)
    *   [R&D Destinations](https://therecursive.com/channel/innovation-ecosystem/r-and-d-destinations/)
    *   [Investors](https://therecursive.com/channel/investors/)
    *   [Deals](https://therecursive.com/channel/deals/)
    *   [Leadership](https://therecursive.com/channel/leaders-diary/)
    *   [Deep Tech](https://therecursive.com/channel/deep-tech/)
    *   [Blockchain](https://therecursive.com/channel/deep-tech/blockchain/)
    *   [AI](https://therecursive.com/channel/deep-tech/ai/)
    *   [Cybersecurity](https://therecursive.com/channel/deep-tech/cybersecurity/)
    *   [Others](https://therecursive.com/channel/others/)
    *   [Gen Z](https://therecursive.com/channel/gen-z/)
    *   [Gaming](https://therecursive.com/channel/gaming/)
    *   [Mobility](https://therecursive.com/channel/mobility/)
    *   [Health](https://therecursive.com/channel/health/)
    *   [Edtech](https://therecursive.com/channel/edtech/)
    *   [Retail](https://therecursive.com/channel/retail/)
    *   [Fintech](https://therecursive.com/channel/fintech/)
    *   [Sustainability](https://therecursive.com/channel/sustainability/)
    *   [Climate Tech](https://therecursive.com/channel/sustainability/climatetech/)
    *   [Social Impact](https://therecursive.com/channel/sustainability/social-impact/)
    *   [Smart Cities](https://therecursive.com/channel/sustainability/smart-cities/)
    *   [Women in Tech](https://therecursive.com/channel/women-in-tech/)
    *   [Future of Work](https://therecursive.com/channel/future-of-work/)
    *   [Corporate Innovation](https://therecursive.com/channel/corporate-innovation/)
    *   [Careers](https://therecursive.com/channel/careers/)

*   [Podcast](https://therecursive.com/channel/podcasts/)
*   [About](https://therecursive.com/about/)
*   [Content Services](https://therecursive.com/our-services/)

Search for...

[Podcasts](https://therecursive.com/channel/podcasts/)[Home](https://therecursive.com/) » [News](https://therecursive.com/news/) » [Podcasts](https://therecursive.com/channel/podcasts/) » **How to disrupt and make an impact with serial entrepreneur Gregoire Vigroux**

How to disrupt and make an impact with serial entrepreneur Gregoire Vigroux
===========================================================================

 by [The Recursive](https://therecursive.com/author/the-recursive/) 7 December 2021

[iTunes](https://podcasts.apple.com/bg/podcast/the-recursive-podcast/id1576538398)[Spotify](https://spoti.fi/3kqEyVW)[YouTube](https://www.youtube.com/channel/UC0t-WA2tlHRjOI9Pb6OTTmQ/videos)[PocketCast](https://pca.st/vz9615k0)[RSS](https://anchor.fm/s/63feb77c/podcast/rss)

 Image credit: The Recursive

[Bucharest](https://therecursive.com/city/bucharest/), [Romania](https://therecursive.com/country/romania/) ~ 

The Recursive podcast comes back to Bucharest to meet with [serial entrepreneur and angel investor Gregoire Vigroux](https://www.linkedin.com/in/gregoire-vigroux/). A Frenchman who fell in love in Romania and set up all his businesses there, he’s working tirelessly to change the country for the better and show its opportunities to the world.

Gregoire was born with an entrepreneurial mindset. He has co-founded and invested in more than 25 businesses across Eastern Europe and has had 4 exits so far.

One of his first ventures w

*[... truncated, 17,631 more characters]*

---

### Grégoire Charles
*255 words* | Source: **EXA** | [Link](https://greg.pm/55f7dba1d3604bb1bd7ae2c244bdc792)

Product Manager, Paris - France

![Image 1](https://dix-sept.notion.site/icons/mail_gray.svg?mode=light)

Contact me

Freelance product manager based in Paris with 15 years of professional experience in hyper growth technology companies. I'm passionate about solving complex problems, and working with cross-functional teams in dynamic environments.

I used to lead product at [eFounders](https://www.efounders.com/) and spent some time discussing our processes and methodologies with Jordan and Alex on their respective podcasts (both in French 🇫🇷).

Jordan Chenevier-Truchet

Alex Delivet

I challenge and guide founders, product, and tech teams on various topics

Product vision and strategy

Roadmap and prioritization

Product organization and rituals

Tool selection and implementation

Discovery and user research

Product design and user experience (UX/UI)

Delivery and tech interface (specs, QA)

Build No/Low Code solutions when relevant

Release and metric monitoring

Talent recruitment and retention

Favorite Tools

Brainstorming & Ideation: Whimsical, Miro, FigJam

Design & Prototyping: Figma, Sketch

Project Management: Linear, Notion, JIRA, Trello, etc.

No-Code Technical Stack

Data: Airtable, Google Sheet (+ Script)

User interface: Glide, Stacker, Softr

Website & Content: Webflow, Framer, Ghost

I also have skills in JavaScript, Ruby, and Python to tailor experiences to your needs. Feel free to reach out to me for further details, via this form or directly on [LinkedIn](https://www.linkedin.com/in/gregoirecharles/).

![Image 2](https://dix-sept.notion.site/icons/mail_gray.svg?mode=light)

Contact me

Projects

No results

Load more

Work & Education

Since 2020

5

2015 - 2020

2

2009 - 2015

4

Prior to 2009

3

![Image 3](https://dix-sept.notion.site/icons/document_gray.svg?mode=light)

Show resume

Side projects

Live

3

Deprecated

3

✉️

hello@greg.pm

![Image 4: Callout icon](https://dix-sept.notion.site/image/https%3A%2F%2Fcdn.worldvectorlogo.com%2Flogos%2Flinkedin-icon-2.svg?table=block&id=61267538-b09b-449c-ab48-ff46188fe9db&spaceId=4273417d-5aef-497a-971b-733480115793&userId=&cache=v2)

![Image 5: Callout icon](https://dix-sept.notion.site/image/https%3A%2F%2Fabs.twimg.com%2Ffavicons%2Ftwitter.ico?table=block&id=7ae1aa6c-82a7-4baf-aed7-28c8aed04dd7&spaceId=4273417d-5aef-497a-971b-733480115793&userId=&cache=v2)

![Image 6: Callout icon](https://dix-sept.notion.site/image/https%3A%2F%2Fgithub.githubassets.com%2Fpinned-octocat.svg?table=block&id=d57068e6-0585-48bf-8298-84f7cdfe24a4&spaceId=4273417d-5aef-497a-971b-733480115793&userId=&cache=v2)

© gregcha 2024

---

### A conversation with Yannick Gregoire
*2,245 words* | Source: **EXA** | [Link](https://timrodenbroeker.de/yannick-gregoire)

About a year ago I stumbled upon Yannick Gregoire’s profile on Instagram and was immediately fascinated by his work. Later, I came across some of his animations at [DEMO Festival 2022](https://timrodenbroeker.de/demo2022-recap/). In this interview, I talk to him about the beginnings of his work with code, creative principles and his favorite tools.

![Image 1](https://timrodenbroeker.de/wp-content/uploads/2023/03/yg3-1024x1024.jpg)

Photo: Douwe de Boer

Hi Yannick, I’ve been following your work for a while now and I’m very glad you answered a few questions for us. Let’s start right away with what drives you. In your Instagram bio you defined a kind of manifesto that makes me curious. How are the three statements “Calm over chaos”, “experimental over predictable” and “learning over consuming” reflected in your work?

Hey TIm, thanks for having me on. Great question. I think for me these statements started out as an anchor for the visual aesthetics I was looking to produce, and the clientele I was looking to build for my business as a web designer / developer. At the time I was looking to actively shift away from advertising for wasteful consumption (consumer fetishism?), towards using my skills and building products that have a lasting positive social impact.

Slowly but surely though I feel these statements have transformed, or are transforming into the main pointers in my creative process. I’m a big believer of doing one thing at a time, and taking the time for it, if circumstances allow for that of course. I feel at my best when I have a calm mind and when I can give the amount of attention to projects that they deserve. I think one way to achieve this is to have a systematic approach to your work. A common theme in my work I think is that visual output is often based around a set of simple rules, in which there’s room to experiment. There’s a lot of beauty in the simple representation of complex systems.

> Calm over chaos, experimental over predictable, learning over consuming.

What are the main motivators and inspiration when experimenting with code?

I guess for me, one of the main motivators for experimenting with code is finding out how certain visuals are made, and what the system behind it looks like. It can be print or motion graphics, art installations, games, websites etc.

Whenever I see an interesting visual I try to figure out the underlying “ruleset”. Most of the time I have a hunch of how something is made, and then try to replicate it with code. Almost every time though, I fail to replicate that exact visual or ruleset, but along the way come to new insights and experiment further with that. I also like to revisit old work and see if I can combine it with new insights I’ve picked up. For me there’s a lot of beauty in the simple representation of complex systems.

Turns out I’ve pretty much embraced the Conditional Design Manifesto: [https://www.conditionaldesign.org/manifesto/](https://www.conditionaldesign.org/manifesto/)

Apart from that I also get inspiration from technical wiki’s ([https://en.wikipedia.org/wiki/QR_code](https://en.wikipedia.org/wiki/QR_code)), the MDN docs ([https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-timeline-axis](https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-timeline-axis))

![Image 2](https://timrodenbroeker.de/wp-content/uploads/2023/03/yg4-1024x1024.jpg)

Photo: Douwe de Boer

What does your workflow look like?

The specific steps taken really depend on whether I’m working for clients directly or for other designers or studio’s, but a common thing in my process is that I don’t work with a predefined final visual in mind. It really depends on the context, but for instance when it’s just me working on a project, I start with research on the given topic and form a concept that I find interesting and fits the clients needs. Often, I immediately start sketching out my ideas in raw HTML / CSS and JavaScript, and use those to give the project its final form. The techniques I use define what it’s going to look like eventually. My skillset is my toolbox, from graphic design to motion graphics to coding.

When I work with a design studio, it’s a different story and it becomes much more a collaboration between the designers, the wants and needs of the client and me, where I take on the role of a front end coder much more.

What topics do you always come back to and are drawn to the most and why?

I’m very much drawn to lo-fi aesthetics. Ascii art, pixel art, C64 colors, command lines interfaces, code editors, BIOS, I/O etc.

I think that’s because my work revolves around exposing or communicating visuals through a system or ruleset rather than the visual itself. Designing after the fact feels unnecessary to me, and I try to stay away from trends as much as possible. I like to kind of provide a view into the source code, as in: Look at what this piece of code can do!

Other than that I believe that working with tech, and designing visual systems make

*[... truncated, 10,049 more characters]*

---

### The EU’s neoliberal constitutionalism(s) | European Law Open | Cambridge Core
*12,000 words* | Source: **GOOGLE** | [Link](https://www.cambridge.org/core/journals/european-law-open/article/eus-neoliberal-constitutionalisms/8E75415A504DF0666E804CD61A8AE50D)

References
----------

![Image 1](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

1 A Vauchez, _L’Union par le droit: l’invention d’un programme institutionnel pour l’Europe_ (Presses de Sciences Po 2013).

![Image 2](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

2 R Lecourt, ‘Allocution prononcée à l’audience solennelle du 23 octobre 1968 à l’occasion du X e anniversaire de la CJCE’ 4 (1968) Revue trimestrielle de droit européen 746, esp 751.

![Image 3](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

3 See CF Ophüls, ‘Grundzüge europäischer Wirtschaftsverfassung’ 124 (1962) Zeitschrift für das Gesamte Handelsrecht und Wirtschaftsrecht 136; L-J Constantinesco, ‘La constitution économique de la C.E.E.’ 13 (2) (1977) Revue trimestrielle de droit européen 244.

![Image 4](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

4 See, eg, M Poiares Maduro, _We the Court: The European Court of Justice and the European Economic Constitution: A Critical Reading of Article 30 of the EC Treaty_ (Hart Publishing 1998); C Kaupa, ‘The pluralist socio-economic character of the European Treaties’ in G Davies and M Avbelj (eds), _Research Handbook on Legal Pluralism and EU Law_ (Edward Elgar Publishing 2018) 257.

![Image 5](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

5 See, eg, DJ Gerber, ‘Constitutionalizing the Economy: German Neo-Liberalism, Competition Law and the New Europe’ 52 (1) (1994) American Journal of Comparative Law 25; S Gill, ‘European Governance and New Constitutionalism: Economic and Monetary Union and Alternatives to Disciplinary Neoliberalism in Europe’ 3 (1) (1998) New Political Economy 5; P Dardot and C Laval, _The New Way Of The World: On Neoliberal Society_ (Verso 2014); T Biebricher, ‘Zur Ordoliberalisierung Europas – Replik auf Hien und Joerges’ 46 (2) (2918) Leviathan 170.

![Image 6](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

6 MA Wilkinson, _Authoritarian Liberalism and the Transformation of Modern Europe_ (Oxford University Press 2021). See also the proceedings of the ‘Symposium on MA Wilkinson, Authoritarian Liberalism and the Transformation of Modern Europe’ 1 (1) (2022) European Law Open 150.

![Image 7](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

7 See, eg, B van Apeldoorn, ‘Transnationalization and the Restructuring of Europe’s Socioeconomic Order: Social Forces in the Construction of “Embedded Neoliberalism”’ 28 (1) (1998) International Journal of Political Economy 12; H Canihac, _La fabrique savante de l’Europe. Une archéologie des savoirs de l’Europe communautaire_ (Larcier 2020).

![Image 8](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

8 M Foucault, ‘Nietzsche, la généalogie, l’histoire’ in S Bachelard et al (eds), _Hommage à Jean Hyppolite_ (Presses Universitaires de France 1971) 145. See also F Taylan, _Concepts et rationalités. Héritages de l’épistémologie historique, de Meyerson à Foucault_ (Éditions matériologiques 2018).

![Image 9](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

9 R Koselleck, _Futures Past. On the Semantics of Historical Time_ (MIT Press 1985); R Koselleck, _The Practice of Conceptual History: Timing History, Spacing Concepts_ (Stanford University Press 2002).

![Image 10](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

10 Q Skinner, ‘Meaning and Understanding in the History of Ideas’ 8 (1) (1969) History and Theory 3; JGA Pocock, _Political Thought and History: Essays on Theory and Method_ (Cambridge University Press 2009).

![Image 11](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

11 M Foucault, ‘Polémique, politique et problématisations’ in D Defert and F Ewald (eds),_Dits et écrits par Michel Foucault, Tome II_ (Gallimard 2001) 1410.

![Image 12](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

12 M Loiselle, ‘L’histoire des concepts juridiques et la question du contexte’ in L Israël et al (eds), _Sur la portée sociale du droit: Usages et légitimité du registre juridique_ (Presses Universitaires de France 2005) 29.

![Image 13](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

13 A Bailleux and F Ost, ‘Droit, contexte et interdisciplinarité: refondation d’une démarche’ 70 (1) (2013) Revue interdisciplinaire d’études juridiques 25. Regarding in particular the ‘law in context’ turn in European studies, see C Harlow ‘The EU and Law in Context: The Context’ 1 (1) (2022) European Law Open 209.

![Image 14](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

14 PJ Neuvonen, ‘A Way of Critique: What Can EU Law Scholars Learn from Critical Theory?’ 1 (1) (2022) European Law Open 60.

![Image 15](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

15 T Pankakoski, ‘Conflict, Context, Concreteness: Koselleck and Schmitt on Concepts’ 38 (6) (2010) Political Theory 749.

![Image 16](blob:http://localhost/439d061206e1e3162f83c666f82d1d80)

16 KW Nörr, ‘“Economic Constitution”: On the Roots of a Legal Concept’ 11 (1) 1994 Journal of L

*[... truncated, 94,708 more characters]*

---

### Educating Through Attentional States of Consciousness, an Effective Way to Develop Creative Potential?
*19,435 words* | Source: **GOOGLE** | [Link](https://hal.science/hal-03777479/document)

REVIEW 

published: 17 March 2022 doi: 10.3389/feduc.2022.774685 

Edited by: 

Helané Wahbeh, Institute of Noetic Sciences, United States 

Reviewed by: 

Ansar Abbas, Airlangga University, Indonesia Kalina Christoff, University of British Columbia, Canada Arnaud Delorme, UMR 5549 Centre de Recherche Cerveau et Cognition (CerCo), France 

*Correspondence: 

Kevin Rebecchi rebecchikevin@yahoo.fr 

Specialty section: 

This article was submitted to Educational Psychology, a section of the journal Frontiers in Education 

Received: 12 September 2021 

Accepted: 23 February 2022 

Published: 17 March 2022 

Citation: 

Rebecchi K and Hagège H (2022) Educating Through Attentional States of Consciousness, an Effective Way to Develop Creative Potential? Front. Educ. 7:774685. doi: 10.3389/feduc.2022.774685 

# Educating Through Attentional States of Consciousness, an Effective Way to Develop Creative Potential? 

Kevin Rebecchi * and Hélène Hagège 

Laboratoire Éducation et Diversité en Espaces Francophones, Department of Education Sciences, University of Limoges, Limoges, France 

Researchers have recently turned their focus to a specific area: the links between altered states of consciousness and creativity. A spectrum of attentional states of consciousness exists, from hypnagogia and mind wandering to mindfulness and flow. These attentional states of consciousness are present during a variety of activities (e.g., sports, music, painting, writing, video games, theater, and meditation) as well as in situations characterized by boredom. They are also present in many professional fields and practices (e.g., education and teaching). Moreover, researchers and educators focus sometimes on only one state of consciousness (such as mind wandering) or only on attention, and do not question relationships with others (such as mindfulness or flow) or the links with intention, the different levels of consciousness involved and the changes in perception of time, self and space. Additionally, as we know that a state of consciousness rarely occurs alone or that it can have two forms (such as spontaneous and deliberate mind wandering), we propose a global approach allowing to grasp the stakes and perspectives of what we call attentional states of consciousness. Thus, to our knowledge, this is the first theoretical review highlighting the historical, empirical, theorical and conceptual relationships between creativity, attention, mind wandering, mindfulness and flow by offering concrete and empirical avenues and bases for reflection about educating for creativity and developing creative potential. 

Keywords: states of consciousness, mindfulness, mind wandering, flow, creativity, education, attention 

# INTRODUCTION 

The aim of this literature review is to offer new perspectives and insights on the connection between states of consciousness and creativity. States (sometimes also called “contents”) of consciousness are generally qualified as “altered” or “modified,” and these terms appear here in quotations, to retain the vocabulary used in research. We, however, prefer to use the term “ attentional states of consciousness” (or the more neutral “states of consciousness”) as we feel this term best encapsulates the main states of consciousness studied in this article, all of which are closely linked to the concept of attention. Thus, initially, the definition of terms seems important to us. Ludwig (1966, p. 225) defines altered states of consciousness as “a sufficient deviation in subjective experience or psychological 

Frontiers in Education | www.frontiersin.org 1 March 2022 | Volume 7 | Article 774685 Rebecchi and Hagège Education, Creativity and Consciousness 

functioning from certain general norms for that individual during alert, waking consciousness.” Lubart et al. (2015, p. 123) define creativity as “the ability to produce a production that is both new and adapted to the context in which it occurs.” One new perspective could then be to harness this connection in educational settings as a means of increasing pupils’ creative potential, a product of distinct and interdependent resources (namely, specific aspects of intelligence, motivation, knowledge, personality, cognitive styles of affect, and physical and socio-cultural environmental contexts). This creative potential can be expressed in a particular task or area and to varying degrees (Lubart et al., 2013; Barbot et al., 2015). The individual may or may not be aware of their potential, a latent state which can be considered a part of human capital as well as a resource for society (Lubart et al., 2013). Runco (2004) believes creativity is present in all children, not just the smartest, and that it is important to identify each child’s potential for developing it. The aim of this article is specifically to review mechanisms and educational practices including mind wandering, mindfulness, flow, and creativity. We will begin by retracing the conceptual history of states o

*[... truncated, 131,649 more characters]*

---

### Information archivée dans le Web
*89 words* | Source: **GOOGLE** | [Link](https://publications.gc.ca/collections/collection_2024/mdn-dnd/D12-8-23-4-eng.pdf)

Publications du gouvernement du Canada
--------------------------------------

[Continuer vers la publication](https://publications.gc.ca/collections/collection_2024/mdn-dnd/D12-8-23-4-eng.pdf)

Pour demander une publication dans un format alternatif, remplissez [le formulaire électronique](https://publications.gc.ca/site/fra/contact/contactezNous.html#emailform) des publications du gouvernement du Canada. Utilisez le champ du formulaire «question ou commentaire» pour spécifier la publication demandée.

[Parcourir les publications du gouvernement du Canada](https://publications.gc.ca/site/fra/parcourir/index.html)
Government of Canada Publications
---------------------------------

[Continue to publication](https://publications.gc.ca/collections/collection_2024/mdn-dnd/D12-8-23-4-eng.pdf)

To request an alternate format of a publication, complete the Government of Canada Publications [email form](https://publications.gc.ca/site/eng/contact/contactUs.html#emailform). Use the form’s “question or comment” field to specify the requested publication.

[Browse Government of Canada publications](https://publications.gc.ca/site/eng/browse/index.html)

---

### Malt
*10,269 words* | Source: **GOOGLE** | [Link](https://www.malt.fr/s/tags/avid-pro-tools-59ca86816e6c295df40aa33e?p=4)

Trouvez un freelance Avid Pro-tools disponible sur Malt

===============

[![Image 1: Malt logo](https://dam.malt.com/cms-front/maltLogo.png?h=32)](https://www.malt.fr/)

Trouver un freelance

[Créer mon compte](https://www.malt.fr/who-are-you?pageSource=cms_marketing_page&componentSource=navbar-unlogged)[Me connecter](https://www.malt.fr/signin?pageSource=cms_marketing_page&componentSource=navbar-unlogged)

 FR

Entreprises

*   [![Image 2: handshake icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/81559655-6677-4b1e-87a9-3099605b2c1a_graph+icon+black.svg)Pourquoi Malt ? Malt est une marketplace qui vous permet de trouver des freelances qualifiés pour tous types de projets.](https://www.malt.fr/c/companies)
*   [![Image 3: person plus icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/67b93cc6-dec9-4911-9e9a-815de21991f2_handshake+icon+black.svg)Engager des freelances Trouvez le bon profil via notre marketplace, nous nous occupons du reste.](https://www.malt.fr/c/companies/engager-des-freelances)
*   [![Image 4: graph icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/cae7556b-846e-4fba-b174-e80037dbf31e_freelancers+plus+icon+black.svg)Centraliser la gestion de ses freelances Simplifiez et consolidez toutes vos activités avec des freelances sur une même plateforme.](https://www.malt.fr/c/companies/solution-gestion-freelances)
*   ![Image 5](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/5d0ae033-9632-46a4-ae82-3a98935e6985_eye+magnifying+glass+icon+black.svg)Explorer les profils Cherchez par métier ou par ville.  

[Créer mon compte](https://www.malt.fr/who-are-you?pageSource=cms_marketing_page&componentSource=navbar-unlogged)[Me connecter](https://www.malt.fr/signin?pageSource=cms_marketing_page&componentSource=navbar-unlogged)

 FR

Entreprises 

*   [![Image 6: handshake icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/81559655-6677-4b1e-87a9-3099605b2c1a_graph+icon+black.svg)Pourquoi Malt ? Malt est une marketplace qui vous permet de trouver des freelances qualifiés pour tous types de projets.](https://www.malt.fr/c/companies)
*   [![Image 7: person plus icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/67b93cc6-dec9-4911-9e9a-815de21991f2_handshake+icon+black.svg)Engager des freelances Trouvez le bon profil via notre marketplace, nous nous occupons du reste.](https://www.malt.fr/c/companies/engager-des-freelances)
*   [![Image 8: graph icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/cae7556b-846e-4fba-b174-e80037dbf31e_freelancers+plus+icon+black.svg)Centraliser la gestion de ses freelances Simplifiez et consolidez toutes vos activités avec des freelances sur une même plateforme.](https://www.malt.fr/c/companies/solution-gestion-freelances)
*   ![Image 9](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/5d0ae033-9632-46a4-ae82-3a98935e6985_eye+magnifying+glass+icon+black.svg)Explorer les profils Cherchez par métier ou par ville.  

Freelances

*   [![Image 10: person with laptop icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/daf9e42b-7561-48d6-b161-7620c9a2406f_icon+of+person+in+front+of+a+laptop+black.svg)Pourquoi Malt ? Rejoignez Malt pour recevoir des missions de qualité, faciliter votre gestion quotidienne et vous faire payer rapidement.](https://www.malt.fr/c/freelancers)
*   [![Image 11: two person icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/59d3fe06-9124-45f0-acd9-4a5f8d687d29_icon+of+two+people+black.svg)Community & Programmes Nous sommes là pour vous aider à vous développer.](https://www.malt.fr/c/freelancers/community-et-programmes-freelances)
*   [![Image 12: crown icon](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/9507beac-a2e6-48be-8e75-7709fcf221f8_crown+icon+black.svg)Nos partenaires Utilisez les services et outils de partenaires bien décidés à faciliter votre vie de freelance.](https://www.malt.fr/c/partners)
*   [![Image 13](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/43457a91-37c9-4626-8eab-f824e0335948_message+sent+icon+black.svg)Programme d’apport d’affaires Partagez une opportunité de mission et gagnez 5% du montant facturé](https://www.malt.fr/c/freelancers/business-referral-program)

[Créer mon compte](https://www.malt.fr/who-are-you?pageSource=cms_marketing_page&componentSource=navbar-unlogged)[Me connecter](https://www.malt.fr/signin?pageSource=cms_marketing_page&componentSource=navbar-unlogged)

 FR

Freelances 

*   [![Image 14: person with laptop icon black](https://malt-cms-marketing.cdn.prismic.io/malt-cms-marketing/daf9e42b-7561-48d6-b161-7620c9a2406f_icon+of+person+in+front+of+a+laptop+black.svg)Pourquoi Malt ? Rejoignez Malt pour recevoir des missions de qualité, faciliter votre gestion quotidienne et vous faire payer rapidement.](https://www.malt.fr/c/freelancers)
*   [![Image 15: two person icon black](https://malt-cm

*[... truncated, 87,932 more characters]*

---

### Remembering 1759: The Conquest of Canada in Historical Memory
 9781442699236 - DOKUMEN.PUB
*126,970 words* | Source: **GOOGLE** | [Link](https://dokumen.pub/remembering-1759-the-conquest-of-canada-in-historical-memory-9781442699236.html)

REMEMBERING 1759 The Conquest of Canada in Historical Memory

This companion volume to Revisiting 1759 examines how the Conquest of Canada has been remembered, commemorated, interpreted, and reinterpreted by groups in Canada, France, Great Britain, the United States, and, most of all, Quebec. It focuses particularly on how the public memory of the Conquest has been used for a variety of cultural, political, and intellectual purposes. The essays contained in this volume investigate topics such as the legacy of 1759 in twentieth-century Quebec; the memorialization of General James Wolfe in a variety of national contexts; and the re-imagination of the Plains of Abraham as a tourist destination. Combined with Revisiting 1759, this collection provides readers with the most comprehensive, wide-ranging assessment to date of the lasting effects of the Conquest of Canada. phillip buckner is a professor emeritus in the Department of History at the University of New Brunswick and a senior fellow at the Institute of Commonwealth Studies and the Institute for the Study of the Americas at the University of London. john g. reid is a professor in the Department of History and a senior fellow at the Gorsebrook Research Institute at Saint Mary’s University.

This page intentionally left blank

Remembering 1759 The Conquest of Canada in Historical Memory

EDITED BY PHILLIP BUCKNER AND JOHN G. REID

UN IVERSIT Y O F TO RO NTO P RE SS Toronto Buffalo London

© University of Toronto Press 2012 Toronto Buffalo London www.utppublishing.com Printed in Canada ISBN 978-1-4426-4411-3 (cloth) ISBN 978-1-4426-1251-8 (paper)

Printed on acid-free, 100% post-consumer recycled paper with vegetable-based inks.

Library and Archives Canada Cataloguing in Publication Remembering 1759 : the conquest of Canada in historical memory / edited by Phillip Buckner and John G. Reid. Includes bibliographical references and index. ISBN 978-1-4426-4411-3 (bound). – ISBN 978-1-4426-1251-8 (pbk.) 1. Québec Campaign, 1759 – Anniversaries, etc. 2. Plains of Abraham, Battle of the, Québec, 1759 – Anniversaries, etc. 3. Collective memory – Québec (Province). 4. Collective memory – Canada. I. Buckner, Phillip A. (Phillip Alfred), 1942– II. Reid, John G. (John Graham), 1948– FC386.R45 2012

971.01′88

C2012-901838-4

This book has been published with the help of a grant from the Canadian Federation for the Humanities and Social Sciences, through the Aid to Scholarly Publications Program, using funds provided by the Social Sciences and Humanities Research Council of Canada. University of Toronto Press acknowledges the ﬁnancial assistance to its publishing program of the Canada Council for the Arts and the Ontario Arts Council.

University of Toronto Press acknowledges the ﬁnancial support of the Government of Canada through the Canada Book Fund for its publishing activities.

Contents

Preface

vii

1 Introduction 3 phillip buckner and john g. reid 2 ‘The Immortal Wolfe’? Monuments, Memory, and the Battle of Quebec 29 joan coutu and john m c aleer 3 ‘Where Famous Heroes Fell’: Tourism, History, and Liberalism in Old Quebec 58 alan gordon 4 In Search of the Plains of Abraham: British, American, and Canadian Views of a Symbolic Landscape, 1793–1913 82 j.i. little 5 History, Historiography, and the Courts: The St Lawrence Mission Villages and the Fall of New France 110 jean-françois lozier 6 Interpreting the Past, Shaping the Present, and Envisioning the Future: Remembering the Conquest in Nineteenth-Century Quebec 136 michel ducharme 7 Overcoming a National ‘Catastrophe’: The British Conquest in the Historical and Polemical Thought of Abbé Lionel Groulx 161 michel bock

vi

Contents

8 Intervening with abandon: The Conquest’s Legacy in the Canada-Quebec-France Triangle of the 1960s 186 david meren 9 A Nightmare to Awaken from: The Conquest in the Thinking of Québécois Nationalists of the 1960s and After 211 alexis lachaine 10 Below the Academic Radar: Denis Vaugeois and Constructing the Conquest in the Quebec Popular Imagination 226 brian young 11 Remembering the Conquest: Mission Impossible? 251 nicole neatby 12 What Is to Be Done with 1759? jocelyn létourneau Contributors Index

303

305

279

Preface

On 14 September 1759 British and French troops fought a battle on the Plains of Abraham, just outside what was then the capital of the colony of Canada, Quebec City. There was nothing inevitable about the victory of the British forces under General James Wolfe and it was not irreversible. Indeed, the British forces met defeat at the Battle of SteFoy in April 1760 and only the arrival of a British rather than a French ﬂeet later that spring ensured that Quebec remained in British hands. Conversely, even if Wolfe had been defeated on the Plains of Abraham, Quebec might still have fallen to the much larger British force slowly making its way north from the thirteen colonies in 1759–60 under the command of General Jeffery Amherst. And, of course, Canada might have been

*[... truncated, 803,872 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[The EU's neoliberal constitutionalism(s) | European Law Open ...](https://www.cambridge.org/core/journals/european-law-open/article/eus-neoliberal-constitutionalisms/8E75415A504DF0666E804CD61A8AE50D)**
  - Source: cambridge.org
  - *Feb 6, 2025 ... Nonetheless, it is instructive to consider their 'unity in ... See G Grégoire, 'L'économie de Karlsruhe. L'intégration européenne à .....*

- **[Educating Through Attentional States of Consciousness, an Effective ...](https://hal.science/hal-03777479/document)**
  - Source: hal.science
  - *Sep 14, 2022 ... The unity and diversity of executive functions and their contributions to ... Grégoire, L. Lachance, and L. Richer (Cambridge: Presse...*

- **[Canadian Military Journal](https://publications.gc.ca/collections/collection_2024/mdn-dnd/D12-8-23-4-eng.pdf)**
  - Source: publications.gc.ca
  - *May 27, 2022 ... The multi- national force leadership must develop a means for coordination among the participants to achieve unity of effort … ... Gr...*

- **[Trouvez un freelance Avid Pro-tools disponible sur Malt](https://www.malt.fr/s/tags/avid-pro-tools-59ca86816e6c295df40aa33e?p=4)**
  - Source: malt.fr
  - *Unity 3D; Intégration Unity; Narration; Conception rédaction; Réécriture ... Grégoire L. Localisé(e) à Paris. 300 €/jour. Monteur Son Podcast / Ingéni...*

- **[Remembering 1759: The Conquest of Canada in Historical Memory ...](https://dokumen.pub/remembering-1759-the-conquest-of-canada-in-historical-memory-9781442699236.html)**
  - Source: dokumen.pub
  - *Thematic unity was an important criterion, and after a great deal of ... Grégoire, 'L'arrêt Le procureur general du Québec c. Régent Sioui et al ......*

- **[Contacts Recruteurs LinkedIn 1.0 | PDF](https://www.scribd.com/document/798189095/Contacts-Recruteurs-LinkedIn-1-0)**
  - Source: scribd.com
  - *Grégoire L. person. Guillaume B. person. Amelie Devulder person. Stephane Villa ... https://www.linkedin.com/in/unity-payton-b9403231 https://www.link...*

- **[Créativité responsable et états attentionnels de conscience ...](https://theses.hal.science/tel-04402671v1/file/2022LIMO0081.pdf)**
  - Source: theses.hal.science
  - *Jan 18, 2024 ... Grégoire, L. Lachance et L. Richer (dir), La présence attentive ... unity and diversity of executive functions and their contribution...*

- **[UCLA Electronic Theses and Dissertations](https://escholarship.org/content/qt17g754d0/qt17g754d0.pdf)**
  - Source: escholarship.org
  - *Search of Unity (San Jose, CA: Pele Yoetz Books, 1987). Theses include ... Gregoire, “L'Affaire Mantout-Sifico,” La Juif Algerienne,. (Paris?: 1889), ...*

- **[Les Archives du mercredi 3 décembre 2025 des actualités Ouest ...](https://www.ouest-france.fr/archives/2025/03-decembre-2025/)**
  - Source: ouest-france.fr
  - *5 days ago ... Saint-Grégoire. L'association Entreprendre+ ... Le festival Unity revient avec une quinzaine de DJ's à la discothèque Le Malvern à Arzo...*

- **[INDEX BIBLIOGRAPHICUS 1971](https://arsi.jesuits.global/wp-content/uploads/2022/05/IBSI-1971.pdf)**
  - Source: arsi.jesuits.global
  - *... Unity, 426-437. • Deliver Us from Evil: The So- cial Welfare Mission of ... Grégoire l'llluminateur, 387-. 418. • Un corpus de l'hagiographie géor...*

---

*Generated by Founder Scraper*
