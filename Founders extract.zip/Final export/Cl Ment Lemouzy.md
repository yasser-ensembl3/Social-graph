# Clément Lemouzy

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399965567786364928 | Text |  |  | 🎉 Always a pleasure to see something come out of development to production.
A brand new version of 𝐖𝐞𝐚𝐫𝐚𝐛𝐥𝐞 – 𝐕𝐢𝐫𝐭𝐮𝐚𝐥 𝐃𝐫𝐞𝐬𝐬𝐢𝐧𝐠 is available as of today, with new feature and enhanced item creation.

📲 Don't miss out and download or update to the latest version of the app now!

💭 Do not hesitate to review, share and rate, it's greatly appreciated! | 7 | 1 | 1 | 1w | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:37.212Z |  | 2025-11-28T00:21:16.072Z | https://www.linkedin.com/feed/update/urn:li:activity:7399465720197304320/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391855212308885504 | Text |  |  | 🚀 Another milestone for Wearable after a release on Android earlier last month!

📈 Happy to see some organic growth of our users without doing any marketing or promoting of the app yet. 
💡 Highlighting the fact that the app is attracting and retaining users with only its core (and easy to use) features!

Many things are being developed, and coming this winter, stay tuned 😉 | 18 | 1 | 0 | 1mo | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:37.212Z |  | 2025-11-05T15:13:36.643Z | https://www.linkedin.com/feed/update/urn:li:activity:7391836702094368768/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7380961885635895296 | Text |  |  | English will follow

🚀 Nouveau jalon pour ExoPM Solutions et notre application 𝐖𝐞𝐚𝐫𝐚𝐛𝐥𝐞 - 𝐃𝐫𝐞𝐬𝐬𝐢𝐧𝐠 𝐕𝐢𝐫𝐭𝐮𝐞𝐥 !
Très fier encore de présenter cette fois-ci l'application avec son lancement sur Android.

📈 Notre acquisition utilisateur augmente tranquillement et cette sortie sur Android va nous permettre de focaliser maintenant notre développement sur de nouvelles fonctionnalités pour nos utilisateurs !

👖 Profitez de Wearable sur votre plateforme favorite et n'hésitez pas à nous donner vos retours !

--------------------------------------------------------------------------------

🚀 New milestone for ExoPM Solutions and our app 𝐖𝐞𝐚𝐫𝐚𝐛𝐥𝐞 – 𝐕𝐢𝐫𝐭𝐮𝐚𝐥 𝐃𝐫𝐞𝐬𝐬𝐢𝐧𝐠!
Once again very proud to present the app with this time its release on Android.

📈 Our user acquisition grows steadily and this Android release will allow us to focus our development on new interesting features for our users!

👖Enjoy Wearable on your favorite platform and do not hesitate to give us your feedback! | 14 | 1 | 1 | 2mo | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:37.213Z |  | 2025-10-06T13:47:25.176Z | https://www.linkedin.com/feed/update/urn:li:activity:7380957800476073985/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7369794209849061377 | Image |  | https://media.licdn.com/dms/image/v2/D5610AQF7DWJfCLzr7A/image-shrink_800/B56Zka0njqHkAc-/0/1757091626190?e=1765785600&v=beta&t=W-6GPF5_Y9SYbc4_p_U619i-lcXWitiJEwLvi5qrPxQ | Join BBC on September 20th in Montreal (Angrignon Park) to participate in Canada Walks for Bladder Cancer! 🚶‍♂️ 
I will be participating as a volunteer !
Sign up or donate here: https://lnkd.in/eRNZqtbx 
#Walk #Montreal #Events #BladderCancer
---
Rejoignez BCC le 20 septembre à Montréal (Parc Angrignon) pour participer à l'événement Le Canada marche contre le cancer de la vessie! 🚶‍♂️ 
Je participerai en tant que bénévole! 
Vous pouvez vous inscrire ou faire un don ici : https://lnkd.in/eRNZqtbx
#Marche #Montréal #Événements #CancerDeLaVessie | 8 | 0 | 0 | 3mo | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:37.214Z |  | 2025-09-05T18:11:03.783Z | https://www.linkedin.com/feed/update/urn:li:activity:7369776529125408768/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7355936159585247232 | Article |  |  | 🇺🇸/🇬🇧 English will follow

🇫🇷  C'est avec beaucoup de plaisir que je vous partage la toute première création de notre entreprise, 𝐖𝐞𝐚𝐫𝐚𝐛𝐥𝐞 - 𝐝𝐫𝐞𝐬𝐬𝐢𝐧𝐠 𝐯𝐢𝐫𝐭𝐮𝐞𝐥. Vous trouverez dans le post ci-dessous tous les détails concernant l'application.

Après plus d'un an et demi de développement et d'administratif ici au Canada nous avons enfin sorti avec mon ami, une application qui n'est que le début de notre aventure.

Endosser toutes les casquettes de dév, testeur, designer, utilisateur et fondateur est parfois challengeant mais tellement récompensant ! Cela peut paraître cliché mais nous apprenons chaque jour et beaucoup est à venir donc restez à l'affût !

💻  𝐓𝐞𝐜𝐤 𝐬𝐭𝐚𝐜𝐤: 𝐃𝐚𝐫𝐭, 𝐅𝐥𝐮𝐭𝐭𝐞𝐫, 𝐅𝐢𝐫𝐞𝐛𝐚𝐬𝐞, 𝐆𝐨𝐨𝐠𝐥𝐞 𝐂𝐥𝐨𝐮𝐝, 𝐢𝐎𝐒, 𝐀𝐧𝐝𝐫𝐨𝐢̈𝐝

🇺🇸/🇬🇧 It's with great pleasure that I share with you the very first creation of our company, 𝐖𝐞𝐚𝐫𝐚𝐛𝐥𝐞 - 𝐯𝐢𝐫𝐭𝐮𝐚𝐥 𝐝𝐫𝐞𝐬𝐬𝐢𝐧𝐠. You can find in the post below all the info regarding the app.

After more than a year and a half of development and paperwork here in Canada, we finally released with my friend, an app that is just the beginning of our adventure.

Wearing all the hats of dev, tester, designer, user and founder is sometimes challenging but so rewarding! This can sound like a cliché but we learn everyday and more to come, so stay tuned! | 31 | 2 | 1 | 4mo | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:37.215Z |  | 2025-07-29T12:24:07.130Z | https://apps.apple.com/us/app/wearable-virtual-dressing/id6740461062 |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7354570232918593536 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | I’m happy to share that I’m part of a new journey as Co-Founder at ExoPM Solutions ! | 49 | 7 | 1 | 4mo | Post | Clément Lemouzy | https://www.linkedin.com/in/clemlmz | https://linkedin.com/in/clemlmz | 2025-12-08T07:03:39.271Z |  | 2025-07-25T17:56:24.835Z |  |  | 

---

