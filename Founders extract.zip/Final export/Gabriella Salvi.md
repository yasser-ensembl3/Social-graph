# Gabriella Salvi

## Position actuelle

**Titre** : Founder + Creative Director
**Entreprise** : Wearshop
**Durée dans le rôle** : 7 years 1 month in role
**Durée dans l'entreprise** : 7 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Retail

## Description du rôle

Founder and designer of e-commerce handbag leather brand recognized by numerous publications such as Vogue, Elle, Globe and Mail, La Presse, Tatler and more. Prioritize sustainable production by using Italian high-end surplus leather rolls, made in Canada. I have had the opportunity to be selected for the Shopify x Coralus Cohort of 2022/2023, the Futurpreneur Growth Accelerator of 2023, and win La Bourse D'Honneur issued by le Ministère de l'Économie et de l'Innovation du Québec in 2020. As a sustainable fashion advocate, I enjoy participating in the Fashion Talks conversations on sustainability, eco-design and innovation during my visits at Lineapelle Milano, Italy.

## Résumé

I’m a creative professional with a knack for turning complex challenges into innovative solutions.  I bring a unique blend of creativity, strategic thinking, and organizational expertise to every project. From designing standout products to leading complex initiatives, I thrive at the intersection of vision, execution, and collaboration—delivering impactful results that drive growth and foster lasting connections.

Key Skills
◽️ Creative leadership: Lead design and brand initiatives that increased brand visibility and customer loyalty. Featured in Vogue, Elle, Tatler, and more.
◽️ Relationship building: Cultivate lasting relationships with clients, suppliers, and cross-functional teams, creating an environment of trust and collaboration.
◽️ Project coordination & management: Expertly manage timelines, budgets, and teams to successfully execute complex projects on schedule and within budget.
◽️ Brand management: Develop and execute brand strategies and social media campaigns that amplified brand presence and deeply engaged audiences.
◽️ Client-centric approach: Built high-value partnerships and delivered personalized customer experiences.
◽️ Strategic problem-solving: Successfully manage projects from inception to completion, ensuring seamless execution, on-time delivery.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAB8fOgwBawZFCEwqyCRqP9y7R5KG61gzpT4/
**Connexions partagées** : 17


---

# Gabriella Salvi

## Position actuelle

**Entreprise** : Wearshop

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Gabriella Salvi
*Wearshop*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Soulful Couture Podcast](https://www.deezer.com/en/show/818372)
- Category: article

### [Soulful Couture Podcast - Libsyn](https://soulfulcouture.libsyn.com/radiopublic)
- Category: article

### [](https://soulfulcouture.libsyn.com/interview-with-gabriella-salvi-founder-of-wearshop)
- Category: article

### [Made in Canada Handbags](https://wearshop.ca/)
*2025-01-01*
- Category: article

### [Wearshop | LinkedIn](https://ca.linkedin.com/company/wearshop-handbags)
*2025-03-21*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Wearshop: Made in Canada Handbags](https://wearshop.ca/)**
  - Source: wearshop.ca
  - *Wearshop Interviews NYC Food Content Creator Jo... January 14 ... Wearshop is a premium handbag brand created by founder and designer Gabriella Salvi....*

- **[Sacs à main fabriqués au Canada – Wearshop](https://wearshop.ca/fr)**
  - Source: wearshop.ca
  - *In this exclusive interview, she reveals how ... Wearshop est une marque de sacs à main haut de gamme créée par la fondatrice et designer Gabriella Sa...*

- **[Montreal-based handbag brand designs for the 'woman-on-the-go ...](https://vancouversun.com/life/fashion-beauty/style-qa-montreal-based-handbag-brand-designs-for-the-woman-on-the-go)**
  - Source: vancouversun.com
  - *Sep 30, 2021 ... When the pandemic prompted the end of after-work happy hour for many, Gabriella Salvi pivoted her brand to accommodate this new reali...*

- **[Gabriella Salvi Email & Phone Number | Wearshop Founder + ...](https://rocketreach.co/gabriella-salvi-email_96812026)**
  - Source: rocketreach.co
  - *Gabriella Salvi, based in Montreal, QC, CA, is currently a Founder + Creative Director at Wearshop. Gabriella Salvi brings experience from previous ro...*

- **[Top 5 Canadian luxury handbag brands you should know in 2026 ...](https://anscel.com/blogs/anscel-blog/canadian-luxury-handbag-brands-you-should-know)**
  - Source: anscel.com
  - *WEARSHOP is the third brand to make it to this list of Canadian luxury handbag brands you should know. Designer Gabriella Salvi ... See you in the nex...*

- **[36 Handbag Brands in Canada: A Blend of Sustainability, Luxury ...](https://truecanadianfinds.com/handbag-brands-in-canada/)**
  - Source: truecanadianfinds.com
  - *Feb 15, 2024 ... Wearshop, led by Gabriella Salvi, focuses on creating sleek ... Article Rating. Subscribe. Login. Notify of. new follow-up comments, ...*

- **[13 Thương Hiệu Canada Bạn Không Thể Bỏ Lỡ – KIREI & HANSAMU](https://kirei.vn/blogs/bai-viet/13-thuong-hieu-canada-ban-khong-the-bo-lo)**
  - Source: kirei.vn
  - *Apr 21, 2023 ... ... blog. Giày dép hàng hiệu ... Nhà thiết kế có trụ sở tại Montreal, Gabriella Salvi và nhóm Wearshop của cô ấy đều nói về nền kinh ...*

---

*Generated by Founder Scraper*
