# Fellipe Beckman

## Position actuelle

**Titre** : Founder
**Entreprise** : synkr.pro
**Durée dans le rôle** : 6 months in role
**Durée dans l'entreprise** : 6 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Technology, Information and Internet

## Description du rôle

From dailies to final delivery. Synkr streamlines your creative pipeline. Review, collaborate, and share. Faster. Clearer. Together.

## Résumé

Hey, I'm Fellipe Beckman, a CG Build Supervisor. I recently led the LookDev team for "Aquaman: Lost Kingdom" and worked as the Build Supervisor on "Godzilla vs Kong: The New Empire." I've contributed to films like "Alita: Battle Angel," "Army of the Dead," "The King," and "Maleficent: Mistress of Evil." Filmmaking is my passion, and I enjoy pushing the boundaries of visual storytelling.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA3S41wBgDdaJpCBcsXjpdxK9hx4cyL8Vas/


---

# Fellipe Beckman

## Position actuelle

**Entreprise** : Lightfarm Studios

## Localisation & Industrie

**Localisation** : Brazil

## Connexion

**Degré de connexion** : 2nd


---

# Fellipe Beckman

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402485141748477952 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHFF95LQN9Ziw/feedshare-shrink_800/B4EZrrpAm7HgAg-/0/1764889987776?e=1766620800&v=beta&t=89mb7hgUuPUQuMqs3yVGiCI4IeWB8QKVypMSJXjc7w4 | Looking for Makeup FX / Prosthetics Recommendations

Hi everyone, I’m looking for strong recommendations for Makeup FX and Prosthetics artists to support an upcoming project.

We need to transform an actor into someone completely unrecognizable, aiming for a high-end cinematic result similar to the reference image in the post. We’re specifically looking for professionals experienced in:
 •	Advanced prosthetics
 •	Full character transformation
 •	Aging or major facial alteration
 •	Realistic film/TV makeup FX

If you’ve worked with someone talented, or if you’re a Makeup FX artist yourself, please feel free to drop a name, link, or portfolio in the comments or send me a message.

Thanks in advance, excited to connect with amazing artists!

Reference image below for visual direction. | 13 | 3 | 1 | 3d | Post | Fellipe Beckman | https://www.linkedin.com/in/fellipe-beckman-73880765 | https://linkedin.com/in/fellipe-beckman-73880765 | 2025-12-08T07:19:16.820Z |  | 2025-12-04T23:13:09.316Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394475822046420993 | Text |  |  | Projeto super bacana! | 2 | 0 | 0 | 3w | Post | Fellipe Beckman | https://www.linkedin.com/in/fellipe-beckman-73880765 | https://linkedin.com/in/fellipe-beckman-73880765 | 2025-12-08T07:19:16.821Z |  | 2025-11-12T20:46:58.693Z | https://www.linkedin.com/feed/update/urn:li:activity:7394464881749426176/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7379607555440025602 | Celebration |  | https://media.licdn.com/media/AAYABAQSAAgAAQAAAAAAAPM41Z-zuuvJS9m99HWxVRhsbg.gif | I’m happy to share that I’m starting a new position as Director/VFX Supervisor! | 168 | 35 | 0 | 2mo | Post | Fellipe Beckman | https://www.linkedin.com/in/fellipe-beckman-73880765 | https://linkedin.com/in/fellipe-beckman-73880765 | 2025-12-08T07:19:16.822Z |  | 2025-10-02T20:05:47.695Z |  |  | 

---



---

# Fellipe Beckman
*Lightfarm Studios*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [ArtStation - A QUICK GUIDE FOR LOOKDEV ARTIST  Part-1](https://www.artstation.com/blogs/fellipebeckman/YMOL/a-quick-guide-for-lookdev-artist-part)
*2019-04-06*
- Category: blog

### [In the Artist's Studio: Felipe Ribeiro's Creative Journey Unveiled - Fox Render Farm](https://www.foxrenderfarm.com/news/in-the-artist-studio-felipe-ribeiro-creative-journey-unveiled/)
*2025-02-14*
- Category: article

### [EP38 Filipe Teixeira Interview by Digital Artcast](https://creators.spotify.com/pod/profile/digitalartcast/episodes/EP38-Filipe-Teixeira-Interview-e7pbar)
*2024-11-13*
- Category: podcast

### [Lightfarm Studios](https://lightfarm.com.br/)
*2024-12-16*
- Category: article

### [Sweet realism and nostalgic motion: The work of Felipe Pavani and Mike Laptev](https://garagefarm.net/case-studies/sweet-realism-and-nostalgic-motion-the-work-of-felipe-pavani-and-mike-laptev)
*2026-06-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Unhide Conference o maior festival de arte digital da América Latina](https://seriesemcena.com.br/?p=37303)**
  - Source: seriesemcena.com.br
  - *Sep 25, 2019 ... No time brasileiro, passarão por lá Fellipe Beckman, profissional ... Lightfarm Studios. Todas essas atividades são abertas ao públic...*

- **[Profissionais de arte digital e entretenimento se reúnem em São ...](https://seriesemcena.com.br/noticias/profissionais-de-arte-digital-e-entretenimento-se-reunem-em-sao-paulo-para-a-unhide-conference/)**
  - Source: seriesemcena.com.br
  - *Sep 28, 2019 ... No time brasileiro estão Fellipe Beckman, maranhense que foi ... Lightfarm Studios, e um dos principais idealizadores do evento. Na ....*

---

*Generated by Founder Scraper*
