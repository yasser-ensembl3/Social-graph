# Nadine Vallee

## Position actuelle

**Titre** : Directrice Services-Conseils
**Entreprise** : Intelli5
**Durée dans le rôle** : 1 year in role
**Durée dans l'entreprise** : 1 year in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Résumé

Je possède plus de 20 ans d'expérience dans le domaine du service-conseil, notamment en TI, en ressources humaines, en administration et récemment en sécurité financière.

Ma mission est d'humaniser le service-conseil et de réinventer le rôle de conseillère axée sur les vrais besoins des clients.

Je m'appuie sur mes compétences en expérience client, en développement d'affaires, et en relations humaines. 

Je suis également une artiste joaillière et la fondatrice de Naïoa - Porter la forêt, une entreprise qui crée des bijoux inspirés de la nature et qui a une mission éducative. Je suis passionnée par la nature, la simplicité et la qualité.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAJoRWMBcTBcuYc5pZlleiPZMWmKi_pbZZc/
**Connexions partagées** : 39


---

# Nadine Vallee

## Position actuelle

**Entreprise** : Intelli5

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nadine Vallee

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396601533641039872 | Text |  |  | Je recommande personnellement Kadiatou!! | 10 | 1 | 0 | 2w | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:53.569Z |  | 2025-11-18T17:33:47.831Z | https://www.linkedin.com/feed/update/urn:li:activity:7396330990744346624/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7333515530361782277 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABqdcB5EZ18gQPCF4HzBOFBBhw.gif | J’ai le plaisir de vous annoncer que j’ai obtenu une nouvelle certification : Partner Training - Advantages of the Lakehouse de Databricks ! | 34 | 21 | 0 | 6mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:53.571Z |  | 2025-05-28T15:32:32.568Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7325886707239690240 | Text |  |  | Fanny Valette #recrute. Connaissez-vous quelqu’un qui pourrait être intéressé ? | 4 | 0 | 0 | 7mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.660Z |  | 2025-05-07T14:18:19.399Z |  | https://www.linkedin.com/jobs/view/4225358466/ | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7325278239449387008 | Text |  |  | Pour un ami!! Merci | 0 | 0 | 0 | 7mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.660Z |  | 2025-05-05T22:00:29.373Z | https://www.linkedin.com/feed/update/urn:li:activity:7325272227912769536/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7323703555121455105 | Text |  |  | Fanny Valette #recrute. Connaissez-vous quelqu’un qui pourrait être intéressé ? 

Rejoignez nous!! | 5 | 0 | 0 | 7mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.661Z |  | 2025-05-01T13:43:15.373Z |  | https://www.linkedin.com/jobs/view/4220199503/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7315029171057946624 |  |  |  |  | 4 | 0 | 0 | 8mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.661Z |  | 2025-04-07T15:14:21.050Z |  | https://www.linkedin.com/jobs/view/4203106895/ | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7313204588570988544 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGNF_kPh2XBow/feedshare-shrink_800/B4EZX19dt9GgAk-/0/1743588285970?e=1766620800&v=beta&t=NDpoGliqK9XE16TdfxxyGE90XcQsE8mrb2Y-ORRh5Rk | Une critique constructive permet de créer une relation de confiance et un désir d'avancer, de s'améliorer. L'inverse, provoquera une démotivation et une régression.. Pensez-y lorsque vous vous adressez à vos employés! | 4 | 0 | 0 | 8mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.662Z |  | 2025-04-02T14:24:06.686Z | https://www.linkedin.com/feed/update/urn:li:activity:7313139325464924161/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7310296199318634499 | Text |  |  | Fanny Valette #recrute. Connaissez-vous quelqu’un qui pourrait être intéressé ? | 3 | 0 | 0 | 8mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.663Z |  | 2025-03-25T13:47:12.653Z |  | https://www.linkedin.com/jobs/view/4192876289/ | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7308863142556585985 | Text |  |  | Bon vendredi à tous! 

Je me tourne vers vous aujourd'hui car la nièce d'une amie cherche un stage d'été dans le domaine du design de communication ou de publicité, du 12 mai au 8 août environ. Étudiante en design à l'Université polytechnique de Hong Kong, actuellement en deuxième année et spécialisée en design de communication, cette brillante jeune femme serait sans l'ombre d'un doute un ajout intéressant pour votre entreprise cet été. Notez qu'elle est quadrilingue (anglais, français indonésien et mandarin)!!

Écrivez moi si vous souhaitez en savoir plus et merci de partager !! | 4 | 0 | 0 | 8mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.664Z |  | 2025-03-21T14:52:45.296Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7304184955117457409 | Text |  |  | C’est la journée internationale des droits des femmes et j’aimerais souligner mes collègues d’exceptions. 

Quel bonheur de travailler avec ces magnifiques et professionnelles femmes! Fanny Valette Candice Thueux Inesse Bencheikh Sandrine Lacaud Reem Eissa Saida AIT HADJI 

🌸🌼🌹🌷 | 16 | 0 | 1 | 8mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.664Z |  | 2025-03-08T17:03:18.494Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7303807245736169472 | Text |  |  | Communiquez avec moi!! | 5 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.665Z |  | 2025-03-07T16:02:25.560Z |  | https://www.linkedin.com/jobs/view/4178603003/ | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7302338001286619137 | Text |  |  | N'hésitez pas à communiquer avec nous! | 2 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.665Z |  | 2025-03-03T14:44:10.386Z | https://www.linkedin.com/feed/update/urn:li:activity:7301376051509645313/ | https://www.linkedin.com/jobs/view/4171322346/ | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7300624110752006144 | Text |  |  | Fanny Valette #recrute. Connaissez-vous quelqu’un qui pourrait être intéressé ? | 7 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.666Z |  | 2025-02-26T21:13:47.040Z |  | https://www.linkedin.com/jobs/view/4168645013/ | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7299169692311535616 | Article |  |  | Communiquez avec Marie-Claude! | 0 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.666Z |  | 2025-02-22T20:54:26.662Z | https://www.quebec.ca/entreprises-et-travailleurs-autonomes/administrer-gerer/embauche-gestion-personnel?utm_campaign=promotion-services-publics-emploi-services-entreprises-1019506&utm_medium=paid-social&utm_source=linkedin&utm_content=image-spe-1-fr |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7296284374700834818 | Text |  |  | Fanny Valette #recrute. Connaissez-vous quelqu’un qui pourrait être intéressé ? | 2 | 0 | 1 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.666Z |  | 2025-02-14T21:49:13.337Z |  | https://www.linkedin.com/jobs/view/4153429169/ | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7295824417979289600 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHktQ-DhXzy5Q/feedshare-shrink_800/B56ZT_2Iv1HoAg-/0/1739459170452?e=1766620800&v=beta&t=sG0Het4oQlEPTMjzHCzmQ-Agf-IYL_qhoX3EK9xHXWE | Partagez svp!! | 0 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.667Z |  | 2025-02-13T15:21:31.109Z | https://www.linkedin.com/feed/update/urn:li:activity:7295820563128692736/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7294829139302199297 | Text |  |  | Je recommande caroline dans un poste RH!! C'est une perle pour votre entreprise. | 0 | 0 | 0 | 9mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.667Z |  | 2025-02-10T21:26:38.181Z | https://www.linkedin.com/feed/update/urn:li:activity:7294826401495494657/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7288703541198610432 | Text |  |  | Un beau poste dans une belle équipe et dans une belle entreprise bien de chez nous!! | 4 | 0 | 1 | 10mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.668Z |  | 2025-01-24T23:45:41.785Z | https://www.linkedin.com/feed/update/urn:li:activity:7288698679215939584/ | https://www.linkedin.com/jobs/view/4133242568/ | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7282479768950779904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFjN5-ob67CbQ/feedshare-shrink_800/B4EZRCQwt1GcAk-/0/1736278478127?e=1766620800&v=beta&t=p2g-ZY9kfKoRQ8UsSbHpwBM2ZrURys11kDsylBaZGTQ | J'ai choisi de rejoindre Intelli5 parce que j'adhère pleinement à leur valeurs :

« Révolutionner le service, cultiver les talents, façonner l’avenir pour les leaders de l’industrie – en harmonie avec nos valeurs fondamentales d’intégrité, de collaboration et d’innovation incessante. » 
- https://lnkd.in/ecq9kusN

Dans mon parcours, j'ai souvent ressenti que la transparence et l'intégrité n'étaient pas nécessairement pleinement respectées dans le domaine du Services Conseils, et cela m'a toujours interpellé. Rien n'égale la satisfaction de voir un projet client non seulement réussir, mais même dépasser ses attentes!
La fierté d’avoir négocié un contrat après une véritable écoute et compréhension des besoins du client. L'accomplissement de l'accompagner bien au-delà de ses attentes initiales et de contribuer à son succès dans l'innovation et la transparence.

Et vous, ces valeurs résonnent-elles avec vous ? Est-ce l'accompagnement que vous recherchez ? | 49 | 1 | 0 | 11mo | Post | Nadine Vallee | https://www.linkedin.com/in/nadinevallee | https://linkedin.com/in/nadinevallee | 2025-12-08T07:05:56.668Z |  | 2025-01-07T19:34:38.849Z |  |  | 

---



---

# Nadine Vallee
*Intelli5*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [Managed services | Intelli5](https://intelli5.com/en/services/managed-services/)
*2023-11-29*
- Category: article

### [Intelli5 Information](https://rocketreach.co/intelli5-profile_b4780556fc302431)
*2025-01-01*
- Category: article

### [Nadine from CanDo Content chats Copywriting and Audience Intel | Jessica Haines Design](https://jessicahainesdesign.com/blog/nadine-cando-content-interview)
*2024-08-02*
- Category: blog

### [Friends of attract: Nadine O’Regan from TQSolutions (Part 2)](https://attract.ai/interview-part-2-the-future-of-talent-acquisition/)
*2022-11-01*
- Category: article

### [Connectedness and Openness: A Company’s Most Powerful Tools - Nadine Hack - CEO, Speaker, Connector, Author, Strategist](https://www.workvivo.com/it/resource/theemployeeexperiencepodcast-nadine-hack/)
*2025-01-01*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Sandrine Lacaud Email & Phone Number | Intelli5 Directrice ...](https://rocketreach.co/sandrine-lacaud-email_116368622)**
  - Source: rocketreach.co
  - *Intelli5 Employee Nadine Vallee's profile photo · Nadine Vallee. Directrice ... Blog · Contact Us. © 2025 RocketReach.co....*

---

*Generated by Founder Scraper*
