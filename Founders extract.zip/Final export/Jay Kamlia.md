# Jay Kamlia

## Position actuelle

**Titre** : Founder
**Entreprise** : TheOnePlan
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Résumé

Dreamer & follower of faith. 

I pursue monumental improvements in society, these currently translate to being:

1) Automating the services industry via Anantya
2) Improving financial education via TheOnePlan
3) Improving financial service via PKWEALTH
4) Improving sales & marketing for businesses via InstantSales
5) Improving the real estate purchase experience via OpenDoorNetwork

If I can be of any help, please don’t be shy to connect.

Thanks,
JK

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAvTe3oBnPoDJZXgdXuygPSACJIVF6Npcp4/
**Connexions partagées** : 19


---

# Jay Kamlia

## Position actuelle

**Entreprise** : TheOnePlan

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jay Kamlia

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396557931627827200 | Article |  |  | 🐢 Slow like a turtle we move.
🎢 But the progress is undeniable. 
⭐ TheOnePlan continues to create massive financial success for everyday people.

#money #success 
https://lnkd.in/eiR5HQTa | 14 | 1 | 0 | 2w | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.189Z |  | 2025-11-18T14:40:32.301Z | https://www.youtube.com/watch?v=fp03SXo8kz0 |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7390791178264211456 | Text |  |  | Self Actualized people ARE 
distinguished by this ONE TRAIT:

“They MUST be, what they CAN be”

🔥🔥🔥🔥🔥🔥🔥🔥🔥🔥

Rip Abraham Maslow & Wayne Dyer | 9 | 0 | 0 | 1mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.190Z |  | 2025-11-02T16:45:31.158Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7378501404132392960 | Article |  |  | AI Employees for Financial Advisors 👀 👀 👀 

https://lnkd.in/enY45K4G | 5 | 0 | 0 | 2mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.190Z |  | 2025-09-29T18:50:20.672Z | https://www.youtube.com/watch?v=zuQt3Vu3n_4 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7375908644208549889 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFWTlS4yX8MkQ/feedshare-shrink_800/B4EZlx90eFHoAk-/0/1758553657321?e=1766620800&v=beta&t=E_ywroqWdg-NoBV4pQnOjvm4o079Z3_6RDX7WkvmtFg | I lost a basketball finals game this weekend.

We were ranked #2 team in league vs opponent was ranked #1. Arguably, we thought we were better; we were tougher & had guys who had previously played higher level basketball, the opponent was younger & faster.

My prep work during the week for the game was weak; I exercised a couple times, but nothing too intense & game prep worth. I had mentally accepted that the 3 best players on our team would do the heavy lifting & I would support them minimally to get us the win. Horrible idea.

During the game, 2 of our 3 best players were having a good game, but the 3rd player was struggling & needed another player to step up their performance. Problem was, no one was ready to step up, including me. 

Worse than that, I had responsibility of guarding one of the opponents best players, & he torched me, scored important baskets on me because my level of focus, attention, relentless drive to win & not be outcompeted was weak.

My lessons from the event: 

1)Part of me wanted the other team to win cause they were younger and I thought they could use the confidence boost - our team was older & we already won a lot in ball & in life - Advice: Don't be part of things if you don't truly want to win at them - you hurt others chances of winning those things.

2)I believe our victory was a done deal because of the talented players on our team. Advice: Don't overly rely on others & be lazy because of it - Always prepare like a pro & be ready to shine & take center stage. You don't know when your opportunity to handle heavy responsibility will come, but you should be ready, prepared, & confront the big challenges during the game - never back down & expect to win because of your preparation.

#life #success #business #victory | 16 | 0 | 0 | 2mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.191Z |  | 2025-09-22T15:07:38.535Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7373303065661034496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFBk7pV9BMtig/feedshare-shrink_800/B4EZlM8ENUIQAg-/0/1757932439187?e=1766620800&v=beta&t=WzYFsRxZQNQTgjMTb2pk2rqdnqBgVUo0MVtvJ7ji_Q0 | For entrepreneurs creating their business or open to “disrupting” their own business:

Agentic AIs are predicted as the next “big thing” in tech.  Helping you to automate your business model.

The technology seems super valauble. We’re implementing @TheOnePlan & will keep you up to date with developments!

#ai | 6 | 2 | 1 | 2mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.191Z |  | 2025-09-15T10:34:00.200Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7367147201950613504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFeOLQhO7PMiA/feedshare-shrink_800/B4EZj1dTqdIUAg-/0/1756464766559?e=1766620800&v=beta&t=4J8um-GGY0kwJyC5TfnYJtc2OGxUxA1aAa8lfczWPbg | Brotherhood. 

It’s been lovely.

Words cannot fully explain the gratitude I have for having such an awesome brother, but let me explain 3 ways why we SHOULD try to develop relationships like this with all our business partners.

🥊 No BS relationship. 
We are always able to communicate the harshest of truths even if it means hurting each other’s feelings, badly. Your sales suck, your operations suck, your service sucks, “per the data”, here is how we can improve it, “solutionize mindset”.

🤠 Bounce back quick. 
Over 25 years, biggest time we have spent upset at each other has been max 2 weeks. Don’t hold grudges & know that the relationship is worth more than any dispute you have. Work quickly to resolve any hurt feelings & always communicate how much you value each other’s business, & how you will continue having each other’s back.

⭐ Biggest supporter.
In a real, real brotherhood (or sisterhood), you know this person has your back, no matter what (well unless you do some illegal things lol). However, in a special brotherhood, like the one I share with mine, I know this person is one of the biggest strengths, if the not the biggest in my life. This is through continuous support in all the major down moments. Not let me give you a hug, but a kick in the butt to keep it moving. For your business partners, keep encouraging their business growth, & help them achieve it.

#business #success 
Karan Kamlia | 61 | 2 | 1 | 3mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:28.192Z |  | 2025-08-29T10:52:47.921Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7354308076503539712 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHwU3S9UQf9zA/feedshare-shrink_800/B4EZg_AOLeGwAg-/0/1753403680237?e=1766620800&v=beta&t=bGbWMwG6nT6W9GlQxKUcbUG5XQyhW6-GLJo9VadKvFM | Building a fintech startup, has been….


One of the most rewarding experiences of my life. A platform for eternal self growth and market connection. Abundance of new life and business lessons. 

A special lesson learnt recently:

“Sales / Technology  / Marketing  combination has formed the most powerful weapon we have in revolutionising the world.”

1- How consistently is your client educated on the benefits of your service 

2- How consistently do you build innovative technology to deliver greater service 

3- How consistently does your client see and connect with your brand 


Let the beautiful journey continue 🐉 🐍 🐯 Karan Kamlia Rutvij Dodiya | 34 | 1 | 1 | 4mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.045Z |  | 2025-07-25T00:34:41.875Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7350947199679111169 | Article |  |  | How financially literate are you?

https://lnkd.in/eyEMtuQE | 19 | 1 | 2 | 4mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.045Z |  | 2025-07-15T17:59:46.398Z | https://www.youtube.com/shorts/On2lomiTSoM |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7335760407980105728 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEOKu1DCXZVXQ/feedshare-shrink_800/B4EZc3bNN_HsAk-/0/1748981570707?e=1766620800&v=beta&t=6JEmQHA9HvL2_jIfrXeEMcImrUhvPOJRaxFOOZSXnGI | 🔥 🔥 🔥 🔥 🔥  We're on fireeeeeeeeee 

Or at least that's what we tell ourselves after the intense month of May at TheOnePlan..

🚘 30+hrs of car rides across Toronto & NewYork to meet with top universities to solve the financial literacy issue amongst young adults 
🥸 Hundreds of student & adult interviews to confirm value of TheOnePlan 
🙄 Met with investors who kept emphasizing "Monetization" 
💰 We got funded by the government of Canada via Futurpreneur 
😎 Signed more North American universities to partnerships 
📚 Presented at #WebSummitVancouver as Impact Startup helping improve financial literacy in the world 
👏Updated our application to provide educational content & advanced financial knowledge 

We're just beginning, we know the journey may be long, however our resilience on becoming the leader in the financial literacy space will not be lost, here we come!!
 Karan Kamlia | 115 | 14 | 2 | 6mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.047Z |  | 2025-06-03T20:12:53.100Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7320806168707096576 | Article |  |  | 50% of USA is financially illiterate & 70% of people struggle with risk comprehension - World Economic Forum

https://lnkd.in/eBYnsC34

This means people have hard time understanding concepts like interest rates, inflation, different types of investments, different government accounts.

TheOnePlan helps to solve this major problem. By providing free personalized financial advice & financial education, we empower every person to better understand the financial options available to them to meet their unique goals. | 22 | 0 | 0 | 7mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.048Z |  | 2025-04-23T13:50:04.621Z | https://www.weforum.org/stories/2024/04/financial-literacy-money-education/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7312959893982883840 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHMJ-d7dqMgLg/feedshare-shrink_800/B4EZXzaRTBGYAk-/0/1743545506177?e=1766620800&v=beta&t=hnoAY5VASzVdBOgClsDmgxqhbTOhGteFVFITk730bgE | Exciting day today at TheOnePlan 😎 

Our wealth planning technology will now be available to Canadian University students via the Alberta University of the Arts. 

https://lnkd.in/e-C2MFqi 

Talking with university students, adults aged 18-35, we have found a common uncertainty about future financial steps. 
🫣 How to buy first house with low salary? 
👀 How to save up for retirement? 
😶  How to manage family finances?
😯 Grants/Loans available for me?

We are excited to be on a journey to empower young adults with financial technology & improve financial literacy. ⭐ ⭐ ⭐

#financialliteracy #empowerment | 60 | 1 | 2 | 8mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.049Z |  | 2025-04-01T22:11:46.950Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7300517994588176385 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFBa2xOR3I2LQ/feedshare-shrink_800/B4EZVCma2EHUAk-/0/1740579125088?e=1766620800&v=beta&t=spaZWr0kDwDMhHXTjUS6a9TH-kAPRtzl4ThZATCZL4Q | I’ve always felt I could do something special.

I believe I now have.

Since I was a child, I have been inspired by my immigrant parents working 7 days a week, 365 days a year, the real no days off type of people. They have been the flame in my heart pushing me to go through all the adversity, failures, and heartbreaks I have faced. And in their 60’s now, they still continue to work the same, so here I go. 

For them, I have promised myself that I would not be denied and I would seek out all possible opportunities to flourish & excel into the special individual that would bring the honour to my parents that I believe they deserved.  I have worked over 20 jobs, studied all possible financial curriculums I could find (failed some lol). My journey has led me here now.

After years working in wealth management: the sector of financial services which is usually reserved for the wealthy class, I got my lucky break. Overhearing colleagues saying how its hard to get a full wealth plan in a timely manner - usually it can take over 1 month to get a wealth plan where you get advice from specialists in : tax, investment, insurance, estate, retirement planning - I knew from my numerous failed entrepreneurship experiences that if there is problem, then there is an opportunity.

As they say, timing is everything. 
 I had matured, I was experienced, I understood what the market needed, and most importantly technology had evolved to solve the problem that the market was facing. 

Now - I stand here - I believe I have built the world’s leading financial planning application. Extremely useful for everyday people, finance professionals, corporations, & anyone who really wants to take their money seriously. The tool I have built provides the quality of financial advice usually reserved for the ultra wealthy to everyday people, within minutes, not months.

This is the most open I have ever been on an online platform, but shit that flame in my heart is not going away anytime soon, so I face my insecurities, the uncertainty, the possible humiliation of public failure, knowing that for my parents all these things evaporate to dust. 

TheOnePlan - “Are you serious about your money?”

https://theoneplan.net/ | 146 | 45 | 0 | 9mo | Post | Jay Kamlia | https://www.linkedin.com/in/jay-kamlia | https://linkedin.com/in/jay-kamlia | 2025-12-08T05:12:32.050Z |  | 2025-02-26T14:12:06.975Z |  |  | 

---



---

# Jay Kamlia
*TheOnePlan*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 14 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [TheOnePlan](https://www.youtube.com/channel/UC4lLMWrhQIqrHSwWGSV1msw)
*2025-05-14*
- Category: video

### [421. Living The ONE Thing with Co-Author Jay Papasan Part 1](https://the1thing.com/captivate-podcast/421/)
*2025-05-14*
- Category: podcast

### [The ONE Thing Podcast - The ONE Thing](https://the1thing.com/podcast/)
*2024-12-17*
- Category: podcast

### [The ONE Thing](https://podcasts.apple.com/ng/podcast/the-one-thing/id1191482456)
*2025-06-02*
- Category: podcast

### [Jay Papasan: The ONE Thing Co-author | EOFire](https://www.eofire.com/podcast/jaypapasan/)
*2024-08-21*
- Category: podcast

---

## 🎬 YouTube Videos

- **[JACKSON WANG in India: Behind the scenes from my upcoming episode](https://www.youtube.com/watch?v=-Ly86w0PmH8)**
  - Channel: Sakshma Srivastav
  - Date: 2025-06-12

- **[Shawn talks about his relationship with Camila. #shawnmendes #camilacabello #jayshetty](https://www.youtube.com/watch?v=g0LTf0jcsYI)**
  - Channel: Jay Shetty Podcast
  - Date: 2024-10-01

- **[Shreya Ghoshal&#39;s lovely voice &quot;Ve Kamleya&quot; #shreyaghoshal #shorts](https://www.youtube.com/watch?v=ZxZ7HFWWd9M)**
  - Channel: VLOGER SAJAL 🇮🇳
  - Date: 2025-03-25

- **[Ve Kamleya | Umesh Barot, Aakil Zariya | Bhadreshwar | Mv Studio #shorts #short](https://www.youtube.com/watch?v=ZvTOflEoEIg)**
  - Channel: Mv Studio
  - Date: 2025-01-29

- **[Kamala Harris: America Is At Breaking Point &amp; I&#39;m Deeply Concerned About The State Of The Country!](https://www.youtube.com/watch?v=D3lhrrXb4WI)**
  - Channel: The Diary Of A CEO
  - Date: 2025-10-30

- **[CHATGPT BECOMES A MUSLIM 😱😂😝 #ai #learnontiktok #quran #bible #islam #interestingfacts #funny](https://www.youtube.com/watch?v=zRyvRStvZ4c)**
  - Channel: Lily Jay
  - Date: 2024-09-12

- **[Julia Pimentel pede para Cauã não comemorar o gol mostrando a barriga #shorts #juliapimentel #casal](https://www.youtube.com/watch?v=4LIyExOm_3I)**
  - Channel: RezenCortes
  - Date: 2025-06-26

- **[CAMILA LOURES E JEAN FAZENDO DANCINHA DO TIKTOK JUNTOS!!](https://www.youtube.com/watch?v=Rq_TyDW2fms)**
  - Channel: Portal Camila Loures
  - Date: 2021-05-17

- **[Bonnie Blue is doing WHAT next?!](https://www.youtube.com/watch?v=wshVH_VpQjw)**
  - Channel: The Kat Baker Show
  - Date: 2025-05-30

- **[Ve Kamleya ...💘 Arijit Singh live in concert at cocacola arena Dubai](https://www.youtube.com/watch?v=3uvftt_DEOU)**
  - Channel: ARIJITIAN LOKI
  - Date: 2024-05-02

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
