# Julien Massot

## Position actuelle

**Titre** : Founder & Chief Executive Officer
**Entreprise** : Extramuros
**Durée dans le rôle** : 3 months in role
**Durée dans l'entreprise** : 3 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Software Development

## Résumé

I'm a founder and investor who thrives at the intersection of B2B SaaS, AI, and venture building.

I started my career by founding Ink Consulting with my co-founder Guessing, scaling it to $5M ARR and 25+ employees before successfully exiting to NRB in 2022. Nine years at Deloitte and Ink deploying CRM systems for enterprise clients taught me a crucial lesson: most B2B companies lose 80% of their leads in the gap between marketing and sales.

Today, I'm building on that insight with Extramuros and investing through Naoh Capital.

At Extramuros, we're solving the inbound qualification problem that costs B2B companies millions. We create persistent digital spaces where leads self-qualify through AI-powered conversations, turning the dead zone between first interest and sales readiness into an active qualification engine. 

With Naoh Capital, I'm backing early-stage SaaS founders through a hands-on, pre-seed fund designed to catalyze growth and deliver structured early liquidity for LPs. I focus on founders who listen to customers obsessively and pivot fast when the data demands it.

What sets me apart is knowing when to persist and when to pivot. I've built companies from scratch, navigated an exit, interviewed hundreds of customers to find real problems, and learned that the best products come from building what users pull from you, not what you push on them.

I believe in data-driven decisions, customer obsession, and surrounding myself with people who choose learning over being right.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAvvsGABi4VCq59S7gXa9-9om1KBP6awlP4/
**Connexions partagées** : 17


---

# Julien Massot

## Position actuelle

**Entreprise** : Extramuros

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Julien Massot

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398782531522957313 | Text |  |  | Most B2B companies lose their best leads in the gap between initial interest and sales readiness. 

We interviewed 100+ teams and discovered the same pattern: Leads engage initially, then disappear before they're ready to buy. 

With Guessing Vondou, we built Extramuros - persistent digital spaces for inbound qualification. 

When someone clicks your link, they land in their own space where they can: 

- Ask questions and get instant AI-powered answers 
- Return anytime to continue the conversation 
- Book a meeting when they're actually ready 

No forms. Just a space that remembers them. 

🎯 Comment EXTRA to try it yourself. | 15 | 1 | 0 | 1w | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:46.042Z |  | 2025-11-24T18:00:18.247Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7382398495959437312 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFh3UDyL3cZdw/feedshare-shrink_800/B4EZnOMTz8HgAg-/0/1760100958471?e=1766620800&v=beta&t=8aB7Tuq3myTyvc8Kp5QCK9ASRUgjXqncS1EyhFfr7Dk | Trust isn’t a feature — it’s the foundation.

I recently upgraded my plan with Apollo.io, one of the most impressive SaaS startups out there.

Their email said:
🚀 30,000+ credits, instantly available.
Plans start at $49 / month.

That “instantly available” part sold me.
Except… those credits only apply to the annual plan — something never mentioned in the email.

Now, Apollo is an amazing product (I genuinely use and recommend it).
But this moment reminded me of something deeper about SaaS:

Most trust isn’t lost through lies.
It’s lost through technical truths wrapped in emotional promises.

When you run a subscription business, every word — from pricing to onboarding — is a small contract. Break it once, and the user doesn’t just doubt your marketing; they start doubting your brand. | 6 | 2 | 0 | 1mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:46.043Z |  | 2025-10-10T12:55:59.768Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7378965090877992961 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH71wrsAoXkvQ/feedshare-shrink_800/B4EZmdZph2GoAk-/0/1759282371309?e=1766620800&v=beta&t=PVMvvk4GR9pKA3_ABcG4WGfqYJOj063-ClPkoV0cw5g | Getting feedback on a startup is harder than I thought…

At first, I asked people to test Extramuros directly. Nobody had time.

So I started booking 30-minute calls instead. Better, but still not enough.

Then I went all in: added YC founders on LinkedIn and just asked for help. That’s when things clicked — lots of meetings, lots of insights.

People told me it could work for:
👉 handling inbound leads on a website
👉 keeping prospects engaged during long sales cycles
👉 even helping in recruitment

And what everyone liked: the simplicity of giving prospects their own microsite, a space just for them.

That gave Guessing Vondou and me the confidence to open Extramuros for everyone.

It’s live & free: https://extramuros.ai/

Would love your feedback — the raw kind. | 31 | 2 | 1 | 2mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:46.043Z |  | 2025-10-01T01:32:52.207Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7374551374128365570 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQENfm-Mw79EUQ/feedshare-shrink_800/B4EZlerZcZHoAk-/0/1758230059337?e=1766620800&v=beta&t=oSqaJdOeGPKtEsm4LCGHuiLJD-993s0uEM1SKP5z6uo | Launching something new is exciting.
Launching it too early is terrifying.

This week I opened the Alpha of Extramuros. It’s not ready for customers yet — which is exactly why I need your help.

If you’re a founder or sales leader, spend 30 minutes with me. I’ll show you a test microsite, you give me your unfiltered feedback, and together we shape what comes next.

👉 https://lnkd.in/eJv4yY59 | 22 | 0 | 1 | 2mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:46.044Z |  | 2025-09-18T21:14:20.131Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7298004957834719232 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6a566d8c-8119-405c-8328-0c95a130427e | https://media.licdn.com/dms/image/v2/D4E05AQFoHklgKOVYVw/videocover-high/B4EZUe2RLyHcBs-/0/1739979306813?e=1765782000&v=beta&t=SJq64Gi7pjelQCd3zoVeeGdf0Ub34SYiVvxjQkpFM2k | As announced, a glimpse of our physical LinkedIn with AUR+A . Imagine connecting it to your Salesforce CRM and seeing in AR your client data ? | 12 | 0 | 0 | 9mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.497Z |  | 2025-02-19T15:46:12.323Z | https://www.linkedin.com/feed/update/urn:li:activity:7298002188969148416/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7296183474460229634 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFSSccM5DMWxA/feedshare-shrink_800/B4DZUEiVhuGkAg-/0/1739537870263?e=1766620800&v=beta&t=SlIdfU3zWfuafmGyGqz7ycqb-amRl6IFhnpwN85UIa8 | Richard Branson, should we have a chat ? Lot's of ideas for Virgin | 2 | 0 | 0 | 9mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.498Z |  | 2025-02-14T15:08:16.845Z | https://www.linkedin.com/feed/update/urn:li:activity:7296150654421549056/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7295229300012630016 | Video (LinkedIn Source) | blob:https://www.linkedin.com/48a87b9b-9882-45be-88d4-5fd0edad0ac5 | https://media.licdn.com/dms/image/v2/D5605AQGcIfxREFI40A/videocover-high/B56ZT0v2FaGoBs-/0/1739272983410?e=1765782000&v=beta&t=phhRyp_NVCMnMvOyPtjL4Jrdf47p02_eKrQObimmPC8 | A first significant milestone towards our vision of bringing to life the physical LinkedIn. Imagine putting on your smart glasses and viewing your CRM relationships through your glasses. Instantly knowing who is who and filtering out whom you need to meet?  Well, AUR+A will be showcasing the future at TECHARENA. | 14 | 0 | 0 | 9mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.499Z |  | 2025-02-11T23:56:43.929Z | https://www.linkedin.com/feed/update/urn:li:activity:7295039649347948544/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7292278739495714816 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF18oWNDs5oKg/feedshare-shrink_800/B4EZTNgCnBG0Ag-/0/1738614516620?e=1766620800&v=beta&t=MXmQfnrm-gv72nSpc9bFXTVkcXKDOYBYSLI7vVFMt8M | Today marks a shift for before studio — one I believe will bring great value to Quebec’s entrepreneurial community. | 14 | 1 | 0 | 10mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.500Z |  | 2025-02-03T20:32:15.483Z | https://www.linkedin.com/feed/update/urn:li:activity:7292277827666624512/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7279871860886933504 | Text |  |  | I discussed the false positive problem with Thomas Eisenmann, the author of Why Startups Fail. The idea is that one of the reasons for startup failure is that founders often misinterpret early traction for product success. While early enthusiastic adopters explain this traction, it does not generally represent a market that is big enough to guarantee product success. Founders will spend too much time tweaking their products to cater to the needs of these early clients and, in doing so, lose sight of the bigger picture. 

Tom argued that this problem could be solved with proper initial customer research, as discussed in my previous post. Understanding your customers and the market as a whole is essential when building a startup. And while engineers tend to fall in love with their solution, a good founder should fall in love with the problem he is trying to solve. I’m surprised how this could sound obvious but is often overlooked. In the last month, I’ve had the opportunity to listen to about ten startups pitching their solution. Yet only one started with the problem they were tackling: TAMs and competitions were nonexistent in the pitches. They all had incredible numbers, but none had taken the time to talk to potential customers. 

A false positive can be avoided when realizing that, yes, there is market traction because some people are enthusiastic, but that doesn’t mean that the market will follow. Good market segmentation and analysis will help understand feature prioritization while it’s still possible to pivot. 

before studio is looking for startup founders willing to talk to their clients, create a feedback loop, and implement it in their product’s core. | 6 | 0 | 0 | 11mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.500Z |  | 2024-12-31T14:51:45.114Z |  | https://www.linkedin.com/jobs/view/4109030612/ | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7278051559580524544 | Text |  |  | Startups are hard. Even with the best intentions, brilliant ideas, and passionate teams, the road to success is full of pitfalls.

I recently had the incredible opportunity to discuss this with Thomas Eisenmann, the author of "Why Startups Fail". We dove into the patterns he’s identified—like Bad Bedfellows, False Starts, False Positives—and explored how they apply in the context of a startup studio like before studio.

The conversation was eye-opening. In a startup studio, where we aim to build multiple ventures from the ground up, the stakes are high. Avoiding these common pitfalls isn’t just important—it’s essential. While I started the conversation, convinced that the startup studio model could solve all the listed problems, I was surprised by Tom’s insights. 

The first highlighted problem is called Bad Bedfellows: while the idea is good, the people executing it might not be the best fit, be that founders, partners, or any stakeholders. I was convinced that this problem was solved in a startup studio due to our rigorous selection process and the fact that founders are selected for a specific idea. This should prove a better fit than a founder having an idea but not being the right person for the job. 

Tom, however, highlighted that all recruitment processes involve biases and that matching a founder with an idea could only work if the recruiter could abstract his own biases. As we are hiring our first founders, this question is currently at the top of our minds. 

What would you believe makes for a better market fit, a founder that finds an idea or selecting a founder for an idea? 

To answer this question, I assume that founders will be equally motivated by success and give it their all wether they found the idea themselves or not. | 7 | 0 | 0 | 11mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.501Z |  | 2024-12-26T14:18:31.463Z |  | https://www.linkedin.com/jobs/view/4109030612/ | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7277861645622644736 | Text |  |  | It’s hard to believe how far we’ve come. When we started before studio, it was just an idea—a bold, slightly crazy idea—to build startups that solve actual problems and can strive. We wanted to create something new that doesn’t just build businesses but does so with a relentless focus on the client, driven by research, and executed at a pace that feels almost impossible.

The journey has been anything but easy. We’ve challenged assumptions, questioned decisions, and pushed ourselves to move faster and think deeper. We’ve spent countless hours talking to potential clients, obsessing over their needs, and ensuring we’re solving the correct problems—not just the easiest ones.

And now, here we are. After months of learning, testing, and building, we’re ready to launch our first companies.

This isn’t just a milestone for Before; it’s a moment of proof—a chance to show that what we’ve been working so hard to create can genuinely work.

But I know we can’t do this alone. Right now, I’m looking for two people to help me take this leap:
 •	A CEO who can take the lead, understand the problems faced by clients, and bring others along for the journey.
 •	A CTO who can turn vision into technology, solving challenging problems with brilliant solutions.

This will be challenging—there’s no way around that. But it will also be worth it. Together, we’ll push boundaries, create something new, and show what’s possible when you truly put the client first.

If this speaks to you—or if you’re just curious about what we’re building—let’s talk. I’d love to share more about this next chapter for Before. Don't forget to apply to be considered. 

Let’s prove what’s possible together. | 22 | 1 | 0 | 11mo | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.502Z |  | 2024-12-26T01:43:52.447Z |  | https://www.linkedin.com/jobs/view/4109030612/ | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7271147630368325633 | Document |  |  | Looking forward to the event. | 2 | 1 | 0 | 1yr | Post | Julien Massot | https://www.linkedin.com/in/jmassot | https://linkedin.com/in/jmassot | 2025-12-08T06:06:50.503Z |  | 2024-12-07T13:04:46.470Z | https://www.linkedin.com/feed/update/urn:li:activity:7270855769665794048/ |  | 

---



---

# Julien Massot
*Extramuros*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Extramuros: Chroniques d'un globe-painter - Malland, Julien: 9782862277493](https://www.abebooks.co.uk/9782862277493/Extramuros-Chroniques-dun-globe-painter-Malland-2862277495/plp)
*1996-01-01*
- Category: article

### [Florent Massot, Independent Publisher Interview | BookBlast®](https://bookblast.com/blog/interview-florent-massot-french-independent-publisher/)
*2024-05-19*
- Category: blog

### [](https://www.demilked.com/world-wide-giant-murals-street-art-julien-malland-seth-globepainter/)
- Category: article

### [Web3 Galaxy Brain 🌌🧠 | Unlock Protocol Founder Julien Genestoux](https://web3galaxybrain.com/episode/Unlock-Protocol-Founder-Julien-Genestoux)
*2023-12-12*
- Category: article

### [behind the counter x Julien Routil - Counter App - Medium](https://medium.com/counter-app/behind-the-counter-x-julien-routil-155b91f275b3)
*2021-01-13*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
