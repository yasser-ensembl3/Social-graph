# Bhavish Beejan

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Material
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 1 year 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Material makes being a top-tier public company effortless. We connect data, automate compliance, and streamline legal workflows, so internal  teams can focus on execution, not paperwork.

## Résumé

I started as a capital markets lawyer, helping companies go and stay public. The process was slow, manual, and painful. I co-founded Material to fix that: a better way to be public. We connect data, automate compliance, and streamline public company workflows so teams can focus on execution, not paperwork.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACdVZj4BX4EO536P8oeOtHAXRN_B2yieKfE/
**Connexions partagées** : 41


---

# Bhavish Beejan

## Position actuelle

**Entreprise** : Material

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Bhavish Beejan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7388557094087729152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFkLK1w91GAhQ/feedshare-shrink_800/B4EZologBSJgAg-/0/1761567968899?e=1766620800&v=beta&t=fjR8Ot-aDs1Pa9NBVLcdCw9GIFVNB-SJdu9vPKVxDlY | My life these days is either telling people about what we’re building at Material or talking to public company management teams (thanks TechTO and Planet MicroCapfor hosting great events last week!).

I’ve been meeting a lot of TSX and TSXV microcaps (companies under $500M market cap) that are basically growth-stage startups that happen to be public. The challenges are the same: managing growth, communication, and execution, but the tools and processes aren’t built for them. 

Legacy reporting tech is mostly made for large publics. Traditional capital markets advisory services, whether legal, IR, or compliance, aren’t designed with a focus on efficiency or cost. Microcap teams are public but still running lean and hands-on, using systems that don’t quite fit.

We’re building and shipping tools for public companies that make their lives easier and help them save costs. If you’re running or advising one, I’d love to connect. | 90 | 2 | 0 | 1mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:41.010Z |  | 2025-10-27T12:48:03.983Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7383868187416633344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/88c9cf64-f711-4549-9a6d-9792b78e7deb | https://media.licdn.com/dms/image/v2/D4E05AQE5b72ubpvBYg/videocover-high/B4EZni6b66HoBw-/0/1760448597678?e=1765778400&v=beta&t=oytSEUvI_koIXBOQEV59iCBF4FBBL4VTyRPgKKcB-Xg | Automating the press release has been one of the hardest challenges since starting Material. We finally cracked it.

If you’re a Canadian-listed company, now’s the time to see what’s possible. 

DM me or reach out through our site to get started. | 55 | 3 | 0 | 1mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:41.010Z |  | 2025-10-14T14:16:01.517Z | https://www.linkedin.com/feed/update/urn:li:activity:7383867946181513216/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7382056023785754625 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFFKoS0C-cMxA/feedshare-shrink_800/B4EZnJIhBBGYAg-/0/1760016077573?e=1766620800&v=beta&t=jK0Jv2_q_kfSbwv0plkVa6HPWeYBDoeaq0dZeSnWtpI | Had a great time speaking on the main stage at Elevate in Toronto this week, sharing how Material is helping Canadian public companies of all sizes streamline their reporting and financing.

We have some exciting updates to announce next week. Stay tuned!

Huge thanks to the McGill Dobson Centre for Entrepreneurship for all their continued support. | 131 | 16 | 0 | 1mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:41.011Z |  | 2025-10-09T14:15:08.039Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7328098818892197888 | Text |  |  | Si tu es étudiant.e en droit ou en comptabilité/finance, on recrute notre tout·e premier·ère stagiaire non-tech chez Material! C’est à distance, donc tu peux même travailler de la piscine si ça te tente.

Tu vas collaborer avec une petite équipe interdisciplinaire, incluant nos chercheurs, et voir concrètement comment l’IA transforme les marchés financiers et la pratique du droit.

Et si l’anglais n’est pas ta première langue, c’est vraiment pas un problème! Ce qui compte pour nous, c’est ta curiosité et ton envie d’apprendre.

Nous acceptons les candidatures jusqu'à vendredi le 16 mai à 17 h (heure de l’Est). | 32 | 0 | 2 | 6mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:41.011Z |  | 2025-05-13T16:48:27.916Z | https://www.linkedin.com/feed/update/urn:li:activity:7328097368946405377/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7327693995789213696 | Text |  |  | We're hiring for our first non-engineering internship at Material! If you're a Canadian law or accounting/finance student interested in capital markets and how AI is being built to understand them, this is a pretty cool opportunity. 

Bonus: your computer training will go well beyond fixing commas or transcribing a partner’s iPad markups into Word 🙂

We're accepting applications until Friday May 16 at 5 p.m. | 45 | 0 | 1 | 6mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:41.012Z |  | 2025-05-12T13:59:50.567Z | https://www.linkedin.com/feed/update/urn:li:activity:7327693471387983872/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7325906325534617600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEozUDTnqe3bA/feedshare-shrink_800/B4EZarXx_.HMAo-/0/1746631860953?e=1766620800&v=beta&t=xKdteJlh8-ENCN4m3copMc_aGdBAdBeslOpsK3BEqLQ | Bâti au Québec —et fièrement en français aussi.

L’abonnement annuel de Material inclut la traduction pour tous les dépôts, sans frais supplémentaires.

Commencez dès aujourd’hui. | 64 | 1 | 0 | 7mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:43.063Z |  | 2025-05-07T15:36:16.765Z | https://www.linkedin.com/feed/update/urn:li:activity:7325905004593094658/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7325848479656828928 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFnsMvttxnvHw/feedshare-shrink_800/B4DZan0SpkHwAg-/0/1746572225575?e=1766620800&v=beta&t=H0bS27YMVWdIvrTTuvnpXalSXagbCFhVYMCAQGQXHq4 | Material 2.0 is live! If you’re a CFO, GC, or VP Finance at a TSX, TSXV, or CSE-listed company, this is for you.

To prove it, we’ll do your next filing—free—for the first 10 companies that reach out. MD&A, AIF, Circular, or Prospectus. No invoice until it’s filed. No catch.

✔️ Aligned to your latest disclosures.
✔️ Benchmarked against peers.
✔️ Reviewed and board-ready.
✔️ Delivered to audit standards.

No fire drills. No billable hours. Just a better way to be public.

Reach out via DM or on our new website www.material.legal! | 73 | 9 | 4 | 7mo | Post | Bhavish Beejan | https://www.linkedin.com/in/bhavishbeejan | https://linkedin.com/in/bhavishbeejan | 2025-12-08T05:21:43.064Z |  | 2025-05-07T11:46:25.233Z | https://www.linkedin.com/feed/update/urn:li:activity:7325845996431679488/ |  | 

---



---

# Bhavish Beejan
*Material*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 3 |

---

## 📚 Articles & Blog Posts

### [Bhavish Aggarwal in conversation with Z47 | Building a Technology-driven Future in India](https://www.z47.com/podcast/bhavish-aggarwal-in-conversation-with-z47-building-a-technology-driven-future-in-india)
*2025-05-12*
- Category: podcast

### [Bhavish Aggarwal s Influence on Indian Startups  A Deep Dive - FasterCapital](https://fastercapital.com/articles/Bhavish-Aggarwal-s-Influence-on-Indian-Startups--A-Deep-Dive.html)
*2024-01-01*
- Category: article

### [Indian tech leaders stand behind Ola's Bhavish in his fight against Microsoft & LinkedIn](https://www.zeebiz.com/startups/news-ola-cab-book-electric-bike-founder-bhavish-aggarwal-on-linkedin-indian-tech-leaders-supports-in-his-fight-against-microsoft-and-linkedin-289458)
*2024-05-12*
- Category: article

### [Bhavish Aggarwal’s ‘Pronoun Illness’ Remark Triggers The Internet; Netizens Call Him ‘Wannabe Elon Musk’](https://in.mashable.com/tech/74646/bhavish-aggarwals-pronoun-illness-remark-triggers-the-internet-netizens-call-him-wannabe-elon-musk)
*2024-05-07*
- Category: article

### [Multibagg AI founder slams Ola Electric CEO Bhavish Aggarwal: ‘Hosting models isn’t innovation’](https://www.livemint.com/news/india/multibagg-ai-founder-slams-ola-electric-ceo-bhavish-aggarwal-hosting-models-isn-t-innovation-11744220372818.html)
*2025-04-09*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[2018 REPORT MONTRÉAL DECLARATION FOR A RESPONSIBLE ...](https://monoskop.org/images/b/b2/Report_Montreal_Declaration_for_a_Responsible_Development_of_Artificial_Intelligence_2018.pdf)**
  - Source: monoskop.org
  - *Bhavish Beejan, Université Laval. Liam Bekirsky, Maison des étudiants ... material conditions under which they are developed. In particular, there is ...*

- **[Top 40+ Hottest Companies at Elevate Conference Toronto 2025 ...](https://thefounderspress.com/hottest-companie-elevate-conference-toronto/)**
  - Source: thefounderspress.com
  - *Oct 10, 2025 ... Elevate Tech Conference returned to downtown Toronto from October 7 ... Material. Bhavish Beejan is making life easier for public com...*

- **[Mila Welcomes Material as a New Partner to Drive AI Innovation in ...](https://mila.quebec/en/news/new-partnership-mila-material-to-drive-ai-innovation-public-company-reporting-compliance)**
  - Source: mila.quebec
  - *Oct 1, 2024 ... Blog · Speed Science Contest · Publications · Open Source Software ... Bhavish Beejan, CEO of Material. “Combining our deep knowledge ...*

---

*Generated by Founder Scraper*
