# Ari Brojde

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Estateably
**Durée dans le rôle** : 7 years 9 months in role
**Durée dans l'entreprise** : 7 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Estateably is a platform that empowers trust and estate professionals to digitize their practices. By complementing existing processes with modern technologies, we offer an automated and compliant solution that increases staff capacity and collaboration between stakeholders while decreasing manual documentation requirements.

## Résumé

At Estateably, our mission is to revolutionize the trust and estate industry by implementing cutting-edge technology that enhances collaboration and efficiency. Our innovative software streamlines processes, allowing professionals to focus on delivering superior client service.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAKKmRkBzLeSJLUYj1Ti752pHSXX69SdxvE/
**Connexions partagées** : 47


---

# Ari Brojde

## Position actuelle

**Entreprise** : Estateably

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Ari Brojde

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401739826707988480 | Article |  |  | Proud moment over here at Estateably: we’ve just launched our new homepage, and I couldn’t be more excited to share it.

As Alex and I look at how far the platform has come, this refresh feels like the right way to showcase what our team has been building behind the scenes.

A few milestones since 2022 that really stand out to me:
➡️ 5,000+ professionals onboarded
➡️ Partnering with 1,000+ firms
➡️ A document library now exceeding 3,000 forms and letters
➡️ More than 550,000 documents generated for users

It’s been an incredible journey — and we’re gearing up for some meaningful updates in the months ahead.

Appreciate everyone who’s been part of the ride so far. Onward! 🚀

www.estateably.com/beta | 35 | 2 | 3 | 5d | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:23.259Z |  | 2025-12-02T21:51:32.363Z | http://www.estateably.com/beta |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7394007778295595008 | Text |  |  | In case you missed Wilmington, Day 2 of the Delaware Trust Conference focused on what it now takes to be an effective modern fiduciary - technical fluency, emotional intelligence, and operational resilience.

Sessions ranged from modifying irrevocable trusts via nonjudicial settlement agreements and OB3-era tax planning to cross-border trust administration, mental-health awareness, and the growing threat of AI-enabled fraud.

The through-line? Trustees and executives must adapt faster than ever - integrating legal precision with human understanding and strong internal controls.

Read my full recap of Day 2 for the key takeaways every trust officer and executive should know.

#DelawareTrustConference #TrustAdministration #FiduciaryDuty #TaxCompliance #WealthManagement #Leadership | 23 | 0 | 0 | 3w | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:23.260Z |  | 2025-11-11T13:47:08.367Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391940180443557890 | Text |  |  | Delaware continues to prove why it’s the gold standard in fiduciary practice - and Day 1 of this year’s conference drove that home.

Professor Sam Donaldson opened with “planning ideas worth stealing,” covering basis optimization, SLATs, and charitable remainder trusts. Later sessions tackled Trust Act 25, settlor intent, ethics and AI, and the evolving world of cross-border and multi-state trust planning - culminating in a lively debate comparing Delaware with Alaska, Nevada, Tennessee, and Florida.

I’ve summarized all six plenary sessions in the article below, highlighting the most practical takeaways for trust officers and fiduciary leaders.

#DelawareTrustConference #FiduciaryLeadership #TrustsAndEstates #WealthManagement #DelawareTrusts | 14 | 0 | 1 | 1mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:23.260Z |  | 2025-11-05T20:51:14.625Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7391604178315395072 | Article |  |  | Incredibly grateful to the Canadian legal community for choosing Estateably in Canadian Lawyer Magazine's Readers' Choice Awards! Your trust means everything to us.
This recognition reminds us why we love what we do. We build tools that make your day a little easier and your practice a lot smoother. 

Thanks for believing in better ways to serve clients.

https://bit.ly/4hLM0GP | 14 | 3 | 0 | 1mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:23.261Z |  | 2025-11-04T22:36:05.475Z | https://bit.ly/4hLM0GP |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7369087549987819522 | Article |  |  | Yes, another AI-in-law post (I see you rolling your eyes). Before you scroll past, the use cases are actually evolving beyond the usual efficiency talk.

Take AI for estate planning risk assessment - not flashy automation, but AI as a second set of eyes for compliance checks, tax modeling, and catching document inconsistencies that slip through manual review.

AI might complement (not replace) the judgment-heavy parts of planning.

Full article: https://lnkd.in/ebQKknpH

#EstatePlanning #AI #RiskManagement #LegalTech | 29 | 0 | 0 | 3mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.686Z |  | 2025-09-03T19:23:02.943Z | https://www.reuters.com/practical-law-the-journal/transactional/use-ai-estate-planning-2025-09-01/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7361783874160345090 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHSM-9lyaluPA/feedshare-shrink_800/B4EZipPa9aHIAg-/0/1755186049566?e=1766620800&v=beta&t=YW845Fc-0kAHk-P5ieWGE8QsFLm1e8hgdBMM6AzB2Ds | An $800,000 lesson in why the details matter in estate administration.

Just shared Part 2 of my ABA Trust School insights, and there's one scenario that perfectly illustrates why systematic processes are so critical in our field.

A couple, Sue and Bob, have a $20M combined estate. When Bob passes away with $4M in his name, it seems straightforward - he's well under the $13.99M exemption, so no Form 706 required, right?

Here's where it gets tricky: Without filing Form 706 to elect portability, Sue loses Bob's unused $9.99M exclusion forever. When she later passes with the remaining $16M, her estate faces tax on $2.01M instead of qualifying for the full exemption.

The result? Nearly $800K in avoidable federal estate tax.

This scenario highlights just how intricate estate administration can be, with critical decisions hiding in seemingly routine situations.

In my latest blog article, I walk through five key mechanics that can make or break estate settlements: 
→ How lifetime gifts interact with estate tax calculations 
→ The portability election timing that protects family wealth 
→ Why organized data makes Form 706 manageable instead of overwhelming → Clear, reliable ownership documentation 
→ The title vs. contribution documentation that saves headaches later

The legal framework for estate administration is comprehensive. The challenge is having reliable workflows that ensure nothing falls through the cracks when managing multiple complex estates.

What systems have you found most helpful for staying organized in estate administration?

Link to full article: https://lnkd.in/eDrdHXQF

#EstateAdministration #TrustAndEstate #Portability #LegalTech | 16 | 1 | 1 | 3mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.689Z |  | 2025-08-14T15:40:50.930Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7359209212909895681 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHeC3ondWgwqg/image-shrink_800/B4EZiEpw3IGYAc-/0/1754572198175?e=1765778400&v=beta&t=UJ-39L2-JVVd002CEU-4riGLVteswwNYCjhEh0EhcYg | Just wrapped ABA Trust School Level II in June - and yes, I'm turning my brain dump into a blog series.

First up: Why building wealth management plans is exactly like engineering a Formula 1 race car. (Trust me, the analogy works better than you'd think.)

I'm breaking down each lesson through analogies that actually make sense because estate and trusts practices are evolving, and modern practitioners deserve explanations that match the innovation in today's legal landscape.

Read the first installment here: https://bit.ly/4liyHNY. More coming soon.

#TrustAndEstates #WealthManagement | 39 | 1 | 1 | 4mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.690Z |  | 2025-08-07T13:10:03.853Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7358877338119335936 | Article |  |  | Daily Journal Corporation's piece on California T&E practitioners highlights a crucial insight: young lawyers aren't avoiding the trust and estates space because it's devoid of opportunity - they're bypassing it because watching senior attorneys drown in manual busywork doesn't look like the career they want.

Meanwhile, everyone's "incredibly busy" with this wealth transfer tsunami, but busy doesn't automatically mean profitability for practices when they’re using the same manual processes for $50K estates that you'd use for $5M ones.

Look, I totally get why so many firms haven't modernized yet. They’ve built successful practices on relationships, not software. They’ve been burned by tech promises before. And when they’re already drowning in work, taking on another "project" feels impossible.

But here's what I'm seeing work: the practices that automate the repetitive stuff - asset tracking, beneficiary updates, compliance reporting - suddenly handle multiple times the volume without the overwhelm, and they're attracting talent instead of burning it out.

If the best time to modernize was five years ago, the second-best time is right now. Practices have already proven they can build great client relationships - imagine what they could do with systems that actually support them.

https://lnkd.in/eR5Qn2q6 
#TrustsAndEstates #LegalTech #EstateAdministration

What's been the biggest barrier to making operational changes in your practice? | 12 | 1 | 0 | 4mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.692Z |  | 2025-08-06T15:11:18.737Z | https://www.dailyjournal.com/article/385242-trust-and-estate-law-booms-as-wealth-transfers-increase |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7353125470952910849 | Text |  |  | A quick thought on strategic trust administration.

Been reading through North Carolina's Uniform Trust Code statute-by-statute. Found something interesting: as per NC Gen Stat § 36C-10-1001 (2023), when beneficiaries or power holders allege breach of trust, courts are likely to compel a trustee to account.

Trustees who produce annual accounts before they are requested aren't just checking compliance boxes. They're building a paper trail that says "we have nothing to hide" long before anyone asks questions.

The ones scrambling to compile years of records only after court compulsion? Different story entirely.

Annual account production isn't just good practice—it's dispute prevention. Good thing it's getting easier to actually do (ahem, in Estateably 😉)

Think I'll dig deeper and share more about transparency as a strategic tool. More to come.

#TrustAdministration | 22 | 2 | 0 | 4mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.693Z |  | 2025-07-21T18:15:26.740Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7351228031392251904 | Video (LinkedIn Source) | blob:https://www.linkedin.com/3e2cf5ae-5986-483f-9522-9d27735844d7 | https://media.licdn.com/dms/image/v2/D4E05AQHj1i_4cqwphQ/feedshare-thumbnail_720_1280/B4EZgOr_tJGoBI-/0/1752593071749?e=1765778400&v=beta&t=zYMhKm_t6ZAG24Ruaeh_GZQ0H2ASbVKn-1EEomSbwmY | Proud of our team for shipping meaningful improvements to Estateably's accounting features. These enhancements are designed to streamline workflows for fiduciary professionals - with more updates coming soon. | 28 | 0 | 4 | 4mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.694Z |  | 2025-07-16T12:35:41.896Z | https://www.linkedin.com/feed/update/urn:li:activity:7350908717522919425/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7335380272391106561 | Article |  |  | According to Clio's latest report, solo and small firms believe AI will save them time more than anyone else - yet they're adopting it less than big firms.

This tells me we have a trust problem, not a technology problem.

At Estateably, I watch trust and estate attorneys struggle with this daily. They see AI's potential but fear the unknown. What if it makes a mistake?

Here's what I think is really happening: Solo practitioners are risk-averse because they can't afford to be wrong. Big firms have safety nets. Solo attorneys ARE the safety net.

But the biggest risk now might be doing nothing. While they're waiting for "more guidance," their competitors are learning and getting better results.

The solution isn't better AI. It's AI that understands legal workflows from day one. 

The question isn't whether AI will transform legal practice. It's whether solo and small firms will shape that transformation or be shaped by it.

https://bit.ly/43GIGG1 | 28 | 0 | 0 | 6mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.695Z |  | 2025-06-02T19:02:21.713Z | https://bit.ly/43GIGG1 |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7331403908977700864 | Article |  |  | Just dropped our partnership announcement with Estatesearch Canada. Honestly, their asset discovery approach is brilliant. Jonathan Upton stoked to see this help estate professionals across Canada. | 43 | 2 | 0 | 6mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.695Z |  | 2025-05-22T19:41:42.798Z | https://bit.ly/45owkF4 |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7329186459947528193 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEXZb5oOPmdZg/feedshare-shrink_800/B56ZaMnyfiGkAk-/0/1746115963168?e=1766620800&v=beta&t=IGzkMJ4RknEeOltf_7QggvwGz-88sgu3bGejskxUFt0 | I read the "Undue Influence Guide" from BC Law Institute. As someone who loves a good checklist (who doesn't?), I like the practical tools they've included.

I'm a big believer that good checklists do more than just tick boxes. They help make sure everyone is meeting the legal requirements and needs of clients - AND - listening to what clients want. And that matters more than anything when working with folks who might be vulnerable.

The guide also talks about effective ways doctors and lawyers can and should talk to each other - which I know is absolutely critical. When that happens, everyone's better protected, and the whole process of creating wills, preparing estate plans, and setting up smooth settlement and trust management becomes more transparent. | 25 | 0 | 0 | 6mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.696Z |  | 2025-05-16T16:50:21.751Z | https://www.linkedin.com/feed/update/urn:li:activity:7325195098638450688/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7318603172271296516 | Text |  |  | I still remember the day I became an executor after my grandmother's passing. What began as a moment of profound grief quickly transformed into a two-year journey through paperwork, legal complexities, and countless sleepless nights. What followed wasn't just about missing her—it was about navigating a system that seemed designed to compound suffering with stress.

That's why Empathy's new report, "The Grief Tax," stopped me in my tracks. Ron has managed to articulate and quantify an experience that so many face but few discuss openly: the hidden toll that follows loss.

My family's experience mirrors what the report reveals—the way grief seeps into every aspect of life, from workplace performance to relationships. Those late nights at my desk, trying to make sense of financial documents while processing my own emotions, weren't just difficult—they changed me and ultimately inspired the creation of Estateably.

What strikes me most about Empathy's research isn't just the numbers (though they're staggering), but how accurately it captures the isolation that executors feel. When you're responsible for closing someone's life, you carry a weight that's difficult to explain to others, especially while trying to maintain your own life and responsibilities.

For those caught in the "Sandwich Generation"—caring for both aging parents and children—this burden becomes nearly impossible to bear alone. I've seen firsthand how this responsibility disproportionately falls on those already stretched thin.

Thank you, Ron Gura for bringing compassionate attention to this universal but often invisible experience. By naming and measuring "The Grief Tax," you've validated what so many families endure silently and created space for necessary conversations about how we support people through life's most challenging transitions.

As we continue building in this space, may we never lose sight of the humans behind every estate—both those who have passed and those left navigating the aftermath.

#GriefTax #EstateSettlement #EndOfLife #Empathy | 38 | 1 | 0 | 7mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.698Z |  | 2025-04-17T11:56:09.341Z | https://www.linkedin.com/feed/update/urn:li:activity:7316134831816421376/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7312521021725560832 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGFLiOCNcNyng/image-shrink_800/B4EZXsVNnPGYAc-/0/1743426739383?e=1765778400&v=beta&t=GmEo7BpuIpbUOsJHgs8k1KLM4ygSQQUZ6Xyweeodk4o | Honored to present Estateably alongside some incredibly innovative software platforms at Martin Shenkman's upcoming "Estate Planning Software for Your Toolkit" webinar on April 3rd. Thanks Martin! You’re a true thought leader in the estate planning space, and I'm looking forward to demo’ing our latest features and discussing the future of technology in estate administration across Canada & the United States. If you’re an estate administration professional, register for the Shenkman Law webinar! | 26 | 0 | 1 | 8mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.700Z |  | 2025-03-31T17:07:51.650Z | https://www.linkedin.com/feed/update/urn:li:activity:7312461770902650881/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7308129827465703424 | Text |  |  | I’ve always agreed that one of the most important jobs as a founder is to hire great people with more skill than you and get out of their way. 

About a year ago, our marketing function was in a bit of a tough spot. Our COO, Alexander Wulkan, handled marketing strategy alongside his COO responsibilities. 

At the same time, our incredibly talented Raine Radke was our only dedicated marketing resource and had a lot on her plate, and as a result, our output could simply not match our ambition.

So, right before Labour Day, we brought in Hilary Scott, a seasoned marketing vet, who instantly impressed us with her scrappiness and “get (sh)it done” attitude. 

Hillary spent her first few weeks assessing the situation and then came to us with a plan to streamline the marketing function while taking on much of the execution responsibilities.

After some time, Hillary introduced us to her former colleague Joe Loeppky. 

Joe initially joined in a consulting role but, in a matter of months, quickly elevated our marketing function to a whole new level—one that amazes everyone at Estateably. 

As I review our company-wide updates every week, I’m blown away by the sheer number of marketing initiatives being executed. I often struggle to summarize them all in our company updates (a great problem to have!).

Joe and Hilary epitomize hiring people far more talented than Alex and I - and we couldn’t be happier to step out of their way to let them do great things.
 
And now, we’re taking things even further! We’re thrilled to welcome Joe as our new Director of Marketing. 

With Joe on board, we’re doubling down on our momentum and pushing even harder to build something incredible. | 57 | 5 | 6 | 8mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.701Z |  | 2025-03-19T14:18:49.354Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7305210056176721920 | Text |  |  | Since Estateably’s inception, Alexander Wulkan and I have held steadfast to an exciting vision that informs our long-term product roadmap and challenges the status quo in trust and estate administration.
 
As we grew our business over time, we became blessed with an engaged customer base that - to this day - provides us with consistently insightful feedback and suggestions on how we can improve the platform’s features and functionality.

There’s only so much time in a day, and from a prioritization perspective, it sometimes feels as though addressing user feedback on the one hand, and keeping laser-focused on delivering our long-term roadmap on the other, represent two competing interests. 

To take our platform to the next level, we knew we needed a dedicated leader—someone who can align strategy with execution, champion innovation, and ensure our solutions truly meet the evolving needs of our users.

That’s why we’re excited to welcome Ian Muirhead as our new Director of Product.

Ian comes from a deep design and user experience background and has over a decade of experience scaling SaaS platforms like Estateably, helping to build high-performing teams that drive product innovation along the way.

As our company continues to grow, so does our commitment to delivering the best possible experience for our customers. 

We're thrilled to have Ian on board and can’t wait to see the impact he’ll make. | 68 | 6 | 4 | 8mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.702Z |  | 2025-03-11T12:56:41.632Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7301314309580599297 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHn5aPnLvZovA/feedshare-shrink_1280/B4EZVN6rJdG0Ao-/0/1740768982013?e=1766620800&v=beta&t=Lv_rXg979AXciSCtKA1vV6dl5uxH33Vyzdn9a5xWFg0 | This year, I’ve made it a habit of spending an hour a week connecting with our clients to hear firsthand about their experience with Estateably and see where we can improve. 

So when I get asked what the best part of my week is, I oftentimes turn to our user feedback. 

This is a great reminder that we're not just building software - we're creating time, efficiency, and revenue opportunities for legal professionals that benefit the families they serve.

When professionals tell us we're helping them work more efficiently and grow their practice, it fuels our drive for the next feature launch.

Thank you to all our users who continue to trust us with such an important part of their practice (and if you’re not yet on Estateably - come and see what you’re missing)! | 72 | 3 | 0 | 9mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.703Z |  | 2025-02-28T18:56:23.264Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7288541665542221824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHmLNe_XO6-5g/feedshare-shrink_800/B4EZSVdh_kHcAk-/0/1737674335044?e=1766620800&v=beta&t=gqEkoU-XDH-aLDufajJ12eZdhvUB0tZK1EEuQPTSe2A | Couldn’t agree more. Well said Alexander Wulkan! | 42 | 0 | 0 | 10mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.703Z |  | 2025-01-24T13:02:27.621Z | https://www.linkedin.com/feed/update/urn:li:activity:7288527960293212160/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7275953771971502080 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF6wx2p2KTuwQ/feedshare-shrink_800/B4EZPlhY2uHgAk-/0/1734722555711?e=1766620800&v=beta&t=TQHUw_slRf8-K3Tp0duAN6cG0tcVhdD5IZTkrX1aKuc | This year has been one of incredible growth for Estateably—not without its challenges, but driven by the conscious effort to push ourselves to be better and stronger as a product, a team and a company. What began as a personal mission, inspired by the challenges my family faced settling my grandmother’s estate, has turned into something that’s helping so many families and professionals navigate estate administration more effortlessly. 

With all we’ve accomplished this year, I’m even more excited about what lies ahead: how much more we can improve, and how much more we can achieve, together. 

To everyone who’s supported us on this journey—thank you. Wishing you a joyful holiday season and a new year filled with opportunities! | 139 | 10 | 2 | 11mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.704Z |  | 2024-12-20T19:22:39.922Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7275612172146151425 | Article |  |  | Thank you to Amanda Breen and Entrepreneur Magazine for sharing the story behind Estateably!

Reflecting on how a personal challenge with settling my grandmother’s estate turned into a mission to simplify this process for so many families has been truly meaningful.

I’d love for you to give it a read and hear your thoughts: https://lnkd.in/evz-zggZ | 43 | 1 | 1 | 11mo | Post | Ari Brojde | https://www.linkedin.com/in/abrojde | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.705Z |  | 2024-12-19T20:45:16.177Z | https://www.entrepreneur.com/starting-a-business/great-wealth-transfer-business-speeds-up-inheritance/483758 |  | 

---



---

# Ari Brojde
*Estateably*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 11 |
| Press & Mentions (Google) | 22 |

---

## 📚 Articles & Blog Posts

### [How Executors Navigate Estate Administration in a Digital World, with Ari Brojde - Overdue Advice](https://www.metcredit.com/podcast/how-executors-navigate-estate-administration-in-a-digital-world-with-ari-brojde/)
*2023-10-31*
- Category: podcast

### [Transforming Estate Administration - With Ari Brojde of Estateably - Techtastic](https://podcast.techtastic.tech/episodes/amYJvwYRQEF)
*2024-07-19*
- Category: podcast

### [Ari Brojde | WealthManagement](https://wealthmanagement.com/author/ari-brojde)
*2025-09-09*
- Category: article

### [Estateably with Ari Brojde | E248 — JasonPereira.ca](https://jason-pereira.squarespace.com/all-content-jason-pereira-toronto/estateably-with-ari-brojde-e248)
*2022-10-25*
- Category: article

### [Estateably brings home the award for Software of the Year in Readers Choice Awards](https://www.canadianlawyermag.com/practice-areas/trusts-and-estates/estateably-brings-home-the-award-for-software-of-the-year-in-readers-choice-awards/361818)
*2021-11-17*
- Category: article

---

## 🎬 YouTube Videos

- **[Ari Brojde of Estateably Part 1](https://www.youtube.com/watch?v=_YZjECj1928)**
  - Channel: Richard Rosin Winnipeg's Friendliest Undertaker TM
  - Date: 2021-03-24

- **[Ari Brojde of Estateably Part Two](https://www.youtube.com/watch?v=ijPLh1wwx2I)**
  - Channel: Richard Rosin Winnipeg's Friendliest Undertaker TM
  - Date: 2021-04-07

- **[How the Brojde Center at  the Hebrew University began?](https://www.youtube.com/watch?v=g2y6_tH4hNw)**
  - Channel: Brojde&OECL HUJI
  - Date: 2016-08-18

- **[Estateably with Ari Brojde | E248](https://www.youtube.com/watch?v=bdUtVrR4sfA)**
  - Channel: Jason Pereira
  - Date: 2022-10-25

- **[Transforming Estate Administration - With Ari Brojde of Estateably](https://www.youtube.com/watch?v=bbnhXSeFNUI)**
  - Channel: Christian Hammer
  - Date: 2024-07-20

- **[Met Talks | Ari Brojde on advice for Estate Executors](https://www.youtube.com/watch?v=KfDDyzf7AMU)**
  - Channel: MetCredit Canada
  - Date: 2023-09-08

- **[Met Talks | Ari Brojde on how much debt Canadians have when they die](https://www.youtube.com/watch?v=yzAtO2Udd6Y)**
  - Channel: MetCredit Canada
  - Date: 2023-09-08

- **[Ari Brojde at the 76th Board of Governors Meeting at Hebrew University](https://www.youtube.com/watch?v=7DIAsZtt5ZM)**
  - Channel: Canadian Friends of Hebrew University
  - Date: 2013-07-03

- **[Settling Estates on Blockchain](https://www.youtube.com/watch?v=4FA8iOvBAQM)**
  - Channel: Global Blockchain Summit
  - Date: 2019-10-16

- **[Michael Levy at the 76th Board of Governors Meeting at Hebrew University](https://www.youtube.com/watch?v=AIO-vxOeYtg)**
  - Channel: Canadian Friends of Hebrew University
  - Date: 2013-07-02

---

## 🔎 Press & Mentions

- **[Estateably: Estate Planning Software Technology Big Advance](https://softwareoasis.com/sixty-two/)**
  - Source: softwareoasis.com
  - *Apr 12, 2024 ... Co-founded by Ari Brojde and Alex Wulkan, Estateably leverages ... Listen And Share This Software Spotlight Podcast Watch And Share T...*

- **[Ari Brojde | Accounting Today](https://www.accountingtoday.com/author/ari-brojde)**
  - Source: accountingtoday.com
  - *Ari Brojde is the co-founder and CEO of Estateably, an estate, trust, and incapacity accounting & administration software used by over 1,000 firms acr...*

- **[Real estate takes top spot in estate planning survey - InvestmentNews](https://www.investmentnews.com/retirement-planning/real-estate-takes-top-spot-in-estate-planning-survey/247711)**
  - Source: investmentnews.com
  - *Jan 9, 2024 ... The InvestmentNews Podcast · Events · Webinars · Whitepapers · Women ... Ari Brojde, CEO of Estateably, said in a statement. “Real est...*

- **[LTN Startup Spotlight: Estateably Founders on the Advantage of ...](https://www.law.com/legaltechnews/2024/05/14/ltn-startup-spotlight-estateably-founders-on-the-advantage-of-being-industry-outsiders/)**
  - Source: law.com
  - *May 14, 2024 ... Legaltech News sat down with Estateably co-founders Ari Brojde and ... Podcasts Industry Webcasts Law Journal Newsletters LawJobs ......*

- **[How Financial Advisors Can Seize Opportunities in the $129T ...](https://www.wealthmanagement.com/high-net-worth/how-financial-advisors-can-seize-opportunities-in-the-129t-wealth-transfer)**
  - Source: wealthmanagement.com
  - *Dec 4, 2023 ... Podcasts & VideosCE WebinarsResearchNewsletters · Wealth Management ... Ari Brojde is CEO of Estateably. About the Author. Ari ......*

- **[Estateably with Ari Brojde | E248 - YouTube](https://www.youtube.com/watch?v=bdUtVrR4sfA)**
  - Source: youtube.com
  - *Oct 25, 2022 ... Jason Pereira talks to Ari Brojde, Founder and CEO of Estateably; a leading provider of digital solutions for the North American trus...*

- **[Software | Entrepreneur](https://www.entrepreneur.com/topic/software)**
  - Source: entrepreneur.com
  - *Ari Brojde, co-founder and CEO of Estateably, had an eye-opening experience while settling his grandmother's estate. ... Podcasts · Magazine · Spotlig...*

- **[I own two houses. How creative can I get with passing them down to ...](https://www.marketwatch.com/story/i-own-two-houses-how-creative-can-i-get-with-passing-them-down-to-my-children-to-avoid-taxes-3eb643c?gaa_at=eafs&gaa_n=AWEtsqf1pIRicvCrMjrQtx6VuR-0vrfzIX14uxZulehQYvEy6qV-kyzqzElq&gaa_ts=69368a48&gaa_sig=x4LjtHV8eWlZHjGHSdAN_S6LbHqVW1v4GZZw0bf-IagW2sil0LHc5OZ754UrXsh7CBXawEsDc4r5h49I1QrxEA%3D%3D)**
  - Source: marketwatch.com
  - *Aug 25, 2023 ... On the Estateably platform, which serves estate professionals ... Ari Brojde. The trouble with this kind of ownership is that you los...*

- **[Millennials | Entrepreneur](https://www.entrepreneur.com/topic/millennials)**
  - Source: entrepreneur.com
  - *Ari Brojde, co-founder and CEO of Estateably, had an eye-opening experience while settling his grandmother's estate. ... Podcasts · Magazine · Spotlig...*

- **[Wealth | Entrepreneur](https://www.entrepreneur.com/topic/wealth)**
  - Source: entrepreneur.com
  - *Ari Brojde, co-founder and CEO of Estateably, had an eye-opening experience while settling his grandmother's estate. ... Podcasts · Magazine · Spotlig...*

---

*Generated by Founder Scraper*
