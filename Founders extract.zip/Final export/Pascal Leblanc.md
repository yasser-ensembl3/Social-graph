# Pascal Leblanc

## Position actuelle

**Titre** : Founder
**Entreprise** : Mantle Technology
**Durée dans le rôle** : 8 years 6 months in role
**Durée dans l'entreprise** : 8 years 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Information Technology & Services

## Description du rôle

Innovating on disruptive technologies to bridge gaps in the cybersecurity industry.
Ransomware Protection | Data Sovereignty | Digital Identity

## Résumé

“Experiment with ease, scale with confidence.” - Mantle

My Blockchain crush started back in 2011.

Bitcoin just came out.

I quickly started experimenting with the concept by coding small tools and apps to get familiar. It made me aware of the ecosystem, its players and its potential application in shaping the next wave of innovation. 

That’s when I founded with a partner, my first startup, YAAMP (Yet Another Anonymous Mining Pool), in 2014.

It was the first instance of a multi-algo multi-crypto auto-switching pool with Bitcoin payouts.

It was a revolution in the field.

It was based on an algorithm my co-founder and I created that took into account: current prices, networks hash rate, networks difficulty, block rewards, the hash rate of the pool and the expectancy to winning a block.

We gained a lot of traction.

So much that we were competing directly against NiceHash when we started Arbitraging hash power between them and YAAMP.

We got acquired 12 months in the making.

After that, I launched, together with the same partner, another venture: Safecex.

We were the perfect hybrid between Shapeshift and Regular exchanges traditionally focused between Bitcoin and fiat exchange.

We created an anonymous crypto to crypto only trading platform with open order books which quickly and in a community-driven fashion added new altcoins

We were acquired 8 months later.

I joined Ernst & Young as Blockchain Strategist in November 2016.

From what I learned in both my experiences as a tech entrepreneur and a consultant for large corporations, I founded Mantle with the goal of crushing blockchain barriers to ignite its adoption thanks to a platform and a suite of products that delivers the most advanced Blockchain-as-a-Service.

Do you want to transform your business with the power of blockchain?

Get in touch with me now.

Pascal Leblanc

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABrtB_8BzsaJGI8SxiowlQ5Lvc9PfllLID0/
**Connexions partagées** : 133


---

# Pascal Leblanc

## Position actuelle

**Entreprise** : Mantle Technology

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pascal Leblanc
*Mantle Technology*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [Pascal Leblanc](https://iq.wiki/wiki/pascal-leblanc)
*2024-10-24*
- Category: article

### [Mantle Technology CEO, Founder, Key Executive Team, Board of Directors & Employees](https://www.cbinsights.com/company/mantle-technology/people)
*2025-04-01*
- Category: article

### [All You Need To Know About Pascal Leblanc, The Founder ...](https://usethebitcoin.com/crypto-personalities/all-you-need-to-know-about-pascal-leblanc-the-founder-of-mantle-technologies/)
- Category: article

### [Meet Mantle, an AI Co-pilot for Modern Founders](https://blog.withmantle.com/meet-mantle-an-ai-copilot-for-modern-founders/)
*2023-10-03*
- Category: blog

### [Pitch Please | Navigating Startup Equity Management with Dwayne Forde from Mantle](https://pitchplease.transistor.fm/episodes/mantle)
*2024-03-11*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[DCmag vous donne rendez-vous à Strasbourg le 16 octobre pour ...](https://dcmag.fr/dcmag-vous-donne-rendez-vous-a-strasbourg-le-16-octobre-pour-parler-proximite-et-futur-souverain/)**
  - Source: dcmag.fr
  - *Oct 10, 2025 ... ... Mantle Technology, OCI Informatique & Digital, IXP Strasbourg et la ... Pascal LEBLANC (Mantle Technologie), Arnaud WILLEM (IXP ....*

- **[Prosperity For Every Generation](https://www.prosperityforeverygeneration.ca/)**
  - Source: prosperityforeverygeneration.ca
  - *Francois Fournier, Podcast creator, Les Productions Ian et Frank inc., Lévis ... Pascal Leblanc, Founder & CEO, Mantle Technology, Montréal. Brett Bel...*

- **[Choose France fait vibrer Montréal pour sa première édition](https://lepetitjournal.com/montreal/choose-france-montreal-premiere-edition-427934)**
  - Source: lepetitjournal.com
  - *Nov 18, 2025 ... Layla Nasr (Makila AI), Ludovic André (Crédit Mutuel Equity), Lionel Rigaud (QbitSoft) et Pascal Leblanc (Mantle Technology) y ont dé...*

- **[Untitled](https://www.quebec.ca/gouvernement/gouvernement-ouvert/transparence-performance/agenda-membres-conseil-ministres/fitzgibbon-pierre.csv)**
  - Source: quebec.ca
  - *... Pascal Leblanc, président et fondateur, Mantle Technology Bahador Zabihiyan ... Conference du 22 au 24 septembre 2019";"Boston, États-Unis";"22-09...*

- **[Mantle (MNT) cryptocurrency price, roadmap and where to buy Mantle.](https://bitglossary.com/en/coin/mantle)**
  - Source: bitglossary.com
  - *[Pascal Leblanc - Founder - Mantle Technology](https://ca.linkedin.com/in ... blog/community/mantle-mainnet-arrival-ecosystem-ama-recap). Mantle Roadm...*

- **[Pascal Leblanc Email & Phone Number | Institut NeuroMyoGène ...](https://rocketreach.co/pascal-leblanc-email_96880140)**
  - Source: rocketreach.co
  - *Others Named Pascal Leblanc. Mantle Technology Employee Pascal Leblanc's profile photo ... Blog · Contact Us. © 2025 RocketReach.co....*

- **[Technologie: un exode des jeunes pousses difficile à freiner | Le ...](https://www.ledevoir.com/economie/591082/technologie-un-exode-difficile-a-freiner)**
  - Source: ledevoir.com
  - *Dec 5, 2020 ... ... Pascal Leblanc, p.-d.g. fondateur de Mantle Technology. La « deep tech » désigne les jeunes pousses qui développent des technologi...*

- **[Contact Simon Cadotte, Email: s***@blackmapletrading.com ...](https://www.zoominfo.com/p/Simon-Cadotte/1917196503)**
  - Source: zoominfo.com
  - *Pascal Leblanc. Founder. Mantle Technology. Phone. Email. AK. United States flag ... Engineering Blog · Privacy Center · Profile Privacy. Free Trial. ...*

---

*Generated by Founder Scraper*
