# Saeed Khosravi

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Nexunom
**Durée dans le rôle** : 12 years 1 month in role
**Durée dans l'entreprise** : 12 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Advertising Services

## Résumé

I am an online marketing strategist and SEO enthusiast. I hold a master's degree in international business (MIB) specializing in marketing from HEC Montreal. I am an Entrepreneur (at heart) and the founder of Nexunom, a digital marketing firm based in Montreal, QC. I am also the founder of different marketing SAAS products such as ReviewTool.com, Tavata.com, and Allintitle.co.

I have been working as an internet marketer and SEO specialist since 2008. I am part of a fantastic team planning and executing numerous online marketing campaigns in different countries. 

At Nexunom, we help local businesses and SMBs (dental and orthodontic practices, for the most part) maximize their online visibility, enhance their online presence, improve their reputation, and increase their conversion and closing rates with our different marketing solutions and products. 

We provide different online marketing services, including search engine optimization, website design and development, conversion optimization, content marketing, PPC and Google Ads advertising, social media marketing, review, and reputation management (via our ReviewTool.com), a keyword research solution (via Allintitle. co.) and a web chat solution (via Tavata.com).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAARbKUYBsXrHgjSoBUpKYNbXKE6eOOtg6Gk/
**Connexions partagées** : 16


---

# Saeed Khosravi

## Position actuelle

**Entreprise** : Nexunom

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Saeed Khosravi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396945530779684864 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF55Z9v8Nqjyg/feedshare-shrink_800/B56Zqc6wkNJ8Ak-/0/1763569241717?e=1766620800&v=beta&t=GAWy72Lp0UChAQ2amzaOJr0bBM_ZY0MP39U3af4bsn4 | Google AI overview hallucinating my IP Address. | 3 | 0 | 0 | 2w | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:49.108Z |  | 2025-11-19T16:20:43.140Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7374086093014470658 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG2GC0l4f5X6w/feedshare-shrink_800/B4DZlYEORqHsAg-/0/1758119127010?e=1766620800&v=beta&t=BbMX3yRYLBVR0wYmSA2QYw2eycKH0nazTYhBwV2a-Ws | Google has turned into a giant "Sponsored Engine." Check the attached SERP out; there are 34 sponsored ads and only 10 organic results. Each organic result is followed by 3 ads. We need a better Search Engine. ¯\_(ツ)_/¯ | 2 | 0 | 0 | 2mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:49.110Z |  | 2025-09-17T14:25:28.469Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7355123843377557504 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEhSg5V1gq6Hw/feedshare-shrink_800/B4EZhKmKDBGYAg-/0/1753598174687?e=1766620800&v=beta&t=j_-AhqCZQ8TI7XiMfie6c_HJ5osf-ICrfSd3Zve2WoU | Google is now testing Scroll-to-Text Fragments directly in the SERP snippet description.

You read that right, those #:~:text= links are no longer just hiding behind the blue links. They’re now showing up in Google's search result descriptions.

I broke down what this could mean for SEO here:
https://saeedkhosravi[dot]com/google-is-now-testing-scroll-to-text-links-in-the-description-section-of-serp-snippets/

Spotted this happening just now, I am curious to hear thoughts from folks like Roger Montti, Barry Schwartz, Lily Ray, and others who watch SERP changes more closely.) | 3 | 0 | 0 | 4mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:49.110Z |  | 2025-07-27T06:36:15.854Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7336231551585734656 | Text |  |  | If you're running ads on Google for keywords where you already rank organically (say, somewhere in the middle of page one or two,) Google recently often places your sponsored listing right above your organic listing (mid-page).
If that’s not designed to hijack your organic traffic, then I don't know what it is. | 2 | 0 | 0 | 6mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:49.111Z |  | 2025-06-05T03:25:02.489Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7306310463221321729 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEKo9_kuJsI_Q/feedshare-shrink_800/B4EZWU6pReG0Ag-/0/1741960157956?e=1766620800&v=beta&t=3E9ye7AUpFXoi5HEDP_PwEhHo-AzkAdvvB8P7pYgSEw | According to Google, "United Kingdom" is among the countries in the "Middle East". 😀 
When did they join the Middle East? 🤷‍♂️ | 4 | 0 | 0 | 8mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.940Z |  | 2025-03-14T13:49:19.116Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7288034472849981441 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGPizBbfvejkw/feedshare-shrink_2048_1536/B56ZSRMusDGQA4-/0/1737602822033?e=1766620800&v=beta&t=CGXd7EnSNHBS7pLLrU8K2ApKZD6L5Wr47wxmF_wRVE0 | Just saw this Ad. If I let you write "my book", wouldn’t it make it "your book" and not mine?

Am I alone thinking that way?! | 2 | 0 | 0 | 10mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.940Z |  | 2025-01-23T03:27:03.460Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7288028856303661056 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE9_cS1P7EzTA/feedshare-shrink_2048_1536/B56ZSRHn5vGQAw-/0/1737601483284?e=1766620800&v=beta&t=YjEPg-vJMOMrdd15haBoAcP8YhGEcxPHqSy5RGGEoLQ | This number just called me from Google (Google Ads). The time you see up there is not AM, it is PM and I am in bed trying to sleep after having a long long working day. 

They did not call our business number but my direct cell number. This is not the first time they call us out of our business hours. I don’t get why they do this. I can’t tell if they are Spam or Google. They sound like Spam but they are from Google. Most of the time the guys who call us ask just irrelevant questions like what’s your goal for advertising, etc. and has no idea why we do what we do and their suggestions are just basics (at best) to irrelevant or damaging.

Hey Google if you see this, leave us and our clients alone. We know what we are doing and we don’t need your help. If we need any help we know how to contact you. At least tell your crew to respect the person they call by not calling them when they should be asleep. | 3 | 1 | 0 | 10mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.941Z |  | 2025-01-23T03:04:44.371Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7277504501480128512 | Text |  |  | Exactly. Our brain is slow but that’s our very unique « advantage » as human being. Magics happen when our brain gets focused on the subject matter. No artificial intelligence can match this. You can not drive at 320 kilometre per hour on a Ferrari and see all the details. You can just arrive at « a » destination (not « the » destination) faster if at all with that speed. Memorization ≠ lntelligence. | 4 | 0 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.942Z |  | 2024-12-25T02:04:42.648Z | https://www.linkedin.com/feed/update/urn:li:activity:7277440330805731328/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7277486774954688512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fe93c03d-ca18-458a-928e-3b7d3a2bf0ec | https://media.licdn.com/dms/image/v2/D4D10AQGanxuXTwilQQ/videocover-low/videocover-low/0/1734528604861?e=1765782000&v=beta&t=bk5F87_10mED1GrQbOQIp3oirXbzrjNAq_YhJDLPQxM | I like the first scene from Sora where the guy « cut through his fingers » to get to the tomato. I didn’t look at the rest of it. Just the very first scene screams this is a waste of my time. I don’t get the buzz about all these. What is so interesting about something so fake in its very heart. When did we all get so lazy to prefer to create such an ugly meaningless scenery with just a few line of text instead of holding a camera and creating a real video we can be actually proud of. | 10 | 5 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.943Z |  | 2024-12-25T00:54:16.315Z | https://www.linkedin.com/feed/update/urn:li:activity:7275140409280843776/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7277464253589061634 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEsZXoZGi8-9Q/feedshare-shrink_800/B4EZPvEamUHsAg-/0/1734882734034?e=1766620800&v=beta&t=lfVqAtdUVgWWix63jA1-UaajKNQVMuuCY55kWjjQsOE | Couldn’t have been said better. Add to it that any imageries created by AI is souless, fake which is either too perfect to be real or too ugly and distorted to be of any value. | 8 | 0 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.943Z |  | 2024-12-24T23:24:46.803Z | https://www.linkedin.com/feed/update/urn:li:activity:7276625596141469697/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7277418222847492096 | Article |  |  | This is horrible and shows why people say that Google’s current leaders think that they own the web. | 4 | 0 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.944Z |  | 2024-12-24T20:21:52.219Z | https://www.youtube.com/watch?v=9K_V4NvgQLo |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7275582605444431874 | Text |  |  | "AI-generated" content is the new "duplicate" content. Just because AI can say the same thing in many different ways doesn't make that content anything new, better, or different. | 9 | 2 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.944Z |  | 2024-12-19T18:47:46.926Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7274858843325513729 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF3j5qEbAS0gg/feedshare-shrink_800/B4EZPVoZ1HGcAo-/0/1734455959380?e=1766620800&v=beta&t=BCLp6OF_kMdI50J8WnLETYmPBAzDte-LjPmk4UAjx0w | This is why you should be suspicious about everything you read on any topic of interest, even if it comes from a top journal in your vertical. | 5 | 0 | 0 | 11mo | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.945Z |  | 2024-12-17T18:51:48.590Z | https://www.linkedin.com/feed/update/urn:li:activity:7274835571569573888/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7271181325355696128 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQFmC8OJI3-mzg/feedshare-shrink_800/feedshare-shrink_800/0/1733266495882?e=1766620800&v=beta&t=sJkr88qx6gCEM9mUrDd2pDHJpJjI0vrOKNfIYkNZICw | What are even these AI agents anyway? A prompt asking the AI to act as this and that expert won’t make a «predictive model» to become this and that expert. The deep understanding of a topic and then being able to decisively take proper actions towards a goal comes from real world experience working in that field not by being trained on a body of text and then being able to arrange words in a way that mimics those text. Yes, AI has its use cases in many fields and helps the human experts and professional do their jobs faster but it won’t replace them. | 3 | 0 | 0 | 1yr | Post | Saeed Khosravi | https://www.linkedin.com/in/saeedkhosravi | https://linkedin.com/in/saeedkhosravi | 2025-12-08T06:17:53.946Z |  | 2024-12-07T15:18:39.981Z | https://www.linkedin.com/feed/update/urn:li:activity:7270066878478262274/ |  | 

---



---

# Saeed Khosravi
*Nexunom*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 26 |

---

## 📚 Articles & Blog Posts

### [26+ Best Internal Linking Tools For SEO (A Must-Read Guide)](https://saeedkhosravi.com/best-internal-linking-tools-for-seo-build-smarter-internal-links/)
*2025-05-26*
- Category: article

### [Rank Math Review: Why Many Users Are Switching to Rank ...](https://saeedkhosravi.com/rank-math-review-why-many-users-are-switching-to-rank-math/)
*2024-07-23*
- Category: article

### [Saeed Khosravi - Nexunom's Founder and President](https://nexunom.com/saeed-khosravi/)
*2025-01-01*
- Category: article

### [SEO Consultant in Montreal, QC | Saeed Khosravi](https://saeedkhosravi.com/)
*2024-07-24*
- Category: article

### [Saeed Khosravi Email & +1(844) 736-3699 | Passionate about Driving Business Growth Online. Internet Marketing Strategist, SEO Expert, MIB Graduate. Founder & CEO @ Nexunom, and Creator of ReviewTool.com, Allintitle.co, and Tavata.com](https://www.success.ai/profile/saeed-khosravi-749448894)
*2021-12-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Rank Math Review: Why Many Users Are Switching to Rank Math](https://saeedkhosravi.com/rank-math-review-why-many-users-are-switching-to-rank-math/)**
  - Source: saeedkhosravi.com
  - *Jul 23, 2024 ... Saeed Khosravi is an SEO consultant based in Montreal, QC. He is the founder and CEO of Nexunom and the creator of Allintitle.co, Rev...*

- **[Free Real-Time Keyword Research Tool | KW Explorer by Allintitle](https://allintitle.co/free-keyword-finder/)**
  - Source: allintitle.co
  - *Meet Saeed Khosravi Allintitle's Founder. Update from our Founder (20 ... A Product of Nexunom. Chat with us, powered by LiveChat....*

- **[26+ Best Internal Linking Tools For SEO (A Must-Read Guide)](https://saeedkhosravi.com/best-internal-linking-tools-for-seo-build-smarter-internal-links/)**
  - Source: saeedkhosravi.com
  - *May 26, 2025 ... Saeed Khosravi is an SEO consultant based in Montreal, QC. He is the founder and CEO of Nexunom and the creator of Allintitle.co, Rev...*

- **[Steven James McLean | SpeakerHub](https://speakerhub.com/speaker/steven-james-mclean)**
  - Source: speakerhub.com
  - *Mobile Premier League (MPL) · Saeed Khosravi's picture. Saeed. Khosravi. Founder & CEO. Nexunom ... Podcast · About us · Organizers · Terms of use · P...*

- **[Best Guest Posting and Blogger Outreach Tools for 2025](https://www.linkee.ai/blog/guest-posting-and-blogger-outreach-tools)**
  - Source: linkee.ai
  - *Mar 14, 2025 ... If you're looking to get featured on podcasts, Respona even has a dedicated podcast ... Saeed Khosravi, Founder and CEO of Nexunom, h...*

- **[What source do you trust more when searching for a cosmetic ...](https://www.quora.com/What-source-do-you-trust-more-when-searching-for-a-cosmetic-surgeon-a-YELP-ranking-knowing-that-YELP-filters-reviews-via-algorithms-or-a-GOOGLE-ranking-that-does-not-filter-reviews-and-why)**
  - Source: quora.com
  - *Dec 26, 2019 ... Yelp doesn't interview doctors as a general rule before ... Profile photo for Saeed Khosravi · Saeed Khosravi. Founder & CEO at Nexun...*

- **[What is the most searched thing on Twitter? - Quora](https://www.quora.com/What-is-the-most-searched-thing-on-Twitter)**
  - Source: quora.com
  - *May 17, 2023 ... ... interview with President Donald J. Trump in August 2023, which ... Profile photo for Saeed Khosravi · Saeed Khosravi. Founder & C...*

- **[Is it safe to forcefully deactivate a plugin? I got this: 'WP Rocket has ...](https://www.quora.com/Is-it-safe-to-forcefully-deactivate-a-plugin-I-got-this-WP-Rocket-has-not-been-deactivated-due-to-missing-writing-permissions-Make-htaccess-writeable-and-retry-deactivation-or-force-deactivation-now-The-htaccess)**
  - Source: quora.com
  - *Jan 7, 2019 ... One of the common WordPress interview questions for freshers is ... Profile photo for Saeed Khosravi. Saeed Khosravi. Founder & CEO at...*

- **[What's the best free way to create a 'Ask Us Anything' crowd-sourced ...](https://www.quora.com/Whats-the-best-free-way-to-create-a-Ask-Us-Anything-crowd-sourced-FAQs)**
  - Source: quora.com
  - *Sep 30, 2014 ... Profile photo for Saeed Khosravi. Saeed Khosravi. Founder & CEO at Nexunom ... interviews, focus groups, surveys may help. Upvote ·. ...*

- **[What are the most asked questions on Google currently? - Quora](https://www.quora.com/What-are-the-most-asked-questions-on-Google-currently)**
  - Source: quora.com
  - *Mar 1, 2019 ... What interview questions does Google ask? As you probably know ... Profile photo for Saeed Khosravi. Saeed Khosravi. Founder & CEO at ...*

---

*Generated by Founder Scraper*
