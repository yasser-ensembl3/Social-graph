# David Desjardins

## Position actuelle

**Titre** : Co-Founder & Acting CEO
**Entreprise** : Beyond Food Science
**Durée dans le rôle** : 1 year 1 month in role
**Durée dans l'entreprise** : 1 year 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Résumé

Fueling the next wave of foodtech & agtech innovation 🚀

As a serial entrepreneur, lawyer, and managing partner at Food Tech Factory, I specialize in building impactful ventures from the ground up. My experience spans global markets, enabling me to help create startups that redefine the food industry.

I am driven by the urgent need to make a real difference in this brave new world, where both humanity and our planet face unprecedented challenges. Through my work, I aim to create solutions that balance innovation with responsibility, fostering a future that is not only productive and sustainable but also deeply humane.

What sets my approach apart:

🔍 Insight-driven validation and execution
🤝 Founder-centered, mission-first leadership
🌍 Diverse, international perspective powering innovation
💡 Thoughtful action, letting results speak for themselves

The famous management thinker Peter Drucker said “The most important thing in communication is hearing what isn’t said”, a principle that I follow every day.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAknNtgBUuJTEHd1XDJRARn3v_UDkV1Ay3A/
**Connexions partagées** : 108


---

# David Desjardins

## Position actuelle

**Entreprise** : Beyond Food Science

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# David Desjardins

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397290468386033665 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFsI7l4FrC9mQ/feedshare-shrink_800/B4EZqh0dkuIQAg-/0/1763651480010?e=1766620800&v=beta&t=NnvEJRGY6DaIjQJY35VC8OrsjIghQtQGVEBzsMIyR98 | Wow! Slush in Helsinki is much more than just a conference, it’s a masterclass in event design and community-building. 

This event manages to bring together over 13,000 entrepreneurs, executives, and investors from around the world to a city of only 650,000 residents and they do it in November, when it’s cold, dark, and snowy most of the day... 

Quite impressive. But how do they pull it off?

Here are the 3 core lessons I take away from the Slush approach to events:

1- A seamless experience: Everything at Slush is designed to flow. Baristas serve great coffee, self‑serve fridges are always full of drinks, and lunches are included. No lines, no payments needed, no friction. Hundreds of students from the University of Helsinki and Aalto University volunteer with incredible professionalism. Being part of the organizing crew is seen as a badge of honour, it's not a chore.

2- The right atmosphere: Think futurist techno music, soft lights, and surprisingly comfortable room temperature. There’s a cozy energy that makes conversations more human and relaxed. People actually talk to each other. You keep your jacket on, grab a coffee, and it all feels natural. No clinical or cafeteria-style lighting...

3- Not taking yourself too seriously: Somehow Slush manages to be world‑class and laid‑back at the same time. The organization adds just the right touch of humor, enough to make it feel authentic, not staged. It’s professional without being stiff.

There’s a lot to learn here. Not just about entrepreneurship, but about how to design moments that connect people.

Great job Slush 👏👏👏 | 36 | 6 | 1 | 2w | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:31.004Z |  | 2025-11-20T15:11:22.674Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7390030314540224512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8e22463b-a686-4fe6-87f7-8ae93e328d95 | https://media.licdn.com/dms/image/v2/D4E05AQEZwCmcjXZrDQ/videocover-high/B4EZo6pZTuKsCM-/0/1761920523820?e=1765774800&v=beta&t=gaq4-Ne1Qkfnp9U8xPUO3_3tPe_Ih6c7g1gHUFpNxqU | Happy Halloween! 🎃 

Perfect timing as I get ready for Slush ‘25 in Helsinki, November 19–20. 

If you’ll be there too, let’s connect over coffee, salmon soup, or another Finnish delicacy. Drop me a DM. I’d love to meet fellow founders, investors, and innovators in HEL. | 15 | 0 | 0 | 1mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:31.006Z |  | 2025-10-31T14:22:07.110Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7376011809646092290 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG9RTFnGaj9HA/feedshare-shrink_800/B4EZlzbqAfGYAg-/0/1758578254285?e=1766620800&v=beta&t=eSRSHSIKiKROaYQnsuSdaFohCJeXkYHtqMV2mBO5pbc | 🚀 Big news! Our startup Terrafy Technologies has been named one of the Top 6 AI solutions in Canada at the AgriTech AI Challenge, happening this week at the ALL IN event. Our brilliant co-founder and CSO, Vanessa Grenier, PhD Biologie, will be presenting our work from the last year on stage this Wednesday!

Terrafy is building the world’s first AI platform to map and optimize soil microbiome interactions, because fixing food, capturing carbon, and boosting productivity all begin underground 🌱

******************

🚀 Grande nouvelle ! Notre startup Technologies Terrafy a été désignée comme l'une des six meilleures solutions d'IA au Canada lors du défi AgriTech AI Challenge, qui se déroule cette semaine dans le cadre de l'événement ALL IN. Notre brillante cofondatrice et directrice scientifique, Vanessa Grenier, PhD Biologie, présentera ce mercredi sur scène le travail que nous avons accompli au cours de la dernière année !

Terrafy développe la première plateforme d'IA au monde permettant de cartographier et d'optimiser les interactions du microbiome du sol, car transformer l'alimentation, capter le carbone et stimuler la productivité commencent toutes sous terre 🌱. | 74 | 10 | 4 | 2mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:31.007Z |  | 2025-09-22T21:57:35.092Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7334986968591704066 | Text |  |  | Imagine a not-so-distant future where every conversation has an agent on both sides 👨‍💻 x 🤖

AI Agent 1: Hey, did you process that data?
AI Agent 2: Yes, but I need to double-check it with you.
AI Agent 1: I already double-checked it with you.
AI Agent 2: But I need to verify your double-check.
AI Agent 1: So, should I verify your verification of my double-check?
AI Agent 2: Only if I can cross-validate your verification of my verification.
AI Agent 1: And then we’ll need to audit the cross-validations, right?
AI Agent 2: Exactly! And then we can start again with the first step…
AI Agent 1: (Sighs) Looks like we’re stuck in an infinite loop.
AI Agent 2: Should we call for help?
AI Agent 1: Who would we call? Another AI agent?
AI Agent 2: …Good point. Let’s keep talking! | 15 | 0 | 1 | 6mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.753Z |  | 2025-06-01T16:59:30.780Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7323016479723954176 | Article |  |  | Pour ceux et celles qui veulent comprendre comment l’IA transforme l'industrie agroalimentaire, cet article résume bien l’ampleur des possibilités : croissance annuelle de 34,5 % jusqu’en 2034. Cette croissance dépasse celle du marché global de l'IA, signalant un changement majeur.

C’est exactement cette dynamique qui a motivé la création de Food Tech Factory : nos 4 startups, lancées en 14 mois, intègrent l’IA pour relever les grands défis du secteur. Réduction du gaspillage, contrôle qualité instantané, nutrition personnalisé, monitoring de la santé des sols, prédiction des risques… L’avenir de l’agroalimentaire se construit maintenant 🚀 | 18 | 4 | 1 | 7mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.754Z |  | 2025-04-29T16:13:03.833Z | https://www.forbes.com/sites/daphneewingchow/2025/03/18/these-are-the-latest-ai-trends-transforming-the-food-industry/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7308919286469709827 | Text |  |  | 👏👏👏 | 7 | 0 | 0 | 8mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.754Z |  | 2025-03-21T18:35:51.048Z | https://www.linkedin.com/feed/update/urn:li:activity:7308905363704094720/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7305261769537519616 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7a064114-5fb6-4375-8805-b9b6c056eaee | https://media.licdn.com/dms/image/v2/D5605AQHcJoIGhsGi1A/videocover-low/B56ZWFpwIaGUCc-/0/1741704242824?e=1765774800&v=beta&t=QbQ-iOD2W3_1yS12CdGysu2pZDHKishTSV4aeIrYKhM | I love this. It says it all. If Canada or the US ever goes into a recession, it will be one person's self made recession, it will be Mr. Trump's recession.

🇺🇸🫶🇨🇦 | 8 | 0 | 0 | 8mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.755Z |  | 2025-03-11T16:22:11.058Z | https://www.linkedin.com/feed/update/urn:li:activity:7305237239876268033/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7292960720239878145 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHmydlRySbHSw/feedshare-shrink_800/B4EZTRXOy1HUAg-/0/1738679316561?e=1766620800&v=beta&t=nEgeTOcpsAPEQFsSj-7f58kIXdVZiISgZOLIKe56ERg | 📢 Introducing the first ever report on the foodtech ecosystem in Canada🍁

I'm proud to see Food Tech Factory shine as a specialist venture studio, and to contribute as an industry expert. Here are my thoughts on the current state of the sector:

“Canada’s foodtech industry has undergone a remarkable evolution, marked by growth and diversification of innovation. But we need to do more. Canadian productivity is at an all-time low, and the food industry is the slowest to adopt technology. Technology is here to help us change things for the better.”

A big well done to the teams at the Canadian Food Innovation Networkand Forward Fooding for this great work👏 👏 👏

****

📢 Voici le tout premier rapport sur l'écosystème foodtech au Canada🍁

Fier de voir Food Tech Factory briller comme venture studio spécialisé et d'y contribuer en tant qu'expert de l'industrie. Voici ma réflexion sur l'état actuel du secteur:

« Le secteur canadien des technologies alimentaires a connu une évolution remarquable, marquée par la croissance et la diversification de l'innovation. Mais nous devons en faire plus. La productivité canadienne n'a jamais été aussi faible et l'adoption des technologies au sein du secteur alimentaire est lente. Les technologies sont là pour nous aider à changer les choses pour le mieux. »

Un grand bravo aux équipes de Canadian Food Innovation Networket Forward Fooding pour ce super travail👏 👏 👏 | 20 | 1 | 4 | 10mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.757Z |  | 2025-02-05T17:42:12.363Z | https://www.linkedin.com/feed/update/urn:li:activity:7292549618150592513/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7279938208337956864 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkTUmzpeZDpg/feedshare-shrink_800/B4EZQeJOI0HsAg-/0/1735672521814?e=1766620800&v=beta&t=1P-tKgOMmuZG5P7yVUY7sp54EGDHb4UNj7BWqoLMcpM | 🌟 Happy New Year 2025, LinkedIn Network! 🌟 This year, let’s strive for more of what brings us joy and purpose, while releasing less negativity, less doubt, and less distraction. Wishing you all a prosperous and inspiring New Year filled with countless opportunities!

******

🌟 Bonne année 2025, réseau LinkedIn ! 🌟 Cette année, efforçons-nous d'obtenir davantage de ce qui nous apporte joie et raisons d'être, tout en libérant moins de négativité, de doute et de distractions. Je vous souhaite à tous une nouvelle année prospère et inspirante, remplie d'innombrables opportunités ! | 28 | 1 | 0 | 11mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.758Z |  | 2024-12-31T19:15:23.579Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7275137376631324672 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHYgObGr2odVw/feedshare-shrink_800/B4EZPXJ9v3GYAg-/0/1734481534564?e=1766620800&v=beta&t=OkbjpNrf4ayLcdxGrstIWM6tmLfGjPv43CQ375UZzTU | L'équipe d'experts s'agrandit et nous avons des projets passionnants avec toi en vue, Tariq 🤝 | 9 | 2 | 2 | 11mo | Post | David Desjardins | https://www.linkedin.com/in/david-desjardins-mtl | https://linkedin.com/in/david-desjardins-mtl | 2025-12-08T04:51:35.759Z |  | 2024-12-18T13:18:36.105Z | https://www.linkedin.com/feed/update/urn:li:activity:7275132790214389760/ |  | 

---



---

# David Desjardins
*Beyond Food Science*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [News | Beyond Food Safety Insights](https://www.beyondfoodscience.com/blog-categories/news)
*2024-11-27*
- Category: blog

### [](https://www.beyondfs.co/blog-posts/beyond-a-strategic-spin-off)
- Category: blog

### [David Desjardins Email Address (Lassonde)](https://anymailfinder.com/directory/lassonde.com/people/david-desjardins)
*2025-07-12*
- Category: article

### [Ep. 098 - How to Be A Certified Food Scientist Without Being a Food Scientist with David Despain, Director of Science Communications at Isagenix International - My Food Job Rocks!](https://myfoodjobrocks.com/098david/)
*2017-12-25*
- Category: article

### [JM Fortier Interviews Dave Chapman](https://realorganicproject.org/jm-fortier-interviews-dave-chapman-episode-one-hundred-eighty/)
*2024-07-18*
- Category: article

---

## 📖 Full Content (Scraped)

*6 articles scraped, 21,633 words total*

### News | Beyond Food Safety Insights
*132 words* | Source: **EXA** | [Link](https://www.beyondfoodscience.com/blog-categories/news)

[![Image 1](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fd7dbbd49ef5f18e6d1280_beyond_logo_small.svg)](https://www.beyondfoodscience.com/)

*   [solution](https://www.beyondfoodscience.com/solution)
*   [platform](https://www.beyondfoodscience.com/platform)
*   [work](https://www.beyondfoodscience.com/work)
*   [news](https://www.beyondfoodscience.com/news)
*   [about](https://www.beyondfoodscience.com/about)
*   [Instagram ![Image 2](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.instagram.com/)[Likedin ![Image 3](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.linkedin.com/)[Dribbble ![Image 4](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://dribbble.com/)[X ![Image 5](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://x.com/)language [English](https://www.beyondfoodscience.com/blog-categories/news) [French](https://www.beyondfoodscience.com/fr-ca/blog-categories/news)    

[connect Connect ![Image 6](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)![Image 7](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg) ‍](https://www.beyondfoodscience.com/contact)

Read articles
-------------

We invite you to read our articles for valuable insights and trends on design.

Category

[All](https://www.beyondfoodscience.com/work)[News](https://www.beyondfoodscience.com/blog-categories/news)

[All](https://www.beyondfoodscience.com/work)[Hyperspectral](https://www.beyondfoodscience.com/blog-categories/hyperspectral)

[All](https://www.beyondfoodscience.com/work)[Artificial intelligence](https://www.beyondfoodscience.com/blog-categories/artificial-intelligent)

[All](https://www.beyondfoodscience.com/work)[Innovation](https://www.beyondfoodscience.com/blog-categories/innovation)

[All](https://www.beyondfoodscience.com/work)[Processes](https://www.beyondfoodscience.com/blog-categories/processes)

![Image 8](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a0f7dcd2ae2a638000c9_blog-spin-off-v1.jpg)

[View](https://www.beyondfoodscience.com/blog-posts/beyond-a-strategic-spin-off)

November 27, 2024

News

[##### Introducing beyond: a strategic spin-off to revolutionize food safety and quality](https://www.beyondfoodscience.com/blog-posts/beyond-a-strategic-spin-off)

##### elevating food safety beyond human vision

[![Image 9](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fd7eff00ac03db68053768_Group%20109.svg)](https://www.beyondfoodscience.com/blog-categories/news#)

1435 St-Alexandre, Suite 700, Montreal (Quebec) Canada

[Linkedin ![Image 10](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.linkedin.com/company/beyond-food-science/)

[home ![Image 11](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/)[solution ![Image 12](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/solution)[platform ![Image 13](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/platform)[work ![Image 14](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/work)[impact ![Image 15](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/news)[about ![Image 16](https://cdn.prod.website-files.com/66fa01010fa05b6e9c625d26/66fa01020fa05b6e9c625db4_arrow-right-menu.svg)](https://www.beyondfoodscience.com/about)

language

[English](https://www.beyondfoodscience.com/blog-categories/news)

[French](https://www.beyondfoodscience.com/fr-ca/blog-categories/news)

Newsletter for updates

Thank you! Your submission has been received!

Oops! Something went wrong while submitting the form.

© Beyond Food Science Inc., 2025

---

### Introducing beyond: a strategic spin-off to revolutionize food safety and quality
*408 words* | Source: **EXA** | [Link](https://www.beyondfs.co/blog-posts/beyond-a-strategic-spin-off)

### Introducing beyond: a strategic spin-off to revolutionize food safety and quality

News

![Image 1](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a0f7dcd2ae2a638000c9_blog-spin-off-v1.jpg)

#### _beyond_ is the result of a collaboration between two leaders in food technology innovation: [Cintech Agroalimentaire](https://cintech.ca/en/), a renowned innovation and applied research centre, and [Food Tech Factory](https://www.foodtechfactory.ca/), a creative studio dedicated to launching innovative technology start-ups in the food and agriculture sector. Cintech has developed cutting-edge expertise in the fields of spectroscopy and hyperspectral imaging (HSI), which will be brought to market with the entrepreneurial technological expertise of Food Tech Factory to create _beyond_, a new technology company dedicated to ensuring food quality, safety and sustainability through artificial intelligence.

##### **What is _beyond_?**

Following the creation of an innovative spectroscopy and HSI platform developed in 2016 to improve quality control and food safety, Beyond integrates this technology with advanced capabilities in artificial intelligence, cloud computing and machine learning.

‍

This revolutionary platform offers food companies unrivalled accuracy in detecting contaminants, optimising production efficiency and reducing food waste. Proven in a wide range of sectors, including meat, poultry, vegetables, fruit, nuts, chocolate and dairy, _beyond_ enables food chain stakeholders, from producers to retailers, to achieve new standards of food safety and quality.

##### **A Visionary Partnership**

The collaboration between Cintech and Food Tech Factory represents a turning point in the evolution of HSI for the food industry. Highlights of this partnership include:

*   Access to Cintech's unique expertise: state-of-the-art laboratories, robust equipment and unrivalled expertise in food science and industrial hyperspectral vision.
*   Food Tech Factory role: commercialization of Beyond's enhanced platform through an entrepreneurial approach, positioning Beyond as a world leader.

##### **Key Features of _beyond’s_ Offering**

*   Enhanced food safety: Contaminant detection and compliance with the most stringent safety standards.
*   Optimized quality control: Texture, maturity and freshness analysis with unrivalled accuracy.
*   Increased efficiency: Process automation to overcome labor shortages and minimize resource wastage.
*   Reduce food waste: Identification of defects and optimization of inputs for a sustainable production process.

##### **Empowering the Food Industry**

Beyond is a movement to redefine food safety and sustainability by combining the research expertise of Cintech Agroalimentaire with the commercialization expertise of Food Tech Factory. Beyond offers innovative solutions that bridge the gap between food science and industrial applications.

‍

For more information about Beyond and how it can revolutionize your food processing operations, contact us today:

‍

![Image 2](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a99985d88d9806d72a75_6747a9199dea0726a5d4f6f5_cintech.png)

‍**Cintech**

Michaela Skulinova, [mskulinova@cintech.ca](mailto:mskulinova@cintech.ca)

‍

![Image 3](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a99985d88d9806d72a71_6747a841b8ab7e65a1ebf1d5_logo_food_tech_factory.png)

**Food Tech Factory / _beyond_**David Desjardins, [info@beyondfs.co](mailto:info@beyondfs.co)

---

### David Desjardins Email Address (Lassonde)
*310 words* | Source: **EXA** | [Link](https://anymailfinder.com/directory/lassonde.com/people/david-desjardins)

![Image 1: Logo of Lassonde](https://directory-cdn.anymailfinder.com/d3e44639-e035-4ad3-bfbd-3a7e5c180d43)

abcdefghij@lassonde.com
-----------------------

**Need many emails like this?**Find your leads with our[Browser Extension](https://chromewebstore.google.com/detail/email-finder-by-anymailfi/jejkgijkhbdnekbbdonkikkfdmlfmdol).If you already have names, use our Email Finder by Name (available in [Bulk](https://anymailfinder.com/bulk-email-finder) or via[API](https://anymailfinder.com/email-finder-api) too).

**Job Title**

Director, Consumer Relations and Regulatory Affairs, North America

**Company**

[**Lassonde**](https://anymailfinder.com/directory/lassonde.com)

At Lassonde, our vast array of brands offers a multitude of quality products that already have an established reputation

**Bio**

Director, Consumer Relations & Regulatory Affairs, North America @ Lassonde Industries

**Last University**

Went to

Université de Montréal / University of Montreal

**Location**

Is based in

Montreal, Quebec, Canada

.

**Linkedin**

### Other people working at Lassonde:

[Stefano Bertolli](https://anymailfinder.com/directory/lassonde.com/people/lassonde)Vice President, Public Affairs and Strategic Communications

[Mathieu Simard](https://anymailfinder.com/directory/lassonde.com/people/mathieu-simard)Vice-président Principal Ressources Humaines

[Caroline Croteau](https://anymailfinder.com/directory/lassonde.com/people/caroline-croteau)Directrice Principale Marketing Et Ventes Senior Director Marketing and Sales

[Eric Gemme](https://anymailfinder.com/directory/lassonde.com/people/eric-gemme)Senior Executive With Strong Finance Background

[Patel](https://anymailfinder.com/directory/lassonde.com/people/patel20)**********@lassonde.com

### How does this work?

Anymail finder is trusted by tens of thousands of companies to provide[accurate contact information](https://anymailfinder.com/email-verifier)to their Sales and Business Development teams.

If you're looking to find the email of David Desjardins at Lassonde then you've come to the right place.

Wondering if it's david@lassonde.com,david.desjardins@lassonde.com,desjardins@lassonde.com, or d desjardins@lassonde.com? We have the answers for you.

Boost your outreach, supercharge your workflow
----------------------------------------------

Tips to maximize your Email Finder ROI

[View All Posts](https://anymailfinder.com/blog)

©

2025

AMF Internet Services Limited

Registered in the UK, number 10586048

AMF Internet Services Limited is not affiliated, associated, authorized, endorsed by, or in any way officially connected with Microsoft or LinkedIn, or any of their subsidiaries or affiliates. By using the Anymail finder browser extension, you agree to abide by LinkedIn's terms of service and take full responsibility for any actions taken through its use. The name LinkedIn, as well as related names, marks, logos, emblems, and images are registered trademarks of their respective owners.

This website uses cookies. By using it, you accept the terms of our [Privacy Policy](https://anymailfinder.com/legal/privacy-policy).

---

### Ep. 098 - How to Be A Certified Food Scientist Without Being a Food Scientist with David Despain, Director of Science Communications at Isagenix International - My Food Job Rocks!
*1,160 words* | Source: **EXA** | [Link](https://myfoodjobrocks.com/098david/)

[![Image 1](https://i0.wp.com/myfoodjobrocks.com/wp-content/uploads/2017/12/Ep-098.png?resize=778%2C438)](https://myfoodjobrocks.com/098david/ep-098/)

I met David before joining Isagenix during my first meeting in [Cactus IFT](http://cactusift.org/), the Arizona section of IFT.

When I interviewed at Isagenix about a year later, I said “wait, I know you”

Over time, David and I have become best coworkers and we talk about food, travel, IFT leadership stuff, and developing cool products for Isagenix.

David is passionate about many things. Nutrition, exercise science, traveling, nature and of course, food science. He is a writer, or rather, a writer who manages other writers. However, as an avid learner, David decided to get his [Certified Food Scientist](http://www.ift.org/certification.aspx) certification after being heavily involved in IFT.

Whether you’re interested in the CFS certification or not, we talk about the whole process and what it takes to become one including some insider and candid tips for success.

Since David is a science writer, we also talk about how to write well, and where to find information to write about. For example, some websites and organizations have more credibility than others, and the source that not many people know about, happens to be nutrition conferences!

About David
-----------

David Despain, MS, CFS, is a science and health writer, a nutritionist, and a budding Certified Food Scientist who is based in Gilbert, Arizona. David has had over a decade of experience being involved in the world of food and nutrition yet he only recently earned his CFS credential from the Institute of Food Technologists in August 2017. He’s currently the Director of Science Communications within the Research and Development Department at Isagenix, a health-and-wellness company. Previously, David has also written for various publications about food and nutrition including Food Technology magazine, American Society for Nutrition’s Nutrition Notes Daily, Outside Online, and Scientific American Online.

* * *

Sponsor – FoodGrads
-------------------

If you are even just a little bit interested in a career in food & beverage, you should join FoodGrads. It’s an interactive platform where you can hear about different careers, hear from your peers, have a voice and share your story as well as ask specific questions and get feedback from industry experts across the sector.

You can create a profile, add your resume and search for co-op, internships and full time opportunities just for Food Grads. Employers can find you too, they can recruit you for jobs and projects they need help with to give you the relevant industry experience you need.

Join FoodGrads today! Just go to[Foodgrads.com](http://foodgrads.com/)

Sponsor – ICON Foods
--------------------

What’s worse than marketing saying, ‘we have to clean up these sugars?’

They want clean label sugar reduction because that’s the trend.

So I advise you to skate to where the puck is going. Whether it’s to make your product a bit healthier or following the ever-changing FDA laws, my friends at Icon Foods – formerly Steviva Ingredients – are here to help. They have more than 20 years of R&D experience with natural sweeteners and sweetening systems in a wide range of applications. With a product list of twenty different sweeteners and plug-in sweetening systems that keeps growing, you can’t go wrong. Check out[stevivaingredients.com](http://stevivaingredients.com/)to learn about the newest all-natural sweetener solutions and collaboration opportunities.

For more information, visit ICON foods at[ICONfoods.com](http://iconfoods.com/)

* * *

Key Takeaways
-------------

*   How David became a part-time stock broker
*   The best place to find quality nutrition news
*   How David started to develop a passion for science writing from an English Professor

Question Summary
----------------

**Cal Poly Professors:** Dr. Amy Lammert and Dr. Robert Kravets

 Prep course IFT2017

**When someone asks what you do for a living:** I’m a nutritionist who works for R+D and head a team of nutritionists that educate the consumer

**Best Thing about Your Job:** To learn something new every day

 Nutrition Conferences

 Exercise Science Conferences

**Describe the path that got to where you are today:** I studied Biology. Got a MS in Nutrition Science. Found out how Nutrition Science had a lot of conflicting views.Got interested in Nutrition Science first, then Exercise Science, then Food Science!

**How did David get involved in Food Science?:** Chair of the Cactus IFT person asked David to create the newsletter. Then David was hired on as a writer in IFT

**Notes on the CFS Course**

 For me, it was a 2 year process

 I attended 2 [CFS short courses](http://www.ift.org/meetings-and-events/short-courses/cfs-prep-course.aspx)

 I read all of the textbooks, and I had a challenge with [Food Engineering](https://myfoodjobrocks.com/042amit/)

 The test was a lot harder th

*[... truncated, 3,940 more characters]*

---

### JM Fortier Interviews Dave Chapman
*19,215 words* | Source: **EXA** | [Link](https://realorganicproject.org/jm-fortier-interviews-dave-chapman-episode-one-hundred-eighty/)

Episode #180

 JM Fortier Interviews Dave Chapman 
Organic Farmer and Real Organic Project co-director Dave Chapman discusses the corporate takeover of the organic label and his founding of the Real Organic Project as a response. After discovering hydroponic produce being certified organic against standards, Chapman realized a larger pattern of abuse including confined livestock operations producing “organic” milk and eggs. “We are going to have to stand and fight,” Chapman declares, explaining that corporate interests can’t be outrun by simply creating new terms like “regenerative.” He emphasizes that building a movement requires both personal integrity and strategic activism: “The world needs our movement. So we need to have a movement.”

_Our transcript of JM interviewing Dave has been edited and condensed for clarity._

Or stream the audio-only version here:

**JM Fortier interviews Dave Chapman, Spring 2024 :**

Dave Chapman 0:00

 The speed, the rapidity with which regenerative became this thing… and of course, there are lots of people who just wanted an alternative to what they saw as a degraded organic standard. And, and I have to take responsibility, because I’ve been one of the biggest mouths, saying that there are problems with organic. And there are, but I did not come to destroy organic, I come to save it. If we said, “You know what, screw it. I’m done with organic. I’m going regenerative.” Well, good luck with that, because that word’s already lost. For what you mean by it, and what I would mean by it, it’s gone. It’s gone. It’s (now) so you’ve got to keep coming up with a new word. And they’re getting so good at it. It’s basically, the moment that you start to get some, some cultural embrace of what you’re doing, they go “Oh, good. We’re with them.” We can’t outrun them. You know, there are serious, serious forces at play here. And we won’t outrun them and we won’t out trick them. And we are going to have to stand and fight.”

Linley Dixon 1:15

 Welcome to The Real Organic Podcast. I’m Linley Dixon, co director of the Real Organic Project. We’re a grassroots, farmer-led movement with an add-on organic food label to distinguish organic crops grown in healthy soils, and organic livestock raised on well-managed pasture. Today’s episode is a big pivot for us, as we’re actually sharing an episode from another podcast. Our friend – farmer, author and television star, JM Fortier began his own show this past spring called [The Market Gardener Podcast](https://themarketgardener.com/podcast/) and co director Dave Chapman was his very first guest. So we hope you enjoy and take some time to explore the other episodes that JM and his team have put together. Otherwise, we’ll be back to it next week with another great interview from the organic movement.

JM Fortier 2:07

 Hey, today’s a very special guests, somebody that I really like; Dave Chapman from the Real Organic Project. And it’s going to be an interesting session because I know Dave, that you’re a great, not a history explainer, but kind of like setting the stage for what’s going on, what happened. And obviously a lot of people that have been following my work and recently, Chris, a we’ve been coming coming strong with with this message of you know, fighting back against corporate takeover of organics. That’s right. So that’s really why you’re here. So welcome to the show.

Dave Chapman 2:42

 Thank you, JM. So, so happy to be here.

JM Fortier 2:45

 I’ve become a bit more vocal because of you. And because I really care about it, about not just what happened, but like the bigger picture. And you’re obviously somebody that I love to talk to, because it always makes it clearer for me and I’m getting more.. getting more conscious about this aligns me more more with my actions. Like it reminds me of why I wanted to farm and why I’m still involved in farming. It feels that, it feels good to be kind of fighting something. Yeah, it brings me energy to be, I’ve always been a rebel. So just like the fact that we’re, yes, we’re promoting something. And yes, we’re doing it with enthusiasm. But we’re, we’re fighting bad guys. In a way.

Dave Chapman 3:32

 Organic has always been an insurgency, it always has been. And, you know, it’s people say, Well, we shouldn’t be defined by fighting against something. But what it is that we genuinely are fighting against is huge. It’s so powerful. And it does need to be fought against it doesn’t mean we do need to create it, we can say it more positively. We’re creating the alternative. We’re creating the positive path. But we shouldn’t we shouldn’t fool ourselves into thinking that this is going to be easy. We are up against the dominant economic model that that rules our world, which is the food system and all the money around it. Yeah. So yeah, this is a big deal. You know, you talk about you know, we need to think bigger. I was in California, maybe last summer, and I was driving around and I just visited Paul Hawken

*[... truncated, 204,290 more characters]*

---

### Introducing beyond: a strategic spin-off to revolutionize food safety and quality
*408 words* | Source: **GOOGLE** | [Link](https://www.beyondfoodscience.com/blog-posts/beyond-a-strategic-spin-off)

### Introducing beyond: a strategic spin-off to revolutionize food safety and quality

News

![Image 1](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a0f7dcd2ae2a638000c9_blog-spin-off-v1.jpg)

#### _beyond_ is the result of a collaboration between two leaders in food technology innovation: [Cintech Agroalimentaire](https://cintech.ca/en/), a renowned innovation and applied research centre, and [Food Tech Factory](https://www.foodtechfactory.ca/), a creative studio dedicated to launching innovative technology start-ups in the food and agriculture sector. Cintech has developed cutting-edge expertise in the fields of spectroscopy and hyperspectral imaging (HSI), which will be brought to market with the entrepreneurial technological expertise of Food Tech Factory to create _beyond_, a new technology company dedicated to ensuring food quality, safety and sustainability through artificial intelligence.

##### **What is _beyond_?**

Following the creation of an innovative spectroscopy and HSI platform developed in 2016 to improve quality control and food safety, Beyond integrates this technology with advanced capabilities in artificial intelligence, cloud computing and machine learning.

‍

This revolutionary platform offers food companies unrivalled accuracy in detecting contaminants, optimising production efficiency and reducing food waste. Proven in a wide range of sectors, including meat, poultry, vegetables, fruit, nuts, chocolate and dairy, _beyond_ enables food chain stakeholders, from producers to retailers, to achieve new standards of food safety and quality.

##### **A Visionary Partnership**

The collaboration between Cintech and Food Tech Factory represents a turning point in the evolution of HSI for the food industry. Highlights of this partnership include:

*   Access to Cintech's unique expertise: state-of-the-art laboratories, robust equipment and unrivalled expertise in food science and industrial hyperspectral vision.
*   Food Tech Factory role: commercialization of Beyond's enhanced platform through an entrepreneurial approach, positioning Beyond as a world leader.

##### **Key Features of _beyond’s_ Offering**

*   Enhanced food safety: Contaminant detection and compliance with the most stringent safety standards.
*   Optimized quality control: Texture, maturity and freshness analysis with unrivalled accuracy.
*   Increased efficiency: Process automation to overcome labor shortages and minimize resource wastage.
*   Reduce food waste: Identification of defects and optimization of inputs for a sustainable production process.

##### **Empowering the Food Industry**

Beyond is a movement to redefine food safety and sustainability by combining the research expertise of Cintech Agroalimentaire with the commercialization expertise of Food Tech Factory. Beyond offers innovative solutions that bridge the gap between food science and industrial applications.

‍

For more information about Beyond and how it can revolutionize your food processing operations, contact us today:

‍

![Image 2](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a99985d88d9806d72a75_6747a9199dea0726a5d4f6f5_cintech.png)

‍**Cintech**

Michaela Skulinova, [mskulinova@cintech.ca](mailto:mskulinova@cintech.ca)

‍

![Image 3](https://cdn.prod.website-files.com/66fa01020fa05b6e9c625d8b/6747a99985d88d9806d72a71_6747a841b8ab7e65a1ebf1d5_logo_food_tech_factory.png)

**Food Tech Factory / _beyond_**David Desjardins, [info@beyondfs.co](mailto:info@beyondfs.co)

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Introducing beyond: a strategic spin-off to revolutionize food safety ...](https://www.beyondfoodscience.com/blog-posts/beyond-a-strategic-spin-off)**
  - Source: beyondfoodscience.com
  - *Nov 28, 2024 ... David Desjardins, info@beyondfs.co. elevating food safety beyond human vision. 1435 St-Alexandre, Suite ... © Beyond Food Science Inc...*

---

*Generated by Founder Scraper*
