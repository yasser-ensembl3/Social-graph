# Jonathan Rouxel

## Position actuelle

**Titre** : Founder & Creative Director
**Entreprise** : Prologue
**Durée dans le rôle** : 6 years 11 months in role
**Durée dans l'entreprise** : 6 years 11 months in company

## Localisation & Industrie

**Localisation** : Mont-Royal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Building Prologue's AI products with world-class partners. Initiating and leading innovative entertainment content from concept to completion. Managing an award-winning team of engineers, designers, and artists to create groundbreaking AI content. Planning business strategies for scaling product development and real-time pipeline for AI content.

Judging and Speaking engagements :
-- AToMiC Awards 2021
-- Digital summit 2020
-- Marketing awards 2019
-- Crea president 2018
-- Cannes Lions, Master of Creativity 2016, 2017, 2018

## Résumé

I’ve spent almost 20 years in the creative world — leading campaigns, telling stories, and pushing ideas further than they “should” go. As Executive Creative Director and Partner at agencies like Cossette, Dare, BCP, and BBR, I’ve had the chance to work with incredible teams and help clients win over 250 national and international awards — from golden lions to quirky misshapen letters of the alphabet — for brands like Ubisoft, Molson and USA Network.

In 2019, I took a leap and started building something of my own: a platform that uses the power of AI to tackle one of the biggest creative challenges today — how to make high-quality content faster, smarter, and at scale. Since then, we’ve grown into one of the most advanced AI-first content production platforms out there, helping creators around the world “create the unseen” with tools that make AI’s potential accessible to everyone.

My mission is simple:  Building tools that help creatives craft better stories on their own terms. I believe generative AI can transform how stories are told, lowering the barriers for creators and brands alike. 

Today, I’m based in Montréal, working with a global team of innovators, creators, and technologists to shape the future of media. And I’m always open to connecting with people who share the same passion for creativity, technology, and new possibilities.

https://linktr.ee/jorouxel

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAOEDccBqZToVmbtmgjN_Uqo8VDU0pvZGy4/
**Connexions partagées** : 133


---

# Jonathan Rouxel

## Position actuelle

**Entreprise** : Prologue AI

## Localisation & Industrie

**Localisation** : Mont-Royal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Jonathan Rouxel
*Prologue AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [How A True Crime Game's Faulty Design may Prove Fatal](https://medium.com/@mrmoali68/how-a-true-crime-games-faulty-design-may-prove-fatal-d7b5b86e2398)
*2023-12-08*
- Category: blog

### [Software](https://arpost.co/category/software/feed/)
- Category: article

### [AGENCY OF THE YEAR - Strategy](https://strategyonline.ca/content/pdf/51816.pdf)
- Category: article

### [Prologue XR Used Conversational AI Tech To Create The Heist of the Century Game](https://beyondgames.biz/38370/prologue-xr-used-conversational-ai-tech-to-create-the-heist-of-the-century-game)
*2023-06-23*
- Category: article

### [This is going to change the game: https://lnkd.in/e9Vc4Fni 

“We present… | Jonathan Rouxel](https://ug.linkedin.com/posts/jonathan-rouxel_text-to-4d-dynamic-scene-generation-activity-7024790657353273344-5mW4)
*2023-01-27*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Jury 2020 - PRIX NUMIX](https://numix.ca/jury-2020/)**
  - Source: numix.ca
  - *... podcast Mon Carnet. Voir la fiche · Jean-François Grenier. Concepteur d ... Jonathan Rouxel. Co-fondateur et directeur de création – Prologue AI. ...*

- **[DOCU 20 : Le balado qui interroge les solutions technologiques ...](https://music.amazon.com/podcasts/54d33f21-eaaf-45e7-8471-33f26bbfeaf9/docu-20-le-balado-qui-interroge-les-solutions-technologiques)**
  - Source: music.amazon.com
  - *L'occasion de faire une balade inédite dans la ville avec Jonathan Rouxel, co-fondateur de Prologue AI, une start-up de création de contenus interacti...*

- **[AToMiC Awards Judges](https://atomicawards.strategyonline.ca/Juries/Judges/2021)**
  - Source: atomicawards.strategyonline.ca
  - *... Conference, Mashable, Fast Company and The Huffington Post, just to name ... Jonathan Rouxel Founder, CD Prologue AI. Bio. Jonathan Rouxel is a cr...*

- **[Prologue - L'Effet Québec : L'Effet Québec](https://effetquebec.ca/entreprises/prologue/)**
  - Source: effetquebec.ca
  - *info@prologue.ai · site web. Responsable développement des affaires. Jonathan Rouxel. PDG, directeur de création. Responsable des communications. Léa ...*

- **[EAI-FR-Rapport Activités 2021-22](https://entertain-ai.com/wp-content/uploads/2022/11/EAI-FR-Rapport-Activite%CC%81s-2021-22.pdf)**
  - Source: entertain-ai.com
  - *Rouxel (Prologue AI). Hub Montréal. Pixel IA. Cette initiative était ... Lavery Avocats avec Jonathan Rouxel. Moov AI avec Olivier Blais. Cocktail d ....*

- **[Prologue AI | Crafted, not generated. A professional-grade GenAI ...](https://prologue.ai/about)**
  - Source: prologue.ai
  - *Prologue AI is the all-in-one GenAI studio where professionals craft ideas ... Our founder, Jonathan Rouxel, spent two decades crafting award-winning ...*

- **[▷ MT Lab - Incubateur d'innovations en tourisme, culture et ...](https://ecolesmontreal.com/ecoles-commerce-dentrepreneuriat/formations-creation-start-up/mt-lab-incubateur-dinnovations-en-tourisme-culture-et-divertissement/)**
  - Source: ecolesmontreal.com
  - *Jonathan Rouxel. Great accelerator in tourism, culture and entertainment ... Prologue AI. Super accélérateur rempli d'énergie positive. Prologue AI ☆ ...*

- **[Des publicités 100 % IA ? | La Presse](https://www.lapresse.ca/affaires/l-ia-au-service-de-la-pub/2025-01-04/des-publicites-100-ia.php)**
  - Source: lapresse.ca
  - *Jan 4, 2025 ... Jonathan Rouxel, fondateur et directeur artistique de Prologue AI, un studio de création avec l'IA. Selon M. Rouxel, les modèles de .....*

---

*Generated by Founder Scraper*
