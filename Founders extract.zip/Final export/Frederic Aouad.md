# Frederic Aouad

## Position actuelle

**Titre** : Chief Commercial Officer (CCO)
**Entreprise** : Stay22
**Durée dans le rôle** : 1 year 11 months in role
**Durée dans l'entreprise** : 6 years 3 months in company

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area
**Industrie** : Software Development

## Description du rôle

As the Chief Commercial Officer at Stay22, I spearhead the comprehensive Go-To-Market (GTM) strategy, overseeing sales, customer success, marketing, and Revenue Operations (RevOps). Leading a dynamic team of over 20 professionals, my role focuses on driving growth and optimizing commercial operations to ensure we deliver exceptional value to our partners and stakeholders. 
Under my leadership, our innovative solutions now reach over 1 billion users, leveraging cutting-edge technology to enhance user experience and engagement. 

My mission is to sustain and accelerate Stay22's market presence by continuously improving our offerings and expanding our global footprint.

## Résumé

My 17-year career in revenue leadership started by accident. I was working nights as a hotel security guard to support my political science studies. 

A conversation with the GM led to my first sales role, which sparked my career in sales and GTM in the travel space. 

In 2019, I joined Stay22 as Head of Sales just months before the pandemic. We were dangerously close to dying. With a mix of luck and ridiculously hard work, we doubled down and built multiple technologies across travel verticals. 

We've since grown 50x our pre-pandemic revenue, reached over 1 billion users, and built a mainly bootstrapped, profitable company that is expected to process $600M in GMV

Now as CCO, I lead a team of 30+ across sales, marketing, customer success and RevOps.

Currently splitting time between Stay 22 and building the GTM community in Montreal as a Pavillion Chapter Head. 

Also a BJJ black belt because… Why not?

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAPxZ1kBrHVSCwgPygB-ssCcHKaVf8TeSMY/
**Connexions partagées** : 190


---

# Frederic Aouad

## Position actuelle

**Entreprise** : Stay22

## Localisation & Industrie

**Localisation** : Greater Montreal Metropolitan Area

## Connexion

**Degré de connexion** : 2nd


---

# Frederic Aouad

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402704102155059200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPnuZjXrbrVg/feedshare-shrink_800/B4EZruwJN8GcAk-/0/1764942190841?e=1766620800&v=beta&t=NwKke2qELMhNbhM773yWX0zuREEwaHqU1tvxp0Qj_Ms | No man is an island… and no company becomes a rocket ship by sitting alone on its launchpad. 🚀

Partnerships matter, a lot. 💪

And one of the most impactful partnerships we’ve ever built at Stay22 has been with none other than Booking.com — the global travel powerhouse of inventory, conversion, and “yes, we have a room for that.” Their depth, their coverage, their tech-first mindset, and their direct affiliate API have been game-changers for us. 
They help us put the right travel offer in front of the right user at exactly the right moment — which, for a company like ours, is pure rocket fuel.

But that’s actually not the point of this post.👇

What blew my mind this week was being invited to the Booking.com North American Summit (an internal event) as one of the only external partners asked to come speak and share our story.

Little Frederic from little Stay22, the same crew who was clawing through the pandemic just four or five years ago… now standing on stage at a 
Booking.com summit. 

That’s wild. 😜
It’s humbling. 

And it’s a massive testament to what strong partnerships can unlock when both sides show up with ambition, transparency, and a willingness to build.

Huge kudos to the Strategic Partnerships team for the years of support and for the awesome time in Grand Rapids: Cintia O Tavella Gomez, Jennifer Huang, and Myles Darcy — you guys are fantastic. 

(Kyle J. Dunster & Jeremy Cornuau, don’t worry, I didn’t forget you. 😄 Hopefully we connect next time!)

Thank you, Booking.com, for the trust and collaboration.

Here’s to more growth, more shared wins, and more proof that partnerships aren’t a “nice to have” : they are the multiplier.

Onward. 🚀 | 67 | 5 | 0 | 2d | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.886Z |  | 2025-12-05T13:43:13.545Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402361102954614784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFoNjz-rGpVZw/feedshare-shrink_800/B4EZrpuA9cKYAg-/0/1764857745922?e=1766620800&v=beta&t=iAlMXIX9Rd2hh2-gbRqy9Wwwh1CU4Z6bj2zJ2kPqb_M | I respect every publisher who pushes back on a new tool because they want to keep their site clean. Protecting the user experience is priority number one. 

But we have to be honest about the trade-offs we are already making.

We often tolerate auto-play videos or shifting layouts from programmatic ads because we need the revenue. We have become used to them and accept them as the cost of doing business.

Yet when a new opportunity comes with a promise of new revenue, we hesitate to protect UX. We worry a new tab or a specific widget might confuse the user.

We tend to judge the new solution much harder than the ones we have.

If we are willing to run standard display ads to keep the lights on, we should be willing to test a solution that helps readers purchase they are already reading & engaging with.

It is not about abandoning standards. 
It is about being a better person, and testing before making revenue decisions.

Don't let the fear of "new" friction prevent you from replacing "old" friction with something potentially more profitable.

Let the data decide.

We offer a pilot program for our monetization product for this exact reason. Give it a shot. If the metrics or the experience don't meet your standards, simply turn it off. 

P.S. We’ve tried this with over 1500 publishers… They never turned it off. | 16 | 0 | 1 | 3d | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.886Z |  | 2025-12-04T15:00:16.163Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401998656129847296 | Text |  |  | Three months of Enterprise sales work. A ~$850,000 ACV deal we were confident about. Lost in a 15-min internal meeting I wasn't invited to. The story:

We were working with a major European weather publisher to help them monetize travel intent.

Contrary to all our competitors, our solution only triggers new tabs for users showing sufficient transactional intent. Their existing tool spammed offers at very single site visitor - sure fire way to lose $$$.

We thought we made our value prop extra clear...

Then they held an internal meeting without us.

They lumped us in with their current spammy provider and decided they didn't want any "new tab" solutions anymore. Done. Deal dead. It stung.

If I could go back, here's what I'd do differently.

1. Map Every Landmine In The Sales Field

In Enterprise sales, you absolutely need to know where every landmine is planted. I didn't properly understand who placed what landmine in that prospect field. The UX team, the editorial team, the technical team - they all had veto power and could've been engaged better. The first step is to map out every.

2. Surface Every Possible Objection Early

We did ask some questions about concerns, but without nailing point 1, you'll without a doubt not the right ones to the right people. I should have pushed harder to have conversations with every decision maker and asked directly: "Why don't you like our solution? What would make this deal not work?"

3. Get Ahead Of Internal Assumptions

The deal died because they created their own definition of what our solution does in a meeting without us. I tried to educate them but again could've done a better job. Even better if you can coach your champion on the best way to articulate your value prop.

- - -

Enterprise deals don't die from competition.

They die from decisions made without you in the room.

Map every stakeholder who can kill your deal.

Then make sure they all understand why you're different. | 33 | 10 | 0 | 4d | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.887Z |  | 2025-12-03T15:00:02.106Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401636350002880512 | Text |  |  | Cold emailing a decision maker: <0.03% reply rate.

Walking into a conference full of your ICPs, finding the VP of Revenue you've been chasing for six months, and introducing yourself over coffee: that's how our CEO Andrew Lockhead booked 50 meetings with prospects and partners in 2 days.

I'll never get tired of saying this: in a world of Nanos, Llamas, Geminis, and GPTs, meeting people in real life is becoming the most efficient GTM channel.

Get on the plane.

Also, your CEO should be your best SDR. I said what I said 🙃 | 79 | 11 | 0 | 5d | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.887Z |  | 2025-12-02T15:00:21.594Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7400167439109496832 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEvCUv3h4HERQ/feedshare-shrink_800/B4EZrKtD.AHEAg-/0/1764337404547?e=1766620800&v=beta&t=HuFFp-Q4B1iVkt3tsH9SZkTyjAPPawQGirqcTys0dbQ | There are people who join a company… and then there are people who change the temperature of the room the second they walk in.

Ryan Sullivan is absolutely the second kind. 

When we hired him a few years ago, Stay22 had zero marketers… and we definitely didn’t have was Ryan — the OG marketer of the post-pandemic era and one of the best culture additions we’ve ever made.

I could list professional accomplishments here. There are many.
But honestly? What matters more is the guy.

Ryan brought humor, authenticity, quirkiness, and a level of positive chaos that every good startup needs to stay alive. When Ryan leaves for vacation, the office feels it. When Ryan works from home, the office feels it. When Ryan is in a meeting but has his camera off for 45 seconds… we feel that too.

And now that Ryan is moving on, yeah we’re really going to feel this one. 

Beyond being a stellar marketing manager, he’s also quietly one of the most creative humans roaming the Earth. The man moonlights as a social media influencer, content creator, food critic (Sullivan’s Food Reviews is canon), viral chaos generator (Garboscope forever), and somehow also an athlete because… why not? 
Renaissance man unlocked.

But let’s be honest:
Ryan’s greatest and most enduring contribution to Stay22 has been introducing us to the sacred glory of Pizza Toni. 🍕
- Generations will talk about this.
- Anthropologists will document it.
- Every time I’m on my sixth slice, I’ll think of you, buddy.

Ryan — thank you for the ride, the laughs, the energy, the culture, and the creativity you brought to this little rocket ship. You’ve left a mark on the company and on our cholesterol levels.

Big love. Big gratitude. Big slices.

#respect. | 84 | 11 | 2 | 1w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.888Z |  | 2025-11-28T13:43:25.946Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7399824450508189696 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6c0a8577-ad17-4c69-9cf5-8225f1f10e96 | https://media.licdn.com/dms/image/v2/D4E05AQGlX4ZGLpQNPA/videocover-high/B4EZrFln8pKYBU-/0/1764251570883?e=1765778400&v=beta&t=IkSBJK7fXYbdz3oIeQNyuhdKvVgKBJu4Wye_ehUF48g | "Who wants change?" Everyone raises their hand.

"Who wants TO change?" Crickets.

Nowhere is that silence louder than in the travel and publishing industry.

The ground is shaky. LLMs, AI answers, and Google updates are threatening the monetization models we rested on for the last 20 years.

We all know we need new revenue streams.

Yet, when a new approach to monetize is presented, the walls go up.

Teams argue it might hurt UX, slow down the site, or they just don't think it will convert. These are valid concerns.

But they are often based on opinions and not empirical data.

We obsess over the risk of action. We worry the user might get confused or the page load might drop by 0.01s.

But we completely ignore the massive risk of inaction:

- We forget that programmatic rates are in decline.
- We forget that AI is coming for our traffic.
- We forget that sticking to the 2010 playbook is a gamble in itself.

Here is the reality:

You don't need to "bet the farm" to fix this. You just need to run a test.

You just need to let empirical reality speak on your monetization strategy.

We work with over 1,000 publishers and travel creators. All of them see an additional $5-20 RPM uplift after using our product. That product generated over $30M in net new revenue for our partners YTD.

They’re succeeding because they realized that standing still (when it comes to content monetization) is the most dangerous thing you can do in this market.

But still, don't trust my opinion.

Trust a 30-day test. Let’s have you use the Stay22 product and see it for yourself.

If there’s no conversion, you can simply turn it off. No harm done.

But if you see the same uplift our other partners are seeing...

You just future-proofed your revenue. | 12 | 1 | 0 | 1w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:36.889Z |  | 2025-11-27T15:00:31.091Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7397287660987506688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWURybpuIklw/feedshare-shrink_800/B4EZqhqL4CIoAk-/0/1763648783806?e=1766620800&v=beta&t=HOkLX5vNSVD7JKKOoI_UqnvH3efVtXRUNvnyyNcuK3Q | A few weeks ago at the Rev star summit, Mark Roberge shared a definition of Product-Market Fit that I wish I'd fully understood five years ago.

"PMF isn't defined by your sales, your CAC, or the size of your TAM."

It's defined by one thing: retention.

It comes down to these questions:

- Are your partners and customers using your product long-term?
- How long are you keeping them?
- Do clients churn regularly?

If they aren't churning, you're on to something.

If they are, you don't have PMF - even if you're hitting record revenue scores.

Scaling before you have strong retention is, he said, "just adding tons of water into a leaking bucket."

That line truly resonated. I look back at the big, "dream" clients we tried to land for years. We couldn't get their attention, and I thought we had a sales problem.

The truth is, our product wasn't ready. We would have signed them, failed to deliver, and watched them churn. Sure fire way to hurt your reputation.

And that's the real trap: confusing revenue growth with PMF. We would have been spending money just to replace the clients we were inevitably losing, instead of actually building a stable business. | 35 | 1 | 1 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.245Z |  | 2025-11-20T15:00:13.338Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7396955164227555328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFcBiQDfSIREw/feedshare-shrink_2048_1536/B4EZqdDhdXIUAw-/0/1763571538218?e=1766620800&v=beta&t=GCGMwI--fC3c5XW4A0hK5R4H0ECxoPi6112Ci4Poe1Y | 🚀 Stay22 just landed on the Deloitte Fast 500… AGAIN.

 And not just anywhere — #94 in North America.
 Top 100, baby. Still trying to process that.🤯
 .....It feels surreal.

 Because not so long ago, the “executive meetings” at Stay22 were basically:
 “How do we survive this month?”
 “Do we make payroll?”
 “Will travel ever come back?”

We were a tiny team in a collapsing industry, during a once-in-a-century pandemic, building tech for events… while all events were cancelled globally.

Honestly, if you wrote it in a TV script, people would call it unrealistic.

But Andrew Lockhead, Hamed Al-Khabbaz, Simon Boulet and the whole crew refused to die. 🙅‍♂️

Stubbornness, curiosity, and a dash of delusion carried us through the near-death moments.

Fast forward to today:
 - Travel is back
 - Our tech is powering thousands of publishers
 - We’re growing like crazy
 - We’re profitable (yes, that still feels illegal for a tech company in 2025)
 - And for the second year in a row, we’ve secured a spot on the Deloitte Fast 500 — this time in the TOP 100.

I’m grateful — genuinely.
 - Grateful for this rocket ship.
 - Grateful to be part of the wildest adventure of my career.
 - Grateful for the people who stayed, the people who joined, and the people who helped us along the way before blasting off to their next chapters.

To paraphrase Star Trek (cheesily, unapologetically):
 "We’re boldly going where no one has gone before."

 And we’re only just getting warmed up. 💪

 Let’s keep climbing. 🚀

#Fast500 #Stay22 #Growth #TravelTech #Proud #Teamwork #Publishers | 46 | 4 | 1 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.249Z |  | 2025-11-19T16:58:59.933Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7396925283838164992 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF2_-zw3WFVbw/feedshare-shrink_800/B4EZqb0pVhKMAg-/0/1763550861917?e=1766620800&v=beta&t=zC7ou4jRvsd8LsvxC_0v1IlhDnRvU-d1_H0pPmz7G4c | I've been waiting to share this one for about 5 years. 

Stay22 is OFFICIALLY LIVE WITH TIME OUT! 

This is a big milestone for us. 

Time Out Group plc is a brand I've always admired, and we've been trying to earn their business for years. We tried meetings in London, ABM, but nothing landed. And honestly, I don't blame them. Our product simply wasn't ready. 

Now it is. 

Thanks to our Nova technology and the incredible work from Denisa Kostolanyiova on our enterprise team, we didn't just launch a small test. We went live across ALL of their digital platforms. 

The performance is already exceeding expectations, converting users at a scale that is surprising both teams. 

This was a dream brand for us. It's a moment that proves how far our product and our team have come. 

Onward! | 184 | 20 | 3 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.250Z |  | 2025-11-19T15:00:15.893Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7396562853694111744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQErJObAqXW_bg/feedshare-shrink_800/B4EZqXJmRSIoAk-/0/1763472468329?e=1766620800&v=beta&t=y3h74IdgqYq62W9wJgDWhK30aYeydgPq-zs2dqDpmW4 | Without a doubt, one of the hardest parts of my job is watching a publishing executive tell me, "I'm pretty sure this won't convert," while revenue is down 17%-30% YoY.

I have the same conversation with CROs/VPs/Directors at publishing & media orgs at least 10 times a month.

The publishing industry is dealing with real pressure right now. LLMs are eating search traffic. Google's serving AI answers instead of sending clicks. Social platforms keep users on-platform.

These are real threats and publishing teams are feeling it every quarter.

So, they look for solutions.

But when we show them a new monetization approach, the response is almost always: "I'm pretty sure this won't convert."

This is the hard part. The industry keeps reaching for the same three levers:

- More sponsored content deals.
- Higher programmatic ad density.
- Affiliation programs run the same way they worked decades ago.

These tactics worked. Past tense.

They kept businesses alive through algorithm changes and platform shifts. But user behaviour changed so dramatically over the past three years that old conversion patterns aren't as reliable.

I've watched publishers test something they were certain would fail and add $50K-$99K in monthly revenue.
That is NET NEW incremental $$, and “Revenues without real estate”

If you're a publishing executive feeling pressure to drive more revenue but wary about new affiliation solutions, talk to someone who's helped major publishers like Hearst and Time Out monetize existing content without disrupting UX.

That's how you find new revenue streams without waiting for organic traffic to recover. | 14 | 3 | 1 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.251Z |  | 2025-11-18T15:00:05.813Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7396337703174316032 | Document |  |  | Totally with Edouard Reinach on this one. The idea that AI adoption should be dictated top-down—like some grand unified corporate theory written in an ivory tower—is… honestly wild.😤

AI is evolving weekly. The use cases inside a company are messy, contextual, weird, clever, human. And yet I keep hearing:
 “AI pilots don’t work, so we need more… top-down control.”

That’s not a strategy. That’s a cry for help.

An overly top-down AI directive is basically:
 “We bought one toothbrush. Pass it around.” 🙈
 Each function has its own hygiene problems, my guy. Let them brush how they need to.

Your people are already using shadow AI. They’re already experimenting, paying out of pocket, hacking workflows, and quietly building the future while leadership drafts another 40-page “AI Vision Document” no one reads.

If you're a leader, here’s the move:👇

 Empower your teams. Give them tools. Ask what they’re doing. Copy the stuff that works. Let the bottom-up momentum show you where the real value is.

AI is not a religion—stop trying to enforce doctrinal purity.
It’s a "super-tool"—let your people wield it their way.

Stop mandating. Start enabling. | 7 | 3 | 0 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.253Z |  | 2025-11-18T00:05:25.746Z | https://www.linkedin.com/feed/update/urn:li:activity:7394740572181331968/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7396259563198599168 | Text |  |  | It’s a Stay22 thing.

I’ve said it before and I’ll keep saying it — I’m obsessed with actions that compound through people and time. 🤪

Not the “hero” moments that make you look good in the moment, but the ones that make everyone around you better — and keep paying dividends long after you’re gone from the Zoom call or meeting. 💪

For me, one of those compounding actions is #mentorship. ✅
Both giving it, and making sure others in the company receive it.

Because when you invest in humans, the ROI curve looks like this: 📈

Which brings me to this — I’m looking for a mentor for Andréa Couture, one of our rising leaders with our Stay22 #rocketship 🚀

Andrea’s been with us for over a year and has left her fingerprints all over our growth — building structure, tightening processes, and stepping up as interim Head of Sales when we needed her most (the kind of “unglamorous but crucial” leadership that holds companies together).
#respect s🫡

Now, we want to make sure her growth doesn’t plateau — and that she continues evolving into not just a sales leader, but a business leader who measures her impact in real, empirical outcomes.

So:
 👉 If you’re an experienced sales or GTM leader who loves helping ambitious operators level up…
 👉 Or if you know someone who’s an amazing mentor type…

Drop me a DM, a comment or email me at frederic@stay22.com. 
Let’s find Andrea the mentor she deserves.

At Stay22, we invest where the compounding returns are exponential — our people. 🚀

#Leadership #Mentorship #GTM #Stay22 #Growth #SalesLeadership | 35 | 6 | 0 | 2w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.255Z |  | 2025-11-17T18:54:55.724Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7395092709520187392 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG3jmkpX9XQIA/feedshare-shrink_800/B4EZqCloPuHgAg-/0/1763127494363?e=1766620800&v=beta&t=VjcrewQKWKYpz-Y9b0eBt10Z6ByFdzbJMeUBcKdceb8 | 📸 Proof that I should never be trusted with the camera…🤣
But also, proof that Pavilion dinners are always worth it.

Yesterday was one of our Montreal Pavilion Chapter executive dinners, and every time we host one, I’m reminded how foundational these evenings are to the Pavilion experience.

There’s something powerful about getting a small group of go-to-market leaders around a table — no slides, no filters, no performance. Just honest, open conversations about what’s really going on:

- scaling pains and growth ceilings
- how we’re (actually) leveraging AI
- leading through pressure and burnout
- finding balance between data, intuition, and chaos

It’s a safe space to share the wins, the struggles, and the “what the hell do we do now” moments — with people who get it.

Huge thanks to everyone who came out — always energizing to learn from each other.

 Until the next one, friends 👊

#Pavilion #Leadership #GoToMarket #Montreal | 56 | 8 | 0 | 3w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.256Z |  | 2025-11-14T13:38:16.128Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7394750987837800448 | Text |  |  | AI is making to make digital outreach 1000x easier. This just means your prospect's inbox is about to get 1000x noisier.

Google Meet is a commodity. A "perfect" email is a commodity. AI-generated video is a commodity. What isn't?

A firm handshake.

For the last decade, we've ALL focused on digital efficiency. We've gotten pretty good at it. And that's a good thing.

BUT...

AI is turning all digital experiences into a commodity. The cost to create a "perfect" deck, email, or video is racing to zero.

This means the volume of digital "noise" is about to explode.

That is why we're investing heavily in the one thing AI can't scale:

Genuine, face-to-face human connection.

As everyone dumps their budget into AI-powered outreach, we're investing more in... flights and hotels.

Why?

1/ Our Enterprise clients are clustered

Decision-makers for our biggest partners are grouped in hubs like NYC, London, SF, and Paris. A single 2-3 day "roadshow" is incredibly efficient for meeting 5-10 key accounts.

2/ Proximity naturally builds trust

Sharing a coffee, reading the room, and sitting with a partner in their office... that builds real bonds. That might become the only differentiator going forward.

3/ Digital should support irl efforts, not replace it

All our digital and AI-powered wizardry must now be geared toward one single goal: earning the right to show up in person.

Nothing agains high-volume automation, but we're making a different bet.

We're going human. We're going analog.

Because in the age of AI, the ultimate advantage isn't scale.

It's simply showing up. | 5 | 1 | 0 | 3w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.258Z |  | 2025-11-13T15:00:23.330Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7394388526479605763 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e7e1b7b8-005c-4e7a-8297-576769b2ef47 | https://media.licdn.com/dms/image/v2/D4E05AQGcBT_7iGVvLg/videocover-high/B4EZp4Xe1IHMCI-/0/1762956033627?e=1765778400&v=beta&t=HZ9JNROaCiUe2p-UWzsAfuuhOsnZVmbaQHPipBWQM5w | We helped one publisher increase their affiliate conversions from 0.6% to 6.7%. That's a 1,016% increase. Another partner hit a 14x (!) affiliate revenue growth. We did it all without adding more clutter to their sites. Here's how:

Publishers often (and wrongfully) compare us to other technologies.

But our goal is the exact opposite of what you'd expect. Our mission is always to show the user the right offer, the right way, at the right time.

Here’s how that works in practice:

1/ We focus on transactional intent, not volume.

Nova is a solution that shows a relevant offer in a new tab to users who are ready to buy. It works by finding the 5-15% of your users who have high transactional intent.

Only for those users, it opens a single, hyper-relevant travel or retail offer. It doesn't add pop-ups, and it takes up zero space on your page.

2/ We don't clutter sites with useless affiliate links

Spark is a tool that adds affiliate links to your content where they are missing. It scans your existing articles for missed opportunities. It finds places where you mentioned a product or destination but forgot to add a link, and smartly inserts one.

If your article is already full of links, it does nothing. It's built to find new value, not to add clutter.

Now...

When publishers hear "user behavior," legal red lights appear. And rightfully so.

But our solution was built for a privacy-first world. We are not reliant on third-party cookies. We are not looking at any personal data.

All we're doing is deploying beacons on the page. We compare how a user is interacting with the content in real-time against the aggregate, anonymous trends from our 8 billion other script loads.

There is ZERO personalized data touch.

There is ZERO compromise on “on-page” user experience.

There is absolutely zero additional clutter on your site.

If there were, we wouldn't have been able to help publishers increase conversions by 1016% and 14x their affiliate revenue. | 25 | 1 | 0 | 3w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.260Z |  | 2025-11-12T15:00:05.808Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7394026127188504578 | Text |  |  | Your marketing team should be earning commissions.

It’s one of the most powerful GTM strategies we have, and it completely ended the classic sales vs. marketing attribution battle at our company.

Here’s how it works.

Basically, our marketing team earns "marketing assisted commissions" on every single deal they touch.

Inbound. ABM. A referral campaign. Even an outbound deal that properly interacts with our digital assets. And this simple change fundamentally aligns everyone on the same goal.

So, instead of Marketing saying, "Sorry, I can't help with that one-off request, I have to hit my MQL quota"...

...they now say, "This is a huge enterprise deal. Let's drop everything and build an ABM campaign for their CEO."

Why? Because we're all playing the same sport. We all look at the same scoreboard: revenue.

It's no longer a zero-sum game.

It's never a "marketing deal" or a "sales deal." It's just a deal,… and both teams can get credit for the win. 
And yes. We matched it out so our acquisition cost stays healthy.

If you want marketing and sales to play as one team, reward them as they ought to. It's as simple as that.

Revenue is a team sport.

So stop asking Marketing for more MQLs.

Start building one team focused on one goal: new revenue. | 20 | 3 | 0 | 3w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.263Z |  | 2025-11-11T15:00:03.084Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7393645841833566208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHAlnG4rZXtPQ/feedshare-shrink_800/B4EZpuBtYDIwAg-/0/1762782533982?e=1766620800&v=beta&t=ql_upedbyFXkJo0c8qgOpDjTB0QkXRvZ_Q74lOBOUkY | What. A. Week
.
Just got back from #WTM London — one of the great, great travel parties of the year.
There’s nothing quite like spending a few days surrounded by the energy of our amazing industry: meeting prospective partners, catching up with existing ones, chatting with suppliers, and just soaking it all in with amazing Stay22 colleagues. 

Travel really is this beautiful ecosystem built on connections, stories, and a shared love for movement.

A personal highlight: running into Ralph Sfeir, who I had the briefest stint working with at Le St-Martin Hotel Particulier - Montreal… what, 15 years ago?
 
Ralph’s now at Dida, and it was such a joy to reconnect. 

Moments like that remind me that this industry isn’t just about business — it’s about people, memories, and those full-circle moments that make you smile.

Ralph, wishing you nothing but success with Dida — and hopefully it won’t take another 15 years before we meet again!

✈️ Here’s to travel, connection, and the people who make it all worth it.

(photo from the Dida booth, which had two floors 🤯  — proof that travel reunions happen in the most random places!) | 51 | 1 | 0 | 3w | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.265Z |  | 2025-11-10T13:48:55.990Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7392214237428862977 | Video (LinkedIn Source) | blob:https://www.linkedin.com/1a3c5bd3-7695-4acd-81a5-7f4d85d60021 | https://media.licdn.com/dms/image/v2/D4E05AQGhZjFMMSCSmw/videocover-high/B4EZpZmsRcKcCI-/0/1762439937278?e=1765778400&v=beta&t=qcJpwM-TfZa5oRWuBsNlvLF_tuFLycCyasijLyIETxI | Your GTM team isn't SOLELY responsible for your revenue.

And I mean that, even as a GTM leader.

We often put all this pressure on our GTM teams and expect them to own the entire revenue number.

They can't do it ALONE, and they're not supposed to. 

Revenue is a TEAM sport. 🧠

Let me unpack what I mean.

At Stay22, for example, we provide travel monetizing solutions for publishers, content creators and platforms. My GTM team cannot generate revenue in a silo. We can't just go sell a product, get an upfront fee, and call it a day.

Our business model just doesn't work like that.

Revenue here is very much a team sport, and it depends on three separate functions.

The GTM team (Sales, CS, Marketing and RevOps) is heavily geared towards User Acquisition. Our goal is to build B2B partnerships with publishers, platforms, and creators to get as many qualified users as possible to interact with our product.

But that's just step one.

Next, the Product team has to ensure those users convert. Their decisions on the redirection logic, the UX, and which supplier to send that user (and at what time!) to have a gigantic impact on revenue generation.

And then, our Supplier deals determine the actual monetization.

- What's the attribution window? Across devices? Apps? 
- What commission do we get? 2% or 5%?
- Do we get credit if the user books 10 days later?

All of these have a DRASTIC impact on the numbers.

The GTM team can do its job perfectly, but if the product fails to convert or our supplier terms are bad, the revenue will tank.

The other way around is also true, GTM can be terrible, but outstanding product efficiency can propel revenues upwards. 

Revenue is a team sport. Period. | 17 | 0 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:40.268Z |  | 2025-11-06T15:00:14.902Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7391898151168667651 | Text |  |  | 🚀 The Unsung Hero of Our Event Game at Stay22

At Stay22, we’ve been doubling down on event presence — not necessarily with massive booths or flashy displays, but with real intention.

Our goal? 
To show up, connect with partners, prospects, and suppliers face-to-face, and build real relationships.

Because behind every partnership and deal are people — with visions, challenges, and goals we can only truly align on when we take the time to sit down, share stories (and sometimes a drink 🍷), and genuinely listen.
But let’s be real — events are A LOT of work. 😅

There’s travel logistics, setting up meetings, prepping for panels, coordinating dinners, lugging merch around, reconciling receipts, capturing content… it’s chaos dressed as opportunity.
And none of it — absolutely none of it — would run nearly as smoothly without the incredible Marie Lechantoux, our Event Specialist and the backbone of Stay22’s event machine.💪

This week at WTM London, it hit me just how much Marie does behind the scenes:
 - Coordinating travel and logistics for the entire team
 - Making sure meetings are booked, badges collected, and everyone knows where they’re supposed to be
-  Prepping all the merch and materials
 - Capturing photos, moments, and content that fuel our marketing engine
 - And doing it all while herding a team of jet-lagged salespeople (myself included) — with a smile.

Marie, thank you.🙏

Your organization, care, and energy are the reason our event presence feels so strong — and why WTM has already been a huge success.

Stay22 wouldn’t have the event game it does today without you.
 You make this #rocketship soar higher 🚀

#WTM2025 #TeamStay22 #Events #Gratitude #Partnerships | 39 | 7 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.681Z |  | 2025-11-05T18:04:14.065Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7391851811701276672 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFLRKe5_UY41Q/feedshare-shrink_800/B4EZpUT4BXHUAg-/0/1762351089204?e=1766620800&v=beta&t=UeLxHHTcp5OIWl7fi0IqSXvrB_0Qe4dRZoAvNGf3UDs | We pay prospects (Travel Publishers / Events & Ticketing Platforms / Weather platforms) up to $101,000 upfront to try our product.

Think paying customers to try your solution screams desperation?

Think again.

When you're profitable and your retention is solid, sitting on capital becomes the worst ROI decision you can make. We're not a bank. We're a tech company.

And we needed to find a way to speed up deals that were dragging on forever.

Partners tell us they're interested but need to wait. They're rebranding. Launching a new website. Internal priorities shifting, etc.

So... We started cutting checks upfront.

The deal:

1. We pay you now to start immediately.

2. You still collect all performance commissions (we pay you so that you can make more money!)

3. All we ask is that you leave our product on for 5-6 months.

We can do this because we forecast revenue with high accuracy. Our churn rate is extremely low. We know the aggregate ROI works.

The payback data across 100+ deals in the past six months:

- Creators: 1 month average

- Weather/data sites: 3 months average

- Large publishers: 4.5 months average

That means in one month, creators have already earned more than we paid them upfront. Then they keep earning for years because they don't churn.

What we've learned is that when you're (1) profitable and (2) your product retention is strong, the fastest way to scale is making it financially stupid for prospects to say no.

Leaving money in the bank account doesn't generate pipeline.

P.S. If you're a travel publisher/content creator/digital media company monetizing travel content... send me a DM. | 79 | 6 | 1 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.683Z |  | 2025-11-05T15:00:05.875Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7391474339893911554 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQENr8BmTedodw/feedshare-shrink_480/B4EZpPGGmgIQAY-/0/1762263591786?e=1766620800&v=beta&t=Mem-7yyOeFi48FEZvVp1aIv1LLsTf3dUeS1Nr9q__uo | 20 years in. Here's every title I've held:

- Security Guard
- Sales Coordinator
- Sales Manager
- Sales Manager
- Director of Sales & Marketing
- General Manager
- Sales Director
- Chief Sales Officer
- Head of Sales (took a paycut for this one, 1st tech rodeo)
- Chief Revenue Officer
- Chief Commercial Officer

Notice how it's not a straight line up?

Taking the jump from Chief Sales Officer to Head of Sales meant less money and a smaller title.

There were layoffs along the way. Nasty firings, respectful endings and everything in between. Lateral moves that looked like going backwards. Years where nothing changed on paper.

Six years later, that paycut (to join Stay22) turned into the best decision of my career.

I'm CCO at a company I love, leading a team of 35+ across sales, customer success, marketing, and RevOps. We're reaching over a billion users and growing beyond what we imagined possible.

The path up isn't straight. And don't confuse a non-linear career with an unsuccessful career.

Never be afraid to start again. | 235 | 21 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.684Z |  | 2025-11-04T14:00:09.583Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7390002139252772865 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH3ZF6YQJaF2w/feedshare-shrink_1280/B4EZo6PyT0GYAs-/0/1761913808609?e=1766620800&v=beta&t=-f0pmitlFBhEY1rIHrTJWhHud7KDQ6Ci6ccabMHSw6A | Things Never Go As Planned.
(....And that’s okay. That’s #business.)😅

We all love a good annual plan. The crisp strategy decks. The clean budgets. The “this-time-it’ll-be-different” playbooks.

And yes — you absolutely need all of that.
Without structure, you’re just winging it.

But here’s the truth:
Business isn’t engineering. 
It doesn’t "compile". It doesn’t “lock.”
You don’t write a perfect go-to-market plan and then push it to production.

We talk a lot about #GTM as a #science — and rightfully so. ✅
 We should aim for predictability, repeatability, data-driven motion.

But if GTM is a science, it’s social science at best.
 -You form hypotheses.
 -You test them in the wild.
 -You collect messy, inconsistent, human data.
- You iterate & re-iterate over & over again. To improve. Always
 -And then you tear it up and do it again. 😜

The motion that was brilliant and capital-efficient six months ago?
Tomorrow it might flop.
And that’s not failure — that’s the game.

The best companies I’ve seen are relentless about two things:
1. Making their outcomes as predictable as possible.
2. Fully expecting their playbook to break anyway.
Because what worked yesterday won’t work tomorrow.
 
And that’s not a bug — that’s evolution.

Business isn’t deterministic. GTM isn’t physics.
It’s constant social experimentation with feedback.

 It’s science, sure — but social science. | 5 | 2 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.686Z |  | 2025-10-31T12:30:09.598Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7389662386900586496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEXKwg5tQq3-w/feedshare-shrink_800/B4EZo1XsJzHEAg-/0/1761831995052?e=1766620800&v=beta&t=rwnU7G-4n3_ydTsN3HzDWvRY3ecQwNIa8kFdHERsua8 | We lost a major publisher account Stay22

It wasn't fatal, but it was a sizeable one—both for revenue and for our reputation. It sparked a massive scramble to save the relationship.

And the responsibility for that entire mess was 100% mine.

We have a playbook for a reason: Sales closes, and our Partner Success team takes over to retain and expand the relationship.

But I made the call to bypass it.

I decided to let one of our most successful salespeople continue managing this relationship directly, basing that call on their past success and my trust in them.

That decision led to the account not being multi-threaded properly. We didn't build relationships with the various stakeholders. It was all run through a single point of contact.

The client threatened to churn, the reasons were fuzzy, and we had to scramble to do the proactive work that should have been done for prior.

This wasn't on Partner Success; they were never given the handoff.

That was on me. I'm the one who didn't hold us to the process.

I’m sharing this because it’s the reality of building a company. It’s not all funding announcements and revenue milestones. It’s the expensive lessons and the sleepless nights. This stuff happens, and as leaders, we have to own it.

For all the leaders out there, here are the tactical takeaways I’m re-learning the hard way:

1. Your process is your safeguard. 

It's a system designed to protect the company from a single point of failure—whether that's a person, a relationship, or your own blind spots.

2. No one is above the playbook. 

Not even your top talent. ESPECIALLY not your top talent. Your best people should set the standard, not be the exception. 

3. A single point of contact is a single point of failure. 

Multi-threading an account isn't optional. it's the only way to make the relationship durable. If your champion leaves (or gets upset), you're left with nothing.

Not sure if this "belongs" on LinkedIn but I know behind the scenes that a lot of leader are going through this stuff. Hope it helps! | 36 | 2 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.687Z |  | 2025-10-30T14:00:06.325Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7388937753717002240 | Text |  |  | I almost have to pinch myself sometimes. 2025 will be our BEST financial year at Stay22. The best since the company was founded, by far. Again.

Success is great. All the power to anyone crushing it.

But something sits in the shadows when things start to work out for you.

You get accolades. You get great compliments. Everyone confirms that every decision you made was right. And that's when things get dangerous—because all of this can easily get to your head.

So I force myself to lean on these 5 things to stay grounded:

1. Take compliments with the same grain of salt you took criticism

Before we had success, naysayers told us we'd fail. We didn't listen to them. Now when people tell us how great we are, I take it the same way. You're probably not as bad as they said before. You're not as good as they say now.

2. Look at ALL the data, not just what fits your story

Prioritize empirical evidence over your own opinions. Run your decisions by people who disagree with you. Listen to the ones showing you where you were wrong. If the data is real, they might be right. Adjust. You're not perfect.

3. Actively dismiss praise the same way you dismiss criticism

Excessive compliments are just as dangerous as harsh criticism. Maybe more dangerous, actually. And praise is tougher to dismiss. But you have to learn how to not let people's words and opinions define the value you bring.

4. Respect luck and randomness

Every success story I've seen has hard work, solid execution, scars, and luck. So many people had great ideas, great work ethic, great plans, and shit happened anyway. Luck isn't the main variable. But it's one of them. Be grateful for what it gave you.

5. Remember you're not as special as you think

The second you think you've got it all figured out is when you stop making good calls.

Onward. | 49 | 3 | 1 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.688Z |  | 2025-10-28T14:00:40.311Z |  |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7388680897652350977 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFXG8kborQ-iQ/feedshare-shrink_800/B56ZomxX.lHkAg-/0/1761587070435?e=1766620800&v=beta&t=l1-3Jq_v6_WNYyXzxAVp-tzL3F4jDZoxqcNtQElXPa0 | Really looking forward to being at RevStar this Wednesday!

It’s incredibly exciting to see the B2B GTM tech scene here in Montreal growing and gathering this kind of momentum.

Canada has a well-known "commercialization gap."

We build world-class tech but often struggle with the GTM science to scale it. This event is 100% focused on tackling this exact challenge, with a heavy-hitting lineup of GTM leaders.

Great to have Pavilion involved as a sponsor to help support this conversation.

Special thanks to Guillaume Jacquet and his team for making this event a reality.

Looking forward to connecting with everyone there! | 19 | 1 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.689Z |  | 2025-10-27T21:00:01.053Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7388552303907344385 | Article |  |  | 🚨 Breaking: The Open Web Has Died (Again). 🤣

Every few years, someone declares the open web is dead. 🪦
Killed by social media. Killed by mobile apps. Killed by AI.
 And yet — like a horror movie villain or a stubborn startup founder — it keeps crawling back.

Yes, LLMs are going to eat a massive part of informational traffic.
Yes, the way we access and package knowledge is shifting fast.
But before we throw dirt on the grave… OpenAI just launched a browser : ChatGPT Atlas 😅

That’s right — the same  LLM AI everyone says will replace the Open web… is now crawling back into it.
We’ve gone full circle. Again. 

To me, this says less about the “death” of the Open web, and more about its resilience.
It might evolve, mutate, or get absorbed into new interfaces —
but it’s still the backbone. 
The source. 
The messy, beautiful chaos AI keeps learning from.

So sure, the open web may be limping — but it’s got more lives than a cat with a Wi-Fi connection.

https://lnkd.in/eJ6Syj5d | 10 | 6 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.690Z |  | 2025-10-27T12:29:01.915Z | https://www.theverge.com/news/803481/openai-web-browser-ai-announcement-teaser |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7387863504684281856 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHC3odbQfc4iA/feedshare-shrink_800/B4EZob2rb5GcAg-/0/1761403915243?e=1766620800&v=beta&t=usiNItYzSl2_lIgbKrGc3z1I1lt7OZJF4w0Yiz0XTlQ | Partnerships That Play in the Big Leagues ⚾️ 

Still buzzing from last night’s Blue Jays vs Dodgers World Series game — an absolute thriller.

A grand slam. By a pinch hitter. Seriously. Unreal.🤯

Huge thanks to Jennifer Huang, Kyle J. Dunster & Myles Darcy and the Booking.com Strategic Partnership team for the invite — and for making it one of those “yep, this is a once-in-a-lifetime” experiences. ✅

Grateful to have shared the night (and the chaos) with Malcolm Archer and some other incredible folks.

Beyond the baseball, moments like this remind me why our partnerships matter so much at Stay22.

We don’t hold inventory. We don’t own the user.
Our entire model is about connecting travelers with the right offer, at the right time, from the right partner. 💪

And partners like Booking.com make that possible — with unmatched tech, scale, and a team that’s just plain fun to work with. 🤣

They say your network is your net worth.
At Stay22, we see our partnership network as our biggest strength — the bridge that lets us drive value for travelers, creators, and platforms alike.

Now if you’ll excuse me… I’m off to Game 2.

 For research purposes, of course. 😉

#WorldSeries #BlueJays #Partnerships #Stay22 #Bookingcom #GTM #TravelTech | 73 | 11 | 3 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.692Z |  | 2025-10-25T14:51:59.383Z |  |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7387465280630857728 | Text |  |  | ✈️ #Travel is one of the purest forces for good in the world.

... yes, I mean it.

Not because it’s glamorous.
Not because it fills your feed with sunsets and smoothie bowls.

But because it’s deeply human. ❤️

Travel reminds us that—despite all the noise—we’re far more similar than different.
That food tastes better when shared.
That other cultures aren’t “foreign”; they’re fascinating.
That curiosity and humility can bridge gaps no algorithm ever could.

Of course, travel isn’t perfect.
Yes, it strains our planet.
Yes, it can feel commercialized, crowded, and occasionally like a Hunger Games of airport gates.

But even with all its flaws… travel still does something extraordinary:
it reconnects us with empathy.

And in a world that seems increasingly allergic to nuance, that’s priceless.

I’m incredibly proud to work in this industry — helping millions of people move, discover, and connect with Stay22.

Here’s to everyone building products, partnerships with amazing travel brands like Booking.com, Expedia Group, Airbnb, GetYourGuide etc.. and experiences that make travel not just easier — but more meaningful.

🌍 Keep exploring. Keep learning. Keep staying curious. | 33 | 6 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.693Z |  | 2025-10-24T12:29:35.370Z |  |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7387107695088054272 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF_FJ0C1PIGTQ/feedshare-shrink_800/B4EZoRHTVHHgAg-/0/1761223718843?e=1766620800&v=beta&t=7bOdl5lLuP7jtPHVL_Q9Y1w48ecs7JQJfNC2CRNIfsE | Montreal #GTM Leaders — Dinner’s on... and maybe a grass of wine 🍷 too 😄

On November 13th, we’re with hosting Pavilion a private, executive-only dinner (max 10–12 seats) for go-to-market leaders and soon-to-be leaders to decompress, compare scars, and look ahead to 2026.
No decks. No pitches. No “synergy.”

Just real talk among peers — the kind you can’t have on Slack or LinkedIn.

We’ll share:
- What worked (and what didn’t) in 2025
- What broke, what surprised us
- How our boards and CEOs are reacting
- What we’re doubling down on (or dropping) next year
- And yes, which tools actually delivered value

Because that’s the heart ❤️ of Pavilion — a safe space for GTM leaders to talk about the messy stuff: the misses, the pivots, the insecurities, and the lessons learned — surrounded by people who get it.

The Executive Dinners are where that happens best: small, local, honest.
 A few glasses of wine, some good food, and even better conversations.

If you’re a Pavilion Executive Member (or thinking of joining) and want in:
 👉 DM me or email frederic@stay22.com

Venue details dropping soon — but trust me, it’ll be worth the RSVP.

Peace out, | 36 | 7 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.694Z |  | 2025-10-23T12:48:40.333Z |  |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7386737436422463488 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEIuioZgwFycw/feedshare-shrink_800/B4EZoL2jY6IIAg-/0/1761135442022?e=1766620800&v=beta&t=5Tx-jsd5QtoySF9rDYcGThEFUKL-C2BNNMbUqgwTSio | It's late 2019. I just had my second kid (Eli). 

Took a 30% pay cut to join a travel startup as Head of Sales. 

Three months later, COVID hits and revenue goes negative.

Not zero. Negative.

We had more cancellations than bookings.

The C-suite was forced to let go of a good portion of the team. I was one of the highest paid employees, so I figured I'd be next.

Then Simon Boulet and Andrew Lockhead pulled me aside:

"Fred, we want you right through this."

I didn't see that coming. I came into work that day thinking I'd finish it without a job. But that belief in me was both validating and nerve-racking.

I don't think words can describe what the following months were like.

We all took massive pay cut. We had no marketing team for two years. 
We scrambled for every government subsidy we could (especially Simon Boulet) find to keep people employed. 

It took an unreasonable amount of hard work, luck, and bringing on the right people at the right time. Slowly, we figured it out. Together.

It wasn't just the CEO. It wasn't just the CTO. It wasn't just the sales team. It was all of us in the trenches.

Five years later, we've grown 50x and helped more people than we ever dreamed of. We went through hell together and came out the other side.

Next goal post: 100x. | 38 | 2 | 0 | 1mo | Post | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/fredericaouad | 2025-12-08T05:04:44.695Z |  | 2025-10-22T12:17:23.788Z |  |  | 

---

## Post 31

https://www.linkedin.com/feed/update/urn:li:activity:7340736797913571330 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHtZAEZVVatPg/feedshare-shrink_800/B4EZd98uaLHcAg-/0/1750164760688?e=1766620800&v=beta&t=sirnlcc3YQg9cC1vibant3L4QFhmEb5zHwoIaUMuKEo | 🚀 We’re hiring a Head of #Sales at Stay22!

 (And yes, it’s every bit as cool as it sounds.)
Big shoutout to our guy Malcolm Archer, who helped launch our sales rocketship into the stratosphere. He’s now shifting gears to join our Supply team, where he’ll keep building magic—just from a new launchpad. 🪄

Which means…
👉 We’re on the hunt for a new Head of Sales to grab the controls and help us fuel our next phase of growth.

Here’s the mission (should you choose to accept it):
 ✨ Lead and scale a world-class B2B sales team
 ✨ Build a repeatable new biz engine (#MEDDIC-friendly!)
 ✨ Manage a multi-track pipeline, big strategic, mid-market, and creators deals.
✨ Own sales forecasting, reporting, and CRM hygiene to provide accurate insights to the C-Suite.
 ✨ Coach, hire, forecast, and grow like hell 🔥

💼 Role: Head of Sales
 💰 OTE: $200K–$225K
 📍 Location: Montreal – Hybrid (2-3 days/week in-office)

🧭 Why Stay22?
 We help travel creators, bloggers, and publishers earn more through smart monetization. We're profitable, fast-moving, AI-fueled, and just a little obsessed with winning together. 
Oh, and we throw excellent parties.
If you're a sales leader who’s part coach, part closer, part growth geek—and you want to join a rocketship that’s already left orbit—let’s chat.

🔗 https://lnkd.in/edudqrAk

Know someone who fits? Tag them below 👇, slide into my DMs, or ping our amazing recruiter Jean-Philippe Martineau, CRHA! | 62 | 4 | 6 | 5mo | Jean-Philippe Martineau, CRHA reposted this | Frederic Aouad | https://www.linkedin.com/in/fredericaouad | https://linkedin.com/in/jeanphilippemartineau | 2025-12-08T05:23:39.829Z |  | 2025-06-17T13:47:16.917Z |  |  | 

---



---

# Frederic Aouad
*Stay22*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Inclusion, AI and Sustainability take centre stage on day ...](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)
*2025-11-06*
- Category: article

### [Dave Wakeman's The Business of Fun Podcast - Libsyn](https://davewakeman.libsyn.com/rss)
- Category: article

### [Doubling Revenue with AI: Stay 22's Success Story](https://podcasts.apple.com/us/podcast/doubling-revenue-with-ai-stay-22s-success-story/id1527278610?i=1000684690379)
*2025-01-20*
- Category: podcast

### [INTIX 2025: Stay22 Is Back and Here to Stay](https://access.intix.org/Full-Article/intix-2025-stay22-is-back-and-here-to-stay)
*2025-01-22*
- Category: article

### [COVID nearly bankrupted him. Then with AI he grew from $0 to $25M ARR in 4 years. | Andrew Lockhead, Founder of Stay22 - A Product Market Fit Show | Startup Podcast for Founders](https://pmfshow.buzzsprout.com/1889238/episodes/15024940-covid-brought-him-from-2m-year-to-near-bankruptcy-then-ai-took-him-to-2m-a-month-andrew-lockhead-founder-of-stay22)
*2025-01-01*
- Category: article

---

## 📖 Full Content (Scraped)

*8 articles scraped, 23,152 words total*

### Inclusion, AI and Sustainability take centre stage on day two of WTM London 2025
*4,738 words* | Source: **EXA** | [Link](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)

Inclusion, AI and Sustainability take centre stage on day two of WTM London 2025

===============
[Skip to content](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#content "Skip to content")

[Travel Daily Media](https://www.traveldailymedia.com/ "Travel Daily Media")

[Boost your business & benchmark against your competitors with **TDM Travel Trade Excellence Awards 2025** – start your entry here »](https://traveltradeexcellenceawards.com/)

[**TDM Travel Trade Excellence Awards 2025** – start your entry here »](https://traveltradeexcellenceawards.com/)

Success!
--------

Your account is ready. Let's get started!

![Image 3: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Login to your Account 
Welcome Back! Select method to log in

Username 

Password 

- [x] Remember Me 

[Forgot Password?](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

Login

[Continue with **Facebook**](https://www.traveldailymedia.com/wp-login.php?loginSocial=facebook&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Finclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025%2F)[Continue with **Google**](https://www.traveldailymedia.com/wp-login.php?loginSocial=google&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Finclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025%2F)[Continue with **Twitter**](https://www.traveldailymedia.com/wp-login.php?loginSocial=twitter&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Finclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025%2F)

Don't have an account? [Register](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

![Image 5: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Sign Up 
Enter your details below to create your account and get started.

I want to

- [x] Join the Community 

- [x] Events 

Name 

Email 

Password 

Confirm Password 

Register
Already have an account? [Login](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

![Image 7: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Forgot password? 
No worries, we'll send you reset instructions.

Enter your email 

Reset Password
[Back to Login](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

![Image 9: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Create a New Password 
Enter your new password below to complete the reset process. Ensure it's strong and secure

New Password 

Confirm Password 

Set Password
[Back to Login](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

[![Image 11](blob:http://localhost/9db9d5962483d27870316969aee76857)](https://www.traveldailymedia.com/)

![Image 13](blob:http://localhost/3a605d02a3c4405390240de2bd089bb0)

TDM AWARDS - NOMINATE NOW!

[enter Now](https://traveltradeexcellenceawards.com/)

[](https://www.traveldailymedia.com/search/)

[](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/#)

*   [HOME](https://www.traveldailymedia.com/)
*   [NEWS](https://www.traveldailymedia.com/news)
    *   [MARKETS](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)
        *   [ASIA](https://www.traveldailymedia.com/asia)
        *   [CHINA](https://www.traveldailymedia.com/china)
        *   [INDIA](https://www.traveldailymedia.com/india)
        *   [MIDDLE EAST](https://www.traveldailymedia.com/middle-east)
        *   [UK & EUROPE](https://www.traveldailymedia.com/uk)
        *   [USA & CANADA](https://www.traveldailymedia.com/usa)

    *   [SECTORS](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)
        *   [AIRLINES / AVIATION](https://www.traveldailymedia.com/category/air/airlines-aviation/)
        *   [AIRPORTS](https://www.traveldailymedia.com/category/air/airports/)
        *   [CRUISE](https://www.traveldailymedia.com/category/cruise/)
        *   [GOLFING](https://www.traveldailymedia.com/category/attractions/golfing/)
        *   [HOSPITALITY](https://www.traveldailymedia.com/category/hospitality/)
        *   [HR & CAREERS](https://www.traveldailymedia.com/category/careers/)
        *   [INDUSTRY APPOINTMENTS](https://www.traveldailymedia.com/category/careers/appointments/)
        *   [LUXURY TRAVEL](https://www.traveldailymedia.com/category/luxury-travel/)
        *   [MICE](https://www.traveldailymedia.com/category/mice/)
        *   [TOURISM](https://www.traveldailymedia.com/category/tourism/)
        *   [TECHNOLOGY](https://www.traveldailymedia.com/category/technology/)
        

*[... truncated, 72,137 more characters]*

---

### INTIX 2025: Stay22 Is Back and Here to Stay
*689 words* | Source: **EXA** | [Link](https://access.intix.org/Full-Article/intix-2025-stay22-is-back-and-here-to-stay)

![Image 1: INTIX 2025: Stay22 Is Back and Here to Stay](https://access.intix.org/Portals/0/EasyDNNNews/2818/images/10-1280-446-c-C-100.png)

### Leadership/ 01.22.25

#### Teddy Durgin

Some vendors use INTIX’s annual conference and exhibition as a valuable networking opportunity. Others treat it like a great big celebration.[Stay22](https://www.stay22.com/ "https://www.stay22.com/")is viewing[INTIX 2025](https://intix.org/events/90837 "https://intix.org/events/90837")as a homecoming of sorts.

Chief Commercial Officer Frederic Aouad says, “The last time Stay22 attended INTIX was back in January 2020, which was also in New York City. Back then, our sole purpose was helping ticketing companies monetize the travel intent of their patrons. Then, the pandemic hit. And with travel and events grinding to a halt, we pivoted to serving bloggers and publishers. Fast-forward four years, and after a ton of hard work, a sprinkle of luck and a 30-times growth journey, we’re back where we belong: supporting live events.”

Stay22 is a travel technology company that offers affiliate revenue generation opportunities for events, ticketing and travel media publications to monetize the travel intent of their audience or organization. At INTIX 2025, Aouad and his colleagues will be looking to remind attendees that Stay22 has a unique value proposition that benefits customers by allowing them to find the perfect accommodation near an event they are attending.

![Image 2: Photo of a man with a beard.](https://access.intix.org/Portals/0/FredericAouadPic_1.jpeg)

Frederic Aouad

He states, “As a ticketing company or event producer, Stay22 adds value to your [user experience] and creates a passive revenue stream. We’re stronger, smarter and more passionate than ever about helping this industry thrive.”

Among Stay22’s most popular offerings is its MAP product, which is built for events, ticketing platforms and travel medias. INTIX 2025 attendees will learn how the S tay22 MAP helps them earn affiliate revenue while giving your visitors tailored offers around the events they will be attending. Aouad remarks, “Live events are all about specific locations—and what communicates a location better than a map? Stay22’s dynamic, customizable maps don’t just look good, they work hard. Every time you help a fan with their travel plans, you earn passive revenue. They’re free, they improve the user experience and they work wonders on confirmation emails, event detail pages and more. Win-win-win!”

Another thing that distinguishes Stay22 is its tech support. Aouad says, “We like to think of ourselves as the tech-support version of your best friend: reliable, approachable and always there for you. Each Stay22 partner gets a dedicated Partner Success associate who will walk you through onboarding, answer your questions and brainstorm new revenue growth ideas with you. Plus, they’re just really nice people.”

Moving forward, Stay22 will be looking to stay ahead of the curve in terms of trends and new and emerging technology. Aouad believes that 2025 is already shaping up to be a big year for innovation with regards to live events. He listed two trends, in particular, he will be keeping an eye on. “Personalization on steroids” is the first one. He explains, “Fans expect every interaction to feel tailor-made, whether it’s the ticket-buying process, travel suggestions or event updates. Tools like our Allez AI-optimized links are paving the way to smarter, more intuitive user experiences.”

And the second trend that has his attention? “Seamless monetization,” he states. “Forget clunky upsells or intrusive ads. The future is about embedding monetization so smoothly that it feels like a natural part of the fan journey.”

But what commands the lion’s share of his focus right now is getting ready for INTIX 2025. So, what is Aouad most looking forward to with regards to this year's show? “I’m most excited about Stay22 reconnecting with this incredible community and hearing firsthand from ticketing pros about their challenges and dreams. Also, let’s be real – the energy at INTIX is unmatched!”

**_Editor’s Note:_**_Not yet registered for INTIX? What are you waiting for? Visit[INTIX.org](https://intix.org/networks/events/90837 "https://intix.org/networks/events/90837")to register today!_

* * *

**You May Also Like**

*   [Cross-Border Connections: A New Regional Ticketing Group Unites the Greater Niagara Area](https://access.intix.org/Full-Article/cross-border-connections-a-new-regional-ticketing-group-unites-the-greater-niagara-area)
*   [INTIX 2025 Attendees Will Be ‘Busy Fools’ No More After Attending This Workshop](https://access.intix.org/Full-Article/intix-2025-attendees-will-be-busy-fools-no-more-after-attending-this-workshop)

* * *

![Image 3](https://access.intix.org/Portals/0/Access%20Weekly%20logo%202.PNG)_Want news like this delivered to your inbox weekly? Subscribe to the [Access Weekly newsletter](http://eepurl.com/hkQGrX), your ticket to indu

*[... truncated, 31 more characters]*

---

### COVID nearly bankrupted him. Then with AI he grew from $0 to $25M ARR in 4 years. | Andrew Lockhead, Founder of Stay22 - A Product Market Fit Show | Startup Podcast for Founders
*9,472 words* | Source: **EXA** | [Link](https://pmfshow.buzzsprout.com/1889238/episodes/15024940-covid-brought-him-from-2m-year-to-near-bankruptcy-then-ai-took-him-to-2m-a-month-andrew-lockhead-founder-of-stay22)

Andrew:0:00

Some people, we had told them you know what? We'll pay you $5,000 up front, and we're going to recoup that money. As soon as you generate revenue, I'll send you money.

Pablo:0:06

You paid them to become customers.

Andrew:0:08

We offered them. As soon as you offer, you know what? If it's still not enough, I'll pay you 5,000.

Pablo:0:12

Wow.

Andrew:0:12

After a couple of months, you will generate enough revenues. I'm going to recoup that money and pay you back.

Pablo:0:17

Welcome to The Product Market Fit Show, brought to you by Mistrial, a seed stage firm based in Canada. I'm Pablo, I'm a founder turned VC. My goal is to help early-stage founders like you find product-market fit. Andrew, welcome to the show.

Andrew:0:34

Hey, Pablo, it's a pleasure.

Pablo:0:34

You're running a company now called Stay22. I remember when you raised your seed round. I saw it late, and I was like, oh, this idea sounds really compelling. Then I saw you grow, and I think you got to about two million in Topline, doing really well. Then Covid happened, and it was like – you're in the travel industry. We’ll get into exactly what you do but went from two million to near zero overnight, and now you've built it back up. Not the two million a year but the two million a month. That's incredible journey, so we'll dive into that. Maybe, Andrew, tell us a little bit what is Stay22 and just a bit about the origin story, like how you started in the first place?

Andrew:1:15

Of course. It first started with my previous company. I had a ticketing platform back in the days that I sold, and I was looking for a new challenge. My co-founder was coming from the travel world. He was trying to go through a B2C route, which I hate. I'm a B2B fan from heart, and I told him there's a better way to do what you're doing right now to reach more people. Let's use ticketing platform events to reach out those user, and this is how Stay22 was formed. We were working with events like South by Southwest, CES, Startup Montreal, C2 to just empower their guests to find destination accommodation and restaurants near their next event, and this is how the story started for us about seven years ago.

Pablo:1:54

What was your co-founder doing before? What was his B2C idea?

Andrew:1:58

It was also in travel, something similar to TripIt so kind of a metasearch but for short-term rentals, kind of like Airbnb merged with Vrbo and [ unclear] and all of those short-term rentals.

Pablo:2:08

What you shifted to was like – if I understand correctly, it's like somebody's doing a big event, and then on their own website they embed your platform so that people can find accommodations near the event easily?

Andrew:2:19

Exactly. This was one of our first idea. We came up with an API for them to embed on their website or ticketing platform, which was a big mistake. No one wanted to integrate API. It’s too complex, take too much time, and the sales cycle was really low because of that. We came up with a new solution called a map-based solution. Now that was taking five minutes, the embedded live frame on their website, and they were able to just show where their events was taking place, all the live abilities with prices for destination nearby from Airbnb, Vrbo, Hotel, Booking.com, Expedia, and so on.

Pablo:2:50

What's the rev share model? How do they win? How do you win?

Andrew:2:53

It depends. With that first customer base we started with, we were more of a painkiller for them, so that was great. They didn't need any type of rev share. They're just like you know what? You're solving a problem for me. I can focus on my events. I don't have to worry about finding accommodation for my guests. You keep everything, and I'm happy with this.

Pablo:3:12

What did they do before? What was a pain point for them?

Andrew:3:14

It was such a bad experience. They need to reach out to hotels. They need to negotiate deals after this. They need to fill the block. If they don't fill it, they're going to be on the payroll, so they have to pay for whatever room people don't fill out. It's just such a pain for them. They don't want to waste time on this. It's not adding value for the event, so they just decide to use solution like yourself.

Pablo:3:32

Tell me a little bit more about the starting of that. Once you partner up with your co-founder, you decide to go B2B. Do you just start building right away? Do you raise money? Do you talk to customers? You done it before. You weren't starting from square one either.

Andrew:3:45

My previous business was bootstrap. For this one, I'm like you know what? I was 28 at that time. I'm like I want to go for the VC path. I want to go fast. I want to break things. I want to see what it's like, so we decided to jump into the journey and jump into another incubator in Denver, Colorado. Me and him barely knew each other for a couple of weeks where we're building stuff in a basement, and we decided to move to Denver, Colorado for

*[... truncated, 47,103 more characters]*

---

### Creating Alignment Through the CRO’s Point of View: A Deep Dive with Frederic Aouad
*1,491 words* | Source: **GOOGLE** | [Link](https://revenuearchitects.io/chief-revenue-officer-alignment-strategies-podcast/)

![Image 1](https://revenuearchitects.io/wp-content/uploads/2025/05/maxresdefault-1024x576.jpg)

The long-awaited return of the podcast kicks off 2025 with exciting energy. Mario, the familiar voice to longtime listeners, resumes his role as host, this time joined by a new co-host, Noam. Together, they bring fresh perspectives and a renewed commitment to digging deep into the nuances of business leadership. For their first episode after a one-year hiatus, they invited a special guest:[**Frederic Aouad**](https://www.linkedin.com/in/fredericaouad/en?originalSubdomain=ca), the Chief Revenue Officer (CRO) at[**Stay22**](https://www.stay22.com/?utm_term=stay22&utm_campaign=Search+%7C+Branded&utm_source=adwords&utm_medium=ppc&hsa_acc=8501556593&hsa_cam=20187569445&hsa_grp=151087201842&hsa_ad=659751685626&hsa_src=g&hsa_tgt=kwd-362264904191&hsa_kw=stay22&hsa_mt=p&hsa_net=adwords&hsa_ver=3&gad_source=1&gbraid=0AAAAApFBZlTekuz4HWUFBB-bF1g3xRsDW&gclid=Cj0KCQjwzrzABhD8ARIsANlSWNMpm1TPHIACGcdDBhXBrTFqNpKZu_W5CzSa5XZIGGpwj3EImR4M3dQaAowAEALw_wcB).

Frederic introduces himself warmly as the first guest of the newly relaunched show. From the start, the focus is clear: understanding how a CRO creates alignment within an organization, especially from a revenue perspective. Frederic begins by sharing his background, setting the tone for the following rich conversation. Born and raised in Montreal, Canada, in a Lebanese immigrant family, Frederic frames his life through the lens of his roles as a husband and father of three.

A self-professed fan of combat sports like Brazilian jiu-jitsu and Judo, Frederic also studied political science purely out of passion. His career path led him from hotel sales at Starwood (now Marriott) to go-to-market leadership roles with Corporate Stays in the short-term rental sector. Eventually, in late 2019, Frederic transitioned into tech at Stay22, looking to combine his travel and hospitality expertise with evolving technology opportunities.

At Stay22, Frederic oversees all go-to-market functions, bringing a comprehensive view of aligning different teams toward shared objectives. His story lays the foundation for a deeper conversation on leadership, goal-setting, and team alignment.

Aligning Short-Term Goals with Long-Term Vision
-----------------------------------------------

After a light-hearted story about golf injuries that brings a sense of lightness to the conversation, the podcast dives into the complex issue of balancing short-term goals with long-term vision. This balance is critical for any organization, but Frederic explains it’s especially vital in revenue-generating. Ideally, short-term goals act as building blocks toward a bigger vision, ensuring that daily activities contribute meaningfully to the overarching objectives.

Frederic emphasizes that while natural alignment is the dream, reality often proves messier. Short-term decisions sometimes conflict with long-term strategy. Here, leadership plays a pivotal role. Leaders must identify when these misalignments occur and address them effectively. Frederic suggests that one way to promote alignment is through distributed decision-making, a concept where individuals are empowered and incentivized to make decisions that mirror the company’s intended outcomes.

Creating an environment where personal financial interests align with company goals is not just beneficial—it’s essential. If people see that their growth and economic success are tied directly to the company’s health, they are more likely to work toward common goals. Designing systems that support this alignment is a sophisticated task. Achieving practical alignment across all teams, even in straightforward business models, presents ongoing challenges. Leaders must continuously evaluate and redesign processes to create environments where everyone’s objectives flow naturally toward the company’s broader vision, from the newest hire to the C-suite.

Incentivizing Revenue Teams for Alignment at Stay22
---------------------------------------------------

Frederic shares how Stay22 has approached the complex task of incentivizing revenue teams to work in unison. Stay22 operates on a cost-per-acquisition (CPA) or affiliation model, meaning its revenue grows alongside its clients’ success. This creates an inherent alignment of interests—when Stay22 wins, its partners win, too. However, internal team alignment requires intentional structure.

To keep the sales team motivated and aligned, Stay22 implemented a sliding commission scale. Salespeople are assigned user acquisition targets, and their commissions rise based on their performance against those targets. Hit higher targets, and you earn more—simple and powerful. The model ensures that the focus remains on bringing in users and revenue, not just hitting arbitrary quotas. This is why sales managers should use some of these[**12 training techniques**](https://revenuearchitects.io/12-training-techniques-sales-managers-should-be-u

*[... truncated, 6,364 more characters]*

---

### Meet a handful of mentors who can help you build new skills
*1,062 words* | Source: **GOOGLE** | [Link](https://femmepalette.com/blog-posts/meet-a-handful-of-mentors-who-can-help-you-build-new-skills)

Ready to take your career to new heights by enhancing your skill set? Our latest mentor spotlight blog post is here, focusing on skill building to help you achieve professional growth and success! Let's dive in and meet some of the incredible [mentors](https://www.femmepalette.com/career-challenge/skill-building) who are ready to help you master new skills and excel in your career journey.

‍

![Image 1](https://cdn.prod.website-files.com/609bcd2eab390bc130192517/64b5027d0cc72f365fb4cc7d_pvglpm35khiox6pvglplukos1gysyfbb.png)

[Cristina Bugu](https://www.linkedin.com/in/cristina-bugu-a8a75913/)

Training & Enablement Program Manager at Oracle

Bucharest, Romania

With 17 years of experience in the IT industry and a passion for coaching, Cristina combines her technical expertise with a playful approach to personal and professional development. She believes in the magic of life and the power of relationships, helping others see connections and purpose in everyday life. Cristina's strengths include connectedness, achiever, developer, responsibility, and intellection. Her motto, inspired by Marshall B. Rosenberg, is "Show up with the desire to give. Natural giving from the heart is all the happiness and inspiration you will ever need." Let Cristina guide you in developing essential soft skills and fostering meaningful connections.

‍

![Image 2](https://cdn.prod.website-files.com/609bcd2eab390bc130192517/63e60c6d08dde3d231d4f596_0bo8wy8t0yvb75p0bofqtmoiedjzs6n1.png)

[Jan Bárta](https://www.linkedin.com/in/janbarta/)

Chief Technology Officer at Kindred.

Prague, Czechia

As the CTO of a service company specializing in website and application development, Jan has extensive experience in software engineering, agile development, and building strong teams. With a background in .NET and JavaScript, and a history of product development in the pharmaceutical industry, Jan is ready to help you tackle software engineering challenges, enhance your technical skills, and master agile methodologies.

‍

![Image 3](https://cdn.prod.website-files.com/609bcd2eab390bc130192517/6673f9d0b088d252a197e2a4_AD_4nXdtyyV2iFqOlOlfDM-p9WT57-wi9zj4cJ7OfT7zPE88KushO8JMxThA4xuIT6gJQ0lu431o2qNiTDM3k3SH05lt4jioYVXbNaz4pHs2v-mUEXA_a7gHrB-YJb9QJrUYD98QVcSCMCg-DUxRqcrrLDQVdTUS.png)

[Tero Moliis](https://www.linkedin.com/in/teromoliis/)

Country Director at Lenz Mexico

Monterrey, Mexico

Tero is a multifaceted professional with a rich background in startups, entrepreneurship, project management, public speaking, gamification, and game and UX design. Originally from Finland, Tero is a learning explorer and unlearning enthusiast. He is the Country Director for Lenz.fi in Mexico and serves on the board of advisors for several startups globally. Tero is also a published board game designer and the founder of CaféConAutores, an organization promoting local authors and literature. His diverse experiences and passion for learning make him an excellent mentor for those looking to innovate and develop new skills in gamification and project management.

‍

![Image 4](https://cdn.prod.website-files.com/609bcd2eab390bc130192517/6673f9d1278fc6c99fdc9572_AD_4nXelhfrHGTQUjvOU5cFhvPhunP_enMk31dN0XIqOvQ9CixJwxvyp1z3RDsjriqItaKlInGHauu7ywWVt6XtQyJkzSHTsY0E5G8Myap1mqbJuANgbmHb4boxgtfrw83xj_ZpXurnqARNjqQP2BE5qY2EqAS8.png)

[Jessica Mansourati](https://www.linkedin.com/in/jessica-mansourati-5928b221/)

Head of Innovation & Co-founder at Nextory / Highlight

Stockholm, Sweden

With over a decade of experience in the audio industry, Jessica has worked at Universal Music, Spotify, Acast, and founded her own companies. Her first company, Bookself, was a social audiobook platform, and her second, highlight.fm, offers bite-sized audio clips for various moods and topics. Jessica holds an MSc in Management and Economics from the Stockholm School of Economics and the Royal Institute of Technology. She has mentored startup founders and creatives in the audio and tech industries and is ready to help you enhance your entrepreneurial skills and navigate the digital audio landscape.

‍

![Image 5](https://cdn.prod.website-files.com/609bcd2eab390bc130192517/6673f9d0411eda4a2e46d28c_AD_4nXcIi7Phvh-zDvPzqzQsSG5kI6B2hN3JFp3WftFTpWVRLZZLYicvUYnjeN-UNTpj1k6P4L1nJiDSHLkPRmtvWMVy0wqAnWy5acem9EDneneskNSSNRhH438Hbn_xJlNsMKIyd3qFcHWAMs-M3jfgJ1OrU54.png)

[Sam Adeniyi](https://www.linkedin.com/in/sam-adeniyi/)

Senior Software Engineer at Perlego Ltd.

Bromley, United Kingdom

Sam has a background in statistics and has worked across multiple industries, including FinTech, EdTech, Renewable Energy, IT Consulting, and Telecoms. As a software engineer and team leader, Sam has spent the past few years building early-stage digital products. Outside of work, he loves to read and is currently learning to roller skate. Sam is eager to help you tackle software engineering challenges, develop your technical skills, and lead your team to success.

‍

![Image 6](https://cdn.prod.website-files.com/609bc

*[... truncated, 4,655 more characters]*

---

### Stay22 bolsters leadership with tech and finance appointments
*3,078 words* | Source: **GOOGLE** | [Link](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/)

Stay22 bolsters leadership with tech and finance appointments

===============
[Skip to content](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#content "Skip to content")

[Travel Daily Media](https://www.traveldailymedia.com/ "Travel Daily Media")

[Boost your business & benchmark against your competitors with **TDM Travel Trade Excellence Awards 2025** – start your entry here »](https://traveltradeexcellenceawards.com/)

[**TDM Travel Trade Excellence Awards 2025** – start your entry here »](https://traveltradeexcellenceawards.com/)

Success!
--------

Your account is ready. Let's get started!

![Image 3: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Login to your Account 
Welcome Back! Select method to log in

Username 

Password 

- [x] Remember Me 

[Forgot Password?](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

Login

[Continue with **Facebook**](https://www.traveldailymedia.com/wp-login.php?loginSocial=facebook&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Fstay22-bolsters-leadership-with-tech-and-finance-appointments%2F)[Continue with **Google**](https://www.traveldailymedia.com/wp-login.php?loginSocial=google&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Fstay22-bolsters-leadership-with-tech-and-finance-appointments%2F)[Continue with **Twitter**](https://www.traveldailymedia.com/wp-login.php?loginSocial=twitter&redirect=https%3A%2F%2Fwww.traveldailymedia.com%2Fstay22-bolsters-leadership-with-tech-and-finance-appointments%2F)

Don't have an account? [Register](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

![Image 5: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Sign Up 
Enter your details below to create your account and get started.

I want to

- [x] Join the Community 

- [x] Events 

Name 

Email 

Password 

Confirm Password 

Register
Already have an account? [Login](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

![Image 7: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Forgot password? 
No worries, we'll send you reset instructions.

Enter your email 

Reset Password
[Back to Login](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

![Image 9: mail](blob:http://localhost/e8a57f4972516a1d3218894eabc89576)Create a New Password 
Enter your new password below to complete the reset process. Ensure it's strong and secure

New Password 

Confirm Password 

Set Password
[Back to Login](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

[![Image 11](https://storage.googleapis.com/stateless-www-live-traveldailymedia/2025/04/8379281b-mask-group-1.png)](https://www.traveldailymedia.com/)

![Image 12](https://storage.googleapis.com/stateless-www-live-traveldailymedia/2025/04/e30e53cd-2026-tdm-awards-logo_new-gold-1.png)

TDM AWARDS - NOMINATE NOW!

[enter Now](https://traveltradeexcellenceawards.com/)

[](https://www.traveldailymedia.com/search/)

[](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/#)

*   [HOME](https://www.traveldailymedia.com/)
*   [NEWS](https://www.traveldailymedia.com/news)
    *   [MARKETS](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/)
        *   [ASIA](https://www.traveldailymedia.com/asia)
        *   [CHINA](https://www.traveldailymedia.com/china)
        *   [INDIA](https://www.traveldailymedia.com/india)
        *   [MIDDLE EAST](https://www.traveldailymedia.com/middle-east)
        *   [UK & EUROPE](https://www.traveldailymedia.com/uk)
        *   [USA & CANADA](https://www.traveldailymedia.com/usa)

    *   [SECTORS](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/)
        *   [AIRLINES / AVIATION](https://www.traveldailymedia.com/category/air/airlines-aviation/)
        *   [AIRPORTS](https://www.traveldailymedia.com/category/air/airports/)
        *   [CRUISE](https://www.traveldailymedia.com/category/cruise/)
        *   [GOLFING](https://www.traveldailymedia.com/category/attractions/golfing/)
        *   [HOSPITALITY](https://www.traveldailymedia.com/category/hospitality/)
        *   [HR & CAREERS](https://www.traveldailymedia.com/category/careers/)
        *   [INDUSTRY APPOINTMENTS](https://www.traveldailymedia.com/category/careers/appointments/)
        *   [LUXURY TRAVEL](https://www.traveldailymedia.com/category/luxury-travel/)
        *   [MICE](https://www.traveldailymedia.com/category/mice/)
        *   [TOURISM](https://www.traveldailymedia.com/category/tourism/)
        *   [TECHNOLOGY](https://www.traveldailymedia.com/category/technology/)
        *   [TRAVEL AGENTS](https://www.traveldailymedia.com/category/travel-agents/)

    *   [PARTNER ARTICLES](https://traveldail

*[... truncated, 60,784 more characters]*

---

### Pavilion | Pavilion University
*1,358 words* | Source: **GOOGLE** | [Link](https://www.joinpavilion.com/pavilion-university)

Pavilion | Pavilion University

===============

Opens in a new window Opens an external website Opens an external website in a new window

This website utilizes technologies such as cookies to enable essential site functionality, as well as for analytics, personalization, and targeted advertising. To learn more, view the following link: [Privacy Policy](https://www.joinpavilion.com/privacy-policy)

[![Image 7: Pavilion Logo Full Color](https://www.joinpavilion.com/hs-fs/hubfs/mjtw-assets/logos/Pavilion-Logo-FullColor.png?width=1667&height=417&name=Pavilion-Logo-FullColor.png)](https://www.joinpavilion.com/?hsLang=en)

*   [Membership](https://www.joinpavilion.com/membership)

    *           *   [Executive](https://www.joinpavilion.com/executive-membership)
        *   [CEO](https://www.joinpavilion.com/ceo)
        *   [Associate](https://www.joinpavilion.com/associate-membership)
        *   [Pavilion for Teams](https://www.joinpavilion.com/for-teams)
        *   [Pricing](https://www.joinpavilion.com/pricing)

*   [Why Pavilion](https://www.joinpavilion.com/why-pavilion)

    *           *   [Pavilion University](https://www.joinpavilion.com/pavilion-university)
        *   [Events](https://www.joinpavilion.com/events-at-pavilion)
        *   [Functional Groups](https://www.joinpavilion.com/functional-communities)
        *   [Chapters at Pavilion](https://www.joinpavilion.com/chapters)

*   [Join Now](https://www.joinpavilion.com/join)
*   [Log In](https://community.joinpavilion.com/login)

Menu

![Image 8: background image](https://www.joinpavilion.com/hubfs/Pavilion-U-Course-Background-web-2.jpg)

Pavilion University
===================

Taught by active CXOs and proven operators, Pavilion University equips you with the playbooks, frameworks, and network to solve real challenges and lead with clarity today.

*   [Explore Memberships](https://www.joinpavilion.com/membership?hsLang=en)
*   [View all Courses](https://www.joinpavilion.com/pavilion-university/catalog?hsLang=en)

![Image 9: pavu_mock2](https://www.joinpavilion.com/hs-fs/hubfs/pavu_mock2.jpg?width=1400&height=1485&name=pavu_mock2.jpg)

Ways to Learn
-------------

Whether you’re short on time or ready for an immersive learning experience, Pavilion University is designed to meet you where you are.

![Image 10: ondemand_icon](https://www.joinpavilion.com/hs-fs/hubfs/ondemand_icon.png?width=140&height=140&name=ondemand_icon.png)

### On-Demand

Learn anytime with clear, step‑by‑step tracks built for emerging leaders. Gain confidence fast, collect micro‑credentials, and see visible progress you can point to right away.

[View all On-Demand Courses](https://www.joinpavilion.com/pavilion-university/catalog?type=%22On+Demand%22&function=*&membership-level=*&hsLang=en)

![Image 11: hybrid_icon](https://www.joinpavilion.com/hs-fs/hubfs/hybrid_icon.png?width=140&height=140&name=hybrid_icon.png)

### Hybrid

Mix live touchpoints with self‑paced learning so you can dive deep without losing momentum. Ask real‑time questions, then apply proven frameworks on your own schedule.

[View all Hybrid Courses](https://www.joinpavilion.com/pavilion-university/catalog?type=%22Hybrid%22&function=*&membership-level=*&hsLang=en)

![Image 12: live_icon](https://www.joinpavilion.com/hs-fs/hubfs/live_icon.png?width=140&height=140&name=live_icon.png)

### Live

Join peers in dynamic, expert‑led sessions designed for active operators. Get direct feedback, actionable tools, and leave ready to lead with clarity and confidence.

[View all Live Courses](https://www.joinpavilion.com/pavilion-university/catalog?type=%22Live%22&function=*&membership-level=*&hsLang=en)

Explore the courses that advance GTM careers
--------------------------------------------

Take a self-guided tour

![Image 13: education-graphic2](https://www.joinpavilion.com/hs-fs/hubfs/education-graphic2.png?width=1296&height=464&name=education-graphic2.png)

Our Schools
-----------

Multi-week intensive courses taught live by industry leaders, designed to provide you with actionable insights into the core functions of a GTM leader.

[![Image 14: leadership_icon](https://www.joinpavilion.com/hs-fs/hubfs/leadership_icon.png?width=120&height=120&name=leadership_icon.png) #### CRO School 90.2% CSAT Score](https://www.joinpavilion.com/pavilion-university/cro-school?hsLang=en)

[![Image 15: customer-success_icon](https://www.joinpavilion.com/hs-fs/hubfs/customer-success_icon.png?width=120&height=121&name=customer-success_icon.png) #### CCO School 90.4% CSAT Score](https://www.joinpavilion.com/pavilion-university/cco-school?hsLang=en)

[![Image 16: marketing_icon](https://www.joinpavilion.com/hs-fs/hubfs/marketing_icon.png?width=120&height=121&name=marketing_icon.png) #### CMO School 88.3% CSAT Score](https://www.joinpavilion.com/pavilion-university/cmo-school?hsLang=en)

[![Image 17: revops_icon](https://www.joinpavilion.com/hs-fs/hubfs/revops_icon.png?width=120&height=121&name=revops_icon.png) #### RevOps School 9

*[... truncated, 11,155 more characters]*

---

### Inclusion, AI and Sustainability take centre stage on day two of WTM London 2025
*1,264 words* | Source: **GOOGLE** | [Link](https://hub.wtm.com/press/wtm-london-press-releases/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)

The second day of World Travel Market London 2025 welcomed the main sessions of this year’s DEAI Summit. It also saw more discussions on AI, sustainability and marketing and touched on how humour can be used to sell travel.

An early session in the **DEAI Summit** highlighted ‘inclusion fatigue’ and political resistance to diversity initiatives.

[![Image 1](https://hub.wtm.com/wp-content/uploads/2025/11/WTM-London_91-1024x576.png)](https://hub.wtm.com/wp-content/uploads/2025/11/WTM-London_91.png)
“There is definitely a rollback that is making it more challenging,” said Joanna Reeve, of tour operator Intrepid Travel. But she suggested travel could make us feel connected to other cultures so “there’s less of ‘us and them’ and more ‘us’.”

Edgar Weggelaar of Queer Destinations, which works with governments on LGBTQ+ tourism strategies, asserted the Trump administration’s anti-DEAI messaging ‘had an impact’, pointing to FBI statistics showing a rise in homophobic and racist attacks. He believed it would have a detrimental effect for US tourism because “we come to places where we feel comfortable and desired.”

As for those keen to welcome LGBTQ+ travellers, Weggelaar said he would like to see investment beyond Pride month.

Accessibility champion Richard Thompson of Inclu Group, said the pandemic had accelerated the use of technology, including for booking travel, to the exclusion of those unable to use it. “Protocols that were implemented, rightly for covid, have been kept in place and it’s another barrier for disabled people,” he said.

Inclu’s research of 600 luxury hotels around the world found pillow menus and dog-friendly facilities more commonly detailed than information on accessibility. Thompson stressed: “We’re turning disabled people into gamblers. They’re gambling tens of thousands of pounds on a holiday before they leave home because they don’t know what they’re getting.”

He called accessible travel “the last untapped market” and pointed out adaptations and marketing needed to look beyond wheelchairs, which were used by only 6% of disabled people.

In a session covering _‘_ The Business Case for Inclusion’, Sadia Ramzan of The Muslim Women Travel Group said small changes could have an impact, for instance not welcoming Muslim travellers with sparkling wine but with a mocktail would prompt word of mouth recommendations. She praised Japan for its halal certification and modesty options in spas.

Futureproofing strategist Sita Sahu of FUTURE& said that those destinations not showing themselves to be inclusive were “leaving money on the table”, and she told travel companies: “At the moment DEAI lives within HR and marketing, but we see by 2030 it’s going to live within governance.”

Destinations were also represented at the conference. Thailand’s recent marriage equality law has opened new opportunities for the country which believes it has the only tourism board with a dedicated LGBTQ+ platform.

Meanwhile Malta, a well-established LGBTQ+-Friendly tourism destination, is, with the help of universities, undertaking international tourism studies on further inclusion,

Iceland’s minister responsible for tourism Hanna Katrín Friðriksson referred to the country’s recent Women’s Day Off, a 50 th anniversary protest about inequality, which commemorated a landmark 1975 strike. Though there was some backlash to the event she believed it had lessons for wider inclusivity.

**AI debates**

Diversification of revenue streams was a theme at the opening session of Wednesday afternoon’s **Media & Influencer Forum**. Attendees heard how having four to five income streams was now common for content creators, with the need to diversify recognised across all types of publishers.

The panel also touched on the use of artificial intelligence. Weather2Travel’s Colin Carter said AI content could not substitute well researched on-the-ground writing from journalists and warned of the technology’s environmental impacts. But, he added, the site was having to revise existing content to improve its appearance in AI-driven search results.

Meanwhile, Frederic Aouad of Stay22 advised creators: “Optimising affiliate links is a passion of nobody… AI can do that for you.”

Artificial intelligence is not the enemy of travel, according to the result of a lively debate which rounded off the **Technology Summit**.

Two teams of three argued for and against AI in tourism. Stephen Joyce from Protect Group noted that trips curated by AI “remove the magical human chaos of being somewhere new”. Advocates of AI pointed out that travellers are already using and enjoying AI, despite its mistakes and limitations.

The show of hands was overwhelmingly in favour of the technology. Christian Watts from Magpie joked that it was “a tough day for the humans” but added that the audience response probably reflected “not where AI is today, but where it’s going to be in the future”.

**Reframing source markets and sustainability**

Among today’s **Geo-eco

*[... truncated, 3,546 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Creating Alignment Through the CRO's Point of View: A Deep Dive ...](https://revenuearchitects.io/chief-revenue-officer-alignment-strategies-podcast/)**
  - Source: revenuearchitects.io
  - *... Frederic Aouad, the Chief Revenue Officer (CRO) at Stay22. Frederic ... Watch the full podcast episode on YouTube to hear the whole conversation w...*

- **[Meet a handful of mentors who can help you build new skills](https://femmepalette.com/blog-posts/meet-a-handful-of-mentors-who-can-help-you-build-new-skills)**
  - Source: femmepalette.com
  - *Jun 20, 2024 ... Frederic Aouad, a father of three and BJJ black belt, joined Stay22 in 2019, bringing over a decade of travel and tech industry exper...*

- **[Stay22 bolsters leadership with tech and finance appointments](https://www.traveldailymedia.com/stay22-bolsters-leadership-with-tech-and-finance-appointments/)**
  - Source: traveldailymedia.com
  - *Nov 4, 2025 ... Frederic Aouad – Chief Commercial Officer; Fabien Loupy – Chief Technology Officer. Stay22 CFO Louis-Charles Genest. Highly-qualified ...*

- **[Pavilion University - Pavilion](https://www.joinpavilion.com/pavilion-university)**
  - Source: joinpavilion.com
  - *From GTM tactics to career acceleration, it's become a cornerstone of how I grow. Frederic Aouad. CCO at Stay22 ... Topline Podcast · The Revenue Lead...*

- **[Inclusion, AI and Sustainability take centre stage on day two of WTM ...](https://hub.wtm.com/press/wtm-london-press-releases/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)**
  - Source: hub.wtm.com
  - *Nov 5, 2025 ... Meanwhile, Frederic Aouad of Stay22 advised creators: “Optimising affiliate links is a passion of nobody… ... Podcast, Press Release, ...*

- **[Are you attending WTM London 2025? — Let's connect at World ...](https://www.travelmassive.com/posts/are-you-attending-wtm-london-2025-810316683)**
  - Source: travelmassive.com
  - *... Podcast. And at 14:20 ... Frederic Aouad, Natalya Wissink, Kateryna Topol and Colin Carter exploring key research insights from Stay22 and Travel ...*

- **[Frederic Aouad - Femme Palette Mentor](https://femmepalette.com/mentors/frederic-aouad)**
  - Source: femmepalette.com
  - *Frederic Aouad, a father of 3 and BJJ blackbelt, joined Stay22 in mid-2019 ... Share with us the mentor name during the interview with the Program ......*

- **[From Accessibility Failures to AI Takeover: WTM London 2025's ...](https://www.travelandtourworld.com/news/article/from-accessibility-failures-to-ai-takeover-wtm-london-2025s-bold-blueprint-for-the-travel-industry/)**
  - Source: travelandtourworld.com
  - *Nov 6, 2025 ... Interviews · Videos · Shows · Clients · TTW ... Frederic Aouad from Stay22 made everyone laugh: “Optimising affiliate links is a passi...*

- **[Inclusion, AI and Sustainability take centre stage on day two of WTM ...](https://www.traveldailymedia.com/inclusion-ai-and-sustainability-take-centre-stage-on-day-two-of-wtm-london-2025/)**
  - Source: traveldailymedia.com
  - *Nov 6, 2025 ... ... INTERVIEWS · IWTA INTERVIEWS; TDM ... Meanwhile, Frederic Aouad of Stay22 advised creators: “Optimising affiliate links is a passi...*

- **[Stay22 Faces Unexpected Legal Challenge as AI Booking Agent ...](https://blog.stay22.com/stay22-faces-unexpected-legal-challenge-as-ai-booking-agent-gains-sentience)**
  - Source: blog.stay22.com
  - *Apr 1, 2025 ... "I tried to fire her," said Frederic Aouad, Chief Commercial Officer at Stay22, "but she hacked into the system and rehired herself - ...*

---

*Generated by Founder Scraper*
