# Sébastien Castiel

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402381113169481728 | Article |  |  | I used to start an AI coding prompt and go make coffee ☕. Or wander the internet. The agent would churn for a minute or two, and I'd read its thinking afterward.

That's over now.

With the latest Cursor models, most prompts finish in 10-20 seconds. Fast enough that I watch the thought process instead of waiting for it to end.

Turns out there's a threshold around 20 seconds. Above it, you context switch. Below it, you stay in flow.

This isn't about the 3x productivity gain everyone talks about. It's about AI becoming an extension of your thought process rather than an asynchronous collaborator.

I wrote about what this shift actually feels like in practice 👇

https://lnkd.in/e9FwBjKm | 11 | 1 | 0 | 3d | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.776Z |  | 2025-12-04T16:19:46.970Z | https://betweentheprompts.com/speed-threshold/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397675147878391808 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGqATNLrxtIxA/image-shrink_1280/B4EZqlbXzgHUAM-/0/1763712008342?e=1765785600&v=beta&t=k95e7e54E9DwMeta1-7ou6cb_bf3ZV1pVa90zLvStYo | Très fier d'apprendre que Framasoft a déployé une instance de mon projet open source Spliit pour créer Framacount 😀

J'ai toujours aimé la mission que s'est donnée Framasoft de promouvoir des alternatives open source aux services propriétaires, et les rendre accessibles au grand public.

Vraiment content de pouvoir contribuer à ça 😊

👉 https://framacount.org | 42 | 0 | 1 | 2w | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.777Z |  | 2025-11-21T16:39:57.412Z | https://www.linkedin.com/feed/update/urn:li:activity:7397544334360956928/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391128868679753728 | Article |  |  | Spent weeks building a copilot feature WITHOUT AI help—too complex, couldn't even explain what I wanted to Claude. 🤯

The irony? That human-only architectural work made our codebase so AI-friendly that "write-a-prompt" replaced "write-a-spec" for most new features.

We didn't set out to build AI-friendly systems. We set out to build good systems. Turns out they're the same thing. 💡

Why good abstractions for humans become perfect for LLMs: https://lnkd.in/eYZtXSim | 13 | 0 | 0 | 1mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.777Z |  | 2025-11-03T15:07:22.827Z | https://betweentheprompts.com/ai-ready-systems/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7389662295733252099 | Article |  |  | 🚀 At Vasco, we’re going all-in on AI. One of our most exciting challenges so far has been building a modular Copilot that helps users navigate complex RevOps workflows right inside the app.

🧠 What started as a small experiment turned into a real shift in how we think about AI in product and engineering.

🛠️ I wrote about how we built it, what we learned, and where we’re heading next in the first post of our new ✨ Engineering Blog ✨!

👉 Check it out: https://lnkd.in/e3bU3NEJ | 22 | 2 | 3 | 1mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.778Z |  | 2025-10-30T13:59:44.589Z | https://engineering.vasco.app/articles/building-modular-ai-copilot |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7386379667315773440 | Text |  |  | 🚀 Come work with me! We’re looking for a Senior Software Developer to join our AI squad!

You’ll work closely with Dan and me on a small team with a big mission: turning our Gama product into a state-of-the-art AI assistant for our users.

It’s already delivering real value, but we have ambitious goals ahead, and plenty of exciting challenges to tackle.

If you love building impactful products and enjoy solving complex problems, let me know! | 34 | 1 | 10 | 1mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.778Z |  | 2025-10-21T12:35:44.986Z |  | https://www.linkedin.com/jobs/view/4315889215/ | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7373832768474091520 | Document |  |  | Proud to have contributed to this guide to AI-powered RevOps for Vasco 🙂 | 11 | 2 | 0 | 2mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.779Z |  | 2025-09-16T21:38:51.192Z | https://www.linkedin.com/feed/update/urn:li:activity:7369372423546257408/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7368663333283074048 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFIZ0J89ju2gw/feedshare-shrink_800/B4EZkK1wM9HoAg-/0/1756823488611?e=1766620800&v=beta&t=pMeRz5kk99JbsP0Ikx9q7crgRo6_38UdxoOiFPiEAmk | Very proud to be a part of making my employer sponsor this cool dev event in Montreal next fall! 🤩 | 16 | 1 | 0 | 3mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:00.779Z |  | 2025-09-02T15:17:21.799Z | https://www.linkedin.com/feed/update/urn:li:activity:7368651790508015618/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7368609648926433280 | Article |  |  | What happens when you try to build an app with AI assistance at 40,000 feet with zero internet? ✈️

I just published the results of my accidental experiment in local AI coding during a 7-hour flight. Spoiler: it actually worked, but not without some surprising challenges.

The energy consumption alone was... educational. 🔥💻

If you've ever wondered about the current state of offline AI development tools, or what it takes to run coding assistants locally, this one's for you.

Read the full experiment: https://lnkd.in/erS6DQb2 | 18 | 4 | 0 | 3mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.347Z |  | 2025-09-02T11:44:02.451Z | https://betweentheprompts.com/40000-feet/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7365672236436865024 | Article |  |  | After months of watching how my team uses AI coding tools, I’ve noticed something interesting: we don’t just “use AI” or “not use AI.” We’ve naturally settled into three distinct approaches.

🎭 Act One: Vibe Coding (Product Manager Mode)

Our UX designers prototype entire features through chat with Claude or Cursor. They iterate with stakeholders on working demos faster than static Figma designs ever allowed.

🎭 Act Two: Copilot (Team Lead Mode)

Developers use Claude Code to plan and build features, reviewing AI-generated code like managing junior developers. We delegate implementation but stay accountable for architecture decisions.

🎭 Act Three: HUD (Augmented Individual Mode)

Most coding happens with Cursor’s Tab feature – AI as autocomplete on steroids. You’re in full control, just more efficient.

The breakthrough: these modes work best when chained together. Designer creates vibe-coded prototype → Developer implements via copilot → Final polish with HUD assistance.

We’re not just learning new tools. We’re discovering new ways to organize development work itself.

Full writeup: https://lnkd.in/eub6U5Bu

How does your team use AI? | 22 | 0 | 1 | 3mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.348Z |  | 2025-08-25T09:11:48.739Z | https://betweentheprompts.com/three-act-play/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7363214027050602497 | Article |  |  | My AI coding went to the next level when I stopped just telling it what to build and started actually planning things together.

Like many developers, I started using Claude Code with a straightforward approach: describe the task, hit enter, hope for the best. For quick fixes, this worked fine. But as I tackled more complex features, this naive method revealed serious limitations.

🚨 The problem:
Conversations became sprawling sources of truth, context limits caused the AI to "forget" earlier instructions, and debugging became more chaotic than helpful.

💡 The breakthrough:
I shifted to a plan-first approach. Now I always start by asking Claude Code to create a detailed plan document before any implementation. But here's the key insight - I treat this as a living document that gets updated throughout the development process.

🎯 The results:
→ Clear source of truth for every feature
→ Ability to start fresh conversations using just the plan file
→ Better architectural thinking (explaining ideas to AI forces clarity)
→ Complete documentation of not just what was built, but why

What surprised me most? Having to articulate my reasoning clearly to the AI is making me a more thoughtful developer overall. It's like having a junior colleague who asks all the right questions about your assumptions.

The shift from "AI as implementer" to "AI as design partner" has fundamentally changed how I approach development.

Anyone else experimenting with systematic approaches to AI-assisted development? I'd love to hear what's working for your teams.

https://lnkd.in/e9qneEw9 | 29 | 6 | 1 | 3mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.350Z |  | 2025-08-18T14:23:45.950Z | https://betweentheprompts.com/design-partner/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7360713978005676034 | Article |  |  | For the first time in my career, I have absolutely no idea what the software engineer job will look like in five or ten years…

It's been three or four months since I fell into AI-assisted coding, and I’m learning new things everyday. So I decided to document my journey in a new blog 🙂

https://lnkd.in/d_uzYYiN | 53 | 12 | 3 | 3mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.351Z |  | 2025-08-11T16:49:27.809Z | https://betweentheprompts.com/two-hours/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7328063021186969601 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFYzTqe-a3TkQ/feedshare-shrink_800/B4EZbJ3qjAHkAg-/0/1747143537808?e=1766620800&v=beta&t=5SM6NY3ftpUQw_pUcB_5258a7QLaH0i29f7ckSCGckA | If you're a developer in Montreal and want to present something to a cool community, you won't find a better place! 👇 | 12 | 0 | 1 | 6mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.354Z |  | 2025-05-13T14:26:13.078Z | https://www.linkedin.com/feed/update/urn:li:activity:7328051132927254532/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7300230031564304384 | Text |  |  | We have many amazing UX challenges at Vasco, come work with us! | 3 | 0 | 0 | 9mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.355Z |  | 2025-02-25T19:07:51.240Z | https://www.linkedin.com/feed/update/urn:li:activity:7300225618422497282/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7284934111427719168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHcaC0tLrg8bA/feedshare-shrink_800/B4EZRk_1kIHAAg-/0/1736861244182?e=1766620800&v=beta&t=wyuw8WOatSK1ixPDGKL1-zqAMI5kly_JLAuoQI9N2RU | Exciting times ahead! Proud to be part of the adventure 🚀🚀🚀 | 17 | 0 | 0 | 10mo | Post | Sébastien Castiel | https://www.linkedin.com/in/scastiel | https://linkedin.com/in/scastiel | 2025-12-08T07:05:05.355Z |  | 2025-01-14T14:07:19.695Z | https://www.linkedin.com/feed/update/urn:li:activity:7284928554742472704/ |  | 

---

