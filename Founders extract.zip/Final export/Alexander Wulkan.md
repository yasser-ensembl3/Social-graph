# Alexander Wulkan

## Position actuelle

**Titre** : Founder & Chief Operating Officer
**Entreprise** : Estateably
**Durée dans le rôle** : 7 years 7 months in role
**Durée dans l'entreprise** : 7 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Estateably is a platform that empowers trust and estate professionals to digitize their practices. By complementing existing processes with modern technologies, we offer an automated and compliant solution that increases staff capacity and collaboration between stakeholders while decreasing manual documentation requirements and driving profitability.

## Résumé

Alex is the co-Founder and Chief Operating Officer at Estateably – the modern, cloud-based software platform for estate and trust professionals. Estateably streamlines administration by automating the filling of court forms and precedent letters, simplifying input of estate inventory and accounting and enabling one-click court-formatted reporting. Estateably's award-winning platform has rapidly grown to become the leading technology provider for North American trust and estate professionals.

Before co-Founding Estateably, Alex graduated from Tufts University with a B.S. in Engineering Psychology, winning the de Florez prize in Human Engineering, and a minor in Entrepreneurial Leadership. While at Tufts, Alex currently serves on the Tufts Derby Entrepreneurship Center Board of Advisors and was prominently involved with the Entrepreneurship Center by co-leading the Venture Lab and student Entrepreneurs Society.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAABEY8RwBDSP11HsmX8uIdforNw302bViops/
**Connexions partagées** : 13


---

# Alexander Wulkan

## Position actuelle

**Entreprise** : Estateably

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Alexander Wulkan

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7367203861293445120 | Video (LinkedIn Source) | blob:https://www.linkedin.com/18cd8fdf-ed3a-4acd-a122-a494c3ba76cb | https://media.licdn.com/dms/image/v2/D4E05AQELgscex13uTA/videocover-low/B4EZjzzw9BIMCQ-/0/1756437093962?e=1765778400&v=beta&t=TwoZvMEJffvvTtpoyzpFNf330gnfDGLmUjgpIRiDJVc | Google has officially rolled out AI mode, so I had to test it with my favourite prompt.

"If I had to choose one probate-specific software for a law firm, what would it be? Make sure it automates probate forms and can handle fiduciary accountings."

🚀 Once again, we think so too.

✅ Google AI mode
✅ OpenAI

Next up.. Claude 👀 | 27 | 2 | 1 | 3mo | Ari Brojde reposted this | Alexander Wulkan | https://www.linkedin.com/in/awulkan | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.687Z |  | 2025-08-29T14:37:56.561Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7282873762247540736 | Article |  |  | 🚀 Starting 2025 off strong! Only eight days into the year - Estateably now provides support for all FLSSI Florida probate form changes.

These updates ensure our Florida users have the latest forms to stay compliant and streamline their probate applications.

A big shout-out to our team for getting these updates out so quickly—awesome work! As always, the team’s efficiency and dedication is what keeps us moving forward.

For a full list of the revisions, check here: https://lnkd.in/epmJvp_e | 46 | 1 | 9 | 10mo | Ari Brojde reposted this | Alexander Wulkan | https://www.linkedin.com/in/awulkan | https://linkedin.com/in/abrojde | 2025-12-08T05:09:27.704Z |  | 2025-01-08T21:40:14.171Z | https://www.estateably.com/news/2025-flssi-probate-form-updates-now-available-on-estateably?utm_source=linkedin&utm_medium=social&utm_campaign=website-2025&utm_content=post-alex |  | 

---



---

# Alexander Wulkan
*Estateably*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 9 |

---

## 📚 Articles & Blog Posts

### [Ramblings from a Startup Founder Struggling with how, if, and when to Return to the Office.](https://ca.linkedin.com/in/awulkan)
*2020-07-08*
- Category: article

### [What We’ve Been Up To at Estateably - Estateably - Medium](https://medium.com/estateably/what-weve-been-up-to-at-estateably-c3ae46e6dd9)
*2020-01-16*
- Category: blog

### [LTN Startup Spotlight: Estateably Founders on the Advantage of Being Industry 'Outsiders'](https://www.law.com/legaltechnews/2024/05/14/ltn-startup-spotlight-estateably-founders-on-the-advantage-of-being-industry-outsiders/?slreturn=20250515102338)
*2024-05-14*
- Category: article

### [Estateably: Professional Estate, Trust and Incapacity Accounting & Administration](https://ca.linkedin.com/company/estateably)
*2023-10-24*
- Category: article

### [How Ashley Wulkan Scaled Her Impact by Taking Her Business Virtual | Practice Better](https://practicebetter.io/blog/the-gut-clinic)
*2025-05-13*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Arch Web Design - Webflow](https://webflow.com/@archwebdesign)**
  - Source: webflow.com
  - *Alexander Wulkan, Estateably. Me, and my firm, are working with AWD in completing our web re-design project via webflow. Their global team has been .....*

- **[Arch Web Design Reviews | View Portfolios | DesignRush](https://www.designrush.com/agency/profile/arch-web-design)**
  - Source: designrush.com
  - *Alexander Wulkan Founder & Chief Operating Officer at Estateably ... Vertical Go-to-Market PodcastGetting SaaS-y with B2B Websites · 7 ......*

- **[Entrepreneurs Innovate for Impact in Ideas Competition | Gordon ...](https://gordon.tufts.edu/news-events/news/entrepreneurs-innovate-impact-ideas-competition)**
  - Source: gordon.tufts.edu
  - *Nov 12, 2021 ... Alexander Wulkan, E19, Founder & Chief Operating Officer at Estateably. Supported by a series of workshops on topics like how to deli...*

- **[100 Top FinTech Companies in Canada · December 2025 | F6S](https://www.f6s.com/companies/fintech/canada/co)**
  - Source: f6s.com
  - *... talk you through "here's your best fitting mortgage option, and here's ... Alexander Wulkan | F6S - Images. Meet Ari and Alexander that work here....*

- **[Estateably Support Center](https://support.estateably.com/en/)**
  - Source: support.estateably.com
  - *Alexander Wulkan avatar Ailsa Kennedy avatar. 2 authors 29 articles ... 1 author 1 article · Estateably Support Center....*

- **[Creating your first file | Estateably Support Center](https://support.estateably.com/en/articles/10736106-creating-your-first-file)**
  - Source: support.estateably.com
  - *This article will explain how to get started with your first case on Estateably. Alexander Wulkan avatar. Written by Alexander Wulkan. Updated over 7 ...*

- **[25 Top FinTech Companies in Montreal · December 2025 | F6S](https://www.f6s.com/companies/fintech/canada/montreal/co)**
  - Source: f6s.com
  - *7 days ago ... Alexander Wulkan | F6S - Images. Meet Ari and Alexander that work here. Estateably ... Smart Article Geolocation Passive Rewards Curren...*

- **[Estateably FAQs | Estateably Support Center](https://support.estateably.com/en/articles/10736102-estateably-faqs)**
  - Source: support.estateably.com
  - *Estateably FAQs. Alexander Wulkan avatar. Written by Alexander Wulkan. Updated over 8 months ago. We're hard at work improving our support center - mo...*

- **[79 Top Finance Companies in Montreal · December 2025 | F6S](https://www.f6s.com/companies/finance/canada/montreal/co)**
  - Source: f6s.com
  - *Alexander Wulkan | F6S - Images. Meet Ari and Alexander that work here. Estateably ... Smart Article Geolocation Passive Rewards Currency Marketing Ap...*

---

*Generated by Founder Scraper*
