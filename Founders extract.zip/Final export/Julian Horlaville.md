# Julian Horlaville

## Position actuelle

**Titre** : Co Founder | 3D technical director | synthetic data generation
**Entreprise** : Silera
**Durée dans le rôle** : 7 months in role
**Durée dans l'entreprise** : 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

Building 3D workflow and procedural data generation to help accelerate AI vision model training.

## Résumé

I’ve been involved in CGI and VFX related projects since 2009 when I started as a CG generalist intern. 
In 2011, I worked as a lighting and compositing artist on tv commercials, at Prodigious CGI ( Post production division of Publicis Group). 

In 2013, I joined Digitas Lbi ( Digital Division of Publicis) as a CG generalist and later CG supervisor of the 3D department working mainly for Nissan to produce there digital visuals and animations. 

In 2015 I co founded Gear Productions a CGI studio specialized in high end Industrial Product Animations. I supervised teams of up to 5 Artists and Technicians, making all bids and handling partners and clients relation until the end of 2017 when I decided to take a step back and look at other opportunities. The company is still running and I am still advising my associate from time to time. 

In 2018 I moved to Montréal to work at Mpc on Godzilla King of the monsters, which was for me a chance to work on a project entirely different from what I have been doing for the past 8 years.

After 6 month working in Montreal, I felt it was the right place for me to settle, so I decided to return to France to make arrangements to sell my company and move to Montreal more permanently.

I am now a proud citizen of Canada, Montreal based.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAR16hUBtkEzU1No6UKyEFNSGj5-p_rSMsM/
**Connexions partagées** : 1


---

# Julian Horlaville

## Position actuelle

**Entreprise** : SPIN VFX

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Julian Horlaville

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7389007296653180928 | Celebration |  | https://media.licdn.com/media/AAYABAQSAAgAAQAAAAAAANxGq8xFRC71QSCvncOnXp8L8A.gif | I’m happy to share that I’m joining the great team at SPIN VFX as CG Supervisor! | 86 | 6 | 0 | 1mo | Post | Julian Horlaville | https://www.linkedin.com/in/julian-horlaville-vfx | https://linkedin.com/in/julian-horlaville-vfx | 2025-12-08T07:17:36.786Z |  | 2025-10-28T18:37:00.639Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7332827731077775360 | Celebration |  | https://media.licdn.com/media/AAYQAQQSAAgAAQAAAAAAABwEEXEeLoHISM2cU9LdzliLaQ.gif | I’m pleased to share that I’ve taken on the role of Co-Founder | 3D Technical Director to elevate synthetic data generation at Silera | 74 | 3 | 0 | 6mo | Post | Julian Horlaville | https://www.linkedin.com/in/julian-horlaville-vfx | https://linkedin.com/in/julian-horlaville-vfx | 2025-12-08T07:17:36.788Z |  | 2025-05-26T17:59:28.440Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7303153378774183938 | Article |  |  | When you have the right people to do the job :

I wish I knew everyone who worked on this, but unfortunately I only know this two 😅 Yan Detang Yoan Sender. 

I hope this shows how much, quality depends on the people doing the job, and not fancy hardware or software. | 8 | 2 | 0 | 9mo | Post | Julian Horlaville | https://www.linkedin.com/in/julian-horlaville-vfx | https://linkedin.com/in/julian-horlaville-vfx | 2025-12-08T07:17:40.510Z |  | 2025-03-05T20:44:11.528Z | https://www.youtube.com/watch?v=X9q_HDiQSTM&ab_channel=HopliteVFX |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7300869950401884160 | Article |  |  | If everything said in this recording is true, Technicolor board and management in France should be ashamed and should not be allowed to have any responsabilities in the future. 

Only reason that can explain not giving any notice to regional management about the lack of funds to pay salary is greed and a total lack of empathy for your employees.

I am not even surprise, their track record on mismanagement is pretty much in line with what's happening now, however this is worst because, not only employees loose their jobs, they also worked for free for an entire month.

I really hope its a cashflow issue and they will get the funds in the future, but IMO if it was the case, they would have at least communicate that to their subsidiary, and from what was told in this video, it seems it was not the case.

https://lnkd.in/eXA_AW3W | 36 | 0 | 3 | 9mo | Post | Julian Horlaville | https://www.linkedin.com/in/julian-horlaville-vfx | https://linkedin.com/in/julian-horlaville-vfx | 2025-12-08T07:17:40.511Z |  | 2025-02-27T13:30:39.780Z | https://youtu.be/Loim8HpGLnA?si=j475RJA741sKYscY |  | 

---



---

# Julian Horlaville
*SPIN VFX*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 1 |

---

## 📚 Articles & Blog Posts

### [VC | EP1 - Julius Horsthuis , Amsterdamian Fractals by The Visual Cast](https://creators.spotify.com/pod/profile/thevisualcast/episodes/VC--EP1---Julius-Horsthuis---Amsterdamian-Fractals-e2gcldt)
*2025-05-31*
- Category: podcast

### [Julius Horsthuis | LA ACM SIGGRAPH](https://lasiggraph.org/bio/presenter/horsthuis-julius)
*2024-11-21*
- Category: article

### [TheVisualCast Podcast- EP 1 with Julius Horsthuis](https://vjun.io/vdmo/thevisualcast-podcast-1-4j20)
*2024-03-23*
- Category: podcast

### [The Access:VFX Podcast](https://www.podcasts-online.org/the-accessvfx-podcast-1458754583)
*2025-04-17*
- Category: podcast

### [Computer Vision & Animation: Where Is The Trend Going?](https://medium.com/@julian.gabenstein/computer-vision-animation-where-is-the-trend-going-00e501992000)
*2025-02-11*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Borderlands (film)/Credits | JH Wiki Collection Wiki | Fandom](https://jhmovie.fandom.com/wiki/Borderlands_(film)/Credits)**
  - Source: jhmovie.fandom.com
  - *Eric Robert Schultz • Keshvi Jajoo • Julian Horlaville • Duncan Kuah • Abhay Singh • Arun George ... Additional Visual Effects by Spin VFX. Additional...*

---

*Generated by Founder Scraper*
