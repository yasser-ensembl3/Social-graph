# Ian Capstick

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Secret Agents
**Durée dans le rôle** : 5 years 11 months in role
**Durée dans l'entreprise** : 5 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Market Research

## Description du rôle

Secret Agents’ mission is to design and lead social research & development projects — unlocking progressive potential in Canada and around the world. We help organizations use technology and storytelling to discover social innovations and measure social impact.

Working with leading charities, foundations and ethical businesses, we collect and analyze social impact metrics and turn our findings into narratives and stories for innovation.

## Résumé

I am a leader and strategist with over 20 years of experience in communicating social impact and innovation across diverse sectors.

As the Chief Impact & Communications Officer at Animikii Inc., I establish strong relationships and prioritize our values, guiding our interactions with partners and our team. I lead marketing, communications, public policy development, and government relations initiatives that align with our mission to amplify Indigenous voices through technology. I also co-founded Secret Agents, a social R&D firm that helps organizations use technology and storytelling to discover social innovations and measure social impact. I have multiple certifications in innovation governance and psychologically safe leadership, and I leverage my skills and knowledge to inspire and drive change.

 I also have a diploma in Horticulture from the University of Guelph ('23) and am passionate about plants.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAI2qHYBgtjqOUDk7R7UacwpEz_taUmrddk/
**Connexions partagées** : 25


---

# Ian Capstick

## Position actuelle

**Entreprise** : Animikii Inc.

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Ian Capstick

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402000084944621569 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQF4tQ1rEcmpvg/feedshare-shrink_800/B4DZrkv2fDGgAk-/0/1764774341389?e=1766620800&v=beta&t=QXcNLIt9gyRnsj9A7LUmgiDgUuHiIoPHs1_nOssUtvE | The #DataBack Fellowship is for community-based organizations at the beginning of their data journey who want to build strong foundations, not rush to implementation. Our team at Animikii Inc. is especially looking to partner with community archives, small grassroots groups and Survivors organizations who are reclaiming materials from archives and libraries or beginning to digitize their physical records.

Applications close December 15th at the end of day. The learning program kicks off mid-January, followed by hands-on Niiwin training and regular check-ins throughout the year.

You don't need to have everything figured out. You need to be willing to learn, ask questions, and build alongside us. This fellowship puts people and communities first, and the relationships we build matter as much as the technology.

If your organization or an organization you know is protecting community stories and ready to do that work carefully, we want to hear from you! 

More + FAQs here : https://lnkd.in/d5KPqvvG

And: you can always message me for more information. 💜 | 11 | 0 | 1 | 4d | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:20.515Z |  | 2025-12-03T15:05:42.762Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7391913262277365760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFEupwIi1tXlA/feedshare-shrink_800/B4EZpVZ8MlGoAg-/0/1762369455467?e=1766620800&v=beta&t=DZHQheQLa8kiHU5qcDDfjnmVR8NX436mEdD5jacLDyY | 🚀 Our data platform Niiwin launches today - on Animikii Inc. 's 22nd birthday no less! We're excited to announcing our #DataBack Fellowship in celebration! After years of building, testing with organizations protecting survivor testimonies and cultural archives - we're finally here and ready to let folks into Niiwin. 

We're selecting our first cohort of early access users this December. The team is  seeking organizations doing the hardest work: reclaiming data and making it work for your community. Because data reclamation can't wait for the next funding cycle. Apply by Dec 8. 

And, stay tuned for more info about #DataBack Day on Feb 20th, 2026. 

Let's go! 🔥 All the info you need is here: https://lnkd.in/exmfzUJi 

#DataBack #LaunchDay #DataSovereignty #IndigenousTech | 32 | 0 | 2 | 1mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:20.516Z |  | 2025-11-05T19:04:16.834Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7389659098000302082 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEDcV29lB5_KA/feedshare-shrink_800/B4EZo1XykIIUAg-/0/1761832020859?e=1766620800&v=beta&t=EYB9qeYSNyjBJAB_TVfqy0BQwwdH1COQnT7vzNF5Q8w | Animikii was recognized at the BC Tech Technology Impact Awards as a game changer in company culture. This award hits different when you know the years and years of daily work behind it. 

Jeff Ward accepting this recognition for Animikii is a culmination of all the moments we choose to take a different path – it's for every time we embrace ceremony, it's recognition for how we work with the people who trust us and it's for every time we say "what is the loving thing do?" when capitalism says we should do it another way.

We're fundamentally reimagining what a tech company can be when Indigenous worldview leads. As we shift our focus fully into our data platform Niiwin, we're also proving that decolonizing the workplace can be scalable and revolutionary.

"Move slow and empower people" isn't a cute tagline. It's a rejection of Silicon Valley's extractive playbook.

Watching Jeff speak Anishinaabemowin from that stage, claiming space in mainstream tech is a little glimpse of the future we're building. 💜 Watch here: https://lnkd.in/e5hxcjJv | 32 | 2 | 0 | 1mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:20.516Z |  | 2025-10-30T13:47:02.190Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7382086720948805632 | Article |  |  | Awesome opportunity to work with some of the best! | 6 | 0 | 1 | 1mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:20.517Z |  | 2025-10-09T16:17:06.813Z | https://investivc.com/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7358965722061914112 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFG6m6XbruLbg/feedshare-shrink_800/B56ZiA1WFIHQAg-/0/1754508125894?e=1766620800&v=beta&t=XtKpVCzTo6My0DgHglzAaIelBsrc9sSogPzYWVhDnLE | We've done so much work to deconstruct and decolonize our work and how we do it, this award nomination is a great moment to pause and reflect on all we've accomplished at Animikii Inc. ❤️ | 9 | 0 | 0 | 4mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.105Z |  | 2025-08-06T21:02:31.111Z | https://www.linkedin.com/feed/update/urn:li:activity:7358940454618353664/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7341458108411498498 | Text |  |  | Lenacapavir was approved by the FDA yesterday. Yay? I guess. 

It's a twice yearly injection to prevent HIV infection, a regimen called pre-exposure prophylaxis, or PrEP, will be sold at a list price of $28,218 in the USA. 🫠

The company says "scientists have made it their life’s work to end HIV." Sure, but the rest of the company is built to extract profit.

Lenacapavir is coming to Canada, it may take until 2026 to receive approval and when it does it is unlikely to be provincially covered.

Meanwhile, HIV rates climb.

2,434 new HIV diagnoses in 2023.

35.2% increase since 2022. 

Every single one of them was preventable. 

Access to PrEP should be simple, easy to access via pharmacies and 100% free of deductibles, fees and on an as needed basis. 

The folks at Community-Based Research Centre (CBRC) and CATIE are doing great work on this. | 20 | 4 | 1 | 5mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.106Z |  | 2025-06-19T13:33:30.741Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7335391999392407553 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFbyzKblTtqEw/feedshare-shrink_800/B4EZcyJJuVHYAg-/0/1748892949887?e=1766620800&v=beta&t=ibre9N3vQsEGrYGWAWKMjmpddgf2tXzH9ci6eMJlfOo | As big brands back away from Pride, Animikii Inc. embraces celebrating 2Spirit and LGBTQ folks. Happy pride month, y'all! ❤️ | 29 | 1 | 1 | 6mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.107Z |  | 2025-06-02T19:48:57.648Z | https://www.linkedin.com/feed/update/urn:li:activity:7335388698148003840/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7333104003033014272 | Article |  |  | This was a fun professional first - a media appearance where I'm not quoted about politics or technology -  thanks to Anastasia Dextrene S. Johnson for featuring my work on low and no-mow lawns. 

Over on Bluesky I've been answering horticulture questions for a few years and have helped hundreds of folks with plant problems and garden planning, two of the most frequent requests was how to make lawns better for pollinators and how to keep the lawn green. I adapted several natural landscape management techniques to help solve both issues. 

Video and article here: https://lnkd.in/eCYbeRpq 

More on the St. Lawrence Lowlands lawn mix / alternative lawn here: https://lnkd.in/eKrHBSY2 | 24 | 1 | 1 | 6mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.107Z |  | 2025-05-27T12:17:16.807Z | https://www.ctvnews.ca/montreal/article/lawn-care-tips-for-every-gardener-from-lush-green-grass-to-no-mow-ecosystems/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7324037040218456066 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFlqAEZEmI-Cg/feedshare-shrink_800/B56ZaH_pr_HUAg-/0/1746038332652?e=1766620800&v=beta&t=kFTPEiVE1IisdQqfFBFB2q334-oPvprdEn2Cku0jD3g | Ahead of the election there was a lot of talk about the need for a dedicated Minister for Women and Gender Equity, now is the perfect time to email or call the Prime Ministers office and request this important inclusion in cabinet. | 13 | 0 | 0 | 7mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.108Z |  | 2025-05-02T11:48:24.416Z | https://www.linkedin.com/feed/update/urn:li:activity:7323415568844259328/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7318400265261309953 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHOZlgWBUOeeQ/feedshare-shrink_800/B4EZZAl0COGYAg-/0/1744840377103?e=1766620800&v=beta&t=OcTXEcj4zSCoW1rT8l2qzg_styAIXz5afLt_4IHp25M | Sometimes we like to have fun with a meme... and make a point about AI ethics 💜 thanks Tom Spetter for your awesome work! | 7 | 0 | 0 | 7mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.108Z |  | 2025-04-16T22:29:52.540Z | https://www.linkedin.com/feed/update/urn:li:activity:7318390978061471745/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7312922751512571904 | Article |  |  | Jeff Ward was recently in Winnipeg as the keynote speaker at North Forge IP Summit. If you're looking for an action items to advance Indigenous IP nationally and in your own business... this speech is great place to start. | 3 | 0 | 0 | 8mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.110Z |  | 2025-04-01T19:44:11.495Z | https://animikii.com/insights/indigenous-perspectives-on-ip |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7311154898459394048 | Article |  |  | We're taking steps to stand against the extractive surveillance economy commodifing your attention and data. Our Animikii Inc. newsletter now runs on Buttondown. A more values-aligned tool that better respects digital consent and autonomy of the users. They set all tracking to "off" and don't aggregate or sell the information. 

News River now track only clicks (to send more news like the articles that you enjoy) and replies. That's it. 

It's a small way we can start to dismantle the tracking systems Big Tech has normalized.

We can rebuild our tech stacks so our money helps center humanity, not exploitation.

Ps. Google Analytics is next on the chopping block. I'll let you know how that transition goes in a few weeks. 💜 | 10 | 1 | 0 | 8mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.111Z |  | 2025-03-27T22:39:22.482Z | https://buttondown.com/newsriver/archive/indigenous-tech-news-grounded-in-joy-and/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7308533005612969984 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFzbKy_klQScA/feedshare-shrink_800/B56ZW0T3psHsAk-/0/1742486862946?e=1766620800&v=beta&t=Jb7mUu-WwfLx_P-T65_etBGA2Iff07Z-Jc0iSaILG_Q | As big tech backs away from diversity, equity and inclusion, Animikii Inc. is going to double down. 💜 | 40 | 3 | 1 | 8mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.112Z |  | 2025-03-20T17:00:54.515Z | https://www.linkedin.com/feed/update/urn:li:activity:7308519625888043008/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7305348243222122496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFa-ENlK0_o0Q/feedshare-shrink_800/B4EZWGaBnJH0Ak-/0/1741716724879?e=1766620800&v=beta&t=iwZOVQyR8CJU3hJrGSYqJW0q09G53Gsfp4tWyI9EFg0 | In this week of heated trade war rhetoric, the Animikii Inc. team is in the USA and is working to strengthen ties with Indigenous organizations, governments and businesses at #RES2025. Watching our team introduce our data platform Niiwin to attendees and kick off important Indigenous-to-Indigenous business relationships in spite of the colonial border fills me with hope. | 9 | 0 | 0 | 8mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.112Z |  | 2025-03-11T22:05:47.991Z | https://www.linkedin.com/feed/update/urn:li:activity:7305289428711723008/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7295434245605388288 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGUpmKK7W7H_A/feedshare-shrink_1280/B4EZT6WyRbG0As-/0/1739367065169?e=1766620800&v=beta&t=9zhXHsFVAqYI3xs_wB7rDK9ao-ydekJs44M7tul-6gE | Looking to pass the torch after a rewarding 6-year tenure on Greenpeace Canada's Board, I am particularly excited to see qualified candidates from Quebec step forward to help shape the organization's future direction and impact. As Greenpeace Canada values bilingualism and diverse regional representation, we are especially interested in Quebec-based candidates who can bring their unique perspective and French language skills to the Board, along with expertise in areas such as Indigenous rights, fundraising, or strategic leadership, for this volunteer position starting June 2025.

🌿 Link for more info and to apply: https://lnkd.in/egivdtmC 

Après 6 années enrichissantes au sein du conseil d'administration de Greenpeace Canada, je suis particulièrement enthousiaste de voir qui me remplacera et de voir des candidat(e)s qualifié(e)s du Québec se manifester pour façonner l'avenir et l'impact de l'organisation. Comme Greenpeace Canada valorise le bilinguisme et la représentation régionale diversifiée, nous recherchons particulièrement des candidat(e)s basé(e)s au Québec qui peuvent apporter leur perspective unique et leurs compétences en français au conseil d'administration, ainsi que leur expertise dans des domaines tels que les droits autochtones, la collecte de fonds ou le leadership stratégique, pour ce poste bénévole débutant en juin 2025.

🌿 Lien pour plus d'informations et pour postuler: 
https://lnkd.in/egivdtmC | 30 | 2 | 1 | 9mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.114Z |  | 2025-02-12T13:31:06.766Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7295075513457344513 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHauQKxHKiyvA/feedshare-shrink_800/B4EZT09kp9HUAk-/0/1739276569730?e=1766620800&v=beta&t=Yw3veVDkvrIMFbPmnJrlxWasXey1b3rZeSt7vXPdrDI | With the AI Summit in Paris making a tonne of news, I'm very thankful a diversity of perspectives are being considered.

The US stance and subsequent refusal to sign the declaration is not surprising, but it is troubling. The UK is also signaling it will be regulating AI differently than the EU with this snub. 

https://lnkd.in/eMm5cEYu | 4 | 0 | 0 | 9mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.114Z |  | 2025-02-11T13:45:38.357Z | https://www.linkedin.com/feed/update/urn:li:activity:7295054676767440896/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7293671250298634241 | Text |  |  | This is a great job for someone in my network. 

Know anyone who might be interested? | 11 | 0 | 1 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.116Z |  | 2025-02-07T16:45:35.930Z |  | https://www.linkedin.com/jobs/view/4145919416/ | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7293238232622747648 | Article |  |  | Just one of the very real risks for GenAI: 

"The web login page of DeepSeek’s chatbot contains heavily obfuscated computer script that when deciphered shows connections to computer infrastructure owned by China Mobile, a state-owned telecommunications company. The code appears to be part of the account creation and user login process for DeepSeek." 

https://lnkd.in/ewyYymf6 | 1 | 0 | 0 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.116Z |  | 2025-02-06T12:04:56.471Z | https://www.bnnbloomberg.ca/business/international/2025/02/05/researchers-say-chinas-deepseek-chatbot-is-linked-to-state-telecom-raising-data-privacy-concerns/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7292895356839735296 | Article |  |  | Amidst all the GenAI hype, it makes me very sad when folks dedicated to the environment and social justice jump all in on GenAI technology. To me, it has become clear the technology is being used to enforce the very systems they are seeking to dismantle. Case in point: I saw more than one enthusiastic post about how DeepSeek was a paradigm shift in how we think of energy and AI... all without clearly stating the model could not have been created without the precedent models. (ie: they used GPT and Llama to build it) 

The ability to quantize models and run them locally is nothing new in the AI world, and it does nothing to negate the very real problems GenAI is exacerbating in society. Can you ethically use a model that has been told to ignore human rights abuses? I don't think so. 

Video on how DeepSeek handles human rights: https://lnkd.in/eQWnPpCC | 9 | 0 | 2 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.117Z |  | 2025-02-05T13:22:28.514Z | https://www.youtube.com/watch?v=o6YhG-87wfc |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7292652622493155328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0UZ0-2eLaEQ/feedshare-shrink_800/B4EZTS06gFHUAg-/0/1738703874561?e=1766620800&v=beta&t=d5czlYaQp2LPthHTL9EoghnA2uaZmoCBezEr7s1I6LI | This year the Animikii Inc. social impact report is also a call to action we wish we did not have to make: the Survivors' Secretariat and Residential School Survivors groups everywhere - need your urgent love and support today. 

The promised funding from Canada isn't flowing and it's most certainly not enough to uncover, document and share the truths associated with one of the darkest chapters in our collective history. 

Read more in our 2024 social impact report: https://2024.animikii.com/

And: Please, take a moment to call or write your MP. ❤️ | 9 | 1 | 2 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.117Z |  | 2025-02-04T21:17:56.136Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7290365080779513856 | Article |  |  | The Google Workspace AI you didn't ask for, but are now paying for: 

"But it looks like it’s all or nothing. You can’t turn off just the new Gemini stuff without also disabling things like Gmail nudging you about an email you received a few days ago, or automatic filtering when Gmail puts emails into primary, social, and promotion tabs, which are features that Gmail has had for years and which many users are probably used to."

https://lnkd.in/eXWBgGTR | 9 | 0 | 1 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.118Z |  | 2025-01-29T13:48:03.691Z | https://www.404media.co/opting-out-of-gmails-gemini-ai-summaries-is-a-mess-heres-how-to-do-it-we-think/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7285385305983975425 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGvTYs0A_KiHg/feedshare-shrink_800/B4EZRrjVCSG0Ag-/0/1736971211348?e=1766620800&v=beta&t=lpTmMq-CZ1jG-NrpCstHWkNRe0Ibxl27eQvtjS0aknI | Animikii Inc. has just awarded $1000 each to eight remarkable Indigenous youth. 🎉  Special thanks to our partners at TakingITGlobal for helping us maximize our impact this year. 

Want to meet these inspiring young folks? Check out their stories here: https://lnkd.in/ePiusb5m 

#IndigenousInnovation #STEAM #SocialImpact #TechForGood #IndigenousLeadership | 30 | 0 | 0 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.119Z |  | 2025-01-15T20:00:12.860Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7282787474890715136 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFrPM5_h9lQSg/feedshare-shrink_800/B4EZRGonceGYAk-/0/1736351840510?e=1766620800&v=beta&t=f_tJyfHyAD9kI44l3n9xhlfIJsCDf34a8P7M4lGUWJo | Wrestling with the personal and professional ramifications of the Meta move to ditch fact-checking? I sure am. Is it time to move beyond Instagram and Facebook? 

That's going to be tough without building another audience in alternate spaces first. 

I strongly believe the next wave of social platforms should not be built by billionaires - it should built by communities. 

Here are some of the leading options and alternatives: 

→ Cara (https://cara.app)
 • 600k+ joined when admitted to using Instagram using images to train AI
 • No AI, no ads
 • Clean feed for Instagram style content 

→ Pixelfed (https://pixelfed.org)
 • Decentralized, still young, like Instagram 
 • Your data stays yours
 • No algorithm tricks

→ Classic options
 • Tumblr
 • Flickr

→ Business networks
 • Polywork (polywork.com)
 • Lunchclub (lunchclub.com)

→ Work spaces
 • Slack (slack.com/community)
 • Discord (discord.com)
 • Circle (circle.so)

→ DIY social
 • Geneva (geneva.com)
 • Mighty Networks (mightynetworks.com)
 • Ghost (ghost.org)

More context: Meta (Facebook/Instagram) is ending fact-checking, shifting leadership ahead of the Trump admin. See: https://lnkd.in/eWApWTW2

Are you migrating? If so, where to? Share below 👇
#SocialMedia #DigitalStrategy #FutureOfTech | 45 | 8 | 3 | 10mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.120Z |  | 2025-01-08T15:57:21.662Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7279115641238745088 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGuLVdybz-M6A/feedshare-shrink_800/B56ZPpu5p3GsAg-/0/1734793207292?e=1766620800&v=beta&t=FZMTjW7xDmJ5llKM6CAqmQwRuioY1lLVSw5b-7YnYss | Scary part: this may be an underestimate. | 7 | 1 | 2 | 11mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.121Z |  | 2024-12-29T12:46:48.300Z | https://www.linkedin.com/feed/update/urn:li:activity:7276250095019335680/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7274851350583119873 | Article |  |  | Very proud moment! 🚀 Raven Indigenous Capital Partners and Animikii Inc. have made the decision to convert their promissory notes into equity to support the continued growth of our core product Niiwin! 

Incredible to see my colleagues at Animikii Indigenous Technology and Raven Indigenous Capital Partners taking meaningful steps to change the typical transactions of impact investment through Indigenous ways of knowing and being.

What makes this remarkable? It's a whole new way of approaching an equity conversion, and turning it into a powerful ceremony centering relationships and reciprocity. The process brings Indigenous values directly into business transactions, creating a whole new kind of agreement. Including:

🗣️ Translation of legal documents into Anishinaabemowin
🪶 Cultural statements grounded in Seven Grandfather Teachings
⭐ A witnessing ceremony at the Poeh Cultural Center and Museum
🖼️ A commissioned art piece by Anishinaabe artist Bruce Barry

It's also creating all new data. As Jeff Ward says, "We have data in oral histories. We have data in regalia. Data is in the land. We've got all kinds of data. So this art piece in and of itself is data. It is a story. This is data sovereignty in action."

Read all about the details in this article: https://lnkd.in/eKefqx2n | 41 | 1 | 0 | 11mo | Post | Ian Capstick | https://www.linkedin.com/in/iancapstick | https://linkedin.com/in/iancapstick | 2025-12-08T05:01:25.122Z |  | 2024-12-17T18:22:02.181Z | https://animikii.com/insights/centering-culture-in-venture-capital-deals |  | 

---



---

# Ian Capstick
*Animikii Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [IMPACT REPORT](https://cdn.prod.website-files.com/667d9ff6e94bee3188f26f2c/66c502281af1a9d9d9ff8e28_RICP%202023%20Impact%20Report_spread.pdf)
*2024-06-01*
- Category: article

### [RAVEN CAPITAL IMPACT REPORT](https://cdn.prod.website-files.com/667d9ff6e94bee3188f26f2c/66c5004f4be41ae30e33a8bc_RICP%202022%20Impact%20Report_spread.pdf)
- Category: article

### [News & Insights
    — Animikii Indigenous Technology](https://animikii.com/insights)
*2025-05-01*
- Category: article

### [Archive
    — Animikii Indigenous Technology](https://animikii.com/insights/archive)
*2023-01-01*
- Category: article

### [Animikii Raises $1M to Scale Social Impact Through Indigenous Technology](https://nationtalk.ca/story/animikii-raises-1m-to-scale-social-impact-through-indigenous-technology-2)
*2025-05-12*
- Category: article

---

## 📖 Full Content (Scraped)

*5 articles scraped, 41,127 words total*

### IMPACT REPORT
*23,889 words* | Source: **EXA** | [Link](https://cdn.prod.website-files.com/667d9ff6e94bee3188f26f2c/66c502281af1a9d9d9ff8e28_RICP%202023%20Impact%20Report_spread.pdf)

I M PA C T R E P O R T 

# RAVEN INDIGENOUS 

# CAPITAL PARTNERS 

# F O R Y E A R E N D I N G 2 0 2 3 

Photograph by Charles Montoya (instagram: @indigenouslens) Contents 

Welcome  05 

Impact Overview  13 

Portfolio Impact  20 

“Creating the conditions for Indigenous women 

in business to thrive is the single most natural, 

swift, and effective pathway to economic 

reconciliation in our country. 

It's very simple to me. 

It's just like in nature. Trees need sunshine, 

water, and fertile soil with nutrients. Just like in 

nature, what gets the nutrients thrives.” 

— Teara Fraser, CEO of Iskwew Air     

> 2023 ANNUAL REPORT /32\2023 ANNUAL REPORT

# S P I R I T O F 

# T H E R I M * 

"The driving force behind our impact 

measurement learning journey is the need for 

us to ensure that everything we do at Raven 

ultimately contributes to the improved well-

being of Native / Indigenous Peoples  We 

are always seeking to better understand and 

measure the impact that Raven Indigenous 

Capital Partners is having with our invested 

businesses, within communities, with our 

investors, and at an eco-system level  "

The image used on this page is of a 

traditionally designed and constructed Native/ 

Indigenous bentwood box whichcontains the 

Raven Impact Measurement Framework(RIM) 

document and RICP’s annual impact reports 

Thisbentwood box reflects the depth of our 

commitment toour mission of improving the 

well-being of Native/Indigenous Peoples 

and is a practical example of ourefforts 

to decolonize our work  The Thunderbird 

andKiller Whale carved on the outside of the 

box representwisdom and protection and 

they serve as principledguardians of our 

sacred commitments to our People andto our 

investors 

-Paul Lacerte, Chief Impact Officer 

*Raven Impact Measurement Framework 

This report was published June 2024 on the traditional territory of the 

Lekwungen speaking Peoples, the Songhees and the Esquimalt First Nations 

Author:  Jonas Hunter, Director of Impact 

Support and Guidance:  Paul Lacerte, Chief Impact Officer 

Design:  Katie Wilhelm, katiewilhelm  design 

The cover image is a photograph of the Sandia Mountains near 

Albuquerque, taken by Charles Montoya, a talented Pueblo artist from 

Santa Ana and Jemez Pueblo in New Mexico, and friend of Nicole 

Johnny, Impact Associate in Albuquerque, New Mexico 

You can reach Charles on Instagram @indigenouslens 

or by charlitoz91@gmail  com     

> 2023 ANNUAL REPORT /54\2023 ANNUAL REPORT

# A Letter From Raven Indigenous Capital Partners 

On behalf of the team at Raven Indigenous Capital Partners, we are proud to present our 2023 Impact 

Report  It is an honour to work in service of our mission – to improve the wellbeing of Indigenous Peoples 

in Canada and Native Americans, Alaska Natives, and Native Hawaiians in the United States 

Our approach at Raven is anchored in our foundational values which are contained in Raven’s Impact 

Measurement Framework (RIM)  They ensure that our work: is rooted in Native / Indigenous Knowledges, 

is guided by culture, builds respectful relationships, increases cultural safety, sees money as medicine, 

treats all of creation as our relatives, and is accountable to the next 7 generations  These values are also 

instrumental in guiding our on-going journey of decolonizing the investment process, increasing our impact, 

and generating risk-adjusted returns for our investors 

Our work is focused at this intersection of capital and culture and we are honoured to share stories, metrics, 

and insights throughout this report that demonstrate how our portfolio companies are navigating this 

complexity and paving the way to a new and more equitable economic future 

Looking back on the year that has passed, it is important to reflect on the challenging environment we have 

all faced with high interest rates, stubborn inflation, decelerating economic growth, a significant correction 

in valuations , and mounting geopolitical tensions 

Notwithstanding these challenges, Raven’s portfolio companies have demonstrated their resilience and 

capacity to pivot and adapt to changing market conditions  Our hands are raised in respect and gratitude 

to all who have worked incredibly hard this year to increase the positive impact they are having on the lives 

of Native/Indigenous Peoples across Turtle Island while building commercial success 

During 2023, Raven continued to expand and strengthen its team, developing new capabilities to support 

our portfolio companies and increase our contribution to the broader impact investing ecosystem  We are 

very pleased to announce the addition of Althea Wishloff and Sean McCormick as General Partners, and 

Fiorella Schiffino as our new Chief Financial Officer  These additions will enable expanded service offerings 

and strengthen our internal processes and systems 

To our investors – thank you  Your investment in Raven Capital is not

*[... truncated, 155,576 more characters]*

---

### RAVEN CAPITAL IMPACT REPORT
*14,330 words* | Source: **EXA** | [Link](https://cdn.prod.website-files.com/667d9ff6e94bee3188f26f2c/66c5004f4be41ae30e33a8bc_RICP%202022%20Impact%20Report_spread.pdf)

# R AV E N C A P I TA L I M PA C T R E P O R T 

# F O R Y E A R E N D I N G 2 0 2 2 

# RAVEN INDIGENOUS CAPITAL PARTNERS 2022 ANNUAL REPORT / 3 2 / 2022 ANNUAL REPORT 

This report was published June 2023 on the traditional territory of the Lekwungen speaking Peoples, 

the Songhees and the Esquimalt First Nations 

- Authors Paul Lacerte, Managing Partner; Jonas Hunter, Director of Impact / Design by Eclipse360 S P I R I T O F T H E R I M* 

“The driving force behind our impact measurement learning journey is the need for us to ensure that everything we do at Raven ultimately contributes to an improved well-being of life for Indigenous Peoples. We are always seeking to better understand and measure the impact that Raven Indigenous Capital Partners is having with our invested businesses, within communities, with our investors, and at an eco-system level.” “We take this engagement with you to be a ceremony and we are committed to doing this work in a good way. In that spirit, the information that has been shared with us is a form of medicine and we are treating it with respect.” 

*Raven Impact Measurement Framework  

> 2022 ANNUAL REPORT

/ 3 

"Two things we could learn from Native American ancestral wisdom are balance and integration. If you look at the tribes’ ancestral practices, and still today, there is a balance between work, nature, family, pleasure. The rest of us have lost a sense of knowing when to work, when to play, when to relax. I teach at Stanford and I see this lack of balance manifesting earlier and earlier in our children, and then it just grows into the business world. I believe that we have to live by loving one another. It's not a love of romance, it is loving our fellow human beings and elevating one another. We're in a crisis right now with people and planet and without that love for one another, it's going to get worse, not better." 

Valerie Red-Horse Mohl, National Native American business leader, accomplished film maker, 

and President of Known Holdings, [Keynote speaker at Raven Capital CEO Retreat 2023] 2022 ANNUAL REPORT / 5 4 / 2022 ANNUAL REPORT HEADLINE METRICS ACROSS PORTFOLIO COMPANIES GREATER THAN 51% INDIGENOUS OWNERSHIP (7 OF 10) 70% 20% 

181 INDIGENOUS CONTRACTORS (OF 886) 25 INVESTMENTS (IN 11 COMPANIES) 

127 INDIGENOUS EMPLOYEES (OF 397) 32% WOMEN IN MANAGEMENT (7 OF 39) 18% INDIGENOUS BOARD REPRESENTATION 60% INDIGENOUS OWNERSHIP 71% 40% 30% GROSS IRR (AS OF DEC 31, 2022) 50% WOMEN FOUNDERS (5 OF 10) WOMEN EMPLOYEES (158 OF 397) A LETTER FROM RAVEN INDIGENOUS CAPITAL PARTNERS 

On behalf of the team at Raven Indigenous Capital Partners, we are proud to present our 2022 Impact Report. Our hands are raised in deep gratitude to our portfolio companies who have worked incredibly hard to build commercial success in 2022 while increasing the positive impact they are having on the lives of Indigenous Peoples. We are also humbled by the trust and support of our investors for believing in our team and investing in our mission. This is economic reconciliation in action. In this report, we are excited to share the impact stories and placemats for each company in a way that centers the voices of Indigenous Peoples. We are also honored to share an update on the evolution of 

our firm and to elaborate on our impact management practices. Our team has grown significantly this year in both Canada and the United States. We are pleased to announce the addition of Althea Wishloff as our first Indigenous woman Partner, Nicole Johnny and 

Devon Krainer as Investment Associates, Edith Baker as an Investment Readiness Associate, Josh Alook as an Investment Analyst, and Kaitlin Littlechild as Strategic Communications Manager. This year also included the establishment of internal working groups in the areas of culture, climate, DEI, and health and wellness to ensure that our organizational culture continues to be co-created and that it remains healthy and accountable as we continue to learn and grow. We are proud of our market-leading impact management practice which supports our investment team and our Founders to create value and drive positive outcomes at scale. This year our Impact team completed the Impact Frontiers training program and furthered our alignment with industry principles and standards of practice including the Principles of Responsible Investment (PRI); the OCAP 

standards of Ownership, Control, Access, and Possession; the UN SDGs, and the UN Declaration on 

the Rights of Indigenous Peoples. Our commitment to aligning our impact measurement work to both Indigenous and non-Indigenous standards will enable our team to continue on our pathway of decolonizing the investment process while at the same time producing best-in-class results. Finally, we are pleased to announce that we recently published the next-gen version of the Raven Impact Measurement Framework (RIM) which is being shared as an open-source document. Our 

intention is to share ‘good medicine’ with th

*[... truncated, 87,790 more characters]*

---

### News & Insights
    — Animikii Indigenous Technology
*1,137 words* | Source: **EXA** | [Link](https://animikii.com/insights)

News & Insights — Animikii Indigenous Technology

===============
[Skip to main content](https://animikii.com/insights#content)

[![Image 1: Animikii Indigenous Technology 2024](https://animikii.com/images/logo-animikii-white.svg)](https://animikii.com/)

*   [Home](https://animikii.com/)
*   [Solutions](https://animikii.com/solutions)
    *   [Niiwin Pathfinding](https://animikii.com/solutions)
    *   [Case Studies](https://animikii.com/solutions/case-studies)

*   [Impact](https://animikii.com/impact)
    *   [Impact Reports](https://animikii.com/impact)
    *   [Workshops](https://animikii.com/impact/workshops)
    *   [Scholarships](https://animikii.com/impact/scholarship)
    *   [Open-Source Policies](https://animikii.com/impact/open-source-policies)

*   [#DataBack](https://animikii.com/databack)
    *   [Asserting and Supporting Indigenous Data Sovereignty](https://animikii.com/databack)
    *   [Understanding and Resisting Generative AI](https://animikii.com/databack/understanding-and-resisting-generative-ai)

*   [News & Insights](https://animikii.com/insights)
*   [About](https://animikii.com/about)
*   [Contact](https://animikii.com/contact)

News & Insights
===============

Discover the Animikii Perspective
---------------------------------

Explore the complex world of Indigenous technology, innovation, and data sovereignty through Animikii's Insights. With a unique lens on issues crucial to Indigenous Nations, communities, and organizations, our Insights serve as an indispensable guide. Dive into articles, reports, and thought-provoking commentary.

[![Image 2](https://animikii2024.imgix.net/files/blog-post-funding-resources-1.png?w=830&auto=format)Funding Pathways for Indigenous Data Sovereignty Infrastructure Indigenous peoples are reclaiming authority over information that defines them. Read More](https://animikii.com/insights/funding-pathways-for-indigenous-data-sovereignty-infrastructure)

[![Image 3](https://animikii2024.imgix.net/files/niiwin-09-2025-launch-graphic-thumb.jpg?w=830&auto=format)Niiwin Launches: Indigenous Data Platform Opens Doors for Values Driven Organizations Animikii's data sovereignty platform Niiwin is opening to our first users through the #DataBack Fellowship! Animikii has spent twenty years advancing Indigenous Data Sovereignty. The company developed technology that lets Indigenous communities control their information through frameworks like OCAP® (Ownership, Control, Access, Possession) and CARE (Collective Benefit, Authority to Control,... Read More](https://animikii.com/insights/niiwin-launches-join-data-sovereignty-movement)

[![Image 4](https://animikii2024.imgix.net/files/maori-marae-thb.jpg?w=830&auto=format)When Indigenous LMS Technology Supports Indigenous Futures​​"The jarjums have been so engaged in the Deadly Coders program - I had to actually peel them away from their computers at the end of the day," said a teacher from Hymba Yumba International School, a First Nations school of excellence on Jagera, Yuggera, and Ugarapul land in Queensland.... Read More](https://animikii.com/insights/when-indigenous-lms-technology-supports-indigenous-futures)

[![Image 5](https://animikii2024.imgix.net/files/idwip2025-banner_0.jpg?w=830&auto=format)Indigenous Peoples and AI: Defending Rights, Shaping Futures We’re highlighting key ideas and sharing a partial excerpt from two panelists who spoke about the ethical approaches they’ve taken in adopting (or not adopting) AI tools in their work with Indigenous Peoples. Read More](https://animikii.com/insights/indigenous-peoples-and-ai-defending-rights-shaping-futures)

[![Image 6](https://animikii2024.imgix.net/files/akii-05-2025-language-post-thumb-1.jpg?w=830&auto=format)Reawaken Language, Revitalize Community Co-founders of Salish School of Spokane’s Indigenous Language Fluency Transfer System share how successful language revitalization creates community connection. Read More](https://animikii.com/insights/reawaken-language-revitalize-community)

[![Image 7](https://animikii2024.imgix.net/files/akii-04-2025-aptn-insights-thumbnail-1.jpg?w=830&auto=format)Indigenous Data Sovereignty: Jeff Ward Discusses #DataBack and Niiwin Platform on APTN News InFocus Jeff Ward recently spoke with Cierra Bettens for APTN News InFocus about Indigenous data sovereignty and #databack in the age of big tech. Read More](https://animikii.com/insights/indigenous-data-sovereignty-jeff-ward-discusses-databack-and-niiwin-platform-on-aptn-news-infocus)

[![Image 8](https://animikii2024.imgix.net/files/akii-03-2025-hidden-costs-of-ai-thb.jpg?w=830&auto=format)Hidden Costs of AI on Indigenous Peoples At an OECD event in Paris, Jeff Ward, Animikii CEO shares his perspectives on the impacts of AI on Indigenous Peoples in both Canadian and global contexts. Read More](https://animikii.com/insights/hidden-costs-of-ai-on-indigenous-peoples)

[![Image 9](https://animikii2024.imgix.net/files/manitoba-thumb.jpg?w=830&auto=format)Exploring Indigenous P

*[... truncated, 7,739 more characters]*

---

### Archive
    — Animikii Indigenous Technology
*1,197 words* | Source: **EXA** | [Link](https://animikii.com/insights/archive)

Archive — Animikii Indigenous Technology

===============
[Skip to main content](https://animikii.com/insights/archive#content)

[![Image 2: Animikii Indigenous Technology 2024](https://animikii.com/images/logo-animikii-white.svg)](https://animikii.com/)

*   [Home](https://animikii.com/)
*   [Solutions](https://animikii.com/solutions)
    *   [Niiwin Pathfinding](https://animikii.com/solutions)
    *   [Case Studies](https://animikii.com/solutions/case-studies)

*   [Impact](https://animikii.com/impact)
    *   [Impact Reports](https://animikii.com/impact)
    *   [Workshops](https://animikii.com/impact/workshops)
    *   [Scholarships](https://animikii.com/impact/scholarship)
    *   [Open-Source Policies](https://animikii.com/impact/open-source-policies)

*   [#DataBack](https://animikii.com/databack)
    *   [Asserting and Supporting Indigenous Data Sovereignty](https://animikii.com/databack)
    *   [Understanding and Resisting Generative AI](https://animikii.com/databack/understanding-and-resisting-generative-ai)

*   [News & Insights](https://animikii.com/insights)
*   [About](https://animikii.com/about)
*   [Contact](https://animikii.com/contact)

Archive
=======

Insights Archive
----------------

Explore all the articles written by us - all in one place - to deepen your grasp of Indigenous technology, data sovereignty, and more. Each piece reflects the unique Animikii perspective, blending traditional wisdom with cutting-edge insights. Here you'll find resources to challenge the norm and empower Indigenous Nations, communities, and organizations.

[**Funding Pathways for Indigenous Data Sovereignty Infrastructure**](https://animikii.com/insights/funding-pathways-for-indigenous-data-sovereignty-infrastructure)

[**When Indigenous LMS Technology Supports Indigenous Futures**](https://animikii.com/insights/when-indigenous-lms-technology-supports-indigenous-futures)

[**Indigenous Peoples and AI: Defending Rights, Shaping Futures**](https://animikii.com/insights/indigenous-peoples-and-ai-defending-rights-shaping-futures)

[**Reawaken Language, Revitalize Community**](https://animikii.com/insights/reawaken-language-revitalize-community)

[**Indigenous Data Sovereignty: Jeff Ward Discusses #DataBack and Niiwin Platform on APTN News InFocus**](https://animikii.com/insights/indigenous-data-sovereignty-jeff-ward-discusses-databack-and-niiwin-platform-on-aptn-news-infocus)

[**Hidden Costs of AI on Indigenous Peoples**](https://animikii.com/insights/hidden-costs-of-ai-on-indigenous-peoples)

[**Exploring Indigenous Perspectives on Intellectual Property**](https://animikii.com/insights/exploring-indigenous-perspectives-on-intellectual-property)

[**AI Action Now Summit Illustrated the Need for Focus on Indigenous Rights**](https://animikii.com/insights/ai-action-now-summit-illustrated-the-need-for-focus-on-indigenous-rights)

[**GenerativeAI, Mass-Scale Digital Art Heist & Indigenous Dispossession**](https://animikii.com/insights/generativeai-mass-scale-digital-art-heist-indigenous-dispossession)

[**Animikii Scholarships & Grants Awarded to 8 Indigenous Youth Thriving in STEAM**](https://animikii.com/insights/animikii-scholarships-grants-awarded-to-8-indigenous-youth-thriving-in-steam)

[**Animikii 2024 Retreat**](https://animikii.com/insights/animikii-2024-retreat)

[**Centering Culture in Venture Capital Deals**](https://animikii.com/insights/centering-culture-in-venture-capital-deals)

[**From Plains Cree to Yagara - AI generated books on Amazon exploit Indigenous languages from Canada to Australia**](https://animikii.com/insights/from-plains-cree-to-yagara-ai-generated-books-on-amazon-exploit-indigenous-languages-from-canada-to-australia)

[**Animikii's Expanded Technology & Business Grants**](https://animikii.com/insights/animikii-s-expanded-technology-business-grants)

[**Typefaces Empower Indigenous Language Revitalization**](https://animikii.com/insights/typefaces-empower-indigenous-language-revitalization)

[**Strengthening Indigenous & Intersectional Relationships in the Workplace**](https://animikii.com/insights/strengthening-indigenous-intersectional-relationships-in-the-workplace)

[**2023 Scholarship Recipients**](https://animikii.com/insights/2023-scholarship-recipients)

[**Embrace Innovation and Transparency with Animikii's Pathfinding Webinar**](https://animikii.com/insights/embrace-innovation-and-transparency-with-animikii-s-pathfinding-webinar)

[**Celebrating Generation One: Animikii Marks 20 Years in the Spirit of Seven Generations**](https://animikii.com/insights/celebrating-generation-one-animikii-marks-20-years-in-the-spirit-of-seven-generations)

[**Cultivating Strong Indigenous & Intersectional Workplace Connections**](https://animikii.com/insights/cultivating-strong-indigenous-intersectional-workplace-connections)

[**Animikii Celebrates Recertification as a B Corp**](https://animikii.com/insights/animikii-celebrates-recertification-as-a-b-corp)

[**Animikii Hackathon: Remote Col

*[... truncated, 12,222 more characters]*

---

### Animikii Raises $1M to Scale Social Impact Through Indigenous Technology
*574 words* | Source: **EXA** | [Link](https://nationtalk.ca/story/animikii-raises-1m-to-scale-social-impact-through-indigenous-technology-2)

**by**animikii**on**June 18, 2019 1342 Views

![Image 1](https://nationtalk.ca/wp-content/uploads/2019/06/Animikii-Indigenous-Technology-600x293.png)

**LEKWUNGEN TERRITORY (VICTORIA, BC)** June 18, 2019 — Animikii is excited to announce that it has successfully raised $1 million in financing from Raven Indigenous Capital Partners (Raven) and the Business Development Bank of Canada (BDC). The funds will be used to further build out the team and support the further development of Animikii’s Indigenous data sovereignty product to complement the company’s existing digital services.

“This $1 million in financing marks an historic event as it is the largest investment of its kind to support an Indigenous technology social enterprise on Turtle Island.” says founder Jeff Ward. He continued, “We hope to lead the way for other Indigenous tech companies to access capital at this level in the future.”

The financing consists of $750k equity investment from Raven, who will be joining Animikii’s board. Jeff Cyr, Managing Partner at Raven says“As an Indigenous impact investor in Canada, we found the perfect partner in Animikii, a cutting edge tech firm with a deep impact narrative and Canada’s first Indigenous B Corp, it’s really a trifecta for impact investment. We believe Animikii is amongst the first in a wave of high value Indigenous social enterprises.”

BDC’s support comes through its Indigenous Entrepreneur Loan Program at $250K and reinforces its track record of supporting Indigenous entrepreneurs over the years, with a current Indigenous entrepreneur client base of over 600 for $325M. “Indigenous entrepreneurs face unique challenges in accessing financing; Animikii is a shining example of the emerging, innovative businesses we want to help succeed”, adds Ryan Mclean, Vice President of BDC’s Indigenous Business Unit.

Ward closed by saying “We’re honoured to receive this level of support from two amazing, values-aligned organizations. We have a lot of work ahead of us as we continue developing technologies to support Indigenous data sovereignty at scale.”

**About Animikii**

Animikii is an Indigenous owned, values-based digital agency and social enterprise based out of Victoria, BC. It was founded in 2003 by Jeff Ward and was the first Indigenous certified B Corp in Canada. Animikii is also a Certified Aboriginal Business member of the Canadian Council for Aboriginal Business (CCAB). To find out more about Animikii visit[animikii.com](http://www.animikii.com/).

**About Raven Indigenous Capital Partners**

As an Indigenous-led and owned intermediary, Raven prioritizes the development of trust-based relationships with entrepreneurs at the centrepiece of its investment strategy. In addition to capital, the Raven team is committed to helping Indigenous social enterprises unlock and create value through capacity building and advisory support. Learn more about Raven at[ravencapitalpartners.ca](http://ravencapitalpartners.ca/).

**About BDC**

BDC is the only bank devoted exclusively to entrepreneurs. It promotes Canadian entrepreneurship with a focus on small and medium-sized businesses. With its 123 business centres from coast to coast, BDC provides businesses in all industries with financing and advisory services. Its investment arm, BDC Capital, offers equity, venture capital and flexible growth and transition capital solutions. BDC is also the first financial institution in Canada to receive B Corp certification. To find out more, visit[bdc.ca](http://bdc.ca/).

**Additional Resources**

*   [Animikii’s Media Kit](https://www.animikii.com/about/media-kit)
*   [New venture capital fund helps Indigenous businesses scale](https://www.theglobeandmail.com/business/small-business/money/article-new-venture-capital-fund-helps-indigenous-businesses-scale/)(Globe & Mail)
*   [Animikii Financing Press Release](https://www.animikii.com/downloads/animikii-raises-1m-to-scale-social-impact-through-indigenous-technology.pdf)(PDF)
*   [Decolonizing Digital Pt. 1: Contextualizing Indigenous Data Sovereignty](https://www.animikii.com/news/decolonizing-digital-contextualizing-indigenous-data-sovereignty)(Animikii Blog)
*   [Decolonizing Digital Pt. 2: Empowering Indigeneity Through Data Sovereignty](https://www.animikii.com/news/decolonizing-digital-empowering-indigeneity-through-data-sovereignty)(Animikii Blog)

**For More Information**

1–877–589–2899

[info@animikii.com](mailto:info@animikii.com)[](mailto:info@animikii.com)[www.animikii.com](http://www.animikii.com/)

| **Clients:** | [Animikii Inc.](https://nationtalk.ca/channel/animikii-inc) |
| --- |

| **Categories:** | [Technology](https://nationtalk.ca/story-category/technology) |
| --- |

**The permalink for this story is:**

 https://nationtalk.ca/story/animikii-raises-1m-to-scale-social-impact-through-indigenous-technology-2

Comments are closed.

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
