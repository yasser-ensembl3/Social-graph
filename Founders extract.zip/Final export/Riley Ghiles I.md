# Riley Ghiles I.

## Position actuelle

**Titre** : Founder
**Entreprise** : ifrican_inq
**Durée dans le rôle** : 2 years 11 months in role
**Durée dans l'entreprise** : 2 years 11 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Media Production

## Description du rôle

Media and content production for
Entrepreneurship, Culture, Athletes

## Résumé

Life’s too short to build a SaaS no one wants.

42% of startups fail because they build something the market doesn’t need.

You quit a good job, code nights & weekends, burn 6–18 months of savings…
Only to end up with zero paying customers.

Your problem isn’t skill.
It’s that no one taught you to validate and sell before you build.

I’ve been there I failed 5 startups before I figured it out.

───

I’m Riley Ghiles Ikni.
Software engineer turned startup advisor & angel investor.
15+ years in Engineering, Product, and Design from raw startups to seasoned billion-dollar tech giants.

I run the SaaS & Startup Kitchen:
a training ground for solo tech founders launching their first product.

My job? Help you validate and sell the 🥐 before you bake it.

In 2025, my bootstrapped clients are on track for $1.2M+ in combined revenue.
NPS 77.5 with video testimonials from every active client. (Ask me.)

───

🧑‍💻 WHO THIS IS FOR

→ First-time solo founders building SaaS or dev tools
→ Senior / Principal engineers (5–10+ years experience)
→ Based in North America, bootstrapped, not chasing VC

You know how to build.
You just can’t afford to guess anymore.

───

🔧 WHAT WE FIX TOGETHER

✴️ From a blurry idea → to real pain & a clear ICP
✴️ From feature soup → to a simple, sharp offer
✴️ From building in the dark → to VALIDATE & SELL with real humans
✴️ From chaos → to a mini OKR system focused on revenue

We run the interviews.
We sort the feedback.
We validate the opportunity.
We iterate — together — until you can fly solo.

───

📈 HOW IT WORKS

We start with a deep dive:
✴️ Your North Star Metric → the WHY
✴️ Your first revenue goal → the WHAT
✴️ The shortest path to paying customers → the HOW

Then we roll:
→ A simple GTM plan
→ Weekly execution & feedback
→ Clear decisions: Go / Pivot / Kill
(no zombie products lingering)

It’s part consulting, part mentoring, part hands-on help.
🚫 No motivational fluff
🚫 No “DIY video course”
🚫 No artificial flavours

───

You don’t need more features.
You need paying customers and a repeatable way to get them.

👉 Unsure? Book a call.
Link’s in the profile.
(That’s my signature right here) 🥐🟧

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAPCSz8B33kzOTQ4y5H7Ei8eDS5XOhpEBW4/
**Connexions partagées** : 14


---

# Riley Ghiles I.

## Position actuelle

**Entreprise** : Founder Compass

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Riley Ghiles I.

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7400314350059589632 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQGvgv_BQT6IEw/mp4-720p-30fp-crf28/B4EZrMyrABHoCI-/0/1764372429409?e=1765774800&v=beta&t=0NGGmub8uDICz9T5iMvwPLBxkMSQ_dT1ifuu4vhRo1I | https://media.licdn.com/dms/image/v2/D4E05AQGvgv_BQT6IEw/videocover-low/B4EZrMyrABHoBQ-/0/1764372428071?e=1765774800&v=beta&t=vG1epix26eJ5Wxh25Q-VwNNHllQY0zlVf2OKLpBoN60 | 🟧 BLACK FRIDAY: $10,596 MASTERCLASS IS FREE FOR 72 HOURS 🟧

Over the last 24 months, I’ve delivered this 90-min masterclass to startup founders, growth teams, and C-level execs.

🏛️ The in-person version for C-level teams goes up to $10,000 (USD)
💻 The virtual version is priced at $250 (USD)


But today?
You get it for FREE.
🟧🥐

For 72 hours only.
(Stops Monday 11.59 PM)

Inside this Clarity & Focus Masterclass, I break down:
→ How to set a North Star that drives real traction
→ How to translate it into OKRs that don’t rot in Notion
→ How to measure progress like a founder, not a project manager
→ Why dashboards lie and how to read them like a pilot

If you’re a founder working 12h/day, shipping nonstop, but still stuck below $10K MRR…
This is your reset button.

⚠️ Drop a comment: “Black Friday”
Send me a connection request
I’ll send you the early access form + bonus when it drops.

(And yes the orange beanie is included 🥐)

🟧 Let’s go!

#BlackFriday #founder #Clarity | 49 | 57 | 3 | 1w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:32.252Z |  | 2025-11-28T23:27:12.246Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399840288518668288 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0c8d0b99-a840-42e9-80f2-380a515bbf93 |  | 🔥 Live Today Startup Kitchen Show

Is burnout killing your creativity?

Jack Vitick felt that too so he built a tool to fix it.

👨‍💻 Jack is an app developer with a background in marketing, and the founder of Socialync a content management tool built to help creators and brands post everywhere without burning out.

🎯 His core belief?

“Creativity comes from boredom. If you’re never bored, you’ll never have ideas.”

In this live episode, we dive into:
 •	Why most creators are running on fumes
 •	Jack’s unique take on burnout and how to avoid it
 •	Building a lean SaaS from a real problem
 •	Marketing as a second brain for developers
 •	How Socialync automates content distribution in seconds

🎙️ Hosted by Riley Ghiles Ikni
📍 Live on LinkedIn + YouTube + X
📅 November 27, 2025


🎙️ Nouveau dans le streaming ou cherchant à passer au niveau supérieur ? Découvrez StreamYard et obtenez $10 de réduction ! 😍 https://lnkd.in/e_5VRQRv | 19 | 5 | 2 | 1w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:32.255Z |  | 2025-11-27T16:03:27.167Z | https://www.linkedin.com/video/live/urn:li:ugcPost:7399840286228619264/?isInternal=true |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399508814636408833 | Video (LinkedIn Source) | blob:https://www.linkedin.com/7faf9871-b8bd-4f3a-8142-e06c7a9fc12c |  | Ever dreamed of turning an idea into a real product?
Venkat Sai Kolli didn’t just dream it he built it. Fast.

As an international student in the U.S., he saw a gap:
Students needed safe, short-distance rides and stays and current platforms weren’t built for them.

So he launched OurBuddy a privacy-first platform helping students and professionals safely share rides and stays.

🎙️ In this live episode, we’ll cover:
 •	How Venkat went from idea to MVP and launch
 •	Rapid prototyping with Flutter & Firebase
 •	Bootstrapping tactics for early traction
 •	Designing for trust in peer-to-peer platforms
 •	His startup playbook for first-time founders

📅 Whether you’re at idea stage or knee-deep in iteration, this one’s packed with tactical gems. | 63 | 25 | 3 | 1w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:32.258Z |  | 2025-11-26T18:06:17.635Z | https://www.linkedin.com/video/live/urn:li:ugcPost:7399508812526743552/?isInternal=true |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397718108880138240 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFMiAoxCyo6WQ/feedshare-shrink_800/B4EZqn5Z.2HoAg-/0/1763753439023?e=1766620800&v=beta&t=j3kNIcZX5aXRpYneWfxq8vLOyisQLqhv8ko4Ubo8IDY | 🚨 I swear if I read another letter from a tech founder asking this to Santa, I ship him frozen croissant !!!

Santa isn’t your Go To Market strategy.
“Dear Santa, I just want one paying customer for my SaaS” = code for:

I built alone in Figma & VSCode (or Lovable)
I never spoke to 20 real humans
I’m hoping luck will fix what my pipeline doesn’t do

🟧 You don’t need a miracle.
✴️ You need conversations.

→ Talk to 20 people in your ICP.
→ Ask about their painful, expensive problems.
→ Turn patterns into an offer.
→ Pre-sell it from a Google Doc.
(That's what my clients do !)

If you can’t get one person to say “yes” to a promise…
why would hundreds magically pay for your product later?

Life’s too short to write wishlists when you could be booking calls.

If you’re done writing to Santa and ready to sell the 🥐 before you bake it, you know where to find me.

🥐 🟧
( in The SaaS & Startup Kitchen) | 32 | 13 | 0 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.864Z |  | 2025-11-21T19:30:40.113Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7397348680124493825 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFMmsDNgFzr_Q/feedshare-shrink_800/B4EZqipa_aKkAg-/0/1763665360721?e=1766620800&v=beta&t=xerqI7FQbQm8Cgh1IKlsXi4uewzFuB-jDnJD7C85WhQ | How I got 57,000 views by reposting Marc Lou's post from Linkedin to Reddit
(and what it reminded me about distribution)
🟧 I promise there’s a lesson in here for founders and startups.

Marc shared a startup revenue benchmarks.
I added a comment.

Then I had an idea.

I screenshotted his post.
Copy-pasted my comment.
Dropped it inside a Tech subreddit.

⏱ 72 hours later:
🥐🟧 57,000 views
🥐🟧 40+ comments
🥐🟧 More traction than most of my original posts ever got.

What changed?

🟧 Not the Croissant.
✴️ But the bakery location.

Same content.
Different platform.
Better results.

This is "content arbitrage"
And founders miss it all the time.

We blame the recipe.
But sometimes, the problem is the bakery.

🟧 Your email didn’t flop because it was bad.
🟧 Your landing page didn’t flop because it was unclear.
🟧 Your LinkedIn post didn’t flop because it lacked value.

✴️ It just walked into the wrong room.

So next time something flops…
Before rewriting it
Try serving it somewhere else.

Even the best croissant won’t sell in a room full of keto bros.
Life is too short to build something nobody wants
🟧🥐 | 35 | 16 | 0 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.865Z |  | 2025-11-20T19:02:41.434Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396404254325972992 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e0dc6792-a643-4b7f-bccc-2cc1c5df5ced |  | You can build the tech.
But can you explain it without boring people to death?

Most engineers were never taught how to talk.
Or sell.
Or pitch their own damn product.

That’s where Othmane Boumzebra comes in.
He’s a founder, ex-aerospace engineer, and now advisor to technical teams who want to position better and speak with impact.

🛠️ He’s built B2B services firms
🎯 He runs the “Engineers Can Talk” community on Skool
💬 He helps founders craft their “Signature Talk” and stop being invisible

🎙️ On the next Startup Kitchen Show, we go deep on:

What engineers get wrong about communication
Why “clarity” is a superpower in positioning
How technical minds can own any room — and close more deals

#StartupKitchenShow #EngineersCanTalk | 24 | 33 | 3 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.868Z |  | 2025-11-18T04:29:52.777Z | https://www.linkedin.com/video/event/urn:li:ugcPost:7396404253277319168/?isInternal=true |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396960646753468416 | Video (LinkedIn Source) | blob:https://www.linkedin.com/c6fbbe6b-12bd-439a-8d95-17ebf553e940 |  | Meet  Elitza Vasileva - Startup Founder | Tech Girl - TSKS 004 🍜

🎙️ Nouveau dans le streaming ou cherchant à passer au niveau supérieur ? Découvrez StreamYard et obtenez $10 de réduction ! 😍 https://lnkd.in/e_5VRQRv | 27 | 7 | 0 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.869Z |  | 2025-11-19T17:20:47.069Z | https://www.linkedin.com/video/live/urn:li:ugcPost:7396960644631220224/?isInternal=true |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7396278517430378496 | Video (LinkedIn Source) |  |  | Not enough women in tech?
Meanwhile…💅 80% of my guests are women 🥐🟧.
Just like my next one ⬇️

🚨 New guest on The Startup Kitchen Show and she’s not here to fit in.

Elitza Vasileva moved from Bulgaria to Austria at 19, studied Computer Science, skipped the safe 9-to-5, and started building. 

Today, she’s the solo founder of own.page, a no-code portfolio builder for indie hackers and creatives.

She’s not just shipping product
She’s breaking stereotypes.

We’ll talk:
👩‍💻 Why looking good doesn’t mean you’re not technical
🛠️ Building in public (with personality)
🧠 What solo founders really go through
🌱 How to grow a startup and an audience without faking it

📅 Wednesday Nov 19 - 12PM EST
🎙️ Live on LinkedIn, YouTube, and X
🍜 Hosted by Riley Ghiles I.

Comment "Croissant 🥐" if you plan on joining us | 18 | 6 | 0 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.871Z |  | 2025-11-17T20:10:14.765Z | https://www.linkedin.com/video/event/urn:li:ugcPost:7396278516037722112/?isInternal=true |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7396250540126670848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG03ztg1h5vGw/feedshare-shrink_800/B4EZqTCqnvHoAg-/0/1763403543494?e=1766620800&v=beta&t=Z-JNScDVJFJITQ1NlNXyCLl49wMyJvW7yLeYFiIwdds | You might be destroying your startup.
And you won’t even realize it.

Because the graph is going up.
Because ChatGPT said your idea was solid.
Because the dashboard is full of green lights.

💥 But here’s the truth:

⛔🟧 Most founders don’t crash because of bad tools.
⛔🟧 They crash because they outsource their judgment.

Let me tell you a story.
(actionnable 🥐 tips after I promise)

🧠 1983. Cold War.

A Soviet satellite system detects 5 incoming US missiles.
Sirens go off.
Red lights everywhere.
Protocol says: retaliate now.

Stanislav Petrov is the officer on duty.
He looks at the data.
Then pauses.

“5 missiles? That doesn’t make sense.
If the US wanted war, they’d send hundreds.”

So he breaks protocol.
🚫 Ignores the system.
🚫 Disobeys the machine.

Minutes later: False alarm.
Petrov saves the world from nuclear war.

But Petrov was trained for this.
✴️ He had context.
✴️ Experience.
✴️ Instinct.

Do you?

Because today…

If your AI says “launch,” will you?
If your CRM spikes, do you celebrate or investigate?
If the funnel converts but no one sticks, do you notice?

🚨 You can’t delegate your brain.

✴️ AI is a lever
✴️ Analytics are a mirror
✴️ Dashboards are tools

None of them replace thinking.

So next time the system screams “GO!”
🥐 Zoom out.
🥐 Take a breath.
🥐 Ask yourself: Does this make sense?

Would Petrov hit launch?

Your startup might not cause World War 3…
But it’s your world.

Make sure you don’t burn it down.

🟧🥐
Not sure what do to with your data?
Book a free 30 min call with me
(link in bio) | 20 | 16 | 0 | 2w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.872Z |  | 2025-11-17T18:19:04.456Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7395175597938745344 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0b10ec5f-38ec-45c2-97aa-5be88dd8bd3e | https://media.licdn.com/dms/image/v2/D4E05AQEK2zjjoAxwnA/videocover-high/B4EZqDxADoKcBY-/0/1763147253877?e=1765774800&v=beta&t=fKvKOgxkKKqRSwdrrte-K6cHbdUPdbPoSpCTAAyv-eg | Startup founders, they don’t PAY you money…
They don’t even PAY you attention.
Stop adding more features and do this instead:

⛔🟧 Adding features is not traction.
⛔🟧 Shipping faster is not validation.
⛔🟧 “Just one more thing” is not what gets you paid.

💡 Founders you don’t fail because the product is bad.
You fail because nobody cares.
(most of the time)

And nobody cares because:

✴️ You’re not clear on who it’s for.
✴️ You’re not speaking THEIR language.
✴️ You’re not showing why it matters to THEM.

Here’s what to do instead:

✴️  Craft a one-liner that tells users EXACTLY what you solve.
✴️ Talk to 5 HUMANS this week. No forms. No ask AI.
✴️ Show the product to get a reaction not to get praise.
✴️ Post messy stuff in public. Document the pain, not just the features.

People don’t buy tools.
They buy confidence.
They buy outcomes.
They buy clarity.

They buy YOU 🥐

✴️ Build what your users can’t ignore.
Not what you hope they’ll like.

Stuck building in silence and want traction?
Drop me a DM or comment “🥐”
I’ll send you my 5-question cheat sheet to fix your positioning in 10 min.

🟧 🥐
Croissant are warm in the oven so
I got to go !

#startups #productmarketfit #founders #nocode #bootstrap #growth | 21 | 20 | 1 | 3w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.875Z |  | 2025-11-14T19:07:38.267Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7394459274732650497 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF517ojtALiiA/feedshare-shrink_800/B4EZp5lhQiIoAg-/0/1762976472517?e=1766620800&v=beta&t=wozFQFy1Jz12VzEpB8RVHSiuLrTetSax1m1siDPpN68 | 6 Startup Killers I’ve seen in 150+ founder calls this year

Every week I take consultation calls with Founders and builders

After 150+ deep dives with early-stage founders, these are the 6 patterns I keep spotting the ones quietly killing momentum:

✴️ Weak positioning → no one gets what you actually solve
✴️ No marketing strategy → you post, but there’s no plan
✴️ No consistent feedback → you build in isolation
✴️ Shiny new pastry→ new tool ≠ new client
✴️ Fear of pricing → undercharging to feel “safe”
✴️ Building faster than learning → shipping without selling

Fix just one, and you’ll feel the shift.
Fix all six, and you’ll stop guessing.
The path is simple but rarely easy.

It's simple to make an omelette
It's not easy to get it great on a plate

That's you and Don't know what to do next?
Book my free 30min call 
(link in bio)

🥐 🟧 | 27 | 15 | 0 | 3w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.877Z |  | 2025-11-12T19:41:13.506Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7394038131269767168 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQG9d-oWVjxpVA/feedshare-shrink_800/B4DZpxvtHDGkAg-/0/1762844923513?e=1766620800&v=beta&t=FItp4vvc7wRNhF4cYkQ6PDTcNSQua2mEgP5urD0oz0U | Everyone says Product > Distribution.
But here’s what they miss:

How long will it take you to build a great product?
How will you survive long enough to finish it?

You can build the best hotel humanity has ever seen… on Mars.
But if no one knows it exists or can reach it it fails.

Distribution > Product.

Great products don’t succeed great distribution makes them succeed.
Unlike product Distribution is a foundation:
1 Distribution = Multiple products (successful or not)

Just ask Elon Musk. 
He paid $44B for distribution.

🥐🟧 | 21 | 6 | 0 | 3w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:36.878Z |  | 2025-11-11T15:47:45.080Z | https://www.linkedin.com/feed/update/urn:li:activity:7394003541226426368/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7393004236520755200 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5070e5cb-07f1-4bfa-bacf-e82e5b20685c | https://media.licdn.com/dms/image/v2/D4E05AQFpOKRWXXPSbA/videocover-high/B4EZpk6KifHoBU-/0/1762629562047?e=1765774800&v=beta&t=0g__yGOJSEe9UsDIHhqYAPmNpu_GOZo-wkZqJmNmT7U | I asked luxury car drivers what they do for a living to inspire my startup community.
You won't believe the answers, literally.


Don't listen to what they say look at what they do
(am talking about your users)

🥐🟧


PS: Also don't believe to what you see, so many Ai generate content these days...👀

#startup #Ai #Talktoyourusers | 32 | 14 | 0 | 4w | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.203Z |  | 2025-11-08T19:19:25.363Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7392628388324229121 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEc7PQayRdZ_g/feedshare-shrink_800/B4EZpfkVs8KsAg-/0/1762539955210?e=1766620800&v=beta&t=32rtw_fXvwCgB1DoTwnik35Ur7bGvS4o8ZHfpLrqrQI | 🚨 4.5 million viewers during Tesla shareholder meeting. LIVE. They shared their North Star, roadmap, and product vision in public...
Most founders won’t even tell their friends.

They showed us:

✴️ Their 10-year mission the ambitious “North Star” guiding every bet
✴️ Their product roadmap what’s coming in the next 12–18 months
✴️ Their next big bets what they’re building before they build it

All of it… streamed LIVE on X.

Think about that.
Most founders are scared to even whisper their idea.
Meanwhile, Tesla handed their competitors the entire playbook and still wins.

This isn’t just a flex. It’s a strategy.

Because clarity > belief.
And belief builds momentum.

If you’re stuck in stealth or secrecy, this is your wake-up call.

🟧 Start sharing.
🟧 Start shipping.
🟧 Start building in public.
Start TALKING to your customers LIVE

(I’ll drop the replay in the comments. Watch it like a founder, not a fan.)
🟧 🥐 

#tesla #Founders #talkToYourCustomers | 24 | 14 | 0 | 1mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.205Z |  | 2025-11-07T18:25:56.170Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7392247492731486208 | Video (LinkedIn Source) | blob:https://www.linkedin.com/d55d4c99-d6a1-4fcb-8306-7b49d8134d0c |  | We are live with Bruna !
The startup kitchen show | 14 | 4 | 0 | 1mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.207Z |  | 2025-11-06T17:12:23.584Z | https://www.linkedin.com/feed/update/urn:li:activity:7391168916494008321/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7391168916494008321 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b24087e4-4d5f-4ffc-a3e3-4ef6ceb2dd8c |  | 🚨 New guest on The Startup Kitchen Show and this one’s healing.
(Still no artificial flavours )

She’s 35, a mom of two, with a background in marketing and neuroscience.
She’s lived everywhere and now she wants to help people everywhere.

Her startup? 
✴️ Thrivr.
Her mission? 
✴️  Keep people off prescription drugs and guide them toward real healing.

We’ll talk:
✴️ Science-backed wellness
✴️ What founders can learn from neuroscience
✴️ Going global with a purpose
✴️ Her book Autism Mafia and the personal story behind it
✴️ Building while parenting

📅 Free Live November 06 on LinkedIn, YouTube, and X.

🍜 Another deep dish from the Startup Kitchen.

#StartupKitchenShow #founders #NaturalHealing #Autism | 32 | 37 | 1 | 1mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.209Z |  | 2025-11-03T17:46:30.970Z | https://www.linkedin.com/video/event/urn:li:ugcPost:7391168915055333376/?isInternal=true |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7391521534449700864 | Text |  |  | I wake up every morning for moments like this.

A founder.
A story.
A why.

✴️ An inspiring journey.

Michelle discovered me on the Startup Kitchen Show 🍜 with the FLAMBOYANT Rachel Petzold.

She booked a free Tea Talk.

And just like that voilà 🥐🟧

We talked about startups, products, and purpose.
We dug deep into her mission.
✴️ Clarity followed.

Because sometimes, all it takes is a good question and a real conversation.

If you’re building something and need a sounding board my DMs are always open.

🥐🟧 | 20 | 4 | 0 | 1mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.211Z |  | 2025-11-04T17:07:41.642Z | https://www.linkedin.com/feed/update/urn:li:activity:7391514608391430145/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7390539658688081920 | Video (LinkedIn Source) | blob:https://www.linkedin.com/4548b0fd-706f-41bf-8853-a733026ca351 | https://media.licdn.com/dms/image/v2/D4E05AQHCBWMN45h7tA/videocover-high/B4EZpB4nhRIwBU-/0/1762041955441?e=1765774800&v=beta&t=d3RUEVYb0XC5nm-_nLfg3iNW5n14r8x9z4lAcgM_DO8 | The Office (of startups) Ep 001:
The scariest costume for startup Founders

- ft (ai) Sam Altman

If you like this format drop a comment !

PS: Don't be afraid of talking to your users...
🥐 🟧 | 29 | 3 | 0 | 1mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.213Z |  | 2025-11-02T00:06:04.218Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7358906937767301120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0dWEtR_ZSiA/feedshare-shrink_800/B4EZiAW3Y9GoAg-/0/1754500135151?e=1766620800&v=beta&t=HMjUPFjI33Awn4tzdu3K9G15ahAEEd_udvzSy2qI3o8 | “Why did your startup fail?”
Here’s what I hear:

❌ “We ran out of money.”
❌ “Bad cofounder fit.”
❌ “No traction.”

But let’s cut the 🥐.

The real reason?

You never talked to your customers...

You spent 3 months building something… and didn’t have 3 conversations to see if anyone wanted it.

Here’s what happens when you skip the talking phase:

You build a solution without a real problem
You don’t know what metrics matter
You don’t know how users think, act, or decide
You confuse “features” with “value”

That’s why 90% of startups die.
They don’t fail from competition.
They fail from isolation.

If this is you there’s a better way.
"TALK TO USERS AND CUSTOMERS"

Lost, scared, anxious to do it ?
I can help you
DM me 

- Your startup Advisor
🟧 🥐

#SaaS #startup #ai | 37 | 28 | 0 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.215Z |  | 2025-08-06T17:08:55.843Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7358189030527623168 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE11wPW8pSSxA/feedshare-shrink_800/B4EZh2J6.bHIAg-/0/1754328972613?e=1766620800&v=beta&t=GbcEy8Z6QrDhAUtwE6zlP6a2Oh42oDSOb5YHYbUxM4s | Some people start McDonald’s at 52.
Some start KFC at 65.
Some build the first car factory at 40.

And some…
Some wait 54 years to talk to a user.

Not saying names....
But his roadmap had more seasoning than a Michelin kitchen
and still no one showed up to dinner.

Talk to your users.
They’re not  toppings.
They’re the whole Bakery.

🟧 🥐

Have a great week

#SaaS #Startup | 67 | 36 | 0 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.216Z |  | 2025-08-04T17:36:13.419Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7356739780077899776 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEuFrOnNESfEg/feedshare-shrink_800/B56Zhhj1hRG4Ao-/0/1753983444458?e=1766620800&v=beta&t=bF-_uhe_fKUCLQ3ldlZNFjGluA9QBqIK6Gm3BuBUWXQ | I gained 10kg (22 lbs) in 6 months. The  same 2 reasons most founders don’t grow their business.

I made 2 big mistakes:

Number #1 
I stopped measuring. 
✴️No food log. 
✴️No weigh-ins. 

Just vibes and croissants.
(Those trip to Paris... were heavy...)

Number #2
I stopped working with my coach. 
✴️No one to check the recipe. 
✴️ No one to tell me when I was overcooking it.
(I was not home, traveling a lot so no habits and systems)

Most founders do the same.
↳ They build blindly. 
↳ They burn out.

And they wonder why nothing’s working.

Without structure, you knead in the wrong direction.
Without support, you burn the croissant.
And without metrics, you’re baking in the dark.

Whether it’s your health or your business,  you need clarity, structure, and accountability to grow.

Life is too short to....
🟧 🥗 | 84 | 62 | 0 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.218Z |  | 2025-07-31T17:37:25.186Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7353859217717399554 | Video (LinkedIn Source) |  |  | 🚨 Live Podcast Announcement 🎙️

What happens when you mix Deloitte-honed strategy, founder grit, and 20+ years of scaling companies from $1M to $1B?

You get Sam Palazzolo 🟢 !

We’re going live to unpack:
→ What real strategy looks like (no fluff, no endless decks)
→ How to scale through both organic + inorganic growth
→ His 5-Pillar Methodology that drives actual results

You’ll hear how he embeds inside companies as a Fractional Chief Strategy Officer and drives transformation with relentless clarity and execution.

🟢 Real Strategies. 
🟧 Real Results.

This one’s for founders, operators, execs, and anyone serious about growth.

Join us live.
Ask your questions.
Steal a framework or two.

Because life’s too short for fake strategy.
🟧 🥐 | 61 | 12 | 1 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.220Z |  | 2025-07-23T18:51:05.601Z | https://www.linkedin.com/video/event/urn:li:ugcPost:7353859214055743488/?isInternal=true |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7355645891191402496 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH3XPlKz5oY6g/feedshare-shrink_800/B4EZhSA9JwHgAk-/0/1753722640550?e=1766620800&v=beta&t=prSXro-Jvihmd7xHTb2bn6Kp85fzYvZ0m4PwKXN5ywk | I get 5x MORE engagement than Justin Welsh and Alex Hormozi 

Not a “who has the longest baguette” contest but a post for #SasS founders who measure the wrong things.

Justin Welsh and Alex Hormozi have 5x less engagement than I do.

Crazy, right?

✴️ They’ve got 800,000 followers each. 
✴️ I’ve got 4,000 (Thank you !). 

Engagement rate?
My posts  = 2.5% 
A & J = 0.5%

If I was measuring just followers or likes, 
I’d think I suck. 
I’d be depressed. 
I’d feel small.

But that number doesn’t scale to impact. 
It doesn’t reflect connection. 
It doesn’t tell the truth.

When I measure the right thing like engagement rate. 
And it tells a very different story: 

I’m actually crushing it.

And this is exactly what I see with early-stage SaaS founders.

Level 1 (white belts): They measure nothing.
Level 2 (yellow belts): They measure the wrong things like vanity metrics.
Level 3 (where you want to be): They measure what matters.

Signal > Noise

Don’t optimize for surface metrics.
Optimize for what actually drives growth: 
✴️ Retention, 
✴️Activation, 
✴️ MRR per user, 
✴️ LTV/CAC

Not just signup numbers or Twitter likes.
(Am I the only one still saying TwitteR?)

If you’re building and you don’t know which metrics matter, you’re probably building blind.

Ok,  your read this post but still puzzled ?
so here what you can do next ⬇️

👉 I’m hosting a free webinar next week on how to find and focus on the right metrics for early-stage SaaS.
🗓️ [August 6]

🎯 I’m also doing a $250 hands-on workshop for those who want tactical help implementing this into their startup. 
Limited seats.
[August 7]

💥 All links in the comments.

Life’s too short to build something nobody wants
🟧 🥐

Riley 1 🥖- A & J 0 | 52 | 66 | 0 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.226Z |  | 2025-07-28T17:10:41.752Z |  |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7354897378316820480 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQFWPieNxvUUVg/videocover-high/B4EZhHYJCEGYCM-/0/1753544173272?e=1765774800&v=beta&t=5DSd5HrXOIWfkCBq0SGIsaLQlbKHRbrc3Fa6ZHsbrhY | 🚨 88% of startups fail.
Not from lack of talent.
From building 🥐 nobody wants.

On Aug 6–7, Sam Palazzolo 🟢 and I are fixing that.

What you get:

✴️  Free 60-min Webinar (Aug 6):
Why 43% of founders waste years on the wrong idea and how to pivot before it’s too late.

✴️ 3-Hour Virtual Workshop (Aug 7):
Bring your mess. Leave with a map.
(Live feedback. Real action plan. No fluff.)
Price: $250 ( But read the bonus )

✴️  Catalyst Community:
A year-long network for founders serious about growth.
We don’t just teach. We build together.

🎁 Bonus:
Join the workshop → Get $250 off community membership.

✅ You’ll learn how to avoid failure
✅ You’ll finally get clarity
✅ You’ll meet people who get it

📍Register: All links in the 1st comment

Life is too short to build something nobody wants...

Ready to build a Business?
YEEEP !

🟧 🥐 | 46 | 17 | 4 | 4mo | Post | Riley Ghiles I. | https://www.linkedin.com/in/ikniriley | https://linkedin.com/in/ikniriley | 2025-12-08T04:39:41.228Z |  | 2025-07-26T15:36:22.376Z |  |  | 

---



---

# Riley Ghiles I.
*Founder Compass*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 18 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [In Conversation with Riley Rees of Sofia Health](https://www.entreprenista.com/articles/617293)
*2025-05-19*
- Category: article

### [Building social community through customer-centric marketing with Riley by Social Creatures](https://creators.spotify.com/pod/profile/sproutsocial/episodes/Building-social-community-through-customer-centric-marketing-with-Riley-e25k27f)
*2024-11-13*
- Category: podcast

### [Q&A with heARsight co-founder Riley Ellingsen - Inside INdiana Business](https://www.insideindianabusiness.com/articles/qa-with-hearsight-co-founder-riley-ellingsen)
*2024-04-17*
- Category: article

### [Ep.21 The Power of Content Creation for Startups with Riley Kaminer by Power Skills For Success](https://creators.spotify.com/pod/profile/annagandrabura/episodes/Ep-21-The-Power-of-Content-Creation-for-Startups-with-Riley-Kaminer-e2mvqbc)
*2025-02-15*
- Category: podcast

### [Social Impact Stories — By Riley Webster](https://rileywebster.com/social-impact-stories)
*2025-03-14*
- Category: article

---

## 📖 Full Content (Scraped)

*4 articles scraped, 10,785 words total*

### In Conversation with Riley Rees of Sofia Health
*1,325 words* | Source: **EXA** | [Link](https://www.entreprenista.com/articles/617293)

**Describe your business in a few words?**

Sofia Health is your on demand holistic health and wellness marketplace. Our platform gives you access to professionals who can support your physical, mental, emotional, and spiritual needs!

![Image 1](https://cdn.prod.website-files.com/plugins/Basic/assets/placeholder.60f9b1840c.svg)

Riley Rees

Today you can find, book, and pay for services from hundreds of health and wellness professionals across the country. You can even sign up for group classes or buy products.

**What made you take the leap to start your own business?**

I have always had an entrepreneurial spirit. Sofia Health was the culmination of personal need and research.

In graduate school, I was working on a project that involved researching patients with chronic conditions. Overwhelmingly, it was clear that they were spending a significant amount of time searching for alternative solutions, practitioners, or therapies. They all wanted to feel better or heal. In some cases, they just wanted to have their condition or symptoms “identified.”

Meanwhile, I experienced the painful effects of a bulging disk. Dissatisfied with traditional medicine options, I found myself doing exactly what people in my research study had been doing: I started searching for alternative solutions.

The market for complementary, alternative, and holistic health was extremely fragmented. With all of the medicine that exists today, people are still sick and our society is sick of being sick. This culmination solidified the need and Sofia Health is our solution to help individuals find a practitioner, a service, a therapy or a product based on their symptoms and what they need support in.

**What was your background prior to starting your own business?**

I’m an Air Force Officer, Pilot, and former Aeromedical Evacuation Technician. I have a passion for creating mixed with a ‘take action’ personality. I have developed a few startups and I’ve had my share of failed attempts. All of which led to a great amount of learning..

**Did you always know you wanted to be an entrepreneur?**

In retrospect, this might be obvious. I love to create. I’m the person who loves change and challenges!

**Take us back to when you first launched your business, what was your marketing strategy to get the word out and did it go as planned?**

Startups and marketing are fundamentally all about testing. So for us, what was most important was getting as many data points and as much feedback as possible. In the very beginning we used ads to run tests. I never recommend getting any feedback or data from any one you know.

Our initial strategy helped build a base of super users and supporters so I think it was very successful.

Our platform empowers entrepreneurs and powers their business, we hope they will continue to share Sofia Health with new clients and use our site for booking, billing, and client messaging! This helps spread the word and as we grow, our practitioners grow.

**We always learn the most from our mistakes, share a time with us that you made a mistake or had a challenging time in business and what you learned from it?**

Build a product people want. Know who your customers are. Listen to your customers.

It’s important to understand who your customers are, whose problem you are solving, and who the payer of the widget is. This is not always as straightforward as it seems. But you need to be hyper focused as an entrepreneur so you don’t waste valuable resources - time and money.

One of the projects I worked on beforehand involved getting consumers access to their own personal medical records. As it turns out, your medical records are key when you need a second opinion--and switching between health systems and providers is no easy task. Unfortunately this is a case where the customer had to pay but was not the one receiving the solution. This is a huge and costly mistake!

**What is the accomplishment you are the most proud of to date?**

Launching Sofia Health and supporting a community of entrepreneurs via the platform is a great accomplishment! Looking forward, we are just as excited to share all of our patient and client success stories.

**When hiring for your team, what is your go-to interview question? Please share any hiring tips you can share from your experience?**

Why do you want to work at Sofia Health?

We are a mission driven company that cares about equal access to care and improving health outcomes. We want to work with like minded, motivated, mission driven people.

This question tells me so much about an individual. I can tell whether or not they prepared for the interview if they know what we do and they know how they can fit into our organization!

**How has your business or industry been impacted by the COVID-19 pandemic?**

The health and wellness industry was forced to rapidly adopt telehealth solutions. Insurance is now reimbursing for telehealth visits and we hope this doesn’t get rescinded once the pandemic i

*[... truncated, 2,909 more characters]*

---

### Building social community through customer-centric marketing with Riley by Social Creatures
*3,678 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/sproutsocial/episodes/Building-social-community-through-customer-centric-marketing-with-Riley-e25k27f)

[![Image 1: How to tackle internet trolling with FIFPRO](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/22544856/22544856-1710242350235-013e2cd4ff37f.jpg) #### Building a Globally Engaged Community with National Geographic With over 800 million followers across their socials(!), National Geographic is a bonafide powerhouse in the world of media. Since their first published issue over 100 years ago, Nat Geo has blended a passion for nature and conservation with a deep understanding of their follower base to capture curiosity and inspire action. Tulani André is the VP of Social Media at the company, and she has been using her passion for community building to not just grow the following of National Geographic, but also to tell stories directly to the audience and help them to engage with their content, whether that’s offering advice on how to maintain a healthy diet or sharing videos about the daily lives of penguins in the arctic. Tulani shares how the synergy between Nat Geo’s socials on different platforms contributes to their success, and also why building a loyal, active community can be more impactful than pure follower numbers. Nov 13, 2024 47:37](https://creators.spotify.com/sproutsocial/episodes/Building-a-Globally-Engaged-Community-with-National-Geographic-e2qto9o)[![Image 2: How to tackle internet trolling with FIFPRO](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/22544856/22544856-1710242350235-013e2cd4ff37f.jpg) #### Breaking news via social media with V Spehar V Spehar has redefined what it means to engage with social media, using platforms to create authentic, community-driven conversations around news and culture. Whether it's their viral TikTok videos delivering concise, informative updates with a dash of humour, or their commitment to amplifying diverse voices and perspectives, everything V does feels refreshingly real. V's journey on social media took off when they began using it as a tool to break down complex issues into accessible, bite-sized content. As the host of _Under the Desk News_, V seamlessly blends advocacy with levity, earning trust with a loyal audience that looks to them for both information and a sense of community. In this episode, we sit down with V Spehar to dive into how they use social media to cut through the noise, build authentic connections, and cultivate a space where followers feel informed and empowered. V shares their insights on how to keep the non-stop news cycle relevant to their audiences, and how the pandemic has changed creator culture. Oct 22, 2024 55:01](https://creators.spotify.com/sproutsocial/episodes/Breaking-news-via-social-media-with-V-Spehar-e2q06fg)[![Image 3: How to tackle internet trolling with FIFPRO](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/22544856/22544856-1710242350235-013e2cd4ff37f.jpg) #### Pushing Boundaries and Challenging the Norm with Oatly Oatly have changed the game in plant based milk, whilst redefining what it means to market their products with authenticity, humour and boldness. Whether it’s their tongue in cheek ads like ‘It’s like milk, but made for humans’ or their innovative approach to turning controversies into opportunities - everything they do is anything but conventional! Sarah Sutton, Global Media Director at Oatly has been overseeing their unique approach and ethos since she joined the company in 2021. She joined at the time when they just spent 90% of their marketing budget at that year's Super Bowl, in which they ran an old advert of their CEO singing “wow, no cow”. Sarah chats to us about how Oatly believe their product is the purpose and so wrap their brand messaging around this. This enables Oatly to be seen as disruptors and that enables Sarah to choose humour and creativity, above all else, when creating content. When talking about social media in general, she believes that if you are on the right side of history and doing the right thing as a brand, then the community will step in and fight battles for you. Oct 08, 2024 43:38](https://creators.spotify.com/sproutsocial/episodes/Pushing-Boundaries-and-Challenging-the-Norm-with-Oatly-e2pcltu)[![Image 4: How to tackle internet trolling with FIFPRO](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo400/22544856/22544856-1710242350235-013e2cd4ff37f.jpg) #### Saving dogs’ lives through social media with Niall Harbison If you’re ever having a bad day, the Happy Doggo socials are where you need to be. With over 1.5 million followers across platforms, this animal welfare charity aims to fix the global street dog problem by raising awareness of the issue and promoting the success stories of the dogs they rescue. Its founder, Niall Harbison, founded the charity in 2021 after a near-death experience, and has gone on to utilise social media in gathering support for important causes which is making a substantial global impact. Niall chats to us about the importance of aut

*[... truncated, 28,570 more characters]*

---

### Ep.21 The Power of Content Creation for Startups with Riley Kaminer by Power Skills For Success
*5,147 words* | Source: **EXA** | [Link](https://creators.spotify.com/pod/profile/annagandrabura/episodes/Ep-21-The-Power-of-Content-Creation-for-Startups-with-Riley-Kaminer-e2mvqbc)

![Image 1: Ep.21 The Power of Content Creation for Startups with Riley Kaminer](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/39851867/39851867-1723154825810-fd97bca1ec1da.jpg)

Ep.21 The Power of Content Creation fo…
---------------------------------------

Power Skills For Success Aug 09, 2024

00:00

27:31

[![Image 2: Ep.39 Practical AI for Any Role: How to Get ROI From AI Tools with Galina Fendikevich](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/39851867/39851867-1757023863695-4b96f070fb52b.jpg) #### Ep.39 Practical AI for Any Role: How to Get ROI From AI Tools with Galina Fendikevich In this episode, I interview Galina Fendikevich, AI expert and Product Manager from San Francisco.We discuss practical applications of AI tools, the misconceptions surrounding AI's capabilities, and the essential skills needed to thrive in an AI-driven world.🔗 USEFUL LINKS AND RESOURCESGuest Connect:https://www.linkedin.com/in/gfendiCastmagic:https://get.castmagic.io/galinaCustomGPT:https://customgpt.ai/?fpr=galinaFireflies:https://app.fireflies.ai/login?referralCode=vwM593D5N1SuperHuman -https://superhuman.com/refer/1lqrixpkArc Browser -https://arc.net/gift/b676625dPerplexity -https://perplexity.ai/pro?referral_code=MUJV30YL🔗 CONNECT WITH ANNA:🎥 Linkedin -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.linkedin.com/in/annagandrabura/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🐦 Twitter -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://twitter.com/anna_gandrabura⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠📸 Instagram -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.instagram.com/annglish_/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🎬 Check out my new course "Power Skills For Tech" -https://www.mytechville.com/power-skills Sep 04, 2025 37:23](https://creators.spotify.com/pod/profile/annagandrabura/episodes/Ep-39-Practical-AI-for-Any-Role-How-to-Get-ROI-From-AI-Tools-with-Galina-Fendikevich-e37q1lj)[![Image 3: Ep.38 Pitch Like a Pro: Power Skills Behind Confident Fundraising with Kat Weaver](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/39851867/39851867-1752858931605-b33528a14fd12.jpg) #### Ep.38 Pitch Like a Pro: Power Skills Behind Confident Fundraising with Kat Weaver In this episode, I interview Kat Weaver, a 24-time pitch competition winner, exited founder, and the founder of Power to Pitch. We discuss mastering the art of the pitch, overcoming mindset blocks, and how telling too many stories can actually ruin your pitch. 🔗 USEFUL LINKS AND RESOURCESDM:https://www.instagram.com/iamkatweaver?igsh=Z2dmOHhndmdkbXpp to get a free pitch plan🔗 CONNECT WITH ANNA:🎥 Linkedin -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.linkedin.com/in/annagandrabura/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🐦 Twitter -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://twitter.com/anna_gandrabura⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠📸 Instagram -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.instagram.com/annglish_/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🎬 Check out my new course "Power Skills For Tech" -https://www.mytechville.com/power-skills Jul 21, 2025 28:29](https://creators.spotify.com/pod/profile/annagandrabura/episodes/Ep-38-Pitch-Like-a-Pro-Power-Skills-Behind-Confident-Fundraising-with-Kat-Weaver-e35nmmf)[![Image 4: Ep.37 Ask What’s Possible: How Envisioning Can 10X Your Life and Work](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/39851867/39851867-1750419552422-23e391006a2ce.jpg) #### Ep.37 Ask What’s Possible: How Envisioning Can 10X Your Life and Work In this episode, I interview Adam Coelho — former Googler, current workshop facilitator, and entrepreneur. We discuss how envisioning can help you 10x your life, what thinking big really means, and the key insights that led Adam to create his workshop for leaders and tech executives, Ask What's Possible.🔗 USEFUL LINKS AND RESOURCESFree Envisioning Exercise to think REALLY BIG about you want and what’s possible for your life and work -http://askwhatspossible.com/powerAsk What’s Possible Workshop -https://askwhatspossible.com/The Mindful FIRE Podcast -www.mindfulfire.orgAdam Coelho on LinkedIn -https://www.linkedin.com/in/adamcoelho/🔗 CONNECT WITH ANNA:🎥 Linkedin -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.linkedin.com/in/annagandrabura/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🐦 Twitter -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://twitter.com/anna_gandrabura⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠📸 Instagram -⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠https://www.instagram.com/annglish_/⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠⁠🎬 Check out my new course "Power Skills For Tech" -https://www.mytechville.com/power-skills Jun 20, 2025 32:07](https://creators.spotify.com/pod/profile/annagandrabura/episodes/Ep-37-Ask-Whats-Possible-How-Envisioning-Can-10X-Your-Life-and-Work-e34gkhn)[![Image 5: Ep.36 Bridging the Communication Skills Gap in the Workplace with Sheri Smith](https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_episode400/39851867/39851867-1749149505167-fd1a5925ddd86.jpg) #### Ep.36 Bridging the Communication Skills Gap in the Workplace with Sheri Smith In this episode, we talk to Sheri Smith, the founder and CEO of the Indigo Project, a social enterprise with the vision of catalyzing a learner-centered education system.Sheri believes that every person has the intrinsic genius to excel in any fie

*[... truncated, 45,991 more characters]*

---

### Social Impact Stories — By Riley Webster
*635 words* | Source: **EXA** | [Link](https://rileywebster.com/social-impact-stories)

*   **The Revolutionary Ideas of Generation Next**

_As seen in_[_Douglas Magazine_](https://www.douglasmagazine.com/the-revolutionary-ideas-of-generation-next/)_, Jan/Feb print and_[_online_](https://www.douglasmagazine.com/the-revolutionary-ideas-of-generation-next/)_issues_

*   **Service Over Self: A Veteran’s Path To A Stanford MBA**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/11/10/service-over-self-a-veterans-path-to-a-stanford-mba/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/over-self-veteran-path-stanford-005524310.html)

*   **At Stanford GSB, A Celebration Of Hispanic Culture & Influence**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/10/17/at-stanford-gsb-a-celebration-of-hispanic-culture-influence/)_,_[_Yahoo_](https://www.yahoo.com/now/stanford-gsb-celebration-hispanic-culture-132457897.html?guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAAGF3NA3n-PDNGUFry7CRo5zGinNs3uzJS_Ax55R7yV4-BO2Ih2SH_hD_XLJUCuJpA4pjGrFTDBYdYh_cis1v-1k2JE_V8zQqyjPu8Y4oTH_-DnD4WpOcGZ3zmE-irjrcKnTyijlcPZ0MtwkEZf0E64-5xEp0GKsyTu8pgOmXH3Lo)

*   **Harnessing The Power Of Harvard’s Global MBA Classroom**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/10/04/harnessing-the-power-of-harvards-global-mba-classroom/)

*   **Fostering Connection: Inside Kellogg’s Pre-MBA ‘Culture Camp’**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/09/19/fostering-connection-inside-kelloggs-pre-mba-culture-camp/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/fostering-connection-inside-kellogg-pre-192839761.html)

*   **‘From A War Zone To An MBA’: Stanford Students Successfully Deliver Equipment To Ukraine**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/09/06/from-a-war-zone-to-an-mba-stanford-students-successfully-deliver-equipment-to-ukraine/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/war-zone-mba-stanford-students-033607666.html)

*   **Ka Hale Hoaka is Bringing Indigenous Language Back to Hawaiian Society**

_As seen in_[_Thinkific_](https://www.thinkific.com/blog/ka-hale-hoaka-success-story/)

*   **Celebrating Nature’s Path: Organic Snack Food Company Wins Distinguished Entrepreneurs of the Year Award from UVic**_As seen in Douglas Magazine,_[_online_](https://www.douglasmagazine.com/celebrating-natures-path-organic-snack-food-company-wins-distinguished-entrepreneurs-of-the-year-award-from-uvic/)_and in Aug/ Sept. 2022 print issue_

*   **The Big Pivot: From College Football To The Military To An MBA At Stanford**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/07/26/the-big-pivot-from-college-football-to-the-military-to-an-mba-at-stanford/)_,_[_NewsBreak_](https://www.newsbreak.com/news/2681118467635/the-big-pivot-from-college-football-to-the-military-to-an-mba-at-stanford)

*   **Meet The MD-MBA Who Turned Down A Medical Residency To ‘Help People Have Babies’**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/07/27/meet-the-md-mba-who-turned-down-a-medical-residency-to-help-people-have-babies/)

*   **Humanizing Business: How Tuck’s Virtual Reality Experiment Brings Empathy Into The MBA Classroom**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/07/05/humanizing-business-how-tucks-virtual-reality-experiment-brings-empathy-into-the-mba-classroom/2/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/humanizing-business-tuck-virtual-reality-024857203.html?guccounter=1&guce_referrer=aHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS8&guce_referrer_sig=AQAAABmdMq1xOD3nG4MK77RAHtZ2FADCB6EqlIwVMnZaUHqfukyPwklytBgIMHLifKc9gOoGSWNLbnKfYcl8VZN-cXHi3muAMUmDDD2edcUDWCQRWewsFoG1Ed2tL2CROp2vSRcrpZyQJJVKOQDVzME6m9fFeMVL8tqxZe2s3qO4zG54)

*   **How Dartmouth’s Student-Led Next50 Initiative Aims To Diversify Case Studies**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/2022/06/15/how-dartmouths-student-led-next50-initiative-aims-to-diversify-case-studies/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/dartmouth-student-led-next50-initiative-224616879.html)

*   **Where Opportunities Are Scarce, Students In This Program Help Create More**_As seen in_[_Poets&Quants for Execs_](https://poetsandquantsforexecs.com/news/where-opportunities-are-scarce-students-in-this-program-help-create-more/)

*   **Transforming Tourism: Vancouver Island’s Industry-Leading Transition Helps Local Businesses Thrive**_As seen in_[_Douglas Magazine_](https://www.douglasmagazine.com/find-a-copy/)_, June/July 2022 print issue_

*   **Celebrating Working Mothers: The Kellogg MBA Changing African Women’s Lives**_As seen in_[_Poets&Quants_](https://poetsandquants.com/students/celebrating-working-mothers-the-kellogg-mba-changing-african-womens-lives/)_,_[_Yahoo Finance_](https://finance.yahoo.com/news/celebrating-working-mothers-kellogg-mba-220055265.html)

*   **Meet The Cornell MBA Bringing Equity To VC**

_As seen in_[_Poets&Quants_](https://poetsandquants.com/business-school-news/meet-the-cornell-mba-bringing-equity-to-vc/)_,_

*[... truncated, 11,123 more characters]*

---

---

## 🎬 YouTube Videos

- **[Engineers Can Sell with Othmane Boumzebra TSKS🍜 005](https://www.youtube.com/watch?v=VjPTMXeMHtw)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-11-20

- **[Act on Inspiration Immediately! By Naval on NW @NavalR  @ChrisWillx](https://www.youtube.com/watch?v=2OijX7wbww4)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-06-07

- **[Life is 2 short to miss Septia The real Emilie in Paris](https://www.youtube.com/watch?v=0XMoadkL6h4)**
  - Channel: Riley Ghiles Ikni
  - Date: 2024-02-20

- **[Rilès - SURVIVAL LIVE SESSION (part 1)](https://www.youtube.com/watch?v=C4k2_1IT30o)**
  - Channel: Rilès
  - Date: 2025-05-12

- **[24h de course face à des scies géantes, le défi (dangereux) du rappeur Rilès a commencé #shorts](https://www.youtube.com/watch?v=xnXIFY8mjJ4)**
  - Channel: LeHuffPost
  - Date: 2025-02-08

- **[&quot; I studied because I had to save my son&quot;  ft Bruna Founder of Thrivr TSKS 003](https://www.youtube.com/watch?v=pREyOaUzsYs)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-11-07

- **[&quot;Africa needs more Zebras not unicorns&quot; &quot;The Startup Kitchen Show #002](https://www.youtube.com/watch?v=zzJ5kZuJUL8)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-10-31

- **[Meet Dee Greene](https://www.youtube.com/watch?v=jiSd26Izwak)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-06-20

- **[0-200 users in 60 days Building Socialync TSKS 🍜 008](https://www.youtube.com/watch?v=Ug158W_klu4)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-11-28

- **[You are NOT a FAILURE you are a FOUNDER](https://www.youtube.com/watch?v=9SprHQ_HPjo)**
  - Channel: Riley Ghiles Ikni
  - Date: 2025-10-28

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
