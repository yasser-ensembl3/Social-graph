# Pascal Jarry

## Position actuelle

**Titre** : Founder and CEO
**Entreprise** : Yapla
**Durée dans le rôle** : 12 years 11 months in role
**Durée dans l'entreprise** : 12 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Non-profit Organizations

## Description du rôle

Software editor dedicated to NPOs, Yapla markets a platform designed by and for NPOs of all sizes. It is an all-in-one payment and management platform that allows you to manage members, process memberships, sell tickets, collect donations and send out newsletters. With Yapla, it is also possible to manage your accounting or even create a website.  In line with its vision to become the most used NPO platform in the world, the Takeoff package is totally free and allows you to receive payments without any transaction fees. 

Yapla was founded in 2013 and is used by over 20,000 NPOs in North America and Europe. It is supported by a team of more than 50 people mobilized to facilitate the daily life of NPOs. The French bank Crédit Agricole is a shareholder of Yapla since 2019. 
To learn more, visit www.yapla.ca

## Résumé

Giving access to information technology to as many managers as possible has been at the heart of Pascal Jarry's daily life for over 25 years. His passion for the digital world has led him to work in many sectors such as transportation, logistics, finance, marketing, software and philanthropy.  

In 2007, he founded the HPJ group, which oversees several companies in Canada and France, with the common denominator of democratizing access to digital technology.

In 2013, he launched Yapla, an all-in-one payment and management platform for NPOs/associations. As CEO, Pascal Jarry specifically accompanies thousands of organizations to whom he reveals the multiple facets of digital technology. His vision is that all associations on the planet, regardless of their size, can benefit from a digital platform to facilitate their daily lives.

Pascal Jarry holds degrees in computer science (University of Sherbrooke, 1996) and economics (University of Quebec in Montreal, 1993).

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAABIzHIBZ8P4-mhjvEJ1LeWQMAcQ2PyQrTc/
**Connexions partagées** : 49


---

# Pascal Jarry

## Position actuelle

**Entreprise** : Yapla

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Pascal Jarry
*Yapla*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 20 |

---

## 📚 Articles & Blog Posts

### [How a Federated Association Organized its Biggest Sporting Event with Yapla | Yapla](https://yapla.com/en-ca/case-study/how-a-federated-association-organized-its-biggest-sporting-event-with-yapla)
*2024-05-04*
- Category: article

### [Pascal Jarde – PG Connects London](https://www.pgconnects.com/london/speakers/pascal-jarde/)
*2024-01-01*
- Category: article

### [Pascal Levy-garboua](https://www.thenetwork.com/profile/pascal-levy-garboua-63273354)
*2024-09-20*
- Category: article

### [Startup Acquisition Stories Podcast With Pascal Levy-Garboua, CEO of Noosa Labs by Startup Acquisition Stories](https://creators.spotify.com/pod/profile/startup-acquisitions/episodes/Startup-Acquisition-Stories-Podcast-With-Pascal-Levy-Garboua--CEO-of-Noosa-Labs-e2lk705)
*2025-05-13*
- Category: podcast

### [Business valuation factors in b2b SaaS acquisitions with Pascal Levy-Garboua @NoosaLabs | Podcast | Boomplay](https://www.boomplay.com/episode/7790002)
*2024-07-29*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Yapla, the Canadian all-in-one NPO management and payment ...](https://www.newswire.ca/news-releases/yapla-the-canadian-all-in-one-npo-management-and-payment-platform-strengthens-its-international-presence-and-growth-with-a-launch-in-italy-and-an-enhanced-partnership-with-credit-agricole-881749918.html)**
  - Source: newswire.ca
  - *May 15, 2024 ... Radio & Podcast · Television · Entertainment & Media Overview · View ... Pascal Jarry, president and founder of Yapla, stated, "We ar...*

- **[La Chaise Bleue - Podcast - Apple Podcasts](https://podcasts.apple.com/us/podcast/la-chaise-bleue/id1732040147)**
  - Source: podcasts.apple.com
  - *Listen to GLM Conseil's La Chaise Bleue podcast on Apple Podcasts ... Pascal Jarry, président et fondateur de Yapla. Ensemble, ils reviennent sur ......*

- **[Programme | Yapla Impact](https://impact.yapla.com/fr/programme)**
  - Source: impact.yapla.com
  - *Dans cette conférence, Pascal Jarry, fondateur et CEO de Yapla, partage les ... La Chaise Bleue: le podcast en direct de l'événement. Nicolas Quintin....*

- **[La Chaise Bleue | Podcast on Spotify](https://open.spotify.com/show/0vFH6K7oJQFfXWPPNzC7Ma)**
  - Source: open.spotify.com
  - *Lors de l'événement Yapla Impact, Benoit Cormier et Nicolas Quintin reçoivent Pascal Jarry, président et fondateur de Yapla. Ensemble, ils reviennent ...*

- **[Le rendez-vous incontournable des OBNL | Le Manufacturier](https://www.cvdm.org/fr/actualites/le-rendez-vous-incontournable-des-obnl)**
  - Source: cvdm.org
  - *Oct 9, 2024 ... Podcast. Actualités. Le rendez-vous ... Pascal Jarry prendra la parole lors de cette 3ème édition de la Conférence Utilisateurs Yapla ...*

- **[Pascal Jarry : Maillage industriel et IA sémantique au cœur de l ...](https://www.youtube.com/watch?v=ZYIDUrXJ0h8)**
  - Source: youtube.com
  - *Nov 27, 2025 ... Lors de l'événement Yapla Impact, Benoit Cormier et Nicolas Quintin reçoivent Pascal Jarry, président et fondateur de Yapla....*

- **[Réinventer l'innovation : créativité, culture et espace au sein de l ...](https://www.youtube.com/watch?v=Eh8sTzs8TYk)**
  - Source: youtube.com
  - *4 days ago ... Lors de l'événement Yapla Impact, Nicolas Quintin reçoit sur la ... Pascal Jarry : Maillage industriel et IA sémantique au cœur de l .....*

- **[Yapla CEO, Founder, Key Executive Team, Board of Directors ...](https://www.cbinsights.com/company/yapla/people)**
  - Source: cbinsights.com
  - *Buyer Interview Transcripts · Analyst Briefings · API & Data Feeds ... Yapla's current Founder, Chief Executive Officer is Pascal Jarry. Name. Work .....*

- **[Portrait d'éditeur : Yapla](https://www.leslogiciels.fr/portrait/crm/portrait-dediteur-yapla)**
  - Source: leslogiciels.fr
  - *Yapla, c'est LA solution de paiement et gestion pour associations de toute taille ... : Pascal Jarry Nombre de salariés : 50. Nationalité : Franco-Qué...*

- **[News - La Fabrique by CA](https://www.lafabriquebyca.com/news/)**
  - Source: lafabriquebyca.com
  - *Dans une récente interview, Benjamin Vergnhes, CEO de Khome, explique que le ... A Big Hairy Audacious Goal : l'histoire de Pascal Jarry, CEO de Yapla...*

---

*Generated by Founder Scraper*
