# Guillaume Provost

## Position actuelle

**Titre** : Founder, Studio Head
**Entreprise** : Compulsion
**Durée dans le rôle** : 16 years 7 months in role
**Durée dans l'entreprise** : 16 years 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Description du rôle

I decided to brave the economic crisis and founded Compulsion Games in 2009, leveraging my expertise and relations to build an independent studio in the vibrant city of Montreal. The studio became a part of Xbox Game Studios in 2018.

Our team is growing steadily with more independent-minded, creative individuals who strive for excellence and ownership.

Find us at www.compulsiongames.com!

## Résumé

I worked with independent game developers for a while, before founding Compulsion Games in 2009 and getting acquired by Microsoft in 2018. I'm also passionate about mentoring and helping people out in our industry.

Specialties: Business, Technology, Creative Direction.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAACW3gBfKdD8Tn0Ic0BabVJQBRNK2ZkLtY/
**Connexions partagées** : 14


---

# Guillaume Provost

## Position actuelle

**Entreprise** : Compulsion Games

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Guillaume Provost
*Compulsion Games*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 23 |

---

## 📚 Articles & Blog Posts

### [Exclusive: South of Midnight Interview with Guillaume Provost](https://lordsofgaming.net/2025/02/exclusive-south-of-midnight-interview-with-guillaume-provost/)
*2025-02-11*
- Category: article

### [Guillaume Provost, studio director Compulsion Games (South of Midnight, We Happy Few).](https://podcasts.apple.com/us/podcast/guillaume-provost-studio-director-compulsion-games/id1665581266?i=1000704409037)
*2025-04-22*
- Category: podcast

### [Compulsion Games boss tells Brazilian devs to bake discoverability into the bedrock of their games](https://gamedeveloper.com/marketing/compulsion-games-boss-tells-brazilian-devs-to-bake-discoverability-into-the-bedrock-of-their-games)
*2025-08-01*
- Category: article

### [Compulsion Games Dev Talks Research and Representation in South of Midnight](https://gamerant.com/south-midnight-compulsion-games-studio-head-guillaume-provos-interview)
*2025-05-02*
- Category: article

### [Compulsion Games boss: Generative AI usage 'is not mandated' at Xbox](https://gamedeveloper.com/production/compulsion-games-boss-says-internal-xbox-studios-aren-t-facing-generative-ai-mandate)
*2025-05-02*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[My Perfect Console with Simon Parkin - Guillaume Provost, studio ...](https://www.reddit.com/r/Games/comments/1k50etb/my_perfect_console_with_simon_parkin_guillaume/)**
  - Source: reddit.com
  - *Apr 22, 2025 ... My Perfect Console with Simon Parkin - Guillaume Provost, studio director Compulsion Games ... r/podcasts. • 1y ago. A recommendation...*

- **[Guillaume Provost, studio director Compulsion Games (South of ...](https://podcasts.apple.com/ca/podcast/guillaume-provost-studio-director-compulsion-games/id1665581266?i=1000704409037)**
  - Source: podcasts.apple.com
  - *Apr 20, 2025 ... Guillaume Provost, studio director Compulsion Games (South of Midnight, We Happy Few). ... Apple Podcasts web player & Privacy · Cook...*

- **[Compulsion Games boss: Generative AI usage 'is not mandated' at ...](https://www.gamedeveloper.com/production/compulsion-games-boss-says-internal-xbox-studios-aren-t-facing-generative-ai-mandate)**
  - Source: gamedeveloper.com
  - *May 2, 2025 ... Yet, during a conversation with Game Developer at Gamescom LATAM, Compulsion Games founder and studio head Guillaume Provost confirmed...*

- **[Guillaume Provost, studio director Compulsion Games (South of ...](https://shows.acast.com/my-perfect-console/episodes/guillame-provost-studio-director-compulsion-games-south-of-m)**
  - Source: shows.acast.com
  - *Apr 20, 2025 ... Listen to Guillaume Provost, studio director Compulsion Games (South of Midnight, We Happy Few). from My Perfect Console with Simon P...*

- **[Compulsion Games boss tells Brazilian devs to bake discoverability ...](https://www.gamedeveloper.com/marketing/compulsion-games-boss-tells-brazilian-devs-to-bake-discoverability-into-the-bedrock-of-their-games)**
  - Source: gamedeveloper.com
  - *Aug 1, 2025 ... Compulsion Games founder Guillaume Provost says Brazil is a ... Podcast Ep. 58. Oct 31, 2025. See all. Game Developer Collective. An ....*

- **[Exclusive: South of Midnight Interview with Guillaume Provost ...](https://lordsofgaming.net/2025/02/exclusive-south-of-midnight-interview-with-guillaume-provost/)**
  - Source: lordsofgaming.net
  - *Feb 11, 2025 ... South of Midnight Guillaume Provost Interview Iron Lords Podcast Thumbnail. Compulsion Games is set to release their highly anticipat...*

- **[Compulsion Games - YouTube](https://www.youtube.com/c/compulsiongames)**
  - Source: youtube.com
  - *Compulsion Games. @CompulsionGames. 17K subscribers•112 videos. For an ... In Conversation with Daryl Ogden | Guillaume Provost, Head of Compulsion Ga...*

- **['We Happy Few' has become much more than a roguelike about ...](https://www.gamedaily.biz/we-happy-few-has-become-much-more-than-a-roguelike-about-pretending-to-be-happy/)**
  - Source: gamedaily.biz
  - *Jun 27, 2018 ... Things have changed in Wellington Wells and for its development studio, Compulsion Games. When I first spoke to co-founder Guillaume ...*

- **[A recommendation for "My Perfect Console," a games interview ...](https://www.reddit.com/r/podcasts/comments/1dz2r8m/a_recommendation_for_my_perfect_console_a_games/)**
  - Source: reddit.com
  - *Jul 9, 2024 ... ... interview, as well as their life and career. ... My Perfect Console with Simon Parkin - Guillaume Provost, studio director Compuls...*

- **[South of Midnight reaches over 1 million players less than a month ...](https://icon-era.com/threads/south-of-midnight-reaches-over-1-million-players-less-than-a-month-after-launch.17175/)**
  - Source: icon-era.com
  - *May 3, 2025 ... ... interview/. Recently, Game Rant chatted with Compulsion Games CEO and Studio Head Guillaume Provost. During the discussion, Provos...*

---

*Generated by Founder Scraper*
