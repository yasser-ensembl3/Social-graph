# Hicham El Hajj Boutros

## Position actuelle

**Titre** : Director of Production
**Entreprise** : Redbox Media
**Durée dans le rôle** : 2 years 5 months in role
**Durée dans l'entreprise** : 2 years 5 months in company

## Localisation & Industrie

**Localisation** : Mont-Royal, Quebec, Canada
**Industrie** : Advertising Services

## Description du rôle

Leads and supervises project managers, coordinating overall production and optimizing team schedules to ensure efficient and high-quality delivery.
Responsible for project performance, quality assurance, and client satisfaction, in alignment with project management standards and strategic objectives.
Implements leadership practices focused on empathy and skills development, fostering engagement and professional growth among team members.

## Résumé

With over a decade of experience leading and empowering multidisciplinary teams, I am a dedicated Digital Leader focused on fostering collaborative environments and driving impactful digital experiences. My approach is rooted in empathy and humility, believing that true success comes from nurturing talent, promoting ethical practices, and inspiring individuals to achieve their best. I specialize in product management, e-commerce strategy, and digital transformation, consistently delivering results by optimizing processes and cultivating strong stakeholder relationships. I am passionate about leveraging technology to create meaningful user journeys and building teams that thrive on innovation and mutual respect.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAd9dYABAPvpWQemtsV88Qhy2fhtLIneN6w/


---

# Hicham El Hajj Boutros

## Position actuelle

**Entreprise** : Redbox Media

## Localisation & Industrie

**Localisation** : Mont-Royal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Hicham El Hajj Boutros

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7394054391260925952 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHBvge2Z_lQ8A/feedshare-shrink_800/B4EZpwbcPnKoAg-/0/1762822834500?e=1766620800&v=beta&t=VcdQDjWSphrckkNWNr9pihuOASGDy1B9Yh8gr4MNE4U | I Used To See AI As A Tool. Now I See Them As Team Members.

Last week, I asked if AI was making us intellectually lazy. Today, I want to share a perspective shift that excites me.

I saw a post that reframed AI not as a feature you use, but as a teammate you collaborate with.

AI isn't replacing the Program Manager, Project Manager, or Product Owner.
It's giving them a team of AI agents to manage.

Think about it:

Your Product Owner now has a "User Story Agent" that can draft 50 epics and stories in the time it used to take to write one.
Your Project Manager has a "Risk Assessment Agent" that continuously monitors project vitals and flags deviations in real-time.

This doesn't eliminate these roles, it transforms them.
We're becoming orchestrators of human and AI talent.

Yes, this creates more to manage. More "team members" mean more coordination, more briefings, and more quality control. But it also elevates our work.

The time consuming tasks get delegated to our AI team. This frees us up for the irreplaceably human work:
Strategic vision and creative direction.
Navigating complex stakeholder politics.
Building team culture and psychological safety.
Making the nuanced, judgment calls that data can't.

They handle the bandwidth. We provide the depth.
Some roles will evolve, but the core of leadership (ex: empathy, strategy, and inspiration) becomes more valuable than ever.
I'm not just using AI anymore. I'm building my team.

How are you structuring your AI team? What "agent roles" have you created?

#AIAgents #FutureOfWork #ProjectManagement #ProductManagement #Leadership #TeamBuilding #AI #DigitalTransformation | 6 | 1 | 0 | 3w | Post | Hicham El Hajj Boutros | https://www.linkedin.com/in/hicham-el-hajj-boutros-4a810136 | https://linkedin.com/in/hicham-el-hajj-boutros-4a810136 | 2025-12-08T07:19:56.412Z |  | 2025-11-11T16:52:21.764Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392298554972717056 | Text |  |  | Jessy Mouawad is moving on to new opportunities, and I just want to say: she’s a really talented designer.
Not only have I seen her work up close, we’ve worked together regularly — and I’ve experienced firsthand how thoughtful, creative, and reliable she is. Yes, I’m her husband, so of course I’m biased. But I also know good design when I see it, and Jessy consistently delivers.
Wishing her all the best for what’s next. | 14 | 4 | 0 | 1mo | Post | Hicham El Hajj Boutros | https://www.linkedin.com/in/hicham-el-hajj-boutros-4a810136 | https://linkedin.com/in/hicham-el-hajj-boutros-4a810136 | 2025-12-08T07:19:56.413Z |  | 2025-11-06T20:35:17.771Z | https://www.linkedin.com/feed/update/urn:li:activity:7392289722003533824/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391924791408238592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG_g5Mnnf5P7g/feedshare-shrink_800/B4EZpVka.RGUAg-/0/1762372204243?e=1766620800&v=beta&t=6H7TFHA9FUMGMhd_f3cjTqxnoPmPspOVSRKS7sTreHE | AI Is Cutting The Learning Curve, But At What Cost?
A junior developer can debug code with Claude.
A new marketer can craft a strategy with ChatGPT.
A product owner can generate user stories in seconds.
We've collapsed the learning curve from years to minutes.
But I have an uncomfortable question: Is this making us intellectually lazy?
There's a crucial difference between finding an answer and understanding a concept.
When I struggled to learn coding as a kid, I spent hours searching, tracing logic, and banging my head against the wall. That struggle was the learning. It built a deep, durable mental model.
Now, AI gives us the answer instantly. We skip the struggle. We get the "what" without the "why."
The "AI Crutch" is creating a generation of professionals who are brilliant at orchestrating work, but may be losing the capacity to fundamentally understand it.
Think about it:
A PM who uses AI for risk analysis but can't intuitively sense project tension.
A designer who generates 100 UI options but can't explain the core principles of visual hierarchy.
A writer who crafts perfect SEO copy but has a fading grasp of narrative voice.
I see this in my own work. Recently, while debugging a complex feature, I immediately pasted an error into an AI. It gave a wrong answer. So, I refined my prompt. I gave it more context. I spent 45 minutes in a looping, frustrating dialogue, trying to help the AI understand the problem rather than just understanding it myself.
I was stuck in a "debug-the-AI" loop, instead of debugging the code. The moment I quit the chat and opened my debugger, I found the issue in 10 minutes. I had wasted energy trying to be a good prompt engineer instead of a good engineer.
We're outsourcing the cognitive heavy-lifting. And our learning muscles are atrophying.
This isn't a rant against progress. AI is the most powerful tool we've ever had. But a tool is only as good as the craftsman wielding it.
So, what's the solution? We must shift from being "AI Users" to "AI Collaborators."
The "10-Minute Rule": Before you go to AI, give yourself a non-negotiable 10-15 minutes to try and solve the problem yourself. Form a hypothesis. The struggle is the seed of understanding.
Use AI for Drafts, Not Final Products: Let AI write the first draft of your user story or code. Then, you rewrite it. You critique it. You apply your own context. The learning happens in the editing.
Ask "Why," Not Just "What": When AI gives you an answer, challenge it. Ask, "What are the underlying principles here?" or "Walk me through your reasoning." Force it to teach you, not just tell you.
AI shouldn't be a shortcut that makes us skip the scenic route of learning. It should be a turbocharger for our own cognition.
The goal isn't to do less thinking. It's to achieve better thinking, faster.
Have you fallen into the "debug-the-AI" loop?
#AI #ProductManagement #ProjectManagement #ContinuousLearning #ArtificialIntelligence #Leadership #Skills #SoftwareDevelopment | 14 | 3 | 0 | 1mo | Post | Hicham El Hajj Boutros | https://www.linkedin.com/in/hicham-el-hajj-boutros-4a810136 | https://linkedin.com/in/hicham-el-hajj-boutros-4a810136 | 2025-12-08T07:19:56.414Z |  | 2025-11-05T19:50:05.593Z |  |  | 

---



---

# Hicham El Hajj Boutros
*Redbox Media*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Hicham El Hajj – Grindyzer](https://grindyzer.com/team/hicham-el-hajj/)
*2023-01-01*
- Category: article

### [Blog - RedBoxx](https://www.myredboxx.com/blog/)
*2024-06-10*
- Category: blog

### [Inside Redbox: Meet Sarmad Hassan, Redbox's Middle East Country Manager](https://www.sqli.com/int-en/insights-news/blog/inside-redbox-meet-sarmad-hassan-redboxs-middle-east-country-manager)
*2020-12-14*
- Category: blog

### [Arbaeah enhances the Arab podcast scene](https://www.redtech.pro/arbaeah-enhancing-the-arab-podcast-landscape/)
*2024-04-03*
- Category: podcast

### [Bridging gaps in global trade: An insightful interview with RedCloud’s Co-founder, Soumaya Hamzaoui](https://www.eu-startups.com/2024/01/bridging-gaps-in-global-trade-an-insightful-interview-with-redclouds-co-founder-soumaya-hamzaoui/)
*2024-01-02*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
