# Andy Mauro

## Position actuelle

**Titre** : Co-Founder & CEO
**Entreprise** : Storycraft
**Durée dans le rôle** : 2 years 11 months in role
**Durée dans l'entreprise** : 2 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Description du rôle

Storycraft is a social AI game that transforms every player into a creator. 

AI is unlocking new types of social creative experiences built on infinite abundance that increase empathy, and self-worth by showcasing how humans working together can create experiences that move beyond mere "content" into deeply enriching, diverse expressions of self. Storycraft is more than a game, it's a new type of entertainment company in which we can all discover and experience everyone's creativity!

Backed by Khosla Ventures, Signalfire, & Lvp

## Résumé

I've spent the last 24 years working on Conversational AI spanning phone based speech recognition, mobile voice assistants, conversational commerce, and now games. Obsessed with improving the state of the art to help create a world where technology lets us have conversations that are impossible today.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAhUjoBzfxrCumVqBQr-XWzz3FRqfDUXpI/
**Connexions partagées** : 273


---

# Andy Mauro

## Position actuelle

**Entreprise** : Storycraft

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Andy Mauro

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398341878250774528 | Article |  |  | Remarkable essay. AI will change our lives as much as the internet did after the 2000 bubble popped, but it’s looking like the AI bubble will have to pop before the rational business models and value creation arrive. 

This is why I rail against government propping up our local AI scene - we should be backing folks looking for business models our priority, not the folks fueled by insane amounts of VC and government cash who announce partnerships and government deals not product launches and revenue numbers. 

https://lnkd.in/eXrZ8nm2 | 13 | 0 | 0 | 2w | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:49.177Z |  | 2025-11-23T12:49:18.320Z | https://crazystupidtech.com/2025/11/21/boom-bubble-bust-boom-why-should-ai-be-different/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396602346958385152 | Article |  |  | I really admire my friend Lauren who was the first to discover the AI girlfriend use case (accidentally), but had the foresight, wisdom, and goodness to not milk it for all it was worth when she easily could have. She has the moral high ground here, I hope those who are contriving to unleash a plague of sexbots upon the world listen to her. | 27 | 1 | 0 | 2w | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:49.178Z |  | 2025-11-18T17:37:01.741Z | https://www.nytimes.com/2025/11/17/opinion/her-film-chatbots-romance.html?unlocked_article_code=1.108.n5OK.Wqs7YDkXQTW0&smid=url-share |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396178522613960704 | Article |  |  | Best essay I’ve read in a long time. Discusses how VC has largely become “Concensus Capital”, and the recent trend of funding slop startups and why now is the time for founders to pick worthwhile quests. Here’s hoping the pendulum swings back to the weird, contrarian, and purpose driven. I’m doing my part 😂 | 20 | 1 | 0 | 2w | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:49.179Z |  | 2025-11-17T13:32:54.143Z | https://investing101.substack.com/p/build-whats-fundable |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7392273866955386880 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D5605AQHLyMFsyS7hGw/feedshare-thumbnail_720_1280/B56ZpUVbIWJoA0-/0/1762351500261?e=1765774800&v=beta&t=w8vhWzq7UmdDgU4UMmbdCh8Yr-k3q_2SwwKHeFAKh7Y | This is 100% correct. Legal issues around AI models should be judged on their output not their input. We are all models, and our influences, and past consumption patterns define our own current day creativity, and AI is no different. | 18 | 1 | 0 | 1mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:49.180Z |  | 2025-11-06T18:57:11.689Z | https://www.linkedin.com/feed/update/urn:li:activity:7391838022838775808/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7389429092535922688 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFH6GZoVYPGng/feedshare-shrink_800/B56ZoxefPyIYAg-/0/1761766668222?e=1766620800&v=beta&t=Iw0iALm016HcUqxupAubYp0lLfwzqyaWlN7RunQxcEo | L. is doing something crazy interesting here - creating a lifetime membership social club for gamers and the people that make them. The implications are wild - check out the unhinged welcome video below! 🏍️ | 4 | 1 | 0 | 1mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:49.181Z |  | 2025-10-29T22:33:04.614Z | https://www.linkedin.com/feed/update/urn:li:activity:7389384989307564032/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7375644417749323777 | Article |  |  | I am taking Shreyas Doshi’s Product Sense course this weekend and with only 2 days / 25% complete all I can say to my founder friends is TAKE THIS EFFING COURSE! 🤯

Every product strategy (especially how product maps to distribution) I’ve ever seen is a 1/10 compared to the sky high bar Shreyas set today. Can’t wait for the upcoming week! 💫

https://lnkd.in/e6MhixnF | 50 | 2 | 1 | 2mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.820Z |  | 2025-09-21T21:37:42.038Z | https://maven.com/shreyas-doshi/product-sense/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7371187140170366976 | Text |  |  | Who's the best mobile games performance/growth marketer you know? Tag them in the comments, I want to talk to them! 📈 | 8 | 4 | 0 | 2mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.821Z |  | 2025-09-09T14:26:04.251Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7371015076994236416 | Article |  |  | I was fortunate to be at this event - it just got posted, there are some surprising takes and disagreements between Sam and Vinod, especially about education - worth a watch!

https://lnkd.in/ec_EemHf | 14 | 0 | 0 | 2mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.821Z |  | 2025-09-09T03:02:21.193Z | https://youtu.be/6NwK-uq16U8?si=0tE8xyauikpkRRC1 |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7369775276811030528 | Text |  |  | One of the best feelings as a leader is when people depart your organization because their personal purpose has begun to diverge from the company’s purpose, and they care enough about both to leave in a super positive way full of appreciation for what you’ve accomplished together, and excitement for what lies ahead individually!

Go get em Daniel Forstinger, and thanks for everything! | 26 | 1 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.821Z |  | 2025-09-05T16:55:49.795Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7368760284271890432 | Article |  |  | Dorian is cool, Julia is cool, this initiative is cool. 🧊 🧊 🧊 | 4 | 1 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.822Z |  | 2025-09-02T21:42:36.716Z | https://www.pocketgamer.biz/female-first-ugc-platform-dorian-partners-with-womens-game-fest/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7367255672163414016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHCaNSSR7Rilw/feedshare-shrink_800/B4EZj2__hAIMAg-/0/1756490627750?e=1766620800&v=beta&t=-21kHE7CJX7lh2NGtQKLkBKrWlAUixpRXC4trtTVIus | Absolute banger from Evan LaPointe who helped Storycraft setup our initial purpose driven culture. If you understand what he means come work with us! 

https://lnkd.in/eBDSQ-Tx | 23 | 2 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.822Z |  | 2025-08-29T18:03:49.235Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7366802981796724739 | Text |  |  | Expedia Group sucks so hard. Getting refunded for a full fare ticket is the most Kafka-esque customer support experience I’ve ever had. 🪳 

Say it three times. 

Book directly. 
Book directly. 
Book directly. | 17 | 1 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.823Z |  | 2025-08-28T12:04:59.441Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7366124366180278272 | Text |  |  | Hey gamedev friends, who are the best startup friendly codev shops out there, especially with a focus on mobile? 📱 | 3 | 4 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.823Z |  | 2025-08-26T15:08:24.870Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7366029000562876417 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEIRcep9b9aKA/feedshare-shrink_800/B56Zjiz6E.H8Ak-/0/1756151916176?e=1766620800&v=beta&t=8-6tXN5CUtqW3QyH1tAVa5FdAX4rBpnoOa8HSipskhk | If you’re a founder or an employee at an early stage startup this is worth a ponder 👀 

“You cannot hold certainty in your hand. You can only hold practice: finding problems, testing solutions, repeating until the rhythm takes shape. Progress is not made in sudden leaps but in the quiet compounding of contact with reality.” | 10 | 1 | 0 | 3mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.824Z |  | 2025-08-26T08:49:27.935Z | https://www.linkedin.com/feed/update/urn:li:activity:7365835015022104576/ |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7359165696347369474 | Text |  |  | If you’ll be at Gamescom hit me up, and let’s meet on the 20th! ☕️ 🍻 🌭 | 1 | 0 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.824Z |  | 2025-08-07T10:17:08.696Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7357179878439329792 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTRrJrrITE0A/feedshare-shrink_1280/B4EZhn0HFOHoAk-/0/1754088371598?e=1766620800&v=beta&t=urCMzkYQmUQKv7ONUqFFIvyz6ZpVkpCzGnNTgmFQ49E | This week in Storycraft 👇

1) we hired two total badasses 🤟🤟
2) my cofounder shipped an ai demo that is going to blow minds 🤯
3) our VP Eng vibe coded the single best hack I’ve ever seen 👨🏻‍💻
4) Product team launched a couple features that made our users literally clap with delight 👏 | 70 | 1 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.825Z |  | 2025-08-01T22:46:12.812Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7354859754730520578 | Text |  |  | The true genius of the Astronomer ad isn’t that it was clever it’s that it hit that sweet spot of making people feel clever for “getting it”. For a brief shining moment the b2b zoom sheep felt culturally relevant (said as former lifelong b2b zoom sheep 🐑) | 10 | 3 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.825Z |  | 2025-07-26T13:06:52.214Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7354630968529354752 | Text |  |  | Goddamn we are cooking up some awesome stuff! 🧑‍🍳 | 37 | 3 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.825Z |  | 2025-07-25T21:57:45.333Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7353128953911353346 | Text |  |  | Truth | 11 | 1 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.826Z |  | 2025-07-21T18:29:17.142Z | https://www.linkedin.com/feed/update/urn:li:activity:7353080318972608512/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7352321890599718915 | Article |  |  | We’re hiring! 👇 | 23 | 0 | 4 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.826Z |  | 2025-07-19T13:02:18.254Z | https://www.storycraft.gg/careers/senior-unity-game-developer |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7351313503904776192 | Text |  |  | These high production value fundraising announcement videos from young founders are the sign of something, and it ain’t good. 

Either, the bubble is bubbling. Or, I’m old. Both can be true. | 26 | 2 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.827Z |  | 2025-07-16T18:15:20.131Z |  |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7349528831965241347 | Text |  |  | I was a pitch mentor for Startupfest this year and the best company I saw was Qalam Health Solutions. Haitham Shoman has been training his whole life (1 MD, 2 Masters, 1 PhD and 1 MBA) to prevent unnecessary amputations and deaths from bone cancer. 🦴 

Happy to make intros to any investors in my network, I’ve never seen founder/market fit as strong as this one! 🧩 | 53 | 6 | 0 | 4mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.827Z |  | 2025-07-11T20:03:41.183Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7348106602282991616 | Text |  |  | We continue to bring top-tier games talent on board at Storycraft! When Jason Willig told me about his time working with David Grossman I knew we had to find a way to recruit him as our VP Engineering. The two of them have built some massive social mobile games together and their dynamic duo shorthand means they're hitting the ground running. I'm not sure which one is Batman and which one is Robin, but who cares when a team kicks this much ass! 🤜💥

Thanks for joining David, it's awesome having such an experienced mobile game dev leader who is also a badass dev and an early AI practitioner on the team! I'm really looking forward to working with you! 🤝 | 32 | 0 | 0 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.828Z |  | 2025-07-07T21:52:15.203Z | https://www.linkedin.com/feed/update/urn:li:activity:7348063864485310465/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7344043148018425860 | Text |  |  | This is a smart analysis that amounts to “Canadian VCs lack technical understanding relative to their US peers, so being risk averse is rational economic behavior”. 🤔

If you’re a founder this is just further reinforcement (from the source) that raising in the US should be your priority. 🇺🇸

It’s also great rationale for why Canadian financing should be capital match/round filling focused rather than lead focused. In fact, this research would indicate that having a Canadian VC lead is an anti-pattern for success because they aren’t technologists! 🤫 | 11 | 4 | 0 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.829Z |  | 2025-06-26T16:45:32.211Z | https://www.linkedin.com/feed/update/urn:li:activity:7343624953260294146/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7343403461939539970 | Article |  |  | I’m so into this. The future is people with dreams and undiscovered talent finding purpose and passion in creation because of AI, like Aline Godbout!

https://lnkd.in/eJtyDYjG | 10 | 0 | 1 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.829Z |  | 2025-06-24T22:23:39.165Z | https://open.substack.com/pub/lilijilabs/p/becoming-an-ai-pop-artist?r=itnpa&utm_medium=ios |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7341894645838147585 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fda69e51-8455-4f89-a762-7182a34f1a94 | https://media.licdn.com/dms/image/v2/D4E05AQH-6_zVbilBtw/videocover-high/B4EZeOmJHNHwB4-/0/1750444075771?e=1765774800&v=beta&t=ZivxB222n665lEYK1gPEulh_848UtvYiPIiLrZh96n0 | I’m at Ax-C Montreal’s thriving innovation hub! | 23 | 9 | 0 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.830Z |  | 2025-06-20T18:28:09.374Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7341624615670071297 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGwd-lHZ1SuDg/feedshare-shrink_800/B56ZeHwQ7SHoAg-/0/1750329267766?e=1766620800&v=beta&t=2aRbVY0sZGrPs5Si6sCvjUPL5dS3qLIazvdsgdrPG5A | Jason is the most connected person I’ve ever met in any industry, and is incredibly generous and helpful to founders. Storycraft might not have gotten off the ground without his help. This is a great get for Griffin and their founders. Congrats buddy! 🥃 | 13 | 2 | 0 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.830Z |  | 2025-06-20T00:35:09.165Z | https://www.linkedin.com/feed/update/urn:li:activity:7341413058579206147/ |  | 

---

## Post 28

https://www.linkedin.com/feed/update/urn:li:activity:7341036554116628480 | Document |  |  | Good list. 💪 | 6 | 1 | 1 | 5mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.831Z |  | 2025-06-18T09:38:24.365Z | https://www.linkedin.com/feed/update/urn:li:activity:7340719149939060736/ |  | 

---

## Post 29

https://www.linkedin.com/feed/update/urn:li:activity:7336932214879711234 | Article |  |  | This is the definitive masterclass on pitching from the man himself Vinod Khosla. A few of Arnaud Spuhler’s lovely slides from our seed deck even made it in which is kind of neat.

https://lnkd.in/e8CqrR79 | 31 | 4 | 0 | 6mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.831Z |  | 2025-06-07T01:49:13.636Z | https://www.khoslaventures.com/nail-your-raise-luring-vcs/ |  | 

---

## Post 30

https://www.linkedin.com/feed/update/urn:li:activity:7335657156035203072 | Article |  |  | Hey friends! We oversubscribed our seed round, have lots of money in the bank, and are ready to grow the team and accelerate -- if you know any awesome people, that are great at making games, and are leaning into AI, please send them our way - we're hiring a Systems Game Designer, Unity Game Developer, and a Product Manager! 

https://lnkd.in/gXA5jkpg | 119 | 11 | 13 | 6mo | Post | Andy Mauro | https://www.linkedin.com/in/andymauro | https://linkedin.com/in/andymauro | 2025-12-08T04:44:55.832Z |  | 2025-06-03T13:22:35.918Z | https://www.storycraft.gg/careers |  | 

---



---

# Andy Mauro
*Storycraft*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 13 |

---

## 📚 Articles & Blog Posts

### [Ep 8: Andy Mauro, Storycraft | Podcast | Boomplay](https://www.boomplay.com/episode/8429718)
*2024-11-07*
- Category: article

### [Andy Mauro - Co-founder & CEO at Storycraft | The Org](https://theorg.com/org/storycraft-1/org-chart/andy-mauro)
*2024-03-21*
- Category: article

### [Andy Mauro - Automat.ai « Phoenix Group](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai)
*2025-01-01*
- Category: podcast

### [Episode #17: Andy Mauro, Co-founder & CEO, Automat.ai | Le Wagon Live](https://shows.acast.com/lewagon-live/episodes/episode-17-andy-mauro-ceo-automat-ai)
*2019-04-25*
- Category: article

### [Andy Mauro - MIGS](https://migs.biz/fr/speakers/andy-mauro/)
*2025-09-04*
- Category: article

---

## 📖 Full Content (Scraped)

*10 articles scraped, 5,696 words total*

### Ep 8: Andy Mauro, Storycraft | Podcast | Boomplay
*1,030 words* | Source: **EXA** | [Link](https://www.boomplay.com/episode/8429718)

Ep 8: Andy Mauro, Storycraft | Podcast | Boomplay

===============

Loading...

 This site uses cookies. By using this site, you agree to our [Privacy Policy](https://www.boomplay.com/privacyPolicy/) and [EULA](https://www.boomplay.com/term/)

[Listen and download music for free on Boomplay](https://www.boomplay.com/)

[Download](https://www.boomplay.com/download)[Boomplay for artists](https://www.boomplay.com/BFA/#/authed/dashboard/overview)[](javascript:;)

**Log in /Sign up**

[Music](https://www.boomplay.com/)

[Home](https://www.boomplay.com/)[Trending](https://www.boomplay.com/trending-songs)[New](https://www.boomplay.com/new-songs)[Artists](https://www.boomplay.com/artists)[Videos](https://www.boomplay.com/video)[Playlists](https://www.boomplay.com/playlists)[Charts](https://www.boomplay.com/charts)[Genres](https://www.boomplay.com/genres)

Library

[Add Playlist](https://www.boomplay.com/addAPlaylist)[Favourites](https://www.boomplay.com/favourites)[My Playlists](https://www.boomplay.com/myPlaylists)

[Buzz](https://www.boomplay.com/buzz)

[Recommended](https://www.boomplay.com/buzz)

[Podcast](https://www.boomplay.com/podcasts)

[Recommended](https://www.boomplay.com/podcasts)

[](javascript:;)[](javascript:;)[Podcast](https://www.boomplay.com/podcasts)/[Ep 8: Andy Mauro, Storycraft](https://www.boomplay.com/episode/8429718)

![Image 2: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)

Ep 8: Andy Mauro, Storycraft
============================

[](javascript:;)

[**Game Founder Support Community![Image 3](https://www.boomplay.com/pc/img/arrow_right.svg)**](https://www.boomplay.com/podcasts/111015)

Play  01:10:03 Nov 07,2024 0 0

Episode Description
-------------------

Andy Mauro founded Storycraft in 2023 after spending a lot of time in the "chatbot" tech space, including a previously founded and exited company. He and I got to know each other through our mutual investor, London Venture Partners. I've always really enjoyed his insights from the tech side as he approaches building a game studio and merges his prior founding experience with being a lifelong gamer.Andy also has spent a lot of time both being and receiving Coaching and spends time in the episode to talk about how that experience has shaped him as a founder, and his team.

More >>
More Episodes
-------------

*   [![Image 4: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 38: Leah Hoyer, Level Headed Games**](https://www.boomplay.com/episode/10513414)
*   [![Image 5: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 37: Jon Selin, Low Drag Labs**](https://www.boomplay.com/episode/10372283)
*   [![Image 6: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 36: Jason Coleman, Sparkypants**](https://www.boomplay.com/episode/10345302)
*   [![Image 7: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 35, Ichiro Lambe, Totally Human Media**](https://www.boomplay.com/episode/10318765)
*   [![Image 8: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 34: Tina Merry, Simply Sweet Games**](https://www.boomplay.com/episode/10112170)
*   [![Image 9: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 33: Shifaz Sikander (Stone Lion Games)**](https://www.boomplay.com/episode/10056659)
*   [![Image 10: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 32: Matthew Manarino, SUMMONER**](https://www.boomplay.com/episode/10031653)
*   [![Image 11: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 31: Thea Chow, Redly Games**](https://www.boomplay.com/episode/10005350)
*   [![Image 12: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 30: Ben Carcich, Build Better Games**](https://www.boomplay.com/episode/9972210)
*   [![Image 13: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 29: Eamonn Glass, Maggie's Farm Studios**](https://www.boomplay.com/episode/9932021)
*   [![Image 14: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 28: Dru Erridge, Gamebreaking Studios**](https://www.boomplay.com/episode/9896735)
*   [![Image 15: Boomplay](https://source.boomplaymusic.com/group10/M00/09/24/8bb35215ec3647418321399f39f9d263H2500W2500_464_464.webp)0 **Ep 27: Stephane Cotichini, 81monkeys**](http

*[... truncated, 10,867 more characters]*

---

### Andy Mauro - Co-founder & CEO at Storycraft | The Org
*378 words* | Source: **EXA** | [Link](https://theorg.com/org/storycraft-1/org-chart/andy-mauro)

Andy Mauro - Co-founder & CEO at Storycraft | The Org

===============

[](https://theorg.com/ "The Org Home")

Platform

Features

[Pricing](https://theorg.com/pricing)

[Log in](https://theorg.com/login "Log in to The Org")[Sign up](https://theorg.com/signup "Sign up to The Org")

*   [![Image 1: Storycraft logo](https://cdn.theorg.com/debaea74-169c-4171-9e1c-9fbcef574701_thumb.jpg) Storycraft](https://theorg.com/org/storycraft-1)
*   Andy Mauro

Unverified

AM

Andy Mauro
==========

### Co-founder & CEO

Contact

Andy Mauro is the Co-Founder & CEO of Storycraft, a mobile multiverse platform that allows players to create and explore personalized game worlds with friends. Prior to Storycraft, Andy served as the Chief Technology & Product Officer at Salesfloor, where Andy led the product and engineering team in revolutionizing omnichannel retail. Andy also co-founded and served as CEO of Automat.ai, a company focused on creating personalized shopping experiences using Conversational AI. Andy has a strong background in technology and product management, with experience at companies like Nuance Communications and Nortel Networks. Furthermore, Andy has served as a mentor at Techstars, providing guidance to startups in the AI program.

Location

Montréal, Canada

Links

[](https://www.linkedin.com/in/andymauro "View on linkedIn")

Previous companies

[![Image 2: Techstars logo](https://cdn.theorg.com/24e0d68f-0272-4dcc-9bad-c870aecc7489_thumb.jpg)](https://theorg.com/org/techstars "Techstars")[![Image 3: Salesfloor logo](https://cdn.theorg.com/66fa608f-b12e-4b9a-bc34-71272b9bdd88_thumb.jpg)](https://theorg.com/org/salesfloor "Salesfloor")[N](https://theorg.com/org/nortel-technology "Nortel Technology")

* * *

Org chart
---------

AM

Andy Mauro

Co-founder & CEO

![Image 4: Adam Waselnuk's profile picture](https://cdn.theorg.com/ae4a3e66-5905-4432-a66e-acd72255f2fa_thumb.jpg)

Adam Waselnuk

Co-founder & CTO

* * *

Teams
-----

This person is not in any teams

* * *

Offices
-------

This person is not in any offices

* * *

Related people
--------------

*   [![Image 5: David Connors' profile picture](https://cdn.theorg.com/44cdcc69-7d5b-4699-92c0-bfa95e32154d_thumb.jpg) ![Image 6: Company logo](https://cdn.theorg.com/1129c42d-dd0c-4a40-8814-0ff48b80bce4_thumb.jpg) ### David Connors The Swarm](https://theorg.com/org/the-swarm/org-chart/david-connors) 
*   [![Image 7: Michael Brizendine's profile picture](https://cdn.theorg.com/cb60a7c2-9de4-40cf-a6ad-322ebd81b46f_thumb.jpg) ![Image 8: Company logo](https://cdn.theorg.com/442b29e5-2e3e-4728-9e47-39cf1db3e2ec_thumb.jpg) ### Michael Brizendine Scoop](https://theorg.com/org/scoop-chat/org-chart/michael-brizendine) 
*   [![Image 9: Janusz Dutkowski's profile picture](https://cdn.theorg.com/ba350fd4-1394-4ea5-9fe2-afeafb2a0148_thumb.jpg) ![Image 10: Company logo](https://cdn.theorg.com/e2d0b375-00f1-40ee-9b5d-4fd5689fa639_thumb.jpg) ### Janusz Dutkowski Data4Cure](https://theorg.com/org/data4cure/org-chart/janusz-dutkowski) 
*   [![Image 11: Kota Kubo's profile picture](https://cdn.theorg.com/ef4c8682-57ae-493e-aeaa-a23c708f77ec_thumb.jpg) ![Image 12: Company logo](https://cdn.theorg.com/a76e9624-5eaf-4dae-9a8d-970e3b2ea517_thumb.jpg) ### Kota Kubo Ubie](https://theorg.com/org/ubie/org-chart/kota-kubo) 
*   [![Image 13: Tavo Zambrano's profile picture](https://cdn.theorg.com/1ca6c21f-2ab7-4b40-af84-73297a011468_thumb.jpg) ![Image 14: Company logo](https://cdn.theorg.com/5f80c19a-e561-49e6-b2b0-110e37f15ee9_thumb.jpg) ### Tavo Zambrano Skydropx](https://theorg.com/org/skydropx/org-chart/tavo-zambrano) 

View more

[](https://theorg.com/ "The Org logo")

Company

[About](https://theorg.com/about "About")[Contact](https://theorg.com/contact "Contact")[Blog](https://blog.theorg.com/ "Blog")

Product

[Learn](https://theorg.com/learn-more "Learn")[Explore](https://theorg.com/explore "Explore")[Iterate](https://theorg.com/iterate "Iterate")

Business

[Solutions](https://theorg.com/solutions "Solutions")[Trust](https://theorg.com/trust "Trust")[Pricing](https://theorg.com/pricing "Pricing")

Enrich

[Browser Extension](https://theorg.com/browser-extension "Browser Extension")[CRM Enrichment](https://theorg.com/crm-enrichment "CRM Enrichment")[Developer Portal](https://theorg.com/developer-portal "Developer Portal")

Social

[](https://x.com/theorgcom "X (Twitter)")[](https://www.linkedin.com/company/theorg/ "LinkedIn")[](https://www.facebook.com/theorgcom "Facebook")[](https://www.instagram.com/theorgcom "Instagram")

© 2025 Orgio, Inc.

[Terms](https://theorg.com/terms "Read our terms and conditions")[Privacy](https://theorg.com/privacy "Read our privacy policy")[Do not sell my info](https://theorg.com/do-not-sell "Do not sell my info")

![Image 15: Cookiebot session tracker icon loaded](https://imgsct.cookiebot.com/1.gif?dgi=46b327ce-c3bf-4c3a-94d7-32411fa4e7b8)

---

### Andy Mauro - Automat.ai « Phoenix Group
*394 words* | Source: **EXA** | [Link](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai)

Andy Mauro - Automat.ai « Phoenix Group

===============

[![Image 1: Phoenix Group](https://thephoenixgroup.ca/res/img/logos/pg-logo.svg)](https://thephoenixgroup.ca/)

*   [What We Do](https://thephoenixgroup.ca/what-we-do)
*   [Us](https://thephoenixgroup.ca/us)
*   [Work](https://thephoenixgroup.ca/work)
*   [Our Causes](https://thephoenixgroup.ca/our-causes)
*   [Insights](https://thephoenixgroup.ca/insights)
*   [Careers](https://thephoenixgroup.ca/careers)
*   [Say hello](https://thephoenixgroup.ca/lets-talk)

[![Image 2: mobile navigation](https://thephoenixgroup.ca/res/img/icons/hamburger.svg)](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#sidr "Menu")

*   [Corporate Social Responsibility](https://thephoenixgroup.ca/what-we-do/corporate-social-responsibility)
*   [Strategy](https://thephoenixgroup.ca/what-we-do/strategy)
*   [Advertising](https://thephoenixgroup.ca/what-we-do/advertising)
*   [Digital](https://thephoenixgroup.ca/what-we-do/digital)
    *   [Search Engine Optimization](https://thephoenixgroup.ca/what-we-do/digital/seo)

*   [Design](https://thephoenixgroup.ca/what-we-do/design)

*   [Andy Mauro - Automat.ai](https://thephoenixgroup.ca/insights/podcast)
*   [Blog](https://thephoenixgroup.ca/insights)
    *   [Post not found.](https://thephoenixgroup.ca/insights/blog/item)

*   [Brand Strategy | Marketing & Advertising Agency | Phoenix Group](https://thephoenixgroup.ca/index)
*   [What We Do](https://thephoenixgroup.ca/what-we-do)[](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#)
    *   [Corporate Social Responsibility](https://thephoenixgroup.ca/what-we-do/corporate-social-responsibility)
    *   [Strategy](https://thephoenixgroup.ca/what-we-do/strategy)
    *   [Advertising](https://thephoenixgroup.ca/what-we-do/advertising)
    *   [Digital](https://thephoenixgroup.ca/what-we-do/digital)[](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#)
        *   [Search Engine Optimization](https://thephoenixgroup.ca/what-we-do/digital/seo)

    *   [Design](https://thephoenixgroup.ca/what-we-do/design)

*   [Us](https://thephoenixgroup.ca/us)
*   [Work](https://thephoenixgroup.ca/work)
*   [Our Causes](https://thephoenixgroup.ca/our-causes)
*   [Insights](https://thephoenixgroup.ca/insights)[](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#)
    *   [Andy Mauro - Automat.ai](https://thephoenixgroup.ca/insights/podcast)
    *   [Blog](https://thephoenixgroup.ca/insights)[](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#)
        *   [Post not found.](https://thephoenixgroup.ca/insights/blog/item)

*   [Careers](https://thephoenixgroup.ca/careers)
*   [Say hello](https://thephoenixgroup.ca/lets-talk)

#### LLM 46

Andy Mauro - Automat.ai
=======================

![Image 3: Andy Mauro - Automat.ai](https://thephoenixgroup.ca/pub/podcasts/bio-japan-dark-color-cropped.jpg)

What is conversational marketing? And how is artificial intelligence opening this up to marketers? And why is better to talk to your customers, rather than just monitor them?

Andy Mauro is the CEO of Automat.ai, a Montreal company applying artificial intelligence through messaging, for brands to communicate and connect with customers. Andy talks about the state of conversational marketing, and what automat.ai is doing. They are the company behind the much talked about Beauty Gifter by L'Oreal.

Andy and his team are creating 1-1 conversations with brands—moving away from targetting to talking. The objective of this marketing is helping you find the product that's best for you, using consultation and guidance.

We talk about the difference between digital marketing, chatbots,AI and a whole lot more. Enjoy the conversation!

**Host:** David Bellerive

**Runtime:** 38:44

 Your browser does not support HTML5 audio. 

[](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai#)[Download](https://thephoenixgroup.ca/pub/podcasts/LLM%2046%20Andy%20Mauro.mp3)[RSS](https://thephoenixgroup.ca/podcast/rss)[iTunes™](https://podcasts.apple.com/ca/podcast/lessons-learned-in-marketing/id1557027236)

Insights
--------

[![Image 4](https://thephoenixgroup.ca/pub/podcasts/Data-cropped.gif)](https://thephoenixgroup.ca/insights/podcast/llm-45-data-for-good)

### [Data For Good](https://thephoenixgroup.ca/insights/podcast/llm-45-data-for-good)

This month Data for Good opened a new chapter in Regina. David talks with Canadian Data for Good founder Joy Robson, Calgary's Data for Good lead,…

[![Image 5](https://thephoenixgroup.ca/insights/podcast/llm-46-andy-mauro-automatai)](https://thephoenixgroup.ca/insights/podcast/llm-44-nicole-siemens-fix-coffee-and-wesk)

### [Nicole Siemens fix coffee and WESK](https://thephoenixgroup.ca/insights/podcast/llm-44-nicole-siemens-fix-coffee-and-wesk)

Meet Nicole Siemens. Entrepreneur, founder of fix coffee, a business advisor with Women Entrepreneurs Saskatchewan and b

*[... truncated, 696 more characters]*

---

### Episode #17: Andy Mauro, Co-founder & CEO, Automat.ai | Le Wagon Live
*1,034 words* | Source: **EXA** | [Link](https://shows.acast.com/lewagon-live/episodes/episode-17-andy-mauro-ceo-automat-ai)

![Image 1: cover art for Episode #17: Andy Mauro, Co-founder & CEO, Automat.ai](https://open-images.acast.com/shows/5ad9fa6e4b7b3f235adbc977/1659708007384-86ca589e5082145bad5a9ca68c5f96f7.jpeg?height=750)

Episode #17: Andy Mauro, Co-founder & CEO, Automat.ai
-----------------------------------------------------

•

Thursday, April 25, 2019

Andy Mauro worked on some of the first speech recognition softwares ever made. Since then,he lives and breathes conversational marketing and today he is one of the most respected entrepreneurs in conversational AI. He is the co-founder of Automat, a Marketing Cloud platform that uses AI to allow companies to have personalized one-on-one messaging conversations with their customers to better understand and serve them. He shared with us his vision on AI, marketing and entrepreneurship.

Podcast and music production : yoann.saunier.me

#### More episodes

[#### View all episodes](https://shows.acast.com/lewagon-live/episodes)

*   [![Image 2](https://open-images.acast.com/shows/5ad9fa6e4b7b3f235adbc977/1659708072772-ab604457052865320ce11e8e008ebec7.jpeg?height=250)](https://shows.acast.com/lewagon-live/episodes/episode-67-roger-dudler-frontify-and-chrisian-reber-pitch)[Episode #67: Roger Dudler, Founder/CEO of Frontify & Christian Reber, Founder/CEO of Pitch ------------------------------------------------------------------------------------------](https://shows.acast.com/lewagon-live/episodes/episode-67-roger-dudler-frontify-and-chrisian-reber-pitch)
57:29|Thursday, July 14, 2022

Welcome to Le Wagon live. Our guests today are Roger Dudler, Founder & CEO of Frontify and Christian Reber, Founder & CEO of Pitch.Roger was previously a Software Engineer and Product Designer for over 10 years, before leading his organization to the forefront of brand management, with a powerful and holistic cloud-based experience.Christian previously founded the award-winning app, Wunderlist and is now an active investor and advisor in a number of technology businesses. He’s also received the Forbes 30 under 30 Award in both 2014 and in 2016.Learn more about their products and how they’ve come to work together.Podcast and music production: yoann.saunier.me 
*   [![Image 3](https://open-images.acast.com/shows/5ad9fa6e4b7b3f235adbc977/1568274952774-bd8fb1e1a79de3963ac9193e38d09687.jpeg?height=250)](https://shows.acast.com/lewagon-live/episodes/episode-66-nathan-larue-bliinx)[Episode #66: Nathan Larue, Co-Founder & CTO at Bliinx -----------------------------------------------------](https://shows.acast.com/lewagon-live/episodes/episode-66-nathan-larue-bliinx)
49:06|Thursday, November 11, 2021

Welcome to Le Wagon Live, our guest today is Nathan Larue, Co-Founder & CTO at Bliinx. Previously a software engineer at Ubisoft and Google, Nathan created Bliinx, a startup that syncs touchpoints and generates a 360° view of how you and your colleagues have interacted with contacts, projects or companies. Bliinx was recently accepted into the prestigious 500 Seed Accelerator, a program with a less than 1% acceptance rate.Learn more about Nathan’s journey from being a software engineer to becoming a successful entrepreneur.Podcast and music production: yoann.saunier.me 
*   [![Image 4](https://open-images.acast.com/shows/5ad9fa6e4b7b3f235adbc977/1659708007384-86ca589e5082145bad5a9ca68c5f96f7.jpeg?height=250)](https://shows.acast.com/lewagon-live/episodes/episode-65-pascale-audette-carebook)[Episode #65: Pascale Audette, CEO at Carebook ---------------------------------------------](https://shows.acast.com/lewagon-live/episodes/episode-65-pascale-audette-carebook)
39:38|Monday, October 4, 2021

Welcome to Le Wagon Live, our guest today is Pascale Audette, CEO at Carebook. A senior executive-turned-entrepreneur with over 20 years of business management experience including leading The Walt Disney Company’s Club Penguin. Pascale has an established track record of building teams of experts committed to sustainable growth.Carebook is a patient-focused, patient-facing platform for pharmacy and clinic groups that addresses the needs of health professionals and individuals.Dive into Pascale’s people-first vision for her healthcare platform, and her journey as an entrepreneur.Podcast and music production: yoann.saunier.me 
*   [![Image 5](https://open-images.acast.com/shows/5ad9fa6e4b7b3f235adbc977/1659708007384-86ca589e5082145bad5a9ca68c5f96f7.jpeg?height=250)](https://shows.acast.com/lewagon-live/episodes/episode-64-patrick-elie-metrio)[Episode #64: Patrick Elie, Co-Founder & CEO at Metrio -----------------------------------------------------](https://shows.acast.com/lewagon-live/episodes/episode-64-patrick-elie-metrio)
51:24|Wednesday, August 18, 2021

Welcome to Le Wagon Live! Our guest today is Patrick Elie, co-founder & CEO of Metrio, a certified B corp that helps businesses manage their ESG with sustainability reporting software. Patrick’s expertise lies in management, sustainability and data strategy, market

*[... truncated, 5,254 more characters]*

---

### Andy Mauro - MIGS
*516 words* | Source: **EXA** | [Link](https://migs.biz/fr/speakers/andy-mauro/)

Andy Mauro - MIGS

===============

We've detected you might be speaking a different language. Do you want to change to:

 EN 

 EN 

 FR 

[Change Language](https://migs.biz/en/speakers/andy-mauro/)

[](https://migs.biz/fr/speakers/andy-mauro/)

[Profitez du tarif prévente jusqu’au 17 octobre !](https://migs.biz/fr/register/) | [Take advantage of early bird pricing until October 17!](https://migs.biz/register/)

✕

[Aller au contenu](https://migs.biz/fr/speakers/andy-mauro/#content)

[![Image 2](https://migs.biz/wp-content/uploads/2023/06/MIGS25.svg)](https://migs.biz/fr)

[![Image 3](https://migs.biz/wp-content/uploads/2023/06/favicon2024@2x.png)](https://migs.biz/fr/)

[![Image 4](https://migs.biz/wp-content/uploads/2023/06/favicon2024@2x.png)](https://migs.biz/fr/)

*   [Exhibitor & Indie Map](https://migs.biz/fr/2025-exhibitors-indies/)
*   [À Propos](https://migs.biz/fr/#programming)
    *   [Planifiez Votre Visite](https://migs.biz/fr/plan-your-visit/)
    *   [Qui Participe](https://migs.biz/fr/who-attends/)
    *   [Foire aux questions](https://migs.biz/fr/faq/)
    *   [Le HUB ExDev](https://migs.biz/fr/exdev/)
    *   [Éditions précédentes](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2023](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2024](https://migs.biz/fr/migs-2024/)

    *   [Code De Conduite](https://migs.biz/fr/code-of-conduct/)
    *   [Kit médias](https://migs.biz/fr/press-kit/)
    *   [Gabarits médias sociaux](https://www.canva.com/design/DAG1BresHZo/qA9NOhqJhrIBuuioYPveUg/view?utm_content=DAG1BresHZo&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink&mode=preview)

*   [Programmation Indie](https://migs.biz/fr/)
    *   [MIGS25 Indie Pitch](https://migs.biz/fr/migs25-indie-pitch/)
    *   [Indie Pod](https://migs.biz/fr/indie-pod/)
    *   [2025 Publishers](https://migs.biz/fr/who-attends/#publishers)

*   [Programmation](https://migs.biz/fr/)
    *   [Conférenciers et conférencières de 2025](https://migs.biz/fr/2025-speakers/)
    *   [Programmation 2025](https://migs.biz/fr/2025-programming/)
    *   [Horaire 2025](https://migs.biz/fr/2025-schedule/)

*   [Sommet Audio](https://migs.biz/fr/audio-summit/)
*   [Journée Découverte Xbox](https://migs.biz/fr/xbox-discovery-day-migs/)

*   [Exhibitor & Indie Map](https://migs.biz/fr/2025-exhibitors-indies/)
*   [À Propos](https://migs.biz/fr/#programming)
    *   [Planifiez Votre Visite](https://migs.biz/fr/plan-your-visit/)
    *   [Qui Participe](https://migs.biz/fr/who-attends/)
    *   [Foire aux questions](https://migs.biz/fr/faq/)
    *   [Le HUB ExDev](https://migs.biz/fr/exdev/)
    *   [Éditions précédentes](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2023](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2024](https://migs.biz/fr/migs-2024/)

    *   [Code De Conduite](https://migs.biz/fr/code-of-conduct/)
    *   [Kit médias](https://migs.biz/fr/press-kit/)
    *   [Gabarits médias sociaux](https://www.canva.com/design/DAG1BresHZo/qA9NOhqJhrIBuuioYPveUg/view?utm_content=DAG1BresHZo&utm_campaign=designshare&utm_medium=link&utm_source=publishsharelink&mode=preview)

*   [Programmation Indie](https://migs.biz/fr/)
    *   [MIGS25 Indie Pitch](https://migs.biz/fr/migs25-indie-pitch/)
    *   [Indie Pod](https://migs.biz/fr/indie-pod/)
    *   [2025 Publishers](https://migs.biz/fr/who-attends/#publishers)

*   [Programmation](https://migs.biz/fr/)
    *   [Conférenciers et conférencières de 2025](https://migs.biz/fr/2025-speakers/)
    *   [Programmation 2025](https://migs.biz/fr/2025-programming/)
    *   [Horaire 2025](https://migs.biz/fr/2025-schedule/)

*   [Sommet Audio](https://migs.biz/fr/audio-summit/)
*   [Journée Découverte Xbox](https://migs.biz/fr/xbox-discovery-day-migs/)

*   [FR](https://migs.biz/fr/speakers/andy-mauro/)
*   [EN](https://migs.biz/en/speakers/andy-mauro/)

*   [FR](https://migs.biz/fr/speakers/andy-mauro/)
*   [EN](https://migs.biz/en/speakers/andy-mauro/)

[![Image 5](https://migs.biz/wp-content/uploads/2023/06/MIGS25.svg)](https://migs.biz/fr)

[![Image 6](https://migs.biz/wp-content/uploads/2023/06/favicon2024@2x.png)](https://migs.biz/fr/)

[![Image 7](https://migs.biz/wp-content/uploads/2023/06/favicon2024@2x.png)](https://migs.biz/fr/)

*   [Exhibitor & Indie Map](https://migs.biz/fr/2025-exhibitors-indies/)
*   [À Propos](https://migs.biz/fr/#programming)
    *   [Planifiez Votre Visite](https://migs.biz/fr/plan-your-visit/)
    *   [Qui Participe](https://migs.biz/fr/who-attends/)
    *   [Foire aux questions](https://migs.biz/fr/faq/)
    *   [Le HUB ExDev](https://migs.biz/fr/exdev/)
    *   [Éditions précédentes](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2023](https://migs.biz/fr/migs-2023/)
        *   [MIGS 2024](https://migs.biz/fr/migs-2024/)

    *   [Code De Conduite](https://migs.biz/fr/code-of-conduct/)
    *   [Kit médias](https://migs.biz/fr/press-kit/)
    *   [Gabarits médias sociaux](https://www.canva.com/design/DAG1BresHZo/qA9NOhqJhrI

*[... truncated, 4,171 more characters]*

---

### Podcast — Dashing Leadership
*29 words* | Source: **GOOGLE** | [Link](https://dashingleadership.com/podcast)

Podcast — Dashing Leadership

===============

[![Image 2: Dashing Leadership](https://images.squarespace-cdn.com/content/v1/5cc87d034d8711e64d60f09a/1571273479847-HERSYV8S8UPSX7SGPGV0/dashing_leadership_logo.png)](https://dashingleadership.com/)

[](https://dashingleadership.com/search)

[Home](https://dashingleadership.com/)[About](https://dashingleadership.com/about)[Services](https://dashingleadership.com/services)[Clients](https://dashingleadership.com/clients)[Podcast](https://dashingleadership.com/podcast)Resources[Blog](https://dashingleadership.com/blog)[Contact](https://dashingleadership.com/contact)

Back[Recommended Reading](https://dashingleadership.com/recommended-reading)[Newsletter](https://dashingleadership.com/newsletter)[FAQ](https://dashingleadership.com/faq)

[](https://www.twitter.com/brianmwang)[](https://www.linkedin.com/in/brianmwang)

[Home](https://dashingleadership.com/)[About](https://dashingleadership.com/about)[Services](https://dashingleadership.com/services)[Clients](https://dashingleadership.com/clients)[Podcast](https://dashingleadership.com/podcast)[Resources](https://dashingleadership.com/resources)[Recommended Reading](https://dashingleadership.com/recommended-reading)[Newsletter](https://dashingleadership.com/newsletter)[FAQ](https://dashingleadership.com/faq)[Blog](https://dashingleadership.com/blog)[Contact](https://dashingleadership.com/contact)

[![Image 3: Dashing Leadership](https://images.squarespace-cdn.com/content/v1/5cc87d034d8711e64d60f09a/1571273479847-HERSYV8S8UPSX7SGPGV0/dashing_leadership_logo.png)](https://dashingleadership.com/)

Executive coaching for startup founders

[brian@dashingleadership.com](mailto:brian@dashingleadership.com "brian@dashingleadership.com")

Hours

[](https://www.twitter.com/brianmwang)[](https://www.linkedin.com/in/brianmwang)

---

### Founder’s Quest
*480 words* | Source: **GOOGLE** | [Link](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes)

[![Image 1: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-38-leah-hoyer-level-headed-273631117)"Today we’re talking with Leah Hoyer of Level Headed Games. Leah’s founding mom...November 20, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----1:05:47s
[![Image 2: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-37-jon-selin-low-drag-labs-270195340)"Today we’re talking with Jon Selin of Low Drag Labs. Jon shares his journey of...October 23, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----1:03:49s
[![Image 3: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-36-jason-coleman-sparkypant-269411262)"Today we're talking with Jason Coleman, founder of Sparkypants Studios. Jason ...October 16, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----1:00:04s
[![Image 4: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-35-ichiro-lambe-totally-hum-268738245)"Today we're talking with Ichiro Lambe, founder of Totally Human Media. This is...October 10, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----1:03:57s
[![Image 5: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-34-tina-merry-simply-sweet-263962917)"Today we’re talking with Tina Merry, of Simply Sweet Games which was founded i...August 28, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----48:19s
[![Image 6: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-33-shifaz-sikander-stone-li-262506882)"Today, we’re talking with Shifaz Sikkander, of Stone Lion Games. Shifaz shares...August 14, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----47:17s
[![Image 7: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com/64x64/aHR0cHM6Ly9wYmNkbjEucG9kYmVhbi5jb20vaW1nbG9nby9pbWFnZS1sb2dvLzE5Mzk4NjA0L2ZvdW5kZXJzLXF1ZXN0Ml9oenNxenEucG5n/aHR0cHM6Ly93d3cucG9kY2hhc2VyLmNvbS9pbWFnZXMvbWlzc2luZy1pbWFnZS5wbmc%3D)](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes/ep-32-matthew-manarino-summone-261855391)"Today we’re talking with Matthew Manarino of SUMMONER, a game focused creative...August 7, 2025[Business](https://www.podchaser.com/categories/business/podcasts)[Entrepreneur](https://www.podchaser.com/categories/entrepreneur/podcasts)[Video Games](https://www.podchaser.com/categories/video-games/podcasts)----58:18s
[![Image 8: Ep 27: Stephane Cotichini, 81monkeys](https://cachedimages.podchaser.com

*[... truncated, 7,571 more characters]*

---

### Consumer | SignalFire
*526 words* | Source: **GOOGLE** | [Link](https://www.signalfire.com/sectors/consumer)

![Image 1](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/65248f7dc942b9346729637e_64c251163e9978bb79b1f762_6475f037171f8371848505bb_placeholder-image.svg)

![Image 2](https://www.signalfire.com/sectors/consumer)

No items found.

![Image 3: Adam Waselnuk](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6542d7b1728696c8f3e89560_hKgJhFLJ_400x400.jpeg)

Adam Waselnuk

CTO

![Image 4](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6542d7b1728696c8f3e89564_storycraft-logo-pink.svg)

"SignalFire went above and beyond for us when we needed to hire our founding team. I've worked closely with some of the best talent acquisition people in the world and SignalFire still managed to blow my expectations out of the water. I honestly can't imagine how hard it would have been without them. When SignalFire says they will help you tactically they really mean it!"

Sector Companies
----------------

Nim

![Image 5](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/67991a4ac2517a0db99a26b8_Nim-logo-main.png)

Exit

Founder(s)

Yury Lifshits

Partner Since

Sector

Status

Current

Storycraft

![Image 6](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/654acba56975133bb186063c_storycraft-logo.png)

Exit

Founder(s)

Andy Mauro

Partner Since

Sector

Status

Current

Tempo

![Image 7](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0aa0e937a889dc9bc4d_tempo-logo_fujhd9.png)

Exit

Founder(s)

Joshua Augustin, Moawia Eldeeb

Partner Since

Sector

Status

Current

Ro

![Image 8](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a8343cb0b372b7ec98_ro-logo_mtxwlx.png)

Exit

Founder(s)

Rachel Blank, Rob Schutz, Saman Rahmanian, Zachariah Reitano

Partner Since

Sector

Status

Current

RedCircle

![Image 9](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a8343cb0b372b7ec91_redcircle-logo_yrvbwb.png)

Exit

Founder(s)

Jeremy Lermitte, Michael Kadin

Partner Since

Sector

Status

Current

Monarch

![Image 10](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a5fbcb1d43f4f179ff_monarch-logo_ckgdfa.png)

Exit

Founder(s)

Jonathan Sutherland, Osman Ahmed Osman, Val Agostino

Partner Since

Sector

Status

Current

Lime

![Image 11](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a5fc5d3c38cd7b5a75_lime-logo_bey7p8.png)

Exit

Founder(s)

Adam Zhang, Brad Bao, Caen Contee, Charlie Gao, Toby Sun

Partner Since

Sector

Status

Current

Karat

![Image 12](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a4d2a972bbed2d9d65_karat-logo_r20nnj.png)

Exit

Founder(s)

Eric Wei, Will Kim

Partner Since

Sector

Status

Current

Grammarly

![Image 13](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a2fbcb1d43f4f177a4_grammarly-logo_yxh5fv.png)

Exit

Founder(s)

Alex Shevchenko, Dmytro Lider, Max Lytvyn

Partner Since

Sector

Status

Current

Form Health

![Image 14](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/654ac86fa3c6b3b219da7283_form-logo-2.png)

Exit

Founder(s)

Evan Richardson

Partner Since

Sector

Status

Current

ClassDojo

![Image 15](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a093ecb919a179221f_classdojo_k8jyxl.png)

Exit

Founder(s)

Liam Don, Sam Chaudhary

Partner Since

Sector

Status

Current

Clubhouse

![Image 16](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a0a064988597e90e5562_clubhouse_l9gucb.png)

Exit

Founder(s)

Paul Davison, Rohan Seth

Partner Since

Sector

Status

Current

Aura

![Image 17](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/654aca2f8387ece45bc5fb20_aura-logo-2.png)

Exit

Founder(s)

Hari Ravichandran

Partner Since

Sector

Status

Current

Apostrophe

![Image 18](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6541a09f1f47c285a01c7abd_apostrophe_cvhykl.png)

Exit

Founder(s)

Ben Holber, Chris Minnich, Ryan Hambley

Partner Since

Sector

Status

Exited

![Image 19: SignalFire’s Creator Economy Market Map](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/6525e72a774d8856e91a2b3a_64ba5e45d6fe425eb92d801a_SignalFire-Creator-Economy-Featured-Image-e1607906771958%2520(1).png)

May 3, 2024

### SignalFire’s Creator Economy Market Map

The creator economy is the class of businesses centered around 50 million+ independent content creators, curators, and community builders including social media influencers, bloggers, and videographers, plus the software and finance tools designed to help them with growth and monetization.

Read more

![Image 20: How EvenUp’s AI gets justice for personal injury victims](https://cdn.prod.website-files.com/6516123533d9510e36f3259c/654c78fb89c1cf46d8533664_ec1e5697-8dbc-4240-b1c8-68fcf9f11f57.jpeg)

June 8, 2023

### How EvenUp’s AI gets justice for personal injury victims

After investing in EvenUp’s seed round and leading the Series A, SignalFire is backing its $50.5M Series B to launch an AI legal a

*[... truncated, 1,000 more characters]*

---

### From Toronto's Startup Open House to Montreal's Tech Scene
*735 words* | Source: **GOOGLE** | [Link](https://blog.techto.org/p/from-toronto-s-startup-open-house-to-montreal-s-tech-scene)

**You are receiving the Community Edition of today’s newsletter —****[upgrade to a Member](https://www.techto.org/memberships?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)****to receive additional perks and experiences**

📷 **RECAP**
------------

What a week. A lot has happened, so here’s a quick rundown of the highlights.

We helped to bring **Startup Open House** to Toronto, and brought together more than 100 startups and 2500+ people to discover the startups and businesses building right here in the city.

Here’s some great recaps that capture the day:

We also closed out the night with the most epic After Party.

##### **More updates from all things SOH coming soon, stay tuned…**

✨**WE’RE COMING TO MONTREAL**
-----------------------------

![Image 1](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/e311cfcf-81a5-4069-9496-4abacf13acfd/Screenshot_2025-09-30_at_9.53.14_AM.png?t=1759240409)

#### **Join us for a week of innovation and connection**✨

Get ready! We're coming back to **Montreal** from **October 20-24** for an electrifying event series.

This isn't your average collection of meetups; it's a strategically designed week to **ignite, instruct, and inspire** the city's current and future innovators.

Here’s what’s on the calendar for the week and everything we’ve recently announced:

#### **DAY ONE: Monday, October 20**

**Success Stories and Lessons for Founders**

The centerpiece event, [**Made In Montreal: From Bagels to Billion-Dollar Ideas**](https://luma.com/sy5ef4xj?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene) hosted at **[HEC Montréal](https://www.hec.ca/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)**, aims to explore the unique journey of building a global enterprise from the city. This session will provide founders with invaluable **lessons** drawn from icons **[Harley Finkelstein](https://www.linkedin.com/in/harleyf/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)** (Shopify) and **[David Segal](https://www.linkedin.com/in/david-segal-80b6079/?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)** (David’s Tea), showcasing success stories that validate Montreal's potential as a global tech hub. It’s a deep dive into the practical realities of **building in Montreal**, leveraging its distinct cultural and academic strengths.

[![Image 2](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/b913ddf9-1a64-4115-a381-8e07f836863f/Screenshot_2025-10-14_at_9.43.32_AM.png?t=1760449428)](https://www.linkedin.com/posts/harleyf_montreal-is-proof-you-can-build-billion-dollar-activity-7376320005325602816-iJrF?utm_source=share&utm_medium=member_desktop&rcm=ACoAABbZgWwBXpM0og8n2-3_as_H9YotgRhK6wk)

#### **DAY TWO: Tuesday, October 21**

**Fundraising, Pitching, and Investing**

For founders seeking capital, the series provides direct routes to investors. The **[Boast Funding Stage](https://luma.com/mtl-funding-stage-?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)**and the **[Venture Showcase](https://luma.com/venture-showcase-MTL?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)** are critical events focusing on **pitching** and **fundraising today**. These stages allow emerging companies to present their vision directly to venture capitalists and strategic partners, driving crucial connections for securing seed, growth, or Series A funding.

**Only 3 spots left for the Venture Showcase!** Make sure you register!

[![Image 3](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,format=auto,onerror=redirect,quality=80/uploads/asset/file/88ef4159-1316-46cf-a1a6-66384ba6d942/Screenshot_2025-10-14_at_9.46.00_AM.png?t=1760449598)](https://www.linkedin.com/posts/alexanderlnorman_montreal-are-you-ready-to-pitch-were-partnering-activity-7383517198264274945-zS4R?utm_source=share&utm_medium=member_desktop&rcm=ACoAABbZgWwBXpM0og8n2-3_as_H9YotgRhK6wk)

#### **DAY THREE: Wednesday, October 22**

**Market Overviews and Tech Trends**

To ensure founders are building for the future, TechTO is offering specialized **Market Overview** sessions that dissect high-growth verticals. Sessions like the **[Market Overview — Gaming Tech](https://luma.com/mtl-mo-gamingtech-oct-22-2025?utm_source=blog.techto.org&utm_medium=referral&utm_campaign=from-toronto-s-startup-open-house-to-montreal-s-tech-scene)** and **[Market Overview — Travel](https://luma.com/mtl-mo-travel-oct-22-2025?utm_source=blog.techto.or

*[... truncated, 4,944 more characters]*

---

### Market Overview - Gaming Tech @ TechTO HQ at Espace CDPQ · Luma
*574 words* | Source: **GOOGLE** | [Link](https://luma.com/mtl-mo-gamingtech-oct-22-2025)

​Market Overview: Gaming Tech
-----------------------------

​A 2-hour deep dive on Gaming Tech, this event will feature a market outlook and a review of several innovations leading the way.

​Gaming is no longer just entertainment - it’s shaping culture, technology, and the future of digital interaction. From AI-driven game design and immersive VR/AR experiences to esports, web3, and new monetization models, gaming tech continues to push boundaries and attract global investment.

​At this Market Overview, we’ll break down where the industry stands today and where it’s headed next. You’ll get a clear picture of market trends, funding patterns, and the innovations transforming how games are built, distributed, and played.

* * *

​**Agenda**
-----------

*   ​​​**1:00 - 1:20pm**: Arrivals & Networking

*   ​​​**1:20 - 1:50pm:**Research presented by Research Partner

*   ​**1:50 - 2:00pm:**Peer Discussion

*   ​​​**2:00 - 2:10pm:**#1 Founder Presentation

*   ​**2:10 - 2:20pm:**#2 Founder Presentation

*   ​**2:20 - 2:30pm:**#3 Founder Presentation

*   ​​**2:30 - 3:00pm:** Fireside Chat

* * *

​**Featured Speakers**
----------------------

​**[Andy Mauro](https://www.linkedin.com/in/andymauro/)** is the **Founder and CEO of****[Storycraft](https://www.storycraft.gg/)**, a game that lets players create and tell stories together using AI. Previously, he founded and exited Automat an e-commerce chatbot startup, and ran global AI innovation at speech recognition pioneer Nuance.

​**[Guillaume Therien](https://www.linkedin.com/in/guillaumetherien/overlay/about-this-profile/)** is a **Managing Partner at****[Triptyq Capital](https://www.linkedin.com/company/triptyq-capital/)**, a $40M seed-stage venture fund based in Montréal. Triptych is investing in technology companies reshaping the future of media & entertainment, supported by world-class infrastructure, accelerator programs and imposing group of experts, partners and mentors.

Triptyq Capital is aiming to propel bold founders fully committed to be part of the transformation of the entertainment industry.

​Triptych is also working as our research partner for this event.

​

​**[François Pelland](https://www.linkedin.com/in/francoispelland/?originalSubdomain=ca)** is currently the CEO of LocusX, a company that develops AI-powered tools for debugging game code.In this role, he leads the company's efforts to create solutions that solve what he describes as "one of the most frustrating and expensive parts of the process" of game development. He has stated that LocusX's "issue resolution engine" can identify and propose fixes for programming bugs.

​Prior to his current role, he was a Senior Executive Producer at Google and was the Head of Production Operations, First Party Game Strategy for Google Stadia. He is also a veteran of the gaming industry with over 20 years of experience as an AAA blockbuster game producer for franchises such as _Splinter Cell_ and _Assassin's Creed_.

​

​**[David Chartrand](https://www.linkedin.com/in/david-chartrand-35221333/?originalSubdomain=ca)** is the founder and CEO of **Squido Studio**, a video game company based in Montreal, Canada.Founded in 2019, Squido Studio specializes in developing virtual reality games. The company has raised over $4 million in funding.

​

* * *

​**[Brandon Weinman-Tyre](https://www.linkedin.com/in/brandon-tyre/)** is the CEO and co-founder of Rivr, an AI-driven social intelligence platform transforming how we understand and act on content at internet scale. With a background at the intersection of technology and media, Brandon is passionate about building ambitious teams, scaling infrastructure, and finding elegant solutions to complex problems.

​**Thank You To Our Venue Partner:**
------------------------------------

​[espace cdpq](https://espacecdpq.com/en)

* * *

​**Thank You To Our Community Partner:**
----------------------------------------

​[La base entrepreneuriale HEC Montréal](https://labase.hec.ca/)

* * *

​**Interested in more events?**

**Envie de découvrir d’autres événements?**
----------------------------------------------------------------------------

​Check out [TechTO's full Montreal event calendar here.](https://luma.com/TechTOMontreal?k=c)

​Découvrez le calendrier complet des [événements TechTO à Montréal ici.](https://luma.com/TechTOMontreal?k=c)

​This event is part of [OHMTL 2025](https://www.ohmtl.com/) - Montreal’s tech week of builders.

​Cet événement fait partie de [OHMTL 2025](https://www.ohmtl.com/) - La semaine tech montréalaise des bâtisseurs.

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Podcast — Dashing Leadership](https://dashingleadership.com/podcast)**
  - Source: dashingleadership.com
  - *... Storycraft. Andy's challenge is to balance a grand vision with effective ... Andy Mauro 51:27 Episode Artwork #002: Reinventing Yourself After Sta...*

- **[Episodes of Founder's Quest | Podchaser](https://www.podchaser.com/podcasts/founders-quest-5837531/episodes)**
  - Source: podchaser.com
  - *Ep 26: Pitching Deep Dive with Andy Mauro (Storycraft)....*

- **[Consumer | SignalFire](https://www.signalfire.com/sectors/consumer)**
  - Source: signalfire.com
  - *Storycraft. Exit. Storycraft. https://www.storycraft.gg/ · Read Case Study. Founder(s). Andy Mauro. Partner Since. Seed. Sector. AI/ML Tools · Consume...*

- **[From Toronto's Startup Open House to Montreal's Tech Scene](https://blog.techto.org/p/from-toronto-s-startup-open-house-to-montreal-s-tech-scene)**
  - Source: blog.techto.org
  - *Upcoming EventsFounder's Journey PodcastQuick Takes Podcast. Login ... GAMING SPEAKERS: Get excited to hear from, Andy Mauro (Storycraft), Francois .....*

- **[Market Overview - Gaming Tech @ TechTO HQ at Espace CDPQ ...](https://luma.com/mtl-mo-gamingtech-oct-22-2025)**
  - Source: luma.com
  - *Oct 22, 2025 ... ​Andy Mauro is the Founder and CEO of Storycraft, a game that lets players create and tell stories together using AI. Previously, he ...*

- **[Prosperity For Every Generation](https://www.prosperityforeverygeneration.ca/)**
  - Source: prosperityforeverygeneration.ca
  - *Francois Fournier, Podcast creator, Les Productions Ian et Frank inc., Lévis ... Andy Mauro, CEO, Storycraft, Montréal. Artem Chaykovskyy, Associate ....*

- **[Players As Creators. UGC in the Age of AI - MIGS](https://migs.biz/en/sessions/players-as-creators-ugc-in-the-age-of-ai/)**
  - Source: migs.biz
  - *In this talk, Andy Mauro (CEO of Storycraft) explores how AI-powered creativity is opening up new gameplay paradigms, why storytelling is the missing ...*

- **[Andy Mauro - MIGS](https://migs.biz/fr/speakers/andy-mauro/)**
  - Source: migs.biz
  - *Andy Mauro. CEO @ Storycraft. À propos du·de Andy. Andy is a serial founder who has been working on AI products for 20 years, first launching Nina a ....*

- **[Storycraft – LVP](https://londonvp.com/our-portfolio/storycraft/)**
  - Source: londonvp.com
  - *Andy Mauro. Founder & CEO. Headquarters. Quebec, Canada. Website & Jobs. https://www.storycraft.gg/. Storycraft exist to help anyone tell their storie...*

- **[AI Salon Montreal #2: Championing Representation in AI ...](https://www.nicholasnadeau.com/2025/2025-03_ai-salon-montreal-2-representation-matters-md)**
  - Source: nicholasnadeau.com
  - *Mar 31, 2025 ... We championed Women in AI, highlighted by Cassie Rheaume's powerful keynote ... Andy Mauro (Storycraft): Turning players into creator...*

---

*Generated by Founder Scraper*
