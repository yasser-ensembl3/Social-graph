# Azad Abbasi

## Position actuelle

**Titre** : Founder and CEO
**Entreprise** : GeniusXR
**Durée dans le rôle** : 18 years 11 months in role
**Durée dans l'entreprise** : 18 years 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Software Development

## Description du rôle

VR / AR / MR / Spatial 
Immersive builders since 2014. We are highly specialized and experienced in Spatial content and platform development.

## Résumé

Founder & CEO of GeniusXR. Immersive Experiences

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAApHDccBC_eZyYVJrxh0Wi7aeGmJ4nlIeuc/
**Connexions partagées** : 200


---

# Azad Abbasi

## Position actuelle

**Entreprise** : GeniusXR

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Azad Abbasi

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401338729883213825 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHcYf3BxvSuLQ/feedshare-shrink_800/B4EZrbWWs_IoAg-/0/1764616662808?e=1766620800&v=beta&t=CsAvq8bQ9aSJFwCtUxrkWshuA82yys3J4Pl2pdj0wFo | Took me 10 seconds to create what would take atleast 12 hours a few years ago. Created with Gemini Nano Banana Pro. Prompt = "Create Infographic for UVRSE" #GenAI #NanoBanana #UVRSE UVRSE | 19 | 0 | 3 | 6d | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:35.943Z |  | 2025-12-01T19:17:43.428Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397268695342882816 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bee5fc01-252e-45e7-826f-477f853e8b77 | https://media.licdn.com/dms/image/v2/D4E05AQHch9iOahPJNw/videocover-high/B4EZqhgoIvKMBU-/0/1763646278067?e=1765778400&v=beta&t=EQFrkAYWM4cTF1l2weEO6f2dSn5Q_Ve1PdqE5nawe3Y | Stoped by our partner studio at COlab Innovation sociale et culture numérique for a fresh calibration of the volumetric capture stage.

Next step: we’re installing a new GPU render farm to support faster, scalable 3D / 4D (Animated) content production. 

The research team at Collège d'Alma is already producing incredible 3D volumetric content for education — from training simulations to immersive learning tools. They’re using our UVRSE tools to deliver outputs for video, VR, and interactive experiences.

Exciting things are happening in Québec. More soon. 📍

This Sony x GeniusXR Rig has a volume of 8'x8'x8' with 75 Sony RX0II Synced Cameras for 4K Video Capture + 70 Soft Box LED Lights with Controllers for Practical Lighting or Relighting in Post-Production. Feel free to ask me any questions you might have and if you want to book a demo at one of our four volumetric capture studios. 


#4D #VolumetricCapture #UVRSE #DigitalEducation #GeniusXR
#CollègeDAlma #ColabNumérique #RenderFarm #VirtualProduction
#SpatialComputing #ImmersiveLearning #XR #FutureOfEducation #VirtualReality #AugmentedReality #XR #Immersive #Interactive #Education #Trainning Rich Destiny | 61 | 7 | 5 | 2w | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:35.945Z |  | 2025-11-20T13:44:51.576Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7394476524378427392 | Video (LinkedIn Source) | blob:https://www.linkedin.com/dde9e1ce-d0f7-4792-8086-384915c0c367 | https://media.licdn.com/dms/image/v2/D5605AQEbayAWb5vNyA/videocover-high/B56Zp5EqNAKABU-/0/1762967862705?e=1765778400&v=beta&t=5I48-i08QBHz__cQpiAjgN5smoISIXR-qioEXcSCzjo | 💯🔥 | 3 | 0 | 0 | 3w | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.562Z |  | 2025-11-12T20:49:46.142Z | https://www.linkedin.com/feed/update/urn:li:activity:7394423255362658304/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7394476342458732544 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6817e152-9b74-450d-84f4-2f88e3515ee8 | https://media.licdn.com/dms/image/v2/D4E05AQF52RmdeIF4Zg/videocover-low/B4EZp5IX.RKgBQ-/0/1762968832320?e=1765778400&v=beta&t=aHu8jg7C4epzQucIcP2NZOWlprzFaOggA9SA6daLIuU | 💥💥💥 | 7 | 0 | 0 | 3w | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.563Z |  | 2025-11-12T20:49:02.769Z | https://www.linkedin.com/feed/update/urn:li:activity:7394427253272657920/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7394386202914873345 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0c5b5187-ba46-4dd4-9546-d8feacd4a3f9 | https://media.licdn.com/dms/image/v2/D4E05AQE6bHRd6Zh16g/videocover-low/B4EZp4i4N8IICI-/0/1762959033698?e=1765778400&v=beta&t=tbXOasX8cKceLbVzKv5NYpSmklCpTvkzRfWKCsobjpI | From Volumetric Studio to Space Station. This is my long time friend Vishal Urva, captured in 4D during his appearance on my upcoming podcast episode of Unified Reality.

We froze a single frame…
Processed it with our UVRSE volumetric pipeline and dropped him into a space station — built in minutes with Marbles by World Labs

No VFX. No post. Just raw 4DGS + AI worldbuilding = instant spatial previz.
Now imagine what we can do for films, games and XR !
Soon coming to a screen near you. 

Captured at GeniusXR x UVRSE Montreal Lab

This is what the future of digital media feels like.
Fast. Spatial. Interactive. Real.

#VishalUrva #UnifiedReality #4DGS #VolumetricCapture #DigitalTwin
#GeniusXR #UVRSE #WorldLabs #Marbles #VirtualProduction
#SpatialComputing #ImmersiveMedia #AIWorldbuilding #NextGenStorytelling #XR #FutureOfContent #PodcastPreview #SpaceStation #3dgaussiansplats #4dgaussiansplats Rich Destiny | 22 | 3 | 4 | 3w | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.564Z |  | 2025-11-12T14:50:51.827Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7394130410403966976 | Video (LinkedIn Source) | blob:https://www.linkedin.com/abcca8a6-c992-4a4e-9acf-dd7ceef42513 | https://media.licdn.com/dms/image/v2/D4E05AQHIVikO7KkEbw/videocover-high/B4EZp00YhYKYBU-/0/1762896482168?e=1765778400&v=beta&t=ZXVHZEJLhH0-BSRTgZNBXazDMQb7Qpp1lIw9C1resfE | Today at #MIGS25 | 2 | 0 | 0 | 3w | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.565Z |  | 2025-11-11T21:54:26.140Z | https://www.linkedin.com/feed/update/urn:li:activity:7394123799287316480/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7392772008909905920 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGOHKTUOy4Z7w/feedshare-shrink_800/B4EZphm9RLHgAg-/0/1762574196116?e=1766620800&v=beta&t=9FJx_hcnEEUs6SfB9vXeFx2UkqomIElRjXy54ni7is4 | Last year we captured Monk-E before the podcast. Here are the results of the scan in 3D Gaussian Splats. 

Captured in our volumetric studio. Background built from his own art. This is 1 single frame from a volumetric scan of Monk-E — visual artist, poet, MC — placed in a fully explorable 6DOF 3D environment. GeniusXR & UVRSE

https://lnkd.in/ebkWZ6ZU 


#VolumetricCapture
#4DGS
#GeniusXR
#UVRSE
#WorldLabs
#SpatialComputing
#DigitalTwin
#GraffitiArt
#ImmersiveMedia
#XR
#VirtualProduction
#AIBackgrounds
#NextGenStorytelling
#ImageTo3D
#FutureOfContent
#Marbles
#6DOF
#3dgaussiansplats
#gaussiansplats
#3dgs
#3dgaussiansplatting | 22 | 0 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.566Z |  | 2025-11-08T03:56:37.986Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7392713762140549120 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEdpws_2p6AUg/feedshare-shrink_1280/B4EZpgx_k4HUAs-/0/1762560310183?e=1766620800&v=beta&t=SdWkTzZcTTf11rFKDWpID7HPLH4iALTXLQ4TVtXnbII | See you at MIGS next week! | 6 | 0 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.567Z |  | 2025-11-08T00:05:10.874Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7392269043069779968 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5c21db19-3c1a-4f1c-af8b-3a167ab40f89 | https://media.licdn.com/dms/image/v2/D4E05AQFLVZsBo0ngcw/videocover-low/B4EZpadVE_GYCE-/0/1762454267546?e=1765778400&v=beta&t=lqc1X16w8OZN_9_Ghx8zaB890GCGGyCkmQfc8w8w8oU | 🎤 Monk-E — Frozen in 4D. Captured in our volumetric studio. Background built from his own art. This is 1 single frame from a volumetric scan of Monk-E — visual artist, poet, MC — placed in a fully explorable 6DOF 3D environment. GeniusXR & UVRSE

The twist? We took one of his graffiti murals from Instagram…
Ran it through Marbles by World Labs… And generated a full 3D world around it — in minutes.

No post. No cleanup.
Just raw 4DGS + AI worldbuilding = PREVIZ
Imagine what’s next when culture, tech, and tools like this collide.

#MonkE #VolumetricCapture #4DGS #GeniusXR #UVRSE
 #WorldLabs #SpatialComputing #DigitalTwin #GraffitiArt
 #ImmersiveMedia #XR #VirtualProduction #AIBackgrounds
 #NextGenStorytelling #ImageTo3D #FutureOfContent #Marbles #6DOF #3dgaussiansplats #gaussiansplats #3dgs #3dgaussiansplatting 
Rich Destiny Brian Seth Hurst | 47 | 0 | 5 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.570Z |  | 2025-11-06T18:38:01.585Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7386796747806900224 | Video (LinkedIn Source) | blob:https://www.linkedin.com/bd205817-e6ba-47b0-a935-cb1f1b3d8f99 | https://media.licdn.com/dms/image/v2/D4E05AQEkdVXvAa4giA/videocover-low/B4EZoMsWGmHEB4-/0/1761149564183?e=1765778400&v=beta&t=gOSlT7A64HXblPvIwwABAGeCjf-Z7ZN9ERKmanUrw_Y | 🎮 Part Deux: 4DGS Now in Game Mode ! What started as real-time, in-browser volumetric video is now a fully navigable interactive 3D experience. Keyboard + mouse control is live. You can now walk around, look around, and explore dynamic 4DGS captures — in real-time.

Captured in our volumetric video studio in Montreal, processed in 4DGS, and dropped into a fully dynamic 6DOF AI environment created in minutes with World Labs.

World Las' Marbles allows you to prompt or upload an image and create have a full 3D background within minutes that you can export in:
- Low-Res SPZ
- High-Res SPZ
- PLY (3D Gaussian Splats)
- GLB collider mesh for 3D interaction
- 360° equirectangular image for immersive previews or skyboxes

GeniusXR x UVRSE x World Labs

DM me for the dev link + pipeline details.

#4DGS #Dynamic3DGS #3DGS #VolumetricCapture #Realtime3D #DigitalTwin #WorldLabs #Marbles #ImmersiveWeb #WebXR
#GeniusXR #UVRSE #SpatialComputing #GameDev #GLB #Equirectangular
#VolumetricVideo #FutureOfContent #VirtualProduction #InteractiveXR #3D #GameMode #3dGaussianSplats #GaussianSplats #VirtualProduction | 30 | 3 | 3 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.575Z |  | 2025-10-22T16:13:04.724Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7386742720557531138 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQN5BM1AXubQ/feedshare-shrink_800/B4EZoL7XEyKgAk-/0/1761136702765?e=1766620800&v=beta&t=i1qXtmnJY-pMTLLbodYXzaCGOoeNb9pGzV0vVPqHl3k | Déjà vu… or a second chance? With the launch of the new Samsung (Android XR) headset, I can’t help but think back to when we worked closely with Samsung on the 360 Round and SamsungVR.

We built content. We pushed boundaries. We live-streamed in 360.
And it felt like the future was right there.

But what happened? Was it timing? Was the market not ready?
Or maybe… people just weren’t ready to strap a computer to their face?

Now, nearly a decade later — headsets are back. XR is booming. Volumetric is real. AI is in the driver’s seat.

So here’s the question: Did we just need better tech — or a better story?
Curious to hear your thoughts.

#XR #SamsungVR #Throwback #SpatialComputing #360Video #VolumetricCapture #VirtualReality #NABShow #GeniusXR #Innovation #TechTiming #FutureOfMedia #AndroidXR #Android #XR GeniusXR UVRSE | 5 | 1 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.577Z |  | 2025-10-22T12:38:23.624Z |  |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7386410046294798336 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQE6WrNBHunyzA/videocover-low/B4EZoHMq2_JgB8-/0/1761057376226?e=1765778400&v=beta&t=sN9QbLHoKS58RcW4dQuC3ZtsewGFI-QjBorQpWt_K5k | ☁️ Sky Realms x 4DGS — Fast Previz with Zero Post 🎮 Meet my Digital Twin & Victoria Vallejo Villa — captured at our volumetric studios in Montreal and dropped into a surreal Sky Realms World created in just minutes with World Labs.

No VFX was done in this shot. It’s a real-time 4DGS frozen frame — straight out of the pipeline. No post-production.

Captured in 4D using multi-cam volumetric at GeniusXR × UVRSE
AI-generated background created in minutes using an Image as input with World Labs

Perfect for previs, pitch decks, and XR workflows that move fast... But that is just the beginning. Virtual Production will #Disrupt #ContentCreation

Scan Human. Build World. Export. This is the new speed of creative production. The Future is Today. 

#4DGS #3DGS #DigitalTwin #VolumetricCapture #WorldLabs #GeniusXR #UVRSE #AIWorldbuilding #Previz #VirtualProduction #Realtime3D #ImmersiveMedia #XR #FutureOfContent #VolumetricVideo #GameDev #VFX #ProductionTech #VirtualProduction #Virtual #Production #VirtualReality #AugmentedReality #Film #3DGaussianSplats #GaussianSplats Rich Destiny GeniusXR UVRSE | 32 | 2 | 7 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.579Z |  | 2025-10-21T14:36:27.899Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7384591927444258816 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQEb2D0XYKE_TQ/videocover-low/B4EZntXE7vIwB4-/0/1760623897408?e=1765778400&v=beta&t=Xc1Fr8hkMC4UoQm9Dedexjl4AM33Cpla8QHrAtwvZc8 | Frozen in 3DGS 🏈🍁 Rodrigo — repping his 49ers gear, frozen mid-flex in a quick volumetric video scan, placed inside a full 3D (6DOF) dreamy, autumn park — generated in minutes with World Labs.

Just a hint of color matching — No VFX. No polish. All raw pipeline.

Captured at our Montreal volumetric studio GeniusXR x UVRSE
Background built with World Labs . Next level World-Building. 

Imagine this scene — animated, spatial, and in real-time. 
This is how fast storytelling is changing.

What you're seeing is straight from the pipeline — a glimpse at what’s possible before the polish.

Just a still. But packed with motion, attitude, and style.
More frames. More movement. More madness coming soon.

#3DGS #3dGaussianSplats #4DGS #VolumetricCapture #DigitalTwin #WorldLabs #GaussianSplats #GeniusXR #UVRSE #AIWorldbuilding #3DGaussianSplats #VolumetricVideo #SpatialComputing #VirtualProduction #XR #FutureOfContent #NextGenStorytelling #NFLStyleXR #ImmersiveMedia #RealTime3D #3DScan #VirtualProduction
Rodrigo Vergara Rich Destiny | 28 | 5 | 2 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.581Z |  | 2025-10-16T14:11:54.586Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7383143297843634181 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQFgDUYjvT_tiw/videocover-low/B4EZnYxsQ7IwB4-/0/1760278530941?e=1765778400&v=beta&t=Jbkxz6zy7lKjPzCzOGGQwN_te9UYUmEryKvQLodj6WY | Having fun with #Sora2 #4DStream | 12 | 0 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:39.584Z |  | 2025-10-12T14:15:34.375Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7382408642744193024 | Article |  |  | Something we built on the side... UVRSE
https://lnkd.in/e4kJ9pZd | 9 | 1 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:43.397Z |  | 2025-10-10T13:36:18.950Z | https://play.google.com/store/apps/details?id=com.uvrse&hl=en |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7382397992441487360 | Text |  |  | Who will be at MIGS? Montréal [Nov.11-12] | 0 | 0 | 0 | 1mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:43.398Z |  | 2025-10-10T12:53:59.720Z | https://www.linkedin.com/feed/update/urn:li:activity:7303543023366287361/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7380627391347322881 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQFWi7cbpBdshw/videocover-low/B4EZm1BW00IoB4-/0/1759678661795?e=1765778400&v=beta&t=u3_a0eJfmQCatDCgtZewRMphByrg1LUJys39IAm6IEw | Skater & Baller VR Comparisson in the Meta Quest from almost a year ago.
Showcasing the difference between a Dynamic Photogrammetry Sequence and a Dynamic 3D Gaussian Splat Sequence. Playback is at 30FPS and interpolated to 72/90hz in VR Headsets.

1- Skater Jump (50 Frames) Comparison: Videogrammetry (old pipeline) VS Dynamic 3D Gaussian Splats (new pipeline)

2- Dynamic 3D Gaussian Splat Sequence of Basketball Player

3- Photogrammetry + AI Rig + AI Animations (old pipelines)

#3DGS #4DGS #VolumetricCapture #SkaterVR #BasketballVR #VRContent
 #Photogrammetry #DigitalTwin #VirtualProduction #SpatialComputing
 #UVRSE #GeniusXR #Sony #VolCap #ImmersiveMedia #XR #VRGaming
 #GaussianSplats #FutureOfContent

Captured at GeniusXR x UVRSE 3D/4D Virtual Production Facilities in Montréal (Québec) Rich Destiny | 28 | 0 | 3 | 2mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:43.401Z |  | 2025-10-05T15:38:15.523Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7380244163214348288 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQE-KwqdkC_hjg/videocover-low/B4EZmsWpqhKcB4-/0/1759533277915?e=1765778400&v=beta&t=_7h46aWu201HAoGCs6aUK3xDbMxC4qp0erhloB7xfa8 | https://lnkd.in/eyJjXeP3 | 1 | 0 | 0 | 2mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:43.401Z |  | 2025-10-04T14:15:26.816Z | https://www.linkedin.com/feed/update/urn:li:activity:7380017524706340864/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7380017524706340864 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQE-KwqdkC_hjg/videocover-low/B4EZmsWpqhKcB4-/0/1759533277915?e=1765778400&v=beta&t=_7h46aWu201HAoGCs6aUK3xDbMxC4qp0erhloB7xfa8 | From the studio to the summit — in 4D. Welcome to the new era of Virtual Production. Placed high above the clouds — on Mount Everest. Meet Drezus — award-winning Indigenous artist. We captured him in our volumetric studio at GeniusXR × UVRSE, then dropped him into a fully dynamic 3D Everest scene — built in minutes using World Labs.

This is just a still frame. A teaser.
But it shows what happens when cultural storytelling meets spatial tech.
From ceremony to cyberspace.
From voice to volume.
This is the new era of digital presence.

#4DGS #VolumetricCapture #Drezus #IndigenousFuturism #SpatialComputing #DigitalTwin #WorldLabs #GeniusXR #UVRSE #AIWorldbuilding #GaussianSplats #XR #VirtualProduction #ImmersiveMedia #FutureOfContent #NextGenStorytelling #VirtualProduction #Virtual #DigitalTwin #GenAI #AI #DeepTech

4K Version on YT
https://lnkd.in/eKay3Syi | 25 | 4 | 4 | 2mo | Post | Azad Abbasi | https://www.linkedin.com/in/azadabbasi514 | https://linkedin.com/in/azadabbasi514 | 2025-12-08T05:09:43.403Z |  | 2025-10-03T23:14:51.985Z |  |  | 

---



---

# Azad Abbasi
*GeniusXR*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 17 |
| Press & Mentions (Google) | 7 |

---

## 📚 Articles & Blog Posts

### [Spatially Aware Podcast - Episode 2 With Azad - Bringing Puzzling Places To Apple Vision Pro](https://www.youtube.com/watch?v=kwo89wW1eHg)
*2024-03-08*
- Category: video

### [“We realised that the only thing we can master is the ability to adapt to change”](https://aurora.dawn.com/news/1145315/we-realised-that-the-only-thing-we-can-master-is-the-ability-to-adapt-to-change)
*2025-01-10*
- Category: article

### [Why I Leave Work at 5 p.m. Every Day - Azad Abbasi - Medium](https://medium.com/@azadabba/why-i-leave-work-at-5-p-m-every-day-c875b7fe099)
*2017-04-12*
- Category: blog

### [GeniusXR - VR - AR - MR - AI - Augmented & Virtual Reality - GXR LAB  Montreal](https://www.geniusxr.ai/?lang=fr)
*2025-05-31*
- Category: article

### [Volumetric Capture Studio in South Florida — GeniusXR - VR - AR - MR - AI - Augmented & Virtual Reality - GXR LAB  Montreal](https://www.geniusxr.ai/work/florida-volumetric-capture-studio)
*2024-01-01*
- Category: article

---

## 🎬 YouTube Videos

- **[192 - Interview with Azad Abbasi of Genius XR](https://www.youtube.com/watch?v=bWxYn2PAooU)**
  - Channel: Digital Oil and Gas
  - Date: 2021-03-10

- **[Immersive Retail   Events – Genius XR](https://www.youtube.com/watch?v=Tm7UA6uYA3k)**
  - Channel: Creator HQ
  - Date: 2021-11-03

- **[Kyle Nel speaking about Innovation Labs at C2 Montreal](https://www.youtube.com/watch?v=lGrcdUKymJc)**
  - Channel: GeniusXR
  - Date: 2018-05-10

- **[Notte Bianco - Traiteur Buonanotte - Genius Marketing](https://www.youtube.com/watch?v=KitxVIKB4os)**
  - Channel: GeniusXR
  - Date: 2014-08-02

- **[C2 Montreal: Emerging Technologies, Human Capital And Their Impact On Innovation](https://www.youtube.com/watch?v=lWxfgCV6ExQ)**
  - Channel: GeniusXR
  - Date: 2017-10-24

- **[Unified Reality Ep.6: Building a Fitness Empire: Insights from Sio Khayami (Gold&#39;s Gym Québec CEO)](https://www.youtube.com/watch?v=HP0sleS9sDc)**
  - Channel: GeniusXR
  - Date: 2024-12-16

- **[Unified Reality Ep.6: Building a Fitness Empire: Insights from Sio Khayami (Gold&#39;s Gym Québec CEO)](https://www.youtube.com/watch?v=jJAEjQqGiT0)**
  - Channel: GeniusXR
  - Date: 2024-12-16

- **[Unified Reality Ep.9: Reinventing Retail: Digital Fashion and Eyewear with Bodo Sidès](https://www.youtube.com/watch?v=SgLEhhoWUII)**
  - Channel: GeniusXR
  - Date: 2025-01-06

- **[Unified Reality Ep.9: Reinventing Retail: Digital Fashion and Eyewear with Bodo Sidès](https://www.youtube.com/watch?v=LS7GzaHfOxg)**
  - Channel: GeniusXR
  - Date: 2025-01-06

- **[Mon Défi Minceur - Demo video - Genius Marketing](https://www.youtube.com/watch?v=uY5LS6h4dEE)**
  - Channel: GeniusXR
  - Date: 2014-08-01

---

## 🔎 Press & Mentions

- **[Azad Abbasi | Founder & CEO - Genius XR | Forbes Agency Council](https://councils.forbes.com/profile/Azad-Abbasi-Founder-CEO-Genius-XR/c119f979-7d7f-41f2-b838-b8f4964e4c3d)**
  - Source: councils.forbes.com
  - *Azad Abbasi. Founder & CEOGenius XR. Montreal, QC, Canada. language. Skills ... GeniusXR is a full service XR creative and development agency. We are ...*

- **[Web3 et le métavers : donner le pouvoir aux créateurs de demain ...](https://ctvm.info/web3-et-le-metavers-donner-le-pouvoir-aux-createurs-de-demain/)**
  - Source: ctvm.info
  - *Jul 12, 2022 ... ... GeniusXR Azad Abbasi et l'animateur de podcast Reynaldo Mendoza. Vous pouvez faire partie du public en direct. Nous discuterons d...*

- **[RDV eCommerce](https://rdvecommerce.com/montreal-ecommerce-event8-20220510/)**
  - Source: rdvecommerce.com
  - *May 10, 2022 ... GeniusXR est bel et bien dans la nouvelle ère de l'internet, le Web3 ... Avec présentation de plusieurs cas de type détaillant. Azad ...*

- **[4DGS in Medical XR & Virtual Production | Volumetric Capture ...](https://www.youtube.com/watch?v=kNbjKm_2tTY)**
  - Source: youtube.com
  - *Aug 8, 2025 ... ... Azad Abbasi | GeniusXR | UVRSE #VolumetricCapture #4D ... Non-ADHD Child Interview. Mental Health Matters•26M views · 16:08 · Go t...*

- **[Unified Reality Ep.6: Building a Fitness Empire: Insights from Sio ...](https://www.youtube.com/watch?v=HP0sleS9sDc)**
  - Source: youtube.com
  - *Dec 15, 2024 ... ... Azad Abbasi unpack what it takes to succeed in today's dynamic ... GeniusXR.ai www.UVRSE.io Stay tuned for more game-changing ......*

- **[Program - 3DBODY.TECH 2025](https://3dbody.tech/docs/3dbody2025_program.pdf)**
  - Source: 3dbody.tech
  - *Oct 22, 2025 ... 3DBODY.TECH Conference & Expo · Lugano, Switzerland · 21-22 ... Azad ABBASI. GeniusXR, Montreal QC, Canada #58. Session Chair: Gerald...*

- **[Volumetric Capture Studio in South Florida — GeniusXR - VR - AR ...](https://www.geniusxr.ai/work/florida-volumetric-capture-studio)**
  - Source: geniusxr.ai
  - *... GeniusXR and Sony, following their initial project at College D'Alma in Northeast Canada. Our CEO, Azad Abbasi, highlights the studio's significan...*

---

*Generated by Founder Scraper*
