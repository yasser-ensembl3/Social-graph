# Patrick Fauquembergue

## Position actuelle

**Titre** : Fondateur - Président
**Entreprise** : Magasin Général / Shipping Distribution
**Durée dans le rôle** : 11 years 3 months in role
**Durée dans l'entreprise** : 11 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAM-RlEB8wsbyK1B69w8mu2brNe1GLufYyg/
**Connexions partagées** : 67


---

# Patrick Fauquembergue

## Position actuelle

**Entreprise** : Magasin Général / Shipping Distribution

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Patrick Fauquembergue

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7403544604727566337 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQE1qemD-8XXbw/feedshare-shrink_800/B56Zr6si28L4Ao-/0/1765142581436?e=1766620800&v=beta&t=XY50Qnh1oAtJu0HQvDq4zWJiTToaW8p0KD78gr9jW3Y | C’est parti pour une semaine de rencontre à Rio pour le World Congress of Science and Factual Producers. Il y a pire comme endroit! Magasin Général | 11 | 2 | 0 | 8h | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:32.292Z |  | 2025-12-07T21:23:04.974Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402366284941918208 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGvSXf3Pa27gw/feedshare-shrink_800/B4EZrp855YIwAg-/0/1764861649417?e=1766620800&v=beta&t=F-aURl_siVY6RAMYAug7Kl4_B8B0cWc7PYlZqc-eUqw | C'est parti pour une nouvelle production de Magasin Général. Le nouveau documentaire de Guillaume Sylvestre. Avec Dylan Page, Cyrielle Deschaud, Daniel Morin, Eve Bastien, Valléry Rousseau. Possible grace Geneviève Arseneau et TV5 Québec Canada, SODEC - Société de développement des entreprises culturelles, Canada Media Fund | Fonds des médias du Canada et au Fond Rogers. | 37 | 1 | 0 | 3d | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:32.293Z |  | 2025-12-04T15:20:51.645Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400134046359502848 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFQ_fF_DwoBZQ/feedshare-shrink_800/B4EZrG8pY9KoAk-/0/1764274381913?e=1766620800&v=beta&t=yoxNfjJu9szPeqIAedICr2z57jvDRyOkxYPHeYFymPs | Salut Riyad et Doha. Plein de projets intéressants pour le Magasin Général! Thank you Edgard Jinbachian for all your help, wisdom…and good food! 
Le meilleur est à venir! | 40 | 0 | 0 | 1w | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:32.293Z |  | 2025-11-28T11:30:44.494Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7398982776416460801 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGPbXJ3aoTBBA/feedshare-shrink_800/B56Zq53eiVJUAg-/0/1764054954787?e=1766620800&v=beta&t=NL0eMgsvu68vaozkCPIYura_dFrsOtmPTfPfS2kfn6Q | Salut Al Ula, à bientôt sur des écrans. Soon on a few screens near you! Paul Carrière, Michel Lam, Dylan Page, Luc Robida, Dom St-Amant, Tobias Haynes, Philippe Chabot, Edgard Jinbachian, Marie Christine Pinault Desmoulins.

Magasin Général | 40 | 2 | 0 | 1w | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:32.294Z |  | 2025-11-25T07:16:00.350Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7392254359730036736 | Article |  |  | WOW!!! Quel honneur! Le documentaire Race for the Arctic (La fonte des frontières) est nominé aux prestigieux Buzzies du World Congress of Science and Factual Producers- WCSFP dans la catégorie Best Natural History Program.
Je capote un peu de me ramasser dans cette liste avec autant de bons projets. Magasin Généraldans une catégorie avec David Attenborough...Juste ça, c'est une victoire!!!! RDV à Rio le 11 décembre!

Un énorme accomplissement possible grace à Daniel Morin, Philippe Chabot, Tilman Remme, Gary Lang, Penelope Lawrence, Enrique Careaga, Dylan Page, Tania Cooper, Rich Williamson, Andrew Sheppard, Jason Porter, Valléry Rousseau, Lianne Marie Gagne. Sans oublier l'équipe de Radio-Canada qui a su accompagné le projet à travers vents et marées. Merci Marie Lambert-Chan, Barbara Plourde, Mélissa Girard, Melissa Dinel. Un merci particulier à michel scheffer ainsi que l'équipe de WDR et l'équipe de distribution de Federation Studios et l'explorateur Robert Salvestrin! 

Pour voir le film sur ICI Tou.tv, il est en commentaire.

===

WOW!!! What an honor!
Our documentary Race for the Arctic has been nominated for the prestigious Buzzies at the World Congress of Science & Factual Producers (WCSFP) in the category Best Natural History Program.
I’m freaking out seeing our name alongside so many great projects. Magasin Général in the same category as David Attenborough… that alone feels like a victory!!! See you in Rio on December 11!

This huge accomplishment was only possible thanks to Daniel Morin, Philippe Chabot, Tilman Remme, Gary Lang, Penelope Lawrence, Enrique Careaga, Dylan Page, Tania Cooper, Rich Williamson, Andrew Sheppard, Jason Porter, Valléry Rousseau, and Lianne Gagné.
And of course, to the amazing Radio-Canada team who supported the project through every challenge — thank you Marie Lambert-Chan, Barbara Plourde, Mélissa Girard, Mel Dinel, as well as our partners at WDR and the Federation Studios distribution team.

To watch the film on ICI Tou.tv, the link is in the comments.

https://wcsfp.com/node/61 | 44 | 8 | 1 | 1mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:32.294Z |  | 2025-11-06T17:39:40.804Z | https://wcsfp.com/node/61 |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7344292614835200000 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFRz41YfhX1w/feedshare-shrink_800/B4EZewrKYMHcAg-/0/1751015805398?e=1766620800&v=beta&t=h2BdB6a2EMuCDORrMaF1gzpbVwKiDG1oCmsPsK4Pcdc | Fin de séjour à Paris après un petit passage pour voir les amis de l’UNESCO. :) De retour avec plein de projets! Magasin Général Daniel Morin | 38 | 0 | 0 | 5mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.661Z |  | 2025-06-27T09:16:49.735Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7342915834010324993 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEoJF3iSOSIQg/feedshare-shrink_800/B56ZedG_.9HUAo-/0/1750687555928?e=1766620800&v=beta&t=4vUFV7UfIs6ImZNgzr1tYN3IuYir5lBSMxsFAiPxnLY | De retour au @Sunnyside à La Rochelle! Plein de nouveaux projets à venir :) avec Tilman Remme Daniel Morin Magasin Général Telefilm Canada SODEC - Société de développement des entreprises culturelles | 47 | 2 | 1 | 5mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.661Z |  | 2025-06-23T14:05:59.607Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7323798461584220161 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpulBYnG522g/feedshare-shrink_800/B4EZaDWG5JHIAs-/0/1745960335919?e=1766620800&v=beta&t=mqzdsBL44GtZaTcVZQwCFywFsVEeVXk1utOHeUrUr-o | Super nouvelle!! Pauline Boisbouvier reçoit le prix l'entreprenariat féminin de la Fondation Guy Laliberté accompagné d'une bourse pour HINT.  Bravo meilleure co-fondatrice!!!! Cette reconnaissance est 100% la tienne. You rock :) | 30 | 6 | 0 | 7mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.662Z |  | 2025-05-01T20:00:22.837Z | https://www.linkedin.com/feed/update/urn:li:activity:7323088427887845376/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7323049239964495873 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGEMKWUB-i7Rw/feedshare-shrink_800/B4EZaCq5oDIAAg-/0/1745949223668?e=1766620800&v=beta&t=QoJnsbHid_KExs1UONaZapFylCZArhFElV7J1AAYzCI | C’est un départ de Riyad après 10 jours de rencontres, de tournage, d’explorations et de nouvelles collaborations en Arabie Saoudite! Plein de potentiel dans ce pays qui change à vu d’oeil!

It’s a departure from Riyadh after 10 days of meetings, filming, explorations, and new collaborations in Saudi Arabia! Full of potential in this country that is changing before our eyes!

Magasin Général | 37 | 1 | 0 | 7mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.662Z |  | 2025-04-29T18:23:14.483Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7321197825634037761 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFmULGGl-UMSg/feedshare-shrink_800/B4EZZoajKDH0Ak-/0/1745509580125?e=1766620800&v=beta&t=JgnlQ7sN6EI2RZqDP_0NzVIQtS1MrGwOjQmKm_T0_UE | Super heureux de pouvoir lancer un nouveau projet avec des gens si talentueux! À venir bientôt! #AlUla | 44 | 2 | 0 | 7mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.663Z |  | 2025-04-24T15:46:22.909Z |  |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7299905539818369024 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHY7b7EM7KERg/feedshare-shrink_800/B56ZU55XTiGQAk-/0/1740433099681?e=1766620800&v=beta&t=nsaNfel559TA5m0NBaEo-CR74O6SNsPti4KSNiR_hiw | Énorme plaisir d'avoir pu présenter le documentaire Matimekush ce week-end en compagnie de l'équipe du film. Guillaume Sylvestre, Dylan Page, Vincent Guignard, Conrad André Kapesh, Jean François Banipo, Judly Durena. Un grand merci à la communauté de Matimekush et l'École Kanatamat. Le film prendra l'affiche en Avril. | 44 | 2 | 1 | 9mo | Post | Patrick Fauquembergue | https://www.linkedin.com/in/patrickfauquembergue | https://linkedin.com/in/patrickfauquembergue | 2025-12-08T06:11:34.663Z |  | 2025-02-24T21:38:26.379Z |  |  | 

---



---

# Patrick Fauquembergue
*Magasin Général / Shipping Distribution*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Table des matières Table of Contents](https://ridm.ca/uploads/document/catalogue_ridm_2020_web.pdf)
*2020-11-01*
- Category: article

### [Quarante Nuances de Retail | Pierre Faury | Substack](https://pierrefaury.substack.com/)
*2023-05-16*
- Category: blog

### [Pierre Faury on Substack](https://substack.com/@pierrefaury/note/c-17211642)
*2023-06-12*
- Category: blog

### [About - Quarante Nuances de Retail](https://pierrefaury.substack.com/about)
*2023-05-16*
- Category: blog

### [Logistics and Supply Chain at La Redoute](https://www.lokad.com/tv/2022/12/14/logistics-and-supply-chain-challenges-at-la-redoute/)
*2022-12-14*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
