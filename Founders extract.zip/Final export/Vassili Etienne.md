# Vassili Etienne

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Floppy Goat Inc.
**Durée dans le rôle** : 3 years 3 months in role
**Durée dans l'entreprise** : 3 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Computer Games

## Description du rôle

Secretary and Vice-President

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA_C5poB4e0P9_m2n2t9Je07dclVfOHG2ic/
**Connexions partagées** : 1


---

# Vassili Etienne

## Position actuelle

**Entreprise** : Floppy Goat Inc.

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Vassili Etienne

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7396226242405998592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHpi1aCS9uF5g/feedshare-shrink_800/B4EZqSpVu8GcAg-/0/1763396902916?e=1766620800&v=beta&t=r1iaN0FMbi0hr0RABKizxtlsSPFWj9lL0Sa9exDPc3w | 🎂Il y a 16 ans, je découvrais la Ville de Montréal à travers une initiative de l'Office franco-québécois pour la jeunesse (OFQJ) qui m'a permis de participer au MIGS en 2009 en temps que visiteur.

💫La semaine passée, je suis passé de l'autre coté - en tant qu'exposant. La boucle est bouclée. C'est un sentiment merveilleux que de suivre son intuition et de voir qu'elle peut nous emmener si loin.

Merci la vie.

--

🎂 Sixteen years ago, I discovered the city of Ville de Montréal through an initiative by the Office franco-québécois pour la jeunesse (OFQJ), which allowed me to attend MIGS 2009 as a visitor.

💫 Last week, I found myself on the other side — as an exhibitor. The circle is complete. It’s a wonderful feeling to follow your intuition and see how far it can take you.

Thank you, life. | 53 | 2 | 1 | 2w | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:10.222Z |  | 2025-11-17T16:42:31.428Z | https://www.linkedin.com/feed/update/urn:li:activity:7396222690518532096/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7392598868623904768 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFuYgosGT3Uqw/feedshare-shrink_800/B4EZpfJfqSHMAg-/0/1762532916733?e=1766620800&v=beta&t=dajQzBvw7_i4sUwm3jmRus0iZCF6iTalsEIkazLO4Dg | 🐐 We have a Booth at MIGS ! Come play the fresh demo of Isles of Krom (https://islesofkrom.com/), we'll be happy to chat with you.

🫶 Thanks again to Loto-Québec, La Guilde du jeu vidéo du Québec, Thunder Lotus and Compulsion Games for this oportunity! 

See you next week 😊 

--

🐐Nous avons un stand au MIGS ! Venez tester la nouvelle demo de Isles of Krom (https://islesofkrom.com/), nous serons ravie de discuter avec vous.

🫶 Merci encore à Loto-Québec, La Guilde du jeu vidéo du Québec, Thunder Lotus et Compulsion Games pour cette oportunité !

À la semaine prochaine 😊

#MIGS2025 #IslesOfKrom #IndieGameDev #GameDevelopment #Montreal
#GamingIndustry | 57 | 4 | 1 | 1mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:10.222Z |  | 2025-11-07T16:28:38.125Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7380695619197181952 | Video (LinkedIn Source) | blob:https://www.linkedin.com/fe780a05-2944-4256-9fa8-17a7b395f8b9 | https://media.licdn.com/dms/image/v2/D4D05AQHbrVvAbnViyQ/videocover-low/B4DZmaS8FaJIB8-/0/1759230286277?e=1765785600&v=beta&t=yaS3B0f8MFThscjymlpcgXjE0QQNYblT61YARYLPuEA | Check my friend's game at BCN Game Fest by IndieDevDay, Wandersky is awesome! | 13 | 0 | 0 | 2mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:10.223Z |  | 2025-10-05T20:09:22.310Z | https://www.linkedin.com/feed/update/urn:li:activity:7378746658123038721/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7345839169358688259 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEYYYFDhBX4vg/feedshare-shrink_1280/B4EZfGph7ZHIAk-/0/1751384465503?e=1766620800&v=beta&t=jGacNYYxBWKswzMKT41LNRBu6c7YMeZTPOzeca4yFjM | 🍁 Bonne fête Canada! | 5 | 0 | 0 | 5mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:10.223Z |  | 2025-07-01T15:42:17.067Z | https://www.linkedin.com/feed/update/urn:li:activity:7345838875484848128/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7345483737674989568 | Video (LinkedIn Source) | blob:https://www.linkedin.com/f321119c-9ef5-42d0-be6a-ec2c55f686cb | https://media.licdn.com/dms/image/v2/D4E05AQFMLkKkVynNtA/videocover-low/B4EZfBlrEjHgCI-/0/1751299580794?e=1765785600&v=beta&t=DhK9ZuQKbmPbq1iBuZmwzDqQvO9pBYUJBhKthtDbp-E | Our summer playtest is Live! I'm sure you'll enjoy the pain 😈 | 17 | 0 | 1 | 5mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:10.224Z |  | 2025-06-30T16:09:55.550Z | https://www.linkedin.com/feed/update/urn:li:activity:7345482875829469185/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7336485487110500353 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE_AagK6_i5qg/feedshare-shrink_800/B4EZdBurIvHQAo-/0/1749154444205?e=1766620800&v=beta&t=d8Ya54OrklLI7PscT7TrSVbYv4e3Jjh28-TpaJdjkTY | 😊 Let' s meet at Toronto next week ! I'll be happy to watch you try to beat our game Isles of Krom.

https://islesofkrom.com/

#FloppyGoat #XP25 | 44 | 2 | 0 | 6mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:13.657Z |  | 2025-06-05T20:14:05.436Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7309969653290725378 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFTqWl9eL43gA/feedshare-shrink_800/B4EZXI5xilHcAw-/0/1742832350012?e=1766620800&v=beta&t=ekxeF2XRDby75l78VOqS-4uaes88LDRNAFQ018DYDOw | 😁 I always wanted to see San Francisco's bay. I'm really greatfull 🌉 | 32 | 0 | 0 | 8mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:13.658Z |  | 2025-03-24T16:09:38.013Z | https://www.linkedin.com/feed/update/urn:li:activity:7309968699493351425/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7306314736705417217 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGobVSuaDL4UQ/feedshare-shrink_800/B4EZWU.iQ1GwAk-/0/1741961176673?e=1766620800&v=beta&t=7jcfR6vBMy4Y5JGig5Rj-2CKv9NYmK-Fe2WnhaPD5qI | 😁C'est la semaine prochaine ! J'ai trop hâte !!!🌉

Avec Benoit Scappazzoni 🔜 GDC et Laurent Salaun en mission pour Floppy Goat Inc. 🙌 | 69 | 4 | 0 | 8mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:13.658Z |  | 2025-03-14T14:06:17.994Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7294755421662183424 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF_Eo6TIYoEDQ/feedshare-shrink_800/B4EZTwsVDoHUAg-/0/1739204940982?e=1766620800&v=beta&t=xd8hGKZtkR1-l6rjxozFSJ8DOBCJCmik9jOR9Afkid4 | 🤩 Yeah! On va à la GDC ! | 50 | 2 | 0 | 9mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:13.658Z |  | 2025-02-10T16:33:42.526Z | https://www.linkedin.com/feed/update/urn:li:activity:7294754245071785986/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7289699649433526272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/099346d4-5794-4fa6-9814-d5a0a579eef2 | https://media.licdn.com/dms/image/v2/D4E05AQH07XJ2rS27Kw/feedshare-thumbnail_720_1280/B4EZSohJ6IHoBA-/0/1737994052857?e=1765785600&v=beta&t=pepyNlV2eJJcQdWzf92Jqke0fQ3ITjd7qBQFrvurdaQ | ✌️😁 Incredibly proud and happy to share this first développement step with all of you: | 44 | 3 | 1 | 10mo | Post | Vassili Etienne | https://www.linkedin.com/in/vassili-etienne-42268374 | https://linkedin.com/in/vassili-etienne-42268374 | 2025-12-08T07:09:13.659Z |  | 2025-01-27T17:43:52.495Z | https://www.linkedin.com/feed/update/urn:li:activity:7289688633941348354/ |  | 

---



---

# Vassili Etienne
*Floppy Goat Inc.*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Founder Stories - Podcast X - Webflow Ecommerce website template](https://www.asaasins.com/episodes-category/founder-stories?a9421850_page=5)
*2026-06-01*
- Category: article

### [Etienne Delessert (Episode: 14) - The Illustrator's Studio Podcast](https://rockwellcenter.org/podcast/etienne-delessert-episode-14/)
*2021-07-11*
- Category: podcast

### [Rare Founders: How one entrepreneur turned his failed startup into a community empowering platform - Founded & Grounded](https://foundedandgrounded.com/episodes/OuHadsFEpuS)
*2024-03-04*
- Category: article

### [These now-successful founders failed (hard) so you don't have to](https://www.indiehackers.com/post/these-now-successful-founders-failed-hard-so-you-don-t-have-to-8d95d439db)
*2023-10-30*
- Category: article

### [Treat ideas like cattle, not pets with Daniel Vassallo, creator of smallbets.co (Ship It! #88)](https://changelog.com/shipit/88)
*2023-01-25*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Exclusifs - Qui fait Quoi / Lien MULTIMÉDIA](https://lienmultimedia.com/?page=exclusifs)**
  - Source: lienmultimedia.com
  - *... Vassili Etienne, artiste 3D de son état. Ensemble, les développeurs se sont lancés en affaires en mode indépendant à l'automne 2022, fondant Flopp...*

- **[Laurent Salaün et Vassili Etienne de Floppy Goat concrétisent leur ...](https://lienmultimedia.com/spip.php?article109548)**
  - Source: lienmultimedia.com
  - *Nov 28, 2025 ... Ensemble, les développeurs se sont lancés en affaires en mode indépendant à l'automne 2022, fondant Floppy Goat Inc. et démarrant la ...*

---

*Generated by Founder Scraper*
