# Thierry Ajaltouni

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Vessel
**Durée dans le rôle** : 3 years 4 months in role
**Durée dans l'entreprise** : 3 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Every LP interaction is an extension of your brand. Vessel is built for GPs by GPs to go direct and tap into the wealth channel with an LP-centric, white-label marketing platform that drives personalized LP engagement. Vessel is led by a team of former LPs with more than 10 years of experience who made more than 50 investment decisions for fund investments and co-investments, and former GPs with a track record of generating successful fundraising outcomes, having led, co-led, or participated in raising $5B+ in capital.

## Résumé

At Vessel, we're redefining LP engagement through a white-label marketing platform designed to foster personalized connections and empower GPs to tap into the wealth channel. My journey in private markets started as an LP at Teralys Capital participating in fund investments and managing a portfolio of a dozen legacy funds. It was followed by 3 years of experience as management consultant at Oliver Wyman advising institutional investors and fund managers. 

With a mission to unlock the $140 trillion opportunity in private markets, our team at Vessel leverages over a decade of industry insights to facilitate access to private wealth capital. Through our efforts, we're not only bridging the gap between individual investors and alternative funds but also setting a new standard for LP engagement in private markets.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA4a_VwB20ehcDkiLCl5X1QUFtZ-DjAEJls/
**Connexions partagées** : 164


---

# Thierry Ajaltouni

## Position actuelle

**Entreprise** : Vessel

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 1st


---

# Thierry Ajaltouni

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7397738661418647552 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHCCFkKNOFNgg/feedshare-shrink_480/B4EZqoMG47IQAg-/0/1763758337983?e=1766620800&v=beta&t=pD7UFmvQg5BsSiUpP135TcoxBqiUDPKbKfXPxYWsaTI | My colleagues Sarin Boivin-Picard, Sary Jalkh and I are hiring 3 interns to join our GTM/Customer Success team in January, in our Montreal office.

Internships changed the trajectory of my career. Each one opened the door to a better opportunity, eventually leading to full-time roles that were usually reserved for students with far better grades than mine. I was lucky to learn from incredible mentors like Nick Briody and Vito G. Dellerba, CFA, and I interned at institutions like The Olayan Group, La Caisse (Caisse de dépôt et placement du Québec) and RBC Capital Markets. I had a lot to prove, and the projects and deals I worked on shaped everything that came after.

We want our interns to have that same experience. Real learning, real responsibility, real impact. The kind of work that builds confidence and creates strong stories for future interviews.

Know anyone sharp who can handle the grind of a fast growing start-up?

Link to roles in the comments.

+ Here is what our past interns (Makram Matta and Jason Wang) had to say about their time at Vessel. | 72 | 11 | 8 | 2w | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.477Z |  | 2025-11-21T20:52:20.220Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397016007535439872 | Text |  |  | Imagine having more than 1,000 companies in your portfolio, 100 plus new investments every year, and a constant wave of follow-on rounds that LPs want co-investment allocation in. That is the daily reality for one of our clients. For years, co-investments were running on pure adrenaline.

A portfolio company would raise a new round, an allocation would appear (who does not love pro-rata rights?), and LPs would receive an email with only a few days to decide. It sometimes worked, but it created real friction. LPs felt rushed, and the fund manager spent more time confirming allocations last minute (and trying to pace the portfolio company on the other end to keep the round open) than building relationships.

Here is the pattern we see across many firms: when LPs only learn about opportunities at the moment of allocation, everything becomes urgent, reactive and harder than it needs to be.

With Vessel, the process looks different. Firms can showcase their strongest companies well before a round opens, giving LPs time to understand the opportunities and signal early interest.

When the allocation does go live, everyone is already aligned. The book is built, expectations are clear, and timelines are understood.

One LP summed it up perfectly after seeing the new system: “I did not know this was possible.”

A useful way to evaluate your own process:
• How early do LPs get visibility into potential co-investments?
• How many rounds required last minute confirmations this quarter?
• How often does a round feel rushed because information arrived too late?

It is a reminder that while venture focuses on innovation at the deal level, innovation in process can be just as transformative. | 38 | 0 | 2 | 2w | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.478Z |  | 2025-11-19T21:00:46.108Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396289500903075840 | Text |  |  | One of the fund managers we support at Vessel grew to seven funds in 14 years with a single person running finance. Sharp, disciplined, flawless in the numbers, but everything beneath the surface was manual. Capital calls in Word and Excel. Reports exported one by one. Delivery through mail-merge and email. As the LP base grew, so did the volume. LPs could not find documents in their inboxes, and the Head of Finance spent hours re-sending files and answering the same questions.

Here is the pattern we see over and over: even the strongest finance teams get buried when reporting lives in inboxes. If your team is re-sending files or fielding repeat LP questions, you are already paying the cost.

This fund manager was even considering hiring someone just to handle the operational load.

When they moved to Vessel, that pressure disappeared. LPs finally had one place to access all their reports, the interface was clear enough that they found what they needed instantly, and the Head of Finance no longer wondered whether the right investor received the right document.

A small team stayed small, the Head of Finance got their time back, and LPs got clarity.

If you want a quick diagnostic:
• How many hours did your team spend last quarter re-sending documents?
• How many steps does it take an LP to find a report?
• Which part of your process still relies on inbox archaeology? | 49 | 0 | 1 | 2w | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.478Z |  | 2025-11-17T20:53:53.429Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7388960847974539264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQH9qSgk-tnobQ/feedshare-shrink_800/B4EZoXchmmHMAg-/0/1761329946034?e=1766620800&v=beta&t=knOWdO3NTEm5t5TFGDXSf7D9g7pFJ0eakarx8XlhH1A | Can better reporting improve your fundraising outcomes?
Any lessons we can take from public markets?

Fundraising outcomes = (Track Record + Differentiation) ÷ Complexity of Story

Higher-quality reporting and LP communication directly impact fundraising outcomes. It’s a lever that increases differentiation and reduces story complexity.

I’ve seen this firsthand working closely with Patrick Ghoche, CPA, CA, CFA and his team at Inovia Capital.

Reporting in private markets is often secretive, so it’s tough to know where you stand or how to improve.

If you’ve ever wondered how your reporting stacks up against best-in-class, or how to take more control of your LP narrative, join our webinar this Thursday (https://lnkd.in/egjvMgbT).

You’ll hear from:
- Patrick Ghoche, CPA, CA, CFA, CFO at Inovia Capital and
- Darrell Heaps, Founder & Chairman at Q4, whose software powers investor relations for the best-performing public companies in your portfolio.

As the saying goes, trust with LPs takes years to build and seconds to lose. | 12 | 0 | 0 | 1mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.479Z |  | 2025-10-28T15:32:26.411Z | https://www.linkedin.com/feed/update/urn:li:activity:7387553246086656001/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7377067566428549121 | Text |  |  | Huge congrats to the Telegraph Ventures team on the launch of their fund 🎉 ! This milestone is the result of tremendous hard work and thoughtfulness, and I’m sure they’ll be working even harder for the entrepreneurs they back. Étienne Mérineau, Luis Gutierrez Roy and Varun Dalal, the entire team at Vessel is truly grateful for your trust and excited to continue working with you! | 9 | 2 | 0 | 2mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.479Z |  | 2025-09-25T19:52:47.124Z | https://www.linkedin.com/feed/update/urn:li:activity:7377035097528639488/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7376986484136062976 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFGJCllk2d_AA/feedshare-shrink_800/B4EZmAMaAJIkAg-/0/1758792362260?e=1766620800&v=beta&t=UxQcheuIxXcTNZj6Yf9ni-Iu8GtvQTUSUT57uFNAwm8 | What is LP engagement, really? Just another buzzword?
A lot of GPs roll their eyes when they hear it. But the best fundraisers know it can make or break a fundraise.

Many of you know fundraising outcomes = (Track Record + Differentiation) ÷ Complexity of Story.

But what about fundraising momentum—how fast and effortful (or effortless) a fundraise can be?

That’s where LP engagement comes in. The more meaningfully you engage with LPs, the more momentum you create. And there are proven ways to do it.

Don’t just take my word for it. Join our next webinar to hear directly from GPs who’ve mastered LP engagement—and from LPs themselves who’ve backed dozens of funds and know what really keeps momentum alive. | 6 | 0 | 0 | 2mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.480Z |  | 2025-09-25T14:30:35.599Z | https://www.linkedin.com/feed/update/urn:li:activity:7376909847474249729/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7371264651600334850 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG1BiZm8g0ufw/feedshare-shrink_800/B4EZksPIK5KYAg-/0/1757383788094?e=1766620800&v=beta&t=NjiZRM-gtoTxr09DMAbS0l-fgBRCOIA1GikjiYSJQLE | What makes a great co-investment for the wealth channel? Curious to learn from both GPs and wealth advisors that have pulled it off?

Join this webinar moderated by my co-founder Thomas Terrats. Sign-up link in Thomas' post. | 8 | 0 | 0 | 2mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:03.481Z |  | 2025-09-09T19:34:04.416Z | https://www.linkedin.com/feed/update/urn:li:activity:7371135320513486848/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7326246211395481600 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQExRCBBvKqaNw/feedshare-shrink_800/B4EZawOGV7HIAk-/0/1746713209647?e=1766620800&v=beta&t=OxJ01zm-kqQEe9zKFD7YSTQy5JQ9VOjy9qchrxUUsUE | Anyone know someone who never fails to delight clients?

We’re hiring again at Vessel! This time to support Thomas Terrats and I on the Customer Success front. More roles are coming soon. We like to move fast at Vessel, so any intros or referrals (or engagement for reach) are hugely appreciated 🙂.

Our last non-engineering hire was Sary Jalkh, who’s now leading our GTM efforts. His first LinkedIn post (as part of the Vessel team) went viral, his coding and automation skills impressed even our most hardcore developers, and he’s already adding a ton of value. (He’s also great at racket sports 🎾 ; so is most of the team). The bar is high.

We’re reshaping the investor experience in private markets, helping fund managers make all their investors feel valued, not just the big ones. We practice what we preach: no churn to date, and client referrals are one of our strongest growth drivers.

Vessel has helped fund managers close tens of millions, delivered reports for billions in commitments, and grown our client base by 20x+ since last year. We’re growing at warp speed, are well-funded (backed by top investors), and we’re now looking to bring on a Founding Customer Success Expert to help us continue exceeding client expectations and build out our CS function. You’ll be joining a diverse team of competitive 🏓 overachievers with incredible customer empathy.

You’ll work closely with Thomas and I in our Mile End office in Montreal. We’ll teach you everything we know and hope to learn a lot from you too.

It’ll be hard work and late nights, but fun and incredibly rewarding. If you’ve got the appetite and what it takes to lead, you’ll grow with us and shape our customer success function. The interview process will be all about showing, not just telling; show us we can trust you to work with our most valued clients and the job is yours.

Know someone who might be interested? DM me or share the job posting link (below) with them.

https://lnkd.in/eW4TPhfV

#CustomerSuccess #privatemarkets | 78 | 0 | 9 | 6mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:05.733Z |  | 2025-05-08T14:06:51.869Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7297381062081466370 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFPCdpo0PT7Iw/feedshare-shrink_800/B4EZUWBZT_G0Ag-/0/1739831220722?e=1766620800&v=beta&t=m0NQ3SbDI_DH1D_5bsok_A3U-6dgCiriKPW529ui8PI | Anyone know someone who's hungry to be our first GTM hire?

When Thomas Terrats and I started Vessel, Founder-Market fit was a term that was often thrown around: we spoke the language of private markets and had experienced client problems firsthand as investors/fund managers. This has proven to be a huge advantage; we’ve built a product that both investors and fund managers love (after a pivot, naturally, and in big part thanks to our stellar team).

Vessel has already helped fund managers close tens of millions of dollars, grown more than 20x since last year and signed some of the most well-established fund managers in the industry. We’re growing fast, are well-funded (backed by some top investors) and we're now looking to bring on a founding business development rep that can help us accelerate and build our GTM function from the ground up. You’ll be joining a diverse team of competitive 🏐 overachievers with incredible customer empathy.

You'll be in the trenches with Thomas and I day-in, day-out, working out of our office in the Mile End in Montreal and joining us when we travel for conferences (e.g., SF, NYC, Paris, Dubai). We’ll teach you everything we know and we’re hoping to learn a lot from you too.

It will be hard work and late nights, but fun and incredibly rewarding; if you have the appetite and what it takes to lead, you’ll grow with us and build our sales and marketing team.

Know someone who might be interested? DM me or share the job posting link (below) with them.

https://lnkd.in/er3nnNW4

#GTM #privatemarkets | 80 | 6 | 12 | 9mo | Post | Thierry Ajaltouni | https://www.linkedin.com/in/thierryajaltouni | https://linkedin.com/in/thierryajaltouni | 2025-12-08T04:57:05.735Z |  | 2025-02-17T22:27:03.984Z |  |  | 

---



---

# Thierry Ajaltouni
*Vessel*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 8 |

---

## 📚 Articles & Blog Posts

### [Vessel raises $10.3 million to retool VC for the age of AI | BetaKit](https://nam12.safelinks.protection.outlook.com/?url=https%3A%2F%2Ffjlabs.us18.list-manage.com%2Ftrack%2Fclick%3Fu%3D2587c27f0067eea486e801053%26id%3D72bb766af1%26e%3D2c59bc0b19&amp;data=05%7C02%7Crose%40fjlabs.com%7C5adbf1b6632045a24bc708de0a758171%7C4ca8a3498b2a465c917ec5e8a27c38c4%7C1%7C0%7C638959696957655624%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&amp;sdata=jzNSYjLmH2B2XclBx95cA3CrUl6vyKrk6uLP1S1UkN8%3D&amp;reserved=0)
*2025-06-10*
- Category: article

### [Vessel raises $10.3M CAD to modernize venture capital with AI-powered platform - FoundersToday](https://www.founderstoday.news/vessel-raises-over-10-millions/)
*2025-06-10*
- Category: article

### [Vessel Secures $10.3 Million to Revolutionize VC Management with AI - Startup Ecosystem Canada](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/)
*2025-06-10*
- Category: article

### [Vessel hiring Founding Customer Success Expert in Montreal, Quebec, Canada | LinkedIn](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)
*2025-05-19*
- Category: article

### [Vessel - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/vessel-5d57)
*2022-08-25*
- Category: article

---

## 📖 Full Content (Scraped)

*9 articles scraped, 10,175 words total*

### Vessel raises $10.3 million to retool VC for the age of AI | BetaKit
*2 words* | Source: **EXA** | [Link](https://nam12.safelinks.protection.outlook.com/?url=https%3A%2F%2Ffjlabs.us18.list-manage.com%2Ftrack%2Fclick%3Fu%3D2587c27f0067eea486e801053%26id%3D72bb766af1%26e%3D2c59bc0b19&amp;data=05%7C02%7Crose%40fjlabs.com%7C5adbf1b6632045a24bc708de0a758171%7C4ca8a3498b2a465c917ec5e8a27c38c4%7C1%7C0%7C638959696957655624%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&amp;sdata=jzNSYjLmH2B2XclBx95cA3CrUl6vyKrk6uLP1S1UkN8%3D&amp;reserved=0)

Bad Request

---

### Vessel raises $10.3M CAD to modernize venture capital with AI-powered platform - FoundersToday
*1,274 words* | Source: **EXA** | [Link](https://www.founderstoday.news/vessel-raises-over-10-millions/)

Vessel raises $10.3M CAD to modernize venture capital with AI-powered platform - FoundersToday

===============

![Image 3: Revisit consent button](https://cdn-cookieyes.com/assets/images/revisit.svg)

We value your privacy

We use cookies to enhance your browsing experience, serve personalised ads or content, and analyse our traffic. By clicking "Accept All", you consent to our use of cookies.

Customise Reject All Accept All

Customise Consent Preferences![Image 4](https://cdn-cookieyes.com/assets/images/close.svg)

We use cookies to help you navigate efficiently and perform certain functions. You will find detailed information about all cookies under each consent category below.

The cookies that are categorised as "Necessary" are stored on your browser as they are essential for enabling the basic functionalities of the site. ...Show more

Necessary Always Active

Necessary cookies are required to enable the basic features of this site, such as providing secure log-in or adjusting your consent preferences. These cookies do not store any personally identifiable data.

*   Cookie __cf_bm 
*   Duration 1 hour 
*   Description This cookie, set by Cloudflare, is used to support Cloudflare Bot Management.  

*   Cookie __cfruid 
*   Duration session 
*   Description Cloudflare sets this cookie to identify trusted web traffic. 

*   Cookie elementor 
*   Duration Never Expires 
*   Description The website's WordPress theme uses this cookie.It allows the website owner to implement or change the website's content in real-time. 

*   Cookie wpEmojiSettingsSupports 
*   Duration session 
*   Description WordPress sets this cookie when a user interacts with emojis on a WordPress site. It helps determine if the user's browser can display emojis properly. 

*   Cookie cookieyes-consent 
*   Duration 1 year 
*   Description CookieYes sets this cookie to remember users' consent preferences so that their preferences are respected on subsequent visits to this site. It does not collect or store any personal information about the site visitors. 

Functional

Functional cookies help perform certain functionalities like sharing the content of the website on social media platforms, collecting feedback, and other third-party features.

No cookies to display.

Analytics

- [x] 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics such as the number of visitors, bounce rate, traffic source, etc.

*   Cookie _ga_* 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to store and count page views. 

*   Cookie _ga 
*   Duration 1 year 1 month 4 days 
*   Description Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. 

Performance

Performance cookies are used to understand and analyse the key performance indexes of the website which helps in delivering a better user experience for the visitors.

No cookies to display.

Advertisement

Advertisement cookies are used to provide visitors with customised advertisements based on the pages you visited previously and to analyse the effectiveness of the ad campaigns.

No cookies to display.

Uncategorised

- [x] 

Other uncategorised cookies are those that are being analysed and have not been classified into a category as yet.

*   Cookie nitroCachedPage 
*   Duration session 
*   Description Description is currently not available. 

*   Cookie pum-1230 
*   Duration 1 month 
*   Description Description is currently not available. 

Reject All Save My Preferences Accept All

Powered by [![Image 5: Cookieyes logo](https://cdn-cookieyes.com/assets/images/poweredbtcky.svg)](https://www.cookieyes.com/product/cookie-consent/?ref=cypbcyb&utm_source=cookie-banner&utm_medium=powered-by-cookieyes)

[Skip to content](https://www.founderstoday.news/vessel-raises-over-10-millions/#content)

[![Image 6: FoundersToday Logo](blob:http://localhost/ad19d9fbab1652616e5e87b830516c1f)](https://www.founderstoday.news/)

*   [Home](https://www.founderstoday.news/)
*   [About Us](https://www.founderstoday.news/about/)
*   [Startup Magazine](https://www.founderstoday.news/founderstoday-startup-magazine/)
*   [Case Studies](https://new.founderstoday.news/case-studies/)
*   [](https://www.founderstoday.news/vessel-raises-over-10-millions/#)[](https://www.founderstoday.news/vessel-raises-over-10-millions/#)[](https://www.facebook.com/FoundersToday)[](https://www.linkedin.com/company/founderstoday/)[](http://www.instagram.com/founderstoday) 
*   [PR Coverage](http://go.founderstoday.news/)

*   [Home](https://www.founderstoday.news/)
*   [About Us](https://www.founderstoday.news/about/)
*   [Startup Magazine](https://www.founderstoday.news/founderstoday-startup-magazine/)
*   [Case Studies](https://new.foundersto

*[... truncated, 11,613 more characters]*

---

### Vessel Secures $10.3 Million to Revolutionize VC Management with AI - Startup Ecosystem Canada
*631 words* | Source: **EXA** | [Link](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/)

Vessel Secures $10.3 Million to Revolutionize VC Management with AI - Startup Ecosystem Canada

===============
[Skip to main content](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#ajax-content-wrap)

Hit enter to search or ESC to close

[Close Search](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#)

[![Image 3: Startup Ecosystem Canada](https://www.startupecosystem.ca/news/wp-content/uploads/2024/11/Ecosystem-Logo.png)](https://www.startupecosystem.ca/)

[Menu](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#mobile-menu)

*   [Home](https://www.startupecosystem.ca/)
*   [Events](https://www.startupecosystem.ca/events/)
*   [Network](https://www.startupecosystem.ca/network/)
*   [Partners](https://www.startupecosystem.ca/partners/)
*   [Resources](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#)
    *   [News](https://www.startupecosystem.ca/news/)
    *   [Startup Wisdom](https://www.startupecosystem.ca/startup-wisdom)
    *   [Student Clubs](https://www.startupecosystem.ca/student-led-clubs/)

*   [Join Us Now](https://www.startupecosystem.ca/my-account/)  

![Image 4: Startup Ecosystem Canada](https://www.startupecosystem.ca/news/wp-content/uploads/2024/11/Ecosystem-Logo.png)

[Join Us Now](https://www.startupecosystem.ca/my-account/)

*   [Home](https://www.startupecosystem.ca/)
*   [Events](https://www.startupecosystem.ca/events/)
*   [Network](https://www.startupecosystem.ca/network/)
*   [Partners](https://www.startupecosystem.ca/partners/)
*   [Resources](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#)
    *   [News](https://www.startupecosystem.ca/news/)
    *   [Startup Wisdom](https://www.startupecosystem.ca/startup-wisdom)
    *   [Student Clubs](https://www.startupecosystem.ca/student-led-clubs/)

By[Startup Eco System](https://www.startupecosystem.ca/news/author/admin/ "Posts by Startup Eco System")[No Comments](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/#respond)

![Image 5: Vessel Secures $10.3 Million to Revolutionize VC Management with AI](https://cdn.betakit.com/wp-content/uploads/2025/06/Capture-decran-le-2025-05-27--770x513.jpg)

**Image Credits:** The image is sourced from [https://betakit.com](https://betakit.com/)

6 months ago

Vessel Secures $10.3 Million to Revolutionize VC Management with AI
-------------------------------------------------------------------

[Canada](https://www.startupecosystem.ca/news/category/canada/)

[Share](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/# "Share this")[Share](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/# "Share this")[Share](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/# "Share this")[Pin](https://www.startupecosystem.ca/news/vessel-secures-10-3-million-to-revolutionize-vc-management-with-ai/# "Pin this")

News Summary
------------

Montréal-based startup Vessel has raised $10.3 million CAD in seed financing to develop an AI-powered platform aimed at streamlining fund and investor management for venture capitalists. Co-founded by Thomas Terrats and Thierry Ajaltouni, Vessel’s platform seeks to automate the ‘grunt work,’ allowing general partners (GPs) and limited partners (LPs) to focus on building relationships. The investment round was co-led by Inovia Capital and Afore Capital, with participation from several other investors. The platform offers tools for every stage of fund management, including LP scouting, onboarding, and reporting returns, and features a portal for LPs to manage co-investment opportunities. Vessel aims to address challenges faced by Canadian VCs, such as limited data access and manual workflows, particularly amid a tough fundraising environment. The startup plans to use the new capital to enhance its automation tools and expand its team slightly. Vessel operates on a subscription model and is targeting global investors, with hopes of aiding Canadian VCs in international fundraising efforts.

#### Tags:

[AI-powered platform](https://www.startupecosystem.ca/news/tag/ai-powered-platform/)[automation](https://www.startupecosystem.ca/news/tag/automation/)[Canada startup news](https://www.startupecosystem.ca/news/tag/canada-startup-news/)[Fund management](https://www.startupecosystem.ca/news/tag/fund-management/)[venture capital](https://www.startupecosystem.ca/news/tag/venture-capital/)

Story Coverage
--------------

![Image 6: Brand Logo](https://www.startupecosystem.ca/news/wp-content/uploads/2024/11/circle_icon.png)betakit.com

#### Vessel raises $10.3 million to retool VC for the age of AI

[Read

*[... truncated, 8,168 more characters]*

---

### Vessel hiring Founding Customer Success Expert in Montreal, Quebec, Canada | LinkedIn
*2,847 words* | Source: **EXA** | [Link](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)

Vessel hiring Founding Customer Success Expert in Montreal, Quebec, Canada | LinkedIn

===============
[Skip to main content](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162#main-content)[LinkedIn](https://ca.linkedin.com/?trk=public_jobs_nav-header-logo)

 Founding Customer Success Expert in North Charleston, SC 

Expand search

This button displays the currently selected search type. When expanded it provides a list of search options that will switch the search inputs to match the current selection. 

*    Jobs 
*    People 
*    Learning 

Clear text Clear text 

Clear text 

Clear text Clear text 

[Sign in](https://www.linkedin.com/login?emailAddress=&fromSignIn=&fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fjobs%2Fview%2Ffounding-customer-success-expert-at-vessel-4228445162&trk=public_jobs_nav-header-signin)[Create an account](https://www.linkedin.com/signup/cold-join?source=jobs_registration&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fjobs%2Fview%2Ffounding-customer-success-expert-at-vessel-4228445162&trk=public_jobs_nav-header-join)[![Image 1](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)](https://www.linkedin.com/login?emailAddress=&fromSignIn=&fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fjobs%2Fview%2Ffounding-customer-success-expert-at-vessel-4228445162&trk=public_jobs_nav-header-signin)

![Image 2: Vessel](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)

### Founding Customer Success Expert

[Vessel](https://ca.linkedin.com/company/vesselco?trk=public_jobs_sub-nav-cta-optional-url "Vessel")Montreal, Quebec, Canada

[![Image 3: Vessel](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)](https://ca.linkedin.com/company/vesselco?trk=public_jobs_topcard_logo)

Founding Customer Success Expert
================================

#### [Vessel](https://ca.linkedin.com/company/vesselco?trk=public_jobs_topcard-org-name) Montreal, Quebec, Canada 

 6 months ago 

 Be among the first 25 applicants 

[![Image 4](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)![Image 5](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)![Image 6](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162) See who Vessel has hired for this role](https://www.linkedin.com/login?session_redirect=https%3A%2F%2Fwww%2Elinkedin%2Ecom%2Fsearch%2Fresults%2Fpeople%2F%3FfacetCurrentCompany%3D85623566%26title%3DCustomer%2BSuccess%2BSpecialist&emailAddress=&fromSignIn=&trk=public_jobs_see-who-was-hired_people-search-link_face-pile-cta)

No longer accepting applications

*   [Report this job](https://www.linkedin.com/uas/login?fromSignIn=true&session_redirect=https%3A%2F%2Fca.linkedin.com%2Fjobs%2Fview%2Ffounding-customer-success-expert-at-vessel-4228445162&trk=public_jobs_ellipsis-menu-semaphore-sign-in-redirect&guestReportContentType=JOB&_f=guest-reporting)

### Use AI to assess how you fit

Get AI-powered advice on this job and more exclusive features.

Am I a good fit for this job?Tailor my resume

![Image 7](https://ca.linkedin.com/jobs/view/founding-customer-success-expert-at-vessel-4228445162)
Sign in to access AI-powered advices
------------------------------------

 Sign in 

Welcome back
------------

 Email or phone  

 Password  

Show

[Forgot password?](https://www.linkedin.com/uas/request-password-reset?trk=public_jobs_ai_button_cta_contextual-sign-in-modal_sign-in-modal_forgot_password) Sign in 

or

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=public_jobs_ai_button_cta_contextual-sign-in-modal_sign-in-modal_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=public_jobs_ai_button_cta_contextual-sign-in-modal_sign-in-modal_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=public_jobs_ai_button_cta_contextual-sign-in-modal_sign-in-modal_auth-button_cookie-policy).

New to LinkedIn? [Join now](https://www.linkedin.com/signup/cold-join?source=jobs_registration&trk=public_jobs_ai_button_cta_contextual-sign-in-modal_sign-in-modal_join-link)

or

New to LinkedIn? [Join now](https://www.linkedin.com/signup/cold-join?source=jobs_registration&trk=public_jobs_ai_button_cta_contextual-sign-in-modal_join-link)

By clicking Continue to join or sign in, you agree to LinkedIn’s [User Agreement](https://ca.linkedin.com/legal/user-agreement?trk=linkedin-tc_auth-button_user-agreement), [Privacy Policy](https://ca.linkedin.com/legal/privacy-policy?trk=linkedin-tc_auth-button_privacy-policy), and [Cookie Policy](https://ca.linkedin.com/legal/cookie-policy?trk=linkedin-tc_auth-button_cookie-policy).

![Image 8](https://ca.linkedin.com/jobs/view/founding-customer-suc

*[... truncated, 38,178 more characters]*

---

### Just a moment...
*27 words* | Source: **EXA** | [Link](https://www.crunchbase.com/organization/vessel-5d57)

Just a moment...

===============

We must verify your session before you can proceed

Waiting for www.crunchbase.com to respond...

Need help? [Contact our support team](mailto:support@crunchbase.com).

Ray ID: `9aaa6e0b7a69c943`

---

### Vessel raises $10.3 million to retool VC for the age of AI | BetaKit
*1,459 words* | Source: **GOOGLE** | [Link](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/)

Vessel raises $10.3 million to retool VC for the age of AI | BetaKit

===============

Read [BetaKit Most Ambitious](https://bit.ly/4k6pCHn): Telling the story of what’s possible.

✕

[![Image 1: BetaKit - Canadian Startup News & Tech Innovation](https://betakit.com/wp-content/uploads/2024/01/BetaKit_Logo_White_250px.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [About](https://betakit.com/about-us/)
*   [Advertise](https://betakit.com/advertise/)
*   [Members](https://betakit.com/innovation-leaders/)
*   [Contact](https://betakit.com/about-us/#contact)

*   [](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/#)
    *   [](https://www.linkedin.com/company/BetaKit)
    *   [](https://twitter.com/BetaKit)
    *   [](https://www.youtube.com/user/Betakit)
    *   [](https://www.facebook.com/BetaKit)

[![Image 2: BetaKit - Canadian Tech & Startup News](https://betakitdev.trypl.com/wp-content/uploads/2025/04/betakit-logo-OG.png)](https://betakit.com/)

Canadian Tech & Startup News

*   [News](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/#)

    *   [Latest News](https://betakit.com/#Latest)
    *   [By Topics](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/#)

        *   [Funding](https://betakit.com/tag/funding)
        *   [Acquisitions](https://betakit.com/tag/acquisitions)
        *   [Layoffs](https://betakit.com/tag/layoffs/)
        *   [VC](https://betakit.com/tag/vc/)
        *   [Events](https://betakit.com/tag/events)
        *   [Markets](https://betakit.com/tag/markets/)
        *   [Reports](https://betakit.com/tag/reports)
        *   [Impact](https://betakit.com/tag/impact)

    *   [By Verticals](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/#)

        *   [AI](https://betakit.com/tag/ai)
        *   [FinTech](https://betakit.com/tag/fintech)
        *   [SaaS](https://betakit.com/tag/saas)
        *   [Retail](https://betakit.com/tag/retail)
        *   [Healthtech](https://betakit.com/tag/healthtech)
        *   [Cleantech](https://betakit.com/tag/cleantech)
        *   [Deep Tech](https://betakit.com/tag/deep-tech/)
        *   [Defence Tech](https://betakit.com/tag/defence-tech/)

    *   [By Regions](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/#)

        *   [Toronto](https://betakit.com/tag/toronto)
        *   [Montréal](https://betakit.com/tag/montreal)
        *   [Vancouver](https://betakit.com/tag/vancouver)
        *   [Waterloo Region](https://betakit.com/tag/kitchener-waterloo)
        *   [Ottawa](https://betakit.com/tag/ottawa)
        *   [Calgary](https://betakit.com/tag/calgary)
        *   [Prairies](https://betakit.com/tag/prairies)
        *   [Atlantic Canada](https://betakit.com/tag/atlantic-canada/)

*   [Podcast](https://betakit.com/category/podcasts)
*   [Newsletter](https://betakit.com/category/newsletters)
*   [Quiz](https://betakit.com/category/quiz/)
*   [Jobs](https://betakit.com/tag/jobs/)

Vessel raises $10.3 million to retool VC for the age of AI
==========================================================

 By [Madison McLauchlan](https://betakit.com/author/madison-mclauchlan/ "Posts by Madison McLauchlan")June 10, 2025

[Email](mailto:?subject=Vessel%20raises%20$10.3%20million%20to%20retool%20VC%20for%20the%20age%20of%20AI&body=https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/)[Share on LinkedIn](http://www.linkedin.com/shareArticle?mini=true&url=https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/&title=Vessel+raises+%2410.3+million+to+retool+VC+for+the+age+of+AI&source=BetaKit)[Share on X](https://twitter.com/intent/tweet?original_referer=https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/&text=Vessel+raises+%2410.3+million+to+retool+VC+for+the+age+of+AI&tw_p=tweetbutton&url=https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/&via=BetaKit)[Share on Reddit](http://www.reddit.com/submit?url=https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/&title=Vessel+raises+%2410.3+million+to+retool+VC+for+the+age+of+AI)[Share on BlueSky](https://bsky.app/intent/compose?text=Vessel+raises+%2410.3+million+to+retool+VC+for+the+age+of+AI%20https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/)

![Image 3: Vessel | BetaKit](https://cdn.betakit.com/wp-content/uploads/2025/06/Capture-decran-le-2025-05-27--770x513.jpg)

Vessel co-founders Thierry Ajaltouni (left) and CEO Thomas Terrats (right). 

Platform developed by two ex-LPs aims to automate “grunt work” for GPs and improve LP relationships. 

Venture capital (VC) mogul Marc Andreessen recently said on [an a16z podcast](https://www.youtube.com/watch?v=qpBDB2NjaWY) that VC investing is the only job 

*[... truncated, 16,909 more characters]*

---

### Talabat talks Saudi, Stargate stalls
*1,494 words* | Source: **GOOGLE** | [Link](https://www.fwdstart.me/p/talabat-talks-saudi-stargate-stalls)

[![Image 1](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/6067915f-22e5-448b-849a-8812999cdcc8/image.png)](https://archives.fwdstart.me/?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me)

Happy Friday, friends 👋

An extremely sleepy post-Eid week, so things are relatively quiet on the news and announcement front. However, you're in luck…

…as that means you’ve got plenty of time to dig into the first edition of the MENA VC Playbook which we published earlier this week! If you missed it, you can [check it out here.](https://archives.fwdstart.me/p/how-to-build-a-strong-dealflow-pipeline?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me)

One story that did catch our attention this week was [Talabat CEO Tomaso Rodriguez’s interview with CNBC’s Dan Murphy](https://archives.fwdstart.me/p/why-talabat-isnt-rushing-into-saudi-arabia?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me). Generally, these kinds of interviews tend to be pretty banal and not especially insightful, but there were a couple of genuinely interesting nuggets in this one.

From why Talabat isn’t rushing into Saudi, to the early efficacy of their new embedded finance functionality, to how any Saudi entry (if it happens) will likely be via M&A.

There’ll be no shortage of quick commerce players to acquire, that’s for sure.

Elsewhere, PRYPCO is still slicing and dicing Dubai real estate – its second fractional property listing [sold out in under two hours](https://www.arabianbusiness.com/industries/real-estate/dubai-tokenised-real-estate-project-sold-out-in-less-than-2-minutes-on-prypco-mint-platform?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me). Stargate UAE may not be as much of a done deal as it first seemed. Qatar is [jumping into the sovereign AI race](https://huggingface.co/QCRI/Fanar-1-9B-Instruct?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me) with new bilingual Arabic-English LLMs, and Kuwait is joining the open banking party with a newly published draft regulatory framework.

Plenty of interesting deep dives coming up over the next few editions as well, especially if you’re into BNPL, spacetech, venture debt, or founders with an exit under their belts.

But without further ado, let’s get into this week’s round-up👇

**This week’s round-up is a 5 min read:**

*   📖 Recommended reads including why the age of AI is the age of philosophy, and how Gulf banks are fighting back to beat BNPL advantage

![Image 2](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/ee63e6a7-dd45-4b22-978e-87f8d4f514ff/Untitled__1000___250px___1292___86px_.png)

![Image 3](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/ee63e6a7-dd45-4b22-978e-87f8d4f514ff/Untitled__1000___250px___1292___86px_.png)

🚀**Startup funding round-up**
------------------------------

![Image 4](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/59829c2a-74a1-4b19-b851-4a7dcf17c8f2/Funding_Round_Up__2_.png)

🇦🇪**Qanooni**, an AI-powered legal tech platform that helps lawyers draft and review documents inside tools like Word and Outlook, and co-founded by the team behind Spotii, has raised $2M (pre-Seed) from Village Global, Oryx Fund, TA Ventures, and angels.

🇦🇪**[SANTECHTURE](https://www.linkedin.com/company/santechture/?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me)**, a healthtech company focused on revenue cycle management, received a strategic investment from CorroHealth (US) to integrate AI solutions across the GCC.

🇸🇦**Meda**, a digital marketplace for building materials that allows contractors to compare suppliers and track orders through its mobile-first interface, has closed a Seed round from undisclosed angel investors.

🇦🇪**[Best Kept Shared](https://www.linkedin.com/company/bestkeptshared/?utm_campaign=talabat-talks-saudi-stargate-stalls&utm_medium=referral&utm_source=www.fwdstart.me)**, a P2P luxury fashion rental and resale platform, has received funding from MTNC to expand its tech and brand partnerships.

![Image 5](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/ee63e6a7-dd45-4b22-978e-87f8d4f514ff/Untitled__1000___250px___1292___86px_.png)

##### **Premium deep-dive**

[![Image 6](https://media.beehiiv.com/cdn-cgi/image/fit=scale-down,quality=80,format=auto,onerror=redirect/uploads/asset/file/beb1d333-ce09-4183-bf85-d30883c361f9/The_MENA_VC_Playbook__7_.png)](https://archives.fwdstart.me/p/how-to-build-a-strong-dealflow-pipeline?utm_campaign=talabat-talks-saudi-star

*[... truncated, 13,904 more characters]*

---

### A Full-Circle Journey Built on Relationships – Inovia
*1,859 words* | Source: **GOOGLE** | [Link](https://www.inovia.vc/inovia-conversations/investing-in-vessel-a-full-circle-journey-built-on-relationships/)

Investing in Vessel: A Full-Circle Journey Built on Relationships – Inovia

===============

Consent to cookies

This website uses cookies to help it work and to track how you interact with it, so that we can provide you with an enhanced and personalised user experience. We will only use cookies if you consent to them by clicking "Accept all". You can also manage your individual cookie preferences from the settings by clicking on "Customize".

Customize Necessary only Refuse all Accept all

Consent to cookies

Necessary- [x] REQUIRED 

Necessary cookies are crucial for the basic functions of the website and the website will not work in its intended way without them. These cookies do not store any personally identifiable data.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| cc_cookie_byscuit | .www.inovia.vc | 6 months | Byscuit sets this cookie to keep all the information related to consent. |

We are experiencing a brief cookie management interruption due to maintenance.

Rest assured that only necessary cookies are being tracked during this period. We appreciate your understanding as we promptly address this issue.

Functional- [x] Functional 

Functional cookies help to perform certain functionalities like sharing the content of the website on social media platforms, collect feedbacks, and other third-party features.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| HSID | .google.com | 1 year 10 days | To provide fraud prevention. |
| NID | .google.com | 1 year | This cookie is used to collect website statistics and track conversion rates and Google ad personalisation |
| SEARCH_SAMESITE | .google.com | 4 month | SameSite prevents the browser from sending this cookie along with cross-site requests. The main goal is mitigate the risk of cross-origin information leakage. It also provides some protection against cross-site request forgery attacks. |
| SIDCC | .google.com | 1 year | To provide the identification of trusted web traffic. |
| wp-wpml_current_language | www.inovia.vc | Session | Stores the current language. By default, this cookie is set only for logged-in users. If you enable the language cookie to support AJAX filtering, this cookie will also be set for users who are not logged in. |

Analytics- [x] Analytics 

Analytical cookies are used to understand how visitors interact with the website. These cookies help provide information on metrics the number of visitors, bounce rate, traffic source, etc.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| _ga | .inovia.vc | 1 year 1 month 4 days | Google Analytics sets this cookie to calculate visitor, session and campaign data and track site usage for the site's analytics report. The cookie stores information anonymously and assigns a randomly generated number to recognise unique visitors. |
| _ga_SF1F6Y3JM8 | .inovia.vc | 1 year 1 month 4 days | Google Analytics sets this cookie to store and count page views. |
| _gat_UA-99297379-1 | .inovia.vc | 1 minute | Google Analytics sets this cookie for user behaviour tracking. |
| _gid | .inovia.vc | 1 day | Google Analytics sets this cookie to store information on how visitors use a website while also creating an analytics report of the website's performance. Some of the collected data includes the number of visitors, their source, and the pages they visit |
| _hjAbsoluteSessionInProgress | .inovia.vc | Session | Detect the first pageview session of a user. |
| _hjFirstSeen | .inovia.vc | 30 minutes | Store first visit to the site. |
| _hjIncludedInSessionSample_2813421 | .inovia.vc | Session | This cookie is set to determine if a user is included in the data sampling defined by your site's daily session limit. |
| 1P_JAR | .google.com | 1 month | These cookies are set via embedded youtube-videos. They register anonymous statistical data on for example how many times the video is displayed and what settings are used for playback. |
| AEC | .google.com | 2 month 1 day |  |
| ajs_anonymous_id | .inovia.vc | 1 year | Store last visit. |
| ajs_group_id | .inovia.vc | 1 year |  |

Advertisement- [x] Advertisement 

Advertisement cookies are used to deliver visitors with customized advertisements based on the pages they visited before and analyze the effectiveness of the ad campaign.

Cookie details
| Name | Domain | Expiration | Description |
| --- | --- | --- | --- |
| __Secure-* | .google.com | 1 year | Cookies whose names begin with __Secure- are secure cookies used primarily to enhance the security of sessions and user data on a website. This prefix is ??a naming convention that indicates that the cookie is set with certain mandatory security measures. |
| APISID | .google.com | 1 year 10 days |  |
| SAPISID | .google.com | 1 year 10 days | The**SAPISID**cookie is used to: * Personalize ads displayed on Google sites. * Track user interactions with Google services (such as YouTube videos). *

*[... truncated, 10,898 more characters]*

---

### Vasco | RevOps for Founders
*582 words* | Source: **GOOGLE** | [Link](https://vasco.app/solutions/founders)

###### Vasco for

![Image 1](https://framerusercontent.com/images/2SZZTl5HMjEYpnwuUub3CN6vQ4.svg?width=12&height=12)

###### founders

![Image 2](https://framerusercontent.com/images/8op0DCLZL53uUN1ZaN01fTfmnI.png?width=854&height=854)

From founder-led sales to predictable revenue engine
----------------------------------------------------

Standardize your GTM motion, forecast with confidence, and update your board of investors without scrambling. No RevOps hire required.

###### Trusted by the world’s most innovative teams

![Image 3](https://framerusercontent.com/images/vtaik9yvrfaOBepT8hjMMNg4w.png?width=1626&height=154)

The system founders trust to scale GTM
--------------------------------------

You built a product that works. Now build a revenue engine that can take you to the next funding round and stage of maturity.

### Investor-ready forecasts without guesswork

No more gut calls. See what's working, what's stuck, and what's next with 100% automated, reverse-engineered forecasting and performance to target.

![Image 4](https://framerusercontent.com/images/pz7whHA6YsXoYjgfaZDTNEhMz4g.svg?width=284&height=284)

### Clear GTM insights, no operator required

Instantly see funnel health, pipeline efficiency, and channel performance without adding operational overhead or complexity.

![Image 5](https://framerusercontent.com/images/2hEYnsNgnxqaJXol8EFLJUDrM.svg?width=284&height=284)

### Discover your true ICP without straining resources

Quickly pinpoint your most profitable customers and confidently expand into untapped elements with ICP insights built for scale.

![Image 6](https://framerusercontent.com/images/o8sr5gHqH0CBW3VD2GAur5ERVs.svg?width=284&height=284)

### operate on insights, not instincts

"With Vasco, we’re no longer running blind. It’s our secret weapon for predictable sales, investor-ready reporting, and securing funding."

![Image 7: Thierry Ajaltouni Vessel.co](https://framerusercontent.com/images/7SD6nWEB4ixI9IDvAQ4qyr33TuQ.png?width=1080&height=1080)

###### Thierry Ajaltouni

Co-founder, Vessel.co

###### Forecast with founder-level confidence

Build precision forecasts tied to high-level goals, conversion rates, team capacity, and unit economics. Plan quarters that exceed expectations, stress-tested with scenario modelling so you can always hit your targets.

![Image 8: top down forecasting](https://framerusercontent.com/images/qC9VXW8seqAmqWM05wFJHOmWa5I.png?width=779&height=519)

###### Stay ahead of every opportunity

Monitor live pipeline coverage, activity SLAs, and deal progression. Spot issues instantly and take proactive, corrective measures without delays or guesswork.

![Image 9: activity SLAs](https://framerusercontent.com/images/3fzVDYoANLE8etn7pdat5vUullA.png?width=779&height=519)

###### Build investor-ready reports in minutes

Create dynamic, real-time dashboards and reports with a drag-and-drop interface. Clearly communicate revenue health, pipeline metrics, and forecasts directly to investors with automated WBRs, QMBRs, and QBRs.

![Image 10: business intelligence platform](https://framerusercontent.com/images/OvorYI0tlMX2Y0UihsWqQncVaM.png?width=2401&height=1601)

###### Unlock your CRM's true potential

Get structured data, automated enrichment, and normalized channel attribution so you can confidently define your ICP, drive accurate reporting, and build a CRM foundation designed for long-term scale.

![Image 11: data hygiene](https://framerusercontent.com/images/yQdpV003bmg8LIR3GHTFrag8oI.png?width=2401&height=1601)

![Image 12](https://framerusercontent.com/images/ao8zZPVpR7k30QTauXmGFT4.svg?width=390&height=200)

How
---

![Image 13](https://framerusercontent.com/images/YzVdF94FTE8E34ULZ9cfyBLJPA.png?width=426&height=104)

Optimized
---------

their pipeline and strengthened investor confidence
---------------------------------------------------

#### Frequently asked questions

###### Is this just another dashboard tool?

No. Vasco helps you manage the entire go-to-market system. You can set ARR goals and reverse-engineer top-down, bottom-up, and unit economics forecasting. We then set SLAs, monitor performance-to-target, and helps you fix GTM performance in real time. It gives you visibility into what’s working, what’s stalling, and what needs attention.

###### How much setup time do I need?

Time is based on the level of customization and depth of your GTM motion. Companies with multiple CRMs, complex lifecycle stages, and multiple motions will require more time to setup than early-stage startups or one-person RevOps teams.

###### What if our GTM is still messy and evolving?

That’s exactly when Vasco helps most. The platform brings structure to your data, normalizes your funnel, and highlights what’s holding back performance. You don’t need to be perfect to get started.

###### Can Vasco help with board reporting and investor updates?

Yes. Vasco gives you immediate access to the metrics and context your board cares about. You can answer questions 

*[... truncated, 361 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Vessel raises $10.3 million to retool VC for the age of AI | BetaKit](https://betakit.com/vessel-raises-10-3-million-to-retool-canadian-vc-for-the-age-of-ai/)**
  - Source: betakit.com
  - *Jun 10, 2025 ... Vessel co-founders Thierry Ajaltouni (left) and CEO Thomas Terrats (right). Platform developed by two ex-LPs aims to automate “grunt ...*

- **[Talabat talks Saudi, Stargate stalls](https://www.fwdstart.me/p/talabat-talks-saudi-stargate-stalls)**
  - Source: fwdstart.me
  - *Jun 12, 2025 ... Founded by Thomas Terrats and Thierry Ajaltouni, Vessel helps GPs automate reporting, compliance, and LP engagement. ... Podcast · Pr...*

- **[Vessel - Crunchbase Company Profile & Funding](https://www.crunchbase.com/organization/vessel-5d57)**
  - Source: crunchbase.com
  - *Legal Name Vessel Funds Inc. Operating Status Active. Company Type For Profit. Founders Nebez Briefkani, Thierry Ajaltouni. Contact Email support@vess...*

- **[Investing in Vessel: A Full-Circle Journey Built on Relationships ...](https://www.inovia.vc/inovia-conversations/investing-in-vessel-a-full-circle-journey-built-on-relationships/)**
  - Source: inovia.vc
  - *Jun 10, 2025 ... ... Vessel founders Thomas Terrats and Thierry Ajaltouni bring an insider perspective. ... Related Article: Vessel raises $10.3 milli...*

- **[Vessel raises $10.3M CAD to modernize venture capital with AI ...](https://www.founderstoday.news/vessel-raises-over-10-millions/)**
  - Source: founderstoday.news
  - *Jun 10, 2025 ... Read this article in: Select Language, Arabic, Dutch, English, French ... Founded by former LPs Thomas Terrats and Thierry Ajaltouni,...*

- **[RevOps for Founders - Vasco](https://vasco.app/solutions/founders)**
  - Source: vasco.app
  - *It's our secret weapon for predictable sales, investor-ready reporting, and securing funding." Thierry Ajaltouni Vessel.co ... Blog · Success Stories....*

- **[Customer Stories - Vasco](https://vasco.app/customer-stories)**
  - Source: vasco.app
  - *Revenue Architecture Clarity with Vasco. Thierry Ajaltouni, Vessel.co. "With ... Resources · Blog · Case studies · Playbooks. Company. Careers · Consu...*

- **[15 Funded Canadian Startups To Watch Out For In 2026 ...](https://www.supercharged.studio/blog/15-canadian-startups-to-watch-out-for-2026)**
  - Source: supercharged.studio
  - *Established by Nebez Briefkani and Thierry Ajaltouni in 2022 in Montréal, Vessel ... Latest Blog Posts. Explore our blog for fresh UX design insights ...*

---

*Generated by Founder Scraper*
