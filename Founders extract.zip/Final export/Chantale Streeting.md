# Chantale Streeting

## Position actuelle

**Titre** : Co-Founder and Chief Operating Officer
**Entreprise** : TBD MTL
**Durée dans le rôle** : 1 year 2 months in role
**Durée dans l'entreprise** : 1 year 2 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Bars, Taverns, and Nightclubs

## Description du rôle

Operations and strategy.
Find us in the news: https://ca.billboard.com/montreal-music-venues-diving-bell

## Résumé

15+ years of experience in different roles in the startup scene has earned me a lot of exposure to ways of keeping businesses lean and mean. My team acts as a right-hand to Founders so they can get out of the day-to-day and focus on strategic items.

When you work with us, we become part of your organization and build trust with you and/or your teams. We work to understand your needs as a business, then set up or optimize systems, workflows, and automations, advising on strategy and best practices in the process. We have a high level of empathy and a sixth sense for understanding an organization’s vitals.

And about me personally: I have a standard for clear expectations, clean data, amazing UX, and strong leadership.

If this speaks to you, let’s talk.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA96AmABd7jzWOByqdl7c1y4eXMICHR2u04/
**Connexions partagées** : 37


---

# Chantale Streeting

## Position actuelle

**Entreprise** : Practicis Strategies

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 2nd


---

# Chantale Streeting

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7399413920500908032 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGlye44HQGi8Q/feedshare-shrink_800/B4EZqvJKogHcAg-/0/1763875008046?e=1766620800&v=beta&t=1W-dUoUIN0cKtBGpJgAHj3LQMa9ek_arhb9NJFWCLI4 | The older I grow, I understand that we can’t make it alone, and that community is key. And whatever you give typically returns to you ten-fold. | 2 | 0 | 0 | 1w | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.113Z |  | 2025-11-26T11:49:13.110Z | https://www.linkedin.com/feed/update/urn:li:activity:7399352481887068160/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7388162966744952832 | Text |  |  | Here is every Founder’s job description:

- Fall in love with the problem you’re solving
- Find and fall in love with the people that will help you launch the solution to that problem
- Get attention on the business (aka sales, maybe funding)
- Give people the space to succeed or fail
- Be a resource and cheerleader to that team; be available to answer questions, to help, and to uplift your team

Being a Founder is really that simple. | 12 | 1 | 0 | 1mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.114Z |  | 2025-10-26T10:41:56.702Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7387443678291808256 | Text |  |  | The most successful leaders make their personal health their top priority.

When you’re a leader, everyone needs you;

Your team needs you sharp.

Your friends and family need you present.

Your clients need answers.

You know you can’t be everything to everyone… and somewhere in there you might forget that you’re human too. You need you.

You can’t lead from empty, so take care of yourself. That’s your top priority. | 7 | 0 | 0 | 1mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.114Z |  | 2025-10-24T11:03:44.971Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7385985668537061376 | Text |  |  | [DISCLAIMER]: The following was not written by AI, it comes from my brain. You've been warned:

In 2017 I had a mandate to build a pitch deck and website for a 3D scanning company with a patented methodology.

As I asked more questions, I could tell that this mandate was going to be difficult. The founders were very excited about their product as "it can scan and analyze everything!"

Try to build a pitch deck that describes seven different Total Addressable Markets...

Try to build a website with seven different brandings to speak to those markets...

Disaster.

My advice to them, before starting the website and pitch deck exercise: "Do ONE thing, and do it WELL."

Needless to say, this crushed the founders. I remember seeing that "you just don't get it, this is going to be HUGE!" look in their eyes. I ended up having to build a (very long) pitch deck and a website that looked like an ADHD-ers brain dump.

And that was the end of my mandate with them.

Eight years later, I just did a Google search for them. Guess what?

They are serving but ONE market. And they are doing it VERY WELL.

As an entrepreneur, it's important - and CRUCIAL - to have BIG VISON. But it doesn't mean you have to execute it all at once. More variables means less control and more possibility + points of failure.

Unless you already have:

1) More capital than you know what to do with;
2) The right team in place;
3) A validated product-market fit;

It's essential to start small, fail fast, iterate. Rinse and repeat.

If you liked this, consider giving me a follow. There will be more. | 4 | 0 | 0 | 1mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.116Z |  | 2025-10-20T10:30:08.357Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7382090307024355329 | Text |  |  | "Five years of sales experience in 60 f*cking seconds - Let's f*cking go!"

(This is the transcript of a video from Instagram that made me chuckle. Follow @devin.the.one on IG).

"Number one: People don't buy products. They buy how you make them feel. They buy how you make them feel about the outcome. So fix your f*cking energy, not just your pitch."

"Number two: Rejection isn't personal unless you make it f*cking personal. Then it's just emotional cardio and sh*t."

"Number three: Follow-ups make the money, but most of y'all treat leads like f*cking exes. You text once, you get f*cking ignored and you never try again. Follow up with these f*cking people."

"Number four: The customer isn't always f*cking right, but they're always watching. Stay professional, even when they're acting like a f*cking cartoon villain."

"Number five: You don't need the f*cking perfect script. You need confidence, empathy, and Wi-Fi that doesn't cut out mid-f*cking-close."

"Number six: Sales is just therapy with commission. You're basically paid to solve problems, calm down emotions, and sound like you have your f*cking life together. The whole time, internally, you're f*cking losing your shit."

"Number seven: Your tone sells more than your words. Smile when you talk. People can hear the fake happiness. It f*cking worked."

"Number eight, stop chasing easy f*cking money. Sales will test your ego, patience, and your f*cking soul. But once you master it, you can sell almost anything."

"That's five years of f*cking sales wisdom in one minute. Saves you a few breakdowns and three failed commissions."

Hope you liked Devin's delivery as much as I did. Go Venmo him: @Linderlifefitness | 4 | 0 | 0 | 1mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.117Z |  | 2025-10-09T16:31:21.800Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7356081418000564225 | Text |  |  | The most important factor that determines the success of a business:

The right people in the right seats.

That’s it, that’s the post. | 5 | 0 | 0 | 4mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.117Z |  | 2025-07-29T22:01:19.435Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7333529152853049344 | Document |  |  | TechnoCompétences recrute un•e adjoint•e administratif•ive ! Venez faire partie d'une organisation qui a comme mandat de soutenir la main d'oeuvre dans le secteur des technologies de l'information et des communications au Québec :) Temps partiel, 21 heures, 4 jours par semaine pour 32-40k$. | 2 | 0 | 0 | 6mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.118Z |  | 2025-05-28T16:26:40.423Z | https://www.linkedin.com/feed/update/urn:li:activity:7333477200014311425/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7315114356575272960 | Video (LinkedIn Source) | blob:https://www.linkedin.com/0fd62525-4ea9-4022-91c8-2e1ff20602a9 | https://media.licdn.com/dms/image/v2/D5605AQFded3bdgd7-g/feedshare-thumbnail_720_1280/B56ZYQx2cSGoA8-/0/1744038226709?e=1765778400&v=beta&t=NvXZifqyo25z0oCCerwooJLxWRoiR7xLTCU2iD9nhw8 | Mon équipe chez TechnoCompétences a monté la plateforme MaTN (ma-tn.ca) pour aider les entreprises avec leur transformation numérique. Voici un petit témoignage de l’impact de ce genre de virage au sein des PMEs: | 4 | 0 | 0 | 8mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.119Z |  | 2025-04-07T20:52:50.860Z | https://www.linkedin.com/feed/update/urn:li:activity:7315028463155875840/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7313265149258199041 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGwUlkODt8wFA/feedshare-shrink_800/B4EZX3v5kvG0Ag-/0/1743618284291?e=1766620800&v=beta&t=Y8g6bmmJCkc5qfcJdr5FeXJxjTZMi0rYHsvHtEiA9hE | BTS at TechnoCompétences where I am relating our strategic objectives to key results. Happy new fiscal year 🎉

Thanks Josiane Stratis M. Sc for the candid shot 📷 | 12 | 1 | 0 | 8mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.120Z |  | 2025-04-02T18:24:45.479Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7307757769267240961 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFjk6UwYOWIQA/feedshare-shrink_800/B4EZWpTxyzGwAk-/0/1742302291939?e=1766620800&v=beta&t=j1g96uP_-9nVf8sGp-K_elh0X8fac0H9Gafo7YW8_Tk | Pour tous les gens en marketing dans mon réseau, et/ou les gens qui veulent simplement ajouter à leur trousse de « mad skills », ma collègue Josiane Stratis M. Sc offra une formation en marketing et IA demain via TechnoCompétences. Inscrivez-vous👇 | 1 | 0 | 0 | 8mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.121Z |  | 2025-03-18T13:40:23.767Z | https://www.linkedin.com/feed/update/urn:li:activity:7307745476903129089/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7305942935940857856 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E10AQF9fDV-9EH1Vg/ads-video-thumbnail_720_1280/B4EZWPmd3wHcAc-/0/1741871001248?e=1765778400&v=beta&t=jlHaw2-UYzGXxfWZ6qw28pnDghSR6qiDTl8WroCrhqo | L’organisation où je suis Directrice des opérations, TechnoCompétences, offre une formation full intéressante sur l’Éthique et la technologie. Ça promet de faire réfléchir 🤔 Inscrivez-vous👇 | 2 | 0 | 0 | 8mo | Post | Chantale Streeting | https://www.linkedin.com/in/chantalestreeting | https://linkedin.com/in/chantalestreeting | 2025-12-08T05:14:16.122Z |  | 2025-03-13T13:28:53.784Z | https://www.linkedin.com/feed/update/urn:li:activity:7305937014879584257/ |  | 

---



---

# Chantale Streeting
*Practicis Strategies*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Navigating the purchase of a practice with Chantelle Stander](https://www.youtube.com/watch?v=4likovOe3qk)
*2025-01-25*
- Category: video

### [How to Run Fintech PR Activity Like a Pro, with Chantal Swainston, Fintech PR Consultant & Founder of The Heard - The Fintech Marketers and Leaders Podcast](https://poddtoppen.se/podcast/1615382324/the-fintech-marketers-and-leaders-podcast/how-to-run-fintech-pr-activity-like-a-pro-with-chantal-swainston-fintech-pr-consultant-founder-of-the-heard)
*2025-04-28*
- Category: podcast

### [How to run fintech PR activity like a pro, with Chantal Swainston, Fintech PR Consultant & Founder of The Heard](https://www.growthgorilla.co.uk/blog/how-to-run-fintech-pr-activity-like-a-pro-with-chantal-swainston-fintech-pr-consultant-founder-of-the-heard)
*2024-03-04*
- Category: blog

### [Chantal & Danielle Khan](https://rootandseed.com/blogs/root-and-seed-podcast-season-2/chantal-danielle-khan)
*2023-05-26*
- Category: podcast

### [- YouTube](https://www.youtube.com/watch?app=desktop&v=xnmxM1u7S-c)
*2025-06-04*
- Category: video

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
