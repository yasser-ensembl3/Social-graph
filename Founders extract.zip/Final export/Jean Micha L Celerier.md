# Jean-Michaël Celerier

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393192122209841152 | Video (LinkedIn Source) | blob:https://www.linkedin.com/dd1c0a03-2e6e-4994-bf69-1d75d56122b4 | https://media.licdn.com/dms/image/v2/D5605AQHheoYjgPQOgw/videocover-high/B56ZpnlBNJIYBU-/0/1762674353156?e=1765774800&v=beta&t=onYyHxURVTgGQNKvqJQi3FyjFhZV2owBnOy2xtKp7do | It took waaaaaay too many restless evenings and retries but it's finally done. 

A pure C++ reimplementation of #StreamDiffusion, straight #cuda #onnx and #tensorrt, zero Python or PyTorch dependencies required at runtime, just pure native code goodness. Will be trivial to integrate into any app as a single DLL on Windows or .so on Linux. Insanely fast to start, adjust and reload compared to the Python version.

All SD1.5, LCM, SD-turbo and SDXL models are supported, with txt2img and img2img workflows. Prompt interpolation is done and very soon ControlNet, ip-adapter and the StreamV2V pipeline adjustments will be there too. 

Massive FPSes even on a trusty five-year-old GTX 3090.

Get in touch to be informed of the release! | 2518 | 126 | 65 | 4w | Post | Jean-Michaël Celerier | https://www.linkedin.com/in/jcelerier | https://linkedin.com/in/jcelerier | 2025-12-08T04:53:40.565Z |  | 2025-11-09T07:46:00.802Z |  |  | 

---

