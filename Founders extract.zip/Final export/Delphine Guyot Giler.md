# Delphine Guyot Giler

## Position actuelle

**Titre** : Co-Fondatrice
**Entreprise** : Liftia
**Durée dans le rôle** : 11 months in role
**Durée dans l'entreprise** : 11 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Business Consulting and Services

## Description du rôle

Liftia aide les sociétés à adopter et appliquer l’IA rapidement. Nous formons les équipes pour intégrer concrètement l'IA dans le quotidien afin d'avoir des résultats immédiats.

💡 Pourquoi Liftia ?
Parce que l’IA, ce n’est pas juste une révolution technologique, c’est une opportunité en or pour booster la productivité, optimiser le travail et libérer la créativité des équipes.

Et surtout, chaque collaborateur peut en tirer parti… encore faut-il savoir par où commencer !

✨ Nous accompagnons TOUTES les entreprises avec :
🚀 Des conférences immersives pour embarquer vos collaborateurs
📖 Des formations adaptées à tous les niveaux
🛠️ Des ateliers spécialisés par service pour passer à l’action
🤖 Des développement d’outils IA sur mesure

✨ Notre promesse ?
Faire de l’IA un réflexe naturel, un véritable levier de croissance et d’innovation, et surtout, dire adieu aux idées reçues !

## Résumé

Chez Liftia, on fait de l’IA un réflexe quotidien ! 🤖✨ Experts en IA et en formation, on transforme chaque collaborateur en pro de l’automatisation. 🚀 Fini le casse-tête ou les grands mots, place à l’efficacité (avec un brin de magie) ! ✨
🤖 Nous proposons 4 offres pour faire de l’IA un véritable allié du quotidien dans votre entreprise :

🚀 Conférences d’acculturation : On embarque tous vos salariés dans l’intégration de l’IA avec des interventions inspirantes et accessibles. Fini la peur de l’IA, place à la curiosité !

🎓 Formations individuelles : On forme chaque collaborateur à maîtriser l’IA pour gagner en efficacité. ChatGPT, automatisation, data… Tout devient (presque) aussi simple qu’un café serré ! ☕

🛠 Ateliers métiers : On passe de la théorie à la pratique en appliquant l’IA dans chaque service. Marketing, RH, finance… Chacun repart avec des solutions concrètes pour son job.

🤖 Développement sur-mesure : On crée des outils IA personnalisés et des agents intelligents adaptés à votre entreprise. L’IA devient un membre de l’équipe (et qui ne prend jamais de pause-café !).

Prêts à intégrer l’IA intelligemment ? 

📞 Discutons de vos besoins :
Contactez moi directement par email delphine@liftia.ai

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAASHgsIBKjoGhrIc67kpqfUl6K7OUaegEzA/
**Connexions partagées** : 73


---

# Delphine Guyot Giler

## Position actuelle

**Entreprise** : Liftia

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Delphine Guyot Giler

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402400017853947904 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFY0Zhp35pUlQ/feedshare-shrink_800/B4EZrllD7nJ0Ao-/0/1764788295516?e=1766620800&v=beta&t=kwm3gEvG3iSr8tXTvqcN3TNS_O26mH96aN0BO6ni5KI | Très heureuse de partager les deux sessions que Liftia a animées chez Espresso communication autour de l’IA générative.
 Un vrai plaisir de collaborer avec des équipes aussi engagées et ouvertes à explorer de nouveaux usages.
Merci pour leur confiance et leur accueil ☕ | 11 | 0 | 0 | 3d | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:39.948Z |  | 2025-12-04T17:34:54.198Z | https://www.linkedin.com/feed/update/urn:li:activity:7402338564371431424/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397271781633323008 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFLpdDwEgoQ1A/feedshare-shrink_800/B4EZqddLEyIQAg-/0/1763578264656?e=1766620800&v=beta&t=OS2R9KwpLoTZri8lYg7JPexxF3DaW9oHArDflpbLOYg | Nouveaux bureaux pour Liftia Canada, sur l’Avenue du Mont-Royal.
 Un lieu à notre image, pour continuer à faire grandir l’aventure.
 📸 Quelques photos juste ici 👇 | 44 | 4 | 0 | 2w | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:39.949Z |  | 2025-11-20T13:57:07.405Z | https://www.linkedin.com/feed/update/urn:li:activity:7397265067878285312/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7391499031555760128 | Article |  |  | 📬 Dans la newsletter Liftia de cette semaine :
 on vous parle d’une intervention client récente, d’assistants IA… et de ce qu’on retient des annonces Mistral, OpenAI...
👉 À lire ici : https://lnkd.in/eReHRzpz

 (et à recevoir chaque semaine en vous abonnant en bas de page) | 14 | 0 | 0 | 1mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:39.951Z |  | 2025-11-04T15:38:16.534Z | https://liftia.substack.com/p/newsletter-ia-du-04-novembre-2025 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7384620998886735873 | Article |  |  | On parle de plus en plus de l’IA comme si elle pensait, ressentait ou décidait.
 Mais derrière les mots, il y a une réalité bien plus simple (et bien plus importante à comprendre) : l’IA ne « comprend » pas. Elle calcule, elle prédit, elle complète.
Dans ce très bon article, Vladimir S., chef de projet chez Liftia, remet les choses à plat :
 ce que l’IA est vraiment, ce qu’elle n’est pas… et pourquoi notre manière d’en parler brouille parfois notre capacité à l’utiliser efficacement.
👉 À lire ici : https://lnkd.in/dWWQqyZW

 Et à garder en tête quand on parle de "pensée" artificielle. | 27 | 4 | 0 | 1mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:39.952Z |  | 2025-10-16T16:07:25.758Z | https://liftia.substack.com/p/blog-liftia-derriere-le-vernis-des |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7368644869772328960 | Article |  |  | 📬 Chaque semaine, on vous prépare chez Liftia une veille IA simple, claire et directement utile.
 Pas besoin d’y passer des heures, on vous donne l’essentiel à retenir pour rester à jour.
👉 Voici celle de cette semaine : https://lnkd.in/etReNeQc

 Et si vous voulez la recevoir directement par courriel, envoyez-moi un petit mot ou abonnez-vous ! | 20 | 1 | 1 | 3mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.958Z |  | 2025-09-02T14:03:59.755Z | https://open.substack.com/pub/liftia/p/newsletter-ia-du-02-septembre-2025?r=5yjx1d&utm_campaign=post&utm_medium=web&showWelcomeOnShare=true |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7348292154382794752 | Article |  |  | Un post qui résume parfaitement notre vision chez Liftia : l’IA n’a pas besoin d’être parfaite pour être utile.
 Merci Alexandre Lapalme pour cet article aussi éclairant que rafraîchissant.
 À lire absolument si vous travaillez avec l’IA (ou que vous hésitez encore à le faire) 👇 | 17 | 0 | 1 | 4mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.959Z |  | 2025-07-08T10:09:34.271Z | https://liftia.ai/et-si-on-faisait-fausse-route-en-voulant-une-ia-parfaite/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7337902007610994689 | Text |  |  | ✨ Et une nouvelle certification pour Liftia… et pas des moindres ! ✨

Nous sommes fiers d’annoncer que Liftia est désormais un organisme formateur agréé par la Commission des partenaires du marché du travail du Québec (CPMT) 🎓✅

Cet agrément permet aux employeurs assujettis à la Loi favorisant le développement et la reconnaissance des compétences de la main-d’œuvre de faire reconnaître les formations offertes par Liftia comme dépenses admissibles.

🎯 C’est une nouvelle étape clé qui confirme la qualité de notre approche pédagogique et notre volonté de contribuer activement au développement des compétences au Québec, notamment autour de l’IA générative, des outils numériques et de la transformation des pratiques professionnelles.
Un immense merci à toutes celles et ceux qui nous soutiennent dans cette aventure !

📩 Envie d’en savoir plus sur nos programmes de formation ? Écrivez-nous ! | 48 | 0 | 2 | 5mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.962Z |  | 2025-06-09T18:02:50.241Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7333591871333584896 | Text |  |  | 🎉 Liftia est maintenant organisme de formation agréé par la SOFEDUC - Société de formation et d'éducation continue !
Cette reconnaissance officielle nous permet de délivrer des UEC (unités d’éducation continue), reconnues par plusieurs ordres professionnels au Québec.
 Une étape importante pour renforcer la qualité et l’impact de nos formations auprès des organisations et des professionnel·le·s en quête de montée en compétences sur l’IA générative et ses usages concrets.

💼 Vous souhaitez former vos équipes tout en valorisant le développement professionnel continu ?
 📩 Écrivez-moi ou visitez liftia.ai | 47 | 0 | 4 | 6mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.963Z |  | 2025-05-28T20:35:53.674Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7331693630971072512 | Text |  |  | 🎓 Notre formation “IA Générative, ChatGPT & Prompts” revient les 25 et 27 juin.
 Toujours en ligne, en français, sur 2 demi-journées, et surtout : toujours axée sur la pratique, la clarté et l’impact concret.

C’est fait pour vous si :
 • Vous voulez comprendre comment fonctionne (vraiment) l’IA générative
 • Vous cherchez à mieux exploiter ChatGPT dans votre quotidien pro
 • Vous voulez apprendre à écrire des prompts efficaces sans jargon technique

🗓 25 & 27 juin 2025
 🕗 8h–11h30 (Montréal) 🇨🇦 / 14h–17h30 (Paris) 🇫🇷
📍 Une formation conçue par Liftia, en petit groupe pour favoriser les échanges
📩 Intéressé.e ? Écrivez-moi directement ici ou à delphine@liftia.ai | 20 | 0 | 2 | 6mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.963Z |  | 2025-05-23T14:52:57.904Z |  |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7328449342963396608 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSmmyNmhLnrQ/feedshare-shrink_800/B4EZbO_GvUHIAg-/0/1747229371892?e=1766620800&v=beta&t=jNFYaxZGHsp5ZxkCmlMhOUfxY9gCytflYteagcO31_c | 📣 Liftia accompagne désormais les entreprises luxembourgeoises dans leur transition vers l’IA ! 🇱🇺
 Merci à Telkea Academy pour leur confiance 🙏
Ensemble, on propose des formations concrètes, accessibles et adaptées à tous les métiers : RH, vente, marketing, juridique, administratif…
🎯 Objectif : faire de l’IA un vrai levier de productivité et d’efficacité pour les équipes, quel que soit leur niveau.
👇 Tous les détails dans le post de Telkea Academy juste ici ! | 26 | 1 | 2 | 6mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.964Z |  | 2025-05-14T16:01:19.367Z | https://www.linkedin.com/feed/update/urn:li:activity:7328430158166605826/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7325174766183616513 | Article |  |  | 📣 Tu travailles en vente ou t'intéresses à l’IA appliquée à la performance commerciale ? Ce webinaire est pour toi !
Le 3 juin, mon collègue Mikael Witwer de Liftia animera une session sur un sujet qu’il maîtrise à fond :
 “L’IA au service de la performance commerciale”
Au programme : des exemples concrets, des outils simples à utiliser, et zéro jargon.
 L’objectif : t’aider à voir clair, et passer à l’action dès le lendemain.
🗓 Le 3 juin à 8h (Montréal) 🇨🇦  / 14h (Paris)
 💻 En ligne – Gratuit – Ouvert à tous
 👉 Inscription ici : https://lnkd.in/eJg44Q3h
N’hésite pas à partager autour de toi si tu connais des personnes que ça pourrait intéresser ! 🙌 | 16 | 0 | 2 | 7mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.965Z |  | 2025-05-05T15:09:19.424Z | https://streamyard.com/watch/NKKNHcUKT8W8 |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7322638043381706752 | Text |  |  | 🚀 Nouvelles dates pour notre formation “IA Générative, ChatGPT & Prompts” chez Liftia !
Après le succès des sessions d’avril, on remet ça en mai 🎯
📅 Prochaine session : 21 & 23 mai 2025
 🕗 8h–11h30 (heure de Montréal) 🇨🇦 / 14h–17h30 (heure de Paris) 🇫🇷
 📍 En ligne, en français, sur 2 demi-journées
Au programme :
 • Comprendre (vraiment) ce qu’est l’IA générative
 • Maîtriser ChatGPT et l’art des prompts efficaces
 • Découvrir des cas d’usage concrets pour booster votre quotidien pro
✅ Formation rythmée, interactive, orientée pratique.
📩 Pour plus d’infos ou pour vous inscrire, écrivez-moi en MP ou par email à delphine@liftia.ai ! | 18 | 2 | 2 | 7mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.966Z |  | 2025-04-28T15:09:17.578Z |  |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7321234418436628480 | Text |  |  | 📣 On recrute chez Liftia !
On cherche un·e chef.fe de projet & formateur·trice à Montréal ( en mode hybride) pour rejoindre l’aventure.

 Tu aimes transmettre, animer, vulgariser des sujets comme l’IA générative ? Tu veux bosser dans un environnement humain, stimulant, et en pleine croissance ?
👉 Viens faire équipe avec nous !

 Les profils pédagogues, curieux, créatifs (et sympas 😉) sont les bienvenus.
📍 Montréal | Temps plein ou partiel | Début : dès que possible
 🧠 Formation assurée sur nos outils
💬 Intéressé·e ou tu connais quelqu’un ? Envoie-moi un message ! | 27 | 1 | 6 | 7mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.967Z |  | 2025-04-24T18:11:47.313Z |  | https://www.linkedin.com/jobs/view/4216700386/ | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7317901910068350976 | Text |  |  | 📢 Dernier rappel avant le lancement !
Notre formation “IA Générative, ChatGPT & Prompts” revient la semaine prochaine chez Liftia
Il reste encore quelques places pour cette nouvelle édition.

👉 Une formation 100% en ligne, en français, sur 2 demi-journées :
 📅 Mercredi 23 et vendredi 25 avril
 🕗 8h–11h30 (Montréal) 🇨🇦 / 14h–17h30 (France) 🇫🇷 

On vous promet :
 • Une approche concrète et accessible
 • Des cas d’usage applicables à votre métier
 • Une méthode claire pour créer des prompts efficaces
🎯 Que vous soyez curieux, débutant ou déjà utilisateur de ChatGPT, cette formation est faite pour vous.

📩 Pour plus d’infos ou pour vous inscrire : delphine@liftia.ai ou en MP. | 10 | 0 | 0 | 7mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.968Z |  | 2025-04-15T13:29:35.403Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7315027811168079873 | Text |  |  | 📣 Rappel : notre webinar “L’IA au service de votre entreprise” a lieu ce jeudi 11h 🇨🇦 /17h 🇫🇷 !
 Il est encore temps de vous inscrire, c’est gratuit et en ligne, lien dans le post ci-dessous 👇 | 11 | 1 | 1 | 8mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.968Z |  | 2025-04-07T15:08:56.827Z | https://www.linkedin.com/feed/update/urn:li:activity:7312391039338643457/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7313165939607298049 | Document |  |  | Mikael Witwer animera notre tout premier webinar chez Liftia le 10 avril 11h 🇨🇦  / 17h 🇫🇷  : “L’IA au service de votre entreprise” – un format en ligne, 100% gratuit, pour comprendre comment utiliser l’IA concrètement au quotidien. 
Toutes les infos sont dans le post ci-dessous ! 
Pour vous inscrire, c’est par ici 👉 https://lnkd.in/epUEHuKb | 8 | 1 | 1 | 8mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.969Z |  | 2025-04-02T11:50:32.055Z | https://www.linkedin.com/feed/update/urn:li:activity:7313092390259417088/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7312544081354579968 | Text |  |  | 🚨On rajoute des dates pour notre formation "IA Générative, ChatGPT & Prompts" chez Liftia 🚀
Les premières sessions ont affiché complet — on prolonge donc l’expérience ✌️
Tu veux :
• Comprendre (vraiment) ce qu’est l’IA générative
 • Savoir comment fonctionne ChatGPT (au-delà du buzz)
 • Maîtriser l’art des prompts clairs, efficaces et puissants
 • Découvrir comment intégrer tout ça dans ton quotidien pro 
Alors cette formation est pour toi.
Une approche concrète, rythmée, interactive, avec des cas d’usage et de la pratique.

 Le tout, en petit groupe, en ligne, en français, sur 2 demi-journées.
📅 Prochaine session : 23 & 25 avril 2025
 🕗 8h–11h30 (heure de Montréal) 🇨🇦/ 14h–17h30 (heure de Paris)🇫🇷
Quelques places sont encore disponibles.

Pour plus d’infos ou pour t’inscrire, écris-moi : delphine@liftia.ai ou directement en MP. | 25 | 0 | 2 | 8mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.970Z |  | 2025-03-31T18:39:29.494Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7307413614716403715 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQFb18MqnRm8nw/feedshare-shrink_800/B56ZWkl8aSHQAo-/0/1742223168844?e=1766620800&v=beta&t=2Ek0EZIGMs9ipsJgqhhdaXG2jg_yYllDa4fcneVJ1EU | La semaine dernière, j’ai eu le plaisir d’assister à une conférence animée par mes associés Charles Martin-Laval et Mikael Witwer de Liftia, devant 100 commerciaux du Groupe SATEC, courtier en assurance.
Leur mission 🚀  : démystifier l’intelligence artificielle et montrer comment elle peut devenir un véritable levier de performance commerciale.

Entre un panorama des évolutions de l’IA, des exemples concrets et des démonstrations en direct, l’enthousiasme était au rendez-vous. 
Les échanges ont été riches et ont confirmé une chose : l’IA n’est plus un concept lointain, c’est une opportunité concrète qui peut transformer le quotidien des équipes commerciales.

Si ce sujet vous intéresse et que vous souhaitez en savoir plus sur nos services, je serai ravie d’en discuter avec vous. | 71 | 6 | 1 | 8mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.971Z |  | 2025-03-17T14:52:50.928Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7300192396602998784 | Text |  |  | C’est le début d’une belle aventure : Liftia est officiellement lancée !

Avec Charles Martin-Laval et Mikael Witwer, nous avons décidé de mettre notre expertise au service des entreprises pour les aider à intégrer l’intelligence artificielle de façon concrète, efficace et adaptée à leurs besoins.

L’IA n’est pas une mode, c’est un levier de transformation puissant… à condition d’être bien maîtrisé. Chez Liftia, nous accompagnons les entreprises à chaque étape, du premier déclic jusqu’à l’implémentation avancée.

Et ce n’est que le début ! 🌍 Je partagerai bientôt plus d’informations sur le développement de nos activités au Canada.
Hâte d’échanger avec vous sur ces sujets passionnants !

#IA #IntelligenceArtificielle #Innovation #Entreprises #Transformation #AI #Liftia

-------- 
A new adventure begins: Liftia is officially launched!

Together with Charles Martin-Laval and Mikael Witwer, we’ve created Liftia to help businesses integrate artificial intelligence in a practical, effective, and tailored way.

AI is not just a trend—it’s a powerful transformation tool… but only if implemented the right way. At Liftia, we guide companies through every step, from initial awareness to advanced deployment.

And this is just the beginning! 🌍 I’ll be sharing more soon about our expansion into Canada.
Excited to connect and discuss these exciting topics with you!

#AI #ArtificialIntelligence #Innovation #Business #Transformation #Liftia | 123 | 56 | 5 | 9mo | Post | Delphine Guyot Giler | https://www.linkedin.com/in/delphine-guyot-giler-62a54721 | https://linkedin.com/in/delphine-guyot-giler-62a54721 | 2025-12-08T05:00:46.972Z |  | 2025-02-25T16:38:18.366Z |  |  | 

---



---

# Delphine Guyot Giler
*Liftia*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 4 |

---

## 📚 Articles & Blog Posts

### [StarDust Testing Blog : a blog about user acceptance testing for mobile & website | Delphine Guyot Giler](https://www2.stardust-testing.com/en/author/delphine-guyot-giler)
*2024-05-30*
- Category: article

### [AI Experts & Training - AI Tools - Liftia](https://liftia.ai/en/ai-conference/)
*2025-07-03*
- Category: article

### [LIFT | Lyssna här](https://podcasts.nu/poddar/lift)
*2025-02-03*
- Category: podcast

### [Episode – She Lift Project](https://sheliftproject.com/podcast/)
*2025-04-01*
- Category: podcast

### [Podcast – She Lift Project](https://sheliftproject.com/podcast-episodes/)
*2025-04-01*
- Category: podcast

---

## 📖 Full Content (Scraped)

*9 articles scraped, 9,985 words total*

### StarDust Testing Blog : a blog about user acceptance testing for mobile & website | Delphine Guyot Giler
*1,083 words* | Source: **EXA** | [Link](https://www2.stardust-testing.com/en/author/delphine-guyot-giler)

StarDust Testing Blog : a blog about user acceptance testing for mobile & website | Delphine Guyot Giler

===============

[Skip to Main Content](https://www2.stardust-testing.com/en/author/delphine-guyot-giler#main-content "Skip all the navigation to page content")[Login BugTrapp](https://www.bugtrapp.com/login)
*   [Contact](https://www.stardust-testing.com/en/contact-2/)
*   [Join WAT as a tester!](https://we-are-testers.com/)
*   [About StarDust](https://www.stardust-testing.com/en/about-stardust/)
*   [Blog](https://www2.stardust-testing.com/en)

[StarDust – QA and UAT for all your digital projects](https://www.stardust-testing.com/)
*   [Our services](https://www.stardust-testing.com/en/our-services/)[](javascript:void(0); "Open submenu of previous link")

Our services

We offer QA and UAT testing to ensure the launch of your digital services so that you can provide the best possible user experience for your customers. 

    *   [Consulting](https://www.stardust-testing.com/en/our-services/consulting/)
    *   [Functional Testing](https://www.stardust-testing.com/en/our-services/functional-testing/)
    *   [Operational Testing](https://www.stardust-testing.com/en/our-services/operational-testing/)
    *   [Environmental Testing](https://www.stardust-testing.com/en/our-services/environmental-testing/)
    *   [Regression Testing](https://www.stardust-testing.com/en/our-services/regression-testing/)
    *   [Multilingual Testing](https://www.stardust-testing.com/en/our-services/multilingual-testing/)
    *   [App Benchmarking](https://www.stardust-testing.com/en/our-services/app-benchmarking/)
    *   [Functional Bug Bounty](https://www.stardust-testing.com/en/our-services/functional-bug-bounty/)
    *   [Accessibility Testing](https://www.stardust-testing.com/en/our-services/accessibility-testing/)
    *   [Performance Testing](https://www.stardust-testing.com/en/our-services/performance-testing/)

*   [Our methods](https://www.stardust-testing.com/en/our-methods/)[](javascript:void(0); "Open submenu of previous link")

Our methods

Our wide range of testings services allows you to hunt down bugs throughout the entire lifecycle of your product, in the best conditions. 

    *   [Manual tests](https://www.stardust-testing.com/en/our-methods/manual-tests/)
    *   [Automated Tests](https://www.stardust-testing.com/en/our-methods/automated-tests/)
    *   [Our Testers in your Lab](https://www.stardust-testing.com/en/our-methods/our-testers-in-your-lab/)
    *   [Crowdsourced Testing](https://www.stardust-testing.com/en/our-methods/community-of-testers/)
    *   [UX/UI Testers](https://www.stardust-testing.com/en/our-methods/ux-ui-testers/)
    *   [BugTrapp](https://www.stardust-testing.com/en/our-methods/bugtrapp/)

*   [Our customers](https://www.stardust-testing.com/en/our-customers/)[](javascript:void(0); "Open submenu of previous link")

Our customers

We have clients across a variety of industries. Through our case studies, you will find the details of QA&UAT for the sectors that we work with on a regular basis. 

    *   [Luxury](https://www.stardust-testing.com/en/our-customers/luxury/)
    *   [Online Betting](https://www.stardust-testing.com/en/our-customers/online-betting/)
    *   [Banking/Insurance](https://www.stardust-testing.com/en/our-customers/banking-insurance/)
    *   [Health](https://www.stardust-testing.com/en/our-customers/health/)
    *   [Food Industry](https://www.stardust-testing.com/en/our-customers/food-industry/)
    *   [Transportation](https://www.stardust-testing.com/en/our-customers/transportation/)
    *   [Retail](https://www.stardust-testing.com/en/our-customers/retail/)
    *   [Energy](https://www.stardust-testing.com/en/our-customers/energy/)
    *   [Sports and Leisure](https://www.stardust-testing.com/en/our-customers/sports-and-leisure/)
    *   [Agencies](https://www.stardust-testing.com/en/our-customers/agencies/)
    *   [Web Services development](https://www.stardust-testing.com/en/our-customers/web-services-development/)
    *   [App-IoT Pure Player](https://www.stardust-testing.com/en/our-customers/app-iot-pure-player/)
    *   [Web Pure Player](https://www.stardust-testing.com/en/our-customers/web-pure-player/)
    *   [Media](https://www.stardust-testing.com/en/our-customers/media/)
    *   [Tourism/Hospitality](https://www.stardust-testing.com/en/our-customers/tourism-hospitality/)
    *   [Smart Home](https://www.stardust-testing.com/en/our-customers/smart-home/)

*   [Publications](https://www.stardust-testing.com/en/publications/)[](javascript:void(0); "Open submenu of previous link")

Publications

Discover all our publications such as white papers and infographics that will give you all the information you need to prepare your testing project.

[See our publications](https://www.stardust-testing.com/en/publications/) 

Our most recent publications

    *   [Infographic: IOT's : A Question of Quality](https://www.stardust-testing.com/en/publication

*[... truncated, 10,057 more characters]*

---

### AI Experts & Training - AI Tools - Liftia
*666 words* | Source: **EXA** | [Link](https://liftia.ai/en/ai-conference/)

Interactive AI Conferences:

Inspire and engage your teams in the AI era

**Liftia** Guides you in turning AI into action throughout your entire organization!
------------------------------------------------------------------------------------

/An engaging setup to immerse your employees in the **AI** experience
---------------------------------------------------------------------

Our **interactive talks** immerse your teams in the real-world challenges of AI. Far from theoretical lectures, these dynamic sessions blend live demos and practical examples tailored to your industry.

/A committed approach to ensure effective AI integration
--------------------------------------------------------

This dynamic and inclusive format mobilizes your entire workforce and embeds AI thinking into your company culture.

Our aim: make AI accessible, spark curiosity, and equip your teams to leverage it with confidence.

![Image 1](https://liftia.ai/wp-content/uploads/2025/04/conference-ia-liftia-satec.webp)

![Image 2](https://liftia.ai/wp-content/uploads/2025/04/hero-conference-2-1024x683.webp)

/The value of our AI conferences
--------------------------------

**Get your teams on board** with a company-wide transformation in the age of AI

**Inspire employees** to harness AI in their daily work

**Demystify AI**and make it accessible to all

/An AI conference designed for total team immersion
---------------------------------------------------

/Why choose our AI conferences?
-------------------------------

Rated 4.8

/Inside our session with Satec
------------------------------

![Image 3](https://liftia.ai/wp-content/uploads/2025/04/liftia_ai_logo.jpg)

![Image 4: 🚀](https://s.w.org/images/core/emoji/16.0.1/svg/1f680.svg) AI for Sales Growth: A Unique Liftia Conference at Satec!

[Charles Martin-Laval](https://www.linkedin.com/in/charles-martin-laval-7b92ab11/)&[Mikael Witwer](https://www.linkedin.com/in/mikaelwitwer/) had the pleasure of hosting the first AI acculturation conference for 100 salespeople from the [SATEC Group](https://www.linkedin.com/company/groupe-satec/)an insurance broker.

The aim? Make AI accessible and highlight its value as a real lever for commercial impact. … . .. [more](https://www.linkedin.com/posts/liftia-ai_ia-assurance-daezveloppementcommercial-activity-7306226170566426624-GYCx/?utm_source=share&utm_medium=member_desktop&rcm=ACoAAAJn44wB4Uq_Ly19boVXS3KzmoTlfeh9bTk)

![Image 5: post linkedin SATEC Liftia](https://liftia.ai/wp-content/uploads/2025/04/post-linkedin.webp)

![Image 6](https://liftia.ai/wp-content/uploads/2025/04/1718338974961.jpg)

### Mathias Valentin  - 3rd

Account Director - SATEC Group

Thanks to the team, I’m already going to start saving time on the kids’ homework this weekend. ![Image 7: 🤭](https://s.w.org/images/core/emoji/16.0.1/svg/1f92d.svg)

![Image 8](https://liftia.ai/wp-content/uploads/2025/04/1675708936981.jpg)

### Charlène LOUIS  - 2nd

Construction Insurance Account Manager - SATEC Group

Thank you to the Liftia team for your relevant, punchy and perfectly adapted presentation! Can’t wait to put it into practice ![Image 9: 👍🏼](https://s.w.org/images/core/emoji/16.0.1/svg/1f44d-1f3fc.svg)

![Image 10](https://liftia.ai/wp-content/uploads/2025/04/1693500951089.jpg)

### Thomas Bousquet  - 2nd

Customer Manager - SATEC Group

![Image 11](https://liftia.ai/wp-content/uploads/2025/04/1652259136232-1.jpg)

### Jérôme Soubaigné - 2nd

Sales, Marketing and Communication Manager

Thank you [Charles](https://www.linkedin.com/in/charles-martin-laval-7b92ab11/) and [Mikael](https://www.linkedin.com/in/mikaelwitwer/) for taking up this challenge and for the quality of your intervention! See you soon!

![Image 12](https://liftia.ai/wp-content/uploads/2025/04/1694097412981.jpg)

### Guillaume Borsalino - 3e et +

Account manager - SATEC Group

The prospects are exciting!

![Image 13](https://liftia.ai/wp-content/uploads/2025/04/1576577506005.jpg)

### Laurent GINON - 3rd and up

Director, Satec Rhône-Alpes - SATEC Group

Top-notch intervention! Immediate application (this morning for my part), making me realize just how useful this assistance is.

/FAQ
----

What do your AI conferences involve?

Led by AI experts, our interactive conferences explore concrete use cases and AI challenges, while involving the audience throughout the session.

How long do conferences last?

Each conference covers the key stakes, benefits, and practical examples of generative AI. Sessions usually run for 90 minutes, ending with open discussion and audience questions.

How do your AI trainings differ from your conferences?

While conferences introduce key issues, benefits, and examples of generative AI, the training sessions dive deeper, teaching how to use tools effectively and apply AI in everyday tasks.

Are these conferences suitable for beginners?

Yes, definitely. These sessions are built for all levels, including beginners. They provide a straightforward, useful overview and include 

*[... truncated, 957 more characters]*

---

### LIFT  | Lyssna här
*192 words* | Source: **EXA** | [Link](https://podcasts.nu/poddar/lift)

9 Avsnitt
---------

1.   ### EP#8: Building AI-Led Products from Frustration & Inspiration Moments - Dr. Joshua Tamayo-Sarver

Publicerades: 2025-02-03 
2.   ### EP#7: Sleepless AI (and Saunas) are Bringing Wellness to Salesforce Architects and Admins - Jari Salomaa

Publicerades: 2024-10-31 
3.   ### EP#6: Sending Money Freely -- Sara Drakeley

Publicerades: 2023-09-22 
4.   ### EP5: Intent Data: The Perfect Answer is Imperfection

Publicerades: 2022-04-22 
5.   ### EP4: Leading a STEM Organization -- Andrew Chrostowski

Publicerades: 2021-05-25 
6.   ### EP4 (Part 1): Leading Amidst Complexity -- Andrew Chrostowski

Publicerades: 2021-04-06 
7.   ### EP3: Succeeding in a World of Risk -- Bob Zukis

Publicerades: 2020-08-25 
8.   ### EP 2: Digging Deep on Motives to Meet Your Customer’s “Invisible” Needs - Cheri Anderson

Publicerades: 2020-02-07 
9.   ### EP 1: Unpacking a Loaded Term: Communications - with Matt Abrahams

Publicerades: 2019-04-24 

[](https://podcasts.nu/poddar/lift?p=0)
1 / 1

[](https://podcasts.nu/poddar/lift?p=2)

Leadership inspiration for professionals who appreciate life-long learning infused with sarcasm and wit. Silicon Valley consultant Allison J. Taylor curates intelligent conversations that illuminate fresh points of view across business, technology, communications, and management. Time-pressed execs can get informed and inspired in under 60 minutes.

[Visit the podcast's native language site](https://podm8.com/podcasts/lift)

---

### Episode – She Lift Project
*742 words* | Source: **EXA** | [Link](https://sheliftproject.com/podcast/)

[![Image 1: Zoe Taylor Headshot](https://sheliftproject.com/wp-content/uploads/2025/12/Zoe-Taylor.webp)](https://sheliftproject.com/podcast/zoe-taylor-64/)

[Zoe Taylor: Serving Doctors While Saving Herself](https://sheliftproject.com/podcast/zoe-taylor-64/)
-----------------------------------------------------------------------------------------------------

“These are brilliant people. But they’ve been so hyper focused on their career path that they don’t have the greatest life skills. They don’t know how to manage their finances, they don’t know how to buy a house, they don’t know what to budget for.”

[Zoe Taylor: Serving Doctors While Saving Herself Read More »](https://sheliftproject.com/podcast/zoe-taylor-64/)

[![Image 2: Ali Hogan Headshot](https://sheliftproject.com/wp-content/uploads/2025/11/Ali-Hogan.webp)](https://sheliftproject.com/podcast/ali-hogan-63/)

[Ali Hogan: Rung For Women’s Ladder to Life Success](https://sheliftproject.com/podcast/ali-hogan-63/)
------------------------------------------------------------------------------------------------------

“What we’re really trying to create here is generational change. And when the kids are in our facility, seeing their moms doing this work, it shows them a completely different path. That, and to no fault of their moms. It just, it never seemed possible. So we’re possibility creators.”

[Ali Hogan: Rung For Women’s Ladder to Life Success Read More »](https://sheliftproject.com/podcast/ali-hogan-63/)

[![Image 3: Jenn Whitmer Headshot](https://sheliftproject.com/wp-content/uploads/2025/11/JennWhitmerHeadshot.jpeg)](https://sheliftproject.com/podcast/jenn-whitmer-62/)

[Jenn Whitmer: From Toxic Leadership to Joyosity™](https://sheliftproject.com/podcast/jenn-whitmer-62/)
-------------------------------------------------------------------------------------------------------

“You can only lead as far as you’ve healed, because until you start to recognize that, you will perpetuate the same mistakes that got you there before, either yourself or the leader that you were under. And that’s why the healing part is so important, because it comes up again and you’re like, okay, wait, this is what this is.”

[Jenn Whitmer: From Toxic Leadership to Joyosity™ Read More »](https://sheliftproject.com/podcast/jenn-whitmer-62/)

[![Image 4: Dr. Vedica Sharma Candid Image](https://sheliftproject.com/wp-content/uploads/2025/10/VedicaHeadshot1.webp)](https://sheliftproject.com/podcast/dr-vedica-sharma-61/)

[Dr. Vedica Sharma: The ICU Doc with a Concierge Self-Care Side Hustle](https://sheliftproject.com/podcast/dr-vedica-sharma-61/)
--------------------------------------------------------------------------------------------------------------------------------

During COVID we realized that people wanted to have certain services and things basically in their home, but you couldn’t find an avenue where you could find a one stop shop that had everything offered and these people would actually show up.

[Dr. Vedica Sharma: The ICU Doc with a Concierge Self-Care Side Hustle Read More »](https://sheliftproject.com/podcast/dr-vedica-sharma-61/)

[![Image 5: Felice McClendon Headshot](https://sheliftproject.com/wp-content/uploads/2025/10/FeliceMcClendon.webp)](https://sheliftproject.com/podcast/felice-mcclendon-60/)

[Felice McClendon: This is Not a Drill](https://sheliftproject.com/podcast/felice-mcclendon-60/)
------------------------------------------------------------------------------------------------

“All of a sudden, it’s cold. I’m cold and I’m wet and. But my windows weren’t open. I’m like, oh, my gosh, this is not a drill.”

[Felice McClendon: This is Not a Drill Read More »](https://sheliftproject.com/podcast/felice-mcclendon-60/)

[![Image 6: Dr. Leslie Davis](https://sheliftproject.com/wp-content/uploads/2025/09/Dr.-Leslie-Davis.webp)](https://sheliftproject.com/podcast/dr-leslie-davis-59/)

[Dr. Leslie Davis: Why Smart Women Stay in Bad Relationships](https://sheliftproject.com/podcast/dr-leslie-davis-59/)
---------------------------------------------------------------------------------------------------------------------

“And when you get into that routine of making sure everybody else is okay and you’re not filling your own cup, then you’re empty. And I think at that point, if it goes on for too long, that’s where silencing happens naturally, where you have no words for yourself because you’ve given it to everyone else.”

[Dr. Leslie Davis: Why Smart Women Stay in Bad Relationships Read More »](https://sheliftproject.com/podcast/dr-leslie-davis-59/)

[![Image 7: Maxine Clark Headshot](https://sheliftproject.com/wp-content/uploads/2025/09/MaxineClark.webp)](https://sheliftproject.com/podcast/maxine-clark-58/)

[Maxine Clark: The Power of Kid Think in Business](https://sheliftproject.com/podcast/maxine-clark-58/)
-------------------------------------------------------------------------------------------------------

The first thing I would say, and may

*[... truncated, 2,673 more characters]*

---

### She Lift Project – A community of women in pursuit of excellence
*1,879 words* | Source: **EXA** | [Link](https://sheliftproject.com/podcast-episodes/)

![Image 1: The She Lift Project Podcast logo](https://sheliftproject.com/wp-content/uploads/2023/07/Podcast-Cover-2023_web.webp)

Enjoy the 

She Lift Project Podcast
------------------------------------

Hear the stories, struggles, and survival tips from successful professional women.

Subscribe Wherever You Get Your Podcasts
----------------------------------------

New episodes are released on the **1st** and **3rd****TUESDAY** of each **MONTH**.

### Listen to the Latest Episodes

### Watch Every Episode

Episodes & Show Notes
---------------------

[![Image 2: Zoe Taylor: Serving Doctors While Saving Herself](https://sheliftproject.com/wp-content/uploads/2025/12/E64ZT_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/zoe-taylor-64/ "Zoe Taylor: Serving Doctors While Saving Herself")[](https://sheliftproject.com/podcast/zoe-taylor-64/ "Zoe Taylor: Serving Doctors While Saving Herself")

[![Image 3: Ali Hogan: Rung For Women's Ladder to Life Success](https://sheliftproject.com/wp-content/uploads/2025/11/E63AH_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/ali-hogan-63/ "Ali Hogan: Rung For Women's Ladder to Life Success")[](https://sheliftproject.com/podcast/ali-hogan-63/ "Ali Hogan: Rung For Women's Ladder to Life Success")

[![Image 4: Jenn Whitmer: From Toxic Leadership to Joyosity™](https://sheliftproject.com/wp-content/uploads/2025/11/E62JW_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/jenn-whitmer-62/ "Jenn Whitmer: From Toxic Leadership to Joyosity™")[](https://sheliftproject.com/podcast/jenn-whitmer-62/ "Jenn Whitmer: From Toxic Leadership to Joyosity™")

[![Image 5: Dr. Vedica Sharma: The ICU Doc with a Concierge Self-Care Side Hustle](https://sheliftproject.com/wp-content/uploads/2025/10/E61VS_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/dr-vedica-sharma-61/ "Dr. Vedica Sharma: The ICU Doc with a Concierge Self-Care Side Hustle")[](https://sheliftproject.com/podcast/dr-vedica-sharma-61/ "Dr. Vedica Sharma: The ICU Doc with a Concierge Self-Care Side Hustle")

[![Image 6: Felice McClendon: This is Not a Drill](https://sheliftproject.com/wp-content/uploads/2025/10/Ep60FM_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/felice-mcclendon-60/ "Felice McClendon: This is Not a Drill")[](https://sheliftproject.com/podcast/felice-mcclendon-60/ "Felice McClendon: This is Not a Drill")

[![Image 7: Dr. Leslie Davis: Why Smart Women Stay in Bad Relationships](https://sheliftproject.com/wp-content/uploads/2025/09/Ep59LD_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/dr-leslie-davis-59/ "Dr. Leslie Davis: Why Smart Women Stay in Bad Relationships")[](https://sheliftproject.com/podcast/dr-leslie-davis-59/ "Dr. Leslie Davis: Why Smart Women Stay in Bad Relationships")

[![Image 8: Maxine Clark: The Power of Kid Think in Business](https://sheliftproject.com/wp-content/uploads/2025/09/Ep58MC_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/maxine-clark-58/ "Maxine Clark: The Power of Kid Think in Business")[](https://sheliftproject.com/podcast/maxine-clark-58/ "Maxine Clark: The Power of Kid Think in Business")

[![Image 9: Mary Engelbreit: Lessons from a 50-Year Art Empire](https://sheliftproject.com/wp-content/uploads/2025/08/Ep57ME_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/mary-engelbreit-57/ "Mary Engelbreit: Lessons from a 50-Year Art Empire")[](https://sheliftproject.com/podcast/mary-engelbreit-57/ "Mary Engelbreit: Lessons from a 50-Year Art Empire")

[![Image 10: Angela Skurtu: The Therapist that Gets Business](https://sheliftproject.com/wp-content/uploads/2025/08/Ep56AS_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/angela-skurtu-56/ "Angela Skurtu: The Therapist that Gets Business")[](https://sheliftproject.com/podcast/angela-skurtu-56/ "Angela Skurtu: The Therapist that Gets Business")

[![Image 11: Laura K. Sawyier: Wardrobe is a Mental Health Tool](https://sheliftproject.com/wp-content/uploads/2025/08/Ep55LKS_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/laura-k-sawyier-55/ "Laura K. Sawyier: Wardrobe is a Mental Health Tool")[](https://sheliftproject.com/podcast/laura-k-sawyier-55/ "Laura K. Sawyier: Wardrobe is a Mental Health Tool")

[![Image 12: Noelle Robinson: Sound as Unexpected Medicine](https://sheliftproject.com/wp-content/uploads/2025/07/Ep54NR_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/noelle-robinson-54/ "Noelle Robinson: Sound as Unexpected Medicine")[](https://sheliftproject.com/podcast/noelle-robinson-54/ "Noelle Robinson: Sound as Unexpected Medicine")

[![Image 13: Courtney English: Your Business Bodyguard](https://sheliftproject.com/wp-content/uploads/2025/07/Ep53CE_Cover_sm-300x300.webp)](https://sheliftproject.com/podcast/courtney-english-53/ "Courtney English: Your Business Bodyguard")[](https://sheliftproject.com/podcast/courtney-english-53/ "Courtney English: Your Business Bodyguard")

[![Image 14: Kelly Spann: Underestimated - From Teen M

*[... truncated, 20,251 more characters]*

---

### AI Experts & Training - AI Tools - Liftia
*1,650 words* | Source: **GOOGLE** | [Link](https://liftia.ai/en/)

AI Experts & Training - AI Tools - Liftia

===============
[Skip to content](https://liftia.ai/en/#content)

[![Image 1: Logo Liftia Conference Formation Ateliers Transformation avec l'ia](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-conference-formation-transformation-ia.svg)](https://liftia.ai/en/)

*   [Conferences AI](https://liftia.ai/en/ai-conference/) 
*   [Training AI](https://liftia.ai/en/ai-training/) 
*   [Workshops AI](https://liftia.ai/en/ai-workshops/) 
*   [Tools AI](https://liftia.ai/en/ai-tools/) 

*   [AI Conference](https://liftia.ai/en/ai-conference/)
*   [AI Training](https://liftia.ai/en/ai-training/)
*   [AI Workshops](https://liftia.ai/en/ai-workshops/)
*   [AI tools](https://liftia.ai/en/ai-tools/)
*   [Marseille](https://liftia.ai/en/marseille/)
*   [Montréal](https://liftia.ai/en/montreal/)
*   [Get in touch](https://liftia.ai/en/get-in-touch/)
*   [![Image 2: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)English](https://liftia.ai/en/ "Switch to English")
*   [![Image 3: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)French](https://liftia.ai/ "Switch to French")

*   [AI Conference](https://liftia.ai/en/ai-conference/)
*   [AI Training](https://liftia.ai/en/ai-training/)
*   [AI Workshops](https://liftia.ai/en/ai-workshops/)
*   [AI tools](https://liftia.ai/en/ai-tools/)
*   [Marseille](https://liftia.ai/en/marseille/)
*   [Montréal](https://liftia.ai/en/montreal/)
*   [Get in touch](https://liftia.ai/en/get-in-touch/)
*   [![Image 4: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)English](https://liftia.ai/en/ "Switch to English")
*   [![Image 5: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)French](https://liftia.ai/ "Switch to French")

*   [Our offices](https://liftia.ai/en/#)
    *   [Marseille](https://liftia.ai/en/marseille/)
    *   [Montréal](https://liftia.ai/en/montreal/)

*   [![Image 6: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/ "Switch to ")
    *   [![Image 7: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/ "Switch to ")

*   [Our offices](https://liftia.ai/en/#)
    *   [Marseille](https://liftia.ai/en/marseille/)
    *   [Montréal](https://liftia.ai/en/montreal/)

*   [![Image 8: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/ "Switch to ")
    *   [![Image 9: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/ "Switch to ")

[Get in touch](https://liftia.ai/en/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6Mjg0NCwidG9nZ2xlIjpmYWxzZX0%3D)

Empower with AI

your staff

y o u r s t a f f y o u r b u s i n e s s y o u r m a r k e t i n g y o u r a d m i n y o u r s a l e s y o u r p r o d u c t i v i t y

**Liftia** Guides you in turning AI into action throughout your entire organization!
====================================================================================

[Book a meeting](https://liftia.ai/en/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6Mjg0NCwidG9nZ2xlIjpmYWxzZX0%3D)

![Image 10: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 11: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 12: midjourney-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/midjourney-logo-liftia.svg)

![Image 13: gemini-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/gemini-logo-liftia.svg)

![Image 14: claude-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/claude-logo-liftia.svg)

![Image 15: copilote-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/copilote-logo-liftia.svg)

![Image 16: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 17: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 18: midjourney-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/midjourney-logo-liftia.svg)

![Image 19: gemini-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/gemini-logo-liftia.svg)

![Image 20: claude-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/claude-logo-liftia.svg)

![Image 21: copilote-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/copilote-logo-liftia.svg)

![Image 22: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 23: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 24: midjourney-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/midjourney-logo-liftia.svg)

![Image 25: gemini-logo-liftia](https://liftia.ai/wp-content/uploads/2

*[... truncated, 20,574 more characters]*

---

### Get in touch - Liftia
*617 words* | Source: **GOOGLE** | [Link](https://liftia.ai/en/get-in-touch/)

Get in touch - Liftia

===============
[Skip to content](https://liftia.ai/en/get-in-touch/#content)

[![Image 1: Logo Liftia Conference Formation Ateliers Transformation avec l'ia](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-conference-formation-transformation-ia.svg)](https://liftia.ai/en/)

*   [Conferences AI](https://liftia.ai/en/ai-conference/) 
*   [Training AI](https://liftia.ai/en/ai-training/) 
*   [Workshops AI](https://liftia.ai/en/ai-workshops/) 
*   [Tools AI](https://liftia.ai/en/ai-tools/) 

*   [AI Conference](https://liftia.ai/en/ai-conference/)
*   [AI Training](https://liftia.ai/en/ai-training/)
*   [AI Workshops](https://liftia.ai/en/ai-workshops/)
*   [AI tools](https://liftia.ai/en/ai-tools/)
*   [Marseille](https://liftia.ai/en/marseille/)
*   [Montréal](https://liftia.ai/en/montreal/)
*   [Get in touch](https://liftia.ai/en/get-in-touch/)
*   [![Image 2: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)English](https://liftia.ai/en/get-in-touch/ "Switch to English")
*   [![Image 3: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)French](https://liftia.ai/contact/ "Switch to French")

*   [AI Conference](https://liftia.ai/en/ai-conference/)
*   [AI Training](https://liftia.ai/en/ai-training/)
*   [AI Workshops](https://liftia.ai/en/ai-workshops/)
*   [AI tools](https://liftia.ai/en/ai-tools/)
*   [Marseille](https://liftia.ai/en/marseille/)
*   [Montréal](https://liftia.ai/en/montreal/)
*   [Get in touch](https://liftia.ai/en/get-in-touch/)
*   [![Image 4: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)English](https://liftia.ai/en/get-in-touch/ "Switch to English")
*   [![Image 5: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)French](https://liftia.ai/contact/ "Switch to French")

*   [Our offices](https://liftia.ai/en/get-in-touch/#)
    *   [Marseille](https://liftia.ai/en/marseille/)
    *   [Montréal](https://liftia.ai/en/montreal/)

*   [![Image 6: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/get-in-touch/ "Switch to ")
    *   [![Image 7: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/contact/ "Switch to ")

*   [Our offices](https://liftia.ai/en/get-in-touch/#)
    *   [Marseille](https://liftia.ai/en/marseille/)
    *   [Montréal](https://liftia.ai/en/montreal/)

*   [![Image 8: English](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/get-in-touch/ "Switch to ")
    *   [![Image 9: French](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/contact/ "Switch to ")

[Get in touch](https://liftia.ai/en/get-in-touch/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6Mjg0NCwidG9nZ2xlIjpmYWxzZX0%3D)

/Interested in integrating **AI** into your organization?
---------------------------------------------------------

 First name  

 Name  

 Your e-mail address  

 Phone  

 Company  

 Message  

Let's chat

/About us
---------

Specialists in AI adoption to support your company’s transformation

![Image 10](https://liftia.ai/wp-content/uploads/2025/02/mikael.webp)

### Mikael Witwer

Backed by a decade in digital marketing, he redesigns business strategies through innovation. At Liftia, he helps organizations embrace generative AI with a focus on strategy and measurable outcomes.

[Linkedin](https://www.linkedin.com/in/mikaelwitwer/)

![Image 11](https://liftia.ai/wp-content/uploads/2025/02/charles.webp)

### Charles Martin-Laval

Driven by a passion for engineering, he launched and managed a company specializing in intelligent automation. At Liftia, he builds generative AI tools to streamline operations and harness AI’s capabilities.

[Linkedin](https://www.linkedin.com/in/charles-martin-laval-7b92ab11/)

![Image 12](https://liftia.ai/wp-content/uploads/2025/02/delphine.webp)

### Delphine Guyot Giler

Specialized in innovation and strategic thinking, she bridges marketing, project coordination, and creative insight. At LIFTIA, she shapes training offers and pinpoints what works best for each organization.

[Linkedin](https://www.linkedin.com/in/delphine-guyot-giler-62a54721/)

![Image 13](https://liftia.ai/wp-content/uploads/2025/02/manu.webp)

### Emmanuel Guyot

An entrepreneur and expert in digital solutions, Emmanuel has founded several startups. At LIFTIA, he designs training courses to help companies adopt generative AI.

[Linkedin](https://www.linkedin.com/in/emmanuel-guyot-3a210670/)

![Image 14: Logo Liftia en blanc](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-white.svg)

Guides you through your transition to artificial intelligence.

[Linkedin](https://liftia.ai/en/get-in-touch/)

FIND US

*   [Our offices](https://liftia.ai/en/get-in-t

*[... truncated, 5,705 more characters]*

---

### Contactez-nous - Liftia
*642 words* | Source: **GOOGLE** | [Link](https://liftia.ai/contact/)

Contactez-nous - Liftia

===============
[Aller au contenu](https://liftia.ai/contact/#content)

[![Image 1: Logo Liftia Conference Formation Ateliers Transformation avec l'ia](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-conference-formation-transformation-ia.svg)](https://liftia.ai/)

*   [Conférences IA](https://liftia.ai/conference-ia/) 
*   [Formations IA](https://liftia.ai/formations-ia/) 
*   [Ateliers IA](https://liftia.ai/ateliers-ia/) 
*   [Outils IA](https://liftia.ai/outils-ia/) 

*   [Conférence IA](https://liftia.ai/conference-ia/)
*   [Formations IA](https://liftia.ai/formations-ia/)
*   [Ateliers IA](https://liftia.ai/ateliers-ia/)
*   [Outils IA](https://liftia.ai/outils-ia/)
*   [Marseille](https://liftia.ai/marseille/)
*   [Montréal](https://liftia.ai/montreal/)
*   [Contactez-nous](https://liftia.ai/contact/)
*   [![Image 2: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)Anglais](https://liftia.ai/en/get-in-touch/ "Passer à Anglais")
*   [![Image 3: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)Français](https://liftia.ai/contact/ "Passer à Français")

*   [Conférence IA](https://liftia.ai/conference-ia/)
*   [Formations IA](https://liftia.ai/formations-ia/)
*   [Ateliers IA](https://liftia.ai/ateliers-ia/)
*   [Outils IA](https://liftia.ai/outils-ia/)
*   [Marseille](https://liftia.ai/marseille/)
*   [Montréal](https://liftia.ai/montreal/)
*   [Contactez-nous](https://liftia.ai/contact/)
*   [![Image 4: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)Anglais](https://liftia.ai/en/get-in-touch/ "Passer à Anglais")
*   [![Image 5: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)Français](https://liftia.ai/contact/ "Passer à Français")

*   [Nos bureaux](https://liftia.ai/contact/#)
    *   [Marseille](https://liftia.ai/marseille/)
    *   [Montréal](https://liftia.ai/montreal/)

*   [![Image 6: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/contact/ "Passer à ")
    *   [![Image 7: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/get-in-touch/ "Passer à ")

*   [Nos bureaux](https://liftia.ai/contact/#)
    *   [Marseille](https://liftia.ai/marseille/)
    *   [Montréal](https://liftia.ai/montreal/)

*   [![Image 8: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/contact/ "Passer à ")
    *   [![Image 9: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/get-in-touch/ "Passer à ")

[Contactez-nous](https://liftia.ai/contact/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6MTU5OSwidG9nZ2xlIjpmYWxzZX0%3D)

/Vous souhaitez **intégrer l’IA** au sein de votre entreprise ?
---------------------------------------------------------------

 Prénom  

 Nom  

 Votre E-mail Pro  

 Téléphone  

 Société  

 Message  

Discutons-en !

/Qui sommes nous ?
------------------

Des experts en IA pour accompagner l’intégration de l’Intelligence Artificielle au sein de votre entreprise

![Image 10](https://liftia.ai/wp-content/uploads/2025/02/mikael.webp)

### Mikael Witwer

Fort de 10 ans d’expérience en marketing digital, il repense les stratégies d’entreprise en y intégrant des approches innovantes. Chez Liftia, il accompagne les entreprises dans l’adoption de l’IA générative avec une vision stratégique et orientée résultats.

[Linkedin](https://www.linkedin.com/in/mikaelwitwer/)

![Image 11](https://liftia.ai/wp-content/uploads/2025/02/charles.webp)

### Charles Martin-Laval

Ingénieur passionné, il a fondé et dirigé une entreprise d’automatisation intelligente.Chez Liftia, il conçoit des solutions basées sur l’IA générative pour optimiser les processus et exploiter tout le potentiel de l’IA.

[Linkedin](https://www.linkedin.com/in/charles-martin-laval-7b92ab11/)

![Image 12](https://liftia.ai/wp-content/uploads/2025/02/delphine.webp)

### Delphine Guyot Giler

Experte en innovation et stratégie, allie marketing, gestion de projet et créativité. Chez LIFTIA, elle structure les offres de formation et identifie les meilleures pratiques pour les organisations.

[Linkedin](https://www.linkedin.com/in/delphine-guyot-giler-62a54721/)

![Image 13](https://liftia.ai/wp-content/uploads/2025/02/manu.webp)

### Emmanuel Guyot

Entrepreneur et expert en solutions numériques, Emmanuel a fondé plusieurs startups. Chez LIFTIA, il conçoit des parcours de formation pour aider les entreprises à adopter l’IA générative.

[Linkedin](https://www.linkedin.com/in/emmanuel-guyot-3a210670/)

![Image 14: Logo Liftia en blanc](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-white.svg)

Vous accompagne dans votre transition vers l’intelligence artificielle

[Linkedin](https://li

*[... truncated, 5,769 more characters]*

---

### Experts & Formations IA en Entreprises - Outils IA - Liftia
*2,514 words* | Source: **GOOGLE** | [Link](https://liftia.ai/)

Experts & Formations IA en Entreprises - Outils IA - Liftia

===============
[Aller au contenu](https://liftia.ai/#content)

[![Image 1: Logo Liftia Conference Formation Ateliers Transformation avec l'ia](https://liftia.ai/wp-content/uploads/2025/02/logo-liftia-conference-formation-transformation-ia.svg)](https://liftia.ai/)

*   [Conférences IA](https://liftia.ai/conference-ia/) 
*   [Formations IA](https://liftia.ai/formations-ia/) 
*   [Ateliers IA](https://liftia.ai/ateliers-ia/) 
*   [Outils IA](https://liftia.ai/outils-ia/) 

*   [Conférence IA](https://liftia.ai/conference-ia/)
*   [Formations IA](https://liftia.ai/formations-ia/)
*   [Ateliers IA](https://liftia.ai/ateliers-ia/)
*   [Outils IA](https://liftia.ai/outils-ia/)
*   [Marseille](https://liftia.ai/marseille/)
*   [Montréal](https://liftia.ai/montreal/)
*   [Contactez-nous](https://liftia.ai/contact/)
*   [![Image 2: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)Anglais](https://liftia.ai/en/ "Passer à Anglais")
*   [![Image 3: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)Français](https://liftia.ai/ "Passer à Français")

*   [Conférence IA](https://liftia.ai/conference-ia/)
*   [Formations IA](https://liftia.ai/formations-ia/)
*   [Ateliers IA](https://liftia.ai/ateliers-ia/)
*   [Outils IA](https://liftia.ai/outils-ia/)
*   [Marseille](https://liftia.ai/marseille/)
*   [Montréal](https://liftia.ai/montreal/)
*   [Contactez-nous](https://liftia.ai/contact/)
*   [![Image 4: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)Anglais](https://liftia.ai/en/ "Passer à Anglais")
*   [![Image 5: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)Français](https://liftia.ai/ "Passer à Français")

*   [Nos bureaux](https://liftia.ai/#)
    *   [Marseille](https://liftia.ai/marseille/)
    *   [Montréal](https://liftia.ai/montreal/)

*   [![Image 6: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/ "Passer à ")
    *   [![Image 7: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/ "Passer à ")

*   [Nos bureaux](https://liftia.ai/#)
    *   [Marseille](https://liftia.ai/marseille/)
    *   [Montréal](https://liftia.ai/montreal/)

*   [![Image 8: Français](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/fr.svg)](https://liftia.ai/ "Passer à ")
    *   [![Image 9: Anglais](https://liftia.ai/wp-content/plugins/sitepress-multilingual-cms/res/flags/en.svg)](https://liftia.ai/en/ "Passer à ")

[Contactez-nous](https://liftia.ai/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6MTU5OSwidG9nZ2xlIjpmYWxzZX0%3D)

Mettez l’IA au service de

votre équipe

v o t r e é q u i p e v o t r e e n t r e p r i s e v o t r e m a r k e t i n g v o t r e a d m i n i s t r a t i f v o s c o l l a b o r a t e u r s v o t r e b u s i n e s s v o t r e p e r f o r m a n c e v o t r e p r o d u c t i v i t é v o t r e c o m m e r c i a l

**Liftia** vous accompagne sur la mise en application concrète de l’IA à tous les étages de votre entreprise !
==============================================================================================================

[Prendre rendez-vous](https://liftia.ai/#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6MTU5OSwidG9nZ2xlIjpmYWxzZX0%3D)

![Image 10: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 11: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 12: midjourney-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/midjourney-logo-liftia.svg)

![Image 13: gemini-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/gemini-logo-liftia.svg)

![Image 14: claude-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/claude-logo-liftia.svg)

![Image 15: copilote-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/copilote-logo-liftia.svg)

![Image 16: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 17: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 18: midjourney-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/midjourney-logo-liftia.svg)

![Image 19: gemini-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/gemini-logo-liftia.svg)

![Image 20: claude-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/claude-logo-liftia.svg)

![Image 21: copilote-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/copilote-logo-liftia.svg)

![Image 22: chatgpt-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/chatgpt-logo-liftia.svg)

![Image 23: mistral-logo-liftia](https://liftia.ai/wp-content/uploads/2025/02/mistral-logo-liftia.svg)

![Image 24: midjourney-l

*[... truncated, 28,165 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[AI Experts & Training - AI Tools - Liftia](https://liftia.ai/en/)**
  - Source: liftia.ai
  - *Liftia Guides you in turning AI into action throughout your entire organization! ... Delphine Guyot Giler. Prompt specialist IA. Mikael Witwer. Strate...*

- **[Get in touch - Liftia](https://liftia.ai/en/get-in-touch/)**
  - Source: liftia.ai
  - *Logo Liftia Conference Formation Ateliers Transformation avec l'ia ... Delphine Guyot Giler. Specialized in innovation and strategic thinking, she bri...*

- **[Contactez-nous - Liftia](https://liftia.ai/contact/)**
  - Source: liftia.ai
  - *Logo Liftia Conference Formation Ateliers Transformation avec l'ia ... Delphine Guyot Giler. Experte en innovation et stratégie, allie marketing, gest...*

- **[Liftia: Experts & Formations IA en Entreprises - Outils IA](https://liftia.ai/)**
  - Source: liftia.ai
  - *Logo Liftia Conference Formation Ateliers Transformation avec l'ia ... Delphine Guyot Giler. Co-Fondatrice - Experte en IA générative. Liftia aide les...*

---

*Generated by Founder Scraper*
