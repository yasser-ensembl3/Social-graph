# Lionel Gakeme

## Position actuelle

**Titre** : Founder
**Entreprise** : Lior Link
**Durée dans le rôle** : 1 year 3 months in role
**Durée dans l'entreprise** : 1 year 3 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

Your Link to Apartments, Concierge, Chatbots & Web Development in Montréal

Lior Link connects renters and landlords quickly while empowering small businesses with custom AI and digital solutions. I oversee all operations, business development, and client strategy, helping clients leverage technology to streamline processes, improve customer experience, and grow their businesses.

## Résumé

Results-driven entrepreneur and sales professional with Rwandan and Canadian experience spanning startups, corporate IT, and national marketing campaigns. I have founded and managed cross-border automotive and tech companies, led teams of 25+, and executed high-impact sponsorship programs for Skol Brewery across 50 national matches. Skilled in sales strategy, CRM management, IT support, and customer experience, I thrive at the intersection of operations, marketing, and business development. Passionate about creating value, building relationships, and delivering measurable growth.

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAFmr6zUBxxBUUEap8MRMlrc1VE4v_qLdJGw/


---

# Lionel Gakeme

## Position actuelle

**Entreprise** : Lior Link

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 3rd


---

# Lionel Gakeme

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398753521770139649 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQG0-EnFrF2n9w/feedshare-shrink_800/B56Zq2nHteHkAg-/0/1764000301043?e=1766620800&v=beta&t=34pEukNuQ3mphYkUvepj5FM0ftkeiHNhPIyqPqsJk_Y | Few years ago, I arrived in Canada with nothing guaranteed except hope. The road was tough, full of challenges and moments that tested my strength. But step by step, with hard work, faith, and God’s help, we made it through.

Today, I’m proud to say that I am officially a Canadian citizen. Grateful for this new beginning and for everyone who stood by me on this journey. The best is ahead. | 8 | 4 | 0 | 1w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:12.043Z |  | 2025-11-24T16:05:01.783Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7396351286981480448 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8abedcd7-a01a-4332-88a8-ed2ba1a91670 |  | Just finished the course “Becoming Head of Sales: Developing Your Playbook”! #salesleadership | 0 | 0 | 0 | 2w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:12.044Z |  | 2025-11-18T00:59:24.378Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396299402178486272 | Video (LinkedIn Source) | blob:https://www.linkedin.com/657e6786-f7c3-4e66-8b1f-e846836b8224 |  | Just finished the course “Sales: Closing Strategies”! #saleseffectiveness | 1 | 0 | 0 | 2w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:12.044Z |  | 2025-11-17T21:33:14.077Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396274392688865280 | Video (LinkedIn Source) | blob:https://www.linkedin.com/af0cc6df-b6b7-46d1-a23f-4c5aa5f2b07e |  | Just finished the course “B2B Sales Foundations”! #businesstobusiness | 0 | 0 | 0 | 2w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:12.045Z |  | 2025-11-17T19:53:51.350Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396255013234360321 | Video (LinkedIn Source) | blob:https://www.linkedin.com/62529102-b532-4af0-a9de-7bc831e2a712 |  | Just finished the course “Social Selling with LinkedIn”! #socialselling #linkedin | 2 | 0 | 0 | 2w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:12.046Z |  | 2025-11-17T18:36:50.928Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7396243522212966400 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ed4658f8-c1e5-4463-84df-1058fb4dc6a1 |  | Just finished the course “Sales Strategies and Approaches in a New World of Selling”! #salesstrategy | 1 | 0 | 0 | 2w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:14.106Z |  | 2025-11-17T17:51:11.255Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7394023637747544065 | Article |  |  | Proud to share the first step of Lior Link.
I started this project to help renters and landlords connect faster. The Facebook community grew to more than 35,000 real people in Montreal and nearby areas.

Now I am building a structured service with better support and follow-up.
If you need help finding a place or promoting a rental, we are here to help. | 0 | 0 | 0 | 3w | Post | Lionel Gakeme | https://www.linkedin.com/in/lionelgakeme | https://linkedin.com/in/lionelgakeme | 2025-12-08T07:21:14.106Z |  | 2025-11-11T14:50:09.555Z | https://www.facebook.com/share/g/1FqUbm6N5W/?mibextid=wwXIfr |  | 

---



---

# Lionel Gakeme
*Lior Link*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [How I Built A $25K/Month Tool In A Crowded Market](https://www.starterstory.com/stories/liinks-supercharge-your-link-in-bio)
*2024-10-22*
- Category: article

### [Eclipse Ventures Founder Lior Susan on Investing in Old-Line Industries Post-Covid - Eclipse](https://eclipse.capital/blog/eclipse-ventures-founder-lior-susan-on-investing-in-old-line-industries-post-covid/)
*2022-02-08*
- Category: blog

### [](https://documents1.worldbank.org/curated/en/099152402162427388/text/IDU1295c61851708b1449b1b81e1e7f4a4c4bf4c.txt)
- Category: article

### [🚀 Meet the 59 Ventures From LOI Labs Batch 11](https://loi.beehiiv.com/p/meet-the-59-ventures-from-loi-labs-batch-11)
*2025-04-14*
- Category: article

### [Liam Gerada Of Krepling On How To Build The Best Omnichannel Customer Experience](https://medium.com/authority-magazine/liam-gerada-of-krepling-on-how-to-build-the-best-omnichannel-customer-experience-76afb7aa357e)
*2024-03-06*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
