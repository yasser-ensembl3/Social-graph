# Alex Nemeroff

## Position actuelle

**Titre** : Founder
**Entreprise** : Dynamo
**Durée dans le rôle** : 26 years 9 months in role
**Durée dans l'entreprise** : 26 years 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Design Services

## Description du rôle

I co-founded Dynamo, a digital design studio, in 1999. We work on bringing digital products to life for both venture-backed startups and established enterprises alike.

## Résumé

I have spent my career leading design and product teams to ambitious ends. As the co-founder of Dynamo I led projects for clients like Glossier, Blue Bottle Coffee, and Sonder. I run workshops that help companies take giant steps *quickly* — Design Sprints, Brand Sprints, Vision Sprints and Naming Sprints.  I also advise design-driven startups, chair an event series for creatives in Montreal, and explore the world behind the work as an interviewer and podcast host.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAADDo6sBTU3QrqBkmABSMLA5-Kj9SRNZhCY/
**Connexions partagées** : 107


---

# Alex Nemeroff

## Position actuelle

**Entreprise** : Dynamo

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Alex Nemeroff

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7391867314138288129 | Text |  |  | Are you a Montreal-based product designer? This is an opportunity to work *with* amazing people and *on* amazing — and new — things. | 5 | 2 | 0 | 1mo | Post | Alex Nemeroff | https://www.linkedin.com/in/nemeroff | https://linkedin.com/in/nemeroff | 2025-12-08T04:43:44.231Z |  | 2025-11-05T16:01:41.944Z | https://www.linkedin.com/feed/update/urn:li:activity:7391819420257431552/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7378863213263691776 | Video (LinkedIn Source) | blob:https://www.linkedin.com/ef0ad7af-a0c7-4df0-ab69-8bbf91adff3e | https://media.licdn.com/dms/image/v2/D5610AQH__k-q6cLrVQ/ads-video-thumbnail_720_1280/B56ZmbI_g1JsAY-/0/1759244450114?e=1765774800&v=beta&t=HGdQgjSpkKOb0g3XE9AjdflV-4RX9wUR6jt_ipKsqek | Huge day for Chord — and every Chord customer. 

We've all seen companies pitch their AI wrappers that sound good in theory, but end up underwhelming in practice. I've gotten to see real customers use Chord's copilot to get quick answers to complicated, muti-faceted questions about their business, and it's clearer than ever that *AI* needs a ton of *Context* to be truly valuable. Chord AI gives you both — data infrastructure for context, commerce copilot for answers and analysis. 

Congrats to the entire Chord team on this launch! | 16 | 7 | 0 | 2mo | Post | Alex Nemeroff | https://www.linkedin.com/in/nemeroff | https://linkedin.com/in/nemeroff | 2025-12-08T04:43:44.232Z |  | 2025-09-30T18:48:02.691Z | https://www.linkedin.com/feed/update/urn:li:activity:7378806113376583680/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7323056432193417216 | Text |  |  | Marketing peeps! Jump at the chance to work with (and fill in for) Abby Borden here — she's looking for someone who can jump into a contract role focused on marketing execution while she's on mat leave. | 8 | 1 | 0 | 7mo | Post | Alex Nemeroff | https://www.linkedin.com/in/nemeroff | https://linkedin.com/in/nemeroff | 2025-12-08T04:43:44.233Z |  | 2025-04-29T18:51:49.244Z | https://www.linkedin.com/feed/update/urn:li:activity:7322956820828803074/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7311043032173142017 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQEtdxpeROPPGg/feedshare-shrink_2048_1536/B56ZXX5qP3HoAo-/0/1743083972188?e=1766620800&v=beta&t=KgCU4C-0iRrSqjfzKc24RNG_4767Xxg0znW7QJOrumU | A big milestone for Chord as it doubles down on its Data offering — congratulations Bryan. It's been very cool seeing up close how Chord is using AI to make Marketers better, faster. | 15 | 1 | 0 | 8mo | Post | Alex Nemeroff | https://www.linkedin.com/in/nemeroff | https://linkedin.com/in/nemeroff | 2025-12-08T04:43:44.234Z |  | 2025-03-27T15:14:51.481Z | https://www.linkedin.com/feed/update/urn:li:activity:7311024081246593024/ |  | 

---



---

# Alex Nemeroff
*Dynamo*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 12 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [In conversation with Jeffrey Zeldman | by Alex Nemeroff](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1)
*2016-12-08*
- Category: blog

### [Alex Nemeroff – Medium](https://medium.com/@nemy?source=post_page-----a8c35f1a375b--------------------------------)
*2016-06-16*
- Category: blog

### [Moving from project-based fees to retainers - Alex Nemeroff - Medium](https://medium.com/@nemy/moving-from-project-based-fees-to-retainers-2341382456dc)
*2014-01-30*
- Category: blog

### [H+C Season 02 Episode 003 -- Alex Nemeroff](https://garden3d.substack.com/p/hc-season-02-episode-003-alex-nemeroff-c38)
*2019-12-10*
- Category: blog

### [Workmode by Dynamo](https://podcast.app/workmode-p135461?page=2)
*2021-12-16*
- Category: podcast

---

## 📖 Full Content (Scraped)

*9 articles scraped, 14,404 words total*

### Jeffrey Zeldman on why he’s getting back into hands-on design, what building (many) businesses has…
*3,480 words* | Source: **EXA** | [Link](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1)

[![Image 1: Alex Nemeroff](https://miro.medium.com/v2/resize:fill:64:64/0*zut9WWrmiZFlyQMH.jpeg)](https://medium.com/@nemy?source=post_page---byline--bf44e7e926c1---------------------------------------)

14 min read

Apr 5, 2016

Press enter or click to view image in full size

![Image 2](https://miro.medium.com/v2/resize:fit:700/1*u1lik1DDBJIgWdcPILmu6w.jpeg)

### Jeffrey Zeldman on why he’s getting back into hands-on design, what building (many) businesses has been like, and why every young designer should work in a studio at some point.

A couple of months ago I had the honour of interviewing Jeffrey Zeldman for our podcast series. Unfortunately the quality of the audio recording was less than ideal, so I decided to transcribe some of our chat here rather than put out a sub-quality podcast.

In addition to being dubbed the King of Web Standards, Jeffrey is also the Founder of [Happy Cog](http://www.happycog.com/), founder of [A List Apart](http://alistapart.com/), co-founder of [A Book Apart](http://www.abookapart.com/) and [An Event Apart](http://aneventapart.com/), and host of [The Big Web Show](http://5by5.tv/bigwebshow) podcast.

Here is a lightly-edited version of our conversation.

_Alex Nemeroff: You’re in New York right?_

Jeffrey Zeldman: I am, it’s a little chilly here today.

_AN: It is here too. Usually like when I’m speaking to the people in the States, I’m the one complaining of bad weather, but it sounds like you and I kind of have the same thing right now._

JZ: Where are you?

_AN: Montreal._

JZ: I love that city so much.

_AN: Have you been here?_

JZ: Yes — I have a cousin Susan, and when I was growing up we used to visit her twice a year. We lived in New York, and later Connecticut, and would drive up. This is when dads would pack you in the car, and drive, and get really mad… that was awful.

_AN: That’s the part of my life that I’m entering right now. I have two young kids, and I’m about to get to that “mad driving dad” phase._

JZ: Be good to your kids.

_AN: Man I’m going to try so hard, I’m going to try so hard._

JZ: It’s so boring for the kids back in the back seat. So if you’re in Montreal where do you drive to?

_AN: I drive down to where you are._

JZ: Yeah, my cousins did too, but we used to visit Montreal around Christmas time.

_AN: So you were here winter or summer, or both?_

JZ: Winter. That’s what I remember, we did both, I think we went to these mountains, the Laurentians in the summer. But in the winter we would go right to Montreal, where the snow was taller than my head.

_AN: Usually when people say, “I’m going to come to Montreal,” I say, “Great come in the summer, unless you want to ski.” So, do you ski in New York?_

JZ: No, I almost killed someone the one time I tried, so no.

_AN: You haven’t been to Montreal in a while then?_

JZ: No I really want to come, I haven’t been in years.

_AN: We’re trying to build up this range of talks —_[_Dynamic/MTL_](http://dynamicmtl.com/)_about the stuff that we learned at An Event Apart. So it’s in our vision map to have An Event Apart here one day._

JZ: I would love to do it, but I don’t know about the logistics. Although Canada is easier than Europe. Europeans often say, “Why don’t you bring in An Event Apart to Europe?” And then there’s the complexity of that. Not to get good speakers and put them on the stage, that part is the same everywhere, but the financials, and taxation… I feel like we who work on the Internet are ahead of our countries, we have friends all over the world. We don’t think quite as nationalistically as countries do for the most part. For example, when I go to some other country to speak, and they’re like, “Why are you coming, are you taking away a job that someone from this country could be doing?” and I’m like, “No I’m just going to talk for an hour”. I’ve been held up at the border in friendly countries.

> I feel like we who work on the Internet are ahead of our countries, we have friends all over the world.

_AN: I know, Canada and United States, they purport to be very friendly, but it’s quite a fuss they put up when you’re just trying to go there for a day. Most of our work is in the States, so we face the same thing all the time._

JZ: I haven’t really had much trouble in Canada, but I remember at the beginning of the Iraq war, Canada wasn’t really happy with America, like a lot of countries. They were hassling me, or anyone who in any way reminded them of George Bush. I saw guys getting off a plane from Houston, and the customs guys were like, “Let’s look through your underwear again.”

_AN: I’m happy this is taking a political turn, that’s where I was hoping to go with this. The reasons that people follow you are the reasons that I, like anyone else in our industry, have been following you for a long time. You’re not only ubiquitous and smart, and have been very forward thinking on many things, but you also let people into your life. Even when you’re talking about your family. I’ve read 

*[... truncated, 14,463 more characters]*

---

### Alex Nemeroff – Medium
*340 words* | Source: **EXA** | [Link](https://medium.com/@nemy?source=post_page-----a8c35f1a375b--------------------------------)

[Everything is an experiment --------------------------- ### I was walking recently with some team members who thought that our recently-implemented Scrum process was making it tougher for them to get…](https://medium.com/@nemy/everything-is-an-experiment-b6d23ddc5768?source=user_profile_page---------0-------------e185f7ddf2fa----------------------)

Jun 16, 2016

[46](https://medium.com/@nemy/everything-is-an-experiment-b6d23ddc5768?source=user_profile_page---------0-------------e185f7ddf2fa----------------------)

Jun 16, 2016

[46](https://medium.com/@nemy/everything-is-an-experiment-b6d23ddc5768?source=user_profile_page---------0-------------e185f7ddf2fa----------------------)

[![Image 1: Sprint Stories](https://miro.medium.com/v2/resize:fill:40:40/1*P6nBz-y1nnn0qDgGOBELqA.png)](https://medium.com/sprint-stories?source=user_profile_page---------1-------------e185f7ddf2fa----------------------)

Published in

[Sprint Stories](https://medium.com/sprint-stories?source=user_profile_page---------1-------------e185f7ddf2fa----------------------)

[Dynamo: Insight and Ownership for All Roles ------------------------------------------- ### How everybody on the project increased insight and ownership in one week](https://medium.com/sprint-stories/a-sprint-story-dynamo-and-famespike-a8c35f1a375b?source=user_profile_page---------1-------------e185f7ddf2fa----------------------)

Jun 6, 2016

[132 1](https://medium.com/sprint-stories/a-sprint-story-dynamo-and-famespike-a8c35f1a375b?source=user_profile_page---------1-------------e185f7ddf2fa----------------------)

![Image 2: Dynamo: Insight and Ownership for All Roles](https://miro.medium.com/v2/resize:fill:160:106/1*o6z98TRMFnEjw5m7IlScwA.jpeg)

![Image 3: Dynamo: Insight and Ownership for All Roles](https://miro.medium.com/v2/resize:fill:320:214/1*o6z98TRMFnEjw5m7IlScwA.jpeg)

Jun 6, 2016

[132 1](https://medium.com/sprint-stories/a-sprint-story-dynamo-and-famespike-a8c35f1a375b?source=user_profile_page---------1-------------e185f7ddf2fa----------------------)

[![Image 4: Monday — The Dynamo Blog](https://miro.medium.com/v2/resize:fill:40:40/1*MFwuIvH19bub59OMdhB62Q.jpeg)](https://medium.com/even-more-dynamo?source=user_profile_page---------2-------------e185f7ddf2fa----------------------)

Published in

[Monday — The Dynamo Blog](https://medium.com/even-more-dynamo?source=user_profile_page---------2-------------e185f7ddf2fa----------------------)

[In conversation with Jeffrey Zeldman ------------------------------------ ### On design, business, and advice for those in the digital world.](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1?source=user_profile_page---------2-------------e185f7ddf2fa----------------------)

Apr 5, 2016

[92](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1?source=user_profile_page---------2-------------e185f7ddf2fa----------------------)

![Image 5: In conversation with Jeffrey Zeldman](https://miro.medium.com/v2/resize:fill:160:106/1*u1lik1DDBJIgWdcPILmu6w.jpeg)

![Image 6: In conversation with Jeffrey Zeldman](https://miro.medium.com/v2/resize:fill:320:214/1*u1lik1DDBJIgWdcPILmu6w.jpeg)

Apr 5, 2016

[92](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1?source=user_profile_page---------2-------------e185f7ddf2fa----------------------)

[![Image 7: Monday — The Dynamo Blog](https://miro.medium.com/v2/resize:fill:40:40/1*MFwuIvH19bub59OMdhB62Q.jpeg)](https://medium.com/even-more-dynamo?source=user_profile_page---------3-------------e185f7ddf2fa----------------------)

Published in

[Monday — The Dynamo Blog](https://medium.com/even-more-dynamo?source=user_profile_page---------3-------------e185f7ddf2fa----------------------)

[Back from the Retreat --------------------- ### Every year at Dynamo we take a couple days to recharge, reflect and take on the year with some new perspective. This past February, in…](https://medium.com/even-more-dynamo/back-from-the-retreat-280066bc13c2?source=user_profile_page---------3-------------e185f7ddf2fa----------------------)

Mar 22, 2016

[26](https://medium.com/even-more-dynamo/back-from-the-retreat-280066bc13c2?source=user_profile_page---------3-------------e185f7ddf2fa----------------------)

![Image 8: Back from the Retreat](https://miro.medium.com/v2/resize:fill:160:106/1*CMAefTcc_i-RawwjkJx6Wg.png)

![Image 9: Back from the Retreat](https://miro.medium.com/v2/resize:fill:320:214/1*CMAefTcc_i-RawwjkJx6Wg.png)

Mar 22, 2016

[26](https://medium.com/even-more-dynamo/back-from-the-retreat-280066bc13c2?source=user_profile_page---------3-------------e185f7ddf2fa----------------------)

[That time we said yes --------------------- ### When two team members had an idea we thought was a sure failure, we still s

*[... truncated, 2,283 more characters]*

---

### H+C Season 02 Episode 003 -- Alex Nemeroff
*338 words* | Source: **EXA** | [Link](https://garden3d.substack.com/p/hc-season-02-episode-003-alex-nemeroff-c38)

H+C Season 02 Episode 003 -- Alex Nemeroff - garden3d.net

===============

[![Image 1: garden3d.net](https://substackcdn.com/image/fetch/$s_!TiDC!,w_80,h_80,c_fill,f_auto,q_auto:good,fl_progressive:steep,g_auto/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F6661e898-eee8-4159-b165-8cca666c416d_250x250.png)](https://garden3d.substack.com/)

[![Image 2: garden3d.net](https://substackcdn.com/image/fetch/$s_!Nkd3!,e_trim:10:white/e_trim:10:transparent/h_72,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack-post-media.s3.amazonaws.com%2Fpublic%2Fimages%2Fd22984d6-af23-4846-aa06-0ec5e38610de_2688x512.png)](https://garden3d.substack.com/)
=============================================================================================================================================================================================================================================================================================================================

Subscribe Sign in

[![Image 3: garden3d.net](http://i1.sndcdn.com/artworks-000650238241-1mgg25-t3000x3000.jpg)](https://garden3d.substack.com/)

humans+computers

H+C Season 02 Episode 003 -- Alex Nemeroff

1×

0:00

Current time: 0:00 / Total time: -53:21

-53:21

Audio playback is not supported on your browser. Please upgrade.

H+C Season 02 Episode 003 -- Alex Nemeroff
------------------------------------------

[![Image 4: garden3d's avatar](https://substackcdn.com/image/fetch/$s_!u8RO!,w_36,h_36,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F13bd9b55-1335-479b-a6d6-4e5e491b4d0c_250x250.png)](https://substack.com/@garden3d)

[garden3d](https://substack.com/@garden3d)

Dec 10, 2019

Share

Mentor, brand advisor, OG agency founder Alex Nemeroff talks with us on trees communicating (one male tree spends 1000s of years finding his soulmate and then he dies), firing yourself out of a job, designing an agency, selecting clients, asking hard questions in terms of selecting projects, what does the world really need, studios have power to make a positive change in terms of sustainability, having a diverse set of friend groups, cooking, and family.

#### Discussion about this episode

Comments Restacks

![Image 5: User's avatar](https://substackcdn.com/image/fetch/$s_!TnFC!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fsubstack.com%2Fimg%2Favatars%2Fdefault-light.png)

[![Image 6: garden3d.net](http://i1.sndcdn.com/artworks-000650238241-1mgg25-t3000x3000.jpg)](https://garden3d.substack.com/)

humans+computers

Search “humans+computers” in your podcast app! Chinatown based studios @human.nyc + @sanctucompu, talking with next level humans sometimes about 💻s.

Search “humans+computers” in your podcast app! Chinatown based studios @human.nyc + @sanctucompu, talking with next level humans sometimes about 💻s.

Subscribe

Listen on

![Image 7](https://garden3d.substack.com/img/shows_app_icons/substack.svg?v=1)

Substack App

![Image 8](https://garden3d.substack.com/img/shows_app_icons/rss.svg?v=1)

RSS Feed

Appears in episode

[![Image 9: garden3d's avatar](https://substackcdn.com/image/fetch/$s_!u8RO!,w_32,h_32,c_fill,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F13bd9b55-1335-479b-a6d6-4e5e491b4d0c_250x250.png)](https://substack.com/@garden3d)

garden3d

Recent Episodes

[H+C Season 03 Episode 003 -- Ian Montgomery](https://garden3d.substack.com/p/hc-season-03-episode-003-ian-montgomery-e56)

Mar 1, 2021•[garden3d](https://substack.com/@garden3d)

[H+C Season 03 Episode 002 -- Shawna X](https://garden3d.substack.com/p/hc-season-03-episode-002-shawna-x-b1d)

Oct 29, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 03 Episode 001 -- Christine Lariviere](https://garden3d.substack.com/p/hc-season-03-episode-001-christine-88a)

Sep 1, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 02 Episode 008 -- Kristian Bjørnard](https://garden3d.substack.com/p/hc-season-02-episode-008-kristian-856)

Aug 4, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 02 Episode 007 -- Erik Carter](https://garden3d.substack.com/p/hc-season-02-episode-007-erik-carter-ac6)

Jul 8, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 02 Episode 006 -- Amy Auscherman](https://garden3d.substack.com/p/hc-season-02-episode-006-amy-auscherman-d5c)

May 26, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 02 Episode 005 -- Jessie Baxa](https://garden3d.substack.com/p/hc-season-02-episode-005-jessie-baxa-a81)

May 7, 2020•[garden3d](https://substack.com/@garden3d)

[H+C Season 02 Episode 004 -- Verena Michelitsch](https://garden3d.substack.com/p/hc-season-02-episode-004-verena-michelitsch-583)

Apr 13, 2020•[garden3d](https://substack.com/@garden3d)

### Ready for more?

Subscri

*[... truncated, 461 more characters]*

---

### Workmode by Dynamo
*1,954 words* | Source: **EXA** | [Link](https://podcast.app/workmode-p135461?page=2)

Workmode podcast - Page 2 - Free on The Podcast App

===============

![Image 15: Close](https://podcast.app/images/close.svg)
Share Workmode
--------------

Copy link

* * *

[Share to email](mailto:?body=https%3A%2F%2Fpodcast.app%2Fworkmode-p135461%3Fpage%3D2%3Futm_source%3Dweb%26utm_medium%3Dshare)

* * *

[Share to Facebook](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fpodcast.app%2Fworkmode-p135461%3Fpage%3D2%3Futm_source%3Dweb%26utm_medium%3Dshare)

* * *

[Share to X](https://twitter.com/intent/tweet?text=https%3A%2F%2Fpodcast.app%2Fworkmode-p135461%3Fpage%3D2%3Futm_source%3Dweb%26utm_medium%3Dshare)

![Image 16: Close](https://podcast.app/images/close.svg)![Image 17: Podcast App](https://podcast.app/images/logo.png)
Sign up to save your podcasts
=============================

Email address 

![Image 18: Email](https://podcast.app/images/signup_email-field.svg)

Password 

![Image 19: Password](https://podcast.app/images/signup_password-field.svg)

Register

* * *

Or

* * *

![Image 20: Continue with Google](https://podcast.app/images/auth/signup_google.svg)Continue with Google Already have an account?[Log in here.](https://podcast.app/signin)

[![Image 21: Podcast App](https://podcast.app/images/logo.svg)](https://podcast.app/)![Image 22: Search...](https://podcast.app/images/search.svg)![Image 23: Menu](https://podcast.app/images/menu.svg)

![Image 24: Search...](https://podcast.app/images/search.svg)

[Podcasts](https://podcast.app/shows)[Sign up](https://podcast.app/register)[Login](https://podcast.app/signin)

![Image 25: Search...](https://podcast.app/images/search.svg)

[Podcasts](https://podcast.app/shows)

* * *

[Login](https://podcast.app/signin)[Sign up](https://podcast.app/register)

![Image 26: Workmode](https://podcast-api-images.s3.amazonaws.com/corona/show/135461/logo_300x300.jpeg)
Workmode
========

By Dynamo

A series of conversations with leading design, tech and cultural creators on how they work. Hosted by Alex Nemeroff, Co-Founder of Dynamo, a digital agency in Montreal, Canada....more

*   [· Arts](https://podcast.app/shows/arts)

![Image 27: Share](https://podcast.app/images/add_favorites.svg)Add to Favorites![Image 28: Share](https://podcast.app/images/share.svg)Share

* * *

*   ![Image 29: 5](https://podcast.app/images/star-full.svg)
*   ![Image 30: 5](https://podcast.app/images/star-full.svg)
*   ![Image 31: 5](https://podcast.app/images/star-full.svg)
*   ![Image 32: 5](https://podcast.app/images/star-full.svg)
*   ![Image 33: 5](https://podcast.app/images/star-full.svg)

5

3 3 ratings

* * *

[![Image 34: Download on the App Store](https://podcast.app/images/stores/app-store-dark.svg)](https://itunes.apple.com/us/app/the-podcast-app/id1199070742?mt=8)[![Image 35: Download on the App Store](https://podcast.app/images/stores/app-store-dark.svg)](https://itunes.apple.com/us/app/the-podcast-app/id1199070742?mt=8)[![Image 36: Get it on Google Play](https://podcast.app/images/stores/play-store-dark.svg)](https://play.google.com/store/apps/details?id=com.streema.podcast&hl=en)

* * *

FAQs about Workmode:
--------------------

### How many episodes does Workmode have?

The podcast currently has 29 episodes available.

Workmode episodes:
------------------

*   [March 30, 2017](https://podcast.app/episode-18-miss-me-e18537730 "Episode 18: Miss Me - Workmode")[Episode 18: Miss Me](https://podcast.app/episode-18-miss-me-e18537730 "Episode 18: Miss Me - Workmode")[Dubbed by VICE as Montreal’s Premier Art Vandal, Miss Me transforms the city’s walls and streets into a canvas for her art. Miss Me discussed the activism and feminism in her art that unapologetically commands the attention of passersby. We touched on the difficulty in finding a balance between personal and professional work, and as a artful vandal, her relationship with “the law”. Miss Me shared tips on navigating her personal anxieties while managing a busy travel schedule as a globally renowned artist. Links: http://www.miss-me-art.com https://www.instagram.com/miss_me_art/ Thank you to our sponsors: http://unbounce.com for the use of their recording studios - check out their podcast Call to Action here: http://unbounce.com/call-to-action-podcast, and to http://mindsparklemag.com - a lovely design blog highlighting new trends in the world of design, web design and video. Edited by Steph Colbourn at http://editaud.io Theme music by http://www.olivieralary.com Find us at http://workmode.show](https://podcast.app/episode-18-miss-me-e18537730 "Episode 18: Miss Me - Workmode")...more  ![Image 37: Listen Later](https://podcast.app/images/add_listenlater.svg)21min![Image 38: Episode 9 - Keira Alexandra](https://podcast.app/images/play.svg)Play

* * *

*   [March 10, 2017](https://podcast.app/episode-17-adi-goodrich-sean-pecknold-of-sing-sing-e17899642 "Episode 17: Adi Goodrich & Sean Pecknold of Sing Sing - Workmode")[Episode 17: Adi Goodrich & Sean Pecknold of Sing Sing](https://podcast.app/episode-17-adi-go

*[... truncated, 14,686 more characters]*

---

### Speaking — m
*948 words* | Source: **GOOGLE** | [Link](https://majomolfino.com/speaking)

![Image 1: women_design_06.jpg](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516404146927-9D2SQ3MHUVEB0GO6XHNZ/women_design_06.jpg)

![Image 2: Majo - 2017.08 - Personal Portrait - 174.jpg](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516675092514-XNCGN9OFPQTZ1HZIX11A/Majo+-+2017.08+-+Personal+Portrait+-+174.jpg)

As a published author (HarperCollins 2020), I support companies to empower female talent, understand gender bias, and create an inclusive workplace. With a Masters in learning, design, and technology from Stanford University, I also speak about how design and design thinking can support their culture and systems. I give audiences tools and frameworks to level up as leaders. I've spoken at top innovative companies like Slack, Medium, Dropbox, VC funds like Designer Fund, as well as business and creativity conferences like Adobe MAX. Topics include women's leadership, creative confidence, diversity in design, as well as designing daily rituals for holistic performance.

![Image 3: Alex-circle.png](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516670642235-I8MAWIQY14QJ2VBVOGC5/Alex-circle.png)

_Majo's talk blew me away. We invited her to speak at Dynamic/MTL, our quarterly event series, because we wanted to have a strong female voice talking about women's creative leadership, and she had a solid track record in the creative community. She gave a TED-style talk that engaged the audience, inciting us to think about big picture questions such as who gets to design the world's future products and experiences. It was a real highlight. After the talk, I invited her onto our new Workmode podcast to dig into how she approaches her work, and what struck me was her level of self-awareness and discipline. She is clearly the type of leader and role model that continues to empower through her talks and podcast. –Alex Nemeroff, Co-Founder of_[_Dynamo_](http://www.godynamo.com/)

Sample Talks
------------

![Image 4](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516674396311-D070TCSR0JM7YLQ2CQG9/Dynamic1.jpg?format=500w)

![Image 5](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516674363595-HATCFIB4QWWVFV27KOF4/WiD2.jpg?format=500w)

![Image 6: Enrique-circle.png](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516671110328-QSJ5TUVSTA56IESDULRO/Enrique-circle.png)

_Majo has spoken at our past three Women in Design events at Adobe, Medium and Dropbox and she’s consistently received feedback from attendees as one of the top rated speakers because she’s both inspirational and actionable.I trust her to give an exceptional,high-quality keynote talk, workshop, and/or panel discussion.”_**_– Enrique Allen, Investor and Co-Director,_**[**_Designer Fund_**](http://designerfund.com/)

![Image 7: Grace-circle.png](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1516671259549-E91D28YRY7ZBURVLSLCX/Grace-circle.png)

_I invited Majo to speak at the Hivery's Entrepreneur Lab because she came highly recommended from a community member. Before the event, Majo and I got on a call and she was very receptive to tailoring the talk for our audience's needs, offering specific tactics female entrepreneurs can use to overcome their "good girl" tendencies, making her presentation both very inspirational and concrete. Her talk led to a fruitful, engaged discussion around monitoring these patterns in ourselves and as both business women and mothers. The feedback from the attendees was truly amazing, and I would absolutely invite her to speak at a future event as well as recommend her to other organizers. Majo is a shining example of the unique potential of women and what happens when we stand in our power, use our voices, and live fully._**_–Grace Kraaijvanger,_**[**_The Hivery_**](https://www.thehivery.com/)

![Image 8: Untitled design (6).png](https://images.squarespace-cdn.com/content/v1/5356e5c9e4b0d988ab9d8f6b/1583360911393-KG51VQHKDSFVF1PHCLCX/Untitled+design+%286%29.png)

_Majo was such a wonderful speaker! Her talk was one of the top-rated experiences of our women's leadership summit at Facebook, with a few women telling me she was a highlight because of the personal and professional insights they received. A few weeks ahead of her talk, she walked me through her outline which made me feel confident in her process and approach. The women walked away having shone light on a part of themselves that they didn’t know before upleveling themselves in their approach in their lives. If you’re looking for an engaging and interesting workshop or talk focused on women’s leadership, definitely work with Majo! I've already been recommending her to other female managers at our company. -_**_Anita Patwardhan Butler, Product Design Manager,_**[**_Facebook_**](https://www.facebook.com/)

![Image 9: Untitled design (7).png](https://images.squarespace-cdn.com/content/v1/5356e

*[... truncated, 2,986 more characters]*

---

### Experience design with Alex Nemeroff, Co-Founder @ Dynamo | Business growth consultant and strategic management firm | PNR
*259 words* | Source: **GOOGLE** | [Link](https://thepnr.com/what-we%E2%80%99re-learning/experience-design-with-alex-nemeroff-co-founder-dynamo/)

![Image 1: Alex-image](https://thepnr.com/wp-content/uploads/2021/11/Alex-image.jpg)

Experience design with Alex Nemeroff, Co-Founder @ Dynamo
---------------------------------------------------------

May 10, 2019

On this week’s show, we spoke with [Alex Nemeroff](https://www.linkedin.com/in/nemeroff/), Co-Founder @ [Dynamo](http://godynamo.com/en)

Since co-founding Dynamo in 2000, Alex Nemeroff has been responsible for guiding some of its biggest clients to success. Alex has funneled his vast bank of knowledge into specializations in digital product design and user experience. His user-centric approach to design and his keen eye for detail has proven to be a winning combination for growth. He’s also host and moderator at Dynamic/MTL, a series of speaking events for Montréal’s creative community. Every three months, Dynamic/MTL invites top guest speakers from across various creative industries to talk about their work and share their experiences.

On the show, we spoke about:

*   The relevance of going to school today
*   How he launched Dynamo and grew the business
*   The evolutions of the company throughout its history
*   Blending expertise and visual design
*   The bittersweet aspect of selling his agency
*   What the agency of the future looks like

Alex is extremely humble and intelligent. I enjoyed his candor and transparency during this interview. I hope that you enjoy the conversation!

Let us know what you think. What types of guests would like to see on the show? What topics interest you the most? Send me your thoughts at [nectar@thepnr.com](mailto:nectar@thepnr.com)

Subscribe | [iTunes](https://itunes.apple.com/ca/podcast/point-of-no-return-podcast/id1160536476?mt=2) | [Google Play](https://play.google.com/music/listen?u=0#/ps/Iefjqhwcdz5o6v6flvj7bu7o5o4) |[Spotify](https://open.spotify.com/show/4c48AlN1hJbQmN7FHPN8vJ?si=nSBgZjtbTV-jANsaz-7ilQ) | [YouTube](https://www.youtube.com/channel/UCf0gXyZXPdWcHEtYEiG0pYw?view_as=subscriber) | [Stitcher](https://www.stitcher.com/s?fid=185161&refid=stpr) | [Breaker](https://www.breaker.audio/point-of-no-return-podcast)

### Subscribe to our newsletter!

A weekly round up of our favorite articles, research and insights about corporate strategy.

---

### Meet Chord AI: The commerce brand’s gateway to intelligent data
*4,081 words* | Source: **GOOGLE** | [Link](https://www.m13.co/article/meet-chord-ai-the-commerce-brands-gateway-to-intelligent-data)

CEO Bryan Mahoney infuses commerce data with artificial intelligence to drive success for e-commerce brands.

TOC

...

Table of Contents

[Read More](https://www.m13.co/article/meet-chord-ai-the-commerce-brands-gateway-to-intelligent-data#readmore)

![Image 1](https://cdn.prod.website-files.com/65d4f8a1a62c18a502877cfe/67e455485499a6062c705759_Chord_website%20header_blog%20(1).webp)

Table of contents

By M13 Team

March 27, 2025

|

7 min

Investment
----------

We’re excited to welcome [Chord](https://www.chordcommerce.com/), a company that unifies all of a brand’s commerce data and makes it AI-ready so brands can see what’s going on with their metrics — and more importantly why — so that they can make better decisions and maximize growth. The company recently closed on a $5.5 million in seed funding led by M13 with participation from Act One Ventures.

Why we’re excited about Chord
-----------------------------

Over the past two years, Chord evolved from a headless commerce platform to a data-driven solution leveraging AI for e-commerce.

After one of Chord’s customers raved about how well the company’s data platform was improving its return on investment, it was the spark for M13 to get to know Bryan Mahoney’s background and understand the importance of what he was building.

Marketers have long relied on misleading data from different sources as well as a long list of software to decipher that data in order to tell them how certain data metrics behave. This can lead to bad recommendations and bad decisions. Brands turned to Chord to get better data and understand it, said M13 partner Brent Murri.

“Marketers are jumping from dashboard to dashboard without knowing which one to trust,” Murri said. “It became clear that Chord’s ability to unify customer data across all of the channels, along with its proprietary modeling and enrichment, is the solution to help marketers understand, make sense of and make decisions with their data.”

![Image 2](https://cdn.prod.website-files.com/65d4f8a1a62c18a502877cfe/67e44163c54fd3f858c568c8_AD_4nXcGsJHalaz3aQTmyx5P0CiVgunX6-tFIiDFBRz54jl9cjhRizLxVqnjz67rh5zkIF7KE5wilzLDmufj_io1rpF2hTuJih-EoVIgHelRomCG3oPWV23vaYYfKCKCkEVbGtlh1SlgRw.png)

Chord’s solution provides a one-stop shop for marketers where they can see all of their metrics — essentially one source of truth — from one dashboard. No longer does a marketer have to use one provider to collect first-party data, another to be the data warehouse provider, and then a handful of other point solutions to tap into that data to yield results so they can make decisions.

> Not very many data platforms connect all of the dots for you. The bigger a brand gets, the more omnichannel it gets, so you need a better data platform to ingest the data and make sense of it so you, as the marketer, can help execute on your campaigns much better. This is where the AI from Chord is really game changing — surfacing hypotheses and recommendations from across your first-party data to make marketers much more effective.”_- M13 partner Brent Murri_

![Image 3](https://cdn.prod.website-files.com/65d4f8a1a62c18a502877cfe/67e5a041ac86bd2022be9f84_founding-team.jpg)

Chord founding team

When the pandemic hit five years ago, brick-and-mortar stores rushed to elevate their online store presence in hopes of not losing sales while people stayed at home.

One of the startups helping companies with this mission was Chord Commerce. In 2021, the company, which started as Arfa, was selling headless commerce technology, which enabled companies to operate back-end infrastructure without affecting the front-end experience.

Headless commerce was supposed to be big. Hundreds of millions of venture capital dollars were invested into companies, including Chord, to pump up this technology. Ultimately, the headless commerce market didn’t have the anticipated “wiz-bang.”

Data was always part of Chord's DNA; in fact Chord came to market as "headless with a brain" because of the data stack underpinning the infrastructure. In 2023, Chord decided to embrace all platforms with its data product, letting go of the requirement to mandate the use of Chord's headless platform to access it.

![Image 4](https://cdn.prod.website-files.com/65d4f8a1a62c18a502877cfe/67e5a08b26338958cd1a9f26_D%20-%20Manage%20Data%20Sources%20(1).webp)

The company is now building an artificial intelligence-driven co-pilot for marketing teams that ​​helps commerce brands make faster, more informed decisions and execute real-time marketing strategies, all within a single platform. The co-pilot will help with hypotheses, understanding trends, providing recommendations and activations into the right channels.

It is also taking the guesswork out of those decisions with a task bar so all the marketer has to do is click a button to increase social media buy of a certain campaign or add another channel to an existing campaign.

“We are giving marketers data superpowers,” Mahoney said. “We are able to 

*[... truncated, 22,451 more characters]*

---

### Mind and body – Mindful coaching
*422 words* | Source: **GOOGLE** | [Link](https://mindfulcoachingmtl.com/services/mindbodyoptions/)

### [Coaching with a twist](http://mindfulcoachingmtl.com/change/)

[![Image 1: qtq80-Styff1](http://mindfulcoachingmtl.com/wp-content/uploads/2017/01/qtq80-Styff1.jpeg)](http://mindfulcoachingmtl.com/change/)

Coaching gives you the confidence you need to connect to your resources and take risks. By _re-patterning_ your habitual responses, you become engaged and able to move forward. Combining coaching with a mind and body practice can help support you in embodying and implementing change.

> _“It takes breaking awful habits and using mindfulness or meditation...my brain has been wired to crave this idea of distraction. I think about meditation or mindfulness or just being brought back to the moment; that practice is so important to break those bad habits.”_

—(Excerpt from a KYO journal conversation)_Alex Nemeroff co-founder of digital design agency Dynamo Workmode and host of Dynamic/MTL conferences and Workmode podcasts._

[Learn More](http://mindfulcoachingmtl.com/change/)

### [](http://mindfulcoachingmtl.com/resistance/)[Mind and Body Possibilities](http://mindfulcoachingmtl.com/resistance/)

Catherine has a strong background in health and wellness, and will work intuitively with you to support you through your process. You’ll work together to find the best combination of tools to help you fully embody the steps toward your goal.She can offer the following tools either alongside the coaching conversations, or lead these practices at your workplace, on your breaks:

*   **Meditation, visualization, breathing and energetic techniques**
*   **Rebalancing coaching:Yoga or Qigong (Taoist Yoga)**
*   **Walking coaching**

[![Image 2: qtq80-kzSPo2](http://mindfulcoachingmtl.com/wp-content/uploads/2016/12/qtq80-kzSPo2.jpeg)](http://mindfulcoachingmtl.com/change/)

### [Coaching and streamlining our thoughts](http://mindfulcoachingmtl.com/change/)

**Meditation, visualization, breathing and energetic techniques**

A coaching conversation about pressing issues, followed by a session of breathing techniques/meditation/visualization (including tools that you can take home with you).

#### **Are you too busy and stressed to go for coaching?**

[Learn More](http://mindfulcoachingmtl.com/change/)

[![Image 3: qtq80-VLYDNd](http://mindfulcoachingmtl.com/wp-content/uploads/2016/12/qtq80-VLYDNd.jpeg)](http://mindfulcoachingmtl.com/change/)

### [Coaching with added energy for change](http://mindfulcoachingmtl.com/change/)

**Rebalancing Coaching**

A coaching conversation combined with Yoga or Qigong exercises (pronounced Chi Gong):an ancient Chinese healing art involving meditation, controlled breathing, and movement exercises. Carefully selected relevant to your goal to help you build more energy and free up blockages. Take-home practices tailored to your needs.

*   #### **What do your body and** feelings**have to do with change?**

[Learn More](http://mindfulcoachingmtl.com/change/)

[![Image 4: qtq80-aieByd](http://mindfulcoachingmtl.com/wp-content/uploads/2016/12/qtq80-aieByd.jpeg)](http://mindfulcoachingmtl.com/change/)

### [Coaching as you walk and get some fresh air](http://mindfulcoachingmtl.com/change/)

**Walking Coaching**

If you like to move, but work has you sitting all day, perhaps you’d like to use your lunch hour or downtime as an opportunity to get the blood flowing _and_ effect change. You pick the circuit, and Catherine will give you a 60-minute walking coaching session.

*   #### What does letting go of**doing**all the time have to do with success?

[Learn More](http://mindfulcoachingmtl.com/change/)

### Next Steps ...

If you have any questions, or are ready to begin get in touch here.

---

### Listão de podcasts sobre UX/UI, Design e outros assuntos que nos interessam
*2,582 words* | Source: **GOOGLE** | [Link](https://brasil.uxdesign.cc/list%C3%A3o-de-podcasts-sobre-ux-ui-design-e-outros-assuntos-que-nos-interessam-81f2b92593bd)

![Image 1](https://miro.medium.com/v2/resize:fit:1920/1*bxvqFn7qh7cmnCm_J11_PQ.jpeg)

[![Image 2: juliana franchin](https://miro.medium.com/v2/resize:fill:64:64/1*-E1OcUj4fCaLTYOGutbOzA.png)](https://jfranchin.medium.com/?source=post_page---byline--81f2b92593bd---------------------------------------)

10 min read

May 16, 2018

Para uma designer viciada em podcasts, essa lista é um paraíso! Você, como eu, vai chegar à conclusão de que 8.760 horas no ano é pouco!

Tentei colocar muitos podcasts que estejam ainda atualizando seus programas, mas tem muitos que não publicam há um tempo. Mas tudo bem, porque eles deixaram um acervo de discussões bem bacana e que permanece relevante até hoje.

Get juliana franchin’s stories in your inbox
--------------------------------------------

Join Medium for free to get updates from this writer.

Dividi as recomendações por tópicos para ajudar um pouquinho:

*   Brasileiros (coloquem mais indicações legais nos comentários pleeease!)
*   Entrevistas e assuntos diversos
*   User Research
*   Métricas e Dados
*   Design de Serviço
*   Produto
*   Criatividade e Inovação
*   Futuro

(Obs.: A descrição que vem abaixo do título é a usada oficialmente na App Store e as dos podcasts em inglês foi livre tradução, então… relevem qualquer coisa :P)

BRASILEIROS
-----------

### [Movimento UX](http://movimentoux.com/)

"Um podcast de entrevistas sobre o universo de UX, com líderes do mercado no Brasil e no mundo. Produzido e apresentado pela Izabela de Fátima." _(duração média: 1h/1h30)_

### [ExPatria](https://anchor.fm/expatria)

"Entrevistas com designers brasileiros que se mudaram para os Estados Unidos." Apresentado por Al Lucca. _(duração média: 30min)_

### [Aela](http://aelacast.podbean.com/)

"Design de produto digital, com muito de tecnologia e foco internacional." _(duração média: 1h/1h30)_

### [Braincast](http://www.brainstorm9.com.br/)

"É o podcast do B9 que debate a intersecção entre a criatividade, tecnologia, cultura digital, inovação e negócios."_(duração média: 1h30/2h)_

### [Código Aberto](http://www.b9.com.br/)

"Conversas francas com os profissionais influentes no mercado, suas grandes ideias e o que pensam sobre o futuro da mídia, da tecnologia e da comunicação." _(duração média: 1h)_

### [Pizza de dados](http://pizzadedados.com/)

"O podcast brasileiro sobre ciência dos dados."_(duração média: 30min/1h)_

### [Varandas ITS](http://itsrio.org/)

"Varandas é uma série de encontros periódicos organizados pelo Instituto de Tecnologia e Sociedade do Rio para promover conversas informais sobre tecnologia, política, cultura, sociedade, democracia e tudo mais que estiver em nosso radar de pesquisa." _(duração média: 1h30)_

### [Like a boss](https://www.likeaboss.com.br/)

"Cada semana um boss diferente, uma história nova e o que aconteceu para a ideia sair do papel para se tornar um grande sucesso." _(duração média: 30min)_

### [Hipsters Ponto Tech](https://hipsters.tech/)

"Discussões acaloradas sobre startups, programação, ux, gadgets e as últimas tendências em tecnologia."_(duração média: 30min/1h)_

### [Tecnocast](http://tecnoblog.net/)

"Tecnologia, negócios, inovação e futuro. No Tecnocast gostamos de conversar não sobre especificidades técnicas, mas sobre como a tecnologia está mudando a forma como vivemos e nos relacionamos com o mundo ao nosso redor."_(duração média: 1h/1h30)_

### [Visual+Mente](http://www.visualmente.com.br/)

"Um spin-off do AntiCast sobre design e afins."_(duração média: alguns curtos de 30min e outros entre 2h/2h30)_

### [Não Obstante](http://www.naoobstante.com/)

"Um bate-papo conduzido por Marcos Beccari e Daniel B. Portugal (contando com a edição de Felipe Ayres), fruto de uma parceria do Anticast com o Filosofia do Design."_(duração média: 1h30/2h)_

### [Aparelho Elétrico](http://aparelhoeletrico.com/)

"Debater e divulgar boas práticas relacionadas a trabalho freelancer e empreendedorismo criativo."_(duração média: 1h/1h30)_

### [Itera Ideia](https://medium.com/itera-ideia)

"O podcast de quem faz designer para quem é design!" _(duração média: 30min/1h)_

### [Yellowcast](http://www.amarelocriativo.com.br/)

"Esse é um podcast da Amarelo Criativo sobre design, comunicação e mundo pop/geek em geral. Queremos que seja um podcast divertidamente Amarelo, mas sempre levando temas relevantes pra vocês." _(duração média: 1h/1h30)_

ENTREVISTAS E ASSUNTOS DIVERSOS
-------------------------------

### [Boagworld Web Show](http://boagworld.com/show/)

"Boagworld é um podcast sobre estratégia digital, service design e experiência do usuário. Oferece conselhos práticos, notícias, ferramentas, review e entrevistas com líderes na comunidade de design. Cobrindo tudo desde usabilidade e design para marketing e estratégia, esse programa tem um pouco de tudo. Esse podcast premiado é o que está rodando há mais tempo, com mais de 380 episódios."_(duração média: 1h)_

### [The Big Web Show](http://5by5.tv/bigwebshow)

"O premiado podcast destac

*[... truncated, 14,463 more characters]*

---

---

## 🎬 YouTube Videos

- **[5 ANGRY MEN TRAILER 6 - Being Faithful](https://www.youtube.com/watch?v=RYGIOydgbok)**
  - Channel: 5angrymenplay
  - Date: 2012-04-04

- **[5 ANGRY MEN TRAILER 7 - Therapy Anyone?](https://www.youtube.com/watch?v=kr1pyjvQ6MI)**
  - Channel: 5angrymenplay
  - Date: 2012-04-08

- **[Let&#39;s talk about : PERSEVERANCE (feat. Alex Nemiroff)｜EP. 01｜The Success Series](https://www.youtube.com/watch?v=VzCHd4cRXow)**
  - Channel: The Success Series
  - Date: 2023-11-17

- **[Must be tough being Zach, drowning in a sea of beautiful DMs...](https://www.youtube.com/watch?v=r475InXWajk)**
  - Channel: Best Of Dropouts
  - Date: 2024-04-06

- **[Nick Nemeroff Just Got Some Devastating News | CONAN on TBS](https://www.youtube.com/watch?v=BRb6HRxN-vg)**
  - Channel: Team Coco
  - Date: 2018-09-26

- **[Wayward Ending Explained: That Brutal Finale Twist &amp; Possible Season 2: &quot;It Could Easily Go On&quot;](https://www.youtube.com/watch?v=9bJCELtYveo)**
  - Channel: Collider Interviews
  - Date: 2025-09-25

- **[DAVE CHAFFEE ARMWRESTLES IN PRISON?](https://www.youtube.com/watch?v=7q5Qkgd_rck)**
  - Channel: Brazilian ArmWrestler
  - Date: 2023-04-06

- **[Her Night - A Short Film by Jason De Vilhena](https://www.youtube.com/watch?v=AIHlGVwFh9c)**
  - Channel: HerNightMovie
  - Date: 2013-01-18

- **[Gecko likes coconut](https://www.youtube.com/watch?v=u_4-d8m-oPA)**
  - Channel: Alex Nemeroff
  - Date: 2015-03-02

- **[5 ANGRY MEN TRAILER 2: Meet the Men](https://www.youtube.com/watch?v=lj2glvL17dY)**
  - Channel: 5angrymenplay
  - Date: 2012-03-21

---

## 🔎 Press & Mentions

- **[In conversation with Jeffrey Zeldman | by Alex Nemeroff | Monday ...](https://medium.com/even-more-dynamo/on-getting-back-into-hands-on-design-growing-a-multifaceted-business-the-importance-of-keeping-an-bf44e7e926c1)**
  - Source: medium.com
  - *Apr 5, 2016 ... More from Alex Nemeroff and Monday — The Dynamo Blog. Moving from project-based fees to retainers. Alex Nemeroff · Moving from ......*

- **[Speaking — m](https://majomolfino.com/speaking)**
  - Source: majomolfino.com
  - *... the type of leader and role model that continues to empower through her talks and podcast. – Alex Nemeroff, Co-Founder of Dynamo. Sample Talks. En...*

- **[Experience design with Alex Nemeroff, Co-Founder @ Dynamo ...](https://thepnr.com/what-we%E2%80%99re-learning/experience-design-with-alex-nemeroff-co-founder-dynamo/)**
  - Source: thepnr.com
  - *May 10, 2019 ... What we're learning > Podcasts. Experience design with Alex Nemeroff, Co-Founder @ Dynamo ... On this week's show, we spoke with Alex...*

- **[Meet Chord AI: The commerce brand's gateway to intelligent data](https://www.m13.co/article/meet-chord-ai-the-commerce-brands-gateway-to-intelligent-data)**
  - Source: m13.co
  - *Mar 27, 2025 ... Mahoney convinced Alex Nemeroff, a friend who still works with ... “Dynamo established a reputation of being a go-to company for earl...*

- **[Mind and body – Mindful coaching](https://mindfulcoachingmtl.com/services/mindbodyoptions/)**
  - Source: mindfulcoachingmtl.com
  - *—(Excerpt from a KYO journal conversation) Alex Nemeroff co-founder of ... Dynamo Workmode and host of Dynamic/MTL conferences and Workmode podcasts....*

- **[Listão de podcasts sobre UX/UI, Design e outros assuntos que nos ...](https://brasil.uxdesign.cc/list%C3%A3o-de-podcasts-sobre-ux-ui-design-e-outros-assuntos-que-nos-interessam-81f2b92593bd)**
  - Source: brasil.uxdesign.cc
  - *May 16, 2018 ... Apresentado por Alex Nemeroff, co-fundador da Dynamo, agência digital em Montreal, Canadá. ... Lead UX Designer na Globo+ Recomendado...*

- **[Richard Banfield C.Todd Lombardo Trace Wax A Practical ...](https://www.adkgroup.com/wp-content/uploads/2018/01/Design-Sprint-Book-Ch.15.pdf)**
  - Source: adkgroup.com
  - *Alex Nemeroff at Dynamo. Ariadna Font Llitjos at IBM. Finally, we're hugely ... After an introduction, briefly describe the reason for the interview, ...*

- **[Untitled Document | PDF](https://www.scribd.com/document/619220346/untitled-document)**
  - Source: scribd.com
  - *It acquired Dynamo, a digital design studio that was founded by Alex Nemeroff and Bryan Mahoney in 1999 (Mason, 2018). ... A07 - Final Integrated Inte...*

- **[A Practical Guidebook for Building Great Digital Products](http://repo.darmajaya.ac.id/4003/1/Design%20Sprint_%20A%20Practical%20Guidebook%20for%20Creating%20Great%20Digital%20Products%20%28%20PDFDrive%20%29.pdf)**
  - Source: repo.darmajaya.ac.id
  - *Alex Nemeroff at Dynamo, a design and UX agency based in Montreal, sug- gests that individuals go first and are allowed their own time to draw out ske...*

- **[Alex Nemeroff – Medium](https://medium.com/@nemy)**
  - Source: medium.com
  - *Read writing from Alex Nemeroff on Medium. Partner and Interactive Director at Dynamo. Obsessive diagrammer. Lover of great bad music....*

---

*Generated by Founder Scraper*
