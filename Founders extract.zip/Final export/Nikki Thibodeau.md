# Nikki Thibodeau

## Position actuelle

**Titre** : Founder & President of the Board
**Entreprise** : The Community Community
**Durée dans le rôle** : 3 years 1 month in role
**Durée dans l'entreprise** : 3 years 1 month in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Community Services

## Description du rôle

The Community Communty's purpose is to build a safe space for senior community professionals to grow, together.

## Résumé

Passionate about people, business and what drives you - Nikki focuses on creating success through Community and Digital Scale Programs.She has been a Community Manager, led a global team of CMs, moved into Community Ops and was Shopify's first Senior Community Strategist to help scale their efforts across a 10,000+ person organization and for their over 2million merchants. A strong advocate for women, Nikki’s works to help women feel included, valued, and heard.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAaPJHwBqESBKTJdYs9jdEKVWoRZ5Tmpd8g/
**Connexions partagées** : 74


---

# Nikki Thibodeau

## Position actuelle

**Entreprise** : Calix

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Nikki Thibodeau

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402355910158807040 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEUvOLaciRMLA/feedshare-shrink_800/B4EZrpzeH1KkAk-/0/1764859176303?e=1766620800&v=beta&t=rSLQ85tQDNtflmcW7QU0NiG16AiaLGrUhVGsNebbRlI | "It’s no wonder 39% of respondents told us their community teams now work across multiple departments. It shows just how essential community has become to how businesses run today."

I really enjoyed the Circle Trends Report this year! It hit a few key trends that I've certainly seen on the rise (as I am sure that you have too!)
One of them is that Community is far more embedded across the business. 

We know as community professionals that our community wins the more other parts of the business are bought in and engaging with our members. 

Check out this trend, and so many more from some of the brightest minds in the space: Jocelyn Hsu, Nicola Earle, Max Pete, Erin Simmons (they/them), Daniel Cmejla and more!!

https://lnkd.in/exYufZNn | 58 | 15 | 2 | 3d | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:13.061Z |  | 2025-12-04T14:39:38.104Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7401712253693075456 | Text |  |  | In the Calix Community, we introduced a group this year called "No Dumb Questions". 

I remembered that in a chat I had with Mark Freeman at the 2024 ConneXions, he said something that struck me: (paraphrased) "I get feedback that people don't want to post on the community because they don't want to look dumb."

I mentioned that to my team, and not long after, Sarah E. created the No Dumb Questions group. Without promotion, the membership of that group climbed. Now, it is one of the biggest groups on our community.

As a community professional, I know that communities themselves are an invitation to ask questions. 
As a human, I know how intimidating it can be to write a post. Not knowing if this is something that "everyone knows" or that I "should" know. 

✨  Giving your community members the permission to post - and removing whatever perceived shame there is - creates magic. 

Let me know if you try this out and how it lands in your community! | 61 | 24 | 1 | 5d | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:13.061Z |  | 2025-12-02T20:01:58.444Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399448471973335041 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG8yRxILKslAg/feedshare-shrink_800/B4EZrATu5WIoAg-/0/1764162990027?e=1766620800&v=beta&t=pxfhoPCl5Welpb7j6jHpra9LxLVITazbMFKvlQJX7pU | Community Management 101: Quiz Time

A member of your community provides feedback about your product or event. Do you:

A) Double down in the comments without any dialogue.
B) Have a dialogue to try and understand your member / let them feel heard.
C) Call them a hater and a troll.
D) A & C | 19 | 6 | 0 | 1w | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:13.062Z |  | 2025-11-26T14:06:30.823Z | https://www.linkedin.com/feed/update/urn:li:activity:7399435888444780544/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7397643423249350656 | Text |  |  | ✨ Gratitude Friday ✨ 

Today, I am sharing my gratitude for Nicole Saunders and Shannon Emery.

Nicole recently hopped on a call with me, and we covered everything from the community industry to conversations around career. Having a friend who brings insight, talent, and perspective to those conversations is truly invaluable. I’m lucky to have that in Nicole.

Shannon has also been such a source of support lately. She’s been a listening ear, holding space for me to process, sharing laughs, and offering thoughtful perspective. Her ability to combine empathy with humor has been a real light during a challenging patch.

I’m so grateful to you both for the ways you show up.

✨  Heading into the weekend - your mission is to send someone you're grateful for a message to tell them about it! | 50 | 6 | 0 | 2w | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:13.063Z |  | 2025-11-21T14:33:53.671Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7396566445763211265 | Article |  |  | Such exciting changes lay ahead!! | 10 | 1 | 0 | 2w | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:13.063Z |  | 2025-11-18T15:14:22.229Z | https://ow.ly/AoO350XtaZI |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7393683221550411776 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFM9FVoZV9QCg/feedshare-shrink_800/B4EZpujtYgKMAg-/0/1762791446756?e=1766620800&v=beta&t=ZinISGG0RAUQHdrQoJ4neQ5g4raYkuknEnVMvXeITbA | This picture was taken two years ago at our first ever The Community Community (TCC) in person meet up. In 5 days, TCC will celebrate its 3 year anniversary. THREE YEARS!? What the heck??

TCC was started because there was something missing in community communities for me. A place to have deeper conversations around community and customer experience topics with seasoned pros.

Sometimes, I think I should be talking about it more. 
I spoke with one of our members last week and asked what she thought about us becoming an official non-profit / professional association and she said "I actually didn't know." 😅 Ooopppppp.

👉  So yeah - TCC is a professional association that belongs to its members. It has absolutely changed my life, and I'm going to find a way to talk about it more. ✨ 💗 | 81 | 6 | 1 | 3w | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.688Z |  | 2025-11-10T16:17:28.009Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7388934295991504896 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGPBis9Fu-Dcw/feedshare-shrink_800/B4EZorEjvnHgAk-/0/1761659207915?e=1766620800&v=beta&t=RbjgtSPSCPNVICv09asL8MTF_sRI3j31RcxFNRc1bCM | Somehow, Francisco Opazo convinced me to come speak at Toronto Community Week -  just days after helping run a 3,000+ person conference. 😅

✨ And you know what? I'm so glad he did. 

After an incredible (and exhausting) week at Calix’s #ConneXions25, I had barely unpacked from Vegas before I was on a train to Toronto (just 14hours later.)

I spoke about aligning community programs with business objectives, a topic I care deeply about.

I feel fortunate to be at Calix, where Community is considered table stakes. With leaders like John Durocher, Kylie Harriman, and Allison Boudreau championing the work, Community is embedded into the core of our business. Because of that, my team and I don’t have to spend time proving its value. We get to focus on building it.

We begin with business goals, identify customer pain points, and create programs that address both. It’s the kind of environment every Community professional hopes for.

As well as being able to nerd out about Community center stage, I got to absorb some incredible information from Community pros. 

✨ Erica Kuhl reminded me to continue to strive for not shipping our org chart.
✨ Max Pete shared some tips to ensure we are staying on top of our mental health.
✨ Ashley Gallman Williams reminded me that I need to crisp up my elevator pitch.
✨ Andy Claremont showed how Partners + Community = magic (Stephen Eyre 👀 )
✨ Ruthie Berber blew my mind with the speed at which she grew her team, and inspired me to think outside the box when it comes to building a team.

AND SO MUCH MORE. 

Highlights included: 
👉 Seeing so many The Community Community members IRL. (Is there anything better than being in Gabrielle Leith's presence?)
👉Connecting with Beth Saunders - a community champion turned community manager who is asking all of the right questions. (and is a blast to hang with!)
👉The feeling of serendipity of meeting Natasha K. who works at the intersection of my passions (Community AND Women in Tech!?)
👉Having more laughs than I can count with Zach Hawtof. (Vendor? Or the Community industry's BFF?)

Huge thanks to the Led by Community C.I.C team for always delivering - from the content to the food. I already can’t wait for the next one! | 138 | 26 | 3 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.689Z |  | 2025-10-28T13:46:55.925Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7388604008476684288 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGfnVtuKo6Bog/feedshare-shrink_800/B4DZomYJmRJcAg-/0/1761580460842?e=1766620800&v=beta&t=OTZ2S1eq3sOSKKHyOQ4cktxdSfk6kcrN6MIBnfCCvDc | Last week, I had the absolute pleasure of attending my third Calix #ConneXions25. 

What an incredible experience - it feels difficult to put into words. 
From leading Women In Telecom (with early feedback suggesting that this was the best year yet??) to watching my team create incredible experiences across the conference, to leading the charge of a new offering called "Takeaway Tuesday" where we helped our customers disseminate what they learned into action - how do you boil that down into a LinkedIn post?

My team created new experiences & updated previous ones:
✨ Build Your ConneXions Roadmap
✨ Level Up Lounge
✨ Champions Cache
✨ ConneXions Challenge
✨ Co-Design Roadmap at the Community Booth!
✨ Updated Circles of Success format
✨ Takeaway Tuesday
✨ Calix Champions Event
✨ Champion of Success Innovation Award

Not to mention the incredible innovation we announced and the future of Calix looking bright! (How cute are those agents!?)

If you're a customer, and you have feedback - we'd love to hear it. 
This #ConneXions25 was an unforgettable experience, and I'm so grateful to my team and other across Calix for delivering such value to our customers! | 97 | 4 | 1 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.690Z |  | 2025-10-27T15:54:29.245Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7386093577484992512 | Video (LinkedIn Source) | blob:https://www.linkedin.com/dc1354b3-c6d2-4b0a-9100-e8da1f603f8e | https://media.licdn.com/dms/image/v2/D4E05AQEPUJ7C5ZZ6ug/videocover-high/B4EZn_0U65KYB8-/0/1760933535916?e=1765782000&v=beta&t=th-fg1Qu06wcgI0YVe8nhVg219OioGY29S4htOPpET4 | We are so thrilled that Vanessa Clemmensen was able to attend ConneXions and we were able to award her for her incredible contributions to the Calix Community and Calix Success.

Vanessa is the definition of a Champion. Among everything else (12 Calix University courses completed, 250+ community contributions, Champions Cache member, etc.) - she worked with a Calix intern this summer to help create a new roadmap - helping to mentor that intern through giving her opportunity to work directly with a customer.

Whatever Vanessa touches is better for her being there, and we are so grateful for her! | 14 | 1 | 1 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.691Z |  | 2025-10-20T17:38:55.855Z | https://www.linkedin.com/feed/update/urn:li:activity:7386091339882610691/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7385854795934502912 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFKUZBjDlGd_Q/feedshare-shrink_800/B4EZn.velVKcAg-/0/1760915487040?e=1766620800&v=beta&t=lRbVQ1D_K_OuXVVttSImGUGMBcsQVAXuwa6d0sIOhyI | Have you ever been to a panel session where you wish you could just have weekly calls with the panelists? 

That was this one for me today.  ✨

I have so much I want to post about regarding today (and will when I get a breath!)

But this panel was one for the books for me.
Dara Leslie, Sarah Malin and Stacey Slaughter are incredibly intelligent, generous with their time, and have YEARS of experience.

What an absolute honor to have been able to bring that conversation to the stage, and a huge thank you to Allison Boudreau for so expertly guiding that conversation as our moderator. | 28 | 1 | 1 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.692Z |  | 2025-10-20T01:50:05.897Z | https://www.linkedin.com/feed/update/urn:li:activity:7385814886834028544/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7384598734535553024 | Article |  |  | Come work at Calix with me!! If you're a skilled customer success manager, and are customer obsessed, this is a great role for you! | 20 | 1 | 4 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.693Z |  | 2025-10-16T14:38:57.523Z | https://calix.wd1.myworkdayjobs.com/External/job/Remote---USA/Success-Engagement-Manager---SmartHome_R-10968 |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7384206398093643777 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b9d5720f-64c8-48ee-afc5-2e3606629ab4 | https://media.licdn.com/dms/image/v2/D4E10AQFxeNDrbMoZag/videocover-low/B4EZnjqCodKgAk-/0/1760461076718?e=1765782000&v=beta&t=iL-hVi8hidICtin0Wnx0eLoyVmkWe8Uz1isHEjGgd4E | Leaving for Vegas in less than 72hrs!! Cannot wait to see y'all there. 
So much to learn, so much to see - it's a new game out there, so let's play by new rules. | 14 | 0 | 0 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.693Z |  | 2025-10-15T12:39:57.226Z | https://www.linkedin.com/feed/update/urn:li:activity:7383908988410843136/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7382522206431494144 | Text |  |  | It's Friday! Gratitude day!

This week, I am sharing my gratitude for my husband, Charles. 
I've struggled writing something that feels like it expresses just how much I am grateful for him. 

But then, I remembered a section from his vows about our love (skip this if you don't like sappy stuff) "No matter how hard I tried, I kept finding that words aren't adequate for the love that we share... but soon I realized that it's completely OK, because I knew that I didn't have to explain any of it to you. You, alone in the entire world, know exactly how great our love is, because you feel it the same way that I do."

So, just know that I could never write something that allows you, dear reader, to fully comprehend how grateful I am for him. But it's okay, because he knows.

✨ Have a great weekend, y'all! Be sure to tell your loved ones that you're grateful for them. | 38 | 3 | 0 | 1mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.694Z |  | 2025-10-10T21:07:34.643Z |  |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7380988711976722432 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFjZ3eckK3t9g/feedshare-shrink_800/B4EZm6KHhcIwAk-/0/1759764839512?e=1766620800&v=beta&t=DpAikH03fQhNYxFE1k7FPmBNsMkgLBg48jv9e2qZDcY | Years ago, I took a leadership course that left me with a lesson I’ll never forget: the concept of the Context Window.

We all have one, and each is uniquely shaped. Every experience we have passes through this window, then gets filtered by our attitudes, beliefs, opinions, and personal truths.

What comes out the other side? Our judgments, behaviors, and results.
One example that stuck with me: siblings. Ask a group of siblings what it was like growing up with their parents, and you’ll likely get very different answers. Not only did each sibling experience a different version of their parents, but their broader life experiences (especially if they’re perceived as a different gender) will shape how they interpret those moments.

That context window influences how we judge situations, how we behave, and what outcomes we create.

When I tell you I drove straight to my brother to apologize for not believing his very different lived experience of our “same” upbringing… 😅

This applies to everyone around us. We can share the same moment, yet perceive it entirely differently. And neither of us is wrong.

That’s why curiosity is so powerful. Instead of reacting, pause and ask:
“I’d love to understand how you came to that conclusion?”

Ask it with genuine curiosity, and you’ll get a glimpse into someone else’s world - even if just for a moment.

✨ ➡️  I'd love to hear from you? What are your thoughts on this Context Window? Does this make you rethink how you interpret others' reactions around you? | 26 | 3 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.695Z |  | 2025-10-06T15:34:01.074Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7380424888274288640 | Text |  |  | Looking forward to ConneXions 2025!! 
So much incredible content, among which my team has dreamt up some brand new experiences!!

New Circles of Success?
New Takeaway Tuesday?
Level-Up Lounge? 

GET EXCITED, because it’s happening!! | 7 | 3 | 1 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.696Z |  | 2025-10-05T02:13:35.028Z | https://www.linkedin.com/feed/update/urn:li:activity:7379641909528649728/ |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7379964535404933121 | Article |  |  | This is an absolutely must watch. It changed the way I give, and I am much less controlling of what the money is spent on. 

Cash = power, and I'm working to cede that power more and more. | 5 | 0 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:17.696Z |  | 2025-10-03T19:44:18.351Z | https://www.youtube.com/watch?v=eAXOQRWignM |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7379915851132723202 | Video (LinkedIn Source) | blob:https://www.linkedin.com/e0971d77-2294-4967-a0e3-4618251952f0 | https://media.licdn.com/dms/image/v2/D4D05AQE-J_ASZSRtCw/feedshare-thumbnail_720_1280/B4DZmqo42bIgAw-/0/1759504470469?e=1765782000&v=beta&t=TWqsZMSYlLroRV6yUz3H-l7Ify2Qm9ymkM2Xc5y50Dw | I am SO SO excited to be speaking at Toronto Community Week on my own home turf 🇨🇦 

Who here deals with tying their Community Tactics back to Business Objectives? I'll show you exactly how my team and I do that here at Calix! | 31 | 0 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.611Z |  | 2025-10-03T16:30:51.116Z | https://www.linkedin.com/feed/update/urn:li:activity:7379908111769362453/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7379884679996542978 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEaMaN_h5kbnw/feedshare-shrink_800/B4EZmqd_k7KgAg-/0/1759501617487?e=1766620800&v=beta&t=VSh9DDGwA5vkeYXMTYMQLbiBPmTjAi0kRTkhIDf1urg | You know what time it is, right?
✨ GRATITUDE FRIDAY ✨ 

This week, I'm really grateful for my dog, Felipe. 
We have had him for 1 1/2 years. When we adopted him, he had just failed his first home placement from Mexico, where he had sat in a kennel for over a year waiting for his forever home. 

When we first met him, he wouldn't even let us touch him. Now look at this silly goose. That takes courage for him to open up and trust, and I am so grateful that he allows us to show up for him everyday. 

If you told me, before Felipe, that I would love being the one to do the dog's morning walk, I would have absolutely laughed in your face. But it's true! One of my favourite things about each day is that it starts with a walk with my buddy - rain or shine (or sleet or snow). 

Here's to you, the chicken loving, will do anything for a treat, smart and sassy dog that you are. We love you, and I'm so grateful that you came into our lives.

Who or what are YOU grateful for this week? | 56 | 11 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.612Z |  | 2025-10-03T14:26:59.338Z |  |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7379608207662673920 | Text |  |  | This may come across as snarky, but please know that I really truly mean it:

If you do not have capacity to have a meeting, don't schedule it hoping that you will. ✨ Just say no. ✨ 

The longer version of this post is this:

I've been leaning in a little more to when I get auto-paired with someone in a membership matching program or some other request to meet comes up. 
Do I have a lot of free time? Nope! But I'm prioritizing connecting with others these days so I don't just bury myself in work. 

Something I have noticed though, is a lot of the time I've made a meeting, the other person cancels shortly before. 

The kicker? I have been this person in the past. 😅 
Mostly because I was hoping to have some capacity magically appear and I didn't want them to think that meeting with them wasn't valuable. 

But being the person who is instigating these meetings, I would rather you say that you don't have time upfront. It's hard to continue to be motivated to set up meetings with new people when they so often get cancelled. I won't be offended if you say that you don't have time right now! 💗 

How do others feel about this? Are you seeing the same thing? Can you relate? | 38 | 3 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.612Z |  | 2025-10-02T20:08:23.197Z |  |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7377330956489158656 | Text |  |  | You know what time it is: it's  ✨  Gratitude Friday ✨ !

This week, I want to shout out two people I shared a stage with:

Beth McIntyre
I actually do not know how Beth does it. She is so incredibly talented and wicked smart. She has a vast amount of impact on/in the community industry and she is somehow still so humble!? She has a calming presence - even when relaying some hard truths. 
I feel so grateful to have her as a friend in this industry, and as a MASSIVE contributor to the profession. 

avely pütsep
Y'all. This woman is a firecracker. A little self-deprecating, but someone with such a fierce drive to build connection with & for others. She is curious, knowledgeable, authentic and kind. She creates real moments of connection and it was so lovely to be at an event and seeing the type of community that she is helping to create at Remote Daily. 

I'm so lucky to be surrounded by talent in this industry. Who rise each other up and stay human. What a gift!

✨  WHO ARE YOU GRATEFUL FOR THIS WEEK?
Either tag them below, create your own post, or share a note directly in their inbox. | 31 | 9 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.613Z |  | 2025-09-26T13:19:24.208Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7377316518331846656 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQFPnHxjlhk9pQ/image-shrink_800/B4EZmFCbPgIUAc-/0/1758873632849?e=1765782000&v=beta&t=w8Dm1DpH6tMSPiQI8TPs4nPK5s1JYU5kb1iGrl-4TUo | This is one of my favourite talks that I’ve ever done. It showcases the ways in which we can build meaningful programs with impactful results.

I’m so excited to be attending a community conference here in my own country, too!! I would love to see you there! | 19 | 2 | 1 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.614Z |  | 2025-09-26T12:22:01.883Z | https://www.linkedin.com/feed/update/urn:li:activity:7377250719013183488/ |  | 

---

## Post 22

https://www.linkedin.com/feed/update/urn:li:activity:7374806647824871425 | Text |  |  | It's Gratitude Friday!
✨  Who or what are you grateful for this week? 

Me? I want to send a BIG shoutout to the folks who enabled me to take a week off last week. I was able to jump into natural bodies of water, cry by the ocean, dance at a music festival and see a few of my West Coast peeps. It was refueling for SURE. 

Thank you to my direct team at Calix:
Trevor M., Austin Swick, Ian Rumbaugh, Amanda Streimer, Sarah E., Trent Tate and Sameer Sharma

My fearless leader:
Allison Boudreau

My The Community Community team:
Jocelyn Hsu, Tiffany Oda, Scott Baldwin and Maryblessing Okolie

Our dog's foster mom who cared for Felipe while we were gone. 🐕 

and thank you to my friends who I didn't see while in Victoria. I needed this time to reset, and your understanding of not filling all of the days with coordinating schedules to see each other meant a lot. 

✨  Who or what are you grateful for this week? | 30 | 8 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.615Z |  | 2025-09-19T14:08:42.123Z |  |  | 

---

## Post 23

https://www.linkedin.com/feed/update/urn:li:activity:7374459279610908672 | Video (LinkedIn Source) |  |  | Next week, I have the pleasure of speaking with Beth McIntyre and avely pütsep on a panel about the future of Community! STOKED for this! | 16 | 5 | 1 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.615Z |  | 2025-09-18T15:08:23.087Z | https://www.linkedin.com/feed/update/urn:li:activity:7373415054593126400/ |  | 

---

## Post 24

https://www.linkedin.com/feed/update/urn:li:activity:7374458710858940417 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHVXLMo_Ct26g/feedshare-shrink_800/B4EZldVCX_KQAg-/0/1758207422693?e=1766620800&v=beta&t=BEOp3j9bevT6kY_-KZ9bEd5Xgx4kFGE_3Tm3AznwRoA | REALLY looking forward to this!! It's so soon too. 
Are you going to be there? | 9 | 0 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.616Z |  | 2025-09-18T15:06:07.486Z | https://www.linkedin.com/feed/update/urn:li:activity:7374456434064850945/ |  | 

---

## Post 25

https://www.linkedin.com/feed/update/urn:li:activity:7370813602863403009 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE-gndfdG5xPA/feedshare-shrink_800/B4EZkpj6PDKQAg-/0/1757338905020?e=1766620800&v=beta&t=y0GXIkUlatLKdMIPoEp3XsF75mqHRKgUWrD7w7S-TGk | A few months ago, someone from my hometown slid into my DMs and said "Do you want to do a house swap in September?" 

I hadn't planned on making a trip back to my hometown this year, but it's hard to turn down a free place to stay, a chance to visit the ocean and the opportunity to hop in a lake. In case you don't know, my hometown is Victoria, British Columbia Canada 🇨🇦. Arguably the most beautiful place on earth. 

Calix is a work from anywhere company. I double checked that there would be a place for me to work in her house and started to make plans around working 6am-2pm everyday. 

While planning, I kept thinking about how I'd be missing out on the best time to go to the lake. (When kids are in school, and before noon.) So then I looked to see if there was a day I could take off while I was away. 

The thought crossed my mind about what I would say to a direct report who was trying to find the best day here or there. "Why not all of them? Let's make it work so you could enjoy your time while you're there." But I've already taken a bunch of time off this year. Most recently, 10 days in July to travel to Ireland & London. 

I asked my boss (Allison Boudreau) if it would be okay and she said "You work hard and get it done! I’m glad you are taking time off." 

🙃 Is now the most opportune time to take time off? Heck no.
🙃 Am I already have a mild panic about being away for a week? You betcha. 
😃 Is my team incredible and able to handle whatever comes up? Absolutely.

I'm so grateful to Calix and its culture - enabling me to work hard AND play hard. 

✨ Take the time off. 
✨ Jump in the lake (it's going to be cold, but whatever. ha)
✨  Spend time with your friends.

The picture is one that I took of my favourite lake in Victoria, Durrance Lake. I'm excited to jump in it again! | 104 | 12 | 0 | 2mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.617Z |  | 2025-09-08T13:41:46.017Z |  |  | 

---

## Post 26

https://www.linkedin.com/feed/update/urn:li:activity:7369746820551385088 | Text |  |  | Let's do another Attitude of Gratitude Friday post. (will this become a thing? Only time will tell!)

I'm really grateful for ☕ coffee from Balance Torrefacteur in Montreal. I ran out of beans this week and had to drink other coffee and IMMEDIATELY missed my Balance coffee beans.

People who brightened up my week this week:

LaToya Scroggins, MPA
It was so fun getting to nerd out on Community / Marketing Funnel and Career with LaToya this week. I'm very grateful for the conversation!

Elizabeth King
Lizzy is an incredible collaborator. She is incredibly proactive and energetic, and I really appreciate her thoughtful approach to the way we work. She is (obviously) customer oriented, and she is an incredibly clear comunicator!

AB Bannon & Ximena Rogers
Who told me the things they like about me, unprompted, and it was SO KIND and grew my heart 10 sizes. 

Shannon Emery
Shannon's friendship is... quiet and ever present. Through exchanged memes and dog pictures, there is a way that she shows up where you feel supported and seen. I love that for me <3 

✨ Who are YOU grateful for this week? | 38 | 7 | 0 | 3mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.618Z |  | 2025-09-05T15:02:45.294Z |  |  | 

---

## Post 27

https://www.linkedin.com/feed/update/urn:li:activity:7369078105031852033 | Text |  |  | Do you need a little mid-week pick me up?

✨  I double-dog dare you to message 3 people in your circle and ask them to send you a message of what they like/love about you. 😉 

1️⃣ It reminds you that you have people in your corner.
2️⃣ It forces those of us who hate asking people for things for ourselves to practice this in a low-stakes way.
3️⃣ It creates a moment of connection. 
... and MORE.

Are you up for the challenge? | 17 | 3 | 0 | 3mo | Post | Nikki Thibodeau | https://www.linkedin.com/in/nikki2987 | https://linkedin.com/in/nikki2987 | 2025-12-08T06:04:22.618Z |  | 2025-09-03T18:45:31.090Z |  |  | 

---



---

# Nikki Thibodeau
*Calix*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 12 |

---

## 📚 Articles & Blog Posts

### [The Community Industry at a Crossroads: An Interview with Nikki Thibodeau](https://cmxhub.com/blog/the-community-industry-at-a-crossroads-an-interview-with-nikki-thibodeau)
*2023-02-14*
- Category: blog

### [Key Voice Series: Calculate Community ROI with Nikki Thibodeau](https://thecommunitycollective.co/blog-1/f/key-voice-serieshow-to-calculate-the-roi-of-community-with-nikki?blogcategory=Interviews)
*2025-01-27*
- Category: blog

### [Nikki Thibodeau | Founder & Head of Community at The Community Community](https://www.ledby.community/stories/post/nikki-thibodeau-founder-head-of-community-at-the-community-community-WHOsmoQDcdlVOXW)
*2024-10-09*
- Category: article

### [Community Nikki | Nikki Thibodeau](https://communitynikki.com/)
*2024-01-01*
- Category: article

### [Episode 4: The Heart of the Sell with Nikki Thibodeau & Keighty Gallagher — The Forum](https://www.theforum.ca/podcast-episodes/s2e4-english)
*2021-02-25*
- Category: podcast

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Community Nikki | Nikki Thibodeau](https://communitynikki.com/)**
  - Source: communitynikki.com
  - *Helping to foster a space for more women in technology. Now, she is the Regional Vice President, Digital Engagement & Community at Calix and also the ...*

- **[Led by Community](https://www.ledby.community/)**
  - Source: ledby.community
  - *... Nikki Thibodeau, a seasoned leader shaping community operations and digital engagement at Calix—and founder of The Community Community. Key discus...*

- **[Conference Talks – Community Nikki](https://communitynikki.com/pages/conference-talks)**
  - Source: communitynikki.com
  - *Podcasts · Twitter · Instagram · Resume · LinkedIn · Contact Me ... Nikki Thibodeau will delve into the strategies Calix implemented to restore custom...*

- **[Nikki Thibodeau - The Community Community & Calix Community ...](https://www.youtube.com/watch?v=6VrA3i-pGtM)**
  - Source: youtube.com
  - *Oct 7, 2024 ... ... podcast: https://podcast.digita... Steadfast Collective: https://steadfastcolle... Find more from Nikki Thibodeau: http://www.cali...*

- **[See CMX Summit 2025 at CMX Connect, powered by Bevy CMX HQ](https://events.cmxhub.com/events/details/cmx-cmx-hq-presents-cmx-summit-2025/)**
  - Source: events.cmxhub.com
  - *... Nikki Thibodeau. Calix. RVP, Digital Engagement & Community. See bio. Paz ... Podcast · Privacy Policy · CMX Blog. Community. CMX Weekly Newslette...*

- **[Transforming Customer–Brand Relationships | Kogan Page](https://www.koganpage.com/marketing-communications/transforming-customer-brand-relationships-9781398621329)**
  - Source: koganpage.com
  - *Sep 3, 2025 ... Podcast · Videos · Trending · Accelerate Action for ... Nikki Thibodeau, Regional Vice President, Digital Engagement and Community at ...*

- **[Community Leadership: How to Grow, Innovate, and Plan for ...](https://www.youtube.com/watch?v=uU94mcsaLrA)**
  - Source: youtube.com
  - *Jul 28, 2023 ... ... Nikki Thibodeau (Senior Manager of Community and Customer Advocacy at Calix, founder of The Community Community, and interim comm...*

- **[Conference - London Community Week](https://london.community-week.com/conference/)**
  - Source: london.community-week.com
  - *... Nikki Thibodeau, Regional Vice President, Digital Engagement & Community, Calix. Shine Track. 10/07/2025. 9:30 am ... interviews, how to structure...*

- **[Speakers – Toronto Community Week](https://toronto.community-week.com/speakers/)**
  - Source: toronto.community-week.com
  - *fbpx. Skip to content. About · 3-Day Agenda · Conference · Conference Overiew ... Nikki Thibodeau. Regional Vice President, Digital Engagement & Commu...*

- **[See CMX Summit 2022: Thrive at CMX Connect, powered by Bevy ...](https://events.cmxhub.com/events/details/cmx-cmx-hq-presents-cmx-summit-2022-thrive/)**
  - Source: events.cmxhub.com
  - *If you plan on using a desktop, you'll be using the Bevy Conference Platform on Google Chrome. ... Nikki Thibodeau. Calix. Senior Manager of Community...*

---

*Generated by Founder Scraper*
