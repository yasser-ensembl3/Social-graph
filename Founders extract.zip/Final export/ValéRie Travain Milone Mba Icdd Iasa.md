# Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A

## Position actuelle

**Titre** : Founder, Executive Partner
**Entreprise** : ImpactON Consulting
**Durée dans le rôle** : 3 years 3 months in role
**Durée dans l'entreprise** : 3 years 3 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Growth and Impact advisory | Support to start-ups and scale-ups in their prospective business plans and implemention | Business advisory, supporting Private equity firms in their investment strategies

## Résumé

With over 30 years of international experience and French-Canadian dual citizenship, I have held executive roles, specializing in business development, governance, and strategy across diverse sectors. 
As President, Advanced Technologies at Calian Group, I led a global team delivering software and hardware solutions for defense & space industries, and communication networks. 
My work experience emphasizes strategic execution,  P&L management, and fostering resilient and sustainable portfolios.  
Leveraging expertise in digital transformation, strategic planning and problem solving, I am passionate about driving organizations and teams towards achieving operational excellence and sustainable growth. 
My career - as executive and non executive board member -  reflects a strong commitment to enabling impactful business strategies, harmonizing portfolios, and driving organizational transformation in critical sectors.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAAA4eYByeQXfOPHlaZ9hTGDkc_GM-WEYQU/
**Connexions partagées** : 14


---

# Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A

## Position actuelle

**Entreprise** : E2IP TECHNOLOGIES

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Valérie TRAVAIN-MILONE, MBA, ICD.D - IAS.A
*E2IP TECHNOLOGIES*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Fortune Global 2000 Executive, Valerie Travain Milone, joins the E2IP Board of Directors](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html)
*2024-03-11*
- Category: article

### [Calian Announces the Appointment of Valérie Travain-Milone as President, Advanced Technologies](https://www.marketscreener.com/quote/stock/CALIAN-GROUP-LTD-1409624/news/Calian-Announces-the-Appointment-of-Valerie-Travain-Milone-as-President-Advanced-Technologies-46300268/)
*2024-03-27*
- Category: article

### [E2IP TECHNOLOGIES Completes $120 Million Growth Funding Round - e2ip](https://e2ip.com/publications/e2ip-technologies-completes-120-million-growth-funding-round/)
*2023-08-23*
- Category: article

### [E2ip Technologies - 2025 Company Profile - Tracxn](https://tracxn.com/d/companies/e2ip-technologies/__mLs40pMNYcGLHvFWkGVKxjfjJLIfktqr5U7oisPRs8A)
*2025-04-27*
- Category: article

### [E2ip Technologies - 2025 Funding Rounds & List of Investors - Tracxn](https://tracxn.com/d/companies/e2ip-technologies/__mLs40pMNYcGLHvFWkGVKxjfjJLIfktqr5U7oisPRs8A/funding-and-investors)
*2025-04-27*
- Category: article

---

## 📖 Full Content (Scraped)

*4 articles scraped, 5,503 words total*

### Fortune Global 2000 Executive, Valerie Travain Milone, joins the E2IP Board of Directors
*2,699 words* | Source: **EXA** | [Link](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html)

Fortune Global 2000 Executive, Valerie Travain Milone, joins the E2IP Board of Directors

===============

[Close menu](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-0)

*   [News](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-news)
*   [Products](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-products)
*   [Contact](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-contact)

[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-default)
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-news)
*   _3_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-1)News in Focus
*   _5_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-2)Business
*   _5_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-3)Science & Tech
*   _5_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-4)Lifestyle & Health
*   _1_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-5)Policy & Public Interest
*   _1_[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-6)People & Culture
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-products)
*   [Explore Our Platform](https://www.newswire.ca/amplify-platform/ "Explore Our Platform ")
*   [Plan Campaigns](https://www.newswire.ca/amplify-ai-plan-module/ "Plan Campaigns ")
*   [Create with AI](https://www.newswire.ca/ai-press-release/ "Create with AI ")
*   [Distribute Press Releases](https://www.newswire.ca/pr-distribution-and-placement/ "Distribute Press Releases ")
*   [Amplify Content](https://www.newswire.ca/multichannel-amplification/ "Amplify Content ")
*   [IR](https://www.newswire.ca/products/investor-relations/ "IR")
*   [All Products](https://www.newswire.ca/products/all-products/ "All Products")
*   [Send a Release](https://www.newswire.ca/contact-us/)
*   [Sign Up](https://www.newswire.ca/contact-us/)
*   [Resources](https://www.newswire.ca/resources/)
*   [Investor Relations](https://www.newswire.ca/products/investor-relations/)
*   [Journalists](https://prnmedia.prnewswire.com/)
*   [Webcasts](https://cnw.en.mediaroom.com/events)
*   [my CNW](https://www.newswire.ca/mycnw/login/)
*   [GDPR](https://gdpr.cision.com/)
*   [](https://twitter.com/CNWGroup)[](https://www.facebook.com/CisionCA/)[](https://www.linkedin.com/company/cnw-group)

[](https://www.newswire.ca/news-releases/fortune-global-2000-executive-valerie-travain-milone-joins-the-e2ip-board-of-directors-831408452.html#mm-panel-contact)
*   [Sign Up](https://www.newswire.ca/contact-us "Sign Up")
*   [Request a Demo](https://www.newswire.ca/request-a-demo/ "Request a Demo")
*   [Editorial Bureaus](https://www.newswire.ca/contact-us/editorial-bureaus "Editorial Bureaus")
*   [Partnerships](https:

*[... truncated, 67,635 more characters]*

---

### E2IP TECHNOLOGIES Completes $120 Million Growth Funding Round - e2ip
*747 words* | Source: **EXA** | [Link](https://e2ip.com/publications/e2ip-technologies-completes-120-million-growth-funding-round/)

**April 26, 2023 – Montreal, Canada**– e 2 ip technologies, a global printed electronics and embedded system technologies innovation leader of the Human Machine Interface (HMI) and Industrial Internet of Things (IIoT) sectors, announced today the completion of its oversubscribed global growth funding round. The Series B financing is co-led by Export Development Canada (EDC) and McRock Capital with existing investor Investissement Québec, who more than doubles its position, and new investor DNA Fund. The round is also supported by National Bank of Canada (BNC). Founding investors W and Namakor remain.

The investment provides e 2 ip technologies with growth capital to productize decades of HMI and IIoT technology leadership from its high-performance engineered solutions business and to grow global revenue through the digital deployment of its productized and ready-to-use printed electronics, embedded systems, touchscreen and In-Mold-Electronics (IME) platforms.

“e 2 ip’s technology is revolutionizing the HMI and IIoT industry. Backed by world-class proprietary and patented technology, they are supporting their customers from ideation to fabrication,” said Guillermo Freire, Senior Vice-President, Mid-Market Group at EDC. “Working with like-minded investors, EDC is thrilled to have played a meaningful role in this round of funding. As a strategic investor, EDC can support e 2 ip by leveraging our financial solutions, trade knowledge and international networks, providing the company with even more momentum to expand into new markets and become a more dominant international market leader.”

The round will enable e 2 ip to immediately expand its embedded systems capabilities in its existing high-volume facility in Casablanca, Morocco. Canadian facilities will additionally be consolidated into a new integrated Manufacturing-R&D facility in Montreal by the end of 2024, which will house e 2 ip’s new head office.

The company will also immediately begin the deployment of the new production lines in its Canadian facilities to provide global market leaders with a high volume, fully scalable In-Mold-Electronics Manufacturing Service (IM-EMS). Leveraging e 2 ip’s global portfolio of patents, these facilities will be the first fully integrated center of excellence, from material and process innovation to product ideation, industrial design, engineering and through to high-volume fabrication.

“e 2 ip’s Smart Structural Surface TM technologies enable functions such as touch controls, lighting, telecommunication and energy harvesting to be printed using additive manufacturing processes, and then directly integrated within the structural surface material of the objects, machines, appliances, and systems we all interact with in our everyday lives,” said Eric Saint-Jacques, CEO of e 2 ip technologies. “This significantly reduces the eco-footprint and cost of our customers’ products as the structural material is reused to integrate functions within the material, during the automated surface manufacturing process, versus adding components, labour and cost to the exterior of the structure during the final assembly. Overall weight and space are further reduced, and the overall design is made more appealing, usable and durable, creating greater differentiation for our market leading customers.”

e 2 ip is part of the advanced materials research and innovation center PRIMA Québec and the National Research Council of Canada, where, in partnership with different universities, it invests in fundamental research and applied science. The company’s R&D teams have developed market disruptive innovations through these collaborations, which have added further depth to the company’s broad patent portfolio of Smart Structural Surface TM technologies.

“Technology is a flagship sector for our economy, and Investissement Québec is strongly committed to supporting companies such as e 2 ip, proven leaders who put innovation at the forefront of their business strategy. We are proud to renew our partnership with e 2 ip and to help them grow and develop new international markets” said Guy LeBlanc, President and CEO of Investissement Québec.

DNA Fund, a Quebec-based private Equity fund, joins the e 2 ip investor eco-system with this round. “We are proud to support a great Québec-based company that has a long history of operational excellence in its transition towards a product-based business model and a global technology leadership,” said Stéphane Léveillé, CEO and co-Founder of DNA Fund.

**About e 2 ip technologies**

e 2 ip develops new technologies and products that transform how people interact with the physical world through innovations in printed electronics, material science, advanced manufacturing processes and embedded system-touchscreen development. From ideation to fabrication, we rethink the boundaries between technology and design to deliver innovative Human Machine Interface (HMI), Industrial Internet of Things (IIoT) and Smart Struct

*[... truncated, 154 more characters]*

---

### E2ip Technologies
*1,043 words* | Source: **EXA** | [Link](https://tracxn.com/d/companies/e2ip-technologies/__mLs40pMNYcGLHvFWkGVKxjfjJLIfktqr5U7oisPRs8A)

E2ip Technologies is a series B company based in Montreal (Canada), founded in 1999

.

It operates as a Provider of engineering and prototyping services for electronic manufacturing industry

.

E2ip Technologies has raised $88.3M in funding

from

[Export Development Canada](https://tracxn.com/d/companies/export-development-canada/__a3xJigg-WE8Ycgy7IF-IBoKLKjUNOOnivBFID5EwGBQ) and [McRock Capital](https://tracxn.com/d/venture-capital/mcrock-capital/__kKQN95tL977UimvHro5jzxZzluCX3sdT2As4mtQO9o4).

The company has 13 active competitors, including 4 funded and 2 that have exited

. Its top competitor

s

include companies like [Canatu](https://tracxn.com/d/companies/canatu/__mggktooBBD5XmYzlq3y9djv3Wu-IkGmTn_HLemSYaQM), [Meyer Burger](https://tracxn.com/d/companies/meyer-burger/__1HbM6M4kaSo0drVVoG24dZtQrDh1LH3kGU5qbFnO0mc) and [Flexterra Flexible](https://tracxn.com/d/companies/flexterra-flexible/__KIpViz6O1mGN5p45zdYu7OFUt1pwsLzztMKzxO5SSL4).

### Company Details

Provider of engineering and prototyping services for the electronic manufacturing industry. It specializes in specializes in printed electronics, Smart Surfaces, and Human Machine Interfaces.

Website[e2ip.com](https://e2ip.com/)

Email ID*****@e2ip.com

Phone Number+1 **********

Part Of[ggisolutions.com](https://platform.tracxn.com/a/d/company/585e74b4e4b0a3382bb17ede/ggisolutions.com)

Key Metrics

Founded Year

1999

Location

Stage

Series B

Total Funding

Investors

Ranked

Investment & Acquisitions

Similar Companies

![Image 1: PDF Illustration Image](https://cdn.tracxn.com/images/static/cta/pdf-icon-illustration.svg)

Download E2ip Technologies' company profile

E2ip Technologies has raised a total funding of$88.3M over 2 round s.Its first funding round was on 2020.Its latest funding round was a Series B round on Apr 26, 2023 for $88.3M.7 investor s participated in its latest round,lead by[Export Development Canada](https://tracxn.com/d/companies/export-development-canada/__a3xJigg-WE8Ycgy7IF-IBoKLKjUNOOnivBFID5EwGBQ) and [McRock Capital](https://tracxn.com/d/venture-capital/mcrock-capital/__kKQN95tL977UimvHro5jzxZzluCX3sdT2As4mtQO9o4).

Here is the list of recent funding rounds of

E2ip Technologies

:

| Date of funding | Funding Amount | Round Name | Post money valuation | Revenue multiple | Investors |
| --- | --- | --- | --- | --- | --- |
| Apr 26, 2023 | $88.3M | Series B | 5681663 | 9601552 | [Export Development Canada](https://tracxn.com/d/companies/export-development-canada/__a3xJigg-WE8Ycgy7IF-IBoKLKjUNOOnivBFID5EwGBQ), [McRock Capital](https://tracxn.com/d/venture-capital/mcrock-capital/__kKQN95tL977UimvHro5jzxZzluCX3sdT2As4mtQO9o4), and [5 more](https://platform.tracxn.com/a/d/company/FN3sc3ETsaIWmMyqTI7TKrBsOjTiuRFKcoNwPIPWoBw/e2ip.com#a:funding-and-investors) |
| 2020 | Undisclosed | Conventional Debt | 3694 | 9149 | [Invest Quebec](https://tracxn.com/d/companies/invest-quebec/__aOFLYIr7olbA8qnsmj1T5IY6_oss7i636EMpLpAe6SM) |

![Image 2: lock](blob:http://localhost/63e1f5b1c4e612612ccfea893e4c84d1)Access funding benchmarks and valuations.

[Sign up today!](https://tracxn.com/signup)

![Image 3: chrome_extension_cta_illustration](https://cdn.tracxn.com/images/static/cta/chrome_extension_cta_illustration.svg)

Access Tracxn on any website

Our Google Chrome extension lets you view company details while browsing their websites

[Install Tracxn Extension](https://chromewebstore.google.com/detail/tracxn-extension/mcplkbacfdjapifgiidjidmnfilipnep?hl=en)

Top competitor

s

of

E2ip Technologies

include

[Canatu](https://tracxn.com/d/companies/canatu/__mggktooBBD5XmYzlq3y9djv3Wu-IkGmTn_HLemSYaQM), [Meyer Burger](https://tracxn.com/d/companies/meyer-burger/__1HbM6M4kaSo0drVVoG24dZtQrDh1LH3kGU5qbFnO0mc) and [Flexterra Flexible](https://tracxn.com/d/companies/flexterra-flexible/__KIpViz6O1mGN5p45zdYu7OFUt1pwsLzztMKzxO5SSL4).

Here is the list of Top 10 competitors of

E2ip Technologies

, ranked by Tracxn score:

| Overall Rank | Company Details | Short Description | Total Funding | Investors | Tracxn Score |
| --- | --- | --- | --- | --- | --- |
| 1st | ![Image 4: Logo for Canatu](https://i.tracxn.com/logo/company/44fb712719264df52982149335f95a9?devicePixelRatio=2&height=40&width=40) [Canatu](https://tracxn.com/d/companies/canatu/__mggktooBBD5XmYzlq3y9djv3Wu-IkGmTn_HLemSYaQM) 2004 , Helsinki ([Finland](https://tracxn.com/d/geographies/finland/__66GZDgE4c7mtFZeNfi38zIpRev21kTct9s73_4NXzmA)) , Public | Developer of advanced carbon nanotube materials for industrial applications | $75.3M | [Nordea](https://tracxn.com/d/companies/nordea/__sMJGFYxGa15_AKry1lGASXcujyTfV4w2v6B4zjDkxbE), [European Investment Bank](https://tracxn.com/d/private-equity/european-investment-bank/__PWteErcIvK3tDMCMFdeWUvz3VQyr2n_bxXO5f22uWJY)& [10 others](https://platform.tracxn.com/a/d/company/CE8OvLCfHLkqPMDyhcNarFZfrh_4nwKCDytaea19X4I/canatu.com#a:funding-and-investors) | 51/100 |
| 2nd | ![Image 5: Logo for E2ip Technologies](https://i.tracxn.com/logo/company

*[... truncated, 10,561 more characters]*

---

### E2ip Technologies
*1,014 words* | Source: **EXA** | [Link](https://tracxn.com/d/companies/e2ip-technologies/__mLs40pMNYcGLHvFWkGVKxjfjJLIfktqr5U7oisPRs8A/funding-and-investors)

E2ip Technologies - 2025 Funding Rounds & List of Investors - Tracxn

===============

Your browser was unable to load all of Tracxn resources. They may have been blocked by your firewall, proxy or browser configuration. Press **Ctrl+F5** or **Ctrl+Shift+R** to have your browser try again and if that doesn't work,[**click here to retry**](https://tracxn.com/)or mail us at[**hi@tracxn.com**](mailto:hi@tracxn.com?subject=Platform%20resources%20not%20loading)

Internal Server Error

[![Image 2: Tracxn.com](https://cdn.tracxn.com/images/static/tracxn-logo-full-100x22.svg)](https://tracxn.com/?redirect=false)

Toggle navigation

*   Customers   Investment Industry [Venture Capital Funds](https://w.tracxn.com/customers/solutions-for-venture-capital-funds)[Private Equity Funds](https://w.tracxn.com/customers/solutions-for-private-equity-funds)[Accelerators & Incubators](https://w.tracxn.com/customers/solutions-for-incubators)[Investment Banks](https://w.tracxn.com/customers/solutions-for-investment-banks)      Corporates and Startups [Corp Dev and M&A Teams](https://w.tracxn.com/customers/solutions-for-corporate-dev-and-ma-team)[Corporate Innovation](https://w.tracxn.com/customers/solutions-for-corporate-innovation)[Startup Founders](https://w.tracxn.com/customers/solutions-for-startup-founders)[Sales Team](https://w.tracxn.com/customers/sales-teams)      Ecosystem [Journalists and Publications](https://w.tracxn.com/customers/solutions-for-journalists-publications)[Universities](https://w.tracxn.com/customers/solutions-for-universities)     [View All Customers](https://w.tracxn.com/customers) [Contact Us](https://tracxn.com/contactus)  
*   Offerings   Rich Data Sets [Companies](https://w.tracxn.com/companies-database)[Investors](https://w.tracxn.com/investor-database)[Funding](https://w.tracxn.com/funding-database)[Acquisitions](https://w.tracxn.com/acquisitions-database)[Financials](https://w.tracxn.com/offerings/financials-db)[Cap Tables](https://w.tracxn.com/offerings/cap-tables-db)[Employee Count](https://w.tracxn.com/offerings/employee-count-trend)      Deep Dives [Company deep-dive](https://w.tracxn.com/company-profiles)[Investor deep-dive](https://w.tracxn.com/investor-profiles)[Activity by Corporates](https://w.tracxn.com/activity-by-corporates)[Sector Coverage](https://w.tracxn.com/sector-profiles)      Workflow Solutions [Sourcing new deals](https://w.tracxn.com/deal-sourcing-made-easy)[Tracking Market Updates](https://w.tracxn.com/tracking-market-activity)[Portfolio Management](https://w.tracxn.com/portfolio-management)[Deal Flow CRM](https://w.tracxn.com/offerings/deal-flow-crm)[LiveDeals](https://w.tracxn.com/live-deals)      And Much More... [Data Solutions](https://w.tracxn.com/integrations/data-solutions/pricing-usd)[Reports by Tracxn](https://w.tracxn.com/offerings/feed-report)[Enterprise Grade Support](https://w.tracxn.com/offerings/enterprise-grade-support)[Sector Coverage](https://w.tracxn.com/sector-profiles)Apps & Extensions [![Image 3: Android](https://cdn.tracxn.com/images/static/downloadSection/Android_App_Icon.svg)![Image 4: Apple](https://cdn.tracxn.com/images/static/downloadSection/iOS_App_Icon.svg)](https://w.tracxn.com/offerings/web-application)[![Image 5: Chrome Web Store](https://cdn.tracxn.com/images/static/integrations/chromelogo.png)](https://chrome.google.com/webstore/detail/tracxn-extension/mcplkbacfdjapifgiidjidmnfilipnep?hl=en)[![Image 6: Firefox Extension](https://cdn.tracxn.com/images/static/integrations/firefoxlogo.png)](https://help.tracxn.com/en/articles/6635148-how-to-use-tracxn-s-firefox-extension)        [View All Offerings](https://w.tracxn.com/offerings) [Contact Us](https://tracxn.com/contactus)  ![Image 7: tracxn illustration](https://cdn.tracxn.com/images/static/homepage/offerings-illustration.svg)![Image 8: tracxn logo](https://cdn.tracxn.com/images/static/Tracxn_Lite_Logo_Black.svg)
Try our premium features for FREE - no threads attached![Learn More](https://w.tracxn.com/tracxnlite-learnmore)

[Get Started. It’s FREE](https://tracxn.com/signup)  
*   
Company 
    *   [About us](https://w.tracxn.com/about-us)
    *   [Our Investors](https://tracxn.com/tracxninvestors)
    *   [Media & Newsroom](https://tracxn.com/p/media)
    *   [Careers](https://w.tracxn.com/careers)
    *   [Contact Us](https://tracxn.com/contactus)

*   [Pricing](https://tracxn.com/pricing)

*   [Login](https://tracxn.com/login)
*   [Sign Up for Free](https://tracxn.com/signup)

1.   [Discover](https://tracxn.com/d)
>2.   [Companies](https://tracxn.com/d/companies)
>3.   [E2ip Technologies](https://tracxn.com/d/companies/e2ip-technologies/__mLs40pMNYcGLHvFWkGVKxjfjJLIfktqr5U7oisPRs8A)
>Funding & Investors

[![Image 9: Logo for E2ip Technologies](https://i.tracxn.com/logo/company/e2ip_Logo_d7780f5f-c5ac-4334-92c7-f50879acaf8b.png?format=webp&height=120&width=120)](https://e2ip.com/)

[E2ip Technologies - Funding & Investors](https://e2ip.com/)
===============================================

*[... truncated, 11,955 more characters]*

---

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
