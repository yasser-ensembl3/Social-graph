# Cimon Chapdelaine

## Position actuelle

**Titre** : CEO-cofounder
**Entreprise** : PhonIA.io
**Durée dans le rôle** : 4 years 10 months in role
**Durée dans l'entreprise** : 4 years 10 months in company

## Localisation & Industrie

**Localisation** : Canada
**Industrie** : Technology, Information and Internet

## Description du rôle

PhonIA offers an automated digital platform for screening and monitoring learning difficulties using artificial intelligence. By providing access to services in an accurate, fast and secure manner, PhonIA aims to help you eliminate the gap that is widening among many learners and contribute to a more inclusive society.

## Résumé

As a speech-language pathologist, public health graduate, and tech entrepreneur, I build bridges between clinical practice, research, and AI to create inclusive, human-centered innovations in health and education.

I’m the CEO and cofounder of PhonIA, a company developing assistive AI tools to support practitioners in speech-language pathology and special education. I also cofounded and co-direct Clinique MultiSens, an interdisciplinary clinic offering communication, cognition, and hearing services across the lifespan, supporting individuals and their families through inclusive, person-centered care.

With over 15 years of experience across clinical, academic, and managerial settings, I’ve cultivated a multidisciplinary skillset spanning healthcare, organizational development, project management, and innovation. I’ve refined this multidisciplinary expertise through several leading accelerators and training programs in innovation, governance, and business development.

My mission is to drive impact at scale. Using technology not to replace, but to empower professionals and expand access to vital rehabilitation and mental health services. At the heart of my work are the values of benevolence, collaboration, professionalism, progress, and innovation.

I’m also actively engaged in governance across the philanthropic, entrepreneurial, and community sectors — continuously seeking opportunities where science, care, and technology can converge to build a better future.

## Connexion

**Degré de connexion** : 1st
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAvfF9kByD2MrfJW8JJ9qE5NqTFrN_eQLaY/
**Connexions partagées** : 72


---

# Cimon Chapdelaine

## Position actuelle

**Entreprise** : PhonIA.io

## Localisation & Industrie

**Localisation** : Canada

## Connexion

**Degré de connexion** : 1st


---

# Cimon Chapdelaine

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401281866890358784 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQF8OblqhuQdYg/image-shrink_800/B4EZrafaMEKkAc-/0/1764602260103?e=1765782000&v=beta&t=KArJykkKutPeTRygvA1IHilisljmYF0qBfqHw1_vUoI | Félicitations aux récipiendaires des bourses 2025 de la Fondation TALAN 🎉 | 2 | 0 | 0 | 6d | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:30.478Z |  | 2025-12-01T15:31:46.234Z | https://www.linkedin.com/feed/update/urn:li:activity:7401278317586247682/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7400259072463183873 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEz0hZV5pdrRQ/image-shrink_800/B4EZb3nWoQHIAk-/0/1747911013902?e=1765782000&v=beta&t=Ib3_qZ-DOSl0yAWrU6kdoLsEZPLS2tSmmnyOrMMmTiM | Un exemple concret de l'impact des dons à la Fondation TALAN 👇 | 2 | 0 | 0 | 1w | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:30.478Z |  | 2025-11-28T19:47:33.040Z | https://www.linkedin.com/feed/update/urn:li:activity:7331270159946416130/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7400176216768450560 | Article |  |  | Je suis heureux de partager la publication d'un article auquel j'ai contribué dans IEEE Xplore : “AI-Powered Tutoring for Active Reading: A Pedagogical and Ethical Approach” 

Ce projet est né d’un désir profond : offrir des outils qui soutiennent l’apprentissage du langage, la réussite éducative et l’accès équitable à des ressources d’évaluation pour tous les élèves, peu importe leur contexte ou leur niveau scolaire.

Je tiens à souligner la contribution exceptionnelle de :
 ✨ Héloïse Masse, pour son expertise et son leadership
 ✨ Jihene Rezgui, Ph.D, pour l’encadrement scientifique et technique
 ✨ Les étudiant·es - chercheurs ayant participé au développement et à l’expérimentation, dont Félix Jobin et Ilian Djorf 
 ✨ Le Collège de Maisonneuve et le LRIMa - Laboratoire de Recherche Informatique Maisonneuve, pour leur soutien et leur engagement en recherche appliquée et pour l'impact de leur contribution

Merci à tous ceux et celles qui croient à l’importance d’un numérique éducatif responsable et utile.

Si ce sujet vous interpelle, j’aimerais beaucoup poursuivre la conversation !
 🔗 https://lnkd.in/eJPT-AHS

#Éducation #IAResponsable #Accessibilité #Orthophonie #TechnologieÉducative #IEEE | 9 | 0 | 2 | 1w | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:30.479Z |  | 2025-11-28T14:18:18.703Z | https://ieeexplore.ieee.org/document/11250441 |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7399182899599536128 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSJD_28_NOvg/feedshare-shrink_1280/B4EZq8s0TVGYAs-/0/1764102457056?e=1766620800&v=beta&t=1qeYtLpKcVh1pihu299NT2R5IrFPevavKYLz-nwMhOE | Nous menons actuellement une collecte de données d'entraînement pour que PhonIA.io puisse être adaptée aux besoins des orthophonistes travaillant auprès de la population de plus de 50 ans présentant un trouble de la communication 😊 

Pour participer et faire circuler dans votre entourage 👇

Voici le lien de participation : https://lnkd.in/eyPYD9V2 | 9 | 1 | 5 | 1w | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:30.481Z |  | 2025-11-25T20:31:13.435Z | https://www.linkedin.com/feed/update/urn:li:activity:7399181997610266625/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7390049467573485569 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF_yvQzDoFVww/feedshare-shrink_800/B4EZo6lf5wHgAk-/0/1761919501193?e=1766620800&v=beta&t=y9jN60kY_f4uvEktfKrhduwcBABqbs1ylqoOBwoHvpo | 🏆 Fier et reconnaissant !

Recevoir le Prix de La Vitrine MTL Connecte 2025, remis par Desjardins Caisse des Technologies, est un moment marquant pour PhonIA.io et pour toute notre équipe. 

Merci à tout le jury pour vos bons mots qui nous rappellent notre raison d'être 🤩 

Phonia est née d’une conviction : que l’intelligence artificielle et la reconnaissance vocale peuvent contribuer à un avenir plus équitable, en soutenant la santé de la communication.

Merci au Printemps numérique pour cette vitrine exceptionnelle, à Desjardins pour leur appui à l’innovation, et à notre équipe de chercheurs, cliniciens et développeurs qui font vivre cette vision chaque jour 💡

#MTLconnecte #Innovation #SantéNumérique #IAResponsable #ImpactPositif #Leadership | 47 | 15 | 3 | 1mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.246Z |  | 2025-10-31T15:38:13.549Z | https://www.linkedin.com/feed/update/urn:li:activity:7390026027445473280/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7385041013754470401 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEmTkofLmtvmw/feedshare-shrink_800/B4EZnzvhELHgAg-/0/1760730945472?e=1766620800&v=beta&t=960VURBHRHQ191rYQkPczNm1CYQMor5NaZHKDOFC2Dw | ⛵ Lever les voiles, ralentir pour mieux avancer

La tête pleine d’inspiration suivant un périple de voile sur le lac Ontario avec mon père.

Un temps d’arrêt rare, mais profondément inspirant.

Sur l’eau, chaque manœuvre demande calme, attention et adaptation.
 
On ne contrôle ni la direction, ni la force du vent, notre contrôle réside dans l’ajustement des voiles.

Cette sagesse, transmise au fil des vagues parfois plus fortes, m’a rappelé que l’entrepreneuriat repose sur les mêmes principes : anticiper sans précipiter, écouter avant d’agir et garder le cap, même quand les courants changent.
Ces moments partagés m’ont aussi rappelé la valeur du ralentissement.
 
Parce que parfois, pour aller plus loin, nous gagnons à simplement prendre le temps d’observer, d’apprendre et de respirer.

Un privilège d’avoir navigué aux côtés d’un mentor de toujours et une belle occasion de redécouvrir l’importance du calme, de la constance et de la transmission.

⚓ À la barre comme dans la vie, le leadership se mesure souvent à la façon dont on accueille le vent. | 38 | 2 | 0 | 1mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.248Z |  | 2025-10-17T19:56:25.106Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7385033077997355008 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQHmYWbU3AclQw/feedshare-shrink_800/B56Znq_jEdH8Ak-/0/1760584205391?e=1766620800&v=beta&t=I340XgSQB6Ul41o-H9eRPBdyf-aGUBbM_9C9msKShWY | WoW 🤩 

Quelle belle double reconnaissance pour tes étudiantes, tes étudiants, ton laboratoire et toi-même.

Nous sommes choyés de collaborer avec toi et ton équipe étudiante. | 11 | 0 | 1 | 1mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.249Z |  | 2025-10-17T19:24:53.074Z | https://www.linkedin.com/feed/update/urn:li:activity:7384425385138118656/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7379492611448795137 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQHGWAVHuxiDVg/image-shrink_800/B4EZmkvZ02KwAc-/0/1759405515103?e=1765782000&v=beta&t=OC7PjoC0-BoiQegB7IZo5vnmHkehMGPJNg1ZtE0YM6s | Des impacts concrets de vos dons pour la recherche 👇

Recherche de participants en cours ☺️ | 1 | 0 | 0 | 2mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.250Z |  | 2025-10-02T12:29:02.912Z | https://www.linkedin.com/feed/update/urn:li:activity:7379481590504058880/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7379186675610038273 | Article |  |  | L'importance du décodage en lecture 👇 | 7 | 0 | 2 | 2mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.250Z |  | 2025-10-01T16:13:22.124Z | https://cliniquemultisens.com/un-incontournable-de-la-comprehension-en-lecture/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7377360647367413760 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHSqM895HyERw/feedshare-shrink_800/B4EZmAprs4IoAg-/0/1758800137158?e=1766620800&v=beta&t=N61u35ZNUfS7s4pgykZ93w_Ce09tbp4_LVfja8gua_Y | Une belle occasion de soutenir une cause concrète pour les jeunes et moins jeunes présentant un trouble d'apprentissage. Joignez-vous à l'équipe de coureurs et coureuses cette année, ou encouragez par un don la Fondation TALAN et supporter des travaux de recherche concrets portant sur les Troubles d'apprentissages.

👇 | 5 | 0 | 1 | 2mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.252Z |  | 2025-09-26T15:17:23.065Z | https://www.linkedin.com/feed/update/urn:li:activity:7376942458921775105/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7354569931360739328 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHkZRCAfwzvRw/feedshare-shrink_800/B4EZgyf3O5HgAk-/0/1753193870907?e=1766620800&v=beta&t=oddvj2EdM0M9BiGlo7vcAkTf2jE5YM8sCfbLfgZOhKk | 📣 Pour tous les entrepreneurs d'impact 👇 | 5 | 0 | 0 | 4mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.255Z |  | 2025-07-25T17:55:12.938Z | https://www.linkedin.com/feed/update/urn:li:activity:7353468905496977408/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7354558053297340417 | Text |  |  | 📣 Félicitations à toute l'équipe et particulièrement au leadership scientifique de Christine Turgeon, Ph.D et de Jihene Rezgui, Ph.D 🎉 

Une collecte de données est actuellement en cours pour tout lecteur francophone du Canada 👇 

https://lnkd.in/eDWbVpgm | 22 | 10 | 2 | 4mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.256Z |  | 2025-07-25T17:08:00.987Z | https://www.linkedin.com/feed/update/urn:li:activity:7354527217105707008/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7337924819667083265 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGV5_krT44Dgg/feedshare-shrink_800/B4DZdVFsr0GgAg-/0/1749479247015?e=1766620800&v=beta&t=dJed9XCU5jSrXKErlFjnk-nwSGmwpFCtmttAUtRD_Kk | C'est avec fierté que nous allions le potentiel de l'Intelligence Artificielle à l'orthophonie pour développer de nouvelles possibilités de façon validée et responsable 👇 | 26 | 3 | 1 | 5mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.257Z |  | 2025-06-09T19:33:29.059Z | https://www.linkedin.com/feed/update/urn:li:activity:7337847807569027072/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7336966901866127360 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG9LMah4i1hHg/feedshare-shrink_800/B4EZdIke.PHgAg-/0/1749269220816?e=1766620800&v=beta&t=FNafIavOqPDg9XdCAO8qU3okYdDOMI9eSufTMQ3OKbM | 🤩 Quelle journée inspirante à ActionIA 2025 : Ensemble pour le développement et l’adoption responsable dans l’industrie ! Une superbe occasion de faire rayonner la vision de PhonIA.io.

J’ai eu le plaisir de prendre part au panel “IA et Santé” aux côtés de Tony Aubé, Imane Chafi, dans une discussion stimulante animée par Barbara Decelle. Une belle occasion d’aborder les avancées, les enjeux, mais aussi la responsabilité collective dans l’usage de l’IA en santé.

Cette journée, organisée de main de maître par l’équipe de l'Obvia et ses partenaires (Fonds de recherche du Québec, Ubisoft Montréal et le Conseil de l'innovation du Québec), a rassemblé des acteurs de tous horizons autour de la question fondamentale : comment favoriser une IA utile, éthique et responsable dans nos industries ?

Le timing ne pouvait être plus juste, au lendemain de la prise de parole marquante de Yoshua Bengio appelant à la prudence et à un ralentissement stratégique dans le développement de l’IA. Ce fut un rappel fort de la responsabilité que nous portons dans ce moment charnière de révolution technologique.

Heureux d’avoir partagé cette journée avec plusieurs personnes engagées et passionnées. Nos réflexions collectives sont précieuses.

🎉 Merci à Pierrich Plusquellec pour son animation et son appel à la contribution collective, ainsi qu'à Lesly Nzeusseu pour la coordination d'un événement de grande qualité. | 31 | 1 | 2 | 6mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.258Z |  | 2025-06-07T04:07:03.658Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7333227203532402688 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEeGf_6ClO7bA/feedshare-shrink_800/B4EZcTbR_QHcAg-/0/1748377609142?e=1766620800&v=beta&t=5H1U_t3RMIZu-PEdKcmccBUgXGWiL_gYNCljJD5ggv8 | 📣 Le 5 juin prochain, l'Obvia vous invite à Action IA, une journée visant à favoriser les collaborations entre les différents acteurs et actrices de l'écosystème industriel et les milieux académiques quant au déploiement et l'utilisation responsable de l'IA! 

📅 Jeudi, 5 juin 2025, de 8h30 à 17h00 
Ubisoft Montréal, 5480 Rue Saint-Dominique La programmation vise trois objectifs principaux : 

Illustrer le rôle complémentaire et crucial de la communauté académique dans le développement et le déploiement responsable de l'IA dans l'industrie. 

Faire rayonner des cas concrets de déploiement responsable de systèmes d'IA. 

Faciliter l'établissement de collaborations solides entre le milieu académique et les différents acteurs de l'écosystème industriel de l'IA.

🎤 En tant que panéliste invité, pour PhonIA.io, il me fera plaisir d'échanger avec vous sur l’IA dans le domaine de la Santé lors de cet événement.
 
J'ai déjà hâte de vous y voir! Pour consulter la programmation et vous inscrire 
👇 
https://bit.ly/43AxcWg | 14 | 0 | 2 | 6mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.260Z |  | 2025-05-27T20:26:50.095Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7331895565271638016 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHL9KpRFLAA3g/feedshare-shrink_800/B4EZcAgKjOHAAg-/0/1748060121986?e=1766620800&v=beta&t=bKrR1VDhx6ShiXie6a2OEX5tpMNeHPZCxYFIywEV8dw | Une bonne présence pour PhonIA.io au Symposium des innovations en première ligne organisé par le Collège québécois des médecins de famille. 

C'était inspirant de participer comme innovateur et d'assister aux présentations des autres innovateurs du réseau de la santé 🚀 Merci Dr Samuel Gareau-Lajoie pour l'animation du Panel de présentation 😊 

De superbes solutions pour traverser le mur. Des innovations pour solidifier le pilier du réseau, la Première Ligne 🦾 

Félicitations à toutes et tous les innovateurs et continuons ce travail au profit de la population 🤩 

Merci à Luc Sirois pour son habituel appel à continuer notre passion et notre dévouement pour innover et foncer. La révolution en santé passera par des acteurs du terrain mobilisés. Tes habiletés de communication donnent des ailes.

Merci aussi aux dragons et félicitations pour le lancement de l'Amplificateur en première ligne. | 48 | 11 | 4 | 6mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.261Z |  | 2025-05-24T04:15:22.793Z |  |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7325902656391032833 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQEklUy-Od2EvQ/image-shrink_800/B4EZaqZ_yxHkAc-/0/1746615664799?e=1765782000&v=beta&t=xlVvm9QMQnMCJ8oLPrGhJ-U9xhvNPxUii3PTehsJjH8 | Félicitations à toutes et tous les participants coureurs de la Fondation TALAN 👇 

L'objectif de financement pour les projets de recherche portant sur les troubles d'attention, du langage et d'apprentissage neurodéveloppementaux (TALAN) continue à battre son plein au lien suivant : https://lnkd.in/ekN-VqF4

Donnez des ailes à des projets de recherche qui impactent concrètement l'inclusion des jeunes et moins jeunes présentant un trouble d'apprentissage neurodéveloppemental. | 3 | 0 | 0 | 7mo | Post | Cimon Chapdelaine | https://www.linkedin.com/in/cimon-chapdelaine-50985056 | https://linkedin.com/in/cimon-chapdelaine-50985056 | 2025-12-08T06:20:36.265Z |  | 2025-05-07T15:21:41.973Z | https://www.linkedin.com/feed/update/urn:li:activity:7325837072009732096/ |  | 

---



---

# Cimon Chapdelaine
*PhonIA.io*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [](https://ivado.ca/en/2024/12/13/phonia-ivado-collaborating-to-transform-learning-through-ai/)
- Category: article

### [Teaching Machines to Speak Like Humans (02 — Preparing Phoneme Alignment)](https://medium.com/@eddieoffermann/teaching-machines-to-speak-like-humans-02-preparing-phoneme-alignment-5dfdf10032b0)
*2024-12-02*
- Category: blog

### [Caroline Chapdelaine Discusses Carve-Out of North Star Photonics…](https://www.how2exit.com/blog/caroline-chapdelaine-discusses-carve-out-of-north-star-photonics-on-how2exit-podcast/)
*2024-06-24*
- Category: podcast

### [What is a PLC? A Closer Look at the Programmable Logic Controller](https://blog.cimon.com/latest-articles/what-is-a-plc-a-closer-look-at-the-programmable-logic-controller)
*2023-07-13*
- Category: blog

### [Improving Spoken Language Modeling with Phoneme Classification: A Simple Fine-tuning Approach](https://cnrs.hal.science/hal-04847733/document)
*2025-11-05*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Conditions d'utilisation](https://phonia.io/terms-of-use)**
  - Source: phonia.io
  - *Sep 1, 2024 ... ... Article 4.2). 2. COMPTE D'UTILISATEUR ... Responsable de la protection des renseignements personnels : Cimon Chapdelaine, support@...*

- **[Untitled](https://www.cqmf.qc.ca/wp-content/uploads/2025/05/Livret-des-innovations.pdf)**
  - Source: cqmf.qc.ca
  - *May 16, 2025 ... cimon.chapdelaine@phonia.io · phonia.io. Page 30. MedSécure s'imbrique ... Article Médecin du Québec : Démonstration du rôle optimisé...*

---

*Generated by Founder Scraper*
