# Natalie Riviere

## Position actuelle

**Titre** : Co-Founder
**Entreprise** : Fuckup Nights Montréal
**Durée dans le rôle** : 9 years 4 months in role
**Durée dans l'entreprise** : 9 years 4 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : Think Tanks

## Description du rôle

Co-founder and host of Montréal chapter of FuckUp Nights- a global movement; research & sharing business failure with community events in 300+ cities, 90+ countries #findtheFUN
www.fuckupnights.com/montreal

## Résumé

CEO Commetta | Trilingual social business entrepreneur in #digitalmarketing supporting #corporateculture communications & having FUN with FuckUp Nights Montréal.

Through her international BCorp certified digital marketing collective, Commetta, Natalie services SMB's and entrepreneurs with the unique #ShineOnline marketing method and product line she developed to produce a marketing ROI through strategic content design, web development and brand management.

With the understanding of entrepreneurship she acquired via her green family company and studying commerce at John Molson School of Business, Natalie realized that there is often little to no practical entrepreneurship training in professional education programs. This became the inspiration for an entrepreneurial endeavor of her own; a mission to empower conscious business owners, thought leaders and social projects with the communication and exchange tools they need to share their unique offerings within the mainstream media and local economies.

As an English, French and Spanish speaking Lean LaunchPad Educator (Steve Blank, Stanford University) and altMBA graduate (Seth Godin), Natalie has taught and collaborated with institutions like the BDC, RBC, Rogers, Global Entrepreneurship Week, Dawson College Centre for Innovation & Entrepreneurship, HEC Montréal University, YES Montreal, Carrefour Jeunesse Emploi, English Montreal School Board, Lester B. Pearson School Board, among many others. 

Chosen to introduce the global event series FuckUp Nights to Montreal, Natalie builds communities around sharing professional failures encouraging authenticity, vulnerability and transparency in corporate communications cultures.

Passionate about health and nature, Natalie is also certified in her practices of Plant-Based Nutrition (Cornell University, Physicians Committee For Responsible Medicine), Yoga (500 Hour YTT), Meditation (Art of Living VTP) and Snowboarding (CASI)!

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAAJDyOcBT4YRl-GkOTYlgP32FuZW34I6wJw/
**Connexions partagées** : 86


---

# Natalie Riviere

## Position actuelle

**Entreprise** : Commetta

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Natalie Riviere

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7402094055163310082 | Document |  |  | La boule d'émotion que je ressentais dans la gorge pendant l'introduction du 9ème anniversaire m'a fait perdre la voix, mais comme on le sait bien en #affaires et en #entrepreneuriat, "the show must go on,” et quel bel événement!

En effet, ce mouvement global renforce la valeur de la #vulnérabilité, les imperfections et les défis des fois imprévus que la vie nous envoie surtout quand on se lance avec ambition et passion envers nos missions #professionnelles. 

Nous partageons nos #échecs et nous célébrons la #résilience, la transparence et l'authenticité dans la culture corporative, et mets-en que c'est le FUN!

🎉 9 ans…
- de générosité incroyable de la part de nos partenaires et intervenants.
- de communauté hors pair ou le réseautage devient rapidement la socialisation et renforce notre humanité et pouvoir collectif.
- de bénévolat et d'amitiés précieuses avec mes collaborateurs (surtout Marie Labbé, Sabrina Belval ✅ et Isabelle Kolish-Dufresne, CPHR).
- de créer des connexions entre professionnels ayant des impacts illimités!

Merci infiniment pour votre confiance, vos contributions, votre soutien et votre participation, je n'aurais jamais pu imaginer que cette initiative cofondée en 2016 avec Louis-Felix Binette, Josh Miller, CPA et Vanessa Mueggler aurait évolué autant. 🖤 

J'ai hâte de voir ce que 2026 nous réserve pour compléter une décennie de FUN! Longue vie Fuckup Nights Montréal! Viva Fuckup Nights! | 13 | 3 | 0 | 4d | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:03.949Z |  | 2025-12-03T21:19:07.008Z | https://www.linkedin.com/feed/update/urn:li:activity:7401281432259706880/ |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7399832778978009088 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQF90q-gnekgIg/image-shrink_800/B4EZrF35IVGYAc-/0/1764256355870?e=1765778400&v=beta&t=mkqI6ajwuIEInT3WdkWfBeA_f8zI5ZgXMN-AEG8Y_5Y | SPOILER ALERT: we'll have a blue #Habs cap signed by Lane #Hutson, and red and blue one signed by Juraj #Slafkovský!

All proceeds going to the Fondation des Canadiens pour l'enfance, join Fuckup Nights Montréal in celebration of our 9th anniversary sharing #business failure Fuckup Nights style TONIGHT: | 5 | 1 | 0 | 1w | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:03.950Z |  | 2025-11-27T15:33:36.753Z | https://www.linkedin.com/feed/update/urn:li:activity:7399827694600863745/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7399078075767889921 | Text |  |  | Last chance for our #community FUN in 2025! Join Fuckup Nights Montréal this Thursday as we close the year with a #fundraising edition in support of Fondation des Canadiens pour l'enfance. 

The price of your ticket includes a $10 donation and a tasty menu selection from La Belle et La Boeuf. We'll be raffling signed hats by the #Habs and a special edition bottle of Dirty Devil Vodka signed by Martin Brodeur! 

Generous speakers Maude Belval 🤓, Laura Blom and Francois Tremblay will be helping us foster a growth #mindset as we set intentions for 2026. Let's celebrate resilience in #business and #ShareTheFailure for a good cause, Fuckup Nights style: https://lnkd.in/erThRxXq | 4 | 0 | 0 | 1w | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:03.951Z |  | 2025-11-25T13:34:41.486Z | https://www.linkedin.com/feed/update/urn:li:activity:7389312900550672384/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7396269982134718464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEzuM9JBZSgbw/feedshare-shrink_800/B4EZqTUWSBJ0Ag-/0/1763408177868?e=1766620800&v=beta&t=83t0OFDUJOH-DczzTpB9spEBlSC6kUi-6AmT866RgXM | Scores! Grateful beyond measure for the quality moments and quantity of loving and supportive messages turning 44 brought in last week! Mil gracias, merci beaucoup, thank you sincerely for your time and kind wishes.

I'll be celebrating #resilience, building #community and paying it forward Thursday the 27th at Fuckup Nights Montréal 's 9th anniversary event in partnership with La Belle et La Boeuf Ave. des Canadiens and Dirty Devil Vodka where we're fundraising for the Fondation des Canadiens pour l'enfance that helps kids around #Montreal develop their #leadership skills and believe in miracles through hockey. 

I'd love to see you there and cheers to another bright year together, join the FUN: https://lnkd.in/erThRxXq | 49 | 3 | 1 | 2w | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:03.952Z |  | 2025-11-17T19:36:19.792Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7389681434363588608 | Article |  |  | Quelle communauté d'impact, j'ai hâte! Rejoignez-nous pour lancer le premier BLD Québec (B Corp Leadership Development) avec B Local Québec le 12 novembre prochain chez GI Quo Vadis inc.! | 6 | 1 | 0 | 1mo | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.967Z |  | 2025-10-30T15:15:47.594Z | https://www.zeffy.com/fr-CA/ticketing/bld-quebec--2025 |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7388632863723876352 | Video (LinkedIn Source) | blob:https://www.linkedin.com/5d4080fc-45f2-4133-a250-640721a4ef17 | https://media.licdn.com/dms/image/v2/D4E05AQGkLzU2PNqkWA/videocover-high/B4EZoTn8WZKcBI-/0/1761265835300?e=1765778400&v=beta&t=dTumtBNwqHVgYjyMCgHgYyPlkacWuIUfQJ9ya_Pzrww | Almost 9 years in and it blows my mind that every month Fuckup Nights Montréalconsistently normalizes communications around #failure in #business with at least half of the audience of professionals joining for the first time, including local rockstars like journalist Paris Mansouri!

Having already participated at Fuckup Nights in other cities, it was truly an honor to welcome you home to our impactful #community conversation with District 3 Innovation and Montréal InVivo at Ax-C. Thank you for taking the time to #ShareTheFailure with Commetta and I this way, hasta pronto con placer! | 25 | 2 | 1 | 1mo | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.969Z |  | 2025-10-27T17:49:08.872Z | https://www.linkedin.com/feed/update/urn:li:activity:7387284401686073344/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7386093689674178560 | Image |  | https://media.licdn.com/dms/image/v2/D4E10AQGubN8spKHRQQ/image-shrink_800/B4EZoBv4d5IUAc-/0/1760965922391?e=1765778400&v=beta&t=m_DF2YeuJ6ygrBAM0lDkwbOrkZpvqZaQOSy-bmRZOmM | Lots of FUN in the forecast this week when Fuckup Nights Montréal reunites with District 3 Innovation of Concordia University Wednesday at Ax-C! Let's #ShareTheFailure: | 10 | 0 | 0 | 1mo | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.970Z |  | 2025-10-20T17:39:22.603Z | https://www.linkedin.com/feed/update/urn:li:activity:7386026420671557632/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7373485759812509696 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQF3TWeQOCsT7A/feedshare-shrink_800/B56Zji07n4HkAw-/0/1756152184418?e=1766620800&v=beta&t=nWYijqTMmQIOOXltqFU9byE0dgCK6g3HciIZnU9Cq0o | Vive la rentrée avec Fuckup Nights Montréal et École des entrepreneurs du Québec !

Venez découvrir leurs nouveaux lieux aux Ax-C espace d'entrepreneuriat innovant, l'ambiance parfaite pour reprendre nos conversations publiques d'échecs professionnels style Fuckup Nights. 

Rejoignez-nous et nos partenaires Le Parachute et 4 ORIGINES ce jeudi dès 17h30, il ne reste que 10 billets! | 13 | 3 | 0 | 2mo | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.973Z |  | 2025-09-15T22:39:57.880Z | https://www.linkedin.com/feed/update/urn:li:activity:7371154164963450880/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7330733216250712064 | Article |  |  | Décompte # 1 - DEMAIN au #CocktailDesGénérations goûtez au délices et bouchées inspirées par les chefs vedettes de la première capsule de la série “Si jeunesse savait,” #SoeurAngèle et #JeanPhilippeCloutier!

Continuez ces conversations #intergénérationnelles et aidez-nous à briser la solitude des #aînés au #Québec avec nos autres invités Élise Tastet, Robert Dutton, Catherine Fournier, Louise Harel, les membres du comité Briseurs de solitude et la fondation Les Petits Frères dès 17h à New City Gas!

Profitez d'un rabais exclusif avec le code FPF250.

Plus d'informations: https://lnkd.in/eGHK_2jw
https://lnkd.in/g9VsUKxb | 6 | 1 | 1 | 6mo | Post | Natalie Riviere | https://www.linkedin.com/in/natalieriviere | https://linkedin.com/in/natalieriviere | 2025-12-08T05:24:08.985Z |  | 2025-05-20T23:16:37.191Z | https://youtu.be/R-rowOIG6kI?si=gd5pCmn0nPS6J4y4 |  | 

---



---

# Natalie Riviere
*Commetta*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 14 |

---

## 📚 Articles & Blog Posts

### [Natalie Riviere & Commetta: Reinventing Marketing for the Betterment of Business](https://whc.ca/blog/natalie-riviere-commetta-reinventing-marketing-for-the-betterment-of-usiness)
*2019-04-10*
- Category: blog

### [Episode 22 : Shining by Helping Others Shine](https://www.growthstory.ca/episode-22-natalie-riviere-commetta-fun-nights-montreal/)
*2018-03-08*
- Category: article

### [Growth Story Podcast – Shining by Helping Others Shine – Commetta](https://commetta.com/growth-story-shining-by-helping-others-shine/)
*2019-08-27*
- Category: article

### [Events for Women Leaders by Nurture (she/her) – Commetta](https://commetta.com/nurture-she-her-summer-2020/)
*2020-07-07*
- Category: article

### [About Commetta Collective – Commetta](https://commetta.com/about/)
*2025-01-01*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Isolation Breakers – A committee fighting isolation](https://littlebrothers.ca/isolation-breakers/)**
  - Source: littlebrothers.ca
  - *Dive into inspiring discussions with Karl Tremblay, host of this podcast series presented by the Isolation Breakers committee. ... Natalie Riviere, CE...*

- **[Commetta Communications - Meet Natalie Riviere - YouTube](https://www.youtube.com/watch?v=QgnIXDQUId4)**
  - Source: youtube.com
  - *Sep 4, 2022 ... Commetta Communications - Meet Natalie Riviere. 70 views · 3 years ... BNS Podcast New 210 views · 20:05. Go to channel · 20 Years Lat...*

- **[DigiMarCon Canada West (Apr 2026), Vancouver Canada - Trade ...](https://10times.com/e1d1-0r2g-5ssh-s)**
  - Source: 10times.com
  - *Natalie Riviere. CEO Commetta Co... 1 Event. Jarrett Sherman ... Podcast Marketi... Salted Stone. Experiential Ma... Search ......*

- **[Josh Miller (He/Him) – Commetta](https://commetta.com/collective/josh/)**
  - Source: commetta.com
  - *... Commetta executive team. Tap to unmute. Your browser can't play this video ... Natalie Riviere (She/Her) · Joanne Wiseman (She/Her) · MJ Serna (Th...*

- **[Talk about your failures in public, say 'Fuckup Nights' founders ...](https://commetta.com/talk-about-your-failures-in-public-say-fuckup-nights-founders/)**
  - Source: commetta.com
  - *Nov 11, 2019 ... Montreal chapter co-founder Natalie Riviere, a digital marketing specialist and head of Commetta Communications, believes modern ......*

- **[Commetta – #ShineOnline Marketing](https://commetta.com/)**
  - Source: commetta.com
  - *- Natalie Riviere, CEO. MEET COMMETTA. “If you're not using business as a force for good, what is it good for?” - Natalie Riviere, CEO & Founder. Cert...*

- **[Natalie Riviere & Commetta: Reinventing Marketing for the ...](https://whc.ca/blog/natalie-riviere-commetta-reinventing-marketing-for-the-betterment-of-usiness)**
  - Source: whc.ca
  - *Apr 10, 2019 ... Natalie Riviere & Commetta: Reinventing Marketing for the Betterment of Business · Hi Natalie, thanks for taking the time to talk to ...*

- **[About – Commetta](https://new.commetta.com/about/)**
  - Source: new.commetta.com
  - *Metta Blog. 4/9 NEW ECONOMY – SriSri University Monograph 2019. LEADING A DIGITAL ERA January 2019 By Natalie Riviere, CEO, Commetta Communications. N...*

- **[TE #WalkRadio – Justin Kingsley of Maku Maku. – Commetta](https://commetta.com/walkradio-justin-kingsley-of-maku-maku/)**
  - Source: commetta.com
  - *View Complete Article. More Press. 3/9 BARTER X 7 BILLION. LEADING A DIGITAL ERA January 2019 By Natalie Riviere, CEO, Commetta Communications. BARTER...*

- **[Today's Entrepreneur Radio – Petros Taverna – Commetta](https://commetta.com/todays-entrepreneur-petros-taverna/)**
  - Source: commetta.com
  - *Sep 20, 2019 ... View Complete Article. More Press. 4/9 NEW ECONOMY. LEADING A DIGITAL ERA January 2019 By Natalie Riviere, CEO, Commetta Communicatio...*

---

*Generated by Founder Scraper*
