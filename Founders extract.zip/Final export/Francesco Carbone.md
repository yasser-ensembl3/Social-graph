# Francesco Carbone

## Position actuelle

**Titre** : Founder & CEO
**Entreprise** : Logiciel Munity Inc
**Durée dans le rôle** : 2 years 8 months in role
**Durée dans l'entreprise** : 2 years 8 months in company

## Localisation & Industrie

**Localisation** : Kirkland, Quebec, Canada
**Industrie** : Blockchain Services

## Résumé

Creating value through purpose with community.

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAEIrhwgBmwNsAyZijMawMKuv_IO9IyjXsvw/
**Connexions partagées** : 3


---

# Francesco Carbone

## Position actuelle

**Entreprise** : Munity

## Localisation & Industrie

**Localisation** : Kirkland, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Francesco Carbone

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7387583042241929216 | Text |  |  | Its about value exchange not extraction. People have needs and groups have dynamics. Should a good leader make a good follower? | 3 | 0 | 0 | 1mo | Post | Francesco Carbone | https://www.linkedin.com/in/francesco-carbone-32095326b | https://linkedin.com/in/francesco-carbone-32095326b | 2025-12-08T06:16:03.913Z |  | 2025-10-24T20:17:31.926Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7384631031011758080 | Text |  |  | Lets bring back brand loyalty, the priority should be generating value for users - not extracing | 8 | 1 | 0 | 1mo | Post | Francesco Carbone | https://www.linkedin.com/in/francesco-carbone-32095326b | https://linkedin.com/in/francesco-carbone-32095326b | 2025-12-08T06:16:03.914Z |  | 2025-10-16T16:47:17.603Z |  |  | 

---



---

# Francesco Carbone
*Munity*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 15 |

---

## 📚 Articles & Blog Posts

### [Francesco Enrico Carbone](https://carbone.coach/)
*2024-01-01*
- Category: article

### [The inventor of the 15 minute city](https://www.frontiere.polimi.it/the-inventor-of-the-15-minute-city/?lang=en)
*2023-12-04*
- Category: article

### [In the media | Research and innovation](https://www.uottawa.ca/research-innovation/positive-energy/media)
- Category: article

### [News – CASCA](https://cas-sca.ca/en/news/)
- Category: article

### [Interviews with Outstanding Authors (2022)](https://tlcr.amegroups.org/post/view/interviews-with-outstanding-authors-2022)
*2022-07-21*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[Full text of "Leading Americans of Italian descent in Massachusetts"](https://archive.org/stream/leadingamericans00carl/leadingamericans00carl_djvu.txt)**
  - Source: archive.org
  - *... munity. Res.: 101 Bosworth, St., West Springfield. BOSSI, ROMEO E. — Partner ... Son of Francesco Carbone and Rosa Porcella. Graduated from Englis...*

- **[Digital Seascapes: Can we use digital technologies to engage ...](https://pearl.plymouth.ac.uk/context/ada-research/article/1585/viewcontent/INCLUSIVE_CITIES_I_Part_Parallel_Workshop_002_.pdf)**
  - Source: pearl.plymouth.ac.uk
  - *Jan 1, 2024 ... ... Francesco Carbone, Maria Venditti. 528 Community validation in ... munity life, a place of exchange and conquest, of markets and ....*

- **[urbanistica](https://arts.units.it/retrieve/handle/11368/2976604/348429/Copertina_indice_sessione1.pdf)**
  - Source: arts.units.it
  - *Oct 17, 2020 ... munity and proximity services, electing the par- ish heritage as ... Francesco Carbone e Alfredo Chiariotti. Il diritto a prendersi c...*

- **[Naples and Napoleon: southern Italy and the European revolutions ...](https://dokumen.pub/naples-and-napoleon-southern-italy-and-the-european-revolutions-1780-1860-9780198207559-9780199552306.html)**
  - Source: dokumen.pub
  - *munity had brought against the 'past and present Possessors of the town of ... Francesco Carbone and his wife in the nearby town of Castalbottaccio....*

- **[(PDF) La Città come scuola. Outdoor Education: effetti della ...](https://www.academia.edu/98505431/La_Citt%C3%A0_come_scuola_Outdoor_Education_effetti_della_pandemia_sull_infanzia_e_possibilit%C3%A0_di_rigenerazione_urbana)**
  - Source: academia.edu
  - *What kind of society and what kind of com- munity are we imagining and ... Francesco Carbone e Alfredo Chiariotti sostenibile Il diritto a prendersi ....*

- **[Introduction To Forestry and Natural Resources: Second Edition ...](https://www.scribd.com/document/642075022/Untitled)**
  - Source: scribd.com
  - *... Francesco Carbone, Federica Alisciani, Olga future? 16 forestry and natural ... munity forestry program (Proyecto Fortalecimiento 4900 ft) and up ...*

- **[Untitled](https://link.springer.com/content/pdf/10.1007/978-3-540-76298-0.pdf)**
  - Source: link.springer.com
  - *... Francesco Carbone. Charalambos Charalambous. Peter Clark. Vasa Curcin. Alfredo ... munity to reap the benefits of the future Semantic Web research...*

- **[Evaluating lossy data compression on climate simulation data within ...](https://d-nb.info/1143532767/34)**
  - Source: d-nb.info
  - *Dec 7, 2016 ... munity Atmosphere Model version 5). Historical forcing is used for the period 1920–2005 and RCP8.5 radiative forcing. (i.e., forcing t...*

- **[SOP-Bench: Complex Industrial SOPs for Evaluating LLM Agents](https://arxiv.org/pdf/2506.08119)**
  - Source: arxiv.org
  - *Jun 9, 2025 ... Francesco Carbone. Applied AI, Amazon ... We invite the com- munity to extend SOP-Bench by contributing the SOPs from their own indust...*

- **[HOUSE OF REPRESENTATIVES](https://www.congress.gov/87/crecb/1962/08/08/GPO-CRECB-1962-pt12-3.pdf)**
  - Source: congress.gov
  - *... munity. I believe it high time that the. Congress take affirmative and ... Francesco Carbone;. H.R. 4628. An act for the .relief of Fotios. Sakela...*

---

*Generated by Founder Scraper*
