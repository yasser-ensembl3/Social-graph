# Gaspar Billerault

## Position actuelle

**Titre** : Founder
**Entreprise** : CallistoAI
**Durée dans le rôle** : 1 year 6 months in role
**Durée dans l'entreprise** : 1 year 6 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT System Custom Software Development

## Résumé

cs @ mcgill, mastery, callistoai

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAADp_KOEBQ2IFovGcmzIdFu2LsGip8cbV5yI/
**Connexions partagées** : 12


---

# Gaspar Billerault

## Position actuelle

**Entreprise** : Callisto AI

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Gaspar Billerault

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7393027683535818752 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4D05AQHerjq2lKrxoQ/mp4-720p-30fp-crf28/B4DZplPYs8KUBw-/0/1762635150360?e=1765785600&v=beta&t=9Uf4JilJm3Qq5fEBpBiyYscDs64URd_8n8vKBL6pJ14 | https://media.licdn.com/dms/image/v2/D4D05AQHerjq2lKrxoQ/videocover-high/B4DZplPYs8KUCI-/0/1762635144230?e=1765785600&v=beta&t=fmnGQb-hw2bcVveVlhbX6dB2j8T6AI4OuQ363DVvWhk | plumbers aren’t losing leads because of bad service.

they’re losing them because no one replies fast enough.

so we fixed that.

this system handles:
 – missed calls → booked jobs
 – urgent requests → routed instantly
 – calendar syncs, confirmations, GPS alerts
 – post-job photos → turned into reports
 – reviews, rebooking, and retention

no apps. no chasing. no admin.

just AI filling the schedule, while the team is out fixing pipes.

if you work with trades or build tools for them, this is worth seeing.

comment “automation” and I’ll send the breakdown. | 18 | 0 | 2 | 4w | Post | Gaspar Billerault | https://www.linkedin.com/in/billerault | https://linkedin.com/in/billerault | 2025-12-08T07:10:09.053Z |  | 2025-11-08T20:52:35.567Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7379902030393294848 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2e0b93c4-9675-4ddb-ba27-46fca02eb22a | https://media.licdn.com/dms/image/v2/D4D05AQFENNZyD56_zg/videocover-high/B4DZmqtsXQJUCA-/0/1759505744286?e=1765785600&v=beta&t=plCYT9o6L47o5SicMnfoSsRoOEN1Uv9bk1a1aZO_LVc | dentists are losing time (and money) on things they shouldn’t be touching.

So we built this for them.

It handles:
 – Confirming bookings + collecting health history
 – Pre-visit reminders + dentist prep
 – On-site check-in
 – Post-visit follow-ups
 – Feedback, reviews, and reactivation

No apps. No extra staff. Just AI doing the repetitive work, so the team can focus on what matters: care.

If you run a clinic, or build for them, this type of system is a game-changer.

Curious how it works? Comment “Automation” and we'll give you the full breakdown. | 18 | 3 | 4 | 2mo | Post | Gaspar Billerault | https://www.linkedin.com/in/billerault | https://linkedin.com/in/billerault | 2025-12-08T07:10:09.054Z |  | 2025-10-03T15:35:55.995Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7346184455629279232 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQHf2bdb9ZiA9A/feedshare-shrink_2048_1536/B4DZfLj01gHkA4-/0/1751466859056?e=1766620800&v=beta&t=YFJPFcNgvE0uLwUTfEESeytGIllMtlVi1C0VNCudyaI | we just launched mastery 🚀

after months of testing, building, rebuilding, and overthinking everything, it’s finally live.

mastery is a platform for action sports athletes to connect with top coaches.
designed for progression, built with purpose.

we’re starting with mountain biking (where justin has 200k followers), 
but this is only the beginning.

webapp’s live. creators are onboarding. users are rolling in.
now it’s just about making it better every single week.

super proud of the team.
super hungry for what’s next.

🔗 mastery.to | 36 | 1 | 0 | 5mo | Post | Gaspar Billerault | https://www.linkedin.com/in/billerault | https://linkedin.com/in/billerault | 2025-12-08T07:10:09.054Z |  | 2025-07-02T14:34:19.729Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7332737299459346432 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b314ace9-735e-4cca-9d09-9df2beda44a3 | https://media.licdn.com/dms/image/v2/D4D05AQFMy9o18sB6yQ/videocover-high/B4DZcKX2gGGcBo-/0/1748225727205?e=1765785600&v=beta&t=piCoioEcoYrVQLDhuVItyA_CI_6aOoCxoyizVclvLI8 | This is how smart restaurants automate everything.

From taking orders to confirming bookings, even handling delivery notifications, it’s all done without lifting a finger.

We built a complete AI system that:

 ✅ Takes orders 24/7
 ✅ Sends tickets directly to the kitchen
 ✅ Manages reservations in real-time
 ✅ Answers FAQs automatically
 ✅ Follows up with customers post-meal

📉 Less time on operations.
📈 More time growing the business.

Curious how this could work for your restaurant (or your client’s)?
Comment "automation" or DM me. | 22 | 6 | 1 | 6mo | Post | Gaspar Billerault | https://www.linkedin.com/in/billerault | https://linkedin.com/in/billerault | 2025-12-08T07:10:09.056Z |  | 2025-05-26T12:00:07.862Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7297504230062358528 | Image |  | https://media.licdn.com/dms/image/v2/D4D22AQGw9wBig2h2SQ/feedshare-shrink_800/B4DZUXxbKCGcAk-/0/1739860588439?e=1766620800&v=beta&t=wN3WlPgm0cnYwxsLmQ0Zkle46PfJoXqcL6OrjMCCbiw | computer science job market in 2025… | 33 | 4 | 0 | 9mo | Post | Gaspar Billerault | https://www.linkedin.com/in/billerault | https://linkedin.com/in/billerault | 2025-12-08T07:10:11.094Z |  | 2025-02-18T06:36:29.519Z |  |  | 

---



---

# Gaspar Billerault
*Callisto AI*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Callisto AI | LinkedIn](https://ca.linkedin.com/company/callistoai)
*2025-05-26*
- Category: article

### [Conversational AI using llm - Callin](https://callin.io/conversational-ai-using-llm/)
*2025-03-04*
- Category: article

### [Callisto Team's Ask Me Anything on 28/07/2022 | Callisto Network](https://docs.callisto.network/community/callisto-amas/callisto-teams-ask-me-anything-on-28-07-2022)
*2022-09-03*
- Category: article

### [Origins of the Callisto Network - Dexaran - Medium](https://dexaran820.medium.com/origins-of-the-callisto-network-5785a40d2817)
*2021-12-31*
- Category: blog

### [Microsoft and DOJ seized the attack infrastructure used by Russia-linked Callisto Group](https://securityaffairs.com/169338/apt/microsoft-and-doj-seized-100-domains-used-by-russia-callisto-group.html)
*2024-10-04*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
