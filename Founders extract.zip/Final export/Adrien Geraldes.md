# Adrien Geraldes

## Position actuelle

**Titre** : Co-fondateur
**Entreprise** : IntellX Inc
**Durée dans le rôle** : 9 months in role
**Durée dans l'entreprise** : 9 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada
**Industrie** : IT Services and IT Consulting

## Résumé

Passionné par les nouvelles technologies et les plus anciennes aussi :-)

## Connexion

**Degré de connexion** : 3rd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAAA0Dc-UBHc4gDeZDRWHsG4vsEDqX8GbIpTU/


---

# Adrien Geraldes

## Position actuelle

**Entreprise** : IntellX Inc

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 3rd


---

# Adrien Geraldes

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7398978782138675200 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEFAJw5EbPB3A/feedshare-shrink_800/B4EZq4xMo.HoAk-/0/1764036496428?e=1766620800&v=beta&t=rNa-4uX1XLeQW5ckR5OminNh_DjMfP2yxo4JXnsN3L4 | ⚡ A clear, reliable, and instant Sage X3 answer.

This isn’t a promise.
 It’s a real-time test.

📧 Send any Sage X3 question to: x3@intellx.chat
⏱️ The AI replies. You judge.

And after that?
 👉 Try it again directly on the platform.
 A free trial period is available for all new sign-ups.

#SageX3 #IntellX #AI #ChatX3 #ERP #IA | 8 | 0 | 0 | 1w | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:54.662Z |  | 2025-11-25T07:00:08.040Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7398723183018725377 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQElZC5RBuLCaA/feedshare-shrink_800/B4EZqnWBhMGcAg-/0/1763744160453?e=1766620800&v=beta&t=xmzCNusMz92Bak2mMol5UQ9NZxkWxl-dgn1KEl0dA5w | Don't miss this opportunity.

Subscribe to our page IntellX Inc to learn about the latest news and new features of our ChatX3. | 2 | 0 | 0 | 1w | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:54.663Z |  | 2025-11-24T14:04:28.461Z | https://www.linkedin.com/feed/update/urn:li:activity:7397679193683300353/ |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7396467677373886464 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGnqz9EEhSyaQ/feedshare-shrink_800/B4EZqTvJVUGUAk-/0/1763415201706?e=1766620800&v=beta&t=ikPRTT8cosHgXDCM25sHle6C0zXjG6gWIjGjbyAwvoE | Nothing is more rewarding than our clients' success. A huge thank you to Annick Sakoua. It’s a pleasure moving forward together! 🤝 | 4 | 0 | 0 | 2w | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:54.663Z |  | 2025-11-18T08:41:54.010Z | https://www.linkedin.com/feed/update/urn:li:activity:7396464723556216832/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7392215285430177792 | Video (LinkedIn Source) | blob:https://www.linkedin.com/2c07115c-4d68-4256-9701-bc6d6ec5911a | https://media.licdn.com/dms/image/v2/D4E05AQF2wEqiHZnkOA/feedshare-thumbnail_720_1280/B4EZpZsj2qIwA4-/0/1762441445171?e=1765785600&v=beta&t=JhAANZeEf5Wk2cF9roMDL4kHCHG7oz-QGIkzT8XUUrU | 🚀 No need to reinvent the wheel! ChatX3 allows you to share your Sage X3 code library with your team.

Every Sage X3 expert has their "secret sauce" – those go-to functions, specific libraries, or ingenious snippets developed over time. For Laurent Verde, our co-founder, he's built an impressive library of custom functions he reuses constantly. 

And while it's brilliant, we always asked: how do we share this goldmine effectively across the entire team?

More examples on our YouTube channel and the RAG playlist 👇 

#SageX3 #IA #ChatX3 #IntellX #ERP | 23 | 3 | 0 | 1mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.265Z |  | 2025-11-06T15:04:24.765Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7391738550674833408 | Video (LinkedIn Source) | blob:https://www.linkedin.com/a7d259bc-5655-4161-b318-a29f8966a34f | https://media.licdn.com/dms/image/v2/D4E05AQHt8YiV4gOj5A/feedshare-thumbnail_720_1280/B4EZpRE6v3GYA4-/0/1762296835418?e=1765785600&v=beta&t=FlZ8Kd5RPEqgVcc_cmK7SL0fI310Zig5CN1LZNETUtI | 🚀 My New SQL Wingman: ChatX3 is Revolutionizing My Workflow!
▶️ Want to see it work? Video Demo ! 👇

As a Sage X3 expert, crafting complex SQL queries is a daily routine. And let's be honest, even if we enjoy it, it's a significant time sink! 😅

I used to dive straight into writing my queries from scratch. But that was before ChatX3! 💡

Now, I have a powerful new partner: ChatX3's SQL Agent.
I simply describe what I need, and it doesn't just write the query. It goes a step further: it tests the SQL code by executing it, ensuring it runs correctly and provides a preliminary result.

This means I receive a validated query with an initial output, ready for review and fine-tuning, not just raw code.

This saves me a tremendous amount of time on initial setup and debugging, allowing me to focus on optimization and final validation rather than boilerplate code and syntax errors.

Less time hunting for the right table or join, more time on actual analysis and impactful work!

A true game-changer for productivity.

What are your go-to tips and tricks for speeding up query writing? 👇
#SageX3 #SQL #AI #ChatX3 #IntellX | 19 | 5 | 2 | 1mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.266Z |  | 2025-11-05T07:30:02.342Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7390043469198815233 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHj8kPO2m97dQ/feedshare-shrink_2048_1536/B4EZo6cFufGUA4-/0/1761917033895?e=1766620800&v=beta&t=D_nFHP1d0d_OK1PIuzhYsLEzuI-zkuKK7skG1zpd7LM | 🧩 You can’t remember how to set a counter value in Sage X3.

You open the help document… search… nothing clear.
Then you ask a colleague, they’re busy. Hours pass.

💡 What if the answer appeared right when you needed it?
#ChatX3 finds the right procedure instantly not from a generic database,
 but from your own Sage X3 setup and rules.
It explains the steps, shows the path and the link (direct to your environement syracuse-main/html/main.html?url=/trans/x3/erp//$sessions?f=MODCPT), and saves the day.

No endless searches. No lost time. Just help that fits your #ERP.
That's what Laurent Verde and I Adrien Geraldes are doing to help us. Soon available to everyone.

⚙️ The first version of ChatX3 will be launched on Monday.

Comment “X3” if you want to see how it works 👇
#SageX3 #ERP #AI #ChatX3 | 47 | 21 | 0 | 1mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.269Z |  | 2025-10-31T15:14:23.425Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7389659085589192704 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGaiHGmtU2JfA/feedshare-shrink_800/B4EZo045SYHgAk-/0/1761823921743?e=1766620800&v=beta&t=nCCoBv7xmVXeEn6EsPIGI1cSVDui8mkod_4UXGwkHE0 | 🧠 Imaginez pouvoir parler à un expert Sage X3 quand vous voulez.

Avec Laurent Verde, on travaille depuis des mois sur un projet un peu fou : essayer de créer notre 'jumeau' agentique IA.

🎯Ce rêve est né d’une frustration simple :  Ne pas pouvoir répondre à toutes les demandes, consultations ou projets qu’on nous propose.

💡 Une IA qui comprend Sage X3 comme un consultant, mais qui répond comme un collègue.

🚀 La version 1 de notre #ChatX3 sera accessible dès lundi.

Pour les plus curieux, commentez simplement “X3” 👇
#SageX3 #ERP #ChatX3 #IA | 70 | 49 | 3 | 1mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.271Z |  | 2025-10-30T13:46:59.231Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7295464724660404224 | Text |  |  | Je vous partage cette superbe opportunité pour réaliser des projets passionnants avec nous👍 | 15 | 0 | 4 | 9mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.272Z |  | 2025-02-12T15:32:13.539Z |  | https://www.linkedin.com/jobs/view/4150460255/ | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7272365112521330688 | Text |  |  | Check out this job at EC SOLUTIONS INC: Conseiller en implantation ERP – Manufacturier | 10 | 0 | 1 | 11mo | Post | Adrien Geraldes | https://www.linkedin.com/in/adrien-geraldes | https://linkedin.com/in/adrien-geraldes | 2025-12-08T07:00:58.273Z |  | 2024-12-10T21:42:36.835Z |  | https://www.linkedin.com/jobs/view/4039841259/ | 

---



---

# Adrien Geraldes
*IntellX Inc*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 0 |

---

## 📚 Articles & Blog Posts

### [Making the Move to SaaS in Financial Services - with Adrien Gabeur of Sinequa - Emerj Artificial Intelligence Research](https://emerj.com/making-the-move-to-saas-in-financial-services-adrien-gabeur-sinequa/)
*2024-09-09*
- Category: article

### [Nexad and Intellibright Announce Strategic Partnership to Pioneer AI-Native Advertising Solutions](https://journalofcyberpolicy.com/nexad-and-intellibright-announce-strategic-partnership-to-pioneer-ai-native-advertising-solutions/)
*2025-04-16*
- Category: article

### [Ignite VC: The Future of Startup Liquidity and Late-Stage Investing with Adrien Gautier | #131](https://insights.teamignite.ventures/p/ignite-vc-the-future-of-startup-liquidity)
*2025-02-06*
- Category: article

### [AI for Drug Development and Portfolio Management - with Leaders from Intelligencia AI and Novartis - Emerj Artificial Intelligence Research](https://emerj.com/ai-for-drug-development-and-portfolio-management-with-leaders-from-intelligencia-ai-and-novartis/)
*2025-06-12*
- Category: article

### [FMD Explained: A Guide to Pharma Serialization & Barcodes](https://intuitionlabs.ai/pdfs/fmd-explained-a-guide-to-pharma-serialization-barcodes.pdf)
*2025-11-24*
- Category: article

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

*No press mentions found*

---

*Generated by Founder Scraper*
