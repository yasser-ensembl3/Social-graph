# Maurine Fauvert

## Position actuelle

**Titre** : Fondateur
**Entreprise** : Créative connect mtl
**Durée dans le rôle** : 7 months in role
**Durée dans l'entreprise** : 7 months in company

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Description du rôle

Pilote la vision, la stratégie et la production de Créative Connect, une organisation à but non lucratif dédiée à la mise en valeur des talents en VFX, animation, jeux vidéo et expériences immersives.

## Résumé

🌟 Co-Founder & Innovator in Visual Experiences at Hoplite VFX 🌟

I’m passionate about storytelling through animation and visual effects. As a co-founder of Hoplite Studio, I lead our talented team in creating immersive visual experiences that bring creative visions to life.

✨ What I Do:

Oversee artistic and technical projects, ensuring top-notch production quality.

Collaborate with clients to transform their ideas into unique visual content.

Explore new technologies and techniques in VFX to push creative boundaries.

🌐 I’m also the founder of Creative Connect, a nonprofit initiative that builds bridges across the digital creation industry. From casual networking events to ADAPT, our international VFX/Animation/Game conference in Montréal, we bring together passionate creators to celebrate, connect, and inspire.

📩 Let’s connect to discuss exciting projects and collaborations in the digital creation space!
Contact me : 
hoplitevfx@gmail.com
maurinef.hoplitestudio@gmail.com
creativeconnectmtl@gmail.com

## Connexion

**Degré de connexion** : 2nd
**Profil LinkedIn** : https://www.linkedin.com/in/ACwAACZANm8B4M3-Z2gKFkYRKqd7HE2gu7OPEos/
**Connexions partagées** : 6


---

# Maurine Fauvert

## Position actuelle

**Entreprise** : Hoplite VFX Studio

## Localisation & Industrie

**Localisation** : Montreal, Quebec, Canada

## Connexion

**Degré de connexion** : 2nd


---

# Maurine Fauvert

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7295506233522806784 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG3-bw3Xs49pA/feedshare-shrink_800/B4EZT7WnErGYAg-/0/1739383796634?e=1766620800&v=beta&t=DANjtMX8UhVobjAEEt48R1dGZW2IxqifqPXE63Fvzr8 | 🚀 Artiste pigiste 3D ? Grooming, compositing, lighting… ?

Chez Hoplite VFX Studio, on est toujours à l'affût de nouveaux talents ! Pas de poste ouvert pour le moment, mais on garde un œil sur les profils talentueux.

🎯 Envie de faire partie de notre réseau ? Remplis ce formulaire : https://lnkd.in/eTPw6JBQ

👉 Ajoute-moi sur LinkedIn et suis Hoplite VFX Studio pour ne rien manquer de nos opportunités.

📌 Important : seules les candidatures via ce formulaire seront prises en compte. Pas de mail, pas de DM.
🔥 Hâte de découvrir ton talent !


🚀 Freelance 3D artist? Grooming, compositing, lighting…?

At Hoplite VFX Studio, we’re always on the lookout for new talent! No open positions at the moment, but we love connecting with skilled artists for future opportunities.

🎯 Want to be part of our network? Fill out this form: https://lnkd.in/eTPw6JBQ

👉 Add me on LinkedIn and follow Hoplite VFX Studio to stay updated on our opportunities.

📌 Important: Only applications submitted via this form will be considered. No emails, no DMs.
🔥 Can’t wait to discover your talent! | 254 | 16 | 30 | 9mo | Thomas G. reposted this | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/tomgillet | 2025-12-08T05:07:29.944Z |  | 2025-02-12T18:17:10.023Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7402005924162203648 | Video (LinkedIn Source) | blob:https://www.linkedin.com/b609776b-0d86-4f5e-bf07-6d22d558e9d0 | https://media.licdn.com/dms/image/v2/D4E05AQHA7lMCw1SGUQ/videocover-high/B4EZrk1JC0IoBU-/0/1764775728597?e=1765782000&v=beta&t=PDHAvJGzCHnXlFyTglI52rL9OyVjSkDEDJCEPEGrj58 | Portfolio Boost, c’est déjà demain !
On est 120 inscrits 🎉 et il reste encore quelques places disponibles sur Zeffy pour les derniers motivés.
👉 Réservations Zeffy : https://lnkd.in/eZvCHeyn
Au programme : Portfolio reviews & clinique de cv, panels & mini-conférence, networking, session photo pro, expo costume ...
Un programme bien rempli… et j’ai vraiment hâte de vous accueillir demain à l'école NAD UCAQ!

 👉 Amenez votre portfolio, votre CV et votre énergie 💪
À demain ❤️🔥

Et merci à l'équipe qui me soutiens dans ce projet rhum - humans and resources , NAD, School of Digital Arts, Animation and Design - UQAC, SYNTHÈSE - Pôle Image Québec & Parallel Life Studios | 15 | 1 | 6 | 4d | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:17.456Z |  | 2025-12-03T15:28:54.940Z |  |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7401996997651714048 | Video (LinkedIn Source) | blob:https://www.linkedin.com/6167bb62-097c-46b0-97e6-5bb0504ee1f6 | https://media.licdn.com/dms/image/v2/D4E05AQExZ-DnY2J35Q/videocover-high/B4EZriiBSsHcBU-/0/1764737162384?e=1765782000&v=beta&t=2Gsss2HwVJy_jwfS1bHQGxluyD-XYHKmmfypjzdAQaU | Le 4ᵉ épisode de Could Be Better Podcast (CBB) est en ligne et il est dédié à Sylvie Trouvé & See Creature animation !
On y parle stop motion, business, mentorat, et bien plus encore.
Un épisode riche en conseils et en retours d’expérience ✨ | 4 | 0 | 0 | 4d | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:17.457Z |  | 2025-12-03T14:53:26.694Z | https://www.linkedin.com/feed/update/urn:li:activity:7401979791979171840/ |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7401640222834257920 | Video (LinkedIn Source) | blob:https://www.linkedin.com/38b57431-aed7-4c61-ac6c-e5718ec2b43c | https://media.licdn.com/dms/image/v2/D4E05AQFuBUvvQ6cTjw/feedshare-thumbnail_720_1280/B4EZrav9CgGUA0-/0/1764606600103?e=1765782000&v=beta&t=H58hIDLai1VONT9-iyopNpGzoyk-T3BCTMBpl8AcZC4 | Hoplite VFX Studio is expanding and launching new services!
We’re starting with 3D animation and clean motion capture.
My DMs are open if you have any questions or want to chat about collaboration 😊 | 26 | 0 | 2 | 5d | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:17.457Z |  | 2025-12-02T15:15:44.949Z | https://www.linkedin.com/feed/update/urn:li:activity:7401632494833336320/ |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7399160381174194177 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEalsckbRbpAQ/feedshare-shrink_800/B4EZq8ZKDPHEAg-/0/1764097303462?e=1766620800&v=beta&t=ZSOzNAemft4DI4KHlwVSSaYJ4shQAs1XXvFV70jtahs | 🔥 Portfolio Boost / Nouvelle mini-conférence annoncée !

Je suis ravie d’annoncer que nous accueillerons Margot Ingrassia pour animer une mini-conférence intitulée :
✨ “Tips & astuces pour réussir son entretien”

Si tu te poses des questions sur quoi dire, ne pas dire, comment te présenter ou comment répondre aux recruteurs, c’est le moment parfait pour obtenir des réponses claires et honnêtes.

Margot a passé les dernières années divers studios : the focus , puis Framestore, et travaille aujourd’hui chez Sony Pictures Imageworks
Autant dire : l’intervenante idéale pour te donner des conseils concrets dans un cadre informel et bienveillant.

🎟️ Rejoins-nous au prochain Portfolio Boost ! Billets ici : https://lnkd.in/eZvCHeyn

ℹ️ Petite mise à jour :
Suite à des obligations professionnelles, Lukas ne pourra malheureusement plus assurer sa mini-conférence “Optimiser ses chances, réussir son entrevue”.
Nous le remercions sincèrement pour le temps qu’il a déjà investi dans l’événement.
La conférence de Margot remplacera donc celle-ci. | 14 | 1 | 2 | 1w | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.663Z |  | 2025-11-25T19:01:44.624Z |  |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7398710759763070977 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGHxhTVf1p2rQ/feedshare-shrink_800/B4EZqxkZuoHEAg-/0/1763915701707?e=1766620800&v=beta&t=tt2d--4CgirEVqYzReo4F6ueS6HPPNGV4ZMsfFkFKrU | Envie de devenir mentor, partager ton expertise et repérer les talents de demain ?
Rejoins-nous le 4 décembre au NAD pour un événement dédié au partage et au réseautage.
 Plus d’infos juste ici : https://lnkd.in/eZvCHeyn



Un évènement Créative connect en collaboration avec rhum - humans and resources, NAD, School of Digital Arts, Animation and Design - UQAC, SYNTHÈSE - Pôle Image Québec | 19 | 0 | 6 | 1w | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.664Z |  | 2025-11-24T13:15:06.526Z |  |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7396193807567835136 | Video (LinkedIn Source) | blob:https://www.linkedin.com/8f7c3eca-5bad-465d-8c64-872aef0ce9c4 | https://media.licdn.com/dms/image/v2/D4E05AQEy3FbJuE-kxA/videocover-high/B4EZqSOKjNHgCI-/0/1763390011111?e=1765782000&v=beta&t=kX6Z4Y9TMFICXKTSFmyYWRCFBPzaonwZWeT_AHR0pWs | Bon lundi ! Tu viens à Portfolio Boost ?
Si tu veux booster ta carrière en VFX / 3D / jeux vidéo… c'est l'évènement parfait pour toi.
📅 Mercredi 4 décembre — École NAD-UQAC
 🎟️ Inscription OBLIGATOIRE sur Zeffy : https://lnkd.in/eZvCHeyn

🚀 AU PROGRAMME (pour pros & étudiants)
🕒 15h – 18h
 • Reviews de portfolio 1-to-1 avec rhum - humans and resources
 • Clinique de CV pour maximiser tes chances en entrevue
📸 17h – 19h
 • Session photo pro en studio (parfait pour ton LinkedIn ou ton CV)
🎤 18h30
 • Panel : les métiers 3D atypiques, animé par SYNTHÈSE - Pôle Image Québec
🤝 16h – 19h
 • Networking avec la gang des Jeudi VFX et Le Québec n'a plus d'effet(s)
 • Expo de pièces de costumes de la collection Parallel Life Studios, avec Arnaud Laye (expert impression 3D & fabrication)
🎯 Objectif : booster ton portfolio, ton réseau et ta visibilité en une seule soirée.


Merci à nos partenaires
 SYNTHÈSE - Pôle Image Québecèse  • rhum - humans and resources • NAD, School of Digital Arts, Animation and Design - UQAC | 22 | 3 | 3 | 2w | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.667Z |  | 2025-11-17T14:33:38.360Z |  |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7394022441657995264 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHClMQOdQDmBg/feedshare-shrink_800/B4EZpzYOs0KkAg-/0/1762872323479?e=1766620800&v=beta&t=BPQJv7LfjV8zLIA4Z6VfAdtLtvwKGvijX-thvQejps8 | ➡️  Portfolio Boost décalé le 4 décembre à l’école NAD-UQAC ! 

Suite à la grève de la STM, on a préféré décaler l’événement pour que tout le monde puisse venir sans stress nouvelle date : jeudi 4 décembre à partir de 15h !
Au programme :
-  Reviews de portfolio 1:1 avec des pros du milieu & clinique de CV en collaboration avec rhum - humans and resources
 - Photos professionnelles en studio pour booster ton profil LinkedIn & Pitch deck
 - Conférences thème annoncé bientôt 
-  Expo de costumes de super-héros (parce que la 3D, c’est aussi utile dans ce domaine )
 🍸 Et bien sûr, un petit drink de réseautage pour clôturer la soirée !
Que tu sois étudiant, junior ou pro, c’est l’occasion parfaite pour échanger, apprendre et tisser des liens dans la communauté VFX, animation et jeux vidéo. 💪
🎟️ Les billets juste ici : https://lnkd.in/eZvCHeyn
 👉 Si tu a des questions mes DM sont ouverts 
Merci à mes partenaires sur cet évènement : NAD, School of Digital Arts, Animation and Design - UQAC, rhum - humans and resources, SYNTHÈSE - Pôle Image Québec | 28 | 3 | 6 | 3w | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.667Z |  | 2025-11-11T14:45:24.385Z |  |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7392687505239592960 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEWXQ0KqkwVKQ/feedshare-shrink_800/B4EZpgZ1VLIUAg-/0/1762553977078?e=1766620800&v=beta&t=_2msfDQNnHMQL-VvXA0TTePCGECECeHyuLXx0YN1i2c | Tellement fière de notre équipe Hoplite VFX Studio ! Ce projet prouve qu’avec de la passion, les studios et jeux indépendants peuvent briller à grande échelle. | 26 | 1 | 1 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.669Z |  | 2025-11-07T22:20:50.741Z | https://www.linkedin.com/feed/update/urn:li:activity:7392687202746474496/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7391855107765706752 | Video (LinkedIn Source) | blob:https://www.linkedin.com/232b1565-353c-48db-826c-eb5d9787f500 | https://media.licdn.com/dms/image/v2/D4E05AQG-Wctenc2WOw/videocover-high/B4EZpSgdOhIQBU-/0/1762320832828?e=1765782000&v=beta&t=3I_lZmOwr5Ez11tOelNnPE8XXCGEKGpY2f-pfNHn_n8 | 💫 On parle VFX dans le deuxième épisode de Could Be Better !

🎧 Écoute l’épisode ici : https://lnkd.in/eGskF5Ju

Une première pour moi en tant qu’animatrice 🎙️
On discute avec Nathalie Girard, VFX Supervisor chez Cinesite, de créativité, de gestion d’équipe et de ce qui fait la magie derrière les effets visuels.
Un grand merci à Cinesite, Nathalie, et à mes acolytes Rexhino & Magalie pour cette belle aventure ✨

Et comme tout bon message Linkedin je ne peux pas finir sans vous dire abonnez-vous pour ne rien manquer !

#VFX #Podcast #CouldBeBetter #Cinesite | 32 | 1 | 1 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.670Z |  | 2025-11-05T15:13:11.718Z | https://www.linkedin.com/feed/update/urn:li:activity:7391851805082820608/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7391154127143346177 | Video (LinkedIn Source) | blob:https://www.linkedin.com/307d2ff8-e1b8-4241-8d77-864c4efef4e0 | https://media.licdn.com/dms/image/v2/D4E05AQF0wiqaQa_lrQ/videocover-high/B4EZpIEuamKMBU-/0/1762145791306?e=1765782000&v=beta&t=hw__TXvgdjZaEONYVMosQvgRilQjA-vk3Cgx-4qHHGY | On se retrouve Mercredi avec Nathalie Girard sur Could be better 💫 
➡️ https://lnkd.in/eGskF5Ju | 3 | 0 | 0 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.672Z |  | 2025-11-03T16:47:44.914Z | https://www.linkedin.com/feed/update/urn:li:activity:7391127092220030976/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7390027248898035713 | Article |  |  | 🎃 For Halloween, Hoplite is revealing its latest project : the cinematic for Menace.
 I’m so grateful for this amazing collaboration with Overhype Studios GmbH 
and Syama Pedersen on such a cool (and spooky!) concept.
So proud of our team and their incredible work, huge shout-out to all the Hoplite artists who made this possible 💥🖤
👉 Support us and take a moment to check it out! | 9 | 0 | 1 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.672Z |  | 2025-10-31T14:09:56.204Z | https://youtu.be/4KcdJck74d8 |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7389301326528073729 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGL8rJoN_PaBw/feedshare-shrink_800/B4EZotdxomKoAg-/0/1761699392373?e=1766620800&v=beta&t=muAo43rA-lo51bUZlFJfYXJfE4W0nUPygY8tAdASrc4 | 🎙️ Si vous avez raté l’info…
 Avec Rexhino Hoxhaj et Magalie Paradis, on a lancé Could Be Better Podcast (CBB), le podcast qui donne la parole aux pros des industries créatives et numériques.
👉 Objectif : partager des expériences concrètes, inspirer et armer tout les créatifs
 🎧 Tous les liens sont ici : https://lnkd.in/eGskF5Ju
💥 Dans une semaine, sort le nouvel épisode spécial VFX avec Nathalie Girard, VFX Supervisor chez Cinesite, une femme qui m’inspire au plus haut point.
 On y parle de son parcours, de son rôle de superviseure, et surtout du côté humain derrière la gestion d’équipes créatives.
Un immense merci à Jeanne Lessard et à Cinesite pour leur accueil dans leurs studios 🙏
Et si tu ne veux pas le rater, active la cloche dès maintenant 🔔
 En attendant, découvre le premier épisode sur le jeu vidéo avec Rexhino et Frederic Robichaud (Gearbox Entertainment) sur toutes nos plateformes 
J’ai trop hâte d’avoir vos retours 🥳 | 28 | 0 | 0 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.673Z |  | 2025-10-29T14:05:22.824Z | https://www.linkedin.com/feed/update/urn:li:activity:7389300122897231872/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7389090901920272385 | Video (LinkedIn Source) | blob:https://www.linkedin.com/38bedfa0-e4f2-49a3-8902-1dd1a4e2cb64 | https://media.licdn.com/dms/image/v2/D4E05AQGmTnizXgSAUA/videocover-high/B4EZotTATQKgCI-/0/1761696551694?e=1765782000&v=beta&t=p_LgzRJzZsmTcobmYP7Zs0Qfg6azRUW7lm8DVhOddmQ | Premier jour de MTL connecte @ Printemps numérique
Ravie de faire partie de la délégation des jeunes ambassadeurs de cette édition 💡
 Et surtout, d’avoir rencontré autant de jeunes entrepreneurs passionnés !
 C’est plus qu’inspirant de découvrir des personnes qui partagent le goût d’entreprendre, mais aussi l’envie d’évoluer avec la technologie, tout en l’encadrant avec sens.
Demain, je serai au Salon de l’innovation, au kiosque LOJIQ - Les Offices jeunesse internationaux du Québec-Office franco-québécois pour la jeunesse (OFQJ) à 16h.
 👉 Si vous voulez parler VFX, CGI ou industries numériques créatives, passez me voir !
Et comme vous le remarquerez… on a fait bon usage du photobooth 📸😉
#MTLConnect | 42 | 2 | 5 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.674Z |  | 2025-10-29T00:09:13.688Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7387242860762333184 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHShPA4hYiT7A/feedshare-shrink_800/B4EZoTCLzxHEAg-/0/1761255941459?e=1766620800&v=beta&t=mmh64A5E4gb2Ht7As_qQyF6EhKdZxSsaoUEf5iek-p0 | Hier, j’ai passé la journée à HUB Montréal 
Même si l’expérience immersive n’est pas mon domaine d’activité principal, je reste toujours fascinée par la créativité et les différentes formes qu’elle peut prendre.

Cette journée m’a aussi permis de visiter OASIS immersion et de débloquer une partie d’un projet sur lequel je travail, comme quoi, les meilleures idées viennent souvent d’ailleurs ✨

Et pour finir, j’ai passé la soirée chez Moment Factory , à courir après des balles projetées au sol et à convaincre d’autres personnes de faire de même… et il y avait même un zèbre 🦓

Merci Albane Français pour cette belle opportunité et pour ces moments d’inspiration ! 🙌

On se retrouve la semaine prochaine à MTL connecte @ Printemps numérique | 46 | 3 | 0 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.676Z |  | 2025-10-23T21:45:46.341Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7386744830175002624 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGykrKvtoRL0g/feedshare-shrink_800/B4EZoKAOTrIQAg-/0/1761104500707?e=1766620800&v=beta&t=40QXp3gbaNKk7uxFvGGZuwF311Lrvi7VkPY4B65NuPI | Le premier épisode de Could Be Better Podcast (CBB) est en ligne ➡️ https://lnkd.in/e6Gsgc5u

Frederic Robichaud y parle de son rôle de directeur technique chez Gearbox Entertainment en compagnie de Rexhino Hoxhaj 👾

N’hésitez pas à vous abonner pour nous soutenir et on se retrouve dans 2 semaines pour parler VFX 🥳 | 8 | 0 | 1 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.676Z |  | 2025-10-22T12:46:46.596Z | https://www.linkedin.com/feed/update/urn:li:activity:7386740682079719424/ |  | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7386385864567836672 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHY69DhNbAJNQ/feedshare-shrink_800/B4EZoCEIFbHoAk-/0/1760971228741?e=1766620800&v=beta&t=W6yL7omsHfG0umhteaFQ6X5_0paS3Sqaxm-O5DH4p04 | 🎉 Nouvelle annonce pour Portfolio Boost !
Bonjour à tous,
 Encore une belle nouvelle à partager pour l’événement !

➡️  Le studio Parallel Life Studios prêtera plusieurs pièces de costumes et moules issus de sa collection pour une exposition exclusive pendant Portfolio Boost. Merci à LOIC MICHEL de permettre cet échange possible.

Arnaud Laye, artiste 3D et spécialiste en impression 3D de costumes, sera également présent pour échanger avec les participants et parler de son métier.

📍 Jeudi 27 novembre – École NAD-UQAC
 🎟️ Infos et inscription : https://lnkd.in/eZvCHeyn

Cet évènement est en collaboration avec rhum - humans and resources, NAD, School of Digital Arts, Animation and Design - UQAC & SYNTHÈSE - Pôle Image Québec | 35 | 0 | 4 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.677Z |  | 2025-10-21T13:00:22.526Z |  |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7385350818130083840 | Article |  |  | 🎙️ J’ai eu la chance de passer dans l’émission Transmission de Julien Klein !
Peut-être que vous commencez à me connaître…
Et vous savez que je pense qu’on n’avance jamais seul. 💬
Les moments de partage de savoir, d’échange et de transmission d’expérience sont, pour moi, le vrai moteur d’une carrière. 

Un super moment d’échange avec Francis di Stasio et Stephane D'Astous, deux parcours inspirants, deux visions complémentaires du métier.
 Si vous aimez les discussions authentique, foncez écouter l’épisode, il est en ligne dès aujourd’hui 🎧
Merci à Julien Klein pour l’invitation et pour créer ces espaces où on apprend autant qu’on partage 🙌
https://lnkd.in/eKiJCCzK | 23 | 0 | 3 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.680Z |  | 2025-10-18T16:27:28.225Z | https://www.youtube.com/watch?v=DNYOb1ChpMA |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7384971187979997185 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGSndxJ6iR4Vw/feedshare-shrink_800/B4EZntiZaKHoAg-/0/1760626938783?e=1766620800&v=beta&t=O6EA3HtW2Rkob0GNdHz2ADiHEmRT7uM1OomkD2ZjWL8 | Retrouvez Rexhino Hoxhaj en compagnie de Frederic Robichaud pour échanger de son rôle de directeur technique chez Gearbox Entertainment 🎮  Mercredi prochain sur toutes vos plateforme d'écoute favorite ➡️ https://lnkd.in/eGskF5Ju | 13 | 2 | 0 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.681Z |  | 2025-10-17T15:18:57.344Z | https://www.linkedin.com/feed/update/urn:li:activity:7384604619982663680/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7384591101917294592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEnzZNuDHg-pg/feedshare-shrink_800/B4EZntWeZJHoAg-/0/1760623716641?e=1766620800&v=beta&t=c2q-ia3UezRHSEhmQgOgkWcLoVUKz64ydyG2W5pIxkM | 🌟 Portfolio Boost, un événement pour propulser ta carrière créative !
 🎨🎮 VFX • Animation • Jeu vidéo • 3D • Design
Le jeudi 27 novembre, Creative Connect t’invite à une soirée unique à l'École NAD-UQAC : rencontres avec des pros du recrutement, review de portfolios, réseautage… et une nouvelle activité vient s’ajouter au programme 👇

🎤 Mini-conférence – 18h à 18h30
 Optimiser ses chances : avoir & réussir son entrevue

 Avec 🇨🇦 ⚜️ Lukas Kurtesanin ⚜️ 🇨🇦 – Talent Acquisition Specialist
Obtenir une entrevue, c’est déjà une victoire.
Mais la transformer en opportunité concrète, c’est un art ✨

Rejoins Lukas, recruteur expérimenté dans l’industrie du jeu vidéo (ex-Gameloft Montréal, aujourd’hui chez Desjardins), pour une discussion authentique et sans tabou sur :
↗️ Maximiser ses chances d’être contacté : CV, portfolio, attitude et communication avec les recruteurs. 
✅ Réussir son entrevue : comment se préparer, structurer ses réponses et mettre en valeur son parcours avec impact. 

🎟️ Inclus avec ton billet Portfolio Boost, lien en commentaire 
 📍 École NAD-UQAC – 27 novembre, dès 15h ( programmation complète à venir ) 
 🤝Merci aux partenaires de cet évènement rhum - humans and resources, NAD, School of Digital Arts, Animation and Design - UQAC & SYNTHÈSE - Pôle Image Québec | 16 | 2 | 4 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.681Z |  | 2025-10-16T14:08:37.765Z |  |  | 

---

## Post 21

https://www.linkedin.com/feed/update/urn:li:activity:7383880015073005568 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQFB71BEazcNjA/videocover-low/B4EZneUeaMKgB4-/0/1760371614750?e=1765782000&v=beta&t=3SMRsez2Jz1kBQm__4E-iKar33jk71PhjliShfO7siI | 👀 Menace approche…
 Le 31 octobre, découvrez la version longue de Menace, notre dernière production réalisée avec Overhype Studios GmbH & Syama Pedersen
Une cinématique pensé pour plonger dans l’univers du jeu et en capter toute l’intensité, en attendant le version longue voici le teaser. 
🎬 Vous travaillez sur un jeu, une cinématique ou un projet immersif ?
Restons en contact ! Hoplite est toujours partant pour de nouvelles collaborations créatives. | 15 | 0 | 0 | 1mo | Post | Maurine Fauvert | https://www.linkedin.com/in/maurine-fauvert | https://linkedin.com/in/maurine-fauvert | 2025-12-08T06:09:22.682Z |  | 2025-10-14T15:03:01.450Z | https://www.linkedin.com/feed/update/urn:li:activity:7383849160569163777/ |  | 

---



---

# Maurine Fauvert
*Hoplite VFX Studio*

*Scraped: 2025-12-08*

---

## 📊 Summary

| Source | Results |
|--------|---------|
| Articles & Blogs (Exa) | 5 |
| YouTube Videos | 0 |
| Press & Mentions (Google) | 2 |

---

## 📚 Articles & Blog Posts

### [Blog-en -](https://hoplitevfx.com/blog-en/)
*2025-03-07*
- Category: blog

### [Hoplite VFX Studio | LinkedIn](https://ca.linkedin.com/company/hoplite-vfx-studio)
*2025-05-04*
- Category: article

### [The Art of the Frame: An interview with the VFX team behind "Napoleon" by Art of the Frame -](https://provideocoalition.com/the-art-of-the-frame-an-interview-with-the-vfx-team-behind-napoleon)
*2023-11-22*
- Category: article

### [Art of the Frame Podcast: Editors on Editing with “Inside Out 2” Editor: Maurissa Horwitz by Art of the](https://provideocoalition.com/art-of-the-frame-podcast-editors-on-editing-with-inside-out-2-editor-maurissa-horwitz)
*2024-07-24*
- Category: podcast

### [Navigating Tech and Animation: Insights from Céline Durieux](https://blog.reemo.io/navigating-tech-and-animation-insights-from-celine-durieux)
*2025-04-22*
- Category: blog

---

## 🎬 YouTube Videos

*No videos found*

---

## 🔎 Press & Mentions

- **[These Are the Clones You're Looking For: Hoplite VFX Fires Up 'Star ...](https://digitalproduction.com/2025/08/18/these-are-the-clones-youre-looking-for-hoplite-vfx-fires-up-star-wars-the-212/)**
  - Source: digitalproduction.com
  - *Aug 18, 2025 ... Producer Maurine Fauvert reveals how a two-artist side project ... hoplite-vfx-studio. Tap to unmute. Your browser can't play this vi...*

- **[Blender brille dans un fan film Star Wars réalisé par Hoplite Studio ...](https://blendamator.com/blender-star-wars-hoplite-studio/)**
  - Source: blendamator.com
  - *Mar 4, 2025 ... Un nouveau venu vient de faire une entrée fracassante dans le monde de l'animation. Hoplite VFX Studio, fraîchement établi à Montréal ...*

---

*Generated by Founder Scraper*
