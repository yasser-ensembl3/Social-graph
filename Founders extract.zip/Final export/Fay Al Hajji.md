# Fayçal Hajji

## Post 1

https://www.linkedin.com/feed/update/urn:li:activity:7401365436132446208 | Video (LinkedIn Source) | https://dms.licdn.com/playlist/vid/v2/D4E05AQEiHdmq9FNMFw/mp4-720p-30fp-crf28/B4EZrbuk6tKUCM-/0/1764623029819?e=1765778400&v=beta&t=6Pv7ffiwAiKULtru7fPzdG3u-A_wBCTIm8z6HJcjq4I | https://media.licdn.com/dms/image/v2/D4E05AQEiHdmq9FNMFw/feedshare-thumbnail_720_1280/B4EZrbuk6tKUA8-/0/1764623011988?e=1765778400&v=beta&t=Qhz2iEszCVFqYpA8aGfKHXgW2IzDGml5LPtSJtzKCvg | 🚨 We’ve been building quietly for almost a year... 
Now it’s time. Introducing our new #Manifesto #film: THE UN KNOWN is Calling! ☎️ 

On November 14, we’ve revealed a whole new universe, from brand, tech, art, sound, culture… all fused into one immersive experience. 

Feel the frequency. If it resonates… you know what comes next. 😉 

.
.
.
.
.
#AnswerTheCall #theunknowntv #theunknown #NextGen #Consultancy #Creative #Strategy #Production #Media #Tech #Ai | 72 | 16 | 0 | 6d | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.004Z |  | 2025-12-01T21:03:50.694Z |  |  | 

---

## Post 2

https://www.linkedin.com/feed/update/urn:li:activity:7397731317246828544 | Article |  |  | Un parcours profondément personnel. Quand la COVID a frappé en 2020, notre agence s’apprêtait à vivre sa meilleure année… puis tout s’est effondré. Ce choc a été un moment de vérité qui m’a obligé à chercher plus loin que le business as usual.

En 2021, nous avons reconstruit à partir de zéro.
En 2022, nous avons plongé dans l’IA.
En 2023, nous avons commencé à y investir sérieusement.
Et en 2025, à travers certaines expériences profondes où le nom THE UN KNOWN n’a jamais eu autant de sens, j’ai trouvé le courage de tout remettre en question et de tout réimaginer.

Aujourd’hui, nous dévoilons bien plus qu’une nouvelle identité. Nous présentons l’évolution naturelle d’un modèle d’agence né d’une maison de production, devenu une Next-Generation Consultancy AI-first mais qui reste profondément humaine. Un pont clair entre l’intelligence d’affaires et l’âme créative. Un espace où la stratégie, la créativité, la production et l’IA s’unissent pour propulser les marques vers une nouvelle ère de croissance et d’impact mesurable.

Ce n’est pas simplement une évolution de services. C’est une transformation d’identité, de mission, et surtout, d’intention. Nous accompagnons les leaders qui veulent créer de nouveaux marchés, briser les modèles établis et bâtir des marques à forte portée.

Notre modèle? Un credo simple en trois temps : Illuminer. Transformer. Croître.

Je suis profondément fier de ce chemin. Les meilleures visions naissent souvent des moments les plus difficiles, là où résilience, courage et intuition peuvent réellement transformer l’inconnu en terrain de jeu.

Mais la chose qui me rend le plus fier aujourd’hui, c’est notre équipe. Un énorme merci !! Vous avez saisi cette vision dès le premier jour, et depuis février, vous avez travaillé sans relâche pour lui donner vie, d’une façon que je n’aurais jamais imaginée. Votre talent, votre engagement et votre cœur ont façonné cette nouvelle identité. Elle compte énormément pour moi. Et désormais, elle vous appartient autant qu’à moi. 🫶 💪 🙏 

On continue d’illuminer l’inconnu et de transformer le connu, ensemble. ✨ 

👉 Aneta Kanaan Christian Blais Iheb Belaid Raouia Koubaa Simon Mantha Catherine Duguay-Blackburn Soufiane Bouchouf Zakaria Sassioui, M.Sc Tairone Livinalli Julie Gauthier Alexandre Verreault Fred Gray Victoria Ambroziak Emmanuelle Solo 💜 
https://lnkd.in/eezuHA9a | 98 | 2 | 3 | 2w | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.005Z |  | 2025-11-21T20:23:09.233Z | https://www.grenier.qc.ca/actualites/52492/nouvelle-identite-pour-the-un-known |  | 

---

## Post 3

https://www.linkedin.com/feed/update/urn:li:activity:7392631296402853888 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEmHCOXXpF-fQ/feedshare-shrink_800/B4EZpfm_S3HcAo-/0/1762540648229?e=1766620800&v=beta&t=ITW1-FJOvN6nO1ngzENdcYA4oe16KQTdXZC4EoQC6Wg | Step into the new era. THE UN KNOWN is Calling!!
An immersive night where #vision, #sound, and #strategy converge. 
A new chapter begins, where strategy meets spirit, creativity meets code, and innovation meets ritual.

Join us for THE UN KNOWN Rebrand Launch Experience, an immersive night blending sound, taste, and story to reveal our new identity and campaign: 
“THE UN KNOWN Is Calling.” ☎️ 

Expect:
• An epic DJ lineup curating the soundtrack of transformation (The Neighbors, Laura Scavo, MIMI ID et Colme)
• Unique Cocktail creations crafted to connect body, mind, and movement
• A multisensory journey through our new identity within our film studios.
• Powerful networking with top-tier founders, creators, and decision makers from Montreal and abroad

This is where the next wave begins, not as a brand, but as a collective resonance.

If you can feel this, you’ve already been chosen.
The call is real. The moment is now.
#AnswerTheCall 📞

.
.
.
.
#theunknown #theunknowntv #nextgenconsultancy #advertising #Creativeagency #Strategy #BrandedEntertainment #storytelling #AdvertisingAgency #illuminateTheUnknown #TransformTheKnown
Aneta Catherine Julie Iheb Christian Alexandre Soufiane Raouia Tairone Zakaria Andy Simon Fred Victoria | 32 | 0 | 5 | 1mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.006Z |  | 2025-11-07T18:37:29.510Z |  |  | 

---

## Post 4

https://www.linkedin.com/feed/update/urn:li:activity:7387175188267913217 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEPiW6thortJg/feedshare-shrink_800/B4EZoSEr3_IIAk-/0/1761239810081?e=1766620800&v=beta&t=-oCr4t_VhDxfCx96fPrk8g6iZ3rlBs6TfTGIG_ymVSg | Last month, I had the privilege of taking the stage at ALL IN 2025, the largest AI conference in Canada, to share what we’ve learned  through THE UN KNOWN, about bringing AI into the world of advertising and marketing.

Over the past few years, we’ve tested, failed, iterated and ultimately discovered what truly works when integrating #AI into advertising workflows, from creative generation to real time optimization.

It’s been a long journey of experimentation and validation, and standing on that stage among some of the top AI minds in Canada 🇨🇦 from the brightest #founders, #researchers, and #visionaries shaping the future of #AI, was a powerful moment of recognition, not just for our work, but for everyone shaping the future of AI and AdTech.

We believe the next wave of marketing isn’t just automated. It’s agentic, data-driven, and human augmented.

PS: Stay tuned, soon we’ll share not only our insights, but also the solution we’ve been building. ⚡️

.
.
.
.

#AI #AdTech #Innovation #Entrepreneurship #Startups #Marketing #Media #AdsToCash #TheUnknown #ALLIN2025 #NextAI #CDLMontreal #Montreal #AIStartups #BusinessGrowth #FounderLife | 137 | 25 | 1 | 1mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.008Z |  | 2025-10-23T17:16:51.961Z |  |  | 

---

## Post 5

https://www.linkedin.com/feed/update/urn:li:activity:7385066750695985152 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQF7vln5YOjALg/feedshare-shrink_800/B4EZnywgZbJ0Ag-/0/1760714427395?e=1766620800&v=beta&t=sYcUlk677CmGO7sVNneYd6H8-otaLZMAMg5EE1xP5u8 | Honored to join this panel as we open a new chapter for #AdTech in #Montreal.
Most people still think #AI is about content automation. It’s NOT.
We’re entering the era of #AgenticAI, where AI doesn’t just assist… 
it Acts. It Executes. It Drives Revenue.

it isn’t about making ads faster. It’s about turning attention directly into cash, autonomously. Let’s build systems that don’t wait for instructions, but rather generate outcomes.

Excited to contribute to this conversation. Montreal has everything it needs to lead. | 59 | 26 | 0 | 1mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.009Z |  | 2025-10-17T21:38:41.271Z | https://www.linkedin.com/feed/update/urn:li:activity:7384971569158070273/ |  | 

---

## Post 6

https://www.linkedin.com/feed/update/urn:li:activity:7376986884402745344 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHMnxf_Skf-OA/feedshare-shrink_800/B4EZmBFS3TIwAo-/0/1758807273869?e=1766620800&v=beta&t=Vl25MIRWlSX-a7hk9fWjybqHZL1i5BqITvF0Gsba2Ok | We’re just getting started. The future of #AI in #AdTech and beyond is being shaped right here in #Montreal , and we’re #Allin! ✨💪🏼
.
.
.
.

#ALLIN2025 #AdTech #Innovation #theunknowntv #Media #aistartup #illuminatetheunknown #stepintotheunknown #advertising | 61 | 3 | 0 | 2mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.010Z |  | 2025-09-25T14:32:11.030Z | https://www.linkedin.com/feed/update/urn:li:activity:7376972390305796096/ |  | 

---

## Post 7

https://www.linkedin.com/feed/update/urn:li:activity:7376938402648317952 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE73_zeiv3hfA/feedshare-shrink_800/B4EZkz.rPPKsAk-/0/1757513693366?e=1766620800&v=beta&t=qnjvlIt_-7AN3RaRa45F1MmHmDbJQvrqjK45iorpaNQ | Another bold step forward. Zylio AI rewriting the rules of #procurement and backed by MFOUNDERS 🙌🏼✌🏼👏🏼 | 61 | 5 | 0 | 2mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.010Z |  | 2025-09-25T11:19:32.079Z | https://www.linkedin.com/feed/update/urn:li:activity:7371546720952020992/ |  | 

---

## Post 8

https://www.linkedin.com/feed/update/urn:li:activity:7366813107580575744 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFs1S9ELZks0w/feedshare-shrink_800/B4EZjrFzjOIIAk-/0/1756290825939?e=1766620800&v=beta&t=fxgyLhKExBC5GzzYR22OzIJk-50I13A5K1yM2zkGg_k | Grateful to walk alongside inspiring people who see creativity as a true force for transformation. 🙏🏽

Every great journey is fueled by courage, belief, and mostly, the people who we share the path with. With a mentor and a brother like Ilan, we’re not just building projects, we’re shaping impact, legacy, and the future of the Moroccan start up ecosystem! 🇲🇦🚀 | 71 | 9 | 0 | 3mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.011Z |  | 2025-08-28T12:45:13.616Z | https://www.linkedin.com/feed/update/urn:li:activity:7366418573403062274/ |  | 

---

## Post 9

https://www.linkedin.com/feed/update/urn:li:activity:7350891336885067776 | Image |  | https://media.licdn.com/dms/image/v2/D5622AQGKtgCNrCEkYw/feedshare-shrink_800/B56Zf2Ez3OHoAk-/0/1752180146566?e=1766620800&v=beta&t=r5GYWtzwq4UOVZEePKtGjTp7TveFYDS9dpNNy-i3Ljw | 🤩 🚨 We’re soooo grateful to be recognized among Canada’s Top 100 #AI #startups by ALL IN 2025. This is just the beginning, as our team at THE UN KNOWN is building something truly special with SPRKR. Leveraging over a decade of experience and millions invested in paid media, SPRKR is powered by a proprietary #algorithm and a #DataWarehouse designed to #Learn, #Predict and #Optimize what really moves the needle for SMBs. ✨ 

Our new Ads→Cash solution will spend your media dollars smarter while continuously monitoring and optimizing campaigns, so you can scale effortlessly. 

We can’t wait to share more in the coming months. This is only the start.⚡️ 
Kudos to Zakaria Sassioui, M.Sc Tairone Livinalli, Andy Fang, Aneta Kanaan Soufiane Bouchouf Julie Gauthier 💪 | 98 | 35 | 4 | 4mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.012Z |  | 2025-07-15T14:17:47.670Z | https://www.linkedin.com/feed/update/urn:li:activity:7349441090153795587/ |  | 

---

## Post 10

https://www.linkedin.com/feed/update/urn:li:activity:7334001912867950592 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQHQYzAzkXOUGw/feedshare-shrink_800/B4EZcbSF.ZHkAk-/0/1748509418721?e=1766620800&v=beta&t=kGurPEfILGM8LOFXlVNO7yqiTHdmkavTm3yhBwBtPAk | 🚨MFOUNDERS en Recrutement sur #Casablanca 🇲🇦✨À qui la chance?! 
Plus de détails sur le post 👇 | 6 | 0 | 0 | 6mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.013Z |  | 2025-05-29T23:45:15.194Z | https://www.linkedin.com/feed/update/urn:li:activity:7333780053022941184/ |  | 

---

## Post 11

https://www.linkedin.com/feed/update/urn:li:activity:7333551078598209536 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFoELZNfPF0TQ/feedshare-shrink_800/B4EZcX_7BSHcAw-/0/1748454327830?e=1766620800&v=beta&t=Op35XQVw4HELi9KdlfdSh489T-eiEU2RccRkT768UCM | 🚨 Check this out! 👇 
Our team’s cooking up a super creative website project, and we need a fly freelance UX/UI designer to join the ride! Send your portfolios our way, and let’s chat! | 32 | 2 | 0 | 6mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.013Z |  | 2025-05-28T17:53:47.928Z | https://www.linkedin.com/feed/update/urn:li:activity:7333548985418203136/ |  | 

---

## Post 12

https://www.linkedin.com/feed/update/urn:li:activity:7332745687345856512 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQEu4EhWMIrThg/feedshare-shrink_800/B4EZcMP3zKGQAg-/0/1748257178066?e=1766620800&v=beta&t=XIW5DJRKdWUvOiJriyQwh9fxta4DH2QUmWfUBTqqAc4 | ✨Great energy and sharp minds at the UM6P - Story School gathering in #Montréal. This is exactly the kind of move that will redefine how #Africa and #Morocco tell their #stories, #communicate with impact, and own their #narrative in a global market hungry for authenticity, #culture, and #innovation.

Big thanks to Meriem Idrissi Kaitouni for bringing us together and driving this vision forward. 🇲🇦🚀📈 | 64 | 2 | 0 | 6mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.014Z |  | 2025-05-26T12:33:27.690Z | https://www.linkedin.com/feed/update/urn:li:activity:7332722083820412928/ |  | 

---

## Post 13

https://www.linkedin.com/feed/update/urn:li:activity:7316487511327821824 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQE5yaKlOdDIvQ/feedshare-shrink_800/B4EZYlEV30HcAg-/0/1744378618760?e=1766620800&v=beta&t=wycfEyqoelIXZDBU__gceFtgDdqlit1ArLUJZVOLTS8 | Even from across the ocean, I couldn’t help but feel proud of what the MFOUNDERS community & Ilan Benhaim ccomplished last night in #Paris. 🇫🇷
Over 60 #investors, #entrepreneurs, and members of the #MoroccanDiaspora came together for an evening of meaningful exchange — all driven by a shared ambition to support high-impact #Startups from #Morocco.

Grateful to our partners at UM6P Ventures France, and to everyone who brought their energy, insights, and vision to the table.
M Founders exists: to activate a #Global, engaged network ready to give more than just #capital but also time, mentorship, ideas and solid connections to build a true collective strength. 💪 

Proud to be part of this story. The best is yet to come. 🌍 ✨ 🇲🇦 

#MFounders #ImpactInvesting #MoroccanDiaspora #Startups #CollectivePower #Investmentclub #DealClub | 66 | 2 | 0 | 7mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.015Z |  | 2025-04-11T15:49:16.465Z | https://www.linkedin.com/feed/update/urn:li:activity:7316454228938420224/ |  | 

---

## Post 14

https://www.linkedin.com/feed/update/urn:li:activity:7315762089979969537 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E05AQELgiDtA8Ccbg/feedshare-thumbnail_720_1280/B4EZYbOwdLHMA8-/0/1744213578333?e=1765778400&v=beta&t=rDLt-_2Hg4kv76Xlh3WDhiglipscwIGKQAVJOox2cAo | Just a kid with ideas… Still building, still learning, still dreaming. 💭⚡️
The only path worth craving is your own. ✍️✨
Couldn't resist to make the #Unboxing video experience of the collectible this #FounderSeries Collectible 😇 🚀 

.
.
.
.
.
.
.
#workfun #passion #theunknowntv #FounderSeries #LightsAndShadows #entrepreneurmind #buildinpublic #creativejourney #visionary #leadership #startuplife #mfounder #dreambuildrepeat #purposedriven #brandbuilder 
#humblehustle #FH4Point0 #theunknown #fyp #elfafito #foryou #fypシ #foryoupage | 53 | 0 | 0 | 7mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.016Z |  | 2025-04-09T15:46:42.538Z |  |  | 

---

## Post 15

https://www.linkedin.com/feed/update/urn:li:activity:7315544469292937216 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQGh82S0q5zzzg/feedshare-shrink_800/B4EZYYI6.THgAg-/0/1744161717047?e=1766620800&v=beta&t=BjY-lm74kIfXMk62ihsTP6vEIKE1wKPSZEmp45kpmuA | From Startup grind to collectible mind. The founder series—Collectible Action Figure by THE UN KNOWN ✨✌🏼

.
.
.
.
.
.
#lightsandshadows #founderseries #theunknowntv #startup #collectibles #figure #unboxing #foryou #fypage #fy #entrepreneur #founder #fyp #business #art #creativity | 23 | 3 | 0 | 7mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.017Z |  | 2025-04-09T01:21:57.723Z |  |  | 

---

## Post 16

https://www.linkedin.com/feed/update/urn:li:activity:7293026928507117568 | Text |  |  | Dare to #code beyond the conventional? ✨ 
At THE UN KNOWN, we’re on a mission to illuminate the unknown and transform the known—one line of code at a time. 

We’re growing our #Tech team, and looking for a Sr #FullStack #Software #Engineer, Front End Heavy, ready to drive high-performance web applications, fine-tune AI models, and engineer digital experiences that defy limits. If you thrive on creating seamless, scalable solutions and turning visionary ideas into reality, join us on a journey where innovation meets impact.

Ready for the challenge? Apply now and help us shape the future! 💪 🚀 
.
.
.
.
.
.
#Hiring #Engineer #Developper #Software #Website #Ai #AiSolutions #Research #Infrastructure #Backend #FrontEnd #GrowingFamily #BestTeam #theunknowntv | 96 | 1 | 0 | 10mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.018Z |  | 2025-02-05T22:05:17.644Z |  | https://www.linkedin.com/jobs/view/4144494244/ | 

---

## Post 17

https://www.linkedin.com/feed/update/urn:li:activity:7292897278170705920 | Video (LinkedIn Source) |  | https://media.licdn.com/dms/image/v2/D4E10AQHRPEvyLzzP9w/videocover-low/B4EZTTFnLNGwA8-/0/1738708274247?e=1765778400&v=beta&t=qu5NxauM79zNRg0UMzEmN6drkuza0r6Y2EqBFcAbuY4 | So proud of our incredible team at THE UN KNOWN for delivering across the board—from strategy to creative to amplification. But more than anything, I’m deeply grateful to the amazing team at MHI RJ Aviation Group— Mélanie Stephanie, Stella and Ross—for their trust in us to handle all their business marketing/Communication needs.

Collaborating with visionary teams like yours is what makes our work truly meaningful. Excited for what’s ahead! 🙏🏼✨✌🏼

.
.
.
.
#advertising #marketing #filmProduction #content #paidmedia #amplification #technology #brandedentertainment #digital #production #communication #experiential #storytelling | 105 | 0 | 0 | 10mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:36.019Z |  | 2025-02-05T13:30:06.595Z | https://www.linkedin.com/feed/update/urn:li:activity:7292671128970416128/ |  | 

---

## Post 18

https://www.linkedin.com/feed/update/urn:li:activity:7283583877317574656 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQExTANbi4igVA/feedshare-shrink_800/B4EZRP22pAHsAg-/0/1736506582532?e=1766620800&v=beta&t=4tuNQZI_ptJ9AAZpxVx8DA8UkIxkhvugrsJapLt4pYo | Proud to see how MFOUNDERS is empowering #Moroccan #startups on a global stage! As part of the #diaspora, I truly believe we can unlock incredible opportunities by joining forces to support #local #innovators. If you’d like to learn more about #MFounders’ #Investor #Club—or just want to chat about making a difference back #home—drop me a DM anytime! 💪 🇲🇦 🚀 | 79 | 0 | 0 | 10mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:40.493Z |  | 2025-01-10T20:41:58.797Z | https://www.linkedin.com/feed/update/urn:li:activity:7283436531640369152/ |  | 

---

## Post 19

https://www.linkedin.com/feed/update/urn:li:activity:7275197855835815937 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQFpMU2Hpte1ZA/feedshare-shrink_800/B4EZPY2hp3HwAg-/0/1734509993345?e=1766620800&v=beta&t=ExYZvRlxzRzup3uF0Ge-VTig_7qIV0k2Vq5kLgVgBJU | After the first successful investment round for Alya, a 2nd Investment is on the way in a very promising industry, will be disclosed soon! Stay tuned with MFOUNDERS latest news! 💪 🇲🇦 🙌 




.
.
.
.
.
#InvestmentClub #MoroccanDiaspora #Moroccanwithoutborders #venturecapital #investments #MoroccanFounders #MoroccanTech #technology #entrepreneurs #entrepreneurship #unicorn #IlanBenhaim | 51 | 0 | 0 | 11mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:40.495Z |  | 2024-12-18T17:18:55.471Z | https://www.linkedin.com/feed/update/urn:li:activity:7275062210349940736/ |  | 

---

## Post 20

https://www.linkedin.com/feed/update/urn:li:activity:7272118163553632256 | Image |  | https://media.licdn.com/dms/image/v2/D4E22AQG0i8FbhAgD4Q/feedshare-shrink_800/feedshare-shrink_800/0/1733477588793?e=1766620800&v=beta&t=joq8Jxamj4mqIllbTtmopx48pIRt4U4DU_LqjXVcBGE | 🇲🇦 x 🇨🇦 MFOUNDERS ✅ | 10 | 0 | 0 | 11mo | Post | Fayçal Hajji | https://www.linkedin.com/in/faicalhajji | https://linkedin.com/in/faicalhajji | 2025-12-08T05:01:40.495Z |  | 2024-12-10T05:21:19.613Z | https://www.linkedin.com/feed/update/urn:li:activity:7270731987923959808/ |  | 

---

